"""Runtime license enforcement (EPIC O).

Two pieces:

    KillSwitch          4-tier on/off control. Tiers stack: a higher tier
                        OFF beats every lower-tier ON.

                        TIER 1: per-workflow         (admin portal)
                        TIER 2: per-org              (admin portal)
                        TIER 3: per-license          (license server flag)
                        TIER 4: global (Cloudflare KV) — <60s worldwide

    HeartbeatEnforcer   Periodically calls the M.7 LicenseClient.heartbeat
                        and trips KillSwitch.tier_3 on revoke or repeated
                        network failures past a grace window.

The kill switch is the contract between the local CLI and the license
server. Any persona pipeline / workflow run consults the switch before
emitting a verdict; if any tier is OFF, the run aborts with a structured
KillSwitchTripped exception that the CLI surfaces with the right tier
label.

Usage:
    from agents._shared.harness.enforcement import (
        KillSwitch, KillSwitchTripped, KillTier, HeartbeatEnforcer,
    )

    switch = KillSwitch()
    switch.tier_3_off("license revoked", reason="payment failed")
    switch.assert_running()  # raises KillSwitchTripped(tier=3)
"""

from agents._shared.harness.enforcement.global_kill import (
    GlobalKillConfig,
    GlobalKillFetcher,
)
from agents._shared.harness.enforcement.heartbeat import (
    HeartbeatConfig,
    HeartbeatEnforcer,
    HeartbeatStatus,
)
from agents._shared.harness.enforcement.kill_switch import (
    KillSwitch,
    KillSwitchTripped,
    KillTier,
)

__all__ = [
    "KillSwitch",
    "KillSwitchTripped",
    "KillTier",
    "HeartbeatEnforcer",
    "HeartbeatConfig",
    "HeartbeatStatus",
    "GlobalKillFetcher",
    "GlobalKillConfig",
]

__version__ = "1.0.0"
