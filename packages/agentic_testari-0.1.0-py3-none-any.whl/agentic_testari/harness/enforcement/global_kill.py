"""GlobalKillFetcher — poll the admin portal's tier-4 flag.

Sits alongside HeartbeatEnforcer in the runtime: both run as long-lived
loops; both can trip the KillSwitch. The fetcher polls the admin
portal's GET /v1/kill/global endpoint every `interval_seconds` and
flips KillSwitch.tier_4_global_off / tier_on accordingly.

Unlike HeartbeatEnforcer, GlobalKillFetcher DOES auto-recover: if the
global flag flips back to OFF, tier 4 returns to ON. Rationale: the
admin portal is the source of truth for tier 4; if Cloudflare KV says
"unkilled", customers should resume immediately. (Tier 3, by contrast,
requires manual operator re-arm because revoke is a security event.)

Network failures are treated as `inactive=False` — we INTENTIONALLY do
NOT trip tier 4 on Cloudflare being down, because that would amplify
incidents into a self-inflicted global outage.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Protocol

from agents._shared.harness.enforcement.kill_switch import KillSwitch, KillTier

logger = logging.getLogger(__name__)


class _AdminClientProto(Protocol):
    def fetch_global_kill(self) -> dict: ...


@dataclass(frozen=True)
class GlobalKillConfig:
    interval_seconds: float = 60.0
    initial_delay_seconds: float = 0.0


class GlobalKillFetcher:
    """Long-running poller that mirrors the admin portal's global flag."""

    def __init__(
        self,
        *,
        kill_switch: KillSwitch,
        client: _AdminClientProto,
        config: Optional[GlobalKillConfig] = None,
    ):
        self._kill_switch = kill_switch
        self._client = client
        self._config = config or GlobalKillConfig()
        self._last_active: Optional[bool] = None
        self._last_checked_at: Optional[datetime] = None
        self._stop_requested = False

    @property
    def last_active(self) -> Optional[bool]:
        return self._last_active

    @property
    def last_checked_at(self) -> Optional[datetime]:
        return self._last_checked_at

    def request_stop(self) -> None:
        self._stop_requested = True

    def tick(self) -> bool:
        """Run one poll cycle. Returns the active flag the server reported.

        Public for testing.
        """
        try:
            response = self._client.fetch_global_kill()
        except Exception as exc:
            logger.warning(
                "global kill fetch failed (treating as inactive): %s", exc
            )
            self._last_checked_at = datetime.now(timezone.utc)
            # Don't trip — Cloudflare being down should NOT take customers down.
            return self._last_active or False

        active = bool(response.get("active", False))
        self._last_active = active
        self._last_checked_at = datetime.now(timezone.utc)

        if active and not self._kill_switch.is_tier_off(KillTier.GLOBAL):
            self._kill_switch.tier_4_global_off(
                actor="admin-portal",
                reason=(
                    f"global kill flag active "
                    f"(server ts: {response.get('ts', 'unknown')})"
                ),
            )
        elif not active and self._kill_switch.is_tier_off(KillTier.GLOBAL):
            self._kill_switch.tier_on(KillTier.GLOBAL)
        return active

    async def run_forever(self) -> None:
        if self._config.initial_delay_seconds > 0:
            await asyncio.sleep(self._config.initial_delay_seconds)
        while not self._stop_requested:
            try:
                self.tick()
            except Exception as exc:
                logger.error("global kill loop tick raised: %s", exc)
            await asyncio.sleep(self._config.interval_seconds)
