"""Agent authority — runtime enforcement of persona boundaries.

Per `.claude/rules/agent-authority.md`: only @devops (Gage) may run
git push, gh pr create, or MCP management commands. All other personas
must delegate. The `@aios-master` may override boundaries when framework
health requires it.

Enforcement is data-driven from
`agents._shared.harness.personas.boundaries` so a typo in this module
can't silently weaken a constitutional rule.
"""

from __future__ import annotations

from agents._shared.harness.personas.boundaries import default_boundaries
from agents._shared.harness.rules.types import (
    CheckContext,
    Rule,
    RuleCheckResult,
    RuleSeverity,
    RuleViolation,
)


_ACTION_TO_BOUNDARY: dict[str, str] = {
    "git_push": "no_remote_push",
    "git_force_push": "no_remote_push",
    "create_pr": "no_pr_create",
    "gh_pr_create": "no_pr_create",
    "gh_pr_merge": "no_pr_create",
    "mcp_add": "no_mcp_management",
    "mcp_remove": "no_mcp_management",
    "mcp_setup": "no_mcp_management",
}


def _check(ctx: CheckContext) -> RuleCheckResult:
    if not ctx.action or not ctx.persona_id:
        return RuleCheckResult(rule_id="agent_authority", passed=True)

    boundary = _ACTION_TO_BOUNDARY.get(ctx.action)
    if boundary is None:
        # Unknown action — no boundary mapping, no violation.
        return RuleCheckResult(rule_id="agent_authority", passed=True)

    persona_boundaries = default_boundaries(ctx.persona_id)
    if boundary not in persona_boundaries:
        # Persona is permitted to perform this action.
        return RuleCheckResult(rule_id="agent_authority", passed=True)

    violation = RuleViolation(
        rule_id="agent_authority",
        severity=RuleSeverity.CRITICAL,
        message=(
            f"Persona {ctx.persona_id!r} cannot perform {ctx.action!r} "
            f"(violates boundary {boundary!r})."
        ),
        recommendation=(
            f"Delegate {ctx.action} to @devops. Only @devops (and "
            f"@aios-master in framework-emergency) may perform this action."
        ),
        metadata={"persona": ctx.persona_id, "action": ctx.action},
    )
    return RuleCheckResult(
        rule_id="agent_authority",
        passed=False,
        violations=(violation,),
    )


def rule() -> Rule:
    """Return the agent_authority rule.

    Severity is CRITICAL — push/PR boundaries are constitutional and never
    scaled by environment mode.
    """
    return Rule(
        id="agent_authority",
        severity=RuleSeverity.CRITICAL,
        description="Agent boundary enforcement (push/PR/MCP authority)",
        check_fn=_check,
    )
