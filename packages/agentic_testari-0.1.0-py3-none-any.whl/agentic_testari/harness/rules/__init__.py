"""Rules engine — runtime enforcement of AIOS rules (EPIC N.4).

Each rule from `.claude/rules/` becomes a runtime check that runs against a
CheckContext (test plan, code diff, persona output, etc.). Violations
surface as RuleViolation objects with severity + actionable recommendation.

Pillars (from `quality-foundation.md`):
    1. Test-First Development      → quality_foundation.pillar_1
    2. Documentation-as-Code       → quality_foundation.pillar_2
    3. QA Continuous Validation    → quality_foundation.pillar_3
    4. Regression Shield           → quality_foundation.pillar_4

Plus:
    - Agent Authority              → agent_authority (boundary enforcement)
    - Environment Mode             → environment_mode (DEV/STAGING/PROD scales
                                     severity but never adds/removes rules)

Usage:
    from agents._shared.harness.rules import (
        RulesEngine, CheckContext, RuleSeverity, EnvironmentMode,
    )

    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    blocking = [v for v in violations if v.is_blocking]
"""

from agents._shared.harness.rules.engine import RulesEngine
from agents._shared.harness.rules.environment_mode import (
    EnvironmentMode,
    scale_severity,
)
from agents._shared.harness.rules.types import (
    CheckContext,
    Rule,
    RuleCheckResult,
    RuleSeverity,
    RuleViolation,
)

__all__ = [
    "RulesEngine",
    "Rule",
    "RuleSeverity",
    "RuleViolation",
    "RuleCheckResult",
    "CheckContext",
    "EnvironmentMode",
    "scale_severity",
]

__version__ = "1.0.0"
