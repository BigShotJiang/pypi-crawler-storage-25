"""Environment mode — DEV / STAGING / PROD strictness scaling.

Per rule `environment-mode.md`: the same rules exist in every environment,
but their *severity* scales with the environment. DEV is permissive (most
violations downgraded to warnings); PROD is strict (warnings bubble up to
hard blocks).

This module never adds or removes rules. It only scales the reported
severity of an existing violation. Constitutional rules (severity=CRITICAL)
are immune to scaling — they block in every environment.
"""

from __future__ import annotations

from enum import Enum
import os

from agents._shared.harness.rules.types import RuleSeverity


class EnvironmentMode(str, Enum):
    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"


def detect_mode(env_var: str = "AGTESTARI_ENV") -> EnvironmentMode:
    raw = os.environ.get(env_var, "dev").strip().lower()
    try:
        return EnvironmentMode(raw)
    except ValueError:
        return EnvironmentMode.DEV


# Severity scaling table — applied to rule's *declared* severity to produce
# the *effective* severity for a given environment. CRITICAL is immune.
_SCALE: dict[EnvironmentMode, dict[RuleSeverity, RuleSeverity]] = {
    EnvironmentMode.DEV: {
        RuleSeverity.HIGH: RuleSeverity.MEDIUM,    # downgrade
        RuleSeverity.MEDIUM: RuleSeverity.LOW,
        RuleSeverity.LOW: RuleSeverity.INFO,
    },
    EnvironmentMode.STAGING: {
        # No change; declared severity is the staging baseline.
    },
    EnvironmentMode.PROD: {
        RuleSeverity.MEDIUM: RuleSeverity.HIGH,    # upgrade
        RuleSeverity.LOW: RuleSeverity.MEDIUM,
        RuleSeverity.INFO: RuleSeverity.LOW,
    },
}


def scale_severity(
    declared: RuleSeverity, mode: EnvironmentMode
) -> RuleSeverity:
    """Return the effective severity for `declared` under `mode`.

    CRITICAL is never scaled — constitutional rules are inviolable.
    """
    if declared is RuleSeverity.CRITICAL:
        return declared
    return _SCALE.get(mode, {}).get(declared, declared)
