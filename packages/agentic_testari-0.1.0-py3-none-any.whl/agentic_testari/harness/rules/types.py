"""Rules engine types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Mapping


class RuleSeverity(str, Enum):
    """Rule severity ranks. Used for scaling + filtering."""

    CRITICAL = "critical"   # Inviolable. Blocks every environment.
    HIGH = "high"           # Blocks STAGING + PROD. Warns in DEV.
    MEDIUM = "medium"       # Warns everywhere. Blocks PROD only.
    LOW = "low"             # Warns everywhere. Never blocks.
    INFO = "info"           # Visibility only.


_BLOCKING_RANK = {
    RuleSeverity.CRITICAL: 4,
    RuleSeverity.HIGH: 3,
    RuleSeverity.MEDIUM: 2,
    RuleSeverity.LOW: 1,
    RuleSeverity.INFO: 0,
}


def severity_rank(s: RuleSeverity) -> int:
    return _BLOCKING_RANK[s]


@dataclass(frozen=True)
class RuleViolation:
    """A rule failed against a context."""

    rule_id: str
    severity: RuleSeverity
    message: str
    recommendation: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def is_blocking(self) -> bool:
        """A violation is blocking when severity is HIGH or CRITICAL."""
        return self.severity in (RuleSeverity.CRITICAL, RuleSeverity.HIGH)


@dataclass(frozen=True)
class RuleCheckResult:
    """Output of one rule evaluation against a CheckContext."""

    rule_id: str
    passed: bool
    violations: tuple[RuleViolation, ...] = ()


@dataclass(frozen=True)
class CheckContext:
    """Bundle of inputs every rule may inspect.

    Rules read fields they care about; absent fields are simply skipped. The
    context is intentionally a flat dataclass — no inheritance — so a single
    test fixture can satisfy any rule.
    """

    run_id: str
    test_intent: str = ""
    persona_id: str | None = None
    action: str | None = None  # e.g., "git_push", "create_pr"
    new_functions: tuple[str, ...] = ()
    tests_per_function: Mapping[str, int] = field(default_factory=dict)
    documented_functions: frozenset[str] = field(default_factory=frozenset)
    coverage_changed_files: float | None = None  # 0.0-1.0
    skipped_tests_count: int = 0
    deleted_tests_count: int = 0
    qa_passes_completed: int = 0
    bug_fix_has_regression_test: bool | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


# A rule is anything callable that takes CheckContext and returns
# RuleCheckResult. Concrete Rule subclasses are dataclasses with metadata
# plus a `check()` method.


@dataclass(frozen=True)
class Rule:
    """Base data shape for a rule. Subclasses override .check()."""

    id: str
    severity: RuleSeverity
    description: str
    check_fn: Callable[[CheckContext], RuleCheckResult] | None = None

    def check(self, ctx: CheckContext) -> RuleCheckResult:
        if self.check_fn is None:
            raise NotImplementedError(
                f"Rule {self.id!r} has no check_fn and no override"
            )
        return self.check_fn(ctx)
