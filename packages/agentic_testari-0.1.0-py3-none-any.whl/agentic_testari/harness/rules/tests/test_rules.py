"""Tests for the rules engine — Pillars 1-4, agent_authority, env-mode scaling."""

from __future__ import annotations

import pytest

from agents._shared.harness.rules import (
    CheckContext,
    EnvironmentMode,
    RulesEngine,
    RuleSeverity,
    scale_severity,
)


# ---- Pillar 1: tests required ----


def test_pillar_1_blocks_function_with_zero_tests():
    ctx = CheckContext(
        run_id="r",
        new_functions=("calc_total",),
        tests_per_function={},
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p1 = [v for v in violations if v.rule_id == "quality_foundation.pillar_1"]
    assert any("0 tests" in v.message for v in p1)
    assert any(v.is_blocking for v in p1)


def test_pillar_1_warns_function_with_partial_tests():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 1},
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    msgs = [v for v in violations if v.rule_id == "quality_foundation.pillar_1"]
    # 1 test exists -> still violation but lower severity (MEDIUM)
    assert any("only 1 tests" in v.message for v in msgs)


def test_pillar_1_passes_when_function_has_three_tests():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset({"foo"}),
        coverage_changed_files=0.95,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p1 = [v for v in violations if v.rule_id == "quality_foundation.pillar_1"]
    assert p1 == []


def test_pillar_1_blocks_low_coverage():
    ctx = CheckContext(
        run_id="r",
        new_functions=(),
        coverage_changed_files=0.65,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert any(
        "65.0%" in v.message and v.is_blocking for v in violations
    )


def test_pillar_1_blocks_skipped_tests():
    ctx = CheckContext(run_id="r", skipped_tests_count=2)
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert any("2 skipped test" in v.message for v in violations)


# ---- Pillar 2: docs ----


def test_pillar_2_warns_undocumented_function():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset(),
        coverage_changed_files=0.9,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p2 = [v for v in violations if v.rule_id == "quality_foundation.pillar_2"]
    assert len(p2) == 1
    assert p2[0].severity == RuleSeverity.MEDIUM


def test_pillar_2_passes_when_documented():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset({"foo"}),
        coverage_changed_files=0.9,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p2 = [v for v in violations if v.rule_id == "quality_foundation.pillar_2"]
    assert p2 == []


# ---- Pillar 3: QA passes ----


def test_pillar_3_blocks_done_with_one_qa_pass():
    ctx = CheckContext(
        run_id="r",
        qa_passes_completed=1,
        metadata={"story_status": "done"},
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p3 = [v for v in violations if v.rule_id == "quality_foundation.pillar_3"]
    assert p3 and "1 QA pass" in p3[0].message


def test_pillar_3_silent_when_story_not_done():
    ctx = CheckContext(run_id="r", qa_passes_completed=0)
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p3 = [v for v in violations if v.rule_id == "quality_foundation.pillar_3"]
    assert p3 == []


# ---- Pillar 4: regression ----


def test_pillar_4_blocks_deleted_test():
    ctx = CheckContext(run_id="r", deleted_tests_count=1)
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert any(
        v.rule_id == "quality_foundation.pillar_4"
        and "1 test(s) deleted" in v.message
        for v in violations
    )


def test_pillar_4_blocks_bug_fix_without_regression_test():
    ctx = CheckContext(run_id="r", bug_fix_has_regression_test=False)
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert any(
        v.rule_id == "quality_foundation.pillar_4"
        and "regression test" in v.message
        for v in violations
    )


def test_pillar_4_silent_when_unaffected():
    ctx = CheckContext(run_id="r", bug_fix_has_regression_test=True)
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p4 = [v for v in violations if v.rule_id == "quality_foundation.pillar_4"]
    assert p4 == []


# ---- Agent authority ----


def test_authority_blocks_dev_pushing():
    ctx = CheckContext(run_id="r", persona_id="dev", action="git_push")
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    auth = [v for v in violations if v.rule_id == "agent_authority"]
    assert auth
    assert auth[0].severity == RuleSeverity.CRITICAL
    assert "Delegate" in auth[0].recommendation


def test_authority_allows_devops_pushing():
    ctx = CheckContext(run_id="r", persona_id="devops", action="git_push")
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    auth = [v for v in violations if v.rule_id == "agent_authority"]
    assert auth == []


def test_authority_blocks_qa_creating_pr():
    ctx = CheckContext(run_id="r", persona_id="qa", action="gh_pr_create")
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    auth = [v for v in violations if v.rule_id == "agent_authority"]
    assert auth and auth[0].severity == RuleSeverity.CRITICAL


def test_authority_silent_for_unknown_action():
    ctx = CheckContext(run_id="r", persona_id="dev", action="lint")
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert all(v.rule_id != "agent_authority" for v in violations)


# ---- Environment mode scaling ----


def test_dev_mode_downgrades_high_to_medium():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={},
    )
    engine = RulesEngine.default(mode=EnvironmentMode.DEV)
    violations = engine.evaluate(ctx)
    p1 = [v for v in violations if v.rule_id == "quality_foundation.pillar_1"]
    assert p1 and p1[0].severity == RuleSeverity.MEDIUM
    assert not p1[0].is_blocking


def test_prod_mode_upgrades_medium_to_high():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset(),
        coverage_changed_files=0.9,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.PROD)
    violations = engine.evaluate(ctx)
    p2 = [v for v in violations if v.rule_id == "quality_foundation.pillar_2"]
    assert p2 and p2[0].severity == RuleSeverity.HIGH
    assert p2[0].is_blocking


def test_critical_severity_never_scaled():
    """CRITICAL rules block in every environment."""
    for mode in (EnvironmentMode.DEV, EnvironmentMode.STAGING, EnvironmentMode.PROD):
        assert scale_severity(RuleSeverity.CRITICAL, mode) == RuleSeverity.CRITICAL


def test_authority_critical_under_dev_still_blocks():
    """Even in DEV, persona authority violations are CRITICAL."""
    ctx = CheckContext(run_id="r", persona_id="dev", action="git_push")
    engine = RulesEngine.default(mode=EnvironmentMode.DEV)
    violations = engine.evaluate(ctx)
    auth = [v for v in violations if v.rule_id == "agent_authority"]
    assert auth and auth[0].severity == RuleSeverity.CRITICAL


def test_staging_is_baseline_no_change():
    ctx = CheckContext(run_id="r", new_functions=("foo",), tests_per_function={"foo": 1})
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    p1 = [v for v in violations if v.rule_id == "quality_foundation.pillar_1"]
    # Declared severity for partial tests is MEDIUM — staging keeps it.
    assert p1[0].severity == RuleSeverity.MEDIUM


# ---- Engine behaviour ----


def test_has_blocking_true_when_blocking_violation():
    ctx = CheckContext(
        run_id="r", new_functions=("foo",), tests_per_function={}
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    assert engine.has_blocking(ctx) is True


def test_has_blocking_false_when_clean():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset({"foo"}),
        coverage_changed_files=0.95,
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    assert engine.has_blocking(ctx) is False


def test_evaluate_detailed_returns_per_rule_results():
    ctx = CheckContext(
        run_id="r", new_functions=("foo",), tests_per_function={}
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    detailed = engine.evaluate_detailed(ctx)
    rule_ids = {r.rule_id for r in detailed}
    assert "quality_foundation.pillar_1" in rule_ids
    assert "agent_authority" in rule_ids
    failed = [r for r in detailed if not r.passed]
    assert any(r.rule_id == "quality_foundation.pillar_1" for r in failed)


def test_default_engine_includes_all_pillars_plus_authority():
    engine = RulesEngine.default()
    ids = {r.id for r in engine.rules}
    for must_have in (
        "quality_foundation.pillar_1",
        "quality_foundation.pillar_2",
        "quality_foundation.pillar_3",
        "quality_foundation.pillar_4",
        "agent_authority",
    ):
        assert must_have in ids


def test_recommendation_present_on_every_violation():
    ctx = CheckContext(
        run_id="r",
        new_functions=("foo",),
        tests_per_function={},
        coverage_changed_files=0.5,
        skipped_tests_count=1,
        deleted_tests_count=1,
        bug_fix_has_regression_test=False,
        persona_id="dev",
        action="git_push",
    )
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert violations
    for v in violations:
        assert v.recommendation, f"{v.rule_id} missing recommendation"


def test_clean_context_yields_no_violations():
    ctx = CheckContext(run_id="r")
    engine = RulesEngine.default(mode=EnvironmentMode.STAGING)
    violations = engine.evaluate(ctx)
    assert violations == []
