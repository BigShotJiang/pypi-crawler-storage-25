"""RulesEngine — orchestrate rule evaluation against a CheckContext.

Builds a default rule set from quality_foundation + agent_authority. Custom
rule sets can be passed in for tests and for future rule additions. The
engine is stateless beyond the rule list and the env mode — safe to share
across runs.
"""

from __future__ import annotations

from typing import Iterable, Optional

from agents._shared.harness.rules.agent_authority import rule as auth_rule
from agents._shared.harness.rules.environment_mode import (
    EnvironmentMode,
    detect_mode,
    scale_severity,
)
from agents._shared.harness.rules.quality_foundation import all_pillars
from agents._shared.harness.rules.types import (
    CheckContext,
    Rule,
    RuleCheckResult,
    RuleSeverity,
    RuleViolation,
)


class RulesEngine:
    """Evaluate a list of Rules against a CheckContext."""

    def __init__(
        self,
        rules: Iterable[Rule],
        *,
        mode: Optional[EnvironmentMode] = None,
    ):
        self._rules: tuple[Rule, ...] = tuple(rules)
        self._mode = mode if mode is not None else detect_mode()

    @classmethod
    def default(
        cls, *, mode: Optional[EnvironmentMode] = None
    ) -> "RulesEngine":
        """Construct an engine with the canonical AIOS rule set."""
        rules: list[Rule] = []
        rules.extend(all_pillars())
        rules.append(auth_rule())
        return cls(rules, mode=mode)

    @property
    def mode(self) -> EnvironmentMode:
        return self._mode

    @property
    def rules(self) -> tuple[Rule, ...]:
        return self._rules

    def evaluate(self, ctx: CheckContext) -> list[RuleViolation]:
        """Run every rule and return all violations, severity-scaled."""
        all_violations: list[RuleViolation] = []
        for rule in self._rules:
            result = rule.check(ctx)
            if not result.passed:
                for v in result.violations:
                    all_violations.append(self._scale(v))
        return all_violations

    def evaluate_detailed(self, ctx: CheckContext) -> list[RuleCheckResult]:
        """Return per-rule results (passed + violations) without aggregation."""
        results: list[RuleCheckResult] = []
        for rule in self._rules:
            raw = rule.check(ctx)
            scaled = RuleCheckResult(
                rule_id=raw.rule_id,
                passed=raw.passed,
                violations=tuple(self._scale(v) for v in raw.violations),
            )
            results.append(scaled)
        return results

    def has_blocking(self, ctx: CheckContext) -> bool:
        """Return True if any rule violation would block the run."""
        for v in self.evaluate(ctx):
            if v.is_blocking:
                return True
        return False

    def _scale(self, v: RuleViolation) -> RuleViolation:
        scaled = scale_severity(v.severity, self._mode)
        if scaled is v.severity:
            return v
        return RuleViolation(
            rule_id=v.rule_id,
            severity=scaled,
            message=v.message,
            recommendation=v.recommendation,
            metadata=v.metadata,
        )
