"""Quality Foundation Pillars 1-4 — runtime enforcement.

Pillars from `.claude/rules/quality-foundation.md`:

    Pillar 1 — Test-First Development:
        VETO if any new function has 0 unit tests.
        VETO if test coverage for changed files drops below 80%.
        VETO if any test is skipped.
        VETO if tests don't cover happy + error + edge (>= 3 per function).

    Pillar 2 — Documentation-as-Code:
        VETO if any new function lacks a doc comment.
        (Module-level + complex-block docs are out of scope here — they
        require AST inspection that the LLM/persona pipeline performs.)

    Pillar 3 — QA Continuous Validation:
        VETO if story moves to Done without 2+ QA passes.

    Pillar 4 — Regression Shield:
        VETO if any existing test was deleted (without architect approval).
        VETO if a bug fix lacks a regression test.
"""

from __future__ import annotations

from agents._shared.harness.rules.types import (
    CheckContext,
    Rule,
    RuleCheckResult,
    RuleSeverity,
    RuleViolation,
)


_MIN_TESTS_PER_FUNCTION = 3
_MIN_COVERAGE = 0.80
_MIN_QA_PASSES = 2


def _pillar_1_check(ctx: CheckContext) -> RuleCheckResult:
    violations: list[RuleViolation] = []

    # 1a — every new function has >= 3 tests.
    for fn in ctx.new_functions:
        count = ctx.tests_per_function.get(fn, 0)
        if count == 0:
            violations.append(
                RuleViolation(
                    rule_id="quality_foundation.pillar_1",
                    severity=RuleSeverity.HIGH,
                    message=f"Function {fn!r} has 0 tests.",
                    recommendation=(
                        f"Add at least {_MIN_TESTS_PER_FUNCTION} tests for "
                        f"{fn} (happy path, error path, edge case)."
                    ),
                    metadata={"function": fn, "tests_found": 0},
                )
            )
        elif count < _MIN_TESTS_PER_FUNCTION:
            violations.append(
                RuleViolation(
                    rule_id="quality_foundation.pillar_1",
                    severity=RuleSeverity.MEDIUM,
                    message=(
                        f"Function {fn!r} has only {count} tests "
                        f"(minimum {_MIN_TESTS_PER_FUNCTION})."
                    ),
                    recommendation=(
                        f"Add {_MIN_TESTS_PER_FUNCTION - count} more tests "
                        f"for {fn}: ensure happy + error + edge paths."
                    ),
                    metadata={"function": fn, "tests_found": count},
                )
            )

    # 1b — coverage on changed files >= 80%.
    if ctx.coverage_changed_files is not None:
        if ctx.coverage_changed_files < _MIN_COVERAGE:
            violations.append(
                RuleViolation(
                    rule_id="quality_foundation.pillar_1",
                    severity=RuleSeverity.HIGH,
                    message=(
                        f"Coverage on changed files is "
                        f"{ctx.coverage_changed_files:.1%} (< 80% required)."
                    ),
                    recommendation=(
                        "Add tests until coverage on changed files >= 80%. "
                        "Run `pytest --cov` to see uncovered lines."
                    ),
                    metadata={"coverage": ctx.coverage_changed_files},
                )
            )

    # 1c — no skipped tests.
    if ctx.skipped_tests_count > 0:
        violations.append(
            RuleViolation(
                rule_id="quality_foundation.pillar_1",
                severity=RuleSeverity.HIGH,
                message=(
                    f"{ctx.skipped_tests_count} skipped test(s) detected."
                ),
                recommendation=(
                    "Unskip or remove (with documented reason). Skipped "
                    "tests rot and mask real failures."
                ),
                metadata={"skipped_count": ctx.skipped_tests_count},
            )
        )

    return RuleCheckResult(
        rule_id="quality_foundation.pillar_1",
        passed=not violations,
        violations=tuple(violations),
    )


def _pillar_2_check(ctx: CheckContext) -> RuleCheckResult:
    violations: list[RuleViolation] = []
    for fn in ctx.new_functions:
        if fn not in ctx.documented_functions:
            violations.append(
                RuleViolation(
                    rule_id="quality_foundation.pillar_2",
                    severity=RuleSeverity.MEDIUM,
                    message=f"Function {fn!r} has no doc comment.",
                    recommendation=(
                        f"Add a docstring to {fn} describing what it does, "
                        "parameters, return value, and exceptions raised."
                    ),
                    metadata={"function": fn},
                )
            )
    return RuleCheckResult(
        rule_id="quality_foundation.pillar_2",
        passed=not violations,
        violations=tuple(violations),
    )


def _pillar_3_check(ctx: CheckContext) -> RuleCheckResult:
    if ctx.qa_passes_completed >= _MIN_QA_PASSES:
        return RuleCheckResult(
            rule_id="quality_foundation.pillar_3", passed=True
        )
    if ctx.metadata.get("story_status") != "done":
        # Pillar 3 only fires when a story is moving toward Done.
        return RuleCheckResult(
            rule_id="quality_foundation.pillar_3", passed=True
        )
    violation = RuleViolation(
        rule_id="quality_foundation.pillar_3",
        severity=RuleSeverity.HIGH,
        message=(
            f"Story marked Done after only {ctx.qa_passes_completed} QA "
            "pass(es)."
        ),
        recommendation=(
            "QA must run >= 2 passes (initial + re-test after fixes) "
            "before a story moves to Done."
        ),
        metadata={"qa_passes": ctx.qa_passes_completed},
    )
    return RuleCheckResult(
        rule_id="quality_foundation.pillar_3",
        passed=False,
        violations=(violation,),
    )


def _pillar_4_check(ctx: CheckContext) -> RuleCheckResult:
    violations: list[RuleViolation] = []

    if ctx.deleted_tests_count > 0:
        violations.append(
            RuleViolation(
                rule_id="quality_foundation.pillar_4",
                severity=RuleSeverity.HIGH,
                message=(
                    f"{ctx.deleted_tests_count} test(s) deleted in this change."
                ),
                recommendation=(
                    "Restore deleted tests, or document why they were removed "
                    "and obtain @architect approval. Broken tests should be "
                    "fixed, not deleted."
                ),
                metadata={"deleted_count": ctx.deleted_tests_count},
            )
        )

    if ctx.bug_fix_has_regression_test is False:
        violations.append(
            RuleViolation(
                rule_id="quality_foundation.pillar_4",
                severity=RuleSeverity.HIGH,
                message="Bug fix submitted without a regression test.",
                recommendation=(
                    "Every bug fix must include a regression test that "
                    "reproduces the bug and verifies the fix."
                ),
                metadata={},
            )
        )

    return RuleCheckResult(
        rule_id="quality_foundation.pillar_4",
        passed=not violations,
        violations=tuple(violations),
    )


def all_pillars() -> list[Rule]:
    """Return all four Pillar rules with their declared severities."""
    return [
        Rule(
            id="quality_foundation.pillar_1",
            severity=RuleSeverity.HIGH,
            description="Pillar 1 — Test-First Development",
            check_fn=_pillar_1_check,
        ),
        Rule(
            id="quality_foundation.pillar_2",
            severity=RuleSeverity.MEDIUM,
            description="Pillar 2 — Documentation-as-Code",
            check_fn=_pillar_2_check,
        ),
        Rule(
            id="quality_foundation.pillar_3",
            severity=RuleSeverity.HIGH,
            description="Pillar 3 — QA Continuous Validation",
            check_fn=_pillar_3_check,
        ),
        Rule(
            id="quality_foundation.pillar_4",
            severity=RuleSeverity.HIGH,
            description="Pillar 4 — Regression Shield",
            check_fn=_pillar_4_check,
        ),
    ]
