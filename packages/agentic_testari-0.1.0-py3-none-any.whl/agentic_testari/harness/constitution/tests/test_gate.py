"""Tests for the ConstitutionalGate."""

from __future__ import annotations

import pytest

from agents._shared.harness.constitution import (
    ConstitutionalGate,
    ConstitutionViolation,
    GateContext,
    GatePhase,
    InviolableRule,
)


@pytest.fixture
def gate() -> ConstitutionalGate:
    return ConstitutionalGate.default()


def _ok_ctx(**overrides) -> GateContext:
    base = dict(
        run_id="r-1",
        intent_text="The user can log in with valid credentials.",
        has_verdict=True,
        anti_patterns_detected=(),
        anti_patterns_acknowledged=(),
        persona_id=None,
        attempted_action=None,
    )
    base.update(overrides)
    return GateContext(**base)


# ---- intent declaration ----


def test_passes_when_intent_present(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(), phase=GatePhase.START)
    assert res.passed
    assert all(c.passed for c in res.checks)


def test_blocks_at_start_when_intent_missing(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(intent_text=""), phase=GatePhase.START)
    assert res.blocked
    fail = [c for c in res.checks if c.rule is InviolableRule.INTENT_DECLARATION_REQUIRED]
    assert fail and not fail[0].passed
    assert "semantic-intent" in fail[0].recommendation


def test_blocks_when_intent_only_whitespace(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(intent_text="   \n  "), phase=GatePhase.START)
    assert res.blocked


# ---- no_verdict_no_ship ----


def test_no_verdict_only_enforced_at_end(gate: ConstitutionalGate):
    """At START, has_verdict=False is fine."""
    res = gate.evaluate(_ok_ctx(has_verdict=False), phase=GatePhase.START)
    nvr = [c for c in res.checks if c.rule is InviolableRule.NO_VERDICT_NO_SHIP]
    assert nvr[0].passed


def test_no_verdict_blocks_at_end(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(has_verdict=False), phase=GatePhase.END)
    nvr = [c for c in res.checks if c.rule is InviolableRule.NO_VERDICT_NO_SHIP]
    assert not nvr[0].passed
    assert "verdict" in nvr[0].message.lower()


def test_verdict_present_passes_at_end(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(has_verdict=True), phase=GatePhase.END)
    assert res.passed


# ---- anti-pattern acknowledgement ----


def test_unacknowledged_anti_pattern_blocks(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(anti_patterns_detected=("ap-1", "ap-2")),
        phase=GatePhase.START,
    )
    ap = [c for c in res.checks if c.rule is InviolableRule.NO_ANTI_PATTERN_IGNORED]
    assert not ap[0].passed
    assert "ap-1" in ap[0].metadata["unacknowledged"]


def test_acknowledged_anti_patterns_pass(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(
            anti_patterns_detected=("ap-1",),
            anti_patterns_acknowledged=("ap-1",),
        ),
        phase=GatePhase.START,
    )
    assert res.passed


def test_partial_acknowledgement_still_blocks(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(
            anti_patterns_detected=("a", "b"),
            anti_patterns_acknowledged=("a",),
        ),
        phase=GatePhase.START,
    )
    ap = [c for c in res.checks if c.rule is InviolableRule.NO_ANTI_PATTERN_IGNORED]
    assert not ap[0].passed
    assert ap[0].metadata["unacknowledged"] == ["b"]


# ---- persona override ----


def test_dev_attempting_push_blocks(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(persona_id="dev", attempted_action="git_push"),
        phase=GatePhase.START,
    )
    npo = [c for c in res.checks if c.rule is InviolableRule.NO_PERSONA_OVERRIDE]
    assert not npo[0].passed
    assert "Delegate" in npo[0].recommendation


def test_devops_attempting_push_passes(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(persona_id="devops", attempted_action="git_push"),
        phase=GatePhase.START,
    )
    assert res.passed


def test_unknown_action_does_not_trigger_override(gate: ConstitutionalGate):
    res = gate.evaluate(
        _ok_ctx(persona_id="dev", attempted_action="lint"),
        phase=GatePhase.START,
    )
    assert res.passed


def test_no_action_no_check(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(persona_id="dev"), phase=GatePhase.START)
    assert res.passed


# ---- gate orchestration ----


def test_all_4_rules_evaluated(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(), phase=GatePhase.START)
    rules = {c.rule for c in res.checks}
    assert rules == {
        InviolableRule.NO_VERDICT_NO_SHIP,
        InviolableRule.INTENT_DECLARATION_REQUIRED,
        InviolableRule.NO_ANTI_PATTERN_IGNORED,
        InviolableRule.NO_PERSONA_OVERRIDE,
    }


def test_gate_result_failures_returns_only_failed(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(intent_text=""), phase=GatePhase.END)
    failures = res.failures()
    assert len(failures) >= 1
    assert all(not c.passed for c in failures)


def test_evaluate_pair_runs_both_phases(gate: ConstitutionalGate):
    start_ctx = _ok_ctx(has_verdict=False)
    end_ctx = _ok_ctx(has_verdict=True)
    pre, post = gate.evaluate_pair(start_ctx, end_ctx)
    assert pre.phase is GatePhase.START
    assert post.phase is GatePhase.END
    assert pre.passed
    assert post.passed


def test_constitution_violation_can_be_raised(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(intent_text=""), phase=GatePhase.START)
    err = ConstitutionViolation(res.failures())
    msg = str(err)
    assert "intent_declaration_required" in msg


def test_blocked_alias(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(intent_text=""), phase=GatePhase.START)
    assert res.blocked
    assert not res.passed
    res2 = gate.evaluate(_ok_ctx(), phase=GatePhase.START)
    assert not res2.blocked
    assert res2.passed


def test_run_id_propagated(gate: ConstitutionalGate):
    res = gate.evaluate(_ok_ctx(run_id="custom-id"), phase=GatePhase.END)
    assert res.run_id == "custom-id"


def test_custom_check_set():
    """Caller can pass a reduced check set (used by tests + future epics)."""
    gate_with_one = ConstitutionalGate(
        checks=(
            lambda ctx, phase: __import__(
                "agents._shared.harness.constitution.types",
                fromlist=["ConstitutionalCheck"],
            ).ConstitutionalCheck(
                rule=InviolableRule.NO_VERDICT_NO_SHIP, passed=True
            ),
        )
    )
    res = gate_with_one.evaluate(_ok_ctx(), phase=GatePhase.START)
    assert len(res.checks) == 1
    assert res.passed
