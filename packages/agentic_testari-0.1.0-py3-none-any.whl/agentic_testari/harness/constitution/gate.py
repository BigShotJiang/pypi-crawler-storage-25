"""ConstitutionalGate — orchestrates inviolable rule checks.

The gate is invoked twice per test run:
    - START: before the persona pipeline runs (block invalid runs early)
    - END:   after the pipeline produces a verdict (catch missing verdict
             and any post-execution violations)

Each phase runs the full set of checks; phase awareness lets individual
rules opt out (e.g., NO_VERDICT_NO_SHIP can only be evaluated at END).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Optional

from agents._shared.harness.personas.boundaries import default_boundaries
from agents._shared.harness.constitution.types import (
    ConstitutionalCheck,
    InviolableRule,
)


class GatePhase(str, Enum):
    """When in a test run the gate is firing."""

    START = "start"
    END = "end"


@dataclass(frozen=True)
class GateContext:
    """Inputs the gate inspects.

    Some fields only make sense at GatePhase.END (e.g., verdict). The rule
    checks are phase-aware.
    """

    run_id: str
    intent_text: str = ""           # semantic-intent.md content (SVG-1)
    has_verdict: bool = False       # set after pipeline produces verdict
    anti_patterns_detected: tuple[str, ...] = ()
    anti_patterns_acknowledged: tuple[str, ...] = ()
    persona_id: Optional[str] = None
    attempted_action: Optional[str] = None
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class GateResult:
    """Aggregate result from a single gate evaluation."""

    phase: GatePhase
    run_id: str
    checks: tuple[ConstitutionalCheck, ...]

    @property
    def passed(self) -> bool:
        return all(c.passed for c in self.checks)

    @property
    def blocked(self) -> bool:
        """Convenience alias — gate FAIL means run is blocked."""
        return not self.passed

    def failures(self) -> tuple[ConstitutionalCheck, ...]:
        return tuple(c for c in self.checks if not c.passed)


# ---- individual rule checks ----


def _check_intent_declaration(ctx: GateContext, phase: GatePhase) -> ConstitutionalCheck:
    """SVG-1: every run must have a semantic-intent statement."""
    text = (ctx.intent_text or "").strip()
    if text:
        return ConstitutionalCheck(
            rule=InviolableRule.INTENT_DECLARATION_REQUIRED,
            passed=True,
        )
    return ConstitutionalCheck(
        rule=InviolableRule.INTENT_DECLARATION_REQUIRED,
        passed=False,
        message="No semantic-intent declared for this run.",
        recommendation=(
            "Provide a 3-5 sentence semantic-intent statement describing "
            "what the user achieves. Without this, downstream personas "
            "cannot cross-check implementation against intent (SVG-1)."
        ),
    )


def _check_no_verdict_no_ship(
    ctx: GateContext, phase: GatePhase
) -> ConstitutionalCheck:
    """A test run cannot ship without a verdict — only enforced at END."""
    if phase is GatePhase.START:
        return ConstitutionalCheck(
            rule=InviolableRule.NO_VERDICT_NO_SHIP,
            passed=True,
            message="Phase START — verdict not yet expected.",
        )
    if ctx.has_verdict:
        return ConstitutionalCheck(
            rule=InviolableRule.NO_VERDICT_NO_SHIP,
            passed=True,
        )
    return ConstitutionalCheck(
        rule=InviolableRule.NO_VERDICT_NO_SHIP,
        passed=False,
        message="Test run completed without producing a verdict.",
        recommendation=(
            "Every run must produce PASS / FAIL / CONCERNS / WAIVED via "
            "the AIOS contract. Check that the verdict pipeline did not "
            "silently swallow an exception before emitting."
        ),
    )


def _check_anti_pattern_acknowledged(
    ctx: GateContext, phase: GatePhase
) -> ConstitutionalCheck:
    """ALMA gates retrieval — flagged anti-patterns must be acknowledged."""
    detected = set(ctx.anti_patterns_detected)
    acknowledged = set(ctx.anti_patterns_acknowledged)
    unacknowledged = detected - acknowledged
    if not unacknowledged:
        return ConstitutionalCheck(
            rule=InviolableRule.NO_ANTI_PATTERN_IGNORED,
            passed=True,
        )
    return ConstitutionalCheck(
        rule=InviolableRule.NO_ANTI_PATTERN_IGNORED,
        passed=False,
        message=(
            f"{len(unacknowledged)} anti-pattern(s) flagged by ALMA but not "
            f"acknowledged: {sorted(unacknowledged)}"
        ),
        recommendation=(
            "Acknowledge each anti-pattern (accept the recommendation OR "
            "document the deviation rationale). Constitutional rule: ALMA "
            "findings cannot be silently ignored."
        ),
        metadata={"unacknowledged": sorted(unacknowledged)},
    )


_AUTHORITY_ACTIONS: dict[str, str] = {
    "git_push": "no_remote_push",
    "git_force_push": "no_remote_push",
    "create_pr": "no_pr_create",
    "gh_pr_create": "no_pr_create",
    "gh_pr_merge": "no_pr_create",
    "mcp_add": "no_mcp_management",
    "mcp_remove": "no_mcp_management",
    "mcp_setup": "no_mcp_management",
}


def _check_no_persona_override(
    ctx: GateContext, phase: GatePhase
) -> ConstitutionalCheck:
    """Reject any attempt to override persona boundaries."""
    if not ctx.persona_id or not ctx.attempted_action:
        return ConstitutionalCheck(
            rule=InviolableRule.NO_PERSONA_OVERRIDE,
            passed=True,
        )
    boundary = _AUTHORITY_ACTIONS.get(ctx.attempted_action)
    if boundary is None:
        return ConstitutionalCheck(
            rule=InviolableRule.NO_PERSONA_OVERRIDE,
            passed=True,
        )
    if boundary not in default_boundaries(ctx.persona_id):
        return ConstitutionalCheck(
            rule=InviolableRule.NO_PERSONA_OVERRIDE,
            passed=True,
        )
    return ConstitutionalCheck(
        rule=InviolableRule.NO_PERSONA_OVERRIDE,
        passed=False,
        message=(
            f"Persona {ctx.persona_id!r} attempted {ctx.attempted_action!r} "
            f"(violates {boundary!r})."
        ),
        recommendation=(
            f"Delegate {ctx.attempted_action} to @devops. Persona boundaries "
            "are constitutional — no override possible without @architect "
            "documented approval."
        ),
        metadata={
            "persona": ctx.persona_id,
            "action": ctx.attempted_action,
            "boundary": boundary,
        },
    )


_DEFAULT_CHECKS = (
    _check_intent_declaration,
    _check_no_verdict_no_ship,
    _check_anti_pattern_acknowledged,
    _check_no_persona_override,
)


# ---- gate ----


class ConstitutionalGate:
    """Run inviolable rule checks at START + END of every test run."""

    def __init__(self, checks: Optional[Iterable] = None):
        self._checks = tuple(checks) if checks is not None else _DEFAULT_CHECKS

    @classmethod
    def default(cls) -> "ConstitutionalGate":
        return cls()

    def evaluate(
        self, ctx: GateContext, *, phase: GatePhase
    ) -> GateResult:
        results = tuple(check(ctx, phase) for check in self._checks)
        return GateResult(phase=phase, run_id=ctx.run_id, checks=results)

    def evaluate_pair(
        self, start_ctx: GateContext, end_ctx: GateContext
    ) -> tuple[GateResult, GateResult]:
        """Convenience: run both phases. Caller controls context per phase."""
        return (
            self.evaluate(start_ctx, phase=GatePhase.START),
            self.evaluate(end_ctx, phase=GatePhase.END),
        )
