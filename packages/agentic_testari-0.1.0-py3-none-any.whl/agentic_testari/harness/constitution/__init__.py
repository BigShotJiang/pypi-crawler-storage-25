"""Constitutional gate (EPIC N.5).

Inviolable rules from `.aios-core/constitution.md`. The gate fires at the
START AND END of every test run. Violations cannot be waived without
@architect documented approval.

Inviolable rules (codified here, not LLM-evaluated):
    1. no_verdict_no_ship          — every run must produce a verdict
    2. intent_declaration_required — SVG-1 anchoring (semantic-intent.md
                                      must exist before persona pipeline)
    3. no_anti_pattern_ignored     — ALMA gates retrieval; if upstream
                                      flagged anti-patterns, gate cannot
                                      pass without acknowledgement
    4. no_persona_override         — persona boundary violations are
                                      constitutional (re-uses N.4
                                      agent_authority rule)

The gate is a thin orchestrator over individual checks. Each check
returns a ConstitutionalCheck with status; the gate aggregates them into
GateResult. A FAIL on any inviolable rule blocks the run.

Usage:
    from agents._shared.harness.constitution import (
        ConstitutionalGate, GatePhase, GateContext,
    )

    gate = ConstitutionalGate.default()
    pre = gate.evaluate(ctx, phase=GatePhase.START)
    if pre.blocked:
        raise ConstitutionViolation(pre.failures())
    # ... run pipeline ...
    post = gate.evaluate(ctx, phase=GatePhase.END)
"""

from agents._shared.harness.constitution.gate import (
    ConstitutionalGate,
    GateContext,
    GatePhase,
    GateResult,
)
from agents._shared.harness.constitution.types import (
    ConstitutionalCheck,
    ConstitutionViolation,
    InviolableRule,
)

__all__ = [
    "ConstitutionalGate",
    "GateContext",
    "GatePhase",
    "GateResult",
    "InviolableRule",
    "ConstitutionalCheck",
    "ConstitutionViolation",
]

__version__ = "1.0.0"
