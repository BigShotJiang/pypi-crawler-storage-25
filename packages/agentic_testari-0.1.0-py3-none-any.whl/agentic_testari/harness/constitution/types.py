"""Constitutional gate types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping


class InviolableRule(str, Enum):
    """The 4 constitutional rules — codified, not LLM-evaluated."""

    NO_VERDICT_NO_SHIP = "no_verdict_no_ship"
    INTENT_DECLARATION_REQUIRED = "intent_declaration_required"
    NO_ANTI_PATTERN_IGNORED = "no_anti_pattern_ignored"
    NO_PERSONA_OVERRIDE = "no_persona_override"


@dataclass(frozen=True)
class ConstitutionalCheck:
    """Result of a single inviolable rule against a GateContext."""

    rule: InviolableRule
    passed: bool
    message: str = ""
    recommendation: str = ""
    metadata: Mapping[str, object] = field(default_factory=dict)


class ConstitutionViolation(Exception):
    """Raised when a caller decides to enforce a failed gate as an error."""

    def __init__(self, checks: tuple[ConstitutionalCheck, ...]):
        self.checks = checks
        rule_ids = [c.rule.value for c in checks if not c.passed]
        super().__init__(
            f"Constitutional gate failed on: {', '.join(rule_ids)}"
        )
