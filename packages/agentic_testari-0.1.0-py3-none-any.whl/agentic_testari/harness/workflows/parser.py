"""Parse workflow YAML files into WorkflowDefinition records.

The bundled `.aios-core/development/workflows/*.yaml` files have a
top-level `workflow:` key with id/name/description/type/sequence.
This parser extracts the metadata we need for routing without coupling to
the full sequence detail (the persona dispatcher in N.2 already runs the
sequence; the router only needs to know which workflow to hand off to).

PyYAML is the only dependency. If the bundle ships malformed YAML the
parser raises WorkflowParseError with the offending file path.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import yaml

from agents._shared.harness.workflows.types import WorkflowError


class WorkflowParseError(WorkflowError):
    """Raised when a workflow YAML cannot be parsed or is missing fields."""


@dataclass(frozen=True)
class WorkflowDefinition:
    """Lightweight metadata view of a workflow YAML."""

    id: str
    name: str
    description: str
    type: str  # e.g., "greenfield" | "brownfield" | "qa-loop"
    project_types: tuple[str, ...] = field(default_factory=tuple)
    raw: dict = field(default_factory=dict)

    @property
    def is_brownfield(self) -> bool:
        return self.type.lower().startswith("brownfield")

    @property
    def is_greenfield(self) -> bool:
        return self.type.lower().startswith("greenfield")


def parse_workflow_yaml(source: str, *, source_id: str = "<inline>") -> WorkflowDefinition:
    """Parse a workflow YAML string into a WorkflowDefinition."""
    try:
        data = yaml.safe_load(source)
    except yaml.YAMLError as exc:
        raise WorkflowParseError(
            f"Workflow {source_id!r} is not valid YAML: {exc}"
        ) from exc

    if not isinstance(data, dict) or "workflow" not in data:
        raise WorkflowParseError(
            f"Workflow {source_id!r} missing top-level 'workflow:' key"
        )

    wf = data["workflow"]
    if not isinstance(wf, dict):
        raise WorkflowParseError(
            f"Workflow {source_id!r}: 'workflow' must be a mapping"
        )

    for required in ("id", "name", "type"):
        if required not in wf:
            raise WorkflowParseError(
                f"Workflow {source_id!r} missing required field {required!r}"
            )

    project_types = wf.get("project_types") or ()
    if isinstance(project_types, str):
        project_types = (project_types,)
    else:
        project_types = tuple(project_types)

    return WorkflowDefinition(
        id=str(wf["id"]),
        name=str(wf["name"]),
        description=str(wf.get("description", "")).strip(),
        type=str(wf["type"]),
        project_types=project_types,
        raw=wf,
    )
