"""Workflow router (EPIC N.3).

Reads `.aios-core/development/workflows/*.yaml` (via N.1 HarnessLoader)
and routes test requests to the right workflow:

    - express-test          → simple test (lighter SDC, 3 personas)
    - full-sdc              → complex test with AC (all 5 personas)
    - qa-loop               → failed test re-run, max 5 iterations
    - spec-pipeline         → new product / no PRD
    - brownfield-discovery  → legacy codebase audit (10-phase)

The router is data-driven: the routing rules live in `routing_rules`,
the workflow definitions come from the bundle. Customers can override
the auto-route via RouteRequest.workflow_override.

Usage:
    from agents._shared.harness.workflows import (
        WorkflowRouter, RouteRequest, WorkflowKind,
    )

    router = WorkflowRouter()
    decision = router.route(RouteRequest(
        run_id="r-1",
        intent="Login flow with valid credentials",
        acceptance_criteria=["AC1: user logs in", "AC2: redirected"],
    ))
    # decision.kind == WorkflowKind.FULL_SDC
    # decision.workflow_id == "greenfield-fullstack"
"""

from agents._shared.harness.workflows.parser import (
    WorkflowDefinition,
    WorkflowParseError,
    parse_workflow_yaml,
)
from agents._shared.harness.workflows.router import (
    RouteDecision,
    RouteRequest,
    WorkflowRouter,
)
from agents._shared.harness.workflows.types import (
    WorkflowKind,
    WorkflowError,
)

__all__ = [
    "WorkflowKind",
    "WorkflowError",
    "WorkflowDefinition",
    "WorkflowParseError",
    "WorkflowRouter",
    "RouteRequest",
    "RouteDecision",
    "parse_workflow_yaml",
]

__version__ = "1.0.0"
