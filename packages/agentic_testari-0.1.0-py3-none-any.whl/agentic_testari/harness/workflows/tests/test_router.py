"""Tests for the WorkflowRouter."""

from __future__ import annotations

import pytest

from agents._shared.harness.workflows import (
    RouteDecision,
    RouteRequest,
    WorkflowKind,
    WorkflowRouter,
    parse_workflow_yaml,
)
from agents._shared.harness.workflows.parser import WorkflowParseError


@pytest.fixture(scope="module")
def router() -> WorkflowRouter:
    return WorkflowRouter()


# ---- routing logic ----


def test_routes_failed_rerun_to_qa_loop(router: WorkflowRouter):
    req = RouteRequest(run_id="r", intent="x", is_failed_rerun=True)
    decision = router.route(req)
    assert decision.kind is WorkflowKind.QA_LOOP
    assert "is_failed_rerun" in decision.reason


def test_routes_legacy_audit_to_brownfield(router: WorkflowRouter):
    req = RouteRequest(run_id="r", intent="x", is_legacy_audit=True)
    decision = router.route(req)
    assert decision.kind is WorkflowKind.BROWNFIELD_DISCOVERY
    assert "legacy" in decision.reason


def test_routes_no_ac_no_prd_to_spec_pipeline(router: WorkflowRouter):
    req = RouteRequest(run_id="r", intent="vague new product idea")
    decision = router.route(req)
    assert decision.kind is WorkflowKind.SPEC_PIPELINE


def test_routes_high_complexity_to_full_sdc(router: WorkflowRouter):
    req = RouteRequest(
        run_id="r",
        intent="login",
        acceptance_criteria=("AC1", "AC2", "AC3", "AC4"),
    )
    decision = router.route(req)
    assert decision.kind is WorkflowKind.FULL_SDC


def test_routes_low_complexity_to_express(router: WorkflowRouter):
    req = RouteRequest(
        run_id="r",
        intent="check 200 OK on /health",
        acceptance_criteria=("AC1",),
    )
    decision = router.route(req)
    assert decision.kind is WorkflowKind.EXPRESS_TEST


def test_workflow_override_wins(router: WorkflowRouter):
    """Override beats every other rule."""
    req = RouteRequest(
        run_id="r",
        intent="x",
        is_failed_rerun=True,  # would normally route to qa-loop
        workflow_override=WorkflowKind.SPEC_PIPELINE,
    )
    decision = router.route(req)
    assert decision.kind is WorkflowKind.SPEC_PIPELINE
    assert "override" in decision.reason


def test_decision_metadata_records_score(router: WorkflowRouter):
    req = RouteRequest(
        run_id="r",
        intent="x",
        acceptance_criteria=("a", "b"),
    )
    decision = router.route(req)
    assert decision.metadata["complexity_score"] == 2
    assert decision.metadata["ac_count"] == 2
    assert decision.metadata["override_used"] is False


def test_decision_loads_workflow_definition(router: WorkflowRouter):
    req = RouteRequest(
        run_id="r",
        intent="x",
        acceptance_criteria=("AC1", "AC2", "AC3", "AC4"),
    )
    decision = router.route(req)
    assert decision.definition is not None
    assert decision.definition.id == "greenfield-fullstack"
    assert decision.definition.is_greenfield


def test_brownfield_loads_brownfield_definition(router: WorkflowRouter):
    req = RouteRequest(run_id="r", intent="x", is_legacy_audit=True)
    decision = router.route(req)
    assert decision.definition is not None
    assert decision.definition.is_brownfield


def test_complexity_score_includes_target_paths():
    req = RouteRequest(
        run_id="r",
        intent="x",
        acceptance_criteria=("a",),
        target_paths=("p1", "p2", "p3", "p4", "p5"),
    )
    # 1 AC + (5 - 3) extra paths = 3 → still under threshold (4)
    assert req.complexity_score == 3


def test_complexity_score_short_path_list_no_bonus():
    req = RouteRequest(
        run_id="r",
        intent="x",
        acceptance_criteria=("a", "b"),
        target_paths=("p1",),
    )
    assert req.complexity_score == 2


def test_router_lists_all_kinds(router: WorkflowRouter):
    kinds = router.list_kinds()
    for k in WorkflowKind:
        assert k in kinds


def test_router_workflow_id_for(router: WorkflowRouter):
    assert router.workflow_id_for(WorkflowKind.FULL_SDC) == "greenfield-fullstack"
    assert (
        router.workflow_id_for(WorkflowKind.BROWNFIELD_DISCOVERY)
        == "brownfield-fullstack"
    )


# ---- parser ----


def test_parser_extracts_workflow_metadata():
    src = """
workflow:
  id: my-flow
  name: My Flow
  description: |
    A test workflow.
  type: greenfield
  project_types:
    - web-app
    - mvp
  sequence: []
"""
    wf = parse_workflow_yaml(src, source_id="my-flow.yaml")
    assert wf.id == "my-flow"
    assert wf.name == "My Flow"
    assert wf.type == "greenfield"
    assert wf.project_types == ("web-app", "mvp")
    assert wf.is_greenfield
    assert not wf.is_brownfield


def test_parser_handles_brownfield_type():
    src = """
workflow:
  id: legacy
  name: Legacy
  type: brownfield-fullstack
"""
    wf = parse_workflow_yaml(src)
    assert wf.is_brownfield


def test_parser_rejects_missing_workflow_key():
    with pytest.raises(WorkflowParseError) as exc_info:
        parse_workflow_yaml("foo: bar", source_id="f.yaml")
    assert "workflow" in str(exc_info.value)


def test_parser_rejects_missing_required_field():
    src = """
workflow:
  id: x
  name: X
"""
    with pytest.raises(WorkflowParseError) as exc_info:
        parse_workflow_yaml(src)
    assert "type" in str(exc_info.value)


def test_parser_rejects_invalid_yaml():
    with pytest.raises(WorkflowParseError):
        parse_workflow_yaml("workflow:\n  id: x\n  type: [unclosed")


def test_parser_normalises_string_project_types():
    src = """
workflow:
  id: x
  name: X
  type: greenfield
  project_types: web-app
"""
    wf = parse_workflow_yaml(src)
    assert wf.project_types == ("web-app",)


# ---- decision dataclass ----


def test_route_decision_immutable(router: WorkflowRouter):
    decision = router.route(RouteRequest(run_id="r", intent="x", is_legacy_audit=True))
    with pytest.raises((AttributeError, Exception)):
        decision.kind = WorkflowKind.FULL_SDC  # type: ignore[misc]
