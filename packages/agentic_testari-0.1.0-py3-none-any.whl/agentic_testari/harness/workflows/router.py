"""WorkflowRouter — picks the right workflow for a RouteRequest.

Routing rules (in priority order):

    1. `request.workflow_override` set       → use override verbatim
    2. `request.is_failed_rerun`             → QA_LOOP
    3. `request.is_legacy_audit`             → BROWNFIELD_DISCOVERY
    4. No `request.acceptance_criteria` AND
       no PRD reference                       → SPEC_PIPELINE
    5. Has AC AND complexity_score >= 4      → FULL_SDC
    6. Otherwise                             → EXPRESS_TEST (default)

The complexity heuristic is intentionally simple — the router doesn't try
to be smart, it just buckets requests. The persona dispatcher (N.2) is
where actual intelligence lives.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from agents._shared.harness.loader import HarnessLoader, get_harness
from agents._shared.harness.types import ResourceNotFoundError
from agents._shared.harness.workflows.parser import (
    WorkflowDefinition,
    parse_workflow_yaml,
)
from agents._shared.harness.workflows.types import WorkflowError, WorkflowKind


@dataclass(frozen=True)
class RouteRequest:
    """Input shape the router classifies."""

    run_id: str
    intent: str
    acceptance_criteria: tuple[str, ...] = ()
    is_failed_rerun: bool = False
    is_legacy_audit: bool = False
    has_prd_reference: bool = False
    target_paths: tuple[str, ...] = ()
    workflow_override: Optional[WorkflowKind] = None

    @property
    def complexity_score(self) -> int:
        """Quick heuristic — number of AC + 1 per target path beyond 3."""
        score = len(self.acceptance_criteria)
        if len(self.target_paths) > 3:
            score += len(self.target_paths) - 3
        return score


@dataclass(frozen=True)
class RouteDecision:
    """The router's verdict for a RouteRequest."""

    kind: WorkflowKind
    workflow_id: str
    reason: str
    definition: Optional[WorkflowDefinition] = None
    metadata: dict = field(default_factory=dict)


# Mapping from WorkflowKind to the bundled workflow id we hand off to.
# Some kinds (express-test, qa-loop, spec-pipeline) don't have dedicated
# YAML files yet — they reuse the closest greenfield/brownfield definition
# until proper workflow files are added in a future epic.
_KIND_TO_WORKFLOW_ID: dict[WorkflowKind, str] = {
    WorkflowKind.EXPRESS_TEST: "greenfield-service",      # smallest greenfield
    WorkflowKind.FULL_SDC: "greenfield-fullstack",        # full pipeline
    WorkflowKind.QA_LOOP: "greenfield-fullstack",         # reuses dev cycle
    WorkflowKind.SPEC_PIPELINE: "greenfield-fullstack",   # full planning
    WorkflowKind.BROWNFIELD_DISCOVERY: "brownfield-fullstack",
}


_FULL_SDC_THRESHOLD = 4  # complexity_score >= this → full SDC


class WorkflowRouter:
    """Routes a RouteRequest to the appropriate WorkflowKind."""

    def __init__(self, loader: Optional[HarnessLoader] = None):
        self._loader = loader or get_harness()
        self._defs_cache: dict[str, WorkflowDefinition] = {}

    def route(self, request: RouteRequest) -> RouteDecision:
        kind, reason = self._classify(request)
        workflow_id = _KIND_TO_WORKFLOW_ID[kind]
        definition = self._load_definition(workflow_id)
        return RouteDecision(
            kind=kind,
            workflow_id=workflow_id,
            reason=reason,
            definition=definition,
            metadata={
                "complexity_score": request.complexity_score,
                "ac_count": len(request.acceptance_criteria),
                "override_used": request.workflow_override is not None,
            },
        )

    @staticmethod
    def _classify(request: RouteRequest) -> tuple[WorkflowKind, str]:
        if request.workflow_override is not None:
            return (
                request.workflow_override,
                "explicit workflow_override",
            )

        if request.is_failed_rerun:
            return WorkflowKind.QA_LOOP, "is_failed_rerun=True"

        if request.is_legacy_audit:
            return (
                WorkflowKind.BROWNFIELD_DISCOVERY,
                "is_legacy_audit=True",
            )

        if not request.acceptance_criteria and not request.has_prd_reference:
            return (
                WorkflowKind.SPEC_PIPELINE,
                "no AC and no PRD reference — needs requirements gathering",
            )

        if request.complexity_score >= _FULL_SDC_THRESHOLD:
            return (
                WorkflowKind.FULL_SDC,
                f"complexity_score={request.complexity_score} >= {_FULL_SDC_THRESHOLD}",
            )

        return (
            WorkflowKind.EXPRESS_TEST,
            f"complexity_score={request.complexity_score} < {_FULL_SDC_THRESHOLD}",
        )

    def _load_definition(self, workflow_id: str) -> Optional[WorkflowDefinition]:
        if workflow_id in self._defs_cache:
            return self._defs_cache[workflow_id]
        try:
            source = self._loader.load_workflow(workflow_id)
        except ResourceNotFoundError:
            return None
        try:
            definition = parse_workflow_yaml(source, source_id=workflow_id)
        except WorkflowError:
            return None
        self._defs_cache[workflow_id] = definition
        return definition

    def list_kinds(self) -> tuple[WorkflowKind, ...]:
        return tuple(WorkflowKind)

    def workflow_id_for(self, kind: WorkflowKind) -> str:
        return _KIND_TO_WORKFLOW_ID[kind]
