"""Workflow router types."""

from __future__ import annotations

from enum import Enum


class WorkflowKind(str, Enum):
    """Canonical workflow kinds the harness can route to."""

    EXPRESS_TEST = "express-test"               # Lightweight SDC, ~3 personas
    FULL_SDC = "full-sdc"                       # Full 5-persona SDC
    QA_LOOP = "qa-loop"                         # Iterative review-fix, max 5
    SPEC_PIPELINE = "spec-pipeline"             # gather→assess→research→spec
    BROWNFIELD_DISCOVERY = "brownfield-discovery"  # 10-phase legacy audit


class WorkflowError(Exception):
    """Base error for workflow routing."""
