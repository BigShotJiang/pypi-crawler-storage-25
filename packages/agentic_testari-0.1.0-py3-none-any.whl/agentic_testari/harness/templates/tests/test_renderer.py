"""Tests for the {{var}} renderer."""

from __future__ import annotations

import pytest

from agents._shared.harness.templates import MissingVariableError, render


def test_simple_substitution():
    assert render("Hello {{name}}", {"name": "Renata"}) == "Hello Renata"


def test_whitespace_tolerated():
    assert render("Hi {{ name }}", {"name": "Dex"}) == "Hi Dex"


def test_dotted_access():
    out = render("Email: {{user.email}}", {"user": {"email": "x@y.z"}})
    assert out == "Email: x@y.z"


def test_default_value_used_when_missing():
    out = render("Count: {{count:0}}", {})
    assert out == "Count: 0"


def test_default_value_overridden_when_present():
    out = render("Count: {{count:0}}", {"count": 7})
    assert out == "Count: 7"


def test_strict_missing_raises():
    with pytest.raises(MissingVariableError) as exc_info:
        render("Hello {{name}}", {})
    assert exc_info.value.missing == ["name"]
    assert exc_info.value.template_id == "<inline>"


def test_non_strict_leaves_placeholder():
    out = render("Hi {{name}}", {}, strict=False)
    assert out == "Hi {{name}}"


def test_handlebars_helpers_left_intact():
    """Renderer must NOT try to evaluate Handlebars #if / #each / partials."""
    src = "{{#if cond}}A{{/if}} {{name}}"
    out = render(src, {"name": "x"})
    assert out == "{{#if cond}}A{{/if}} x"


def test_partials_left_intact():
    out = render("{{> mypartial}} {{name}}", {"name": "y"})
    assert out == "{{> mypartial}} y"


def test_bool_stringified_lowercase():
    out = render("active={{flag}}", {"flag": True})
    assert out == "active=true"


def test_none_stringified_empty():
    out = render("x={{val}}", {"val": None})
    assert out == "x="


def test_template_id_propagated_to_error():
    with pytest.raises(MissingVariableError) as exc_info:
        render("{{a}} {{b}}", {}, template_id="story")
    assert exc_info.value.template_id == "story"
    assert exc_info.value.missing == ["a", "b"]


def test_duplicate_missing_deduped():
    with pytest.raises(MissingVariableError) as exc_info:
        render("{{a}} {{a}} {{b}}", {})
    assert exc_info.value.missing == ["a", "b"]
