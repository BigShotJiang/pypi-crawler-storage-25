"""Tests for TemplateService — JIT instantiation against the real bundle."""

from __future__ import annotations

import pytest

from agents._shared.harness.templates import (
    MissingVariableError,
    TemplateKind,
    TemplateService,
)


@pytest.fixture(scope="module")
def svc() -> TemplateService:
    return TemplateService()


def _story_vars() -> dict[str, str]:
    return {
        "id": "RUN-T-001",
        "title": "Login flow",
        "asA": "user",
        "iWant": "to authenticate",
        "soThat": "I can access protected pages",
    }


def _qa_gate_vars() -> dict[str, str]:
    return {
        "task_id": "RUN-T-001",
        "gate_id": "GATE-001",
        "gate_name": "Login Acceptance Gate",
    }


def test_instantiate_story_returns_instance(svc: TemplateService):
    inst = svc.instantiate(
        TemplateKind.STORY,
        run_id="run-abc",
        variables=_story_vars(),
    )
    assert inst.metadata.kind == TemplateKind.STORY
    assert inst.metadata.run_id == "run-abc"
    assert inst.metadata.template_id == "story"
    assert inst.metadata.instance_id.startswith("tpl-")
    # Required variables must appear in the rendered text.
    assert "RUN-T-001" in inst.rendered
    assert "Login flow" in inst.rendered


def test_instantiate_story_applies_defaults(svc: TemplateService):
    inst = svc.instantiate(
        TemplateKind.STORY, run_id="run-1", variables=_story_vars()
    )
    # Defaults from the registry should appear in `variables`.
    assert inst.variables.get("priority") == "Medium"
    assert inst.variables.get("status") == "Draft"
    # run_id is auto-injected.
    assert inst.variables.get("run_id") == "run-1"


def test_user_vars_override_defaults(svc: TemplateService):
    vars_ = {**_story_vars(), "priority": "High"}
    inst = svc.instantiate(TemplateKind.STORY, run_id="r", variables=vars_)
    assert inst.variables["priority"] == "High"


def test_missing_required_raises(svc: TemplateService):
    incomplete = {k: v for k, v in _story_vars().items() if k != "title"}
    with pytest.raises(MissingVariableError) as exc_info:
        svc.instantiate(TemplateKind.STORY, run_id="r", variables=incomplete)
    assert "title" in exc_info.value.missing


def test_qa_gate_instantiation(svc: TemplateService):
    inst = svc.instantiate(
        TemplateKind.QA_GATE,
        run_id="run-xyz",
        variables=_qa_gate_vars(),
    )
    assert inst.metadata.kind == TemplateKind.QA_GATE
    assert inst.variables["gate_type"] == "blocking"  # default applied
    assert "GATE-001" in inst.rendered


def test_instances_have_unique_ids(svc: TemplateService):
    a = svc.instantiate(TemplateKind.STORY, run_id="r", variables=_story_vars())
    b = svc.instantiate(TemplateKind.STORY, run_id="r", variables=_story_vars())
    assert a.metadata.instance_id != b.metadata.instance_id


def test_registry_is_read_only(svc: TemplateService):
    """Mutating the returned registry must not affect the service."""
    snapshot = svc.registry
    snapshot.pop(TemplateKind.STORY, None)
    # Service still has all bindings.
    assert TemplateKind.STORY in svc.registry


def test_aidr_falls_back_to_adr_when_unbundled(svc: TemplateService):
    """AIDR template isn't yet bundled; service must fall back to ADR."""
    inst = svc.instantiate(
        TemplateKind.AIDR,
        run_id="run-aidr",
        variables={"number": "001", "title": "Sample", "status": "Proposed"},
    )
    # Either AIDR or ADR is acceptable depending on bundle state, but the
    # service must not crash and the rendered text must be non-empty.
    assert inst.metadata.template_id in ("aidr", "adr")
    assert inst.rendered.strip()


def test_unknown_kind_raises_keyerror():
    """Custom registry without a binding raises KeyError on instantiate."""
    custom = TemplateService(registry={})
    with pytest.raises(KeyError):
        custom.instantiate(TemplateKind.STORY, run_id="r", variables={})


def test_metadata_created_at_is_utc(svc: TemplateService):
    inst = svc.instantiate(TemplateKind.STORY, run_id="r", variables=_story_vars())
    assert inst.metadata.created_at.tzinfo is not None
