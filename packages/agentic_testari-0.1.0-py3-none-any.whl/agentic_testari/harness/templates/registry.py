"""Default bindings between TemplateKind and bundled template ids.

Each binding declares:
    - kind        : TemplateKind enum
    - template_id : id passed to HarnessLoader.load_template()
    - required    : variables that MUST be supplied at instantiation time
    - defaults    : variables auto-populated by the service if not supplied
                    (mostly run_id, timestamps, framework-injected values)

The defaults are defined as data, not code, so a future EPIC can mutate this
registry without touching the service. Customers cannot override the
constitution-bound bindings (story + qa-gate); they CAN add custom bindings.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from agents._shared.harness.templates.types import TemplateKind


@dataclass(frozen=True)
class TemplateBinding:
    """Declarative binding between a TemplateKind and a bundled template."""

    kind: TemplateKind
    template_id: str
    required: tuple[str, ...] = ()
    defaults: dict[str, str] = field(default_factory=dict)


def default_registry() -> dict[TemplateKind, TemplateBinding]:
    """Return the default kind→binding map.

    Story and QA Gate are mandatory per the constitution (every test run
    produces both). ADR and AIDR are emitted only when the harness detects a
    novel decision (gated by the persona dispatcher in N.2).
    """
    return {
        TemplateKind.STORY: TemplateBinding(
            kind=TemplateKind.STORY,
            template_id="story",
            required=("id", "title", "asA", "iWant", "soThat"),
            defaults={
                "epicRef": "AGtestari-runtime",
                "sprint": "0",
                "points": "0",
                "priority": "Medium",
                "status": "Draft",
            },
        ),
        TemplateKind.QA_GATE: TemplateBinding(
            kind=TemplateKind.QA_GATE,
            template_id="qa-gate-tmpl",
            required=("task_id", "gate_id", "gate_name"),
            defaults={
                "gate_type": "blocking",
                "validator": "harness",
                "version": "1.0",
            },
        ),
        TemplateKind.ADR: TemplateBinding(
            kind=TemplateKind.ADR,
            template_id="adr",
            required=("number", "title", "status"),
            defaults={"status": "Proposed"},
        ),
        TemplateKind.AIDR: TemplateBinding(
            kind=TemplateKind.AIDR,
            # AIDR template ships under the same name; if absent in the bundle
            # the service will fall back to the ADR template.
            template_id="aidr",
            required=("number", "title", "status"),
            defaults={"status": "Proposed"},
        ),
    }
