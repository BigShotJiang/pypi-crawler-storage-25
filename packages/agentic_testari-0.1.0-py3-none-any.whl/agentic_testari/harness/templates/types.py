"""Template types + errors."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4


class TemplateKind(str, Enum):
    """Kinds of runtime artifacts the harness instantiates per test run."""

    STORY = "story"
    QA_GATE = "qa-gate"
    ADR = "adr"
    AIDR = "aidr"


class TemplateError(Exception):
    """Base error for template operations."""


class MissingVariableError(TemplateError):
    """Raised when a required template variable was not supplied."""

    def __init__(self, missing: list[str], template_id: str):
        self.missing = sorted(missing)
        self.template_id = template_id
        super().__init__(
            f"Template {template_id!r} missing required variables: {self.missing}"
        )


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class TemplateMetadata:
    """Metadata captured at instantiation time."""

    kind: TemplateKind
    template_id: str
    run_id: str
    instance_id: str
    created_at: datetime


@dataclass(frozen=True)
class TemplateInstance:
    """A rendered template ready for persistence."""

    metadata: TemplateMetadata
    rendered: str
    variables: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def build(
        cls,
        *,
        kind: TemplateKind,
        template_id: str,
        run_id: str,
        rendered: str,
        variables: dict[str, Any],
        instance_id: str | None = None,
        created_at: datetime | None = None,
    ) -> "TemplateInstance":
        return cls(
            metadata=TemplateMetadata(
                kind=kind,
                template_id=template_id,
                run_id=run_id,
                instance_id=instance_id or f"tpl-{uuid4().hex[:12]}",
                created_at=created_at or _utc_now(),
            ),
            rendered=rendered,
            variables=dict(variables),
        )
