"""Template rendering — `{{var}}` substitution.

Deterministic, no arbitrary code execution. Supports:
    - Simple substitution: `{{name}}` → variables["name"]
    - Dotted access:       `{{user.email}}` → variables["user"]["email"]
    - Default value:       `{{count:0}}` → "0" if count missing
    - Whitespace tolerance: `{{ name }}` works the same as `{{name}}`

Every other template syntax is left as-is. This is intentional — the harness
needs predictable rendering, not Jinja2 power. AIOS templates that ship with
heavier syntax (Handlebars `{{#if}}`, YAML front-matter sections) get rendered
on a best-effort basis: variables substituted, structural blocks left intact
for downstream tools to consume.
"""

from __future__ import annotations

import re
from typing import Any

from agents._shared.harness.templates.types import MissingVariableError

_VAR_PATTERN = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")
# Handlebars helpers we leave intact (don't try to render them).
_HBS_HELPER_PREFIXES = ("#", "/", "!", ">", "^")


def _resolve(path: str, variables: dict[str, Any]) -> Any:
    cur: Any = variables
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            raise KeyError(path)
    return cur


def render(
    source: str,
    variables: dict[str, Any],
    *,
    template_id: str = "<inline>",
    strict: bool = True,
) -> str:
    """Render `{{var}}` placeholders in `source` against `variables`.

    Args:
        source: Template text.
        variables: Lookup table.
        template_id: Identifier surfaced in MissingVariableError messages.
        strict: When True (default), raise MissingVariableError if any required
            variable is missing. When False, leave the placeholder intact so
            the caller can decide what to do.

    Returns:
        Rendered string.
    """
    missing: list[str] = []

    def replace(match: re.Match[str]) -> str:
        expr = match.group(1).strip()

        # Leave Handlebars helpers and partials alone.
        if expr.startswith(_HBS_HELPER_PREFIXES):
            return match.group(0)

        # Default-value syntax: `{{name:fallback}}`.
        default: str | None = None
        if ":" in expr:
            expr, _, default = expr.partition(":")
            expr = expr.strip()
            default = default.strip()

        try:
            value = _resolve(expr, variables)
        except KeyError:
            if default is not None:
                return default
            missing.append(expr)
            return match.group(0) if not strict else ""

        return _stringify(value)

    rendered = _VAR_PATTERN.sub(replace, source)
    if strict and missing:
        # Deduplicate while preserving order.
        seen: set[str] = set()
        ordered: list[str] = []
        for m in missing:
            if m not in seen:
                seen.add(m)
                ordered.append(m)
        raise MissingVariableError(ordered, template_id=template_id)
    return rendered


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)
