"""TemplateService — JIT instantiation of harness templates per test run.

Pulls templates from the bundle via HarnessLoader, applies variable
substitution, and returns a TemplateInstance ready for storage. Persistence
is deliberately out of scope here — the service hands instances back; the
caller (test runner / verdict pipeline) writes them via the M.1 storage
layer or any other sink.

Design notes:
    - Service is stateless except for the loader handle and the registry.
      Reusable across many test runs.
    - The registry is constructor-injectable; tests pass a custom registry.
    - Defaults from the registry are merged UNDER user-supplied variables
      (user wins), so callers can override anything.
    - AIDR falls back to ADR template if AIDR is not yet bundled — the
      framework migration plan packages them separately, but during the
      transition we don't want runtime errors.
"""

from __future__ import annotations

from typing import Any, Optional

from agents._shared.harness.loader import HarnessLoader, get_harness
from agents._shared.harness.types import ResourceNotFoundError
from agents._shared.harness.templates.registry import (
    TemplateBinding,
    default_registry,
)
from agents._shared.harness.templates.renderer import render
from agents._shared.harness.templates.types import (
    MissingVariableError,
    TemplateInstance,
    TemplateKind,
)


class TemplateService:
    """JIT template instantiation for harness runtime artifacts."""

    def __init__(
        self,
        *,
        loader: Optional[HarnessLoader] = None,
        registry: Optional[dict[TemplateKind, TemplateBinding]] = None,
    ):
        self._loader = loader or get_harness()
        self._registry = registry if registry is not None else default_registry()

    @property
    def registry(self) -> dict[TemplateKind, TemplateBinding]:
        """Read-only view of the active registry."""
        return dict(self._registry)

    def binding(self, kind: TemplateKind) -> TemplateBinding:
        """Return the binding for a kind, raising KeyError if unbound."""
        if kind not in self._registry:
            raise KeyError(f"No binding registered for kind {kind!r}")
        return self._registry[kind]

    def instantiate(
        self,
        kind: TemplateKind,
        *,
        run_id: str,
        variables: Optional[dict[str, Any]] = None,
    ) -> TemplateInstance:
        """Render a template for a specific test run.

        Args:
            kind: Which TemplateKind to instantiate.
            run_id: The harness test run id this artifact belongs to.
            variables: Caller-supplied variables. Merged on top of registry
                defaults.

        Raises:
            MissingVariableError: when a required variable is not supplied
                (after registry defaults).
            KeyError: when no binding exists for `kind`.
            ResourceNotFoundError: when neither the primary nor fallback
                template is in the bundle.
        """
        binding = self.binding(kind)
        merged = self._merge_variables(binding, variables, run_id)

        missing_required = [v for v in binding.required if v not in merged]
        if missing_required:
            raise MissingVariableError(missing_required, binding.template_id)

        source, used_template_id = self._load_with_fallback(binding)
        rendered = render(source, merged, template_id=used_template_id, strict=False)

        return TemplateInstance.build(
            kind=kind,
            template_id=used_template_id,
            run_id=run_id,
            rendered=rendered,
            variables=merged,
        )

    # ---- helpers ----

    @staticmethod
    def _merge_variables(
        binding: TemplateBinding,
        user_vars: Optional[dict[str, Any]],
        run_id: str,
    ) -> dict[str, Any]:
        merged: dict[str, Any] = {"run_id": run_id, **dict(binding.defaults)}
        if user_vars:
            merged.update(user_vars)
        return merged

    def _load_with_fallback(self, binding: TemplateBinding) -> tuple[str, str]:
        """Load the primary template, falling back to ADR for AIDR if needed.

        Returns (source_text, template_id_used).
        """
        try:
            return self._loader.load_template(binding.template_id), binding.template_id
        except ResourceNotFoundError:
            if binding.kind is TemplateKind.AIDR:
                # AIDR may not be bundled yet; ADR template is functionally
                # interchangeable for runtime decision capture.
                return self._loader.load_template("adr"), "adr"
            raise
