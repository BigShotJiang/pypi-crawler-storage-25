"""Templates JIT — runtime artifacts for every test run (EPIC N.7).

The harness instantiates one or more templates per test invocation:
    - story        → user story for traceability (test_id + AC + scope)
    - qa-gate      → instantiated 12-point quality gate
    - adr          → if a runtime decision is novel
    - aidr         → if AI-specific decision detected

Templates come from the bundled AIOS resources (loaded via HarnessLoader).
Variable substitution is `{{var}}` style — keep simple, deterministic, no
arbitrary code execution. Rendered instances are returned as TemplateInstance
objects ready for persistence by the storage layer (M.1).

Usage:
    from agents._shared.harness.templates import TemplateService, TemplateKind

    svc = TemplateService()
    story = svc.instantiate(
        TemplateKind.STORY,
        run_id="run-123",
        variables={"id": "T-001", "title": "Login", ...},
    )
    # story.rendered → markdown text
    # story.metadata.kind → TemplateKind.STORY
    # story.metadata.run_id → "run-123"
"""

from agents._shared.harness.templates.types import (
    MissingVariableError,
    TemplateError,
    TemplateInstance,
    TemplateKind,
    TemplateMetadata,
)
from agents._shared.harness.templates.registry import (
    TemplateBinding,
    default_registry,
)
from agents._shared.harness.templates.renderer import render
from agents._shared.harness.templates.service import TemplateService

__all__ = [
    "TemplateService",
    "TemplateKind",
    "TemplateInstance",
    "TemplateMetadata",
    "TemplateBinding",
    "TemplateError",
    "MissingVariableError",
    "default_registry",
    "render",
]

__version__ = "1.0.0"
