# Doc-Sync Discipline — NON-NEGOTIABLE

globs: ["**/*"]

## Severity: NON-NEGOTIABLE

This rule cannot be overridden, bypassed, or skipped. Same severity as CLI First and Agent Authority. Failure to follow this rule produced the 2026-04-29 CLAUDE.md v3.0 incident — Maestro rewrote CLAUDE.md from memory + a user message instead of reading the architecture lock, then a brownfield audit ran against the outdated doc and flagged everything-that-didn't-match as a "gap", wasting agent work that had to be reversed.

## The Rule

**Every project pivot, architecture decision, or strategic shift MUST update the following three files in the SAME session, BEFORE any downstream agent work proceeds:**

1. `.claude/CLAUDE.md` — runtime contract for every Claude session
2. `docs/prd/PRD-MASTER.md` — single canonical PRD index pointing to live epic PRDs with current status
3. `~/.claude/projects/{project-folder}/memory/MEMORY.md` — user's auto-memory mirror

Plus update the originating authority doc (e.g. `docs/architecture/IMPORTANT-PRODUCT-ARCHITECTURE.md`) BEFORE the three above, since they should match it.

## What Counts as a "Pivot"

Any of:
- Architecture changes (e.g. priority flip, new distribution shape, dropping a track)
- Naming changes (product, package, binary, scope)
- Hosting / vendor changes (Azure → Hostinger, Hetzner → Cloudflare)
- Pricing model changes (free tier added/removed, tier price changes)
- Epic activation / deactivation / status change (active → paused → shipped)
- New decision that supersedes a previous decision
- Locked decision recorded with `**Status:** ACCEPTED — locked YYYY-MM-DD`

## What is NOT a "Pivot" (no doc-sync needed)

- Single-story implementation work
- Bug fixes within a known scope
- Test additions
- Doc clarifications inside a single PRD that don't change scope
- Internal refactoring with no external surface change

## Process

When a pivot is detected (user announces it OR you produce a recommendation that gets accepted):

1. **STOP** any in-flight downstream agent work that depends on the affected scope (architect, dev, qa, brownfield, etc.)
2. **READ** the existing authority docs in the affected area:
   - `docs/architecture/IMPORTANT-PRODUCT-ARCHITECTURE.md`
   - `docs/architecture/TWO-TRACK-DISTRIBUTION.md`
   - `docs/architecture/PORTABILITY-CONTRACT.md`
   - `docs/architecture/NAMING-CONVENTION.md`
   - `docs/architecture/AGTESTARI-HERMES-DECOUPLING.md`
   - `docs/launch/LAUNCH-STATE-{latest-date}.md`
   - `docs/prd/PRD-MASTER.md`
3. **WRITE / UPDATE** authority doc(s) for the new decision (lock with `**Status:** ACCEPTED — locked YYYY-MM-DD`)
4. **UPDATE CLAUDE.md** — bump version (v3.x → v3.x+1), update reference table, ensure file paths + names match reality
5. **UPDATE PRD-MASTER** — reflect epic status changes, scope shifts, deferrals
6. **UPDATE MEMORY.md** — mirror CLAUDE.md changes; add lesson-learned to "Critical Lessons" section if a previous version was wrong
7. **VERIFY** the four updates are consistent with each other and with the authority docs
8. Only THEN may downstream agent work resume

## Enforcement by Environment

**DEV** — Required. Agent work that proceeds against an outdated CLAUDE.md is a process failure (log it as a lesson).
**STAGING** — Required. Pre-push gate fails if CLAUDE.md / PRD-MASTER / MEMORY.md mtime is older than the most recent locked authority doc.
**PROD** — Required + signed commit on the doc updates. The commit message must reference the authority doc.

## Anti-Pattern Triggers

If you see any of the following, STOP and apply this rule:

- "rewrite the docs" / "update CLAUDE.md" → check authority docs FIRST, write CLAUDE.md AGAINST them
- "the project pivoted" / "we changed direction" → identify the authority doc that captures the pivot; if none exists, write it FIRST
- "brownfield audit" / "what's missing" / "current state" → read the authority docs into the audit's prompt; do not let the audit run against an outdated CLAUDE.md
- "Hetzner" or generic VPS terms when AGtestari uses Hostinger KVM2/KVM4 → flag inconsistency immediately
- "Azure" referenced as active when it should be dormant → flag and verify against Shape 3 status
- A user message that contradicts the current CLAUDE.md → reconcile BEFORE acting on the user's direction (verify which is correct, update the wrong one)

## Reference Examples

**GOOD:**
> User: "we're moving to Cloudflare D1 for verdicts"
> Maestro: "before I update anything, let me read PORTABILITY-CONTRACT.md and IMPORTANT-PRODUCT-ARCHITECTURE.md to see if D1 is already specced. … Confirmed D1 is in IMPORTANT-PRODUCT-ARCHITECTURE.md Shape 1 §1. Updating CLAUDE.md, PRD-MASTER, MEMORY.md to reflect verdict storage decision."

**BAD (2026-04-29 incident):**
> User: "azure is dormant, we're on npx + SaaS now"
> Maestro: *writes CLAUDE.md from memory without reading the architecture lock from 2 days prior*
> Result: CLAUDE.md says "2 modes" / "Hetzner" / `cli/` dir. Reality is "3 distribution shapes" / "Hostinger" / `packages/cli-npm/`. Brownfield audit then runs against the wrong CLAUDE.md and flags everything-that-doesn't-match as gaps. Wave 1 DB fixes get reversed.

---

*Doc-Sync Discipline v1.0 — locked 2026-04-29*
*Truth state, not aspiration. Update before every pivot. Never let an agent work against an outdated copy.*
