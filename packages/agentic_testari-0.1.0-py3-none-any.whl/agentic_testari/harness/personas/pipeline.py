"""Sequential persona pipeline — architect → sm → po → dev → qa.

Per AC of N.2: a single test invocation produces a chain of 5 persona calls,
each logged, each with its own AIOS rule enforcement.

Each stage receives the rolling chain of upstream PersonaResults via
InvocationContext.chain — so a downstream persona can read what upstream
decided without the harness having to flatten the chain into prose.

The pipeline is sequential by design (Phase 1 non-goal NG3 from EPIC N PRD:
"Live agent-to-agent network in Phase 1 — runtime persona invocation is
sequential, not concurrent").
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

from agents._shared.harness.personas.invocation import (
    InvocationContext,
    LLMClient,
    PersonaInvocation,
    PersonaResult,
)
from agents._shared.harness.personas.registry import PersonaRegistry
from agents._shared.harness.personas.types import PersonaError

DEFAULT_PIPELINE: tuple[str, ...] = ("architect", "sm", "po", "dev", "qa")


@dataclass(frozen=True)
class PipelineRun:
    """Result of one full pipeline invocation."""

    run_id: str
    test_intent: str
    results: tuple[PersonaResult, ...]

    @property
    def final(self) -> PersonaResult:
        """The last persona's result — typically @qa's verdict."""
        if not self.results:
            raise PersonaError("PipelineRun has no results")
        return self.results[-1]


class Pipeline:
    """Orchestrates sequential persona invocations against an LLMClient."""

    def __init__(
        self,
        *,
        personas: Sequence[str],
        registry: Optional[PersonaRegistry] = None,
    ):
        if not personas:
            raise PersonaError("Pipeline requires at least one persona id")
        self._personas = tuple(personas)
        self._registry = registry or PersonaRegistry()

    @classmethod
    def default(cls, registry: Optional[PersonaRegistry] = None) -> "Pipeline":
        """Construct the canonical SDC pipeline."""
        return cls(personas=DEFAULT_PIPELINE, registry=registry)

    @property
    def persona_ids(self) -> tuple[str, ...]:
        return self._personas

    async def run(
        self,
        *,
        run_id: str,
        test_intent: str,
        llm: LLMClient,
        metadata: Optional[dict] = None,
    ) -> PipelineRun:
        """Execute the pipeline end-to-end against `llm`.

        Each stage's PersonaResult is appended to the InvocationContext.chain
        before the next stage is invoked.
        """
        ctx = InvocationContext(
            run_id=run_id,
            test_intent=test_intent,
            metadata=dict(metadata or {}),
        )
        results: list[PersonaResult] = []

        for persona_id in self._personas:
            persona = self._registry.get(persona_id)
            user_prompt = self._build_prompt(persona_id, ctx)
            invocation = PersonaInvocation.build(
                persona_id=persona_id,
                run_id=run_id,
                user_prompt=user_prompt,
                system_prompt_hash=self._registry.system_prompt_hash(persona_id),
            )
            response = await llm.complete(
                system_prompt=persona.system_prompt,
                user_prompt=user_prompt,
                metadata={"persona": persona_id, "run_id": run_id},
            )
            result = PersonaResult.from_response(
                invocation=invocation, response=response
            )
            results.append(result)
            ctx = ctx.append(result)

        return PipelineRun(
            run_id=run_id,
            test_intent=test_intent,
            results=tuple(results),
        )

    @staticmethod
    def _build_prompt(persona_id: str, ctx: InvocationContext) -> str:
        """Assemble the user prompt fed to a persona at this pipeline stage.

        Format:
            [TEST INTENT]
            <test_intent>

            [UPSTREAM CHAIN]
            <persona_a> → <one-line summary>
            <persona_b> → <one-line summary>

            [YOUR TURN — <persona_id>]
            Produce your stage's output per your persona definition.

        Keeping the format compact + deterministic so token cost stays low
        and unit tests can assert on shape.
        """
        lines: list[str] = ["[TEST INTENT]", ctx.test_intent.strip(), ""]
        if ctx.chain:
            lines.append("[UPSTREAM CHAIN]")
            for r in ctx.chain:
                first = r.output.strip().splitlines()[0] if r.output.strip() else ""
                lines.append(f"{r.persona_id} → {first[:160]}")
            lines.append("")
        lines.append(f"[YOUR TURN — {persona_id}]")
        lines.append(
            "Produce your stage's output per your persona definition. "
            "Stay within your boundary; defer cross-boundary actions to the "
            "appropriate persona."
        )
        return "\n".join(lines)
