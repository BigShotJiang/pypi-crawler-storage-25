"""Hard-coded persona boundaries derived from `.claude/rules/agent-authority.md`.

These boundaries are part of the constitutional surface — they cannot be
disabled at runtime. The rule markdown is loaded for context (rules engine
N.4 uses it), but enforcement is data-driven from this module so a typo
in the markdown can't silently weaken a boundary.

Each boundary is a short label. The rules engine maps labels to runtime
checks (e.g., `no_remote_push` → intercept `git push` calls).
"""

from __future__ import annotations


class BoundaryViolation(Exception):
    """Raised when an action attempts to cross a persona's hard boundary."""

    def __init__(self, persona_id: str, boundary: str, action: str):
        self.persona_id = persona_id
        self.boundary = boundary
        self.action = action
        super().__init__(
            f"Persona {persona_id!r} cannot perform {action!r} "
            f"(violates boundary {boundary!r})"
        )


_DEFAULT_BOUNDARIES: dict[str, tuple[str, ...]] = {
    # @devops is the ONLY persona that can push / open PRs / manage MCP.
    "devops": (),
    # All other personas are blocked from push/PR by default.
    "dev": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "qa": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "architect": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "pm": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "po": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "sm": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "data-engineer": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "analyst": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "ux-design-expert": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "security": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "compliance": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "stability": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "strategy": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    "squad-creator": ("no_remote_push", "no_pr_create", "no_mcp_management"),
    # @aios-master can override boundaries for framework health.
    "aios-master": (),
}


def default_boundaries(persona_id: str) -> tuple[str, ...]:
    """Return the default boundary tuple for a known persona id.

    Unknown ids return the strict default (everything blocked) — safer than
    accidentally granting elevated authority to an unrecognised persona.
    """
    if persona_id in _DEFAULT_BOUNDARIES:
        return _DEFAULT_BOUNDARIES[persona_id]
    return ("no_remote_push", "no_pr_create", "no_mcp_management")


def all_known_personas() -> tuple[str, ...]:
    return tuple(sorted(_DEFAULT_BOUNDARIES.keys()))
