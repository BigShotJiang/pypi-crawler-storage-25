"""Invocation primitives — LLM-agnostic protocol for persona calls.

The harness must work in three LLM modes (per AIDR-022/025):
    1. BYO API key (OpenAI / Anthropic env vars)
    2. MCP-delegated host (Claude Code / Codex / Cursor)
    3. Founder's own dev subscription (same MCP path)

All three implement the LLMClient protocol below. Persona invocations never
touch SDK specifics — they hand a prompt + system_prompt to the LLMClient
and consume the response.

This module also defines the InvocationContext (what the persona sees) and
the PersonaInvocation/PersonaResult records (audit trail for the verdict
pipeline).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Protocol, runtime_checkable
from uuid import uuid4


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class InvocationContext:
    """Context passed into a persona invocation.

    `chain` is the rolling list of prior persona results in the pipeline,
    used by downstream personas to see what upstream decided. Read-only.
    """

    run_id: str
    test_intent: str
    metadata: Mapping[str, Any] = field(default_factory=dict)
    chain: tuple["PersonaResult", ...] = ()

    def append(self, result: "PersonaResult") -> "InvocationContext":
        """Return a new context with `result` appended to the chain."""
        return InvocationContext(
            run_id=self.run_id,
            test_intent=self.test_intent,
            metadata=dict(self.metadata),
            chain=self.chain + (result,),
        )


@dataclass(frozen=True)
class LLMResponse:
    """LLM provider's response, normalised."""

    text: str
    model: str = ""
    usage: Mapping[str, int] = field(default_factory=dict)


@runtime_checkable
class LLMClient(Protocol):
    """Protocol every LLM mode must implement.

    Async-only — even MCP-delegated calls are awaitable. Implementations live
    outside this package (e.g., `agents/_shared/llm/openai_client.py`).
    """

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> LLMResponse: ...


@dataclass(frozen=True)
class PersonaInvocation:
    """Inputs captured for an invocation, for audit."""

    invocation_id: str
    persona_id: str
    run_id: str
    user_prompt: str
    system_prompt_hash: str
    started_at: datetime

    @classmethod
    def build(
        cls,
        *,
        persona_id: str,
        run_id: str,
        user_prompt: str,
        system_prompt_hash: str,
    ) -> "PersonaInvocation":
        return cls(
            invocation_id=f"inv-{uuid4().hex[:12]}",
            persona_id=persona_id,
            run_id=run_id,
            user_prompt=user_prompt,
            system_prompt_hash=system_prompt_hash,
            started_at=_utc_now(),
        )


@dataclass(frozen=True)
class PersonaResult:
    """Outputs captured from an invocation, for audit + handoff."""

    invocation: PersonaInvocation
    persona_id: str
    output: str
    finished_at: datetime
    model: str = ""
    usage: Mapping[str, int] = field(default_factory=dict)

    @classmethod
    def from_response(
        cls,
        *,
        invocation: PersonaInvocation,
        response: LLMResponse,
    ) -> "PersonaResult":
        return cls(
            invocation=invocation,
            persona_id=invocation.persona_id,
            output=response.text,
            finished_at=_utc_now(),
            model=response.model,
            usage=dict(response.usage),
        )
