"""Persona dispatcher (EPIC N.2).

Wraps each AIOS persona file (`.aios-core/development/agents/{id}.md`) as a
runtime-invokable `Persona` instance with:
    - system_prompt: str          — the persona's full markdown definition
    - tools: tuple[str, ...]      — declarative list of framework tools allowed
    - boundary: tuple[str, ...]   — hard-coded "must NOT do" rules from
                                     `.claude/rules/agent-authority.md`

Pipeline: sequential dispatch architect → sm → po → dev → qa, where each
stage runs `await persona.invoke(prompt, context, llm_client)`. The LLM
client is abstracted so BYO API keys and MCP-delegated hosts share the same
interface.

Usage:
    from agents._shared.harness.personas import (
        PersonaRegistry, Pipeline, LLMClient, BoundaryViolation,
    )

    registry = PersonaRegistry()
    arch = registry.get("architect")
    pipeline = Pipeline.default(registry)  # architect → sm → po → dev → qa
    result = await pipeline.run("test login", context={...}, llm=my_llm_client)
"""

from agents._shared.harness.personas.boundaries import (
    BoundaryViolation,
    default_boundaries,
)
from agents._shared.harness.personas.invocation import (
    InvocationContext,
    LLMClient,
    LLMResponse,
    PersonaInvocation,
    PersonaResult,
)
from agents._shared.harness.personas.pipeline import Pipeline, PipelineRun
from agents._shared.harness.personas.registry import PersonaRegistry
from agents._shared.harness.personas.types import Persona, PersonaError

__all__ = [
    "Persona",
    "PersonaError",
    "PersonaRegistry",
    "Pipeline",
    "PipelineRun",
    "InvocationContext",
    "PersonaInvocation",
    "PersonaResult",
    "LLMClient",
    "LLMResponse",
    "BoundaryViolation",
    "default_boundaries",
]

__version__ = "1.0.0"
