"""Persona types + errors."""

from __future__ import annotations

from dataclasses import dataclass


class PersonaError(Exception):
    """Base error for persona operations."""


@dataclass(frozen=True)
class Persona:
    """A runtime-invokable AIOS persona.

    Constructed by `PersonaRegistry.get()`. Holds the system prompt loaded
    from the bundled persona file plus the declarative tools/boundaries
    derived from the `agent-authority` rule.
    """

    id: str
    system_prompt: str
    tools: tuple[str, ...] = ()
    boundary: tuple[str, ...] = ()

    def with_boundary(self, *extra: str) -> "Persona":
        """Return a new Persona with additional boundary rules appended."""
        return Persona(
            id=self.id,
            system_prompt=self.system_prompt,
            tools=self.tools,
            boundary=self.boundary + tuple(extra),
        )
