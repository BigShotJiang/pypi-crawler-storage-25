"""Persona registry — turns bundled persona files into Persona instances.

Each `.aios-core/development/agents/{id}.md` becomes a Persona with:
    - system_prompt → the markdown text verbatim
    - tools         → declarative tool list (currently empty; N.6 wires
                       skills as tools)
    - boundary      → from boundaries.default_boundaries(persona_id)

Registry caches Persona instances; subsequent `.get(id)` calls return the
same object so audit hashes (system_prompt_hash) stay stable across a run.
"""

from __future__ import annotations

import hashlib
from typing import Optional

from agents._shared.harness.loader import HarnessLoader, get_harness
from agents._shared.harness.personas.boundaries import default_boundaries
from agents._shared.harness.personas.types import Persona, PersonaError


class PersonaRegistry:
    """Cache of Persona instances loaded from the bundle."""

    def __init__(self, loader: Optional[HarnessLoader] = None):
        self._loader = loader or get_harness()
        self._cache: dict[str, Persona] = {}

    def list_ids(self) -> list[str]:
        """Return the ids of all personas available in the bundle."""
        return self._loader.list_personas()

    def get(self, persona_id: str) -> Persona:
        """Return a Persona instance, loading from the bundle on first call."""
        if persona_id not in self._cache:
            try:
                system_prompt = self._loader.load_persona(persona_id)
            except Exception as exc:
                raise PersonaError(
                    f"Cannot load persona {persona_id!r}: {exc}"
                ) from exc
            self._cache[persona_id] = Persona(
                id=persona_id,
                system_prompt=system_prompt,
                tools=(),
                boundary=default_boundaries(persona_id),
            )
        return self._cache[persona_id]

    def system_prompt_hash(self, persona_id: str) -> str:
        """Stable SHA-256 prefix of the persona's system prompt."""
        persona = self.get(persona_id)
        digest = hashlib.sha256(persona.system_prompt.encode("utf-8")).hexdigest()
        return digest[:16]

    def reset(self) -> None:
        """Drop cached personas — useful for tests that mutate the bundle."""
        self._cache.clear()
