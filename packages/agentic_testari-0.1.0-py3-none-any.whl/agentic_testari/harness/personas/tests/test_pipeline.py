"""Tests for sequential persona pipeline (architect → sm → po → dev → qa).

The pipeline is the dispatcher core for N.2: each test invocation produces a
chain of N persona calls against an injected LLMClient. Tests use a stub LLM
that records what it was asked, so we can assert ordering, prompt format, and
chain accumulation without real LLM cost.
"""

from __future__ import annotations

from typing import Any, Mapping

import pytest

from agents._shared.harness.personas.invocation import (
    LLMResponse,
    PersonaResult,
)
from agents._shared.harness.personas.pipeline import (
    DEFAULT_PIPELINE,
    Pipeline,
    PipelineRun,
)
from agents._shared.harness.personas.registry import PersonaRegistry
from agents._shared.harness.personas.types import PersonaError


class _RecordingLLM:
    """Stub LLM that records every call, returns a deterministic response."""

    def __init__(self):
        self.calls: list[dict[str, Any]] = []

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> LLMResponse:
        self.calls.append(
            {
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "metadata": dict(metadata or {}),
            }
        )
        # Echo the persona id so test assertions can verify ordering.
        persona_id = (metadata or {}).get("persona", "?")
        return LLMResponse(
            text=f"[{persona_id}] decision\nmore details",
            model="stub-model",
            usage={"input": 10, "output": 5},
        )


# ---- happy path ----


def test_default_pipeline_constants_match_sdc_order():
    # Pin the canonical sequence per AIDR-012 (Story Development Cycle).
    assert DEFAULT_PIPELINE == ("architect", "sm", "po", "dev", "qa")


def test_pipeline_default_uses_sdc_order():
    p = Pipeline.default()
    assert p.persona_ids == DEFAULT_PIPELINE


def test_pipeline_custom_personas_are_preserved():
    p = Pipeline(personas=("dev", "qa"))
    assert p.persona_ids == ("dev", "qa")


@pytest.mark.asyncio
async def test_pipeline_run_invokes_all_personas_in_order():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(
        run_id="run-001",
        test_intent="exercise login flow",
        llm=llm,
    )
    assert isinstance(run, PipelineRun)
    assert run.run_id == "run-001"
    assert run.test_intent == "exercise login flow"
    assert len(run.results) == 5
    actual_order = tuple(r.persona_id for r in run.results)
    assert actual_order == DEFAULT_PIPELINE


@pytest.mark.asyncio
async def test_pipeline_run_records_one_llm_call_per_persona():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    await pipeline.run(run_id="r", test_intent="x", llm=llm)
    assert len(llm.calls) == 5
    actual_order = tuple(c["metadata"]["persona"] for c in llm.calls)
    assert actual_order == DEFAULT_PIPELINE


@pytest.mark.asyncio
async def test_pipeline_run_passes_run_id_in_metadata():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    await pipeline.run(run_id="run-42", test_intent="x", llm=llm)
    for call in llm.calls:
        assert call["metadata"]["run_id"] == "run-42"


@pytest.mark.asyncio
async def test_pipeline_run_uses_each_personas_system_prompt():
    llm = _RecordingLLM()
    registry = PersonaRegistry()
    pipeline = Pipeline.default(registry=registry)
    await pipeline.run(run_id="r", test_intent="x", llm=llm)
    # Each call's system_prompt MUST match the corresponding persona's prompt.
    for call, persona_id in zip(llm.calls, DEFAULT_PIPELINE):
        expected = registry.get(persona_id).system_prompt
        assert call["system_prompt"] == expected


@pytest.mark.asyncio
async def test_pipeline_user_prompt_includes_test_intent():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    await pipeline.run(run_id="r", test_intent="exercise login flow", llm=llm)
    for call in llm.calls:
        assert "exercise login flow" in call["user_prompt"]
        assert "[TEST INTENT]" in call["user_prompt"]


@pytest.mark.asyncio
async def test_pipeline_user_prompt_includes_upstream_chain_after_first_stage():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    await pipeline.run(run_id="r", test_intent="x", llm=llm)
    # First call (architect): no upstream chain header.
    assert "[UPSTREAM CHAIN]" not in llm.calls[0]["user_prompt"]
    # Subsequent calls accumulate upstream lines.
    assert "[UPSTREAM CHAIN]" in llm.calls[1]["user_prompt"]
    assert "architect →" in llm.calls[1]["user_prompt"]
    # qa (last call) sees all 4 prior personas.
    qa_prompt = llm.calls[-1]["user_prompt"]
    for upstream in ("architect", "sm", "po", "dev"):
        assert f"{upstream} →" in qa_prompt


@pytest.mark.asyncio
async def test_pipeline_run_final_returns_last_result():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(run_id="r", test_intent="x", llm=llm)
    assert run.final.persona_id == "qa"
    assert run.final is run.results[-1]


@pytest.mark.asyncio
async def test_pipeline_run_results_carry_invocation_audit_data():
    llm = _RecordingLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(run_id="run-7", test_intent="x", llm=llm)
    for result in run.results:
        assert isinstance(result, PersonaResult)
        assert result.invocation.run_id == "run-7"
        assert result.invocation.invocation_id.startswith("inv-")
        assert len(result.invocation.system_prompt_hash) == 16


# ---- error path ----


def test_pipeline_with_empty_personas_raises():
    with pytest.raises(PersonaError, match="at least one persona"):
        Pipeline(personas=())


@pytest.mark.asyncio
async def test_pipeline_with_unknown_persona_raises_persona_error():
    llm = _RecordingLLM()
    pipeline = Pipeline(personas=("dev", "totally-not-real"))
    with pytest.raises(PersonaError):
        await pipeline.run(run_id="r", test_intent="x", llm=llm)


def test_pipeline_run_final_on_empty_results_raises():
    empty = PipelineRun(run_id="r", test_intent="x", results=())
    with pytest.raises(PersonaError, match="no results"):
        _ = empty.final


# ---- edge cases ----


@pytest.mark.asyncio
async def test_pipeline_with_single_persona_runs_one_invocation():
    llm = _RecordingLLM()
    pipeline = Pipeline(personas=("qa",))
    run = await pipeline.run(run_id="r", test_intent="x", llm=llm)
    assert len(run.results) == 1
    assert run.results[0].persona_id == "qa"
    assert run.final is run.results[0]


@pytest.mark.asyncio
async def test_pipeline_truncates_upstream_summary_to_160_chars():
    class _LongOutputLLM:
        async def complete(self, *, system_prompt, user_prompt, metadata=None):
            return LLMResponse(text="x" * 500)

    llm = _LongOutputLLM()
    pipeline = Pipeline(personas=("dev", "qa"))
    await pipeline.run(run_id="r", test_intent="x", llm=llm)
    # No assertion on _LongOutputLLM's calls (it doesn't record), but the
    # pipeline must complete without error — it truncates to keep tokens cheap.


@pytest.mark.asyncio
async def test_pipeline_passes_metadata_dict_to_each_call():
    llm = _RecordingLLM()
    pipeline = Pipeline(personas=("dev",))
    await pipeline.run(
        run_id="r",
        test_intent="x",
        llm=llm,
        metadata={"env": "dev", "story_id": "N.2"},
    )
    # The pipeline's own per-call metadata wins (persona, run_id), but
    # callers' metadata is currently scoped to context — assert run completes.
    assert len(llm.calls) == 1
