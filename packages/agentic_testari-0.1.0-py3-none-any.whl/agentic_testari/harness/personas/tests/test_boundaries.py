"""Tests for boundary enforcement primitives.

The boundaries module is the source of truth for "what each persona MUST NOT
do". A typo here would silently weaken the constitutional surface, so these
tests pin the exact set of rules per known persona.
"""

from __future__ import annotations

import pytest

from agents._shared.harness.personas.boundaries import (
    BoundaryViolation,
    all_known_personas,
    default_boundaries,
)


# ---- happy path: known personas ----


def test_devops_has_no_default_boundaries():
    # @devops is the ONLY persona with push/PR/MCP authority.
    assert default_boundaries("devops") == ()


def test_aios_master_has_no_default_boundaries():
    # @aios-master can override boundaries for framework health.
    assert default_boundaries("aios-master") == ()


@pytest.mark.parametrize(
    "persona_id",
    [
        "dev",
        "qa",
        "architect",
        "pm",
        "po",
        "sm",
        "data-engineer",
        "analyst",
        "ux-design-expert",
        "security",
        "compliance",
        "stability",
        "strategy",
        "squad-creator",
    ],
)
def test_restricted_personas_have_three_default_boundaries(persona_id: str):
    boundaries = default_boundaries(persona_id)
    assert boundaries == (
        "no_remote_push",
        "no_pr_create",
        "no_mcp_management",
    ), f"{persona_id!r} boundaries drifted"


def test_all_known_personas_returns_sorted_tuple():
    known = all_known_personas()
    assert known == tuple(sorted(known))
    assert isinstance(known, tuple)


def test_all_known_personas_includes_renatas_critical_set():
    known = all_known_personas()
    for must_have in ("dev", "qa", "devops", "architect", "pm", "po", "sm"):
        assert must_have in known


# ---- error path: unknown persona ----


def test_unknown_persona_returns_strict_default():
    # Strict default = everything blocked. Safer than failing open.
    assert default_boundaries("totally-made-up") == (
        "no_remote_push",
        "no_pr_create",
        "no_mcp_management",
    )


def test_unknown_persona_with_empty_id_returns_strict_default():
    assert default_boundaries("") == (
        "no_remote_push",
        "no_pr_create",
        "no_mcp_management",
    )


# ---- BoundaryViolation ----


def test_boundary_violation_carries_context():
    err = BoundaryViolation(
        persona_id="dev",
        boundary="no_remote_push",
        action="git push",
    )
    assert err.persona_id == "dev"
    assert err.boundary == "no_remote_push"
    assert err.action == "git push"


def test_boundary_violation_message_includes_persona_action_boundary():
    err = BoundaryViolation(
        persona_id="dev",
        boundary="no_remote_push",
        action="git push origin main",
    )
    msg = str(err)
    assert "dev" in msg
    assert "git push origin main" in msg
    assert "no_remote_push" in msg


def test_boundary_violation_is_raisable():
    with pytest.raises(BoundaryViolation) as excinfo:
        raise BoundaryViolation(
            persona_id="dev",
            boundary="no_pr_create",
            action="gh pr create",
        )
    assert excinfo.value.persona_id == "dev"
    assert excinfo.value.action == "gh pr create"


# ---- edge: every known persona id is unique ----


def test_no_duplicate_persona_ids_in_registry():
    known = all_known_personas()
    assert len(known) == len(set(known))


def test_default_boundaries_returns_tuple_not_list():
    # Mutability would let downstream code accidentally weaken boundaries.
    assert isinstance(default_boundaries("dev"), tuple)
    assert isinstance(default_boundaries("devops"), tuple)
    assert isinstance(default_boundaries("nonsense"), tuple)
