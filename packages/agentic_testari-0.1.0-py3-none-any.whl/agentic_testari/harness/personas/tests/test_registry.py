"""Tests for PersonaRegistry — load + cache + hash personas from the bundle.

Run against the real on-disk `.aios-core/development/agents/` directory, which
is the same layout shipped in the wheel.
"""

from __future__ import annotations

import pytest

from agents._shared.harness.personas.registry import PersonaRegistry
from agents._shared.harness.personas.types import Persona, PersonaError


# ---- happy path ----


def test_list_ids_returns_sorted_persona_ids():
    reg = PersonaRegistry()
    ids = reg.list_ids()
    assert isinstance(ids, list)
    assert ids == sorted(ids)
    assert len(ids) >= 7


def test_list_ids_includes_critical_personas():
    reg = PersonaRegistry()
    ids = reg.list_ids()
    for must_have in ("dev", "qa", "architect", "pm", "po", "sm", "devops"):
        assert must_have in ids, f"{must_have!r} missing from {ids}"


def test_get_returns_persona_with_loaded_system_prompt():
    reg = PersonaRegistry()
    persona = reg.get("dev")
    assert isinstance(persona, Persona)
    assert persona.id == "dev"
    assert len(persona.system_prompt) > 100  # real persona file is non-trivial


def test_get_attaches_default_boundary_for_dev():
    reg = PersonaRegistry()
    persona = reg.get("dev")
    assert "no_remote_push" in persona.boundary
    assert "no_pr_create" in persona.boundary
    assert "no_mcp_management" in persona.boundary


def test_get_attaches_empty_boundary_for_devops():
    reg = PersonaRegistry()
    persona = reg.get("devops")
    assert persona.boundary == ()


def test_get_caches_persona_returns_same_instance():
    reg = PersonaRegistry()
    p1 = reg.get("dev")
    p2 = reg.get("dev")
    assert p1 is p2  # cache returns the SAME object — important for hash stability


# ---- system_prompt_hash ----


def test_system_prompt_hash_is_stable_across_calls():
    reg = PersonaRegistry()
    h1 = reg.system_prompt_hash("dev")
    h2 = reg.system_prompt_hash("dev")
    assert h1 == h2


def test_system_prompt_hash_differs_per_persona():
    reg = PersonaRegistry()
    h_dev = reg.system_prompt_hash("dev")
    h_qa = reg.system_prompt_hash("qa")
    assert h_dev != h_qa


def test_system_prompt_hash_is_16_char_hex():
    reg = PersonaRegistry()
    h = reg.system_prompt_hash("architect")
    assert len(h) == 16
    int(h, 16)  # raises if not hex


# ---- error path ----


def test_get_unknown_persona_raises_persona_error():
    reg = PersonaRegistry()
    with pytest.raises(PersonaError, match="Cannot load persona"):
        reg.get("definitely-not-a-real-persona")


def test_system_prompt_hash_on_unknown_persona_raises_persona_error():
    reg = PersonaRegistry()
    with pytest.raises(PersonaError):
        reg.system_prompt_hash("definitely-not-a-real-persona")


# ---- reset behaviour ----


def test_reset_drops_cache_so_next_get_reloads():
    reg = PersonaRegistry()
    p1 = reg.get("dev")
    reg.reset()
    p2 = reg.get("dev")
    # New instance after reset (different object identity).
    assert p1 is not p2
    # But same value (immutable dataclass).
    assert p1 == p2


def test_reset_on_empty_cache_is_safe():
    reg = PersonaRegistry()
    reg.reset()  # No-op on fresh registry; should not raise.
    persona = reg.get("dev")
    assert persona.id == "dev"


# ---- edge cases ----


def test_get_loads_all_listed_personas_without_error():
    reg = PersonaRegistry()
    ids = reg.list_ids()
    loaded = [reg.get(pid) for pid in ids]
    assert len(loaded) == len(ids)
    assert all(isinstance(p, Persona) for p in loaded)


def test_each_persona_has_nonempty_system_prompt():
    reg = PersonaRegistry()
    for pid in reg.list_ids():
        persona = reg.get(pid)
        assert persona.system_prompt.strip(), f"{pid!r} has empty system prompt"


def test_each_persona_id_matches_loaded_id():
    reg = PersonaRegistry()
    for pid in reg.list_ids():
        assert reg.get(pid).id == pid
