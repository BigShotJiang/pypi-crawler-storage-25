"""Tests for invocation primitives — InvocationContext, PersonaInvocation,
PersonaResult, LLMClient protocol.

The contract these tests pin:
    - PersonaInvocation captures every field needed for audit replay
    - PersonaResult round-trips an LLMResponse without losing usage data
    - InvocationContext.append is functional (returns new instance)
    - LLMClient is a runtime-checkable Protocol so duck-typed clients pass
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

import pytest

from agents._shared.harness.personas.invocation import (
    InvocationContext,
    LLMClient,
    LLMResponse,
    PersonaInvocation,
    PersonaResult,
)


# ---- LLMResponse ----


def test_llm_response_defaults_model_and_usage():
    r = LLMResponse(text="hello")
    assert r.text == "hello"
    assert r.model == ""
    assert r.usage == {}


def test_llm_response_carries_usage_dict():
    r = LLMResponse(
        text="hi",
        model="gpt-4o",
        usage={"input": 10, "output": 5},
    )
    assert r.model == "gpt-4o"
    assert r.usage == {"input": 10, "output": 5}


def test_llm_response_is_frozen():
    r = LLMResponse(text="hi")
    with pytest.raises(Exception):
        r.text = "bye"  # type: ignore[misc]


# ---- LLMClient Protocol ----


class _StubLLM:
    """Minimal LLMClient implementation for protocol-conformance check."""

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> LLMResponse:
        return LLMResponse(text="stub", model="stub-model")


def test_stub_llm_satisfies_llm_client_protocol():
    # runtime_checkable means isinstance() works for duck-typed clients.
    assert isinstance(_StubLLM(), LLMClient)


def test_non_llm_object_does_not_satisfy_protocol():
    class NotAnLLM:
        pass

    assert not isinstance(NotAnLLM(), LLMClient)


# ---- PersonaInvocation ----


def test_persona_invocation_build_assigns_unique_invocation_id():
    inv1 = PersonaInvocation.build(
        persona_id="dev",
        run_id="run-1",
        user_prompt="do thing",
        system_prompt_hash="abc123",
    )
    inv2 = PersonaInvocation.build(
        persona_id="dev",
        run_id="run-1",
        user_prompt="do thing",
        system_prompt_hash="abc123",
    )
    assert inv1.invocation_id != inv2.invocation_id
    assert inv1.invocation_id.startswith("inv-")


def test_persona_invocation_build_records_started_at_utc():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="run-1",
        user_prompt="x",
        system_prompt_hash="h",
    )
    assert inv.started_at.tzinfo == timezone.utc


def test_persona_invocation_is_frozen():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    with pytest.raises(Exception):
        inv.persona_id = "qa"  # type: ignore[misc]


# ---- PersonaResult.from_response ----


def test_persona_result_from_response_copies_response_fields():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    response = LLMResponse(
        text="implementation done",
        model="gpt-4o",
        usage={"input": 100, "output": 50},
    )
    result = PersonaResult.from_response(invocation=inv, response=response)
    assert result.invocation is inv
    assert result.persona_id == "dev"
    assert result.output == "implementation done"
    assert result.model == "gpt-4o"
    assert result.usage == {"input": 100, "output": 50}


def test_persona_result_finished_at_is_utc():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    result = PersonaResult.from_response(
        invocation=inv,
        response=LLMResponse(text="x"),
    )
    assert result.finished_at.tzinfo == timezone.utc


def test_persona_result_finished_at_is_after_started_at():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    result = PersonaResult.from_response(
        invocation=inv,
        response=LLMResponse(text="x"),
    )
    assert result.finished_at >= inv.started_at


def test_persona_result_usage_defaults_to_empty_when_response_omits_it():
    inv = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    result = PersonaResult.from_response(
        invocation=inv,
        response=LLMResponse(text="x"),
    )
    assert result.usage == {}


# ---- InvocationContext ----


def test_invocation_context_constructs_with_empty_chain_and_metadata():
    ctx = InvocationContext(run_id="r-1", test_intent="test login")
    assert ctx.run_id == "r-1"
    assert ctx.test_intent == "test login"
    assert ctx.metadata == {}
    assert ctx.chain == ()


def test_invocation_context_append_adds_result_to_chain():
    ctx = InvocationContext(run_id="r-1", test_intent="x")
    inv = PersonaInvocation.build(
        persona_id="architect",
        run_id="r-1",
        user_prompt="p",
        system_prompt_hash="h",
    )
    result = PersonaResult.from_response(
        invocation=inv, response=LLMResponse(text="design")
    )
    new_ctx = ctx.append(result)
    assert new_ctx.chain == (result,)
    # Original context unchanged (functional update).
    assert ctx.chain == ()


def test_invocation_context_append_preserves_metadata_and_intent():
    ctx = InvocationContext(
        run_id="r-1",
        test_intent="check signup",
        metadata={"env": "dev"},
    )
    inv = PersonaInvocation.build(
        persona_id="sm",
        run_id="r-1",
        user_prompt="p",
        system_prompt_hash="h",
    )
    result = PersonaResult.from_response(
        invocation=inv, response=LLMResponse(text="story drafted")
    )
    new_ctx = ctx.append(result)
    assert new_ctx.run_id == "r-1"
    assert new_ctx.test_intent == "check signup"
    assert new_ctx.metadata == {"env": "dev"}


def test_invocation_context_chain_is_immutable_tuple():
    ctx = InvocationContext(run_id="r", test_intent="x")
    assert isinstance(ctx.chain, tuple)


def test_invocation_context_is_frozen():
    ctx = InvocationContext(run_id="r", test_intent="x")
    with pytest.raises(Exception):
        ctx.run_id = "other"  # type: ignore[misc]


# ---- edge: timestamps don't share state across invocations ----


def test_two_invocations_have_distinct_started_at_or_invocation_ids():
    inv1 = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    inv2 = PersonaInvocation.build(
        persona_id="dev",
        run_id="r",
        user_prompt="p",
        system_prompt_hash="h",
    )
    # Even if clock resolution collides, invocation_id never does.
    assert inv1.invocation_id != inv2.invocation_id
