"""Tests for Persona dataclass + PersonaError."""

from __future__ import annotations

import pytest

from agents._shared.harness.personas.types import Persona, PersonaError


# ---- happy path ----


def test_persona_constructs_with_all_fields():
    p = Persona(
        id="dev",
        system_prompt="# Dev persona\nYou implement code.",
        tools=("git_commit", "run_tests"),
        boundary=("no_remote_push",),
    )
    assert p.id == "dev"
    assert p.system_prompt.startswith("# Dev persona")
    assert p.tools == ("git_commit", "run_tests")
    assert p.boundary == ("no_remote_push",)


def test_persona_defaults_tools_and_boundary_to_empty():
    p = Persona(id="solo", system_prompt="hi")
    assert p.tools == ()
    assert p.boundary == ()


def test_persona_with_boundary_appends_extra():
    base = Persona(id="dev", system_prompt="x", boundary=("no_remote_push",))
    extended = base.with_boundary("no_pr_create", "no_mcp_management")
    assert extended.boundary == (
        "no_remote_push",
        "no_pr_create",
        "no_mcp_management",
    )
    assert extended.id == "dev"
    assert extended.system_prompt == "x"


def test_persona_with_boundary_returns_new_instance():
    base = Persona(id="dev", system_prompt="x")
    extended = base.with_boundary("no_remote_push")
    assert base is not extended
    assert base.boundary == ()
    assert extended.boundary == ("no_remote_push",)


# ---- error path ----


def test_persona_is_frozen_cannot_mutate_id():
    p = Persona(id="dev", system_prompt="x")
    with pytest.raises(Exception):
        p.id = "qa"  # type: ignore[misc]


def test_persona_is_frozen_cannot_mutate_boundary():
    p = Persona(id="dev", system_prompt="x", boundary=("no_remote_push",))
    with pytest.raises(Exception):
        p.boundary = ()  # type: ignore[misc]


def test_persona_error_is_exception_subclass():
    assert issubclass(PersonaError, Exception)
    err = PersonaError("boom")
    assert str(err) == "boom"


def test_persona_error_can_be_raised_and_caught():
    with pytest.raises(PersonaError, match="cannot load"):
        raise PersonaError("cannot load persona")


# ---- edge cases ----


def test_persona_with_empty_string_id_is_allowed():
    # Validation lives in registry, not the dataclass — types.py is dumb storage.
    p = Persona(id="", system_prompt="x")
    assert p.id == ""


def test_persona_with_empty_boundary_appended_yields_same_tuple_value():
    base = Persona(id="dev", system_prompt="x", boundary=("a",))
    extended = base.with_boundary()
    assert extended.boundary == ("a",)


def test_persona_equality_is_value_based():
    p1 = Persona(id="dev", system_prompt="x", boundary=("a",))
    p2 = Persona(id="dev", system_prompt="x", boundary=("a",))
    assert p1 == p2
    assert hash(p1) == hash(p2)


def test_persona_inequality_when_boundary_differs():
    p1 = Persona(id="dev", system_prompt="x", boundary=("a",))
    p2 = Persona(id="dev", system_prompt="x", boundary=("b",))
    assert p1 != p2
