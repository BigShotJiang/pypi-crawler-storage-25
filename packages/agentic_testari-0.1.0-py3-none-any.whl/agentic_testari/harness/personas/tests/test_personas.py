"""Tests for persona registry, boundaries, and pipeline.

Uses an in-process FakeLLM so tests run offline, fast, and deterministic.
"""

from __future__ import annotations

import asyncio
from typing import Any, Mapping

import pytest

from agents._shared.harness.personas import (
    BoundaryViolation,
    InvocationContext,
    LLMClient,
    LLMResponse,
    Persona,
    PersonaRegistry,
    Pipeline,
    PipelineRun,
    default_boundaries,
)


# ---- FakeLLM ----


class FakeLLM:
    """Records every call; returns deterministic per-persona output."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> LLMResponse:
        meta = dict(metadata or {})
        self.calls.append(
            {
                "system_prompt_excerpt": system_prompt[:50],
                "user_prompt": user_prompt,
                "metadata": meta,
            }
        )
        persona_id = meta.get("persona", "unknown")
        return LLMResponse(
            text=f"[{persona_id}] decision summary line 1\nmore detail",
            model="fake-model",
            usage={"input": 10, "output": 5},
        )


def test_fake_llm_satisfies_protocol():
    """FakeLLM is a structural match for LLMClient."""
    assert isinstance(FakeLLM(), LLMClient)


# ---- Registry + boundaries ----


def test_registry_loads_known_persona():
    reg = PersonaRegistry()
    persona = reg.get("dev")
    assert isinstance(persona, Persona)
    assert persona.id == "dev"
    assert persona.system_prompt
    assert "no_remote_push" in persona.boundary


def test_registry_caches_instance():
    reg = PersonaRegistry()
    a = reg.get("dev")
    b = reg.get("dev")
    assert a is b


def test_devops_has_no_default_boundary():
    """@devops is the ONLY persona allowed to push / open PRs."""
    assert default_boundaries("devops") == ()


def test_unknown_persona_gets_strict_default():
    boundary = default_boundaries("not-a-real-persona")
    assert "no_remote_push" in boundary
    assert "no_pr_create" in boundary


def test_system_prompt_hash_stable():
    reg = PersonaRegistry()
    h1 = reg.system_prompt_hash("dev")
    h2 = reg.system_prompt_hash("dev")
    assert h1 == h2
    assert len(h1) == 16


def test_with_boundary_appends():
    p = Persona(id="x", system_prompt="...", boundary=("a",))
    p2 = p.with_boundary("b", "c")
    assert p2.boundary == ("a", "b", "c")
    # Original is unchanged (frozen).
    assert p.boundary == ("a",)


def test_boundary_violation_message():
    err = BoundaryViolation("dev", "no_remote_push", "git push")
    assert "dev" in str(err)
    assert "no_remote_push" in str(err)
    assert "git push" in str(err)


# ---- Pipeline ----


def test_pipeline_default_has_canonical_order():
    p = Pipeline.default()
    assert p.persona_ids == ("architect", "sm", "po", "dev", "qa")


def test_pipeline_rejects_empty_personas():
    from agents._shared.harness.personas.types import PersonaError

    with pytest.raises(PersonaError):
        Pipeline(personas=())


@pytest.mark.asyncio
async def test_pipeline_runs_all_stages_in_order():
    llm = FakeLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(
        run_id="run-1",
        test_intent="Verify login flow accepts valid credentials",
        llm=llm,
    )

    assert isinstance(run, PipelineRun)
    assert run.run_id == "run-1"
    # All 5 personas were called, in order.
    assert len(run.results) == 5
    assert [r.persona_id for r in run.results] == [
        "architect",
        "sm",
        "po",
        "dev",
        "qa",
    ]
    # FakeLLM saw 5 calls.
    assert len(llm.calls) == 5


@pytest.mark.asyncio
async def test_pipeline_passes_chain_to_downstream():
    llm = FakeLLM()
    pipeline = Pipeline.default()
    await pipeline.run(
        run_id="r", test_intent="test something", llm=llm
    )
    # The 5th call (qa) must mention all 4 upstream personas in its prompt.
    qa_call = llm.calls[-1]
    user_prompt = qa_call["user_prompt"]
    for upstream in ("architect", "sm", "po", "dev"):
        assert upstream in user_prompt
    assert "[YOUR TURN — qa]" in user_prompt


@pytest.mark.asyncio
async def test_pipeline_first_stage_has_no_upstream_chain():
    llm = FakeLLM()
    pipeline = Pipeline.default()
    await pipeline.run(run_id="r", test_intent="x", llm=llm)
    arch_call = llm.calls[0]
    # No upstream block when chain is empty.
    assert "[UPSTREAM CHAIN]" not in arch_call["user_prompt"]
    assert "[TEST INTENT]" in arch_call["user_prompt"]


@pytest.mark.asyncio
async def test_pipeline_run_final_returns_last_result():
    llm = FakeLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(run_id="r", test_intent="x", llm=llm)
    assert run.final.persona_id == "qa"


@pytest.mark.asyncio
async def test_pipeline_uses_correct_system_prompt_per_persona():
    """Each call must carry the persona's own system prompt — no cross-talk."""
    llm = FakeLLM()
    pipeline = Pipeline(personas=("dev", "qa"))
    await pipeline.run(run_id="r", test_intent="x", llm=llm)

    reg = PersonaRegistry()
    dev_excerpt = reg.get("dev").system_prompt[:50]
    qa_excerpt = reg.get("qa").system_prompt[:50]
    assert llm.calls[0]["system_prompt_excerpt"] == dev_excerpt
    assert llm.calls[1]["system_prompt_excerpt"] == qa_excerpt
    assert dev_excerpt != qa_excerpt


@pytest.mark.asyncio
async def test_pipeline_records_unique_invocation_ids():
    llm = FakeLLM()
    pipeline = Pipeline.default()
    run = await pipeline.run(run_id="r", test_intent="x", llm=llm)
    inv_ids = {r.invocation.invocation_id for r in run.results}
    assert len(inv_ids) == 5  # all unique


@pytest.mark.asyncio
async def test_pipeline_records_system_prompt_hash():
    llm = FakeLLM()
    pipeline = Pipeline(personas=("dev",))
    run = await pipeline.run(run_id="r", test_intent="x", llm=llm)
    h = run.results[0].invocation.system_prompt_hash
    assert h
    assert len(h) == 16


# ---- Context append ----


def test_context_append_is_immutable():
    from agents._shared.harness.personas.invocation import (
        InvocationContext,
        PersonaInvocation,
        PersonaResult,
    )
    from datetime import datetime, timezone

    inv = PersonaInvocation.build(
        persona_id="dev", run_id="r", user_prompt="p", system_prompt_hash="h"
    )
    result = PersonaResult(
        invocation=inv,
        persona_id="dev",
        output="o",
        finished_at=datetime.now(timezone.utc),
    )
    ctx = InvocationContext(run_id="r", test_intent="t")
    ctx2 = ctx.append(result)
    assert ctx.chain == ()
    assert ctx2.chain == (result,)


# ---- Sanity: registry lists at least 7 ----


def test_registry_lists_canonical_personas():
    reg = PersonaRegistry()
    ids = reg.list_ids()
    for must_have in ("dev", "qa", "architect", "pm", "po", "sm", "devops"):
        assert must_have in ids
