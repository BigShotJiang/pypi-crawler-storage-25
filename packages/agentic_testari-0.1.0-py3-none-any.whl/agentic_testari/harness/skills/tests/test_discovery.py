"""Tests for SkillRegistry — frontmatter parsing + bundle lookups."""

from __future__ import annotations

import pytest

from agents._shared.harness.skills import (
    SkillNotFoundError,
    SkillRegistry,
)
from agents._shared.harness.skills.discovery import _parse


@pytest.fixture(scope="module")
def registry() -> SkillRegistry:
    return SkillRegistry()


def test_lists_real_bundled_skills(registry: SkillRegistry):
    ids = registry.list_ids()
    assert "aiox-maestro" in ids
    assert "excalidraw-diagram" in ids
    # At least 5 skills should ship in the bundle.
    assert len(ids) >= 5


def test_loads_aiox_maestro_with_frontmatter(registry: SkillRegistry):
    skill = registry.get("aiox-maestro")
    assert skill.id == "aiox-maestro"
    assert skill.name == "aiox-maestro"
    # Description survives multiline YAML.
    assert "AIOX Maestro" in skill.description
    assert "Maestro" in skill.body


def test_loads_excalidraw_with_frontmatter(registry: SkillRegistry):
    skill = registry.get("excalidraw-diagram")
    assert skill.is_documented
    assert "diagram" in skill.description.lower()


def test_get_optional_returns_none_for_unknown(registry: SkillRegistry):
    assert registry.get_optional("not-a-real-skill") is None


def test_get_unknown_raises(registry: SkillRegistry):
    with pytest.raises(SkillNotFoundError) as exc_info:
        registry.get("not-a-real-skill")
    assert "not-a-real-skill" in str(exc_info.value)
    assert exc_info.value.available  # available list populated


def test_caches_skill_instance(registry: SkillRegistry):
    a = registry.get("aiox-maestro")
    b = registry.get("aiox-maestro")
    assert a is b


def test_reset_clears_cache(registry: SkillRegistry):
    skill_id = "aiox-maestro"
    a = registry.get(skill_id)
    registry.reset()
    b = registry.get(skill_id)
    # Same content, different instance.
    assert a == b
    assert a is not b


# ---- _parse direct tests ----


def test_parse_handles_skill_without_frontmatter():
    skill = _parse("noskill", "# Just a heading\nbody text")
    assert skill.id == "noskill"
    assert skill.name == "noskill"
    assert skill.description == ""
    assert "Just a heading" in skill.body


def test_parse_handles_malformed_frontmatter():
    """Garbage YAML between fences must not crash; falls back to defaults."""
    src = "---\n: : [malformed yaml\n---\n# body"
    skill = _parse("x", src)
    assert skill.id == "x"
    # Body still extracted (or kept as full source on parse error).
    assert skill.body  # non-empty


def test_parse_extracts_simple_frontmatter():
    src = "---\nname: my-skill\ndescription: A short skill.\n---\n\n# Body\n"
    skill = _parse("my-skill", src)
    assert skill.name == "my-skill"
    assert skill.description == "A short skill."
    assert "# Body" in skill.body


def test_parse_strips_description_whitespace():
    src = "---\nname: x\ndescription: '  surrounded  '\n---\nbody"
    skill = _parse("x", src)
    assert skill.description == "surrounded"
