"""Tests for skill triggers — context defaults, matching, default trigger set."""

from __future__ import annotations

from agents._shared.harness.skills.triggers import (
    SkillContext,
    SkillTrigger,
    default_triggers,
)


# ---- SkillContext ----


def test_context_constructs_with_defaults():
    ctx = SkillContext(run_id="r-1")
    assert ctx.run_id == "r-1"
    assert ctx.fail_count == 0
    assert ctx.steps_count == 0
    assert ctx.similar_failure_count_30d == 0
    assert ctx.review_phase is False
    assert ctx.token_budget_pct == 0.0
    assert ctx.metadata == {}


def test_context_constructs_with_all_fields():
    ctx = SkillContext(
        run_id="r-1",
        fail_count=10,
        steps_count=20,
        similar_failure_count_30d=5,
        review_phase=True,
        token_budget_pct=0.95,
        metadata={"env": "dev"},
    )
    assert ctx.fail_count == 10
    assert ctx.steps_count == 20
    assert ctx.similar_failure_count_30d == 5
    assert ctx.review_phase is True
    assert ctx.token_budget_pct == 0.95
    assert ctx.metadata == {"env": "dev"}


def test_context_is_frozen():
    ctx = SkillContext(run_id="r")
    try:
        ctx.run_id = "other"  # type: ignore[misc]
        raised = False
    except Exception:
        raised = True
    assert raised, "SkillContext should be frozen"


# ---- SkillTrigger.matches ----


def test_trigger_matches_when_predicate_true():
    trg = SkillTrigger(
        skill_id="x",
        predicate=lambda c: c.fail_count > 3,
        reason="test",
    )
    assert trg.matches(SkillContext(run_id="r", fail_count=10)) is True


def test_trigger_does_not_match_when_predicate_false():
    trg = SkillTrigger(
        skill_id="x",
        predicate=lambda c: c.fail_count > 3,
        reason="test",
    )
    assert trg.matches(SkillContext(run_id="r", fail_count=2)) is False


def test_trigger_predicate_truthy_value_coerced_to_bool():
    # Non-bool truthy returns must coerce to bool.
    trg = SkillTrigger(skill_id="x", predicate=lambda c: 1, reason="t")
    assert trg.matches(SkillContext(run_id="r")) is True


def test_trigger_predicate_falsy_value_coerced_to_bool():
    trg = SkillTrigger(skill_id="x", predicate=lambda c: 0, reason="t")
    assert trg.matches(SkillContext(run_id="r")) is False


# ---- default_triggers — built-in set ----


def test_default_triggers_returns_5_canonical_triggers():
    triggers = default_triggers()
    assert len(triggers) == 5
    skill_ids = {t.skill_id for t in triggers}
    assert skill_ids == {
        "context-surgeon",
        "excalidraw-diagram",
        "humanize-message",
        "simplify",
        "synapse",
    }


def test_default_triggers_returned_sorted_by_skill_id():
    triggers = default_triggers()
    ids = [t.skill_id for t in triggers]
    assert ids == sorted(ids)


def test_default_triggers_returns_tuple_not_list():
    # Mutability would let downstream code accidentally weaken triggers.
    assert isinstance(default_triggers(), tuple)


def test_default_triggers_are_idempotent():
    a = default_triggers()
    b = default_triggers()
    assert [t.skill_id for t in a] == [t.skill_id for t in b]


# ---- specific built-in trigger semantics ----


def test_humanize_message_fires_when_fail_count_gt_5():
    triggers = {t.skill_id: t for t in default_triggers()}
    hm = triggers["humanize-message"]
    assert hm.matches(SkillContext(run_id="r", fail_count=6)) is True
    assert hm.matches(SkillContext(run_id="r", fail_count=5)) is False
    assert hm.matches(SkillContext(run_id="r", fail_count=0)) is False


def test_excalidraw_fires_when_steps_count_gt_8():
    triggers = {t.skill_id: t for t in default_triggers()}
    ex = triggers["excalidraw-diagram"]
    assert ex.matches(SkillContext(run_id="r", steps_count=9)) is True
    assert ex.matches(SkillContext(run_id="r", steps_count=8)) is False


def test_synapse_fires_when_similar_failures_gt_3():
    triggers = {t.skill_id: t for t in default_triggers()}
    syn = triggers["synapse"]
    assert syn.matches(SkillContext(run_id="r", similar_failure_count_30d=4)) is True
    assert syn.matches(SkillContext(run_id="r", similar_failure_count_30d=3)) is False


def test_simplify_fires_only_in_review_phase():
    triggers = {t.skill_id: t for t in default_triggers()}
    simp = triggers["simplify"]
    assert simp.matches(SkillContext(run_id="r", review_phase=True)) is True
    assert simp.matches(SkillContext(run_id="r", review_phase=False)) is False


def test_context_surgeon_fires_at_or_above_85_pct_budget():
    triggers = {t.skill_id: t for t in default_triggers()}
    cs = triggers["context-surgeon"]
    assert cs.matches(SkillContext(run_id="r", token_budget_pct=0.85)) is True
    assert cs.matches(SkillContext(run_id="r", token_budget_pct=0.95)) is True
    assert cs.matches(SkillContext(run_id="r", token_budget_pct=0.84)) is False


def test_default_triggers_have_human_readable_reasons():
    for trg in default_triggers():
        assert trg.reason
        assert len(trg.reason) > 5  # not just a placeholder


def test_no_trigger_fires_on_default_context():
    ctx = SkillContext(run_id="r")
    fired = [t for t in default_triggers() if t.matches(ctx)]
    assert fired == []  # default ctx must be quiet
