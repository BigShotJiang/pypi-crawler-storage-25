"""Tests for SkillDispatcher + triggers — Mode C auto-fire behaviour."""

from __future__ import annotations

from typing import Optional

import pytest

from agents._shared.harness.skills import (
    Skill,
    SkillContext,
    SkillDispatcher,
    SkillNotFoundError,
    SkillRegistry,
    SkillTrigger,
    default_triggers,
)


# ---- fake registry ----


class FakeRegistry:
    """In-memory registry for offline trigger tests."""

    def __init__(self, skills: dict[str, Skill]):
        self._skills = dict(skills)

    def list_ids(self) -> list[str]:
        return sorted(self._skills.keys())

    def get(self, skill_id: str) -> Skill:
        if skill_id not in self._skills:
            raise SkillNotFoundError(
                skill_id, available=tuple(self.list_ids())
            )
        return self._skills[skill_id]

    def get_optional(self, skill_id: str) -> Optional[Skill]:
        return self._skills.get(skill_id)


def _fake_skill(skill_id: str) -> Skill:
    return Skill(
        id=skill_id,
        name=skill_id,
        description=f"{skill_id} description",
        body=f"# {skill_id}\nbody",
    )


def _full_registry() -> FakeRegistry:
    """Stub registry that has all 5 trigger-bound skills."""
    return FakeRegistry(
        {
            "humanize-message": _fake_skill("humanize-message"),
            "excalidraw-diagram": _fake_skill("excalidraw-diagram"),
            "synapse": _fake_skill("synapse"),
            "simplify": _fake_skill("simplify"),
            "context-surgeon": _fake_skill("context-surgeon"),
            "extra-skill": _fake_skill("extra-skill"),
        }
    )


# ---- default trigger set ----


def test_default_triggers_returns_5():
    triggers = default_triggers()
    skill_ids = sorted(t.skill_id for t in triggers)
    assert skill_ids == [
        "context-surgeon",
        "excalidraw-diagram",
        "humanize-message",
        "simplify",
        "synapse",
    ]


# ---- auto-fire behaviour ----


def test_dispatch_fires_humanize_on_high_fail_count():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", fail_count=7))
    skill_ids = [i.skill_id for i in invs]
    assert "humanize-message" in skill_ids


def test_dispatch_silent_below_fail_threshold():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", fail_count=5))
    assert all(i.skill_id != "humanize-message" for i in invs)


def test_dispatch_fires_excalidraw_on_high_steps():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", steps_count=10))
    assert any(i.skill_id == "excalidraw-diagram" for i in invs)


def test_dispatch_fires_synapse_on_repeat_failures():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(
        SkillContext(run_id="r", similar_failure_count_30d=4)
    )
    assert any(i.skill_id == "synapse" for i in invs)


def test_dispatch_fires_simplify_in_review_phase():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", review_phase=True))
    assert any(i.skill_id == "simplify" for i in invs)


def test_dispatch_fires_context_surgeon_high_token_budget():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", token_budget_pct=0.92))
    assert any(i.skill_id == "context-surgeon" for i in invs)


def test_dispatch_fires_multiple_when_multiple_match():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(
        SkillContext(
            run_id="r",
            fail_count=10,
            steps_count=20,
            review_phase=True,
        )
    )
    skill_ids = {i.skill_id for i in invs}
    assert "humanize-message" in skill_ids
    assert "excalidraw-diagram" in skill_ids
    assert "simplify" in skill_ids


def test_dispatch_silent_on_clean_context():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r"))
    assert invs == ()


def test_dispatch_skips_unbundled_skills():
    """If a triggered skill is not in the bundle, the dispatcher skips."""
    registry = FakeRegistry(
        {"simplify": _fake_skill("simplify")}
    )  # no humanize-message
    dispatcher = SkillDispatcher(registry=registry)
    invs = dispatcher.dispatch(
        SkillContext(run_id="r", fail_count=10, review_phase=True)
    )
    skill_ids = {i.skill_id for i in invs}
    assert "humanize-message" not in skill_ids
    assert "simplify" in skill_ids


# ---- forced (manual) override ----


def test_force_skill_id_appended():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(
        SkillContext(run_id="r"), force_skill_ids=("extra-skill",)
    )
    assert len(invs) == 1
    assert invs[0].skill_id == "extra-skill"
    assert invs[0].forced is True
    assert "manual override" in invs[0].reason


def test_force_skill_unknown_raises():
    dispatcher = SkillDispatcher(registry=_full_registry())
    with pytest.raises(SkillNotFoundError):
        dispatcher.dispatch(
            SkillContext(run_id="r"), force_skill_ids=("not-a-skill",)
        )


def test_forced_skill_dedupes_with_auto():
    """If force_skill_ids overlaps with auto-fire, no duplicate invocation."""
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(
        SkillContext(run_id="r", review_phase=True),
        force_skill_ids=("simplify",),
    )
    skill_ids = [i.skill_id for i in invs]
    assert skill_ids.count("simplify") == 1
    # Auto-fire wins (forced=False).
    assert next(i for i in invs if i.skill_id == "simplify").forced is False


# ---- invocation record ----


def test_invocation_has_unique_id():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(
        SkillContext(run_id="r", fail_count=10, steps_count=20)
    )
    ids = {i.invocation_id for i in invs}
    assert len(ids) == 2  # all unique


def test_invocation_records_reason():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", fail_count=10))
    assert invs[0].reason == "fail_count > 5"


def test_invocation_fired_at_is_utc():
    dispatcher = SkillDispatcher(registry=_full_registry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", review_phase=True))
    assert invs[0].fired_at.tzinfo is not None


# ---- custom triggers ----


def test_custom_triggers_replace_default():
    registry = FakeRegistry({"simplify": _fake_skill("simplify")})
    custom = (
        SkillTrigger(
            skill_id="simplify",
            predicate=lambda ctx: ctx.fail_count >= 1,  # very loose
            reason="custom",
        ),
    )
    dispatcher = SkillDispatcher(registry=registry, triggers=custom)
    invs = dispatcher.dispatch(SkillContext(run_id="r", fail_count=1))
    assert len(invs) == 1
    assert invs[0].reason == "custom"


# ---- listing ----


def test_list_skills_returns_registry_ids():
    dispatcher = SkillDispatcher(registry=_full_registry())
    ids = dispatcher.list_skills()
    assert "extra-skill" in ids


# ---- real registry sanity ----


def test_real_registry_dispatch_smoke():
    """Smoke test against the actual bundle — no exceptions."""
    dispatcher = SkillDispatcher.default(registry=SkillRegistry())
    # `excalidraw-diagram` and `context-surgeon` both ship in `.claude/skills/`
    # and are bound to triggers; high steps_count must fire excalidraw.
    invs = dispatcher.dispatch(SkillContext(run_id="r", steps_count=20))
    assert any(i.skill_id == "excalidraw-diagram" for i in invs)


def test_real_registry_unbundled_skills_skipped_silently():
    """`simplify` is a Claude Code built-in, not in the project bundle.

    Even when its trigger fires, the dispatcher must skip silently rather
    than raise — bundle slim-downs should never crash callers.
    """
    dispatcher = SkillDispatcher.default(registry=SkillRegistry())
    invs = dispatcher.dispatch(SkillContext(run_id="r", review_phase=True))
    # No exception. `simplify` may or may not appear depending on bundle.
    assert all(isinstance(i.skill_id, str) for i in invs)
