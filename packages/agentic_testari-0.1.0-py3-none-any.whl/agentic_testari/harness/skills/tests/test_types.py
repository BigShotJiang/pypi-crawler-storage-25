"""Tests for Skill dataclass + error types."""

from __future__ import annotations

import pytest

from agents._shared.harness.skills.types import (
    Skill,
    SkillError,
    SkillNotFoundError,
)


# ---- Skill dataclass ----


def test_skill_constructs_with_all_fields():
    s = Skill(
        id="my-skill",
        name="My Skill",
        description="A short description.",
        body="# Body\nFull markdown.",
    )
    assert s.id == "my-skill"
    assert s.name == "My Skill"
    assert s.description == "A short description."
    assert "Body" in s.body


def test_skill_is_frozen_cannot_mutate_id():
    s = Skill(id="x", name="X", description="d", body="b")
    with pytest.raises(Exception):
        s.id = "y"  # type: ignore[misc]


def test_skill_is_frozen_cannot_mutate_description():
    s = Skill(id="x", name="X", description="d", body="b")
    with pytest.raises(Exception):
        s.description = "other"  # type: ignore[misc]


def test_skill_equality_is_value_based():
    a = Skill(id="x", name="X", description="d", body="b")
    b = Skill(id="x", name="X", description="d", body="b")
    assert a == b
    assert hash(a) == hash(b)


def test_skill_inequality_when_id_differs():
    a = Skill(id="x", name="X", description="d", body="b")
    b = Skill(id="y", name="X", description="d", body="b")
    assert a != b


# ---- is_documented property ----


def test_skill_is_documented_true_when_description_set():
    s = Skill(id="x", name="X", description="hello", body="b")
    assert s.is_documented is True


def test_skill_is_documented_false_when_description_empty():
    s = Skill(id="x", name="X", description="", body="b")
    assert s.is_documented is False


def test_skill_is_documented_false_when_description_only_whitespace():
    s = Skill(id="x", name="X", description="   \n\t ", body="b")
    assert s.is_documented is False


# ---- SkillError ----


def test_skill_error_is_exception_subclass():
    assert issubclass(SkillError, Exception)


def test_skill_error_can_be_raised_and_caught():
    with pytest.raises(SkillError, match="boom"):
        raise SkillError("boom")


# ---- SkillNotFoundError ----


def test_skill_not_found_error_subclasses_skill_error():
    assert issubclass(SkillNotFoundError, SkillError)


def test_skill_not_found_message_includes_skill_id():
    err = SkillNotFoundError("missing-skill")
    assert "missing-skill" in str(err)
    assert err.skill_id == "missing-skill"


def test_skill_not_found_message_lists_first_5_available():
    err = SkillNotFoundError(
        "x",
        available=("a", "b", "c", "d", "e", "f", "g"),
    )
    msg = str(err)
    assert "a, b, c, d, e" in msg
    assert "+2 more" in msg


def test_skill_not_found_message_no_more_when_5_or_fewer():
    err = SkillNotFoundError("x", available=("a", "b", "c"))
    msg = str(err)
    assert "a, b, c" in msg
    assert "more" not in msg


def test_skill_not_found_message_omits_available_when_empty():
    err = SkillNotFoundError("x", available=())
    msg = str(err)
    assert "Available" not in msg
    assert "x" in msg


def test_skill_not_found_carries_available_tuple():
    err = SkillNotFoundError("x", available=("a", "b"))
    assert err.available == ("a", "b")


# ---- edge ----


def test_skill_with_empty_body_is_allowed():
    s = Skill(id="x", name="X", description="d", body="")
    assert s.body == ""
