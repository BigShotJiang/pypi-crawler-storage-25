"""Skill discovery — load skills from the bundle.

Reads `.claude/skills/{id}/SKILL.md` via the N.1 HarnessLoader, parses
the YAML frontmatter (`---` delimiters) for `name` + `description`, and
caches Skill instances keyed by id.

Skills without frontmatter fall back to id-as-name; they're still usable.
"""

from __future__ import annotations

from typing import Optional

import yaml

from agents._shared.harness.loader import HarnessLoader, get_harness
from agents._shared.harness.skills.types import (
    Skill,
    SkillError,
    SkillNotFoundError,
)


class SkillRegistry:
    """Cached lookup of bundled skills."""

    def __init__(self, loader: Optional[HarnessLoader] = None):
        self._loader = loader or get_harness()
        self._cache: dict[str, Skill] = {}

    def list_ids(self) -> list[str]:
        return self._loader.list_skills()

    def get(self, skill_id: str) -> Skill:
        if skill_id not in self._cache:
            try:
                source = self._loader.load_skill(skill_id)
            except Exception as exc:
                raise SkillNotFoundError(
                    skill_id, available=tuple(self.list_ids())
                ) from exc
            self._cache[skill_id] = _parse(skill_id, source)
        return self._cache[skill_id]

    def get_optional(self, skill_id: str) -> Optional[Skill]:
        try:
            return self.get(skill_id)
        except SkillNotFoundError:
            return None

    def reset(self) -> None:
        self._cache.clear()


def _parse(skill_id: str, source: str) -> Skill:
    """Parse SKILL.md text into a Skill record.

    Frontmatter format:

        ---
        name: my-skill
        description: |
          Multi-line description...
        ---

        # My Skill
        ...body...

    If frontmatter is absent or malformed, fall back to id-as-name with
    empty description and the full source as body.
    """
    name = skill_id
    description = ""
    body = source

    if source.startswith("---"):
        # Find the closing fence.
        rest = source[3:]
        end = rest.find("\n---")
        if end != -1:
            front_block = rest[:end]
            body = rest[end + len("\n---"):].lstrip("\n")
            try:
                meta = yaml.safe_load(front_block) or {}
                if isinstance(meta, dict):
                    name = str(meta.get("name", skill_id))
                    description = str(meta.get("description", "")).strip()
            except yaml.YAMLError:
                # Malformed frontmatter — keep defaults.
                pass

    return Skill(id=skill_id, name=name, description=description, body=body)
