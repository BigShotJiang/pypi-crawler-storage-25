"""Built-in skill triggers (Mode C — auto-fire when context matches).

Per AIDR-022 (locked 2026-04-27), the harness invokes skills automatically
when context triggers fire. Pro tier unlocks manual override; the
free/default tier always uses auto-fire.

Trigger map:

    humanize-message    →  fail_count > 5
    excalidraw-diagram  →  steps_count > 8
    synapse             →  similar_failure_count_30d > 3
    simplify            →  review_phase == True
    context-surgeon     →  token_budget_pct >= 0.85

A trigger is a callable `(SkillContext) -> bool`. Keep them pure functions
so a mock context is trivial. The dispatcher composes them, doesn't own
them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Mapping


@dataclass(frozen=True)
class SkillContext:
    """Inputs every trigger may inspect.

    Fields are deliberately flat. Triggers read what they care about;
    absent fields default to safe values that never fire.
    """

    run_id: str
    fail_count: int = 0
    steps_count: int = 0
    similar_failure_count_30d: int = 0
    review_phase: bool = False
    token_budget_pct: float = 0.0
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class SkillTrigger:
    """Declarative trigger binding skill_id → predicate + reason template."""

    skill_id: str
    predicate: Callable[[SkillContext], bool]
    reason: str

    def matches(self, ctx: SkillContext) -> bool:
        return bool(self.predicate(ctx))


# ---- built-in predicates ----


def _fail_count_gt_5(ctx: SkillContext) -> bool:
    return ctx.fail_count > 5


def _steps_count_gt_8(ctx: SkillContext) -> bool:
    return ctx.steps_count > 8


def _similar_failures_gt_3(ctx: SkillContext) -> bool:
    return ctx.similar_failure_count_30d > 3


def _is_review_phase(ctx: SkillContext) -> bool:
    return ctx.review_phase is True


def _token_budget_high(ctx: SkillContext) -> bool:
    return ctx.token_budget_pct >= 0.85


def default_triggers() -> tuple[SkillTrigger, ...]:
    """Return the canonical trigger set (frozen, sorted by skill_id)."""
    return (
        SkillTrigger(
            skill_id="context-surgeon",
            predicate=_token_budget_high,
            reason="token_budget_pct >= 0.85",
        ),
        SkillTrigger(
            skill_id="excalidraw-diagram",
            predicate=_steps_count_gt_8,
            reason="steps_count > 8",
        ),
        SkillTrigger(
            skill_id="humanize-message",
            predicate=_fail_count_gt_5,
            reason="fail_count > 5",
        ),
        SkillTrigger(
            skill_id="simplify",
            predicate=_is_review_phase,
            reason="review_phase=True",
        ),
        SkillTrigger(
            skill_id="synapse",
            predicate=_similar_failures_gt_3,
            reason="similar_failure_count_30d > 3",
        ),
    )
