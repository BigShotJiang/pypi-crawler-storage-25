"""Skills invocation (EPIC N.6).

Discovers `.claude/skills/*/SKILL.md` (via N.1 HarnessLoader) and exposes
them as runtime tools the harness can invoke. Skill activation follows
**Mode C** (always-all relevant skills run automatically — locked by
AIDR-022 / 2026-04-27): the dispatcher inspects a SkillContext and
auto-fires every skill whose trigger matches.

Manual override (`--skill=<name>`) is Pro-tier; for the harness layer
this is a `force_skill_ids=` argument on dispatch.

Built-in trigger map (auto-fire conditions):

    humanize-message      → fail_count > 5
    excalidraw-diagram    → steps_count > 8
    synapse               → similar_failure_count_30d > 3
    simplify              → review_phase=True (always run during QA)
    context-surgeon       → token_budget_pct >= 0.85

Skills not in the trigger map are discoverable but not auto-fired.

Usage:
    from agents._shared.harness.skills import (
        SkillRegistry, SkillDispatcher, SkillContext,
    )

    registry = SkillRegistry()      # loads from bundle
    dispatcher = SkillDispatcher.default(registry=registry)
    invocations = dispatcher.dispatch(SkillContext(
        run_id="r-1",
        fail_count=7,                # → triggers humanize-message
        steps_count=10,              # → triggers excalidraw-diagram
    ))
    # invocations is a tuple[SkillInvocation, ...] in fire order.
"""

from agents._shared.harness.skills.dispatcher import (
    SkillDispatcher,
    SkillInvocation,
)
from agents._shared.harness.skills.discovery import (
    SkillRegistry,
)
from agents._shared.harness.skills.triggers import (
    SkillContext,
    SkillTrigger,
    default_triggers,
)
from agents._shared.harness.skills.types import (
    Skill,
    SkillError,
    SkillNotFoundError,
)

__all__ = [
    "Skill",
    "SkillContext",
    "SkillTrigger",
    "SkillRegistry",
    "SkillDispatcher",
    "SkillInvocation",
    "SkillError",
    "SkillNotFoundError",
    "default_triggers",
]

__version__ = "1.0.0"
