"""Skills types + errors."""

from __future__ import annotations

from dataclasses import dataclass


class SkillError(Exception):
    """Base error for skill operations."""


class SkillNotFoundError(SkillError):
    """Raised when a requested skill id is not in the bundle."""

    def __init__(self, skill_id: str, available: tuple[str, ...] = ()):
        self.skill_id = skill_id
        self.available = available
        msg = f"Skill {skill_id!r} not found in bundle."
        if available:
            preview = ", ".join(available[:5])
            more = f" (+{len(available) - 5} more)" if len(available) > 5 else ""
            msg += f" Available: {preview}{more}"
        super().__init__(msg)


@dataclass(frozen=True)
class Skill:
    """A bundled skill (`.claude/skills/{id}/SKILL.md`)."""

    id: str
    name: str
    description: str
    body: str  # full markdown body (excluding frontmatter)

    @property
    def is_documented(self) -> bool:
        return bool(self.description.strip())
