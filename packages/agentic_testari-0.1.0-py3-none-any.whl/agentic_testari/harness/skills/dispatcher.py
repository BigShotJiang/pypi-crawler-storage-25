"""SkillDispatcher — fire skills whose triggers match the context.

Mode C activation (per AIDR-022): every trigger evaluates against the
context; matching skills auto-fire in deterministic order. Skills not
present in the bundle are skipped silently (so a future bundle slim-down
doesn't crash callers).

`force_skill_ids` lets callers (Pro tier `--skill=<name>`) inject
manual invocations. These are appended AFTER auto-triggered ones so the
audit log shows the natural order.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable, Optional, Sequence
from uuid import uuid4

from agents._shared.harness.skills.discovery import SkillRegistry
from agents._shared.harness.skills.triggers import (
    SkillContext,
    SkillTrigger,
    default_triggers,
)
from agents._shared.harness.skills.types import (
    Skill,
    SkillNotFoundError,
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class SkillInvocation:
    """A planned skill invocation — what would fire given a context.

    Returned by SkillDispatcher.dispatch(); the harness consumes these
    and actually drives the skill body. Audit-friendly.
    """

    invocation_id: str
    skill_id: str
    skill_name: str
    fired_at: datetime
    reason: str
    forced: bool = False
    metadata: dict = field(default_factory=dict)

    @classmethod
    def build(
        cls,
        *,
        skill: Skill,
        reason: str,
        forced: bool = False,
        metadata: Optional[dict] = None,
    ) -> "SkillInvocation":
        return cls(
            invocation_id=f"sk-{uuid4().hex[:12]}",
            skill_id=skill.id,
            skill_name=skill.name,
            fired_at=_utc_now(),
            reason=reason,
            forced=forced,
            metadata=dict(metadata or {}),
        )


class SkillDispatcher:
    """Fires bundled skills when their triggers match the context."""

    def __init__(
        self,
        *,
        registry: Optional[SkillRegistry] = None,
        triggers: Optional[Iterable[SkillTrigger]] = None,
    ):
        self._registry = registry or SkillRegistry()
        self._triggers: tuple[SkillTrigger, ...] = (
            tuple(triggers) if triggers is not None else default_triggers()
        )

    @classmethod
    def default(
        cls, *, registry: Optional[SkillRegistry] = None
    ) -> "SkillDispatcher":
        return cls(registry=registry)

    @property
    def triggers(self) -> tuple[SkillTrigger, ...]:
        return self._triggers

    def dispatch(
        self,
        ctx: SkillContext,
        *,
        force_skill_ids: Sequence[str] = (),
    ) -> tuple[SkillInvocation, ...]:
        """Return invocations that would fire for `ctx` + any forced skills."""
        invocations: list[SkillInvocation] = []
        seen: set[str] = set()

        for trigger in self._triggers:
            if not trigger.matches(ctx):
                continue
            skill = self._registry.get_optional(trigger.skill_id)
            if skill is None:
                # Skill not bundled — skip silently. Discovery might add it
                # later via M.4 wheel updates.
                continue
            if skill.id in seen:
                continue
            invocations.append(
                SkillInvocation.build(
                    skill=skill, reason=trigger.reason, forced=False
                )
            )
            seen.add(skill.id)

        for skill_id in force_skill_ids:
            if skill_id in seen:
                continue
            try:
                skill = self._registry.get(skill_id)
            except SkillNotFoundError:
                # Caller asked for a skill that's not bundled — that's an
                # error worth surfacing, unlike silent auto-fire skips.
                raise
            invocations.append(
                SkillInvocation.build(
                    skill=skill,
                    reason="manual override (--skill)",
                    forced=True,
                )
            )
            seen.add(skill_id)

        return tuple(invocations)

    def list_skills(self) -> tuple[str, ...]:
        return tuple(self._registry.list_ids())
