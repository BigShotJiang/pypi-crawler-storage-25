"""AIOS Harness Loader (EPIC N.1).

Bundles AIOS development resources (personas, tasks, workflows, templates,
checklists, rules, skills) and exposes a stable read API. Works the same way
whether AGtestari is running from the source tree or from an installed wheel.

Usage:
    from agents._shared.harness import HarnessLoader

    harness = HarnessLoader()
    persona_md = harness.load_persona("dev")
    workflow_yaml = harness.load_workflow("greenfield-fullstack")
    rule_md = harness.load_rule("agent-authority")
    skill_md = harness.load_skill("aiox-maestro")
    checklist_md = harness.load_checklist("story-dod-checklist")

The loader is read-only. It never mutates resources. Discovery uses the
filesystem in dev mode and `importlib.resources` in wheel mode.
"""

from agents._shared.harness.loader import HarnessLoader, get_harness
from agents._shared.harness.types import (
    ResourceKind,
    ResourceNotFoundError,
    HarnessError,
)

__all__ = [
    "HarnessLoader",
    "get_harness",
    "ResourceKind",
    "ResourceNotFoundError",
    "HarnessError",
]

__version__ = "1.0.0"
