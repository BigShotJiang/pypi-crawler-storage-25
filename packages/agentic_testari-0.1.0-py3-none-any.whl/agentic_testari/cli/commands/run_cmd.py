"""`at-cli run` — execute a test under the AIOS harness.

Wires together:
  - WorkflowRouter   (N.3) — pick the right workflow
  - ConstitutionalGate (N.5) — fire at START + END
  - QaGateChecklist  (N.8) — 12-point matrix
  - TemplateService  (N.7) — instantiate story + qa-gate artifacts
  - SkillDispatcher  (N.6) — auto-fire skills on context match

This entry point is intentionally LLM-free for the M.4 milestone — the
persona pipeline (N.2) is invoked by the verdict pipeline downstream
(EPIC F.1+ Helena/Victor wiring). The CLI command handles routing,
constitution checks, and reports back; the actual browser/api driving
happens in the agent containers.

Returns an exit code: 0 = PASS, 1 = FAIL, 2 = BLOCKED (constitutional
gate or precondition failure).
"""

from __future__ import annotations

from typing import Optional
from uuid import uuid4

from rich.console import Console
from rich.panel import Panel

from agentic_testari import (
    ConstitutionalGate,
    GatePhase,
    QaGateChecklist,
    SkillDispatcher,
    TemplateService,
    WorkflowRouter,
)
from agentic_testari.harness.constitution import GateContext
from agentic_testari.harness.skills import SkillContext
from agentic_testari.harness.templates import TemplateKind
from agentic_testari.harness.workflows import RouteRequest, WorkflowKind
from agentic_testari.cli.commands.init_cmd import get_configured_binding


_EXIT_PASS = 0
_EXIT_FAIL = 1
_EXIT_BLOCKED = 2


def run_test(
    *,
    console: Console,
    intent: str,
    workflow_override: Optional[str],
    acceptance_criteria: tuple[str, ...],
    raw: bool,
) -> int:
    """Drive a single harness-governed test run."""
    if not get_configured_binding():
        console.print(
            "[red]No LLM binding configured.[/red] "
            "Run [bold]at-cli init[/bold] first."
        )
        return _EXIT_BLOCKED

    run_id = f"run-{uuid4().hex[:12]}"

    if raw:
        console.print(
            "[yellow]⚠[/yellow] Running with [bold]--raw[/bold] — "
            "harness skipped for this call. Next run reverts to harness."
        )

    # ---- Constitutional gate (START) ----
    gate = ConstitutionalGate.default()
    start_ctx = GateContext(
        run_id=run_id,
        intent_text=intent,
        has_verdict=False,
    )
    pre = gate.evaluate(start_ctx, phase=GatePhase.START)
    if pre.blocked and not raw:
        console.print(
            Panel(
                "\n".join(
                    f"· [bold]{c.rule.value}[/bold]\n  {c.message}\n  [dim]{c.recommendation}[/dim]"
                    for c in pre.failures()
                ),
                title="[red]Constitutional gate FAILED at START[/red]",
                border_style="red",
            )
        )
        return _EXIT_BLOCKED

    # ---- Workflow routing ----
    router = WorkflowRouter()
    if workflow_override:
        kind = WorkflowKind(workflow_override)
    else:
        kind = None
    decision = router.route(
        RouteRequest(
            run_id=run_id,
            intent=intent,
            acceptance_criteria=tuple(acceptance_criteria),
            workflow_override=kind,
        )
    )
    console.print(
        f"[cyan]Workflow:[/cyan] {decision.kind.value} "
        f"[dim]({decision.reason})[/dim]"
    )

    # ---- JIT story artifact ----
    templates = TemplateService()
    try:
        story = templates.instantiate(
            TemplateKind.STORY,
            run_id=run_id,
            variables={
                "id": run_id,
                "title": intent[:80],
                "asA": "user",
                "iWant": intent,
                "soThat": "the system behaves as expected",
            },
        )
        console.print(f"[dim]Story artifact: {story.metadata.instance_id}[/dim]")
    except Exception as exc:
        console.print(f"[yellow]Story instantiation skipped:[/yellow] {exc}")

    # ---- Skill dispatch (auto-fire on context) ----
    skills = SkillDispatcher.default()
    skill_invocations = skills.dispatch(
        SkillContext(
            run_id=run_id,
            steps_count=len(acceptance_criteria),
            review_phase=False,
        )
    )
    if skill_invocations:
        console.print(
            f"[cyan]Auto-fired skills:[/cyan] "
            f"{', '.join(s.skill_id for s in skill_invocations)}"
        )

    # ---- Placeholder verdict (full execution comes from Helena/Victor wiring) ----
    console.print(
        "[yellow]⚠[/yellow] CLI-only path: actual test execution requires "
        "Helena/Victor agent containers (EPIC F integration in progress). "
        "Returning a synthetic PASS verdict for harness validation."
    )

    # ---- 12-point QA gate (synthetic clean context for now) ----
    from agentic_testari.harness.rules import CheckContext

    qa_ctx = CheckContext(run_id=run_id, metadata={"ac_total": len(acceptance_criteria), "ac_met": len(acceptance_criteria)})
    checklist = QaGateChecklist().run(qa_ctx)
    console.print(
        f"[cyan]QA Gate:[/cyan] {checklist.passed_count()}/{checklist.total()} checks green"
    )

    # ---- Constitutional gate (END) ----
    end_ctx = GateContext(
        run_id=run_id,
        intent_text=intent,
        has_verdict=True,
    )
    post = gate.evaluate(end_ctx, phase=GatePhase.END)
    if post.blocked:
        console.print(
            Panel(
                "\n".join(
                    f"· [bold]{c.rule.value}[/bold]: {c.message}"
                    for c in post.failures()
                ),
                title="[red]Constitutional gate FAILED at END[/red]",
                border_style="red",
            )
        )
        return _EXIT_FAIL

    console.print("\n[bold green]✔ PASS[/bold green]")
    return _EXIT_PASS
