"""`at-cli onboard` — guided 5-step first-customer onboarding flow.

Reuses init_cmd, license_cmd, run_cmd, status_cmd, dashboard so the
onboarding wizard stays a thin orchestrator. Each step can be skipped
(--skip-step N) and the wizard resumes from the next.

Steps:
  1. Welcome + naming reminder
  2. LLM binding (calls run_init_wizard)
  3. License activation (calls activate_license)
  4. Sample run (synthetic test_intent → at-cli run)
  5. Dashboard prompt (offer to start the local dashboard)

Exit codes:
  0  completed successfully
  1  user aborted
  2  step failed (e.g., LLM binding skipped, license activation failed)
"""

from __future__ import annotations

import sys
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel

from agentic_testari import __version__


_STEPS = (
    "welcome",
    "llm-binding",
    "license",
    "sample-run",
    "dashboard",
)


def run_onboard_wizard(
    console: Console,
    *,
    skip_steps: tuple[int, ...] = (),
    license_token: Optional[str] = None,
    sample_intent: str = "Verify a basic GET /health request returns 200",
    auto_yes: bool = False,
) -> int:
    """Drive the 5-step onboarding flow.

    Args:
      console:        Rich console for output (tests pass a captured one)
      skip_steps:     1-indexed step numbers to skip
      license_token:  pre-supplied token (skips the prompt)
      sample_intent:  intent for the optional step-4 dry run
      auto_yes:       auto-accept dashboard prompt (testing)

    Returns process exit code.
    """
    welcome_box(console)

    # Step 1 — welcome
    if 1 not in skip_steps:
        console.print(_step_header(1, "Welcome"))
        console.print(
            "Agentic Testari runs your tests under the AIOS development "
            "discipline.\n\n"
            "[bold]Customer-facing name:[/bold] Agentic Testari\n"
            "[bold]CLI binary:[/bold]          at-cli\n"
            "[bold]npm package:[/bold]         @agentic-testari/cli\n"
            "[bold]Python package:[/bold]      agentic-testari\n"
        )

    # Step 2 — LLM binding
    if 2 not in skip_steps:
        console.print(_step_header(2, "LLM binding"))
        console.print(
            "[dim]Your LLM is always your own — Agentic Testari ships zero bundled keys.[/dim]\n"
        )
        if auto_yes:
            console.print(
                "[yellow]auto-yes:[/yellow] skipping interactive LLM wizard."
            )
        else:
            try:
                from agentic_testari.cli.commands.init_cmd import (
                    run_init_wizard,
                )

                run_init_wizard(console)
            except (click.exceptions.Abort, KeyboardInterrupt):
                console.print("[yellow]LLM wizard aborted.[/yellow]")
                return 1

    # Step 3 — license
    if 3 not in skip_steps:
        console.print(_step_header(3, "License activation"))
        token = license_token
        if token is None and not auto_yes:
            token = click.prompt(
                "Paste your license token (leave blank to skip)",
                default="",
                show_default=False,
                hide_input=True,
            )
        if token:
            from agentic_testari.cli.commands.license_cmd import (
                activate_license,
            )

            rc = activate_license(console, token)
            if rc != 0 and rc != 1:
                # rc=1 is "network unreachable, retry later" — non-fatal.
                return rc
        else:
            console.print(
                "[yellow]License skipped.[/yellow] You can run "
                "[bold]at-cli license activate <token>[/bold] later."
            )

    # Step 4 — sample run
    if 4 not in skip_steps:
        console.print(_step_header(4, "Sample run"))
        console.print(
            f"[dim]Running a synthetic test intent through the harness:[/dim]\n"
            f"  → {sample_intent}\n"
        )
        if auto_yes or click.confirm(
            "Run the sample now?", default=True
        ):
            try:
                from agentic_testari.cli.commands.run_cmd import run_test

                rc = run_test(
                    console=console,
                    intent=sample_intent,
                    workflow_override=None,
                    acceptance_criteria=("AC1: server returns 200 OK",),
                    raw=False,
                )
                if rc != 0:
                    console.print(
                        f"[yellow]Sample run exited with code {rc}.[/yellow] "
                        "Onboarding will continue."
                    )
            except Exception as exc:
                console.print(
                    f"[yellow]Sample run failed: {exc}[/yellow] "
                    "(continuing onboarding)"
                )

    # Step 5 — dashboard
    if 5 not in skip_steps:
        console.print(_step_header(5, "Local dashboard"))
        console.print(
            "Start the local dashboard with: "
            "[bold]at-cli dashboard --port 8765[/bold]\n"
            "Open http://localhost:8765 to see runs + pending approvals."
        )

    console.print("\n[bold green]✔ Onboarding complete.[/bold green]\n")
    console.print(
        "Next:\n"
        "  [dim]·[/dim] [bold]at-cli run \"<intent>\"[/bold] — run a test\n"
        "  [dim]·[/dim] [bold]at-cli status[/bold] — check version + license\n"
        "  [dim]·[/dim] [bold]at-cli dashboard[/bold] — start the local UI\n"
    )
    return 0


def welcome_box(console: Console) -> None:
    console.print(
        Panel.fit(
            f"[bold]Agentic Testari[/bold] · v{__version__}\n"
            f"[dim]Autonomous QA testing under AIOS development discipline.[/dim]",
            border_style="cyan",
        )
    )


def _step_header(n: int, title: str) -> str:
    return f"\n[cyan]── Step {n}/{len(_STEPS)} · {title} ──[/cyan]"
