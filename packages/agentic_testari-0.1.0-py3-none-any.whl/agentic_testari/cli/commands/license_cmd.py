"""`at-cli license` subcommands — activate / show / clear.

`activate` calls the M.7 license server to bind the token + hardware_id.
On success, the activation_id is persisted alongside the token so future
heartbeats can check revocation status.

Override the license server URL with `AGENTIC_TESTARI_LICENSE_URL` (used
by the local dev worker via `wrangler dev`).
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

from rich.console import Console

from agentic_testari import LicenseKeyStore
from agentic_testari.keychain import KeychainBackendUnavailable
from agentic_testari.licensing import (
    LicenseClient,
    LicenseError,
    LicenseRevoked,
    hardware_id,
)


def _build_client() -> LicenseClient:
    base_url = os.environ.get("AGENTIC_TESTARI_LICENSE_URL")
    if base_url:
        return LicenseClient(base_url=base_url)
    return LicenseClient()


def activate_license(
    console: Console,
    token: str,
    *,
    client: LicenseClient | None = None,
    skip_remote: bool = False,
) -> int:
    """Bind a license token to this machine.

    Steps:
      1. Persist the token in the OS keychain (so subsequent commands can
         read it without re-prompting).
      2. Call the license server `/v1/license/activate` with the token
         and a stable hardware_id.
      3. Store the returned activation_id + last_validated.

    `skip_remote` is for tests / offline scenarios; the local copy of
    the token is still persisted but no server round-trip happens.
    """
    try:
        lic = LicenseKeyStore()
    except KeychainBackendUnavailable:
        console.print(
            "[red]Error:[/red] no OS keychain available — cannot persist license."
        )
        return 1

    lic.set_token(token)

    if skip_remote:
        lic.set("last_validated", datetime.now(timezone.utc).isoformat())
        console.print(
            "[green]✔[/green] License token stored in OS keychain "
            "[yellow](remote validation skipped)[/yellow]."
        )
        return 0

    cli = client or _build_client()
    hwid = hardware_id()
    lic.set("hardware_id", hwid)

    try:
        activation = cli.activate(token=token, hardware_id=hwid)
    except LicenseRevoked as exc:
        console.print(f"[red]License revoked:[/red] {exc}")
        lic.clear_all()
        return 2
    except LicenseError as exc:
        console.print(f"[red]Activation failed:[/red] {exc}")
        return 1
    except Exception as exc:
        # Network failure, etc — keep the token but flag activation as
        # incomplete so the user can retry.
        console.print(
            f"[yellow]Could not reach license server:[/yellow] {exc}\n"
            "[dim]Token stored locally; run [bold]at-cli license activate[/bold] "
            "again when online.[/dim]"
        )
        return 1

    lic.set("activation_id", activation.activation_id)
    lic.set("last_validated", datetime.now(timezone.utc).isoformat())
    lic.set("tier", activation.tier)

    console.print(
        f"[green]✔[/green] License activated.\n"
        f"  tier:          [bold]{activation.tier}[/bold]\n"
        f"  activation_id: [dim]{activation.activation_id}[/dim]\n"
        f"  expires_at:    [dim]{activation.expires_at}[/dim]\n"
        f"  seats:         [dim]{activation.seats_used}/{activation.seats_total}[/dim]"
    )
    return 0


def show_license(console: Console) -> None:
    """Show license activation state without printing the token."""
    try:
        lic = LicenseKeyStore()
    except KeychainBackendUnavailable:
        console.print("[red]No OS keychain available.[/red]")
        return
    if lic.is_activated():
        token = lic.get_token() or ""
        console.print(
            f"[green]Activated[/green]\n"
            f"  token preview: [dim]{token[:8]}...{token[-4:] if len(token) > 12 else ''}[/dim]\n"
            f"  tier:          [dim]{lic.get('tier') or '[unset]'}[/dim]\n"
            f"  activation_id: [dim]{lic.get('activation_id') or '[unset]'}[/dim]\n"
            f"  hardware_id:   [dim]{lic.get('hardware_id') or '[unset]'}[/dim]\n"
            f"  last_validated: [dim]{lic.get('last_validated') or '[unset]'}[/dim]"
        )
    else:
        console.print(
            "[yellow]Not activated.[/yellow] Run "
            "[bold]at-cli license activate <token>[/bold]."
        )


def clear_license(
    console: Console, *, client: LicenseClient | None = None
) -> None:
    """Wipe all license fields. Best-effort revoke on the server side."""
    try:
        lic = LicenseKeyStore()
    except KeychainBackendUnavailable:
        console.print("[red]No OS keychain available.[/red]")
        return

    token = lic.get_token()
    activation_id = lic.get("activation_id")
    if token and activation_id:
        cli = client or _build_client()
        try:
            cli.revoke(token=token, activation_id=activation_id)
        except Exception as exc:
            console.print(
                f"[yellow]Server revoke failed (clearing local anyway):[/yellow] {exc}"
            )

    lic.clear_all()
    console.print(
        "[green]✔[/green] License credentials cleared from OS keychain."
    )
