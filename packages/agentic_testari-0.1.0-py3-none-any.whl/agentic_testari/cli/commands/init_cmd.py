"""`at-cli init` — first-run wizard for LLM binding.

Per AIDR-022 (locked 2026-04-27): the wizard MANDATES one of:

    1. BYO API key (OpenAI / Anthropic / Azure)
    2. MCP-delegated to host (Claude Code / Codex / Cursor / Antigravity)

No run proceeds without LLM binding configured. The wizard stores the
choice and (for BYO) the API key in the OS keychain.

The founder's own LLM is NEVER used to serve customer calls. This file
exists to enforce that contract at the CLI level.
"""

from __future__ import annotations

import click
from rich.console import Console
from rich.panel import Panel

from agentic_testari import ApiKeyStore, get_default_keystore
from agentic_testari.keychain import NullKeyStore


_CONFIG_NAMESPACE = "config"
_LLM_BINDING_KEY = "llm_binding"


def run_init_wizard(console: Console) -> None:
    """Interactive first-run wizard. Configures LLM binding and stores choice."""
    console.print(
        Panel.fit(
            "[bold]Agentic Testari — First-run setup[/bold]\n\n"
            "We need to know how you'd like the harness to call your LLM.\n"
            "[dim]Your LLM is always your own — Agentic Testari ships zero bundled keys.[/dim]",
            border_style="cyan",
        )
    )

    choice = click.prompt(
        "\nChoose LLM binding mode",
        type=click.Choice(["byo-key", "mcp-host", "skip"]),
        default="byo-key",
        show_choices=True,
    )

    config_store = get_default_keystore(_CONFIG_NAMESPACE)
    if isinstance(config_store, NullKeyStore):
        console.print(
            "[yellow]Warning:[/yellow] no OS keychain available. "
            "Configuration will not persist across sessions."
        )

    if choice == "byo-key":
        provider = click.prompt(
            "Which provider?",
            type=click.Choice(["openai", "anthropic", "azure"]),
            default="anthropic",
        )
        api_key = click.prompt(
            f"Paste your {provider} API key",
            hide_input=True,
            confirmation_prompt=False,
        )
        api_store = ApiKeyStore()
        api_store.set(provider, api_key)
        config_store.set(_LLM_BINDING_KEY, f"byo-key:{provider}")
        console.print(
            f"\n[green]✔[/green] Stored {provider} key in OS keychain "
            f"(namespace [bold]agtestari.api-keys[/bold])."
        )
    elif choice == "mcp-host":
        host = click.prompt(
            "Which host will run the harness?",
            type=click.Choice(["claude-code", "codex", "cursor", "antigravity"]),
            default="claude-code",
        )
        config_store.set(_LLM_BINDING_KEY, f"mcp-host:{host}")
        console.print(
            f"\n[green]✔[/green] Configured MCP delegation to "
            f"[bold]{host}[/bold]. The host's session billing applies."
        )
    else:
        console.print(
            "\n[yellow]Skipped[/yellow] — runs will fail until you "
            "configure an LLM binding via [bold]at-cli init[/bold]."
        )
        return

    console.print(
        "\n[bold green]Setup complete.[/bold green] Next steps:\n"
        "  [dim]·[/dim] [bold]at-cli run \"Verify the login flow\"[/bold]\n"
        "  [dim]·[/dim] [bold]at-cli license activate <token>[/bold]"
    )


def get_configured_binding() -> str | None:
    """Return the stored llm_binding string or None."""
    return get_default_keystore(_CONFIG_NAMESPACE).get(_LLM_BINDING_KEY)
