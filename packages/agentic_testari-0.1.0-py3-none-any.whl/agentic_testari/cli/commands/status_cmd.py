"""`at-cli status` — show installed version, LLM binding, license state."""

from __future__ import annotations

from agentic_testari import (
    ApiKeyStore,
    LicenseKeyStore,
    __version__,
    get_default_keystore,
    get_storage,
)
from agentic_testari.keychain import KeychainBackendUnavailable, NullKeyStore
from agentic_testari.cli.commands.init_cmd import get_configured_binding


def build_status_report() -> dict[str, object]:
    """Return a flat dict of status fields for table rendering."""
    report: dict[str, object] = {"agentic-testari version": __version__}

    binding = get_configured_binding()
    report["llm_binding"] = binding or "[not configured — run `at-cli init`]"

    try:
        api_store = ApiKeyStore()
        report["api_keys.openai"] = "set" if api_store.has("openai") else "unset"
        report["api_keys.anthropic"] = "set" if api_store.has("anthropic") else "unset"
        report["api_keys.azure"] = "set" if api_store.has("azure") else "unset"
    except KeychainBackendUnavailable:
        report["api_keys"] = "[no OS keychain available]"

    license_state = "unknown"
    try:
        lic = LicenseKeyStore()
        license_state = "activated" if lic.is_activated() else "not activated"
    except KeychainBackendUnavailable:
        license_state = "[no OS keychain available]"
    report["license"] = license_state

    config_store = get_default_keystore("config")
    if isinstance(config_store, NullKeyStore):
        report["config_storage"] = "memory only (no OS keychain)"
    else:
        report["config_storage"] = "OS keychain"

    try:
        storage = get_storage()
        report["storage_mode"] = storage.mode.value
    except Exception as exc:
        report["storage_mode"] = f"[error: {exc}]"

    return report
