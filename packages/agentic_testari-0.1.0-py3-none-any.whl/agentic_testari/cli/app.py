"""at-cli main entry point.

Uses `click` for argument parsing + `rich` for output. Stays thin — the
real work happens in the harness/storage/keychain modules. This file is
just the shell.
"""

from __future__ import annotations

import sys
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from agentic_testari import __version__
from agentic_testari.cli.commands.init_cmd import run_init_wizard
from agentic_testari.cli.commands.license_cmd import (
    activate_license,
    clear_license,
    show_license,
)
from agentic_testari.cli.commands.run_cmd import run_test
from agentic_testari.cli.commands.status_cmd import build_status_report

console = Console()


@click.group(invoke_without_command=True)
@click.option("--version", "-V", is_flag=True, help="Print version and exit.")
@click.pass_context
def cli(ctx: click.Context, version: bool) -> None:
    """Agentic Testari — autonomous QA testing under AIOS development discipline."""
    if version:
        click.echo(f"agentic-testari {__version__}")
        return
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
def init() -> None:
    """Configure LLM binding (BYO API key OR MCP delegation)."""
    run_init_wizard(console)


@cli.command()
@click.argument("intent", required=False)
@click.option(
    "--intent",
    "intent_opt",
    help="Test intent (alternative to positional argument).",
)
@click.option(
    "--workflow",
    type=click.Choice(
        ["express-test", "full-sdc", "qa-loop", "spec-pipeline", "brownfield-discovery"]
    ),
    help="Force a workflow type instead of letting the router pick.",
)
@click.option(
    "--ac",
    "acceptance_criteria",
    multiple=True,
    help="Acceptance criterion (repeat for multiple).",
)
@click.option(
    "--raw",
    is_flag=True,
    help="Pro-tier: skip the harness for this single call.",
)
def run(
    intent: Optional[str],
    intent_opt: Optional[str],
    workflow: Optional[str],
    acceptance_criteria: tuple[str, ...],
    raw: bool,
) -> None:
    """Execute a test under the AIOS harness."""
    final_intent = intent or intent_opt
    if not final_intent:
        click.echo("Error: provide a test intent (positional or --intent).", err=True)
        sys.exit(2)
    exit_code = run_test(
        console=console,
        intent=final_intent,
        workflow_override=workflow,
        acceptance_criteria=acceptance_criteria,
        raw=raw,
    )
    sys.exit(exit_code)


@cli.command()
def status() -> None:
    """Show installed version, configured LLM, license state."""
    report = build_status_report()
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("key", style="bold cyan")
    table.add_column("value")
    for key, value in report.items():
        table.add_row(key, str(value))
    console.print(table)


@cli.group()
def license() -> None:
    """Manage license credentials."""


@license.command("activate")
@click.argument("token", required=True)
@click.option(
    "--skip-remote",
    is_flag=True,
    help="Persist locally but skip the license server round-trip (offline / dev).",
)
def license_activate(token: str, skip_remote: bool) -> None:
    """Bind a license token to this machine via the license server."""
    rc = activate_license(console, token, skip_remote=skip_remote)
    sys.exit(rc)


@license.command("show")
def license_show() -> None:
    """Show current license activation state (no secrets printed)."""
    show_license(console)


@license.command("clear")
@click.confirmation_option(prompt="Wipe all license credentials?")
def license_clear() -> None:
    """Wipe license + activation_id + hardware_id from the keychain."""
    clear_license(console)


@cli.command()
def version() -> None:
    """Print the installed version."""
    click.echo(f"agentic-testari {__version__}")


@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", default=8765, show_default=True, type=int)
def dashboard(host: str, port: int) -> None:
    """Start the local web dashboard (test history + pending approvals)."""
    try:
        from agentic_testari.dashboard import run_dashboard
    except ImportError as exc:
        click.echo(
            f"Dashboard requires fastapi + uvicorn. Install: "
            f"pip install fastapi uvicorn  ({exc})",
            err=True,
        )
        sys.exit(1)
    click.echo(f"Dashboard listening on http://{host}:{port}")
    run_dashboard(host=host, port=port)


@cli.command()
@click.option(
    "--skip-step",
    "skip_steps",
    multiple=True,
    type=int,
    help="Skip step N (1-indexed). Repeat for multiple.",
)
@click.option(
    "--license-token",
    default=None,
    help="Pre-supplied license token (skips the prompt in step 3).",
)
@click.option(
    "--sample-intent",
    default="Verify a basic GET /health request returns 200",
    show_default=True,
    help="Override the sample-run intent in step 4.",
)
@click.option(
    "--auto-yes",
    is_flag=True,
    help="Auto-accept all prompts (testing / scripted setup).",
)
def onboard(
    skip_steps: tuple[int, ...],
    license_token: Optional[str],
    sample_intent: str,
    auto_yes: bool,
) -> None:
    """Guided 5-step first-customer onboarding flow."""
    from agentic_testari.cli.commands.onboard_cmd import run_onboard_wizard

    rc = run_onboard_wizard(
        console=console,
        skip_steps=tuple(skip_steps),
        license_token=license_token,
        sample_intent=sample_intent,
        auto_yes=auto_yes,
    )
    sys.exit(rc)


def main(argv: Optional[list[str]] = None) -> None:
    """Console-script entry point."""
    cli.main(args=argv, prog_name="at-cli", standalone_mode=True)


if __name__ == "__main__":
    main()
