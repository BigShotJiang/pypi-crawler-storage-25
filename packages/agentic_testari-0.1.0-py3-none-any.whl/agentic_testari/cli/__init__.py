"""at-cli — command-line entry point for Agentic Testari.

Subcommands:
    init      First-run wizard (LLM binding: BYO key or MCP delegation)
    run       Execute a test under the AIOS harness
    status    Show installed version, configured LLM, license state
    license   Activate / show / clear license credentials
    version   Print the installed version

Usage:
    at-cli init
    at-cli run "Verify the login flow with valid credentials"
    at-cli run --intent "Login flow" --workflow full-sdc
    at-cli status
    at-cli license activate <token>
"""

from __future__ import annotations

from agentic_testari.cli.app import main

__all__ = ["main"]
