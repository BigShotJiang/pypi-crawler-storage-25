"""Agentic Testari — autonomous QA testing under AIOS development discipline.

This package re-exports the public surface of the harness, storage, and
keychain modules so customers have a single import path:

    from agentic_testari import (
        HarnessLoader,
        Pipeline,
        ConstitutionalGate,
        get_storage,
        ApiKeyStore,
        LicenseKeyStore,
    )

The actual implementations live in `agents/_shared/{harness,storage,keychain}`
in the development tree and are force-included into the wheel under
`agentic_testari/{harness,storage,keychain}` at build time (see hatchling
config in pyproject.toml).

M.4.1 Phase 6 — Wheel-mode import remap (`sys.meta_path` finder)
---------------------------------------------------------------
Inside the force-included subpackages, every internal import uses the
absolute form `from agents._shared.harness.X import Y` (M.4 invariant —
EPIC N source ships unchanged into the wheel). After install, the
top-level `agents` namespace does NOT exist on disk, so those imports
fail with `ModuleNotFoundError: No module named 'agents'`.

We solve this by installing a `MetaPathFinder` that maps every
`agents._shared.X.Y` import request to its `agentic_testari.X.Y`
counterpart at import time. The finder is a no-op in dev mode (where
`agents._shared` exists on the real filesystem and Python's default
finder resolves it directly).

Why a finder, not pre-populated `sys.modules` aliases:
    - Aliases require importing all subpackages eagerly, which is a
      chicken-and-egg with the very imports we're trying to satisfy.
    - A finder lazily resolves on demand, so it works no matter what
      order modules import each other in.
    - A finder is idempotent — if the same module is already cached
      under either name, the cache wins.

Dev-mode safety:
    - If `agents._shared` is already in `sys.modules` (e.g., pytest
      imported the source tree first), the finder skips installation.
    - If `agents/_shared/__init__.py` exists on the filesystem
      relative to the current Python path, the finder skips
      installation.

This file is the entrypoint that runs the install before any
`agentic_testari.harness` etc. imports trigger the absolute-form
imports inside the bundled modules.
"""

from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import importlib.util
import sys
from pathlib import Path
from typing import Sequence

__version__ = "0.1.0"

# Modules that ship inside the wheel under `agentic_testari/<name>/` and
# are also imported via the absolute form `agents._shared.<name>` from
# inside their own `__init__.py` and submodules. Order matters only for
# documentation; the finder resolves all of them lazily.
_REMAP_SUBPACKAGES = ("harness", "storage", "keychain", "quality")


class _AliasingLoader(importlib.abc.Loader):
    """Wraps a real loader so the loaded module is also registered under
    `alias` in `sys.modules` post-exec.

    Why: when the finder resolves `agents._shared.harness.loader`, we
    load the file `<anchor>/harness/loader.py` directly. Without this
    aliasing wrapper, the module would only be registered under
    `agents._shared.harness.loader` — and when other code does
    `from agentic_testari.harness.loader import X`, Python would
    re-load the same file under the second name, producing two
    distinct module instances. Aliasing keeps one shared instance.
    """

    def __init__(self, real_loader: importlib.abc.Loader, *, alias: str) -> None:
        self._real = real_loader
        self._alias = alias

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> object | None:
        # Defer to the real loader; most return None so the default
        # module type is used.
        if hasattr(self._real, "create_module"):
            return self._real.create_module(spec)
        return None

    def exec_module(self, module: object) -> None:
        # Run the real exec_module first so the module's globals get
        # populated, then register under the alias name.
        self._real.exec_module(module)
        sys.modules[self._alias] = module


class _AgentsSharedFinder(importlib.abc.MetaPathFinder):
    """Resolve `agents._shared.X.Y` to `agentic_testari.X.Y` in wheel mode.

    Why this exists:
        Wheel-mode internal imports (e.g.
        `from agents._shared.harness.loader import HarnessLoader`)
        would otherwise fail because the top-level `agents` package is
        not present on disk after `pip install agentic-testari`.

    How it works:
        Each `agents._shared.X.Y` lookup is mapped to the on-disk file
        that `agentic_testari/X/Y` would resolve to (next to this
        `__init__.py`). We use `spec_from_file_location` to build a
        spec that loads the file DIRECTLY — *without* re-entering
        `agentic_testari/__init__.py`, which would otherwise cause a
        circular-import partial-initialization error during the very
        first re-export `from agentic_testari.harness import ...`.

        For each resolved leaf module, we also alias it into
        `sys.modules` under BOTH names (`agents._shared.X.Y` and
        `agentic_testari.X.Y`) so subsequent re-export imports from
        `agentic_testari/__init__.py` find the same instance.

    Args / Returns / Raises follow the importlib MetaPathFinder
    protocol (find_spec → ModuleSpec | None).
    """

    _PREFIX = "agents._shared"
    _ROOT = "agents"

    def __init__(self, anchor_dir: Path) -> None:
        # `anchor_dir` is the directory that contains this file —
        # i.e. `<site-packages>/agentic_testari/`. All on-disk lookups
        # for `agents._shared.X.Y` are resolved relative to here.
        self._anchor = anchor_dir

    def find_spec(
        self,
        fullname: str,
        path: Sequence[str] | None = None,
        target: object | None = None,
    ) -> importlib.machinery.ModuleSpec | None:
        # Step 1: derive the on-disk subpath under `agentic_testari/`.
        if fullname == self._ROOT or fullname == self._PREFIX:
            sub_path: tuple[str, ...] = ()
        elif fullname.startswith(self._PREFIX + "."):
            tail = fullname[len(self._PREFIX) + 1 :]
            sub_path = tuple(tail.split("."))
        else:
            return None

        # Step 2: locate the module file on disk.
        #   - Empty sub_path → the `agents` / `agents._shared` umbrella
        #     itself: synthesize a namespace package pointing at our
        #     anchor directory so submodule lookups recurse here.
        #   - Non-empty sub_path → either `<anchor>/X/.../Y/__init__.py`
        #     (package) or `<anchor>/X/.../Y.py` (leaf module).
        if not sub_path:
            return self._namespace_spec(fullname, [str(self._anchor)])

        # Avoid double-loading when the equivalent `agentic_testari.X.Y`
        # module is already in `sys.modules`. This is critical: the
        # outer `from agentic_testari.harness import ...` re-export in
        # this `__init__.py` partially-initializes `agentic_testari.harness`
        # *before* `harness/__init__.py`'s internal
        # `from agents._shared.harness.loader import ...` runs. If we
        # loaded `agents._shared.harness` from disk as a fresh module
        # we'd end up with two distinct module instances. Instead we
        # alias the existing partial module so all submodule lookups
        # go through one shared object graph.
        target_name = "agentic_testari." + ".".join(sub_path)
        cached = sys.modules.get(target_name)
        if cached is not None:
            sys.modules[fullname] = cached
            return self._spec_from_existing_module(fullname, cached)

        candidate_dir = self._anchor.joinpath(*sub_path)
        package_init = candidate_dir / "__init__.py"
        leaf_file = candidate_dir.with_suffix(".py")

        if package_init.is_file():
            return self._spec_for_file(
                fullname, package_init, is_package=True
            )
        if leaf_file.is_file():
            return self._spec_for_file(
                fullname, leaf_file, is_package=False
            )

        # Also check for compiled extensions (.pyd / .so) when the
        # Cython moat has compiled the leaf away.
        for ext in importlib.machinery.EXTENSION_SUFFIXES:
            for compiled in candidate_dir.parent.glob(
                f"{sub_path[-1]}{ext}"
            ):
                return self._spec_for_extension(fullname, compiled)
        return None

    def _spec_from_existing_module(
        self,
        fullname: str,
        module: object,
    ) -> importlib.machinery.ModuleSpec:
        """Wrap an already-loaded `agentic_testari.*` module as `agents._shared.*`."""
        spec = importlib.machinery.ModuleSpec(
            name=fullname,
            loader=None,
            origin=getattr(module, "__file__", None),
            is_package=hasattr(module, "__path__"),
        )
        if hasattr(module, "__path__"):
            spec.submodule_search_locations = list(module.__path__)
        return spec

    def _spec_for_file(
        self,
        fullname: str,
        path: Path,
        *,
        is_package: bool,
    ) -> importlib.machinery.ModuleSpec | None:
        """Build a spec that loads `path` directly via SourceFileLoader.

        Crucially this does NOT trigger `importlib.import_module` on
        `agentic_testari.X`, which would re-enter the partially-loaded
        `agentic_testari` package and raise a circular-import error.
        Instead we wrap the SourceFileLoader so that after the module
        executes, we also register it under the `agentic_testari.X`
        alias — keeping a single instance shared across both naming
        spaces.
        """
        target_name = "agentic_testari." + fullname[len(self._PREFIX) + 1 :]
        loader = _AliasingLoader(
            importlib.machinery.SourceFileLoader(fullname, str(path)),
            alias=target_name,
        )
        spec = importlib.util.spec_from_file_location(
            fullname,
            str(path),
            loader=loader,
            submodule_search_locations=(
                [str(path.parent)] if is_package else None
            ),
        )
        return spec

    def _spec_for_extension(
        self,
        fullname: str,
        path: Path,
    ) -> importlib.machinery.ModuleSpec | None:
        """Build a spec that loads a compiled `.pyd` / `.so` extension."""
        target_name = "agentic_testari." + fullname[len(self._PREFIX) + 1 :]
        loader = _AliasingLoader(
            importlib.machinery.ExtensionFileLoader(fullname, str(path)),
            alias=target_name,
        )
        return importlib.util.spec_from_file_location(
            fullname, str(path), loader=loader
        )

    def _namespace_spec(
        self,
        fullname: str,
        search_locations: list[str],
    ) -> importlib.machinery.ModuleSpec:
        """Synthesize a namespace package spec for `agents` / `agents._shared`."""
        spec = importlib.machinery.ModuleSpec(
            name=fullname,
            loader=None,
            is_package=True,
        )
        spec.submodule_search_locations = search_locations
        return spec


def _is_dev_mode() -> bool:
    """Detect dev mode (don't install the finder if real `agents._shared` exists).

    Why: in source-tree development (pytest from repo root, editable
    installs that include the `agents/` tree), `agents._shared` is a
    real filesystem package. Installing the finder there would shadow
    it and break dev workflows. We err on the side of NOT installing.

    Heuristics:
        1. `agents._shared` already in `sys.modules` (someone imported
           it before us).
        2. An `agents/_shared/__init__.py` file exists relative to any
           directory on `sys.path`.
    """
    if "agents._shared" in sys.modules:
        return True
    for entry in sys.path:
        if not entry:
            continue
        try:
            candidate = Path(entry) / "agents" / "_shared" / "__init__.py"
        except (TypeError, ValueError):
            continue
        if candidate.is_file():
            return True
    return False


def _install_remap() -> None:
    """Install the `agents._shared` → `agentic_testari` finder once.

    Idempotent: re-running is a no-op (we check for the finder type in
    `sys.meta_path`).
    """
    if _is_dev_mode():
        return
    for finder in sys.meta_path:
        if isinstance(finder, _AgentsSharedFinder):
            return
    anchor = Path(__file__).resolve().parent
    # Insert at front so we resolve before the default file-system finder
    # (which would otherwise raise ModuleNotFoundError for `agents`).
    sys.meta_path.insert(0, _AgentsSharedFinder(anchor))


_install_remap()


# Dev-mode aliases: when running from the source tree, `agentic_testari.X`
# isn't a real package on disk — only `agents._shared.X` is. Register the
# aliases in `sys.modules` so the wheel-style imports below
# (`from agentic_testari.harness import ...`) resolve to the real
# source-tree packages. This must happen BEFORE the re-export imports.
if _is_dev_mode():
    import agents._shared.harness as _h  # noqa: E402
    import agents._shared.harness.personas as _hp  # noqa: E402
    import agents._shared.harness.constitution as _hc  # noqa: E402
    import agents._shared.harness.rules as _hr  # noqa: E402
    import agents._shared.harness.workflows as _hw  # noqa: E402
    import agents._shared.harness.skills as _hs  # noqa: E402
    import agents._shared.harness.templates as _ht  # noqa: E402
    import agents._shared.harness.checklists as _hck  # noqa: E402
    import agents._shared.storage as _s  # noqa: E402
    import agents._shared.keychain as _k  # noqa: E402

    sys.modules.setdefault("agentic_testari.harness", _h)
    sys.modules.setdefault("agentic_testari.harness.personas", _hp)
    sys.modules.setdefault("agentic_testari.harness.constitution", _hc)
    sys.modules.setdefault("agentic_testari.harness.rules", _hr)
    sys.modules.setdefault("agentic_testari.harness.workflows", _hw)
    sys.modules.setdefault("agentic_testari.harness.skills", _hs)
    sys.modules.setdefault("agentic_testari.harness.templates", _ht)
    sys.modules.setdefault("agentic_testari.harness.checklists", _hck)
    sys.modules.setdefault("agentic_testari.storage", _s)
    sys.modules.setdefault("agentic_testari.keychain", _k)


# Re-exports — these resolve to `agentic_testari.harness` etc. directly
# (when running from the wheel) or to `agents._shared.harness` (in dev,
# via the aliases registered above). The finder handles wheel-mode
# resolution of internal `from agents._shared...` imports transparently.
from agentic_testari.harness import (  # noqa: E402
    HarnessLoader,
    get_harness,
)
from agentic_testari.harness.personas import (  # noqa: E402
    Pipeline,
    PersonaRegistry,
)
from agentic_testari.harness.constitution import (  # noqa: E402
    ConstitutionalGate,
    GatePhase,
)
from agentic_testari.harness.rules import RulesEngine  # noqa: E402
from agentic_testari.harness.workflows import WorkflowRouter  # noqa: E402
from agentic_testari.harness.skills import SkillDispatcher  # noqa: E402
from agentic_testari.harness.templates import TemplateService  # noqa: E402
from agentic_testari.harness.checklists import QaGateChecklist  # noqa: E402

from agentic_testari.storage import get_storage, StorageMode  # noqa: E402
from agentic_testari.keychain import (  # noqa: E402
    ApiKeyStore,
    LicenseKeyStore,
    get_default_keystore,
)


__all__ = [
    "__version__",
    "HarnessLoader",
    "get_harness",
    "Pipeline",
    "PersonaRegistry",
    "ConstitutionalGate",
    "GatePhase",
    "RulesEngine",
    "WorkflowRouter",
    "SkillDispatcher",
    "TemplateService",
    "QaGateChecklist",
    "get_storage",
    "StorageMode",
    "ApiKeyStore",
    "LicenseKeyStore",
    "get_default_keystore",
]
