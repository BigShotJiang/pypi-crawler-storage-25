"""MCP types — Tool, ToolCallResult, errors.

Following MCP spec (2024-11-05): tools are JSON-Schema-typed callable
units. Each tool has a name, description, inputSchema, and a handler
that takes a dict of arguments and returns a structured ToolCallResult.

We do NOT depend on the official `mcp` Python SDK — keeping deps small.
A minimal JSON-RPC 2.0 dispatcher is enough for the 4 tools we expose.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Mapping, Protocol


class McpError(Exception):
    """Base error for MCP server operations."""


@dataclass(frozen=True)
class JsonRpcError:
    """Standard JSON-RPC 2.0 error object."""

    code: int
    message: str
    data: Any = None

    # Standard codes from JSON-RPC 2.0 spec.
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.data is not None:
            d["data"] = self.data
        return d


@dataclass(frozen=True)
class ToolCallResult:
    """Output of a tool call.

    `content` is a list of MCP content items — typically one text item.
    `isError` flags whether the host should surface the call as failed.
    """

    content: list[dict[str, Any]] = field(default_factory=list)
    is_error: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"content": list(self.content), "isError": self.is_error}

    @classmethod
    def text(cls, msg: str, *, is_error: bool = False) -> "ToolCallResult":
        return cls(content=[{"type": "text", "text": msg}], is_error=is_error)


# Tool handlers may be sync or async; the dispatcher awaits both.
ToolHandler = Callable[[Mapping[str, Any]], Awaitable[ToolCallResult] | ToolCallResult]


@dataclass(frozen=True)
class Tool:
    """A registered MCP tool."""

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: ToolHandler

    def to_listing(self) -> dict[str, Any]:
        """Shape returned by the tools/list method."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class ToolDispatcher(Protocol):
    """Resolves a tool name to a handler. Used by the server."""

    def list_tools(self) -> list[Tool]: ...

    def get(self, name: str) -> Tool | None: ...
