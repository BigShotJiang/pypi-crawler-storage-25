"""Minimal MCP server — JSON-RPC 2.0 over stdio.

Implements the subset of MCP needed to expose tools:

    initialize                — handshake; returns capabilities
    notifications/initialized — handshake complete (no response)
    tools/list                — return all registered tools
    tools/call                — invoke a tool by name with arguments
    ping                      — heartbeat

The server reads newline-delimited JSON from stdin and writes JSON to
stdout. stderr is reserved for diagnostics.

Why not the official mcp Python SDK? Cuts a transitive dependency. The
protocol surface we need is ~150 LOC. Switching to the SDK later is
mechanical — the tool definitions are already in MCP shape.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import sys
from typing import Any, Awaitable, Optional, TextIO

from agentic_testari.mcp.registry import DefaultToolRegistry
from agentic_testari.mcp.types import (
    JsonRpcError,
    Tool,
    ToolCallResult,
    ToolDispatcher,
)


_PROTOCOL_VERSION = "2024-11-05"
_SERVER_NAME = "agentic-testari"
_SERVER_VERSION = "0.1.0"


class McpServer:
    """JSON-RPC 2.0 dispatcher with MCP method handlers."""

    def __init__(
        self,
        *,
        dispatcher: Optional[ToolDispatcher] = None,
        stdin: Optional[TextIO] = None,
        stdout: Optional[TextIO] = None,
    ):
        self._dispatcher: ToolDispatcher = dispatcher or DefaultToolRegistry()
        self._stdin = stdin if stdin is not None else sys.stdin
        self._stdout = stdout if stdout is not None else sys.stdout
        self._initialized = False

    # ---- public API ----

    async def handle_message(self, raw: str) -> Optional[dict[str, Any]]:
        """Parse one JSON-RPC message and return the response (or None for notifications)."""
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            return _error_response(
                None, JsonRpcError(JsonRpcError.PARSE_ERROR, "Invalid JSON")
            )
        return await self.dispatch(message)

    async def dispatch(self, message: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Route a parsed JSON-RPC message to its handler."""
        if not isinstance(message, dict):
            return _error_response(
                None, JsonRpcError(JsonRpcError.INVALID_REQUEST, "Not an object")
            )

        method = message.get("method")
        msg_id = message.get("id")
        params = message.get("params") or {}

        # Notifications have no id.
        is_notification = "id" not in message

        if not isinstance(method, str):
            if is_notification:
                return None
            return _error_response(
                msg_id,
                JsonRpcError(JsonRpcError.INVALID_REQUEST, "Missing method"),
            )

        try:
            result = await self._handle_method(method, params)
        except JsonRpcErrorRaised as exc:
            return _error_response(msg_id, exc.error)
        except Exception as exc:  # pragma: no cover — defensive
            return _error_response(
                msg_id,
                JsonRpcError(JsonRpcError.INTERNAL_ERROR, str(exc)),
            )

        if is_notification:
            return None

        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    async def _handle_method(
        self, method: str, params: dict[str, Any]
    ) -> Any:
        if method == "initialize":
            self._initialized = True
            return {
                "protocolVersion": _PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": {
                    "name": _SERVER_NAME,
                    "version": _SERVER_VERSION,
                },
            }
        if method == "notifications/initialized":
            self._initialized = True
            return None
        if method == "ping":
            return {}
        if method == "tools/list":
            return {"tools": [t.to_listing() for t in self._dispatcher.list_tools()]}
        if method == "tools/call":
            return await self._handle_tool_call(params)
        raise JsonRpcErrorRaised(
            JsonRpcError(JsonRpcError.METHOD_NOT_FOUND, f"Unknown method: {method}")
        )

    async def _handle_tool_call(self, params: dict[str, Any]) -> dict[str, Any]:
        name = params.get("name")
        if not isinstance(name, str):
            raise JsonRpcErrorRaised(
                JsonRpcError(JsonRpcError.INVALID_PARAMS, "Missing tool name")
            )
        tool = self._dispatcher.get(name)
        if tool is None:
            raise JsonRpcErrorRaised(
                JsonRpcError(
                    JsonRpcError.INVALID_PARAMS, f"Unknown tool: {name}"
                )
            )
        arguments = params.get("arguments") or {}
        if not isinstance(arguments, dict):
            raise JsonRpcErrorRaised(
                JsonRpcError(
                    JsonRpcError.INVALID_PARAMS,
                    "arguments must be an object",
                )
            )
        result = tool.handler(arguments)
        if inspect.isawaitable(result):
            result = await result
        if not isinstance(result, ToolCallResult):
            raise JsonRpcErrorRaised(
                JsonRpcError(
                    JsonRpcError.INTERNAL_ERROR,
                    f"Tool {name!r} returned {type(result).__name__}, "
                    "not ToolCallResult",
                )
            )
        return result.to_dict()

    # ---- main loop ----

    async def serve_forever(self) -> None:
        """Read JSON-RPC messages line-by-line from stdin until EOF."""
        loop = asyncio.get_event_loop()
        while True:
            line = await loop.run_in_executor(None, self._stdin.readline)
            if not line:
                return
            line = line.strip()
            if not line:
                continue
            response = await self.handle_message(line)
            if response is not None:
                self._stdout.write(json.dumps(response) + "\n")
                self._stdout.flush()


class JsonRpcErrorRaised(Exception):
    """Internal: control-flow exception for error responses."""

    def __init__(self, error: JsonRpcError):
        self.error = error
        super().__init__(error.message)


def _error_response(
    msg_id: Any, error: JsonRpcError
) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": msg_id,
        "error": error.to_dict(),
    }


def run_server(
    *,
    dispatcher: Optional[ToolDispatcher] = None,
    stdin: Optional[TextIO] = None,
    stdout: Optional[TextIO] = None,
) -> None:
    """Construct + run a server until stdin EOF. Blocking."""
    server = McpServer(dispatcher=dispatcher, stdin=stdin, stdout=stdout)
    asyncio.run(server.serve_forever())


def main() -> None:
    """Console-script entry point for `at-cli-mcp`."""
    run_server()


if __name__ == "__main__":
    main()
