"""MCP Server (EPIC M.5).

Exposes the harness via the Model Context Protocol so Claude Code / Cursor
/ Codex / Antigravity can drive Agentic Testari directly. Stdio transport,
JSON-RPC 2.0 wire format.

The MCP server is a thin shell over the same building blocks the CLI uses
(`agentic_testari.cli.commands.*`). Tools exposed:

    at_run             — execute a test under the harness pipeline
    at_status          — installed version, LLM binding, license state
    at_license_show    — show license activation state
    at_harness_info    — list available personas, workflows, rules, skills

Usage (in Claude Code's MCP config):

    {
      "mcpServers": {
        "agentic-testari": {
          "command": "at-cli-mcp",
          "args": []
        }
      }
    }

The `at-cli-mcp` console script is registered alongside `at-cli` and
forwards to `agentic_testari.mcp:main`.
"""

from agentic_testari.mcp.server import McpServer, main, run_server
from agentic_testari.mcp.types import (
    JsonRpcError,
    McpError,
    Tool,
    ToolCallResult,
    ToolDispatcher,
)

__all__ = [
    "McpServer",
    "main",
    "run_server",
    "Tool",
    "ToolCallResult",
    "ToolDispatcher",
    "McpError",
    "JsonRpcError",
]

__version__ = "1.0.0"
