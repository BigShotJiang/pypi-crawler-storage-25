"""Built-in tool registry — wraps the at-cli surface as MCP tools.

Each tool follows JSON-Schema (Draft 7-ish, what MCP hosts accept) for
its input and returns a ToolCallResult. Handlers are async-friendly but
many of them stay sync because the underlying CLI commands are sync.
"""

from __future__ import annotations

from typing import Any, Mapping

from agentic_testari.mcp.types import Tool, ToolCallResult


# ---- Tool definitions ----


def _tool_at_run() -> Tool:
    async def handler(args: Mapping[str, Any]) -> ToolCallResult:
        intent = args.get("intent", "").strip()
        if not intent:
            return ToolCallResult.text(
                "Error: `intent` is required.", is_error=True
            )
        # Defer to run_cmd from the CLI surface. We use a Console that
        # captures output so the MCP host receives it as text.
        from io import StringIO

        from rich.console import Console

        from agentic_testari.cli.commands.run_cmd import run_test

        buf = StringIO()
        captured = Console(file=buf, force_terminal=False, color_system=None)
        exit_code = run_test(
            console=captured,
            intent=intent,
            workflow_override=args.get("workflow"),
            acceptance_criteria=tuple(args.get("acceptance_criteria") or ()),
            raw=bool(args.get("raw", False)),
        )
        text = buf.getvalue().strip() or "(no output)"
        text += f"\n\nexit_code: {exit_code}"
        return ToolCallResult.text(text, is_error=exit_code != 0)

    return Tool(
        name="at_run",
        description=(
            "Execute a test under the AIOS harness pipeline. "
            "Routes through workflow router → constitutional gate → "
            "skill dispatch → 12-point QA gate. Returns the verdict text."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "intent": {
                    "type": "string",
                    "description": "Natural-language test intent.",
                },
                "workflow": {
                    "type": "string",
                    "enum": [
                        "express-test",
                        "full-sdc",
                        "qa-loop",
                        "spec-pipeline",
                        "brownfield-discovery",
                    ],
                    "description": "Optional workflow override.",
                },
                "acceptance_criteria": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of acceptance criteria.",
                },
                "raw": {
                    "type": "boolean",
                    "description": "Pro tier: skip harness for this single call.",
                    "default": False,
                },
            },
            "required": ["intent"],
        },
        handler=handler,
    )


def _tool_at_status() -> Tool:
    def handler(args: Mapping[str, Any]) -> ToolCallResult:
        from agentic_testari.cli.commands.status_cmd import build_status_report

        report = build_status_report()
        lines = [f"{k}: {v}" for k, v in report.items()]
        return ToolCallResult.text("\n".join(lines))

    return Tool(
        name="at_status",
        description=(
            "Show installed agentic-testari version, configured LLM "
            "binding, license activation state, and storage mode."
        ),
        input_schema={"type": "object", "properties": {}},
        handler=handler,
    )


def _tool_at_license_show() -> Tool:
    def handler(args: Mapping[str, Any]) -> ToolCallResult:
        from agentic_testari import LicenseKeyStore
        from agentic_testari.keychain import KeychainBackendUnavailable

        try:
            lic = LicenseKeyStore()
        except KeychainBackendUnavailable:
            return ToolCallResult.text(
                "No OS keychain available — license cannot be persisted."
            )
        if not lic.is_activated():
            return ToolCallResult.text("Not activated.")
        token = lic.get_token() or ""
        preview = (
            f"{token[:8]}...{token[-4:]}" if len(token) > 12 else "[short token]"
        )
        return ToolCallResult.text(
            "Activated\n"
            f"  token preview: {preview}\n"
            f"  activation_id: {lic.get('activation_id') or '[unset]'}\n"
            f"  last_validated: {lic.get('last_validated') or '[unset]'}"
        )

    return Tool(
        name="at_license_show",
        description=(
            "Show license activation state. Never returns the raw token — "
            "only a preview."
        ),
        input_schema={"type": "object", "properties": {}},
        handler=handler,
    )


def _tool_at_harness_info() -> Tool:
    def handler(args: Mapping[str, Any]) -> ToolCallResult:
        from agentic_testari import HarnessLoader
        from agentic_testari.harness.skills import SkillRegistry

        loader = HarnessLoader()
        skills = SkillRegistry()
        lines = [
            f"personas:    {len(loader.list_personas())} ({', '.join(loader.list_personas()[:5])}...)",
            f"workflows:   {len(loader.list_workflows())} ({', '.join(loader.list_workflows()[:5])}...)",
            f"rules:       {len(loader.list_rules())}",
            f"templates:   {len(loader.list_templates())}",
            f"checklists:  {len(loader.list_checklists())}",
            f"tasks:       {len(loader.list_tasks())}",
            f"skills:      {len(skills.list_ids())} ({', '.join(skills.list_ids()[:5])}...)",
            f"bundle root: {loader.bundle_root}",
        ]
        return ToolCallResult.text("\n".join(lines))

    return Tool(
        name="at_harness_info",
        description=(
            "List the AIOS resources available to the harness: personas, "
            "workflows, rules, templates, checklists, tasks, skills."
        ),
        input_schema={"type": "object", "properties": {}},
        handler=handler,
    )


# ---- Registry ----


class DefaultToolRegistry:
    """Built-in registry — 4 tools wrapping the at-cli surface."""

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}
        for factory in (
            _tool_at_run,
            _tool_at_status,
            _tool_at_license_show,
            _tool_at_harness_info,
        ):
            tool = factory()
            self._tools[tool.name] = tool

    def list_tools(self) -> list[Tool]:
        return sorted(self._tools.values(), key=lambda t: t.name)

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def register(self, tool: Tool) -> None:
        """Register a custom tool. Overrides any existing tool with the same name."""
        self._tools[tool.name] = tool
