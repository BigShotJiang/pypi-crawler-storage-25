"""Concrete key stores — ApiKeyStore + LicenseKeyStore.

These are thin specialisations of KeyStore with fixed namespaces and
typed conveniences. Adding a new store is one subclass + a namespace
constant.
"""

from __future__ import annotations

from typing import Optional

from agents._shared.keychain.keystore import KeyStore, NullKeyStore, _detect_backend_available
from agents._shared.keychain.types import KeychainBackendUnavailable


class ApiKeyStore(KeyStore):
    """User-supplied LLM API keys (BYO key path).

    Standard keys (convention, not enforced):
        openai      — OPENAI_API_KEY equivalent
        anthropic   — ANTHROPIC_API_KEY equivalent
        azure       — Azure OpenAI key
        custom_*    — user-defined providers
    """

    namespace = "api-keys"

    def get_openai(self) -> Optional[str]:
        return self.get("openai")

    def get_anthropic(self) -> Optional[str]:
        return self.get("anthropic")

    def get_azure(self) -> Optional[str]:
        return self.get("azure")

    def has_any(self) -> bool:
        """True if at least one of the canonical providers has a key."""
        return any(
            self.has(p) for p in ("openai", "anthropic", "azure")
        )


class LicenseKeyStore(KeyStore):
    """License token + activation metadata (M.7 / EPIC O).

    Canonical keys:
        license_token    — signed JWT-ish token from the license server
        activation_id    — opaque id used in heartbeat calls
        hardware_id      — derived hardware fingerprint
        last_validated   — ISO timestamp of last successful heartbeat
    """

    namespace = "license"

    def get_token(self) -> Optional[str]:
        return self.get("license_token")

    def set_token(self, token: str) -> None:
        self.set("license_token", token)

    def clear_all(self) -> None:
        """Wipe all license fields — used on revocation / sign-out."""
        for k in ("license_token", "activation_id", "hardware_id", "last_validated"):
            self.delete(k)

    def is_activated(self) -> bool:
        return self.has("license_token") and self.has("activation_id")


def get_default_keystore(namespace: str = "default") -> KeyStore:
    """Return a KeyStore for `namespace`, falling back to NullKeyStore.

    Use this in callers that should not crash on a headless host.
    """
    try:
        return KeyStore(namespace=namespace)
    except KeychainBackendUnavailable:
        return NullKeyStore(namespace=namespace)
