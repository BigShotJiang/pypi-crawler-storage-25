"""Tests for the keychain wrapper.

Uses an in-memory monkeypatched keyring backend so tests never touch the
real OS credential store.
"""

from __future__ import annotations

import pytest

from agents._shared.keychain import (
    ApiKeyStore,
    KeyMetadata,
    KeychainBackendUnavailable,
    KeyNotFoundError,
    KeyStore,
    LicenseKeyStore,
    NullKeyStore,
    get_default_keystore,
)


# ---- in-memory keyring ----


class _InMemoryBackend:
    """Replaces keyring.get_keyring() with an in-memory dict store."""

    priority = 5

    def __init__(self):
        self._store: dict[tuple[str, str], str] = {}

    def get_password(self, service, username):
        return self._store.get((service, username))

    def set_password(self, service, username, password):
        self._store[(service, username)] = password

    def delete_password(self, service, username):
        if (service, username) not in self._store:
            from keyring.errors import PasswordDeleteError

            raise PasswordDeleteError("not found")
        del self._store[(service, username)]


@pytest.fixture
def memory_keyring(monkeypatch):
    """Patch the active keyring with an in-memory backend.

    Also force `_detect_backend_available` to return True so KeyStore
    doesn't refuse to construct.
    """
    import keyring

    backend = _InMemoryBackend()
    monkeypatch.setattr(keyring, "get_keyring", lambda: backend)
    monkeypatch.setattr(keyring, "set_password", backend.set_password)
    monkeypatch.setattr(keyring, "get_password", backend.get_password)
    monkeypatch.setattr(keyring, "delete_password", backend.delete_password)

    # Tell KeyStore the backend is available even though we monkey-patched.
    from agents._shared.keychain import keystore as ks_module

    monkeypatch.setattr(ks_module, "_detect_backend_available", lambda: True)
    return backend


# ---- KeyStore basics ----


def test_keystore_set_get_roundtrip(memory_keyring):
    store = KeyStore(namespace="test-1")
    store.set("foo", "bar")
    assert store.get("foo") == "bar"


def test_keystore_get_returns_none_for_missing(memory_keyring):
    store = KeyStore(namespace="test-2")
    assert store.get("missing") is None


def test_keystore_set_overwrites(memory_keyring):
    store = KeyStore(namespace="test-3")
    store.set("k", "v1")
    store.set("k", "v2")
    assert store.get("k") == "v2"


def test_keystore_delete_returns_true_when_present(memory_keyring):
    store = KeyStore(namespace="test-4")
    store.set("k", "v")
    assert store.delete("k") is True
    assert store.get("k") is None


def test_keystore_delete_returns_false_when_absent(memory_keyring):
    store = KeyStore(namespace="test-5")
    assert store.delete("missing") is False


def test_keystore_has(memory_keyring):
    store = KeyStore(namespace="test-6")
    assert store.has("k") is False
    store.set("k", "v")
    assert store.has("k") is True


def test_keystore_metadata(memory_keyring):
    store = KeyStore(namespace="test-7")
    store.set("k", "v")
    meta = store.metadata("k")
    assert isinstance(meta, KeyMetadata)
    assert meta.namespace == "test-7"
    assert meta.key == "k"
    assert meta.present is True


def test_keystore_require_raises_on_missing(memory_keyring):
    store = KeyStore(namespace="test-8")
    with pytest.raises(KeyNotFoundError):
        store.require("missing")


def test_keystore_require_returns_value(memory_keyring):
    store = KeyStore(namespace="test-9")
    store.set("k", "secret")
    assert store.require("k") == "secret"


def test_keystore_require_treats_empty_as_missing(memory_keyring):
    store = KeyStore(namespace="test-10")
    store.set("k", "")
    with pytest.raises(KeyNotFoundError):
        store.require("k")


# ---- namespace isolation ----


def test_namespaces_do_not_collide(memory_keyring):
    a = KeyStore(namespace="ns-A")
    b = KeyStore(namespace="ns-B")
    a.set("shared", "alpha")
    b.set("shared", "beta")
    assert a.get("shared") == "alpha"
    assert b.get("shared") == "beta"


def test_service_name_uses_agtestari_prefix(memory_keyring):
    """Stored items must land under `agtestari.{namespace}`."""
    store = KeyStore(namespace="ns-X")
    store.set("k", "v")
    assert ("agtestari.ns-X", "k") in memory_keyring._store


# ---- ApiKeyStore ----


def test_api_key_store_default_namespace():
    """Construction may fail without a backend, so just check the class attr."""
    assert ApiKeyStore.namespace == "api-keys"


def test_api_key_store_canonical_providers(memory_keyring):
    api = ApiKeyStore()
    assert api.get_openai() is None
    assert api.has_any() is False
    api.set("openai", "sk-test")
    assert api.get_openai() == "sk-test"
    assert api.has_any() is True


def test_api_key_store_anthropic(memory_keyring):
    api = ApiKeyStore()
    api.set("anthropic", "ant-test")
    assert api.get_anthropic() == "ant-test"


def test_api_key_store_azure(memory_keyring):
    api = ApiKeyStore()
    api.set("azure", "az-test")
    assert api.get_azure() == "az-test"


# ---- LicenseKeyStore ----


def test_license_key_store_namespace():
    assert LicenseKeyStore.namespace == "license"


def test_license_set_and_get_token(memory_keyring):
    lic = LicenseKeyStore()
    lic.set_token("lic-jwt")
    assert lic.get_token() == "lic-jwt"


def test_license_is_activated_requires_both_fields(memory_keyring):
    lic = LicenseKeyStore()
    assert not lic.is_activated()
    lic.set_token("t")
    assert not lic.is_activated()
    lic.set("activation_id", "act-1")
    assert lic.is_activated()


def test_license_clear_all_removes_every_field(memory_keyring):
    lic = LicenseKeyStore()
    lic.set("license_token", "t")
    lic.set("activation_id", "a")
    lic.set("hardware_id", "h")
    lic.set("last_validated", "2026-04-28T00:00:00Z")
    lic.clear_all()
    assert lic.get_token() is None
    assert lic.get("activation_id") is None
    assert lic.get("hardware_id") is None
    assert lic.get("last_validated") is None


# ---- NullKeyStore ----


def test_null_keystore_get_returns_none():
    null = NullKeyStore(namespace="x")
    assert null.get("anything") is None


def test_null_keystore_set_silently_noops():
    null = NullKeyStore(namespace="x")
    null.set("k", "v")
    assert null.get("k") is None


def test_null_keystore_delete_returns_false():
    null = NullKeyStore(namespace="x")
    assert null.delete("k") is False


def test_null_keystore_does_not_require_backend():
    """NullKeyStore must construct even if no real backend is available."""
    NullKeyStore(namespace="x")  # no exception


# ---- get_default_keystore ----


def test_get_default_keystore_returns_real_store_when_backend_present(
    memory_keyring,
):
    store = get_default_keystore("ns-Y")
    assert isinstance(store, KeyStore)
    assert not isinstance(store, NullKeyStore)


def test_get_default_keystore_falls_back_to_null(monkeypatch):
    """When no backend is available, return NullKeyStore."""
    from agents._shared.keychain import keystore as ks_module

    monkeypatch.setattr(ks_module, "_detect_backend_available", lambda: False)
    store = get_default_keystore("ns-Z")
    assert isinstance(store, NullKeyStore)


def test_keystore_raises_when_backend_unavailable(monkeypatch):
    from agents._shared.keychain import keystore as ks_module

    monkeypatch.setattr(ks_module, "_detect_backend_available", lambda: False)
    with pytest.raises(KeychainBackendUnavailable):
        KeyStore(namespace="x")


# ---- real backend smoke (Windows/macOS/Linux dependent) ----


def test_real_backend_detection_smoke():
    """The host OS should have a real keychain backend available.

    On CI without a backend, this is allowed to skip.
    """
    from agents._shared.keychain.keystore import _detect_backend_available

    if not _detect_backend_available():
        pytest.skip("No OS keychain available on this host")
    # Just confirm we can construct without exception.
    KeyStore(namespace="agtestari-smoke")
