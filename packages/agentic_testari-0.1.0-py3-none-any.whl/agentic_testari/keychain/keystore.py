"""Base KeyStore — thin wrapper around `keyring`.

Handles namespacing (so two agents storing `api_key` don't collide),
backend availability detection, and graceful degradation. Concrete
stores (ApiKeyStore, LicenseKeyStore) just specify their namespace.

Backend detection:
    - `keyring` not importable        → NullKeyStore (no-op + warn)
    - `keyring.backends.fail`         → NullKeyStore
    - `keyring.backends.null`         → NullKeyStore
    - any working backend             → real store

The Null variant lets the harness still run on headless CI without
crashing every read; callers get None and can decide whether to fail
hard or fall back to env vars.
"""

from __future__ import annotations

import logging
from typing import Optional

from agents._shared.keychain.types import (
    KeyMetadata,
    KeyNotFoundError,
    KeychainBackendUnavailable,
)

logger = logging.getLogger(__name__)


_SERVICE_PREFIX = "agtestari"


def _service_name(namespace: str) -> str:
    """Build the keyring `service` string for a namespace."""
    return f"{_SERVICE_PREFIX}.{namespace}"


def _detect_backend_available() -> bool:
    """Return True iff a usable keyring backend is present."""
    try:
        import keyring
        from keyring.backends import fail as _fail_module
    except ImportError:
        return False
    try:
        active = keyring.get_keyring()
    except Exception:
        return False
    # The `fail` backend is what keyring returns when no real backend exists.
    if isinstance(active, _fail_module.Keyring):
        return False
    # Also reject any backend whose class name starts with "Null"/"Fail".
    name = active.__class__.__name__.lower()
    if name.startswith(("null", "fail")):
        return False
    return True


class KeyStore:
    """Namespaced key/value store backed by the OS keychain.

    Construct with a `namespace`; all reads/writes are scoped to that
    namespace via the keyring service name `agtestari.{namespace}`.
    """

    namespace: str = "default"

    def __init__(self, namespace: Optional[str] = None):
        if namespace is not None:
            self.namespace = namespace
        if not _detect_backend_available():
            raise KeychainBackendUnavailable(
                "No usable OS keychain backend detected. Use NullKeyStore "
                "for headless environments or install a system keyring "
                "(e.g., gnome-keyring on Linux)."
            )

    # ---- public API ----

    def get(self, key: str) -> Optional[str]:
        """Return the value for `key`, or None if absent."""
        import keyring

        try:
            return keyring.get_password(_service_name(self.namespace), key)
        except Exception as exc:
            logger.warning(
                "keyring read failed (namespace=%s key=%s): %s",
                self.namespace,
                key,
                exc,
            )
            return None

    def require(self, key: str) -> str:
        """Like `get()` but raises KeyNotFoundError if absent or empty."""
        value = self.get(key)
        if not value:
            raise KeyNotFoundError(self.namespace, key)
        return value

    def set(self, key: str, value: str) -> None:
        """Store `value` under `key`. Idempotent overwrite."""
        import keyring

        keyring.set_password(_service_name(self.namespace), key, value)

    def delete(self, key: str) -> bool:
        """Remove `key`. Returns True if deleted, False if absent."""
        import keyring

        try:
            keyring.delete_password(_service_name(self.namespace), key)
            return True
        except Exception:
            return False

    def has(self, key: str) -> bool:
        return self.get(key) is not None

    def metadata(self, key: str) -> KeyMetadata:
        return KeyMetadata(
            namespace=self.namespace, key=key, present=self.has(key)
        )


class NullKeyStore(KeyStore):
    """Drop-in replacement when no OS keychain is available.

    All `get()` calls return None. `set()` and `delete()` are no-ops with
    a one-time warning. Useful in CI / Docker / headless environments
    where the harness must not crash on missing keychain.
    """

    _warned: bool = False

    def __init__(self, namespace: Optional[str] = None):
        # Bypass the parent's backend check.
        if namespace is not None:
            self.namespace = namespace

    def _warn_once(self) -> None:
        if not type(self)._warned:
            logger.warning(
                "KeyStore running in NULL mode — values are not persisted. "
                "Install an OS keychain to enable storage."
            )
            type(self)._warned = True

    def get(self, key: str) -> Optional[str]:
        return None

    def set(self, key: str, value: str) -> None:
        self._warn_once()

    def delete(self, key: str) -> bool:
        return False
