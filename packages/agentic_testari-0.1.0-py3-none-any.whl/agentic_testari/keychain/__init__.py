"""OS Keychain integration (EPIC M.3).

Wraps the `keyring` library to store/retrieve sensitive material in the
host OS's native credential store:

    macOS    → Keychain
    Linux    → Secret Service (GNOME Keyring / KWallet)
    Windows  → Credential Locker (WinVault)

Two stores ship by default:

    LicenseKeyStore   — license token + activation metadata (M.7 / EPIC O)
    ApiKeyStore       — user-supplied LLM API keys (BYO key path)

Both share a KeyStore base, namespace items per agent, and degrade
gracefully when no OS backend is available (returns None on get, no-ops
on set with a warning).

Usage:
    from agents._shared.keychain import (
        ApiKeyStore, LicenseKeyStore, get_default_keystore,
    )

    api = ApiKeyStore()
    api.set("openai", "sk-...")
    key = api.get("openai")
    api.delete("openai")

    lic = LicenseKeyStore()
    lic.set("license_token", "...")
    lic.get("license_token")
"""

from agents._shared.keychain.stores import (
    ApiKeyStore,
    LicenseKeyStore,
    get_default_keystore,
)
from agents._shared.keychain.types import (
    KeychainBackendUnavailable,
    KeychainError,
    KeyMetadata,
    KeyNotFoundError,
)
from agents._shared.keychain.keystore import KeyStore, NullKeyStore

__all__ = [
    "KeyStore",
    "NullKeyStore",
    "ApiKeyStore",
    "LicenseKeyStore",
    "get_default_keystore",
    "KeyMetadata",
    "KeychainError",
    "KeychainBackendUnavailable",
    "KeyNotFoundError",
]

__version__ = "1.0.0"
