"""Keychain types + errors."""

from __future__ import annotations

from dataclasses import dataclass


class KeychainError(Exception):
    """Base error for keychain operations."""


class KeychainBackendUnavailable(KeychainError):
    """Raised when no usable OS keychain backend is present."""


class KeyNotFoundError(KeychainError):
    """Raised by `.require()` when a key is not present."""

    def __init__(self, namespace: str, key: str):
        self.namespace = namespace
        self.key = key
        super().__init__(f"Key {namespace}/{key!r} not found")


@dataclass(frozen=True)
class KeyMetadata:
    """Lightweight metadata about a stored key (no secret value)."""

    namespace: str
    key: str
    present: bool
