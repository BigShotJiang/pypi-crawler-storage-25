"""License client — HTTP wrapper around the Cloudflare Worker endpoints.

Sync wrapper preferred over async here so the CLI doesn't need to spin
up an event loop just to validate a license. Internally uses `httpx`
which supports both modes.

Endpoints (Cloudflare Worker @ workers/license-server/):
    POST /v1/license/activate
    POST /v1/license/heartbeat
    POST /v1/license/revoke

All requests carry the license_token in the Authorization header
(`Bearer <token>`) and the hardware_id in the JSON body.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import httpx


_DEFAULT_BASE_URL = "https://license.agentictestari.com"
_DEFAULT_TIMEOUT_SECONDS = 10.0


class LicenseError(Exception):
    """Base error for license-server interactions."""


class LicenseRevoked(LicenseError):
    """Raised when the server reports the license has been revoked."""


@dataclass(frozen=True)
class ActivationResponse:
    activation_id: str
    expires_at: str  # ISO8601
    tier: str        # 'pro' | 'enterprise' | 'trial'
    seats_used: int
    seats_total: int


@dataclass(frozen=True)
class HeartbeatResponse:
    ok: bool
    revoked: bool
    last_seen: str   # ISO8601
    tier: str


class LicenseClient:
    """Thin HTTP client. Construct once per process and reuse."""

    def __init__(
        self,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT_SECONDS,
        client: Optional[httpx.Client] = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client = client

    def _http(self) -> httpx.Client:
        if self._client is not None:
            return self._client
        return httpx.Client(
            base_url=self._base_url,
            timeout=self._timeout,
            headers={"User-Agent": "agentic-testari-cli/0.1.0"},
        )

    @staticmethod
    def _auth(token: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {token}"}

    # ---- public API ----

    def activate(self, *, token: str, hardware_id: str) -> ActivationResponse:
        """Bind the license to this machine. Returns activation metadata."""
        resp = self._http().post(
            "/v1/license/activate",
            headers=self._auth(token),
            json={"hardware_id": hardware_id},
        )
        if resp.status_code == 410:
            raise LicenseRevoked(self._error_text(resp, "license revoked"))
        if resp.status_code >= 400:
            raise LicenseError(self._error_text(resp, "activation failed"))
        body = resp.json()
        return ActivationResponse(
            activation_id=body["activation_id"],
            expires_at=body["expires_at"],
            tier=body.get("tier", "pro"),
            seats_used=int(body.get("seats_used", 1)),
            seats_total=int(body.get("seats_total", 1)),
        )

    def heartbeat(
        self, *, token: str, activation_id: str, hardware_id: str
    ) -> HeartbeatResponse:
        """Periodic liveness check. Server returns revoked=True if revoked."""
        resp = self._http().post(
            "/v1/license/heartbeat",
            headers=self._auth(token),
            json={
                "activation_id": activation_id,
                "hardware_id": hardware_id,
            },
        )
        if resp.status_code == 410:
            return HeartbeatResponse(
                ok=False, revoked=True, last_seen="", tier=""
            )
        if resp.status_code >= 400:
            raise LicenseError(self._error_text(resp, "heartbeat failed"))
        body = resp.json()
        return HeartbeatResponse(
            ok=bool(body.get("ok", True)),
            revoked=bool(body.get("revoked", False)),
            last_seen=body.get("last_seen", ""),
            tier=body.get("tier", "pro"),
        )

    def revoke(self, *, token: str, activation_id: str) -> None:
        """Voluntarily release the activation slot (for re-binding)."""
        resp = self._http().post(
            "/v1/license/revoke",
            headers=self._auth(token),
            json={"activation_id": activation_id},
        )
        if resp.status_code >= 400 and resp.status_code != 410:
            raise LicenseError(self._error_text(resp, "revoke failed"))

    # ---- helpers ----

    @staticmethod
    def _error_text(resp: httpx.Response, default: str) -> str:
        try:
            body = resp.json()
            return str(body.get("message") or body.get("error") or default)
        except Exception:
            return default
