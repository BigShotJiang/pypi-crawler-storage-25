"""Stable hardware fingerprint for license binding.

Derives a hex digest from machine identifiers that:
  - Stay stable across reboots and OS upgrades
  - Don't change when the user reinstalls the OS (best effort)
  - Can be regenerated on a fresh install (the user re-activates)

The fingerprint is INTENTIONALLY coarse — we want license binding, not
fingerprinting for tracking. The hash uses platform + node + a stable
disk identifier. No network MACs, no UUID-from-hardware.

Returned as a 32-char SHA-256 prefix so it fits comfortably in URLs
and headers.
"""

from __future__ import annotations

import hashlib
import platform
import socket
import sys


def _candidates() -> list[str]:
    """Collect platform-stable identifiers."""
    parts: list[str] = [
        platform.system(),  # 'Windows', 'Darwin', 'Linux'
        platform.machine(),  # 'AMD64', 'arm64', 'x86_64'
        sys.platform,
    ]
    try:
        parts.append(socket.gethostname())
    except OSError:
        parts.append("unknown-host")
    # platform.node() is sometimes empty — guard.
    node = platform.node() or "unknown-node"
    parts.append(node)
    return parts


def hardware_id() -> str:
    """Return a 32-character hex digest unique to this machine.

    NOT a guarantee of uniqueness in a virtualised fleet (two VMs cloned
    from the same image will share). Combined with the activation flow,
    this is sufficient for the per-seat license model.
    """
    raw = "::".join(_candidates()).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:32]
