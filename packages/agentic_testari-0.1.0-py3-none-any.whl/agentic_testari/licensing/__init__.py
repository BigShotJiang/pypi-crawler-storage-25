"""License flow (EPIC M.7).

Client-side license validation against the Cloudflare Worker license
server. The worker (deployed at `https://license.agentictestari.com`)
exposes three endpoints:

    POST /v1/license/activate    — exchange license_token + hardware_id
                                    for an activation_id (one-time bind)
    POST /v1/license/heartbeat   — periodic liveness check; returns
                                    revoked=True if the license has been
                                    revoked since last call
    POST /v1/license/revoke      — explicit revocation (admin / user
                                    self-service)

The CLI invokes this client during `at-cli license activate <token>` and
periodically while running tests. Activation state lives in the OS
keychain (LicenseKeyStore from M.3); the worker is the source of truth.

Usage:
    from agentic_testari.licensing import LicenseClient, hardware_id

    client = LicenseClient(base_url="https://license.agentictestari.com")
    activation = await client.activate(
        token="lic-jwt",
        hardware_id=hardware_id(),
    )
    # activation.activation_id, activation.expires_at, activation.tier
"""

from agentic_testari.licensing.client import (
    ActivationResponse,
    HeartbeatResponse,
    LicenseClient,
    LicenseError,
    LicenseRevoked,
)
from agentic_testari.licensing.hardware import hardware_id

__all__ = [
    "LicenseClient",
    "ActivationResponse",
    "HeartbeatResponse",
    "LicenseError",
    "LicenseRevoked",
    "hardware_id",
]

__version__ = "1.0.0"
