"""Local Dashboard (EPIC M.8).

Lightweight FastAPI app that runs alongside `at-cli` and exposes:

    GET  /                  static HTML dashboard (tabs: Runs / Approvals / License)
    GET  /api/health        liveness check
    GET  /api/status        version + LLM binding + license + storage mode
    GET  /api/verdicts      recent verdicts from M.1 storage
    GET  /api/approvals     pending HITL approvals from EPIC P
    POST /api/approvals/{id}/resolve   { status, decided_by, reason }

Started via `at-cli dashboard --port 8765` (or programmatically via
`run_dashboard()`). Uses the same harness modules as the CLI; no
duplicate logic.

The UI is a single static HTML file — no React, no build step. Pure
fetch() calls + minimal vanilla JS. Customers don't need npm to run it.
"""

from agentic_testari.dashboard.app import create_app, run_dashboard

__all__ = ["create_app", "run_dashboard"]

__version__ = "1.0.0"
