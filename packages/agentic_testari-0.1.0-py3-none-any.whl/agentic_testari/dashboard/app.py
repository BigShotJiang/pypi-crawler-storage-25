"""FastAPI app + endpoints for the local dashboard."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from agentic_testari import __version__


_STATIC_DIR = Path(__file__).resolve().parent / "static"


class ResolveRequest(BaseModel):
    status: str
    decided_by: Optional[str] = None
    reason: str = ""


def create_app(*, approval_engine: Any | None = None) -> FastAPI:
    """Build the dashboard FastAPI app.

    `approval_engine` lets callers inject an existing
    `ApprovalEngine` instance so the dashboard sees the same pending
    approvals as a running workflow-engine. Default: a fresh engine
    (useful for tests / standalone smoke).
    """
    from agents._shared.harness.approvals import (
        ApprovalEngine,
        ApprovalNotFoundError,
        ApprovalStatus,
    )

    app = FastAPI(
        title="Agentic Testari — Local Dashboard",
        version=__version__,
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
    )

    engine: ApprovalEngine = approval_engine or ApprovalEngine()
    app.state.approval_engine = engine

    # ---- HTML ----

    @app.get("/", response_class=HTMLResponse)
    async def index() -> HTMLResponse:
        index_file = _STATIC_DIR / "index.html"
        if not index_file.is_file():
            return HTMLResponse(
                "<h1>Agentic Testari Dashboard</h1>"
                "<p>Static assets missing — reinstall the wheel.</p>",
                status_code=200,
            )
        return HTMLResponse(index_file.read_text(encoding="utf-8"))

    # ---- API ----

    @app.get("/api/health")
    async def health() -> dict[str, Any]:
        return {"ok": True, "version": __version__}

    @app.get("/api/status")
    async def status_endpoint() -> dict[str, Any]:
        from agentic_testari.cli.commands.status_cmd import build_status_report

        report = build_status_report()
        return {k: str(v) for k, v in report.items()}

    @app.get("/api/verdicts")
    async def verdicts(limit: int = 20) -> dict[str, Any]:
        try:
            from agentic_testari import get_storage

            storage = get_storage()
            items = await storage.verdicts.list_recent(
                org_id="local", limit=max(1, min(limit, 100))
            )
            return {"verdicts": items}
        except Exception as exc:
            return {"verdicts": [], "error": str(exc)}

    @app.get("/api/approvals")
    async def approvals() -> dict[str, Any]:
        pending = engine.list_pending()
        return {
            "pending": [
                {
                    "request_id": r.request_id,
                    "run_id": r.run_id,
                    "title": r.title,
                    "message": r.message,
                    "approvers": list(r.approvers),
                    "expires_at": r.expires_at.isoformat(),
                    "created_at": r.created_at.isoformat(),
                }
                for r in pending
            ]
        }

    @app.post("/api/approvals/{request_id}/resolve")
    async def resolve_approval(
        request_id: str, body: ResolveRequest
    ) -> dict[str, Any]:
        try:
            target = ApprovalStatus(body.status.lower())
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"invalid status; expected one of: "
                    f"{[s.value for s in ApprovalStatus]}"
                ),
            )
        if target is ApprovalStatus.PENDING:
            raise HTTPException(
                status_code=400, detail="cannot resolve to PENDING"
            )
        try:
            response = engine.resolve(
                request_id,
                target,
                decided_by=body.decided_by,
                reason=body.reason,
            )
        except ApprovalNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        return {
            "request_id": response.request_id,
            "status": response.status.value,
            "decided_by": response.decided_by,
            "reason": response.reason,
            "decided_at": response.decided_at.isoformat(),
        }

    @app.get("/api/license")
    async def license_state() -> dict[str, Any]:
        from agentic_testari import LicenseKeyStore
        from agentic_testari.keychain import KeychainBackendUnavailable

        try:
            lic = LicenseKeyStore()
        except KeychainBackendUnavailable:
            return {"available": False, "activated": False}
        if not lic.is_activated():
            return {"available": True, "activated": False}
        token = lic.get_token() or ""
        return {
            "available": True,
            "activated": True,
            "tier": lic.get("tier"),
            "activation_id": lic.get("activation_id"),
            "last_validated": lic.get("last_validated"),
            "token_preview": (
                f"{token[:8]}...{token[-4:]}" if len(token) > 12 else "[short]"
            ),
        }

    return app


def run_dashboard(*, host: str = "127.0.0.1", port: int = 8765) -> None:
    """Blocking — start uvicorn for the local dashboard."""
    import uvicorn

    uvicorn.run(create_app(), host=host, port=port, log_level="info")
