"""Push local sessions to the MethodProof platform."""

import json
import urllib.error
import urllib.request
from typing import Any

from methodproof import store


def sync_metadata(session: dict[str, Any], token: str, api_url: str) -> None:
    """Sync repo, tags, and visibility for an already-pushed session."""
    remote_id = session.get("remote_id")
    if not remote_id:
        return
    repo_url = session.get("repo_url")
    if repo_url:
        _request("POST", f"/sessions/{remote_id}/repos", api_url, token,
                 {"remote_url": repo_url, "detected_by": "cli"})
    tags = json.loads(session.get("tags") or "[]")
    if tags:
        _request("PUT", f"/sessions/{remote_id}/tags", api_url, token,
                 {"tags": tags})
    if session.get("visibility") == "public":
        _request("PUT", f"/sessions/{remote_id}/visibility", api_url, token,
                 {"visibility": "public"})


def _raw_request(
    method: str, url: str, token: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    data = json.dumps(body).encode() if body else None
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _refresh_token(api_url: str, refresh: str) -> tuple[str, str] | None:
    """Exchange refresh token for new access + refresh tokens. Returns None on failure."""
    try:
        result = _raw_request("POST", f"{api_url}/auth/refresh", "", {"refresh_token": refresh})
        return result["access_token"], result["refresh_token"]
    except Exception:
        return None


def _request(
    method: str, path: str, api_url: str, token: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    url = f"{api_url}{path}"
    try:
        return _raw_request(method, url, token, body)
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            from methodproof import config
            cfg = config.load()
            refresh = cfg.get("refresh_token", "")
            if refresh:
                pair = _refresh_token(api_url, refresh)
                if pair:
                    cfg["token"], cfg["refresh_token"] = pair
                    config.save(cfg)
                    return _raw_request(method, url, cfg["token"], body)
            raise SystemExit("Session expired. Run `methodproof login` to re-authenticate.") from None
        detail = ""
        if exc.fp:
            try:
                detail = json.loads(exc.read()).get("detail", "")
            except Exception:
                pass
        raise SystemExit(f"API error {exc.code}: {detail}") from None


def push(session_id: str, token: str, api_url: str) -> None:
    """Upload a local session to the platform."""
    session = store.get_session(session_id)
    if not session:
        raise SystemExit(f"Session not found: {session_id}")
    if session["synced"]:
        print(f"Already synced: {session_id[:8]}")
        return

    # Create remote session
    print("Creating remote session...", end=" ", flush=True)
    result = _request("POST", "/personal/sessions", api_url, token)
    remote_id = result["session_id"]
    print(f"done ({remote_id[:8]})")

    # Upload events in batches (with hash chain if available)
    events = store.get_events(session_id)
    event_hashes = store.get_event_hashes(session_id)
    hash_lookup = {h["event_id"]: h["hash"] for h in event_hashes}
    total = len(events)
    for i in range(0, total, 100):
        batch = events[i:i + 100]
        payload = [{"id": e["id"], "type": e["type"],
                     "timestamp": _iso(e["timestamp"]),
                     "timestamp_raw": e["timestamp"],
                     "duration_ms": int(e["duration_ms"]),
                     "metadata": json.loads(e["metadata"]),
                     "hash": hash_lookup.get(e["id"], "")}
                    for e in batch]
        _request("POST", f"/sessions/{remote_id}/events", api_url, token,
                 {"events": payload})
        done = min(i + 100, total)
        print(f"\r  Uploading: {done}/{total} events", end="", flush=True)
    print()

    # Attestation (if signing key available)
    from methodproof.integrity import has_keypair
    if has_keypair() and event_hashes:
        try:
            import hashlib as _hl
            from methodproof.integrity import sign_attestation, compute_binary_hash, get_public_key_pem
            from methodproof import __version__
            root_hash = event_hashes[0]["hash"]
            leaf_hash = event_hashes[-1]["hash"]
            binary_hash = compute_binary_hash()
            signature = sign_attestation(
                session_id, root_hash, leaf_hash, total, __version__, binary_hash,
            )
            pub_pem = get_public_key_pem().decode()
            fp = _hl.sha256(pub_pem.encode()).hexdigest()
            try:
                _request("POST", "/personal/signing-keys", api_url, token,
                         {"public_key_pem": pub_pem, "fingerprint": fp})
            except SystemExit:
                pass  # 409 = already registered
            _request("POST", f"/sessions/{remote_id}/attestation", api_url, token, {
                "session_id": session_id, "root_hash": root_hash, "leaf_hash": leaf_hash,
                "event_count": total, "cli_version": __version__, "binary_hash": binary_hash,
                "signature": signature, "key_fingerprint": fp,
            })
            print(f"  Attestation: signed ({fp[:8]})")
        except ImportError:
            pass  # cryptography not installed

    # Complete
    _request("PUT", f"/personal/sessions/{remote_id}/complete", api_url, token)
    store.mark_synced(session_id, remote_id)

    # Sync metadata (repo, tags, visibility)
    session["remote_id"] = remote_id
    sync_metadata(session, token, api_url)

    print(f"Pushed: {session_id[:8]} -> {api_url}")


def _iso(ts: float) -> str:
    from datetime import datetime, UTC
    return datetime.fromtimestamp(ts, tz=UTC).isoformat()
