"""Tests for replication.enabled helper (Discussion #23 A.5 / OQ1)."""
from __future__ import annotations

import pytest

from forge_manager_mcp.replication import enabled as en


class TestIsEnabled:
    def test_missing_field_defaults_true(self):
        assert en.is_enabled({}) is True

    def test_none_value_defaults_true(self):
        assert en.is_enabled({"enabled": None}) is True

    def test_true_returns_true(self):
        assert en.is_enabled({"enabled": True}) is True

    def test_false_returns_false(self):
        assert en.is_enabled({"enabled": False}) is False

    def test_truthy_non_bool_coerces(self):
        """Permissive read-time coercion — configs that supply non-bools
        get the conventional truthiness mapping rather than a schema
        error. Helper is intentionally tolerant; write-side normalizes."""
        assert en.is_enabled({"enabled": 1}) is True
        assert en.is_enabled({"enabled": "true"}) is True
        assert en.is_enabled({"enabled": [1]}) is True

    def test_falsy_non_bool_coerces(self):
        assert en.is_enabled({"enabled": 0}) is False
        assert en.is_enabled({"enabled": ""}) is False
        assert en.is_enabled({"enabled": []}) is False


class TestFilterEnabled:
    def test_empty_list(self):
        assert en.filter_enabled([]) == []

    def test_all_enabled_returns_all(self):
        platforms = [
            {"id": "github"},
            {"id": "codeberg", "enabled": True},
            {"id": "local"},
        ]
        result = en.filter_enabled(platforms)
        assert [p["id"] for p in result] == ["github", "codeberg", "local"]

    def test_disabled_dropped(self):
        platforms = [
            {"id": "github"},
            {"id": "codeberg", "enabled": False},
            {"id": "local"},
        ]
        result = en.filter_enabled(platforms)
        assert [p["id"] for p in result] == ["github", "local"]

    def test_all_disabled(self):
        platforms = [
            {"id": "github", "enabled": False},
            {"id": "codeberg", "enabled": False},
        ]
        assert en.filter_enabled(platforms) == []

    def test_order_preserved(self):
        """Canonical-first ordering from replication_order survives the
        filter — important for dispatch-path consumers."""
        platforms = [
            {"id": "local"},
            {"id": "github", "enabled": False},
            {"id": "codeberg"},
            {"id": "gitlab", "enabled": False},
            {"id": "forgejo"},
        ]
        result = en.filter_enabled(platforms)
        assert [p["id"] for p in result] == ["local", "codeberg", "forgejo"]

    def test_returns_new_list_not_view(self):
        platforms = [{"id": "github"}]
        result = en.filter_enabled(platforms)
        assert result is not platforms


class TestWithEnabled:
    def test_sets_true(self):
        result = en.with_enabled({"id": "github"}, True)
        assert result == {"id": "github", "enabled": True}

    def test_sets_false(self):
        result = en.with_enabled({"id": "github"}, False)
        assert result == {"id": "github", "enabled": False}

    def test_overwrites_existing(self):
        result = en.with_enabled({"id": "github", "enabled": True}, False)
        assert result["enabled"] is False

    def test_does_not_mutate_input(self):
        entry = {"id": "github"}
        en.with_enabled(entry, False)
        assert "enabled" not in entry  # Input unchanged.

    def test_coerces_to_bool(self):
        """Even though the helper accepts any truthy/falsy, write
        always normalizes to a true Python bool so the persisted
        config stays clean."""
        result = en.with_enabled({"id": "github"}, 1)
        assert result["enabled"] is True
        assert isinstance(result["enabled"], bool)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
