"""Unit tests for forge_manager_mcp.mode_registry (#501).

Covers:

* Pydantic model construction (Mode + GateStateDeclaration) — name
  shape validation, dot-namespaced gate refs, extra-field rejection.
* Loader behavior — file-not-found, parse error, schema violation,
  duplicate name, scope tuple round-trip.
* Registry accessors — get_mode / list_modes / names / containment.
* Bidirectional helpers — compute_current_mode happy + miss paths,
  mode_gate_targets flattening, label_for_gate_state with blocker
  + custom-fallback + compound label.
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from forge_manager_mcp.mode_registry import (
    GateStateDeclaration,
    Mode,
    ModeRegistry,
    ModeRegistryError,
    compute_current_mode,
    label_for_gate_state,
    load_modes,
    mode_gate_targets,
)


# ---------------------------------------------------------------------------
# Pydantic model tests
# ---------------------------------------------------------------------------

class TestGateStateDeclaration:
    def test_minimal_declaration_constructs(self) -> None:
        decl = GateStateDeclaration(
            gate="autonomous_mode.default_state", state="open",
        )
        assert decl.gate == "autonomous_mode.default_state"
        assert decl.state == "open"
        assert decl.scope == ()

    def test_scope_round_trips(self) -> None:
        decl = GateStateDeclaration(
            gate="autonomous_mode.pause_conditions",
            state="open",
            scope=("protocol_required_input", "blocker"),
        )
        assert decl.scope == ("protocol_required_input", "blocker")

    def test_dot_namespace_required(self) -> None:
        with pytest.raises(Exception):
            GateStateDeclaration(gate="missingdot", state="open")

    def test_invalid_state_rejected(self) -> None:
        with pytest.raises(Exception):
            GateStateDeclaration(gate="x.y", state="bogus")

    def test_extra_field_forbidden(self) -> None:
        with pytest.raises(Exception):
            GateStateDeclaration(gate="x.y", state="open", bogus="nope")


class TestModeModel:
    def test_default_identity_mode(self) -> None:
        mode = Mode(
            name="default", description="standard", gate_states=()
        )
        assert mode.name == "default"
        assert mode.gate_states == ()

    def test_constrained_mode_with_decls(self) -> None:
        mode = Mode(
            name="autonomous",
            description="opens pause gates",
            gate_states=(
                GateStateDeclaration(
                    gate="autonomous_mode.default_state", state="open",
                ),
            ),
        )
        assert len(mode.gate_states) == 1
        assert mode.gate_states[0].gate == "autonomous_mode.default_state"

    def test_empty_name_rejected(self) -> None:
        with pytest.raises(Exception):
            Mode(name="", description="x", gate_states=())

    def test_dotted_name_rejected(self) -> None:
        with pytest.raises(Exception):
            Mode(name="auto.mode", description="x", gate_states=())

    def test_non_alnum_name_rejected(self) -> None:
        with pytest.raises(Exception):
            Mode(name="auto-mode", description="x", gate_states=())

    def test_extra_field_forbidden(self) -> None:
        with pytest.raises(Exception):
            Mode(
                name="x", description="y", gate_states=(), bogus="nope",
            )


# ---------------------------------------------------------------------------
# Loader tests
# ---------------------------------------------------------------------------

def _write(tmp_path: Path, text: str) -> Path:
    target = tmp_path / "modes.yaml"
    target.write_text(textwrap.dedent(text))
    return target


class TestLoadModes:
    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(ModeRegistryError, match="not found"):
            load_modes(tmp_path / "missing.yaml")

    def test_default_modes_load(self, tmp_path: Path) -> None:
        path = _write(tmp_path, """\
            modes:
              - name: default
                description: standard
                gate_states: []

              - name: autonomous
                description: opens pause gates
                gate_states:
                  - gate: autonomous_mode.default_state
                    state: open
                  - gate: autonomous_mode.pause_conditions
                    state: open
                    scope: [protocol_required_input, blocker]

              - name: plan
                description: plan-mode engaged
                gate_states:
                  - gate: plan_mode.skill_prose_edit
                    state: closed
                  - gate: plan_mode.project_rules_edit
                    state: closed
        """)
        registry = load_modes(path)
        assert len(registry) == 3
        assert registry.names() == ["default", "autonomous", "plan"]
        autonomous = registry.get_mode("autonomous")
        assert len(autonomous.gate_states) == 2
        pause = autonomous.gate_states[1]
        assert pause.scope == ("protocol_required_input", "blocker")

    def test_duplicate_name_raises(self, tmp_path: Path) -> None:
        path = _write(tmp_path, """\
            modes:
              - name: dup
                description: a
                gate_states: []
              - name: dup
                description: b
                gate_states: []
        """)
        with pytest.raises(ModeRegistryError, match="duplicate mode name"):
            load_modes(path)

    def test_schema_violation_raises(self, tmp_path: Path) -> None:
        path = _write(tmp_path, """\
            modes:
              - name: bad
                description: missing gate dot
                gate_states:
                  - gate: nodot
                    state: open
        """)
        with pytest.raises(ModeRegistryError, match="gate_states failed"):
            load_modes(path)

    def test_invalid_mode_name_raises(self, tmp_path: Path) -> None:
        path = _write(tmp_path, """\
            modes:
              - name: bad.dotted
                description: x
                gate_states: []
        """)
        with pytest.raises(ModeRegistryError, match="failed schema validation"):
            load_modes(path)

    def test_parse_error_wraps(self, tmp_path: Path) -> None:
        path = tmp_path / "modes.yaml"
        path.write_text("\tinvalid tab indent\n")
        with pytest.raises(ModeRegistryError):
            load_modes(path)


# ---------------------------------------------------------------------------
# Registry accessor tests
# ---------------------------------------------------------------------------

class TestModeRegistry:
    def _registry(self) -> ModeRegistry:
        return ModeRegistry([
            Mode(name="default", description="standard", gate_states=()),
            Mode(
                name="autonomous",
                description="autopilot",
                gate_states=(
                    GateStateDeclaration(
                        gate="autonomous_mode.default_state", state="open",
                    ),
                ),
            ),
        ])

    def test_get_mode_hits(self) -> None:
        registry = self._registry()
        assert registry.get_mode("autonomous").description == "autopilot"

    def test_get_mode_miss_returns_none(self) -> None:
        assert self._registry().get_mode("nope") is None

    def test_list_modes_preserves_order(self) -> None:
        registry = self._registry()
        names = [m.name for m in registry.list_modes()]
        assert names == ["default", "autonomous"]

    def test_contains(self) -> None:
        registry = self._registry()
        assert "default" in registry
        assert "missing" not in registry
        # Non-string keys never match.
        assert 5 not in registry

    def test_len(self) -> None:
        assert len(self._registry()) == 2

    def test_duplicate_at_construct_raises(self) -> None:
        with pytest.raises(ModeRegistryError):
            ModeRegistry([
                Mode(name="x", description="a", gate_states=()),
                Mode(name="x", description="b", gate_states=()),
            ])


# ---------------------------------------------------------------------------
# Bidirectional helpers
# ---------------------------------------------------------------------------

def _registry_with_three() -> ModeRegistry:
    return ModeRegistry([
        Mode(name="default", description="d", gate_states=()),
        Mode(
            name="autonomous",
            description="a",
            gate_states=(
                GateStateDeclaration(
                    gate="autonomous_mode.default_state", state="open",
                ),
                GateStateDeclaration(
                    gate="autonomous_mode.pause_conditions",
                    state="open",
                    scope=("protocol_required_input", "blocker"),
                ),
            ),
        ),
        Mode(
            name="plan",
            description="p",
            gate_states=(
                GateStateDeclaration(
                    gate="plan_mode.skill_prose_edit", state="closed",
                ),
                GateStateDeclaration(
                    gate="plan_mode.project_rules_edit", state="closed",
                ),
            ),
        ),
    ])


class TestComputeCurrentMode:
    def test_identity_default_always_matches(self) -> None:
        registry = _registry_with_three()
        matches = compute_current_mode(registry, {})
        # default + plan match because plan's gates default to "open"
        # but plan declares "closed" so plan does NOT match the
        # empty-state snapshot.
        assert "default" in matches

    def test_autonomous_matches_when_gates_open(self) -> None:
        registry = _registry_with_three()
        matches = compute_current_mode(registry, {
            "autonomous_mode.default_state": "open",
            "autonomous_mode.pause_conditions": "open",
        })
        assert "autonomous" in matches
        assert "default" in matches  # identity always matches

    def test_autonomous_misses_when_one_gate_closed(self) -> None:
        registry = _registry_with_three()
        matches = compute_current_mode(registry, {
            "autonomous_mode.default_state": "open",
            "autonomous_mode.pause_conditions": "closed",
        })
        assert "autonomous" not in matches

    def test_compound_autonomous_plus_plan(self) -> None:
        # When autonomous gates are open AND plan gates are closed,
        # the status display reads "autonomous + plan" (Issue #501
        # §Composability).
        registry = _registry_with_three()
        matches = compute_current_mode(registry, {
            "autonomous_mode.default_state": "open",
            "autonomous_mode.pause_conditions": "open",
            "plan_mode.skill_prose_edit": "closed",
            "plan_mode.project_rules_edit": "closed",
        })
        assert "autonomous" in matches
        assert "plan" in matches
        # Sorted for deterministic display.
        assert matches == sorted(matches)

    def test_default_state_defaults_to_open(self) -> None:
        # Unmentioned gates are treated as ``open`` (gate registry's
        # default-state contract). This makes autonomous match on a
        # fresh project where no gate has been touched.
        registry = _registry_with_three()
        matches = compute_current_mode(registry, {})
        assert "autonomous" in matches


class TestModeGateTargets:
    def test_flattens_to_tuples(self) -> None:
        registry = _registry_with_three()
        autonomous = registry.get_mode("autonomous")
        targets = mode_gate_targets(autonomous)
        assert targets == [
            ("autonomous_mode.default_state", "open", ()),
            (
                "autonomous_mode.pause_conditions",
                "open",
                ("protocol_required_input", "blocker"),
            ),
        ]

    def test_empty_for_identity_mode(self) -> None:
        registry = _registry_with_three()
        assert mode_gate_targets(registry.get_mode("default")) == []


class TestLabelForGateState:
    def test_blocker_overrides(self) -> None:
        registry = _registry_with_three()
        label = label_for_gate_state(
            registry, {}, blocking_gate="commit.test_coverage",
        )
        assert label == "gated"

    def test_compound_label_join(self) -> None:
        registry = _registry_with_three()
        label = label_for_gate_state(registry, {
            "autonomous_mode.default_state": "open",
            "autonomous_mode.pause_conditions": "open",
            "plan_mode.skill_prose_edit": "closed",
            "plan_mode.project_rules_edit": "closed",
        })
        # Sorted alphabetically — autonomous + default + plan.
        assert "autonomous" in label
        assert "plan" in label
        assert " + " in label

    def test_custom_fallback_when_no_match(self) -> None:
        # An empty registry with no identity mode → label falls back
        # to the configured fallback string.
        empty = ModeRegistry([])
        assert label_for_gate_state(empty, {}) == "custom"

    def test_custom_fallback_override(self) -> None:
        empty = ModeRegistry([])
        assert (
            label_for_gate_state(empty, {}, fallback="bespoke")
            == "bespoke"
        )


# Bazel-required entry point so this file isn't a silent no-op when run
# directly (#198 lint gate).
if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
