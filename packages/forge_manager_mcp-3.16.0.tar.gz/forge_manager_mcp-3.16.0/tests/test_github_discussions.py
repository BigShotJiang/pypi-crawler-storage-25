"""Unit tests for github.py — Discussion operations.

Covers add_discussion_comment, create_discussion, get_discussion_comments,
get_discussion_body, and the _graphql validation surface that every
discussion helper shares.
"""
from __future__ import annotations

import json
import httpx
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from forge_manager_mcp.github.core import GitHubError
from forge_manager_mcp.github.discussions import (
    add_discussion_comment,
    create_discussion,
    get_discussion_body,
    get_discussion_comments,
)


TOKEN = "ghp_test_token"


def _mock_response(data: dict, status_code: int = 200):
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = data
    mock.text = json.dumps(data)
    return mock


class TestGraphQLValidation:
    @pytest.mark.asyncio
    async def test_empty_token_raises(self):
        with pytest.raises(ValueError, match="token"):
            await add_discussion_comment("", "DIC_123", "body")

    @pytest.mark.asyncio

    async def test_empty_query_raises(self):
        # Tested indirectly via empty discussion_id
        with pytest.raises(ValueError, match="discussion_id"):
            await add_discussion_comment(TOKEN, "", "body")

    @pytest.mark.asyncio

    async def test_empty_body_raises(self):
        with pytest.raises(ValueError, match="body"):
            await add_discussion_comment(TOKEN, "DIC_123", "")


class TestAddDiscussionComment:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {
            "data": {
                "addDiscussionComment": {
                    "comment": {
                        "id": "DC_abc123",
                        "url": "https://github.com/owner/repo/discussions/1#comment-1",
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            result = await add_discussion_comment(TOKEN, "D_abc123", "Hello")
        assert result["id"] == "DC_abc123"
        assert "github.com" in result["url"]

    @pytest.mark.asyncio

    async def test_github_errors_raises(self):
        response_data = {"errors": [{"message": "Forbidden"}]}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="Forbidden"):
                await add_discussion_comment(TOKEN, "D_abc123", "Hello")

    @pytest.mark.asyncio

    async def test_http_error_raises(self):
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response({}, status_code=401))):
            with pytest.raises(GitHubError, match="HTTP 401"):
                await add_discussion_comment(TOKEN, "D_abc123", "Hello")


class TestCreateDiscussion:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {
            "data": {
                "createDiscussion": {
                    "discussion": {
                        "id": "D_new123",
                        "number": 5,
                        "url": "https://github.com/owner/repo/discussions/5",
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            result = await create_discussion(
                TOKEN, "R_repo123", "DIC_cat123", "Test Title", "Test body"
            )
        assert result["id"] == "D_new123"
        assert result["number"] == 5

    @pytest.mark.asyncio

    async def test_empty_title_raises(self):
        with pytest.raises(ValueError, match="title"):
            await create_discussion(TOKEN, "R_repo123", "DIC_cat123", "", "body")


class TestGetDiscussionComments:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {
            "data": {
                "node": {
                    "comments": {
                        "nodes": [
                            {"id": "DC_1", "body": "First", "createdAt": "2026-01-01"},
                            {"id": "DC_2", "body": "Second", "createdAt": "2026-01-02"},
                        ]
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            comments = await get_discussion_comments(TOKEN, "D_abc123")
        assert len(comments) == 2
        assert comments[0]["id"] == "DC_1"

    @pytest.mark.asyncio

    async def test_discussion_not_found_raises(self):
        response_data = {"data": {"node": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await get_discussion_comments(TOKEN, "D_notexist")

    @pytest.mark.asyncio

    async def test_invalid_last_n_raises(self):
        with pytest.raises(ValueError, match="last_n"):
            await get_discussion_comments(TOKEN, "D_abc123", last_n=0)

    @pytest.mark.asyncio

    async def test_last_n_too_large_raises(self):
        with pytest.raises(ValueError, match="last_n"):
            await get_discussion_comments(TOKEN, "D_abc123", last_n=101)


class TestGetDiscussionBody:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {"data": {"node": {"body": "# Hello\n\nTable of Contents"}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            body = await get_discussion_body(TOKEN, "D_abc123")
        assert body.startswith("# Hello")

    @pytest.mark.asyncio

    async def test_missing_discussion_raises(self):
        response_data = {"data": {"node": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await get_discussion_body(TOKEN, "D_missing")

    @pytest.mark.asyncio

    async def test_empty_id_raises(self):
        with pytest.raises(ValueError, match="discussion_id"):
            await get_discussion_body(TOKEN, "")
# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) update_discussion_body + answer helpers.
# ---------------------------------------------------------------------------


class TestUpdateDiscussionBody:
    @pytest.mark.asyncio
    async def test_empty_discussion_id_raises(self):
        from forge_manager_mcp.github.discussions import update_discussion_body
        with pytest.raises(ValueError, match="discussion_id"):
            await update_discussion_body(TOKEN, "", "body")

    @pytest.mark.asyncio
    async def test_empty_body_raises(self):
        from forge_manager_mcp.github.discussions import update_discussion_body
        with pytest.raises(ValueError, match="body"):
            await update_discussion_body(TOKEN, "D_x", "  ")

    @pytest.mark.asyncio
    async def test_success_returns_true(self):
        from forge_manager_mcp.github.discussions import update_discussion_body
        with patch(
            "forge_manager_mcp.github.discussions._graphql",
            new_callable=AsyncMock,
            return_value={"updateDiscussion": {"discussion": {"id": "D_x"}}},
        ):
            assert await update_discussion_body(TOKEN, "D_x", "new body") is True


class TestGetDiscussionComments:
    @pytest.mark.asyncio
    async def test_empty_discussion_id_raises(self):
        with pytest.raises(ValueError, match="discussion_id"):
            await get_discussion_comments(TOKEN, "")

    @pytest.mark.asyncio
    async def test_invalid_last_n_raises(self):
        with pytest.raises(ValueError, match="last_n"):
            await get_discussion_comments(TOKEN, "D_x", last_n=0)

    @pytest.mark.asyncio
    async def test_returns_node_comments_nodes(self):
        # Happy path: data.node.comments.nodes returned. L160-164.
        with patch(
            "forge_manager_mcp.github.discussions._graphql",
            new_callable=AsyncMock,
            return_value={
                "node": {"comments": {"nodes": [{"id": "c1"}]}},
            },
        ):
            result = await get_discussion_comments(TOKEN, "D_x", last_n=5)
        assert result == [{"id": "c1"}]

    @pytest.mark.asyncio
    async def test_node_none_raises_github_error(self):
        # data.node is None → raise GitHubError. L161-163.
        with patch(
            "forge_manager_mcp.github.discussions._graphql",
            new_callable=AsyncMock,
            return_value={"node": None},
        ):
            with pytest.raises(GitHubError, match="not found"):
                await get_discussion_comments(TOKEN, "D_x", last_n=5)


class TestMarkDiscussionAnswer:
    @pytest.mark.asyncio
    async def test_empty_comment_id_raises(self):
        from forge_manager_mcp.github.discussions import mark_discussion_answer
        with pytest.raises(ValueError, match="comment_id"):
            await mark_discussion_answer(TOKEN, "")

    @pytest.mark.asyncio
    async def test_success_returns_true(self):
        from forge_manager_mcp.github.discussions import mark_discussion_answer
        with patch(
            "forge_manager_mcp.github.discussions._graphql",
            new_callable=AsyncMock,
            return_value={
                "markDiscussionCommentAsAnswer": {
                    "discussion": {"id": "D_x"},
                },
            },
        ):
            assert await mark_discussion_answer(TOKEN, "C_x") is True


if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
