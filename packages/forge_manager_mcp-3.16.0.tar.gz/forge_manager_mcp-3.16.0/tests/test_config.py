"""
Unit tests for config.py.

All tests verify fail-fast behaviour — every bad input must raise
immediately with a meaningful error message.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from forge_manager_mcp.config import (
    ConfigError,
    get_github_token,
    load_config,
    require_env,
)


class TestLoadConfig:
    def test_loads_valid_config(self, project_dir):
        config = load_config(project_dir)
        assert config.owner == "telejester"
        assert config.account_type == "personal"
        assert config.repos.private == "telejester/claude-skills-dev"

    def test_raises_if_project_dir_missing(self, tmp_path):
        missing = tmp_path / "does-not-exist"
        with pytest.raises(ConfigError, match="does not exist"):
            load_config(missing)

    def test_raises_if_config_file_missing(self, empty_project_dir):
        # Post-#274 Phase D, load_config tries forge-config.json first
        # then falls back to github-config.json. Error message includes
        # both paths.
        with pytest.raises(ConfigError, match="No forge config found"):
            load_config(empty_project_dir)

    def test_loads_forge_config_json_in_preference_to_legacy(
        self, tmp_path
    ):
        """#274 Phase D — when both forge-config.json and the legacy
        github-config.json exist, the 3.0 file wins."""
        import json
        from tests.conftest import VALID_CONFIG

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()

        legacy = dict(VALID_CONFIG)
        legacy["owner"] = "from-legacy"
        (claude_dir / "github-config.json").write_text(
            json.dumps(legacy), encoding="utf-8",
        )

        forge = dict(VALID_CONFIG)
        forge["owner"] = "from-forge"
        forge["schema_version"] = "3.0"
        forge["platforms"] = [
            {"id": "github", "owner": "from-forge",
             "private": "from-forge/dev", "public": "from-forge/pub"},
        ]
        forge["replication_order"] = ["github"]
        (claude_dir / "forge-config.json").write_text(
            json.dumps(forge), encoding="utf-8",
        )

        config = load_config(tmp_path)
        assert config.owner == "from-forge"
        assert config.schema_version == "3.0"
        assert config.replication_order == ["github"]

    def test_legacy_github_config_loads_when_forge_config_absent(
        self, project_dir
    ):
        """A 2.x project (only github-config.json present) loads
        cleanly — the 3.0 fields default to empty / "2.x"."""
        config = load_config(project_dir)
        assert config.schema_version == "2.x"
        assert config.platforms == []
        assert config.replication_order == []

    def test_raises_on_invalid_json(self, tmp_path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text("not json {{", encoding="utf-8")
        with pytest.raises(ConfigError, match="not valid JSON"):
            load_config(tmp_path)

    def test_raises_on_missing_required_field(self, tmp_path, valid_config_dict):
        del valid_config_dict["owner"]
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        with pytest.raises(ConfigError, match="failed validation"):
            load_config(tmp_path)

    def test_raises_on_wrong_skill_name(self, tmp_path, valid_config_dict):
        valid_config_dict["skill"] = "some-other-skill"
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        with pytest.raises(ConfigError, match="failed validation"):
            load_config(tmp_path)

    def test_raises_on_short_node_id(self, tmp_path, valid_config_dict):
        valid_config_dict["project_discussion_id"] = "short"
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        with pytest.raises(ConfigError, match="suspiciously short"):
            load_config(tmp_path)

    def test_raises_on_empty_category_id(self, tmp_path, valid_config_dict):
        valid_config_dict["discussion_categories"]["Architecture"]["id"] = ""
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        with pytest.raises(ConfigError, match="failed validation"):
            load_config(tmp_path)

    def test_config_is_immutable(self, project_dir):
        config = load_config(project_dir)
        with pytest.raises(Exception):
            config.owner = "other"  # type: ignore[misc]

    def test_loads_related_repos_field(self, tmp_path, valid_config_dict):
        # #98 — related_repos is optional and parses alongside the
        # rest of the schema when present.
        valid_config_dict["related_repos"] = [
            {
                "repo": "other-org/shared",
                "relationship": "sibling",
                "description": "peer project",
            }
        ]
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        config = load_config(tmp_path)
        assert len(config.related_repos) == 1
        assert config.related_repos[0].relationship == "sibling"

    def test_contribution_target_emits_deprecation_warning(
        self, tmp_path, valid_config_dict, recwarn
    ):
        # #98 — the pre-1.3.0 umbrella `contribution_target` still
        # parses but must emit a DeprecationWarning so the user gets
        # prompted to migrate to a precise sub-type.
        valid_config_dict["related_repos"] = [
            {"repo": "legacy-org/tool", "relationship": "contribution_target"},
            {"repo": "another-org/x", "relationship": "contribution_target"},
            {"repo": "new-org/y", "relationship": "sibling"},  # control
        ]
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "github-config.json").write_text(
            json.dumps(valid_config_dict), encoding="utf-8"
        )
        config = load_config(tmp_path)

        # Config still loads, contribution_target entries preserved.
        types = [r.relationship for r in config.related_repos]
        assert types.count("contribution_target") == 2

        dep_warnings = [
            w for w in recwarn.list
            if issubclass(w.category, DeprecationWarning)
        ]
        assert len(dep_warnings) == 1, (
            "Exactly one DeprecationWarning for contribution_target usage"
        )
        msg = str(dep_warnings[0].message)
        assert "contribution_target" in msg
        assert "legacy-org/tool" in msg
        assert "another-org/x" in msg
        # The non-deprecated sibling entry is not named in the warning.
        assert "new-org/y" not in msg

    def test_no_deprecation_warning_for_clean_config(
        self, project_dir, recwarn
    ):
        load_config(project_dir)
        dep_warnings = [
            w for w in recwarn.list
            if issubclass(w.category, DeprecationWarning)
        ]
        assert dep_warnings == [], (
            "A clean config (no contribution_target) must emit zero "
            "DeprecationWarnings on load."
        )


class TestRequireEnv:
    def test_returns_value_when_set(self, monkeypatch):
        monkeypatch.setenv("TEST_VAR_123", "myvalue")
        assert require_env("TEST_VAR_123") == "myvalue"

    def test_raises_when_not_set(self, monkeypatch):
        monkeypatch.delenv("TEST_VAR_123", raising=False)
        with pytest.raises(ConfigError, match="TEST_VAR_123"):
            require_env("TEST_VAR_123")

    def test_raises_when_empty(self, monkeypatch):
        monkeypatch.setenv("TEST_VAR_123", "   ")
        with pytest.raises(ConfigError, match="TEST_VAR_123"):
            require_env("TEST_VAR_123")


class TestGetGithubToken:
    """Token resolution: env-var first, gh CLI fallback (#154)."""

    def test_uses_github_token_when_set(self, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_from_env")
        monkeypatch.delenv("GH_TOKEN", raising=False)
        assert get_github_token() == "ghp_from_env"

    def test_uses_gh_token_when_github_token_absent(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        monkeypatch.setenv("GH_TOKEN", "ghp_from_gh_token_var")
        assert get_github_token() == "ghp_from_gh_token_var"

    def test_falls_back_to_gh_cli_when_env_empty(self, monkeypatch):
        """Reproduces the v2.0.0a1 dogfood failure: GITHUB_TOKEN empty in
        the launcher's PATH-stripped subshell. Server must use `gh auth
        token` instead of failing fast (#154)."""
        monkeypatch.setenv("GITHUB_TOKEN", "")
        monkeypatch.setenv("GH_TOKEN", "")

        import subprocess as sp_module

        def fake_run(cmd, **kwargs):
            assert cmd == ["gh", "auth", "token"]

            class _Result:
                stdout = "ghp_from_gh_cli\n"

            return _Result()

        monkeypatch.setattr(sp_module, "run", fake_run)
        assert get_github_token() == "ghp_from_gh_cli"

    def test_raises_when_gh_returns_empty(self, monkeypatch):
        """gh auth token can return empty if the user is logged out."""
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        monkeypatch.delenv("GH_TOKEN", raising=False)

        import subprocess as sp_module

        def fake_run(cmd, **kwargs):
            class _Result:
                stdout = ""

            return _Result()

        monkeypatch.setattr(sp_module, "run", fake_run)
        with pytest.raises(ConfigError, match="No GitHub token found"):
            get_github_token()

    def test_raises_when_gh_not_installed(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        monkeypatch.delenv("GH_TOKEN", raising=False)

        import subprocess as sp_module

        def fake_run(cmd, **kwargs):
            raise FileNotFoundError("gh not on PATH")

        monkeypatch.setattr(sp_module, "run", fake_run)
        with pytest.raises(ConfigError, match="No GitHub token found"):
            get_github_token()


class TestGetPlatformToken:
    """Per-platform token dispatcher (#283)."""

    def test_local_returns_none(self, monkeypatch):
        from forge_manager_mcp.config import get_platform_token
        # LocalStore has no remote auth
        assert get_platform_token("local") is None

    def test_unknown_platform_returns_none(self):
        from forge_manager_mcp.config import get_platform_token
        assert get_platform_token("hypothetical_backend") is None

    def test_forgejo_uses_forgejo_token_env(self, monkeypatch):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("FORGEJO_TOKEN", "forgejo-pat-123")
        assert get_platform_token("forgejo") == "forgejo-pat-123"

    def test_codeberg_uses_codeberg_token_env(self, monkeypatch):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("CODEBERG_TOKEN", "codeberg-pat-456")
        # Make sure we don't accidentally pick up forgejo or github tokens
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        monkeypatch.delenv("GH_TOKEN", raising=False)
        assert get_platform_token("codeberg") == "codeberg-pat-456"

    def test_gitlab_uses_gitlab_token_env(self, monkeypatch):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("GITLAB_TOKEN", "glpat-789")
        assert get_platform_token("gitlab") == "glpat-789"

    def test_token_env_override_wins(self, monkeypatch):
        """forge-config.json platforms[].token_env names a custom env var
        that takes precedence over the platform's default chain."""
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("MY_CUSTOM_FORGEJO_TOKEN", "custom-987")
        monkeypatch.setenv("FORGEJO_TOKEN", "default-default")
        token = get_platform_token(
            "forgejo", token_env_override="MY_CUSTOM_FORGEJO_TOKEN",
        )
        assert token == "custom-987"

    def test_token_env_override_misses_fall_through_to_default(self, monkeypatch):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.delenv("MY_UNSET_VAR", raising=False)
        monkeypatch.setenv("FORGEJO_TOKEN", "fallback-default")
        token = get_platform_token(
            "forgejo", token_env_override="MY_UNSET_VAR",
        )
        assert token == "fallback-default"

    def test_token_file_used_when_env_absent(self, monkeypatch, tmp_path):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        token_file = tmp_path / ".forgejo-token"
        token_file.write_text("from-file-token\n")
        # Point HOME at tmp_path so ~/.forgejo-token resolves there
        monkeypatch.setenv("HOME", str(tmp_path))
        assert get_platform_token("forgejo") == "from-file-token"

    def test_returns_none_when_all_sources_absent(self, monkeypatch, tmp_path):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # no ~/.forgejo-token
        assert get_platform_token("forgejo") is None

    def test_empty_env_var_skipped(self, monkeypatch, tmp_path):
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("FORGEJO_TOKEN", "")  # empty doesn't satisfy
        monkeypatch.setenv("HOME", str(tmp_path))
        assert get_platform_token("forgejo") is None

    def test_github_uses_existing_chain(self, monkeypatch):
        """get_platform_token("github") preserves the env → gh-CLI chain."""
        from forge_manager_mcp.config import get_platform_token
        monkeypatch.setenv("GITHUB_TOKEN", "gh-pat-from-env")
        assert get_platform_token("github") == "gh-pat-from-env"


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) OSError-path coverage.
# ---------------------------------------------------------------------------


class TestLoadConfigReadOSError:
    def test_oserror_reading_config_raises_configerror(
        self, tmp_path, monkeypatch,
    ):
        # OSError reading forge-config.json → L86-90 wrapped as
        # ConfigError.
        from pathlib import Path as _P
        cfg = tmp_path / ".claude" / "forge-config.json"
        cfg.parent.mkdir(parents=True)
        cfg.write_text("{}")
        original = _P.read_text

        def _fail(self, *a, **kw):
            if self == cfg:
                raise OSError("simulated read failure")
            return original(self, *a, **kw)

        monkeypatch.setattr(_P, "read_text", _fail)
        with pytest.raises(ConfigError, match="Cannot read"):
            load_config(project_dir=tmp_path)


class TestGetPlatformTokenFileChain:
    def test_token_file_oserror_continues_chain(self, tmp_path, monkeypatch):
        # get_platform_token's token-file branch: OSError reading the
        # file → L278-280 continue past it. Inject two token files into
        # the codeberg source list — first raises OSError, second
        # succeeds.
        from forge_manager_mcp import config as _cfg
        from pathlib import Path as _P

        monkeypatch.delenv("CODEBERG_TOKEN", raising=False)

        first = tmp_path / "first-token.txt"
        first.write_text("first-token-content")
        second = tmp_path / "second-token.txt"
        second.write_text("second-token-content")

        # Patch the source table to route codeberg through our two files.
        patched_sources = dict(_cfg._PLATFORM_TOKEN_SOURCES)
        patched_sources["codeberg"] = ((), (str(first), str(second)))
        monkeypatch.setattr(_cfg, "_PLATFORM_TOKEN_SOURCES", patched_sources)

        original = _P.read_text

        def _fail_first(self, *a, **kw):
            if self == first:
                raise OSError("simulated")
            return original(self, *a, **kw)

        monkeypatch.setattr(_P, "read_text", _fail_first)
        result = _cfg.get_platform_token("codeberg")
        assert result == "second-token-content"


if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
