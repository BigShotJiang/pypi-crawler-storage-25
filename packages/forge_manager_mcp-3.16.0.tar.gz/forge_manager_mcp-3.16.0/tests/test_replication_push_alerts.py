"""Tests for replication.push_alerts (Discussion #23 A.5 / OQ4)."""
from __future__ import annotations

import sqlite3

import pytest

from forge_manager_mcp.replication import push_alerts as pa
from forge_manager_mcp.shadow import replication_push as rp


class TestMakePushFailedAlert:
    def test_payload_shape(self):
        alert = pa.make_push_failed_alert(
            platform_id="github",
            error_class="ForgeUnavailable",
            error_message="connection refused",
            canonical_kind="issue",
            canonical_number=42,
            source_event="create_issue_42_github_fail",
        )
        assert alert["level"] == "info"
        assert "github" in alert["message"]
        assert "issue:#42" in alert["message"]
        assert "ForgeUnavailable" in alert["detail"]
        assert "connection refused" in alert["detail"]
        assert alert["platform_id"] == "github"
        assert "push_failed" in alert["tags"]
        assert "adapter:github" in alert["tags"]

    def test_low_severity(self):
        """Chatty alerts are info-level per OQ4 (c) — dedup via
        #454 content-hash keeps noise manageable."""
        alert = pa.make_push_failed_alert(
            platform_id="github",
            error_class="X", error_message="x",
            canonical_kind="issue", canonical_number=1,
            source_event="e",
        )
        assert alert["level"] == "info"


class TestMakeUnhealthyAlert:
    def test_payload_shape(self):
        alert = pa.make_unhealthy_alert(
            platform_id="codeberg",
            consecutive_failures=3,
            most_recent_error="auth token expired",
        )
        assert alert["level"] == "warning"
        assert "codeberg" in alert["message"]
        assert "3" in alert["message"]
        assert "auth token expired" in alert["detail"]
        assert alert["platform_id"] == "codeberg"
        assert "adapter_unhealthy" in alert["tags"]
        assert "adapter:codeberg" in alert["tags"]

    def test_without_recent_error(self):
        alert = pa.make_unhealthy_alert(
            platform_id="github",
            consecutive_failures=5,
        )
        assert "consecutive_failures: 5" in alert["detail"]
        # No most_recent_error line.
        assert "most_recent_error:" not in alert["detail"]


class TestIsAtUnhealthyThreshold:
    def test_at_threshold(self):
        assert pa.is_at_unhealthy_threshold(3) is True

    def test_below_threshold(self):
        assert pa.is_at_unhealthy_threshold(1) is False
        assert pa.is_at_unhealthy_threshold(2) is False

    def test_above_threshold_returns_false(self):
        """First-of-N — alert fires once at the transition moment.
        Subsequent failures don't re-fire the alert until streak
        breaks + new threshold crossing."""
        assert pa.is_at_unhealthy_threshold(4) is False
        assert pa.is_at_unhealthy_threshold(100) is False

    def test_zero_returns_false(self):
        assert pa.is_at_unhealthy_threshold(0) is False

    def test_custom_threshold(self):
        assert pa.is_at_unhealthy_threshold(5, threshold=5) is True
        assert pa.is_at_unhealthy_threshold(3, threshold=5) is False

    def test_default_threshold_is_three(self):
        assert pa.DEFAULT_UNHEALTHY_THRESHOLD == 3


class TestCountConsecutiveFailures:
    @pytest.fixture
    def conn(self):
        c = sqlite3.connect(":memory:")
        for ddl in rp.SCHEMA_DDL:
            c.execute(ddl)
        c.commit()
        yield c
        c.close()

    def _insert(self, conn, *, adapter, n, success, idx):
        rp.insert_replication_push_fact(
            conn,
            adapter=adapter,
            canonical_kind="issue",
            canonical_number=n,
            success=success,
            mirror_number=n if success else None,
            error_class=None if success else "X",
            error_message=None if success else "x",
            attempted_at=f"2026-05-16T10:0{idx}:00.000Z",
            valid_from=f"2026-05-16T10:0{idx}:00.000Z",
            recorded_at=f"2026-05-16T10:0{idx}:00.000Z",
            source_event=f"event_{adapter}_{n}_{idx}",
            recorded_by=None,
        )

    def test_empty_table_zero(self, conn):
        assert pa.count_consecutive_failures(conn, adapter="github") == 0

    def test_no_failures_zero(self, conn):
        self._insert(conn, adapter="github", n=1, success=True, idx=1)
        assert pa.count_consecutive_failures(conn, adapter="github") == 0

    def test_single_failure(self, conn):
        self._insert(conn, adapter="github", n=1, success=False, idx=1)
        assert pa.count_consecutive_failures(conn, adapter="github") == 1

    def test_consecutive_failures(self, conn):
        for i in range(1, 4):
            self._insert(
                conn, adapter="github", n=i, success=False, idx=i,
            )
        assert pa.count_consecutive_failures(conn, adapter="github") == 3

    def test_streak_broken_by_success(self, conn):
        """A success breaks the streak; consecutive count from head."""
        self._insert(conn, adapter="github", n=1, success=False, idx=1)
        self._insert(conn, adapter="github", n=2, success=True, idx=2)
        self._insert(conn, adapter="github", n=3, success=False, idx=3)
        # Most-recent (idx=3) is failure; one above is success.
        assert pa.count_consecutive_failures(conn, adapter="github") == 1

    def test_streak_broken_after_three(self, conn):
        for i in range(1, 4):
            self._insert(
                conn, adapter="github", n=i, success=False, idx=i,
            )
        # 4th attempt succeeds — streak broken.
        self._insert(conn, adapter="github", n=4, success=True, idx=4)
        assert pa.count_consecutive_failures(conn, adapter="github") == 0

    def test_independent_per_adapter(self, conn):
        self._insert(conn, adapter="github", n=1, success=False, idx=1)
        self._insert(conn, adapter="codeberg", n=2, success=True, idx=2)
        self._insert(conn, adapter="github", n=3, success=False, idx=3)
        assert pa.count_consecutive_failures(conn, adapter="github") == 2
        assert pa.count_consecutive_failures(conn, adapter="codeberg") == 0

    def test_table_absent_returns_zero(self):
        """Pre-shadow-schema state — table doesn't exist."""
        bare = sqlite3.connect(":memory:")
        try:
            assert pa.count_consecutive_failures(
                bare, adapter="github",
            ) == 0
        finally:
            bare.close()


class TestIntegration:
    """The end-to-end OQ4 (c) flow: after emit_push_outcome lands,
    count the streak + check threshold + decide whether to fire
    unhealthy alert."""

    def test_threshold_crossing_yields_unhealthy(self):
        c = sqlite3.connect(":memory:")
        try:
            for ddl in rp.SCHEMA_DDL:
                c.execute(ddl)
            c.commit()

            # Three failures in a row.
            for i in range(1, 4):
                rp.emit_push_outcome(
                    c, adapter="github",
                    canonical_kind="issue",
                    canonical_number=i,
                    success=False,
                    error_class="X", error_message="x",
                    source_event=f"e_{i}",
                )
                streak = pa.count_consecutive_failures(c, adapter="github")
                fires_unhealthy = pa.is_at_unhealthy_threshold(streak)
                if i < 3:
                    assert fires_unhealthy is False
                else:
                    assert fires_unhealthy is True
        finally:
            c.close()


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
