"""Tests for the public-issue triage classifier (3.16.0 D5).

Pure unit tests; classifier has no I/O so JSDOM / sqlite fixtures
aren't needed. Coverage focuses on the precedence ordering, the
per-detector signals, and the make_classification factory's
vocabulary validation.
"""
from __future__ import annotations

import sys

import pytest

from forge_manager_mcp.triage_classifier import (
    MIN_USEFUL_BODY_CHARS,
    VALID_CATEGORIES,
    classify_issue,
    make_classification,
)


# ---------------------------------------------------------------------------
# make_classification factory
# ---------------------------------------------------------------------------


class TestMakeClassification:
    def test_valid_record(self):
        r = make_classification(
            category="valid", confidence=0.4, reasons=["x"],
        )
        assert r == {"category": "valid", "confidence": 0.4, "reasons": ["x"]}

    def test_rejects_unknown_category(self):
        with pytest.raises(ValueError, match="category must be one of"):
            make_classification(
                category="garbage", confidence=0.5, reasons=[],
            )

    @pytest.mark.parametrize("conf", [-0.1, 1.5, 2.0])
    def test_rejects_out_of_range_confidence(self, conf):
        with pytest.raises(ValueError, match="confidence must be in"):
            make_classification(
                category="valid", confidence=conf, reasons=[],
            )

    def test_vocabulary_is_locked(self):
        """The set of categories is part of the operator-facing
        contract — locking the tuple here means changes require a
        coordinated test update."""
        assert set(VALID_CATEGORIES) == {
            "duplicate", "needs_info", "spam", "valid", "unclassified",
        }


# ---------------------------------------------------------------------------
# Spam detection
# ---------------------------------------------------------------------------


class TestSpamDetection:
    def test_buy_now_marker(self):
        r = classify_issue(
            body="Buy now! Best deals on viagra at our shop.",
            title="Important",
        )
        assert r["category"] == "spam"
        assert r["confidence"] == 0.9
        # Should report which marker(s) matched.
        assert any("buy now" in reason for reason in r["reasons"])

    def test_click_here_marker(self):
        r = classify_issue(
            body="Click here to win a free gift card!",
            title="t",
        )
        assert r["category"] == "spam"

    def test_marker_in_title(self):
        """Spam markers in title should also trigger."""
        r = classify_issue(
            body=(
                "legitimate content here that's plenty long for "
                "this test case to have substance"
            ),
            title="Casino bonus inside",
        )
        assert r["category"] == "spam"

    def test_case_insensitive(self):
        r = classify_issue(
            body="VIAGRA cheap rates here",
            title="t",
        )
        assert r["category"] == "spam"


# ---------------------------------------------------------------------------
# Duplicate detection
# ---------------------------------------------------------------------------


class TestDuplicateDetection:
    def test_exact_title_match_is_duplicate(self):
        r = classify_issue(
            body="Detailed description with plenty of context and "
                 "a repro that exceeds the minimum body length.",
            title="App crashes on startup",
            existing_titles=["App crashes on startup"],
        )
        assert r["category"] == "duplicate"
        assert r["confidence"] == 0.9

    def test_case_insensitive_match(self):
        r = classify_issue(
            body="Long enough body content for the needs-info threshold.",
            title="app crashes on startup",
            existing_titles=["App Crashes On Startup"],
        )
        assert r["category"] == "duplicate"

    def test_no_duplicate_when_titles_differ(self):
        r = classify_issue(
            body="Long enough body content for the needs-info threshold.",
            title="Something else",
            existing_titles=["App crashes on startup"],
        )
        assert r["category"] != "duplicate"

    def test_empty_title_is_not_duplicate(self):
        r = classify_issue(
            body="Long enough body content for the needs-info threshold.",
            title="",
            existing_titles=["Anything"],
        )
        assert r["category"] != "duplicate"

    def test_no_existing_titles_passed(self):
        """Default empty corpus → no duplicate possible."""
        r = classify_issue(
            body="Long enough body content for the needs-info threshold.",
            title="x",
        )
        assert r["category"] != "duplicate"


# ---------------------------------------------------------------------------
# Needs-info detection
# ---------------------------------------------------------------------------


class TestNeedsInfoDetection:
    def test_short_body(self):
        r = classify_issue(body="bug", title="x")
        assert r["category"] == "needs_info"

    def test_url_only_body_is_short(self):
        """URLs are stripped from the length count so a "see this
        link" body still classifies as needs_info."""
        r = classify_issue(
            body="See: https://example.com/very-long-url",
            title="x",
        )
        assert r["category"] == "needs_info"
        # Reason should reference the threshold.
        assert any(
            "shorter than" in reason for reason in r["reasons"]
        )

    def test_tbd_marker(self):
        r = classify_issue(
            body="TODO: fill this in later when I have time to "
                 "actually reproduce the issue and figure out exactly "
                 "what was happening when the crash occurred.",
            title="x",
        )
        assert r["category"] == "needs_info"

    def test_wip_marker(self):
        r = classify_issue(
            body="WIP - still investigating root cause; will update "
                 "with repro steps once I narrow it down further.",
            title="x",
        )
        assert r["category"] == "needs_info"

    def test_multi_signal_higher_confidence(self):
        r = classify_issue(body="TBD", title="x")
        assert r["category"] == "needs_info"
        # Short body + stub marker = 2 reasons = 0.6 confidence
        assert r["confidence"] == 0.6


# ---------------------------------------------------------------------------
# Valid (catchall)
# ---------------------------------------------------------------------------


class TestValidCatchall:
    def test_no_signals_matched(self):
        r = classify_issue(
            body="Reproducible bug: clicking the Save button on "
                 "the new-project form raises a 500 error from the "
                 "/projects endpoint when the project name contains "
                 "a colon.",
            title="500 error on project name with colon",
        )
        assert r["category"] == "valid"
        assert r["confidence"] == 0.4
        assert "no spam / duplicate / needs-info signals" in r["reasons"][0]


# ---------------------------------------------------------------------------
# Precedence
# ---------------------------------------------------------------------------


class TestPrecedence:
    def test_spam_beats_duplicate(self):
        """Spam marker present + title is a duplicate → still spam.
        Operator wants to delete-as-spam regardless."""
        r = classify_issue(
            body="Buy now! Cheap viagra! And by the way this is a "
                 "duplicate of issue 42 about the crash.",
            title="App crashes on startup",
            existing_titles=["App crashes on startup"],
        )
        assert r["category"] == "spam"

    def test_duplicate_beats_needs_info(self):
        """Short body + duplicate title → classify as duplicate
        (operator should close-as-duplicate rather than ask for
        more info)."""
        r = classify_issue(
            body="short",
            title="Existing bug",
            existing_titles=["Existing bug"],
        )
        assert r["category"] == "duplicate"

    def test_needs_info_beats_valid(self):
        """Short body alone → needs_info, not valid."""
        r = classify_issue(body="bug", title="x")
        assert r["category"] == "needs_info"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
