"""Per-step unit tests for the migration flow interceptor wrappers (#294 Phase B).

Mirrors the test pattern from tests/test_flow_release_steps.py: each
step's enter / error / leave handler tested in isolation via
mock-context. Underlying migration runner / detector primitives are
stubbed via monkeypatch.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from forge_manager_mcp.flows.migration import build_migration_chain
from forge_manager_mcp.flows.migration.backfill_canonical_from_remote import (
    make_backfill_canonical_from_remote_interceptor,
)
from forge_manager_mcp.flows.migration.backup_claude_dir import (
    MigrationStepFailed,
    make_backup_claude_dir_interceptor,
)
from forge_manager_mcp.flows.migration.bootstrap_docs_repo import (
    make_bootstrap_docs_repo_interceptor,
)
from forge_manager_mcp.flows.migration.detect_legacy_state import (
    make_detect_legacy_state_interceptor,
)
from forge_manager_mcp.flows.migration.finalize import (
    make_finalize_interceptor,
)
from forge_manager_mcp.flows.migration.rename_skill_dir import (
    make_rename_skill_dir_interceptor,
)
from forge_manager_mcp.flows.migration.rewrite_claude_md import (
    make_rewrite_claude_md_interceptor,
)
from forge_manager_mcp.flows.migration.translate_schema import (
    make_translate_schema_interceptor,
)
from forge_manager_mcp.interceptors import Context


def _request(project_dir: Path, **kwargs) -> dict:
    base = {"project_dir": project_dir, "apply": False}
    base.update(kwargs)
    return base


def _step(kind: str, source: str = "", target: str = "", **payload):
    return SimpleNamespace(
        kind=kind, source=source, target=target, payload=dict(payload),
    )


# ---------------------------------------------------------------------------
# backup_claude_dir
# ---------------------------------------------------------------------------

class TestBackupClaudeDir:
    @pytest.mark.asyncio
    async def test_dry_run_skips_backup(self, tmp_path: Path):
        ic = make_backup_claude_dir_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.error is None
        assert result.response["backup_claude_dir"]["status"] == "dry_run_preview"

    @pytest.mark.asyncio
    async def test_apply_creates_backup(self, tmp_path: Path, monkeypatch):
        backup = tmp_path / "_backup"
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._create_backup",
            MagicMock(return_value=backup),
        )
        ic = make_backup_claude_dir_interceptor()
        result = await ic.enter(
            Context(request=_request(tmp_path, apply=True))
        )
        assert result.error is None
        assert result.request["backup_path"] == backup
        assert result.response["backup_claude_dir"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_error_preserves_backup_with_rollback_command(
        self, tmp_path: Path,
    ):
        ic = make_backup_claude_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(tmp_path / "_backup"),
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is False  # backup preserved
        assert "migrate_to_3_0_rollback" in compensation["detail"][
            "rollback_command"
        ]

    @pytest.mark.asyncio
    async def test_apply_create_backup_raises_returns_error_envelope(
        self, tmp_path: Path, monkeypatch,
    ):
        # (#428 D-Coverage drain) lines 50-53 — _create_backup raises
        # → ctx.error = MigrationStepFailed("backup failed: ...")
        def _boom(_pd):
            raise OSError("simulated backup failure")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._create_backup",
            _boom,
        )
        ic = make_backup_claude_dir_interceptor()
        result = await ic.enter(
            Context(request=_request(tmp_path, apply=True))
        )
        assert isinstance(result.error, MigrationStepFailed)
        assert "backup failed" in str(result.error)
        assert "simulated backup failure" in str(result.error)

    @pytest.mark.asyncio
    async def test_leave_deletes_backup_on_success(
        self, tmp_path: Path,
    ):
        # The success-path leave handler deletes the backup tarball
        # via shutil.rmtree (line 94).
        ic = make_backup_claude_dir_interceptor()
        backup = tmp_path / "_backup_dir"
        backup.mkdir()
        (backup / "marker").write_text("backup")
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(backup),
                }
            },
        )
        await ic.leave(ctx)
        # Backup deleted on success path.
        assert not backup.exists()

    @pytest.mark.asyncio
    async def test_leave_preserves_backup_when_failed_compensations(
        self, tmp_path: Path,
    ):
        # If any earlier step recorded failed_compensations, leave
        # preserves the backup (lines 89-91).
        ic = make_backup_claude_dir_interceptor()
        backup = tmp_path / "_backup_dir"
        backup.mkdir()
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(backup),
                },
                "failed_compensations": ({"step": "some_step", "error": "x"},),
            },
        )
        await ic.leave(ctx)
        # Backup preserved.
        assert backup.exists()

    @pytest.mark.asyncio
    async def test_leave_no_backup_path_returns_early(
        self, tmp_path: Path,
    ):
        # `if not backup_path: return ctx` (line 87-88).
        ic = make_backup_claude_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={"backup_claude_dir": {"status": "dry_run_preview"}},
        )
        result = await ic.leave(ctx)
        assert result is ctx

    @pytest.mark.asyncio
    async def test_leave_rmtree_failure_swallowed(
        self, tmp_path: Path, monkeypatch,
    ):
        # shutil.rmtree raises → swallowed (lines 95-99).
        import shutil
        ic = make_backup_claude_dir_interceptor()
        backup = tmp_path / "_backup_dir"
        backup.mkdir()
        original = shutil.rmtree

        def _boom(*args, **kwargs):
            raise PermissionError("simulated")

        monkeypatch.setattr(shutil, "rmtree", _boom)
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(backup),
                }
            },
        )
        # No exception raised; backup still exists (rmtree failed
        # but leave swallowed it).
        await ic.leave(ctx)

    @pytest.mark.asyncio
    async def test_error_no_backup_path_returns_early(
        self, tmp_path: Path,
    ):
        # `if not backup_path: return ctx` (line 107-108).
        ic = make_backup_claude_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={"backup_claude_dir": {"status": "dry_run_preview"}},
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result is ctx


# ---------------------------------------------------------------------------
# detect_legacy_state
# ---------------------------------------------------------------------------

class TestDetectLegacyState:
    @pytest.mark.asyncio
    async def test_detect_failure_wraps_as_migration_step_failed(
        self, tmp_path: Path, monkeypatch,
    ):
        # detect_legacy_state raises → L24-30 wraps as
        # MigrationStepFailed.
        def _boom(project_dir):
            raise RuntimeError("simulated detect failure")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.detector.detect_legacy_state",
            _boom,
        )
        ic = make_detect_legacy_state_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.error is not None
        assert "detect_legacy_state failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_threads_plan_onto_request(
        self, tmp_path: Path, monkeypatch,
    ):
        plan = SimpleNamespace(
            steps=[_step("translate_config_schema")], warnings=[],
        )
        monkeypatch.setattr(
            "forge_manager_mcp.migration.detector.detect_legacy_state",
            MagicMock(return_value=plan),
        )
        ic = make_detect_legacy_state_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.error is None
        assert result.request["plan"] is plan
        assert result.response["detect_legacy_state"]["step_count"] == 1

    @pytest.mark.asyncio
    async def test_error_is_passthrough(self, tmp_path: Path):
        # error() is read-only → pass through. L58-60.
        ic = make_detect_legacy_state_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            error=MigrationStepFailed("upstream"),
        )
        result = await ic.error(ctx)
        assert result.error is ctx.error


# ---------------------------------------------------------------------------
# translate_schema / rename_skill_dir / rewrite_claude_md
# ---------------------------------------------------------------------------

class TestTranslateSchema:
    @pytest.mark.asyncio
    async def test_skip_when_no_plan(self, tmp_path: Path):
        ic = make_translate_schema_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.response["translate_schema"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_apply_calls_runner_execute_step(
        self, tmp_path: Path, monkeypatch,
    ):
        target_step = _step(
            "translate_config_schema",
            source=".claude/github-config.json",
            target=".claude/forge-config.json",
            translated_data={"schema_version": "3.0"},
        )
        plan = SimpleNamespace(steps=[target_step], warnings=[])
        execute_step = MagicMock()
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            execute_step,
        )
        ic = make_translate_schema_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        execute_step.assert_called_once()
        assert result.response["translate_schema"]["status"] == "ok"


class TestRenameSkillDir:
    @pytest.mark.asyncio
    async def test_compensation_reverses_rename(self, tmp_path: Path):
        # Set up a real on-disk rename — enter ran, wrote target;
        # compensation should reverse-rename target → source.
        source_rel = "skills/forge-manager"
        target_rel = "skills/active-claude-github"  # arbitrary
        # Pre-stage: target exists, source doesn't.
        target_dir = tmp_path / target_rel
        target_dir.mkdir(parents=True)
        ic = make_rename_skill_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "rename_skill_dir": {
                    "status": "ok",
                    "source": source_rel,
                    "target": target_rel,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # Source dir exists post-compensation; target gone.
        assert (tmp_path / source_rel).is_dir()
        assert not (tmp_path / target_rel).exists()
        # Compensation entry recorded.
        assert any(
            s["step"] == "rename_skill_dir" and s.get("compensated")
            for s in result.steps_taken
        )

    # (#428 D-Coverage drain) skip + failure + error edge cases.

    @pytest.mark.asyncio
    async def test_enter_skips_when_no_plan(self, tmp_path: Path):
        ic = make_rename_skill_dir_interceptor()
        # _request defaults set plan=None; verify the skip path.
        request = _request(tmp_path)
        request["plan"] = None
        result = await ic.enter(Context(request=request))
        assert result.response["rename_skill_dir"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_enter_skips_when_no_target_step(self, tmp_path: Path):
        from types import SimpleNamespace
        ic = make_rename_skill_dir_interceptor()
        # Plan with no rename_skill_dir step.
        request = _request(tmp_path)
        request["plan"] = SimpleNamespace(steps=[])
        result = await ic.enter(Context(request=request))
        assert result.response["rename_skill_dir"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_enter_dry_run_records_preview(self, tmp_path: Path):
        from types import SimpleNamespace
        ic = make_rename_skill_dir_interceptor()
        step = SimpleNamespace(
            kind="rename_skill_dir",
            source="src", target="dst", description="rename",
        )
        request = _request(tmp_path, apply=False)
        request["plan"] = SimpleNamespace(steps=[step])
        result = await ic.enter(Context(request=request))
        assert (
            result.response["rename_skill_dir"]["status"]
            == "dry_run_preview"
        )

    @pytest.mark.asyncio
    async def test_enter_apply_success_records_ok(
        self, tmp_path: Path, monkeypatch,
    ):
        from types import SimpleNamespace
        ic = make_rename_skill_dir_interceptor()
        step = SimpleNamespace(
            kind="rename_skill_dir",
            source="src", target="dst", description="rename",
        )
        request = _request(tmp_path, apply=True)
        request["plan"] = SimpleNamespace(steps=[step])
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            lambda pd, step: None,
        )
        result = await ic.enter(Context(request=request))
        assert result.response["rename_skill_dir"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_enter_apply_failure_sets_error(
        self, tmp_path: Path, monkeypatch,
    ):
        from types import SimpleNamespace
        ic = make_rename_skill_dir_interceptor()

        step = SimpleNamespace(
            kind="rename_skill_dir",
            source="src",
            target="dst",
            description="rename",
        )
        request = _request(tmp_path, apply=True)
        request["plan"] = SimpleNamespace(steps=[step])

        def _boom(project_dir, step):
            raise OSError("simulated rename failure")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step", _boom,
        )
        result = await ic.enter(Context(request=request))
        assert isinstance(result.error, MigrationStepFailed)
        assert "rename_skill_dir failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_compensation_no_op_when_step_did_not_succeed(
        self, tmp_path: Path,
    ):
        ic = make_rename_skill_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={"rename_skill_dir": {"status": "skipped"}},
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result is ctx

    @pytest.mark.asyncio
    async def test_compensation_no_op_when_paths_missing(
        self, tmp_path: Path,
    ):
        ic = make_rename_skill_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={"rename_skill_dir": {
                "status": "ok",
                # No source/target keys.
            }},
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result is ctx

    @pytest.mark.asyncio
    async def test_compensation_reverse_rename_failure_records_failed(
        self, tmp_path: Path, monkeypatch,
    ):
        # The compensation rename raises → failed_compensations entry.
        ic = make_rename_skill_dir_interceptor()
        source_rel = "skills/forge-manager"
        target_rel = "skills/active-claude-github"
        (tmp_path / target_rel).mkdir(parents=True)

        from pathlib import Path as _Path
        original_rename = _Path.rename

        def _fail(self, target):
            raise OSError("simulated rename failure")

        monkeypatch.setattr(_Path, "rename", _fail)
        ctx = Context(
            request=_request(tmp_path),
            response={
                "rename_skill_dir": {
                    "status": "ok",
                    "source": source_rel,
                    "target": target_rel,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        failed = result.response.get("failed_compensations", ())
        assert any(
            f.get("step") == "rename_skill_dir" for f in failed
        )


# (#428 D-Coverage drain) rewrite_claude_md — was untested at the
# enter layer; same shape as the rename step.


class TestRewriteClaudeMd:
    @pytest.mark.asyncio
    async def test_enter_skips_when_no_plan(self, tmp_path: Path):
        ic = make_rewrite_claude_md_interceptor()
        request = _request(tmp_path)
        request["plan"] = None
        result = await ic.enter(Context(request=request))
        assert result.response["rewrite_claude_md"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_enter_skips_when_no_update_claude_md_step(
        self, tmp_path: Path,
    ):
        from types import SimpleNamespace
        ic = make_rewrite_claude_md_interceptor()
        request = _request(tmp_path)
        request["plan"] = SimpleNamespace(steps=[])
        result = await ic.enter(Context(request=request))
        assert result.response["rewrite_claude_md"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_enter_dry_run_records_preview(self, tmp_path: Path):
        from types import SimpleNamespace
        ic = make_rewrite_claude_md_interceptor()
        step = SimpleNamespace(
            kind="update_claude_md",
            target=tmp_path / "CLAUDE.md",
            description="rewrite",
        )
        request = _request(tmp_path, apply=False)
        request["plan"] = SimpleNamespace(steps=[step])
        result = await ic.enter(Context(request=request))
        assert (
            result.response["rewrite_claude_md"]["status"]
            == "dry_run_preview"
        )

    @pytest.mark.asyncio
    async def test_enter_apply_failure_sets_error(
        self, tmp_path: Path, monkeypatch,
    ):
        from types import SimpleNamespace
        ic = make_rewrite_claude_md_interceptor()
        step = SimpleNamespace(
            kind="update_claude_md",
            target=tmp_path / "CLAUDE.md",
            description="rewrite",
        )
        request = _request(tmp_path, apply=True)
        request["plan"] = SimpleNamespace(steps=[step])

        def _boom(pd, step):
            raise OSError("simulated rewrite failure")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step", _boom,
        )
        result = await ic.enter(Context(request=request))
        assert isinstance(result.error, MigrationStepFailed)
        assert "rewrite_claude_md failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_enter_apply_success_records_ok(
        self, tmp_path: Path, monkeypatch,
    ):
        from types import SimpleNamespace
        ic = make_rewrite_claude_md_interceptor()
        step = SimpleNamespace(
            kind="update_claude_md",
            target=tmp_path / "CLAUDE.md",
            description="rewrite",
        )
        request = _request(tmp_path, apply=True)
        request["plan"] = SimpleNamespace(steps=[step])
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            lambda pd, step: None,
        )
        result = await ic.enter(Context(request=request))
        assert result.response["rewrite_claude_md"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_error_records_backup_compensation(self, tmp_path: Path):
        ic = make_rewrite_claude_md_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "rewrite_claude_md": {"status": "ok"},
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(tmp_path / "_backup"),
                },
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # Compensation entry references the backup.
        assert any(
            s["step"] == "rewrite_claude_md" for s in result.steps_taken
        )


# ---------------------------------------------------------------------------
# bootstrap_docs_repo
# ---------------------------------------------------------------------------

class TestBootstrapDocsRepoEnterPaths:
    @pytest.mark.asyncio
    async def test_no_plan_skipped(self, tmp_path: Path):
        # L35-36 _record_skip when plan is None.
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path))  # no plan
        result = await ic.enter(ctx)
        assert (
            result.response["bootstrap_docs_repo"]["status"] == "skipped"
        )

    @pytest.mark.asyncio
    async def test_no_bootstrap_step_skipped(self, tmp_path: Path):
        # L42-45 _record_skip when plan exists but no bootstrap step.
        plan = SimpleNamespace(steps=[_step("translate_config_schema")], warnings=[])
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan))
        result = await ic.enter(ctx)
        assert (
            result.response["bootstrap_docs_repo"]["status"] == "skipped"
        )

    @pytest.mark.asyncio
    async def test_dry_run_preview(self, tmp_path: Path):
        # apply=False → L56-57 dry_run_preview with detail.
        step = _step(
            "bootstrap_docs_repo",
            docs_path=str(tmp_path / "p-docs"),
        )
        plan = SimpleNamespace(steps=[step], warnings=[])
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=False))
        result = await ic.enter(ctx)
        assert (
            result.response["bootstrap_docs_repo"]["status"]
            == "dry_run_preview"
        )

    @pytest.mark.asyncio
    async def test_apply_success_records_ok(
        self, tmp_path: Path, monkeypatch,
    ):
        # apply=True, _execute_step succeeds, no manual_step_note →
        # L59-74 ok.
        step = _step(
            "bootstrap_docs_repo",
            docs_path=str(tmp_path / "p-docs"),
        )
        plan = SimpleNamespace(steps=[step], warnings=[])
        execute = MagicMock()
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            execute,
        )
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        assert result.response["bootstrap_docs_repo"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_apply_failure_wraps_as_migration_step_failed(
        self, tmp_path: Path, monkeypatch,
    ):
        # _execute_step raises → L59-67 MigrationStepFailed.
        step = _step(
            "bootstrap_docs_repo",
            docs_path=str(tmp_path / "p-docs"),
        )
        plan = SimpleNamespace(steps=[step], warnings=[])

        def _boom(project_dir, target_step):
            raise RuntimeError("simulated")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            _boom,
        )
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        assert result.error is not None
        assert "bootstrap_docs_repo failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_apply_with_manual_step_note_records_adopted(
        self, tmp_path: Path, monkeypatch,
    ):
        # _execute_step mutates target_step.payload['manual_step_note']
        # — L68-73 detail surfaces adopted_existing=True.
        step = _step(
            "bootstrap_docs_repo",
            docs_path=str(tmp_path / "p-docs"),
        )

        def _record_note(project_dir, target_step):
            target_step.payload["manual_step_note"] = (
                "origin already set differently"
            )

        plan = SimpleNamespace(steps=[step], warnings=[])
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            _record_note,
        )
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        body = result.response["bootstrap_docs_repo"]
        assert body["status"] == "ok"
        assert body["adopted_existing"] is True

    @pytest.mark.asyncio
    async def test_error_status_not_ok_passthrough(self, tmp_path: Path):
        # error() with status != "ok" → L81-83 return ctx unchanged.
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={"bootstrap_docs_repo": {"status": "skipped"}},
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result.steps_taken == ctx.steps_taken

    @pytest.mark.asyncio
    async def test_error_no_docs_path_passthrough(self, tmp_path: Path):
        # error() with ok-status but no docs_path → L105-106 return ctx.
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "existed_before": False,
                    # No docs_path
                },
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result.steps_taken == ctx.steps_taken

    @pytest.mark.asyncio
    async def test_error_rmtree_failure_records_failed_compensation(
        self, tmp_path: Path, monkeypatch,
    ):
        # shutil.rmtree raises → L120-135 failed_compensations entry.
        import shutil
        docs = tmp_path / "docs"
        docs.mkdir()

        def _fail_rmtree(path, ignore_errors=True):
            raise OSError("simulated rmtree failure")

        monkeypatch.setattr(shutil, "rmtree", _fail_rmtree)
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "docs_path": str(docs),
                    "existed_before": False,
                },
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        failed = result.response.get("failed_compensations", ())
        assert any(
            f["step"] == "bootstrap_docs_repo" for f in failed
        )


class TestBootstrapDocsRepo:
    @pytest.mark.asyncio
    async def test_compensation_preserves_when_adopted(self, tmp_path: Path):
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "docs_path": str(tmp_path / "docs"),
                    "existed_before": True,
                    "adopted_existing": True,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is False
        assert "adopted" in compensation["detail"]["reason"]

    @pytest.mark.asyncio
    async def test_compensation_deletes_when_created(self, tmp_path: Path):
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "marker.txt").write_text("hi")
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "docs_path": str(docs),
                    "existed_before": False,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # docs dir deleted by compensation.
        assert not docs.exists()
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is True


# ---------------------------------------------------------------------------
# backfill_canonical_from_remote
# ---------------------------------------------------------------------------

class TestBackfillCanonicalFromRemoteEnterPaths:
    @pytest.mark.asyncio
    async def test_dry_run_preview(self, tmp_path: Path):
        # backfill_since present, apply=False → L40-47 dry_run_preview.
        from datetime import datetime, timezone
        ic = make_backfill_canonical_from_remote_interceptor()
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        ctx = Context(request=_request(
            tmp_path,
            backfill_since=cutoff,
            backfill_remote="github",
            apply=False,
        ))
        result = await ic.enter(ctx)
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "dry_run_preview"
        )

    @pytest.mark.asyncio
    async def test_no_replication_skipped(self, tmp_path: Path):
        # apply=True + backfill_since + no replication → L48-52 skip.
        from datetime import datetime, timezone
        ic = make_backfill_canonical_from_remote_interceptor()
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        ctx = Context(request=_request(
            tmp_path,
            backfill_since=cutoff,
            backfill_remote="github",
            apply=True,
            replication=None,
        ))
        result = await ic.enter(ctx)
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "skipped"
        )

    @pytest.mark.asyncio
    async def test_not_implemented_error_records_deferred(
        self, tmp_path: Path,
    ):
        # replication.import_remote_changes raises NotImplementedError
        # → L58-72 deferred.
        from datetime import datetime, timezone

        class _Repl:
            async def import_remote_changes(self, *, since, source_platform_id):
                raise NotImplementedError("not yet wired")

        ic = make_backfill_canonical_from_remote_interceptor()
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        ctx = Context(request=_request(
            tmp_path,
            backfill_since=cutoff,
            backfill_remote="github",
            apply=True,
            replication=_Repl(),
        ))
        result = await ic.enter(ctx)
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "deferred"
        )

    @pytest.mark.asyncio
    async def test_general_exception_records_degraded(self, tmp_path: Path):
        # replication.import_remote_changes raises other Exception →
        # L73-78 degraded.
        from datetime import datetime, timezone

        class _Repl:
            async def import_remote_changes(self, *, since, source_platform_id):
                raise RuntimeError("simulated")

        ic = make_backfill_canonical_from_remote_interceptor()
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        ctx = Context(request=_request(
            tmp_path,
            backfill_since=cutoff,
            backfill_remote="github",
            apply=True,
            replication=_Repl(),
        ))
        result = await ic.enter(ctx)
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "degraded"
        )

    @pytest.mark.asyncio
    async def test_success_records_ok(self, tmp_path: Path):
        # Happy path: replication returns a report → L80-87 ok.
        from datetime import datetime, timezone

        class _Report:
            applied = [1, 2, 3]
            conflicts = []
            skipped = []

        class _Repl:
            async def import_remote_changes(self, *, since, source_platform_id):
                return _Report()

        ic = make_backfill_canonical_from_remote_interceptor()
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        ctx = Context(request=_request(
            tmp_path,
            backfill_since=cutoff,
            backfill_remote="github",
            apply=True,
            replication=_Repl(),
        ))
        result = await ic.enter(ctx)
        body = result.response["backfill_canonical_from_remote"]
        assert body["status"] == "ok"
        assert body["imported"] == 3

    @pytest.mark.asyncio
    async def test_error_status_not_ok_or_degraded_passthrough(
        self, tmp_path: Path,
    ):
        # error() with status="skipped" → L95-96 return ctx (no
        # compensation appended).
        ic = make_backfill_canonical_from_remote_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "backfill_canonical_from_remote": {"status": "skipped"},
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert result.steps_taken == ctx.steps_taken


class TestBackfillCanonicalFromRemote:
    @pytest.mark.asyncio
    async def test_skip_when_no_since(self, tmp_path: Path):
        ic = make_backfill_canonical_from_remote_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "skipped"
        )

    @pytest.mark.asyncio
    async def test_compensation_is_passthrough(self, tmp_path: Path):
        ic = make_backfill_canonical_from_remote_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "backfill_canonical_from_remote": {
                    "status": "ok",
                    "imported": 5,
                    "conflicts": 0,
                    "skipped": 0,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        # User data is not undone.
        assert compensation["compensated"] is False
        assert "user data" in compensation["detail"]["reason"]


# ---------------------------------------------------------------------------
# finalize
# ---------------------------------------------------------------------------

class TestFinalize:
    @pytest.mark.asyncio
    async def test_error_passthrough(self, tmp_path: Path):
        # finalize.error is a pass-through. L49-53.
        ic = make_finalize_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            error=MigrationStepFailed("upstream"),
        )
        result = await ic.error(ctx)
        assert result.error is ctx.error

    @pytest.mark.asyncio
    async def test_summarises_completed_and_skipped(self, tmp_path: Path):
        ic = make_finalize_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "translate_schema": {"status": "ok"},
                "rename_skill_dir": {"status": "ok"},
                "bootstrap_docs_repo": {"status": "skipped"},
            },
        )
        result = await ic.enter(ctx)
        f = result.response["finalize"]
        assert f["status"] == "ok"
        assert "translate_schema" in f["completed_steps"]
        assert "rename_skill_dir" in f["completed_steps"]
        assert "bootstrap_docs_repo" in f["skipped_steps"]


# ---------------------------------------------------------------------------
# Chain composer
# ---------------------------------------------------------------------------

class TestBuildMigrationChain:
    def test_full_chain_ordering(self):
        chain = build_migration_chain()
        names = [ic.name for ic in chain]
        assert names == [
            "migration.backup_claude_dir",
            "migration.detect_legacy_state",
            "migration.translate_schema",
            "migration.rename_skill_dir",
            "migration.bootstrap_docs_repo",
            "migration.rewrite_claude_md",
            "migration.backfill_canonical_from_remote",
            "migration.finalize",
        ]

    def test_skip_backfill(self):
        chain = build_migration_chain(include_backfill=False)
        names = [ic.name for ic in chain]
        assert "migration.backfill_canonical_from_remote" not in names
        # Ordering preserved otherwise.
        assert names[0] == "migration.backup_claude_dir"
        assert names[-1] == "migration.finalize"


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) translate_schema edge branches.
# ---------------------------------------------------------------------------


class TestTranslateSchemaEdgeBranches:
    @pytest.mark.asyncio
    async def test_skip_when_plan_has_no_translate_step(
        self, tmp_path: Path,
    ):
        # Plan exists but no translate_config_schema step → L40-43
        # _record_skip.
        plan = SimpleNamespace(steps=[
            _step("rename_skill_dir", source="a", target="b"),
        ], warnings=[])
        ic = make_translate_schema_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        assert result.response["translate_schema"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_dry_run_records_preview(self, tmp_path: Path):
        # Plan with translate step + apply=False → L45-50 dry-run.
        target_step = _step(
            "translate_config_schema",
            source=".claude/github-config.json",
            target=".claude/forge-config.json",
            translated_data={"schema_version": "3.0"},
        )
        plan = SimpleNamespace(steps=[target_step], warnings=[])
        ic = make_translate_schema_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=False))
        result = await ic.enter(ctx)
        assert result.response["translate_schema"]["status"] == "dry_run_preview"

    @pytest.mark.asyncio
    async def test_apply_failure_returns_error_envelope(
        self, tmp_path: Path, monkeypatch,
    ):
        # _execute_step raises → L52-58 return ctx with
        # MigrationStepFailed error.
        target_step = _step(
            "translate_config_schema",
            source=".claude/github-config.json",
            target=".claude/forge-config.json",
            translated_data={"schema_version": "3.0"},
        )
        plan = SimpleNamespace(steps=[target_step], warnings=[])

        def _boom(project_dir, step):
            raise RuntimeError("simulated execute_step failure")

        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            _boom,
        )
        ic = make_translate_schema_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        assert result.error is not None
        assert "translate_schema failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_compensation_skipped_when_step_not_ok(
        self, tmp_path: Path,
    ):
        # _record_backup_compensation: recorded.status != "ok" →
        # L132-134 return ctx unchanged.
        ic = make_translate_schema_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "translate_schema": {"status": "skipped"},
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # No compensation entry recorded.
        assert not any(
            s.get("step") == "translate_schema"
            for s in result.steps_taken
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
