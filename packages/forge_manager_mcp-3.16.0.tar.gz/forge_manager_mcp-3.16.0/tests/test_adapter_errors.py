"""Unit tests for the adapter error hierarchy + is_forge_unavailable predicate (3.0 / Phase 2)."""
from __future__ import annotations

import httpx
import pytest

from forge_manager_mcp.adapters.errors import (
    ConsentRequiredError,
    ForgeError,
    ForgeUnavailableError,
    InvalidArtifactRefError,
    LocalStoreAlreadyExistsError,
    is_forge_unavailable,
    is_permanent_error,
)


class TestSubclassRelationship:
    def test_unavailable_is_a_forge_error(self):
        assert isinstance(ForgeUnavailableError("x"), ForgeError)

    def test_invalid_ref_is_a_forge_error(self):
        assert isinstance(InvalidArtifactRefError("ref", "bad"), ForgeError)

    def test_base_forge_error_not_unavailable(self):
        assert not isinstance(ForgeError("x"), ForgeUnavailableError)

    def test_unavailable_carries_status(self):
        exc = ForgeUnavailableError("rate limit", status_code=429, body="...")
        assert exc.status_code == 429
        assert exc.body == "..."


class TestIsForgeUnavailableTrue:
    """Cases that SHOULD trigger fallback / replay queueing."""

    def test_explicit_unavailable_subclass(self):
        assert is_forge_unavailable(ForgeUnavailableError("any"))

    @pytest.mark.parametrize("status", [401, 403, 429, 502, 503, 504])
    def test_status_codes_classified_as_unavailable(self, status):
        exc = ForgeError("HTTP error", status_code=status, body="")
        assert is_forge_unavailable(exc), (
            f"status {status} should classify as unavailable"
        )

    def test_timeout_chained_via_httpx(self):
        underlying = httpx.TimeoutException("read timeout")
        exc = ForgeError("API request timed out.")
        exc.__cause__ = underlying
        assert is_forge_unavailable(exc)

    def test_connect_error_chained(self):
        underlying = httpx.ConnectError("DNS failed")
        exc = ForgeError("API network error.")
        exc.__cause__ = underlying
        assert is_forge_unavailable(exc)

    def test_user_subclass_of_unavailable(self):
        class CustomOutage(ForgeUnavailableError):
            pass

        assert is_forge_unavailable(CustomOutage("custom"))


class TestIsForgeUnavailableFalse:
    """Cases that should NOT trigger fallback (caller-fault)."""

    @pytest.mark.parametrize("status", [400, 404, 405, 409, 422, 500, 501])
    def test_caller_fault_codes_not_unavailable(self, status):
        exc = ForgeError("HTTP error", status_code=status)
        assert not is_forge_unavailable(exc)

    def test_no_status_no_cause_is_caller_fault(self):
        exc = ForgeError("opaque failure")
        assert not is_forge_unavailable(exc)

    def test_invalid_ref_error_not_unavailable(self):
        # Stale/bad refs are caller-fault; retrying with the same ref
        # would fail identically.
        exc = InvalidArtifactRefError("issue_id", "I_kwDObogus")
        assert not is_forge_unavailable(exc)

    def test_arbitrary_chained_cause_not_unavailable(self):
        exc = ForgeError("opaque")
        exc.__cause__ = ValueError("non-httpx cause")
        assert not is_forge_unavailable(exc)

    def test_value_error_not_unavailable(self):
        assert not is_forge_unavailable(ValueError("not a forge error"))

    def test_runtime_error_not_unavailable(self):
        # ForgeError inherits from RuntimeError, but a bare RuntimeError
        # isn't a ForgeError and shouldn't match.
        assert not is_forge_unavailable(RuntimeError("generic"))


class TestEdgeCases:
    def test_none_returns_false(self):
        assert not is_forge_unavailable(None)  # type: ignore[arg-type]

    def test_string_returns_false(self):
        assert not is_forge_unavailable("not an exception")  # type: ignore[arg-type]


class TestDuckTypedStatusCode:
    """(#362, 3.7.0 D1) Predicate duck-types on ``status_code`` so legacy
    GitHubError-shape exceptions (which don't subclass ForgeError) are
    classified correctly when their status is in the unavailable set.

    Pre-#362 the predicate matched only ForgeError subclasses; a 403
    raised by the github/* layer as ``GitHubError`` fell through to the
    catch-all return False, and the ReplicationManager's state machine
    never transitioned the adapter to DEGRADED.
    """

    def _legacy_github_error(self, status: int):
        """Construct a GitHubError-shape exception that doesn't subclass
        ForgeError. Mirrors the legacy github.core.GitHubError shape:
        RuntimeError + status_code attribute + body attribute."""
        exc = RuntimeError(f"GitHub API returned HTTP {status}.")
        exc.status_code = status  # type: ignore[attr-defined]
        exc.body = ""  # type: ignore[attr-defined]
        return exc

    def test_legacy_github_403_classified_as_unavailable(self):
        # Account-suspension scenario the project has been hitting since
        # 2026-04-28 — every API call returns HTTP 403. Without the
        # duck-type, replication state machine ignored these.
        assert is_forge_unavailable(self._legacy_github_error(403))

    def test_legacy_github_401_classified_as_unavailable(self):
        # Token-expired scenario; same shape as 403.
        assert is_forge_unavailable(self._legacy_github_error(401))

    def test_legacy_github_429_classified_as_unavailable(self):
        # Rate-limited.
        assert is_forge_unavailable(self._legacy_github_error(429))

    def test_legacy_github_502_classified_as_unavailable(self):
        # Provider hiccup.
        assert is_forge_unavailable(self._legacy_github_error(502))

    def test_legacy_github_404_NOT_classified_as_unavailable(self):
        # Caller-fault: stale ref. Must propagate, not trigger DEGRADED.
        assert not is_forge_unavailable(self._legacy_github_error(404))

    def test_legacy_github_422_NOT_classified_as_unavailable(self):
        # Caller-fault: validation error. Must propagate.
        assert not is_forge_unavailable(self._legacy_github_error(422))

    def test_unknown_status_code_NOT_classified_as_unavailable(self):
        # Anything outside the explicit unavailable set is treated as
        # caller-fault, conservative default.
        assert not is_forge_unavailable(self._legacy_github_error(418))

    def test_runtime_error_without_status_code_NOT_classified(self):
        # Plain RuntimeError without a status_code attribute returns
        # False — duck-typing requires the attribute to be present.
        assert not is_forge_unavailable(RuntimeError("plain"))


class TestInvalidArtifactRefError:
    def test_message_includes_param_name_and_value(self):
        exc = InvalidArtifactRefError("issue_id", "I_kwDObogus")
        assert "issue_id" in str(exc)
        assert "I_kwDObogus" in str(exc)
        assert exc.param_name == "issue_id"
        assert exc.value == "I_kwDObogus"


# (#465) is_permanent_error — companion predicate to is_forge_unavailable.
# Permanent = retry futile; transient = retry may help.


class TestIsPermanentErrorTrue:
    """Exceptions that should classify as permanent (no buffer)."""

    def test_invalid_artifact_ref_is_permanent(self):
        exc = InvalidArtifactRefError("issue_id", "I_kwDObogus")
        assert is_permanent_error(exc) is True

    def test_value_error_is_permanent(self):
        assert is_permanent_error(ValueError("bad input")) is True

    def test_invalid_node_id_error_is_permanent(self):
        # InvalidNodeIdError lives in github/core.py and isn't in this
        # test target's dep-graph closure (#198 dep discipline). Duck-
        # type via class name; `is_permanent_error` matches on the
        # class name, not via isinstance.
        class InvalidNodeIdError(Exception):  # noqa: N818 — mirrors real shape
            pass
        exc = InvalidNodeIdError("bogus node id")
        assert is_permanent_error(exc) is True

    def test_classification_error_is_permanent(self):
        # Same — ClassificationError lives in forge_manager_mcp.
        # classification, not in dep closure. Duck-type via class
        # name.
        class ClassificationError(RuntimeError):
            pass
        exc = ClassificationError("rule violated")
        assert is_permanent_error(exc) is True

    @pytest.mark.parametrize("status", [400, 404, 405, 409, 422])
    def test_forge_error_with_caller_fault_status_is_permanent(self, status):
        exc = ForgeError("caller-fault", status_code=status)
        assert is_permanent_error(exc) is True, (
            f"status {status} should classify as permanent"
        )

    def test_consent_required_error_is_permanent(self):
        # (#458) ConsentRequiredError — caller didn't pass consent;
        # retry-with-same-args fails identically. Permanent.
        exc = ConsentRequiredError("consent missing")
        assert is_permanent_error(exc) is True

    def test_consent_required_error_is_forge_error(self):
        # ConsentRequiredError subclasses ForgeError so existing
        # except-ForgeError clauses catch it.
        exc = ConsentRequiredError("x")
        assert isinstance(exc, ForgeError)


class TestIsPermanentErrorFalse:
    """Exceptions that should NOT classify as permanent (buffer OK)."""

    def test_forge_unavailable_not_permanent(self):
        # 429 rate-limit is transient — daemon-side reconciliation
        # should re-attempt after a backoff. Not permanent.
        exc = ForgeUnavailableError("rate limit", status_code=429)
        assert is_permanent_error(exc) is False

    @pytest.mark.parametrize("status", [429, 502, 503, 504])
    def test_transient_unavailable_status_codes_not_permanent(self, status):
        # 429 (rate limit) / 5xx (service hiccup) are transient even
        # under the #485 auth-failure extension — they're independent
        # of credential state and a retry-after-backoff is the right
        # response.
        exc = ForgeError("HTTP", status_code=status)
        assert is_permanent_error(exc) is False, (
            f"status {status} is transient, not permanent"
        )

    def test_bare_403_without_auth_marker_not_permanent(self):
        # (#485) HTTP 403 without an auth-failure marker stays
        # transient — visibility-change races, ephemeral
        # permission-scope flips, mid-rotation credentials all
        # surface as 403 and could recover on retry.
        exc = ForgeError("HTTP", status_code=403, body="forbidden")
        assert is_permanent_error(exc) is False

    def test_forge_error_with_no_status_is_not_permanent(self):
        # Opaque ForgeError without status info — could be either.
        # Default to NOT permanent to preserve buffering safety net.
        exc = ForgeError("opaque")
        assert is_permanent_error(exc) is False

    def test_arbitrary_runtime_error_not_permanent(self):
        # Unknown exception class shouldn't be classified as permanent.
        assert is_permanent_error(RuntimeError("unknown")) is False

    def test_none_returns_false(self):
        assert is_permanent_error(None) is False  # type: ignore[arg-type]


class TestIsPermanentVsForgeUnavailableComplement:
    """The two predicates partition the relevant exception space without
    overlap on the classified cases:
        permanent: caller-fault statuses + explicit perm-class
        unavailable: service-fault statuses + ForgeUnavailableError
        neither: opaque, unknown, daemon-down (transient-but-not-unavail)
    """

    def test_no_overlap_on_permanent_status(self):
        # 404 → permanent, NOT unavailable.
        exc = ForgeError("not found", status_code=404)
        assert is_permanent_error(exc) is True
        assert is_forge_unavailable(exc) is False

    def test_no_overlap_on_unavailable_status(self):
        # 429 → unavailable, NOT permanent.
        exc = ForgeError("rate limit", status_code=429)
        assert is_forge_unavailable(exc) is True
        assert is_permanent_error(exc) is False

    def test_overlap_allowed_for_auth_failure_403(self):
        # (#485) Suspended-account 403 is BOTH unavailable (state
        # machine marks DEGRADED) AND permanent (don't buffer for
        # replay). Predicates are independent — no inverse contract.
        exc = ForgeError(
            "GitHub API returned HTTP 403.",
            status_code=403,
            body='{"message":"Bad credentials"}',
        )
        assert is_forge_unavailable(exc) is True
        assert is_permanent_error(exc) is True

    def test_overlap_on_bare_401(self):
        # (#485) HTTP 401 is always permanent (auth misconfigured)
        # AND classifies as unavailable for state-machine purposes.
        exc = ForgeError("Unauthorized", status_code=401)
        assert is_forge_unavailable(exc) is True
        assert is_permanent_error(exc) is True

    def test_invalid_ref_is_permanent_not_unavailable(self):
        exc = InvalidArtifactRefError("ref", "bad")
        assert is_permanent_error(exc) is True
        assert is_forge_unavailable(exc) is False


# (#485) HTTP 401/403 auth-failure classification.
#
# Extends is_permanent_error to cover the suspended-account /
# missing-token / bad-credentials path the 3.13.0 #462+#465 work
# missed. Pre-#485 every HTTP 403 from the suspended-GitHub account
# buffered to .claude/pending-posts.md — guaranteed-stale on every
# retry, polluting the buffer with entries the operator had to
# manually clean.
#
# Test corpus mirrors the 9 stale buffered entries from the
# 2026-05-14 session (#475-483) that the AC mandates coverage for:
# every one carried the "GitHub API returned HTTP 403." message with
# the suspended-account 'Bad credentials' body.


class TestIsPermanentErrorAuthFailure:
    """(#485) HTTP 401/403 with auth-failure markers classify as
    permanent — retry-with-same-args fails identically until the
    operator rotates / re-installs credentials."""

    def test_bare_401_is_permanent(self):
        # Any HTTP 401 is permanent — every supported backend means
        # "your credentials are invalid." No marker needed.
        exc = ForgeError("Unauthorized", status_code=401)
        assert is_permanent_error(exc) is True

    def test_401_on_forge_unavailable_is_permanent(self):
        # The _to_forge_error normalization at adapters/github.py
        # elevates 401/403 to ForgeUnavailableError. The 401 path
        # should still classify as permanent.
        exc = ForgeUnavailableError(
            "Unauthorized", status_code=401, body=""
        )
        assert is_permanent_error(exc) is True

    def test_403_with_no_token_message_is_permanent(self):
        # The daemon's startup_probe synthesizes StartupProbeError
        # with this exact phrase when GITHUB_TOKEN is unset.
        # ReplicationManager surfaces it as the entry's last_error.
        # When a write fires against that adapter, the resulting
        # 403 carries the same message.
        exc = ForgeUnavailableError(
            "no token available in environment",
            status_code=403,
            body="",
        )
        assert is_permanent_error(exc) is True

    def test_403_with_bad_credentials_body_is_permanent(self):
        # GitHub's REST/GraphQL error envelope when the token is
        # revoked, expired, or never had access to the resource.
        # Body is the verbatim HTTP response body GitHubError
        # preserves via the body= kwarg.
        exc = ForgeUnavailableError(
            "GitHub API returned HTTP 403.",
            status_code=403,
            body='{"message":"Bad credentials","documentation_url":"..."}',
        )
        assert is_permanent_error(exc) is True

    def test_403_with_account_suspended_body_is_permanent(self):
        # GitHub's response when the owning account is under
        # suspension review. Same shape as Bad credentials but
        # different marker. Per project history: the dev account has
        # been suspended since 2026-04-28; every public-mirror push
        # gets this response.
        exc = ForgeUnavailableError(
            "GitHub API returned HTTP 403.",
            status_code=403,
            body='{"message":"This account has been suspended..."}',
        )
        assert is_permanent_error(exc) is True

    def test_403_with_insufficient_scope_is_permanent(self):
        # OAuth scope misconfig — operator must reinstall the app
        # with the correct scopes; retry-with-same-token fails
        # identically.
        exc = ForgeUnavailableError(
            "insufficient_scope: repo write required",
            status_code=403,
            body="",
        )
        assert is_permanent_error(exc) is True

    def test_403_must_be_authenticated_is_permanent(self):
        # GitLab's auth-failure envelope wording.
        exc = ForgeUnavailableError(
            "401 Unauthorized: You must be authenticated.",
            status_code=401,
            body="",
        )
        assert is_permanent_error(exc) is True

    def test_legacy_github_error_403_with_marker_is_permanent(self):
        # Pre-#465 some call sites raised legacy GitHubError (not a
        # ForgeError subclass) directly. Duck-typing via
        # status_code attribute means the predicate classifies the
        # same — defensive coverage even though _to_forge_error
        # should now normalize at every adapter boundary.
        class GitHubError(RuntimeError):
            def __init__(self, msg: str, status_code: int, body: str = ""):
                super().__init__(msg)
                self.status_code = status_code
                self.body = body

        exc = GitHubError(
            "GitHub API returned HTTP 403.",
            status_code=403,
            body='{"message":"Bad credentials"}',
        )
        assert is_permanent_error(exc) is True

    def test_legacy_github_error_bare_401_is_permanent(self):
        # Defensive coverage for legacy GitHubError(status=401)
        # without auth-marker body — bare 401 still classifies.
        class GitHubError(RuntimeError):
            def __init__(self, msg: str, status_code: int):
                super().__init__(msg)
                self.status_code = status_code
                self.body = ""

        exc = GitHubError("Unauthorized", status_code=401)
        assert is_permanent_error(exc) is True

    def test_403_without_auth_marker_stays_transient(self):
        # Critical contract: bare 403 with no auth-failure marker
        # stays transient. Visibility-change races and mid-rotation
        # token windows preserve their buffer-and-retry safety net.
        exc = ForgeUnavailableError(
            "Forbidden",
            status_code=403,
            body="resource access denied",
        )
        assert is_permanent_error(exc) is False

    def test_429_stays_transient_even_with_auth_text(self):
        # Status code gating: 429 stays transient regardless of
        # message content. Auth-failure markers are 401/403-only.
        exc = ForgeUnavailableError(
            "rate limit exceeded; bad credentials",
            status_code=429,
            body="",
        )
        assert is_permanent_error(exc) is False

    def test_marker_match_is_case_insensitive(self):
        exc = ForgeUnavailableError(
            "BAD CREDENTIALS",
            status_code=403,
            body="",
        )
        assert is_permanent_error(exc) is True


# (#470 sub-fix 2a) LocalStoreAlreadyExistsError classification.


class TestLocalStoreAlreadyExistsErrorClassification:
    """The class exists so a caller-fault idempotency violation
    doesn't trip the canonical adapter to DEGRADED. Predicate
    contracts:

      * is_forge_unavailable → False (canonical is healthy)
      * is_permanent_error   → True  (retry-with-same-args fails)
    """

    def _err(self, artifact_kind="milestone", artifact_id="3.13.0"):
        return LocalStoreAlreadyExistsError(
            f"LocalStoreAdapter.create_{artifact_kind}: "
            f"compound-doc already exists at /tmp/{artifact_kind}/{artifact_id}.",
            artifact_kind=artifact_kind,
            artifact_id=artifact_id,
        )

    def test_subclass_of_forge_error(self):
        exc = self._err()
        assert isinstance(exc, ForgeError)
        # NOT a ForgeUnavailableError — different semantic.
        assert not isinstance(exc, ForgeUnavailableError)

    def test_carries_artifact_metadata(self):
        exc = self._err(artifact_kind="milestone", artifact_id="3.14.0")
        assert exc.artifact_kind == "milestone"
        assert exc.artifact_id == "3.14.0"

    def test_status_code_is_none(self):
        # No HTTP semantics — this is a filesystem-side idempotency
        # check. status_code is None so the duck-typed predicate
        # branch never matches; the explicit isinstance check is the
        # only path.
        exc = self._err()
        assert exc.status_code is None

    def test_NOT_classified_as_forge_unavailable(self):
        # (#470 sub-fix 2a) Critical contract — this is the bug
        # filed in #470. Pre-fix this exception (raised by
        # create_milestone) classified as forge-unavailable via
        # ForgeError having a status_code attribute (and even
        # without status, the canonical-write blanket
        # except-BaseException unconditionally DEGRADED). Now the
        # predicate returns False so the canonical adapter stays
        # HEALTHY.
        assert is_forge_unavailable(self._err()) is False

    def test_classified_as_permanent(self):
        # Retry-with-same-args fails identically — caller must
        # either map to update_* or treat as success. Permanent so
        # the dispatch wrapper doesn't buffer for replay.
        assert is_permanent_error(self._err()) is True

    def test_does_not_overlap_unavailable(self):
        # Negative-space guard. Pre-#470 a sticky-DEGRADED canonical
        # local could occur if these overlapped.
        exc = self._err()
        assert is_forge_unavailable(exc) is False
        assert is_permanent_error(exc) is True

    def test_subclasses_classify_same(self):
        # User-defined subclasses of LocalStoreAlreadyExistsError
        # inherit the classification by isinstance.
        class IssueAlreadyExistsError(LocalStoreAlreadyExistsError):
            pass

        exc = IssueAlreadyExistsError("dup", artifact_kind="issue", artifact_id="42")
        assert is_forge_unavailable(exc) is False
        assert is_permanent_error(exc) is True


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
