"""Unit tests for forge_manager_mcp.audit_prose (#290).

Per-category detector tests with sample prose. Conformance test against
this dev repo's CLAUDE.md verifies the four ## Overrides subsections
are detected (high-confidence). Apply-mode tests verify generated
migrated text matches #288's project-rules.md schema.
"""
from __future__ import annotations

import textwrap
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from forge_manager_mcp.audit_prose import (
    AuditError,
    Finding,
    apply_finding,
    audit_prose,
)
from forge_manager_mcp.gate_registry import Gate, GateRegistry
from forge_manager_mcp.project_rules import parse_project_rules


def _make_gate(
    name: str,
    *,
    summary: str = "",
    notes: str | None = None,
    gtype: str = "pre-commit",
    location_file: str = "commit-rules.md",
) -> Gate:
    return Gate(
        name=name,
        type=gtype,
        location=f"{location_file}#{name}",
        summary=summary or name,
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"{location_file}#{name}",
        introduced_in="1.0.0",
        notes=notes,
    )


def _registry_with_test_coverage() -> GateRegistry:
    return GateRegistry([
        _make_gate(
            "commit.test_coverage",
            summary="every new code path in the diff is exercised by at least one test in the same commit",
            notes="Skill ships no default evaluator — qualitative bar lives in project rules.",
        ),
        _make_gate(
            "commit.llm_verifier",
            summary="LLM checks that plan assumptions still hold against current code",
            notes="Backed by verify_existing_code_assumptions. Auto-comment by default.",
            location_file="validation.md",
        ),
    ])


# ---------------------------------------------------------------------------
# Per-category detector tests
# ---------------------------------------------------------------------------


def _write(path: Path, name: str, body: str) -> Path:
    f = path / name
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(body)
    return f


class TestGateExtensionCandidate:
    def test_high_confidence_explicit_extends(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            # Project

            ## Overrides

            ### Maximal Test Coverage Required
            Extends §Commit Rules. Every new code path must be exercised
            by at least one test in the same commit.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        ext_findings = [
            f for f in report.findings
            if f.category == "gate_extension_candidate"
            and f.suspected_gate == "commit.test_coverage"
            and f.confidence == "high"
        ]
        assert ext_findings, f"expected high-confidence extension finding, got: {report.findings}"

    def test_medium_confidence_keyword_overlap(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            ## Project Rules

            Every new function must have at least one test covering its
            new code path before any commit.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        ext = [
            f for f in report.findings
            if f.category == "gate_extension_candidate"
            and f.suspected_gate == "commit.test_coverage"
        ]
        assert ext, "expected at least one extension finding"
        assert ext[0].confidence in ("medium", "low")

    def test_no_finding_without_signals(self, tmp_path: Path) -> None:
        body = "# README\n\nAbout this project.\n"
        _write(tmp_path, "README.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        ext = [
            f for f in report.findings
            if f.category == "gate_extension_candidate"
        ]
        assert ext == []


class TestGateOverrideCandidate:
    def test_explicit_overrides(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            ## Overrides

            ### Override commit test coverage
            This project overrides §Commit Rules with a custom evaluator
            because the test framework requires running tests every commit.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        ovr = [
            f for f in report.findings
            if f.category == "gate_override_candidate"
        ]
        assert ovr, "expected override finding"


class TestGateClosureCandidate:
    def test_closure_for_llm_verifier(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            ## Configuration

            ### LLM verifier disabled
            ANTHROPIC_API_KEY is not configured for this project, so the
            LLM verifier is skipped. The plan assumptions check runs
            without it.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        closures = [
            f for f in report.findings
            if f.category == "gate_closure_candidate"
            and f.suspected_gate == "commit.llm_verifier"
        ]
        assert closures, f"expected closure finding for commit.llm_verifier, got: {report.findings}"


class TestProtocolConceptRedefinition:
    def test_running_log_mention(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            ## Documentation conventions

            The running-log Discussion at Project category collects
            historical Discussion threads. Architecture Discussions are
            for things that can reach Decided.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        concepts = [
            f for f in report.findings
            if f.category == "protocol_concept_redefinition"
        ]
        assert concepts, "expected concept-redefinition finding"


class TestRulesInIdentityDoc:
    def test_overrides_subsection_high_confidence(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            # Project

            ## Overrides

            ### Use Bazel for everything

            Every language uses Bazel. No language-native runners.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        rules = [
            f for f in report.findings
            if f.category == "rules_in_identity_doc"
        ]
        assert rules, "expected rules-in-identity-doc finding"
        assert rules[0].confidence == "high"

    def test_only_subsections_flagged_not_umbrella(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            # Project

            ## Overrides

            (No subsections.)
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        rules = [
            f for f in report.findings
            if f.category == "rules_in_identity_doc"
        ]
        assert rules == []


class TestIdentityInRulesDoc:
    def test_repo_metadata_in_project_rules(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            # Project Rules — testproj

            ## Independent rules

            ### Project facts
            repo: telejester-claude-skills/foo
            owner: telejester-claude-skills
            account type: org
        """)
        _write(tmp_path, ".claude/project-rules.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        identity = [
            f for f in report.findings
            if f.category == "identity_in_rules_doc"
        ]
        assert identity, "expected identity-in-rules-doc finding"


# ---------------------------------------------------------------------------
# Apply mode + summary
# ---------------------------------------------------------------------------


class TestApplyMode:
    def test_apply_extension_finding_renders_valid_project_rules(
        self, tmp_path: Path
    ) -> None:
        body = textwrap.dedent("""\
            # Project

            ## Overrides

            ### Maximal Test Coverage Required
            Extends §Commit Rules. Every new code path must be exercised
            by at least one test in the same commit.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        registry = _registry_with_test_coverage()
        report = audit_prose(tmp_path, registry)
        ext = [
            f for f in report.findings
            if f.category == "gate_extension_candidate"
            and f.confidence == "high"
        ][0]
        migrated = apply_finding(ext, registry)
        assert "### Extends `commit.test_coverage`" in migrated
        assert "**Extension:**" in migrated
        # The rendered text should parse cleanly under #288's parser.
        full_doc = "## Gate extensions\n\n" + migrated
        rules = parse_project_rules(full_doc)
        assert "commit.test_coverage" in rules.extensions

    def test_apply_concept_finding_raises(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            ## Conventions

            running-log Discussions live in the Project category.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        registry = _registry_with_test_coverage()
        report = audit_prose(tmp_path, registry)
        concept = [
            f for f in report.findings
            if f.category == "protocol_concept_redefinition"
        ][0]
        # Concept findings have no suggested_text → apply_finding raises.
        with pytest.raises(AuditError):
            apply_finding(concept, registry)


class TestSummary:
    def test_summary_counts(self, tmp_path: Path) -> None:
        body = textwrap.dedent("""\
            # P

            ## Overrides

            ### A
            Extends §Commit Rules. Every new code path must be tested.

            ### B
            Use Bazel for everything.
        """)
        _write(tmp_path, "CLAUDE.md", body)
        report = audit_prose(tmp_path, _registry_with_test_coverage())
        s = report.summary
        assert s.total_findings == len(report.findings)
        assert sum(s.by_category.values()) == s.total_findings
        assert sum(s.by_confidence.values()) == s.total_findings


class TestSinceFilter:
    def test_old_files_skipped(self, tmp_path: Path) -> None:
        old_path = _write(tmp_path, "CLAUDE.md", "## Overrides\n\n### A\nExtends §Commit Rules.\n")
        # Set mtime to far past.
        old_time = (datetime.now() - timedelta(days=60)).timestamp()
        import os
        os.utime(old_path, (old_time, old_time))
        cutoff = datetime.now() - timedelta(days=7)
        report = audit_prose(
            tmp_path, _registry_with_test_coverage(), since=cutoff
        )
        assert report.findings == ()


# ---------------------------------------------------------------------------
# Conformance test against this dev repo's CLAUDE.md (#290 AC)
# ---------------------------------------------------------------------------


class TestDevRepoConformance:
    """Run the audit against this dev repo's CLAUDE.md.

    Pre-#291 the dev repo's CLAUDE.md carried four `## Overrides`
    subsections (Always use Bazel, Running-Log Discussion Placement,
    Test Dep-Graph Discipline, Maximal Test Coverage) — exactly the
    rules-in-identity-doc finding shape this audit category was
    designed to surface. #291's dogfood pass migrated those four to
    `.claude/project-rules.md` per the new framework, so the dev
    repo's current CLAUDE.md is the **post-migration** reference.
    The contract this test asserts flipped from "≥4 findings" to
    "0 findings" with that migration.

    The test resolves the project root by walking up from the test file
    until it finds CLAUDE.md alongside .claude/skills/forge-manager.
    Bazel test sandboxing means this needs to walk through the runfiles
    tree; if CLAUDE.md isn't reachable (test env doesn't ship it), the
    test skips with a clear message rather than failing.
    """

    def _find_dev_repo_root(self) -> Path | None:
        # Walk from the current working directory up looking for the
        # CLAUDE.md + .claude/skills/forge-manager pair.
        candidate = Path.cwd()
        for parent in [candidate, *candidate.parents]:
            if (
                (parent / "CLAUDE.md").exists()
                and (parent / ".claude" / "skills" / "forge-manager").is_dir()
            ):
                return parent
        return None

    def test_post_291_no_high_confidence_rules_in_identity(self) -> None:
        root = self._find_dev_repo_root()
        if root is None:
            pytest.skip(
                "dev repo not reachable from test runfiles "
                "(expected outside Bazel sandbox)"
            )
        # Use the live gate registry from this repo's gates.yaml to
        # match real names.
        from forge_manager_mcp.gate_registry import load_gates
        registry = load_gates(root / ".claude" / "skills" / "forge-manager" / "gates.yaml")
        report = audit_prose(
            root,
            registry,
            include=("CLAUDE.md",),
            exclude=(),
        )
        rules_in_identity = [
            f for f in report.findings
            if f.category == "rules_in_identity_doc"
            and f.confidence == "high"
        ]
        # Post-#291: the four ## Overrides subsections migrated to
        # .claude/project-rules.md. CLAUDE.md should have zero
        # high-confidence rules-in-identity-doc findings.
        assert rules_in_identity == [], (
            f"expected 0 high-confidence rules-in-identity-doc findings "
            f"post-#291 migration; got {len(rules_in_identity)}: "
            f"{[f.id for f in rules_in_identity]}. "
            f"If new rules accumulated under ## Overrides since the "
            f"migration, run `audit_project_prose --apply` to migrate "
            f"them to .claude/project-rules.md."
        )

    def test_post_291_project_rules_md_exists(self) -> None:
        root = self._find_dev_repo_root()
        if root is None:
            pytest.skip(
                "dev repo not reachable from test runfiles "
                "(expected outside Bazel sandbox)"
            )
        # Post-#291: the migration produced .claude/project-rules.md.
        # Its presence is the load-bearing artifact of the migration.
        rules_md = root / ".claude" / "project-rules.md"
        assert rules_md.exists(), (
            "expected .claude/project-rules.md after #291 migration; "
            "the four pre-migration ## Overrides entries should live "
            "there now."
        )
        body = rules_md.read_text()
        # The four migrated entries' headings should appear.
        assert "### Always use Bazel for all build and test" in body
        assert "### Running-Log Discussion Placement" in body
        assert "### Test Dep-Graph Discipline" in body
        assert "### Extends `commit.test_coverage`" in body


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Helper-level coverage.
# ---------------------------------------------------------------------------


class TestWalkProseFilesExclusions:
    def test_non_file_glob_match_skipped(self, tmp_path):
        # _iter_prose_files: directory matched by glob → not a file →
        # `continue`. L215-216.
        from forge_manager_mcp.audit_prose import _iter_prose_files
        (tmp_path / "subdir.md").mkdir()  # name ends in .md but is a dir
        (tmp_path / "real.md").write_text("# real\nbody")
        matches = list(_iter_prose_files(
            tmp_path,
            include=("*.md",),
            exclude=(),
            since=None,
        ))
        assert tmp_path / "real.md" in matches
        # Directory was skipped despite matching the glob.

    def test_exclude_match_by_pathlib_match(self, tmp_path):
        # First exclude check: match against the absolute path's basename.
        # L217-218.
        from forge_manager_mcp.audit_prose import _iter_prose_files
        (tmp_path / "keep.md").write_text("ok")
        (tmp_path / "skip.md").write_text("ok")
        matches = list(_iter_prose_files(
            tmp_path,
            include=("*.md",),
            exclude=("skip.md",),
            since=None,
        ))
        names = {p.name for p in matches}
        assert "keep.md" in names
        assert "skip.md" not in names

    def test_exclude_match_by_relative_path(self, tmp_path):
        # Second exclude check: match against project_root-relative
        # path. L219-220.
        from forge_manager_mcp.audit_prose import _iter_prose_files
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "skip.md").write_text("ok")
        (tmp_path / "keep.md").write_text("ok")
        matches = list(_iter_prose_files(
            tmp_path,
            include=("**/*.md",),
            exclude=("sub/skip.md",),
            since=None,
        ))
        names = {p.name for p in matches}
        assert "keep.md" in names
        assert "skip.md" not in names


class TestExplicitExtensionMatchBacktick:
    def test_explicit_backtick_gate_name_matches(self):
        # "extends `commit.test_coverage`" lowercase form → True at
        # L420-421.
        from forge_manager_mcp.audit_prose import (
            _Section, _explicit_extension_match,
        )
        gate = _make_gate("commit.test_coverage")
        section = _Section(
            level=3,
            heading="X",
            line_start=1,
            line_end=5,
            body="Extends `commit.test_coverage` — additional bar.",
            parents=("Overrides",),
        )
        assert _explicit_extension_match(section, gate) is True


class TestSectionKeywordsNoAnchor:
    def test_gate_location_without_hash_returns_empty_tuple(self):
        # _section_keywords_from_gate: gate.location lacking `#` →
        # L439-440. The Gate model normally requires `#` so we
        # synthesize a malformed gate via direct attribute set.
        from forge_manager_mcp.audit_prose import (
            _section_keywords_from_gate,
        )
        gate = _make_gate("commit.x")
        # Bypass frozen-model guard via object.__setattr__.
        object.__setattr__(gate, "location", "commit-rules.md")
        assert _section_keywords_from_gate(gate) == ()


class TestClosureCandidateNoKeywordOverlap:
    def test_closure_section_with_no_gate_keyword_overlap_skipped(
        self, tmp_path,
    ):
        # Closure-language present ("not applicable") but no overlap
        # with any gate's keywords → continue at L541-542.
        registry = _registry_with_test_coverage()
        _write(tmp_path, "doc.md", textwrap.dedent("""\
            ## Sundry

            This step is **not applicable** to our flow.
            """))
        report = audit_prose(
            project_root=tmp_path,
            gate_registry=registry,
            include=("*.md",),
        )
        # No gate_closure_candidate findings — closure-language fires
        # but each gate's keywords don't overlap with the section.
        assert not any(
            f.category == "gate_closure_candidate" for f in report.findings
        )


class TestIdentityInRulesDocNoMarkers:
    def test_section_without_identity_markers_emits_nothing(self, tmp_path):
        # Section that has NO identity-marker regex hits → L626-627
        # early-return.
        registry = _registry_with_test_coverage()
        rules_md = tmp_path / ".claude" / "project-rules.md"
        rules_md.parent.mkdir(parents=True)
        rules_md.write_text(textwrap.dedent("""\
            # Project Rules

            ## Some Rule

            A normal rule with no identity markers like owner / repo / etc.
            """))
        report = audit_prose(
            project_root=tmp_path,
            gate_registry=registry,
            include=(".claude/project-rules.md",),
        )
        assert not any(
            f.category == "identity_in_rules_doc" for f in report.findings
        )


class TestRulesInIdentityDocLevelTwoSkipped:
    def test_level_two_under_overrides_ancestor_is_skipped(self, tmp_path):
        # Section at level <= 2 with "Overrides" in parents (i.e.,
        # under a level-1 # Overrides ancestor) → L662-665 early-
        # return (only deeper sub-sections count as rules).
        registry = _registry_with_test_coverage()
        claude_md = tmp_path / "CLAUDE.md"
        claude_md.write_text(textwrap.dedent("""\
            # Overrides

            ## Some umbrella heading
            """))
        report = audit_prose(
            project_root=tmp_path,
            gate_registry=registry,
            include=("CLAUDE.md",),
        )
        # No rules-in-identity finding for the level-2 umbrella header.
        assert not any(
            f.category == "rules_in_identity_doc" for f in report.findings
        )


class TestRenderOverridesSubsectionTemplate:
    def test_no_suspected_gate_returns_section_only(self):
        from forge_manager_mcp.audit_prose import (
            _Section, _render_overrides_subsection_template,
        )
        section = _Section(
            level=3,
            heading="Independent rule",
            line_start=1, line_end=5,
            body="Some rule body.",
            parents=("CLAUDE", "Overrides"),
        )
        registry = _registry_with_test_coverage()
        out = _render_overrides_subsection_template(
            section, suspected_gate=None, gate_registry=registry,
        )
        assert "### Independent rule" in out
        assert "Some rule body" in out

    def test_suspected_gate_not_in_registry_returns_section_only(self):
        from forge_manager_mcp.audit_prose import (
            _Section, _render_overrides_subsection_template,
        )
        section = _Section(
            level=3,
            heading="Unknown gate",
            line_start=1, line_end=5,
            body="Body.",
            parents=("CLAUDE", "Overrides"),
        )
        registry = _registry_with_test_coverage()
        out = _render_overrides_subsection_template(
            section, suspected_gate="nonexistent.gate",
            gate_registry=registry,
        )
        assert "### Unknown gate" in out


class TestTruncateLong:
    def test_truncation_appends_ellipsis(self):
        from forge_manager_mcp.audit_prose import _truncate
        result = _truncate("abcdefghij", limit=5)
        assert result.endswith("…")
        assert len(result) <= 5


class TestFirstSentenceEmpty:
    def test_empty_text_returns_none(self):
        from forge_manager_mcp.audit_prose import _first_sentence
        assert _first_sentence("   ") is None


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
