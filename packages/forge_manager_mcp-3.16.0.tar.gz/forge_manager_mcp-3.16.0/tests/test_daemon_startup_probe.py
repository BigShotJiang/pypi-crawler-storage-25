"""Unit tests for the daemon startup whoami probe (#378 / 3.8.1 D2).

Companion to #377's state persistence:
  * D1 (#377) — state survives daemon restart.
  * D2 (#378, this) — fresh probes at daemon startup catch
    auth lapse / suspended account / network failures even when
    no qualifying op has fanned out yet.

Tests stub the underlying ``test_credential`` helper so probes
return canned envelopes without hitting the network.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from forge_manager_mcp.daemon import startup_probe as probe_mod
from forge_manager_mcp.daemon.startup_probe import (
    DEFAULT_PROBE_TIMEOUT,
    StartupProbeError,
    get_startup_probe_timeout,
    is_startup_probe_enabled,
    run_startup_probe,
)
from forge_manager_mcp.replication import (
    AdapterState, ReplicationManager,
)


class _MockAdapter:
    def __init__(self, platform_id: str):
        self.platform_id = platform_id


def _adapters(*ids: str) -> list:
    return [(pid, _MockAdapter(pid)) for pid in ids]


def _stub_test_credential(monkeypatch: pytest.MonkeyPatch, results: dict):
    """Replace ``test_credential`` with a stub returning per-platform
    envelopes from ``results`` (platform_id → {ok, ...} dict)."""
    async def _stub(platform_id: str, token: str) -> dict:
        return results.get(platform_id, {
            "ok": False, "platform_id": platform_id,
            "error": "no stub configured",
        })
    monkeypatch.setattr(
        "forge_manager_mcp.daemon.credential_test.test_credential",
        _stub,
    )


@pytest.fixture(autouse=True)
def _provide_tokens(monkeypatch: pytest.MonkeyPatch):
    """Ensure the probe sees a token for every platform under test;
    otherwise the no-token short-circuit fires before the stub."""
    monkeypatch.setenv("GITHUB_TOKEN", "stub-github")
    monkeypatch.setenv("CODEBERG_TOKEN", "stub-codeberg")
    monkeypatch.setenv("FORGEJO_TOKEN", "stub-forgejo")
    monkeypatch.setenv("GITLAB_TOKEN", "stub-gitlab")


# ---------------------------------------------------------------------------
# Skip semantics
# ---------------------------------------------------------------------------

class TestSkipSemantics:

    def test_canonical_adapter_skipped(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        called: list[str] = []

        async def _stub(platform_id, token):
            called.append(platform_id)
            return {"ok": True, "platform_id": platform_id}
        monkeypatch.setattr(
            "forge_manager_mcp.daemon.credential_test.test_credential",
            _stub,
        )
        manager = ReplicationManager(_adapters("local", "github"))
        asyncio.run(run_startup_probe(manager))
        # Canonical (local, idx 0) must NOT be probed.
        assert "local" not in called
        assert "github" in called

    # (#23 A.5 OQ1 / 3.15.0) test_paused_adapter_skipped RETIRED —
    # PAUSED state retired; operator-disabled adapters are filtered
    # via the `enabled` config flag at construction time (focused-
    # session follow-up), not state-checked in the probe loop.

    def test_no_candidates_returns_immediately(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        # Only canonical → no candidates → no probe call → return.
        async def _stub(platform_id, token):
            raise AssertionError("should not be called")
        monkeypatch.setattr(
            "forge_manager_mcp.daemon.credential_test.test_credential",
            _stub,
        )
        manager = ReplicationManager(_adapters("local"))
        # Must not raise.
        asyncio.run(run_startup_probe(manager))


# ---------------------------------------------------------------------------
# Failure → DEGRADED
# ---------------------------------------------------------------------------

class TestFailureTransitions:

    def test_http_403_transitions_degraded(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        _stub_test_credential(monkeypatch, {
            "github": {
                "ok": False, "platform_id": "github",
                "error": "HTTP 403",
            },
        })
        manager = ReplicationManager(_adapters("local", "github"))
        asyncio.run(run_startup_probe(manager))
        github = manager._entries[1]
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert github.state == AdapterState.DEGRADED
        assert isinstance(github.last_error, StartupProbeError)
        assert github.last_error.status_code == 403
        assert "HTTP 403" in str(github.last_error)

    def test_timeout_transitions_degraded(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        async def _slow_stub(platform_id, token):
            await asyncio.sleep(10)  # exceeds default 3.0s timeout
            return {"ok": True, "platform_id": platform_id}
        monkeypatch.setattr(
            "forge_manager_mcp.daemon.credential_test.test_credential",
            _slow_stub,
        )
        manager = ReplicationManager(_adapters("local", "github"))
        asyncio.run(run_startup_probe(manager, timeout=0.05))
        github = manager._entries[1]
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert github.state == AdapterState.DEGRADED
        assert "timeout" in str(github.last_error).lower()

    def test_no_token_in_env_treated_as_failure(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        # Strip the token; probe should classify "no token" as failure
        # since GitHub will 403 every subsequent call anyway.
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        async def _stub(platform_id, token):
            raise AssertionError("should short-circuit before this")
        monkeypatch.setattr(
            "forge_manager_mcp.daemon.credential_test.test_credential",
            _stub,
        )
        manager = ReplicationManager(_adapters("local", "github"))
        asyncio.run(run_startup_probe(manager))
        github = manager._entries[1]
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert github.state == AdapterState.DEGRADED
        assert "no token" in str(github.last_error).lower()


# ---------------------------------------------------------------------------
# Success path + interaction with #377 persistence
# ---------------------------------------------------------------------------

class TestSuccessPath:

    def test_healthy_stays_healthy_on_success(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        _stub_test_credential(monkeypatch, {
            "github": {
                "ok": True, "platform_id": "github", "identity": "u",
            },
        })
        manager = ReplicationManager(_adapters("local", "github"))
        asyncio.run(run_startup_probe(manager))
        assert manager._entries[1].state == AdapterState.HEALTHY

    def test_success_clears_last_error(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        """(#23 A.5 OQ2 / 3.15.0) DEGRADED state retired; rehydrated-
        DEGRADED-promotion semantic reshaped to "successful probe
        clears last_error". The startup_probe now sets/clears
        last_error directly without state transitions."""
        m = ReplicationManager(_adapters("local", "github"))
        # Manually seed an error on the github entry.
        m._entries[1].last_error = RuntimeError("HTTP 403")
        _stub_test_credential(monkeypatch, {
            "github": {
                "ok": True, "platform_id": "github", "identity": "u",
            },
        })
        asyncio.run(run_startup_probe(m))
        assert m._entries[1].last_error is None

    # (#23 A.5 OQ2 / 3.15.0) test_failure_on_already_degraded_does_not_
    # re_transition RETIRED — state_changed_at refresh tied to the
    # retired _set_state DEGRADED branch; last_error refresh now
    # uses datetime.now() directly without the state machine.


# ---------------------------------------------------------------------------
# Parallelism
# ---------------------------------------------------------------------------

class TestParallelism:

    def test_probes_run_in_parallel(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        # asyncio.Event barrier — every probe must start before any
        # finishes. If probes ran serially, the barrier would deadlock
        # (entries[0]'s wait blocks before entries[1] starts).
        in_flight = 0
        max_in_flight = 0

        async def _stub(platform_id, token):
            nonlocal in_flight, max_in_flight
            in_flight += 1
            max_in_flight = max(max_in_flight, in_flight)
            await asyncio.sleep(0.01)  # let other coros start
            in_flight -= 1
            return {"ok": True, "platform_id": platform_id}
        monkeypatch.setattr(
            "forge_manager_mcp.daemon.credential_test.test_credential",
            _stub,
        )
        manager = ReplicationManager(
            _adapters("local", "github", "codeberg", "gitlab")
        )
        asyncio.run(run_startup_probe(manager))
        # Three non-canonical adapters must all be in flight at once.
        assert max_in_flight == 3


# ---------------------------------------------------------------------------
# Config-driven disable
# ---------------------------------------------------------------------------

class TestConfigDisable:

    def test_default_enabled(self):
        assert is_startup_probe_enabled(None) is True
        assert is_startup_probe_enabled({}) is True
        assert is_startup_probe_enabled({"daemon": {}}) is True

    def test_explicitly_disabled(self):
        assert is_startup_probe_enabled({
            "daemon": {"startup_probe": False},
        }) is False

    def test_truthy_values_enable(self):
        # Belt-and-suspenders against operator misconfiguration.
        assert is_startup_probe_enabled({
            "daemon": {"startup_probe": True},
        }) is True
        assert is_startup_probe_enabled({
            "daemon": {"startup_probe": "false"},  # truthy string
        }) is True

    def test_default_timeout(self):
        assert get_startup_probe_timeout(None) == DEFAULT_PROBE_TIMEOUT
        assert get_startup_probe_timeout({}) == DEFAULT_PROBE_TIMEOUT

    def test_custom_timeout(self):
        assert get_startup_probe_timeout({
            "daemon": {"startup_probe_timeout": 5.0},
        }) == 5.0

    def test_invalid_timeout_falls_back(self):
        assert get_startup_probe_timeout({
            "daemon": {"startup_probe_timeout": "not-a-number"},
        }) == DEFAULT_PROBE_TIMEOUT


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Helper coverage.
# ---------------------------------------------------------------------------


class TestResolveTokenHelper:
    def test_unknown_platform_id_returns_empty_string(self):
        # _resolve_token's `if not env_var: return ""` early-exit branch
        # — covers L69. _PLATFORM_ENV_VAR has no entry for "mystery".
        from forge_manager_mcp.daemon.startup_probe import _resolve_token
        assert _resolve_token("mystery") == ""


class TestStatusCodeFromError:
    def test_http_prefix_with_unparseable_status(self):
        # `HTTP <not-an-int>` — `int(...)` raises ValueError → return None.
        # Covers L87-88.
        from forge_manager_mcp.daemon.startup_probe import (
            _status_code_from_error,
        )
        assert _status_code_from_error("HTTP not-a-number") is None

    def test_http_prefix_no_status_token(self):
        # `HTTP ` with nothing after — `.split()` → IndexError → None.
        from forge_manager_mcp.daemon.startup_probe import (
            _status_code_from_error,
        )
        # Empty after "HTTP " — `"".split()` is [] → IndexError [0].
        assert _status_code_from_error("HTTP ") is None


class TestRunStartupProbeBaseExceptionInGather:
    def test_base_exception_outcome_skipped_silently(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        # asyncio.gather(..., return_exceptions=True) can theoretically
        # surface a BaseException. The outer for-loop has a
        # `if isinstance(outcome, BaseException): continue` skip — L154.
        # Stub asyncio.gather to inject a BaseException into the results.
        manager = ReplicationManager(_adapters("local", "github"))
        original_state = manager._entries[1].state

        async def _fake_gather(*coros, return_exceptions=False):
            # Drain the coros to avoid warnings.
            for c in coros:
                c.close()
            return [RuntimeError("synthetic gather failure")]

        monkeypatch.setattr(
            "forge_manager_mcp.daemon.startup_probe.asyncio.gather",
            _fake_gather,
        )
        asyncio.run(run_startup_probe(manager))
        # BaseException outcome was skipped → state unchanged.
        assert manager._entries[1].state == original_state


class TestGetStartupProbeTimeoutNoneRaw:
    def test_explicit_none_raw_returns_default(self):
        # `daemon.startup_probe_timeout: null` → raw is None → L201
        # early-exit returns DEFAULT_PROBE_TIMEOUT.
        assert get_startup_probe_timeout({
            "daemon": {"startup_probe_timeout": None},
        }) == DEFAULT_PROBE_TIMEOUT


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
