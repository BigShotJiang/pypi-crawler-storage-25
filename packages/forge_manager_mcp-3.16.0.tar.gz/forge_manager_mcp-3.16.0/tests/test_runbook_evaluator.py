"""Runbook evaluator unit tests (3.4.0 / Codeberg-dev #3 Phase 1b).

Covers the factory + the registry registration helper. The runtime
shape (Interceptor enter handler over the Context) is exercised
synchronously here; the async aexecute path is covered via
test_runbook_evaluator_chain when the evaluator is composed with
project_rules in test_server_gates.
"""
from __future__ import annotations

from dataclasses import replace

import pytest

from forge_manager_mcp.gate_registry import Gate, GateRegistry
from forge_manager_mcp.interceptors import Context, Interceptor
from forge_manager_mcp.runbook_evaluator import (
    RUNBOOK_CONFIRMATIONS_REQUEST_KEY,
    make_runbook_evaluator,
    register_runbook_evaluators,
)
from forge_manager_mcp.server.gates import (
    clear_default_evaluators,
    get_default_evaluator,
)


def _runbook_gate(name: str = "publish.example") -> Gate:
    return Gate(
        name=name,
        type="pre-publish",
        location=f"release.md#{name}",
        summary="example",
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"release.md#{name}",
        introduced_in="3.4.0",
        runbook_url=f"runbooks/{name.replace('.', '-')}.md",
    )


def _non_runbook_gate(name: str = "commit.example") -> Gate:
    return Gate(
        name=name,
        type="pre-commit",
        location=f"commit-rules.md#{name}",
        summary="example",
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"commit-rules.md#{name}",
        introduced_in="1.0.0",
    )


class TestMakeRunbookEvaluator:
    def test_returns_interceptor(self) -> None:
        gate = _runbook_gate()
        evaluator = make_runbook_evaluator(gate)
        assert isinstance(evaluator, Interceptor)
        assert evaluator.enter is not None
        assert evaluator.leave is None
        assert evaluator.error is None

    def test_display_name_includes_gate_name(self) -> None:
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        assert "publish.foo" in evaluator.display_name

    def test_rejects_non_pre_publish_gate(self) -> None:
        gate = _non_runbook_gate()
        with pytest.raises(ValueError, match="pre-publish"):
            make_runbook_evaluator(gate)

    def test_rejects_pre_publish_gate_without_runbook_url(self) -> None:
        # (#428) L68-72 — defensive check for missing runbook_url.
        # Gate model validator normally catches this, but the evaluator
        # double-checks. Construct via model_construct to bypass.
        gate = Gate.model_construct(
            name="publish.example",
            type="pre-publish",
            location="release.md#publish.example",
            summary="example",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc="release.md#publish.example",
            introduced_in="3.4.0",
            runbook_url=None,
        )
        with pytest.raises(ValueError, match="runbook_url"):
            make_runbook_evaluator(gate)

    @pytest.mark.asyncio
    async def test_passed_when_confirmation_true(self) -> None:
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        ctx = Context(request={
            RUNBOOK_CONFIRMATIONS_REQUEST_KEY: {"publish.foo": True},
        })
        result_ctx = await evaluator.enter(ctx)
        result = result_ctx.response["publish.foo"]
        assert result["status"] == "passed"
        assert result["confirmed"] is True
        assert result["gate_name"] == "publish.foo"
        assert result["runbook_url"] == gate.runbook_url
        assert "manual_steps" not in result

    @pytest.mark.asyncio
    async def test_unconfirmed_when_confirmation_false(self) -> None:
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        ctx = Context(request={
            RUNBOOK_CONFIRMATIONS_REQUEST_KEY: {"publish.foo": False},
        })
        result_ctx = await evaluator.enter(ctx)
        result = result_ctx.response["publish.foo"]
        assert result["status"] == "unconfirmed"
        assert result["confirmed"] is False
        assert "manual_steps" in result
        assert any(gate.runbook_url in step for step in result["manual_steps"])

    @pytest.mark.asyncio
    async def test_unconfirmed_when_key_missing(self) -> None:
        """Default behavior — missing entry treated as unconfirmed,
        same as explicit False. Matches the conservative-default
        contract in the runbook gate framework spec."""
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        ctx = Context(request={
            RUNBOOK_CONFIRMATIONS_REQUEST_KEY: {},
        })
        result_ctx = await evaluator.enter(ctx)
        result = result_ctx.response["publish.foo"]
        assert result["status"] == "unconfirmed"
        assert result["confirmed"] is False

    @pytest.mark.asyncio
    async def test_unconfirmed_when_request_key_absent(self) -> None:
        """Request payload without runbook_confirmations key — same
        as missing entry."""
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        ctx = Context(request={})
        result_ctx = await evaluator.enter(ctx)
        result = result_ctx.response["publish.foo"]
        assert result["status"] == "unconfirmed"

    @pytest.mark.asyncio
    async def test_other_response_keys_preserved(self) -> None:
        """The evaluator only writes its own gate-name key; other
        accumulated response keys (from earlier gates) survive."""
        gate = _runbook_gate("publish.foo")
        evaluator = make_runbook_evaluator(gate)
        ctx = Context(
            request={RUNBOOK_CONFIRMATIONS_REQUEST_KEY: {"publish.foo": True}},
            response={"earlier.gate": "preserved-value"},
        )
        result_ctx = await evaluator.enter(ctx)
        assert result_ctx.response["earlier.gate"] == "preserved-value"
        assert "publish.foo" in result_ctx.response


class TestRegisterRunbookEvaluators:
    def setup_method(self, method) -> None:
        clear_default_evaluators()

    def teardown_method(self, method) -> None:
        clear_default_evaluators()

    def test_registers_only_pre_publish_gates(self) -> None:
        gates = [
            _runbook_gate("publish.a"),
            _runbook_gate("publish.b"),
            _non_runbook_gate("commit.c"),
        ]
        registry = GateRegistry(gates)
        registered = register_runbook_evaluators(registry)
        assert set(registered) == {"publish.a", "publish.b"}
        assert get_default_evaluator("publish.a") is not None
        assert get_default_evaluator("publish.b") is not None
        assert get_default_evaluator("commit.c") is None

    def test_returns_empty_for_registry_with_no_runbook_gates(self) -> None:
        registry = GateRegistry([_non_runbook_gate("commit.a")])
        registered = register_runbook_evaluators(registry)
        assert registered == []

    def test_idempotent_re_registration(self) -> None:
        registry = GateRegistry([_runbook_gate("publish.a")])
        first = register_runbook_evaluators(registry)
        second = register_runbook_evaluators(registry)
        assert first == second == ["publish.a"]
        # Both calls should succeed; last-wins semantics are inherited
        # from register_default_evaluator.

    @pytest.mark.asyncio
    async def test_registered_evaluators_function(self) -> None:
        """End-to-end: register, look up, run the evaluator."""
        gate = _runbook_gate("publish.run_smoke_test")
        registry = GateRegistry([gate])
        register_runbook_evaluators(registry)
        evaluator = get_default_evaluator("publish.run_smoke_test")
        assert evaluator is not None
        ctx = Context(request={
            RUNBOOK_CONFIRMATIONS_REQUEST_KEY: {
                "publish.run_smoke_test": True,
            },
        })
        result_ctx = await evaluator.enter(ctx)
        assert result_ctx.response["publish.run_smoke_test"]["status"] == "passed"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
