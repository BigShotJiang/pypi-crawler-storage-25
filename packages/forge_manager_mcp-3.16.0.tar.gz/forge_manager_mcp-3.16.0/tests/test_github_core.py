"""(#428 / 3.12.0 D-Coverage drain) Tests for github/core.py — the
GraphQL plumbing shared across every github.* module.

Covers the input-validation guards, the timeout/network error
wrapping, and the singleton client close path.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from forge_manager_mcp.github.core import (
    GitHubError,
    InvalidNodeIdError,
    _get_client,
    _graphql,
    aclose_client,
)


TOKEN = "ghp_test_token"


class TestInputValidation:
    @pytest.mark.asyncio
    async def test_empty_token_raises(self):
        with pytest.raises(ValueError, match="token"):
            await _graphql("", "{ viewer { login } }")

    @pytest.mark.asyncio
    async def test_empty_query_raises(self):
        with pytest.raises(ValueError, match="query"):
            await _graphql(TOKEN, "  \n  ")


class TestNetworkErrorWrapping:
    @pytest.mark.asyncio
    async def test_timeout_wrapped_as_github_error(self):
        async def _post_raises(*args, **kwargs):
            raise httpx.TimeoutException("simulated timeout")

        client_mock = MagicMock()
        client_mock.post = _post_raises
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            with pytest.raises(GitHubError, match="timed out"):
                await _graphql(TOKEN, "{ viewer { login } }")

    @pytest.mark.asyncio
    async def test_request_error_wrapped_as_github_error(self):
        async def _post_raises(*args, **kwargs):
            raise httpx.ConnectError("network unreachable")

        client_mock = MagicMock()
        client_mock.post = _post_raises
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            with pytest.raises(GitHubError, match="network error"):
                await _graphql(TOKEN, "{ viewer { login } }")


class TestInvalidNodeIdError:
    def test_carries_param_and_value(self):
        err = InvalidNodeIdError("project_id", "PVT_xyz")
        assert err.param_name == "project_id"
        assert err.value == "PVT_xyz"
        assert "project_id" in str(err)
        assert "PVT_xyz" in str(err)


class TestGetClient:
    @pytest.mark.asyncio
    async def test_lazy_singleton_creation(self):
        from forge_manager_mcp.github import core as _c
        _c._CLIENT = None
        client = _get_client()
        try:
            assert client is not None
            # Second call returns the same instance.
            assert _get_client() is client
        finally:
            await aclose_client()


class TestGraphQLSuccessPaths:
    @pytest.mark.asyncio
    async def test_happy_path_returns_data_field(self):
        response_mock = MagicMock()
        response_mock.status_code = 200
        response_mock.json.return_value = {"data": {"viewer": {"login": "me"}}}

        async def _post(*args, **kwargs):
            return response_mock

        client_mock = MagicMock()
        client_mock.post = _post
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            result = await _graphql(TOKEN, "{ viewer { login } }")
        assert result == {"viewer": {"login": "me"}}

    @pytest.mark.asyncio
    async def test_variables_included_in_payload(self):
        """Cover the `if variables:` branch (line 105)."""
        captured: dict = {}
        response_mock = MagicMock()
        response_mock.status_code = 200
        response_mock.json.return_value = {"data": {"ok": True}}

        async def _post(url, headers=None, json=None):
            captured["payload"] = json
            return response_mock

        client_mock = MagicMock()
        client_mock.post = _post
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            await _graphql(TOKEN, "query ($x: String!) { x }", {"x": "v"})
        assert captured["payload"]["variables"] == {"x": "v"}


class TestGraphQLErrorPaths:
    @pytest.mark.asyncio
    async def test_non_200_status_raises_github_error(self):
        response_mock = MagicMock()
        response_mock.status_code = 401
        response_mock.text = "Bad credentials"

        async def _post(*args, **kwargs):
            return response_mock

        client_mock = MagicMock()
        client_mock.post = _post
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            with pytest.raises(GitHubError, match="HTTP 401") as excinfo:
                await _graphql(TOKEN, "{ viewer { login } }")
        assert excinfo.value.status_code == 401
        assert excinfo.value.body == "Bad credentials"

    @pytest.mark.asyncio
    async def test_errors_field_in_response_raises_github_error(self):
        response_mock = MagicMock()
        response_mock.status_code = 200
        response_mock.text = '{"errors":[{"message":"oops"}]}'
        response_mock.json.return_value = {
            "errors": [{"message": "oops"}],
        }

        async def _post(*args, **kwargs):
            return response_mock

        client_mock = MagicMock()
        client_mock.post = _post
        with patch(
            "forge_manager_mcp.github.core._get_client",
            return_value=client_mock,
        ):
            with pytest.raises(GitHubError, match="GraphQL errors"):
                await _graphql(TOKEN, "{ viewer { login } }")


class TestAcloseClient:
    @pytest.mark.asyncio
    async def test_close_idempotent_when_client_none(self):
        # When _CLIENT is None (no prior _get_client call), aclose is
        # a no-op — must not raise.
        from forge_manager_mcp.github import core as _c
        # Force the global to None.
        _c._CLIENT = None
        await aclose_client()
        assert _c._CLIENT is None

    @pytest.mark.asyncio
    async def test_close_clears_client_when_present(self, monkeypatch):
        from forge_manager_mcp.github import core as _c

        fake_client = MagicMock()
        fake_client.aclose = AsyncMock(return_value=None)
        monkeypatch.setattr(_c, "_CLIENT", fake_client)
        await aclose_client()
        # aclose called once, singleton reset.
        fake_client.aclose.assert_awaited_once()
        assert _c._CLIENT is None


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
