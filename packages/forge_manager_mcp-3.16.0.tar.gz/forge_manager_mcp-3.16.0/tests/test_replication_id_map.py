"""Tests for replication.id_map (Discussion #23 A.5)."""
from __future__ import annotations

import pytest

from forge_manager_mcp.replication.id_map import (
    MirrorNumberMap,
)


class TestRecord:
    def test_basic_round_trip(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        assert m.get_mirror_number(("issue", 42)) == 117

    def test_idempotent_same_value(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        m.record(("issue", 42), 117)
        assert m.get_mirror_number(("issue", 42)) == 117

    def test_conflicting_mirror_raises(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        with pytest.raises(ValueError, match="conflicting"):
            m.record(("issue", 42), 200)

    def test_invalid_canonical_shape_raises(self):
        m = MirrorNumberMap()
        with pytest.raises(ValueError, match="kind, number"):
            m.record("issue:42", 117)  # type: ignore[arg-type]
        with pytest.raises(ValueError, match="kind, number"):
            m.record(("issue",), 117)  # type: ignore[arg-type]
        with pytest.raises(ValueError, match="kind, number"):
            m.record(("issue", 42, "extra"), 117)  # type: ignore[arg-type]

    def test_different_kinds_independent(self):
        """Same number across different kinds is allowed — issue #42
        and discussion #42 are different canonical artifacts."""
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        m.record(("discussion", 42), 23)
        assert m.get_mirror_number(("issue", 42)) == 117
        assert m.get_mirror_number(("discussion", 42)) == 23


class TestGetMirrorNumber:
    def test_missing_returns_none(self):
        m = MirrorNumberMap()
        assert m.get_mirror_number(("issue", 42)) is None

    def test_returns_recorded_value(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        assert m.get_mirror_number(("issue", 42)) == 117

    def test_different_kind_returns_none(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        # discussion:42 not recorded — returns None.
        assert m.get_mirror_number(("discussion", 42)) is None


class TestGetCanonicalId:
    def test_reverse_lookup(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        assert m.get_canonical_id("issue", 117) == ("issue", 42)

    def test_missing_returns_none(self):
        m = MirrorNumberMap()
        assert m.get_canonical_id("issue", 117) is None

    def test_different_kind_returns_none(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        assert m.get_canonical_id("discussion", 117) is None


class TestLenAndContains:
    def test_empty_len_zero(self):
        m = MirrorNumberMap()
        assert len(m) == 0

    def test_len_grows(self):
        m = MirrorNumberMap()
        for i in range(5):
            m.record(("issue", i), 100 + i)
        assert len(m) == 5

    def test_contains_true(self):
        m = MirrorNumberMap()
        m.record(("issue", 42), 117)
        assert ("issue", 42) in m

    def test_contains_false(self):
        m = MirrorNumberMap()
        assert ("issue", 42) not in m

    def test_contains_bad_shape_returns_false(self):
        m = MirrorNumberMap()
        # Not a tuple — must not raise.
        assert "issue:42" not in m  # type: ignore[operator]
        # Wrong-length tuple — must not raise.
        assert ("issue",) not in m  # type: ignore[operator]


class TestIterEntries:
    def test_empty_iter(self):
        m = MirrorNumberMap()
        assert list(m.iter_entries()) == []

    def test_preserves_insertion_order(self):
        m = MirrorNumberMap()
        m.record(("issue", 7), 700)
        m.record(("issue", 3), 300)
        m.record(("issue", 5), 500)
        result = list(m.iter_entries())
        assert result == [
            (("issue", 7), 700),
            (("issue", 3), 300),
            (("issue", 5), 500),
        ]


class TestClear:
    def test_clear_removes_all(self):
        m = MirrorNumberMap()
        m.record(("issue", 1), 100)
        m.record(("discussion", 2), 200)
        m.clear()
        assert len(m) == 0
        assert m.get_mirror_number(("issue", 1)) is None
        assert m.get_canonical_id("issue", 100) is None

    def test_clear_idempotent(self):
        m = MirrorNumberMap()
        m.clear()
        m.clear()
        assert len(m) == 0


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
