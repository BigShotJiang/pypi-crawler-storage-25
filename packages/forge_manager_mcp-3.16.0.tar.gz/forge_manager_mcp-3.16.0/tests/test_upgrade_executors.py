"""Tests for upgrade.executors (#373 / 3.8.0 D2.3 / Discussion #12)."""
from __future__ import annotations

import pytest

from forge_manager_mcp.upgrade import executors


class TestRegistry:
    def test_all_seven_repair_types_registered(self):
        names = executors.all_repair_types()
        assert "pipx_upgrade" in names
        assert "daemon_restart" in names
        assert "schema_migration" in names
        assert "skill_prose_pull" in names
        assert "config_patch" in names
        assert "claude_md_merge" in names
        assert "verify" in names
        assert len(names) == 7

    def test_get_executor_returns_executor(self):
        ex = executors.get_executor("pipx_upgrade")
        assert ex.repair_type == "pipx_upgrade"
        assert callable(ex.dry_run_fn)
        assert callable(ex.execute_fn)
        assert callable(ex.rollback_fn)

    def test_get_executor_raises_for_unknown(self):
        with pytest.raises(executors.UnknownExecutorError):
            executors.get_executor("nonsense")


class TestPipxExecutor:
    def test_dry_run_carries_copy_paste_command(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.dry_run_fn({"target_version": "3.7.1"})
        assert outcome.repair_type == "pipx_upgrade"
        assert outcome.preconditions_ok
        assert "pipx" in (outcome.operator_action or "")
        assert "3.7.1" in (outcome.operator_action or "")

    def test_dry_run_falls_back_to_generic_upgrade(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.dry_run_fn({})
        assert outcome.operator_action == "pipx upgrade forge-manager-mcp"

    def test_execute_returns_operator_handoff(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.execute_fn({"current_version": "3.6.0"})
        # Daemon can't pipx-upgrade itself per Discussion #12 OQ3.
        assert outcome.status == "operator_handoff"
        assert outcome.operator_action is not None
        # Rollback handle preserves the prior version for the
        # rollback path's reverse-pin.
        assert outcome.rollback_handle == {"prior_version": "3.6.0"}

    def test_execute_with_target_version_pins_install_force(self):
        # (#428) L188-189 — target_version present → pipx install --force.
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.execute_fn({
            "current_version": "3.6.0",
            "target_version": "3.7.1",
        })
        assert outcome.status == "operator_handoff"
        # Action uses `pipx install --force forge-manager-mcp==<version>`
        # rather than the generic upgrade.
        assert "--force" in (outcome.operator_action or "")
        assert "3.7.1" in (outcome.operator_action or "")

    def test_rollback_pins_to_prior_version(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.rollback_fn({}, {"prior_version": "3.6.0"})
        assert outcome.status == "operator_handoff"
        assert "3.6.0" in (outcome.operator_action or "")
        assert "--force" in (outcome.operator_action or "")


class TestDaemonRestartExecutor:
    def test_dry_run_describes_restart(self):
        ex = executors.get_executor("daemon_restart")
        outcome = ex.dry_run_fn({})
        assert outcome.preconditions_ok
        assert "restart" in outcome.description.lower()
        assert outcome.operator_action == "forge-manager-mcp daemon-restart"

    def test_execute_returns_operator_handoff(self):
        # Daemon can't restart itself from inside a request handler
        # without deadlocking the response.
        ex = executors.get_executor("daemon_restart")
        outcome = ex.execute_fn({})
        assert outcome.status == "operator_handoff"
        assert "daemon-restart" in (outcome.operator_action or "")

    def test_rollback_is_idempotent_noop(self):
        ex = executors.get_executor("daemon_restart")
        outcome = ex.rollback_fn({}, None)
        assert outcome.status == "ok"
        assert "idempotent" in outcome.message.lower()


class TestStubExecutors:
    @pytest.mark.parametrize(
        "rt",
        [
            "schema_migration", "skill_prose_pull", "config_patch",
            "claude_md_merge", "verify",
        ],
    )
    def test_stub_dry_run_marks_preconditions_not_ok(self, rt):
        ex = executors.get_executor(rt)
        outcome = ex.dry_run_fn({})
        # Stub executors mark themselves not-yet-implemented so the
        # wizard skips them rather than dispatching into a no-op.
        assert outcome.preconditions_ok is False
        assert "3.8.x" in (outcome.preconditions_message or "")

    @pytest.mark.parametrize(
        "rt",
        [
            "schema_migration", "skill_prose_pull", "config_patch",
            "claude_md_merge", "verify",
        ],
    )
    def test_stub_execute_returns_deferred(self, rt):
        ex = executors.get_executor(rt)
        outcome = ex.execute_fn({})
        assert outcome.status == "deferred"

    @pytest.mark.parametrize(
        "rt",
        [
            "schema_migration", "skill_prose_pull", "config_patch",
            "claude_md_merge", "verify",
        ],
    )
    def test_stub_rollback_returns_deferred(self, rt):
        ex = executors.get_executor(rt)
        outcome = ex.rollback_fn({}, None)
        assert outcome.status == "deferred"


class TestSerialization:
    def test_to_dry_run_dict_carries_every_field(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.dry_run_fn({"target_version": "3.7.1"})
        payload = executors.to_dry_run_dict(outcome)
        for key in (
            "repair_type", "description", "operator_action",
            "preconditions_ok", "preconditions_message",
        ):
            assert key in payload

    def test_to_result_dict_carries_every_field(self):
        ex = executors.get_executor("pipx_upgrade")
        outcome = ex.execute_fn({})
        payload = executors.to_result_dict(outcome)
        for key in (
            "repair_type", "status", "message",
            "operator_action", "rollback_handle",
        ):
            assert key in payload


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
