"""Unit tests for the #140 skill_validator module."""
from __future__ import annotations

from pathlib import Path

import pytest

from forge_manager_mcp.skill_validator import (
    REQUIRED_FRONTMATTER_KEYS,
    REQUIRED_TOPICS,
    ValidationError,
    collect_anchors,
    main,
    parse_frontmatter,
    validate_registry_anchors,
    validate_skill,
)


_GOOD_FRONTMATTER = (
    "---\n"
    "name: test-skill\n"
    "description: A skill for tests.\n"
    "---\n"
    "\n"
    "# Body\n"
)


def _make_skill(
    tmp_path: Path,
    *,
    frontmatter: str = _GOOD_FRONTMATTER,
    topics: tuple[str, ...] | None = None,
    omit_skill_md: bool = False,
) -> Path:
    skill_dir = tmp_path / "skill"
    skill_dir.mkdir()
    if not omit_skill_md:
        (skill_dir / "SKILL.md").write_text(frontmatter)
    if topics is None:
        topics = REQUIRED_TOPICS
    for t in topics:
        (skill_dir / t).write_text(f"# {t}\n")
    return skill_dir


class TestParseFrontmatter:
    def test_extracts_keys(self) -> None:
        keys = parse_frontmatter(_GOOD_FRONTMATTER)
        assert keys["name"] == "test-skill"
        assert keys["description"] == "A skill for tests."

    def test_skips_lines_without_colon(self) -> None:
        # Blank lines and bare text inside frontmatter are tolerated.
        body = (
            "---\n"
            "name: x\n"
            "\n"
            "just-a-comment\n"
            "description: y\n"
            "---\n"
        )
        keys = parse_frontmatter(body)
        assert keys == {"name": "x", "description": "y"}

    def test_missing_opening_delimiter_raises(self) -> None:
        with pytest.raises(ValidationError, match="must start with"):
            parse_frontmatter("name: test\n")

    def test_unterminated_frontmatter_raises(self) -> None:
        with pytest.raises(ValidationError, match="not terminated"):
            parse_frontmatter("---\nname: test\n")

    def test_value_with_colon_preserves_remainder(self) -> None:
        # ``description: a: b`` should yield ``"a: b"`` as the value
        # (partition on first colon).
        body = "---\nname: x\ndescription: tag: ok\n---\n"
        keys = parse_frontmatter(body)
        assert keys["description"] == "tag: ok"


class TestValidateSkill:
    def test_happy_path(self, tmp_path: Path) -> None:
        skill_dir = _make_skill(tmp_path)
        validate_skill(skill_dir)  # does not raise

    def test_missing_skill_md_raises(self, tmp_path: Path) -> None:
        skill_dir = _make_skill(tmp_path, omit_skill_md=True)
        with pytest.raises(ValidationError, match="SKILL.md not found"):
            validate_skill(skill_dir)

    def test_missing_required_key_raises(self, tmp_path: Path) -> None:
        bad = "---\nname: only-name\n---\n"
        skill_dir = _make_skill(tmp_path, frontmatter=bad)
        with pytest.raises(ValidationError, match="missing required key: 'description'"):
            validate_skill(skill_dir)

    def test_empty_required_key_raises(self, tmp_path: Path) -> None:
        bad = "---\nname: x\ndescription:\n---\n"
        skill_dir = _make_skill(tmp_path, frontmatter=bad)
        with pytest.raises(ValidationError, match="key 'description' is empty"):
            validate_skill(skill_dir)

    def test_missing_topic_file_raises(self, tmp_path: Path) -> None:
        topics = tuple(t for t in REQUIRED_TOPICS if t != "tools.md")
        skill_dir = _make_skill(tmp_path, topics=topics)
        with pytest.raises(ValidationError, match="topic file missing: tools.md"):
            validate_skill(skill_dir)


class TestMain:
    def test_returns_zero_on_valid(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        skill_dir = _make_skill(tmp_path)
        rc = main(["--skill-dir", str(skill_dir)])
        assert rc == 0
        out = capsys.readouterr().out
        assert "OK:" in out

    def test_returns_one_on_invalid(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        skill_dir = _make_skill(tmp_path, omit_skill_md=True)
        rc = main(["--skill-dir", str(skill_dir)])
        assert rc == 1
        err = capsys.readouterr().err
        assert "::error::" in err
        assert "SKILL.md not found" in err


_VALID_GATES_YAML = """\
gates:
  - name: commit.example
    type: pre-commit
    location: commit-rules.md#commit.example
    summary: example
    default_state: open
    extension_semantics: tighten
    override_semantics: replace
    state_change_semantics: open_close
    rationale_doc: commit-rules.md#commit.example
    introduced_in: "1.0.0"
"""

_VALID_PROCESSES_YAML = """\
processes:
  - name: session.start
    type: lifecycle
    location: bootstrap.md#session.start
    summary: bootstrap
    rationale_doc: bootstrap.md#session.start
    introduced_in: "1.0.0"
    steps:
      - id: account-detect
        location: bootstrap.md#session.start.account-detect
        gates: []
"""


class TestCollectAnchors:
    def test_heading_anchor(self) -> None:
        body = "## Some heading {#commit.x}\n\ncontent\n"
        assert "commit.x" in collect_anchors(body)

    def test_html_anchor(self) -> None:
        body = 'before <a id="release.bazel_tests_green"></a> after\n'
        assert "release.bazel_tests_green" in collect_anchors(body)

    def test_no_anchors(self) -> None:
        body = "## Heading without anchor\n"
        assert collect_anchors(body) == set()

    def test_multiple_kinds(self) -> None:
        body = (
            "## A {#a.one}\n"
            "Text with <a id='b.two'>inline</a>.\n"
            "## C {#c.three}\n"
        )
        assert collect_anchors(body) == {"a.one", "b.two", "c.three"}


class TestValidateRegistryAnchors:
    def test_no_registry_files_is_noop(self, tmp_path: Path) -> None:
        validate_registry_anchors(tmp_path)  # does not raise

    def test_resolves_when_anchors_present(self, tmp_path: Path) -> None:
        (tmp_path / "gates.yaml").write_text(_VALID_GATES_YAML)
        (tmp_path / "commit-rules.md").write_text(
            "## Example {#commit.example}\n\nbody\n"
        )
        validate_registry_anchors(tmp_path)

    def test_missing_anchor_raises(self, tmp_path: Path) -> None:
        (tmp_path / "gates.yaml").write_text(_VALID_GATES_YAML)
        (tmp_path / "commit-rules.md").write_text(
            "## Example without anchor\n\nbody\n"
        )
        with pytest.raises(ValidationError, match="anchor not declared"):
            validate_registry_anchors(tmp_path)

    def test_missing_topic_file_raises(self, tmp_path: Path) -> None:
        (tmp_path / "gates.yaml").write_text(_VALID_GATES_YAML)
        with pytest.raises(ValidationError, match="missing topic file"):
            validate_registry_anchors(tmp_path)

    def test_processes_steps_anchors_checked(self, tmp_path: Path) -> None:
        (tmp_path / "processes.yaml").write_text(_VALID_PROCESSES_YAML)
        # Bootstrap missing the step anchor — should fail.
        (tmp_path / "bootstrap.md").write_text(
            "## Session Start {#session.start}\n\nbody\n"
        )
        with pytest.raises(ValidationError, match="account-detect"):
            validate_registry_anchors(tmp_path)

    def test_malformed_registry_yaml_raises(self, tmp_path: Path) -> None:
        (tmp_path / "gates.yaml").write_text("gates:\n  - name: nodot\n")
        with pytest.raises(ValidationError, match="gates.yaml"):
            validate_registry_anchors(tmp_path)


def test_required_frontmatter_keys_minimum() -> None:
    # Sanity: name + description are the keys Claude Code documents
    # as required (#140's CI-contract reference). If this set ever
    # shrinks, the validator no longer enforces the contract.
    assert "name" in REQUIRED_FRONTMATTER_KEYS
    assert "description" in REQUIRED_FRONTMATTER_KEYS


# (#428 / 3.12.0 D-Coverage drain) Edge-path tests for the small
# remaining holes.


class TestValidateRegistryEdgePaths:
    def test_processes_yaml_parse_error_raises(self, tmp_path: Path) -> None:
        # Malformed processes.yaml → GateRegistryError → wrapped as
        # ValidationError with "processes.yaml: ..." prefix.
        (tmp_path / "processes.yaml").write_text(
            "processes:\n  - name: nodot\n",  # missing required fields
        )
        with pytest.raises(ValidationError, match="processes.yaml"):
            validate_registry_anchors(tmp_path)

    def test_anchor_missing_hash_segment_raises(
        self, tmp_path: Path, monkeypatch,
    ) -> None:
        # If a gate's location field lacks the `#anchor` segment, the
        # validator raises rather than silently treating it as a file-
        # only reference. Easier to drive this through a stub registry
        # since gates.yaml's parser already enforces well-formed
        # `file#anchor` shapes.
        from forge_manager_mcp import gate_registry as _gr
        from types import SimpleNamespace

        stub_gate = SimpleNamespace(
            location="commit-rules.md",  # no `#anchor`
            rationale_doc="commit-rules.md#some-anchor",
        )
        stub_registry = SimpleNamespace(
            list_gates=lambda: [stub_gate],
        )

        def _stub_load_gates(path):
            return stub_registry

        # Ship a non-empty gates.yaml so the validator enters the
        # gates branch; load_gates is stubbed to return our shape.
        (tmp_path / "gates.yaml").write_text(_VALID_GATES_YAML)
        monkeypatch.setattr(_gr, "load_gates", _stub_load_gates)
        with pytest.raises(ValidationError, match="missing `#anchor`"):
            validate_registry_anchors(tmp_path)


def test_main_block_runs_main():
    # Cover the `if __name__ == "__main__": raise SystemExit(main())`
    # block by running the module as a script. The script will exit
    # with a validation error (no skill at cwd), which still
    # exercises the ``if __name__ == "__main__"`` branch.
    import subprocess
    import sys

    result = subprocess.run(
        [sys.executable, "-m", "forge_manager_mcp.skill_validator"],
        capture_output=True,
        text=True,
    )
    # Any exit code is fine; we're covering the script entry point.
    assert isinstance(result.returncode, int)


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
