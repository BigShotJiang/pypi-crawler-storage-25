"""Tests for session_rotation (#375 / 3.8.0 D6 / Theme G / Discussion #15)."""
from __future__ import annotations

import pytest

from forge_manager_mcp import session_rotation
from forge_manager_mcp.session_rotation import (
    RotationPolicy, Trigger, TriggerType,
)


# ---------------------------------------------------------------------------
# detect_phase_boundary
# ---------------------------------------------------------------------------

class TestDetectPhaseBoundary:
    def test_returns_none_for_empty_event_list(self):
        assert session_rotation.detect_phase_boundary([]) is None

    def test_returns_none_when_no_phase_event_present(self):
        events = [
            {"operation": "create_issue", "timestamp": "2026-05-08"},
            {"operation": "post_turn", "timestamp": "2026-05-08"},
        ]
        assert session_rotation.detect_phase_boundary(events) is None

    def test_detects_post_release(self):
        events = [
            {"operation": "release_project", "timestamp": "2026-05-08"},
        ]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_RELEASE
        assert "2026-05-08" in trigger.detail

    def test_detects_post_pr_merge(self):
        events = [{"operation": "pr_merge"}]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_PR_MERGE

    def test_detects_post_discussion_ac(self):
        events = [{"operation": "mark_discussion_decided"}]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_DISCUSSION_AC

    def test_detects_post_development_phase(self):
        events = [{"operation": "phase_completed"}]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_DEVELOPMENT_PHASE

    def test_first_match_wins_when_multiple_triggers_present(self):
        # Caller passes events newest-first; the detector returns
        # the first match, so the most recent boundary wins.
        events = [
            {"operation": "release_project"},
            {"operation": "pr_merge"},
        ]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_RELEASE

    def test_unknown_operations_skipped(self):
        events = [
            {"operation": "open_session"},
            {"operation": "create_thread"},
            {"operation": "release_project"},
        ]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger is not None
        assert trigger.type == TriggerType.POST_RELEASE

    def test_empty_operation_string_skipped(self):
        events = [
            {"operation": ""},
            {"operation": "release_project"},
        ]
        trigger = session_rotation.detect_phase_boundary(events)
        assert trigger.type == TriggerType.POST_RELEASE


# ---------------------------------------------------------------------------
# should_rotate (policy + per-trigger disable)
# ---------------------------------------------------------------------------

class TestShouldRotate:
    def _trigger(self) -> Trigger:
        return Trigger(
            type=TriggerType.POST_RELEASE,
            source_event="release_project",
            detail="release_project completion",
        )

    def test_no_trigger_never_rotates(self):
        assert session_rotation.should_rotate(None) is False

    def test_off_policy_never_rotates(self):
        assert session_rotation.should_rotate(
            self._trigger(), policy=RotationPolicy.OFF,
        ) is False

    def test_conditional_policy_rotates_on_autonomous_trigger(self):
        assert session_rotation.should_rotate(
            self._trigger(), policy=RotationPolicy.CONDITIONAL,
        ) is True

    def test_aggressive_policy_rotates_on_any_trigger(self):
        # In aggressive mode, even non-standard triggers pass.
        assert session_rotation.should_rotate(
            self._trigger(), policy=RotationPolicy.AGGRESSIVE,
        ) is True

    def test_disabled_trigger_blocks_rotation(self):
        assert session_rotation.should_rotate(
            self._trigger(), policy=RotationPolicy.CONDITIONAL,
            disabled_triggers=["post_release"],
        ) is False

    def test_disabled_other_trigger_does_not_block(self):
        assert session_rotation.should_rotate(
            self._trigger(), policy=RotationPolicy.CONDITIONAL,
            disabled_triggers=["post_pr_merge"],
        ) is True

    def test_default_policy_is_off(self):
        # Default-OFF posture per operator directive 2026-05-08:
        # the structural infrastructure ships behind the project-
        # rule flag; nothing rotates without explicit opt-in.
        assert session_rotation.should_rotate(self._trigger()) is False


# ---------------------------------------------------------------------------
# make_rotation_marker
# ---------------------------------------------------------------------------

class TestMakeRotationMarker:
    def test_marker_format_carries_all_fields(self):
        trigger = Trigger(
            type=TriggerType.POST_RELEASE,
            source_event="release_project",
            detail="release_project completion at 2026-05-08T18:42:49Z",
        )
        marker = session_rotation.make_rotation_marker(
            prior_session_id="abc123",
            new_session_id="def456",
            trigger=trigger,
        )
        assert marker.startswith("[Session rotated: ")
        assert marker.endswith("]")
        assert "release_project completion" in marker
        assert "abc123" in marker
        assert "def456" in marker

    def test_marker_is_parseable_with_known_separators(self):
        # External tools can extract the new session_id by splitting
        # on "; new session: " — the contract for the visible-signal
        # pattern.
        trigger = Trigger(
            type=TriggerType.POST_PR_MERGE,
            source_event="pr_merge",
            detail="PR merge at 2026-05-08",
        )
        marker = session_rotation.make_rotation_marker(
            prior_session_id="P", new_session_id="N", trigger=trigger,
        )
        assert "; new session: N]" in marker
        assert "; prior session: P;" in marker


# ---------------------------------------------------------------------------
# make_rotation_event (action_log payload)
# ---------------------------------------------------------------------------

class TestMakeRotationEvent:
    def test_event_carries_full_audit_shape(self):
        trigger = Trigger(
            type=TriggerType.POST_DISCUSSION_AC,
            source_event="mark_discussion_decided",
            detail="Discussion AC closure at 2026-05-08",
        )
        event = session_rotation.make_rotation_event(
            prior_session_id="P", new_session_id="N",
            trigger=trigger, timestamp="2026-05-08T18:42:49Z",
        )
        assert event["operation"] == "session.rotated.autonomous"
        assert event["trigger_type"] == "post_discussion_ac"
        assert event["prior_session_id"] == "P"
        assert event["new_session_id"] == "N"
        assert event["timestamp"] == "2026-05-08T18:42:49Z"
        assert "Discussion AC" in event["detail"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
