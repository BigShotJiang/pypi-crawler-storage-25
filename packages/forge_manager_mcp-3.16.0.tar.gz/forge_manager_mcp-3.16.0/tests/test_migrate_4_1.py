"""Unit tests for migrate_4_1 — milestone-as-compound-doc backfill (#397 D1.a Phase 3b).

Pure-filesystem migration: walks ``<docs>/issues/*/meta.json`` for
unique milestone strings, materializes ``milestones/<version>/``
compound docs for each missing one. Tier semver-inferred. Idempotent.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from forge_manager_mcp.migrations.migrate_4_1 import (
    apply_migration,
    collect_milestone_versions,
    detect_4_1_state,
    infer_tier,
    list_already_materialized,
    parse_semver,
)


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


class TestParseSemver:
    def test_three_part_version(self):
        assert parse_semver("3.11.0") == (3, 11, 0, "")

    def test_with_prerelease_suffix(self):
        assert parse_semver("3.11.0a1") == (3, 11, 0, "a1")
        assert parse_semver("4.0.0rc1") == (4, 0, 0, "rc1")

    def test_unparseable_returns_none(self):
        assert parse_semver("not-a-version") is None
        assert parse_semver("3.11") is None
        assert parse_semver("") is None


class TestInferTier:
    def test_no_prior_versions_returns_major(self):
        # Greenfield first cut — major.
        assert infer_tier("1.0.0", []) == "major"

    def test_major_bump(self):
        assert infer_tier("4.0.0", ["3.10.0", "3.9.0"]) == "major"

    def test_minor_bump(self):
        assert infer_tier("3.11.0", ["3.10.0", "3.9.0"]) == "minor"

    def test_patch_bump(self):
        assert infer_tier("3.10.1", ["3.10.0"]) == "patch"

    def test_unparseable_falls_back_to_minor(self):
        assert infer_tier("not-a-version", ["3.10.0"]) == "minor"

    def test_picks_nearest_prior(self):
        # 3.10.1 vs priors 3.9.0 + 3.10.0 — nearest is 3.10.0 → patch.
        assert infer_tier("3.10.1", ["3.9.0", "3.10.0"]) == "patch"


# ---------------------------------------------------------------------------
# Filesystem walks
# ---------------------------------------------------------------------------


def _seed_issue(docs_root: Path, *, number: int, milestone: str | None):
    d = docs_root / "issues" / str(number)
    d.mkdir(parents=True, exist_ok=True)
    (d / "title.md").write_text(f"Issue {number}", encoding="utf-8")
    (d / "state.txt").write_text("open\n", encoding="utf-8")
    meta = {"number": number}
    if milestone is not None:
        meta["milestone"] = milestone
    (d / "meta.json").write_text(json.dumps(meta), encoding="utf-8")


def _seed_milestone_compound_doc(docs_root: Path, *, version: str):
    d = docs_root / "milestones" / version
    d.mkdir(parents=True, exist_ok=True)
    (d / "title.md").write_text(version, encoding="utf-8")
    (d / "state.txt").write_text("planned\n", encoding="utf-8")
    (d / "meta.json").write_text(
        json.dumps({"version": version, "tier": "minor"}),
        encoding="utf-8",
    )


class TestCollectMilestoneVersions:
    def test_empty_issues_dir_returns_empty_with_warning(self, tmp_path):
        # No issues dir at all.
        versions, warnings = collect_milestone_versions(tmp_path)
        assert versions == set()
        assert any("No issues/" in w for w in warnings)

    def test_collects_unique_milestones(self, tmp_path):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_issue(tmp_path, number=2, milestone="3.10.0")  # duplicate
        _seed_issue(tmp_path, number=3, milestone="3.11.0")
        _seed_issue(tmp_path, number=4, milestone=None)  # no milestone
        versions, warnings = collect_milestone_versions(tmp_path)
        assert versions == {"3.10.0", "3.11.0"}
        # No warnings for happy path.
        assert warnings == []

    def test_skips_unparseable_meta_with_warning(self, tmp_path):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        # Corrupt one.
        bad = tmp_path / "issues" / "99"
        bad.mkdir(parents=True)
        (bad / "meta.json").write_text("{not valid json", encoding="utf-8")
        versions, warnings = collect_milestone_versions(tmp_path)
        assert versions == {"3.10.0"}
        assert any("99" in w for w in warnings)


class TestListAlreadyMaterialized:
    def test_empty_when_no_milestones_dir(self, tmp_path):
        assert list_already_materialized(tmp_path) == set()

    def test_returns_dirs_with_meta_json(self, tmp_path):
        _seed_milestone_compound_doc(tmp_path, version="3.10.0")
        _seed_milestone_compound_doc(tmp_path, version="3.11.0")
        # Stale flat-file shouldn't count.
        (tmp_path / "milestones").mkdir(parents=True, exist_ok=True)
        (tmp_path / "milestones" / "3.0.1.md").write_text("# legacy\n")
        assert list_already_materialized(tmp_path) == {"3.10.0", "3.11.0"}


# ---------------------------------------------------------------------------
# detect_4_1_state
# ---------------------------------------------------------------------------


class TestDetect41State:
    def test_clean_when_all_versions_already_materialized(
        self, tmp_path, monkeypatch,
    ):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_milestone_compound_doc(tmp_path, version="3.10.0")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan = detect_4_1_state(Path("/dummy/project"))
        assert plan.is_clean is True
        assert plan.versions_to_create == ()

    def test_creates_for_new_versions(self, tmp_path, monkeypatch):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_issue(tmp_path, number=2, milestone="3.11.0")
        # Only 3.10.0 already materialized.
        _seed_milestone_compound_doc(tmp_path, version="3.10.0")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan = detect_4_1_state(Path("/dummy/project"))
        assert plan.is_clean is False
        assert plan.versions_to_create == ("3.11.0",)
        assert plan.versions_already_materialized == ("3.10.0",)

    def test_no_docs_root_warns_and_clean(self, tmp_path, monkeypatch):
        # FORGE_MANAGER_DOCS_REPO unset and no ~/<project>-docs/.
        monkeypatch.delenv("FORGE_MANAGER_DOCS_REPO", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # ensure no docs/ exists
        plan = detect_4_1_state(Path("/dummy/totally-unique-project-name"))
        assert plan.is_clean is True
        assert plan.versions_to_create == ()
        assert any("not found" in w.lower() for w in plan.warnings)


# ---------------------------------------------------------------------------
# apply_migration
# ---------------------------------------------------------------------------


class TestApplyMigration:
    def test_clean_plan_returns_no_materialized(self, tmp_path, monkeypatch):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_milestone_compound_doc(tmp_path, version="3.10.0")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan = detect_4_1_state(Path("/dummy"))
        result = apply_migration(plan)
        assert result["success"] is True
        assert result["materialized"] == []
        assert result["skipped"] == ["3.10.0"]

    def test_creates_compound_docs_for_each_version(
        self, tmp_path, monkeypatch,
    ):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_issue(tmp_path, number=2, milestone="3.11.0")
        _seed_issue(tmp_path, number=3, milestone="3.10.1")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan = detect_4_1_state(Path("/dummy"))
        result = apply_migration(plan)
        assert result["success"] is True
        # All three versions materialized.
        materialized_versions = {m["version"] for m in result["materialized"]}
        assert materialized_versions == {"3.10.0", "3.10.1", "3.11.0"}
        # Each version has a compound doc on disk.
        for version in materialized_versions:
            ms_dir = tmp_path / "milestones" / version
            assert ms_dir.is_dir()
            assert (ms_dir / "title.md").is_file()
            assert (ms_dir / "state.txt").read_text().strip() == "planned"
            meta = json.loads((ms_dir / "meta.json").read_text())
            assert meta["version"] == version
            assert meta["plan_discussion"] is None  # operator pins later
            assert meta["hotfix"] is False
            assert meta["cut_at"] is None

    def test_tier_inference_uses_semver_delta(
        self, tmp_path, monkeypatch,
    ):
        # 3.10.0 (greenfield = major), 3.11.0 (minor), 3.10.1 (patch).
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        _seed_issue(tmp_path, number=2, milestone="3.11.0")
        _seed_issue(tmp_path, number=3, milestone="3.10.1")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan = detect_4_1_state(Path("/dummy"))
        result = apply_migration(plan)
        tier_by_version = {
            m["version"]: m["tier"] for m in result["materialized"]
        }
        # Sort order: 3.10.0 first (greenfield → major), 3.10.1 next
        # (patch vs 3.10.0), 3.11.0 last (minor vs 3.10.1 nearest).
        assert tier_by_version["3.10.0"] == "major"
        assert tier_by_version["3.10.1"] == "patch"
        assert tier_by_version["3.11.0"] == "minor"

    def test_idempotent_second_apply_no_op(self, tmp_path, monkeypatch):
        _seed_issue(tmp_path, number=1, milestone="3.10.0")
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(tmp_path))
        plan_first = detect_4_1_state(Path("/dummy"))
        result_first = apply_migration(plan_first)
        assert len(result_first["materialized"]) == 1

        plan_second = detect_4_1_state(Path("/dummy"))
        assert plan_second.is_clean is True
        result_second = apply_migration(plan_second)
        assert result_second["materialized"] == []


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Edge-branch coverage.
# ---------------------------------------------------------------------------


class TestCollectMilestoneVersionsContinueBranches:
    def test_non_dir_entry_in_issues_root_skipped(self, tmp_path):
        # Stray file under issues/ → `if not entry.is_dir(): continue`
        # (L130).
        (tmp_path / "issues").mkdir()
        (tmp_path / "issues" / "stray.txt").write_text("nope")
        # Real issue with a milestone.
        (tmp_path / "issues" / "1").mkdir()
        (tmp_path / "issues" / "1" / "meta.json").write_text(
            json.dumps({"milestone": "3.10.0"})
        )
        versions, warnings = collect_milestone_versions(tmp_path)
        assert versions == {"3.10.0"}
        assert warnings == []

    def test_entry_without_meta_json_skipped(self, tmp_path):
        # Directory under issues/ that has no meta.json →
        # `if not meta_path.is_file(): continue` (L133).
        (tmp_path / "issues" / "1").mkdir(parents=True)
        # No meta.json under issues/1.
        versions, warnings = collect_milestone_versions(tmp_path)
        assert versions == set()
        assert warnings == []


class TestDetect41StateHomeFallback:
    def test_home_directory_fallback_resolves(
        self, tmp_path, monkeypatch,
    ):
        # FORGE_MANAGER_DOCS_REPO unset (or pointing nowhere) →
        # ``~/<project>-docs/`` candidate. Stub Path.home to tmp_path,
        # seed tmp_path/<projname>-docs/issues/ — covers L173-175.
        monkeypatch.delenv("FORGE_MANAGER_DOCS_REPO", raising=False)
        from forge_manager_mcp.migrations import migrate_4_1 as m41
        monkeypatch.setattr(m41.Path, "home", lambda: tmp_path)

        proj = tmp_path / "myproj"
        proj.mkdir()
        docs = tmp_path / "myproj-docs"
        (docs / "issues" / "1").mkdir(parents=True)
        (docs / "issues" / "1" / "meta.json").write_text(
            json.dumps({"milestone": "3.10.0"})
        )

        plan = detect_4_1_state(proj)
        # Home-fallback resolved docs_root → plan reports versions.
        assert plan.versions_present == ("3.10.0",)


class TestApplyMigrationSortKeyUnparseable:
    def test_unparseable_versions_sort_first(self, tmp_path, monkeypatch):
        # A milestone string that doesn't parse as semver triggers
        # the `return (0, v)` branch in sort_key (L261). It must
        # still get materialized (with "minor" fallback tier from
        # infer_tier).
        from forge_manager_mcp.migrations.migrate_4_1 import _migration_plan_class
        MP = _migration_plan_class()
        plan = MP(
            docs_root=tmp_path,
            versions_present=("not-a-semver",),
            versions_already_materialized=(),
            versions_to_create=("not-a-semver",),
            warnings=(),
        )
        result = apply_migration(plan)
        # Materialized despite unparseable version.
        assert {m["version"] for m in result["materialized"]} == {"not-a-semver"}
        # Tier falls back to "minor" since parse_semver returned None.
        assert result["materialized"][0]["tier"] == "minor"


class TestApplyMigrationOSError:
    def test_write_failure_collected_as_warning(
        self, tmp_path, monkeypatch,
    ):
        # _write_milestone_compound_doc raises OSError → continue
        # past, record a warning. L270-274.
        from forge_manager_mcp.migrations import migrate_4_1 as m41

        def _boom(docs_root, version, tier):
            raise OSError(f"simulated write failure on {version}")

        monkeypatch.setattr(m41, "_write_milestone_compound_doc", _boom)

        plan = m41._migration_plan_class()(
            docs_root=tmp_path,
            versions_present=("3.10.0",),
            versions_already_materialized=(),
            versions_to_create=("3.10.0",),
            warnings=(),
        )
        result = apply_migration(plan)
        assert result["materialized"] == []
        assert any("Failed to materialize" in w for w in result["warnings"])


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
