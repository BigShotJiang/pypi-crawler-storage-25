"""Regression tests for the ref.number=None URL-construction guards
(#413 / 3.12.0).

The 2026-05-10 incident: 17 failed POST/PATCH calls in 28 minutes
to ``/issues/None/comments`` and ``/issues/None`` against Codeberg
because the ForgejoAdapter was f-stringing ``ref.number`` directly
into URL paths even when ``ref.number is None``. Each call burned
rate limit and surfaced as a generic 404.

The fix added ``_require_number(ref, op)`` helpers to both
ForgejoAdapter and GitLabAdapter (GitHub doesn't have the bug-class
because its ops use GraphQL node_ids, not REST URL paths).

These tests assert that every URL-constructing method on each
adapter raises :class:`InvalidArtifactRefError` (typed) before
firing an HTTP request when given a None-number ref.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
from forge_manager_mcp.adapters.gitlab import GitLabAdapter
from forge_manager_mcp.adapters.types import ArtifactRef


def _none_number_ref() -> ArtifactRef:
    return ArtifactRef(
        kind="issue",
        owner="telejester",
        repo="proj",
        number=None,
        native_id="some-node-id",
        platform_id="forgejo",
    )


# ---------------------------------------------------------------------------
# ForgejoAdapter
# ---------------------------------------------------------------------------


@pytest.fixture
def forgejo() -> ForgejoAdapter:
    return ForgejoAdapter(
        token="t", api_base="https://example.invalid/api/v1",
        platform_id="forgejo",
    )


class TestForgejoNoneNumberGuards:
    @pytest.mark.asyncio
    async def test_update_issue_body(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.update_issue_body(_none_number_ref(), "new body")
        assert "update_issue_body" in str(exc_info.value)
        assert "ref.number" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_close_issue(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.close_issue(_none_number_ref())
        assert "close_issue" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_add_label(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.add_label(_none_number_ref(), "bug")
        assert "add_label" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_remove_label(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.remove_label(_none_number_ref(), "bug")
        assert "remove_label" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_append_comment(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.append_comment(_none_number_ref(), "comment body")
        assert "append_comment" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_list_comments(self, forgejo):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await forgejo.list_comments(_none_number_ref())
        assert "list_comments" in str(exc_info.value)


# ---------------------------------------------------------------------------
# GitLabAdapter
# ---------------------------------------------------------------------------


@pytest.fixture
def gitlab() -> GitLabAdapter:
    return GitLabAdapter(
        token="t", api_base="https://example.invalid/api/v4",
        platform_id="gitlab",
    )


class TestGitLabNoneNumberGuards:
    @pytest.mark.asyncio
    async def test_update_issue_body(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.update_issue_body(_none_number_ref(), "new body")
        assert "update_issue_body" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_close_issue(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.close_issue(_none_number_ref())
        assert "close_issue" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_add_label(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.add_label(_none_number_ref(), "bug")
        assert "add_label" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_remove_label(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.remove_label(_none_number_ref(), "bug")
        assert "remove_label" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_append_comment(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.append_comment(_none_number_ref(), "comment body")
        assert "append_comment" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_list_comments(self, gitlab):
        with pytest.raises(_errors.InvalidArtifactRefError) as exc_info:
            await gitlab.list_comments(_none_number_ref())
        assert "list_comments" in str(exc_info.value)


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
