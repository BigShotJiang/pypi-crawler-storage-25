"""Unit tests for ReplicationManager adapter-state persistence (#377 /
3.8.1 D1).

Covers:
  * State-file written atomically on every _set_state transition
  * Construction rehydrates persisted state into entries
  * Schema-version mismatch discards with no crash
  * PAUSED + DEGRADED states survive round trip
  * Atomic write: partial write doesn't corrupt the prior file
  * No state_dir → no persistence (back-compat)
  * Per-entry parse failure keeps surviving entries
  * Unknown persisted platform_id ignored when current entries don't match
  * write_replication_state OSError is swallowed by manager
  * Integration shape: two-manager round trip (kill + respawn equivalent)
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from forge_manager_mcp.replication import (
    AdapterState, ReplicationManager,
)
from forge_manager_mcp.replication.persistence import (
    PersistedAdapterError,
    REPLICATION_STATE_FILENAME,
    REPLICATION_STATE_SCHEMA_VERSION,
    make_persisted_entry,
    make_replication_state,
    read_replication_state,
    replication_state_path,
    write_replication_state,
)


class _MockAdapter:
    def __init__(self, platform_id: str):
        self.platform_id = platform_id


def _adapters(*ids: str) -> list:
    return [(pid, _MockAdapter(pid)) for pid in ids]


def _state_file(state_dir: Path) -> Path:
    return state_dir / REPLICATION_STATE_FILENAME


# ---------------------------------------------------------------------------
# Set_state writes file
# ---------------------------------------------------------------------------

class TestSetStateWritesFile:

    def test_initial_construction_writes_default_state(self, tmp_path: Path):
        ReplicationManager(_adapters("local", "github"), state_dir=tmp_path)
        # No transition has fired, but rehydrate-with-no-file is silent;
        # no file should be written until the first _set_state call.
        assert not _state_file(tmp_path).exists()

    def test_set_state_writes_file(self, tmp_path: Path):
        manager = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        manager._set_state(
            manager._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("HTTP 403"),
        )
        f = _state_file(tmp_path)
        assert f.exists()
        data = json.loads(f.read_text())
        assert data["schema_version"] == REPLICATION_STATE_SCHEMA_VERSION
        github_entry = next(
            e for e in data["entries"] if e["platform_id"] == "github"
        )
        assert github_entry["state"] == "degraded"
        assert github_entry["last_error_message"] == "HTTP 403"
        assert github_entry["last_error_type"] == "RuntimeError"

    def test_persist_swallows_oserror(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        # Best-effort contract: filesystem failures must not poison the
        # state machine. _set_state still mutates the entry; only the
        # write is lost.
        manager = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        from forge_manager_mcp.replication import manager as mgr_mod

        def _boom(*a, **kw):
            raise OSError("filesystem full")
        monkeypatch.setattr(
            "forge_manager_mcp.replication.persistence."
            "write_replication_state", _boom,
        )
        # No exception should escape.
        manager._set_state(
            manager._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("nope"),
        )
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert manager._entries[1].state == AdapterState.DEGRADED


# ---------------------------------------------------------------------------
# Construction rehydrates from file
# ---------------------------------------------------------------------------

class TestConstructionRehydrates:

    def test_rehydrates_persisted_degraded(self, tmp_path: Path):
        m1 = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        m1._set_state(
            m1._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("HTTP 403"),
        )
        # Construct a fresh manager — same adapter list, same state_dir.
        # Should rehydrate github into DEGRADED without any new ops.
        m2 = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        github = m2._entries[1]
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert github.state == AdapterState.DEGRADED
        assert isinstance(github.last_error, PersistedAdapterError)
        assert str(github.last_error) == "HTTP 403"
        assert github.last_error.original_type_name == "RuntimeError"

    def test_rehydrates_state_changed_at_timestamp(self, tmp_path: Path):
        m1 = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        m1._set_state(
            m1._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("e"),
        )
        ts1 = m1._entries[1].state_changed_at
        m2 = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        # The persisted timestamp must round-trip — UI uses it for
        # "DEGRADED since X" labels.
        assert m2._entries[1].state_changed_at == ts1

    def test_unknown_persisted_platform_id_ignored(self, tmp_path: Path):
        # Persist state for "github"; construct a manager that has no
        # github entry. Surviving entries (local) keep their default
        # initialization; the orphaned github persisted entry is
        # silently dropped.
        write_replication_state(
            tmp_path,
            make_replication_state(entries=(
                make_persisted_entry(
                    platform_id="github",
                    state="degraded",
                    last_error_message="boom",
                    last_error_type="RuntimeError",
                    state_changed_at=__import__("datetime").datetime(
                        2026, 5, 8, 12, 0, 0,
                        tzinfo=__import__("datetime").timezone.utc,
                    ),
                    last_error_at=None,
                    next_attempt_at=None,
                ),
            )),
        )
        m = ReplicationManager(
            _adapters("local", "codeberg"), state_dir=tmp_path,
        )
        assert m._entries[0].state == AdapterState.HEALTHY
        assert m._entries[1].state == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# Schema mismatch
# ---------------------------------------------------------------------------

class TestSchemaMismatch:

    def test_unknown_schema_version_returns_none(self, tmp_path: Path):
        target = _state_file(tmp_path)
        target.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION + 99,
            "entries": [],
        }))
        assert read_replication_state(tmp_path) is None

    def test_schema_mismatch_does_not_crash_construction(
        self, tmp_path: Path,
    ):
        target = _state_file(tmp_path)
        target.write_text(json.dumps({
            "schema_version": "future-version-string",
            "entries": [],
        }))
        # Constructor must not raise; entries fall back to default
        # HEALTHY initialization.
        m = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        assert m._entries[0].state == AdapterState.HEALTHY
        assert m._entries[1].state == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# PAUSED state round trip
# ---------------------------------------------------------------------------

# (#23 A.5 OQ1 / 3.15.0) TestPausedRoundTrip RETIRED — PAUSED state
# migrated to the durable `platforms[i].enabled` config flag. The
# "operator intent survives restart" invariant now reads as
# "enabled=False survives restart" which is structurally true:
# forge-config.json IS the durable record.


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------

class TestAtomicWrite:

    def test_atomic_write_partial_does_not_corrupt(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        # Establish a good file via a normal write.
        m1 = ReplicationManager(
            _adapters("local", "github"), state_dir=tmp_path,
        )
        m1._set_state(
            m1._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("first"),
        )
        target = _state_file(tmp_path)
        original = target.read_text()

        # Simulate a crash mid-write: the rename step never executes,
        # so the prior file should still be intact.
        import os as _os
        real_replace = _os.replace

        def _crash_before_rename(src, dst):
            raise OSError("simulated crash before rename")
        monkeypatch.setattr(_os, "replace", _crash_before_rename)

        # The next _set_state call's persist should be swallowed by the
        # manager. The state machine still updates in-memory.
        m1._set_state(
            m1._entries[1], AdapterState.HEALTHY,
        )
        # Restore real replace for any subsequent test cleanup.
        monkeypatch.setattr(_os, "replace", real_replace)

        # The on-disk file is the original DEGRADED record — atomic
        # rename never happened.
        assert target.read_text() == original
        # In-memory state still transitioned.
        assert m1._entries[1].state == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# Back-compat: no state_dir means no persistence
# ---------------------------------------------------------------------------

class TestNoStateDir:

    def test_no_state_dir_no_file_written(self, tmp_path: Path):
        m = ReplicationManager(_adapters("local", "github"))
        m._set_state(
            m._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("e"),
        )
        # No state_dir was passed; nothing should be on disk under
        # tmp_path (we never told the manager about it).
        assert not (tmp_path / REPLICATION_STATE_FILENAME).exists()

    def test_state_dir_none_construction_ok(self):
        # Sanity: pre-3.8.1 callers (no state_dir kwarg) still work.
        m = ReplicationManager(_adapters("local", "github"))
        assert m._entries[0].state == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# Per-entry corruption tolerance
# ---------------------------------------------------------------------------

class TestPerEntryCorruption:

    def test_one_bad_entry_keeps_others(self, tmp_path: Path):
        target = _state_file(tmp_path)
        target.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                # Valid entry.
                {
                    "platform_id": "github",
                    "state": "degraded",
                    "last_error_message": "boom",
                    "last_error_type": "RuntimeError",
                    "state_changed_at": "2026-05-08T12:00:00+00:00",
                    "last_error_at": "2026-05-08T12:00:00+00:00",
                    "next_attempt_at": None,
                },
                # Malformed entry: state not in valid set.
                {
                    "platform_id": "codeberg",
                    "state": "imaginary",
                    "last_error_message": None,
                    "last_error_type": None,
                    "state_changed_at": "2026-05-08T12:00:00+00:00",
                    "last_error_at": None,
                    "next_attempt_at": None,
                },
            ],
        }))
        m = ReplicationManager(
            _adapters("local", "github", "codeberg"), state_dir=tmp_path,
        )
        # github applied; codeberg fell through to default healthy.
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m._entries[1].state == AdapterState.DEGRADED
        assert m._entries[2].state == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# Integration: round-trip across two manager instances (kill+respawn)
# ---------------------------------------------------------------------------

class TestKillRespawnRoundTrip:

    def test_state_survives_two_manager_instances(self, tmp_path: Path):
        # Stage 1: first manager, transition github to DEGRADED.
        m1 = ReplicationManager(
            _adapters("local", "github", "codeberg"), state_dir=tmp_path,
        )
        m1._set_state(
            m1._entries[1], AdapterState.DEGRADED,
            error=RuntimeError("HTTP 403"),
        )
        # (#23 A.5 OQ1) PAUSED transition retired; second adapter
        # stays HEALTHY for this restart-survival test.

        # Stage 2: drop m1 (simulate daemon SIGTERM); construct m2 from
        # the same state_dir. The DEGRADED transition must rehydrate
        # before any op fires.
        m2 = ReplicationManager(
            _adapters("local", "github", "codeberg"), state_dir=tmp_path,
        )
        assert m2._entries[0].state == AdapterState.HEALTHY  # canonical, untouched
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m2._entries[1].state == AdapterState.DEGRADED
        assert str(m2._entries[1].last_error) == "HTTP 403"


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Edge-branch coverage.
# ---------------------------------------------------------------------------


class TestMakePersistedEntryValidation:
    def test_empty_platform_id_raises_value_error(self):
        # L113-114 ValueError for empty platform_id.
        from datetime import datetime, timezone
        with pytest.raises(ValueError, match="platform_id"):
            make_persisted_entry(
                platform_id="",
                state="healthy",
                last_error_message=None,
                last_error_type=None,
                state_changed_at=datetime.now(timezone.utc),
                last_error_at=None,
                next_attempt_at=None,
            )

    def test_invalid_state_raises_value_error(self):
        # L115-118 ValueError for state not in _VALID_STATE_VALUES.
        from datetime import datetime, timezone
        with pytest.raises(ValueError, match="state"):
            make_persisted_entry(
                platform_id="github",
                state="not_a_real_state",
                last_error_message=None,
                last_error_type=None,
                state_changed_at=datetime.now(timezone.utc),
                last_error_at=None,
                next_attempt_at=None,
            )


class TestParseEntryEdgeBranches:
    def test_missing_required_field_returns_none(self, tmp_path):
        # _parse_entry: KeyError on missing platform_id / state →
        # L217-218 returns None.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                # Missing "platform_id" → _parse_entry returns None.
                {"state": "healthy", "state_changed_at": "2026-01-01T00:00:00+00:00"},
            ],
        }))
        state = read_replication_state(tmp_path)
        # Bad entry dropped; valid surviving entries: none.
        assert state is not None
        assert state.entries == ()

    def test_invalid_last_error_at_returns_none(self, tmp_path):
        # _parse_entry: ValueError parsing last_error_at →
        # L228-229 returns None.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                {
                    "platform_id": "github",
                    "state": "healthy",
                    "state_changed_at": "2026-01-01T00:00:00+00:00",
                    "last_error_at": "not-an-iso-string",
                    "next_attempt_at": None,
                },
            ],
        }))
        state = read_replication_state(tmp_path)
        assert state is not None
        assert state.entries == ()

    def test_non_string_last_error_message_returns_none(self, tmp_path):
        # _parse_entry: last_error_message not a string → L230-233.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                {
                    "platform_id": "github",
                    "state": "healthy",
                    "state_changed_at": "2026-01-01T00:00:00+00:00",
                    "last_error_at": None,
                    "next_attempt_at": None,
                    "last_error_message": 42,  # not a string
                },
            ],
        }))
        state = read_replication_state(tmp_path)
        assert state is not None and state.entries == ()

    def test_non_string_last_error_type_returns_none(self, tmp_path):
        # _parse_entry: last_error_type not a string → L234-235.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                {
                    "platform_id": "github",
                    "state": "healthy",
                    "state_changed_at": "2026-01-01T00:00:00+00:00",
                    "last_error_at": None,
                    "next_attempt_at": None,
                    "last_error_type": 42,  # not a string
                },
            ],
        }))
        state = read_replication_state(tmp_path)
        assert state is not None and state.entries == ()


class TestReadReplicationStateEdgeBranches:
    def test_oserror_reading_file_returns_none(self, tmp_path, monkeypatch):
        # OSError reading the state file → L267-268 returns None.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({"schema_version": 1, "entries": []}))

        from pathlib import Path as _P
        original = _P.read_text

        def _fail(self, *a, **kw):
            if self == state_path:
                raise OSError("simulated")
            return original(self, *a, **kw)

        monkeypatch.setattr(_P, "read_text", _fail)
        assert read_replication_state(tmp_path) is None

    def test_malformed_json_returns_none(self, tmp_path):
        # json.JSONDecodeError → L267-268 returns None.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text("{ not valid json")
        assert read_replication_state(tmp_path) is None

    def test_top_level_not_a_dict_returns_none(self, tmp_path):
        # Top-level data is a list, not a dict → L269-270.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps(["not", "a", "dict"]))
        assert read_replication_state(tmp_path) is None

    def test_entries_not_a_list_returns_none(self, tmp_path):
        # data.entries is a dict (not a list) → L273-275.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": {"wrong": "shape"},
        }))
        assert read_replication_state(tmp_path) is None

    def test_non_dict_entry_in_entries_list_skipped(self, tmp_path):
        # Entry-list element that isn't a dict → continue at L278-279.
        state_path = tmp_path / REPLICATION_STATE_FILENAME
        state_path.write_text(json.dumps({
            "schema_version": REPLICATION_STATE_SCHEMA_VERSION,
            "entries": [
                "not-a-dict",
                {
                    "platform_id": "github",
                    "state": "healthy",
                    "state_changed_at": "2026-01-01T00:00:00+00:00",
                    "last_error_at": None,
                    "next_attempt_at": None,
                },
            ],
        }))
        state = read_replication_state(tmp_path)
        # Non-dict skipped; valid entry survives.
        assert state is not None
        assert len(state.entries) == 1
        assert state.entries[0].platform_id == "github"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
