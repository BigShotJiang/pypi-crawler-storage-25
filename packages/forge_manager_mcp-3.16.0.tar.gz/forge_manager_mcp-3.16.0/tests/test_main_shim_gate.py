"""Gate: every Python test source file ends with the canonical
pytest.main shim (#431 / 3.12.0).

Per #198 / 2.1.0, rules_python's py_test runs the test source as
a script. Without ``if __name__ == "__main__": sys.exit(pytest.main(
[__file__, "-v"]))``, pytest's collection logic never executes —
every test SILENTLY PASSES because zero cases run. The PASSED status
is a lie.

#198 added a CI lint gate but it runs only at PR-open time on
GitHub. With GitHub suspended (since 2026-04-28) and direct-to-main
commits during 3.12.0 autonomous mode, the gate was bypassed. 4
test files I added during 3.12.0 had this bug — 44 ghost cases
that never ran. This gate moves the check from CI to Bazel: every
``bazel test //tests:unit_tests`` invocation enforces the shim,
not just CI.

Implementation: walk every ``test_*.py`` under tests/, check each
contains the canonical shim regex. Files that fail surface in the
test output as a clear list of paths needing the shim.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest


# Match the canonical shim. Tolerant of formatting variations
# (whitespace, trailing args). Requires both ``__name__ ==
# "__main__"`` AND ``pytest.main`` to coexist somewhere after.
_SHIM_PATTERN = re.compile(
    r'if\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:.*?pytest\.main\s*\(',
    re.DOTALL,
)


def _find_test_files() -> list[Path]:
    """Return every test_*.py file under the project's tests/ tree.

    Resolves the project root by walking up from this file's own
    location. Bazel's runfile sandbox places the test script + the
    `data` files in a predictable layout — this code reads from
    the runfile tree, which contains the source-tree layout.
    """
    here = Path(__file__).resolve()
    # The runfile tree mirrors the source layout: tests/ is the
    # parent dir of every test file.
    tests_dir = here.parent
    return sorted(tests_dir.rglob("test_*.py"))


def test_every_test_file_has_main_shim():
    """Every test_*.py file must end with the pytest.main shim.

    Without it, the file's test cases are silent no-ops under
    rules_python's py_test — Bazel reports PASSED but no cases
    run. This gate catches the regression at every `bazel test`
    invocation, not just at CI's PR-open time.
    """
    test_files = _find_test_files()
    # Defensive — the rglob should find this file at minimum
    assert len(test_files) > 0, (
        f"No test_*.py files found under {Path(__file__).parent}; "
        "the gate's file discovery is broken."
    )

    missing: list[str] = []
    for path in test_files:
        text = path.read_text()
        if not _SHIM_PATTERN.search(text):
            # Use a workspace-relative path for readability
            try:
                rel = path.relative_to(Path(__file__).parent.parent)
            except ValueError:
                rel = path
            missing.append(str(rel))

    if missing:
        formatted = "\n".join(f"  - {m}" for m in missing)
        raise AssertionError(
            f"{len(missing)} Python test file(s) missing the canonical "
            f"`if __name__ == \"__main__\": sys.exit(pytest.main(...))` "
            f"shim. Without it the file's test cases are SILENT NO-OPS "
            f"under rules_python's py_test (see #431, #198):\n{formatted}"
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
