"""Unit tests for LocalStoreAdapter (3.0 / Phase 2 sub-run C).

Tests filesystem-backed adapter against a tmp_path-rooted docs repo.
Covers all PlatformAdapter Protocol methods.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from forge_manager_mcp.adapters.errors import (
    ForgeError,
    InvalidArtifactRefError,
    LocalStoreAlreadyExistsError,
)
from forge_manager_mcp.adapters.local_store import (
    DEFAULT_DOCS_REPO_ENV,
    LocalStoreAdapter,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def docs_repo(tmp_path: Path) -> Path:
    """Empty git-init'd docs repo at tmp_path."""
    subprocess.run(
        ["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"], cwd=tmp_path, check=True,
    )
    # Initial empty commit so subsequent commits have a base.
    subprocess.run(
        ["git", "commit", "-q", "--allow-empty", "-m", "initial"],
        cwd=tmp_path, check=True,
    )
    return tmp_path


@pytest.fixture
def adapter(docs_repo: Path) -> LocalStoreAdapter:
    return LocalStoreAdapter(docs_repo_path=docs_repo)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestConstruction:
    def test_platform_id_classvar(self):
        assert LocalStoreAdapter.platform_id == "local"

    def test_from_config_with_explicit_path(self, docs_repo: Path):
        a = LocalStoreAdapter.from_config({"id": "local", "path": str(docs_repo)})
        assert a.path == docs_repo

    def test_from_config_with_env_var(self, docs_repo: Path, monkeypatch):
        monkeypatch.setenv(DEFAULT_DOCS_REPO_ENV, str(docs_repo))
        a = LocalStoreAdapter.from_config({"id": "local"})
        assert a.path == docs_repo

    def test_from_config_missing_repo_raises(self, tmp_path: Path):
        bogus = tmp_path / "not_a_repo"
        with pytest.raises(ForgeError, match="not found"):
            LocalStoreAdapter.from_config({"id": "local", "path": str(bogus)})


# ---------------------------------------------------------------------------
# Issue operations
# ---------------------------------------------------------------------------

class TestCreateIssue:
    @pytest.mark.asyncio
    async def test_creates_issue_files(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r",
            title="test issue", body="body content",
            labels=["kind:bug", "area:mcp"],
        )
        assert issue.ref.number == 1
        assert issue.ref.platform_id == "local"
        assert issue.title == "test issue"
        assert issue.body == "body content"
        assert issue.state == "open"
        assert "kind:bug" in issue.labels

        issue_dir = docs_repo / "issues" / "1"
        assert (issue_dir / "title.md").read_text() == "test issue\n"
        assert (issue_dir / "body.md").read_text() == "body content"
        assert (issue_dir / "state.txt").read_text() == "open\n"
        assert "kind:bug" in (issue_dir / "labels.txt").read_text()

    @pytest.mark.asyncio
    async def test_consecutive_numbering(self, adapter):
        i1 = await adapter.create_issue(
            owner="o", repo="r", title="t1", body="", labels=["kind:bug"],
        )
        i2 = await adapter.create_issue(
            owner="o", repo="r", title="t2", body="", labels=["kind:bug"],
        )
        i3 = await adapter.create_issue(
            owner="o", repo="r", title="t3", body="", labels=["kind:bug"],
        )
        assert i1.ref.number == 1
        assert i2.ref.number == 2
        assert i3.ref.number == 3

    @pytest.mark.asyncio
    async def test_milestone_persisted(self, adapter, docs_repo):
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="",
            labels=["kind:bug"], milestone="3.0.0",
        )
        meta = json.loads((docs_repo / "issues" / "1" / "meta.json").read_text())
        assert meta["milestone"] == "3.0.0"

    @pytest.mark.asyncio
    async def test_auto_commits(self, adapter, docs_repo):
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        log = subprocess.run(
            ["git", "log", "--oneline"],
            cwd=docs_repo, capture_output=True, text=True, check=True,
        )
        assert "create_issue #1" in log.stdout


class TestGetAndUpdateIssue:
    @pytest.mark.asyncio
    async def test_get_issue_round_trip(self, adapter):
        created = await adapter.create_issue(
            owner="o", repo="r", title="round-trip", body="body",
            labels=["kind:bug"],
        )
        fetched = await adapter.get_issue("o", "r", created.ref.number)
        assert fetched.title == "round-trip"
        assert fetched.body == "body"

    @pytest.mark.asyncio
    async def test_get_missing_issue_raises(self, adapter):
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue("o", "r", 999)

    @pytest.mark.asyncio
    async def test_update_issue_body(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="old", labels=["kind:bug"],
        )
        await adapter.update_issue_body(issue.ref, "new body")
        assert (docs_repo / "issues" / "1" / "body.md").read_text() == "new body"

    @pytest.mark.asyncio
    async def test_get_issue_body_round_trip(self, adapter):
        """#274 Phase C1 — get_issue_body(ref) reads back what
        update_issue_body wrote, so an update→read cycle is the
        identity within a session."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="hello",
            labels=["kind:bug"],
        )
        assert await adapter.get_issue_body(issue.ref) == "hello"
        await adapter.update_issue_body(issue.ref, "rewritten")
        assert await adapter.get_issue_body(issue.ref) == "rewritten"

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_dir_raises(self, adapter):
        from forge_manager_mcp.adapters.types import ArtifactRef
        bogus = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue_body(bogus)

    @pytest.mark.asyncio
    async def test_update_issue_milestone_writes_meta_json(
        self, adapter, docs_repo,
    ):
        """(#388, 3.9.0 D5) update_issue_milestone writes the
        milestone field into meta.json."""
        import json
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.update_issue_milestone(issue.ref, "3.9.0")
        meta_path = docs_repo / "issues" / "1" / "meta.json"
        meta = json.loads(meta_path.read_text())
        assert meta["milestone"] == "3.9.0"

    @pytest.mark.asyncio
    async def test_update_issue_milestone_clears_with_none(
        self, adapter, docs_repo,
    ):
        """Passing milestone_title=None clears the milestone."""
        import json
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        # Set then clear.
        await adapter.update_issue_milestone(issue.ref, "3.9.0")
        await adapter.update_issue_milestone(issue.ref, None)
        meta_path = docs_repo / "issues" / "1" / "meta.json"
        meta = json.loads(meta_path.read_text())
        assert meta["milestone"] is None

    @pytest.mark.asyncio
    async def test_update_issue_milestone_records_history(
        self, adapter, docs_repo,
    ):
        """History entry captures prior + new milestone values."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.update_issue_milestone(issue.ref, "3.9.0")
        history_dir = docs_repo / "issues" / "1" / "history"
        # The most-recent history file should mention update_milestone.
        files = sorted(history_dir.glob("*.json"))
        assert files
        last = files[-1].read_text()
        assert "update_milestone" in last
        assert "3.9.0" in last

    @pytest.mark.asyncio
    async def test_update_issue_milestone_missing_dir_raises(self, adapter):
        from forge_manager_mcp.adapters.types import ArtifactRef
        bogus = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.update_issue_milestone(bogus, "3.9.0")

    # -------------------------------------------------------------
    # (3.16.0 D4 / RFC #506) update_issue_meta — generic field-bag
    # -------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_update_issue_meta_title(self, adapter, docs_repo):
        """G1: title mutation closes the rename-without-tool gap."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="Old title", body="b",
            labels=["kind:bug"],
        )
        await adapter.update_issue_meta(issue.ref, title="New title")
        assert (docs_repo / "issues" / "1" / "title.md").read_text() == "New title\n"

    @pytest.mark.asyncio
    async def test_update_issue_meta_body(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="old body",
            labels=["kind:bug"],
        )
        await adapter.update_issue_meta(issue.ref, body="new body")
        assert (docs_repo / "issues" / "1" / "body.md").read_text() == "new body"

    @pytest.mark.asyncio
    async def test_update_issue_meta_milestone(self, adapter, docs_repo):
        import json
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.update_issue_meta(issue.ref, milestone="3.16.0")
        meta = json.loads(
            (docs_repo / "issues" / "1" / "meta.json").read_text(),
        )
        assert meta["milestone"] == "3.16.0"

    @pytest.mark.asyncio
    async def test_update_issue_meta_multi_field_atomic(self, adapter, docs_repo):
        """All allowed fields in one call land together."""
        import json
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.update_issue_meta(
            issue.ref,
            title="Renamed", body="Rebodied", milestone="3.16.0",
        )
        d = docs_repo / "issues" / "1"
        assert d.joinpath("title.md").read_text() == "Renamed\n"
        assert d.joinpath("body.md").read_text() == "Rebodied"
        meta = json.loads(d.joinpath("meta.json").read_text())
        assert meta["milestone"] == "3.16.0"

    @pytest.mark.asyncio
    async def test_update_issue_meta_rejects_unknown_field(self, adapter):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        from forge_manager_mcp.adapters.errors import ForgeError
        with pytest.raises(ForgeError, match="unknown field"):
            await adapter.update_issue_meta(issue.ref, garbage="x")

    @pytest.mark.asyncio
    async def test_update_issue_meta_missing_dir_raises(self, adapter):
        from forge_manager_mcp.adapters.types import ArtifactRef
        bogus = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.update_issue_meta(bogus, title="X")

    @pytest.mark.asyncio
    async def test_update_issue_meta_appends_history(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.update_issue_meta(issue.ref, title="New")
        history_dir = docs_repo / "issues" / "1" / "history"
        entries = list(history_dir.iterdir()) if history_dir.exists() else []
        assert len(entries) >= 1
        # Last entry should be the update_meta op.
        import json
        last_entry = sorted(entries)[-1]
        rec = json.loads(last_entry.read_text())
        assert rec["operation"] == "update_meta"

    @pytest.mark.asyncio
    async def test_close_issue_returns_canonical_issue(self, adapter):
        """#274 Phase C2 — close_issue returns the closed Issue."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        closed = await adapter.close_issue(issue.ref)
        assert closed.state == "closed"
        assert closed.ref.number == issue.ref.number
        assert closed.title == issue.title  # title unchanged

    @pytest.mark.asyncio
    async def test_search_issues_returns_search_result(self, adapter):
        """#274 Phase C4 — search_issues returns SearchResult with
        total_count counting the full match set even when results is
        capped by limit."""
        # Create three matching Issues, then search with limit=2.
        for n in range(3):
            await adapter.create_issue(
                owner="o", repo="r", title=f"hit {n}",
                body="searchable", labels=["kind:bug"],
            )
        result = await adapter.search_issues(
            owner="o", repo="r", query="searchable", limit=2,
        )
        assert len(result.results) == 2
        # total_count reflects the full set, not just `len(results)`.
        assert result.total_count == 3
        assert result.query == "searchable"

    @pytest.mark.asyncio
    async def test_list_comments_limit(self, adapter):
        """#274 Phase C3 — limit kwarg keeps the most-recent N
        comments after the chronological order."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        # Three comments; with limit=2, expect the 2 most recent.
        await adapter.append_comment(issue.ref, "first")
        await adapter.append_comment(issue.ref, "second")
        await adapter.append_comment(issue.ref, "third")
        all_three = await adapter.list_comments(issue.ref)
        assert len(all_three) == 3
        last_two = await adapter.list_comments(issue.ref, limit=2)
        assert len(last_two) == 2
        assert last_two[-1].body == "third"

    @pytest.mark.asyncio
    async def test_close_issue(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.close_issue(issue.ref)
        state_text = (docs_repo / "issues" / "1" / "state.txt").read_text()
        assert "closed" in state_text
        assert "open" not in state_text


class TestLabelOps:
    @pytest.mark.asyncio
    async def test_add_label(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="", labels=["kind:bug"],
        )
        await adapter.add_label(issue.ref, "priority:high")
        labels_text = (docs_repo / "issues" / "1" / "labels.txt").read_text()
        assert "priority:high" in labels_text
        assert "kind:bug" in labels_text  # original preserved

    @pytest.mark.asyncio
    async def test_remove_label(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="",
            labels=["kind:bug", "area:mcp"],
        )
        await adapter.remove_label(issue.ref, "area:mcp")
        labels_text = (docs_repo / "issues" / "1" / "labels.txt").read_text()
        assert "area:mcp" not in labels_text
        assert "kind:bug" in labels_text

    @pytest.mark.asyncio
    async def test_ensure_label_returns_synthetic_id(self, adapter):
        result = await adapter.ensure_label(
            owner="o", repo="r", name="kind:bug",
        )
        assert result.startswith("local-label://")


class TestSearchAndList:
    @pytest.mark.asyncio
    async def test_list_open_issues(self, adapter):
        for i in range(3):
            await adapter.create_issue(
                owner="o", repo="r", title=f"issue {i}", body="",
                labels=["kind:bug"],
            )
        # Close one so it's no longer open.
        i2 = await adapter.get_issue("o", "r", 2)
        await adapter.close_issue(i2.ref)

        open_issues = await adapter.list_open_issues(owner="o", repo="r")
        nums = sorted(i.ref.number for i in open_issues)
        assert nums == [1, 3]

    @pytest.mark.asyncio
    async def test_search_by_label(self, adapter):
        await adapter.create_issue(
            owner="o", repo="r", title="bug-1", body="", labels=["kind:bug"],
        )
        await adapter.create_issue(
            owner="o", repo="r", title="feat-1", body="", labels=["kind:feature"],
        )
        result = await adapter.search_issues(
            owner="o", repo="r", labels=["kind:bug"],
        )
        # #274 Phase C4 — search_issues returns SearchResult.
        assert len(result.results) == 1
        assert result.results[0].title == "bug-1"
        assert result.total_count == 1

    @pytest.mark.asyncio
    async def test_search_by_query(self, adapter):
        await adapter.create_issue(
            owner="o", repo="r", title="alpha", body="x", labels=["kind:bug"],
        )
        await adapter.create_issue(
            owner="o", repo="r", title="beta", body="x", labels=["kind:bug"],
        )
        result = await adapter.search_issues(
            owner="o", repo="r", query="alpha",
        )
        assert len(result.results) == 1
        assert result.results[0].title == "alpha"
        assert result.query == "alpha"


# ---------------------------------------------------------------------------
# Discussion operations
# ---------------------------------------------------------------------------

class TestDiscussions:
    @pytest.mark.asyncio
    async def test_create_discussion_with_category(self, adapter, docs_repo):
        d = await adapter.create_discussion(
            owner="o", repo="r",
            title="design discussion",
            body="markdown",
            category="Architecture",
        )
        assert d.category == "Architecture"
        labels_text = (docs_repo / "discussions" / "1" / "labels.txt").read_text()
        assert "kind:discussion" in labels_text
        assert "category:architecture" in labels_text

    @pytest.mark.asyncio
    async def test_get_discussion_round_trip(self, adapter):
        created = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b", category="Ideas",
        )
        fetched = await adapter.get_discussion("o", "r", created.ref.number)
        assert fetched.title == "t"
        assert fetched.category == "Ideas"

    @pytest.mark.asyncio
    async def test_mark_decided(self, adapter, docs_repo):
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b", category="Architecture",
        )
        await adapter.mark_decided(d.ref)
        state_text = (docs_repo / "discussions" / "1" / "state.txt").read_text()
        assert "decided" in state_text
        assert "open" in state_text  # multi-dim — both axes present

        # Re-read; decided flag should be set.
        fetched = await adapter.get_discussion("o", "r", 1)
        assert fetched.decided is True

    @pytest.mark.asyncio
    async def test_mark_discussion_decided_state_only(
        self, adapter, docs_repo,
    ):
        """(#486) Combined Protocol method without a comment_ref —
        flips state.txt to add 'decided' (same as mark_decided)."""
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        await adapter.mark_discussion_decided(d.ref, None)
        state_text = (docs_repo / "discussions" / "1" / "state.txt").read_text()
        assert "decided" in state_text

    @pytest.mark.asyncio
    async def test_mark_discussion_decided_with_comment_writes_marker(
        self, adapter, docs_repo,
    ):
        """(#486) Combined Protocol method with a comment_ref writes
        a sibling .meta.json file alongside the comment markdown
        carrying ``{"answer": true, "marked_at": ...}``. Pre-#486 the
        canonical store had no per-comment answer marker; the
        marker only ever landed on GitHub via mark_answer."""
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        # Append a comment so a canonical comment file exists.
        comment = await adapter.append_comment(d.ref, "decision body")
        await adapter.mark_discussion_decided(d.ref, comment.ref)

        # state.txt flipped.
        state_text = (docs_repo / "discussions" / "1" / "state.txt").read_text()
        assert "decided" in state_text

        # Sibling marker landed next to the comment file.
        from pathlib import Path
        comment_path = docs_repo / comment.ref.native_id
        assert comment_path.exists()
        marker_path = Path(
            str(comment_path) + ".meta.json"
        )
        assert marker_path.exists()
        import json as _json
        marker = _json.loads(marker_path.read_text(encoding="utf-8"))
        assert marker["answer"] is True
        assert "marked_at" in marker

    @pytest.mark.asyncio
    async def test_mark_discussion_decided_with_missing_comment_skips_marker(
        self, adapter, docs_repo,
    ):
        """(#486) When the comment_ref's path doesn't exist on disk
        (e.g. caller passed a GitHub node ID by mistake, or the
        canonical comment was never recorded), the marker write is
        silently skipped. The state flip still lands — operator can
        backfill the marker manually if needed."""
        from forge_manager_mcp.adapters.types import ArtifactRef

        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        bogus_comment_ref = ArtifactRef(
            platform_id="local",
            native_id="discussions/1/comments/never-existed.md",
            kind="comment",
            owner="o", repo="r", number=None,
        )
        # Doesn't raise — silent skip on missing comment file.
        await adapter.mark_discussion_decided(d.ref, bogus_comment_ref)

        # state.txt still flipped.
        state_text = (docs_repo / "discussions" / "1" / "state.txt").read_text()
        assert "decided" in state_text

        # No marker file was created for the missing comment.
        marker_path = (
            docs_repo / "discussions" / "1" / "comments"
            / "never-existed.md.meta.json"
        )
        assert not marker_path.exists()


# ---------------------------------------------------------------------------
# (3.16.0 D4 / RFC #506 G3) update_discussion_meta — generic field-bag
# ---------------------------------------------------------------------------


class TestUpdateDiscussionMeta:
    @pytest.mark.asyncio
    async def test_update_discussion_meta_title(self, adapter, docs_repo):
        """G1 for discussions: title mutation."""
        d = await adapter.create_discussion(
            owner="o", repo="r", title="Old", body="b",
            category="Architecture",
        )
        await adapter.update_discussion_meta(d.ref, title="New")
        assert (docs_repo / "discussions" / "1" / "title.md").read_text() == "New\n"

    @pytest.mark.asyncio
    async def test_update_discussion_meta_anchored_milestone(
        self, adapter, docs_repo,
    ):
        """G3 closure — anchored_milestone is the originally-named
        Discussion-meta gap (per 3.10.0 D6.2 stale_milestone_plan_gap
        detector that consumes the field)."""
        import json
        d = await adapter.create_discussion(
            owner="o", repo="r", title="3.16.0 plan", body="b",
            category="Architecture",
        )
        await adapter.update_discussion_meta(
            d.ref, anchored_milestone="3.16.0",
        )
        meta = json.loads(
            (docs_repo / "discussions" / "1" / "meta.json").read_text(),
        )
        assert meta["anchored_milestone"] == "3.16.0"

    @pytest.mark.asyncio
    async def test_update_discussion_meta_anchored_milestone_list(
        self, adapter,
    ):
        """3.10.0 D6.2 OQ2 accepts list-of-versions too — multi-anchor
        case where one plan-Discussion spans multiple milestones."""
        d = await adapter.create_discussion(
            owner="o", repo="r", title="multi", body="b",
            category="Architecture",
        )
        await adapter.update_discussion_meta(
            d.ref, anchored_milestone=["3.16.0", "3.17.0"],
        )
        import json
        meta_file = adapter._artifact_dir_from_ref(d.ref) / "meta.json"
        meta = json.loads(meta_file.read_text())
        assert meta["anchored_milestone"] == ["3.16.0", "3.17.0"]

    @pytest.mark.asyncio
    async def test_update_discussion_meta_category_change(self, adapter):
        import json
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Ideas",
        )
        await adapter.update_discussion_meta(d.ref, category="Architecture")
        meta_file = adapter._artifact_dir_from_ref(d.ref) / "meta.json"
        meta = json.loads(meta_file.read_text())
        assert meta["category"] == "Architecture"

    @pytest.mark.asyncio
    async def test_update_discussion_meta_rejects_unknown_field(self, adapter):
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        from forge_manager_mcp.adapters.errors import ForgeError
        with pytest.raises(ForgeError, match="unknown field"):
            await adapter.update_discussion_meta(d.ref, garbage="x")

    @pytest.mark.asyncio
    async def test_update_discussion_meta_missing_dir_raises(self, adapter):
        from forge_manager_mcp.adapters.types import ArtifactRef
        bogus = ArtifactRef(
            platform_id="local", native_id="discussions/9999",
            kind="discussion", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.update_discussion_meta(bogus, title="X")

    @pytest.mark.asyncio
    async def test_update_discussion_meta_multi_field_atomic(
        self, adapter, docs_repo,
    ):
        import json
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        await adapter.update_discussion_meta(
            d.ref,
            title="Renamed", body="Rebodied",
            anchored_milestone="3.16.0",
        )
        dd = docs_repo / "discussions" / "1"
        assert dd.joinpath("title.md").read_text() == "Renamed\n"
        assert dd.joinpath("body.md").read_text() == "Rebodied"
        meta = json.loads(dd.joinpath("meta.json").read_text())
        assert meta["anchored_milestone"] == "3.16.0"

    @pytest.mark.asyncio
    async def test_update_discussion_meta_appends_history(
        self, adapter, docs_repo,
    ):
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b",
            category="Architecture",
        )
        await adapter.update_discussion_meta(d.ref, title="X")
        history_dir = docs_repo / "discussions" / "1" / "history"
        entries = list(history_dir.iterdir()) if history_dir.exists() else []
        assert len(entries) >= 1
        import json
        last = sorted(entries)[-1]
        rec = json.loads(last.read_text())
        assert rec["operation"] == "update_meta"


# ---------------------------------------------------------------------------
# Comment operations
# ---------------------------------------------------------------------------

class TestComments:
    @pytest.mark.asyncio
    async def test_append_comment_to_issue(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        comment = await adapter.append_comment(issue.ref, "Hello!")
        assert comment.body == "Hello!"
        comments_dir = docs_repo / "issues" / "1" / "comments"
        assert comments_dir.exists()
        files = list(comments_dir.iterdir())
        assert len(files) == 1
        assert files[0].read_text() == "Hello!"

    @pytest.mark.asyncio
    async def test_append_to_unknown_target_goes_to_orphan(self, adapter, docs_repo):
        # Synthetic ref to nonexistent target.
        ghost_ref = ArtifactRef(
            platform_id="github",
            native_id="I_kwDObogus",
            kind="issue", owner="o", repo="r", number=999,
        )
        comment = await adapter.append_comment(ghost_ref, "orphan!")
        orphan_dir = docs_repo / "_orphan-comments"
        assert orphan_dir.exists()
        files = list(orphan_dir.iterdir())
        assert len(files) == 1
        assert files[0].read_text() == "orphan!"

    @pytest.mark.asyncio
    async def test_list_comments_chronological(self, adapter):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        # Two appends at different times.
        await adapter.append_comment(issue.ref, "first")
        await adapter.append_comment(issue.ref, "second")

        comments = await adapter.list_comments(issue.ref)
        assert len(comments) == 2
        bodies = [c.body for c in comments]
        assert bodies == ["first", "second"]


# ---------------------------------------------------------------------------
# Misc / health
# ---------------------------------------------------------------------------

class TestMiscOps:
    @pytest.mark.asyncio
    async def test_probe_returns_true(self, adapter):
        assert await adapter.probe() is True

    @pytest.mark.asyncio
    async def test_probe_after_dir_removed_returns_false(self, tmp_path: Path):
        a = LocalStoreAdapter(docs_repo_path=tmp_path / "ghost")
        assert await a.probe() is False

    @pytest.mark.asyncio
    async def test_compute_drift_clean(self, adapter):
        report = await adapter.compute_drift({})
        assert report.is_clean is True
        assert report.platform_id == "local"

    @pytest.mark.asyncio
    async def test_get_repo_node_id_synthetic(self, adapter):
        node_id = await adapter.get_repo_node_id("o", "r")
        assert node_id == "local://o/r"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_public_when_path_exists(self, adapter):
        # PAR-3: LocalStore reports PUBLIC by convention since
        # filesystem permissions, not a visibility flag, gate access.
        assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_none_when_path_missing(self, tmp_path: Path):
        a = LocalStoreAdapter(docs_repo_path=tmp_path / "ghost")
        assert await a.get_repo_visibility("o", "r") is None

    @pytest.mark.asyncio
    async def test_create_release_writes_file(self, adapter, docs_repo):
        rel = await adapter.create_release(
            owner="o", repo="r", tag="v3.0.0", name="3.0.0",
            body="release notes", prerelease=False,
        )
        assert rel.tag == "v3.0.0"
        rel_file = docs_repo / "releases" / "v3.0.0.md"
        assert rel_file.exists()
        assert "release notes" in rel_file.read_text()

    @pytest.mark.asyncio
    async def test_create_release_persists_prerelease_and_created_at(
        self, adapter, docs_repo,
    ):
        """PAR-2: prerelease + created_at land in YAML frontmatter so a
        future round-trip read can recover them. Pre-fix the file body
        was ``# {name}\\n{body}`` only — both fields were lost on disk."""
        rel = await adapter.create_release(
            owner="o", repo="r", tag="v3.0.1a1",
            name="3.0.1 alpha 1", body="alpha notes",
            prerelease=True,
        )
        rel_file = docs_repo / "releases" / "v3.0.1a1.md"
        text = rel_file.read_text(encoding="utf-8")
        # Frontmatter at the top of the file.
        assert text.startswith("---\n")
        # Both lossy-pre-fix fields are now persisted.
        assert "prerelease: true" in text
        assert "tag: v3.0.1a1" in text
        # created_at frontmatter matches the returned Release.
        assert f"created_at: {rel.created_at.isoformat()}" in text
        # Existing body behaviour preserved (H1 heading + body content).
        assert "# 3.0.1 alpha 1" in text
        assert "alpha notes" in text

    @pytest.mark.asyncio
    async def test_create_release_prerelease_false_round_trips(
        self, adapter, docs_repo,
    ):
        """The non-prerelease default also persists explicitly so
        ``prerelease: false`` is grep-able rather than absent."""
        await adapter.create_release(
            owner="o", repo="r", tag="v3.0.0", name="3.0.0",
            body="ga notes", prerelease=False,
        )
        rel_file = docs_repo / "releases" / "v3.0.0.md"
        assert "prerelease: false" in rel_file.read_text()

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_content_when_present(
        self, adapter, docs_repo,
    ):
        (docs_repo / "README.md").write_text("hello world")
        content = await adapter.fetch_file_content(
            owner="o", repo="r", path="README.md",
        )
        assert content == "hello world"

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_none_when_missing(self, adapter):
        content = await adapter.fetch_file_content(
            owner="o", repo="r", path="does-not-exist.md",
        )
        assert content is None


class TestSessionEvents:
    """Canonical-side session-lock surface — groundwork for the
    open_session handler fix the GitHub-down bug calls for."""

    def test_has_session_event_surface_classvar_true(self):
        assert LocalStoreAdapter.has_session_event_surface is True

    @pytest.mark.asyncio
    async def test_record_session_event_writes_json(
        self, adapter, docs_repo: Path,
    ):
        evt = await adapter.record_session_event(
            session_id="sess-abc", event="opened", body="boot",
        )
        assert evt.session_id == "sess-abc"
        assert evt.event == "opened"
        assert evt.body == "boot"
        sessions_dir = docs_repo / "sessions" / "sess-abc"
        assert sessions_dir.is_dir()
        files = list(sessions_dir.iterdir())
        assert len(files) == 1
        payload = json.loads(files[0].read_text(encoding="utf-8"))
        assert payload["session_id"] == "sess-abc"
        assert payload["event"] == "opened"
        assert payload["body"] == "boot"

    @pytest.mark.asyncio
    async def test_record_session_event_rejects_empty_session_id(self, adapter):
        with pytest.raises(ForgeError, match="session_id"):
            await adapter.record_session_event(
                session_id="  ", event="opened",
            )

    @pytest.mark.asyncio
    async def test_record_session_event_rejects_empty_event(self, adapter):
        with pytest.raises(ForgeError, match="event"):
            await adapter.record_session_event(
                session_id="sess", event="",
            )

    @pytest.mark.asyncio
    async def test_read_session_events_empty_when_no_history(self, adapter):
        events = await adapter.read_session_events()
        assert events == []

    @pytest.mark.asyncio
    async def test_read_session_events_orders_oldest_first(self, adapter):
        # Two events on one session, then a third on a different session.
        await adapter.record_session_event(session_id="s1", event="opened")
        await adapter.record_session_event(session_id="s1", event="closed")
        await adapter.record_session_event(session_id="s2", event="opened")
        events = await adapter.read_session_events()
        assert len(events) == 3
        # Oldest-first.
        timestamps = [e.timestamp for e in events]
        assert timestamps == sorted(timestamps)
        # All three sessions visible.
        kinds = [(e.session_id, e.event) for e in events]
        assert ("s1", "opened") in kinds
        assert ("s1", "closed") in kinds
        assert ("s2", "opened") in kinds

    @pytest.mark.asyncio
    async def test_read_session_events_last_n_clamps(self, adapter):
        for i in range(5):
            await adapter.record_session_event(
                session_id=f"sess-{i}", event="opened",
            )
        events = await adapter.read_session_events(last_n=2)
        assert len(events) == 2
        # The two most-recent.
        assert events[0].session_id == "sess-3"
        assert events[1].session_id == "sess-4"

    @pytest.mark.asyncio
    async def test_read_session_events_skips_malformed_files(
        self, adapter, docs_repo: Path,
    ):
        await adapter.record_session_event(session_id="ok", event="opened")
        # Drop a malformed peer next to the good entry.
        malformed_dir = docs_repo / "sessions" / "broken"
        malformed_dir.mkdir(parents=True, exist_ok=True)
        (malformed_dir / "garbage.json").write_text("not-json", encoding="utf-8")
        # Same dir as the good entry: an entry with valid JSON but no timestamp.
        (docs_repo / "sessions" / "ok" / "no-ts.json").write_text(
            '{"session_id":"ok","event":"opened"}', encoding="utf-8",
        )
        events = await adapter.read_session_events()
        # Only the well-formed entry survives.
        assert len(events) == 1
        assert events[0].session_id == "ok"


class TestBootstrapProject:
    """Multi-platform scaffold C1 — LocalStoreAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert LocalStoreAdapter.has_scaffold is True

    @pytest.mark.asyncio
    async def test_bootstrap_creates_dir_git_readme_placeholders(
        self, tmp_path: Path,
    ):
        target = tmp_path / "fresh-docs"
        a = LocalStoreAdapter(docs_repo_path=target)
        result = await a.bootstrap_project(
            owner="acme", project_name="fresh", description="x",
        )
        assert result.platform_id == "local"
        assert result.phase == "complete"
        assert result.manual_steps == []
        assert target.is_dir()
        assert (target / ".git").is_dir()
        assert (target / "README.md").exists()
        assert "fresh-docs" in (target / "README.md").read_text(encoding="utf-8")
        for placeholder in ("issues", "discussions", "milestones"):
            assert (target / placeholder).is_dir()
        # artifacts dict carries per-step action codes for diagnostics.
        assert result.artifacts["docs_repo_path"] == str(target)
        assert result.artifacts["dir"] == "created"
        assert result.artifacts["readme"] == "written"
        assert result.artifacts["git"] == "init"
        assert "issues" in result.artifacts["placeholders"]

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent(self, tmp_path: Path):
        """Re-running bootstrap on an already-bootstrapped repo no-ops
        each step. Action codes flip from ``created`` / ``written`` /
        ``init`` to ``existed``."""
        target = tmp_path / "twice"
        a = LocalStoreAdapter(docs_repo_path=target)
        first = await a.bootstrap_project(
            owner="o", project_name="twice", description="",
        )
        assert first.artifacts["dir"] == "created"
        second = await a.bootstrap_project(
            owner="o", project_name="twice", description="",
        )
        assert second.artifacts["dir"] == "existed"
        assert second.artifacts["readme"] == "existed"
        assert second.artifacts["git"] == "existed"

    @pytest.mark.asyncio
    async def test_bootstrap_existing_state_accepted(self, tmp_path: Path):
        """``existing_state`` is for Protocol parity; LocalStore ignores
        it. Passing a populated dict still completes successfully."""
        target = tmp_path / "with-state"
        a = LocalStoreAdapter(docs_repo_path=target)
        result = await a.bootstrap_project(
            owner="o", project_name="with-state", description="",
            existing_state={"github": {"repo_node_id": "R_xxx"}},
        )
        assert result.phase == "complete"


class TestMilestones:
    """find_milestone parity (PAR-1): integer lookups raise rather than
    silently return None — LocalStore has no native integer-ID concept."""

    @pytest.mark.asyncio
    async def test_find_by_title_returns_milestone(self, adapter, docs_repo):
        ms_dir = docs_repo / "milestones"
        ms_dir.mkdir(parents=True, exist_ok=True)
        (ms_dir / "3.0.1.md").write_text("# 3.0.1\nMilestone notes.\n")

        result = await adapter.find_milestone("o", "r", "3.0.1")
        assert result is not None
        assert result.title == "3.0.1"

    @pytest.mark.asyncio
    async def test_find_by_title_returns_none_when_absent(self, adapter):
        result = await adapter.find_milestone("o", "r", "no-such-milestone")
        assert result is None

    @pytest.mark.asyncio
    async def test_find_by_int_raises(self, adapter):
        """PAR-1: integer-ID lookups must raise rather than silently
        return None. The error message names the limitation and
        suggests the workaround."""
        from forge_manager_mcp.adapters import errors as _errors

        with pytest.raises(_errors.ForgeError) as exc_info:
            await adapter.find_milestone("o", "r", 42)
        # Message names the limitation explicitly.
        assert "find_milestone(int)" in str(exc_info.value)
        assert "title" in str(exc_info.value)


class TestMilestoneArtifacts:
    """LocalStore impl of #397 / 3.11.0 D1.a milestone-as-compound-doc surface.

    Covers create / read / state-transition / meta-update / list-versions.
    Coexists with legacy flat-file ``milestones/<title>.md`` schema —
    those keep working through ``list_milestones`` / ``find_milestone``;
    the new compound-doc methods write directories instead.
    """

    def test_has_milestone_artifacts_classvar_true(self):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        assert LocalStoreAdapter.has_milestone_artifacts is True

    @pytest.mark.asyncio
    async def test_create_milestone_writes_compound_doc(self, adapter, docs_repo):
        result = await adapter.create_milestone(
            version="3.11.0",
            tier="minor",
            plan_discussion=18,
            body="UI tightening iteration 1",
        )
        ms_dir = docs_repo / "milestones" / "3.11.0"
        assert ms_dir.is_dir()
        assert (ms_dir / "title.md").read_text().strip() == "3.11.0"
        assert "UI tightening" in (ms_dir / "body.md").read_text()
        assert (ms_dir / "state.txt").read_text().strip() == "planned"
        labels = (ms_dir / "labels.txt").read_text()
        assert "kind:milestone" in labels
        assert "tier:minor" in labels
        meta = json.loads((ms_dir / "meta.json").read_text())
        assert meta["version"] == "3.11.0"
        assert meta["tier"] == "minor"
        assert meta["hotfix"] is False
        assert meta["plan_discussion"] == 18
        assert meta["cut_at"] is None
        assert meta["tag_sha"] is None
        # Returned MilestoneArtifact mirrors the persisted state.
        assert result.version == "3.11.0"
        assert result.state == "planned"
        assert result.plan_discussion == 18

    @pytest.mark.asyncio
    async def test_create_milestone_with_explicit_title(self, adapter, docs_repo):
        result = await adapter.create_milestone(
            version="3.11.0",
            tier="minor",
            title="3.11.0 — UI tightening 1",
        )
        title_text = (docs_repo / "milestones" / "3.11.0" / "title.md").read_text().strip()
        assert title_text == "3.11.0 — UI tightening 1"
        assert result.title == "3.11.0 — UI tightening 1"

    @pytest.mark.asyncio
    async def test_create_milestone_hotfix_writes_label(self, adapter, docs_repo):
        await adapter.create_milestone(
            version="3.10.1", tier="patch", hotfix=True,
        )
        labels = (docs_repo / "milestones" / "3.10.1" / "labels.txt").read_text()
        assert "hotfix:true" in labels

    @pytest.mark.asyncio
    async def test_create_milestone_duplicate_raises(self, adapter):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        # (#470 sub-fix 2a) Specifically raises LocalStoreAlready
        # ExistsError — the dedicated idempotency class that does NOT
        # classify as forge-unavailable. Still a ForgeError subclass
        # so legacy ``except ForgeError`` clauses keep working.
        with pytest.raises(LocalStoreAlreadyExistsError) as exc_info:
            await adapter.create_milestone(version="3.11.0", tier="minor")
        assert "already exists" in str(exc_info.value)
        assert isinstance(exc_info.value, ForgeError)
        assert exc_info.value.artifact_kind == "milestone"
        assert exc_info.value.artifact_id == "3.11.0"
        assert exc_info.value.status_code is None

    @pytest.mark.asyncio
    async def test_create_milestone_with_multi_anchor_plan_list(self, adapter):
        """#390 D6.2 OQ2 b symmetric shape — plan_discussion can be a
        list when multiple plans cross-anchor."""
        result = await adapter.create_milestone(
            version="3.11.0",
            tier="minor",
            plan_discussion=[18, 19],
        )
        assert result.plan_discussion == [18, 19]

    @pytest.mark.asyncio
    async def test_get_milestone_body(self, adapter):
        await adapter.create_milestone(
            version="3.11.0", tier="minor", body="narrative content here",
        )
        body = await adapter.get_milestone_body("3.11.0")
        assert body == "narrative content here"

    @pytest.mark.asyncio
    async def test_get_milestone_body_missing_raises(self, adapter):
        with pytest.raises(ForgeError) as exc_info:
            await adapter.get_milestone_body("99.99.99")
        assert "not found" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_update_milestone_state_planned_to_active(self, adapter, docs_repo):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        result = await adapter.update_milestone_state("3.11.0", "active")
        state_text = (docs_repo / "milestones" / "3.11.0" / "state.txt").read_text().strip()
        assert state_text == "active"
        assert result.state == "active"
        # cut_at remains None on non-close transitions
        assert result.cut_at is None

    @pytest.mark.asyncio
    async def test_update_milestone_state_close_stamps_cut_at(self, adapter, docs_repo):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        await adapter.update_milestone_state("3.11.0", "active")
        result = await adapter.update_milestone_state("3.11.0", "closed")
        assert result.state == "closed"
        # cut_at was None pre-close; close-transition stamped it.
        assert result.cut_at is not None
        meta = json.loads(
            (docs_repo / "milestones" / "3.11.0" / "meta.json").read_text(),
        )
        assert meta["cut_at"] is not None

    @pytest.mark.asyncio
    async def test_update_milestone_meta_plan_discussion(self, adapter, docs_repo):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        # Plan resolved later via prose-heuristic — caller pins the link.
        result = await adapter.update_milestone_meta(
            "3.11.0", plan_discussion=18,
        )
        assert result.plan_discussion == 18
        meta = json.loads(
            (docs_repo / "milestones" / "3.11.0" / "meta.json").read_text(),
        )
        assert meta["plan_discussion"] == 18

    @pytest.mark.asyncio
    async def test_update_milestone_meta_unknown_field_raises(self, adapter):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        with pytest.raises(ForgeError) as exc_info:
            await adapter.update_milestone_meta(
                "3.11.0", bogus_field="value",
            )
        assert "unknown field" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_update_milestone_meta_tier_change_updates_labels(
        self, adapter, docs_repo,
    ):
        await adapter.create_milestone(version="3.11.0", tier="minor")
        # Promote to major — labels.txt should reflect.
        await adapter.update_milestone_meta("3.11.0", tier="major")
        labels = (docs_repo / "milestones" / "3.11.0" / "labels.txt").read_text()
        assert "tier:major" in labels
        assert "tier:minor" not in labels

    @pytest.mark.asyncio
    async def test_update_milestone_meta_clear_field(self, adapter, docs_repo):
        await adapter.create_milestone(
            version="3.11.0", tier="minor", plan_discussion=18,
        )
        # Explicit None clears the field.
        result = await adapter.update_milestone_meta(
            "3.11.0", plan_discussion=None,
        )
        assert result.plan_discussion is None

    @pytest.mark.asyncio
    async def test_update_milestone_meta_omitted_field_unchanged(
        self, adapter, docs_repo,
    ):
        await adapter.create_milestone(
            version="3.11.0", tier="minor", plan_discussion=18,
        )
        # Updating only tag_sha leaves plan_discussion alone.
        result = await adapter.update_milestone_meta(
            "3.11.0", tag_sha="abc1234",
        )
        assert result.plan_discussion == 18
        assert result.tag_sha == "abc1234"

    @pytest.mark.asyncio
    async def test_update_milestone_meta_missing_raises(self, adapter):
        with pytest.raises(ForgeError) as exc_info:
            await adapter.update_milestone_meta("99.99.99", tag_sha="x")
        assert "not found" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions_empty(self, adapter):
        # Greenfield — no milestones yet.
        result = await adapter.list_all_milestone_versions()
        assert result == []

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions_semver_descending(self, adapter):
        await adapter.create_milestone(version="3.10.0", tier="minor")
        await adapter.create_milestone(version="3.11.0", tier="minor")
        await adapter.create_milestone(version="3.10.1", tier="patch", hotfix=True)
        await adapter.create_milestone(version="3.9.0", tier="minor")

        result = await adapter.list_all_milestone_versions()
        # Semver-descending: 3.11.0 > 3.10.1 > 3.10.0 > 3.9.0.
        assert result == ["3.11.0", "3.10.1", "3.10.0", "3.9.0"]

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions_ignores_flat_files(
        self, adapter, docs_repo,
    ):
        """Legacy flat-file `milestones/<title>.md` should not appear
        in the compound-doc version list. Only directories with a
        meta.json count."""
        await adapter.create_milestone(version="3.11.0", tier="minor")
        # Sprinkle a legacy flat file alongside.
        (docs_repo / "milestones" / "3.0.1.md").write_text("# 3.0.1\n")
        result = await adapter.list_all_milestone_versions()
        assert result == ["3.11.0"]
        assert "3.0.1.md" not in result
        assert "3.0.1" not in result


class TestGapArtifacts:
    """LocalStore impl of #405 / 3.11.0 D1.b gaps-as-compound-doc surface.

    Detector-driven upsert + operator-driven state transitions.
    Single-axis four-state lifecycle (triage / accepted / filed /
    ignored) with re-detection rules per #405 S2.
    """

    def test_has_gap_artifacts_classvar_true(self):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        assert LocalStoreAdapter.has_gap_artifacts is True

    def _mk_finding(self, *, path="src/foo.py", line=42,
                   severity="warn", message="missing tag"):
        from forge_manager_mcp.adapters.types import GapFinding
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        return GapFinding(
            path=path, line=line, severity=severity, message=message,
            first_seen_at=now, last_seen_at=now,
        )

    @pytest.mark.asyncio
    async def test_upsert_gap_creates_new_compound_doc(
        self, adapter, docs_repo,
    ):
        finding = self._mk_finding()
        result = await adapter.upsert_gap(
            category="test_purity_tagging",
            tier="mechanical",
            findings=[finding],
        )
        gap_dir = docs_repo / "gaps" / "test_purity_tagging"
        assert gap_dir.is_dir()
        assert (gap_dir / "title.md").read_text().strip() == "test_purity_tagging"
        assert (gap_dir / "state.txt").read_text().strip() == "triage"
        labels = (gap_dir / "labels.txt").read_text()
        assert "kind:gap" in labels
        assert "tier:mechanical" in labels
        assert "severity:warn" in labels
        meta = json.loads((gap_dir / "meta.json").read_text())
        assert meta["state"] == "triage"
        assert meta["finding_count"] == 1
        assert meta["state_changed_by"] == "detector"
        # Returned artifact mirrors persisted state.
        assert result.state == "triage"
        assert result.finding_count == 1
        assert result.severity == "warn"

    @pytest.mark.asyncio
    async def test_upsert_gap_severity_rollup_highest_wins(
        self, adapter, docs_repo,
    ):
        warns = self._mk_finding(severity="warn")
        fails = self._mk_finding(severity="fail", path="src/critical.py")
        infos = self._mk_finding(severity="info", path="src/minor.py")
        await adapter.upsert_gap(
            category="capability_gap",
            tier="mechanical",
            findings=[warns, fails, infos],
        )
        labels = (docs_repo / "gaps" / "capability_gap" / "labels.txt").read_text()
        # Highest severity rollup → fail.
        assert "severity:fail" in labels

    @pytest.mark.asyncio
    async def test_upsert_gap_preserves_first_seen_across_runs(
        self, adapter, docs_repo,
    ):
        f = self._mk_finding()
        first = await adapter.upsert_gap(
            category="cat", tier="advisory", findings=[f],
        )
        first_seen = first.findings[0].first_seen_at

        # Second run with same finding — first_seen_at preserved,
        # last_seen_at refreshed.
        import time
        time.sleep(0.01)
        second = await adapter.upsert_gap(
            category="cat", tier="advisory", findings=[f],
        )
        assert second.findings[0].first_seen_at == first_seen
        assert second.findings[0].last_seen_at >= first_seen

    @pytest.mark.asyncio
    async def test_upsert_gap_filed_state_flips_to_triage_on_new_findings(
        self, adapter, docs_repo,
    ):
        """#405 S2 re-detection rule: new findings on previously-filed
        gap re-flip to triage so operator re-decides."""
        # Initial detection.
        await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding()],
        )
        # Operator files for later.
        await adapter.update_gap_state(
            "cat", "filed",
            filed_issue=999, filed_target_milestone="3.12.0",
        )
        # New findings appear — should re-flip to triage.
        new_finding = self._mk_finding(message="brand new finding")
        result = await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding(), new_finding],
        )
        assert result.state == "triage"
        assert result.state_changed_by == "detector"

    @pytest.mark.asyncio
    async def test_upsert_gap_accepted_state_preserved_on_new_findings(
        self, adapter, docs_repo,
    ):
        """Accepted gaps don't re-flip; operator already committed."""
        await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding()],
        )
        await adapter.update_gap_state(
            "cat", "accepted",
            anchored_milestone="3.11.0", accepted_phase="D2",
        )
        # New findings → state stays accepted.
        result = await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding(), self._mk_finding(message="new")],
        )
        assert result.state == "accepted"
        assert result.anchored_milestone == "3.11.0"

    @pytest.mark.asyncio
    async def test_update_gap_state_to_accepted_records_milestone_and_phase(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding()],
        )
        result = await adapter.update_gap_state(
            "cat", "accepted",
            changed_by="operator",
            note="addressing in iteration 1",
            anchored_milestone="3.11.0",
            accepted_phase="D2.a",
        )
        assert result.state == "accepted"
        assert result.anchored_milestone == "3.11.0"
        assert result.accepted_phase == "D2.a"
        assert result.state_changed_by == "operator"
        assert result.state_change_note == "addressing in iteration 1"

    @pytest.mark.asyncio
    async def test_update_gap_state_to_filed_records_issue_and_target(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding()],
        )
        result = await adapter.update_gap_state(
            "cat", "filed",
            changed_by="operator",
            filed_issue=777,
            filed_target_milestone="3.12.0",
        )
        assert result.state == "filed"
        assert result.filed_issue == 777
        assert result.filed_target_milestone == "3.12.0"

    @pytest.mark.asyncio
    async def test_update_gap_state_missing_raises(self, adapter):
        with pytest.raises(ForgeError) as exc_info:
            await adapter.update_gap_state("nonexistent", "ignored")
        assert "not found" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_update_gap_meta_rejects_unknown_field(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="cat", tier="advisory",
            findings=[self._mk_finding()],
        )
        with pytest.raises(ForgeError) as exc_info:
            await adapter.update_gap_meta("cat", bogus_field="x")
        assert "unknown field" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_update_gap_meta_cross_links(self, adapter, docs_repo):
        await adapter.upsert_gap(
            category="cat", tier="advisory",
            findings=[self._mk_finding()],
        )
        result = await adapter.update_gap_meta(
            "cat", cross_links=[100, 200, 300],
        )
        assert result.cross_links == (100, 200, 300)

    @pytest.mark.asyncio
    async def test_get_gap_body_returns_findings_table(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="cat", tier="mechanical",
            findings=[self._mk_finding(message="test thing")],
        )
        body = await adapter.get_gap_body("cat")
        # Body is a markdown table; finding row appears.
        assert "test thing" in body
        assert "| Severity |" in body

    @pytest.mark.asyncio
    async def test_get_gap_body_empty_findings_renders_clean_message(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="cat", tier="mechanical", findings=[],
        )
        body = await adapter.get_gap_body("cat")
        assert "No active findings" in body

    @pytest.mark.asyncio
    async def test_list_gap_categories_empty(self, adapter):
        result = await adapter.list_gap_categories()
        assert result == []

    @pytest.mark.asyncio
    async def test_list_gap_categories_returns_sorted(
        self, adapter, docs_repo,
    ):
        await adapter.upsert_gap(
            category="zebra", tier="advisory", findings=[],
        )
        await adapter.upsert_gap(
            category="alpha", tier="mechanical", findings=[],
        )
        await adapter.upsert_gap(
            category="middle", tier="advisory", findings=[],
        )
        result = await adapter.list_gap_categories()
        assert result == ["alpha", "middle", "zebra"]


# (#428 / 3.12.0 D-Coverage drain) Per-method tests for the smaller
# helpers that the conformance suite doesn't directly exercise.


class TestListAllIssueNumbers:
    @pytest.mark.asyncio
    async def test_returns_empty_when_no_issues_dir(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        assert await adapter.list_all_issue_numbers("o", "r") == []

    @pytest.mark.asyncio
    async def test_returns_sorted_numeric_dirs(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        issues = tmp_path / "issues"
        for n in ("10", "2", "100", "1"):
            (issues / n).mkdir(parents=True)
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_all_issue_numbers("o", "r")
        assert result == [1, 2, 10, 100]

    @pytest.mark.asyncio
    async def test_skips_non_numeric_dirs(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        issues = tmp_path / "issues"
        (issues / "5").mkdir(parents=True)
        (issues / "_drafts").mkdir()
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_all_issue_numbers("o", "r")
        assert result == [5]

    @pytest.mark.asyncio
    async def test_skips_files_in_issues_root(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        issues = tmp_path / "issues"
        issues.mkdir()
        (issues / "stray.txt").write_text("stray")
        (issues / "1").mkdir()
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_all_issue_numbers("o", "r")
        assert result == [1]


class TestListAllDiscussionNumbers:
    @pytest.mark.asyncio
    async def test_returns_empty_when_no_discussions_dir(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        assert await adapter.list_all_discussion_numbers("o", "r") == []

    @pytest.mark.asyncio
    async def test_returns_sorted_numeric_dirs(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        d_dir = tmp_path / "discussions"
        for n in ("7", "1", "20"):
            (d_dir / n).mkdir(parents=True)
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_all_discussion_numbers("o", "r")
        assert result == [1, 7, 20]

    @pytest.mark.asyncio
    async def test_skips_non_numeric_and_files(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        d_dir = tmp_path / "discussions"
        d_dir.mkdir()
        (d_dir / "nonsense").mkdir()
        (d_dir / "stray.md").write_text("x")
        (d_dir / "3").mkdir()
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_all_discussion_numbers("o", "r")
        assert result == [3]


class TestGetFileContent:
    @pytest.mark.asyncio
    async def test_missing_file_returns_none(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.get_file_content(
            "o", "r", "main", "no/such/file.md",
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_directory_path_returns_none(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        (tmp_path / "subdir").mkdir()
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.get_file_content("o", "r", "main", "subdir")
        assert result is None

    @pytest.mark.asyncio
    async def test_reads_utf8_text(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        (tmp_path / "test.md").write_text("hello\nworld\n", encoding="utf-8")
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.get_file_content("o", "r", "main", "test.md")
        assert result == "hello\nworld\n"

    @pytest.mark.asyncio
    async def test_binary_file_returns_none(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        (tmp_path / "binary.dat").write_bytes(b"\xff\xfe\xfd not utf-8")
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.get_file_content(
            "o", "r", "main", "binary.dat",
        )
        # UnicodeDecodeError caught → None.
        assert result is None


class TestListMilestonesLegacyMd:
    """Pre-3.11.0 milestones lived as <docs>/milestones/<X.Y.Z>.md;
    list_milestones still recognizes that legacy shape."""

    @pytest.mark.asyncio
    async def test_returns_empty_when_no_milestones_dir(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_milestones("o", "r")
        assert result == []

    @pytest.mark.asyncio
    async def test_returns_md_entries_as_open_milestones(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        ms = tmp_path / "milestones"
        ms.mkdir()
        (ms / "3.10.0.md").write_text("milestone notes")
        (ms / "3.11.0.md").write_text("milestone notes")
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_milestones("o", "r")
        titles = sorted(m.title for m in result)
        assert "3.10.0" in titles
        assert "3.11.0" in titles
        assert all(m.state == "open" for m in result)

    @pytest.mark.asyncio
    async def test_skips_non_md_files(self, tmp_path):
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        ms = tmp_path / "milestones"
        ms.mkdir()
        (ms / "3.10.0.md").write_text("good")
        (ms / "notes.txt").write_text("ignored")
        adapter = LocalStoreAdapter(docs_repo_path=tmp_path)
        result = await adapter.list_milestones("o", "r")
        titles = sorted(m.title for m in result)
        assert titles == ["3.10.0"]


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Error-path coverage for milestone +
# gap operations.
# ---------------------------------------------------------------------------


class TestMilestoneErrorPaths:
    @pytest.mark.asyncio
    async def test_read_milestone_artifact_missing_raises(self, adapter):
        # _read_milestone_artifact: ms_dir doesn't exist → L317-319
        # ForgeError.
        with pytest.raises(ForgeError, match="milestone"):
            await adapter.get_milestone_body("99.99.99")

    @pytest.mark.asyncio
    async def test_update_milestone_meta_unknown_field_raises(
        self, adapter,
    ):
        # Create a milestone first then call update_milestone_meta with
        # a bad field name → L400-405 raise.
        await adapter.create_milestone(version="1.0.0", tier="minor")
        with pytest.raises(ForgeError, match="unknown"):
            await adapter.update_milestone_meta(
                "1.0.0", definitely_unknown_field="x",
            )

    @pytest.mark.asyncio
    async def test_update_milestone_meta_title_and_body_rewrites(
        self, adapter,
    ):
        # Exercise the title + body file rewrite branches at L407-414.
        await adapter.create_milestone(version="1.0.0", tier="minor")
        await adapter.update_milestone_meta(
            "1.0.0", title="New title", body="New body content",
        )
        ms_dir = adapter._milestone_dir("1.0.0")
        assert (ms_dir / "title.md").read_text().startswith("New title")
        assert "New body content" in (ms_dir / "body.md").read_text()

    @pytest.mark.asyncio
    async def test_update_milestone_meta_cut_at_datetime_serializes(
        self, adapter,
    ):
        # cut_at as datetime → isoformat conversion. L420-422.
        from datetime import datetime, timezone
        await adapter.create_milestone(version="1.0.0", tier="minor")
        cut_at = datetime(2026, 1, 1, tzinfo=timezone.utc)
        await adapter.update_milestone_meta("1.0.0", cut_at=cut_at)
        meta = json.loads(
            (adapter._milestone_dir("1.0.0") / "meta.json").read_text()
        )
        assert "2026-01-01" in meta["cut_at"]

    @pytest.mark.asyncio
    async def test_update_milestone_meta_hotfix_relabels(self, adapter):
        # hotfix=True → labels.txt includes hotfix:true. L426-432.
        await adapter.create_milestone(version="1.0.0", tier="minor")
        await adapter.update_milestone_meta("1.0.0", hotfix=True)
        labels = (
            adapter._milestone_dir("1.0.0") / "labels.txt"
        ).read_text()
        assert "hotfix:true" in labels

    @pytest.mark.asyncio
    async def test_list_milestones_with_unparseable_dirname(self, adapter):
        # Drop an unparseable-named directory under milestones/ → the
        # semver_key fallback at L455-456 keeps the sort working.
        ms_root = adapter._path / "milestones"
        ms_root.mkdir(exist_ok=True)
        (ms_root / "not-a-version").mkdir()
        (ms_root / "not-a-version" / "meta.json").write_text(
            json.dumps({"version": "not-a-version", "tier": "minor"})
        )
        versions = await adapter.list_all_milestone_versions()
        assert "not-a-version" in versions


class TestGapErrorPaths:
    @pytest.mark.asyncio
    async def test_read_gap_meta_oserror_returns_none(
        self, adapter, monkeypatch,
    ):
        # _read_existing_gap_meta: OSError reading meta.json → L506-509
        # returns None.
        from pathlib import Path as _P
        gap_dir = adapter._gap_dir("test_category")
        gap_dir.mkdir(parents=True)
        meta_path = gap_dir / "meta.json"
        meta_path.write_text(json.dumps({"state": "triage"}))
        original = _P.read_text

        def _fail(self, *a, **kw):
            if self == meta_path:
                raise OSError("simulated")
            return original(self, *a, **kw)

        monkeypatch.setattr(_P, "read_text", _fail)
        assert adapter._read_existing_gap_meta(gap_dir) is None

    @pytest.mark.asyncio
    async def test_read_gap_artifact_missing_dir_raises(self, adapter):
        # _read_gap_artifact: gap_dir doesn't exist → L599-603.
        with pytest.raises(ForgeError, match="gap"):
            adapter._read_gap_artifact("nonexistent_category")

    @pytest.mark.asyncio
    async def test_read_gap_artifact_missing_meta_raises(self, adapter):
        # _read_gap_artifact: dir exists but no meta → L604-608.
        gap_dir = adapter._gap_dir("partial_gap")
        gap_dir.mkdir(parents=True)
        # No meta.json.
        with pytest.raises(ForgeError, match="meta"):
            adapter._read_gap_artifact("partial_gap")

    @pytest.mark.asyncio
    async def test_get_gap_body_not_found_raises(self, adapter):
        # get_gap_body: gap_dir doesn't exist → L645-649.
        with pytest.raises(ForgeError, match="not found"):
            await adapter.get_gap_body("nonexistent")

    @pytest.mark.asyncio
    async def test_update_gap_state_not_found_raises(self, adapter):
        # update_gap_state: gap_dir doesn't exist → L664-668.
        with pytest.raises(ForgeError, match="not found"):
            await adapter.update_gap_state("nonexistent", "accepted")

    @pytest.mark.asyncio
    async def test_update_gap_meta_unknown_field_raises(self, adapter):
        # update_gap_meta: unknown field name → L697-703.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import GapFinding
        now = datetime.now(timezone.utc)
        finding = GapFinding(
            path="x.py", line=1, severity="warn", message="m",
            first_seen_at=now, last_seen_at=now,
        )
        await adapter.upsert_gap(
            category="cat1", tier="mechanical",
            findings=[finding], title="t",
        )
        with pytest.raises(ForgeError, match="unknown"):
            await adapter.update_gap_meta("cat1", garbage="x")

    @pytest.mark.asyncio
    async def test_update_gap_meta_title_rewrites_file(self, adapter):
        # update_gap_meta title → file rewritten. L705-708.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import GapFinding
        now = datetime.now(timezone.utc)
        finding = GapFinding(
            path="x.py", line=1, severity="warn", message="m",
            first_seen_at=now, last_seen_at=now,
        )
        await adapter.upsert_gap(
            category="cat2", tier="mechanical",
            findings=[finding], title="initial",
        )
        await adapter.update_gap_meta("cat2", title="renamed")
        title_path = adapter._gap_dir("cat2") / "title.md"
        assert title_path.read_text().startswith("renamed")

    @pytest.mark.asyncio
    async def test_update_gap_meta_cross_links_rewrites_meta(self, adapter):
        # update_gap_meta cross_links → meta updated. L709-710.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import GapFinding
        now = datetime.now(timezone.utc)
        finding = GapFinding(
            path="x.py", line=1, severity="warn", message="m",
            first_seen_at=now, last_seen_at=now,
        )
        await adapter.upsert_gap(
            category="cat3", tier="mechanical",
            findings=[finding], title="t",
        )
        await adapter.update_gap_meta(
            "cat3", cross_links=[1, 2],
        )
        meta = json.loads(
            (adapter._gap_dir("cat3") / "meta.json").read_text()
        )
        assert meta["cross_links"] == [1, 2]


class TestUpdateIssueBodyArtifactRef:
    @pytest.mark.asyncio
    async def test_update_body_invalid_ref_raises(self, adapter):
        # update_issue_body with a ref pointing at a non-existent
        # artifact dir → InvalidArtifactRefError. L838-841.
        ref = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.update_issue_body(ref, "new body")

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_dir_raises(self, adapter):
        # get_issue_body: dir doesn't exist → InvalidArtifactRefError.
        ref = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue_body(ref)


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) More error-path coverage.
# ---------------------------------------------------------------------------


class TestGetIssueBodyMissingFile:
    @pytest.mark.asyncio
    async def test_missing_body_file_returns_empty_string(self, adapter):
        # Issue dir exists but body.md absent → L832-833 returns "".
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="initial", labels=[],
        )
        body_file = adapter._artifact_dir_from_ref(issue.ref) / "body.md"
        if body_file.exists():
            body_file.unlink()
        result = await adapter.get_issue_body(issue.ref)
        assert result == ""


class TestUpdateIssueMilestoneMetaUnparseable:
    @pytest.mark.asyncio
    async def test_meta_json_unparseable_treated_as_empty(self, adapter):
        # update_issue_milestone: meta.json malformed → L871-876
        # except branch sets meta = {}, then proceeds to write.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        meta_file = adapter._artifact_dir_from_ref(issue.ref) / "meta.json"
        meta_file.write_text("{ not json")
        await adapter.update_issue_milestone(issue.ref, "3.12.0")
        meta = json.loads(meta_file.read_text())
        assert meta["milestone"] == "3.12.0"


class TestCloseIssueRefNumberNone:
    @pytest.mark.asyncio
    async def test_ref_with_no_number_parses_from_native_id(self, adapter):
        # close_issue: ref.number is None, native_id = "issues/N" →
        # parse N from native_id. L916-922.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        ref_no_number = ArtifactRef(
            platform_id=issue.ref.platform_id,
            native_id=issue.ref.native_id,
            kind=issue.ref.kind,
            owner=issue.ref.owner, repo=issue.ref.repo,
            number=None,
        )
        result = await adapter.close_issue(ref_no_number)
        # The function returns the closed Issue; verify it succeeded
        # (no error path traversed → number parsed from native_id).
        assert result.ref.native_id == issue.ref.native_id


class TestRemoveLabelEdgeBranches:
    @pytest.mark.asyncio
    async def test_no_labels_file_returns_silently(self, adapter):
        # remove_label: labels.txt absent → L951-952 return.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        labels_file = adapter._artifact_dir_from_ref(issue.ref) / "labels.txt"
        if labels_file.exists():
            labels_file.unlink()
        # Should not raise.
        await adapter.remove_label(issue.ref, "nonexistent")

    @pytest.mark.asyncio
    async def test_label_not_present_no_op(self, adapter):
        # remove_label: label not in existing → L955-957 no-op return.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["bug"],
        )
        await adapter.remove_label(issue.ref, "feature")  # not present
        labels_file = adapter._artifact_dir_from_ref(issue.ref) / "labels.txt"
        assert "bug" in labels_file.read_text()


class TestSearchIssuesUnparseable:
    @pytest.mark.asyncio
    async def test_non_numeric_dir_name_skipped(self, adapter):
        # search_issues: directory name not parseable as int →
        # L993-996 continue.
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        # Stray non-numeric directory.
        (adapter._path / "issues" / "stray").mkdir()
        result = await adapter.search_issues(owner="o", repo="r")
        assert result.total_count >= 1


class TestGetDiscussionNotFound:
    @pytest.mark.asyncio
    async def test_missing_discussion_raises(self, adapter):
        # get_discussion: disc_dir missing → L1083-1085 raise.
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_discussion(owner="o", repo="r", number=9999)


class TestUpdateMilestoneStateMissing:
    @pytest.mark.asyncio
    async def test_missing_milestone_raises(self, adapter):
        # update_milestone_state: ms_dir absent → L363-368 raise.
        with pytest.raises(ForgeError, match="not found"):
            await adapter.update_milestone_state("9.9.9", "active")


class TestSearchIssuesMilestoneFilter:
    @pytest.mark.asyncio
    async def test_milestone_mismatch_skipped(self, adapter):
        # search_issues: issue.milestone != milestone filter → L1005-1006
        # continue.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        await adapter.update_issue_milestone(issue.ref, "1.0.0")
        result = await adapter.search_issues(
            owner="o", repo="r", milestone="2.0.0",
        )
        assert result.total_count == 0


class TestUpdateGapMetaMoreEdgeBranches:
    @pytest.mark.asyncio
    async def test_not_found_raises(self, adapter):
        # update_gap_meta: gap_dir doesn't exist → L692-696 raise.
        with pytest.raises(ForgeError, match="not found"):
            await adapter.update_gap_meta("nonexistent_category")

    @pytest.mark.asyncio
    async def test_state_change_note_updates_meta(self, adapter):
        # update_gap_meta with state_change_note → L711-712 meta update.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import GapFinding
        now = datetime.now(timezone.utc)
        finding = GapFinding(
            path="x.py", line=1, severity="warn", message="m",
            first_seen_at=now, last_seen_at=now,
        )
        await adapter.upsert_gap(
            category="cat-note", tier="mechanical",
            findings=[finding], title="t",
        )
        await adapter.update_gap_meta(
            "cat-note", state_change_note="documenting deferred",
        )
        meta = json.loads(
            (adapter._gap_dir("cat-note") / "meta.json").read_text()
        )
        assert meta["state_change_note"] == "documenting deferred"


class TestUpdateIssueMilestoneNoMetaFile:
    @pytest.mark.asyncio
    async def test_no_meta_file_creates_fresh(self, adapter):
        # update_issue_milestone: meta_file doesn't exist → L877-878
        # else branch sets meta = {}, then writes.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        meta_file = adapter._artifact_dir_from_ref(issue.ref) / "meta.json"
        if meta_file.exists():
            meta_file.unlink()
        await adapter.update_issue_milestone(issue.ref, "3.12.0")
        meta = json.loads(meta_file.read_text())
        assert meta["milestone"] == "3.12.0"


class TestMarkAnswerNotImplemented:
    @pytest.mark.asyncio
    async def test_mark_answer_raises_not_implemented(self, adapter):
        # LocalStore has no comment-level answer concept. L1141-1145.
        ref = ArtifactRef(
            platform_id="local", native_id="comments/x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError, match="mark_answer"):
            await adapter.mark_answer(ref)


class TestGetCommentsEdgeBranches:
    @pytest.mark.asyncio
    async def test_no_comments_dir_returns_empty(self, adapter):
        # comments_dir absent → L1198-1199 returns [].
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        result = await adapter.list_comments(issue.ref)
        assert result == []

    @pytest.mark.asyncio
    async def test_non_file_entry_in_comments_dir_skipped(self, adapter):
        # Stray subdirectory under comments/ → L1210-1211 continue.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        comments_dir = adapter._artifact_dir_from_ref(issue.ref) / "comments"
        comments_dir.mkdir()
        (comments_dir / "subdir").mkdir()  # stray dir, not a file
        result = await adapter.list_comments(issue.ref)
        assert result == []


class TestListRecentDiscussionsMtimeFilter:
    @pytest.mark.asyncio
    async def test_old_discussion_skipped_by_cutoff(self, adapter):
        # list_recent_discussions filters by mtime < cutoff → L1117-1118
        # continue.
        import os as _os
        import time as _time
        disc_root = adapter._path / "discussions"
        disc_root.mkdir(exist_ok=True)
        old = disc_root / "100"
        old.mkdir()
        # Seed minimum required files.
        (old / "title.md").write_text("t\n")
        (old / "body.md").write_text("b")
        (old / "state.txt").write_text("open\n")
        (old / "meta.json").write_text(json.dumps({
            "number": 100, "owner": "o", "repo": "r",
        }))
        # Backdate mtime to before the cutoff.
        old_ts = _time.time() - (30 * 86400)  # 30 days ago
        _os.utime(old, (old_ts, old_ts))
        result = await adapter.list_recent_discussions(
            owner="o", repo="r", since_days=7,
        )
        # Old entry skipped.
        assert result == []


class TestListRecentDiscussionsEdgeBranches:
    @pytest.mark.asyncio
    async def test_no_discussions_dir_returns_empty(self, adapter):
        # disc_root absent → L1104-1106 returns [].
        result = await adapter.list_recent_discussions(owner="o", repo="r")
        assert result == []

    @pytest.mark.asyncio
    async def test_non_numeric_dir_name_skipped(self, adapter):
        # Stray dir name not parseable as int → L1110-1114 continue.
        disc_root = adapter._path / "discussions"
        disc_root.mkdir()
        (disc_root / "stray").mkdir()
        result = await adapter.list_recent_discussions(owner="o", repo="r")
        assert result == []


class TestSyntheticHelpers:
    """get_clone_url, noreply_email, public_issue_url_regex,
    delete_release, get_discussion_body, update_discussion_body,
    bundle_recover_context delegate — all small uncov methods
    that just need a call to mark covered."""

    def test_get_clone_url_returns_local_sentinel(self, adapter):
        # L1316.
        assert adapter.get_clone_url("o", "r") == "local://o/r"

    def test_noreply_email_format(self, adapter):
        # L1322-1323.
        assert adapter.noreply_email("claude") == "claude+claude@local.invalid"

    def test_noreply_email_with_user_id_ignored(self, adapter):
        # user_id param is accepted but not used.
        assert adapter.noreply_email("x", user_id=42) == "claude+x@local.invalid"

    def test_public_issue_url_regex_never_matches(self, adapter):
        # L1332-1333.
        pattern = adapter.public_issue_url_regex()
        assert pattern.search("https://example.com/issues/1") is None
        assert pattern.search("anything") is None

    @pytest.mark.asyncio
    async def test_delete_release_unlinks_existing_file(
        self, adapter, docs_repo,
    ):
        # L1343-1349 — happy path.
        releases = docs_repo / "releases"
        releases.mkdir()
        target = releases / "1.2.3.md"
        target.write_text("notes")
        await adapter.delete_release(owner="o", repo="r", tag="1.2.3")
        assert not target.exists()

    @pytest.mark.asyncio
    async def test_delete_release_missing_file_is_noop(self, adapter):
        # L1347-1348 — FileNotFoundError swallowed.
        await adapter.delete_release(owner="o", repo="r", tag="missing")

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates(self, adapter):
        # L1094 — delegates to get_issue_body via same shape.
        disc_dir = adapter._path / "discussions" / "5"
        disc_dir.mkdir(parents=True)
        (disc_dir / "body.md").write_text("body of disc")
        (disc_dir / "title.md").write_text("t")
        (disc_dir / "state.txt").write_text("open\n")
        ref = ArtifactRef(
            platform_id="local", native_id="discussions/5",
            kind="discussion", owner="o", repo="r", number=5,
        )
        assert await adapter.get_discussion_body(ref) == "body of disc"

    @pytest.mark.asyncio
    async def test_update_discussion_body_delegates(self, adapter):
        # L1099 — delegates to update_issue_body.
        disc_dir = adapter._path / "discussions" / "5"
        disc_dir.mkdir(parents=True)
        (disc_dir / "body.md").write_text("old body that is reasonably long")
        (disc_dir / "title.md").write_text("t")
        (disc_dir / "state.txt").write_text("open\n")
        ref = ArtifactRef(
            platform_id="local", native_id="discussions/5",
            kind="discussion", owner="o", repo="r", number=5,
        )
        new_body = "new body that is also reasonably long enough"
        await adapter.update_discussion_body(ref, new_body, force=True)
        assert (disc_dir / "body.md").read_text() == new_body


class TestSearchIssuesEdgeBranches:
    @pytest.mark.asyncio
    async def test_no_issues_dir_returns_empty(self, adapter):
        # L984 — issues_dir absent.
        result = await adapter.search_issues(owner="o", repo="r")
        assert result.total_count == 0
        assert result.results == []

    @pytest.mark.asyncio
    async def test_non_dir_entry_in_issues_root_skipped(self, adapter):
        # L991-992 — stray file under issues/ continue.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "stray.txt").write_text("nope")
        result = await adapter.search_issues(owner="o", repo="r")
        assert result.total_count == 0


class TestAddLabelIdempotent:
    @pytest.mark.asyncio
    async def test_re_add_existing_label_is_noop(self, adapter):
        # L936 — label already present → early return.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["x"],
        )
        # Re-add same label — should hit the early return path.
        await adapter.add_label(issue.ref, "x")
        labels_file = adapter._artifact_dir_from_ref(issue.ref) / "labels.txt"
        existing = labels_file.read_text().splitlines()
        assert existing.count("x") == 1


class TestCloseIssueNumberFallback:
    @pytest.mark.asyncio
    async def test_close_with_non_numeric_native_id_tail_defaults_to_zero(
        self, adapter,
    ):
        # L917-922 — close_issue: ref.number=None and native_id tail
        # not parseable as int → number defaults to 0.
        d = adapter._path / "issues" / "weird"
        d.mkdir(parents=True)
        (d / "title.md").write_text("t")
        (d / "body.md").write_text("b")
        (d / "state.txt").write_text("open\n")
        (d / "labels.txt").write_text("")
        (d / "meta.json").write_text("{}")
        ref = ArtifactRef(
            platform_id="local", native_id="issues/weird",
            kind="issue", owner="o", repo="r", number=None,
        )
        result = await adapter.close_issue(ref)
        # Tail "weird" not parseable as int → number=0 (the fallback path).
        assert result.ref.number == 0


class TestMilestoneArtifactNotFound:
    def test_read_missing_milestone_raises_forge_error(self, adapter):
        # L319 — _read_milestone_artifact when dir absent.
        with pytest.raises(ForgeError, match="milestone compound-doc not found"):
            adapter._read_milestone_artifact("99.99.99")


class TestAppendHistoryOSError:
    def test_oserror_writing_history_swallowed(
        self, adapter, monkeypatch,
    ):
        # L824-826 — OSError on history write is best-effort (pass).
        import builtins
        original = Path.write_text

        def _fail(self, *a, **kw):
            if "history" in str(self):
                raise OSError("simulated disk error")
            return original(self, *a, **kw)

        monkeypatch.setattr(Path, "write_text", _fail)
        # Should not raise.
        adapter._append_history(
            adapter._path / "fake_artifact",
            "test_op",
            {"key": "value"},
        )


class TestListCommentsMtimeCutoff:
    @pytest.mark.asyncio
    async def test_old_comment_skipped_by_cutoff(self, adapter):
        # L1213-1214 — list_comments filters by mtime < cutoff.
        import os as _os
        import time as _time
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        comments_dir = adapter._artifact_dir_from_ref(issue.ref) / "comments"
        comments_dir.mkdir()
        old_comment = comments_dir / "2020-01-01T00-00-00-000000Z-user.md"
        old_comment.write_text("old comment body")
        old_ts = _time.time() - (30 * 86400)
        _os.utime(old_comment, (old_ts, old_ts))
        result = await adapter.list_comments(issue.ref, since_days=7)
        assert result == []


class TestListRecentDiscussionsAppendPath:
    @pytest.mark.asyncio
    async def test_recent_discussion_appended(self, adapter):
        # L1119 — entry within cutoff → append to result.
        disc_root = adapter._path / "discussions"
        disc_root.mkdir()
        d = disc_root / "42"
        d.mkdir()
        (d / "title.md").write_text("recent discussion\n")
        (d / "body.md").write_text("body")
        (d / "state.txt").write_text("open\n")
        (d / "meta.json").write_text(json.dumps({
            "number": 42, "owner": "o", "repo": "r",
        }))
        result = await adapter.list_recent_discussions(
            owner="o", repo="r", since_days=7,
        )
        assert len(result) == 1
        assert result[0].ref.number == 42


class TestBundleRecoverContextDelegates:
    @pytest.mark.asyncio
    async def test_bundle_recover_context_calls_default(self, adapter):
        # L1380 — delegates to _recovery.default_bundle_recover_context.
        # Seed a minimal TOC discussion so the helper doesn't choke.
        disc = adapter._path / "discussions" / "1"
        disc.mkdir(parents=True)
        (disc / "title.md").write_text("TOC\n")
        (disc / "body.md").write_text("- toc")
        (disc / "state.txt").write_text("open\n")
        (disc / "meta.json").write_text(json.dumps({
            "number": 1, "owner": "o", "repo": "r", "node_id": "D_1",
        }))
        bundle = await adapter.bundle_recover_context(
            owner="o", repo="r", toc_discussion_id="D_1",
            since_days=7, issue_limit=10,
        )
        # Smoke: bundle returns; downstream shape is _recovery's contract.
        assert bundle is not None


class TestProjectBoardNotImplementedSurface:
    """LocalStore raises NotImplementedError for the project-board
    sub-Protocol. L1805 / 1815 / 1824 / 1833."""

    @pytest.mark.asyncio
    async def test_add_to_project_board_raises(self, adapter):
        ref = ArtifactRef(
            platform_id="local", native_id="issues/1", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(NotImplementedError, match="add_to_project_board"):
            await adapter.add_to_project_board(board_id="b1", ref=ref)

    @pytest.mark.asyncio
    async def test_get_project_status_field_raises(self, adapter):
        with pytest.raises(NotImplementedError, match="status_field"):
            await adapter.get_project_status_field(board_id="b1")

    @pytest.mark.asyncio
    async def test_get_project_item_id_raises(self, adapter):
        ref = ArtifactRef(
            platform_id="local", native_id="issues/1", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(NotImplementedError, match="project_item_id"):
            await adapter.get_project_item_id(ref=ref, board_id="b1")

    @pytest.mark.asyncio
    async def test_move_project_item_raises(self, adapter):
        with pytest.raises(NotImplementedError, match="move_project_item"):
            await adapter.move_project_item(
                board_id="b1", item_id="i1",
                status_field_id="s1", option_id="o1",
            )


class TestQueryHistoryWalker:
    """L1570-1612 — query_history walker."""

    @pytest.mark.asyncio
    async def test_no_history_dir_returns_empty(self, adapter):
        # L1572-1573.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        # Remove any auto-created history dir.
        import shutil
        history_dir = adapter._artifact_dir_from_ref(issue.ref) / "history"
        if history_dir.exists():
            shutil.rmtree(history_dir)
        result = await adapter.query_history(issue.ref)
        assert result == []

    @pytest.mark.asyncio
    async def test_non_json_entry_in_history_dir_skipped(self, adapter):
        # L1577-1578.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        history_dir = adapter._artifact_dir_from_ref(issue.ref) / "history"
        history_dir.mkdir(exist_ok=True)
        (history_dir / "stray.txt").write_text("nope")
        result = await adapter.query_history(issue.ref)
        # Only the auto-created create_issue history entry should appear.
        ops = [e.operation for e in result]
        assert all(op != "" for op in ops)

    @pytest.mark.asyncio
    async def test_malformed_json_skipped(self, adapter):
        # L1581-1584.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        history_dir = adapter._artifact_dir_from_ref(issue.ref) / "history"
        history_dir.mkdir(exist_ok=True)
        (history_dir / "20300101T000000000000Z-bad.json").write_text("{bad json")
        result = await adapter.query_history(issue.ref)
        # The bad entry was skipped — the create_issue auto-entry remains.
        ops = [e.operation for e in result]
        assert "bad" not in ops

    @pytest.mark.asyncio
    async def test_bad_timestamp_skipped(self, adapter):
        # L1593-1594.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        history_dir = adapter._artifact_dir_from_ref(issue.ref) / "history"
        history_dir.mkdir(exist_ok=True)
        (history_dir / "bad-ts.json").write_text(json.dumps({
            "timestamp": "not-a-timestamp",
            "operation": "broken_op",
        }))
        result = await adapter.query_history(issue.ref)
        ops = [e.operation for e in result]
        assert "broken_op" not in ops

    @pytest.mark.asyncio
    async def test_operation_filter_excludes(self, adapter):
        # L1597-1598 — entries whose op doesn't match are skipped.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "x" * 100, force=True,
        )
        # The history has operation="update_body"; filter for something
        # else → empty list.
        result = await adapter.query_history(issue.ref, operation="bogus_op")
        assert result == []

    @pytest.mark.asyncio
    async def test_since_filter_excludes_older(self, adapter):
        # L1599-1600.
        from datetime import datetime, timezone
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "x" * 100, force=True,
        )
        future = datetime(2099, 1, 1, tzinfo=timezone.utc)
        result = await adapter.query_history(issue.ref, since=future)
        assert result == []

    @pytest.mark.asyncio
    async def test_happy_path_returns_entries(self, adapter):
        # L1602-1612 — payload extraction + HistoryEntry append.
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="b" * 100, labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "y" * 100, force=True,
        )
        result = await adapter.query_history(issue.ref)
        assert len(result) >= 1
        assert result[0].operation == "update_body"
        assert "timestamp" not in result[0].payload  # excluded
        assert "operation" not in result[0].payload  # excluded


class TestAggregateHistorySinceWalker:
    """L1638-1670 — aggregate_history_since walker."""

    @pytest.mark.asyncio
    async def test_no_issues_or_discussions_dirs_returns_empty(
        self, adapter,
    ):
        # L1647-1648.
        from datetime import datetime, timezone
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.aggregate_history_since(since=epoch)
        assert result == []

    @pytest.mark.asyncio
    async def test_non_dir_entry_in_root_skipped(self, adapter):
        # L1650-1651.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "stray.txt").write_text("nope")
        from datetime import datetime, timezone
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.aggregate_history_since(since=epoch)
        assert result == []

    @pytest.mark.asyncio
    async def test_non_numeric_dir_name_skipped(self, adapter):
        # L1652-1655.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "weird").mkdir()
        from datetime import datetime, timezone
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.aggregate_history_since(since=epoch)
        assert result == []

    @pytest.mark.asyncio
    async def test_happy_path_walks_issues_and_discussions(self, adapter):
        # L1645-1670 — full traversal.
        from datetime import datetime, timezone
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="b" * 100, labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "y" * 100, force=True,
        )
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.aggregate_history_since(
            since=epoch, owner="o", repo="r",
        )
        # Sorted by timestamp; at least the update_body entry present.
        assert len(result) >= 1

    @pytest.mark.asyncio
    async def test_kind_filter_limits_walk_to_issue(self, adapter):
        # L1639-1640 — kind="issue" walks only issues/ subdir.
        from datetime import datetime, timezone
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="b" * 100, labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "y" * 100, force=True,
        )
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.aggregate_history_since(
            since=epoch, kind="issue", owner="o", repo="r",
        )
        # Only issue refs.
        assert all(e.ref.kind == "issue" for e in result)


class TestSnapshotWalker:
    """L1704-1786 — snapshot() walker."""

    @pytest.mark.asyncio
    async def test_empty_store_returns_skeleton(self, adapter):
        result = await adapter.snapshot(owner="o", repo="r")
        assert result["platform_id"] == "local"
        assert result["owner"] == "o"
        assert result["repo"] == "r"
        assert result["issues"] == {}
        assert result["discussions"] == {}
        assert result["milestones"] == []

    @pytest.mark.asyncio
    async def test_snapshot_includes_issues_and_discussions(self, adapter):
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["x"],
        )
        # Seed a discussion dir directly.
        disc = adapter._path / "discussions" / "5"
        disc.mkdir(parents=True)
        (disc / "title.md").write_text("d\n")
        (disc / "body.md").write_text("b")
        (disc / "state.txt").write_text("open\n")
        (disc / "labels.txt").write_text("triage\n")
        (disc / "meta.json").write_text(json.dumps({
            "number": 5, "owner": "o", "repo": "r",
        }))
        # Seed a milestone file.
        ms = adapter._path / "milestones"
        ms.mkdir(parents=True, exist_ok=True)
        (ms / "1.0.0.md").write_text("# milestone")
        result = await adapter.snapshot(owner="o", repo="r")
        assert 1 in result["issues"]
        assert result["issues"][1]["labels"] == ["x"]
        assert 5 in result["discussions"]
        assert result["discussions"][5]["labels"] == ["triage"]
        assert "1.0.0" in result["milestones"]

    @pytest.mark.asyncio
    async def test_non_dir_entries_skipped(self, adapter):
        # L1734-1736 + L1758-1760.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "stray.txt").write_text("nope")
        disc_root = adapter._path / "discussions"
        disc_root.mkdir()
        (disc_root / "stray.txt").write_text("nope")
        result = await adapter.snapshot(owner="o", repo="r")
        assert result["issues"] == {}
        assert result["discussions"] == {}

    @pytest.mark.asyncio
    async def test_non_numeric_dir_names_skipped(self, adapter):
        # L1737-1740 + L1761-1764.
        (adapter._path / "issues" / "weird").mkdir(parents=True)
        (adapter._path / "discussions" / "weird").mkdir(parents=True)
        result = await adapter.snapshot(owner="o", repo="r")
        assert result["issues"] == {}
        assert result["discussions"] == {}

    @pytest.mark.asyncio
    async def test_since_filter_excludes_unchanged(self, adapter):
        # L1706-1720 + L1741-1744 — recent_*_numbers gates membership.
        from datetime import datetime, timezone
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        future = datetime(2099, 1, 1, tzinfo=timezone.utc)
        result = await adapter.snapshot(
            owner="o", repo="r", since=future,
        )
        # No issues should match a future cutoff.
        assert result["issues"] == {}
        assert result["since"] is not None


class TestFetchRemoteChanges:
    @pytest.mark.asyncio
    async def test_fetch_remote_changes_delegates_to_history(self, adapter):
        # L1851-1854.
        from datetime import datetime, timezone
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="b" * 100, labels=[],
        )
        await adapter.update_issue_body(
            issue.ref, "y" * 100, force=True,
        )
        epoch = datetime(2000, 1, 1, tzinfo=timezone.utc)
        result = await adapter.fetch_remote_changes(
            since=epoch, owner="o", repo="r",
        )
        assert len(result) >= 1
        # Shape: RemoteChange with source_platform_id="local"
        assert result[0].source_platform_id == "local"


class TestApplyRemoteChangeConflictAndDispatch:
    """L1889-1945 — apply_remote_change conflict + dispatch."""

    @pytest.mark.asyncio
    async def test_artifact_not_found_returns_conflict(self, adapter):
        # L1891-1895 — _artifact_dir_from_ref raises
        # InvalidArtifactRefError → conflict.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        # Build a ref to a non-existent platform that won't resolve.
        ref = ArtifactRef(
            platform_id="github", native_id="MDU_nope",
            kind="issue", owner="o", repo="r",
        )
        change = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body",
            observed_at=datetime(2020, 1, 1, tzinfo=timezone.utc),
            payload={"new_body": "X"},
        )
        result = await adapter.apply_remote_change(change)
        # Cross-platform ref with no meta.json match → _orphan path → not exists.
        assert result is not None
        assert "missing" in result.reason or "not found" in result.reason

    @pytest.mark.asyncio
    async def test_dispatch_update_body(self, adapter):
        # L1930-1932.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="old body that is reasonably long enough",
            labels=[],
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="update_body",
            observed_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
            payload={"new_body": "new body that is also reasonably long"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is None  # clean apply
        body_file = adapter._artifact_dir_from_ref(issue.ref) / "body.md"
        assert "new body" in body_file.read_text()

    @pytest.mark.asyncio
    async def test_dispatch_close_issue(self, adapter):
        # L1933-1935.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="close_issue",
            observed_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
            payload={"state_reason": "completed"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is None

    @pytest.mark.asyncio
    async def test_dispatch_add_label(self, adapter):
        # L1936-1939.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="add_label",
            observed_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
            payload={"label": "new-label"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is None

    @pytest.mark.asyncio
    async def test_dispatch_remove_label(self, adapter):
        # L1940-1943.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["x"],
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="remove_label",
            observed_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
            payload={"label": "x"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is None

    @pytest.mark.asyncio
    async def test_unknown_op_is_noop(self, adapter):
        # L1944 — unknown op returns None without error.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=[],
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="some_unknown_op",
            observed_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
            payload={},
        )
        result = await adapter.apply_remote_change(change)
        assert result is None


class TestLocalStoreRemainingEdges:
    """Drain the last cluster of uncov branches in local_store.py
    (the lines remaining after the bulk drain): L1111 + 1769
    (non-dir in disc walk), L1891-1892 (apply_remote_change with
    cross-adapter ref that hits InvalidArtifactRefError), L1918
    (diverging history conflict), L1977-1981 (_next_artifact_number
    edge branches), L1998-2007 (cross-adapter _artifact_dir_from_ref
    walk), L2039-2040 / L2083-2084 (meta.json JSONDecodeError),
    L2129-2130 (_auto_commit subprocess failure)."""

    @pytest.mark.asyncio
    async def test_list_recent_discussions_non_dir_skipped(self, adapter):
        # L1110-1111 — stray file in discussions/ continue.
        disc_root = adapter._path / "discussions"
        disc_root.mkdir()
        (disc_root / "stray.txt").write_text("nope")
        result = await adapter.list_recent_discussions(owner="o", repo="r")
        assert result == []

    @pytest.mark.asyncio
    async def test_snapshot_skips_filtered_discussion(self, adapter):
        # L1765-1769 — discussion seeded but mtime older than future
        # cutoff → continue.
        from datetime import datetime, timezone
        disc = adapter._path / "discussions" / "5"
        disc.mkdir(parents=True)
        (disc / "title.md").write_text("d\n")
        (disc / "body.md").write_text("b")
        (disc / "state.txt").write_text("open\n")
        (disc / "meta.json").write_text(json.dumps({
            "number": 5, "owner": "o", "repo": "r",
        }))
        future = datetime(2099, 1, 1, tzinfo=timezone.utc)
        result = await adapter.snapshot(
            owner="o", repo="r", since=future,
        )
        assert result["discussions"] == {}

    def test_next_artifact_number_skips_non_dir_and_non_numeric(
        self, adapter,
    ):
        # L1976-1981 — stray file + non-numeric dir.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "stray.txt").write_text("nope")
        (issues_root / "weird").mkdir()
        # Should still return 1 (no valid numeric entries).
        assert adapter._next_artifact_number("issues") == 1

    def test_artifact_dir_cross_adapter_skips_missing_meta(self, adapter):
        # L1998-2007 — cross-adapter ref scan walks meta.json files.
        # Seed an issue dir without meta.json, plus one with a
        # different node_id, plus one with malformed JSON.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        (issues_root / "1").mkdir()  # no meta.json
        d2 = issues_root / "2"
        d2.mkdir()
        (d2 / "meta.json").write_text("{not json")  # malformed
        d3 = issues_root / "3"
        d3.mkdir()
        (d3 / "meta.json").write_text(json.dumps({"node_id": "other_id"}))
        # Ref from another platform with a node_id that doesn't match.
        ref = ArtifactRef(
            platform_id="github", native_id="MDU_zzz",
            kind="issue", owner="o", repo="r",
        )
        result = adapter._artifact_dir_from_ref(ref)
        # No match → falls through to _orphan path.
        assert "_orphan" in str(result)

    def test_artifact_dir_cross_adapter_matches_node_id(self, adapter):
        # L2006-2007 — meta.json node_id matches incoming ref.
        issues_root = adapter._path / "issues"
        issues_root.mkdir()
        d = issues_root / "1"
        d.mkdir()
        (d / "meta.json").write_text(json.dumps({"node_id": "MDU_aaa"}))
        ref = ArtifactRef(
            platform_id="github", native_id="MDU_aaa",
            kind="issue", owner="o", repo="r",
        )
        result = adapter._artifact_dir_from_ref(ref)
        assert result == d

    def test_read_issue_swallows_malformed_meta_json(self, adapter):
        # L2039-2040 — meta.json JSONDecodeError → meta={}.
        d = adapter._path / "issues" / "1"
        d.mkdir(parents=True)
        (d / "title.md").write_text("t")
        (d / "body.md").write_text("b")
        (d / "state.txt").write_text("open\n")
        (d / "meta.json").write_text("{not json")  # malformed
        issue = adapter._read_issue(owner="o", repo="r", number=1, issue_dir=d)
        # Falls back to milestone=None when meta unparseable.
        assert issue.milestone is None

    def test_read_discussion_swallows_malformed_meta_json(self, adapter):
        # L2083-2084 — meta.json JSONDecodeError → meta={}.
        d = adapter._path / "discussions" / "1"
        d.mkdir(parents=True)
        (d / "title.md").write_text("t")
        (d / "body.md").write_text("b")
        (d / "state.txt").write_text("open\n")
        (d / "meta.json").write_text("{not json")
        disc = adapter._read_discussion(
            owner="o", repo="r", number=1, disc_dir=d,
        )
        # Falls back to category=None when meta unparseable.
        assert disc.category is None

    def test_auto_commit_swallows_filenotfounderror(
        self, adapter, monkeypatch,
    ):
        # L2129-2130 — FileNotFoundError on subprocess.run → return None.
        original = subprocess.run

        def _fail(*a, **kw):
            raise FileNotFoundError("git not installed")

        monkeypatch.setattr(subprocess, "run", _fail)
        result = adapter._auto_commit("test message")
        assert result is None

    def test_auto_commit_swallows_called_process_error(
        self, adapter, monkeypatch,
    ):
        # L2129-2130 — CalledProcessError on first call → return None.
        original = subprocess.run

        def _fail(*a, **kw):
            raise subprocess.CalledProcessError(1, "git")

        monkeypatch.setattr(subprocess, "run", _fail)
        result = adapter._auto_commit("test message")
        assert result is None


class TestApplyRemoteChangeRemainingBranches:
    @pytest.mark.asyncio
    async def test_invalid_ref_returns_conflict(self, adapter):
        # L1891-1895 — _artifact_dir_from_ref raises
        # InvalidArtifactRefError. Trigger by monkeypatching
        # _artifact_dir_from_ref to raise directly.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        from forge_manager_mcp.adapters import errors as _errors

        def _raise(ref):
            raise _errors.InvalidArtifactRefError("ref", ref.native_id)

        adapter._artifact_dir_from_ref = _raise
        ref = ArtifactRef(
            platform_id="local", native_id="issues/1",
            kind="issue", owner="o", repo="r", number=1,
        )
        change = RemoteChange(
            source_platform_id="local", ref=ref,
            operation="update_body",
            observed_at=datetime(2020, 1, 1, tzinfo=timezone.utc),
            payload={"new_body": "X"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is not None
        assert "not found" in result.reason

    @pytest.mark.asyncio
    async def test_diverging_history_returns_conflict(self, adapter):
        # L1917-1925 — local history newer than observed_at → conflict.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import RemoteChange
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t",
            body="b" * 100, labels=[],
        )
        # Add a real history entry by mutating the issue locally.
        await adapter.update_issue_body(
            issue.ref, "y" * 100, force=True,
        )
        change = RemoteChange(
            source_platform_id="local", ref=issue.ref,
            operation="update_body",
            observed_at=datetime(2000, 1, 1, tzinfo=timezone.utc),
            payload={"new_body": "z" * 100},
        )
        result = await adapter.apply_remote_change(change)
        assert result is not None
        assert "newer than" in result.reason


class TestReadSessionEventsEdgeBranches:
    @pytest.mark.asyncio
    async def test_non_dir_entry_in_sessions_root_skipped(self, adapter):
        # Stray file in sessions/ → L1454-1455 continue.
        sessions_root = adapter._path / "sessions"
        sessions_root.mkdir(exist_ok=True)
        (sessions_root / "stray.txt").write_text("nope")
        events = await adapter.read_session_events()
        assert events == []

    @pytest.mark.asyncio
    async def test_non_json_file_in_session_dir_skipped(self, adapter):
        # Stray .txt file in sessions/<id>/ → L1457-1458 continue.
        d = adapter._path / "sessions" / "abc"
        d.mkdir(parents=True)
        (d / "not-an-event.txt").write_text("nope")
        events = await adapter.read_session_events()
        assert events == []

    @pytest.mark.asyncio
    async def test_invalid_iso_timestamp_skipped(self, adapter):
        # raw.timestamp not parseable as ISO → L1471-1472 continue.
        d = adapter._path / "sessions" / "abc"
        d.mkdir(parents=True)
        (d / "bad-ts.json").write_text(json.dumps({
            "session_id": "abc",
            "event": "opened",
            "body": "",
            "timestamp": "not-an-iso",
        }))
        events = await adapter.read_session_events()
        assert events == []


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
