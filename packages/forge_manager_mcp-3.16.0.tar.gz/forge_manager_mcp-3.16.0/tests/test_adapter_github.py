"""Unit tests for GitHubAdapter shape conversions (3.0 / Phase 2 sub-run B).

Focus: the dict-to-canonical-type shapers, the platform_id classvar,
and the probe predicate. Live integration is covered by the cross-
adapter conformance suite (Phase 2 sub-run D).
"""
from __future__ import annotations

from datetime import datetime
from unittest.mock import AsyncMock, patch

import pytest

from forge_manager_mcp.adapters.github import (
    GitHubAdapter,
    _comment_from_dict,
    _discussion_from_dict,
    _issue_from_dict,
    _make_ref,
    _milestone_from_dict,
    _milestone_from_field,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id classvar
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_classvar(self):
        assert GitHubAdapter.platform_id == "github"

    def test_instance_inherits(self):
        adapter = GitHubAdapter(token="fake")
        assert adapter.platform_id == "github"

    def test_has_scaffold_true_after_c2(self):
        assert GitHubAdapter.has_scaffold is True

    def test_has_session_event_surface_false(self):
        assert GitHubAdapter.has_session_event_surface is False


# ---------------------------------------------------------------------------
# _make_ref
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            native_id="I_kwDO123",
            kind="issue",
            owner="org",
            repo="proj",
            number=42,
        )
        assert ref.platform_id == "github"
        assert ref.native_id == "I_kwDO123"
        assert ref.kind == "issue"
        assert ref.number == 42

    def test_comment_no_number(self):
        ref = _make_ref(
            native_id="DC_abc",
            kind="comment",
            owner="o",
            repo="r",
        )
        assert ref.number is None


# ---------------------------------------------------------------------------
# _issue_from_dict
# ---------------------------------------------------------------------------

class TestIssueFromDict:
    def test_minimal(self):
        d = {"id": "I_x", "number": 1, "title": "t", "body": "b"}
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.title == "t"
        assert issue.body == "b"
        assert issue.state == "open"
        assert issue.ref.number == 1

    def test_state_normalization(self):
        d = {"id": "x", "number": 1, "title": "t", "body": "", "state": "CLOSED"}
        assert _issue_from_dict(d, owner="o", repo="r").state == "closed"

    def test_state_default_open(self):
        d = {"id": "x", "number": 1, "title": "t", "body": ""}
        assert _issue_from_dict(d, owner="o", repo="r").state == "open"

    def test_labels_explicit(self):
        d = {"id": "x", "number": 1, "title": "t", "body": ""}
        issue = _issue_from_dict(
            d, owner="o", repo="r", labels=["kind:bug", "area:mcp"],
        )
        assert issue.labels == ["kind:bug", "area:mcp"]

    def test_labels_from_dict_field(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "labels": [{"name": "bug"}, {"name": "area:mcp"}],
        }
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert "bug" in issue.labels
        assert "area:mcp" in issue.labels

    def test_milestone_from_field_dict(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "milestone": {"title": "3.0.0"},
        }
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.milestone == "3.0.0"

    def test_milestone_explicit_overrides_field(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "milestone": {"title": "from-dict"},
        }
        issue = _issue_from_dict(
            d, owner="o", repo="r", milestone="explicit",
        )
        assert issue.milestone == "explicit"

    def test_body_none_normalized_to_empty(self):
        # Some github/* responses have body: None for empty Issues.
        d = {"id": "x", "number": 1, "title": "t", "body": None}
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.body == ""


# ---------------------------------------------------------------------------
# _discussion_from_dict
# ---------------------------------------------------------------------------

class TestDiscussionFromDict:
    def test_minimal(self):
        d = {"id": "D_x", "number": 5, "title": "t", "body": "b"}
        disc = _discussion_from_dict(d, owner="o", repo="r")
        assert disc.title == "t"
        assert disc.ref.kind == "discussion"
        assert disc.category is None

    def test_with_category(self):
        d = {
            "id": "D_x", "number": 5, "title": "t", "body": "b",
            "category": "Architecture",
        }
        disc = _discussion_from_dict(d, owner="o", repo="r")
        assert disc.category == "Architecture"


# ---------------------------------------------------------------------------
# _comment_from_dict
# ---------------------------------------------------------------------------

class TestCommentFromDict:
    def test_minimal(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r", number=1,
        )
        d = {"id": "DC_a", "body": "hello", "author": "claude"}
        c = _comment_from_dict(d, parent=parent)
        assert c.body == "hello"
        assert c.author == "claude"
        assert c.parent.kind == "issue"

    def test_iso_timestamp_parsed(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r",
        )
        d = {
            "id": "DC_a", "body": "x", "author": "a",
            "createdAt": "2026-04-29T15:00:00Z",
        }
        c = _comment_from_dict(d, parent=parent)
        assert c.created_at.year == 2026
        assert c.created_at.month == 4

    def test_missing_timestamp_uses_now(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r",
        )
        d = {"id": "DC_a", "body": "x", "author": "a"}
        c = _comment_from_dict(d, parent=parent)
        # Should fall back to datetime.now(); just verify it's a real datetime.
        assert isinstance(c.created_at, datetime)


# ---------------------------------------------------------------------------
# _milestone_from_dict / _milestone_from_field
# ---------------------------------------------------------------------------

class TestMilestoneFromDict:
    def test_basic(self):
        d = {"title": "3.0.0", "number": 5, "state": "open"}
        m = _milestone_from_dict(d)
        assert m.title == "3.0.0"
        assert m.number == 5
        assert m.state == "open"

    def test_closed_state_normalization(self):
        d = {"title": "2.3.0", "number": 1, "state": "CLOSED"}
        assert _milestone_from_dict(d).state == "closed"


class TestMilestoneFromField:
    def test_none(self):
        assert _milestone_from_field(None) is None

    def test_string(self):
        assert _milestone_from_field("3.0.0") == "3.0.0"

    def test_dict_with_title(self):
        assert _milestone_from_field({"title": "3.0.0"}) == "3.0.0"

    def test_dict_without_title(self):
        assert _milestone_from_field({}) is None


# ---------------------------------------------------------------------------
# probe
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_probe_success(self):
        adapter = GitHubAdapter(token="fake")
        with patch(
            "forge_manager_mcp.github.core._graphql",
            new=AsyncMock(return_value={"viewer": {"login": "test"}}),
        ):
            assert await adapter.probe() is True

    @pytest.mark.asyncio
    async def test_probe_unavailable_returns_false(self):
        from forge_manager_mcp.adapters.errors import ForgeUnavailableError

        adapter = GitHubAdapter(token="fake")
        with patch(
            "forge_manager_mcp.github.core._graphql",
            new=AsyncMock(side_effect=ForgeUnavailableError("503")),
        ):
            assert await adapter.probe() is False


# ---------------------------------------------------------------------------
# create_issue — lookup parallelism + failure propagation
# ---------------------------------------------------------------------------
#
# Pre-#274 these concerns lived at the handler level (in test_create_issue.py
# and test_create_thread.py). Post-#274 the adapter owns the
# repo / label / milestone resolution dance, so the tests follow.

class TestCreateIssueParallelism:
    """#179 / #180 — repo + label (+ milestone) lookups must dispatch
    concurrently. Pre-#274 the handler did the gather; #274 moved the
    gather inside ``GitHubAdapter.create_issue``. Either layer must
    keep the lookup phase parallel — the test asserts on observable
    peak in-flight count."""

    @pytest.mark.asyncio
    async def test_lookup_phase_runs_in_parallel(self, monkeypatch):
        import asyncio

        in_flight = 0
        peak = 0
        release = asyncio.Event()

        async def stalled_lookup(*args, **kwargs):
            nonlocal in_flight, peak
            in_flight += 1
            peak = max(peak, in_flight)
            try:
                await release.wait()
                return "STUB"
            finally:
                in_flight -= 1

        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.get_repo_node_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_label_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.find_milestone_node_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.create_issue",
            AsyncMock(return_value={
                "id": "I_x", "number": 1, "url": "u",
            }),
        )

        adapter = GitHubAdapter(token="fake")
        labels = ["feature", "area:mcp", "area:skill"]
        task = asyncio.create_task(
            adapter.create_issue(
                owner="o", repo="r", title="t", body="b",
                labels=labels, milestone="2.3.0",
            )
        )

        # 1 repo + 3 labels + 1 milestone = 5 concurrent reads expected.
        for _ in range(40):
            await asyncio.sleep(0)
            if in_flight >= 5:
                break

        assert peak == 5, (
            f"expected 5 concurrent lookups (1 repo + 3 labels + 1 "
            f"milestone), got peak={peak}. GitHubAdapter.create_issue "
            "lookup phase is running sequentially."
        )

        release.set()
        await task


class TestCreateIssueMilestoneFailure:
    """#232 — milestone resolution failure surfaces clearly. Pre-#274
    this was tested at the handler level via
    `test_milestone_resolution_failure_propagates`; #274 moved the
    lookup into the adapter, so the test follows. The adapter must
    NOT call `_gh.create_issue` when milestone resolution fails — a
    bad milestone shouldn't leak a partially-created Issue."""

    @pytest.mark.asyncio
    async def test_milestone_lookup_failure_skips_create_issue(self, monkeypatch):
        from forge_manager_mcp.github.core import GitHubError

        async def boom(*args, **kwargs):
            raise GitHubError(
                "Milestone '9.9.9' not found in o/r. Available milestones: ['1.2.0']"
            )

        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.get_repo_node_id",
            AsyncMock(return_value="R_x"),
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_label_id",
            AsyncMock(return_value="LA_x"),
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.find_milestone_node_id", boom,
        )
        create_mock = AsyncMock()
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.create_issue", create_mock,
        )

        adapter = GitHubAdapter(token="fake")
        with pytest.raises(GitHubError, match="Available milestones"):
            await adapter.create_issue(
                owner="o", repo="r", title="t", body="b",
                labels=["feature"], milestone="9.9.9",
            )

        create_mock.assert_not_called()


# ---------------------------------------------------------------------------
# close_issue returns Issue (Phase C2)
# ---------------------------------------------------------------------------

class TestCloseIssueReturnShape:
    """#274 Phase C2 — close_issue returns the closed canonical Issue.
    Pre-Phase-C2 it returned None and the handler relied on the raw
    GraphQL dict from _gh_issues.close_issue (url + closed_at)."""

    @pytest.mark.asyncio
    async def test_returns_canonical_issue_with_url_and_updated_at(
        self, monkeypatch
    ):
        from datetime import datetime
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=42,
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.close_issue",
            AsyncMock(return_value={
                "url": "https://github.com/o/r/issues/42",
                "closed_at": "2026-04-23T17:00:00Z",
            }),
        )
        issue = adapter.close_issue(ref)
        result = await issue
        assert result.state == "closed"
        assert result.url == "https://github.com/o/r/issues/42"
        assert result.updated_at == datetime(
            2026, 4, 23, 17, 0, 0,
            tzinfo=result.updated_at.tzinfo,
        )
        # ref echoed through unchanged
        assert result.ref.native_id == "I_abc"


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. Lets handlers that
    have an issue_id / discussion_id (not a number) fetch the current
    body for size-guardrail checks."""

    @pytest.mark.asyncio
    async def test_get_issue_body_delegates_to_gh_layer(self, monkeypatch):
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r",
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_issue_body",
            AsyncMock(return_value="the body"),
        )
        body = await adapter.get_issue_body(ref)
        assert body == "the body"

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates_to_gh_layer(self, monkeypatch):
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="D_x", kind="discussion",
            owner="o", repo="r",
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.discussions.get_discussion_body",
            AsyncMock(return_value="discussion body"),
        )
        body = await adapter.get_discussion_body(ref)
        assert body == "discussion body"


# ---------------------------------------------------------------------------
# compute_drift stub (Phase 6 will implement)
# ---------------------------------------------------------------------------

class TestComputeDriftStub:
    @pytest.mark.asyncio
    async def test_returns_clean_report(self):
        adapter = GitHubAdapter(token="fake")
        report = await adapter.compute_drift({})
        assert report.platform_id == "github"
        assert report.is_clean is True


class TestProjectBoardErrorWrap:
    """3.4.2 fix — every GitHubAdapter project-board method normalizes
    legacy ``GitHubError`` (raised by ``forge_manager_mcp.github.projects``
    helpers) into the canonical ``ForgeError`` Protocol contract so
    handler-helper code can catch a single exception type. Pre-3.4.2
    the raw GitHubError leaked past `except ForgeError` clauses, masking
    canonical-success outcomes (notably in
    `_attach_to_project_board_if_supported`)."""

    @pytest.mark.asyncio
    async def test_add_to_project_board_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_mod, "__name__", gh_mod.__name__)
        # Monkey-patch the indirect import the adapter uses
        from forge_manager_mcp.github import projects as gh_projects
        monkeypatch.setattr(gh_projects, "add_item_to_project", _raise)

        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.add_to_project_board(board_id="PVT_x", ref=ref)

    @pytest.mark.asyncio
    async def test_get_project_status_field_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "get_project_status_field", _raise)
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.get_project_status_field(board_id="PVT_x")

    @pytest.mark.asyncio
    async def test_get_project_item_id_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "get_project_item_id", _raise)
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.get_project_item_id(ref=ref, board_id="PVT_x")

    @pytest.mark.asyncio
    async def test_move_project_item_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "move_project_item", _raise)
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.move_project_item(
                board_id="PVT_x", item_id="PVTI_x",
                status_field_id="PVTSSF_x", option_id="OPT_x",
            )


class TestBootstrapProject:
    """Multi-platform scaffold C2 first stage — GitHubAdapter.bootstrap_project.

    Method is implemented but the capability flag stays False until
    stage 2 wires it into scaffold_project_multi's dispatch. Tests
    cover the method in isolation by monkey-patching the github.scaffold
    helpers (no live GraphQL calls)."""

    @staticmethod
    def _stub_stage_2b_i(monkeypatch):
        """Install canonical-happy-path stubs for the C2 stage 2b-i
        project-board calls. Used by every test that runs past the
        Discussion-categories check (where stage 2b-i fires)."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def _list_projects(token, owner_id):
            return []

        async def _create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 1,
                "url": f"https://github.com/orgs/o/projects/1",
                "title": title,
            }

        async def _link_project(token, project_id, repo_id):
            return True

        async def _get_status(token, project_id):
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def _update_status(token, project_id, field_id, desired):
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", _list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", _create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", _link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", _get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", _update_status,
        )

    @staticmethod
    def _stub_stage_2b_ii(monkeypatch):
        """Install canonical-happy-path stubs for the C2 stage 2b-ii
        Discussion seeding calls."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def _create_discussion(token, repo_id, category_id, title, body):
            return {
                "id": f"D_{title.replace(' ', '_')}",
                "number": 1,
                "url": "https://github.com/x/y/discussions/1",
            }

        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", _create_discussion)

    @pytest.mark.asyncio
    async def test_missing_org_returns_awaiting_manual(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return None  # org missing

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="ghost-org", project_name="widgets", description="",
        )
        assert result.platform_id == "github"
        assert result.phase == "awaiting_manual"
        assert any("does not exist" in s for s in result.manual_steps)
        assert result.artifacts["org_id"] is None

    @pytest.mark.asyncio
    async def test_creates_repo_trio_and_seeds_labels(self, monkeypatch):
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        repos_created: list[tuple[str, str]] = []
        labels_seeded_per_repo: dict[str, list[str]] = {}

        async def fake_get_org_id(token, login):
            return "O_widgets"

        async def fake_get_repo_node_id(token, owner, name):
            # All three repos new — raise so creation fires.
            raise _errs.ForgeError("not found")

        async def fake_create_repository(token, *, owner_id, name, visibility, description):
            repos_created.append((name, visibility))
            return {
                "id": f"R_{name}",
                "name_with_owner": f"acme/{name}",
                "url": f"https://github.com/acme/{name}",
            }

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            labels_seeded_per_repo.setdefault(repo_id, []).append(label_name)
            return {"id": f"LA_{label_name}"}

        # Stage 2a stubs — Discussions enabled, all required categories present.
        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "DIC_b", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_c", "isAnswerable": True},
                    "Ideas": {"id": "DIC_d", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_e", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        # Stage 2b-i stubs — fresh board path.
        async def fake_list_projects(token, owner_id):
            return []  # no existing project

        async def fake_create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 7,
                "url": f"https://github.com/orgs/acme/projects/7",
                "title": title,
            }

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            # Default GitHub Status options post-create.
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def fake_update_status(token, project_id, field_id, desired):
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="widgets!",
        )

        # All three repos created.
        assert {n for n, _ in repos_created} == {"widgets-dev", "widgets", "widgets-docs"}
        # dev is private; public + docs are public.
        priv = next(v for n, v in repos_created if n == "widgets-dev")
        assert priv == "PRIVATE"
        for n in ("widgets", "widgets-docs"):
            assert next(v for nn, v in repos_created if nn == n) == "PUBLIC"
        # Labels seeded on dev + public (not docs — docs is the rendered site).
        assert "R_widgets-dev" in labels_seeded_per_repo
        assert "R_widgets" in labels_seeded_per_repo
        assert "R_widgets-docs" not in labels_seeded_per_repo
        for repo_id in ("R_widgets-dev", "R_widgets"):
            assert "bug" in labels_seeded_per_repo[repo_id]
            assert "rfc" in labels_seeded_per_repo[repo_id]
            assert "area:mcp" in labels_seeded_per_repo[repo_id]
        # C2 fully absorbed → phase = complete (no manual_steps
        # since the canonical-happy-path stubs satisfy every step).
        assert result.phase == "complete"
        assert result.manual_steps == []

    @pytest.mark.asyncio
    async def test_idempotent_when_repos_exist(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod

        creates: list[str] = []

        async def fake_get_org_id(token, login):
            return "O_widgets"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"  # exists

        async def fake_create_repository(token, *, owner_id, name, **kwargs):
            creates.append(name)
            return {"id": f"R_{name}", "name_with_owner": f"acme/{name}", "url": ""}

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            return {"id": f"LA_{label_name}"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "1", "isAnswerable": False},
                    "Architecture": {"id": "2", "isAnswerable": True},
                    "UX / UI": {"id": "3", "isAnswerable": True},
                    "Ideas": {"id": "4", "isAnswerable": False},
                    "claude-use-only": {"id": "5", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert creates == []  # nothing created — all probed-as-existing.
        assert result.artifacts["dev_repo"]["created_now"] is False
        assert result.artifacts["public_repo"]["created_now"] is False
        assert result.artifacts["docs_repo"]["created_now"] is False

    @pytest.mark.asyncio
    async def test_rejects_empty_owner_or_project_name(self):
        from forge_manager_mcp.adapters import errors as _errs
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(_errs.ForgeError, match="owner"):
            await adapter.bootstrap_project(
                owner=" ", project_name="widgets", description="",
            )
        with pytest.raises(_errs.ForgeError, match="project_name"):
            await adapter.bootstrap_project(
                owner="acme", project_name="", description="",
            )

    @pytest.mark.asyncio
    async def test_enables_discussions_when_disabled(self, monkeypatch):
        """C2 stage 2a — Discussions enable absorption.

        When the dev repo has Discussions disabled, bootstrap_project
        calls enable_discussions then re-fetches state. Pre-fetch
        returns enabled=False, post-enable fetch returns enabled=True
        + the auto-created Announcements category."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            raise _errs.ForgeError("not found")

        async def fake_create_repository(token, *, owner_id, name, **kwargs):
            return {
                "id": f"R_{name}", "name_with_owner": f"acme/{name}",
                "url": f"https://github.com/acme/{name}",
            }

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            return {"id": f"LA_{label_name}"}

        # Discussions state: first call returns disabled, second
        # returns enabled with the four required categories present.
        state_calls = {"count": 0}

        async def fake_get_state(token, repo_id):
            state_calls["count"] += 1
            if state_calls["count"] == 1:
                return {"enabled": False, "categories": {}}
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "DIC_b", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_c", "isAnswerable": True},
                    "Ideas": {"id": "DIC_d", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_e", "isAnswerable": False},
                },
            }

        enable_calls: list[str] = []

        async def fake_enable(token, repo_id):
            enable_calls.append(repo_id)
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert enable_calls == ["R_widgets-dev"]
        assert result.artifacts["discussions"]["enabled"] is True
        assert result.artifacts["discussions"]["enabled_now"] is True
        assert "Architecture" in result.artifacts["discussions"]["categories"]
        # All required categories present + canonical-happy-path stubs
        # → phase=complete after C2 absorption.
        assert result.phase == "complete"
        assert not any("Discussion categories missing" in s for s in result.manual_steps)

    @pytest.mark.asyncio
    async def test_skips_enable_when_discussions_already_on(self, monkeypatch):
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": "x"}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Architecture": {"id": "1", "isAnswerable": True},
                    "UX / UI": {"id": "2", "isAnswerable": True},
                    "Ideas": {"id": "3", "isAnswerable": False},
                    "claude-use-only": {"id": "4", "isAnswerable": False},
                    "Announcements": {"id": "5", "isAnswerable": False},
                },
            }

        enable_called: list[str] = []

        async def fake_enable(token, repo_id):
            enable_called.append(repo_id)
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # enable_discussions NOT called (idempotent — already enabled).
        assert enable_called == []
        assert result.artifacts["discussions"]["enabled_now"] is False

    @pytest.mark.asyncio
    async def test_project_board_created_with_canonical_status_options(
        self, monkeypatch,
    ):
        """C2 stage 2b-i — Project board absorption.

        Fresh-bootstrap path: project doesn't exist, gets created,
        Status field gets read-diff-written from the GitHub default
        (Todo / In Progress / Done) to the canonical
        (Backlog / In Progress / In Review / Done / Parked)."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    n: {"id": f"DIC_{n}", "isAnswerable": False}
                    for n in ("Announcements", "Architecture", "UX / UI",
                              "Ideas", "claude-use-only")
                },
            }

        async def fake_enable(token, repo_id):
            return True

        # Project board: doesn't exist; create returns; GitHub default
        # Status options post-create; update_status replaces with canonical.
        list_calls: list[str] = []
        update_calls: list[tuple[str, list[str]]] = []

        async def fake_list_projects(token, owner_id):
            list_calls.append(owner_id)
            return []

        async def fake_create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 7,
                "url": "https://github.com/orgs/acme/projects/7",
                "title": title,
            }

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def fake_update_status(token, project_id, field_id, desired):
            update_calls.append((field_id, list(desired)))
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # Project board absorbed in artifacts.
        assert "project_board" in result.artifacts
        board = result.artifacts["project_board"]
        assert board["created_now"] is True
        assert board["status_options"]["Backlog"] == "OPT_Backlog"
        assert board["status_options"]["In Progress"] == "OPT_In Progress"
        # update_projectv2_status_options was called with the canonical list.
        assert len(update_calls) == 1
        assert update_calls[0][1] == [
            "Backlog", "In Progress", "In Review", "Done", "Parked",
        ]

    @pytest.mark.asyncio
    async def test_project_board_custom_status_surfaces_manual_step(
        self, monkeypatch,
    ):
        """When a pre-existing board has custom Status options that
        match neither the canonical set nor GitHub's default, surface
        a manual-step note rather than clobbering the operator's
        existing Status assignments."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    n: {"id": f"DIC_{n}", "isAnswerable": False}
                    for n in ("Announcements", "Architecture", "UX / UI",
                              "Ideas", "claude-use-only")
                },
            }

        async def fake_enable(token, repo_id):
            return True

        async def fake_list_projects(token, owner_id):
            # Pre-existing board with custom Status options.
            return [{
                "id": "PVT_existing", "number": 3, "title": "widgets",
                "url": "https://github.com/orgs/acme/projects/3",
            }]

        async def fake_create_project(*args, **kwargs):
            raise AssertionError("should not create — board already exists")

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            # Custom set — not canonical, not GitHub-default.
            return {
                "field_id": "PVTSSF_y",
                "options": {"Active": "1", "Blocked": "2", "Resolved": "3"},
            }

        update_called = False

        async def fake_update_status(*args, **kwargs):
            nonlocal update_called
            update_called = True
            return {}

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert result.artifacts["project_board"]["created_now"] is False
        # update was NOT called — operator state preserved.
        assert update_called is False
        # Manual step explains the custom-options situation.
        joined = "\n".join(result.manual_steps)
        assert "custom Status options" in joined
        assert "⋯ → Settings" in joined

    @pytest.mark.asyncio
    async def test_seeds_discussions_when_existing_state_empty(self, monkeypatch):
        """C2 stage 2b-ii — Project Index + Session Lock Discussions
        seeded when existing_state doesn't carry their IDs."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_announce", "isAnswerable": False},
                    "Architecture": {"id": "DIC_arch", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_ux", "isAnswerable": True},
                    "Ideas": {"id": "DIC_ideas", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_cuo", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        create_discussion_calls: list[tuple[str, str]] = []

        async def fake_create_discussion(token, repo_id, category_id, title, body):
            create_discussion_calls.append((category_id, title))
            return {
                "id": f"D_{title.replace(' ', '_')}",
                "number": len(create_discussion_calls),
                "url": f"https://github.com/x/y/discussions/{len(create_discussion_calls)}",
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", fake_create_discussion)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # Both Discussions seeded under Announcements.
        assert len(create_discussion_calls) == 2
        for category_id, _title in create_discussion_calls:
            assert category_id == "DIC_announce"
        titles = {t for _, t in create_discussion_calls}
        assert "widgets — Project" in titles
        assert "widgets — Session Lock" in titles

        assert result.artifacts["project_discussion_id"] == "D_widgets_—_Project"
        assert result.artifacts["session_lock_discussion_id"] == "D_widgets_—_Session_Lock"
        assert result.artifacts["project_discussion_created_now"] is True
        assert result.artifacts["session_lock_created_now"] is True
        # Phase = complete since no manual_step warnings.
        assert result.phase == "complete"

    @pytest.mark.asyncio
    async def test_seeds_discussions_skipped_when_existing_state_has_ids(
        self, monkeypatch,
    ):
        """When existing_state carries prior project_discussion_id +
        session_lock_discussion_id, the adapter reuses them and
        does NOT call create_discussion. Idempotency-via-state-
        threading from the multi-platform handler."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "1", "isAnswerable": True},
                    "UX / UI": {"id": "2", "isAnswerable": True},
                    "Ideas": {"id": "3", "isAnswerable": False},
                    "claude-use-only": {"id": "4", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        create_called: list[str] = []

        async def fake_create_discussion(*args, **kwargs):
            create_called.append("called")
            return {"id": "D_unexpected", "number": 0, "url": ""}

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", fake_create_discussion)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
            existing_state={
                "github": {
                    "project_discussion_id": "D_PRIOR_Project",
                    "session_lock_discussion_id": "D_PRIOR_SessionLock",
                },
            },
        )

        # No create_discussion calls — both reused from existing_state.
        assert create_called == []
        assert result.artifacts["project_discussion_id"] == "D_PRIOR_Project"
        assert result.artifacts["session_lock_discussion_id"] == "D_PRIOR_SessionLock"
        assert result.artifacts["project_discussion_created_now"] is False
        assert result.artifacts["session_lock_created_now"] is False
        assert result.phase == "complete"

    @pytest.mark.asyncio
    async def test_pauses_when_required_categories_missing(self, monkeypatch):
        """When required Discussion categories are missing, the
        method returns awaiting_manual with copy-pasteable instructions
        naming exactly which categories the operator must create."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": "x"}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            # Only Announcements + Architecture present.
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "1", "isAnswerable": False},
                    "Architecture": {"id": "2", "isAnswerable": True},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert result.phase == "awaiting_manual"
        # Pause-on-categories surfaces the missing names + URL.
        joined = "\n".join(result.manual_steps)
        assert "Discussion categories missing" in joined
        # The missing list explicitly names the three NOT present.
        # Pull it out by parsing — the message has the form
        # "missing on <repo>: <name>, <name>, <name>. ..."
        missing_segment = joined.split("missing on ", 1)[1].split(".", 1)[0]
        assert "UX / UI" in missing_segment
        assert "Ideas" in missing_segment
        assert "claude-use-only" in missing_segment
        assert "Architecture" not in missing_segment  # already present
        assert "Announcements" not in missing_segment  # never required
        assert "/discussions/categories" in joined


class TestDiscussionDelegation:
    """(#428) Drain GitHubAdapter discussion delegation paths."""

    @pytest.mark.asyncio
    async def test_search_issues_marshals_results(self, monkeypatch):
        # (#428) L429-441 — search_issues marshals raw → SearchResult.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "search_issues",
            AsyncMock(return_value={
                "results": [{
                    "id": "I_1", "number": 1, "title": "t",
                    "body": "b", "state": "open",
                    "url": "u", "labels": [], "milestone": None,
                }],
                "total_count": 1,
                "query": "stub",
            }),
        )
        result = await adapter.search_issues(
            owner="o", repo="r", query="stub",
        )
        assert result.total_count == 1
        assert len(result.results) == 1
        assert result.query == "stub"

    @pytest.mark.asyncio
    async def test_list_open_issues_delegates(self, monkeypatch):
        # (#428) L446-449 — list_open_issues delegates + marshals.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_open_issues",
            AsyncMock(return_value=[
                {
                    "id": "I_1", "number": 1, "title": "t",
                    "body": "b", "state": "open",
                    "url": "u", "labels": [], "milestone": None,
                },
            ]),
        )
        result = await adapter.list_open_issues(owner="o", repo="r")
        assert len(result) == 1
        assert result[0].ref.number == 1

    @pytest.mark.asyncio
    async def test_create_discussion_resolves_category(self, monkeypatch):
        # (#428) L478-508 — create_discussion resolves category name →
        # node ID, fetches repo node ID, dispatches, returns Discussion.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(
            token="ghp_test",
            discussion_categories={"Architecture": "DIC_arch"},
        )
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_node_id",
            AsyncMock(return_value="R_repo"),
        )
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "create_discussion",
            AsyncMock(return_value={
                "id": "D_xyz", "number": 5,
                "url": "https://github.com/o/r/discussions/5",
            }),
        )
        result = await adapter.create_discussion(
            owner="o", repo="r", title="T", body="B",
            category="Architecture",
        )
        assert result.ref.number == 5
        assert result.ref.native_id == "D_xyz"
        assert result.category == "Architecture"

    @pytest.mark.asyncio
    async def test_create_discussion_missing_category_raises(self):
        # (#428) L478-481 — category=None → InvalidArtifactRefError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import InvalidArtifactRefError

        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(InvalidArtifactRefError):
            await adapter.create_discussion(
                owner="o", repo="r", title="T", body="B", category=None,
            )

    @pytest.mark.asyncio
    async def test_create_discussion_unknown_category_raises(self):
        # (#428) L482-486 — category not in map → InvalidArtifactRefError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import InvalidArtifactRefError

        adapter = GitHubAdapter(
            token="ghp_test",
            discussion_categories={"Architecture": "DIC_arch"},
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.create_discussion(
                owner="o", repo="r", title="T", body="B",
                category="Unknown",
            )

    @pytest.mark.asyncio
    async def test_get_discussion_raises_not_implemented(self):
        # (#428) L510-516 — get_discussion is unimplemented.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(NotImplementedError):
            await adapter.get_discussion("o", "r", 1)

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates(self, monkeypatch):
        # (#428) L519 — get_discussion_body delegates.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "get_discussion_body",
            AsyncMock(return_value="disc body"),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="D_abc",
            kind="discussion", owner="o", repo="r",
        )
        assert await adapter.get_discussion_body(ref) == "disc body"

    @pytest.mark.asyncio
    async def test_update_discussion_body_delegates(self, monkeypatch):
        # (#428) L524 — update_discussion_body delegates.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "update_discussion_body", stub,
        )
        ref = ArtifactRef(
            platform_id="github", native_id="D_abc",
            kind="discussion", owner="o", repo="r",
        )
        await adapter.update_discussion_body(ref, "new body")
        stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_list_recent_discussions_marshals(self, monkeypatch):
        # (#428) L529-532 — list_recent_discussions marshals raw dicts.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_recent_discussions",
            AsyncMock(return_value=[{
                "id": "D_1", "number": 1,
                "title": "t", "body": "b",
                "state": "OPEN", "category": "Architecture",
                "url": "u", "labels": [],
            }]),
        )
        result = await adapter.list_recent_discussions(owner="o", repo="r")
        assert len(result) == 1
        assert result[0].ref.number == 1

    @pytest.mark.asyncio
    async def test_mark_decided_delegates_to_add_label(self, monkeypatch):
        # (#428) L538 — mark_decided dispatches add_label("decided").
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.github import triage as _gh_triage
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "get_label_id",
            AsyncMock(return_value="LA_decided"),
        )
        add_stub = AsyncMock(return_value=None)
        monkeypatch.setattr(_gh_triage, "add_label_to_issue", add_stub)
        ref = ArtifactRef(
            platform_id="github", native_id="D_abc",
            kind="discussion", owner="o", repo="r",
        )
        await adapter.mark_decided(ref)
        add_stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_mark_answer_delegates(self, monkeypatch):
        # (#428) L540-547 — mark_answer dispatches mark_discussion_answer.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "mark_discussion_answer", stub,
        )
        comment_ref = ArtifactRef(
            platform_id="github", native_id="DC_xyz",
            kind="comment", owner="o", repo="r",
        )
        await adapter.mark_answer(comment_ref)
        stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_mark_answer_wrong_kind_raises(self):
        # (#428) L541-544 — non-comment ref → ValueError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef

        adapter = GitHubAdapter(token="ghp_test")
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="comment"):
            await adapter.mark_answer(ref)


class TestCommentDelegation:
    """(#428) Drain GitHubAdapter comment + label delegation paths."""

    @pytest.mark.asyncio
    async def test_append_comment_to_discussion(self, monkeypatch):
        # (#428) L624-628 — discussion target → add_discussion_comment.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "add_discussion_comment",
            AsyncMock(return_value={
                "id": "DC_xyz",
                "url": "https://github.com/o/r/discussions/1#c1",
                "body": "hello",
            }),
        )
        target = ArtifactRef(
            platform_id="github", native_id="D_abc",
            kind="discussion", owner="o", repo="r",
        )
        result = await adapter.append_comment(target, "hello")
        assert result.ref.native_id == "DC_xyz"

    @pytest.mark.asyncio
    async def test_append_comment_to_issue(self, monkeypatch):
        # (#428) L629-632 — issue target → add_issue_comment.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "add_issue_comment",
            AsyncMock(return_value={
                "id": "IC_xyz",
                "url": "https://github.com/o/r/issues/1#c1",
                "body": "hello",
            }),
        )
        target = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        result = await adapter.append_comment(target, "hello")
        assert result.ref.native_id == "IC_xyz"

    @pytest.mark.asyncio
    async def test_append_comment_wrong_kind_raises(self):
        # (#428) L633-634 — unsupported kind → ValueError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef

        adapter = GitHubAdapter(token="ghp_test")
        ref = ArtifactRef(
            platform_id="github", native_id="X_abc",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="append_comment"):
            await adapter.append_comment(ref, "hello")

    @pytest.mark.asyncio
    async def test_list_comments_discussion(self, monkeypatch):
        # (#428) L644-647 — discussion → get_discussion_comments.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_discussions, "get_discussion_comments",
            AsyncMock(return_value=[
                {"id": "DC_1", "url": "u", "body": "a",
                 "createdAt": "2026-05-12T00:00:00Z"},
            ]),
        )
        target = ArtifactRef(
            platform_id="github", native_id="D_abc",
            kind="discussion", owner="o", repo="r",
        )
        result = await adapter.list_comments(target)
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_list_comments_issue_with_limit(self, monkeypatch):
        # (#428) L649-659 — issue → list_thread_comments + limit slicing.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_thread_comments",
            AsyncMock(return_value=[
                {"id": f"IC_{i}", "url": "u", "body": f"c{i}",
                 "createdAt": "2026-05-12T00:00:00Z"}
                for i in range(5)
            ]),
        )
        target = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        result = await adapter.list_comments(target, limit=2)
        # Limit slices to the last 2.
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_ensure_label_existing(self, monkeypatch):
        # (#428) L675-682 — existing label → return its id without create.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_triage, "find_label_id_or_none",
            AsyncMock(return_value="LA_existing"),
        )
        result = await adapter.ensure_label(owner="o", repo="r", name="bug")
        assert result == "LA_existing"

    @pytest.mark.asyncio
    async def test_ensure_label_create_when_missing(self, monkeypatch):
        # (#428) L683-686 — label missing → create_label dispatches.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_triage, "find_label_id_or_none",
            AsyncMock(return_value=None),
        )
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "create_label",
            AsyncMock(return_value="LA_new"),
        )
        result = await adapter.ensure_label(owner="o", repo="r", name="bug")
        assert result == "LA_new"


class TestProbeAndDriftDelegation:
    """(#428) Drain probe / compute_drift / project-board paths."""

    @pytest.mark.asyncio
    async def test_probe_returns_true_when_graphql_succeeds(self, monkeypatch):
        # (#428) L1228-1231 — successful viewer query → True.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={"viewer": {"login": "test"}}),
        )
        assert await adapter.probe() is True

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_forge_unavailable(self, monkeypatch):
        # (#428) L1232-1233 — ForgeUnavailableError → False.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters import errors as _errors
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(side_effect=_errors.ForgeUnavailableError("down")),
        )
        assert await adapter.probe() is False

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_unexpected_error(self, monkeypatch):
        # (#428) L1234-1237 — other Exception → False (defensive).
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(side_effect=RuntimeError("network")),
        )
        assert await adapter.probe() is False

    @pytest.mark.asyncio
    async def test_compute_drift_returns_clean_stub(self):
        # (#428) L1241-1242 — placeholder returns clean DriftReport.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        adapter = GitHubAdapter(token="ghp_test")
        report = await adapter.compute_drift({})
        assert report.is_clean is True
        assert report.platform_id == "github"


class TestFetchGhArtifactsSince:
    """(#428) Drain _fetch_gh_artifacts_since GraphQL pagination paths."""

    @pytest.mark.asyncio
    async def test_issues_single_page_returns_filtered_nodes(
        self, monkeypatch,
    ):
        # (#428) L1442-1517 — issues path, single page, tail not below
        # since, hasNextPage=False.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={
                "repository": {
                    "issues": {
                        "pageInfo": {
                            "endCursor": None, "hasNextPage": False,
                        },
                        "nodes": [
                            {
                                "id": "I_1", "number": 1,
                                "title": "T", "body": "B",
                                "state": "OPEN",
                                "createdAt": "2026-06-01T00:00:00Z",
                                "updatedAt": "2026-06-01T00:00:00Z",
                                "closedAt": None,
                                "labels": {"nodes": []},
                                "comments": {"nodes": []},
                            },
                        ],
                    },
                },
            }),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        result = await adapter._fetch_gh_artifacts_since(
            owner="o", repo="r", since=since, kind="issues",
        )
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_discussions_path_used_when_kind_is_discussions(
        self, monkeypatch,
    ):
        # (#428) L1470-1486 — discussions branch.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={
                "repository": {
                    "discussions": {
                        "pageInfo": {
                            "endCursor": None, "hasNextPage": False,
                        },
                        "nodes": [],
                    },
                },
            }),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        result = await adapter._fetch_gh_artifacts_since(
            owner="o", repo="r", since=since, kind="discussions",
        )
        assert result == []

    @pytest.mark.asyncio
    async def test_empty_page_breaks_loop(self, monkeypatch):
        # (#428) L1493-1495 — empty nodes page → break.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={
                "repository": {
                    "issues": {
                        "pageInfo": {
                            "endCursor": None, "hasNextPage": True,
                        },
                        "nodes": [],
                    },
                },
            }),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        result = await adapter._fetch_gh_artifacts_since(
            owner="o", repo="r", since=since, kind="issues",
        )
        assert result == []

    @pytest.mark.asyncio
    async def test_pagination_breaks_when_tail_below_since(
        self, monkeypatch,
    ):
        # (#428) L1499-1502 — tail.updatedAt < since → break.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={
                "repository": {
                    "issues": {
                        "pageInfo": {
                            "endCursor": "abc", "hasNextPage": True,
                        },
                        "nodes": [{
                            "id": "I_old", "number": 1,
                            "title": "old", "body": "B",
                            "state": "OPEN",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "updatedAt": "2025-01-01T00:00:00Z",
                            "closedAt": None,
                            "labels": {"nodes": []},
                            "comments": {"nodes": []},
                        }],
                    },
                },
            }),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        result = await adapter._fetch_gh_artifacts_since(
            owner="o", repo="r", since=since, kind="issues",
        )
        # Old item filtered out post-page; result is empty.
        assert result == []

    @pytest.mark.asyncio
    async def test_pagination_breaks_when_no_endcursor(
        self, monkeypatch,
    ):
        # (#428) L1506-1508 — hasNextPage but endCursor missing → break.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import core as _core
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _core, "_graphql",
            AsyncMock(return_value={
                "repository": {
                    "issues": {
                        "pageInfo": {
                            "endCursor": None, "hasNextPage": True,
                        },
                        "nodes": [{
                            "id": "I_1", "number": 1,
                            "title": "T", "body": "B",
                            "state": "OPEN",
                            "createdAt": "2026-06-01T00:00:00Z",
                            "updatedAt": "2026-06-01T00:00:00Z",
                            "closedAt": None,
                            "labels": {"nodes": []},
                            "comments": {"nodes": []},
                        }],
                    },
                },
            }),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        result = await adapter._fetch_gh_artifacts_since(
            owner="o", repo="r", since=since, kind="issues",
        )
        # No endCursor → break after first page.
        assert len(result) == 1


class TestPureHelpers:
    """(#428) Drain pure-helper functions in adapters/github.py."""

    def test_comment_from_dict_invalid_iso_falls_back_to_now(self):
        # (#428) L1606-1608 — bad iso timestamp → datetime.now fallback.
        from forge_manager_mcp.adapters.github import _comment_from_dict
        from forge_manager_mcp.adapters.types import ArtifactRef
        parent = ArtifactRef(
            platform_id="github", native_id="I_1",
            kind="issue", owner="o", repo="r",
        )
        d = {
            "id": "IC_1",
            "createdAt": "not-an-iso",
            "body": "hi",
            "author": "octocat",
        }
        result = _comment_from_dict(d, parent=parent)
        assert result.body == "hi"
        # Falls back to now → tz-aware.
        assert result.created_at is not None

    def test_milestone_from_field_unsupported_type_returns_none(self):
        # (#428) L1644-1645 — non-None/str/dict input returns None.
        from forge_manager_mcp.adapters.github import _milestone_from_field
        assert _milestone_from_field(42) is None
        assert _milestone_from_field([1, 2]) is None

    def test_gh_parse_iso_invalid_string_returns_none(self):
        # (#428) L1662-1663 — invalid iso → ValueError → None.
        from forge_manager_mcp.adapters.github import _gh_parse_iso
        assert _gh_parse_iso("not-an-iso") is None

    def test_gh_parse_iso_naive_datetime_attaches_utc(self):
        # (#428) L1664-1666 — tz-naive parse → attach utc tzinfo.
        from forge_manager_mcp.adapters.github import _gh_parse_iso
        # ISO without tz info.
        dt = _gh_parse_iso("2026-05-12T00:00:00")
        assert dt is not None
        assert dt.tzinfo is not None

    def test_gh_labels_from_raw_non_dict_returns_empty(self):
        # (#428) L1672-1673 — labels field not a dict → [].
        from forge_manager_mcp.adapters.github import _gh_labels_from_raw
        assert _gh_labels_from_raw({"labels": "not a dict"}) == []
        assert _gh_labels_from_raw({"labels": None}) == []


class TestFetchRemoteChanges:
    """(#428) Drain fetch_remote_changes shape-conversion paths."""

    @pytest.mark.asyncio
    async def test_create_issue_shape_when_created_after_since(
        self, monkeypatch,
    ):
        # (#428) L1352-1368 — createdAt >= since → create_issue change.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        async def _fetch(**kw):
            if kw.get("kind") == "issues":
                return [{
                    "id": "I_1", "number": 1,
                    "title": "T", "body": "B",
                    "state": "OPEN",
                    "createdAt": "2026-06-01T00:00:00Z",
                    "updatedAt": "2026-06-01T00:00:00Z",
                    "closedAt": None,
                    "labels": {"nodes": []},
                    "comments": {"nodes": []},
                }]
            return []
        monkeypatch.setattr(adapter, "_fetch_gh_artifacts_since", _fetch)

        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        assert len(changes) == 1
        assert changes[0].operation == "create_issue"
        assert changes[0].ref.kind == "issue"

    @pytest.mark.asyncio
    async def test_close_issue_shape_when_closed_after_since(
        self, monkeypatch,
    ):
        # (#428) L1369-1383 — issue CLOSED + closedAt >= since →
        # close_issue change.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter

        adapter = GitHubAdapter(token="ghp_test")
        async def _fetch(**kw):
            if kw.get("kind") == "issues":
                return [{
                    "id": "I_1", "number": 1,
                    "title": "T", "body": "B",
                    "state": "CLOSED",
                    "createdAt": "2026-04-01T00:00:00Z",
                    "updatedAt": "2026-06-02T00:00:00Z",
                    "closedAt": "2026-06-02T00:00:00Z",
                    "labels": {"nodes": []},
                    "comments": {"nodes": []},
                }]
            return []
        monkeypatch.setattr(adapter, "_fetch_gh_artifacts_since", _fetch)
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        assert len(changes) == 1
        assert changes[0].operation == "close_issue"

    @pytest.mark.asyncio
    async def test_update_body_shape_when_neither_created_nor_closed(
        self, monkeypatch,
    ):
        # (#428) L1384-1393 — default → update_body change.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter

        adapter = GitHubAdapter(token="ghp_test")
        async def _fetch(**kw):
            if kw.get("kind") == "issues":
                return [{
                    "id": "I_1", "number": 1,
                    "title": "T", "body": "B-new",
                    "state": "OPEN",
                    "createdAt": "2026-04-01T00:00:00Z",
                    "updatedAt": "2026-06-02T00:00:00Z",
                    "closedAt": None,
                    "labels": {"nodes": []},
                    "comments": {"nodes": []},
                }]
            return []
        monkeypatch.setattr(adapter, "_fetch_gh_artifacts_since", _fetch)
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        assert len(changes) == 1
        assert changes[0].operation == "update_body"

    @pytest.mark.asyncio
    async def test_comments_after_since_become_add_comment(
        self, monkeypatch,
    ):
        # (#428) L1395-1423 — comments with createdAt >= since →
        # add_comment changes.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter

        adapter = GitHubAdapter(token="ghp_test")
        async def _fetch(**kw):
            if kw.get("kind") == "issues":
                return [{
                    "id": "I_1", "number": 1,
                    "title": "T", "body": "B",
                    "state": "OPEN",
                    "createdAt": "2026-04-01T00:00:00Z",
                    "updatedAt": "2026-04-01T00:00:00Z",
                    "closedAt": None,
                    "labels": {"nodes": []},
                    "comments": {"nodes": [
                        {
                            "id": "IC_x", "createdAt": "2026-06-02T00:00:00Z",
                            "body": "new comment",
                            "author": {"login": "octocat"},
                        },
                        {
                            # Older comment → skipped.
                            "id": "IC_old", "createdAt": "2025-01-01T00:00:00Z",
                            "body": "old", "author": None,
                        },
                    ]},
                }]
            return []
        monkeypatch.setattr(adapter, "_fetch_gh_artifacts_since", _fetch)
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        # 1 update_body for the parent + 1 add_comment for the new one.
        add_comments = [c for c in changes if c.operation == "add_comment"]
        assert len(add_comments) == 1
        assert add_comments[0].payload["author"] == "octocat"

    @pytest.mark.asyncio
    async def test_forge_unavailable_returns_rate_limited_sentinel(
        self, monkeypatch,
    ):
        # (#428) L1331-1332 — ForgeUnavailableError → rate-limited sentinel.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters import errors as _errors
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            adapter, "_fetch_gh_artifacts_since",
            AsyncMock(side_effect=_errors.ForgeUnavailableError("rate")),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        assert len(changes) == 1
        # Sentinel carries the rate-limit marker.
        assert changes[0].operation == "rate_limited" or "rate" in str(
            changes[0].payload
        )

    @pytest.mark.asyncio
    async def test_forge_error_returns_rate_limited_sentinel(
        self, monkeypatch,
    ):
        # (#428) L1333-1334 — ForgeError → rate-limited sentinel.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters import errors as _errors
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            adapter, "_fetch_gh_artifacts_since",
            AsyncMock(side_effect=_errors.ForgeError("error")),
        )
        since = datetime(2026, 5, 1, tzinfo=timezone.utc)
        changes = await adapter.fetch_remote_changes(
            since=since, owner="o", repo="r",
        )
        assert len(changes) == 1


class TestProjectBoardDelegation:
    """(#428) Drain project-board sub-Protocol methods."""

    @pytest.mark.asyncio
    async def test_add_to_project_board_dispatches(self, monkeypatch):
        # (#428) L1253-1259 — successful add → returns project item id.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.github import projects as _projects
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "add_item_to_project",
            AsyncMock(return_value="PVTI_xyz"),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        result = await adapter.add_to_project_board(
            board_id="PVT_board", ref=ref,
        )
        assert result == "PVTI_xyz"

    @pytest.mark.asyncio
    async def test_add_to_project_board_githuberror_wraps(self, monkeypatch):
        # (#428) L1260-1267 — GitHubError → ForgeError normalization.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as _projects
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "add_item_to_project",
            AsyncMock(side_effect=GitHubError("HTTP 403")),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(ForgeError):
            await adapter.add_to_project_board(
                board_id="PVT_board", ref=ref,
            )

    @pytest.mark.asyncio
    async def test_get_project_status_field_delegates(self, monkeypatch):
        # (#428) L1269-1275 — delegates + returns dict.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import projects as _projects
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "get_project_status_field",
            AsyncMock(return_value={
                "field_id": "PVTSSF_xyz",
                "options": {"In Progress": "opt_ip"},
            }),
        )
        result = await adapter.get_project_status_field(board_id="b1")
        assert result["field_id"] == "PVTSSF_xyz"

    @pytest.mark.asyncio
    async def test_get_project_status_field_githuberror_wraps(
        self, monkeypatch,
    ):
        # (#428) L1276-1277 — GitHubError → ForgeError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as _projects
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "get_project_status_field",
            AsyncMock(side_effect=GitHubError("HTTP 401")),
        )
        with pytest.raises(ForgeError):
            await adapter.get_project_status_field(board_id="b1")

    @pytest.mark.asyncio
    async def test_get_project_item_id_delegates(self, monkeypatch):
        # (#428) L1279-1285 — delegates returning item id.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.github import projects as _projects
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "get_project_item_id",
            AsyncMock(return_value="PVTI_x"),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        result = await adapter.get_project_item_id(
            ref=ref, board_id="b1",
        )
        assert result == "PVTI_x"

    @pytest.mark.asyncio
    async def test_get_project_item_id_githuberror_wraps(self, monkeypatch):
        # (#428) L1286-1287 — GitHubError → ForgeError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as _projects
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "get_project_item_id",
            AsyncMock(side_effect=GitHubError("HTTP 429")),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(ForgeError):
            await adapter.get_project_item_id(ref=ref, board_id="b1")

    @pytest.mark.asyncio
    async def test_move_project_item_delegates(self, monkeypatch):
        # (#428) L1289-1296 — delegates without return value.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import projects as _projects
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(_projects, "move_project_item", stub)
        await adapter.move_project_item(
            board_id="b1", item_id="i1",
            status_field_id="s1", option_id="o1",
        )
        stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_move_project_item_githuberror_wraps(self, monkeypatch):
        # (#428) L1297-1298 — GitHubError → ForgeError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as _projects
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _projects, "move_project_item",
            AsyncMock(side_effect=GitHubError("HTTP 500")),
        )
        with pytest.raises(ForgeError):
            await adapter.move_project_item(
                board_id="b1", item_id="i1",
                status_field_id="s1", option_id="o1",
            )


class TestSyntheticHelpers:
    """(#428) Synthetic identity helpers on GitHubAdapter."""

    def test_get_clone_url_returns_https_form(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        adapter = GitHubAdapter(token="ghp_test")
        assert (
            adapter.get_clone_url("o", "r")
            == "https://github.com/o/r.git"
        )

    def test_noreply_email_post_2017_form_with_user_id(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        adapter = GitHubAdapter(token="ghp_test")
        email = adapter.noreply_email("octocat", user_id=42)
        assert email == "42+octocat@users.noreply.github.com"

    def test_noreply_email_legacy_form_without_user_id(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        adapter = GitHubAdapter(token="ghp_test")
        email = adapter.noreply_email("octocat")
        assert email == "octocat@users.noreply.github.com"


class TestReleaseAndPublicHelpers:
    """(#428) Drain GitHubAdapter release page + public-issue helpers."""

    @pytest.mark.asyncio
    async def test_create_release_writes_notes_and_dispatches(
        self, monkeypatch,
    ):
        # (#428) L717-751 — create_release writes notes to temp + calls
        # gh CLI helper + returns Release shape.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")
        # Stub the synchronous helper.
        monkeypatch.setattr(
            _releases, "create_github_release",
            lambda **kw: "https://github.com/o/r/releases/tag/v1.0.0",
        )
        result = await adapter.create_release(
            owner="o", repo="r", tag="v1.0.0",
            name="v1.0.0", body="notes body",
        )
        assert result.tag == "v1.0.0"
        assert result.url == "https://github.com/o/r/releases/tag/v1.0.0"
        assert result.body == "notes body"

    @pytest.mark.asyncio
    async def test_create_release_unlink_oserror_swallowed(
        self, monkeypatch, tmp_path,
    ):
        # (#428) L740-744 — notes_path.unlink() raises OSError → except: pass.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases
        from pathlib import Path

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _releases, "create_github_release",
            lambda **kw: "https://github.com/o/r/releases/tag/v1.0.0",
        )
        # Force Path.unlink to raise.
        original_unlink = Path.unlink
        def _fail_unlink(self, *a, **kw):
            raise OSError("simulated unlink failure")
        monkeypatch.setattr(Path, "unlink", _fail_unlink)

        result = await adapter.create_release(
            owner="o", repo="r", tag="v1.0.0",
            name="v1.0.0", body="notes",
        )
        # Despite the cleanup failure, the release still returned ok.
        assert result.tag == "v1.0.0"

    def test_public_issue_url_regex_matches_github_issue_urls(self):
        # (#428) L772-777 — regex matches standard GitHub issue URLs.
        from forge_manager_mcp.adapters.github import GitHubAdapter

        adapter = GitHubAdapter(token="ghp_test")
        pattern = adapter.public_issue_url_regex()
        m = pattern.match("https://github.com/owner/repo/issues/42")
        assert m is not None
        assert m.group(1) == "owner"
        assert m.group(2) == "repo"
        assert m.group(3) == "42"

    @pytest.mark.asyncio
    async def test_delete_release_calls_gh_cli(self, monkeypatch):
        # (#428) L788-801 — delete_release dispatches gh release delete.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")
        called = {}

        def _run(cmd, cwd=None, timeout=None):
            called["cmd"] = cmd
            return None  # success

        monkeypatch.setattr(_releases, "_run", _run)
        await adapter.delete_release(owner="o", repo="r", tag="v1.0.0")
        assert "delete" in called["cmd"]
        assert "v1.0.0" in called["cmd"]

    @pytest.mark.asyncio
    async def test_delete_release_swallows_not_found(self, monkeypatch):
        # (#428) L802-806 — CalledProcessError with "not found" in
        # stderr → idempotent no-op.
        import subprocess
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")

        def _run(cmd, cwd=None, timeout=None):
            exc = subprocess.CalledProcessError(1, cmd)
            exc.stderr = "release not found\n"
            raise exc

        monkeypatch.setattr(_releases, "_run", _run)
        # Should not raise.
        await adapter.delete_release(owner="o", repo="r", tag="v9.9.9")

    @pytest.mark.asyncio
    async def test_delete_release_release_command_error_not_found(
        self, monkeypatch,
    ):
        # (#428) L807-811 — ReleaseCommandError with "not found" →
        # idempotent no-op.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")

        def _run(cmd, cwd=None, timeout=None):
            raise _releases.ReleaseCommandError(
                cmd, 1, "release not found",
            )

        monkeypatch.setattr(_releases, "_run", _run)
        # Should not raise.
        await adapter.delete_release(owner="o", repo="r", tag="v9.9.9")

    @pytest.mark.asyncio
    async def test_fetch_file_content_delegates(self, monkeypatch):
        # (#428) L820-822 — fetch_file_content delegates to resolvers.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import resolvers as _resolvers
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _resolvers, "get_file_content",
            AsyncMock(return_value="content"),
        )
        result = await adapter.fetch_file_content(
            owner="o", repo="r", path="path.md",
        )
        assert result == "content"


class TestMilestoneGapArtifactsNotImplemented:
    """(#428) GitHubAdapter milestone/gap artifact methods all raise
    NotImplementedError (has_milestone_artifacts / has_gap_artifacts = False)."""

    @pytest.mark.asyncio
    async def test_create_milestone(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError, match="milestone"):
            await GitHubAdapter(token="x").create_milestone()

    @pytest.mark.asyncio
    async def test_get_milestone_body(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").get_milestone_body("1.0.0")

    @pytest.mark.asyncio
    async def test_update_milestone_state(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").update_milestone_state(
                "1.0.0", "open",
            )

    @pytest.mark.asyncio
    async def test_update_milestone_meta(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").update_milestone_meta(
                "1.0.0", tier="patch",
            )

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").list_all_milestone_versions()

    @pytest.mark.asyncio
    async def test_upsert_gap(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError, match="gap"):
            await GitHubAdapter(token="x").upsert_gap()

    @pytest.mark.asyncio
    async def test_get_gap_body(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").get_gap_body("cat")

    @pytest.mark.asyncio
    async def test_update_gap_state(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").update_gap_state(
                "cat", "triage",
            )

    @pytest.mark.asyncio
    async def test_update_gap_meta(self):
        # (#428) L610-613.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").update_gap_meta("cat", tier="x")

    @pytest.mark.asyncio
    async def test_list_gap_categories(self):
        # (#428) L615-618.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        with pytest.raises(NotImplementedError):
            await GitHubAdapter(token="x").list_gap_categories()


class TestIssueWriteDelegation:
    """(#428) Drain GitHubAdapter issue-write delegation paths."""

    @pytest.mark.asyncio
    async def test_close_issue_returns_canonical_shape(self, monkeypatch):
        # (#428) L380-401 — close_issue parses closed_at + returns Issue.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "close_issue",
            AsyncMock(return_value={
                "url": "https://github.com/o/r/issues/1",
                "closed_at": "2026-05-12T00:00:00Z",
            }),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=1,
        )
        result = await adapter.close_issue(ref)
        assert result.state == "closed"
        assert result.url == "https://github.com/o/r/issues/1"

    @pytest.mark.asyncio
    async def test_close_issue_invalid_closed_at_falls_back(self, monkeypatch):
        # (#428) L386-393 — bad ISO timestamp → datetime.now fallback.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "close_issue",
            AsyncMock(return_value={
                "url": "u", "closed_at": "not-an-iso",
            }),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=1,
        )
        result = await adapter.close_issue(ref)
        assert result.state == "closed"
        # Falls back to now; just verify it's set.
        assert result.updated_at is not None

    @pytest.mark.asyncio
    async def test_close_issue_no_closed_at_uses_now(self, monkeypatch):
        # (#428) L392-393 — no closed_at field → datetime.now.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "close_issue",
            AsyncMock(return_value={"url": "u"}),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=1,
        )
        result = await adapter.close_issue(ref)
        assert result.state == "closed"
        assert result.updated_at is not None

    @pytest.mark.asyncio
    async def test_add_label_resolves_id_and_dispatches(self, monkeypatch):
        # (#428) L405-409 — get_label_id then add_label_to_issue.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from forge_manager_mcp.github import triage as _gh_triage
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "get_label_id",
            AsyncMock(return_value="LA_xyz"),
        )
        add_stub = AsyncMock(return_value=None)
        monkeypatch.setattr(_gh_triage, "add_label_to_issue", add_stub)
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=1,
        )
        await adapter.add_label(ref, "bug")
        add_stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_remove_label_raises_not_implemented(self):
        # (#428) L411-416 — remove_label is unimplemented.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef

        adapter = GitHubAdapter(token="ghp_test")
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=1,
        )
        with pytest.raises(NotImplementedError, match="remove_label"):
            await adapter.remove_label(ref, "bug")

    @pytest.mark.asyncio
    async def test_get_file_content_delegates(self, monkeypatch):
        # (#428) L365-370 — get_file_content delegates to resolvers.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import resolvers as _resolvers
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _resolvers, "get_file_content",
            AsyncMock(return_value="file contents"),
        )
        result = await adapter.get_file_content("o", "r", "main", "path.md")
        assert result == "file contents"

    @pytest.mark.asyncio
    async def test_get_file_content_githuberror_wraps(self, monkeypatch):
        # (#428) L369-370 — GitHubError → ForgeError.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import resolvers as _resolvers
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _resolvers, "get_file_content",
            AsyncMock(side_effect=GitHubError("HTTP 403")),
        )
        with pytest.raises(ForgeError):
            await adapter.get_file_content("o", "r", "main", "path.md")


class TestRepoLevelReadDelegation:
    """(#428) Drain GitHubAdapter delegation methods — adapter calls the
    underlying github.* helpers; unit tests mock the helper layer."""

    @pytest.mark.asyncio
    async def test_get_repo_node_id_delegates(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value="R_node_xyz")
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_node_id", stub,
        )
        result = await adapter.get_repo_node_id("owner", "repo")
        assert result == "R_node_xyz"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_delegates(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value="PUBLIC")
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_visibility", stub,
        )
        result = await adapter.get_repo_visibility("owner", "repo")
        assert result == "PUBLIC"

    @pytest.mark.asyncio
    async def test_list_all_issue_numbers_delegates(self, monkeypatch):
        # (#428) Drain list_all_issue_numbers — also confirms the
        # `_s.` → `_gh_recovery.` name fix in adapters/github.py.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=[1, 2, 3])
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_all_issue_numbers", stub,
        )
        result = await adapter.list_all_issue_numbers("o", "r")
        assert result == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_list_all_discussion_numbers_delegates(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=[10, 20])
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_all_discussion_numbers", stub,
        )
        result = await adapter.list_all_discussion_numbers("o", "r")
        assert result == [10, 20]

    @pytest.mark.asyncio
    async def test_list_milestones_marshals_results(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=[
            {
                "number": 1, "title": "1.0.0", "state": "open",
                "url": "https://github.com/o/r/milestone/1",
                "open_issues": [], "closed_issues": [],
            },
        ])
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_milestones_with_progress", stub,
        )
        result = await adapter.list_milestones("o", "r")
        assert len(result) == 1
        assert result[0].number == 1
        assert result[0].title == "1.0.0"

    @pytest.mark.asyncio
    async def test_find_milestone_by_number(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_milestones_with_progress",
            AsyncMock(return_value=[{
                "number": 42, "title": "1.0.0", "state": "open",
                "url": "https://github.com/o/r/milestone/42",
                "open_issues": [], "closed_issues": [],
            }]),
        )
        result = await adapter.find_milestone("o", "r", 42)
        assert result is not None
        assert result.number == 42

    @pytest.mark.asyncio
    async def test_find_milestone_by_number_no_match(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_milestones_with_progress",
            AsyncMock(return_value=[]),
        )
        result = await adapter.find_milestone("o", "r", 999)
        assert result is None

    @pytest.mark.asyncio
    async def test_find_milestone_by_title(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "get_milestone_by_title",
            AsyncMock(return_value={
                "number": 5, "title": "2.0.0", "state": "open",
                "url": "https://github.com/o/r/milestone/5",
                "open_issues": [], "closed_issues": [],
            }),
        )
        result = await adapter.find_milestone("o", "r", "2.0.0")
        assert result is not None
        assert result.title == "2.0.0"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_githuberror_wraps_to_forge_error(
        self, monkeypatch,
    ):
        # (#428) L332-333 — GitHubError → _to_forge_error normalization.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_visibility",
            AsyncMock(side_effect=GitHubError("HTTP 403")),
        )
        with pytest.raises(ForgeError):
            await adapter.get_repo_visibility("o", "r")

    @pytest.mark.asyncio
    async def test_list_all_issue_numbers_githuberror_wraps(
        self, monkeypatch,
    ):
        # (#428) L342-343 — same pattern for list_all_issue_numbers.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_all_issue_numbers",
            AsyncMock(side_effect=GitHubError("HTTP 401")),
        )
        with pytest.raises(ForgeError):
            await adapter.list_all_issue_numbers("o", "r")

    @pytest.mark.asyncio
    async def test_list_all_discussion_numbers_githuberror_wraps(
        self, monkeypatch,
    ):
        # (#428) L352-353 — same for list_all_discussion_numbers.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "list_all_discussion_numbers",
            AsyncMock(side_effect=GitHubError("HTTP 429")),
        )
        with pytest.raises(ForgeError):
            await adapter.list_all_discussion_numbers("o", "r")

    @pytest.mark.asyncio
    async def test_get_issue_body_delegates(self, monkeypatch):
        # (#428) L314 — get_issue_body passes ref.native_id verbatim.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "get_issue_body",
            AsyncMock(return_value="body text"),
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        assert await adapter.get_issue_body(ref) == "body text"

    @pytest.mark.asyncio
    async def test_update_issue_body_delegates(self, monkeypatch):
        # (#428) L320 — update_issue_body forwards to gh_issues.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import ArtifactRef
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_issues, "update_issue_body", stub,
        )
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r",
        )
        await adapter.update_issue_body(ref, "new body")
        stub.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_get_issue_by_number_searches_and_returns(
        self, monkeypatch,
    ):
        # (#428) L298-307 — get_issue uses recovery.search_issues
        # then matches the number.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "search_issues",
            AsyncMock(return_value={
                "results": [{
                    "id": "I_xyz", "number": 42,
                    "title": "found", "body": "b",
                    "state": "open",
                    "url": "https://github.com/o/r/issues/42",
                    "labels": [], "milestone": None,
                }],
            }),
        )
        result = await adapter.get_issue("o", "r", 42)
        assert result.ref.number == 42
        assert result.title == "found"

    @pytest.mark.asyncio
    async def test_get_issue_by_number_not_found_raises(
        self, monkeypatch,
    ):
        # (#428) L308 — number not in results → InvalidArtifactRefError.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import InvalidArtifactRefError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "search_issues",
            AsyncMock(return_value={"results": []}),
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue("o", "r", 42)

    @pytest.mark.asyncio
    async def test_find_milestone_by_title_not_found(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock
        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "get_milestone_by_title",
            AsyncMock(return_value=None),
        )
        result = await adapter.find_milestone("o", "r", "missing")
        assert result is None


class TestDeleteReleaseReraisePaths:
    """(#428) L806 + L811 — delete_release re-raises when stderr/msg
    does NOT contain 'not found'."""

    @pytest.mark.asyncio
    async def test_called_process_error_other_stderr_reraises(
        self, monkeypatch,
    ):
        # (#428) L802-806 — CalledProcessError with stderr that does
        # NOT match "not found" should re-raise.
        import subprocess
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")

        def _run(cmd, cwd=None, timeout=None):
            exc = subprocess.CalledProcessError(1, cmd)
            exc.stderr = "rate limit exceeded"
            raise exc

        monkeypatch.setattr(_releases, "_run", _run)
        with pytest.raises(subprocess.CalledProcessError):
            await adapter.delete_release(owner="o", repo="r", tag="v1.0.0")

    @pytest.mark.asyncio
    async def test_release_command_error_other_msg_reraises(
        self, monkeypatch,
    ):
        # (#428) L807-811 — ReleaseCommandError without "not found" → re-raise.
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import releases as _releases

        adapter = GitHubAdapter(token="ghp_test")

        def _run(cmd, cwd=None, timeout=None):
            raise _releases.ReleaseCommandError(cmd, 1, "permission denied")

        monkeypatch.setattr(_releases, "_run", _run)
        with pytest.raises(_releases.ReleaseCommandError):
            await adapter.delete_release(owner="o", repo="r", tag="v1.0.0")


class TestBundleRecoverContextHappyPath:
    """(#428) L840-857 — bundle_recover_context delegates to recovery
    helper and converts the raw shape into a RecoveryBundle."""

    @pytest.mark.asyncio
    async def test_bundle_recover_context_happy_path(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import RecoveryBundle
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        raw = {
            "toc_body": "TOC body content",
            "open_issues": [
                {
                    "number": 1, "title": "issue-1", "body": "b1",
                    "state": "open", "url": "u1", "labels": [],
                    "assignees": [], "author": "a", "created_at": "t",
                    "updated_at": "t", "milestone": None, "node_id": "n1",
                },
            ],
            "recent_discussions": [
                {
                    "number": 2, "title": "disc-2", "body": "b2",
                    "url": "u2", "category": "General", "author": "a",
                    "created_at": "t", "updated_at": "t", "node_id": "n2",
                    "labels": [],
                },
            ],
            "milestones": [
                {
                    "number": 3, "title": "v1.0", "state": "open",
                    "open_issues": 1, "closed_issues": 0,
                },
            ],
        }
        monkeypatch.setattr(
            _gh_adapter._gh_recovery, "fetch_recover_context_bundle",
            AsyncMock(return_value=raw),
        )
        result = await adapter.bundle_recover_context(
            owner="o", repo="r", toc_discussion_id="D_1",
            since_days=14, issue_limit=50,
        )
        assert isinstance(result, RecoveryBundle)
        assert result.toc_body == "TOC body content"
        assert len(result.open_issues) == 1
        assert result.open_issues[0].ref.number == 1
        assert len(result.recent_discussions) == 1
        assert result.recent_discussions[0].ref.number == 2
        assert len(result.milestones) == 1
        assert result.milestones[0].number == 3


class TestBootstrapAnnouncementsMissing:
    """(#428) L1024-1040 — when Announcements category is missing
    from a freshly-discussions-enabled repo, bootstrap surfaces a
    manual_step and returns awaiting_manual phase."""

    @pytest.mark.asyncio
    async def test_announcements_category_missing(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import BootstrapResult
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        # Org exists
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "get_organization_id",
            AsyncMock(return_value="ORG_NODE"),
        )
        # _ensure_repo: probe returns node ids → repos already exist
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_node_id",
            AsyncMock(side_effect=lambda token, owner, name: f"R_{name}"),
        )
        # _seed_labels: noop
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "create_label",
            AsyncMock(return_value={"id": "L1"}),
        )
        # Discussions state: enabled, all REQUIRED categories present, but
        # NO Announcements (so we pass the missing_categories check at L973
        # but trip the announcements_id check at L1024).
        cats = {
            "Architecture": {"id": "C_arch"},
            "UX / UI": {"id": "C_ux"},
            "Ideas": {"id": "C_ideas"},
            "claude-use-only": {"id": "C_claude"},
        }
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "get_repo_discussions_state",
            AsyncMock(return_value={"enabled": True, "categories": cats}),
        )
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "enable_discussions",
            AsyncMock(return_value=None),
        )
        # _ensure_project_board returns no manual_step
        async def _board(**kwargs):
            return {"id": "PB1", "number": 1, "url": "u",
                    "status_field_id": "F1", "status_options": {},
                    "created_now": False}, None
        monkeypatch.setattr(adapter, "_ensure_project_board", _board)

        result = await adapter.bootstrap_project(
            owner="o", project_name="proj", description="d",
        )
        assert isinstance(result, BootstrapResult)
        assert result.phase == "awaiting_manual"
        assert any(
            "Announcements" in s for s in result.manual_steps
        )


class TestEnsureProjectBoardStatusOptionsAlreadyCorrect:
    """(#428) L1140-1141 — _ensure_project_board no-ops when current
    Status options already match the desired STATUS_OPTIONS set."""

    @pytest.mark.asyncio
    async def test_already_correct_options_no_update(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.github import projects as _projects
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        # Existing project with matching title.
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "list_owner_projects",
            AsyncMock(return_value=[
                {"id": "PB1", "number": 1, "title": "proj",
                 "url": "https://example.com/proj"},
            ]),
        )
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "link_projectv2_to_repo",
            AsyncMock(return_value=None),
        )
        # status_field options EXACTLY match STATUS_OPTIONS → L1141 fires.
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "get_project_status_field",
            AsyncMock(return_value={
                "field_id": "F1",
                "options": {name: f"OPT_{name}" for name in _projects.STATUS_OPTIONS},
            }),
        )
        # update should NOT be called.
        update_mock = AsyncMock(return_value={"field_id": "F1", "options": {}})
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "update_projectv2_status_options",
            update_mock,
        )
        descriptor, manual_step = await adapter._ensure_project_board(
            org_id="ORG", project_title="proj",
            dev_repo_id="R_dev", public_repo_id="R_pub",
        )
        assert descriptor["id"] == "PB1"
        assert manual_step is None
        assert update_mock.await_count == 0


class TestSeedLabelsExceptionSwallow:
    """(#428) L1219-1220 — _seed_labels swallows ForgeError/ValueError
    on individual create_label failures (idempotency)."""

    @pytest.mark.asyncio
    async def test_seed_labels_swallows_existing_label(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")

        # First call raises ForgeError, second raises ValueError, rest succeed.
        call_count = {"n": 0}

        async def _create(token, repo_id, name, color, desc):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise ForgeError("label already exists")
            if call_count["n"] == 2:
                raise ValueError("validation failed")
            return {"id": f"L{call_count['n']}"}

        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "create_label", _create,
        )
        # Call private method directly
        created = await adapter._seed_labels("R_id")
        # First two raised → not in created list
        # Subsequent calls succeed; created should equal the rest
        # of _GITHUB_STANDARD_LABELS minus the first two.
        from forge_manager_mcp.adapters.github import _GITHUB_STANDARD_LABELS
        expected = [name for name, _, _ in _GITHUB_STANDARD_LABELS[2:]]
        assert created == expected


class TestEnsureRepoExceptionFallback:
    """(#428) L1188-1194 — _ensure_repo's broad `except Exception: pass`
    catches the un-renamed GitHubError and proceeds to create."""

    @pytest.mark.asyncio
    async def test_ensure_repo_generic_exception_falls_through_to_create(
        self, monkeypatch,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")

        # Probe raises a generic Exception (not ForgeError) — should be caught
        # by the broad except.
        async def _probe(token, owner, name):
            raise RuntimeError("legacy GitHubError shape")

        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "get_repo_node_id", _probe,
        )
        monkeypatch.setattr(
            _gh_adapter._gh_scaffold, "create_repository",
            AsyncMock(return_value={
                "id": "R_NEW",
                "name_with_owner": "o/r",
                "url": "https://github.com/o/r",
            }),
        )
        descriptor = await adapter._ensure_repo(
            owner="o", org_id="ORG", name="r",
            visibility="PUBLIC", description="d",
        )
        assert descriptor["id"] == "R_NEW"
        assert descriptor["created_now"] is True


# (#458 / 3.13.0 D-Friction.1) set_visibility — Protocol method + consent gate.


class TestGitHubAdapterSetVisibility:
    """set_visibility raises ConsentRequiredError when caller doesn't
    pass explicit consent; otherwise delegates to set_repo_visibility.
    """

    @pytest.mark.asyncio
    async def test_consent_false_raises_without_network_call(
        self, monkeypatch,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ConsentRequiredError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        # Stub set_repo_visibility — should NOT be called when consent
        # is false.
        stub = AsyncMock()
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "set_repo_visibility", stub,
        )

        with pytest.raises(ConsentRequiredError, match="consent"):
            await adapter.set_visibility(
                owner="o", repo="r", target="private",
                confirmed_consequences=False,
            )
        # Critical: the network call must not have fired.
        stub.assert_not_called()

    @pytest.mark.asyncio
    async def test_consent_true_delegates_to_resolver(
        self, monkeypatch,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "set_repo_visibility", stub,
        )

        await adapter.set_visibility(
            owner="o", repo="r", target="private",
            confirmed_consequences=True,
        )
        stub.assert_awaited_once_with(
            "ghp_test", "o", "r", target="private",
        )

    @pytest.mark.asyncio
    async def test_consent_true_target_public_delegates(
        self, monkeypatch,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "set_repo_visibility", stub,
        )
        await adapter.set_visibility(
            owner="o", repo="r", target="public",
            confirmed_consequences=True,
        )
        stub.assert_awaited_once_with(
            "ghp_test", "o", "r", target="public",
        )

    @pytest.mark.asyncio
    async def test_githuberror_wraps_to_forge_error(self, monkeypatch):
        # Matches the existing add_to_project_board / get_repo_visibility
        # error-wrap pattern. GitHubError raised by the resolver wraps
        # to ForgeError so adapter-Protocol callers can catch a single
        # canonical exception type.
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        adapter = GitHubAdapter(token="ghp_test")
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers, "set_repo_visibility",
            AsyncMock(side_effect=GitHubError("HTTP 422")),
        )
        with pytest.raises(ForgeError):
            await adapter.set_visibility(
                owner="o", repo="r", target="private",
                confirmed_consequences=True,
            )


class TestSetRepoVisibilityHelper:
    """Direct unit tests on the github/resolvers.py helper."""

    @pytest.mark.asyncio
    async def test_rejects_empty_owner_repo(self):
        from forge_manager_mcp.github.resolvers import set_repo_visibility
        with pytest.raises(ValueError, match="owner and repo"):
            await set_repo_visibility("tok", "", "r", target="private")
        with pytest.raises(ValueError, match="owner and repo"):
            await set_repo_visibility("tok", "o", "", target="private")

    @pytest.mark.asyncio
    async def test_rejects_invalid_target(self):
        from forge_manager_mcp.github.resolvers import set_repo_visibility
        with pytest.raises(ValueError, match="target must be"):
            await set_repo_visibility(
                "tok", "o", "r", target="internal",
            )

    @pytest.mark.asyncio
    async def test_private_target_sends_private_true(self, monkeypatch):
        # PATCH payload should have private=true + the consent flag.
        from forge_manager_mcp.github import resolvers as _r
        from unittest.mock import AsyncMock, MagicMock

        captured: dict = {}

        class _Resp:
            status_code = 200
            text = "{}"

        async def _patch(url, headers=None, json=None):
            captured["url"] = url
            captured["json"] = json
            return _Resp()

        fake_client = MagicMock()
        fake_client.patch = _patch
        monkeypatch.setattr(_r, "_get_client", lambda: fake_client)

        await _r.set_repo_visibility(
            "tok", "owner", "repo", target="private",
        )
        assert captured["url"] == "https://api.github.com/repos/owner/repo"
        assert captured["json"]["private"] is True
        assert captured["json"]["accept_visibility_change_consequences"] is True

    @pytest.mark.asyncio
    async def test_public_target_sends_private_false(self, monkeypatch):
        from forge_manager_mcp.github import resolvers as _r
        from unittest.mock import AsyncMock, MagicMock

        captured: dict = {}

        class _Resp:
            status_code = 200
            text = "{}"

        async def _patch(url, headers=None, json=None):
            captured["json"] = json
            return _Resp()

        fake_client = MagicMock()
        fake_client.patch = _patch
        monkeypatch.setattr(_r, "_get_client", lambda: fake_client)

        await _r.set_repo_visibility(
            "tok", "o", "r", target="public",
        )
        assert captured["json"]["private"] is False

    @pytest.mark.asyncio
    async def test_non_2xx_raises_github_error(self, monkeypatch):
        from forge_manager_mcp.github import resolvers as _r
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import MagicMock

        class _Resp:
            status_code = 422
            text = '{"message": "consent missing"}'

        async def _patch(url, headers=None, json=None):
            return _Resp()

        fake_client = MagicMock()
        fake_client.patch = _patch
        monkeypatch.setattr(_r, "_get_client", lambda: fake_client)

        with pytest.raises(GitHubError, match="HTTP 422"):
            await _r.set_repo_visibility(
                "tok", "o", "r", target="private",
            )


# (#460 / 3.13.0 D-Friction.5) attach_release_artifact + binary upload helper.


class TestGitHubAdapterAttachReleaseArtifact:
    """Binary uploads delegate to upload_release_asset_binary; link
    refs raise NotImplementedError (GitHub has no link-ref API).
    """

    def _make_release_ref(self):
        from forge_manager_mcp.adapters.types import ArtifactRef
        return ArtifactRef(
            platform_id="github",
            native_id="123456",  # release_id
            kind="release",
            owner="owner",
            repo="repo",
            number=None,
        )

    @pytest.mark.asyncio
    async def test_binary_upload_delegates_to_resolver(
        self, monkeypatch, tmp_path,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import BinaryUpload
        from unittest.mock import AsyncMock

        asset = tmp_path / "release.tar.gz"
        asset.write_bytes(b"binary content")

        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers,
            "upload_release_asset_binary",
            stub,
        )

        adapter = GitHubAdapter(token="ghp_test")
        await adapter.attach_release_artifact(
            release_ref=self._make_release_ref(),
            artifact=BinaryUpload(
                path=str(asset),
                content_type="application/gzip",
            ),
        )
        stub.assert_awaited_once()
        call_args = stub.await_args
        # Positional: (token, owner, repo)
        assert call_args.args == ("ghp_test", "owner", "repo")
        # Keyword args carry the release-specific fields.
        kw = call_args.kwargs
        assert kw["release_id"] == "123456"
        assert kw["asset_path"] == str(asset)
        assert kw["content_type"] == "application/gzip"
        # name defaults to basename(path).
        assert kw["name"] == "release.tar.gz"

    @pytest.mark.asyncio
    async def test_binary_upload_explicit_name_overrides_basename(
        self, monkeypatch, tmp_path,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import BinaryUpload
        from unittest.mock import AsyncMock

        asset = tmp_path / "internal-name.tar.gz"
        asset.write_bytes(b"x")
        stub = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers,
            "upload_release_asset_binary",
            stub,
        )

        adapter = GitHubAdapter(token="ghp_test")
        await adapter.attach_release_artifact(
            release_ref=self._make_release_ref(),
            artifact=BinaryUpload(
                path=str(asset),
                name="display-name.tar.gz",
            ),
        )
        kw = stub.await_args.kwargs
        assert kw["name"] == "display-name.tar.gz"

    @pytest.mark.asyncio
    async def test_link_reference_raises_not_implemented(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.types import LinkReference

        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(NotImplementedError, match="link-reference"):
            await adapter.attach_release_artifact(
                release_ref=self._make_release_ref(),
                artifact=LinkReference(
                    url="https://example.org/asset.tar.gz",
                    name="external",
                ),
            )

    @pytest.mark.asyncio
    async def test_invalid_artifact_type_raises_type_error(self):
        from forge_manager_mcp.adapters.github import GitHubAdapter

        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(TypeError, match="BinaryUpload or LinkReference"):
            await adapter.attach_release_artifact(
                release_ref=self._make_release_ref(),
                artifact="not a valid artifact",  # wrong type
            )

    @pytest.mark.asyncio
    async def test_githuberror_wraps_to_forge_error(
        self, monkeypatch, tmp_path,
    ):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.adapters.types import BinaryUpload
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import AsyncMock

        asset = tmp_path / "a.bin"
        asset.write_bytes(b"x")
        monkeypatch.setattr(
            _gh_adapter._gh_resolvers,
            "upload_release_asset_binary",
            AsyncMock(side_effect=GitHubError("HTTP 401")),
        )
        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(ForgeError):
            await adapter.attach_release_artifact(
                release_ref=self._make_release_ref(),
                artifact=BinaryUpload(path=str(asset)),
            )


class TestUploadReleaseAssetBinaryHelper:
    @pytest.mark.asyncio
    async def test_rejects_empty_args(self, tmp_path):
        from forge_manager_mcp.github.resolvers import (
            upload_release_asset_binary,
        )
        asset = tmp_path / "a.bin"
        asset.write_bytes(b"x")
        # Each blank arg surfaces a clear error.
        with pytest.raises(ValueError, match="owner and repo"):
            await upload_release_asset_binary(
                "tok", "", "r",
                release_id="1", asset_path=str(asset), name="a",
            )
        with pytest.raises(ValueError, match="release_id"):
            await upload_release_asset_binary(
                "tok", "o", "r",
                release_id="", asset_path=str(asset), name="a",
            )
        with pytest.raises(ValueError, match="asset_path"):
            await upload_release_asset_binary(
                "tok", "o", "r",
                release_id="1", asset_path="", name="a",
            )
        with pytest.raises(ValueError, match="name"):
            await upload_release_asset_binary(
                "tok", "o", "r",
                release_id="1", asset_path=str(asset), name="",
            )

    @pytest.mark.asyncio
    async def test_targets_uploads_subdomain(self, monkeypatch, tmp_path):
        # The host MUST be uploads.github.com, not api.github.com —
        # different CDN endpoint by design.
        from forge_manager_mcp.github import resolvers as _r
        from unittest.mock import MagicMock

        asset = tmp_path / "a.bin"
        asset.write_bytes(b"payload-bytes")
        captured: dict = {}

        class _Resp:
            status_code = 201
            text = "{}"

        async def _post(url, headers=None, params=None, content=None):
            captured["url"] = url
            captured["params"] = params
            captured["content"] = content
            captured["content_type"] = headers.get("Content-Type")
            return _Resp()

        fake_client = MagicMock()
        fake_client.post = _post
        monkeypatch.setattr(_r, "_get_client", lambda: fake_client)

        await _r.upload_release_asset_binary(
            "tok", "owner", "repo",
            release_id="999",
            asset_path=str(asset),
            name="released.tar.gz",
            content_type="application/gzip",
        )
        assert captured["url"] == (
            "https://uploads.github.com/repos/owner/repo/"
            "releases/999/assets"
        )
        assert captured["params"] == {"name": "released.tar.gz"}
        assert captured["content"] == b"payload-bytes"
        assert captured["content_type"] == "application/gzip"

    @pytest.mark.asyncio
    async def test_non_2xx_raises_github_error(self, monkeypatch, tmp_path):
        from forge_manager_mcp.github import resolvers as _r
        from forge_manager_mcp.github.core import GitHubError
        from unittest.mock import MagicMock

        asset = tmp_path / "a.bin"
        asset.write_bytes(b"x")

        class _Resp:
            status_code = 422
            text = '{"message": "validation failed"}'

        async def _post(url, headers=None, params=None, content=None):
            return _Resp()

        fake_client = MagicMock()
        fake_client.post = _post
        monkeypatch.setattr(_r, "_get_client", lambda: fake_client)

        with pytest.raises(GitHubError, match="HTTP 422"):
            await _r.upload_release_asset_binary(
                "tok", "o", "r",
                release_id="1", asset_path=str(asset), name="a",
            )


# (#459 / 3.13.0 D-Friction.4) set_project_item_column — aggregate
# the three-step column-move chain into a single Protocol method.


class TestGitHubAdapterSetProjectItemColumn:
    """GitHubAdapter.set_project_item_column internalizes the
    get_project_status_field + get_project_item_id + move_project_item
    chain. Pre-cached field_id + options skip the first call.
    """

    def _make_ref(self):
        from forge_manager_mcp.adapters.types import ArtifactRef
        return ArtifactRef(
            platform_id="github", native_id="I_node123",
            kind="issue", owner="o", repo="r", number=42,
        )

    @pytest.mark.asyncio
    async def test_uses_pre_cached_field_and_options(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        get_status = AsyncMock()  # should NOT be called
        get_item = AsyncMock(return_value="PVTI_xyz")
        move = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "get_project_status_field", get_status,
        )
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "get_project_item_id", get_item,
        )
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "move_project_item", move,
        )

        adapter = GitHubAdapter(token="ghp_test")
        await adapter.set_project_item_column(
            board_id="B", ref=self._make_ref(),
            column_name="Done",
            status_field_id="F1",
            status_options={"Done": "OPT_DONE"},
        )
        get_status.assert_not_called()
        get_item.assert_awaited_once()
        move.assert_awaited_once()
        # The move call carries the pre-cached field_id + the resolved
        # option_id from the pre-cached options map.
        kw = move.await_args.args
        # _move's signature: (token, board_id, item_id, field_id, option_id)
        assert kw[1] == "B"
        assert kw[2] == "PVTI_xyz"
        assert kw[3] == "F1"
        assert kw[4] == "OPT_DONE"

    @pytest.mark.asyncio
    async def test_resolves_field_when_not_pre_cached(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from unittest.mock import AsyncMock

        get_status = AsyncMock(return_value={
            "field_id": "F_AUTO", "options": {"Done": "OPT_AUTO"},
        })
        get_item = AsyncMock(return_value="PVTI_abc")
        move = AsyncMock(return_value=None)
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "get_project_status_field", get_status,
        )
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "get_project_item_id", get_item,
        )
        monkeypatch.setattr(
            _gh_adapter._gh_projects, "move_project_item", move,
        )

        adapter = GitHubAdapter(token="ghp_test")
        await adapter.set_project_item_column(
            board_id="B", ref=self._make_ref(),
            column_name="Done",
        )
        get_status.assert_awaited_once()
        # Move uses the auto-resolved field_id + option.
        kw = move.await_args.args
        assert kw[3] == "F_AUTO"
        assert kw[4] == "OPT_AUTO"

    @pytest.mark.asyncio
    async def test_unknown_column_raises_forge_error(self, monkeypatch):
        from forge_manager_mcp.adapters import github as _gh_adapter
        from forge_manager_mcp.adapters.github import GitHubAdapter
        from forge_manager_mcp.adapters.errors import ForgeError
        from unittest.mock import AsyncMock

        # Don't even need get_status — pre-cached options provided.
        adapter = GitHubAdapter(token="ghp_test")
        with pytest.raises(ForgeError, match="not found on board"):
            await adapter.set_project_item_column(
                board_id="B", ref=self._make_ref(),
                column_name="UnknownColumn",
                status_field_id="F1",
                status_options={"Done": "OPT_DONE"},
            )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
