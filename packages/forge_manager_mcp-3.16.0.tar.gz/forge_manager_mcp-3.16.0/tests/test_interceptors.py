"""Unit tests for interceptors.py.

Tests verify:
- Public types: Context immutability, Interceptor display_name fallback
- Sync runtime: enter/leave/error mechanics, halt, error propagation,
  cleared-error recovery, empty queue, single interceptor
- Async runtime: same mechanics under aexecute
- Sync/async mixing rejection (ChainError eagerly at chain entry)
- The four operator-facing patterns end-to-end
- Immutability regression: input Context structurally equal before and
  after every public-function call
"""

from __future__ import annotations

import asyncio
import copy
from collections.abc import Mapping
from dataclasses import FrozenInstanceError, replace

import pytest

from forge_manager_mcp.interceptors import (
    AsyncHandler,
    ChainError,
    Context,
    Handler,
    Interceptor,
    aexecute,
    execute,
    result,
)


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def make_recording_step(name: str, *, raises: BaseException | None = None) -> Interceptor:
    """Build an Interceptor whose enter records its name in steps_taken
    and contributes a top-level response key. If `raises` is set, enter
    raises that exception instead.
    """

    def _enter(ctx: Context) -> Context:
        if raises is not None:
            raise raises
        return replace(
            ctx,
            response={**ctx.response, name: {"ran": True}},
            steps_taken=ctx.steps_taken + ({"step": name},),
        )

    def _leave(ctx: Context) -> Context:
        return replace(
            ctx,
            response={
                **ctx.response,
                name: {**ctx.response.get(name, {}), "left": True},
            },
        )

    def _error(ctx: Context) -> Context:
        return replace(
            ctx,
            response={
                **ctx.response,
                name: {**ctx.response.get(name, {}), "errored": True},
            },
            steps_taken=ctx.steps_taken + ({"step": name, "compensated": True},),
        )

    return Interceptor(enter=_enter, leave=_leave, error=_error, name=name)


# ---------------------------------------------------------------------------
# Context — immutability
# ---------------------------------------------------------------------------

class TestContextImmutability:
    def test_frozen_field_assignment_raises(self):
        ctx = Context(request={"x": 1})
        with pytest.raises(FrozenInstanceError):
            ctx.request = {"y": 2}

    def test_replace_returns_new_instance(self):
        ctx = Context(request={"x": 1})
        ctx2 = replace(ctx, response={"a": 1})
        assert ctx is not ctx2
        assert ctx.response == {}
        assert ctx2.response == {"a": 1}

    def test_default_factories(self):
        ctx = Context()
        assert ctx.request == {}
        assert ctx.response == {}
        assert ctx.queue == ()
        assert ctx.stack == ()
        assert ctx.error is None
        assert ctx.halt is False
        assert ctx.steps_taken == ()


# ---------------------------------------------------------------------------
# Interceptor.display_name — fallback chain
# ---------------------------------------------------------------------------

class TestDisplayName:
    def test_explicit_name_used_when_set(self):
        def my_enter(ctx):
            return ctx
        ic = Interceptor(enter=my_enter, name="explicit-name")
        assert ic.display_name == "explicit-name"

    def test_fallback_to_enter_qualname(self):
        def named_enter(ctx):
            return ctx
        ic = Interceptor(enter=named_enter)
        assert ic.display_name.endswith("named_enter")

    def test_fallback_uses_first_non_none_handler(self):
        def named_leave(ctx):
            return ctx
        ic = Interceptor(leave=named_leave)
        assert ic.display_name.endswith("named_leave")

    def test_fallback_to_anonymous_for_lambdas(self):
        ic = Interceptor(enter=lambda ctx: ctx)
        # Lambda __qualname__ ends in "<lambda>"
        assert ic.display_name.endswith("<lambda>")

    def test_anonymous_when_no_handlers(self):
        ic = Interceptor()
        assert ic.display_name == "<anonymous>"


# ---------------------------------------------------------------------------
# Sync runtime: basic chain mechanics
# ---------------------------------------------------------------------------

class TestExecuteEmptyChain:
    def test_empty_chain_returns_initial_context(self):
        ctx = execute([], request={"x": 1})
        assert ctx.error is None
        assert ctx.response == {}
        assert ctx.steps_taken == ()


class TestExecuteSingleInterceptor:
    def test_enter_only(self):
        step = Interceptor(
            enter=lambda c: replace(c, response={"a": 1}),
            name="step",
        )
        ctx = execute([step])
        assert ctx.response == {"a": 1}
        assert ctx.error is None

    def test_enter_and_leave_run_in_order(self):
        order = []
        step = Interceptor(
            enter=lambda c: (order.append("enter"), c)[1],
            leave=lambda c: (order.append("leave"), c)[1],
            name="step",
        )
        execute([step])
        assert order == ["enter", "leave"]

    def test_three_interceptors_run_outer_to_inner_then_unwind(self):
        order = []

        def enter(ic_name):
            return lambda c: (order.append(f"enter:{ic_name}"), c)[1]

        def leave(ic_name):
            return lambda c: (order.append(f"leave:{ic_name}"), c)[1]

        a = Interceptor(enter=enter("a"), leave=leave("a"), name="a")
        b = Interceptor(enter=enter("b"), leave=leave("b"), name="b")
        c = Interceptor(enter=enter("c"), leave=leave("c"), name="c")

        execute([a, b, c])
        assert order == [
            "enter:a", "enter:b", "enter:c",
            "leave:c", "leave:b", "leave:a",
        ]


# ---------------------------------------------------------------------------
# Sync runtime: error propagation
# ---------------------------------------------------------------------------

class TestErrorPropagation:
    def test_error_in_enter_halts_descent(self):
        order = []

        def enter_a(ctx):
            order.append("enter:a")
            return ctx

        def enter_b(ctx):
            order.append("enter:b")
            raise RuntimeError("boom")

        def enter_c(ctx):
            order.append("enter:c")
            return ctx

        a = Interceptor(enter=enter_a, name="a")
        b = Interceptor(enter=enter_b, name="b")
        c = Interceptor(enter=enter_c, name="c")

        ctx = execute([a, b, c])
        assert order == ["enter:a", "enter:b"]
        # c.enter never ran
        assert isinstance(ctx.error, RuntimeError)
        assert str(ctx.error) == "boom"

    def test_error_runs_prior_interceptors_error_handlers(self):
        order = []

        def enter_a(ctx):
            return ctx

        def error_a(ctx):
            order.append("error:a")
            return ctx  # propagate; don't clear

        def enter_b(ctx):
            raise RuntimeError("boom")

        a = Interceptor(enter=enter_a, error=error_a, name="a")
        b = Interceptor(enter=enter_b, name="b")

        ctx = execute([a, b])
        assert order == ["error:a"]
        assert isinstance(ctx.error, RuntimeError)


# ---------------------------------------------------------------------------
# Sync runtime: cleared-error recovery
# ---------------------------------------------------------------------------

class TestClearedErrorRecovery:
    def test_error_handler_clearing_error_switches_to_leave_path(self):
        order = []

        def enter_a(ctx):
            order.append("enter:a")
            return ctx

        def leave_a(ctx):
            order.append("leave:a")
            return ctx

        def error_a(ctx):
            # Should NOT be called — recoverer (b) clears the error first
            order.append("error:a")
            return ctx

        def enter_b(ctx):
            order.append("enter:b")
            return ctx

        def leave_b(ctx):
            # Should NOT be called — b's enter caused the error
            order.append("leave:b")
            return ctx

        def error_b(ctx):
            order.append("error:b")
            return replace(ctx, error=None)  # ← clear error → recover

        def enter_c(ctx):
            order.append("enter:c")
            raise RuntimeError("boom")  # error originates here

        a = Interceptor(enter=enter_a, leave=leave_a, error=error_a, name="a")
        b = Interceptor(enter=enter_b, leave=leave_b, error=error_b, name="b")
        c = Interceptor(enter=enter_c, name="c")

        ctx = execute([a, b, c])
        # c.enter raised → c is on stack; unwind starts with c (no error
        # handler) → unwind reaches b → b.error clears the error → unwind
        # reaches a → a.leave fires (not a.error) because error is now None.
        assert "error:b" in order, "b.error must run"
        assert "error:a" not in order, "a.error must NOT run (recovered)"
        assert "leave:a" in order, "a.leave must run after recovery"
        assert ctx.error is None, "error cleared by b.error"

    def test_recovered_error_returns_clean_context(self):
        def enter(ctx):
            raise RuntimeError("inner")

        def error_recover(ctx):
            return replace(ctx, error=None,
                           response={**ctx.response, "recovered": True})

        recoverer = Interceptor(error=error_recover, name="recoverer")
        failing = Interceptor(enter=enter, name="failing")

        ctx = execute([recoverer, failing])
        assert ctx.error is None
        assert ctx.response == {"recovered": True}


# ---------------------------------------------------------------------------
# Sync runtime: halt mechanism (non-error short-circuit)
# ---------------------------------------------------------------------------

class TestHaltShortCircuit:
    def test_halt_set_in_enter_stops_descent(self):
        order = []

        def enter_a(ctx):
            order.append("enter:a")
            return ctx

        def enter_b(ctx):
            order.append("enter:b")
            return replace(
                ctx,
                halt=True,
                response={**ctx.response, "halted_by": "b"},
            )

        def enter_c(ctx):
            order.append("enter:c")
            return ctx

        a = Interceptor(enter=enter_a, name="a")
        b = Interceptor(enter=enter_b, name="b")
        c = Interceptor(enter=enter_c, name="c")

        ctx = execute([a, b, c])
        assert order == ["enter:a", "enter:b"]
        assert ctx.halt is True
        assert ctx.error is None  # halt is NOT an error
        assert ctx.response == {"halted_by": "b"}

    def test_halt_unwinds_via_leave_not_error(self):
        order = []

        def leave_a(ctx):
            order.append("leave:a")
            return ctx

        def error_a(ctx):
            order.append("error:a")
            return ctx

        a = Interceptor(leave=leave_a, error=error_a, name="a")
        b = Interceptor(
            enter=lambda c: replace(c, halt=True),
            name="halter",
        )

        execute([a, b])
        assert order == ["leave:a"], "halt is not error; leave fires"


# ---------------------------------------------------------------------------
# Sync/async mixing — eagerly rejected
# ---------------------------------------------------------------------------

class TestSyncAsyncMixing:
    def test_execute_rejects_async_handler(self):
        async def async_enter(ctx):
            return ctx

        ic = Interceptor(enter=async_enter, name="ic")
        with pytest.raises(ChainError, match="execute requires sync"):
            execute([ic])

    def test_aexecute_rejects_sync_handler(self):
        def sync_enter(ctx):
            return ctx

        ic = Interceptor(enter=sync_enter, name="ic")
        with pytest.raises(ChainError, match="aexecute requires async"):
            asyncio.run(aexecute([ic]))


# ---------------------------------------------------------------------------
# Async runtime: smoke test that the same semantics hold
# ---------------------------------------------------------------------------

class TestAsyncRuntime:
    def test_async_enter_leave_order(self):
        order = []

        async def enter_a(ctx):
            order.append("enter:a")
            return ctx

        async def leave_a(ctx):
            order.append("leave:a")
            return ctx

        async def enter_b(ctx):
            order.append("enter:b")
            return ctx

        async def leave_b(ctx):
            order.append("leave:b")
            return ctx

        a = Interceptor(enter=enter_a, leave=leave_a, name="a")
        b = Interceptor(enter=enter_b, leave=leave_b, name="b")

        asyncio.run(aexecute([a, b]))
        assert order == ["enter:a", "enter:b", "leave:b", "leave:a"]

    def test_async_error_propagation(self):
        async def enter_b(ctx):
            raise RuntimeError("async boom")

        b = Interceptor(enter=enter_b, name="b")
        ctx = asyncio.run(aexecute([b]))
        assert isinstance(ctx.error, RuntimeError)


# ---------------------------------------------------------------------------
# result(ctx) — get-or-raise convenience
# ---------------------------------------------------------------------------

class TestResultExtraction:
    def test_result_returns_response_when_no_error(self):
        ic = Interceptor(
            enter=lambda c: replace(c, response={"x": 1}),
            name="ic",
        )
        ctx = execute([ic])
        assert result(ctx) == {"x": 1}

    def test_result_raises_when_error_set(self):
        def enter(ctx):
            raise RuntimeError("boom")

        ic = Interceptor(enter=enter, name="ic")
        ctx = execute([ic])
        with pytest.raises(RuntimeError, match="boom"):
            result(ctx)


# ---------------------------------------------------------------------------
# The four operator-facing patterns — end-to-end demonstration
# ---------------------------------------------------------------------------

class TestFourPatterns:
    """Each test exercises one of the four documented patterns.

    Together these demonstrate the patterns are implementable end-to-end
    against the runtime; serve as regression check + teaching artifact.
    """

    def test_pattern_1_leave_is_raii(self):
        """Resource allocated in enter is released in leave, regardless
        of subsequent success/failure.
        """
        released = []

        def enter(ctx):
            return replace(
                ctx,
                response={**ctx.response, "resource": {"path": "/tmp/x"}},
            )

        def leave(ctx):
            path = ctx.response.get("resource", {}).get("path")
            if path:
                released.append(path)
            return ctx

        def error(ctx):
            # Same cleanup; resource needs releasing whether success or error
            return leave(ctx)

        resource = Interceptor(enter=enter, leave=leave, error=error,
                               name="resource")
        # Success path
        execute([resource])
        assert released == ["/tmp/x"]
        # Error path (later step throws)
        released.clear()
        boom = Interceptor(
            enter=lambda c: (_ for _ in ()).throw(RuntimeError("boom")),
            name="boom",
        )
        execute([resource, boom])
        assert released == ["/tmp/x"], "RAII cleanup runs on error path too"

    def test_pattern_2_error_recovery_via_cleared_error(self):
        """Error handler clears ctx.error → unwind switches to leave path."""
        order = []

        def cleanup_a(ctx):
            order.append("cleanup_a")
            return ctx

        def recover_b(ctx):
            order.append("recover_b")
            return replace(ctx, error=None,
                           response={**ctx.response, "via": "fallback"})

        def fail_c(ctx):
            raise RuntimeError("primary failed")

        a = Interceptor(leave=cleanup_a, name="a")
        b = Interceptor(error=recover_b, name="b")
        c = Interceptor(enter=fail_c, name="c")

        ctx = execute([a, b, c])
        assert "recover_b" in order
        assert "cleanup_a" in order  # leave fires after recovery, not error
        assert ctx.error is None
        assert ctx.response == {"via": "fallback"}

    def test_pattern_3_response_accumulates(self):
        """Each enter contributes one top-level key to ctx.response."""
        a = Interceptor(
            enter=lambda c: replace(c, response={**c.response, "a": {"v": 1}}),
            name="a",
        )
        b = Interceptor(
            enter=lambda c: replace(c, response={**c.response, "b": {"v": 2}}),
            name="b",
        )
        c = Interceptor(
            enter=lambda c: replace(c, response={**c.response, "c": {"v": 3}}),
            name="c",
        )
        ctx = execute([a, b, c])
        assert ctx.response == {"a": {"v": 1}, "b": {"v": 2}, "c": {"v": 3}}

    def test_pattern_4_steps_taken_audits_forward_and_compensated(self):
        """enter appends a forward entry; error may append a compensated marker."""

        def enter_a(ctx):
            return replace(
                ctx,
                steps_taken=ctx.steps_taken + ({"step": "a"},),
            )

        def error_a(ctx):
            return replace(
                ctx,
                steps_taken=ctx.steps_taken + (
                    {"step": "a", "compensated": True},
                ),
            )

        def enter_b(ctx):
            raise RuntimeError("boom")

        a = Interceptor(enter=enter_a, error=error_a, name="a")
        b = Interceptor(enter=enter_b, name="b")

        ctx = execute([a, b])
        assert ctx.steps_taken == (
            {"step": "a"},
            {"step": "a", "compensated": True},
        ), "forward + compensated entries paired by step name"


# ---------------------------------------------------------------------------
# Immutability regression — input Context unchanged after every public call
# ---------------------------------------------------------------------------

class TestImmutabilityRegression:
    """For every public function path, assert input Context is structurally
    equal before and after the call. Catches accidental mutation regressions.
    """

    def test_execute_does_not_mutate_input(self):
        ic = Interceptor(
            enter=lambda c: replace(c, response={"x": 1}),
            name="ic",
        )
        # We can't pass a Context to execute (it builds its own initial),
        # but we can verify the chain list isn't mutated and request mapping
        # isn't mutated.
        chain = [ic]
        chain_before = chain.copy()
        request = {"x": 1}
        request_before = copy.deepcopy(request)

        execute(chain, request=request)

        assert chain == chain_before
        assert request == request_before

    def test_handlers_get_new_context_not_alias(self):
        """Handler receives a Context; if it returns a different Context,
        the handler's input is not affected by the new one's mutations
        (frozen guarantees this; this test verifies the runtime threads
        new contexts through correctly).
        """
        captured = []

        def enter_capture(ctx):
            captured.append(ctx)
            return replace(ctx, response={"new": True})

        def enter_check(ctx):
            # The captured ctx from the previous interceptor should still
            # have its original response (empty), even though the runtime
            # passed forward the new ctx with response={"new": True}.
            assert captured[0].response == {}
            return ctx

        a = Interceptor(enter=enter_capture, name="a")
        b = Interceptor(enter=enter_check, name="b")
        execute([a, b])
        assert len(captured) == 1
        assert captured[0].response == {}, "captured ctx unchanged by later replace"

    def test_response_typed_as_mapping_prevents_assignment(self):
        """ctx.response is typed as Mapping; type checker rejects item
        assignment. Runtime can't enforce this (Mapping is structural,
        not nominal at runtime), but verify the Mapping default is
        immutable-shaped: dict and friends are accepted as Mapping but
        callers should treat as read-only.
        """
        ctx = Context(response={"a": 1})
        # The dict IS still a dict at runtime, so this won't actually raise
        # — type-checker is the enforcement point. This test documents
        # the convention rather than enforcing it at runtime.
        assert isinstance(ctx.response, Mapping)


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) display_name fallback chain.
# ---------------------------------------------------------------------------


class TestDisplayNameNameFallback:
    def test_handler_with_only_name_falls_through(self):
        # Handler has __name__ but no __qualname__ → L310-312 returns
        # __name__. Use functools.partial wrapping a function — the
        # outer partial has __name__ via the wrapped function but
        # may lack __qualname__ depending on cpython version.
        # Simplest reliable trigger: a plain function whose
        # __qualname__ has been set to empty (falsy) and __name__
        # remains.

        async def _real_handler(ctx):  # pragma: no cover — never called
            return ctx

        # Reset __qualname__ to falsy ('').
        _real_handler.__qualname__ = ""
        ic = Interceptor(enter=_real_handler)
        # __qualname__ is "" (falsy), so the next fallback (__name__)
        # fires: name resolves to "_real_handler".
        assert ic.display_name == "_real_handler"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
