"""
Unit tests for models.py.

Pydantic models are the first validation layer. Tests confirm
that every required field is enforced and that frozen models
reject mutation.
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from forge_manager_mcp.models import (
    ClassifyResult,
    DiscussionCategories,
    GithubConfig,
    OperationError,
    RelatedRepo,
    ThemeChangeResult,
)


class TestGithubConfig:
    def test_valid_config(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.owner == "telejester"

    def test_missing_owner_raises(self, valid_config_dict):
        del valid_config_dict["owner"]
        with pytest.raises(ValidationError):
            GithubConfig.model_validate(valid_config_dict)

    def test_wrong_skill_raises(self, valid_config_dict):
        valid_config_dict["skill"] = "wrong-skill"
        with pytest.raises(ValidationError):
            GithubConfig.model_validate(valid_config_dict)

    def test_short_project_discussion_id_raises(self, valid_config_dict):
        valid_config_dict["project_discussion_id"] = "short"
        with pytest.raises(ValidationError, match="suspiciously short"):
            GithubConfig.model_validate(valid_config_dict)

    def test_frozen_rejects_mutation(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        with pytest.raises(Exception):
            config.owner = "other"  # type: ignore[misc]

    def test_extra_fields_rejected(self, valid_config_dict):
        valid_config_dict["unknown_field"] = "value"
        with pytest.raises(ValidationError):
            GithubConfig.model_validate(valid_config_dict)

    def test_full_config_with_all_optional_fields(self, valid_config_dict_full):
        config = GithubConfig.model_validate(valid_config_dict_full)
        assert config.project_board.status_field_id is not None
        assert config.project_board.status_options is not None
        assert config.discussion_categories.Project is not None
        assert config.discussion_categories.Architecture.note is not None

    def test_optional_status_fields_accepted(self, valid_config_dict):
        valid_config_dict["project_board"]["status_field_id"] = "PVTSSF_abc123abcd"
        valid_config_dict["project_board"]["status_options"] = {"Backlog": "aaa"}
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.project_board.status_field_id == "PVTSSF_abc123abcd"
        assert config.project_board.status_options == {"Backlog": "aaa"}

    def test_project_category_accepted(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["Project"] = {
            "id": "DIC_kwDOSIO9Xs4C7UzY",
            "isAnswerable": False,
        }
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.discussion_categories.Project is not None

    def test_note_on_category_accepted(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["Architecture"]["note"] = "Q&A"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.discussion_categories.Architecture.note == "Q&A"

    def test_repos_docs_optional(self, valid_config_dict):
        # Pre-Gap-A configs have no `repos.docs` key — they must still
        # validate. Newer configs emit it; the field is optional.
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.repos.docs is None

    def test_repos_docs_round_trips(self, valid_config_dict):
        valid_config_dict["repos"]["docs"] = "myorg/widgets-docs"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.repos.docs == "myorg/widgets-docs"

    def test_docs_repo_path_optional(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.docs_repo_path is None

    def test_docs_repo_path_round_trips(self, valid_config_dict):
        valid_config_dict["docs_repo_path"] = "/home/user/widgets-docs"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.docs_repo_path == "/home/user/widgets-docs"

    def test_skill_accepts_forge_manager(self, valid_config_dict):
        # 3.0+ canonical value (G1).
        valid_config_dict["skill"] = "forge-manager"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.skill == "forge-manager"

    def test_skill_accepts_legacy_active_claude_github(self, valid_config_dict):
        # 2.x value continues to validate so pre-migration configs still
        # load (G1 grace period).
        valid_config_dict["skill"] = "active-claude-github"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.skill == "active-claude-github"

    def test_skill_rejects_unknown_value(self, valid_config_dict):
        valid_config_dict["skill"] = "totally-different-skill"
        with pytest.raises(ValidationError):
            GithubConfig.model_validate(valid_config_dict)


class TestPublicFaceCoords:
    """forgejo #8 — GithubConfig.public_face_coords() resolution."""

    def test_returns_platform_coords_when_public_face_set(
        self, valid_config_dict
    ):
        valid_config_dict["platforms"] = [
            {"id": "github", "owner": "ghorg",
             "public": "ghorg/widgets",
             "private": "ghorg/widgets-dev"},
            {"id": "codeberg", "owner": "cborg",
             "public": "cborg/widgets-public",
             "private": "cborg/widgets-dev"},
        ]
        valid_config_dict["public_face"] = "codeberg"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face_coords() == ("cborg", "widgets-public")

    def test_returns_none_when_public_face_set_but_platform_missing(
        self, valid_config_dict
    ):
        valid_config_dict["platforms"] = [
            {"id": "github", "owner": "ghorg",
             "public": "ghorg/widgets",
             "private": "ghorg/widgets-dev"},
        ]
        # public_face references unknown platform — model validator catches
        # this at construction, so build the model with public_face matching
        # a present platform first then mutate. Since the model is frozen
        # we use model_construct to bypass validation for this edge case.
        valid_config_dict["public_face"] = "github"
        config = GithubConfig.model_validate(valid_config_dict)
        # Now simulate the unreachable case: platforms became empty after
        # the fact (e.g., a future migration bug). Build a fresh dict so
        # validator passes, then assert the coord lookup behavior.
        assert config.public_face_coords() == ("ghorg", "widgets")

    def test_falls_back_to_repos_public_when_public_face_unset(
        self, valid_config_dict
    ):
        # 2.x-compat path: no platforms list, no public_face — legacy
        # repos.public is the implicit public face.
        valid_config_dict.pop("platforms", None)
        valid_config_dict.pop("public_face", None)
        config = GithubConfig.model_validate(valid_config_dict)
        # repos.public from the fixture is "telejester/active-claude-github"
        # in the standard test fixture; assert it splits cleanly.
        coords = config.public_face_coords()
        assert coords is not None
        owner, repo = coords
        assert "/" not in owner
        assert "/" not in repo
        assert f"{owner}/{repo}" == config.repos.public

    def test_returns_none_when_platform_entry_has_malformed_public(
        self, valid_config_dict
    ):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "cborg",
             "public": "no-slash-here",  # malformed
             "private": "cborg/widgets-dev"},
        ]
        valid_config_dict["public_face"] = "codeberg"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face_coords() is None

    def test_returns_none_when_public_face_set_but_no_matching_platform(
        self, valid_config_dict
    ):
        # public_face set, but the named platform isn't in `platforms`
        # (defensive against operator-edited config drift).
        valid_config_dict["platforms"] = [
            {"id": "github", "owner": "ghorg",
             "public": "ghorg/widgets",
             "private": "ghorg/widgets-dev"},
        ]
        # Validator allows public_face to reference a registered platform
        # only; we bypass via model_construct for the drift case.
        valid_config_dict["public_face"] = "github"
        config = GithubConfig.model_validate(valid_config_dict)
        # Force public_face to a non-existent platform via __dict__ since
        # the model is frozen.
        object.__setattr__(config, "public_face", "gitlab-not-listed")
        assert config.public_face_coords() is None

    def test_legacy_fallback_returns_none_for_invalid_format(
        self, valid_config_dict,
    ):
        # No platforms, public_face unset; if repos.public is malformed
        # the helper returns None.
        valid_config_dict.pop("platforms", None)
        valid_config_dict.pop("public_face", None)
        valid_config_dict["repos"]["public"] = "no-slash"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face_coords() is None


class TestCoordsForPlatform:
    """(#428 / 3.12.0 D-Coverage drain) coords_for_platform resolver — #296."""

    def test_invalid_repo_role_raises(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        with pytest.raises(ValueError, match="repo_role must be one of"):
            config.coords_for_platform("github", repo_role="bogus")

    def test_local_returns_legacy_repos_coords(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        # repos.private from fixture splits to (owner, repo).
        owner, repo = config.coords_for_platform("local", repo_role="private")
        assert f"{owner}/{repo}" == config.repos.private

    def test_local_returns_empty_when_legacy_repo_field_missing(
        self, valid_config_dict,
    ):
        # `docs` field is optional on RepoConfig — empty by default.
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.coords_for_platform("local", repo_role="docs") == ("", "")

    def test_resolves_from_3_0_platforms_entry(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "cborg",
             "public": "cborg/widgets-pub",
             "private": "cborg/widgets-dev"},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        owner, repo = config.coords_for_platform("codeberg", repo_role="public")
        assert (owner, repo) == ("cborg", "widgets-pub")

    def test_3_0_platform_entry_with_malformed_field_returns_empty(
        self, valid_config_dict,
    ):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "cborg",
             "public": "no-slash",  # malformed
             "private": "cborg/widgets-dev"},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.coords_for_platform(
            "codeberg", repo_role="public",
        ) == ("", "")

    def test_falls_back_to_repos_when_no_platforms_match(
        self, valid_config_dict,
    ):
        # 2.x-compat: no `platforms` block; resolver falls back to
        # `repos.<role>` for any platform_id (the legacy behavior).
        valid_config_dict.pop("platforms", None)
        config = GithubConfig.model_validate(valid_config_dict)
        owner, repo = config.coords_for_platform("github", repo_role="private")
        assert f"{owner}/{repo}" == config.repos.private

    def test_returns_empty_when_no_match_anywhere(self, valid_config_dict):
        # repos.docs is empty by default → 2.x fallback yields ("", "").
        valid_config_dict.pop("platforms", None)
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.coords_for_platform("docs", repo_role="docs") == ("", "")


class TestTargetIssueNumberForPlatform:
    """(#467 / #468 / 3.13.0) target_issue_number_for_platform —
    per-platform Issue-encoded-as-Discussion target slots for the
    Codeberg / Forgejo Session Lock + Project Index equivalents.
    """

    def test_invalid_target_kind_raises(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        with pytest.raises(ValueError, match="target_kind must be"):
            config.target_issue_number_for_platform(
                "codeberg", target_kind="bogus",
            )

    def test_returns_none_when_no_platforms(self, valid_config_dict):
        valid_config_dict.pop("platforms", None)
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) is None

    def test_returns_none_when_platform_absent(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "github", "owner": "o", "public": "o/p", "private": "o/d"},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) is None

    def test_returns_none_when_field_absent(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d"},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) is None

    def test_returns_session_lock_issue_number(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d",
             "session_lock_issue_number": 42},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) == 42

    def test_returns_project_index_issue_number(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d",
             "project_index_issue_number": 7},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="project_index",
        ) == 7

    def test_session_lock_and_project_index_independent(
        self, valid_config_dict,
    ):
        # Both fields populated — resolver picks the right one per
        # target_kind without crosstalk.
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d",
             "session_lock_issue_number": 100,
             "project_index_issue_number": 200},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) == 100
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="project_index",
        ) == 200

    def test_zero_or_negative_returns_none(self, valid_config_dict):
        # Defensive: 0 and negative values aren't valid Issue numbers.
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d",
             "session_lock_issue_number": 0},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) is None

    def test_non_int_returns_none(self, valid_config_dict):
        # Defensive: a string in the field returns None rather than
        # raising — keeps the helper graceful on malformed config.
        valid_config_dict["platforms"] = [
            {"id": "codeberg", "owner": "o", "public": "o/p",
             "private": "o/d",
             "session_lock_issue_number": "not-a-number"},
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.target_issue_number_for_platform(
            "codeberg", target_kind="session_lock",
        ) is None


class TestDiscussionCategories:
    def test_empty_category_id_raises(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["Architecture"]["id"] = ""
        with pytest.raises(ValidationError, match="empty ID"):
            GithubConfig.model_validate(valid_config_dict)

    def test_project_category_empty_id_raises(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["Project"] = {
            "id": "",
            "isAnswerable": False,
        }
        with pytest.raises(ValidationError, match="empty ID"):
            GithubConfig.model_validate(valid_config_dict)

    def test_extra_category_accepted(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["General"] = {
            "id": "DIC_kwDOSIO9Xs4C7UzZ",
            "isAnswerable": False,
            "note": "Admin / session records",
        }
        config = GithubConfig.model_validate(valid_config_dict)
        extras = config.discussion_categories.model_extra or {}
        assert "General" in extras
        assert extras["General"].id == "DIC_kwDOSIO9Xs4C7UzZ"
        assert extras["General"].is_answerable is False

    def test_extra_category_empty_id_raises(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["General"] = {
            "id": "",
            "isAnswerable": False,
        }
        with pytest.raises(ValidationError, match="empty ID"):
            GithubConfig.model_validate(valid_config_dict)

    def test_announcements_category_accepted(self, valid_config_dict):
        # Announcements is an optional named field on DiscussionCategories;
        # construction walks the `if self.Announcements is not None`
        # branch in the validator.
        valid_config_dict["discussion_categories"]["Announcements"] = {
            "id": "DIC_announce", "isAnswerable": False,
        }
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.discussion_categories.Announcements is not None
        assert config.discussion_categories.Announcements.id == "DIC_announce"

    def test_extra_category_already_typed_passes_through(self, valid_config_dict):
        # When a DiscussionCategory instance is supplied directly as an
        # extra (not a dict), the validator's isinstance branch passes
        # it through without re-validation.
        from forge_manager_mcp.models import DiscussionCategory
        existing = DiscussionCategory(id="DIC_existing", isAnswerable=True)
        valid_config_dict["discussion_categories"]["MyCategory"] = existing
        config = GithubConfig.model_validate(valid_config_dict)
        # Extra preserved (model_extra carries the typed instance).
        extras = config.discussion_categories.model_extra or {}
        assert "MyCategory" in extras

    def test_extra_category_missing_fields_raises(self, valid_config_dict):
        valid_config_dict["discussion_categories"]["General"] = {
            "id": "DIC_kwDOSIO9Xs4C7UzZ",
        }
        with pytest.raises(ValidationError, match="is invalid"):
            GithubConfig.model_validate(valid_config_dict)


class TestClassifyResult:
    def test_valid_discussion(self):
        result = ClassifyResult(
            destination="discussion",
            category="Architecture",
            issue_label=None,
            suggested_title="Auth design",
            confidence="high",
        )
        assert result.destination == "discussion"

    def test_invalid_destination_raises(self):
        with pytest.raises(ValidationError):
            ClassifyResult(
                destination="unknown",  # type: ignore[arg-type]
                category=None,
                issue_label=None,
                suggested_title="Title",
                confidence="high",
            )

    def test_invalid_confidence_raises(self):
        with pytest.raises(ValidationError):
            ClassifyResult(
                destination="discussion",
                category=None,
                issue_label=None,
                suggested_title="Title",
                confidence="very_sure",  # type: ignore[arg-type]
            )


class TestOperationError:
    def test_success_field_is_always_false(self):
        err = OperationError(
            success=False,
            error="timeout",
            buffered=True,
            buffer_file=".claude/pending-posts.md",
            retry_tool="post_turn",
            retry_args={"thread_id": "D_abc"},
        )
        assert err.success is False
        assert err.manual_step is None

    def test_cannot_set_success_true(self):
        with pytest.raises(ValidationError):
            OperationError(
                success=True,  # type: ignore[arg-type]
                error="",
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )

    def test_manual_step_populated_for_protocol_gate(self):
        # #98 — cousin preflight block surfaces a manual_step rather
        # than a buffered error.
        err = OperationError(
            success=False,
            error="cousin-repo mutation blocked: other-org/foo",
            buffered=False,
            buffer_file=None,
            retry_tool=None,
            retry_args=None,
            manual_step=(
                "Cross-org mutation on 'other-org/foo' requires "
                "explicit user permission."
            ),
        )
        assert err.manual_step is not None
        assert "explicit user permission" in err.manual_step


class TestRelatedRepo:
    # #98 — RelatedRepo extends config schema from 3 to 6 typed
    # relationships, with `contribution_target` parsed-but-deprecated.

    def test_all_six_types_accepted(self):
        for rel in (
            "subsystem",
            "publish_target",
            "sibling",
            "cousin",
            "neighbor",
            "foreign",
        ):
            entry = RelatedRepo(repo="org/name", relationship=rel)
            assert entry.relationship == rel

    def test_contribution_target_accepted_deprecated(self):
        # Parses cleanly so existing configs load; the deprecation
        # warning is emitted by config.load_config, not by the model.
        entry = RelatedRepo(repo="org/name", relationship="contribution_target")
        assert entry.relationship == "contribution_target"

    def test_invalid_relationship_rejected(self):
        with pytest.raises(ValidationError):
            RelatedRepo(
                repo="org/name",
                relationship="partner",  # type: ignore[arg-type]
            )

    def test_repo_without_slash_rejected(self):
        with pytest.raises(ValidationError, match="owner/name"):
            RelatedRepo(repo="just-a-name", relationship="sibling")

    def test_repo_with_multiple_slashes_rejected(self):
        with pytest.raises(ValidationError, match="owner/name"):
            RelatedRepo(repo="a/b/c", relationship="sibling")

    def test_repo_with_empty_parts_rejected(self):
        with pytest.raises(ValidationError, match="owner/name"):
            RelatedRepo(repo="/name", relationship="sibling")
        with pytest.raises(ValidationError, match="owner/name"):
            RelatedRepo(repo="org/", relationship="sibling")

    def test_description_optional(self):
        with_desc = RelatedRepo(
            repo="org/name", relationship="sibling", description="A sibling"
        )
        no_desc = RelatedRepo(repo="org/name", relationship="sibling")
        assert with_desc.description == "A sibling"
        assert no_desc.description is None

    def test_extra_fields_rejected(self):
        with pytest.raises(ValidationError):
            RelatedRepo.model_validate(
                {
                    "repo": "org/name",
                    "relationship": "sibling",
                    "nope": "extra",
                }
            )


class TestGithubConfigRelatedRepos:
    # #98 — related_repos is optional; empty default means existing
    # bootstrap configs continue to load unchanged.

    def test_related_repos_optional_defaults_empty(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.related_repos == []

    def test_related_repos_populated(self, valid_config_dict):
        valid_config_dict["related_repos"] = [
            {
                "repo": "telejester-claude-skills/claude-skills-mcp-dev",
                "relationship": "subsystem",
                "description": "MCP server source",
            },
            {
                "repo": "other-org/shared-tool",
                "relationship": "cousin",
                "description": "Cross-org collaborator",
            },
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        assert len(config.related_repos) == 2
        assert config.related_repos[0].relationship == "subsystem"
        assert config.related_repos[1].relationship == "cousin"

    def test_find_related_repo_match(self, valid_config_dict):
        valid_config_dict["related_repos"] = [
            {"repo": "other-org/Shared-Tool", "relationship": "cousin"}
        ]
        config = GithubConfig.model_validate(valid_config_dict)
        # Case-insensitive lookup so casing drift in args doesn't miss.
        entry = config.find_related_repo("other-org/shared-tool")
        assert entry is not None
        assert entry.relationship == "cousin"

    def test_find_related_repo_miss(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.find_related_repo("nobody/nothing") is None


# (Phase H / 3.5.0) TestSiteConfig REMOVED with SiteConfig itself.

class TestPublicFace:
    """public_face platform-role field (#280)."""

    def test_default_none(self, valid_config_dict):
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face is None

    def test_explicit_value_with_matching_platform_ok(self, valid_config_dict):
        valid_config_dict["platforms"] = [
            {"id": "github", "owner": "x", "public": "x/p", "private": "x/p-dev"},
            {"id": "forgejo", "owner": "x"},
        ]
        valid_config_dict["replication_order"] = ["local", "github", "forgejo"]
        valid_config_dict["public_face"] = "forgejo"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face == "forgejo"

    def test_explicit_value_no_matching_platform_raises(self, valid_config_dict):
        valid_config_dict["platforms"] = [{"id": "github", "owner": "x"}]
        valid_config_dict["replication_order"] = ["local", "github"]
        valid_config_dict["public_face"] = "gitlab"
        with pytest.raises(ValidationError, match="public_face"):
            GithubConfig.model_validate(valid_config_dict)

    def test_value_skipped_when_platforms_empty_2x_compat(self, valid_config_dict):
        # 2.x-compat config: platforms is empty, public_face has no effect
        # but should not raise — the legacy path ignores it entirely.
        valid_config_dict["public_face"] = "github"
        config = GithubConfig.model_validate(valid_config_dict)
        assert config.public_face == "github"  # field stored, not validated


class TestPublicFaceTranslation:
    """Migration translator default (#280) — _translate_config_schema."""

    def test_2x_config_with_public_repo_defaults_public_face_to_github(self):
        from forge_manager_mcp.migration.detector import _translate_config_schema

        legacy = {
            "owner": "x",
            "repos": {"private": "x/p-dev", "public": "x/p"},
            "skill": "active-claude-github",
        }
        translated = _translate_config_schema(legacy)
        assert translated["public_face"] == "github"

    def test_existing_public_face_preserved(self):
        from forge_manager_mcp.migration.detector import _translate_config_schema

        legacy = {
            "owner": "x",
            "repos": {"private": "x/p-dev", "public": "x/p"},
            "public_face": "forgejo",
            "skill": "active-claude-github",
        }
        translated = _translate_config_schema(legacy)
        assert translated["public_face"] == "forgejo"

    def test_no_public_repo_no_public_face_default(self):
        from forge_manager_mcp.migration.detector import _translate_config_schema

        legacy = {
            "owner": "x",
            "repos": {"private": "x/p-dev"},  # no public
            "skill": "active-claude-github",
        }
        translated = _translate_config_schema(legacy)
        assert "public_face" not in translated


class TestFactoryPatternRule5:
    """Verify the 6 config-related models (D3.4 / #299) live behind
    cached factory helpers per Rule 5 (schema_as_functions).

    The class is defined inside ``_<name>_class()`` and exposed via a
    module-level re-export ``Name = _<name>_class()``. This test asserts
    the contract:
    - calling the helper twice returns the same class object (``@cache``)
    - the module-level binding resolves to the helper's return value
    - the class isn't a top-level ``ast.ClassDef`` (covered by the
      check_code_design gate; included here as a smoke check that the
      class's qualname reflects the nested definition).
    """

    @pytest.mark.parametrize(
        "name,helper_name",
        [
            ("RepoConfig", "_repo_config_class"),
            ("RelatedRepo", "_related_repo_class"),
            ("ProjectBoard", "_project_board_class"),
            ("DiscussionCategory", "_discussion_category_class"),
            ("DiscussionCategories", "_discussion_categories_class"),
            ("GithubConfig", "_github_config_class"),
            ("RepoShapeEntry", "_repo_shape_entry_class"),
            ("TocDrift", "_toc_drift_class"),
            ("SessionState", "_session_state_class"),
            ("PostTurnResult", "_post_turn_result_class"),
            ("CreateThreadResult", "_create_thread_result_class"),
            ("ClassifyResult", "_classify_result_class"),
            ("ThemeChangeResult", "_theme_change_result_class"),
            ("ForkResult", "_fork_result_class"),
            ("CreateIssueResult", "_create_issue_result_class"),
            ("SearchIssueHit", "_search_issue_hit_class"),
            ("SearchIssuesResult", "_search_issues_result_class"),
            ("OperationError", "_operation_error_class"),
        ],
    )
    def test_factory_pattern(self, name, helper_name):
        from forge_manager_mcp import models

        helper = getattr(models, helper_name)
        cls = getattr(models, name)
        assert helper() is helper(), f"{helper_name} not @cache-stable"
        assert cls is helper(), f"{name} module-level re-export drift"
        assert "<locals>" in cls.__qualname__, (
            f"{name}.__qualname__={cls.__qualname__!r}; expected nested "
            "class qualname (factory pattern signature)"
        )


if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
