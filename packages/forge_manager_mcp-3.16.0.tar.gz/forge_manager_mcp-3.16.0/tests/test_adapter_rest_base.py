"""(#428 / 3.12.0 D-Coverage drain) Tests for the shared REST adapter base.

Covers _get_client lazy construction, _request's TimeoutException /
RequestError → ForgeUnavailableError wrapping, and the ValueError
fallback for non-JSON 2xx response bodies.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters._rest_base import (
    DEFAULT_TIMEOUT_S,
    RestAdapterBase,
)


class _TestAdapter(RestAdapterBase):
    _AUTH_SCHEME = "token"
    _API_PATH = "/api/v1"
    _ADAPTER_NAME = "test-adapter"

    def __init__(self, token: str = "tk", api_base: str = "https://x"):
        self._token = token
        self._api_base = api_base
        self._client = None


@pytest.mark.asyncio
async def test_get_client_lazy_creation():
    adapter = _TestAdapter()
    # First call constructs the AsyncClient.
    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client_cls.return_value = MagicMock(aclose=AsyncMock())
        client = await adapter._get_client()
    assert client is not None
    assert adapter._client is client
    # Second call returns the same instance.
    client2 = await adapter._get_client()
    assert client2 is client


@pytest.mark.asyncio
async def test_request_timeout_wraps_as_unavailable():
    adapter = _TestAdapter()
    fake_client = MagicMock()
    fake_client.request = AsyncMock(
        side_effect=httpx.TimeoutException("simulated"),
    )
    with patch.object(adapter, "_get_client", AsyncMock(return_value=fake_client)):
        with pytest.raises(_errors.ForgeUnavailableError, match="timeout"):
            await adapter._request("GET", "/things")


@pytest.mark.asyncio
async def test_request_request_error_wraps_as_unavailable():
    adapter = _TestAdapter()
    fake_client = MagicMock()
    fake_client.request = AsyncMock(
        side_effect=httpx.ConnectError("network unreachable"),
    )
    with patch.object(adapter, "_get_client", AsyncMock(return_value=fake_client)):
        with pytest.raises(_errors.ForgeUnavailableError, match="network error"):
            await adapter._request("GET", "/things")


@pytest.mark.asyncio
async def test_2xx_with_non_json_body_returns_text():
    # Response.json() raises ValueError (non-JSON) → return response.text.
    # L137-139 fallback.
    adapter = _TestAdapter()
    fake_resp = MagicMock()
    fake_resp.status_code = 200
    fake_resp.content = b"not json"
    fake_resp.text = "not json"
    fake_resp.json = MagicMock(side_effect=ValueError("not json"))
    fake_client = MagicMock()
    fake_client.request = AsyncMock(return_value=fake_resp)
    with patch.object(adapter, "_get_client", AsyncMock(return_value=fake_client)):
        result = await adapter._request("GET", "/things")
    assert result == "not json"


@pytest.mark.asyncio
async def test_aclose_closes_client_singleton():
    # _client is set by a get_client call → aclose() invokes
    # self._client.aclose() and resets the singleton. L96-98.
    adapter = _TestAdapter()
    fake_client = MagicMock()
    fake_client.aclose = AsyncMock(return_value=None)
    adapter._client = fake_client
    await adapter.aclose()
    fake_client.aclose.assert_awaited_once()
    assert adapter._client is None


@pytest.mark.asyncio
async def test_204_no_content_returns_none():
    # 204 status → return None. L134-135.
    adapter = _TestAdapter()
    fake_resp = MagicMock()
    fake_resp.status_code = 204
    fake_resp.content = b""
    fake_client = MagicMock()
    fake_client.request = AsyncMock(return_value=fake_resp)
    with patch.object(
        adapter, "_get_client", AsyncMock(return_value=fake_client),
    ):
        result = await adapter._request("DELETE", "/things/1")
    assert result is None


@pytest.mark.asyncio
async def test_404_with_allow_404_returns_none():
    # 404 + allow_404_as_none → return None. L141-143.
    adapter = _TestAdapter()
    fake_resp = MagicMock()
    fake_resp.status_code = 404
    fake_resp.content = b"{}"
    fake_resp.text = "not found"
    fake_client = MagicMock()
    fake_client.request = AsyncMock(return_value=fake_resp)
    with patch.object(
        adapter, "_get_client", AsyncMock(return_value=fake_client),
    ):
        result = await adapter._request(
            "GET", "/missing", allow_404_as_none=True,
        )
    assert result is None


@pytest.mark.asyncio
async def test_unavailable_status_raises_unavailable():
    # status in _UNAVAILABLE_CODES (e.g. 503) → ForgeUnavailableError.
    # L144-149.
    adapter = _TestAdapter()
    fake_resp = MagicMock()
    fake_resp.status_code = 503
    fake_resp.text = "service unavailable"
    fake_resp.content = b"err"
    fake_client = MagicMock()
    fake_client.request = AsyncMock(return_value=fake_resp)
    with patch.object(
        adapter, "_get_client", AsyncMock(return_value=fake_client),
    ):
        with pytest.raises(
            _errors.ForgeUnavailableError, match="HTTP 503",
        ):
            await adapter._request("GET", "/things")


@pytest.mark.asyncio
async def test_other_4xx_5xx_raises_forge_error():
    # Status outside _UNAVAILABLE_CODES (e.g. 400) → ForgeError. L150.
    adapter = _TestAdapter()
    fake_resp = MagicMock()
    fake_resp.status_code = 400
    fake_resp.text = "bad request"
    fake_resp.content = b"err"
    fake_client = MagicMock()
    fake_client.request = AsyncMock(return_value=fake_resp)
    with patch.object(
        adapter, "_get_client", AsyncMock(return_value=fake_client),
    ):
        with pytest.raises(_errors.ForgeError, match="HTTP 400"):
            await adapter._request("POST", "/things")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
