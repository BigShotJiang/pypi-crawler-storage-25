"""(#428 / 3.12.0 D-Coverage drain) Tests for PlatformAdapter's
default-NotImplementedError methods.

The Protocol class defines five methods with a default body that
raises NotImplementedError so concrete adapters can opt out. Adapters
that don't override these (LocalStore for some, etc.) fall through
to the default impl; the ReplicationManager.read failover skips them.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.adapters.protocol import PlatformAdapter
from forge_manager_mcp.adapters.types import ArtifactRef


class _MinimalAdapter(PlatformAdapter):
    """An adapter that overrides none of the default-NotImplementedError
    methods, so calling any of them hits the default raise."""

    platform_id = "minimal"

    def __init__(self):
        pass

    @classmethod
    def from_config(cls, _config):
        return cls()


@pytest.mark.asyncio
async def test_list_all_issue_numbers_default_raises():
    a = _MinimalAdapter()
    with pytest.raises(NotImplementedError, match="list_all_issue_numbers"):
        await a.list_all_issue_numbers("o", "r")


@pytest.mark.asyncio
async def test_list_all_discussion_numbers_default_raises():
    a = _MinimalAdapter()
    with pytest.raises(NotImplementedError, match="list_all_discussion_numbers"):
        await a.list_all_discussion_numbers("o", "r")


@pytest.mark.asyncio
async def test_get_repo_visibility_default_raises():
    a = _MinimalAdapter()
    with pytest.raises(NotImplementedError, match="get_repo_visibility"):
        await a.get_repo_visibility("o", "r")


@pytest.mark.asyncio
async def test_get_file_content_default_raises():
    a = _MinimalAdapter()
    with pytest.raises(NotImplementedError, match="get_file_content"):
        await a.get_file_content("o", "r", "main", "path.md")


@pytest.mark.asyncio
async def test_update_issue_milestone_default_raises():
    a = _MinimalAdapter()
    ref = ArtifactRef(
        platform_id="minimal", native_id="issues/1",
        kind="issue", owner="o", repo="r", number=1,
    )
    with pytest.raises(NotImplementedError, match="milestone mutation"):
        await a.update_issue_milestone(ref, "3.12.0")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
