"""
Unit tests for the server package — build-server fast-fail, tool
registration, and the `resolve_thread_identifier` dispatch helper.

The pure parsers (parse_skill_version, parse_changelog, semver_gt,
parse_owner_repo) live in test_parsers.py.

The IO-free utilities (SessionActivity, compose_session_summary,
meets_confidence_threshold, check_overwrite_size) live in
test_utils.py.

Full tool execution is covered in tests/tools/.
MCP protocol compliance is covered in tests/integration/.
"""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from forge_manager_mcp.adapters.types import ArtifactRef, Discussion, Issue
from forge_manager_mcp.config import ConfigError
from forge_manager_mcp.server import build_server
from forge_manager_mcp.server.helpers import resolve_thread_identifier


def _stub_canonical(*, issue_native: str = "issues/42", disc_native: str = "discussions/7"):
    """Minimal canonical PlatformAdapter stub.

    3.5.0 Phase C → 3.7.0 D8.9 — resolve_thread_identifier now
    dispatches through the daemon's `resolve_thread_identifier` op.
    The stub exposes get_issue / get_discussion so the bridge
    fixture's monkeypatched `dispatch_read` can drive the canonical
    lookup against the same shape.
    """
    issue = Issue(
        ref=ArtifactRef(
            platform_id="local-test",
            native_id=issue_native,
            kind="issue",
            owner="defowner",
            repo="defrepo",
            number=42,
        ),
        title="(stub)",
        body="(stub)",
        state="open",
        labels=[],
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    discussion = Discussion(
        ref=ArtifactRef(
            platform_id="local-test",
            native_id=disc_native,
            kind="discussion",
            owner="defowner",
            repo="defrepo",
            number=7,
        ),
        title="(stub)",
        body="(stub)",
        state="open",
        category="Architecture",
        created_at=datetime.now(timezone.utc),
    )
    return SimpleNamespace(
        platform_id="local-test",
        get_issue=AsyncMock(return_value=issue),
        get_discussion=AsyncMock(return_value=discussion),
    )


def _patch_dispatch_read_via_canonical(monkeypatch, canonical):
    """(#356, 3.7.0 D8.9) Bridge `dispatch_read("resolve_thread_
    identifier", ...)` to the test's canonical stub. Mirrors what
    the daemon op does server-side. Tests can still drive the
    canonical adapter mock to verify call-arg shape.
    """
    async def _stub(state_dir, op, args):
        if op != "resolve_thread_identifier":
            raise NotImplementedError(f"unexpected op: {op}")
        primary_id = args.get("primary_id") or ""
        if primary_id:
            return {"value": primary_id}
        number = args.get("number")
        if number is None:
            return {"value": ""}
        kind = args["kind"]
        owner = args["owner"]
        repo = args["repo"]
        if kind == "issue":
            issue = await canonical.get_issue(owner, repo, int(number))
            return {"value": issue.ref.native_id}
        if kind == "discussion":
            discussion = await canonical.get_discussion(
                owner, repo, int(number),
            )
            return {"value": discussion.ref.native_id}
        raise ValueError(f"Unsupported kind: {kind!r}")

    monkeypatch.setattr(
        "forge_manager_mcp.daemon_client.dispatch_read", _stub,
    )


class TestResolveThreadIdentifier:
    """#56 (original) + #309 / 3.5.0 Phase C (canonical-first refactor).

    resolve_thread_identifier translates either a primary-id arg or
    (number, owner, repo) into a canonical native_id. 3.5.0 dropped the
    GitHub-direct GraphQL roundtrip and routes number→ref through the
    canonical adapter. Tests verify the canonical is consulted and no
    GitHub call ever fires.
    """

    @pytest.mark.asyncio
    async def test_uses_node_id_when_provided(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"issue_id": "I_abc"},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="owner",
            default_repo="repo",
        )
        assert result == "I_abc"
        canonical.get_issue.assert_not_called()
        canonical.get_discussion.assert_not_called()

    @pytest.mark.asyncio
    async def test_resolves_from_number_with_default_owner_repo(self, monkeypatch):
        canonical = _stub_canonical(issue_native="issues/42")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 42},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="defowner",
            default_repo="defrepo",
        )
        assert result == "issues/42"
        canonical.get_issue.assert_called_once_with("defowner", "defrepo", 42)

    @pytest.mark.asyncio
    async def test_explicit_owner_repo_override_defaults(self, monkeypatch):
        canonical = _stub_canonical(disc_native="discussions/7")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 7, "owner": "alt", "repo": "altrepo"},
            primary_id_param="discussion_id",
            kind="discussion",
            default_owner="defowner",
            default_repo="defrepo",
        )
        assert result == "discussions/7"
        canonical.get_discussion.assert_called_once_with("alt", "altrepo", 7)

    @pytest.mark.asyncio
    async def test_both_forms_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="either"):
            await resolve_thread_identifier(
                {"issue_id": "I_abc", "number": 42},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_neither_form_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="must be provided"):
            await resolve_thread_identifier(
                {},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_non_integer_number_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="number must be"):
            await resolve_thread_identifier(
                {"number": "not_an_int"},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_unknown_kind_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="Unsupported kind"):
            await resolve_thread_identifier(
                {"number": 1},
                primary_id_param="thread_id",
                kind="pull_request",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_canonical_first_no_github_required(self, monkeypatch):
        """The post-3.5.0 contract: number-resolution succeeds without any
        GitHub credentials available — closes the bug class that caused
        every `close_issue_with_comment(number=...)` against the dev repo
        to fail with HTTP 403 + buffered while GitHub access was
        suspended (2026-04-28+).

        Post-D8.9 the resolution flows through the daemon's
        `resolve_thread_identifier` op rather than calling the
        canonical adapter directly. The bridge fixture preserves
        the same contract."""
        canonical = _stub_canonical(issue_native="issues/316")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 316},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="telejester-claude-skills",
            default_repo="telejester-claude-skills-dev",
        )
        assert result == "issues/316"
        canonical.get_issue.assert_called_once()


class TestResolveThreadIdentifierPlatformId:
    """(#464, 3.14.0) MCP-side passthrough of the optional
    ``platform_id`` parameter. The helper plumbs the value verbatim
    to the daemon op via dispatch_read; the daemon op selects the
    matching adapter. Bug 1 of public-mirror #7 — operator path for
    "this number means GitHub specifically" on a project where
    canonical-local has its own number space.
    """

    @pytest.mark.asyncio
    async def test_platform_id_passes_through_to_daemon_op(self, monkeypatch):
        """(#464 AC: when platform_id set, daemon's
        resolve_thread_identifier receives it.) The helper does not
        intercept the value — it forwards verbatim so the daemon's
        single-source-of-truth resolution logic stays uniform."""
        captured: dict = {}

        async def _stub(state_dir, op, args):
            captured["op"] = op
            captured["args"] = args
            return {"value": "GHID_169"}

        monkeypatch.setattr(
            "forge_manager_mcp.daemon_client.dispatch_read", _stub,
        )

        result = await resolve_thread_identifier(
            {"number": 169, "platform_id": "github"},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="acme",
            default_repo="widgets",
        )

        assert result == "GHID_169"
        assert captured["op"] == "resolve_thread_identifier"
        assert captured["args"]["platform_id"] == "github"
        assert captured["args"]["number"] == 169

    @pytest.mark.asyncio
    async def test_platform_id_omitted_sends_none(self, monkeypatch):
        """(#464 backward-compat) Omitted platform_id maps to None in
        the op args — preserves today's canonical-first semantics on
        the daemon side."""
        captured: dict = {}

        async def _stub(state_dir, op, args):
            captured["args"] = args
            return {"value": "issues/42"}

        monkeypatch.setattr(
            "forge_manager_mcp.daemon_client.dispatch_read", _stub,
        )

        await resolve_thread_identifier(
            {"number": 42},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="o", default_repo="r",
        )

        assert captured["args"]["platform_id"] is None

    @pytest.mark.asyncio
    async def test_bad_platform_id_surfaces_daemon_error(self, monkeypatch):
        """(#464 AC: bad platform_id fails before dispatch with clear
        error.) The daemon's resolver raises ValueError; the MCP-side
        helper does not swallow it — the operator sees the message."""
        async def _stub(state_dir, op, args):
            # Mirror the real daemon behavior: bad platform_id raises
            # before any adapter touch.
            raise ValueError(
                f"platform_id={args.get('platform_id')!r} not in "
                f"replication_order (known: ['local', 'github'])."
            )

        monkeypatch.setattr(
            "forge_manager_mcp.daemon_client.dispatch_read", _stub,
        )

        with pytest.raises(ValueError, match="not in replication_order"):
            await resolve_thread_identifier(
                {"number": 169, "platform_id": "gitlab"},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="o", default_repo="r",
            )


TOOL_NAMES = {
    "open_session",
    "recover_context",
    "check_skill_version",
    "replay_pending",
    "get_thread_comments",
    "close_issue_with_comment",
    "close_triaged_public_issues",
    "close_session",
    "post_turn",
    "create_thread",
    "classify_turn",
    "classify_and_create",
    "scaffold_project",
    "scaffold_project_multi",
    "detect_theme_change",
    "fork_discussion",
    "create_issue",
    "search_issues",
    "update_issue_toc",
    "move_project_item",
    "update_project_toc",
    "update_discussion_body",
    "compose_post_reframe_toc",
    "mark_discussion_decided",
    "validate_release",
    "release_project",
    "generate_changelog",
    "verify_plan_completeness",
    "verify_diff_covers_plan",
    "verify_existing_code_assumptions",
    "migrate_to_3_0",
    "migrate_to_3_0_rollback",
    "migrate_to_3_5",
    "migrate_to_3_5_rollback",
    "migrate_to_4_0",
    "migrate_to_4_0_rollback",
    "add_backend",
    "audit_project_prose",
    "shadow_query",  # (#475 / 3.14.0)
    "check_code_design",
    "get_daemon_alerts",
    "get_daemon_status",
    "get_code_design_status",
    "analyze_gaps",
    "search_local",
    "run_command",  # (#387, 3.9.0 D4.3) text command grammar dispatch
    "fix_repo_shape",  # (#456, 3.13.0 D-Friction.2) visibility-flip tool
    "update_issue_milestone",  # (#388, 3.9.0 D5) milestone mutation
    # (#397, 3.11.0 D1.a Phase 2b) milestone-as-compound-doc surface
    "create_milestone",
    "update_milestone_body",
    "mark_milestone_active",
    "close_milestone",
    "set_milestone_plan",
    # (#397, 3.11.0 D1.a Phase 3b) milestone-compound-doc backfill
    "migrate_to_4_1",
    # (#405, 3.11.0 D1.b Phase 2b) gap-as-compound-doc 4-state triage
    "triage_gap",
    "accept_gap",
    "file_gap",
    "ignore_gap",
    # (#406, 3.11.0 D2.a) Claude Code gap surface
    "gaps_for_file",
    # (#501) mode-registry surface — list / get-current / apply
    "list_modes",
    "get_current_mode",
    "set_mode",
    # (#506-512 / 3.16.0 D4) generic field-bag mutation surface
    "update_issue_meta",
    "update_discussion_meta",
    "update_milestone_meta",
    "add_label",
    "remove_label",
    "reopen_issue",
    "unmark_decided",
    # (#506 D5 / 3.16.0) public-issue triage classifier
    "triage_classify",
}


class TestBuildServerFastFail:
    def test_raises_config_error_if_project_dir_missing(self, tmp_path):
        missing = tmp_path / "no-such-dir"
        with pytest.raises(ConfigError, match="does not exist"):
            build_server(missing)

    def test_no_config_file_starts_in_pre_bootstrap_mode(
        self, empty_project_dir, monkeypatch
    ):
        # #156 — absent .claude/github-config.json is no longer fatal.
        # The server starts in degraded mode: config=None, pre_bootstrap=True.
        # Tool dispatch will reject every tool except scaffold_project /
        # check_skill_version (covered by separate dispatch tests).
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        server, config, _, _ = build_server(empty_project_dir)
        assert server is not None
        assert config is None

    def test_raises_config_error_if_api_key_missing(
        self, project_dir, monkeypatch
    ):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        with pytest.raises(ConfigError, match="ANTHROPIC_API_KEY"):
            build_server(project_dir)


class TestBuildReplication:
    """#274 — `_build_replication` constructs the per-server
    ReplicationManager from project config.

    Pre-bootstrap (config is None) returns None so the server can
    still start in degraded mode (#156). With a loaded config it
    wraps a single GitHubAdapter as the canonical entry — the 2.x
    config schema doesn't yet carry a multi-platform list.
    """

    def test_returns_none_pre_bootstrap(self):
        from forge_manager_mcp.server.build import _build_replication
        assert _build_replication(None, "ghp_test") is None

    def test_wraps_github_adapter_when_config_present(self, project_dir):
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")

        assert manager is not None
        assert manager.canonical().platform_id == "github"
        assert manager.healthy_adapters() == ["github"]

    def test_3_0_multi_platform_local_canonical(
        self, project_dir, tmp_path, monkeypatch
    ):
        """#274 Phase D — when schema_version is "3.0", the manager
        assembles platforms in replication_order with the first as
        canonical. Local-first per OQ3."""
        import copy
        import json
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        # GitHubAdapter.from_config calls get_github_token() which
        # reads $GITHUB_TOKEN; in this test environment we set it
        # explicitly rather than rely on `gh auth token`.
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [
            {"id": "local", "path": str(tmp_path / "docs")},
            {"id": "github", "owner": "telejester",
             "private": "telejester/dev", "public": "telejester/pub"},
        ]
        cfg["replication_order"] = ["local", "github"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )
        (tmp_path / "docs").mkdir()

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")

        assert manager is not None
        # Canonical = first entry in replication_order = local.
        assert manager.canonical().platform_id == "local"
        states = manager.states()
        assert "local" in states
        assert "github" in states

    def test_3_0_unknown_platform_id_raises(self, project_dir):
        import copy
        import json
        from forge_manager_mcp.config import ConfigError, load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [{"id": "bitbucket", "owner": "x"}]
        cfg["replication_order"] = ["bitbucket"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        with pytest.raises(ConfigError, match="Unknown platform_id"):
            _build_replication(config, "ghp_test")

    def test_3_0_replication_order_references_missing_platform_raises(
        self, project_dir, monkeypatch
    ):
        """A non-local platform in replication_order without a
        matching platforms[] entry is a config inconsistency."""
        import copy
        import json
        from forge_manager_mcp.config import ConfigError, load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        # gitlab is referenced in order but no entry in platforms[].
        cfg["platforms"] = [
            {"id": "github", "owner": "x", "private": "x/dev",
             "public": "x/pub"},
        ]
        cfg["replication_order"] = ["github", "gitlab"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        with pytest.raises(ConfigError, match="no matching entry"):
            _build_replication(config, "ghp_test")

    def test_normalize_per_platform_categories_flat(self):
        """#299 / 3.6.0 D3 — per-platform discussion_categories
        flat shape (`{"Architecture": "DIC_..."}`) flattens to
        name → ID dict directly."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        })
        assert result == {
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        }

    def test_normalize_per_platform_categories_object(self):
        """Object shape (`{"Architecture": {"id": "DIC_..."}}`)
        also flattens correctly — mirrors the legacy 3.x
        DiscussionCategories model_dump output."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Architecture": {"id": "DIC_arch"},
            "Ideas": {"id": "DIC_ideas"},
        })
        assert result == {
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        }

    def test_normalize_per_platform_categories_announcements_alias(self):
        """#191 alias preserved: Announcements ↔ Project."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        # Only Announcements set → Project mirrors it.
        result = _normalize_per_platform_categories({
            "Announcements": "DIC_ann",
        })
        assert result["Project"] == "DIC_ann"
        # Only Project set → Announcements mirrors it.
        result = _normalize_per_platform_categories({
            "Project": "DIC_proj",
        })
        assert result["Announcements"] == "DIC_proj"

    def test_normalize_per_platform_categories_skips_empty(self):
        """Empty string IDs and missing `id` keys silently drop."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Empty": "",
            "Ok": "DIC_ok",
            "MissingId": {},
            "OkObject": {"id": "DIC_obj"},
        })
        assert result == {"Ok": "DIC_ok", "OkObject": "DIC_obj"}

    def test_3_0_local_is_implicit_when_absent_from_platforms(
        self, project_dir, tmp_path, monkeypatch
    ):
        """``local`` is allowed in replication_order without an
        explicit platforms entry — LocalStoreAdapter falls back to
        the env var or home-dir default."""
        import copy
        import json
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        docs_path = tmp_path / "implicit-docs"
        docs_path.mkdir()
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(docs_path))

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = []  # no explicit local entry
        cfg["replication_order"] = ["local"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")
        assert manager is not None
        assert manager.canonical().platform_id == "local"


class TestToolRegistration:
    """
    Verify that all expected tools are registered and have
    valid inputSchema definitions.
    """

    @pytest.fixture
    def server_and_config(self, project_dir, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        return build_server(project_dir)

    @pytest.mark.asyncio
    async def test_all_tools_registered(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        tool_names = {t.name for t in tools}
        assert TOOL_NAMES == tool_names, (
            f"Missing tools: {TOOL_NAMES - tool_names}\n"
            f"Extra tools: {tool_names - TOOL_NAMES}"
        )

    @pytest.mark.asyncio
    async def test_all_tools_have_schemas(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        for tool in tools:
            assert tool.inputSchema is not None, f"{tool.name} missing inputSchema"
            assert tool.inputSchema.get("type") == "object", (
                f"{tool.name} inputSchema type should be 'object'"
            )

    @pytest.mark.asyncio
    async def test_required_fields_declared(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        tool_map = {t.name: t for t in tools}

        # post_turn requires thread_type / speaker / body. thread_id is
        # optional post-#56 — callers can provide number + owner/repo
        # instead.
        post_turn = tool_map["post_turn"]
        assert set(post_turn.inputSchema.get("required", [])) >= {
            "thread_type", "speaker", "body"
        }
        props = post_turn.inputSchema.get("properties", {})
        assert "thread_id" in props
        assert "number" in props

        # create_issue requires title and body. Either `labels` (list)
        # or `label` (deprecated single) must be supplied at call time
        # but neither is declared required in the schema (#55).
        create_issue = tool_map["create_issue"]
        assert set(create_issue.inputSchema.get("required", [])) >= {
            "title", "body"
        }
        props = create_issue.inputSchema.get("properties", {})
        assert "labels" in props
        assert "label" in props  # deprecated alias still present


class TestPackageLazyExports:
    def test_main_lazy_export_resolves(self):
        # forge_manager_mcp.server.main is a lazy __getattr__ export →
        # exercise the L112-114 "if name == 'main'" branch.
        import forge_manager_mcp.server as srv
        assert callable(getattr(srv, "main"))

    def test_unknown_attribute_raises_attribute_error(self):
        # __getattr__ falls through to AttributeError. L115.
        import forge_manager_mcp.server as srv
        with pytest.raises(AttributeError):
            getattr(srv, "definitely_not_a_real_export")


class TestResolvePublicFace:
    """(#428) Drain build.py _resolve_public_face paths."""

    def test_no_config_returns_none(self):
        # (#428) L373-374 — config None → None.
        from forge_manager_mcp.server.build import _resolve_public_face
        assert _resolve_public_face(None, "ghp_test") is None

    def test_no_public_face_returns_none(self, project_dir):
        # (#428) L373-374 — config.public_face None → None.
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face
        config = load_config(project_dir)
        # ctx fixture loads VALID_CONFIG which has no public_face.
        assert config.public_face is None
        assert _resolve_public_face(config, "ghp_test") is None

    def test_2x_github_target_returns_github_adapter(self, project_dir):
        # (#428) L375-380 — 2.x schema with public_face="github" →
        # GitHubAdapter.
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face
        from forge_manager_mcp.adapters.github import GitHubAdapter

        config = load_config(project_dir)
        # Force a 2.x schema with public_face set.
        config = config.model_copy(update={
            "schema_version": "2.0",
            "public_face": "github",
        })
        adapter = _resolve_public_face(config, "ghp_test")
        assert isinstance(adapter, GitHubAdapter)

    def test_2x_non_github_target_returns_none(self, project_dir):
        # (#428) L379-381 — 2.x but public_face!="github" → None.
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face

        config = load_config(project_dir)
        config = config.model_copy(update={
            "schema_version": "2.0",
            "public_face": "codeberg",
        })
        assert _resolve_public_face(config, "ghp_test") is None

    def test_3_0_unknown_adapter_returns_none(self, project_dir):
        # (#428) L386-388 — adapter class not registered → None.
        # Build a valid 3.0 config then drop the platform from
        # _PLATFORM_ADAPTERS at runtime.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [
            {"id": "local", "path": str(project_dir / "docs")},
        ]
        cfg["replication_order"] = ["local"]
        cfg["public_face"] = "local"
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        config = load_config(project_dir)
        from forge_manager_mcp.server import build as _b
        original = _b._PLATFORM_ADAPTERS
        try:
            _b._PLATFORM_ADAPTERS = {}  # bypass "local" lookup
            assert _resolve_public_face(config, "ghp_test") is None
        finally:
            _b._PLATFORM_ADAPTERS = original

    def test_3_0_public_face_missing_from_platforms_returns_none(
        self, project_dir,
    ):
        # (#428) L382-385 — 3.0 with public_face id not in platforms_by_id.
        # Use model_construct to bypass schema validation that normally
        # cross-checks public_face against platforms.
        from forge_manager_mcp.models import GithubConfig
        from forge_manager_mcp.server.build import _resolve_public_face

        config = GithubConfig.model_construct(
            schema_version="3.0",
            platforms=[{"id": "local", "path": "/tmp/x"}],
            replication_order=["local"],
            public_face="codeberg",  # not in platforms
            discussion_categories=None,
        )
        assert _resolve_public_face(config, "ghp_test") is None

    def test_3_0_github_with_discussion_categories_injects(
        self, project_dir, monkeypatch,
    ):
        # (#428) L389-394 — 3.0 with github public_face + discussion
        # categories → categories injected into platform_config.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face
        from forge_manager_mcp.adapters.github import GitHubAdapter
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_stub")

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [
            {
                "id": "github",
                "owner": "stub-owner",
                "public": "stub-owner/public",
                "private": "stub-owner/private",
            },
        ]
        cfg["replication_order"] = ["github"]
        cfg["public_face"] = "github"
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        config = load_config(project_dir)
        adapter = _resolve_public_face(config, "ghp_test")
        assert isinstance(adapter, GitHubAdapter)

    def test_3_0_resolves_local_adapter(self, project_dir):
        # (#428) L382-394 — 3.0 happy path: platform in list,
        # adapter cls registered → returns the constructed adapter.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _resolve_public_face
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        docs_dir = project_dir / "docs"
        docs_dir.mkdir()
        cfg["platforms"] = [
            {"id": "local", "path": str(docs_dir)},
        ]
        cfg["replication_order"] = ["local"]
        cfg["public_face"] = "local"
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        config = load_config(project_dir)
        adapter = _resolve_public_face(config, "ghp_test")
        assert isinstance(adapter, LocalStoreAdapter)


class TestBuildReplicationPerPlatformCategories:
    """(#428) Drain build.py 4.0 schema per-platform categories injection
    path (L243-252)."""

    def test_per_platform_categories_normalized_and_injected(
        self, project_dir, monkeypatch, tmp_path,
    ):
        # (#428) L243-252 — 4.0 shape with platform-local
        # discussion_categories → normalize + inject into platform_config.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        cfg["platforms"] = [
            {
                "id": "local",
                "path": str(docs_dir),
                # 4.0 shape — per-platform map.
                "discussion_categories": {
                    "Architecture": "DIC_arch",
                    "UX_UI": "DIC_ux",
                },
            },
        ]
        cfg["replication_order"] = ["local"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")
        assert manager is not None
        # canonical adapter is local; the 4.0 path normalized the per-
        # platform map before from_config consumed it.
        assert manager.canonical().platform_id == "local"


class TestBuildServerCanonicalPlatformId:
    """(#428) Drain build.py canonical_platform_id resolution paths."""

    def test_3_0_canonical_from_replication_order(
        self, project_dir, monkeypatch, tmp_path,
    ):
        # (#428) L457-458 — schema 3.0 + replication_order →
        # canonical_platform_id = first entry.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.server.build import build_server

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        cfg["platforms"] = [
            {"id": "local", "path": str(docs_dir)},
        ]
        cfg["replication_order"] = ["local"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        server_obj, config, _, _ = build_server(project_dir)
        assert server_obj is not None
        assert config is not None
        assert config.schema_version == "3.0"


class TestBuildServerWithGateRegistry:
    """(#428) Drain build.py gate registry registration paths (L439-450)
    by constructing a build_server with a real gates.yaml."""

    def test_build_server_registers_runbook_evaluators(
        self, project_dir, monkeypatch,
    ):
        # (#428) L439-450 — gate_registry non-None →
        # register_runbook_evaluators + register_cut_gate +
        # register_coverage_gate.
        from forge_manager_mcp.server.build import build_server

        skill_dir = project_dir / ".claude" / "skills" / "forge-manager"
        skill_dir.mkdir(parents=True, exist_ok=True)
        # Minimal valid gates.yaml with one pre-publish gate.
        (skill_dir / "gates.yaml").write_text(
            "gates:\n"
            "  - name: publish.stub\n"
            "    type: pre-publish\n"
            "    location: release.md#publish.stub\n"
            "    summary: stub\n"
            "    default_state: open\n"
            "    extension_semantics: tighten\n"
            "    override_semantics: replace\n"
            "    state_change_semantics: open_close\n"
            "    rationale_doc: release.md#publish.stub\n"
            "    introduced_in: \"3.4.0\"\n"
            "    runbook_url: runbooks/publish-stub.md\n",
        )
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        server, _, _, _ = build_server(project_dir)
        # build_server returns; no exception means the registration ran.
        assert server is not None


class TestLoadRegistriesFailures:
    """(#428) Drain build.py _load_registries + _load_project_rules
    error paths."""

    def test_malformed_gates_yaml_warns_and_returns_none(
        self, tmp_path, caplog,
    ):
        # (#428) L293-297 — load_gates raises GateRegistryError → warn
        # logged, gate_registry stays None.
        from forge_manager_mcp.server.build import _load_registries
        skill_dir = tmp_path / ".claude" / "skills" / "forge-manager"
        skill_dir.mkdir(parents=True)
        (skill_dir / "gates.yaml").write_text("not: valid: gate: yaml\n")
        gate_reg, _ = _load_registries(tmp_path)
        assert gate_reg is None

    def test_malformed_processes_yaml_warns_and_returns_none(
        self, tmp_path,
    ):
        # (#428) L300-306 — load_processes raises GateRegistryError →
        # warn logged, process_registry stays None.
        from forge_manager_mcp.server.build import _load_registries
        skill_dir = tmp_path / ".claude" / "skills" / "forge-manager"
        skill_dir.mkdir(parents=True)
        (skill_dir / "processes.yaml").write_text("not: valid: process: yaml\n")
        _, proc_reg = _load_registries(tmp_path)
        assert proc_reg is None


class TestLoadProjectRulesFailures:
    def test_malformed_rules_md_warns_and_returns_none(self, tmp_path):
        # (#428) L333-337 — ProjectRulesError on parse → warn + None.
        from forge_manager_mcp.server.build import _load_project_rules
        (tmp_path / ".claude").mkdir()
        # Project-rules with malformed gate-ref heading.
        (tmp_path / ".claude" / "project-rules.md").write_text(
            "## Gate extensions\n\n"
            "### Extends garbage_no_backticks\n"
            "**Extension:** something\n",
        )
        result = _load_project_rules(tmp_path, gate_registry=None)
        assert result is None

    def test_unknown_gate_ref_validates_but_attaches(
        self, tmp_path, project_dir,
    ):
        # (#428) L338-348 — validate_against_registry raises but rules
        # still load (warn logged; rules returned).
        from forge_manager_mcp.server.build import (
            _load_project_rules, _load_registries,
        )
        from forge_manager_mcp.gate_registry import GateRegistry

        # Empty registry so any rule reference is "unknown".
        empty_reg = GateRegistry([])
        (project_dir / ".claude" / "project-rules.md").write_text(
            "## Gate extensions\n\n"
            "### Extends `commit.test_coverage`\n"
            "**Extension:** custom rule\n",
        )
        result = _load_project_rules(project_dir, gate_registry=empty_reg)
        # Rules attached (validation warns but doesn't reject).
        assert result is not None


class TestDiscussionCategoriesMap:
    """(#428) Drain _discussion_categories_map paths in build.py."""

    def test_none_categories_returns_empty(self, project_dir):
        # (#428) L173-174 — config.discussion_categories is None → {}.
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _discussion_categories_map
        config = load_config(project_dir)
        # Override discussion_categories to None.
        config = config.model_copy(update={"discussion_categories": None})
        assert _discussion_categories_map(config) == {}

    def test_announcements_only_aliases_project(self, project_dir):
        # (#428) L185-186 — Announcements populated, Project not →
        # Project alias mirrors Announcements ID.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _discussion_categories_map

        cfg = copy.deepcopy(VALID_CONFIG)
        # Add an Announcements extra alongside the existing required cats.
        cfg["discussion_categories"]["Announcements"] = {
            "id": "DIC_ann_xyz", "isAnswerable": False,
        }
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        config = load_config(project_dir)
        result = _discussion_categories_map(config)
        assert result.get("Announcements") == "DIC_ann_xyz"
        # Project alias mirrors Announcements when only Announcements is set.
        assert result.get("Project") == "DIC_ann_xyz"

    def test_project_only_aliases_announcements(self, project_dir):
        # (#428) L187-188 — Project populated, Announcements not →
        # Announcements alias mirrors Project ID.
        import copy
        import json
        from tests.conftest import VALID_CONFIG
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _discussion_categories_map

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["discussion_categories"]["Project"] = {
            "id": "DIC_proj_xyz", "isAnswerable": False,
        }
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8",
        )
        config = load_config(project_dir)
        result = _discussion_categories_map(config)
        assert result.get("Project") == "DIC_proj_xyz"
        # Announcements alias mirrors Project when only Project is set.
        assert result.get("Announcements") == "DIC_proj_xyz"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
