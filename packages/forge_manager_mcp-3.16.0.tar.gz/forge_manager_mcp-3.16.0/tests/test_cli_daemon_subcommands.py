"""Tests for the `daemon-status` / `open-ui` CLI subcommands (#335).

The MCP-server default mode (no subcommand) is exercised by
test_server.py + integration; we don't re-cover it here. These
tests focus on the new subcommand routing + output shapes.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone

import pytest

from forge_manager_mcp.daemon import discovery as discovery_mod
from forge_manager_mcp.daemon.discovery import (
    make_discovery_file, write_discovery,
)
from forge_manager_mcp.daemon_client import DaemonStatus
from forge_manager_mcp.server import cli as cli_mod


def _stub_df(**overrides):
    defaults = {
        "pid": 99999,
        "port": 51223,
        "version": "3.5.0",
        "started_at": datetime(2026, 5, 5, 12, 0, tzinfo=timezone.utc),
        "auth_token": "x" * 64,
    }
    defaults.update(overrides)
    return make_discovery_file(**defaults)


class TestDaemonStatus_Absent:
    def test_human_format_reports_absent(
        self, tmp_path, monkeypatch, capsys,
    ):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 1
        out = capsys.readouterr().out
        assert "ABSENT" in out
        assert str(tmp_path) in out

    def test_json_format_reports_absent(
        self, tmp_path, monkeypatch, capsys,
    ):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status", "--json"])
        assert excinfo.value.code == 1
        payload = json.loads(capsys.readouterr().out)
        assert payload["status"] == "absent"
        assert payload["state_dir"] == str(tmp_path)


class TestDaemonStatus_Running:
    def test_human_format_reports_running(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=51223, version="3.5.0"))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # Bypass /health probe — return RUNNING.
        from forge_manager_mcp.server import cli as _cli_mod
        monkeypatch.setattr(
            _cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "RUNNING" in out
        assert "3.5.0" in out
        assert "http://127.0.0.1:51223/" in out

    def test_json_format_reports_running(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=51223, version="3.5.0"))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status", "--json"])
        assert excinfo.value.code == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["status"] == "running"
        assert payload["version"] == "3.5.0"
        assert payload["url"] == "http://127.0.0.1:51223/"


class TestDaemonStatus_Stale:
    def test_stale_exits_2_with_next_step(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df())
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.STALE,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 2
        out = capsys.readouterr().out
        assert "STALE" in out
        assert "daemon-restart" in out


class TestOpenUi:
    def test_no_daemon_exits_1(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 1
        err = capsys.readouterr().err
        assert "No daemon running" in err

    def test_running_no_browser_prints_url(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui", "--no-browser"])
        assert excinfo.value.code == 0
        assert "http://127.0.0.1:12345/" in capsys.readouterr().out

    def test_running_launches_browser(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        opened = {}
        # Stub webbrowser via sys.modules so the cli's import inside
        # _run_open_ui resolves to our fake.
        import types
        fake_wb = types.SimpleNamespace(
            open=lambda url: opened.setdefault("url", url),
        )
        monkeypatch.setitem(sys.modules, "webbrowser", fake_wb)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 0
        assert opened["url"] == "http://127.0.0.1:12345/"

    def test_stale_exits_2(self, tmp_path, monkeypatch, capsys):
        write_discovery(tmp_path, _stub_df())
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.STALE,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 2
        err = capsys.readouterr().err
        assert "/health is unreachable" in err


class TestDaemonStop:
    """#339 — `forge-manager-mcp daemon-stop`."""

    def test_no_daemon_exits_1(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 1
        assert "No daemon running" in capsys.readouterr().err

    def test_stale_pid_cleans_up_file(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # First os.kill(pid, sig) raises ProcessLookupError → already gone.
        kill_calls = []
        def _kill(pid, sig):
            kill_calls.append((pid, sig))
            raise ProcessLookupError(f"no such process {pid}")
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        assert kill_calls[0][0] == 99999
        out = capsys.readouterr().out
        assert "stale discovery file" in out

    def test_clean_sigterm(self, tmp_path, monkeypatch, capsys):
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # (#497) Stub the Layer-1 pre-checks so the signal-send path
        # executes — alive=True + zombie=False means we proceed past
        # the zombie/dead short-circuits into the SIGTERM branch.
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        # First kill = signal send (succeeds); subsequent kill(pid, 0) =
        # liveness probe that raises ProcessLookupError → process dead.
        sent = []
        liveness_probes = {"n": 0}
        def _kill(pid, sig):
            if sig == 0:
                liveness_probes["n"] += 1
                raise ProcessLookupError("dead")
            sent.append((pid, sig))
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "stopped via SIGTERM" in out

    def test_force_uses_sigkill(self, tmp_path, monkeypatch, capsys):
        import signal
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # (#497) Bypass the Layer-1 pre-checks (see test_clean_sigterm).
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        sent = []
        def _kill(pid, sig):
            if sig == 0:
                raise ProcessLookupError("dead")
            sent.append((pid, sig))
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit):
            cli_mod.main(["daemon-stop", "--force"])
        assert any(sig == signal.SIGKILL for _, sig in sent)


class TestDaemonRestart:
    """#339 — `forge-manager-mcp daemon-restart`."""

    def _stub_restart_env(self, tmp_path, monkeypatch):
        """Shared monkeypatch fixture for the restart subcommand.

        Wires the state-dir, neutralizes the stop-path kill, stubs
        ``spawn_daemon`` to record its kwargs + write a fresh
        discovery file, and short-circuits ``wait_for_discovery``.
        Returns the ``spawn_calls`` list each test inspects.
        """
        from forge_manager_mcp.server import cli as _cli_mod
        write_discovery(tmp_path, _stub_df(pid=11111))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        import os as _os
        def _kill(pid, sig):
            raise ProcessLookupError("dead")
        monkeypatch.setattr(_os, "kill", _kill)
        spawn_calls: list[dict] = []
        def _spawn(sd, name, *, project_dir=None):
            spawn_calls.append(
                {"sd": sd, "name": name, "project_dir": project_dir},
            )
            write_discovery(sd, _stub_df(pid=22222, port=9999))
            return 22222
        monkeypatch.setattr(_cli_mod, "spawn_daemon", _spawn)
        monkeypatch.setattr(
            _cli_mod, "wait_for_discovery", lambda sd, timeout=5.0: True,
        )
        return spawn_calls

    def test_restart_with_running_daemon(
        self, tmp_path, monkeypatch, capsys,
    ):
        spawn_calls = self._stub_restart_env(tmp_path, monkeypatch)

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "daemon-restart", "--project-dir", str(tmp_path / "proj"),
            ])
        assert excinfo.value.code == 0
        # ``.resolve()`` is idempotent on already-absolute paths that
        # do not traverse symlinks, so the comparison still matches
        # the sub-form argument verbatim.
        assert spawn_calls[0]["project_dir"] == (tmp_path / "proj")
        out = capsys.readouterr().out
        assert "respawned" in out
        assert "PID=22222" in out

    def test_parent_project_dir_threaded_to_spawn(
        self, tmp_path, monkeypatch, capsys,
    ):
        """#498 — parent CLI ``--project-dir`` flows through to the
        spawned daemon's ``project_dir`` kwarg even when the sub form
        omits its own ``--project-dir`` flag.

        Pre-#498 the subparser declared ``default=None`` which won
        argparse's parent-vs-sub merge, so the spawned daemon's argv
        had no ``--project-dir`` — daemon came up with
        ``config_loaded: false`` (the operator-visible repro from the
        Issue body). Post-#498 ``argparse.SUPPRESS`` defers to the
        parent value.
        """
        spawn_calls = self._stub_restart_env(tmp_path, monkeypatch)
        parent_project = tmp_path / "parent-proj"

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "--project-dir", str(parent_project), "daemon-restart",
            ])
        assert excinfo.value.code == 0
        # The parent CLI's --project-dir threaded through to spawn_daemon.
        assert spawn_calls[0]["project_dir"] == parent_project

    def test_subparser_project_dir_wins_over_parent(
        self, tmp_path, monkeypatch, capsys,
    ):
        """#498 — when BOTH parent and sub forms pass ``--project-dir``
        the sub form's explicit value wins (operator-explicit beats
        position-default).
        """
        spawn_calls = self._stub_restart_env(tmp_path, monkeypatch)
        parent_project = tmp_path / "parent-proj"
        sub_project = tmp_path / "sub-proj"

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "--project-dir", str(parent_project),
                "daemon-restart", "--project-dir", str(sub_project),
            ])
        assert excinfo.value.code == 0
        assert spawn_calls[0]["project_dir"] == sub_project

    def test_no_project_dir_anywhere_threads_cwd(
        self, tmp_path, monkeypatch, capsys,
    ):
        """#498 — when neither parent nor sub form passes
        ``--project-dir`` the spawn helper receives the parent's
        default (cwd via ``Path(".").resolve()``).

        This matches main-mode's behavior at cli.py:101 where the
        daemon auto-spawn at MCP startup also passes
        ``Path(".").resolve()`` as the project_dir when no explicit
        flag was given. Consistent semantics across both spawn
        entry points.
        """
        spawn_calls = self._stub_restart_env(tmp_path, monkeypatch)
        # Pin cwd so the assertion is deterministic.
        monkeypatch.chdir(tmp_path)

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-restart"])
        assert excinfo.value.code == 0
        # ``Path(".").resolve()`` collapses to the chdir'd directory.
        from pathlib import Path as _P
        assert spawn_calls[0]["project_dir"] == _P(tmp_path).resolve()

    def test_spawn_argv_includes_project_dir_flag(
        self, tmp_path, monkeypatch,
    ):
        """#498 acceptance criterion — the spawned daemon's argv
        must include ``--project-dir <path>`` when the parent CLI
        was invoked with it.

        Asserts at the :func:`spawn_daemon` layer where the argv is
        actually assembled (the ``cmd`` list). Sibling assertion to
        the kwarg-level checks above; ties the fix to the operator-
        observable surface (process argv).
        """
        import forge_manager_mcp.daemon_client as _dc_mod

        captured_cmds: list[list[str]] = []

        class _FakePopen:
            def __init__(self, cmd, **kwargs):
                captured_cmds.append(cmd)
                self.pid = 33333

        # Replace Popen on the daemon_client module so spawn_daemon
        # records the argv without actually launching a subprocess.
        monkeypatch.setattr(_dc_mod.subprocess, "Popen", _FakePopen)

        parent_project = tmp_path / "parent-proj"
        # Set up the rest of the restart machinery; reuse the
        # discovery-write side effect so the post-spawn wait passes.
        write_discovery(tmp_path, _stub_df(pid=11111))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        import os as _os
        monkeypatch.setattr(
            _os, "kill",
            lambda pid, sig: (_ for _ in ()).throw(ProcessLookupError()),
        )
        # The discovery file already exists from write_discovery; the
        # post-spawn wait_for_discovery sees it immediately.
        monkeypatch.setattr(
            cli_mod, "wait_for_discovery", lambda sd, timeout=5.0: True,
        )

        with pytest.raises(SystemExit):
            cli_mod.main([
                "--project-dir", str(parent_project), "daemon-restart",
            ])

        assert len(captured_cmds) == 1
        cmd = captured_cmds[0]
        # Argv structure: [python, -m, forge_manager_mcp.daemon.main,
        #                  --project-name, <name>, --state-dir, <sd>,
        #                  --project-dir, <project-dir-resolved>]
        assert "--project-dir" in cmd
        # The path immediately following --project-dir is the
        # parent CLI's value (post-.resolve()).
        idx = cmd.index("--project-dir")
        assert cmd[idx + 1] == str(parent_project.resolve())


class TestDaemonLogs:
    """#339 — `forge-manager-mcp daemon-logs`."""

    def test_no_log_file_exits_1(self, tmp_path, monkeypatch, capsys):
        from forge_manager_mcp.daemon import paths as _paths
        monkeypatch.setattr(
            _paths, "log_dir", lambda name=None: tmp_path / "logs",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs"])
        assert excinfo.value.code == 1
        assert "No log file" in capsys.readouterr().err

    def test_tail_default_lines(self, tmp_path, monkeypatch, capsys):
        from forge_manager_mcp.daemon import paths as _paths
        ld = tmp_path / "logs"
        ld.mkdir()
        log_path = ld / "forge-manager.log"
        log_path.write_text("\n".join(f"line{i}" for i in range(200)) + "\n")
        monkeypatch.setattr(
            _paths, "log_dir", lambda name=None: ld,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs", "-n", "5"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        # Last 5 lines should be 195..199.
        assert "line195" in out
        assert "line199" in out
        assert "line194" not in out


class TestCheckDesign:
    """#345 — `forge-manager-mcp check-design` CLI subcommand."""

    def test_clean_project_exits_0(self, tmp_path, monkeypatch, capsys):
        # tmp_path with no python files → no findings; should exit 0.
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "0 fail" in out

    def test_severity_filter_threshold(self, tmp_path, monkeypatch, capsys):
        # Severity filter set to fail; fewer findings shown.
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design", "--severity-filter", "fail"])
        # Empty project → zero findings even at filter=fail.
        assert excinfo.value.code == 0

    def test_diff_arg_prints_warning(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit):
            cli_mod.main(["check-design", "--diff", "main"])
        err = capsys.readouterr().err
        assert "3.5.x scope" in err

    def test_evaluator_exception_returns_2(
        self, tmp_path, monkeypatch, capsys,
    ):
        # When an evaluator raises, the handler exits 2.
        monkeypatch.chdir(tmp_path)
        from forge_manager_mcp.code_design import registry

        def _all():
            return ["broken_rule"]

        def _eval(project_dir, exclude, severity):
            raise RuntimeError("simulated evaluator crash")

        monkeypatch.setattr(registry, "all_rules", _all)
        monkeypatch.setattr(registry, "get_evaluator", lambda n: _eval)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 2
        err = capsys.readouterr().err
        assert "check-design failed" in err

    def test_fail_severity_finding_exits_1(
        self, tmp_path, monkeypatch, capsys,
    ):
        # Stub registry to yield one fail-severity finding.
        monkeypatch.chdir(tmp_path)
        from types import SimpleNamespace
        from forge_manager_mcp.code_design import registry

        def _eval(project_dir, exclude, severity):
            return [SimpleNamespace(
                severity="fail",
                rule="stub_rule",
                location=SimpleNamespace(path="x.py", line=1),
                message="bad code",
            )]

        monkeypatch.setattr(registry, "all_rules", lambda: ["stub_rule"])
        monkeypatch.setattr(registry, "get_evaluator", lambda n: _eval)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 1
        out = capsys.readouterr().out
        assert "1 fail" in out
        assert "[FAIL]" in out

    def test_unregistered_evaluator_skipped(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) L679-680 — get_evaluator returns None → continue.
        monkeypatch.chdir(tmp_path)
        from forge_manager_mcp.code_design import registry
        monkeypatch.setattr(registry, "all_rules", lambda: ["missing_rule"])
        monkeypatch.setattr(registry, "get_evaluator", lambda n: None)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "0 finding(s)" in out

    def test_severity_filter_skips_below_threshold(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) L686-688 — rank < min_rank → continue (finding not
        # accumulated).
        monkeypatch.chdir(tmp_path)
        from types import SimpleNamespace
        from forge_manager_mcp.code_design import registry

        def _eval(project_dir, exclude, severity):
            return [
                SimpleNamespace(
                    severity="info",
                    rule="r",
                    location=SimpleNamespace(path="x.py", line=1),
                    message="advisory",
                ),
                SimpleNamespace(
                    severity="warn",
                    rule="r",
                    location=SimpleNamespace(path="y.py", line=2),
                    message="warning",
                ),
            ]

        monkeypatch.setattr(registry, "all_rules", lambda: ["r"])
        monkeypatch.setattr(registry, "get_evaluator", lambda n: _eval)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design", "--severity-filter", "warn"])
        # Below-threshold info finding dropped; warn finding kept.
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "1 finding(s)" in out

    def test_info_severity_counted_separately(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) L694-695 — info-severity bucket increment.
        monkeypatch.chdir(tmp_path)
        from types import SimpleNamespace
        from forge_manager_mcp.code_design import registry

        def _eval(project_dir, exclude, severity):
            return [SimpleNamespace(
                severity="info", rule="r_advisory",
                location=SimpleNamespace(path="x.py", line=1),
                message="info",
            )]

        monkeypatch.setattr(registry, "all_rules", lambda: ["r_advisory"])
        monkeypatch.setattr(registry, "get_evaluator", lambda n: _eval)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "1 info" in out

    def test_findings_truncated_at_50(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from types import SimpleNamespace
        from forge_manager_mcp.code_design import registry

        def _eval(project_dir, exclude, severity):
            return [
                SimpleNamespace(
                    severity="warn",
                    rule="r",
                    location=SimpleNamespace(path=f"f{i}.py", line=i),
                    message=f"finding {i}",
                )
                for i in range(60)
            ]

        monkeypatch.setattr(registry, "all_rules", lambda: ["r"])
        monkeypatch.setattr(registry, "get_evaluator", lambda n: _eval)
        with pytest.raises(SystemExit):
            cli_mod.main(["check-design"])
        out = capsys.readouterr().out
        assert "60 finding(s)" in out
        # Truncation footer.
        assert "(... 10 more)" in out


class TestActionLog:
    """(#428 / 3.12.0 D-Coverage drain) action-log rebuild CLI subcommand."""

    def test_unknown_subcommand_exits_1(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["action-log", "nonsuch"])
        # The argparse parser likely rejects unknown subcommands before
        # _run_action_log even fires; either an argparse error (exit=2)
        # or our explicit message (exit=1) is acceptable.
        assert excinfo.value.code in (1, 2)

    def test_missing_docs_repo_exits_1(
        self, tmp_path, monkeypatch, capsys,
    ):
        # FORGE_MANAGER_DOCS_REPO unset, no ~/<project>-docs/ → docs
        # resolver yields a non-dir path → exit 1.
        from forge_manager_mcp.daemon import paths as _paths

        monkeypatch.delenv("FORGE_MANAGER_DOCS_REPO", raising=False)
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        # Make Path.home() resolve into tmp_path so the fallback yields
        # a non-existent dir.
        monkeypatch.setattr(
            "pathlib.Path.home", lambda: tmp_path / "fake-home",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["action-log", "rebuild"])
        assert excinfo.value.code == 1
        err = capsys.readouterr().err
        assert "docs repo not found" in err

    def test_rebuild_success_exits_0(
        self, tmp_path, monkeypatch, capsys,
    ):
        from forge_manager_mcp.daemon import paths as _paths

        docs = tmp_path / "docs"
        docs.mkdir()
        # Empty canonical store → counts all 0; success path.
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "action-log", "rebuild", "--docs-repo", str(docs),
            ])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "indexed 0 issue(s)" in out

    def test_rebuild_uses_env_var_when_no_flag(
        self, tmp_path, monkeypatch, capsys,
    ):
        from forge_manager_mcp.daemon import paths as _paths

        docs = tmp_path / "via-env"
        docs.mkdir()
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(docs))
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["action-log", "rebuild"])
        assert excinfo.value.code == 0

    def test_explicit_unknown_subcommand_via_direct_call(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) L745-750 — _run_action_log invoked directly with an
        # invalid subcommand returns 1 with the usage message. Test via
        # argparse Namespace to bypass argparse's own validation (which
        # rejects unknown choices before _run_action_log fires).
        from types import SimpleNamespace
        args = SimpleNamespace(
            action_log_subcommand="bogus",
            project_name=None, state_dir=None,
            docs_repo=None, project_dir=None,
        )
        rc = cli_mod._run_action_log(args)
        assert rc == 1
        err = capsys.readouterr().err
        assert "Usage: forge-manager-mcp action-log rebuild" in err

    def test_rebuild_con_close_exception_swallowed(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) L786-790 — con.close raises in finally → except Exception: pass.
        from forge_manager_mcp.daemon import action_log as _al
        from forge_manager_mcp.daemon import paths as _paths

        docs = tmp_path / "docs"
        docs.mkdir()

        class _ConWithBadClose:
            def close(self):
                raise RuntimeError("simulated close failure")

        def _open(*a, **kw):
            return _ConWithBadClose()

        monkeypatch.setattr(_al, "open_connection", _open)
        # ensure_schema + rebuild_fts5 are called on the stub con.
        monkeypatch.setattr(_al, "ensure_schema", lambda con: None)
        monkeypatch.setattr(
            _al, "rebuild_fts5",
            lambda *a, **kw: {"issues": 0, "discussions": 0, "sessions": 0},
        )
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "action-log", "rebuild", "--docs-repo", str(docs),
            ])
        # close failure is swallowed → rebuild still returns 0.
        assert excinfo.value.code == 0

    def test_rebuild_failure_exits_1(self, tmp_path, monkeypatch, capsys):
        from forge_manager_mcp.daemon import action_log as _al
        from forge_manager_mcp.daemon import paths as _paths

        docs = tmp_path / "docs"
        docs.mkdir()

        def _boom(*args, **kwargs):
            raise RuntimeError("simulated rebuild failure")

        monkeypatch.setattr(_al, "rebuild_fts5", _boom)
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "action-log", "rebuild", "--docs-repo", str(docs),
            ])
        assert excinfo.value.code == 1
        err = capsys.readouterr().err
        assert "rebuild failed" in err


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) main() server-startup paths.
# ---------------------------------------------------------------------------


class TestResolveStateDirOverride:
    def test_state_dir_arg_takes_precedence(self, tmp_path):
        # _resolve_state_dir: args.state_dir not None → L337-338 return.
        from types import SimpleNamespace
        args = SimpleNamespace(state_dir=tmp_path, project_name=None)
        result = cli_mod._resolve_state_dir(args)
        assert result == tmp_path


class TestOpenUiBrowserFailure:
    def test_webbrowser_exception_logged_returns_zero(
        self, tmp_path, monkeypatch, capsys,
    ):
        # _run_open_ui: webbrowser.open raises → L461-469 logged warn,
        # still returns 0.
        write_discovery(tmp_path, _stub_df(pid=12345, port=7777))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # Stub probe — UI reachable.
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )

        # Stub webbrowser.open to raise.
        import webbrowser
        def _fail_open(url):
            raise RuntimeError("simulated DISPLAY=")
        monkeypatch.setattr(webbrowser, "open", _fail_open)

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 0
        err = capsys.readouterr().err
        assert "Failed to launch browser" in err


class TestDaemonStopEdgeBranches:
    def test_oserror_on_kill_exits_2(self, tmp_path, monkeypatch, capsys):
        # os.kill raises OSError → L506-508 exit 2.
        # (#497) Bypass Layer-1 pre-checks so the OSError on the actual
        # SIGTERM signal triggers the diagnostic branch.
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        import os as _os

        def _kill(pid, sig):
            raise OSError("permission denied")

        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 2
        assert "kill" in capsys.readouterr().err

    def test_timeout_waiting_for_exit_exits_2(
        self, tmp_path, monkeypatch, capsys,
    ):
        # Process never exits → poll-loop times out → exit 2.
        # (#497) Bypass Layer-1 pre-checks + the mid-loop zombie check
        # so the loop runs to its deadline.
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        import os as _os
        import time as _time

        def _kill(pid, sig):
            # SIGTERM succeeds; sig=0 probes return None (process alive).
            return None

        monkeypatch.setattr(_os, "kill", _kill)
        monkeypatch.setattr(_time, "sleep", lambda s: None)
        # Make monotonic jump past the deadline after one iteration.
        call_count = [0]

        def _mono():
            call_count[0] += 1
            return 0.0 if call_count[0] == 1 else 100.0

        monkeypatch.setattr(_time, "monotonic", _mono)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 2
        assert "did not exit" in capsys.readouterr().err

    def test_polling_sleep_fires_when_process_still_alive(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) Liveness probe succeeds → loop hits time.sleep(0.1).
        # (#497) Bypass Layer-1 pre-checks + mid-loop zombie check.
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        import os as _os
        import time as _time

        sigs_sent = []
        liveness_call_count = [0]

        def _kill(pid, sig):
            if sig == 0:
                liveness_call_count[0] += 1
                if liveness_call_count[0] == 1:
                    # First probe: process still alive → triggers sleep.
                    return None
                # Second probe: process gone → clean exit.
                raise ProcessLookupError("dead")
            sigs_sent.append((pid, sig))

        sleep_calls = []

        def _sleep(secs):
            sleep_calls.append(secs)

        monkeypatch.setattr(_os, "kill", _kill)
        monkeypatch.setattr(_time, "sleep", _sleep)
        # Monotonic always 0.0 so we never time out — exit relies on
        # the second probe raising.
        monkeypatch.setattr(_time, "monotonic", lambda: 0.0)

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        # The sleep at L520 was reached after the first alive probe.
        assert sleep_calls == [0.1]
        assert liveness_call_count[0] == 2
        assert "stopped via SIGTERM" in capsys.readouterr().out


class TestDaemonRestartEdgeBranches:
    def test_stop_fails_non_zero_returns_early(
        self, tmp_path, monkeypatch, capsys,
    ):
        # _run_daemon_stop returns rc not in (0, 1) → L549-554 abort.
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(cli_mod, "_run_daemon_stop", lambda args: 2)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-restart"])
        assert excinfo.value.code == 2
        assert "not respawning" in capsys.readouterr().err

    def test_wait_for_discovery_timeout_exits_2(
        self, tmp_path, monkeypatch, capsys,
    ):
        # wait_for_discovery returns False after spawn → L563-569 exit 2.
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(cli_mod, "spawn_daemon", lambda *a, **kw: 12345)
        monkeypatch.setattr(
            cli_mod, "wait_for_discovery", lambda sd: False,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-restart"])
        assert excinfo.value.code == 2
        assert "daemon.json appeared within" in capsys.readouterr().err

    def test_discovery_disappears_after_wait_exits_2(
        self, tmp_path, monkeypatch, capsys,
    ):
        # wait_for_discovery returns True but read_discovery returns
        # None on the second read → L571-578 exit 2.
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(cli_mod, "spawn_daemon", lambda *a, **kw: 12345)
        monkeypatch.setattr(
            cli_mod, "wait_for_discovery", lambda sd: True,
        )
        monkeypatch.setattr(cli_mod, "read_discovery", lambda sd: None)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-restart"])
        assert excinfo.value.code == 2
        assert "disappeared again" in capsys.readouterr().err


class TestDaemonLogsEdgeBranches:
    def test_log_read_oserror_exits_1(
        self, tmp_path, monkeypatch, capsys,
    ):
        # log.open() raises OSError → L616-618 exit 1.
        from forge_manager_mcp.daemon import paths as _p
        from pathlib import Path as _P

        log_path = tmp_path / "forge-manager.log"
        log_path.write_text("line1\nline2\n")
        monkeypatch.setattr(_p, "log_dir", lambda name: tmp_path)

        original_open = _P.open

        def _fail(self, *a, **kw):
            if self == log_path:
                raise OSError("simulated read failure")
            return original_open(self, *a, **kw)

        monkeypatch.setattr(_P, "open", _fail)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs"])
        assert excinfo.value.code == 1
        assert "Read failed" in capsys.readouterr().err


class TestDaemonLogsFollowMode:
    """(#428) cli.py L629-640 — daemon-logs --follow mode loops on
    new lines, sleeping when none, exiting cleanly on KeyboardInterrupt."""

    def test_follow_mode_streams_new_lines_then_exits_on_interrupt(
        self, tmp_path, monkeypatch, capsys,
    ):
        from forge_manager_mcp.daemon import paths as _paths
        ld = tmp_path / "logs"
        ld.mkdir()
        log_path = ld / "forge-manager.log"
        log_path.write_text("initial1\ninitial2\n")
        monkeypatch.setattr(
            _paths, "log_dir", lambda name=None: ld,
        )

        # Stub time.sleep to count + raise KeyboardInterrupt on the
        # SECOND sleep — that gives us at least one full loop iteration
        # through readline-empty → sleep → continue (L636).
        import time as _time
        sleep_calls = []

        def _sleep(secs):
            sleep_calls.append(secs)
            if len(sleep_calls) >= 2:
                raise KeyboardInterrupt()

        monkeypatch.setattr(_time, "sleep", _sleep)

        # Stub readline so:
        #   call 1 → "appended-line\n" (writes + loops)
        #   call 2 → "" → sleep #1 → continue (L636)
        #   call 3 → "" → sleep #2 → KeyboardInterrupt → exit
        from pathlib import Path as _P
        original_open = _P.open
        readline_calls = {"n": 0}

        class _StubFile:
            def __init__(self, real):
                self._real = real
            def __enter__(self):
                self._real.__enter__()
                return self
            def __exit__(self, *a):
                return self._real.__exit__(*a)
            def seek(self, *a):
                pass
            def readlines(self):
                # Initial tail — return the seeded content.
                return ["initial1\n", "initial2\n"]
            def readline(self):
                readline_calls["n"] += 1
                if readline_calls["n"] == 1:
                    return "appended-line\n"
                return ""

        def _patched_open(self, *a, **kw):
            real = original_open(self, *a, **kw)
            if self == log_path and "r" in (a[0] if a else kw.get("mode", "r")):
                return _StubFile(real)
            return real

        monkeypatch.setattr(_P, "open", _patched_open)

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs", "--follow"])
        assert excinfo.value.code == 0
        # Two sleeps fired — first returned (continue at L636 hit),
        # second raised KeyboardInterrupt to exit the loop.
        assert sleep_calls == [0.25, 0.25]
        out = capsys.readouterr().out
        assert "appended-line" in out


class TestMainServerStartup:
    """Drive the main() server-startup body: build_server / spawn /
    _serve. All effects (build_server, daemon spawn, asyncio.run) are
    stubbed; we only assert the right branches print the right banners
    and dispatch to the right helpers."""

    def _stub_build_server(self, monkeypatch, config=None, error=None):
        from unittest.mock import MagicMock

        if error is not None:
            def _raise(_path):
                raise error
            monkeypatch.setattr(cli_mod, "build_server", _raise)
            return None

        fake_server = MagicMock()
        monkeypatch.setattr(
            cli_mod, "build_server",
            lambda _path: (fake_server, config, None, None),
        )
        return fake_server

    def _stub_serve_path(self, monkeypatch):
        """Replace asyncio.run so main() returns without blocking."""
        import asyncio
        monkeypatch.setattr(asyncio, "run", lambda coro: coro.close())

    def _stub_spawn(self, monkeypatch, *, spawned=False, status="RUNNING", pid=4242):
        from types import SimpleNamespace

        result = SimpleNamespace(
            spawned=spawned, status=getattr(DaemonStatus, status), pid=pid,
        )
        monkeypatch.setattr(
            cli_mod, "spawn_if_needed",
            lambda sd, name, *, auto_spawn=True, project_dir=None: result,
        )
        monkeypatch.setattr(
            cli_mod, "read_discovery",
            lambda sd: _stub_df(pid=pid, port=7777),
        )

    def test_config_error_exits_one(self, tmp_path, monkeypatch, capsys):
        # ConfigError on build_server → L60-63 print + sys.exit(1).
        from forge_manager_mcp.config import ConfigError
        self._stub_build_server(
            monkeypatch, error=ConfigError("bad config"),
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["--project-dir", str(tmp_path)])
        assert excinfo.value.code == 1
        assert "bad config" in capsys.readouterr().err

    def test_pre_bootstrap_banner(self, tmp_path, monkeypatch, capsys):
        # config is None → PRE-BOOTSTRAP banner. L65-76.
        self._stub_build_server(monkeypatch, config=None)
        self._stub_spawn(monkeypatch, spawned=False, status="RUNNING")
        self._stub_serve_path(monkeypatch)
        cli_mod.main(["--project-dir", str(tmp_path)])
        assert "PRE-BOOTSTRAP" in capsys.readouterr().err

    def test_post_bootstrap_banner(self, tmp_path, monkeypatch, capsys):
        # config present → post-bootstrap banner. L78-82.
        from unittest.mock import MagicMock
        config = MagicMock()
        config.repos.private = "org/proj"
        self._stub_build_server(monkeypatch, config=config)
        self._stub_spawn(monkeypatch, spawned=False, status="RUNNING")
        self._stub_serve_path(monkeypatch)
        cli_mod.main(["--project-dir", str(tmp_path)])
        err = capsys.readouterr().err
        assert "org/proj" in err

    def test_daemon_spawned_prints_url(self, tmp_path, monkeypatch, capsys):
        # spawn_if_needed result.spawned=True → L103-110 prints URL.
        self._stub_build_server(monkeypatch, config=None)
        self._stub_spawn(monkeypatch, spawned=True, status="RUNNING")
        self._stub_serve_path(monkeypatch)
        cli_mod.main(["--project-dir", str(tmp_path)])
        err = capsys.readouterr().err
        assert "daemon spawned" in err

    def test_daemon_spawn_failed_banner(self, tmp_path, monkeypatch, capsys):
        # spawn result.status != RUNNING and not spawned → L119-126.
        self._stub_build_server(monkeypatch, config=None)
        self._stub_spawn(monkeypatch, spawned=False, status="ABSENT")
        self._stub_serve_path(monkeypatch)
        cli_mod.main(["--project-dir", str(tmp_path)])
        err = capsys.readouterr().err
        assert "daemon spawn failed" in err

    def test_daemon_spawn_exception_logged_and_continues(
        self, tmp_path, monkeypatch, capsys,
    ):
        # spawn_if_needed raises → L127-132 logs + continues to _serve.
        self._stub_build_server(monkeypatch, config=None)

        def _boom(*args, **kwargs):
            raise RuntimeError("simulated spawn crash")

        monkeypatch.setattr(cli_mod, "spawn_if_needed", _boom)
        self._stub_serve_path(monkeypatch)
        cli_mod.main(["--project-dir", str(tmp_path)])
        err = capsys.readouterr().err
        assert "daemon auto-spawn raised" in err

    def test_serve_runs_stdio_then_aclose_in_finally(
        self, tmp_path, monkeypatch, capsys,
    ):
        # (#428) cli.py L135-137 + L152-153 — actually drive the
        # _serve() async loop end-to-end. Stub stdio_server and
        # server.run, then let asyncio.run execute _serve so the
        # `finally: aclose_client()` block fires.
        from contextlib import asynccontextmanager

        fake_server = self._stub_build_server(monkeypatch, config=None)
        self._stub_spawn(monkeypatch, spawned=False, status="RUNNING")

        @asynccontextmanager
        async def _fake_stdio():
            yield ("read_stream_stub", "write_stream_stub")

        import mcp.server.stdio as _stdio_mod
        monkeypatch.setattr(_stdio_mod, "stdio_server", _fake_stdio)

        async def _fake_run(read, write, init_options):
            return None

        fake_server.run = _fake_run
        fake_server.get_capabilities.return_value = {}

        aclose_called = {"n": 0}

        async def _fake_aclose():
            aclose_called["n"] += 1

        from forge_manager_mcp.github import core as _core
        monkeypatch.setattr(_core, "aclose_client", _fake_aclose)

        # NOTE: do NOT stub asyncio.run — let the real coroutine run.
        cli_mod.main(["--project-dir", str(tmp_path)])
        # The finally block always fires even on the success path.
        assert aclose_called["n"] == 1


# ---------------------------------------------------------------------------
# (#497, 3.14.0) Layer 3 — daemon-stop zombie / dead PID detection.
# ---------------------------------------------------------------------------


class TestDaemonStop_ZombieDetection:
    """(#497 Layer 3) Pre-signal zombie detection: signals on a zombie
    are no-ops; pre-#497 ``--force`` reported timeout. New behavior
    detects zombie state, cleans up discovery file, reports success."""

    def test_zombie_pid_cleaned_up_without_signal(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # PID is alive (kernel slot still there) but zombie state.
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: True)
        # If the zombie short-circuit works, os.kill is never called.
        import os as _os
        def _kill(pid, sig):
            raise AssertionError(
                "should not signal a zombie — short-circuit failed"
            )
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "was zombie" in out
        assert "cleaned up discovery file" in out
        # Discovery file actually removed.
        from forge_manager_mcp.daemon.discovery import read_discovery
        assert read_discovery(tmp_path) is None

    def test_zombie_force_also_cleaned_up_without_signal(
        self, tmp_path, monkeypatch, capsys,
    ):
        # --force against a zombie hits the same short-circuit (would
        # otherwise time out for 5s of "did not exit within 5s of SIGKILL").
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: True)
        import os as _os
        def _kill(pid, sig):
            raise AssertionError("should not signal a zombie")
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop", "--force"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "was zombie" in out

    def test_dead_pid_cleaned_up_via_explicit_alive_check(
        self, tmp_path, monkeypatch, capsys,
    ):
        # PID is not alive (returned False) → upfront cleanup.
        # Distinct from the post-signal ProcessLookupError race path.
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: False)
        monkeypatch.setattr(_dc, "is_pid_zombie", lambda pid: False)
        import os as _os
        def _kill(pid, sig):
            raise AssertionError(
                "should not signal a dead PID — upfront check failed"
            )
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "not found" in out
        assert "stale" in out


class TestDaemonStop_MidLoopZombieDetection:
    """(#497 Layer 3) Daemon may crash mid-shutdown and become a
    zombie rather than exit cleanly — wait loop detects this and
    cleans up instead of timing out."""

    def test_becomes_zombie_during_shutdown_wait(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        from forge_manager_mcp import daemon_client as _dc
        # Pre-signal: PID alive + not zombie → proceeds to SIGTERM.
        # Mid-loop: zombie check transitions to True on second probe.
        monkeypatch.setattr(_dc, "is_pid_alive", lambda pid: True)
        zombie_state = {"is_zombie": False}
        zombie_calls = {"n": 0}
        def _zombie(pid):
            zombie_calls["n"] += 1
            # First call (pre-signal): False. Subsequent (in-loop): True
            # after the SIGTERM is sent and we're polling for exit.
            if zombie_calls["n"] >= 2:
                return True
            return False
        monkeypatch.setattr(_dc, "is_pid_zombie", _zombie)
        import os as _os
        sigs_sent = []
        def _kill(pid, sig):
            if sig == 0:
                # Liveness probe in the wait-loop: process still alive.
                return None
            sigs_sent.append((pid, sig))
        monkeypatch.setattr(_os, "kill", _kill)
        import time as _time
        monkeypatch.setattr(_time, "sleep", lambda s: None)
        # Monotonic stays under deadline so the loop runs.
        monkeypatch.setattr(_time, "monotonic", lambda: 0.0)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "became zombie during shutdown" in out
        # SIGTERM was sent before we detected the zombie transition.
        import signal
        assert (12345, signal.SIGTERM) in sigs_sent


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
