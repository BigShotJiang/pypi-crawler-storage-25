"""Tests for command_registry.py (Phase D4.1+D4.2 / #387 / 3.9.0).

Covers (1) the YAML loader → CommandRegistry pipeline, (2) the
slash-command parser, and (3) the live commands.yaml shipping in
.claude/skills/forge-manager/ (loads cleanly + every dispatch
surface is one of the expected forms).

Tagged ``negative`` because most cases drive the parser's error
paths (unknown verb, missing required arg, malformed flag).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from forge_manager_mcp.command_registry import (
    Command,
    CommandArg,
    CommandRegistry,
    CommandRegistryError,
    ParsedCommand,
    load_commands,
    parse_command,
)


def _registry_with_search_and_open() -> CommandRegistry:
    """Synthetic mini registry exercising both surfaces."""
    return CommandRegistry([
        Command(
            verb="search",
            noun="issues",
            summary="search issues",
            mcp_tool="search_local",
            mcp_args_json='{"kind": "issue", "q": "{query}"}',
            args=(CommandArg(name="query", type="string", positional=True, required=True),),
            introduced_in="3.9.0",
        ),
        Command(
            verb="open",
            noun="issue",
            summary="open issue in UI",
            ui_route="#files?path=issues/{number}",
            args=(CommandArg(name="number", type="integer", positional=True, required=True),),
            introduced_in="3.9.0",
        ),
        Command(
            verb="show",
            noun="daemon",
            summary="show daemon status",
            mcp_tool="get_daemon_status",
            mcp_args_json="{}",
            args=(),
            introduced_in="3.9.0",
        ),
    ])


# ---------------------------------------------------------------------------
# Schema validation
# ---------------------------------------------------------------------------


class TestCommandSchema:
    def test_command_with_no_dispatch_surface_rejected(self):
        with pytest.raises(ValueError, match="no dispatch surface"):
            Command(
                verb="orphan",
                noun="",
                summary="no surfaces",
                args=(),
                introduced_in="3.9.0",
            )

    def test_mcp_args_without_mcp_tool_rejected(self):
        with pytest.raises(ValueError, match="mcp_args_json but no mcp_tool"):
            Command(
                verb="x", noun="", summary="x",
                ui_route="#x",
                mcp_args_json='{"a": "b"}',  # but no mcp_tool
                args=(),
                introduced_in="3.9.0",
            )

    def test_invalid_json_in_mcp_args_rejected(self):
        with pytest.raises(ValueError, match="invalid"):
            Command(
                verb="x", noun="", summary="x",
                mcp_tool="some_tool",
                mcp_args_json="this is not json",
                args=(),
                introduced_in="3.9.0",
            )


# ---------------------------------------------------------------------------
# Registry accessors
# ---------------------------------------------------------------------------


class TestCommandRegistry:
    def test_get_returns_command(self):
        reg = _registry_with_search_and_open()
        cmd = reg.get("search", "issues")
        assert cmd is not None
        assert cmd.verb == "search"

    def test_get_unknown_returns_none(self):
        reg = _registry_with_search_and_open()
        assert reg.get("nonexistent", "verb") is None

    def test_list_verbs_dedupes(self):
        reg = _registry_with_search_and_open()
        assert sorted(reg.list_verbs()) == ["open", "search", "show"]

    def test_aliases_resolve_to_same_command(self):
        # 3.10.0 D2 / #392: alias wire form is noun-verb. The alias
        # "issues find" registers a (verb=find, noun=issues) key
        # pointing at the same Command as the canonical
        # (verb=search, noun=issues) entry.
        cmd = Command(
            verb="search", noun="issues", summary="s",
            mcp_tool="search_local", mcp_args_json="{}",
            args=(),
            aliases=("issues find",),
            introduced_in="3.9.0",
        )
        reg = CommandRegistry([cmd])
        assert reg.get("search", "issues") is reg.get("find", "issues")

    def test_verb_only_alias_registers_under_empty_noun(self):
        # Single-token alias for verb-only meta-commands.
        cmd = Command(
            verb="help", noun="",
            summary="help",
            mcp_tool="__help__", mcp_args_json="{}",
            args=(),
            aliases=("?",),
            introduced_in="3.10.0",
        )
        reg = CommandRegistry([cmd])
        assert reg.get("help", "") is reg.get("?", "")

    def test_duplicate_command_rejected(self):
        cmd = Command(
            verb="x", noun="", summary="x",
            mcp_tool="t", mcp_args_json="{}", args=(),
            introduced_in="3.9.0",
        )
        with pytest.raises(CommandRegistryError, match="duplicate"):
            CommandRegistry([cmd, cmd])


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class TestParseCommand:
    """Wire form is noun-verb as of 3.10.0 D2 / #392 — `/<noun> <verb> [args]`.
    Field semantics on the Command schema unchanged: `verb` is still
    the action word, `noun` is still the resource. Only the token
    ordering at the wire interface swapped."""
    def test_simple_noun_verb_positional(self):
        reg = _registry_with_search_and_open()
        parsed = parse_command("/issues search schema", reg)
        assert parsed.command.verb == "search"
        assert parsed.command.noun == "issues"
        assert parsed.positional == ("schema",)
        assert parsed.flags == {}

    def test_quoted_multi_word_arg(self):
        reg = _registry_with_search_and_open()
        parsed = parse_command(
            '/issues search "schema as functions"', reg,
        )
        assert parsed.positional == ("schema as functions",)

    def test_substitute_renders_args_into_template(self):
        reg = _registry_with_search_and_open()
        parsed = parse_command("/issues search foo", reg)
        rendered = parsed.substitute(parsed.command.mcp_args_json)
        assert rendered == '{"kind": "issue", "q": "foo"}'

    def test_open_issue_with_integer_arg(self):
        reg = _registry_with_search_and_open()
        parsed = parse_command("/issue open 367", reg)
        rendered = parsed.substitute(parsed.command.ui_route)
        assert rendered == "#files?path=issues/367"

    def test_no_args_command(self):
        reg = _registry_with_search_and_open()
        parsed = parse_command("/daemon show", reg)
        assert parsed.positional == ()
        assert parsed.flags == {}

    def test_empty_command_rejected(self):
        reg = _registry_with_search_and_open()
        with pytest.raises(CommandRegistryError, match="empty"):
            parse_command("", reg)

    def test_missing_leading_slash_rejected(self):
        reg = _registry_with_search_and_open()
        with pytest.raises(CommandRegistryError, match="must start with"):
            parse_command("issues search foo", reg)

    def test_unknown_command_rejected(self):
        reg = _registry_with_search_and_open()
        with pytest.raises(CommandRegistryError, match="unknown command"):
            parse_command("/nonexistent foo", reg)

    def test_required_positional_missing_rejected(self):
        reg = _registry_with_search_and_open()
        with pytest.raises(CommandRegistryError, match="required positional"):
            parse_command("/issues search", reg)  # no query

    def test_flag_with_equals_form(self):
        cmd = Command(
            verb="filter", noun="",
            summary="x",
            mcp_tool="filter_tool", mcp_args_json="{}",
            args=(
                CommandArg(name="kind", type="string", positional=False, required=False),
            ),
            introduced_in="3.9.0",
        )
        reg = CommandRegistry([cmd])
        parsed = parse_command("/filter --kind=issue", reg)
        assert parsed.flags == {"kind": "issue"}

    def test_flag_with_space_form(self):
        cmd = Command(
            verb="filter", noun="",
            summary="x",
            mcp_tool="filter_tool", mcp_args_json="{}",
            args=(
                CommandArg(name="kind", type="string", positional=False, required=False),
            ),
            introduced_in="3.9.0",
        )
        reg = CommandRegistry([cmd])
        parsed = parse_command("/filter --kind issue", reg)
        assert parsed.flags == {"kind": "issue"}

    def test_unknown_flag_rejected(self):
        reg = _registry_with_search_and_open()
        with pytest.raises(CommandRegistryError, match="unknown flag"):
            parse_command("/issues search foo --bogus=value", reg)

    def test_verb_only_command_resolves_when_noun_empty(self):
        cmd = Command(
            verb="help", noun="",
            summary="show help",
            mcp_tool="__help__", mcp_args_json="{}",
            args=(
                CommandArg(name="verb", type="string", positional=True, required=False),
            ),
            introduced_in="3.9.0",
        )
        reg = CommandRegistry([cmd])
        # Bare /help with no noun.
        parsed = parse_command("/help", reg)
        assert parsed.command.verb == "help"
        assert parsed.positional == ()
        # /help search → "search" is the optional positional, not a noun.
        parsed = parse_command("/help search", reg)
        assert parsed.positional == ("search",)


# ---------------------------------------------------------------------------
# Live commands.yaml smoke test
# ---------------------------------------------------------------------------


class TestLiveCommandsYaml:
    """Validates the actual commands.yaml shipping in
    .claude/skills/forge-manager/ — every entry parses, every dispatch
    surface is one of the expected forms."""

    def _commands_path(self) -> Path | None:
        # Walk up from this test file to find the dev repo root.
        cwd = Path(__file__).resolve()
        for parent in [cwd] + list(cwd.parents):
            candidate = (
                parent / ".claude" / "skills" / "forge-manager" / "commands.yaml"
            )
            if candidate.exists():
                return candidate
        return None

    def test_loads_without_error(self):
        path = self._commands_path()
        if path is None:
            pytest.skip("commands.yaml not in scope (Bazel sandbox shape)")
        registry = load_commands(path)
        assert len(registry) > 0

    def test_every_command_has_a_dispatch_surface(self):
        path = self._commands_path()
        if path is None:
            pytest.skip("commands.yaml not in scope (Bazel sandbox shape)")
        registry = load_commands(path)
        # The schema-level validator already enforces this; the live
        # check confirms no entry was added that violates it.
        for verb in registry.list_verbs():
            for cmd in registry.list_for_verb(verb):
                surfaces = (cmd.mcp_tool, cmd.daemon_endpoint, cmd.ui_route)
                assert any(s is not None for s in surfaces), (
                    f"{cmd.verb}/{cmd.noun!r} has no dispatch surface"
                )


# (#428 / 3.12.0 D-Coverage drain) Edge-path tests.


class TestCommandSchemaDaemonValidation:
    def test_daemon_params_json_without_endpoint_rejected(self):
        from pydantic import ValidationError
        with pytest.raises(ValidationError, match="daemon_params_json"):
            Command(
                verb="x", noun="y", summary="s", introduced_in="1.0",
                args=[], ui_route="/x",
                daemon_params_json='{"foo": "{bar}"}',
            )

    def test_invalid_daemon_params_json_rejected(self):
        from pydantic import ValidationError
        with pytest.raises(ValidationError, match="invalid"):
            Command(
                verb="x", noun="y", summary="s", introduced_in="1.0",
                args=[],
                daemon_endpoint="/foo",
                daemon_params_json="{not valid json",
            )


class TestRegistryAccessors:
    def _make_cmd(self, verb="open", noun="issue"):
        return Command(
            verb=verb, noun=noun, summary="s", introduced_in="1.0",
            args=[], ui_route=f"/{noun}/{verb}",
        )

    def test_contains_returns_true_for_registered_key(self):
        registry = CommandRegistry([self._make_cmd()])
        assert ("open", "issue") in registry
        assert ("nope", "nope") not in registry


class TestLoadCommandsErrors:
    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(CommandRegistryError, match="not found"):
            load_commands(tmp_path / "no-such.yaml")

    def test_yaml_parse_error_wrapped_with_path_prefix(self, tmp_path):
        path = tmp_path / "commands.yaml"
        path.write_text("commands:\n\t- verb: x\n")
        with pytest.raises(CommandRegistryError, match=str(path)):
            load_commands(path)

    def test_invalid_command_entry_wrapped(self, tmp_path):
        path = tmp_path / "commands.yaml"
        path.write_text(
            "commands:\n"
            "  - verb: x\n"
            "    noun: y\n"
            # missing summary, introduced_in, dispatch surface
        )
        with pytest.raises(
            CommandRegistryError, match="invalid command entry",
        ):
            load_commands(path)


class TestParseCommandEdges:
    def test_only_leading_slash_rejected(self):
        with pytest.raises(CommandRegistryError, match="leading slash"):
            parse_command("/   ", CommandRegistry([]))

    def test_unbalanced_quote_in_command_rejected(self):
        with pytest.raises(
            CommandRegistryError, match="could not tokenize",
        ):
            parse_command('/issue add "unbalanced', CommandRegistry([]))


class TestParseCommandBooleanFlag:
    def test_boolean_flag_without_value_defaults_true(self):
        cmd = Command(
            verb="add", noun="issue", summary="s", introduced_in="1.0",
            args=[
                CommandArg(
                    name="dry-run", type="boolean", positional=False,
                    required=False,
                ),
            ],
            ui_route="/issue/add",
        )
        registry = CommandRegistry([cmd])
        parsed = parse_command("/issue add --dry-run", registry)
        assert parsed.flags == {"dry-run": "true"}


class TestSubstituteEdges:
    def _build_registry(self, args):
        cmd = Command(
            verb="add", noun="issue", summary="s", introduced_in="1.0",
            args=args, ui_route="/x",
        )
        return CommandRegistry([cmd])

    def test_unknown_placeholder_left_as_is(self):
        registry = self._build_registry([
            CommandArg(name="title", type="string", positional=True),
        ])
        parsed = parse_command('/issue add "Test"', registry)
        out = parsed.substitute('title={title} unknown={unknown}')
        assert "title=Test" in out
        assert "{unknown}" in out

    def test_optional_flag_with_value_substituted(self):
        registry = self._build_registry([
            CommandArg(name="label", type="string", positional=False,
                       required=False),
        ])
        parsed = parse_command("/issue add --label=bug", registry)
        out = parsed.substitute("label={label}")
        assert out == "label=bug"

    def test_optional_arg_omitted_yields_empty_substitution(self):
        registry = self._build_registry([
            CommandArg(name="optional", type="string",
                       positional=False, required=False),
        ])
        parsed = parse_command("/issue add", registry)
        out = parsed.substitute("opt={optional}")
        assert out == "opt="


class TestParseFlagRequiresValue:
    def test_non_boolean_flag_at_end_without_value_rejected(self):
        # Line 452: --name (no =value) at end of args, declared as
        # non-boolean → "flag requires a value".
        cmd = Command(
            verb="add", noun="issue", summary="s", introduced_in="1.0",
            args=[
                CommandArg(name="label", type="string", positional=False,
                           required=False),
            ],
            ui_route="/x",
        )
        registry = CommandRegistry([cmd])
        with pytest.raises(CommandRegistryError, match="requires a value"):
            parse_command("/issue add --label", registry)


class TestAliasCollision:
    def test_alias_collides_with_existing_command_raises(self):
        # Line 288: registry construction with an alias that matches
        # an existing command's key → CommandRegistryError.
        cmd1 = Command(
            verb="add", noun="issue", summary="s", introduced_in="1.0",
            args=[], ui_route="/x",
        )
        # Second command's alias collides with cmd1's primary key.
        cmd2 = Command(
            verb="open", noun="issue", summary="s", introduced_in="1.0",
            args=[], ui_route="/y",
            aliases=("issue add",),  # collides with cmd1
        )
        with pytest.raises(CommandRegistryError, match="collides"):
            CommandRegistry([cmd1, cmd2])


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
