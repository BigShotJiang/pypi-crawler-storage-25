"""Tests for the 3.4.x → 3.5 credentials migration (#332).

Covers:
1. Detector — clean state (already migrated; no platforms).
2. Detector — partial env vars set.
3. Apply — captures tokens, writes credentials.enc, returns
   manual_steps.
4. Apply — partial migration (some env vars missing) surfaces
   manual_steps.
5. Idempotency — re-running detect after apply returns is_clean.
6. Backup + rollback — restores state-dir contents.
7. Manual-steps include the .git/config token-scrub recommendation.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from forge_manager_mcp.daemon.credentials import (
    CREDENTIALS_FILENAME, KEY_FILENAME, save_credentials,
)
from forge_manager_mcp.migrations.migrate_3_5 import (
    apply_migration,
    detect_3_5_state,
    restore_to_targets,
)


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for var in ("GITHUB_TOKEN", "GH_TOKEN", "FORGEJO_TOKEN",
                "CODEBERG_TOKEN", "GITLAB_TOKEN"):
        monkeypatch.delenv(var, raising=False)


class TestDetectClean:
    def test_no_platforms_clean(self, tmp_path):
        plan = detect_3_5_state(tmp_path, tmp_path / "state", [])
        assert plan.is_clean is True

    def test_only_local_platform_clean(self, tmp_path):
        plan = detect_3_5_state(tmp_path, tmp_path / "state", ["local"])
        assert plan.is_clean is True

    def test_existing_credentials_clean(self, tmp_path):
        sd = tmp_path / "state"
        save_credentials(sd, {"github": "x"})
        plan = detect_3_5_state(tmp_path, sd, ["github", "codeberg"])
        assert plan.is_clean is True
        assert any("already present" in w for w in plan.warnings)


class TestDetectPartial:
    def test_all_env_present(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        monkeypatch.setenv("CODEBERG_TOKEN", "cb_y")
        plan = detect_3_5_state(
            tmp_path, tmp_path / "state", ["github", "codeberg"],
        )
        assert plan.is_clean is False
        assert set(plan.env_present) == {"github", "codeberg"}
        assert plan.env_missing == ()

    def test_partial_env(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        # CODEBERG_TOKEN unset.
        plan = detect_3_5_state(
            tmp_path, tmp_path / "state", ["github", "codeberg"],
        )
        assert plan.is_clean is False
        assert plan.env_present == ("github",)
        assert plan.env_missing == ("codeberg",)

    def test_no_env_set(self, tmp_path):
        plan = detect_3_5_state(
            tmp_path, tmp_path / "state", ["github", "codeberg"],
        )
        assert plan.is_clean is False
        assert plan.env_present == ()
        assert set(plan.env_missing) == {"github", "codeberg"}


class TestApply:
    def test_apply_captures_env_tokens(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_secret")
        monkeypatch.setenv("CODEBERG_TOKEN", "cb_secret")
        sd = tmp_path / "state"
        plan = detect_3_5_state(tmp_path, sd, ["github", "codeberg"])
        result = apply_migration(plan)
        assert result["success"] is True
        assert set(result["captured"]) == {"github", "codeberg"}
        assert (sd / CREDENTIALS_FILENAME).is_file()
        assert (sd / KEY_FILENAME).is_file()
        # Token never appears in result body.
        assert "ghp_secret" not in str(result)
        assert "cb_secret" not in str(result)

    def test_apply_partial_surfaces_manual_step(
        self, tmp_path, monkeypatch,
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        sd = tmp_path / "state"
        plan = detect_3_5_state(tmp_path, sd, ["github", "codeberg"])
        result = apply_migration(plan)
        # captured == github only
        assert result["captured"] == ["github"]
        # manual_steps mentions setting env vars for codeberg
        manual = "\n".join(result["manual_steps"])
        assert "codeberg" in manual
        assert "Set env vars" in manual

    def test_apply_writes_backup(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        sd = tmp_path / "state"
        plan = detect_3_5_state(tmp_path, sd, ["github"])
        result = apply_migration(plan)
        backup = Path(result["backup_path"])
        assert backup.is_dir()
        assert "migration-3.5-" in backup.name

    def test_manual_steps_include_git_scrub(
        self, tmp_path, monkeypatch,
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        sd = tmp_path / "state"
        plan = detect_3_5_state(tmp_path, sd, ["github"])
        result = apply_migration(plan)
        manual = "\n".join(result["manual_steps"])
        assert ".git/config" in manual
        assert "token-in-URL" in manual

    def test_idempotent_after_apply(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        sd = tmp_path / "state"
        plan1 = detect_3_5_state(tmp_path, sd, ["github"])
        apply_migration(plan1)
        # Re-detect — should return is_clean now.
        plan2 = detect_3_5_state(tmp_path, sd, ["github"])
        assert plan2.is_clean is True


class TestRollback:
    def test_restore_round_trip(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_x")
        sd = tmp_path / "state"
        # Pre-existing state-dir content (will be backed up).
        sd.mkdir(parents=True, exist_ok=True)
        (sd / "marker.txt").write_text("pre-existing")

        # Apply migration (replaces state-dir contents).
        plan = detect_3_5_state(tmp_path, sd, ["github"])
        result = apply_migration(plan)
        backup = Path(result["backup_path"])

        # After apply, marker.txt may still be present (apply_migration
        # adds files but doesn't wipe). Verify credentials.enc landed.
        assert (sd / CREDENTIALS_FILENAME).exists()

        # Roll back.
        rollback = restore_to_targets(
            backup, project_dir=tmp_path, state_dir=sd,
        )
        assert rollback["success"] is True
        # Marker preserved through round-trip.
        assert (sd / "marker.txt").read_text() == "pre-existing"
        # credentials.enc gone (since pre-migration state had none).
        assert not (sd / CREDENTIALS_FILENAME).exists()

    def test_restore_missing_backup(self, tmp_path):
        result = restore_to_targets(
            tmp_path / "nonexistent",
            project_dir=tmp_path, state_dir=tmp_path / "state",
        )
        assert result["success"] is False
        assert "backup not found" in result["error"]


# (#428 / 3.12.0 D-Coverage drain) The low-level rollback_migration
# helper + restore_to_targets edge paths.


class TestRollbackMigration:
    def test_missing_backup_returns_error_envelope(self, tmp_path):
        from forge_manager_mcp.migrations.migrate_3_5 import (
            rollback_migration,
        )
        result = rollback_migration(tmp_path / "no-such-backup")
        assert result["success"] is False
        assert "backup not found" in result["error"]
        assert result["restored"] == []

    def test_returns_success_envelope_when_backup_exists(self, tmp_path):
        # Even an empty backup directory yields success=True; the
        # helper relies on the caller to bind state-dir/project-dir
        # for actual restore.
        from forge_manager_mcp.migrations.migrate_3_5 import (
            rollback_migration,
        )
        backup = tmp_path / "backup"
        backup.mkdir()
        (backup / "state-dir").mkdir()
        result = rollback_migration(backup)
        assert result["success"] is True
        assert result["backup_path"] == str(backup)


class TestRestoreToTargetsEdges:
    def test_state_backup_dir_with_subdirs_copied(
        self, tmp_path,
    ):
        # Cover lines 292-293 (subdirectory copy via copytree) and
        # 298 (file copy via copy2 inside state-dir loop).
        from forge_manager_mcp.migrations.migrate_3_5 import (
            restore_to_targets,
        )
        backup = tmp_path / "backup"
        state_backup = backup / "state-dir"
        state_backup.mkdir(parents=True)
        # Both file and subdirectory in the state backup.
        (state_backup / "credentials.enc").write_bytes(b"enc")
        (state_backup / "subdir").mkdir()
        (state_backup / "subdir" / "log.txt").write_text("log")

        # Pre-existing state-dir contents (will be wiped by the
        # restore — exercises lines 290-293).
        sd = tmp_path / "state"
        sd.mkdir()
        (sd / "old_file.txt").write_text("old")
        (sd / "old_subdir").mkdir()
        (sd / "old_subdir" / "old.txt").write_text("old subdir")
        # Create a symlink (one of the wipe-loop branches).
        (sd / "symlink").symlink_to(sd / "old_file.txt")

        project_dir = tmp_path / "project"
        result = restore_to_targets(
            backup, project_dir=project_dir, state_dir=sd,
        )
        assert result["success"] is True
        # New state-dir contents present.
        assert (sd / "credentials.enc").read_bytes() == b"enc"
        assert (sd / "subdir" / "log.txt").read_text() == "log"
        # Pre-existing wiped.
        assert not (sd / "old_file.txt").exists()
        assert not (sd / "old_subdir").exists()
        assert not (sd / "symlink").exists()

    def test_claude_backup_files_copied(self, tmp_path):
        # Cover lines 310-314 — claude_backup walk + per-file copy.
        from forge_manager_mcp.migrations.migrate_3_5 import (
            restore_to_targets,
        )
        backup = tmp_path / "backup"
        claude_backup = backup / ".claude"
        claude_backup.mkdir(parents=True)
        (claude_backup / "github-config.json").write_text(
            '{"owner": "x"}',
        )
        # Subdirectory file in .claude/ tree.
        (claude_backup / "skills").mkdir()
        (claude_backup / "skills" / "SKILL.md").write_text("# skill")

        project_dir = tmp_path / "project"
        result = restore_to_targets(
            backup, project_dir=project_dir, state_dir=tmp_path / "no-state",
        )
        assert result["success"] is True
        # Files restored at project_dir/.claude/.
        assert (
            project_dir / ".claude" / "github-config.json"
        ).read_text() == '{"owner": "x"}'
        assert (
            project_dir / ".claude" / "skills" / "SKILL.md"
        ).read_text() == "# skill"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
