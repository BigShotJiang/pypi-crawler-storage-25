"""Unit tests for GitLabAdapter (3.0 / Phase 4).

Covers:
  - platform_id ClassVar
  - from_config token-file + env-var resolution
  - _project_path URL-encoding (slash → %2F, nested groups)
  - shape converters (issue with iid, discussion, comment, milestone)
  - GitLab-specific state mapping ('opened' → 'open', 'active' → 'open')
  - _request error classification
  - probe() returns False on classified-unavailable status
  - Bearer auth header (not GitHub's token convention)

Live integration is covered by the cross-adapter conformance suite
parameterized for gitlab.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters.gitlab import (
    GITLAB_API_BASE,
    GitLabAdapter,
    _category_from_labels,
    _comment_from_api,
    _discussion_from_issue,
    _issue_from_api,
    _make_ref,
    _milestone_from_api,
    _normalize_category,
    _parse_iso,
    _project_path,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_classvar(self):
        assert GitLabAdapter.platform_id == "gitlab"

    def test_instance(self):
        adapter = GitLabAdapter(token="t")
        assert adapter.platform_id == "gitlab"

    def test_has_scaffold_true_from_c4(self):
        assert GitLabAdapter.has_scaffold is True

    def test_has_session_event_surface_false(self):
        assert GitLabAdapter.has_session_event_surface is False


# ---------------------------------------------------------------------------
# _project_path URL-encoding
# ---------------------------------------------------------------------------

class TestProjectPath:
    def test_simple_path(self):
        assert _project_path("alice", "repo") == "alice%2Frepo"

    def test_nested_groups(self):
        # Nested groups: 'parent/child/repo' → 'parent%2Fchild%2Frepo'
        assert _project_path("parent/child", "repo") == "parent%2Fchild%2Frepo"

    def test_special_chars_encoded(self):
        # Space → %20, dot stays.
        assert _project_path("with space", "repo.name") == "with%20space%2Frepo.name"


# ---------------------------------------------------------------------------
# from_config
# ---------------------------------------------------------------------------

class TestFromConfig:
    def test_token_from_file(self, tmp_path: Path, monkeypatch):
        # Make sure no env var leaks in.
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / ".gitlab-token"
        token_file.write_text("ABC123\n")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "gitlab"
        assert adapter._api_base == GITLAB_API_BASE
        assert adapter._token == "ABC123"

    def test_token_from_env_overrides_file(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("GITLAB_TOKEN", "FROM_ENV")
        token_file = tmp_path / ".gitlab-token"
        token_file.write_text("FROM_FILE\n")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "token_path": str(token_file),
        })
        assert adapter._token == "FROM_ENV"

    def test_self_hosted_url(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "url": "https://gitlab.example.com",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "https://gitlab.example.com"

    def test_unsupported_platform_id_raises(self):
        with pytest.raises(_errors.ForgeError, match="unsupported platform_id"):
            GitLabAdapter.from_config({"id": "github"})

    def test_missing_token_file_raises(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # no ~/.gitlab-token here
        with pytest.raises(_errors.ForgeError, match="no token found"):
            GitLabAdapter.from_config({
                "id": "gitlab",
                "token_path": str(tmp_path / "nope"),
            })

    def test_empty_token_file_raises(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))
        token_file = tmp_path / "empty"
        token_file.write_text("   \n")
        with pytest.raises(_errors.ForgeError, match="no token found"):
            GitLabAdapter.from_config({
                "id": "gitlab",
                "token_path": str(token_file),
            })

    def test_strips_trailing_slash_from_url(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "url": "https://gitlab.example.com/",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "https://gitlab.example.com"


# ---------------------------------------------------------------------------
# Headers
# ---------------------------------------------------------------------------

class TestHeaders:
    def test_bearer_auth(self):
        adapter = GitLabAdapter(token="ABC123")
        headers = adapter._headers()
        # GitLab uses Bearer (OAuth-style), distinct from Forgejo's "token <T>"
        # and GitHub's GraphQL Bearer (close cousin but separate adapter).
        assert headers["Authorization"] == "Bearer ABC123"


# ---------------------------------------------------------------------------
# Shape converters
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            platform_id="gitlab",
            native_id="42",
            kind="issue",
            owner="o",
            repo="r",
            number=7,
        )
        assert ref.platform_id == "gitlab"
        assert ref.native_id == "42"
        assert ref.number == 7


class TestIssueFromApi:
    def test_iid_maps_to_ref_number(self):
        # GitLab gotcha: iid is the user-facing project-scoped number;
        # id is the global database-row id.
        d = {
            "id": 100, "iid": 7, "title": "t", "description": "b",
            "state": "opened",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.ref.number == 7
        assert issue.ref.native_id == "100"

    def test_state_opened_maps_to_open(self):
        d = {"id": 1, "iid": 1, "title": "t", "description": "", "state": "opened"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.state == "open"

    def test_state_closed_passes_through(self):
        d = {"id": 1, "iid": 1, "title": "t", "description": "", "state": "closed"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.state == "closed"

    def test_description_field_maps_to_body(self):
        # GitLab uses 'description' where GitHub/Forgejo use 'body'.
        d = {"id": 1, "iid": 1, "title": "t", "description": "hello world", "state": "opened"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.body == "hello world"

    def test_labels_as_strings(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "labels": ["kind:bug", "priority:high"],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.labels == ["kind:bug", "priority:high"]

    def test_milestone_dict_extracts_title(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "milestone": {"id": 1, "title": "v1.0", "state": "active"},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.milestone == "v1.0"

    def test_author_username(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "author": {"username": "alice", "id": 100},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.author == "alice"

    def test_web_url_maps_to_url(self):
        # GitLab uses 'web_url' (not 'html_url' like GitHub/Forgejo).
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "web_url": "https://gitlab.com/o/r/-/issues/1",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.url == "https://gitlab.com/o/r/-/issues/1"


class TestDiscussionFromIssue:
    def test_re_emits_ref_with_discussion_kind(self):
        issue = _issue_from_api(
            {
                "id": 1, "iid": 7, "title": "t", "description": "b",
                "state": "opened",
                "labels": ["kind:discussion"],
            },
            owner="o", repo="r", platform_id="gitlab",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.ref.kind == "discussion"
        assert disc.ref.number == 7

    def test_decided_label_lifts(self):
        issue = _issue_from_api(
            {
                "id": 1, "iid": 1, "title": "t", "description": "",
                "state": "opened",
                "labels": ["kind:discussion", "decided"],
            },
            owner="o", repo="r", platform_id="gitlab",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is True


class TestCommentFromApi:
    def test_basic(self):
        parent = ArtifactRef(
            platform_id="gitlab", native_id="1", kind="issue",
            owner="o", repo="r", number=7,
        )
        d = {
            "id": 200, "body": "hello",
            "author": {"username": "bob"},
            "created_at": "2026-04-29T10:00:00Z",
        }
        comment = _comment_from_api(d, parent=parent, platform_id="gitlab")
        assert isinstance(comment, Comment)
        assert comment.body == "hello"
        assert comment.author == "bob"


class TestMilestoneFromApi:
    def test_active_state_maps_to_open(self):
        # GitLab milestone state is 'active' / 'closed' (not 'open').
        d = {"id": 1, "title": "v1.0", "state": "active"}
        m = _milestone_from_api(d)
        assert isinstance(m, Milestone)
        assert m.state == "open"

    def test_closed_state_passes_through(self):
        d = {"id": 1, "title": "v1.0", "state": "closed"}
        m = _milestone_from_api(d)
        assert m.state == "closed"


class TestNormalizeCategory:
    def test_lowercase(self):
        assert _normalize_category("Architecture") == "architecture"


class TestCategoryFromLabels:
    def test_finds_category(self):
        assert _category_from_labels(["kind:discussion", "category:ux_ui"]) == "ux_ui"

    def test_returns_none_when_absent(self):
        assert _category_from_labels(["kind:discussion"]) is None


class TestParseIso:
    def test_z_suffix(self):
        result = _parse_iso("2026-04-29T12:00:00Z")
        assert result is not None
        assert result.year == 2026

    def test_none(self):
        assert _parse_iso(None) is None

    def test_garbage(self):
        assert _parse_iso("not-a-timestamp") is None


# ---------------------------------------------------------------------------
# _request error classification (MockTransport)
# ---------------------------------------------------------------------------

def _adapter_with_mock(handler) -> GitLabAdapter:
    adapter = GitLabAdapter(
        token="fake", api_base="http://gitlab.test", platform_id="gitlab",
    )
    adapter._client = httpx.AsyncClient(
        base_url=f"{adapter._api_base}/api/v4",
        transport=httpx.MockTransport(handler),
        headers=adapter._headers(),
    )
    return adapter


class TestRequestErrorClassification:
    @pytest.mark.asyncio
    async def test_5xx_raises_unavailable(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(503, text="down"))
        try:
            with pytest.raises(_errors.ForgeUnavailableError) as e:
                await adapter._request("GET", "/version")
            assert e.value.status_code == 503
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_401_raises_unavailable(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(401, text="auth"))
        try:
            with pytest.raises(_errors.ForgeUnavailableError):
                await adapter._request("GET", "/user")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_with_allow_returns_none(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(404))
        try:
            result = await adapter._request(
                "GET", "/projects/foo/issues/9999",
                allow_404_as_none=True,
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_without_allow_raises_forge_error(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(404))
        try:
            with pytest.raises(_errors.ForgeError) as e:
                await adapter._request("GET", "/projects/foo")
            assert not isinstance(e.value, _errors.ForgeUnavailableError)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_2xx_json_parses(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(200, json={"version": "19.0.0"})
        )
        try:
            result = await adapter._request("GET", "/version")
            assert result == {"version": "19.0.0"}
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_204_returns_none(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(204))
        try:
            result = await adapter._request("DELETE", "/projects/foo/issues/1")
            assert result is None
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. GitLab REST is
    number-based; node-ID-only refs surface a clear
    InvalidArtifactRefError."""

    @pytest.mark.asyncio
    async def test_get_issue_body_returns_description_on_200(self):
        # GitLab uses "description" not "body" — the adapter normalizes.
        def handler(req):
            return httpx.Response(200, json={
                "iid": 7, "id": 1007,
                "description": "current description",
                "title": "t", "author": {"username": "u"},
                "labels": [], "state": "opened",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "web_url": "http://gitlab.test/x/y/-/issues/7",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="1007",
                kind="issue", owner="x", repo="y", number=7,
            )
            body = await adapter.get_issue_body(ref)
            assert body == "current description"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_404_raises_invalid_ref(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(404, text="not found")
        )
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="9999",
                kind="issue", owner="x", repo="y", number=9999,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_number_raises(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(500, text="should never be called")
        )
        try:
            ref = ArtifactRef(
                platform_id="github", native_id="I_x",
                kind="issue", owner="x", repo="y", number=None,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# probe()
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_returns_true_on_version_response(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(200, json={"version": "19.0.0"})
        )
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_401(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(401))
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# compute_drift stub
# ---------------------------------------------------------------------------

class TestComputeDrift:
    """PAR-4: GitLab compute_drift diffs remote against the canonical
    snapshot (mirrors Forgejo's pattern). Pre-PAR-4 this returned
    is_clean=True unconditionally — silent gap."""

    @pytest.mark.asyncio
    async def test_inconclusive_without_owner_repo_in_snapshot(self):
        adapter = GitLabAdapter(token="t")
        report = await adapter.compute_drift({})
        assert report.platform_id == "gitlab"
        assert report.is_clean is False
        assert any("owner/repo" in n for n in report.notes)

    @pytest.mark.asyncio
    async def test_clean_when_remote_matches_snapshot(self):
        def handler(req):
            # GitLab uses iid for project-internal numbers.
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": ["bug"]},
                {"iid": 2, "state": "closed", "labels": ["chore"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {
                    1: {"state": "open", "labels": ["bug"]},
                    2: {"state": "closed", "labels": ["chore"]},
                },
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is True
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
            assert report.issues_diverged == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_detects_remote_only_issue(self):
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": []},
                {"iid": 5, "state": "opened", "labels": []},  # remote-only
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert report.issues_only_remote == [5]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_detects_state_divergence(self):
        # Local says open, remote says closed → diverged.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "closed", "labels": []},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert report.issues_diverged == [1]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_partitions_discussions_via_kind_label(self):
        # An item with kind:discussion lands in discussions, not issues.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 7, "state": "opened",
                 "labels": ["kind:discussion", "category:Architecture"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {},
                "discussions": {
                    7: {
                        "state": "open",
                        "labels": ["kind:discussion", "category:Architecture"],
                    },
                },
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is True
            # Issue side untouched.
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_unreachable_remote_reports_inconclusive(self):
        def handler(req):
            return httpx.Response(503, text="upstream down")
        adapter = _adapter_with_mock(handler)
        try:
            report = await adapter.compute_drift(
                {"owner": "g", "repo": "r"}
            )
            assert report.is_clean is False
            assert any("inconclusive" in n for n in report.notes)
        finally:
            await adapter.aclose()


class TestRepoVisibility:
    """PAR-3: get_repo_visibility upper-cases GitLab's lowercase
    ``visibility`` field so the Protocol-level alphabet is consistent
    with GitHub (PUBLIC/PRIVATE/INTERNAL)."""

    @pytest.mark.asyncio
    async def test_public_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "public"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_internal_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "internal"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "INTERNAL"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_private_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "private"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PRIVATE"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_missing_repo_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()


class TestBootstrapProject:
    """Multi-platform scaffold C4 — GitLabAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert GitLabAdapter.has_scaffold is True

    @pytest.mark.asyncio
    async def test_bootstrap_creates_project_pair_and_seeds_labels(self):
        labels_created: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path

            # Namespace lookup: returns the matching group.
            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[
                    {"id": 99, "name": "myorg", "path": "myorg", "kind": "group"},
                ])

            # Probe: project doesn't exist (404 with allow_404_as_none).
            if method == "GET" and path.startswith("/api/v4/projects/myorg/") \
                    and "/labels" not in path:
                return httpx.Response(404)

            # Create: returns the project.
            if method == "POST" and path == "/api/v4/projects":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                # Verify namespace_id was passed (group creation).
                assert body.get("namespace_id") == 99
                return httpx.Response(201, json={
                    "id": 200 if body["name"] == "widgets-dev" else 201,
                    "name": body["name"],
                    "path_with_namespace": f"myorg/{body['name']}",
                    "web_url": f"http://gitlab.test/myorg/{body['name']}",
                    "visibility": body["visibility"],
                })

            # Label probe (always-empty paginated → trigger create).
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                labels_created.append(body["name"])
                return httpx.Response(201, json={"id": len(labels_created)})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets",
                description="widgets project",
            )
        finally:
            await adapter.aclose()

        assert result.platform_id == "gitlab"
        assert result.phase == "complete"
        assert result.artifacts["dev_project"]["existed"] is False
        assert result.artifacts["public_project"]["existed"] is False
        assert result.artifacts["namespace_id"] == 99
        # Standard labels.
        assert "bug" in labels_created
        assert "rfc" in labels_created
        assert "area:mcp" in labels_created
        # Discussions-as-Issues reserved.
        assert "kind:discussion" in labels_created
        assert "category:Architecture" in labels_created
        assert "decided" in labels_created

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent_when_projects_exist(self):
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path

            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[
                    {"id": 99, "name": "myorg", "path": "myorg", "kind": "group"},
                ])

            # Both projects exist (200).
            if method == "GET" and path.startswith("/api/v4/projects/myorg/") \
                    and "/labels" not in path:
                return httpx.Response(200, json={
                    "id": 42, "name": "widgets",
                    "path_with_namespace": "myorg/widgets",
                    "web_url": "http://gitlab.test/myorg/widgets",
                    "visibility": "private",
                })

            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["dev_project"]["existed"] is True
        assert result.artifacts["public_project"]["existed"] is True

    @pytest.mark.asyncio
    async def test_bootstrap_falls_back_to_user_namespace_when_lookup_misses(self):
        """When the owner doesn't match any namespace (user-account case),
        the create POST omits namespace_id; GitLab places the project
        under the authenticated user's default namespace."""
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[])  # no match
            if method == "GET" and path.startswith("/api/v4/projects/") \
                    and "/labels" not in path:
                return httpx.Response(404)
            if method == "POST" and path == "/api/v4/projects":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                # No namespace_id in payload → user-namespace fallback.
                assert "namespace_id" not in body
                return httpx.Response(201, json={
                    "id": 7, "name": body["name"],
                    "path_with_namespace": f"alice/{body['name']}",
                    "web_url": f"http://gitlab.test/alice/{body['name']}",
                    "visibility": body["visibility"],
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="alice", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["namespace_id"] is None

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_owner(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="owner"):
                await adapter.bootstrap_project(
                    owner="  ", project_name="widgets", description="",
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_project_name(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="project_name"):
                await adapter.bootstrap_project(
                    owner="myorg", project_name="", description="",
                )
        finally:
            await adapter.aclose()


class TestEnsureLabelExistingGitLab:
    """(#428) Drain ensure_label existing-label early-return path."""

    @pytest.mark.asyncio
    async def test_ensure_label_existing_returns_id(self):
        # (#428) L636-638 — _find_label_id returns existing → return id.
        recorded = {"posts": 0}
        def handler(req):
            if req.method == "POST" and "/labels" in req.url.path:
                recorded["posts"] += 1
                return httpx.Response(201, json={"id": 99, "name": "x"})
            # _find_label_id GET returns the label.
            return httpx.Response(200, json=[{"id": 42, "name": "bug"}])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.ensure_label(
                owner="o", repo="r", name="bug",
            )
            assert result == "42"
            assert recorded["posts"] == 0  # no POST since label existed
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_label_id_paginates_until_short_page(self):
        # (#428) L660-662 — pagination terminates when page < 100.
        # Build a 2-page sequence: first page 100 results without match;
        # second page short (<100) so loop exits.
        recorded = {"page": 0}
        def handler(req):
            recorded["page"] += 1
            if recorded["page"] == 1:
                # 100 unmatched labels (pages until page < 100).
                return httpx.Response(200, json=[
                    {"id": i, "name": f"label-{i}"} for i in range(100)
                ])
            # Page 2: short → exit returning None.
            return httpx.Response(200, json=[
                {"id": 200, "name": "other"},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._find_label_id(
                owner="o", repo="r", name="missing",
            )
            assert result is None
            assert recorded["page"] >= 2
        finally:
            await adapter.aclose()


class TestCreateIssueWithMilestone:
    @pytest.mark.asyncio
    async def test_create_issue_with_resolved_milestone(self):
        # (#428) L286-292 — find_milestone success → milestone_id payload.
        recorded = {"json": None}
        def handler(req):
            if "/milestones/" in req.url.path:
                return httpx.Response(200, json={
                    "id": 1, "iid": 5, "title": "v1.0",
                    "state": "active", "description": "",
                })
            if req.method == "POST" and req.url.path.endswith("/issues"):
                import json as _json
                recorded["json"] = _json.loads(req.content.decode())
                return httpx.Response(201, json={
                    "id": 1, "iid": 1, "title": "T", "description": "B",
                    "state": "opened", "labels": [], "milestone": None,
                    "web_url": "http://gitlab.test/o/r/issues/1",
                })
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.create_issue(
                owner="o", repo="r", title="T", body="B",
                labels=[], milestone=5,
            )
            assert "milestone_id" in recorded["json"]
        finally:
            await adapter.aclose()


class TestBundleRecoverContextDelegatesGitLab:
    @pytest.mark.asyncio
    async def test_bundle_recover_context_delegates(self):
        # (#428) L825 — delegates to default helper.
        def handler(req):
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bundle_recover_context(
                owner="o", repo="r", toc_discussion_id="D_1",
                since_days=7, issue_limit=10,
            )
            assert result is not None
        finally:
            await adapter.aclose()


class TestComputeDriftLabelsGitLab:
    @pytest.mark.asyncio
    async def test_compute_drift_discussion_label_divergence(self):
        # (#428) L925-930 — discussion label set diff.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "iid": 5, "state": "opened",
                    "labels": ["kind:discussion", "different"],
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "discussions": {
                    5: {"state": "open",
                        "labels": ["kind:discussion", "original"]},
                },
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is False
        finally:
            await adapter.aclose()


class TestNamespaceResolution:
    @pytest.mark.asyncio
    async def test_resolve_namespace_id_non_list_returns_none(self):
        # (#428) L1052-1053 — non-list response → None.
        def handler(req):
            return httpx.Response(200, json={"not": "a list"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._resolve_namespace_id("o")
            assert result is None
        finally:
            await adapter.aclose()


class TestPaginateGetEdgeBranches:
    @pytest.mark.asyncio
    async def test_non_list_response_breaks_loop(self):
        # (#428) L687-688 — non-list response → break.
        def handler(req):
            return httpx.Response(200, json={"not": "a list"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._paginate_get("/projects/x/issues")
            assert result == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_short_page_breaks_loop(self):
        # (#428) L690-691 — len(data) < page_size → break.
        def handler(req):
            return httpx.Response(200, json=[{"id": 1}])  # short page
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._paginate_get(
                "/projects/x/issues", page_size=50,
            )
            assert len(result) == 1
        finally:
            await adapter.aclose()


class TestFetchRemoteChangesGitLab:
    """(#428) Drain GitLabAdapter fetch_remote_changes shape paths."""

    @pytest.mark.asyncio
    async def test_create_issue_shape(self):
        from datetime import datetime, timezone
        call_count = {"n": 0}
        def handler(req):
            call_count["n"] += 1
            if "/notes" in req.url.path:
                return httpx.Response(200, json=[])
            if call_count["n"] == 1:
                return httpx.Response(200, json=[{
                    "id": 1, "iid": 1, "title": "T", "description": "B",
                    "state": "opened", "labels": [], "milestone": None,
                    "created_at": "2026-06-01T00:00:00Z",
                    "updated_at": "2026-06-01T00:00:00Z",
                    "closed_at": None,
                    "web_url": "http://gitlab.test/o/r/issues/1",
                }])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            create_changes = [c for c in changes if c.operation == "create_issue"]
            assert len(create_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_close_issue_shape(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/notes" in req.url.path:
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[{
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "closed", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": "2026-06-02T00:00:00Z",
                "web_url": "http://gitlab.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            close_changes = [c for c in changes if c.operation == "close_issue"]
            assert len(close_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_body_default_path(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/notes" in req.url.path:
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[{
                "id": 1, "iid": 1, "title": "T", "description": "B-new",
                "state": "opened", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            update_changes = [c for c in changes if c.operation == "update_body"]
            assert len(update_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_issues_unreachable_returns_sentinel(self):
        from datetime import datetime, timezone
        def handler(req):
            return httpx.Response(503)
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert len(changes) == 1
            assert changes[0].operation == "rate_limited"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_notes_unreachable_appends_sentinel(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/notes" in req.url.path:
                return httpx.Response(503)
            return httpx.Response(200, json=[{
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "opened", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert any(c.operation == "rate_limited" for c in changes)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_notes_filtered_by_system_and_since(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/notes" in req.url.path:
                return httpx.Response(200, json=[
                    {  # system note → skip
                        "id": 1, "body": "label change",
                        "author": {"username": "u"},
                        "created_at": "2026-06-02T00:00:00Z",
                        "updated_at": "2026-06-02T00:00:00Z",
                        "system": True,
                    },
                    {  # old note → skip via since check
                        "id": 2, "body": "old",
                        "author": {"username": "u"},
                        "created_at": "2025-01-01T00:00:00Z",
                        "updated_at": "2025-01-01T00:00:00Z",
                        "system": False,
                    },
                    {  # real new note → kept
                        "id": 3, "body": "kept",
                        "author": {"username": "u"},
                        "created_at": "2026-06-02T00:00:00Z",
                        "updated_at": "2026-06-02T00:00:00Z",
                        "system": False,
                    },
                ])
            return httpx.Response(200, json=[{
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "opened", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            add_comments = [c for c in changes if c.operation == "add_comment"]
            assert len(add_comments) == 1
        finally:
            await adapter.aclose()


class TestProbeAndDriftDelegation:
    """(#428) Drain GitLabAdapter probe + compute_drift paths."""

    @pytest.mark.asyncio
    async def test_probe_returns_true_on_version(self):
        # (#428) L835-840.
        def handler(req):
            return httpx.Response(200, json={"version": "16.0"})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_forge_unavailable(self):
        # (#428) L841-842.
        def handler(req):
            return httpx.Response(503, text="down")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_forge_error(self):
        # (#428) L843-844.
        def handler(req):
            return httpx.Response(404, text="missing")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_missing_owner_returns_dirty(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        report = await adapter.compute_drift({})
        assert report.is_clean is False
        assert any("snapshot missing" in n for n in report.notes)

    @pytest.mark.asyncio
    async def test_compute_drift_unreachable_returns_dirty(self):
        # (#428) L878-883.
        def handler(req):
            return httpx.Response(503)
        adapter = _adapter_with_mock(handler)
        try:
            report = await adapter.compute_drift(
                {"owner": "o", "repo": "r"},
            )
            assert report.is_clean is False
            assert any("unreachable" in n for n in report.notes)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_clean_when_remote_matches_local(self):
        # (#428) L886-948.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": ["bug"]},
                {"iid": 5, "state": "opened", "labels": ["kind:discussion"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "issues": {1: {"state": "open", "labels": ["bug"]}},
                "discussions": {
                    5: {"state": "open", "labels": ["kind:discussion"]},
                },
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_state_diverged(self):
        # (#428) L912-917 + L924-930 — state divergence.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "closed", "labels": []},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_skips_no_iid(self):
        # (#428) L889-891.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": None, "state": "opened", "labels": []},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            report = await adapter.compute_drift(
                {"owner": "o", "repo": "r"},
            )
            assert report.is_clean is True
        finally:
            await adapter.aclose()


class TestProjectBoardNotImplemented:
    """(#428) GitLabAdapter project-board methods raise NotImplementedError."""

    @pytest.mark.asyncio
    async def test_add_to_project_board(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        ref = ArtifactRef(
            platform_id="gitlab", native_id="o/r#1",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError):
            await adapter.add_to_project_board(board_id="b", ref=ref)

    @pytest.mark.asyncio
    async def test_get_project_status_field(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        with pytest.raises(NotImplementedError):
            await adapter.get_project_status_field(board_id="b")

    @pytest.mark.asyncio
    async def test_get_project_item_id(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        ref = ArtifactRef(
            platform_id="gitlab", native_id="x",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError):
            await adapter.get_project_item_id(ref=ref, board_id="b")

    @pytest.mark.asyncio
    async def test_move_project_item(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        with pytest.raises(NotImplementedError):
            await adapter.move_project_item(
                board_id="b", item_id="i",
                status_field_id="s", option_id="o",
            )


class TestReleaseAndUrlHelpers:
    """(#428) Drain GitLabAdapter release + URL helpers."""

    @pytest.mark.asyncio
    async def test_create_release_marshals_response(self):
        # (#428) L699-732.
        def handler(req):
            return httpx.Response(201, json={
                "tag_name": "v1.0.0", "name": "v1.0.0",
                "description": "notes",
                "created_at": "2026-05-12T00:00:00Z",
                "_links": {"self": "http://gitlab.test/o/r/-/releases/v1.0.0"},
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_release(
                owner="o", repo="r", tag="v1.0.0",
                name="v1.0.0", body="notes", draft=True,
            )
            assert result.tag == "v1.0.0"
            assert result.url == "http://gitlab.test/o/r/-/releases/v1.0.0"
        finally:
            await adapter.aclose()

    def test_get_clone_url_strips_api_suffix(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(
            token="x", api_base="https://gitlab.com/api/v4",
        )
        assert (
            adapter.get_clone_url("o", "r")
            == "https://gitlab.com/o/r.git"
        )

    def test_noreply_email_with_user_id(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(
            token="x", api_base="https://gitlab.com/api/v4",
        )
        email = adapter.noreply_email("octocat", user_id=42)
        assert email == "42-octocat@users.noreply.gitlab.com"

    def test_noreply_email_legacy_no_user_id(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(
            token="x", api_base="https://gitlab.com/api/v4",
        )
        email = adapter.noreply_email("octocat")
        assert email == "octocat@users.noreply.gitlab.com"

    def test_public_issue_url_regex_matches_gitlab_url(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(
            token="x", api_base="https://gitlab.com/api/v4",
        )
        pattern = adapter.public_issue_url_regex()
        m = pattern.match("https://gitlab.com/owner/repo/issues/42")
        assert m is not None
        assert m.group(3) == "42"

    @pytest.mark.asyncio
    async def test_delete_release_idempotent(self):
        # (#428) L777-789 — 404 swallowed.
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.delete_release(owner="o", repo="r", tag="v9")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_delete_release_dispatches_delete(self):
        recorded = {"method": None, "path": None}
        def handler(req):
            recorded["method"] = req.method
            recorded["path"] = req.url.path
            return httpx.Response(204, text="")
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.delete_release(owner="o", repo="r", tag="v1.0.0")
            assert recorded["method"] == "DELETE"
            assert "v1.0.0" in recorded["path"]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_text(self):
        # (#428) L795-808 — fetch_file_content delegates to raw endpoint.
        def handler(req):
            return httpx.Response(200, text="file body")
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.fetch_file_content(
                owner="o", repo="r", path="foo.md",
            )
            assert result is None or isinstance(result, str)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_fetch_file_content_404_returns_none(self):
        # (#428) L806-807.
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.fetch_file_content(
                owner="o", repo="r", path="missing.md",
            )
            assert result is None
        finally:
            await adapter.aclose()


class TestMarkAndStubsAndComments:
    """(#428) Drain GitLabAdapter mark_decided / mark_answer / stubs / comments."""

    @pytest.mark.asyncio
    async def test_mark_decided_dispatches_label_add(self):
        # (#428) L495-496 — mark_decided → add_label("decided").
        recorded = {"puts": []}
        def handler(req):
            if req.method == "GET" and "/labels" in req.url.path:
                return httpx.Response(200, json=[])
            if req.method == "POST" and "/labels" in req.url.path:
                return httpx.Response(201, json={"id": 1, "name": "decided"})
            if req.method == "PUT" and "/issues" in req.url.path:
                recorded["puts"].append(str(req.url))
                return httpx.Response(200, json={})
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            await adapter.mark_decided(ref)
            assert len(recorded["puts"]) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_mark_answer_raises_not_implemented(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        ref = ArtifactRef(
            platform_id="gitlab", native_id="x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError):
            await adapter.mark_answer(ref)


class TestMilestoneGapNotImplemented:
    """(#428) GitLabAdapter milestone/gap stubs all raise NotImplementedError."""

    @pytest.mark.asyncio
    async def test_create_milestone(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").create_milestone()

    @pytest.mark.asyncio
    async def test_get_milestone_body(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").get_milestone_body("1.0")

    @pytest.mark.asyncio
    async def test_update_milestone_state(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").update_milestone_state(
                "1.0", "open",
            )

    @pytest.mark.asyncio
    async def test_update_milestone_meta(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").update_milestone_meta(
                "1.0", tier="x",
            )

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").list_all_milestone_versions()

    @pytest.mark.asyncio
    async def test_upsert_gap(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").upsert_gap()

    @pytest.mark.asyncio
    async def test_get_gap_body(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").get_gap_body("cat")

    @pytest.mark.asyncio
    async def test_update_gap_state(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").update_gap_state(
                "cat", "triage",
            )

    @pytest.mark.asyncio
    async def test_update_gap_meta(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").update_gap_meta(
                "cat", tier="x",
            )

    @pytest.mark.asyncio
    async def test_list_gap_categories(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        with pytest.raises(NotImplementedError):
            await GitLabAdapter(token="x").list_gap_categories()


class TestCommentDelegation:
    """(#428) Drain GitLabAdapter comment paths."""

    @pytest.mark.asyncio
    async def test_append_comment_dispatches_post(self):
        # (#428) L576-585.
        def handler(req):
            return httpx.Response(201, json={
                "id": 1, "body": "hello",
                "author": {"username": "bot"},
                "created_at": "2026-05-12T00:00:00Z",
                "system": False,
            })
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.append_comment(target, "hello")
            assert result.body == "hello"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_append_comment_unsupported_kind_raises(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        target = ArtifactRef(
            platform_id="gitlab", native_id="x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="append_comment"):
            await adapter.append_comment(target, "x")

    @pytest.mark.asyncio
    async def test_list_comments_skips_system_notes(self):
        # (#428) L608-611 — system=True notes skipped.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "body": "real",
                    "author": {"username": "u"},
                    "created_at": "2026-05-12T00:00:00Z",
                    "system": False,
                },
                {
                    "id": 2, "body": "label change",
                    "author": {"username": "u"},
                    "created_at": "2026-05-12T00:00:00Z",
                    "system": True,  # skipped
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.list_comments(target)
            assert len(result) == 1
            assert result[0].body == "real"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_comments_with_since_days_filters(self):
        # (#428) L612-615 — since_days local filter.
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        old = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "body": "old",
                    "author": {"username": "u"},
                    "created_at": old, "system": False,
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.list_comments(target, since_days=7)
            assert len(result) == 0
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_comments_with_limit_slices(self):
        # (#428) L619-620 — limit slices last N.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": i, "body": f"c{i}",
                    "author": {"username": "u"},
                    "created_at": "2026-05-12T00:00:00Z",
                    "system": False,
                }
                for i in range(5)
            ])
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.list_comments(target, limit=2)
            assert len(result) == 2
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_comments_unsupported_kind_raises(self):
        from forge_manager_mcp.adapters.gitlab import GitLabAdapter
        adapter = GitLabAdapter(token="x")
        target = ArtifactRef(
            platform_id="gitlab", native_id="x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="list_comments"):
            await adapter.list_comments(target)


class TestExtraIssueAndDiscussion:
    """(#428) Drain GitLabAdapter remaining issue + discussion paths."""

    @pytest.mark.asyncio
    async def test_get_issue_body_returns_description(self):
        # (#428) L311-329 — get_issue_body fetches issue + returns description.
        def handler(req):
            return httpx.Response(200, json={"description": "body text"})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            assert await adapter.get_issue_body(ref) == "body text"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_404_raises(self):
        # (#428) L324-327 — 404 → InvalidArtifactRefError.
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#999",
                kind="issue", owner="o", repo="r", number=999,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_issue_body_dispatches_put(self):
        # (#428) L331-339 — PUT with description payload.
        recorded = {}
        def handler(req):
            recorded["method"] = req.method
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            await adapter.update_issue_body(ref, "new")
            assert recorded["method"] == "PUT"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_close_issue_returns_closed_issue(self):
        # (#428) L341-355 — PUT state_event=close.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "closed", "labels": [], "milestone": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.close_issue(ref)
            assert result.state == "closed"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_remove_label_dispatches_put(self):
        # (#428) L367-373 — PUT remove_labels.
        recorded = {}
        def handler(req):
            recorded["method"] = req.method
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            await adapter.remove_label(ref, "bug")
            assert recorded["method"] == "PUT"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_search_issues_state_open_maps_to_opened(self):
        # (#428) L388-389 — open → opened.
        recorded = {"params": None}
        def handler(req):
            recorded["params"] = dict(req.url.params)
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.search_issues(owner="o", repo="r", state="open")
            assert recorded["params"].get("state") == "opened"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_search_issues_with_query_labels_milestone(self):
        # (#428) L386-414 — full filter assembly.
        recorded = {"params": None}
        def handler(req):
            recorded["params"] = dict(req.url.params)
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.search_issues(
                owner="o", repo="r", query="x", state="closed",
                labels=["bug", "ui"], milestone="1.0",
            )
            assert recorded["params"]["state"] == "closed"
            assert recorded["params"]["search"] == "x"
            assert recorded["params"]["labels"] == "bug,ui"
            assert recorded["params"]["milestone"] == "1.0"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_open_issues_delegates_to_search(self):
        # (#428) L417-423 — list_open_issues calls search_issues.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "iid": 1, "title": "T", "description": "B",
                    "state": "opened", "labels": [], "milestone": None,
                    "web_url": "http://gitlab.test/o/r/issues/1",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.list_open_issues(owner="o", repo="r")
            assert len(result) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_create_discussion_adds_kind_label(self):
        # (#428) L429-444 — create_discussion adds kind:discussion + category.
        def handler(req):
            if req.method == "POST" and "/labels" in req.url.path:
                return httpx.Response(201, json={"id": 1, "name": "x"})
            if req.method == "GET" and "/labels" in req.url.path:
                return httpx.Response(200, json=[])
            if req.method == "POST" and "/issues" in req.url.path:
                return httpx.Response(201, json={
                    "id": 1, "iid": 1, "title": "T", "description": "B",
                    "state": "opened",
                    "labels": ["kind:discussion", "category:architecture"],
                    "milestone": None,
                    "web_url": "http://gitlab.test/o/r/issues/1",
                })
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_discussion(
                owner="o", repo="r", title="T", body="B",
                category="Architecture",
            )
            assert result.ref.kind == "discussion"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_resolves_kind_discussion(self):
        # (#428) L446-456 — get_discussion fetches issue + filters.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "opened",
                "labels": ["kind:discussion", "category:ideas"],
                "milestone": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.get_discussion("o", "r", 1)
            assert result.ref.kind == "discussion"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_without_kind_label_raises(self):
        # (#428) L450-454.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "opened", "labels": ["bug"], "milestone": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_discussion("o", "r", 1)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates(self):
        # (#428) L458-461.
        def handler(req):
            return httpx.Response(200, json={"description": "disc body"})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            assert await adapter.get_discussion_body(ref) == "disc body"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_discussion_body_delegates(self):
        # (#428) L463-466.
        recorded = {}
        def handler(req):
            recorded["method"] = req.method
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            await adapter.update_discussion_body(ref, "new body")
            assert recorded["method"] == "PUT"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_recent_discussions_filters_by_cutoff(self):
        # (#428) L468-493 — list_recent filters out old.
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        old = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
        recent = now.isoformat().replace("+00:00", "Z")

        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "iid": 1, "title": "old",
                    "description": "B", "state": "opened",
                    "labels": ["kind:discussion"],
                    "milestone": None, "created_at": old,
                    "web_url": "http://gitlab.test/o/r/issues/1",
                },
                {
                    "id": 2, "iid": 2, "title": "new",
                    "description": "B", "state": "opened",
                    "labels": ["kind:discussion"],
                    "milestone": None, "created_at": recent,
                    "web_url": "http://gitlab.test/o/r/issues/2",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.list_recent_discussions(
                owner="o", repo="r", since_days=7,
            )
            assert len(result) == 1
            assert result[0].title == "new"
        finally:
            await adapter.aclose()


class TestRepoLevelReadDelegation:
    """(#428) Drain GitLabAdapter repo-level reads via MockTransport."""

    @pytest.mark.asyncio
    async def test_get_repo_node_id_returns_string_id(self):
        # (#428) L206-211 — happy path returns str(id).
        def handler(req):
            return httpx.Response(200, json={"id": 999})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.get_repo_node_id("o", "r")
            assert result == "999"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_node_id_missing_id_raises(self):
        # (#428) L209-210 — id missing → InvalidArtifactRefError.
        def handler(req):
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_repo_node_id("o", "r")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_visibility_uppercases_each_value(self):
        # (#428) L213-227 — public/internal/private uppercased.
        for raw, expected in [
            ("public", "PUBLIC"),
            ("internal", "INTERNAL"),
            ("private", "PRIVATE"),
        ]:
            def handler(req, v=raw):
                return httpx.Response(200, json={"visibility": v})
            adapter = _adapter_with_mock(handler)
            try:
                assert await adapter.get_repo_visibility("o", "r") == expected
            finally:
                await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_visibility_404_returns_none(self):
        # (#428) L224-225 — 404 → None.
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_milestones_state_open_maps_to_active(self):
        # (#428) L234-244 — state="open" → params["state"]="active".
        recorded = {"params": None}
        def handler(req):
            recorded["params"] = dict(req.url.params)
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.list_milestones("o", "r", state="open")
            assert recorded["params"].get("state") == "active"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_milestones_state_closed_passes_through(self):
        recorded = {"params": None}
        def handler(req):
            recorded["params"] = dict(req.url.params)
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.list_milestones("o", "r", state="closed")
            assert recorded["params"].get("state") == "closed"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_milestone_by_number(self):
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "iid": 5, "title": "1.0", "state": "active",
                "description": "", "due_date": None,
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.find_milestone("o", "r", 5)
            assert result is not None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_milestone_by_number_404_returns_none(self):
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.find_milestone("o", "r", 999) is None
        finally:
            await adapter.aclose()


class TestIssueWriteDelegation:
    """(#428) Drain GitLabAdapter issue write paths."""

    @pytest.mark.asyncio
    async def test_create_issue_no_milestone(self):
        def handler(req):
            return httpx.Response(201, json={
                "id": 1, "iid": 1, "title": "T", "description": "B",
                "state": "opened", "labels": [], "milestone": None,
                "web_url": "http://gitlab.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_issue(
                owner="o", repo="r", title="T", body="B", labels=[],
            )
            assert result.title == "T"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_create_issue_milestone_not_found_raises(self):
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.create_issue(
                    owner="o", repo="r", title="T", body="B",
                    labels=[], milestone=99,
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_404_raises(self):
        # (#428) L307-308.
        def handler(req):
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue("o", "r", 999)
        finally:
            await adapter.aclose()


class TestFindMilestoneByTitle:
    """(#428) L257-259 — find_milestone with non-numeric name routes
    to title-based linear search via _find_milestone_by_title_in_list."""

    @pytest.mark.asyncio
    async def test_find_milestone_by_title_match(self):
        def handler(req):
            # /milestones list-call returns 1.0
            if req.url.path.endswith("/milestones"):
                return httpx.Response(200, json=[
                    {"id": 1, "iid": 5, "title": "1.0", "state": "active",
                     "description": "", "due_date": None},
                    {"id": 2, "iid": 6, "title": "2.0", "state": "active",
                     "description": "", "due_date": None},
                ])
            return httpx.Response(404)
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.find_milestone("o", "r", "1.0")
            assert result is not None
            assert result.title == "1.0"
        finally:
            await adapter.aclose()


class TestPaginateGetMultiPage:
    """(#428) L692 — _paginate_get advances to next page when a full
    page comes back (page += 1)."""

    @pytest.mark.asyncio
    async def test_paginate_walks_multiple_pages(self):
        page_size = 100  # default
        page1 = [{"id": i} for i in range(page_size)]  # full page → next
        page2 = [{"id": page_size}]  # short page → stop

        calls = {"n": 0}

        def handler(req):
            calls["n"] += 1
            page_param = req.url.params.get("page")
            if page_param == "1":
                return httpx.Response(200, json=page1)
            return httpx.Response(200, json=page2)

        adapter = _adapter_with_mock(handler)
        try:
            results = await adapter._paginate_get("/projects/x/issues")
            assert len(results) == page_size + 1
            assert calls["n"] == 2
        finally:
            await adapter.aclose()


class TestComputeDriftLabelsBranches:
    """(#428) L917 + L927-928 — compute_drift hits the labels-differ
    branch for issues and the state-differs branch (with continue) for
    discussions."""

    @pytest.mark.asyncio
    async def test_drift_label_and_state_branches(self):
        # Remote issue 1 with [bug] (no kind:discussion → routed to issues),
        # local issue 1 with [] → state matches but labels differ → L917.
        # Remote disc 2 with kind:discussion + state=closed; local disc 2
        # state=open → state differs → L927 + L928 continue.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": ["bug"]},
                {"iid": 2, "state": "closed",
                 "labels": ["kind:discussion"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "o",
                "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
                "discussions": {2: {"state": "open", "labels": []}},
            }
            report = await adapter.compute_drift(snapshot)
            assert 1 in report.issues_diverged
            assert 2 in report.discussions_diverged
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
            assert report.is_clean is False
        finally:
            await adapter.aclose()


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
