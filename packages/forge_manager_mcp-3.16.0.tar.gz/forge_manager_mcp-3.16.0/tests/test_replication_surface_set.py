"""Tests for replication.surface_set helper (Discussion #23 A.5)."""
from __future__ import annotations

import pytest

from forge_manager_mcp.replication import surface_set as ss


class TestValidSurfaces:
    def test_vocabulary_is_stable(self):
        """The canonical surface set is frozen; adding a new one is
        an explicit API extension. Asserting the exact set guards
        accidental additions."""
        assert ss.VALID_SURFACES == frozenset({
            "bodies", "comments", "releases", "labels", "milestones",
        })

    def test_default_is_bodies_and_releases(self):
        assert ss.DEFAULT_SURFACE_SET == ("bodies", "releases")

    def test_default_subset_of_valid(self):
        for entry in ss.DEFAULT_SURFACE_SET:
            assert entry in ss.VALID_SURFACES


class TestGetSurfaceSet:
    def test_missing_field_returns_default(self):
        assert ss.get_surface_set({}) == ss.DEFAULT_SURFACE_SET

    def test_none_returns_default(self):
        assert ss.get_surface_set({"surface_set": None}) == (
            ss.DEFAULT_SURFACE_SET
        )

    def test_explicit_full_set(self):
        entry = {"surface_set": [
            "bodies", "comments", "releases", "labels", "milestones",
        ]}
        result = ss.get_surface_set(entry)
        # Order preserved per input.
        assert result == (
            "bodies", "comments", "releases", "labels", "milestones",
        )

    def test_subset(self):
        assert ss.get_surface_set({"surface_set": ["bodies"]}) == (
            "bodies",
        )

    def test_empty_list_is_explicit_zero(self):
        """An operator's explicit empty list means push nothing to
        this mirror — distinct from "no surface_set field" (which
        defaults to bodies+releases)."""
        assert ss.get_surface_set({"surface_set": []}) == ()

    def test_unknown_tokens_dropped(self):
        entry = {"surface_set": ["bodies", "bogus", "releases"]}
        assert ss.get_surface_set(entry) == ("bodies", "releases")

    def test_non_string_entries_dropped(self):
        entry = {"surface_set": ["bodies", 42, None, "releases"]}
        assert ss.get_surface_set(entry) == ("bodies", "releases")

    def test_duplicates_deduplicated(self):
        entry = {"surface_set": ["bodies", "bodies", "releases", "bodies"]}
        assert ss.get_surface_set(entry) == ("bodies", "releases")

    def test_string_value_returns_default(self):
        """`surface_set: "bodies"` (not a list) → default. Keeps the
        schema rigorous; configs must use a list."""
        assert ss.get_surface_set({"surface_set": "bodies"}) == (
            ss.DEFAULT_SURFACE_SET
        )

    def test_int_value_returns_default(self):
        assert ss.get_surface_set({"surface_set": 42}) == (
            ss.DEFAULT_SURFACE_SET
        )

    def test_order_preserved_from_input(self):
        """Operator-specified order survives the helper — useful for
        display surfaces that show the configured value as-is."""
        entry = {"surface_set": ["releases", "bodies"]}
        assert ss.get_surface_set(entry) == ("releases", "bodies")


class TestAcceptsSurface:
    def test_default_accepts_bodies(self):
        assert ss.accepts_surface({}, "bodies") is True

    def test_default_accepts_releases(self):
        assert ss.accepts_surface({}, "releases") is True

    def test_default_rejects_comments(self):
        assert ss.accepts_surface({}, "comments") is False

    def test_explicit_set_filters(self):
        entry = {"surface_set": ["bodies"]}
        assert ss.accepts_surface(entry, "bodies") is True
        assert ss.accepts_surface(entry, "releases") is False

    def test_empty_set_rejects_all(self):
        entry = {"surface_set": []}
        for surface in ss.VALID_SURFACES:
            assert ss.accepts_surface(entry, surface) is False

    def test_unknown_surface_always_rejected(self):
        """Even with a wildly permissive config, requesting a
        non-vocabulary surface returns False."""
        entry = {"surface_set": list(ss.VALID_SURFACES) + ["bogus"]}
        assert ss.accepts_surface(entry, "bogus") is False


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
