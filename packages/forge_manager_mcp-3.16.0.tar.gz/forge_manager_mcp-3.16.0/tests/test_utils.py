"""Unit tests for the IO-free utils module (#82 Phase 1).

These tests depend only on `:utils` so they re-run only when
utils.py itself changes — handler / parser / github edits do not
invalidate them.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.utils import (
    SessionActivity,
    check_overwrite_size,
    compose_session_summary,
    meets_confidence_threshold,
    resolve_new_body,
)


class TestMeetsConfidenceThreshold:
    def test_high_meets_high(self):
        assert meets_confidence_threshold("high", "high")

    def test_medium_does_not_meet_high(self):
        assert not meets_confidence_threshold("medium", "high")

    def test_medium_meets_medium(self):
        assert meets_confidence_threshold("medium", "medium")

    def test_low_does_not_meet_medium(self):
        assert not meets_confidence_threshold("low", "medium")

    def test_low_meets_low(self):
        assert meets_confidence_threshold("low", "low")

    def test_high_meets_low(self):
        assert meets_confidence_threshold("high", "low")

    def test_invalid_observed_raises(self):
        with pytest.raises(ValueError, match="observed"):
            meets_confidence_threshold("certain", "high")

    def test_invalid_threshold_raises(self):
        with pytest.raises(ValueError, match="threshold"):
            meets_confidence_threshold("high", "bogus")


class TestComposeSessionSummary:
    def test_empty_activity_returns_explanatory_line(self):
        activity = SessionActivity()
        out = compose_session_summary(
            activity, skill_update_candidates=0, has_pending_buffer=False
        )
        assert "No tracked activity" in out

    def test_full_activity(self):
        activity = SessionActivity(
            turns_posted=12,
            turns_by_thread={"D_1": 5, "I_2": 7},
            discussions_created=1,
            issues_created=2,
            forks_executed=1,
            discussions_decided=1,
            tool_errors=0,
        )
        out = compose_session_summary(
            activity, skill_update_candidates=2, has_pending_buffer=False
        )
        assert "12 turn(s)" in out
        assert "2 thread(s)" in out
        assert "1 Discussion(s)" in out
        assert "2 Issue(s)" in out
        assert "1 fork(s)" in out
        assert "1 Discussion(s) decided" in out
        assert "2 skill update candidate(s)" in out
        assert "caveats" not in out.lower()

    def test_caveats_included(self):
        activity = SessionActivity(
            turns_posted=3,
            turns_by_thread={"D_1": 3},
            tool_errors=2,
        )
        out = compose_session_summary(activity, 0, has_pending_buffer=True)
        assert "2 tool error(s)" in out
        assert "pending buffer non-empty at close" in out

    def test_only_candidates(self):
        activity = SessionActivity()
        out = compose_session_summary(
            activity, skill_update_candidates=3, has_pending_buffer=False
        )
        assert "3 skill update candidate(s)" in out


class TestCheckOverwriteSize:
    def test_force_skips_check(self):
        check_overwrite_size("a" * 10000, "", force=True)

    def test_small_current_is_unconstrained(self):
        check_overwrite_size("tiny", "x", force=False)

    def test_hard_cliff_fires(self):
        # Regression for #48: 10K current overwritten with a 38-char
        # placeholder. Must refuse.
        with pytest.raises(ValueError, match="Refusing overwrite"):
            check_overwrite_size("a" * 10000, "x" * 38, force=False)

    def test_ratio_cliff_fires(self):
        # current > 1000 AND new < 50% of current → refuse
        with pytest.raises(ValueError, match="Refusing overwrite"):
            check_overwrite_size("a" * 2000, "x" * 999, force=False)

    def test_ratio_cliff_allows_at_50_percent(self):
        # new exactly 50% of current → allowed
        check_overwrite_size("a" * 2000, "x" * 1000, force=False)

    def test_modest_shrink_allowed(self):
        # 25% shrink — above the 50% floor
        check_overwrite_size("a" * 2000, "x" * 1500, force=False)

    def test_growth_always_allowed(self):
        check_overwrite_size("a" * 10000, "x" * 15000, force=False)

    def test_force_bypasses_ratio_cliff(self):
        check_overwrite_size("a" * 2000, "x" * 100, force=True)


class TestResolveNewBody:
    """#193 Phase A — `resolve_new_body` is the shared dispatcher
    helper that backs `update_project_toc` and `update_issue_toc`.
    These tests cover the helper in isolation; the handler tests
    cover the end-to-end flow."""

    def test_inline_returned_verbatim(self):
        assert resolve_new_body("inline body", None) == "inline body"

    def test_empty_string_inline_is_valid(self):
        # An empty string is intentional content; only None is "unset."
        assert resolve_new_body("", None) == ""

    def test_file_path_returned_verbatim(self, tmp_path):
        body = "# header\nbody text\n"
        p = tmp_path / "x.md"
        p.write_text(body, encoding="utf-8")

        assert resolve_new_body(None, str(p)) == body

    def test_both_args_rejected(self, tmp_path):
        p = tmp_path / "x.md"
        p.write_text("body", encoding="utf-8")

        with pytest.raises(ValueError, match="exactly one of"):
            resolve_new_body("inline", str(p))

    def test_neither_arg_rejected(self):
        with pytest.raises(ValueError, match="Must pass either"):
            resolve_new_body(None, None)

    def test_relative_path_rejected(self):
        with pytest.raises(ValueError, match="must be absolute"):
            resolve_new_body(None, "relative/x.md")

    def test_missing_file_rejected(self, tmp_path):
        missing = tmp_path / "absent.md"

        with pytest.raises(ValueError, match="not found"):
            resolve_new_body(None, str(missing))


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) OSError-path coverage.
# ---------------------------------------------------------------------------


class TestResolveNewBodyOSError:
    def test_oserror_reading_file_raises_value_error(
        self, tmp_path, monkeypatch,
    ):
        # OSError (non-FileNotFoundError) reading new_body_path →
        # L217-220 raises ValueError.
        target = tmp_path / "body.md"
        target.write_text("content")
        from pathlib import Path as _P
        original = _P.read_text

        def _fail(self, *a, **kw):
            if self == target:
                raise PermissionError("simulated")
            return original(self, *a, **kw)

        monkeypatch.setattr(_P, "read_text", _fail)
        with pytest.raises(ValueError, match="read failed"):
            resolve_new_body(None, str(target))


# (#444) Deprecated-TOC-section validator — warn on #439-deprecated
# section reintroduction in Project Discussion TOC bodies.


class TestFindDeprecatedTocSections:
    def test_clean_body_returns_empty(self):
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Releases\nfoo\n## Repos\nbar"
        assert find_deprecated_toc_sections(body) == []

    def test_milestones_h2_flagged(self):
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Milestones\nsome content"
        assert find_deprecated_toc_sections(body) == ["Milestones"]

    def test_discussions_h2_flagged(self):
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Discussions\nsome content"
        assert find_deprecated_toc_sections(body) == ["Discussions"]

    def test_deprecated_annotation_suppresses(self):
        # Lines that mention DEPRECATED are already-annotated legacy
        # markers, not reintroductions. Don't flag.
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Milestones ← DEPRECATED per #439\ncontent"
        assert find_deprecated_toc_sections(body) == []

    def test_case_insensitive_deprecated_match(self):
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Milestones - deprecated\ncontent"
        assert find_deprecated_toc_sections(body) == []

    def test_h3_not_flagged(self):
        # The deprecated sections are H2 per the TOC convention. H3
        # subsections named Milestones / Discussions are valid.
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Releases\n### Milestones\nsubsection"
        assert find_deprecated_toc_sections(body) == []

    def test_both_deprecated_returned_in_order(self):
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## Milestones\nfoo\n## Discussions\nbar"
        assert find_deprecated_toc_sections(body) == ["Milestones", "Discussions"]

    def test_case_sensitive_name_match(self):
        # "milestones" lowercase isn't matched — convention is the
        # capitalized H2.
        from forge_manager_mcp.utils import find_deprecated_toc_sections
        body = "## milestones\ncontent"
        assert find_deprecated_toc_sections(body) == []


class TestCheckDeprecatedTocSections:
    def test_force_true_skips_check(self):
        from forge_manager_mcp.utils import check_deprecated_toc_sections
        # Even with deprecated sections, force=True passes silently.
        check_deprecated_toc_sections("## Milestones\nfoo", force=True)

    def test_clean_body_passes(self):
        from forge_manager_mcp.utils import check_deprecated_toc_sections
        check_deprecated_toc_sections("## Releases\n## Repos", force=False)

    def test_deprecated_section_raises(self):
        from forge_manager_mcp.utils import check_deprecated_toc_sections
        with pytest.raises(ValueError, match="#439-deprecated"):
            check_deprecated_toc_sections("## Milestones\n", force=False)

    def test_error_message_names_the_section(self):
        from forge_manager_mcp.utils import check_deprecated_toc_sections
        with pytest.raises(ValueError) as excinfo:
            check_deprecated_toc_sections("## Discussions\n", force=False)
        assert "Discussions" in str(excinfo.value)

    def test_error_message_mentions_force_override(self):
        from forge_manager_mcp.utils import check_deprecated_toc_sections
        with pytest.raises(ValueError, match="force=true"):
            check_deprecated_toc_sections("## Milestones\n", force=False)


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
