"""(#428 / 3.12.0 D-Coverage drain) Tests for server/helpers.py
private helpers + with_retry that the handler-level test files don't
exercise directly.
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from forge_manager_mcp.server.helpers import coord_ref, with_retry


class TestCoordRef:
    def _make_ref(self):
        from forge_manager_mcp.adapters.types import ArtifactRef
        return ArtifactRef(
            platform_id="local", native_id="issues/1",
            kind="issue", owner="orig-owner", repo="orig-repo",
            number=1,
        )

    def test_returns_same_ref_when_coords_empty(self):
        # Both coords blank → no override, ref returned as-is.
        ref = self._make_ref()
        out = coord_ref(ref, ("", ""))
        # The ref is unchanged.
        assert out is ref

    def test_override_owner_only(self):
        ref = self._make_ref()
        out = coord_ref(ref, ("new-owner", ""))
        assert out.owner == "new-owner"
        assert out.repo == "orig-repo"

    def test_override_repo_only(self):
        ref = self._make_ref()
        out = coord_ref(ref, ("", "new-repo"))
        assert out.owner == "orig-owner"
        assert out.repo == "new-repo"

    def test_override_both(self):
        ref = self._make_ref()
        out = coord_ref(ref, ("new-owner", "new-repo"))
        assert out.owner == "new-owner"
        assert out.repo == "new-repo"

    def test_no_change_returns_same_instance(self):
        ref = self._make_ref()
        # Coords match the existing values exactly → no copy.
        out = coord_ref(ref, ("orig-owner", "orig-repo"))
        assert out is ref


class TestWithRetry:
    def test_returns_value_on_first_success(self):
        calls = []

        def _ok():
            calls.append(1)
            return "result"

        assert with_retry(_ok) == "result"
        assert len(calls) == 1

    def test_retries_on_recognized_error(self, monkeypatch):
        # Reduce _MAX_RETRIES so the test doesn't take forever.
        from forge_manager_mcp.server import helpers as _h
        monkeypatch.setattr(_h, "_MAX_RETRIES", 3)

        calls = []

        def _flaky():
            calls.append(1)
            if len(calls) < 3:
                # Use the real exception types from the module's
                # late-binding `_s` reference.
                from forge_manager_mcp.github.core import GitHubError
                raise GitHubError("transient")
            return "ok"

        result = with_retry(_flaky)
        assert result == "ok"
        assert len(calls) == 3

    def test_raises_last_exception_on_persistent_failure(
        self, monkeypatch,
    ):
        from forge_manager_mcp.server import helpers as _h
        from forge_manager_mcp.github.core import GitHubError

        monkeypatch.setattr(_h, "_MAX_RETRIES", 2)

        def _always_fails():
            raise GitHubError("persistent")

        with pytest.raises(GitHubError, match="persistent"):
            with_retry(_always_fails)

    def test_does_not_retry_unrecognized_exception(self, monkeypatch):
        from forge_manager_mcp.server import helpers as _h
        monkeypatch.setattr(_h, "_MAX_RETRIES", 5)

        calls = []

        def _runtime_err():
            calls.append(1)
            raise RuntimeError("not retryable")

        # RuntimeError isn't in the (GitHubError, ClassificationError)
        # tuple → propagates immediately.
        with pytest.raises(RuntimeError, match="not retryable"):
            with_retry(_runtime_err)
        assert len(calls) == 1


class TestUpstreamSkillCandidatesInvalidSlug:
    """The fetch_upstream_skill_text helper iterates _upstream_skill_
    candidates() pairs and parse_owner_repo each one; an invalid slug
    triggers a ValueError that the loop swallows + skips."""

    @pytest.mark.asyncio
    async def test_invalid_slug_skipped(self, tmp_path, monkeypatch):
        from forge_manager_mcp.server import helpers as _h

        # Stub the candidates iterator to include one bad slug.
        def _candidates(public, dev):
            return [("not-a-valid-slug", "SKILL.md")]

        monkeypatch.setattr(
            _h, "_upstream_skill_candidates", _candidates,
        )
        # Force the daemon-unavailable path by ensuring no daemon.
        from forge_manager_mcp.daemon import paths as _paths
        monkeypatch.setattr(
            _paths, "state_dir", lambda name=None: tmp_path / "state",
        )
        # fetch_upstream_skill_text iterates candidates; bad slug
        # → parse_owner_repo raises ValueError → loop continues.
        # After consuming the only (bad) candidate, returns None.
        result = await _h.fetch_upstream_skill_text(
            "ghp_test", "owner/public", "owner/dev",
        )
        assert result is None


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
