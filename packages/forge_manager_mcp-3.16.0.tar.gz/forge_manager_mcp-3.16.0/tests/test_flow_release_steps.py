"""Per-step unit tests for the release flow interceptor wrappers (#294 Phase A).

Mock-context pattern per #292: each test passes a synthetic
``Context`` to the step's enter or error handler and asserts the
resulting Context's response / steps_taken / error shape. The
underlying ``_run_*`` callables in handlers/release.py are
monkey-patched per-test so the wrappers' pass-through semantics
test in isolation from the handler's real GitHub / git / pypi work.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from forge_manager_mcp.flows.release import build_release_chain
from forge_manager_mcp.flows.release.dev_tag import make_dev_tag_interceptor
from forge_manager_mcp.flows.release.mirror_sync import (
    make_mirror_sync_interceptor,
)
from forge_manager_mcp.flows.release.mirror_tag import (
    make_mirror_tag_interceptor,
)
from forge_manager_mcp.flows.release.pypi_publish import (
    make_pypi_publish_interceptor,
)
from forge_manager_mcp.flows.release.release_notes import (
    make_release_notes_interceptor,
)
from forge_manager_mcp.flows.release.validate import (
    ReleaseStepFailed,
    make_validate_interceptor,
)
from forge_manager_mcp.interceptors import Context


def _server_ctx_stub(tmp_path: Path) -> SimpleNamespace:
    """A SimpleNamespace masquerading as a ServerContext for the
    enter handlers' field accesses (project_dir, github_token,
    config.repos, etc.). The wrapper tests don't run the underlying
    _run_* — those are stubbed — so the namespace just carries enough
    fields for argument extraction."""
    return SimpleNamespace(
        project_dir=tmp_path,
        github_token="ghp_test",
        config=SimpleNamespace(
            repos=SimpleNamespace(
                public="o/repo",
                private="o/repo-dev",
                docs="o/repo-docs",
            ),
        ),
    )


def _request(server_ctx, **kwargs) -> dict:
    base = {
        "server_ctx": server_ctx,
        "version": "9.9.9",
        "notes": "test notes",
        "skip_bazel": False,
        "pypi_only": False,
        "dry_run": True,
    }
    base.update(kwargs)
    return base


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

class TestValidateStep:
    @pytest.mark.asyncio
    async def test_enter_records_response_and_repo_role(
        self, tmp_path: Path, monkeypatch
    ):
        run_validate = AsyncMock(
            return_value=(
                {"step": "validate", "status": "ok",
                 "data": {"checks": []}},
                [],
                "skill",
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_validate",
            run_validate,
        )

        ic = make_validate_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)

        assert result.error is None
        assert "validate" in result.response
        assert result.response["validate"]["status"] == "ok"
        assert result.response["validate"]["repo_role"] == "skill"
        # repo_role threaded onto request for downstream steps.
        assert result.request["repo_role"] == "skill"
        # steps_taken records the forward entry.
        assert result.steps_taken[-1]["step"] == "validate"

    @pytest.mark.asyncio
    async def test_enter_failure_sets_chain_error(
        self, tmp_path: Path, monkeypatch
    ):
        run_validate = AsyncMock(
            return_value=(
                {"step": "validate", "status": "failed", "data": {}},
                [{"name": "milestone_closed", "ok": False, "severity": "fail"}],
                "monorepo",
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_validate",
            run_validate,
        )

        ic = make_validate_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)

        assert isinstance(result.error, ReleaseStepFailed)
        assert "validate failed" in str(result.error)
        # Response still records the validate state for the chain
        # unwind / handler to surface.
        assert result.response["validate"]["status"] == "failed"

    @pytest.mark.asyncio
    async def test_error_is_passthrough(self, tmp_path: Path):
        ic = make_validate_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            error=ReleaseStepFailed("upstream"),
        )
        result = await ic.error(ctx)
        # validate is read-only — no compensation, error passes through.
        assert result.error is ctx.error


# ---------------------------------------------------------------------------
# dev_tag
# ---------------------------------------------------------------------------

class TestDevTagStep:
    @pytest.mark.asyncio
    async def test_enter_dry_run(self, tmp_path: Path, monkeypatch):
        run_dev_tag = MagicMock(
            return_value={
                "step": "dev_tag",
                "status": "dry_run_preview",
                "data": {"tag": "v9.9.9", "sha": "abc"},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_dev_tag",
            run_dev_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)
        assert result.error is None
        assert result.response["dev_tag"]["status"] == "dry_run_preview"

    @pytest.mark.asyncio
    async def test_error_no_compensation_when_step_didnt_succeed(
        self, tmp_path: Path,
    ):
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"dev_tag": {"status": "dry_run_preview"}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # No compensation appended for non-ok dev_tag state.
        forward_steps = [s for s in result.steps_taken if not s.get("compensated")]
        compensation = [s for s in result.steps_taken if s.get("compensated")]
        assert compensation == []

    @pytest.mark.asyncio
    async def test_error_calls_delete_tag_compensation(
        self, tmp_path: Path, monkeypatch,
    ):
        # delete_tag exists in releases_mod (#294 Phase A primitive).
        # Compensation invokes it; the test asserts the call rather
        # than the failed_compensations fallback the placeholder
        # used to surface pre-primitive.
        delete_tag = MagicMock()
        monkeypatch.setattr(
            "forge_manager_mcp.github.releases.delete_tag", delete_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={
                "dev_tag": {
                    "status": "ok",
                    "data": {"tag": "v9.9.9"},
                }
            },
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        delete_tag.assert_called_once()
        args = delete_tag.call_args.args
        # Wrapper passes (project_dir, "origin", tag).
        assert args[1] == "origin"
        assert args[2] == "v9.9.9"
        # No failed_compensations — compensation succeeded cleanly.
        assert "failed_compensations" not in result.response
        # Compensated marker landed in steps_taken.
        assert any(
            s.get("compensated") and s["step"] == "dev_tag"
            for s in result.steps_taken
        )

    @pytest.mark.asyncio
    async def test_error_records_failed_compensation_on_delete_failure(
        self, tmp_path: Path, monkeypatch,
    ):
        # delete_tag exists but raises (e.g., not a git repo). The
        # wrapper surfaces a failed_compensations entry so the
        # operator sees the gap.
        delete_tag = MagicMock(side_effect=RuntimeError("not a git repo"))
        monkeypatch.setattr(
            "forge_manager_mcp.github.releases.delete_tag", delete_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={
                "dev_tag": {
                    "status": "ok",
                    "data": {"tag": "v9.9.9"},
                }
            },
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert "failed_compensations" in result.response
        failed = result.response["failed_compensations"]
        assert any(f["step"] == "dev_tag" for f in failed)

    @pytest.mark.asyncio
    async def test_error_no_tag_in_recorded_data_returns_ctx(
        self, tmp_path: Path,
    ):
        # (#428) L67-71 — status=ok but recorded data has no tag key →
        # nothing to compensate; return ctx as-is.
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"dev_tag": {"status": "ok", "data": {}}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # No compensation appended.
        compensation = [s for s in result.steps_taken if s.get("compensated")]
        assert compensation == []


# ---------------------------------------------------------------------------
# mirror_sync / mirror_tag / release_notes / pypi_publish — minimal coverage
# ---------------------------------------------------------------------------

class TestMirrorSyncStep:
    @pytest.mark.asyncio
    async def test_enter_threads_mirror_clone(
        self, tmp_path: Path, monkeypatch,
    ):
        clone_path = tmp_path / "mirror"
        run_mirror_sync = MagicMock(
            return_value=(
                {"step": "mirror_sync", "status": "ok", "data": {}},
                clone_path,
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_sync",
            run_mirror_sync,
        )
        ic = make_mirror_sync_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill"
            )
        )
        result = await ic.enter(ctx)
        assert result.request["mirror_clone"] == clone_path
        assert result.response["mirror_sync"]["status"] == "ok"


class TestMirrorTagStep:
    @pytest.mark.asyncio
    async def test_enter_consumes_mirror_clone_from_request(
        self, tmp_path: Path, monkeypatch,
    ):
        run_mirror_tag = MagicMock(
            return_value={
                "step": "mirror_tag",
                "status": "ok",
                "data": {"tag": "v9.9.9"},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_tag",
            run_mirror_tag,
        )
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path),
                repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["mirror_tag"]["status"] == "ok"
        # _run_mirror_tag received the mirror_clone we threaded in.
        # Real signature: (mirror_clone, version, notes, dry_run) — so
        # mirror_clone is positional arg 0.
        run_mirror_tag.assert_called_once()
        kwargs_or_args = run_mirror_tag.call_args
        assert kwargs_or_args.args[0] == tmp_path / "mirror"

    @pytest.mark.asyncio
    async def test_enter_failed_status_sets_error(
        self, tmp_path: Path, monkeypatch,
    ):
        # (#428 D-Coverage drain) status="failed" attaches
        # ReleaseStepFailed onto the Context.
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_tag",
            MagicMock(return_value={
                "step": "mirror_tag",
                "status": "failed",
                "data": {"error": "tag failed"},
            }),
        )
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            )
        )
        result = await ic.enter(ctx)
        assert isinstance(result.error, ReleaseStepFailed)
        assert "mirror_tag failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_error_compensation_no_op_when_step_did_not_succeed(
        self, tmp_path: Path,
    ):
        # If the step never reported status==ok, error compensation is
        # a no-op (returns ctx unchanged).
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            ),
            response={"mirror_tag": {"status": "failed"}},
        )
        result = await ic.error(ctx)
        assert result is ctx

    @pytest.mark.asyncio
    async def test_error_compensation_no_tag_or_clone_returns_ctx(
        self, tmp_path: Path,
    ):
        # status==ok but data.tag is None → no-op compensation.
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            ),
            response={"mirror_tag": {"status": "ok", "data": {}}},
        )
        result = await ic.error(ctx)
        assert result is ctx

    @pytest.mark.asyncio
    async def test_error_compensation_calls_delete_tag(
        self, tmp_path: Path, monkeypatch,
    ):
        # status=ok + tag + clone → delete_tag called; compensation
        # step appended.
        from forge_manager_mcp.github import releases as releases_mod
        called = []
        monkeypatch.setattr(
            releases_mod, "delete_tag",
            lambda clone, remote, tag: called.append((clone, remote, tag)),
        )
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            ),
            response={"mirror_tag": {
                "status": "ok",
                "data": {"tag": "v9.9.9"},
            }},
        )
        result = await ic.error(ctx)
        assert called == [(tmp_path / "mirror", "origin", "v9.9.9")]
        # Steps_taken records the compensation.
        assert result.steps_taken[-1]["step"] == "mirror_tag"
        assert result.steps_taken[-1]["compensated"] is True

    @pytest.mark.asyncio
    async def test_error_compensation_delete_failure_records_failed(
        self, tmp_path: Path, monkeypatch,
    ):
        # delete_tag raises → records failed_compensations entry +
        # still appends compensation step to steps_taken.
        from forge_manager_mcp.github import releases as releases_mod

        def _boom(clone, remote, tag):
            raise RuntimeError("simulated delete failure")

        monkeypatch.setattr(releases_mod, "delete_tag", _boom)
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            ),
            response={"mirror_tag": {
                "status": "ok",
                "data": {"tag": "v9.9.9"},
            }},
        )
        result = await ic.error(ctx)
        failed = result.response["failed_compensations"]
        assert len(failed) == 1
        assert "simulated delete failure" in failed[0]["error"]
        assert failed[0]["tag"] == "v9.9.9"


class TestReleaseNotesStep:
    @pytest.mark.asyncio
    async def test_enter_pass_through(
        self, tmp_path: Path, monkeypatch,
    ):
        # (#359, 3.7.0 D2) `_run_release_notes` is async — patch with an
        # AsyncMock so the chain wrapper's `await` resolves correctly.
        from unittest.mock import AsyncMock
        run_release_notes = AsyncMock(
            return_value={
                "step": "release_notes",
                "status": "ok",
                "data": {},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_release_notes",
            run_release_notes,
        )
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["release_notes"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_enter_failed_status_sets_error(
        self, tmp_path: Path, monkeypatch,
    ):
        """When _run_release_notes returns status=failed, the wrapper
        attaches a ReleaseStepFailed error onto the Context."""
        run_release_notes = AsyncMock(
            return_value={
                "step": "release_notes",
                "status": "failed",
                "data": {"reason": "release-create returned 422"},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_release_notes",
            run_release_notes,
        )
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path), repo_role="skill"),
        )
        result = await ic.enter(ctx)
        assert isinstance(result.error, ReleaseStepFailed)
        assert "release_notes failed" in str(result.error)

    @pytest.mark.asyncio
    async def test_error_compensation_no_op_when_step_did_not_succeed(
        self, tmp_path: Path,
    ):
        """If `release_notes` step never reported `status==ok`, the
        compensation handler returns ctx unchanged — there's nothing to
        delete."""
        ic = make_release_notes_interceptor()
        request = _request(_server_ctx_stub(tmp_path), repo_role="skill")
        ctx = Context(
            request=request,
            response={"release_notes": {"status": "failed"}},
        )
        result = await ic.error(ctx)
        # No compensation steps recorded (returned ctx is unchanged).
        assert result is ctx

    @pytest.mark.asyncio
    async def test_error_compensation_no_public_face_records_failure(
        self, tmp_path: Path,
    ):
        """When ctx.public_face is None, compensation can't run; emits
        a failed_compensations entry pointing operator to manual cleanup."""
        ic = make_release_notes_interceptor()
        # Default _server_ctx_stub has no public_face attribute.
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path), repo_role="skill"),
            response={"release_notes": {"status": "ok"}},
        )
        result = await ic.error(ctx)
        failed = result.response["failed_compensations"]
        assert len(failed) == 1
        assert failed[0]["step"] == "release_notes"
        assert "public_face is None" in failed[0]["reason"]

    @pytest.mark.asyncio
    async def test_error_compensation_deletes_release_on_both_repos(
        self, tmp_path: Path,
    ):
        """Successful path: walks public + private repos and calls
        delete_release on each; records steps_taken entry with both
        targets."""
        public_face = SimpleNamespace(
            delete_release=AsyncMock(return_value=None),
        )
        server_ctx = _server_ctx_stub(tmp_path)
        server_ctx.public_face = public_face
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(server_ctx, repo_role="skill"),
            response={"release_notes": {"status": "ok"}},
        )
        result = await ic.error(ctx)
        assert public_face.delete_release.await_count == 2
        # Both targets identified.
        targets_called = [
            call.kwargs for call in public_face.delete_release.await_args_list
        ]
        assert {(c["owner"], c["repo"]) for c in targets_called} == {
            ("o", "repo"), ("o", "repo-dev"),
        }
        # Tag derived from version.
        assert all(c["tag"] == "v9.9.9" for c in targets_called)
        # Steps_taken records the compensation.
        assert result.steps_taken[-1]["step"] == "release_notes"
        assert result.steps_taken[-1]["compensated"] is True

    @pytest.mark.asyncio
    async def test_error_compensation_records_per_target_errors(
        self, tmp_path: Path,
    ):
        """Per-target delete failures land in failed_compensations
        and the compensation step records the errors detail."""

        class _DeleteFailing:
            def __init__(self):
                self.calls = []

            async def delete_release(self, *, owner, repo, tag):
                self.calls.append((owner, repo, tag))
                raise RuntimeError(f"403 on {owner}/{repo}")

        public_face = _DeleteFailing()
        server_ctx = _server_ctx_stub(tmp_path)
        server_ctx.public_face = public_face
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(server_ctx, repo_role="skill"),
            response={"release_notes": {"status": "ok"}},
        )
        result = await ic.error(ctx)
        assert len(public_face.calls) == 2
        failed = result.response["failed_compensations"]
        assert len(failed) == 1
        assert failed[0]["step"] == "release_notes"
        assert len(failed[0]["errors"]) == 2
        # Compensation step still recorded with per-target error detail.
        last_step = result.steps_taken[-1]
        assert last_step["step"] == "release_notes"
        assert "errors" in last_step["detail"]

    @pytest.mark.asyncio
    async def test_error_compensation_skips_unsplittable_repo_full_names(
        self, tmp_path: Path,
    ):
        """A config with public/private fields that don't carry a slash
        (or are empty) skips the corresponding target — no crash."""
        public_face = SimpleNamespace(
            delete_release=AsyncMock(return_value=None),
        )
        server_ctx = _server_ctx_stub(tmp_path)
        server_ctx.public_face = public_face
        # Replace public with empty, private without slash.
        server_ctx.config.repos = SimpleNamespace(
            public="", private="malformed",
        )
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(server_ctx, repo_role="skill"),
            response={"release_notes": {"status": "ok"}},
        )
        result = await ic.error(ctx)
        # No deletions attempted; no failed_compensations either.
        assert public_face.delete_release.await_count == 0
        assert "failed_compensations" not in result.response
        # Compensation step still recorded with empty targets.
        assert result.steps_taken[-1]["detail"]["targets"] == []


class TestPypiPublishStep:
    @pytest.mark.asyncio
    async def test_enter_pass_through(
        self, tmp_path: Path, monkeypatch,
    ):
        run_pypi = MagicMock(
            return_value={
                "step": "pypi_publish",
                "status": "ok",
                "data": {},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_pypi_publish",
            run_pypi,
        )
        ic = make_pypi_publish_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path),
                repo_role="mcp",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["pypi_publish"]["status"] == "ok"


# ---------------------------------------------------------------------------
# Chain composer
# ---------------------------------------------------------------------------

class TestBuildReleaseChain:
    def test_full_chain_ordering(self):
        chain = build_release_chain()
        names = [ic.name for ic in chain]
        assert names == [
            "release.validate",
            "release.dev_tag",
            "release.mirror_sync",
            "release.mirror_tag",
            "release.release_notes",
        ]

    def test_pypi_only_chain_skips_github_steps(self):
        chain = build_release_chain(pypi_only=True)
        names = [ic.name for ic in chain]
        assert names == ["release.validate", "release.pypi_publish"]

    def test_stop_after_truncates_chain(self):
        chain = build_release_chain(stop_after="dev_tag")
        names = [ic.name for ic in chain]
        assert names == ["release.validate", "release.dev_tag"]

    def test_pypi_only_overrides_stop_after(self):
        chain = build_release_chain(pypi_only=True, stop_after="dev_tag")
        names = [ic.name for ic in chain]
        # pypi_only path is always validate → pypi_publish, regardless
        # of stop_after.
        assert names == ["release.validate", "release.pypi_publish"]


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) mirror_sync + pypi_publish compensation.
# ---------------------------------------------------------------------------


class TestMirrorSyncFailedStatus:
    @pytest.mark.asyncio
    async def test_failed_step_sets_error(self, tmp_path: Path, monkeypatch):
        # _run_mirror_sync returns status="failed" → enter wraps as
        # ReleaseStepFailed. mirror_sync L56-58.
        run = MagicMock(return_value=(
            {"step": "mirror_sync", "status": "failed", "data": {}},
            None,
        ))
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_sync",
            run,
        )
        ic = make_mirror_sync_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path), repo_role="skill"),
        )
        result = await ic.enter(ctx)
        assert isinstance(result.error, ReleaseStepFailed)


class TestMirrorSyncNoCompensationOnNonOk:
    @pytest.mark.asyncio
    async def test_non_ok_state_skips_compensation(self, tmp_path: Path):
        # mirror_sync status != "ok" → compensation early-return.
        # mirror_sync L68-70.
        ic = make_mirror_sync_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"mirror_sync": {"status": "dry_run_preview"}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert "failed_compensations" not in result.response


class TestPypiPublishFailedStatus:
    @pytest.mark.asyncio
    async def test_failed_step_sets_error(self, tmp_path: Path, monkeypatch):
        # _run_pypi_publish returns status="failed" → enter wraps
        # as ReleaseStepFailed. pypi_publish L47-50.
        run = MagicMock(return_value={
            "step": "pypi_publish", "status": "failed",
        })
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_pypi_publish",
            run,
        )
        ic = make_pypi_publish_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path), repo_role="skill"),
        )
        result = await ic.enter(ctx)
        assert isinstance(result.error, ReleaseStepFailed)


class TestPypiPublishNoCompensationOnNonOk:
    @pytest.mark.asyncio
    async def test_non_ok_state_skips_compensation(self, tmp_path: Path):
        # pypi_publish status != "ok" → compensation early-return.
        # pypi_publish L60-62.
        ic = make_pypi_publish_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"pypi_publish": {"status": "skipped"}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert "failed_compensations" not in result.response


class TestMirrorSyncCompensationOnOk:
    @pytest.mark.asyncio
    async def test_ok_state_records_failed_compensation(self, tmp_path: Path):
        # mirror_sync recorded status="ok" → compensation records a
        # failed_compensations entry because the prior ref isn't
        # captured. L70-99.
        ic = make_mirror_sync_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"mirror_sync": {"status": "ok", "data": {}}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert any(
            f["step"] == "mirror_sync"
            for f in result.response.get("failed_compensations", ())
        )


class TestPypiPublishCompensationOnOk:
    @pytest.mark.asyncio
    async def test_ok_state_records_failed_compensation(self, tmp_path: Path):
        # pypi_publish recorded status="ok" → compensation records a
        # failed_compensations entry. L60-99.
        ic = make_pypi_publish_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"pypi_publish": {"status": "ok"}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert any(
            f["step"] == "pypi_publish"
            for f in result.response.get("failed_compensations", ())
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
