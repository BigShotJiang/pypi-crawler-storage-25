"""Unit tests for forge_manager_mcp.gate_registry (#287).

Covers:

* Pydantic model construction + dot-namespace validator.
* Constrained-shape YAML parser — happy path, scalars, inline lists,
  block scalars, nested sequences (steps).
* Loader behavior — file-not-found, schema violation, duplicate name.
* Registry accessors — get_gate / list_gates(type=) / containment.
* The same shape coverage on processes.yaml.
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
from pydantic import ValidationError

from forge_manager_mcp.gate_registry import (
    Gate,
    GateRegistry,
    GateRegistryError,
    Process,
    ProcessRegistry,
    ProcessStep,
    load_gates,
    load_processes,
    parse_yaml_text,
)


# ---------------------------------------------------------------------------
# Pydantic model tests
# ---------------------------------------------------------------------------

class TestGateModel:
    def test_minimal_gate_constructs(self) -> None:
        gate = Gate(
            name="commit.example",
            type="pre-commit",
            location="commit-rules.md#commit.example",
            summary="example",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc="commit-rules.md#commit.example",
            introduced_in="1.0.0",
        )
        assert gate.name == "commit.example"
        assert gate.related == ()
        assert gate.notes is None

    def test_dot_namespace_required(self) -> None:
        with pytest.raises(Exception):
            Gate(
                name="missingdot",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
            )

    def test_extra_field_forbidden(self) -> None:
        with pytest.raises(Exception):
            Gate(
                name="commit.x",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
                bogus_extra="nope",
            )

    def test_pre_publish_gate_requires_runbook_url(self) -> None:
        """3.4.0 #3: pre-publish gates are operator-driven and must
        reference a runbook in the docs repo. The model rejects a
        pre-publish gate without runbook_url."""
        with pytest.raises(Exception):
            Gate(
                name="publish.example",
                type="pre-publish",
                location="release.md#publish.example",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="release.md#publish.example",
                introduced_in="3.4.0",
            )

    def test_pre_publish_gate_with_runbook_url_constructs(self) -> None:
        gate = Gate(
            name="publish.example",
            type="pre-publish",
            location="release.md#publish.example",
            summary="x",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc="release.md#publish.example",
            introduced_in="3.4.0",
            runbook_url="runbooks/publish-example.md",
        )
        assert gate.runbook_url == "runbooks/publish-example.md"

    def test_non_pre_publish_gate_rejects_runbook_url(self) -> None:
        """runbook_url is only meaningful for pre-publish gates. A
        pre-tag or pre-commit gate with runbook_url is a misuse."""
        with pytest.raises(Exception):
            Gate(
                name="commit.example",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
                runbook_url="runbooks/x.md",
            )


class TestProcessModel:
    def test_minimal_process(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="bootstrap.md#session.start",
            summary="bootstrap",
            rationale_doc="bootstrap.md#session.start",
            introduced_in="1.0.0",
        )
        assert proc.steps == ()
        assert proc.related_processes == ()

    def test_steps_construct(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="bootstrap.md#session.start",
            summary="bootstrap",
            rationale_doc="bootstrap.md#session.start",
            introduced_in="1.0.0",
            steps=[
                ProcessStep(id="s1", location="bootstrap.md#s1", gates=[]),
                ProcessStep(id="s2", location="bootstrap.md#s2", gates=["g.x"]),
            ],
        )
        assert len(proc.steps) == 2
        assert proc.steps[1].gates == ("g.x",)


# ---------------------------------------------------------------------------
# Registry accessors
# ---------------------------------------------------------------------------

def _make_gate(name: str, gtype: str = "pre-commit") -> Gate:
    return Gate(
        name=name,
        type=gtype,
        location=f"x.md#{name}",
        summary=name,
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"x.md#{name}",
        introduced_in="1.0.0",
    )


class TestGateRegistry:
    def test_get_and_list(self) -> None:
        reg = GateRegistry([
            _make_gate("commit.a"),
            _make_gate("release.b", gtype="pre-tag"),
        ])
        assert reg.get_gate("commit.a") is not None
        assert reg.get_gate("missing") is None
        assert "commit.a" in reg
        assert "missing" not in reg
        assert len(reg) == 2

    def test_filter_by_type(self) -> None:
        reg = GateRegistry([
            _make_gate("commit.a"),
            _make_gate("commit.b"),
            _make_gate("release.c", gtype="pre-tag"),
        ])
        commit_gates = reg.list_gates(type="pre-commit")
        assert {g.name for g in commit_gates} == {"commit.a", "commit.b"}
        release_gates = reg.list_gates(type="pre-tag")
        assert {g.name for g in release_gates} == {"release.c"}

    def test_duplicate_name_raises(self) -> None:
        with pytest.raises(GateRegistryError):
            GateRegistry([_make_gate("commit.a"), _make_gate("commit.a")])


class TestProcessRegistry:
    def test_get_and_list(self) -> None:
        reg = ProcessRegistry([
            Process(
                name="session.start",
                type="lifecycle",
                location="b.md#x",
                summary="x",
                rationale_doc="b.md#x",
                introduced_in="1.0.0",
            ),
            Process(
                name="release.process",
                type="release",
                location="r.md#x",
                summary="x",
                rationale_doc="r.md#x",
                introduced_in="1.0.0",
            ),
        ])
        assert reg.get_process("session.start") is not None
        assert reg.get_process("missing") is None
        lifecycles = reg.list_processes(type="lifecycle")
        assert len(lifecycles) == 1

    def test_duplicate_name_raises(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="b.md#x",
            summary="x",
            rationale_doc="b.md#x",
            introduced_in="1.0.0",
        )
        with pytest.raises(GateRegistryError):
            ProcessRegistry([proc, proc])


# ---------------------------------------------------------------------------
# Constrained-YAML parser
# ---------------------------------------------------------------------------

class TestParseYAML:
    def test_minimal_document(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert len(result) == 1
        assert result[0]["name"] == "commit.x"
        assert result[0]["introduced_in"] == "1.0.0"

    def test_inline_list(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: [commit.a, commit.b, commit.c]
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["related"] == ["commit.a", "commit.b", "commit.c"]

    def test_empty_inline_list(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: []
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["related"] == []

    def test_block_scalar(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                notes: |
                  Line one.
                  Line two.
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["notes"] == "Line one.\nLine two."

    def test_nested_sequence_for_steps(self) -> None:
        doc = textwrap.dedent("""\
            processes:
              - name: session.start
                type: lifecycle
                location: b.md#x
                summary: x
                rationale_doc: b.md#x
                introduced_in: "1.0.0"
                steps:
                  - id: s1
                    location: b.md#s1
                    gates: []
                  - id: s2
                    location: b.md#s2
                    gates: [g.x]
        """)
        result = parse_yaml_text(doc, root_key="processes")
        assert len(result[0]["steps"]) == 2
        assert result[0]["steps"][1]["id"] == "s2"
        assert result[0]["steps"][1]["gates"] == ["g.x"]

    def test_comments_skipped(self) -> None:
        doc = textwrap.dedent("""\
            # Top comment
            gates:
              # Item-level comment
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert len(result) == 1

    def test_quoted_strings(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: "commit.x"
                type: 'pre-commit'
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0a1"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["name"] == "commit.x"
        assert result[0]["type"] == "pre-commit"
        assert result[0]["introduced_in"] == "1.0.0a1"

    def test_tabs_rejected(self) -> None:
        doc = "gates:\n\t- name: commit.x\n"
        with pytest.raises(GateRegistryError, match="tabs"):
            parse_yaml_text(doc, root_key="gates")

    def test_missing_root_key(self) -> None:
        with pytest.raises(GateRegistryError, match="expected root key"):
            parse_yaml_text("processes:\n  - name: x\n", root_key="gates")

    def test_root_key_must_be_at_column_zero(self) -> None:
        with pytest.raises(GateRegistryError):
            parse_yaml_text("  gates:\n    - name: x\n", root_key="gates")

    def test_inline_value_on_root_rejected(self) -> None:
        with pytest.raises(GateRegistryError, match="inline value"):
            parse_yaml_text("gates: [a, b]\n", root_key="gates")

    def test_dash_line_must_have_inline_value(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name:
                type: pre-commit
        """)
        with pytest.raises(GateRegistryError, match="inline value"):
            parse_yaml_text(doc, root_key="gates")

    def test_empty_document(self) -> None:
        with pytest.raises(GateRegistryError, match="empty"):
            parse_yaml_text("# only comments\n\n", root_key="gates")

    def test_trailing_garbage_rejected(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
            unexpected_top_level: value
        """)
        with pytest.raises(GateRegistryError, match="unexpected content"):
            parse_yaml_text(doc, root_key="gates")


# ---------------------------------------------------------------------------
# Loader (file-system entry points)
# ---------------------------------------------------------------------------

class TestLoaders:
    def test_load_gates_happy(self, tmp_path: Path) -> None:
        path = tmp_path / "gates.yaml"
        path.write_text(textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: [commit.a]
        """))
        registry = load_gates(path)
        gate = registry.get_gate("commit.x")
        assert gate is not None
        assert gate.related == ("commit.a",)

    def test_load_gates_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(GateRegistryError, match="not found"):
            load_gates(tmp_path / "absent.yaml")

    def test_load_gates_schema_violation(self, tmp_path: Path) -> None:
        # `default_state` must be open|closed; "maybe" violates the Literal.
        path = tmp_path / "gates.yaml"
        path.write_text(textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: maybe
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """))
        with pytest.raises(GateRegistryError, match="schema validation"):
            load_gates(path)

    def test_load_processes_with_steps(self, tmp_path: Path) -> None:
        path = tmp_path / "processes.yaml"
        path.write_text(textwrap.dedent("""\
            processes:
              - name: session.start
                type: lifecycle
                location: b.md#session.start
                summary: bootstrap
                rationale_doc: b.md#session.start
                introduced_in: "1.0.0"
                steps:
                  - id: step1
                    location: b.md#step1
                    gates: []
        """))
        registry = load_processes(path)
        proc = registry.get_process("session.start")
        assert proc is not None
        assert len(proc.steps) == 1
        assert proc.steps[0].id == "step1"

    def test_load_processes_step_validation_error(self, tmp_path: Path) -> None:
        # (#428 D-Coverage drain) Step missing required `id` field →
        # ValidationError → wrapped as GateRegistryError per
        # gate_registry.py:366-367.
        path = tmp_path / "processes.yaml"
        path.write_text(textwrap.dedent("""\
            processes:
              - name: session.start
                type: lifecycle
                location: b.md#session.start
                summary: bootstrap
                rationale_doc: b.md#session.start
                introduced_in: "1.0.0"
                steps:
                  - location: b.md#stepfoo
                    gates: []
        """))
        with pytest.raises(GateRegistryError, match="step failed validation"):
            load_processes(path)

    def test_load_processes_top_level_validation_error(
        self, tmp_path: Path,
    ) -> None:
        # Process missing required `summary` field → ValidationError →
        # wrapped (lines 372-373).
        path = tmp_path / "processes.yaml"
        path.write_text(textwrap.dedent("""\
            processes:
              - name: x.y
                type: lifecycle
                location: b.md#xy
                rationale_doc: b.md#xy
                introduced_in: "1.0.0"
        """))
        with pytest.raises(GateRegistryError, match="schema validation"):
            load_processes(path)

    def test_load_gates_yaml_error_wrapped_with_path_prefix(
        self, tmp_path: Path,
    ) -> None:
        # (#428 D-Coverage drain) parse_yaml_text raises GateRegistryError
        # → _parse_yaml_file wraps with the path prefix (lines 438-439).
        path = tmp_path / "gates.yaml"
        # Tab in the file → parser rejects.
        path.write_text("gates:\n\t- name: x\n")
        with pytest.raises(GateRegistryError, match=str(path)):
            load_gates(path)


# (#428 / 3.12.0 D-Coverage drain) Edge tests for the small registry
# accessors + parser tail branches the original suite missed.


class TestRegistryAccessors:
    def _make_gate(self, name: str, gate_type: str = "pre-commit"):
        return Gate(
            name=name, type=gate_type,
            location=f"x.md#{name}",
            summary="s",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc=f"x.md#{name}",
            introduced_in="1.0.0",
        )

    def _make_process(self, name: str = "session.start"):
        return Process(
            name=name, type="lifecycle",
            location=f"b.md#{name}",
            summary="s",
            rationale_doc=f"b.md#{name}",
            introduced_in="1.0.0",
        )

    def test_gate_registry_filter_by_type(self) -> None:
        # Hits gate_registry.py:296 — filtered list comprehension.
        registry = GateRegistry([
            self._make_gate("a.x", "pre-commit"),
            self._make_gate("a.y", "pre-tag"),
        ])
        only_pre_commit = registry.list_gates(type="pre-commit")
        assert len(only_pre_commit) == 1
        assert only_pre_commit[0].name == "a.x"

    def test_process_registry_filter_by_type(self) -> None:
        # Hits gate_registry.py:325 — filtered list comprehension.
        registry = ProcessRegistry([
            self._make_process("session.start"),
        ])
        # No matching type → empty result.
        assert registry.list_processes(type="release") == []
        # Matching type → returns the process.
        assert len(registry.list_processes(type="lifecycle")) == 1

    def test_process_registry_len_and_contains(self) -> None:
        # Hits gate_registry.py:329 (__len__) + 332 (__contains__).
        registry = ProcessRegistry([self._make_process()])
        assert len(registry) == 1
        assert "session.start" in registry
        assert "no.such.process" not in registry
        # Non-string key → False.
        assert (123 not in registry)


class TestProcessNameValidator:
    def test_non_dot_namespaced_name_raises(self) -> None:
        # Hits gate_registry.py:255-256 — the model_validator raises
        # ValueError when the name lacks a dot.
        with pytest.raises(ValidationError, match="dot-namespaced"):
            Process(
                name="undotted",  # missing the dot-namespace
                type="lifecycle",
                location="b.md#x",
                summary="s",
                rationale_doc="b.md#x",
                introduced_in="1.0.0",
            )


class TestParserEdges:
    def test_inline_value_after_dash_must_have_colon(self) -> None:
        # parse_scalar_or_inline_seq raises when dash-line has no colon.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="key: value"):
            parse_yaml_text(
                "gates:\n  - just_a_string\n",
                root_key="gates",
            )

    def test_block_scalar_pipe_on_dash_line_rejected(self) -> None:
        # `- name: |` (block scalar pipe directly after the dash-line's
        # first key) is rejected. Block scalars must appear on
        # continuation lines, not on the dash-line itself.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="block scalar"):
            parse_yaml_text(
                "gates:\n  - name: |\n      something\n",
                root_key="gates",
            )

    def test_inline_seq_with_quoted_strings(self) -> None:
        # Inline-list with quoted strings exercises the in_str / str_char
        # state machine in parse_scalar_or_inline_seq.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        result = parse_yaml_text(
            'gates:\n  - name: x\n    related: ["a, b", \'c, d\']\n',
            root_key="gates",
        )
        assert result == [{"name": "x", "related": ["a, b", "c, d"]}]


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Parser edge-branch coverage.
# ---------------------------------------------------------------------------


class TestParserAdditionalEdges:
    def test_tab_on_root_line_rejected(self):
        # Tab character anywhere on the root key line → L403 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="tabs"):
            parse_yaml_text("gates\t:\n", root_key="gates")

    def test_trailing_non_blank_after_sequence_rejected(self):
        # Trailing content after the root sequence that isn't blank/
        # comment → L425-426 raise. (L428 is the increment in the
        # accepted case — exercise via a comment-only trailer.)
        from forge_manager_mcp.gate_registry import parse_yaml_text
        # Acceptable trailing comment exercises L428 (the pos += 1).
        result = parse_yaml_text(
            "gates:\n  - name: x\n# trailing comment\n",
            root_key="gates",
        )
        assert result == [{"name": "x"}]

    def test_tab_on_continuation_line_rejected(self):
        # Tab character on a continuation line → L480 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="tabs"):
            parse_yaml_text(
                "gates:\n  - name: x\n    extra\t: y\n",
                root_key="gates",
            )

    def test_deeper_indent_on_continuation_rejected(self):
        # Continuation line with deeper indent than expected →
        # field_text starts with " " → L491 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="deeper indentation"):
            parse_yaml_text(
                "gates:\n  - name: x\n      surprise: 1\n",
                root_key="gates",
            )

    def test_continuation_without_colon_rejected(self):
        # Continuation line missing `:` → L498-500 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="key: value"):
            parse_yaml_text(
                "gates:\n  - name: x\n    nokeyvalue\n",
                root_key="gates",
            )

    def test_empty_key_on_continuation_rejected(self):
        # Continuation line with empty key (just `: value`) →
        # L503-505 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="empty key"):
            parse_yaml_text(
                "gates:\n  - name: x\n    : oops\n",
                root_key="gates",
            )

    def test_empty_value_skips_blank_comment_lines_during_peek(self):
        # `key:` empty value with blank/comment lines between the
        # current pos and the next non-blank → peek-loop's `peek += 1`
        # at L519 advances through them.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        body = (
            "gates:\n"
            "  - name: x\n"
            "    extras:\n"
            "    # inline comment\n"
            "  - name: y\n"
        )
        result = parse_yaml_text(body, root_key="gates")
        assert result == [
            {"name": "x", "extras": []},
            {"name": "y"},
        ]

    def test_empty_value_at_eof_yields_empty_list(self):
        # Continuation `key:` with empty value AND no further lines
        # → peek hits eof → item[key] = []. L519-522.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        result = parse_yaml_text(
            "gates:\n  - name: x\n    extras:\n",
            root_key="gates",
        )
        assert result == [{"name": "x", "extras": []}]

    def test_empty_value_followed_by_next_seq_item_yields_empty_list(self):
        # `key:` empty value with next non-blank line being the next
        # sequence item (dash at outer indent, not the nested-dash
        # prefix) → item[key] = []. L531-533.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        result = parse_yaml_text(
            "gates:\n  - name: x\n    extras:\n  - name: y\n",
            root_key="gates",
        )
        assert result == [
            {"name": "x", "extras": []},
            {"name": "y"},
        ]

    def test_dash_line_with_empty_key_after_partition_rejected(self):
        # _consume_field_into: dash-line text "` : value`" → empty key
        # → L548-549 raise. The parser strips the leading `- ` so
        # the field text we pass is exactly what comes after the dash.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        with pytest.raises(GateRegistryError, match="empty key"):
            parse_yaml_text(
                "gates:\n  - : whoops\n",
                root_key="gates",
            )

    def test_list_gates_no_filter_returns_all(self):
        # GateRegistry.list_gates(type=None) → return-all branch L296.
        reg = GateRegistry([_make_gate("commit.a"), _make_gate("release.b")])
        result = reg.list_gates()
        assert len(result) == 2

    def test_list_processes_no_filter_returns_all(self):
        # ProcessRegistry.list_processes(type=None) → L325.
        from forge_manager_mcp.gate_registry import (
            Process, ProcessRegistry,
        )
        p1 = Process(
            name="proc.one", type="release",
            location="x.md#proc.one", summary="x",
            rationale_doc="x.md#proc.one", introduced_in="1.0.0",
        )
        reg = ProcessRegistry([p1])
        assert len(reg.list_processes()) == 1

    def test_block_scalar_collects_blank_lines(self):
        # _consume_block_scalar appends "" for blank lines inside the
        # block. L583-586. Place a blank line between two content lines.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        body = (
            "gates:\n"
            "  - name: x\n"
            "    body: |\n"
            "      first\n"
            "\n"
            "      after-blank\n"
        )
        result = parse_yaml_text(body, root_key="gates")
        assert result[0]["body"] == "first\n\nafter-blank"

    def test_block_scalar_outdent_breaks(self):
        # Line less-indented than the block's indent breaks the
        # consumer. L590-591. Body block at indent 6, outdented line
        # at indent 4 (next sequence item) terminates.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        body = (
            "gates:\n"
            "  - name: x\n"
            "    body: |\n"
            "      one\n"
            "      two\n"
            "    after: z\n"
        )
        result = parse_yaml_text(body, root_key="gates")
        assert result[0]["body"] == "one\ntwo"
        assert result[0]["after"] == "z"

    def test_block_scalar_trims_trailing_blank_lines(self):
        # Block scalar ending with blank line(s) → trailing-blank pop
        # at L595-596.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        body = (
            "gates:\n"
            "  - name: x\n"
            "    body: |\n"
            "      content\n"
            "\n"
        )
        result = parse_yaml_text(body, root_key="gates")
        assert result[0]["body"] == "content"

    def test_block_scalar_with_tab_rejected(self):
        # _consume_block_scalar: tab inside the block → L587-588 raise.
        from forge_manager_mcp.gate_registry import parse_yaml_text
        body = (
            "gates:\n"
            "  - name: x\n"
            "    body: |\n"
            "      line1\n"
            "      \twith tab\n"
        )
        with pytest.raises(GateRegistryError, match="tabs"):
            parse_yaml_text(body, root_key="gates")


# Bazel-required entry point so this file isn't a silent no-op when run
# directly (#198 lint gate).
if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
