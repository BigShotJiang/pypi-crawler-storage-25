"""Unit tests for the #184 plan-completeness verifier.

Covers the YAML frontmatter parser, AC ID extraction, and the
orchestrator's report shape across well-formed plans, missing
frontmatter, malformed frontmatter, missing required fields, AC
mismatch, malformed paths, and duplicate IDs.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.validators.plan import (
    FrontmatterParseError,
    extract_ac_ids_from_body,
    parse_plan_frontmatter,
    verify_plan_completeness,
)


_GOOD_PLAN = """\
---
plan_id: "2.1.0-example"
touched_files:
  - mcp-server/src/foo.py
  - .claude/skills/active-claude-github/validation.md
entities_introduced:
  - "verify_plan_completeness"
  - "PlanFrontmatter"
entities_modified:
  - "build_server"
assumptions:
  - "All handlers are async def"
acceptance_criteria:
  - id: AC1
    description: "Tool registered in tool_schemas.py"
  - id: AC2
    description: "Test coverage for golden + sad paths"
---

# Plan: example

Body content here.

## Acceptance criteria

- [ ] (AC1) Tool registered in tool_schemas.py
- [ ] (AC2) Test coverage for golden + sad paths
"""


class TestParseFrontmatter:
    def test_no_frontmatter_returns_none(self):
        assert parse_plan_frontmatter("# Plan\n\nbody\n") is None

    def test_unterminated_frontmatter_raises(self):
        with pytest.raises(FrontmatterParseError, match="not terminated"):
            parse_plan_frontmatter("---\nplan_id: x\nno close marker\n")

    def test_parses_scalars(self):
        body = '---\nplan_id: "abc"\n---\n\nbody\n'
        out = parse_plan_frontmatter(body)
        assert out == {"plan_id": "abc"}

    def test_parses_string_list(self):
        body = '---\ntouched_files:\n  - foo.py\n  - bar.py\n---\n\nbody\n'
        out = parse_plan_frontmatter(body)
        assert out == {"touched_files": ["foo.py", "bar.py"]}

    def test_parses_dict_list(self):
        body = (
            "---\nacceptance_criteria:\n"
            "  - id: AC1\n"
            "    description: \"first\"\n"
            "  - id: AC2\n"
            "    description: \"second\"\n"
            "---\n\nbody\n"
        )
        out = parse_plan_frontmatter(body)
        assert out["acceptance_criteria"] == [
            {"id": "AC1", "description": "first"},
            {"id": "AC2", "description": "second"},
        ]

    def test_strips_inline_comments(self):
        body = '---\nplan_id: "abc"  # trailing comment\n---\n\nbody\n'
        out = parse_plan_frontmatter(body)
        assert out == {"plan_id": "abc"}

    def test_full_good_plan_parses(self):
        out = parse_plan_frontmatter(_GOOD_PLAN)
        assert out["plan_id"] == "2.1.0-example"
        assert out["touched_files"] == [
            "mcp-server/src/foo.py",
            ".claude/skills/active-claude-github/validation.md",
        ]
        assert out["entities_introduced"] == [
            "verify_plan_completeness",
            "PlanFrontmatter",
        ]
        assert out["assumptions"] == ["All handlers are async def"]
        assert len(out["acceptance_criteria"]) == 2


class TestExtractAcIdsFromBody:
    def test_pulls_ac_prefixes_from_acceptance_section(self):
        body = (
            "## Acceptance criteria\n\n"
            "- [ ] (AC1) first\n"
            "- [ ] (AC2) second\n"
            "- [ ] (AC3) third\n"
        )
        assert extract_ac_ids_from_body(body) == ["AC1", "AC2", "AC3"]

    def test_ignores_ac_outside_acceptance_section(self):
        body = (
            "## Background\n\n(AC99) not here\n\n"
            "## Acceptance criteria\n\n- [ ] (AC1) only this\n"
        )
        assert extract_ac_ids_from_body(body) == ["AC1"]

    def test_no_acceptance_section_returns_empty(self):
        assert extract_ac_ids_from_body("# Plan\n\nbody\n") == []

    def test_handles_case_insensitive_heading(self):
        body = "## ACCEPTANCE CRITERIA\n\n- [ ] (AC1) yes\n"
        assert extract_ac_ids_from_body(body) == ["AC1"]


class TestVerifyPlanCompleteness:
    def test_good_plan_returns_valid(self):
        result = verify_plan_completeness(_GOOD_PLAN)
        assert result["valid"] is True, result["errors"]
        assert result["errors"] == []
        # No assumptions warning since the field is set.
        assert not any(
            w["field"] == "assumptions" for w in result["warnings"]
        )

    def test_no_frontmatter_returns_valid_with_warning(self):
        """AC4 — graceful degradation."""
        result = verify_plan_completeness("# Plan\n\nbody\n")
        assert result["valid"] is True
        assert result["errors"] == []
        assert any(
            "no YAML frontmatter" in w["issue"] for w in result["warnings"]
        )

    def test_malformed_frontmatter_returns_invalid(self):
        body = "---\nplan_id: \"x\"\nno_close_marker\n"
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            e["field"] == "frontmatter" and "parse error" in e["issue"]
            for e in result["errors"]
        )

    def test_missing_required_field_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "acceptance_criteria:\n  - id: AC1\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            e["field"] == "touched_files" and "missing" in e["issue"]
            for e in result["errors"]
        )

    def test_ac_in_yaml_but_not_in_body_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d1\"\n"
            "  - id: AC2\n    description: \"d2\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d1\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "AC2" in e["issue"] and "markdown checkbox list" in e["issue"]
            for e in result["errors"]
        )

    def test_ac_in_body_but_not_in_yaml_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n"
            "- [ ] (AC1) d\n- [ ] (AC2) extra\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "AC2" in e["field"] and "no entry in the YAML" in e["issue"]
            for e in result["errors"]
        )

    def test_duplicate_ac_id_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d1\"\n"
            "  - id: AC1\n    description: \"d2\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "duplicate id" in e["issue"] for e in result["errors"]
        )

    def test_malformed_ac_id_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: \"acceptance-1\"\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "must match" in e["issue"] for e in result["errors"]
        )

    def test_absolute_path_in_touched_files_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - /etc/passwd\n  - ../escape\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "absolute paths" in e["issue"] for e in result["errors"]
        )
        assert any(
            "traversal" in e["issue"] for e in result["errors"]
        )

    def test_missing_assumptions_field_warns(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is True
        assert any(
            w["field"] == "assumptions"
            for w in result["warnings"]
        )

    def test_empty_entities_introduced_entry_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "entities_introduced:\n  - \"\"\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is False
        assert any(
            "entities_introduced" in e["field"] and "non-empty" in e["issue"]
            for e in result["errors"]
        )

    def test_unknown_field_warns_not_errors(self):
        body = (
            "---\nplan_id: \"x\"\n"
            "touched_files:\n  - f.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n    description: \"d\"\n"
            "future_field: \"x\"\n"
            "---\n\n## Acceptance criteria\n- [ ] (AC1) d\n"
        )
        result = verify_plan_completeness(body)
        assert result["valid"] is True
        assert any(
            w["field"] == "future_field" and "unknown" in w["issue"]
            for w in result["warnings"]
        )


# (#428 / 3.12.0 D-Coverage drain) Edge-path tests for the parser
# helpers + frontmatter validators.


class TestParseFrontmatterEdges:
    def test_blank_lines_in_frontmatter_skipped(self):
        body = (
            "---\n"
            "title: foo\n"
            "\n"
            "version: 1.0\n"
            "---\n"
            "body content\n"
        )
        result = parse_plan_frontmatter(body)
        assert result == {"title": "foo", "version": "1.0"}

    def test_unexpected_indentation_raises(self):
        body = (
            "---\n"
            "  indented_top_level: nope\n"
            "---\n"
        )
        with pytest.raises(FrontmatterParseError, match="indentation"):
            parse_plan_frontmatter(body)

    def test_missing_colon_on_key_line_raises(self):
        body = "---\nno_colon_here\n---\n"
        with pytest.raises(FrontmatterParseError, match="key"):
            parse_plan_frontmatter(body)

    def test_strip_comment_inside_quoted_string_left_alone(self):
        from forge_manager_mcp.validators.plan import _strip_comment
        # `#` inside a quoted string isn't a comment marker.
        assert _strip_comment('foo: "value # not comment"') == \
            'foo: "value # not comment"'

    def test_strip_comment_at_start_of_line(self):
        from forge_manager_mcp.validators.plan import _strip_comment
        assert _strip_comment("# full line comment") == ""


class TestParseIndentedBlockEdges:
    def test_continuation_subkey_without_colon_raises(self):
        body = (
            "---\n"
            "items:\n"
            "  - id: AC1\n"
            "    no_colon_here\n"
            "---\n"
        )
        with pytest.raises(FrontmatterParseError, match="subkey"):
            parse_plan_frontmatter(body)


class TestVerifyPlanCompletenessTouchedFiles:
    def test_empty_touched_file_entry_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "touched_files:\n"
            "  - ''\n"
            "  - valid.py\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            "touched_files[0]" in e["field"] for e in result["errors"]
        )

    def test_absolute_touched_file_path_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "touched_files:\n"
            "  - /abs/path.py\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any("absolute" in e["issue"] for e in result["errors"])

    def test_dotdot_in_touched_file_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "touched_files:\n"
            "  - ../escape.py\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any("traversal" in e["issue"] for e in result["errors"])

    def test_touched_files_not_list_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "touched_files: not_a_list\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            e["field"] == "touched_files" and "list" in e["issue"]
            for e in result["errors"]
        )


class TestVerifyPlanCompletenessEntities:
    def test_entities_introduced_not_list_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "entities_introduced: not_a_list\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            e["field"] == "entities_introduced" and "list" in e["issue"]
            for e in result["errors"]
        )

    def test_empty_entity_entry_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "entities_modified:\n"
            "  - ''\n"
            "  - real_entity\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            "entities_modified[0]" in e["field"] for e in result["errors"]
        )


class TestVerifyPlanCompletenessAcceptanceCriteria:
    def test_acceptance_criteria_not_list_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "acceptance_criteria: not_a_list\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            e["field"] == "acceptance_criteria" and "list" in e["issue"]
            for e in result["errors"]
        )

    def test_acceptance_criteria_non_dict_entry_flagged(self):
        from forge_manager_mcp.validators.plan import verify_plan_completeness
        body = (
            "---\n"
            "title: t\n"
            "acceptance_criteria:\n"
            "  - just_a_string\n"
            "---\n"
            "body\n"
        )
        result = verify_plan_completeness(body)
        assert any(
            "acceptance_criteria[0]" in e["field"]
            and "dict" in e["issue"]
            for e in result["errors"]
        )


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Parser + validator edge branches.
# ---------------------------------------------------------------------------


class TestParseListBlankLineSkipped:
    def test_blank_line_inside_list_block_skipped(self):
        # _parse_list: blank line inside the list block → continue at
        # L168-169.
        plan = (
            "---\n"
            "touched_files:\n"
            "  - a.py\n"
            "\n"
            "  - b.py\n"
            "---\n"
        )
        result = parse_plan_frontmatter(plan)
        assert result["touched_files"] == ["a.py", "b.py"]


class TestParseListContinuationWithoutContext:
    def test_indented_continuation_with_no_pending_dict_raises(self):
        # _parse_list: indented continuation line with no pending dict
        # → L187-191 raise. Trigger via a list block that opens with
        # a deeper-indent continuation rather than a `- ` dash item.
        plan = (
            "---\n"
            "touched_files:\n"
            "  surprise: value\n"
            "---\n"
        )
        with pytest.raises(
            FrontmatterParseError, match="indented continuation",
        ):
            parse_plan_frontmatter(plan)


class TestVerifyPlanCompletenessTouchedFilesEdgeBranches:
    def test_non_string_touched_files_entry_flagged(self):
        # touched_files entry that's not a non-empty string → flagged
        # at L284-290. Empty string is the simplest non-empty trigger.
        plan = (
            "---\n"
            "plan_id: \"p\"\n"
            "touched_files:\n"
            "  - \"\"\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n"
            "    description: x\n"
            "---\n"
            "(AC1) marker\n"
        )
        result = verify_plan_completeness(plan)
        assert any(
            "touched_files[0]" in e["field"]
            and "non-empty string" in e["issue"]
            for e in result["errors"]
        )

    def test_absolute_touched_path_flagged(self):
        # touched_files entry with absolute path → L301-307.
        plan = (
            "---\n"
            "plan_id: \"p\"\n"
            "touched_files:\n"
            "  - /etc/passwd\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n"
            "    description: x\n"
            "---\n"
            "(AC1) marker\n"
        )
        result = verify_plan_completeness(plan)
        assert any(
            "absolute" in e["issue"] for e in result["errors"]
        )


class TestAcceptanceCriteriaEmptyDescription:
    def test_empty_description_flagged(self):
        # description is empty string → L372-378 flag.
        plan = (
            "---\n"
            "plan_id: \"p\"\n"
            "touched_files:\n"
            "  - a.py\n"
            "acceptance_criteria:\n"
            "  - id: AC1\n"
            "    description: \"\"\n"
            "---\n"
            "(AC1) marker\n"
        )
        result = verify_plan_completeness(plan)
        assert any(
            "acceptance_criteria[0].description" in e["field"]
            for e in result["errors"]
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
