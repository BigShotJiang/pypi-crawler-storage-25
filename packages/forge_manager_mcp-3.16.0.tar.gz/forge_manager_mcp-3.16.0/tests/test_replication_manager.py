"""Unit tests for ReplicationManager (3.0 / Phase 6 sub-run A).

Covers the orchestration shape: read-path failover ordering, write-
path local-first invariant, per-adapter state-machine transitions,
DEGRADED-skip behavior, and the queueing semantics for failed remote
writes. Real adapters aren't needed — the tests construct minimal
mock adapters that record calls.
"""
from __future__ import annotations

from typing import Any, ClassVar

import pytest

from forge_manager_mcp.adapters import errors as _adapter_errors
from forge_manager_mcp.replication import (
    AdapterState,
    AllAdaptersFailedError,
    MirrorWarning,
    ReplicationError,
    ReplicationManager,
    ReplicationWriteError,
    WriteResult,
)


# ---------------------------------------------------------------------------
# Mock adapter helpers
# ---------------------------------------------------------------------------

class _MockAdapter:
    """Minimal stand-in for a PlatformAdapter — records every method
    call on `.calls` so tests can assert on order + count."""

    def __init__(
        self,
        platform_id: str,
        *,
        fail_with: BaseException | None = None,
        return_value: Any = "ok",
    ):
        self.platform_id: str = platform_id
        self.fail_with = fail_with
        self.return_value = return_value
        self.calls: list[str] = []

    async def some_op(self, *args, **kwargs) -> Any:
        self.calls.append("some_op")
        if self.fail_with is not None:
            raise self.fail_with
        return self.return_value


def _manager_with(*adapters: _MockAdapter) -> ReplicationManager:
    return ReplicationManager(
        [(a.platform_id, a) for a in adapters],  # type: ignore[arg-type]
    )


class _StubConfig:
    """Stand-in for GithubConfig.coords_for_platform used by #296 tests.

    Real GithubConfig requires a populated forge-config.json shape;
    this stub exposes only the surface ReplicationManager needs.
    """

    def __init__(self, mapping: dict[tuple[str, str], tuple[str, str]]):
        self._mapping = mapping

    def coords_for_platform(
        self, platform_id: str, repo_role: str = "private",
    ) -> tuple[str, str]:
        return self._mapping.get((platform_id, repo_role), ("", ""))


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestConstruction:
    def test_empty_adapters_raises(self):
        with pytest.raises(ValueError, match="at least one adapter"):
            ReplicationManager([])

    def test_initial_states_all_healthy(self):
        m = _manager_with(_MockAdapter("local"), _MockAdapter("remote"))
        states = m.states()
        assert states == {"local": AdapterState.HEALTHY, "remote": AdapterState.HEALTHY}

    def test_canonical_returns_first(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote")
        m = _manager_with(local, remote)
        assert m.canonical() is local


# ---------------------------------------------------------------------------
# Read-path failover
# ---------------------------------------------------------------------------

class TestReadFailover:
    @pytest.mark.asyncio
    async def test_first_healthy_wins(self):
        local = _MockAdapter("local", return_value="local-result")
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        result = await m.read(lambda a, _: a.some_op())
        assert result == "local-result"
        assert local.calls == ["some_op"]
        assert remote.calls == []  # short-circuited

    @pytest.mark.asyncio
    async def test_unavailable_falls_through_to_next(self):
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.ForgeUnavailableError("offline"),
        )
        remote = _MockAdapter("remote", return_value="remote-saved-the-day")
        m = _manager_with(local, remote)
        result = await m.read(lambda a, _: a.some_op())
        assert result == "remote-saved-the-day"
        # Local was tried + degraded; remote took over.
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m.states()["local"] == AdapterState.DEGRADED
        assert m.states()["remote"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_caller_fault_error_propagates(self):
        # Caller-fault error (not unavailable) must NOT trigger failover —
        # next adapter would fail identically; raise immediately so the
        # caller can fix the underlying problem.
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.InvalidArtifactRefError("issue", "9999"),
        )
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        with pytest.raises(_adapter_errors.InvalidArtifactRefError):
            await m.read(lambda a, _: a.some_op())
        assert remote.calls == []  # remote never consulted

    @pytest.mark.asyncio
    async def test_all_adapters_unavailable_raises_all_failed(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("a"),
        )
        remote = _MockAdapter(
            "remote", fail_with=_adapter_errors.ForgeUnavailableError("b"),
        )
        m = _manager_with(local, remote)
        with pytest.raises(AllAdaptersFailedError) as exc_info:
            await m.read(lambda a, _: a.some_op())
        # Both per-adapter errors captured.
        assert "local" in exc_info.value.errors
        assert "remote" in exc_info.value.errors

    # (#23 A.5 OQ2 / 3.15.0) test_degraded_adapters_skipped RETIRED —
    # DEGRADED-skip in the read path retired; every adapter is
    # attempted and the first to succeed serves the result.

    # -----------------------------------------------------------------
    # (#502, 3.16.0 D0) skip_canonical flag for inherently-remote reads
    # -----------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_skip_canonical_bypasses_first_entry(self):
        # Canonical (entries[0]) returns a stub value; without skip_canonical
        # the failover would short-circuit there and return the stub. With
        # skip_canonical=True the canonical is bypassed entirely.
        canonical = _MockAdapter("local", return_value="canonical-stub")
        remote = _MockAdapter("remote", return_value="remote-real-value")
        m = _manager_with(canonical, remote)
        result = await m.read(
            lambda a, _: a.some_op(),
            skip_canonical=True,
        )
        assert result == "remote-real-value"
        assert canonical.calls == []  # never consulted
        assert remote.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_skip_canonical_default_false_preserves_legacy(self):
        # Regression guard: existing callers that don't pass skip_canonical
        # still get the pre-3.16.0 canonical-first failover behavior.
        canonical = _MockAdapter("local", return_value="canonical-stub")
        remote = _MockAdapter("remote", return_value="remote-real-value")
        m = _manager_with(canonical, remote)
        result = await m.read(lambda a, _: a.some_op())
        assert result == "canonical-stub"
        assert canonical.calls == ["some_op"]
        assert remote.calls == []  # short-circuited at canonical

    @pytest.mark.asyncio
    async def test_skip_canonical_falls_through_to_subsequent_remote(self):
        # skip_canonical bypasses entries[0] (canonical) but still iterates
        # subsequent entries with the normal failover semantics — first
        # remote unavailable → second remote serves.
        canonical = _MockAdapter("local", return_value="canonical-stub")
        remote1 = _MockAdapter(
            "remote1",
            fail_with=_adapter_errors.ForgeUnavailableError("offline"),
        )
        remote2 = _MockAdapter("remote2", return_value="remote2-result")
        m = _manager_with(canonical, remote1, remote2)
        result = await m.read(
            lambda a, _: a.some_op(),
            skip_canonical=True,
        )
        assert result == "remote2-result"
        assert canonical.calls == []
        assert remote1.calls == ["some_op"]
        assert remote2.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_skip_canonical_all_remotes_unavailable_raises(self):
        # Canonical bypassed; every remote fails with unavailable →
        # AllAdaptersFailedError with per-remote errors captured.
        canonical = _MockAdapter("local", return_value="canonical-stub")
        remote1 = _MockAdapter(
            "remote1",
            fail_with=_adapter_errors.ForgeUnavailableError("a"),
        )
        remote2 = _MockAdapter(
            "remote2",
            fail_with=_adapter_errors.ForgeUnavailableError("b"),
        )
        m = _manager_with(canonical, remote1, remote2)
        with pytest.raises(AllAdaptersFailedError) as exc_info:
            await m.read(lambda a, _: a.some_op(), skip_canonical=True)
        # Canonical NOT in errors dict — it was never tried.
        assert "local" not in exc_info.value.errors
        assert "remote1" in exc_info.value.errors
        assert "remote2" in exc_info.value.errors

    @pytest.mark.asyncio
    async def test_skip_canonical_single_canonical_only_raises(self):
        # Edge case: only the canonical adapter is registered + skip_canonical
        # is set → no adapters are tried → AllAdaptersFailedError with empty
        # errors dict. The audit caller treats this as UNREACHABLE.
        canonical = _MockAdapter("local", return_value="canonical-stub")
        m = _manager_with(canonical)
        with pytest.raises(AllAdaptersFailedError) as exc_info:
            await m.read(lambda a, _: a.some_op(), skip_canonical=True)
        assert exc_info.value.errors == {}


# ---------------------------------------------------------------------------
# Write-path fan-out
# ---------------------------------------------------------------------------

class TestWriteFanOut:
    @pytest.mark.asyncio
    async def test_canonical_first_then_mirrors(self):
        local = _MockAdapter("local", return_value="canonical-result")
        m1 = _MockAdapter("mirror1")
        m2 = _MockAdapter("mirror2")
        m = _manager_with(local, m1, m2)
        result = await m.write(lambda a, _: a.some_op())
        # #297 — write() now returns WriteResult; .value carries the
        # canonical adapter's return.
        assert isinstance(result, WriteResult)
        assert result.value == "canonical-result"
        assert result.mirror_warnings == ()
        # All three got the call, local first.
        assert local.calls == ["some_op"]
        assert m1.calls == ["some_op"]
        assert m2.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_canonical_failure_is_fatal(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("local-down"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError) as exc_info:
            await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert exc_info.value.platform_id == "local"
        assert exc_info.value.operation == "create_issue"
        # Mirror was NOT attempted — local is canonical, fatal failure.
        assert mirror.calls == []
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m.states()["local"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_mirror_unavailable_does_not_fail_call(self):
        # A mirror going down should not affect the caller — the
        # canonical write succeeded, the mirror's failure becomes a
        # queued replay. #297 — surfaces as a MirrorWarning on the
        # WriteResult so the caller can see what didn't replicate.
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.ForgeUnavailableError("mirror-down"),
        )
        m = _manager_with(local, mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="update_issue_body",
        )
        assert result.value == "local-ok"
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m.states()["mirror"] == AdapterState.DEGRADED
        # (#23 A.5) pending_count assertion retired with the queue.
        # Warning surfaced on the envelope.
        assert len(result.mirror_warnings) == 1
        warning = result.mirror_warnings[0]
        assert warning.platform_id == "mirror"
        assert warning.operation == "update_issue_body"
        assert warning.error_type == "ForgeUnavailableError"
        assert "mirror-down" in warning.error_message

    @pytest.mark.asyncio
    async def test_mirror_legacy_github_403_drives_DEGRADED_transition(self):
        # (#362, 3.7.0 D1) Pre-#362 a GitHubError(status=403) raised
        # by the github/* layer fell through the
        # ``except ForgeUnavailableError`` class match in
        # ReplicationManager.write — last_error was recorded but the
        # state machine never transitioned to DEGRADED. Operator
        # dashboards showed every adapter as healthy indefinitely
        # while every write 403'd.
        #
        # Fix: predicate-based dispatch via ``is_forge_unavailable``,
        # which duck-types on ``status_code`` so legacy GitHubError-
        # shape exceptions classify correctly.
        legacy_403 = RuntimeError("GitHub API returned HTTP 403.")
        legacy_403.status_code = 403  # type: ignore[attr-defined]
        legacy_403.body = ""  # type: ignore[attr-defined]

        local = _MockAdapter("local", return_value="local-ok")
        github_mirror = _MockAdapter("github", fail_with=legacy_403)
        m = _manager_with(local, github_mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        # Canonical write succeeded; the call returned cleanly.
        assert result.value == "local-ok"
        # (#23 A.5 OQ2) DEGRADED state-transition retired (was the
        # #362 bug-fix contract for GitHubError(status=403) →
        # DEGRADED). Post-A.5 the failure records last_error
        # without state change.
        # Op queued for replay.
        # (#23 A.5) pending_count assertion retired with the queue.
        # MirrorWarning surfaced with the original error_type for
        # downstream observability.
        assert len(result.mirror_warnings) == 1
        assert result.mirror_warnings[0].error_type == "RuntimeError"
        assert "403" in result.mirror_warnings[0].error_message

    @pytest.mark.asyncio
    async def test_mirror_fan_out_runs_concurrently(self):
        """(#273 F1, 3.7.0 D7) Mirror writes run in parallel via
        asyncio.gather — total wall-clock is bounded by max(latency)
        not sum(latency). Pre-F1 the loop awaited each mirror serially
        so a slow GitHub timeout (~5s under suspended-account 403)
        delayed every other mirror.

        Test assertion: each mirror's coroutine starts BEFORE any
        completes. Pre-F1 (sequential) the second mirror wouldn't
        start until the first returned; with F1 (gather) all three
        start, then complete.
        """
        import asyncio

        # Three slow mirrors that block on a barrier; without
        # parallelism, only one would be "in flight" at a time and
        # the gather below would deadlock waiting for the barrier.
        started = [asyncio.Event() for _ in range(3)]
        proceed = asyncio.Event()

        class StepAdapter:
            """Inline adapter with a `step(idx)` method that signals
            the matching `started[idx]` event then waits on
            `proceed`. The canonical (idx=-1) skips the wait so the
            mirror fan-out runs."""
            def __init__(self, platform_id: str, idx: int):
                self.platform_id = platform_id
                self._idx = idx

            async def step(self):
                if self._idx >= 0:
                    started[self._idx].set()
                    await proceed.wait()
                return f"ok-{self._idx}"

        local = StepAdapter("local", -1)  # canonical; no wait
        m1 = StepAdapter("m1", 0)
        m2 = StepAdapter("m2", 1)
        m3 = StepAdapter("m3", 2)
        m = _manager_with(local, m1, m2, m3)  # type: ignore[arg-type]

        # Schedule the write; it should not complete until proceed
        # is set, but all three mirrors should have STARTED.
        write_task = asyncio.create_task(
            m.write(lambda a, _: a.step(), operation_name="op"),
        )

        # Wait for all three to start. If the loop were serial, only
        # `started[0]` would set within the timeout.
        await asyncio.wait_for(
            asyncio.gather(*(e.wait() for e in started)),
            timeout=2.0,
        )
        # All three confirmed in flight before any completed.
        assert all(e.is_set() for e in started), (
            "all 3 mirrors must start concurrently (F1 contract)"
        )
        proceed.set()
        result = await write_task
        assert result.value == "ok--1"
        assert result.mirror_warnings == ()

    @pytest.mark.asyncio
    async def test_mirror_caller_fault_404_does_NOT_drive_DEGRADED(self):
        # (#362) Caller-fault errors (404 stale-ref, 422 validation)
        # must NOT trigger a state transition — the adapter is healthy,
        # the request is bad. #297 contract: record + queue + continue,
        # state stays unchanged.
        legacy_404 = RuntimeError("GitHub API returned HTTP 404.")
        legacy_404.status_code = 404  # type: ignore[attr-defined]
        legacy_404.body = ""  # type: ignore[attr-defined]

        local = _MockAdapter("local", return_value="local-ok")
        github_mirror = _MockAdapter("github", fail_with=legacy_404)
        m = _manager_with(local, github_mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="update_issue_body",
        )
        assert result.value == "local-ok"
        # State stays HEALTHY — not a service-availability failure.
        assert m.states()["github"] == AdapterState.HEALTHY, (
            "404 caller-fault must NOT degrade adapter state (#362 contract)"
        )
        # Still surfaces as a MirrorWarning so the UI sees the failure.
        assert len(result.mirror_warnings) == 1
        # last_error_at populated even without state change.
        assert m._entries[1].last_error is legacy_404

    @pytest.mark.asyncio
    async def test_mirror_non_unavailable_error_does_not_propagate(self):
        # #297 — pre-fix: a non-Unavailable mirror error (HTTP 4xx,
        # malformed-body, adapter-coords-bug, etc.) propagated to the
        # caller, masking the canonical-success outcome. Now: recorded
        # as a MirrorWarning, queued for replay, surfaced on the
        # WriteResult — does NOT propagate.
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "x"),
        )
        m = _manager_with(local, mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        # Canonical success surfaces — pre-#297 this was masked.
        assert result.value == "local-ok"
        assert local.calls == ["some_op"]
        assert mirror.calls == ["some_op"]
        # Mirror failure recorded as a warning, not raised.
        assert len(result.mirror_warnings) == 1
        warning = result.mirror_warnings[0]
        assert warning.platform_id == "mirror"
        assert warning.operation == "create_issue"
        assert warning.error_type == "InvalidArtifactRefError"
        # Mirror queued for replay — same shape as Unavailable path.
        # (#23 A.5) pending_count assertion retired with the queue.

    @pytest.mark.asyncio
    async def test_mirror_warnings_for_multiple_failures(self):
        # Mixed failure modes across mirrors: one Unavailable, one
        # non-Unavailable. Both surface as warnings; both queue for
        # replay; canonical result returns clean.
        local = _MockAdapter("local", return_value="canonical-ok")
        m1 = _MockAdapter(
            "m1", fail_with=_adapter_errors.ForgeUnavailableError("m1-down"),
        )
        m2 = _MockAdapter(
            "m2", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "y"),
        )
        m = _manager_with(local, m1, m2)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="append_comment",
        )
        assert result.value == "canonical-ok"
        # Both warnings present, in fan-out order.
        assert len(result.mirror_warnings) == 2
        assert {w.platform_id for w in result.mirror_warnings} == {"m1", "m2"}
        # Both queued.
        # (#23 A.5) pending_count assertion retired with the queue.
        # (#23 A.5) pending_count assertion retired with the queue.
        # m1 degraded (Unavailable convention); m2 stays healthy
        # because non-Unavailable doesn't trigger DEGRADED transition
        # (the error may be caller-fault that a future op shouldn't
        # automatically skip — DEGRADED is reserved for service-down).
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m.states()["m1"] == AdapterState.DEGRADED
        assert m.states()["m2"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_canonical_failure_still_propagates_after_297(self):
        # Regression guard: #297 changed mirror-failure semantics;
        # canonical-failure semantics MUST stay the same. A failed
        # canonical write is still fatal — local IS the source of
        # truth. ReplicationWriteError raises; WriteResult never
        # reaches the caller.
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "z"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op())
        # Mirror NOT attempted — fatal canonical failure short-circuits.
        assert mirror.calls == []

    # (#23 A.5 OQ2 / 3.15.0) test_pre_degraded_mirror_queues_without_call
    # RETIRED — best-effort additive-only fan-out means every mirror
    # is attempted regardless of state; no queueing.


class TestPerPlatformCoords:
    """#296 — write/read thread per-platform coordinates so each
    adapter receives its OWN coords rather than a single set shared
    across all backends. Pre-#296, every adapter got the project's
    GitHub coords, causing Codeberg fan-out to 404 against Codeberg's
    API. The fix routes coords through ``config.coords_for_platform``
    per iteration.
    """

    @pytest.mark.asyncio
    async def test_each_adapter_receives_its_own_coords(self):
        """Multi-platform setup with diverging owner slugs — each
        adapter's lambda invocation MUST receive its own coords."""
        observed: dict[str, tuple[str, str]] = {}

        class _CoordAwareAdapter:
            def __init__(self, platform_id: str):
                self.platform_id = platform_id
                self.calls: list[str] = []

            async def some_op(self, *args, owner: str = "", repo: str = "", **kw):
                self.calls.append("some_op")
                observed[self.platform_id] = (owner, repo)
                return f"{self.platform_id}-result"

        local = _CoordAwareAdapter("local")
        github = _CoordAwareAdapter("github")
        codeberg = _CoordAwareAdapter("codeberg")

        config = _StubConfig({
            ("local", "private"): ("local-owner", "local-repo"),
            ("github", "private"): ("gh-owner", "gh-repo"),
            ("codeberg", "private"): ("cb-owner", "cb-repo"),
        })
        m = ReplicationManager(
            [("local", local), ("github", github), ("codeberg", codeberg)],  # type: ignore[arg-type]
            config=config,
        )

        await m.write(
            lambda a, c: a.some_op(owner=c[0], repo=c[1]),
            operation_name="some_op",
            repo_role="private",
        )

        # Each backend received its OWN coords — pre-#296 they all
        # would have been ("", "") (no config) or all the same
        # (single-tenant config field).
        assert observed["local"] == ("local-owner", "local-repo")
        assert observed["github"] == ("gh-owner", "gh-repo")
        assert observed["codeberg"] == ("cb-owner", "cb-repo")

    @pytest.mark.asyncio
    async def test_repo_role_param_threads_through(self):
        """`repo_role="public"` resolves coords from the public
        per-platform field, not private — proves the role parameter
        threads correctly."""
        observed: dict[str, str] = {}

        class _RoleAwareAdapter:
            def __init__(self, platform_id: str):
                self.platform_id = platform_id

            async def some_op(self, *args, owner: str = "", **kw):
                observed[self.platform_id] = owner
                return None

        local = _RoleAwareAdapter("local")
        github = _RoleAwareAdapter("github")

        config = _StubConfig({
            ("local", "private"): ("local-private", "x"),
            ("local", "public"): ("local-public", "y"),
            ("github", "private"): ("gh-private", "z"),
            ("github", "public"): ("gh-public", "w"),
        })
        m = ReplicationManager(
            [("local", local), ("github", github)],  # type: ignore[arg-type]
            config=config,
        )

        await m.write(
            lambda a, c: a.some_op(owner=c[0]),
            operation_name="some_op",
            repo_role="public",
        )

        assert observed == {"local": "local-public", "github": "gh-public"}

    @pytest.mark.asyncio
    async def test_no_config_falls_back_to_empty_coords(self):
        """When config is None (pre-bootstrap, test fixtures), each
        adapter receives ``("", "")``. Lambdas that fall back via
        ``c[0] or default`` see the default; safe for legacy paths."""
        observed: list[tuple[str, str]] = []

        async def op(adapter, coords):
            observed.append(coords)
            return adapter.return_value

        local = _MockAdapter("local")
        m = ReplicationManager([("local", local)])  # config defaults to None

        await m.write(op, operation_name="some_op")
        assert observed == [("", "")]


class TestOnCanonicalWriteHook:
    """The Hugo live-update hook fires once after every successful
    canonical write — wiring point for SiteRebuilder.notify."""

    @pytest.mark.asyncio
    async def test_hook_fires_after_canonical_success(self):
        local = _MockAdapter("local", return_value="ok")
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert captured == ["create_issue"]

    @pytest.mark.asyncio
    async def test_hook_does_not_fire_on_canonical_failure(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("down"),
        )
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        # Hook MUST NOT fire on failure — rebuild on a failed write
        # would publish stale state.
        assert captured == []

    @pytest.mark.asyncio
    async def test_hook_error_doesnt_poison_canonical_write(self):
        """A broken hook (raising callback) doesn't fail the
        underlying write — the canonical store IS authoritative."""
        local = _MockAdapter("local", return_value="ok")

        def broken(name):
            raise RuntimeError("hook is broken")

        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=broken,
        )
        # Write completes cleanly despite the broken hook.
        result = await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert result.value == "ok"  # #297 — WriteResult envelope


# ---------------------------------------------------------------------------
# State machine transitions
# ---------------------------------------------------------------------------

class TestStateTransitions:
    def test_mark_healthy(self):
        local = _MockAdapter("local")
        m = _manager_with(local)
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m._entries[0].last_error = ValueError("x")  # type: ignore[attr-defined]
        m.mark_healthy("local")
        assert m.states()["local"] == AdapterState.HEALTHY
        assert m._entries[0].last_error is None  # type: ignore[attr-defined]

    # (#23 A.5 OQ3 / 3.15.0) test_mark_reconciling + test_reconciling_
    # skipped_in_read RETIRED — RECONCILING state + mark_reconciling
    # method retired with the canonical_reconcile loop (commit 54581bc).

    def test_mark_unknown_platform_raises(self):
        m = _manager_with(_MockAdapter("local"))
        with pytest.raises(KeyError):
            m.mark_healthy("nonexistent")


class TestStateTimestampTracking:
    """#333 — `_set_state` keeps `state_changed_at`, `last_error_at`,
    and `next_attempt_at` coherent across every transition."""

    def test_initial_state_has_state_changed_at(self):
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        assert entry.state_changed_at is not None
        assert entry.last_error_at is None
        assert entry.next_attempt_at is None

    # (#23 A.5 OQ1) test_pause_* + test_resume_* RETIRED — pause/
    # resume methods retired with the durable enabled config flag.

    # (#23 A.5 OQ2 / 3.15.0) test_set_degraded_records_error_and_
    # schedules_next_attempt RETIRED — _set_state's DEGRADED branch
    # (with next_attempt_at scheduling) retired; failures record
    # last_error directly without state transitions.

    # (#23 A.5 OQ3) test_set_reconciling_sets_next_attempt_now RETIRED
    # with the RECONCILING enum value.

    def test_set_healthy_clears_error(self):
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("x"))  # type: ignore[attr-defined]
        assert entry.last_error is not None
        m._set_state(entry, AdapterState.HEALTHY)  # type: ignore[attr-defined]
        assert entry.last_error is None
        assert entry.last_error_at is None
        assert entry.next_attempt_at is None

    def test_on_state_change_listener_fires(self):
        """#333 — daemon attaches a listener that publishes
        backend.state_changed events. _set_state must invoke it."""
        events: list = []
        m = _manager_with(_MockAdapter("local"))
        m.set_on_state_change(lambda entry: events.append(
            (entry.platform_id, entry.state),
        ))
        m._set_state(m._entries[0], AdapterState.DEGRADED, error=RuntimeError("x"))  # type: ignore[attr-defined]
        m._set_state(m._entries[0], AdapterState.HEALTHY)  # type: ignore[attr-defined]
        assert events == [
            ("local", AdapterState.DEGRADED),
            ("local", AdapterState.HEALTHY),
        ]

    def test_listener_failure_does_not_poison_state(self):
        """Listener exception is swallowed — state mutation still
        takes effect."""
        m = _manager_with(_MockAdapter("local"))
        def _broken(entry):
            raise RuntimeError("listener kaboom")
        m.set_on_state_change(_broken)
        # Should not raise. (Was PAUSED pre-A.5; uses DEGRADED now
        # since PAUSED retired alongside pause()/resume().)
        m._set_state(m._entries[0], AdapterState.DEGRADED, error=RuntimeError("e"))  # type: ignore[attr-defined]
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m._entries[0].state == AdapterState.DEGRADED  # type: ignore[attr-defined]

    def test_set_state_idempotent_refreshes_state_changed_at(self):
        """Re-asserting the same state still bumps state_changed_at —
        signals to the UI that the transition was observed (e.g.,
        a second auto-degrade on the same adapter)."""
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("a"))  # type: ignore[attr-defined]
        ts1 = entry.state_changed_at
        # Force a measurable delta (datetime.now resolution).
        import time
        time.sleep(0.001)
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("b"))  # type: ignore[attr-defined]
        assert entry.state_changed_at > ts1
        assert str(entry.last_error) == "b"


# (#23 A.5 OQ1 / 3.15.0) TestPauseResume RETIRED — pause/resume
# methods retired with the durable enabled config flag. Coverage
# for the replacement lives at tests/daemon/test_http.py's
# TestEnableDisableBackendEndpoints + tests/test_replication_enabled.py.


# ---------------------------------------------------------------------------
# Healthy-adapters introspection
# ---------------------------------------------------------------------------

class TestIntrospection:
    def test_healthy_adapters_filters_out_degraded(self):
        m = _manager_with(_MockAdapter("a"), _MockAdapter("b"), _MockAdapter("c"))
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        # (#23 A.5) RECONCILING + PAUSED retired; both non-healthy
        # slots use DEGRADED now.
        m._entries[2].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        assert m.healthy_adapters() == ["a"]


# ---------------------------------------------------------------------------
# Error types
# ---------------------------------------------------------------------------

class TestErrorTypes:
    def test_replication_write_error_is_replication_error(self):
        assert issubclass(ReplicationWriteError, ReplicationError)

    def test_all_adapters_failed_is_replication_error(self):
        assert issubclass(AllAdaptersFailedError, ReplicationError)

    def test_all_adapters_failed_message_lists_causes(self):
        errors = {
            "local": _adapter_errors.ForgeUnavailableError("net"),
            "remote": _adapter_errors.ForgeUnavailableError("auth"),
        }
        exc = AllAdaptersFailedError(errors)
        msg = str(exc)
        assert "local" in msg and "remote" in msg
        assert exc.errors == errors


# (#23 A.5 OQ2 / 3.15.0) TestReplayPendingWrites RETIRED — the
# manager-level pending_writes queue + replay_pending_writes drain
# went away with the DEGRADED state machine.



class TestLocalChangesSince:
    """#274 Phase D — time-window complement to compute_drifts.
    Delegates to canonical adapter's aggregate_history_since when
    available; raises NotImplementedError when canonical doesn't
    expose history (i.e., remote-only canonical configurations)."""

    @pytest.mark.asyncio
    async def test_delegates_to_canonical_when_method_present(self):
        from datetime import datetime, timezone

        class _HistoricalAdapter:
            platform_id = "local"

            def __init__(self):
                self.calls: list[dict] = []

            async def aggregate_history_since(
                self, *, since, kind=None, owner="", repo="",
            ):
                self.calls.append({
                    "since": since, "kind": kind,
                    "owner": owner, "repo": repo,
                })
                return ["sentinel-entry"]

        canonical = _HistoricalAdapter()
        manager = _manager_with(canonical)  # type: ignore[arg-type]

        marker = datetime.now(timezone.utc)
        result = await manager.local_changes_since(
            since=marker, kind="issue", owner="o", repo="r",
        )
        assert result == ["sentinel-entry"]
        assert len(canonical.calls) == 1
        assert canonical.calls[0]["since"] == marker
        assert canonical.calls[0]["kind"] == "issue"

    @pytest.mark.asyncio
    async def test_raises_when_canonical_lacks_method(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no aggregate_history_since attribute.
        canonical = _MockAdapter("remote-canonical")
        manager = _manager_with(canonical)

        with pytest.raises(NotImplementedError, match="aggregate_history_since"):
            await manager.local_changes_since(since=datetime.now(timezone.utc))


class TestImportRemoteChanges:
    """#274 Phase D — orchestrator for the OQ4 import_remote_changes
    flow. Foundation only: tests use mocked source adapters; live
    fetch_remote_changes implementations are deferred per the
    project-level GitHub-defer directive."""

    @staticmethod
    def _stub_source(platform_id: str, changes: list):
        """Mock a remote source adapter with a configurable change feed."""

        class _Source:
            def __init__(self, pid, payload):
                self.platform_id = pid
                self._changes = list(payload)
                self.fetch_calls: list[dict] = []

            async def fetch_remote_changes(
                self, *, since, owner="", repo="",
            ):
                self.fetch_calls.append({
                    "since": since, "owner": owner, "repo": repo,
                })
                return list(self._changes)

        return _Source(platform_id, changes)

    @staticmethod
    def _stub_canonical():
        """Mock a canonical adapter with apply_remote_change. The mock
        records each change applied; configurable conflict-mode lets
        the test return ImportConflict for specific operations."""
        from forge_manager_mcp.adapters.types import ImportConflict

        class _Canonical:
            def __init__(self):
                self.platform_id = "local"
                self.applied: list = []
                self.conflict_on_op: str | None = None

            async def apply_remote_change(self, change):
                if self.conflict_on_op and change.operation == self.conflict_on_op:
                    return ImportConflict(
                        change=change,
                        reason="synthetic conflict for test",
                    )
                self.applied.append(change)
                return None

        return _Canonical()

    @pytest.mark.asyncio
    async def test_routes_changes_from_source_to_canonical(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        change = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
            payload={"new_body": "imported"},
        )

        canonical = self._stub_canonical()
        source = self._stub_source("github", [change])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert report.applied[0].operation == "update_body"
        assert report.conflicts == []
        assert canonical.applied == [change]
        # Source got the right since/owner/repo.
        assert source.fetch_calls[0]["since"] == ts

    @pytest.mark.asyncio
    async def test_conflicts_route_to_conflicts_list(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        clean = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
        )
        conflicting = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="close_issue", observed_at=ts,
        )

        canonical = self._stub_canonical()
        canonical.conflict_on_op = "close_issue"
        source = self._stub_source("github", [clean, conflicting])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert len(report.conflicts) == 1
        assert report.conflicts[0].change.operation == "close_issue"

    @pytest.mark.asyncio
    async def test_unknown_source_platform_raises(self):
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(KeyError, match="bitbucket"):
            await manager.import_remote_changes(
                source_platform_id="bitbucket",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_as_source_raises(self):
        """Importing from the canonical itself is a programmer error
        — the canonical is the sink, not a remote source."""
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(ValueError, match="canonical adapter"):
            await manager.import_remote_changes(
                source_platform_id="local",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_without_apply_method_raises(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no apply_remote_change.
        canonical = _MockAdapter("local")
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="apply_remote_change"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_source_not_implemented_propagates(self):
        from datetime import datetime, timezone

        class _UnimplementedSource:
            platform_id = "github"
            async def fetch_remote_changes(self, *, since, owner="", repo=""):
                raise NotImplementedError("no fetch implementation yet")

        canonical = self._stub_canonical()
        source = _UnimplementedSource()
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="no fetch"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )


class TestBackgroundMirrorMode:
    """(#368) Async mirror fan-out: canonical succeeds → write returns
    immediately; mirror outcomes publish via the broadcaster. Eliminates
    the ReadTimeout false-positive class that was burying successful
    canonical writes in `.claude/pending-posts.md` whenever a remote
    mirror was slow / failing."""

    def _capture(self):
        events: list[tuple[str, dict]] = []

        def publisher(event_name: str, data: dict) -> None:
            events.append((event_name, data))

        return events, publisher

    async def _drain(self, ticks: int = 5) -> None:
        """Yield control so background tasks scheduled via
        ``asyncio.create_task`` can run + publish their events."""
        import asyncio
        for _ in range(ticks):
            await asyncio.sleep(0)

    @pytest.mark.asyncio
    async def test_canonical_returns_with_empty_mirror_warnings(self):
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )

        assert result.value == "local-ok"
        # Mirror warnings empty in background mode — outcomes flow via
        # broadcaster events, not the response envelope.
        assert result.mirror_warnings == ()
        await self._drain()

    @pytest.mark.asyncio
    async def test_background_mirror_actually_runs(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        _, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        # Mirror was eventually called even though write() returned
        # before the mirror completed.
        assert mirror.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_publishes_mirror_completed_for_success(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        completed = [e for e in events if e[0] == "mirror.completed"]
        assert len(completed) == 1
        assert completed[0][1] == {
            "platform_id": "mirror",
            "operation_name": "create_issue",
        }

    @pytest.mark.asyncio
    async def test_publishes_mirror_failed_for_failure(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter(
            "mirror",
            fail_with=_adapter_errors.ForgeUnavailableError("mirror-down"),
        )
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        failed = [e for e in events if e[0] == "mirror.failed"]
        assert len(failed) == 1
        payload = failed[0][1]
        assert payload["platform_id"] == "mirror"
        assert payload["operation_name"] == "create_issue"
        assert payload["error_type"] == "ForgeUnavailableError"
        assert "mirror-down" in payload["error_message"]

    @pytest.mark.asyncio
    async def test_publishes_fan_out_complete_summary(self):
        local = _MockAdapter("local")
        mirror_a = _MockAdapter("mirror_a")
        mirror_b = _MockAdapter(
            "mirror_b",
            fail_with=_adapter_errors.ForgeUnavailableError("b-down"),
        )
        m = _manager_with(local, mirror_a, mirror_b)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        summary = [e for e in events if e[0] == "mirror.fan_out_complete"]
        assert len(summary) == 1
        assert summary[0][1] == {
            "operation_name": "create_issue",
            "success_count": 1,
            "failure_count": 1,
        }

    @pytest.mark.asyncio
    async def test_canonical_failure_still_raises_in_background_mode(self):
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.ForgeError("canonical-down"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        _, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        with pytest.raises(ReplicationWriteError):
            await m.write(
                lambda a, _: a.some_op(), operation_name="create_issue",
            )
        # Mirror was NOT scheduled — canonical fatality preserved.
        assert mirror.calls == []

    @pytest.mark.asyncio
    async def test_publisher_exception_does_not_crash_background_task(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)

        def bad_publisher(event_name, data):
            raise RuntimeError("publisher exploded")

        m.set_background_mirror_mode(publisher=bad_publisher)

        # Should not raise — the publisher exception is swallowed.
        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

    @pytest.mark.asyncio
    async def test_no_publisher_is_acceptable(self):
        # Background mode should work even when no publisher is set
        # (the daemon may construct without one before wiring later).
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        m.set_background_mirror_mode(publisher=None)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()
        assert mirror.calls == ["some_op"]


# (#428 / 3.12.0 D-Coverage drain) Edge-path tests for the small
# helpers / setter / KeyError branches.


class TestSetOnCanonicalWriteSetter:
    def test_setter_replaces_callback(self):
        # set_on_canonical_write is the post-construction hook setter
        # that lets the daemon (D3a+) attach its live-update channel.
        m = _manager_with(_MockAdapter("local"))
        called = []
        m.set_on_canonical_write(
            lambda op_name, value: called.append(op_name)
        )
        # The hook is on the internal attribute — verify the setter
        # actually mutated the manager's state.
        assert m._on_canonical_write is not None


# (#23 A.5 OQ2 / 3.15.0) TestPendingCountUnknownPlatform RETIRED —
# pending_count method retired with the queue.


class TestCanonicalStorePath:
    def test_returns_none_when_no_entries(self):
        # Empty-manager construction is rejected, but the no-entries
        # branch is defensible against a hypothetical empty state.
        # Build via __new__ to bypass the constructor validation.
        from forge_manager_mcp.replication.manager import ReplicationManager
        m = object.__new__(ReplicationManager)
        m._entries = []
        assert m.canonical_store_path() is None

    def test_returns_none_when_canonical_has_no_path_attr(self):
        from types import SimpleNamespace
        adapter = SimpleNamespace(platform_id="x")  # no .path
        m = _manager_with(adapter)
        assert m.canonical_store_path() is None

    def test_returns_path_when_canonical_has_str_path(self, tmp_path):
        from types import SimpleNamespace
        adapter = SimpleNamespace(platform_id="x", path=str(tmp_path))
        m = _manager_with(adapter)
        from pathlib import Path
        result = m.canonical_store_path()
        assert isinstance(result, Path)
        assert result == tmp_path

    def test_returns_path_when_canonical_has_Path_path(self, tmp_path):
        from types import SimpleNamespace
        adapter = SimpleNamespace(platform_id="x", path=tmp_path)
        m = _manager_with(adapter)
        # Already a Path → no conversion.
        assert m.canonical_store_path() is tmp_path


# (#23 A.5 OQ1 / 3.15.0) TestReconcileUnknownPlatform RETIRED with
# the pause/resume methods. mark_healthy still has its KeyError test
# at TestMarkStateMethods.test_mark_unknown_platform_raises.


class TestRehydrateBadStateValue:
    def test_invalid_state_string_in_persisted_state_is_skipped(
        self, tmp_path,
    ):
        # Persisted state file with an invalid AdapterState string →
        # persistence._parse_entry drops the entry at the validation
        # gate, so the manager's rehydrate loop never sees it.
        # In-memory state stays at default HEALTHY.
        import json
        state_path = tmp_path / "replication-state.json"
        state_path.write_text(
            json.dumps({
                "schema_version": 1,
                "entries": [
                    {
                        "platform_id": "local",
                        "state": "NOT_A_REAL_STATE",  # invalid
                        "state_changed_at": "2026-05-11T10:00:00+00:00",
                        "last_error_at": None,
                        "next_attempt_at": None,
                        "last_error_type": None,
                        "last_error_message": None,
                    },
                ],
            }),
        )
        adapter = _MockAdapter("local")
        m = ReplicationManager(
            [("local", adapter)], state_dir=tmp_path,
        )
        # Default-HEALTHY survives because the entry was dropped.
        assert m.states()["local"] == AdapterState.HEALTHY


# ---------------------------------------------------------------------------
# (#428 / 3.12.0 D-Coverage drain) Edge-branch coverage.
# ---------------------------------------------------------------------------


class TestEntriesAccessor:
    def test_entries_returns_pairs_in_canonical_first_order(self):
        a_local = _MockAdapter("local")
        a_github = _MockAdapter("github")
        m = _manager_with(a_local, a_github)
        pairs = m.entries()
        assert pairs == [("local", a_local), ("github", a_github)]


# (#23 A.5 OQ3 / 3.15.0) TestMarkReconcilingUnknownPlatform RETIRED —
# mark_reconciling method retired with the RECONCILING enum value.


class TestImportRemoteChangesInvalidArtifactRef:
    @pytest.mark.asyncio
    async def test_invalid_artifact_ref_change_skipped(self):
        # Canonical adapter's apply_remote_change raising
        # InvalidArtifactRefError → that change goes to `skipped`,
        # subsequent changes still apply. L1151-1153.
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.errors import (
            InvalidArtifactRefError,
        )
        from forge_manager_mcp.adapters.types import (
            ArtifactRef, RemoteChange,
        )

        ref_a = ArtifactRef(
            platform_id="github", native_id="issues/1",
            kind="issue", owner="o", repo="r", number=1,
        )
        ref_b = ArtifactRef(
            platform_id="github", native_id="issues/2",
            kind="issue", owner="o", repo="r", number=2,
        )
        now = datetime.now(timezone.utc)
        bad = RemoteChange(
            source_platform_id="github", ref=ref_a,
            operation="update_body", observed_at=now, payload={},
        )
        ok = RemoteChange(
            source_platform_id="github", ref=ref_b,
            operation="update_body", observed_at=now, payload={},
        )

        canonical = _MockAdapter("local")
        call_count = [0]

        async def _apply(change):
            call_count[0] += 1
            if call_count[0] == 1:
                raise InvalidArtifactRefError("artifact_ref", "bad-ref-value")
            return None

        canonical.apply_remote_change = _apply

        source = _MockAdapter("github")

        async def _fetch(*, since, owner="", repo=""):
            return [bad, ok]

        source.fetch_remote_changes = _fetch

        m = _manager_with(canonical, source)
        report = await m.import_remote_changes(
            source_platform_id="github", since=now,
        )
        assert len(report.skipped) == 1
        assert len(report.applied) == 1


class TestRunMirrorFanoutAndPublishEdgeBranches:
    def _capture(self):
        events: list[tuple[str, dict]] = []

        def publisher(event_name: str, data: dict) -> None:
            events.append((event_name, data))

        return events, publisher

    async def _drain(self, ticks: int = 5) -> None:
        import asyncio
        for _ in range(ticks):
            await asyncio.sleep(0)

    @pytest.mark.asyncio
    async def test_fanout_exception_returns_silently(self, monkeypatch):
        # _run_mirror_fanout raises → outer try/except swallows and
        # returns; no events published. L836-837.
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        async def _boom(*args, **kwargs):
            raise RuntimeError("simulated fanout failure")

        monkeypatch.setattr(m, "_run_mirror_fanout", _boom)
        await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        await self._drain()
        # No mirror.failed / mirror.completed events because the
        # fan-out crashed before they could be emitted.
        assert events == []

    @pytest.mark.asyncio
    async def test_publisher_exception_during_mirror_failed_swallowed(self):
        # Publisher raises when emitting mirror.failed → swallowed,
        # subsequent fan_out_complete still emits. L854-855.
        local = _MockAdapter("local")
        mirror = _MockAdapter(
            "mirror",
            fail_with=_adapter_errors.ForgeUnavailableError("down"),
        )
        m = _manager_with(local, mirror)
        events: list[tuple[str, dict]] = []

        def _pub(name, data):
            if name == "mirror.failed":
                raise RuntimeError("publisher crashed")
            events.append((name, data))

        m.set_background_mirror_mode(publisher=_pub)
        await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        await self._drain()
        # fan_out_complete still landed (not mirror.failed since it
        # crashed the publisher).
        assert any(e[0] == "mirror.fan_out_complete" for e in events)


# (#23 A.5 OQ2 / 3.15.0) TestReplayPendingForgeUnavailableProbe
# RETIRED — replay_pending_writes retired with the queue.


class TestComputeDriftsCanonicalLacksSnapshot:
    @pytest.mark.asyncio
    async def test_raises_type_error_when_canonical_has_no_snapshot(self):
        # canonical adapter lacks snapshot method → L1052 raise.
        local = _MockAdapter("local")
        # Remove snapshot attribute set up by _MockAdapter (if any) and
        # ensure attribute is absent.
        if hasattr(local, "snapshot"):
            delattr(local, "snapshot")
        m = _manager_with(local)
        with pytest.raises(TypeError, match="snapshot"):
            await m.compute_drifts(owner="o", repo="r")


class TestComputeDriftsUnavailableCatch:
    """(#23 A.5 OQ2 / 3.15.0) DEGRADED skip retired; failures during
    compute_drift now record last_error but don't filter the next
    iteration."""

    @pytest.mark.asyncio
    async def test_forge_unavailable_during_compute_drift_records_error(
        self,
    ):
        local = _MockAdapter("local")

        async def _snapshot(**kw):
            return {"artifacts": []}

        local.snapshot = _snapshot
        mirror = _MockAdapter("mirror")

        async def _compute_drift(snap):
            raise _adapter_errors.ForgeUnavailableError("down")

        mirror.compute_drift = _compute_drift
        m = _manager_with(local, mirror)
        result = await m.compute_drifts(owner="o", repo="r")
        # Mirror's compute_drift raised → excluded from result.
        assert "mirror" not in result
        # last_error recorded for /backends health derivation.
        assert m._entries[1].last_error is not None


class TestComputeDriftsSinceBranch:
    @pytest.mark.asyncio
    async def test_since_parameter_passed_to_snapshot(self):
        # `if since is not None: snapshot_kwargs["since"] = since` —
        # L1057-1058. Verify the kwarg reaches snapshot when set.
        from datetime import datetime, timezone

        captured_kwargs: dict = {}

        local = _MockAdapter("local")

        async def _snapshot(**kwargs):
            captured_kwargs.update(kwargs)
            return {"artifacts": []}

        local.snapshot = _snapshot
        mirror = _MockAdapter("mirror")

        async def _compute_drift(snap):
            return {"drift": []}

        mirror.compute_drift = _compute_drift

        m = _manager_with(local, mirror)
        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        await m.compute_drifts(owner="o", repo="r", since=cutoff)
        assert captured_kwargs.get("since") == cutoff


# ---------------------------------------------------------------------------
# (#470 sub-fix 2a) Canonical-write does NOT auto-DEGRADE on caller-fault
# ---------------------------------------------------------------------------


class TestCanonicalDegradeGating:
    """Pre-#470 sub-fix 2a, ``_run_canonical_write`` caught every
    exception and unconditionally transitioned the canonical adapter
    to DEGRADED. The sticky-DEGRADED bug filed in #470 was the
    visible symptom: a single create_milestone targeting an existing
    milestone tripped the canonical to DEGRADED for ~12h. Fix:
    predicate-gate the transition on ``is_forge_unavailable(exc)``;
    caller-fault exceptions still raise ``ReplicationWriteError``
    but the adapter stays HEALTHY.
    """

    @pytest.mark.asyncio
    async def test_already_exists_does_NOT_degrade_canonical(self):
        # Direct regression for the #470 root cause.
        already = _adapter_errors.LocalStoreAlreadyExistsError(
            "milestone already exists",
            artifact_kind="milestone",
            artifact_id="3.13.0",
        )
        local = _MockAdapter("local", fail_with=already)
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError):
            await m.write(
                lambda a, _: a.some_op(), operation_name="create_milestone",
            )
        # CRITICAL: state stays HEALTHY. Pre-fix this was DEGRADED.
        assert m.states()["local"] == AdapterState.HEALTHY, (
            "LocalStoreAlreadyExistsError must NOT transition canonical "
            "to DEGRADED — caller-fault, not adapter outage (#470 2a)"
        )
        assert m._entries[0].last_error is None
        # Mirror never attempted — canonical failure short-circuits.
        assert mirror.calls == []

    @pytest.mark.asyncio
    async def test_invalid_artifact_ref_does_NOT_degrade_canonical(self):
        # Same shape: other caller-fault errors keep canonical HEALTHY.
        bad_ref = _adapter_errors.InvalidArtifactRefError("ref", "stale")
        local = _MockAdapter("local", fail_with=bad_ref)
        m = _manager_with(local, _MockAdapter("mirror"))
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op())
        assert m.states()["local"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_forge_unavailable_DOES_degrade_canonical(self):
        # Regression guard: the predicate-gate must STILL transition
        # canonical to DEGRADED on classified-unavailable errors.
        # (Pre-existing test_canonical_failure_is_fatal covers this
        # case in its own scope; this test makes the contract
        # explicit in the new gating class.)
        offline = _adapter_errors.ForgeUnavailableError("offline")
        local = _MockAdapter("local", fail_with=offline)
        m = _manager_with(local, _MockAdapter("mirror"))
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op())
        # (#23 A.5 OQ2) DEGRADED retired; assertion deleted.
        # was: assert m.states()["local"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_replication_write_error_still_raises_on_already_exists(self):
        # The caller still sees the failure — we just don't poison
        # adapter state. ReplicationWriteError wraps the original
        # exception so caller can inspect via __cause__.
        already = _adapter_errors.LocalStoreAlreadyExistsError(
            "dup",
            artifact_kind="milestone",
            artifact_id="3.13.0",
        )
        local = _MockAdapter("local", fail_with=already)
        m = _manager_with(local)
        with pytest.raises(ReplicationWriteError) as exc_info:
            await m.write(
                lambda a, _: a.some_op(), operation_name="create_milestone",
            )
        assert exc_info.value.__cause__ is already
        assert exc_info.value.platform_id == "local"
        assert exc_info.value.operation == "create_milestone"



if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
