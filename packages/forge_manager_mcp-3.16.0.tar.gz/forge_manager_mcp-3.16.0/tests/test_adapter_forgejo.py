"""Unit tests for ForgejoAdapter (3.0 / Phase 3 sub-run A).

Covers:
  - platform_id ClassVar + per-instance override (codeberg / forgejo)
  - from_config token-file resolution and clear errors
  - shape converters (issue / discussion / comment / milestone)
  - _normalize_category / _category_from_labels round-trip
  - _parse_iso edge cases
  - probe() returns False on classified-unavailable status

Live integration (real HTTP against localhost:3000 / codeberg.org) is
covered by the cross-adapter conformance suite (sub-run D, parameterized
per-backend).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters.forgejo import (
    CODEBERG_API_BASE,
    ForgejoAdapter,
    _FORGEJO_DISCUSSION_LABELS,
    _FORGEJO_STANDARD_LABELS,
    _category_from_labels,
    _comment_from_api,
    _discussion_from_issue,
    _issue_from_api,
    _make_ref,
    _milestone_from_api,
    _normalize_category,
    _parse_iso,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_default_classvar(self):
        assert ForgejoAdapter.platform_id == "forgejo"

    def test_instance_codeberg_override(self):
        adapter = ForgejoAdapter(
            token="t", api_base=CODEBERG_API_BASE, platform_id="codeberg",
        )
        assert adapter.platform_id == "codeberg"

    def test_instance_forgejo_default(self):
        adapter = ForgejoAdapter(token="t", api_base="http://x")
        assert adapter.platform_id == "forgejo"


# ---------------------------------------------------------------------------
# from_config
# ---------------------------------------------------------------------------

class TestFromConfig:
    def test_codeberg_uses_hosted_url(self, tmp_path: Path):
        token_file = tmp_path / ".codeberg-token"
        token_file.write_text("ABC123\n")
        adapter = ForgejoAdapter.from_config({
            "id": "codeberg",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "codeberg"
        assert adapter._api_base == CODEBERG_API_BASE
        assert adapter._token == "ABC123"

    def test_forgejo_self_hosted_uses_url(self, tmp_path: Path):
        token_file = tmp_path / ".forgejo-token"
        token_file.write_text("XYZ\n")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "url": "http://localhost:3000",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "forgejo"
        assert adapter._api_base == "http://localhost:3000"
        assert adapter._token == "XYZ"

    def test_forgejo_default_url_when_unset(self, tmp_path: Path):
        token_file = tmp_path / ".forgejo-token"
        token_file.write_text("Y\n")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "http://localhost:3000"

    def test_unsupported_platform_id_raises(self, tmp_path: Path):
        with pytest.raises(_errors.ForgeError, match="unsupported platform_id"):
            ForgejoAdapter.from_config({"id": "github"})

    def test_missing_token_file_raises(self, tmp_path: Path, monkeypatch):
        # No env vars + nonexistent token_path + nonexistent default → no token
        monkeypatch.delenv("CODEBERG_TOKEN", raising=False)
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # no ~/.codeberg-token here
        with pytest.raises(_errors.ForgeError, match="no token found"):
            ForgejoAdapter.from_config({
                "id": "codeberg",
                "token_path": str(tmp_path / "nonexistent"),
            })

    def test_empty_token_file_raises(self, tmp_path: Path, monkeypatch):
        # Empty token_path file, no env, no fallback → no token
        monkeypatch.delenv("CODEBERG_TOKEN", raising=False)
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))
        token_file = tmp_path / "empty"
        token_file.write_text("   \n")
        with pytest.raises(_errors.ForgeError, match="no token found"):
            ForgejoAdapter.from_config({
                "id": "codeberg",
                "token_path": str(token_file),
            })

    def test_strips_trailing_slash_from_url(self, tmp_path: Path):
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "url": "http://localhost:3000/",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "http://localhost:3000"


# ---------------------------------------------------------------------------
# Shape converters
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            platform_id="forgejo",
            native_id="42",
            kind="issue",
            owner="o",
            repo="r",
            number=7,
        )
        assert ref.platform_id == "forgejo"
        assert ref.native_id == "42"
        assert ref.kind == "issue"
        assert ref.number == 7

    def test_codeberg_platform_id(self):
        ref = _make_ref(
            platform_id="codeberg",
            native_id="99",
            kind="discussion",
            owner="o",
            repo="r",
            number=3,
        )
        assert ref.platform_id == "codeberg"


class TestIssueFromApi:
    def test_minimal(self):
        d = {
            "id": 1, "number": 7, "title": "t", "body": "b",
            "state": "open",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert isinstance(issue, Issue)
        assert issue.ref.number == 7
        assert issue.ref.native_id == "1"
        assert issue.ref.platform_id == "forgejo"
        assert issue.title == "t"
        assert issue.state == "open"
        assert issue.labels == []

    def test_closed_state(self):
        d = {"id": 2, "number": 1, "title": "x", "body": "", "state": "closed"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.state == "closed"

    def test_label_objects_become_names(self):
        d = {
            "id": 3, "number": 1, "title": "t", "body": "",
            "state": "open",
            "labels": [
                {"id": 1, "name": "kind:bug", "color": "ff0000"},
                {"id": 2, "name": "priority:high", "color": "0e8a16"},
            ],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.labels == ["kind:bug", "priority:high"]

    def test_label_strings_pass_through(self):
        d = {
            "id": 4, "number": 2, "title": "t", "body": "",
            "state": "open",
            "labels": ["kind:rfc", "status:wip"],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.labels == ["kind:rfc", "status:wip"]

    def test_milestone_dict_extracts_title(self):
        d = {
            "id": 5, "number": 3, "title": "t", "body": "",
            "state": "open",
            "milestone": {"id": 1, "title": "v1.0", "state": "open"},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.milestone == "v1.0"

    def test_milestone_none(self):
        d = {
            "id": 6, "number": 4, "title": "t", "body": "",
            "state": "open", "milestone": None,
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.milestone is None

    def test_user_login_becomes_author(self):
        d = {
            "id": 7, "number": 5, "title": "t", "body": "",
            "state": "open",
            "user": {"login": "alice", "id": 100},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.author == "alice"

    def test_html_url_becomes_url(self):
        d = {
            "id": 8, "number": 6, "title": "t", "body": "",
            "state": "open",
            "html_url": "https://codeberg.org/o/r/issues/6",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.url == "https://codeberg.org/o/r/issues/6"

    def test_iso_timestamps_parsed(self):
        d = {
            "id": 9, "number": 7, "title": "t", "body": "",
            "state": "open",
            "created_at": "2026-04-29T12:00:00Z",
            "updated_at": "2026-04-29T13:00:00Z",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.created_at is not None
        assert issue.created_at.year == 2026
        assert issue.updated_at is not None


class TestDiscussionFromIssue:
    def test_re_emits_ref_with_discussion_kind(self):
        issue = _issue_from_api(
            {
                "id": 1, "number": 7, "title": "t", "body": "b",
                "state": "open",
                "labels": [{"id": 1, "name": "kind:discussion"}],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.ref.kind == "discussion"
        assert disc.ref.number == 7
        assert disc.title == "t"
        assert disc.body == "b"

    def test_decided_label_lifts_to_decided_field(self):
        issue = _issue_from_api(
            {
                "id": 2, "number": 1, "title": "t", "body": "",
                "state": "open",
                "labels": [
                    {"id": 1, "name": "kind:discussion"},
                    {"id": 2, "name": "decided"},
                ],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is True

    def test_no_decided_label(self):
        issue = _issue_from_api(
            {
                "id": 3, "number": 2, "title": "t", "body": "",
                "state": "open",
                "labels": [{"id": 1, "name": "kind:discussion"}],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is False

    def test_category_pass_through(self):
        issue = _issue_from_api(
            {"id": 4, "number": 1, "title": "t", "body": "", "state": "open"},
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category="Architecture")
        assert disc.category == "Architecture"


class TestCommentFromApi:
    def test_basic(self):
        parent = ArtifactRef(
            platform_id="forgejo", native_id="1", kind="issue",
            owner="o", repo="r", number=7,
        )
        d = {
            "id": 100, "body": "first",
            "user": {"login": "bob"},
            "created_at": "2026-04-29T10:00:00Z",
        }
        comment = _comment_from_api(d, parent=parent, platform_id="forgejo")
        assert isinstance(comment, Comment)
        assert comment.body == "first"
        assert comment.author == "bob"
        assert comment.parent.kind == "issue"
        assert comment.parent.number == 7
        assert comment.ref.kind == "comment"
        assert comment.ref.number is None  # comments have no repo-scoped number

    def test_falls_back_to_now_on_missing_created_at(self):
        parent = ArtifactRef(
            platform_id="forgejo", native_id="1", kind="issue",
            owner="o", repo="r", number=1,
        )
        d = {"id": 1, "body": "x", "user": {"login": "u"}}
        comment = _comment_from_api(d, parent=parent, platform_id="forgejo")
        # Just verify it's a recent UTC datetime; tolerate clock skew.
        assert comment.created_at.tzinfo is not None


class TestMilestoneFromApi:
    def test_basic(self):
        d = {"id": 1, "title": "v1.0", "state": "open", "description": "first"}
        m = _milestone_from_api(d)
        assert isinstance(m, Milestone)
        assert m.title == "v1.0"
        assert m.number == 1
        assert m.state == "open"
        assert m.description == "first"

    def test_closed_state(self):
        d = {"id": 2, "title": "v2.0", "state": "closed"}
        m = _milestone_from_api(d)
        assert m.state == "closed"


class TestNormalizeCategory:
    def test_lowercase(self):
        assert _normalize_category("Architecture") == "architecture"

    def test_spaces_become_underscores(self):
        assert _normalize_category("UX UI") == "ux_ui"

    def test_slash_compound_collapses(self):
        assert _normalize_category("UX / UI") == "ux_ui"


class TestCategoryFromLabels:
    def test_finds_first(self):
        assert _category_from_labels([
            "kind:discussion", "category:architecture", "decided",
        ]) == "architecture"

    def test_returns_none_when_absent(self):
        assert _category_from_labels(["kind:discussion", "decided"]) is None


class TestParseIso:
    def test_z_suffix(self):
        result = _parse_iso("2026-04-29T12:00:00Z")
        assert result is not None
        assert result.year == 2026
        assert result.month == 4

    def test_offset(self):
        result = _parse_iso("2026-04-29T12:00:00+00:00")
        assert result is not None

    def test_none_returns_none(self):
        assert _parse_iso(None) is None

    def test_empty_string_returns_none(self):
        assert _parse_iso("") is None

    def test_garbage_returns_none(self):
        assert _parse_iso("not a timestamp") is None

    def test_non_string_returns_none(self):
        assert _parse_iso(12345) is None


# ---------------------------------------------------------------------------
# _request error classification — uses MockTransport so we don't open
# real sockets. Verifies the unavailable-vs-caller-fault split.
# ---------------------------------------------------------------------------

def _adapter_with_mock(handler) -> ForgejoAdapter:
    """Build an adapter whose httpx client uses a MockTransport."""
    adapter = ForgejoAdapter(
        token="fake", api_base="http://forgejo.test", platform_id="forgejo",
    )
    adapter._client = httpx.AsyncClient(
        base_url=f"{adapter._api_base}/api/v1",
        transport=httpx.MockTransport(handler),
        headers=adapter._headers(),
    )
    return adapter


class TestRequestErrorClassification:
    @pytest.mark.asyncio
    async def test_5xx_raises_forge_unavailable(self):
        def handler(req):
            return httpx.Response(503, text="upstream broken")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeUnavailableError) as exc_info:
                await adapter._request("GET", "/version")
            assert exc_info.value.status_code == 503
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_403_raises_forge_unavailable(self):
        def handler(req):
            return httpx.Response(403, text="suspended")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeUnavailableError):
                await adapter._request("GET", "/version")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_with_allow_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request(
                "GET", "/repos/x/y/issues/9999", allow_404_as_none=True,
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_without_allow_raises_forge_error(self):
        def handler(req):
            return httpx.Response(404, text="nope")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeError) as exc_info:
                await adapter._request("GET", "/repos/x/y")
            # 404 is caller-fault, so NOT classified as unavailable.
            assert not isinstance(exc_info.value, _errors.ForgeUnavailableError)
            assert exc_info.value.status_code == 404
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_422_raises_forge_error_not_unavailable(self):
        def handler(req):
            return httpx.Response(422, text="validation")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeError) as exc_info:
                await adapter._request("POST", "/repos/x/y/issues", json={})
            assert exc_info.value.status_code == 422
            assert not isinstance(exc_info.value, _errors.ForgeUnavailableError)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_204_returns_none(self):
        def handler(req):
            return httpx.Response(204)
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request(
                "DELETE", "/repos/x/y/issues/1/labels/3",
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_2xx_json_parses(self):
        def handler(req):
            return httpx.Response(200, json={"version": "13.0.4"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request("GET", "/version")
            assert result == {"version": "13.0.4"}
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. Forgejo's REST API
    is number-based, so the implementation requires ref.number to be
    populated; node-ID-only refs from other adapters surface a clear
    InvalidArtifactRefError."""

    @pytest.mark.asyncio
    async def test_get_issue_body_returns_body_on_200(self):
        def handler(req):
            return httpx.Response(200, json={
                "number": 7, "body": "current body content",
                "title": "t", "user": {"login": "u"},
                "labels": [], "state": "open", "comments": 0,
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "html_url": "http://forgejo.test/x/y/issues/7",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#7",
                kind="issue", owner="x", repo="y", number=7,
            )
            body = await adapter.get_issue_body(ref)
            assert body == "current body content"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_404_raises_invalid_ref(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#9999",
                kind="issue", owner="x", repo="y", number=9999,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_number_raises(self):
        """Cross-adapter ref without ref.number → can't be resolved
        via Forgejo REST. InvalidArtifactRefError surfaces a clear
        diagnostic."""
        def handler(req):
            return httpx.Response(500, text="should never be called")
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="github", native_id="I_kwDO_xx",
                kind="issue", owner="x", repo="y", number=None,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_body_uses_same_endpoint(self):
        """Forgejo models Discussions as Issues — get_discussion_body
        delegates to get_issue_body."""
        def handler(req):
            return httpx.Response(200, json={
                "number": 9, "body": "discussion body",
                "title": "d", "user": {"login": "u"},
                "labels": [{"name": "kind:discussion"}],
                "state": "open", "comments": 0,
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "html_url": "http://forgejo.test/x/y/issues/9",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#9",
                kind="discussion", owner="x", repo="y", number=9,
            )
            body = await adapter.get_discussion_body(ref)
            assert body == "discussion body"
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# probe()
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_returns_true_on_version_response(self):
        def handler(req):
            return httpx.Response(200, json={"version": "13.0.4"})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_503(self):
        def handler(req):
            return httpx.Response(503, text="down")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_403(self):
        def handler(req):
            return httpx.Response(403, text="auth")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# Header construction
# ---------------------------------------------------------------------------

class TestHeaders:
    def test_token_auth_header(self):
        adapter = ForgejoAdapter(
            token="ABC123", api_base="http://x", platform_id="forgejo",
        )
        headers = adapter._headers()
        # Forgejo/Gitea uses 'token <T>', not GitHub's 'Bearer <T>'.
        assert headers["Authorization"] == "token ABC123"
        assert headers["Accept"] == "application/json"
        assert headers["Content-Type"] == "application/json"


# ---------------------------------------------------------------------------
# compute_drift stub
# ---------------------------------------------------------------------------

class TestComputeDrift:
    @pytest.mark.asyncio
    async def test_inconclusive_without_owner_repo_in_snapshot(self):
        # Phase 6 sub-run B: compute_drift now requires owner/repo in
        # the snapshot dict to know which remote project to diff.
        # Empty snapshot → inconclusive report. Comprehensive coverage
        # of the diff logic lives in tests/test_drift_detection.py.
        adapter = ForgejoAdapter(
            token="t", api_base="http://x", platform_id="codeberg",
        )
        report = await adapter.compute_drift({})
        assert report.platform_id == "codeberg"
        assert report.is_clean is False
        assert any("owner/repo" in n for n in report.notes)


class TestRepoVisibility:
    """PAR-3: get_repo_visibility maps Forgejo's boolean ``private`` flag
    onto the Protocol's PUBLIC/PRIVATE/INTERNAL alphabet."""

    @pytest.mark.asyncio
    async def test_public_repo(self):
        def handler(req):
            return httpx.Response(200, json={"id": 1, "private": False})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_private_repo(self):
        def handler(req):
            return httpx.Response(200, json={"id": 1, "private": True})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PRIVATE"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_missing_repo_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()


class TestBootstrapProject:
    """Multi-platform scaffold C3 — ForgejoAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert ForgejoAdapter.has_scaffold is True

    def test_has_session_event_surface_classvar_false(self):
        # Forgejo / Codeberg session-lock surface is comments on the
        # Issues-as-Discussions Project Index Issue, addressed by the
        # handler via append_comment — not a dedicated Protocol surface.
        assert ForgejoAdapter.has_session_event_surface is False

    @pytest.mark.asyncio
    async def test_bootstrap_creates_repo_pair_and_seeds_labels(self):
        seen_calls: list[tuple[str, str]] = []
        labels_created: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path  # full path including /api/v1
            seen_calls.append((method, path))

            # (#467 / #468) Anchor-issue search must be matched BEFORE
            # the generic repo-probe (which uses path.startswith and
            # would otherwise swallow /issues paths). Search returns
            # empty for greenfield bootstrap → triggers POST /issues
            # in the next branch.
            if method == "GET" and path.endswith("/issues"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/issues"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                next_num = (
                    100 if "Session Lock" in body.get("title", "")
                    else 101
                )
                return httpx.Response(201, json={
                    "id": next_num + 1000,
                    "number": next_num,
                    "title": body.get("title", ""),
                    "body": body.get("body", ""),
                    "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": (
                            "category:claude-use-only"
                            if "Session Lock" in body.get("title", "")
                            else "category:Announcements"
                        )},
                    ],
                    "html_url": (
                        f"http://forgejo.test/myorg/widgets-dev/issues/{next_num}"
                    ),
                })

            # Probe: GET /repos/<owner>/<name> — both repos new (404).
            if method == "GET" and path.startswith("/api/v1/repos/myorg/widgets") \
                    and "/labels" not in path:
                return httpx.Response(404, json={"message": "not found"})

            # Org-namespace repo create succeeds.
            if method == "POST" and path == "/api/v1/orgs/myorg/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 42 if body["name"] == "widgets-dev" else 43,
                    "full_name": f"myorg/{body['name']}",
                    "html_url": f"http://forgejo.test/myorg/{body['name']}",
                    "private": body["private"],
                })

            # Label probe (always-empty paginated list → trigger create).
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                labels_created.append(body["name"])
                return httpx.Response(201, json={"id": len(labels_created)})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets",
                description="widgets project",
            )
        finally:
            await adapter.aclose()

        assert result.platform_id == "forgejo"
        assert result.phase == "complete"
        assert result.manual_steps == []
        assert result.artifacts["dev_repo"]["existed"] is False
        assert result.artifacts["public_repo"]["existed"] is False
        assert result.artifacts["dev_repo"]["full_name"] == "myorg/widgets-dev"
        assert result.artifacts["public_repo"]["full_name"] == "myorg/widgets"
        # forgejo #7 (3.4.0): docs repo joins the trio per #263.
        assert result.artifacts["docs_repo"]["existed"] is False
        assert result.artifacts["docs_repo"]["full_name"] == "myorg/widgets-docs"
        assert result.artifacts["docs_repo"]["html_url"] == (
            "http://forgejo.test/myorg/widgets-docs"
        )
        # (#467 / #468) Anchor Issues seeded with distinct numbers.
        assert result.artifacts["session_lock_issue_number"] == 100
        assert result.artifacts["project_index_issue_number"] == 101

        # Standard labels seeded.
        assert "bug" in labels_created
        assert "rfc" in labels_created
        assert "area:mcp" in labels_created
        # Discussions-as-Issues reserved labels seeded.
        assert "kind:discussion" in labels_created
        assert "category:Architecture" in labels_created
        assert "decided" in labels_created

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent_when_repos_exist(self):
        """Re-running bootstrap when both repos exist no-ops the
        creation (probe returns 200) and reports existed=True. Labels
        still iterate (each ``ensure_label`` no-ops on a present label
        via the repo-labels probe)."""
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            # (#467 / #468) Anchor-issue search: existing matching
            # anchors so idempotent re-bootstrap returns the same
            # numbers without creating duplicates.
            if method == "GET" and path.endswith("/issues"):
                labels_param = req.url.params.get("labels", "")
                if "category:claude-use-only" in labels_param:
                    return httpx.Response(200, json=[{
                        "id": 5001,
                        "number": 100,
                        "title": "widgets — Session Lock",
                        "body": "",
                        "state": "open",
                        "labels": [
                            {"name": "kind:discussion"},
                            {"name": "category:claude-use-only"},
                        ],
                        "html_url": "http://forgejo.test/x",
                    }])
                if "category:Announcements" in labels_param:
                    return httpx.Response(200, json=[{
                        "id": 5002,
                        "number": 101,
                        "title": "widgets — Project",
                        "body": "",
                        "state": "open",
                        "labels": [
                            {"name": "kind:discussion"},
                            {"name": "category:Announcements"},
                        ],
                        "html_url": "http://forgejo.test/y",
                    }])
                return httpx.Response(200, json=[])
            if method == "GET" and "/labels" not in path \
                    and "/issues" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                # Repo exists with required unit flags already correct
                # (post-#9 steady state — units enabled at create time).
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42 if name == "widgets-dev" else 43,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": True,
                    "has_issues": True,
                })
            if method == "GET" and path.endswith("/labels"):
                # Every label already present — return matching by name.
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["dev_repo"]["existed"] is True
        assert result.artifacts["public_repo"]["existed"] is True
        # forgejo #7 (3.4.0): docs repo idempotent on probe.
        assert result.artifacts["docs_repo"]["existed"] is True
        # (#467 / #468) Anchor numbers come from the existing-match
        # search path — no POST /issues attempt.
        assert result.artifacts["session_lock_issue_number"] == 100
        assert result.artifacts["project_index_issue_number"] == 101

    @pytest.mark.asyncio
    async def test_bootstrap_falls_back_to_user_repos_when_org_404s(self):
        """When the owner is a user (not an org), the org-create POST
        returns 404; the adapter falls back to ``POST /user/repos``."""
        org_create_attempts: list[str] = []
        user_create_attempts: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            # (#467 / #468) Anchor-issue handling — match first to avoid
            # the repo-probe's path.startswith swallowing /issues.
            if method == "GET" and path.endswith("/issues"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/issues"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 9999, "number": 100,
                    "title": body.get("title", ""),
                    "body": body.get("body", ""), "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": (
                            "category:claude-use-only"
                            if "Session Lock" in body.get("title", "")
                            else "category:Announcements"
                        )},
                    ],
                    "html_url": "http://forgejo.test/x",
                })
            if method == "GET" and path.startswith("/api/v1/repos/alice/") \
                    and "/labels" not in path:
                return httpx.Response(404, text="not found")
            if method == "POST" and path == "/api/v1/orgs/alice/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                org_create_attempts.append(body["name"])
                return httpx.Response(404, text="org not found")
            if method == "POST" and path == "/api/v1/user/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                user_create_attempts.append(body["name"])
                return httpx.Response(201, json={
                    "id": 99,
                    "full_name": f"alice/{body['name']}",
                    "html_url": f"http://forgejo.test/alice/{body['name']}",
                    "private": body["private"],
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="alice", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        # All three repos went through the user-fallback path.
        # forgejo #7 (3.4.0): docs repo joins the trio per #263.
        assert org_create_attempts == ["widgets-dev", "widgets", "widgets-docs"]
        assert user_create_attempts == ["widgets-dev", "widgets", "widgets-docs"]

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_owner(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="owner"):
                await adapter.bootstrap_project(
                    owner="  ", project_name="widgets", description="",
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_project_name(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="project_name"):
                await adapter.bootstrap_project(
                    owner="myorg", project_name="  ", description="",
                )
        finally:
            await adapter.aclose()

    # ---- forgejo #9: required repo unit flags ---------------------------

    @pytest.mark.asyncio
    async def test_bootstrap_create_payload_enables_required_units(self):
        """#9: create payload must include has_releases=True so freshly-
        scaffolded Codeberg repos accept ``POST /repos/.../releases``
        without requiring a manual PATCH."""
        from forge_manager_mcp.adapters.forgejo import _REQUIRED_UNIT_FLAGS

        create_payloads: list[dict] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            # (#467 / #468) Anchor-issue handling — first to win over
            # the repo-probe path.startswith.
            if method == "GET" and path.endswith("/issues"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/issues"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 9999, "number": 100,
                    "title": body.get("title", ""),
                    "body": body.get("body", ""), "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": (
                            "category:claude-use-only"
                            if "Session Lock" in body.get("title", "")
                            else "category:Announcements"
                        )},
                    ],
                    "html_url": "http://forgejo.test/x",
                })
            if method == "GET" and path.startswith("/api/v1/repos/myorg/widgets") \
                    and "/labels" not in path:
                return httpx.Response(404, text="not found")
            if method == "POST" and path == "/api/v1/orgs/myorg/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                create_payloads.append(body)
                return httpx.Response(201, json={
                    "id": len(create_payloads),
                    "full_name": f"myorg/{body['name']}",
                    "html_url": f"http://forgejo.test/myorg/{body['name']}",
                    "private": body["private"],
                    "has_releases": body.get("has_releases", False),
                    "has_issues": body.get("has_issues", True),
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert len(create_payloads) == 3  # dev + public + docs (#7 / 3.4.0)
        for payload in create_payloads:
            for flag, required in _REQUIRED_UNIT_FLAGS.items():
                assert payload[flag] is required, (
                    f"create payload missing or wrong value for {flag!r}: "
                    f"{payload!r}"
                )

    @pytest.mark.asyncio
    async def test_bootstrap_patches_existing_repo_with_disabled_units(self):
        """#9: probe-found existing repo with diverging unit flags
        triggers a PATCH carrying only the diverging flags. Mid-life
        adoption path — pre-#9 bootstrap or hand-created Codeberg repos."""
        patch_calls: list[tuple[str, dict]] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            # (#467 / #468) Anchor-issue handling first.
            if method == "GET" and path.endswith("/issues"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/issues"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 9999, "number": 100,
                    "title": body.get("title", ""),
                    "body": body.get("body", ""), "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": (
                            "category:claude-use-only"
                            if "Session Lock" in body.get("title", "")
                            else "category:Announcements"
                        )},
                    ],
                    "html_url": "http://forgejo.test/x",
                })
            if method == "GET" and "/labels" not in path \
                    and "/issues" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": False,  # the diverging flag
                    "has_issues": True,
                })
            if method == "PATCH" and path.startswith("/api/v1/repos/myorg/widgets"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                name = path.rsplit("/", 1)[-1]
                patch_calls.append((name, body))
                return httpx.Response(200, json={
                    "id": 42, "has_releases": True, "has_issues": True,
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        # forgejo #7 (3.4.0): docs repo joins the trio.
        assert {name for name, _ in patch_calls} == {
            "widgets-dev", "widgets", "widgets-docs",
        }
        for _, body in patch_calls:
            # Only the diverging flag — has_issues was already True so omitted.
            assert body == {"has_releases": True}

    @pytest.mark.asyncio
    async def test_bootstrap_skips_patch_when_units_already_correct(self):
        """#9: probe-found existing repo whose units already match the
        required state issues no PATCH (pure idempotence)."""
        patch_calls: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            # (#467 / #468) Anchor-issue handling first.
            if method == "GET" and path.endswith("/issues"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/issues"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 9999, "number": 100,
                    "title": body.get("title", ""),
                    "body": body.get("body", ""), "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": (
                            "category:claude-use-only"
                            if "Session Lock" in body.get("title", "")
                            else "category:Announcements"
                        )},
                    ],
                    "html_url": "http://forgejo.test/x",
                })
            if method == "GET" and "/labels" not in path \
                    and "/issues" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": True,
                    "has_issues": True,
                })
            if method == "PATCH":
                patch_calls.append(path)
                return httpx.Response(200, json={})
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert patch_calls == []


class TestIssueWriteDelegation:
    """(#428) Drain ForgejoAdapter issue write paths."""

    @pytest.mark.asyncio
    async def test_create_issue_no_labels_no_milestone(self):
        # (#428) L321-346 — create_issue happy path with no labels.
        def handler(req):
            return httpx.Response(201, json={
                "id": 1, "number": 1, "title": "T", "body": "B",
                "state": "open", "labels": [], "milestone": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_issue(
                owner="o", repo="r", title="T", body="B", labels=[],
            )
            assert result.title == "T"
            assert result.ref.number == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_create_issue_with_unknown_milestone_raises(self):
        # (#428) L330-336 — find_milestone returns None → raise.
        call_count = {"n": 0}

        def handler(req):
            call_count["n"] += 1
            # ensure_label call(s) succeed, then the milestone-by-number
            # GET returns 404.
            if "/milestones/" in req.url.path:
                return httpx.Response(404, text="not found")
            return httpx.Response(404, text="not found")

        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.create_issue(
                    owner="o", repo="r", title="T", body="B",
                    labels=[],
                    milestone=99,  # not found
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_404_raises(self):
        # (#428) L348-355 — 404 → InvalidArtifactRefError.
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue("o", "r", 999)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_issue_body_dispatches_patch(self):
        # (#428) L377-385 — PATCH /issues/{number} with body payload.
        recorded = {}
        def handler(req):
            recorded["method"] = req.method
            recorded["path"] = req.url.path
            return httpx.Response(200, json={"body": "new"})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            await adapter.update_issue_body(ref, "new body")
            assert recorded["method"] == "PATCH"
            assert "/issues/1" in recorded["path"]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_close_issue_returns_closed_issue(self):
        # (#428) L387-402 — PATCH state=closed → returns Issue.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "number": 1, "title": "T", "body": "B",
                "state": "closed", "labels": [], "milestone": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.close_issue(ref)
            assert result.state == "closed"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_remove_label_when_label_not_present(self):
        # (#428) L415-422 — label not present → noop (no DELETE).
        recorded = {"deletes": 0}
        def handler(req):
            if req.method == "DELETE":
                recorded["deletes"] += 1
            # _find_label_id returns label list — empty here.
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            await adapter.remove_label(ref, "nonexistent-label")
            assert recorded["deletes"] == 0
        finally:
            await adapter.aclose()


class TestCreateIssueWithMilestone:
    @pytest.mark.asyncio
    async def test_create_issue_with_resolved_milestone(self):
        # (#428) L331-341 — find_milestone success → payload["milestone"]
        # populated.
        recorded = {"json": None}
        def handler(req):
            if "/milestones/" in req.url.path:
                return httpx.Response(200, json={
                    "id": 5, "title": "v1",
                    "state": "open", "description": "",
                    "closed_issues": 0, "open_issues": 0,
                })
            if req.method == "POST" and req.url.path.endswith("/issues"):
                import json as _json
                recorded["json"] = _json.loads(req.content.decode())
                return httpx.Response(201, json={
                    "id": 1, "number": 1, "title": "T", "body": "B",
                    "state": "open", "labels": [], "milestone": None,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                })
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.create_issue(
                owner="o", repo="r", title="T", body="B",
                labels=[], milestone=5,
            )
            assert recorded["json"]["milestone"] == 5
        finally:
            await adapter.aclose()


class TestSearchIssuesWithResolvedMilestone:
    @pytest.mark.asyncio
    async def test_search_issues_milestone_resolves_title(self):
        # (#428) L449-451 — find_milestone returns ms → milestones param.
        recorded = {"params": None}
        def handler(req):
            # Title-based search → list endpoint.
            if req.url.path.endswith("/milestones"):
                return httpx.Response(200, json=[
                    {
                        "id": 5, "title": "v1.0",
                        "state": "open", "description": "",
                        "closed_issues": 0, "open_issues": 0,
                    },
                ])
            if req.url.path.endswith("/issues"):
                recorded["params"] = dict(req.url.params)
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.search_issues(
                owner="o", repo="r", milestone="v1.0",
            )
            assert recorded["params"].get("milestones") == "v1.0"
        finally:
            await adapter.aclose()


class TestBundleRecoverContextDelegates:
    @pytest.mark.asyncio
    async def test_bundle_recover_context_delegates(self):
        # (#428) L894 — delegates to default helper. Uses MockTransport
        # so the helper makes calls; we just verify it returns.
        def handler(req):
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bundle_recover_context(
                owner="o", repo="r", toc_discussion_id="D_1",
                since_days=7, issue_limit=10,
            )
            assert result is not None
        finally:
            await adapter.aclose()


class TestComputeDriftDiscussionLabels:
    @pytest.mark.asyncio
    async def test_compute_drift_discussion_label_divergence(self):
        # (#428) L996-999 — discussion label set diff.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "number": 5, "state": "open",
                    "labels": [
                        {"name": "kind:discussion"},
                        {"name": "different"},
                    ],
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "discussions": {
                    5: {"state": "open",
                        "labels": ["kind:discussion", "original"]},
                },
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_discussion_state_divergence(self):
        # (#428) L995-997 — discussion state diff (continue branch).
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "number": 7, "state": "closed",
                    "labels": [{"name": "kind:discussion"}],
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "discussions": {
                    7: {"state": "open", "labels": ["kind:discussion"]},
                },
            }
            report = await adapter.compute_drift(local)
            assert 7 in report.discussions_diverged
            assert report.is_clean is False
        finally:
            await adapter.aclose()


class TestPaginateGetEdgeBranchesForgejo:
    @pytest.mark.asyncio
    async def test_non_list_response_breaks_loop(self):
        # (#428) L744-745.
        def handler(req):
            return httpx.Response(200, json={"not": "a list"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._paginate_get("/repos/o/r/issues")
            assert result == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_pagination_continues_on_full_page(self):
        # (#428) L749 — page += 1 when full page.
        recorded = {"page": 0}
        def handler(req):
            recorded["page"] += 1
            if recorded["page"] == 1:
                # First page full (50 items) → loop continues.
                return httpx.Response(200, json=[
                    {"id": i} for i in range(50)
                ])
            # Second page short → break.
            return httpx.Response(200, json=[{"id": 999}])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._paginate_get(
                "/repos/o/r/issues", page_size=50,
            )
            assert len(result) == 51
            assert recorded["page"] >= 2
        finally:
            await adapter.aclose()


class TestRemoveLabelHappyPath:
    @pytest.mark.asyncio
    async def test_remove_label_dispatches_delete_when_present(self):
        # (#428) L423-426 — _find_label_id returns id → DELETE dispatched.
        recorded = {"deletes": 0}
        def handler(req):
            if req.method == "DELETE":
                recorded["deletes"] += 1
                return httpx.Response(204, text="")
            # _find_label_id GET → return label found.
            return httpx.Response(200, json=[{"id": 99, "name": "bug"}])
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            await adapter.remove_label(ref, "bug")
            assert recorded["deletes"] == 1
        finally:
            await adapter.aclose()


class TestPureHelpers:
    """(#428) Drain pure-helper functions in forgejo adapter."""

    def test_issue_number_from_comment_url_valid(self):
        from forge_manager_mcp.adapters.forgejo import (
            _issue_number_from_comment_url,
        )
        url = "https://example.test/api/v1/repos/o/r/issues/42"
        assert _issue_number_from_comment_url(url) == 42

    def test_issue_number_from_comment_url_empty(self):
        from forge_manager_mcp.adapters.forgejo import (
            _issue_number_from_comment_url,
        )
        assert _issue_number_from_comment_url("") is None
        assert _issue_number_from_comment_url(None) is None

    def test_issue_number_from_comment_url_malformed_short(self):
        from forge_manager_mcp.adapters.forgejo import (
            _issue_number_from_comment_url,
        )
        assert _issue_number_from_comment_url("a") is None

    def test_issue_number_from_comment_url_not_an_issue_url(self):
        from forge_manager_mcp.adapters.forgejo import (
            _issue_number_from_comment_url,
        )
        # /pulls/42 path → not "issues" segment → None.
        url = "https://example.test/api/v1/repos/o/r/pulls/42"
        assert _issue_number_from_comment_url(url) is None

    def test_issue_number_from_comment_url_non_numeric_tail(self):
        from forge_manager_mcp.adapters.forgejo import (
            _issue_number_from_comment_url,
        )
        url = "https://example.test/api/v1/repos/o/r/issues/notanumber"
        assert _issue_number_from_comment_url(url) is None


class TestFindLabelIdPagination:
    """(#428) Drain ForgejoAdapter _find_label_id pagination edges."""

    @pytest.mark.asyncio
    async def test_find_label_id_paginates_until_short_page(self):
        # (#428) L713-715 — short page → return None.
        recorded = {"page": 0}
        def handler(req):
            recorded["page"] += 1
            if recorded["page"] == 1:
                # Full page (50 items) without match → continue paginating.
                return httpx.Response(200, json=[
                    {"id": i, "name": f"label-{i}"} for i in range(50)
                ])
            # Page 2: short page → exit.
            return httpx.Response(200, json=[
                {"id": 200, "name": "other"},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._find_label_id(
                owner="o", repo="r", name="missing",
            )
            assert result is None
            assert recorded["page"] >= 2
        finally:
            await adapter.aclose()


class TestProjectBoardNotImplemented:
    """(#428) ForgejoAdapter project-board methods all raise NotImplementedError."""

    @pytest.mark.asyncio
    async def test_add_to_project_board(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        ref = ArtifactRef(
            platform_id="forgejo", native_id="o/r#1",
            kind="issue", owner="o", repo="r", number=1,
        )
        with pytest.raises(NotImplementedError):
            await adapter.add_to_project_board(board_id="b", ref=ref)

    @pytest.mark.asyncio
    async def test_get_project_status_field(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.get_project_status_field(board_id="b")

    @pytest.mark.asyncio
    async def test_get_project_item_id(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        ref = ArtifactRef(
            platform_id="forgejo", native_id="o/r#1",
            kind="issue", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError):
            await adapter.get_project_item_id(ref=ref, board_id="b")

    @pytest.mark.asyncio
    async def test_move_project_item(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.move_project_item(
                board_id="b", item_id="i",
                status_field_id="s", option_id="o",
            )


class TestFetchRemoteChanges:
    """(#428) Drain ForgejoAdapter fetch_remote_changes shape paths."""

    @pytest.mark.asyncio
    async def test_create_issue_shape_when_created_after_since(self):
        from datetime import datetime, timezone
        recorded = {"calls": 0}
        def handler(req):
            recorded["calls"] += 1
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[])
            # First (and only) page: one new issue.
            if recorded["calls"] == 1:
                return httpx.Response(200, json=[{
                    "id": 1, "number": 1, "title": "T", "body": "B",
                    "state": "open", "labels": [], "milestone": None,
                    "created_at": "2026-06-01T00:00:00Z",
                    "updated_at": "2026-06-01T00:00:00Z",
                    "closed_at": None,
                    "pull_request": None,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                }])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            create_changes = [c for c in changes if c.operation == "create_issue"]
            assert len(create_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_close_issue_shape_when_closed_after_since(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[{
                "id": 1, "number": 1, "title": "T", "body": "B",
                "state": "closed", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": "2026-06-02T00:00:00Z",
                "pull_request": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            close_changes = [c for c in changes if c.operation == "close_issue"]
            assert len(close_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_body_default_path(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[{
                "id": 1, "number": 1, "title": "T", "body": "B-new",
                "state": "open", "labels": [], "milestone": None,
                "created_at": "2026-04-01T00:00:00Z",
                "updated_at": "2026-06-02T00:00:00Z",
                "closed_at": None,
                "pull_request": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            }])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            update_changes = [c for c in changes if c.operation == "update_body"]
            assert len(update_changes) == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_pull_request_rows_filtered_out(self):
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[
                {  # PR — should skip
                    "id": 1, "number": 1, "title": "PR", "body": "B",
                    "state": "open", "labels": [], "milestone": None,
                    "created_at": "2026-06-01T00:00:00Z",
                    "updated_at": "2026-06-01T00:00:00Z",
                    "closed_at": None,
                    "pull_request": {"merged": False},
                    "html_url": "http://forgejo.test/o/r/pulls/1",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert len(changes) == 0
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_issues_unreachable_returns_rate_limited_sentinel(self):
        from datetime import datetime, timezone
        def handler(req):
            return httpx.Response(503, text="rate limited")
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert len(changes) == 1
            assert changes[0].operation == "rate_limited"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_comments_unreachable_appends_sentinel(self):
        # (#428) L1332-1334 — issues OK, comments fetch fails →
        # sentinel appended.
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(503, text="comments down")
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert any(c.operation == "rate_limited" for c in changes)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_comments_with_no_issue_url_skipped(self):
        # (#428) L1338-1340 — comment without issue_url → skip.
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[
                    {  # no issue_url → skip
                        "id": 1, "body": "stray", "user": {"login": "x"},
                        "created_at": "2026-06-02T00:00:00Z",
                        "html_url": "http://forgejo.test/comment",
                    },
                ])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            assert len(changes) == 0
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_comments_valid_issue_url_become_add_comment(self):
        # (#428) L1341-1352+ — comment with valid issue_url → becomes
        # add_comment RemoteChange.
        from datetime import datetime, timezone
        def handler(req):
            if "/comments" in req.url.path:
                return httpx.Response(200, json=[
                    {
                        "id": 100, "body": "real comment",
                        "user": {"login": "octocat"},
                        "created_at": "2026-06-02T00:00:00Z",
                        "html_url": "http://forgejo.test/o/r/issues/1#c100",
                        "issue_url": (
                            "http://forgejo.test/api/v1/repos/o/r/issues/1"
                        ),
                        "issue_id": 1,
                    },
                ])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            since = datetime(2026, 5, 1, tzinfo=timezone.utc)
            changes = await adapter.fetch_remote_changes(
                since=since, owner="o", repo="r",
            )
            add_comments = [c for c in changes if c.operation == "add_comment"]
            assert len(add_comments) == 1
        finally:
            await adapter.aclose()


class TestProbeAndDriftDelegation:
    """(#428) Drain ForgejoAdapter probe + compute_drift paths."""

    @pytest.mark.asyncio
    async def test_probe_returns_true_on_version_response(self):
        # (#428) L904-908 — version dict → True.
        def handler(req):
            return httpx.Response(200, json={"version": "1.21"})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_forge_unavailable(self):
        # (#428) L909-910 — ForgeUnavailableError → False.
        def handler(req):
            return httpx.Response(503, text="down")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_probe_returns_false_on_forge_error(self):
        # (#428) L911-912 — non-unavailable ForgeError → False.
        def handler(req):
            return httpx.Response(404, text="endpoint missing")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_missing_owner_returns_dirty(self):
        # (#428) L922-930 — no owner/repo in snapshot → unclean note.
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(
            token="x", api_base="x", platform_id="forgejo",
        )
        report = await adapter.compute_drift({})
        assert report.is_clean is False
        assert any("snapshot missing" in n for n in report.notes)

    @pytest.mark.asyncio
    async def test_compute_drift_unreachable_remote_returns_dirty(self):
        # (#428) L944-949 — ForgeUnavailableError on /issues fetch →
        # inconclusive note.
        def handler(req):
            return httpx.Response(503, text="down")
        adapter = _adapter_with_mock(handler)
        try:
            report = await adapter.compute_drift(
                {"owner": "o", "repo": "r"}
            )
            assert report.is_clean is False
            assert any("unreachable" in n for n in report.notes)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_clean_when_remote_matches_local(self):
        # (#428) L952-1010 — issues+discussions match → clean.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "number": 1, "state": "open",
                    "labels": [{"name": "bug"}],
                },
                {
                    "number": 5, "state": "open",
                    "labels": [{"name": "kind:discussion"}],
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "issues": {1: {"state": "open", "labels": ["bug"]}},
                "discussions": {
                    5: {"state": "open", "labels": ["kind:discussion"]},
                },
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_diverged_state_marks_dirty(self):
        # (#428) L981-986 + L994-999 — state divergence flags drift.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "number": 1, "state": "closed",
                    "labels": [],
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_compute_drift_skips_items_without_number(self):
        # (#428) L955-957 — number=None entries skip.
        def handler(req):
            return httpx.Response(200, json=[
                {"number": None, "state": "open", "labels": []},
                {"number": 1, "state": "open", "labels": []},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            local = {
                "owner": "o", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
            }
            report = await adapter.compute_drift(local)
            assert report.is_clean is True
        finally:
            await adapter.aclose()


class TestReleaseAndUrlHelpers:
    """(#428) Drain ForgejoAdapter release + URL helper paths."""

    @pytest.mark.asyncio
    async def test_create_release_marshals_response(self):
        # (#428) L756-784 — POST /releases → marshals Release.
        def handler(req):
            return httpx.Response(201, json={
                "id": 1, "tag_name": "v1.0.0", "name": "v1.0.0",
                "body": "notes", "prerelease": False, "draft": False,
                "created_at": "2026-05-12T00:00:00Z",
                "html_url": "http://forgejo.test/o/r/releases/v1.0.0",
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_release(
                owner="o", repo="r", tag="v1.0.0",
                name="v1.0.0", body="notes",
            )
            assert result.tag == "v1.0.0"
            assert result.url == "http://forgejo.test/o/r/releases/v1.0.0"
        finally:
            await adapter.aclose()

    def test_get_clone_url_strips_api_suffix(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(
            token="x", api_base="https://codeberg.org/api/v1",
            platform_id="codeberg",
        )
        assert (
            adapter.get_clone_url("o", "r")
            == "https://codeberg.org/o/r.git"
        )

    def test_noreply_email_format(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(
            token="x", api_base="https://codeberg.org/api/v1",
            platform_id="codeberg",
        )
        assert (
            adapter.noreply_email("octocat")
            == "octocat@noreply.codeberg.org"
        )

    def test_public_issue_url_regex_matches_codeberg(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(
            token="x", api_base="https://codeberg.org/api/v1",
            platform_id="codeberg",
        )
        pattern = adapter.public_issue_url_regex()
        m = pattern.match("https://codeberg.org/owner/repo/issues/42")
        assert m is not None
        assert m.group(3) == "42"

    @pytest.mark.asyncio
    async def test_delete_release_idempotent_when_missing(self):
        # (#428) L844-853 — GET by tag 404 → noop.
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.delete_release(
                owner="o", repo="r", tag="v9.9.9",
            )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_delete_release_dispatches_delete(self):
        # (#428) L844-858 — GET returns release, then DELETE by id.
        recorded = {"deletes": 0}
        def handler(req):
            if req.method == "GET":
                return httpx.Response(200, json={"id": 42})
            if req.method == "DELETE":
                recorded["deletes"] += 1
                return httpx.Response(204, text="")
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.delete_release(
                owner="o", repo="r", tag="v1.0.0",
            )
            assert recorded["deletes"] == 1
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_delete_release_no_id_returns_noop(self):
        # (#428) L851-853 — release missing id → return without delete.
        recorded = {"deletes": 0}
        def handler(req):
            if req.method == "GET":
                return httpx.Response(200, json={})  # no id field
            if req.method == "DELETE":
                recorded["deletes"] += 1
                return httpx.Response(204, text="")
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            await adapter.delete_release(
                owner="o", repo="r", tag="v1.0.0",
            )
            assert recorded["deletes"] == 0
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_text(self):
        # (#428) L864-? — fetch_file_content delegates to raw endpoint.
        def handler(req):
            return httpx.Response(200, text="file body")
        adapter = _adapter_with_mock(handler)
        try:
            # Note: _request normally json-decodes; the raw endpoint
            # may need different handling. Check the adapter impl.
            result = await adapter.fetch_file_content(
                owner="o", repo="r", path="foo.md",
            )
            # Likely returns the raw text body or None — accept both.
            assert result is None or isinstance(result, str)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_fetch_file_content_404_returns_none(self):
        # (#428) L867-873 — 404 → None.
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.fetch_file_content(
                owner="o", repo="r", path="missing.md",
            )
            assert result is None
        finally:
            await adapter.aclose()


class TestDiscussionDelegation:
    """(#428) Drain ForgejoAdapter discussion paths (Issues + kind:discussion)."""

    @pytest.mark.asyncio
    async def test_create_discussion_adds_kind_and_category_labels(self):
        # (#428) L480-495 — create_discussion → adds kind:discussion +
        # category:* labels, delegates to create_issue.
        def handler(req):
            if "/labels" in req.url.path and req.method == "GET":
                # ensure_label flow
                return httpx.Response(200, json=[])
            if "/labels" in req.url.path and req.method == "POST":
                return httpx.Response(201, json={
                    "id": 99, "name": "kind:discussion",
                })
            if "/issues" in req.url.path and req.method == "POST":
                return httpx.Response(201, json={
                    "id": 1, "number": 1, "title": "T", "body": "B",
                    "state": "open",
                    "labels": [
                        {"id": 99, "name": "kind:discussion"},
                        {"id": 100, "name": "category:architecture"},
                    ],
                    "milestone": None,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                })
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.create_discussion(
                owner="o", repo="r", title="T", body="B",
                category="Architecture",
            )
            assert result.ref.kind == "discussion"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_resolves_to_kind_discussion_issue(self):
        # (#428) L497-507 — get_discussion fetches issue + filters by label.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "number": 1, "title": "T", "body": "B",
                "state": "open",
                "labels": [{"name": "kind:discussion"},
                           {"name": "category:ideas"}],
                "milestone": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.get_discussion("o", "r", 1)
            assert result.ref.kind == "discussion"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_without_kind_label_raises(self):
        # (#428) L501-505 — issue without kind:discussion → raise.
        def handler(req):
            return httpx.Response(200, json={
                "id": 1, "number": 1, "title": "T", "body": "B",
                "state": "open", "labels": [{"name": "bug"}],
                "milestone": None,
                "html_url": "http://forgejo.test/o/r/issues/1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_discussion("o", "r", 1)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates_to_get_issue_body(self):
        # (#428) L509-513 — get_discussion_body == get_issue_body.
        def handler(req):
            return httpx.Response(200, json={"body": "disc body"})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            assert await adapter.get_discussion_body(ref) == "disc body"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_update_discussion_body_delegates(self):
        # (#428) L515-518 — delegates to update_issue_body.
        recorded = {"method": None}
        def handler(req):
            recorded["method"] = req.method
            return httpx.Response(200, json={"body": "new"})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            await adapter.update_discussion_body(ref, "new body")
            assert recorded["method"] == "PATCH"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_recent_discussions_filters_by_cutoff(self):
        # (#428) L520-547 — list_recent_discussions filters out old.
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        old = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
        recent = now.isoformat().replace("+00:00", "Z")

        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "number": 1, "title": "old",
                    "body": "B", "state": "open",
                    "labels": [{"name": "kind:discussion"}],
                    "milestone": None, "created_at": old,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                },
                {
                    "id": 2, "number": 2, "title": "new",
                    "body": "B", "state": "open",
                    "labels": [{"name": "kind:discussion"}],
                    "milestone": None, "created_at": recent,
                    "html_url": "http://forgejo.test/o/r/issues/2",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.list_recent_discussions(
                owner="o", repo="r", since_days=7,
            )
            assert len(result) == 1
            assert result[0].title == "new"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_mark_decided_dispatches_label_add(self):
        # (#428) L549-551 — mark_decided → add_label("decided").
        recorded = {"posts": []}
        def handler(req):
            if req.method == "GET" and "/labels" in req.url.path:
                return httpx.Response(200, json=[])  # ensure_label list
            if req.method == "POST" and req.url.path.endswith("/labels"):
                recorded["posts"].append(req.url.path)
                if "issues" in req.url.path:
                    return httpx.Response(200, json=[])
                return httpx.Response(201, json={"id": 1, "name": "decided"})
            return httpx.Response(200, json={})
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="discussion", owner="o", repo="r", number=1,
            )
            await adapter.mark_decided(ref)
            assert any("issues/1/labels" in p for p in recorded["posts"])
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_mark_answer_raises_not_implemented(self):
        # (#428) L553-561 — mark_answer is unimplemented on Forgejo.
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(
            token="x", api_base="http://forgejo.test",
            platform_id="forgejo",
        )
        ref = ArtifactRef(
            platform_id="forgejo", native_id="DC_x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(NotImplementedError):
            await adapter.mark_answer(ref)


class TestMilestoneGapNotImplemented:
    """(#428) ForgejoAdapter milestone/gap stubs all raise NotImplementedError."""

    @pytest.mark.asyncio
    async def test_create_milestone(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.create_milestone()

    @pytest.mark.asyncio
    async def test_get_milestone_body(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.get_milestone_body("1.0")

    @pytest.mark.asyncio
    async def test_update_milestone_state(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.update_milestone_state("1.0", "open")

    @pytest.mark.asyncio
    async def test_update_milestone_meta(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.update_milestone_meta("1.0", tier="x")

    @pytest.mark.asyncio
    async def test_list_all_milestone_versions(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.list_all_milestone_versions()

    @pytest.mark.asyncio
    async def test_upsert_gap(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.upsert_gap()

    @pytest.mark.asyncio
    async def test_get_gap_body(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.get_gap_body("cat")

    @pytest.mark.asyncio
    async def test_update_gap_state(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.update_gap_state("cat", "triage")

    @pytest.mark.asyncio
    async def test_update_gap_meta(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.update_gap_meta("cat", tier="x")

    @pytest.mark.asyncio
    async def test_list_gap_categories(self):
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        with pytest.raises(NotImplementedError):
            await adapter.list_gap_categories()


class TestCommentDelegation:
    """(#428) Drain ForgejoAdapter comment paths."""

    @pytest.mark.asyncio
    async def test_append_comment_dispatches_post(self):
        # (#428) L632-642 — POST /issues/{n}/comments.
        def handler(req):
            return httpx.Response(201, json={
                "id": 1, "body": "hello",
                "user": {"login": "bot"},
                "created_at": "2026-05-12T00:00:00Z",
                "html_url": "http://forgejo.test/o/r/issues/1#c1",
            })
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.append_comment(target, "hello")
            assert result.body == "hello"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_append_comment_unsupported_kind_raises(self):
        # (#428) L634-635 — bad kind → ValueError.
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        target = ArtifactRef(
            platform_id="forgejo", native_id="x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="append_comment"):
            await adapter.append_comment(target, "x")

    @pytest.mark.asyncio
    async def test_list_comments_with_since_days(self):
        # (#428) L644-671 — list_comments with since_days computes
        # ISO param.
        recorded = {"params": None}
        def handler(req):
            recorded["params"] = dict(req.url.params)
            return httpx.Response(200, json=[
                {
                    "id": 1, "body": "c1",
                    "user": {"login": "bot"},
                    "created_at": "2026-05-12T00:00:00Z",
                    "html_url": "http://forgejo.test/o/r/issues/1#c1",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.list_comments(target, since_days=7)
            assert len(result) == 1
            assert "since" in recorded["params"]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_comments_with_limit_slices(self):
        # (#428) L669-670 — limit slices to last N.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": i, "body": f"c{i}",
                    "user": {"login": "bot"},
                    "created_at": "2026-05-12T00:00:00Z",
                    "html_url": f"http://forgejo.test/o/r/issues/1#c{i}",
                }
                for i in range(5)
            ])
        adapter = _adapter_with_mock(handler)
        try:
            target = ArtifactRef(
                platform_id="forgejo", native_id="o/r#1",
                kind="issue", owner="o", repo="r", number=1,
            )
            result = await adapter.list_comments(target, limit=2)
            assert len(result) == 2
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_comments_unsupported_kind_raises(self):
        # (#428) L651-652 — bad kind → ValueError.
        from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
        adapter = ForgejoAdapter(token="x", api_base="x", platform_id="forgejo")
        target = ArtifactRef(
            platform_id="forgejo", native_id="x",
            kind="comment", owner="o", repo="r",
        )
        with pytest.raises(ValueError, match="list_comments"):
            await adapter.list_comments(target)


class TestSearchAndListIssuesDelegation:
    """(#428) Drain ForgejoAdapter search + list_open_issues."""

    @pytest.mark.asyncio
    async def test_search_issues_marshals_results(self):
        # (#428) L428-466 — search_issues marshals API → SearchResult.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "number": 1, "title": "T", "body": "B",
                    "state": "open", "labels": [], "milestone": None,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.search_issues(
                owner="o", repo="r", query="x", labels=["bug"],
            )
            assert result.total_count == 1
            assert result.query == "x"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_search_issues_resolves_milestone_filter(self):
        # (#428) L448-451 — milestone filter resolves to title via
        # find_milestone.
        def handler(req):
            path = req.url.path
            if "/milestones/" in path:
                # find_milestone by number
                return httpx.Response(200, json={
                    "id": 1, "number": 1, "title": "v1",
                    "state": "open", "description": "",
                    "closed_issues": 0, "open_issues": 0,
                })
            if path.endswith("/issues"):
                return httpx.Response(200, json=[])
            return httpx.Response(200, json=[])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.search_issues(
                owner="o", repo="r", milestone="1",
            )
            assert result.total_count == 0
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_open_issues_delegates_to_search(self):
        # (#428) L468-474 — list_open_issues → search_issues with state=open.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "number": 1, "title": "T", "body": "B",
                    "state": "open", "labels": [], "milestone": None,
                    "html_url": "http://forgejo.test/o/r/issues/1",
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.list_open_issues(owner="o", repo="r")
            assert len(result) == 1
        finally:
            await adapter.aclose()


class TestRepoLevelReadDelegation:
    """(#428) Drain ForgejoAdapter repo-level reads via MockTransport."""

    @pytest.mark.asyncio
    async def test_get_repo_node_id_returns_string_id(self):
        # (#428) L264-269 — happy path returns str(data["id"]).
        def handler(req):
            return httpx.Response(200, json={"id": 12345, "name": "r"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.get_repo_node_id("o", "r")
            assert result == "12345"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_node_id_missing_id_raises(self):
        # (#428) L267-268 — id missing → InvalidArtifactRefError.
        def handler(req):
            return httpx.Response(200, json={"name": "r"})
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_repo_node_id("o", "r")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_visibility_public(self):
        # (#428) L271-281 — private=False → PUBLIC.
        def handler(req):
            return httpx.Response(200, json={"private": False})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_visibility_private(self):
        # (#428) L271-281 — private=True → PRIVATE.
        def handler(req):
            return httpx.Response(200, json={"private": True})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PRIVATE"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_repo_visibility_404_returns_none(self):
        # (#428) L279-280 — 404 → None.
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_list_milestones_marshals_results(self):
        # (#428) L283-290 — list_milestones marshals API → Milestone[].
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "number": 1, "title": "1.0.0",
                    "state": "open", "description": "",
                    "closed_issues": 0, "open_issues": 0,
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.list_milestones("o", "r")
            assert len(result) == 1
            assert result[0].title == "1.0.0"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_milestone_by_number(self):
        # (#428) L295-301 — find by number via direct GET.
        def handler(req):
            return httpx.Response(200, json={
                "id": 5, "number": 5, "title": "1.0.0",
                "state": "open", "description": "",
                "closed_issues": 0, "open_issues": 0,
            })
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.find_milestone("o", "r", 5)
            assert result is not None
            assert result.number == 5
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_milestone_by_number_404_returns_none(self):
        # (#428) L299-301 — 404 → None.
        def handler(req):
            return httpx.Response(404, text="missing")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.find_milestone("o", "r", 999) is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_find_milestone_by_title_via_helper(self):
        # (#428) L302-305 — title path via helper walks list_milestones.
        def handler(req):
            return httpx.Response(200, json=[
                {
                    "id": 1, "number": 1, "title": "2.0.0",
                    "state": "open", "description": "",
                    "closed_issues": 0, "open_issues": 0,
                },
            ])
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.find_milestone("o", "r", "2.0.0")
            assert result is not None
            assert result.title == "2.0.0"
        finally:
            await adapter.aclose()


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
