"""
Config loading for forge-manager-mcp.

Fails immediately at startup if github-config.json is missing,
malformed, or contains invalid values. No lazy loading.
"""

from __future__ import annotations

import json
import os
import warnings
from pathlib import Path

from pydantic import ValidationError

from .models import GithubConfig

_CONFIG_RELATIVE_PATH = ".claude/github-config.json"
"""Legacy 2.x config filename. Pre-3.0 the project always wrote here."""

_FORGE_CONFIG_RELATIVE_PATH = ".claude/forge-config.json"
"""3.0 canonical config filename (#274 Phase D). The migration tool
emits this and load_config prefers it when both files exist."""


class ConfigError(RuntimeError):
    """
    Raised when config cannot be loaded or validated.
    Always fatal — the server cannot operate without valid config.
    """


class ConfigMissingError(ConfigError):
    """Raised when github-config.json is absent (pre-bootstrap state).

    Distinguishable from `ConfigError` so the MCP server can fall into
    degraded-mode startup (#156) instead of crashing — the file is
    *generated* by `scaffold_project`, so its absence is a normal
    pre-bootstrap state, not an error.
    """


def load_config(project_dir: Path) -> GithubConfig:
    """
    Load and validate the project's forge config from project_dir.

    Tries ``.claude/forge-config.json`` first (3.0 canonical filename
    written by the migration tool); falls back to
    ``.claude/github-config.json`` (2.x legacy). 2.x configs validate
    via the same model — the 3.0-only fields ``platforms`` /
    ``replication_order`` / ``schema_version`` default to empty /
    ``2.x``, which keeps ``_build_replication`` on the single-
    GitHubAdapter path.

    Raises:
    - `ConfigMissingError` (a `ConfigError` subclass) if neither file
      is present — pre-bootstrap state, MCP server can degrade
      gracefully (#156).
    - `ConfigError` (the parent class) for any non-recoverable failure:
      project_dir doesn't exist, JSON is malformed, validation fails.

    Never returns a partially-valid config.
    """
    if not project_dir.exists():
        raise ConfigError(
            f"Project directory does not exist: {project_dir}\n"
            "Ensure --project-dir points to your *-dev repo root."
        )

    forge_path = project_dir / _FORGE_CONFIG_RELATIVE_PATH
    legacy_path = project_dir / _CONFIG_RELATIVE_PATH

    if forge_path.exists():
        config_path = forge_path
    elif legacy_path.exists():
        config_path = legacy_path
    else:
        raise ConfigMissingError(
            f"No forge config found. Looked for {forge_path} and "
            f"{legacy_path}.\nRun bootstrap first: open Claude Code "
            "in this repo and say 'bootstrap yourself'."
        )

    try:
        raw = config_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(
            f"Cannot read {config_path}: {exc}"
        ) from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ConfigError(
            f"github-config.json is not valid JSON: {exc}\n"
            f"File: {config_path}"
        ) from exc

    # (Phase H / 3.5.0) Strip the legacy ``site`` block silently if
    # present. Pre-3.5.0 configs may carry it; 3.5.0 doesn't honor it.
    # Stripping keeps GithubConfig.model_config["extra"] = "forbid"
    # working without a noisy validation error on freshly-migrated
    # projects.
    if isinstance(data, dict):
        data.pop("site", None)

    try:
        config = GithubConfig.model_validate(data)
    except ValidationError as exc:
        # Surface every validation error, not just the first
        errors = "\n".join(
            f"  - {'.'.join(str(l) for l in e['loc'])}: {e['msg']}"
            for e in exc.errors()
        )
        raise ConfigError(
            f"github-config.json failed validation:\n{errors}\n"
            f"File: {config_path}\n"
            "Re-run bootstrap or manually correct the file."
        ) from exc

    _warn_deprecated_relationship_types(config, config_path)
    return config


def _warn_deprecated_relationship_types(
    config: GithubConfig, config_path: Path
) -> None:
    """Emit a DeprecationWarning for each related_repos entry still
    using the pre-1.3.0 `contribution_target` umbrella type (#98).

    Config continues to load — the type parses — but the user should
    migrate each entry to one of `sibling` / `cousin` / `neighbor` /
    `foreign` at next edit, per the precise sub-type definitions in
    §Multi-repo relations.
    """
    stale = [r.repo for r in config.related_repos if r.relationship == "contribution_target"]
    if not stale:
        return
    warnings.warn(
        "github-config.json uses deprecated relationship type "
        "'contribution_target' for "
        f"{stale!r}. Migrate to one of sibling / cousin / neighbor / "
        "foreign — see forge-manager skill multi-repo.md §Multi-repo relations "
        f"(#97). File: {config_path}",
        DeprecationWarning,
        stacklevel=3,
    )


def require_env(name: str) -> str:
    """
    Return the value of environment variable `name`.

    Raises ConfigError immediately if the variable is not set or empty.
    Used for ANTHROPIC_API_KEY and GITHUB_TOKEN.
    """
    value = os.environ.get(name, "").strip()
    if not value:
        raise ConfigError(
            f"Environment variable {name!r} is not set or empty.\n"
            "Ensure gh is authenticated and ANTHROPIC_API_KEY is set."
        )
    return value


def get_github_token() -> str:
    """
    Retrieve the GitHub token from the environment or gh CLI config.

    Thin wrapper around :func:`get_platform_token` for the GitHub case.
    Preserved at the public surface so 2.x callers continue to work
    without rewriting.

    Tries in order:
    1. GITHUB_TOKEN environment variable
    2. GH_TOKEN environment variable
    3. ``gh auth token`` subprocess call

    Raises ConfigError if none are available.
    """
    token = get_platform_token("github")
    if token is None:
        raise ConfigError(
            "No GitHub token found.\n"
            "Set GITHUB_TOKEN or GH_TOKEN, or run: gh auth login"
        )
    return token


# ---------------------------------------------------------------------------
# Per-platform token resolution (#283)
# ---------------------------------------------------------------------------

# Per-platform discovery rules. Each entry: (env_vars, token_file_paths).
# Lookup walks env vars first, then file paths. First non-empty match wins.
# Token file is read with .strip() so trailing newlines don't break headers.
_PLATFORM_TOKEN_SOURCES: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "github": (
        ("GITHUB_TOKEN", "GH_TOKEN"),
        (),  # GitHub falls back to `gh auth token` subprocess; not a file
    ),
    "forgejo": (
        ("FORGEJO_TOKEN",),
        ("~/.forgejo-token",),
    ),
    "forgejo-self": (
        ("FORGEJO_TOKEN",),
        ("~/.forgejo-token",),
    ),
    "codeberg": (
        ("CODEBERG_TOKEN",),
        ("~/.codeberg-token",),
    ),
    "gitlab": (
        ("GITLAB_TOKEN",),
        ("~/.gitlab-token",),
    ),
    "local": ((), ()),  # LocalStore has no remote auth
}


def get_platform_token(
    platform_id: str, *, token_env_override: str | None = None,
) -> str | None:
    """Resolve credentials for the named platform; return None if unavailable.

    Per-platform discovery chain:

    - **github**: ``GITHUB_TOKEN`` → ``GH_TOKEN`` → ``gh auth token``
    - **forgejo** / **forgejo-self**: ``FORGEJO_TOKEN`` → ``~/.forgejo-token``
    - **codeberg**: ``CODEBERG_TOKEN`` → ``~/.codeberg-token``
    - **gitlab**: ``GITLAB_TOKEN`` → ``~/.gitlab-token``
    - **local**: returns None (no remote auth needed)

    The optional ``token_env_override`` short-circuits the discovery
    chain — when ``forge-config.json.platforms[].token_env`` is set,
    that env var is consulted first. This lets multiple instances of
    the same platform (two Forgejo deployments, etc.) carry different
    credentials without renaming the canonical env vars.

    Returns None when no credential is found. Callers that require a
    token (e.g., :func:`get_github_token`) raise ConfigError on None.

    Parameters
    ----------
    platform_id:
        One of "github", "forgejo", "forgejo-self", "codeberg",
        "gitlab", "local". Unknown ids return None.
    token_env_override:
        Optional explicit env-var name from
        ``forge-config.json.platforms[].token_env``. Consulted first;
        falls through to the platform's default chain on miss.
    """
    # 1. Caller-specified env override wins.
    if token_env_override:
        token = os.environ.get(token_env_override, "").strip()
        if token:
            return token

    sources = _PLATFORM_TOKEN_SOURCES.get(platform_id)
    if sources is None:
        return None

    env_vars, token_files = sources

    # 2. Env-var chain.
    for var in env_vars:
        token = os.environ.get(var, "").strip()
        if token:
            return token

    # 3. Token-file chain.
    for path_str in token_files:
        path = Path(path_str).expanduser()
        if path.is_file():
            try:
                content = path.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if content:
                return content

    # 4. GitHub-specific fallback: subprocess `gh auth token`.
    if platform_id == "github":
        return _gh_auth_token_or_none()

    return None


def _gh_auth_token_or_none() -> str | None:
    """Return ``gh auth token`` output or None on any failure.

    Separated from :func:`get_platform_token` so test suites can mock
    just this path without intercepting all subprocess calls.
    """
    import subprocess  # noqa: PLC0415

    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    token = result.stdout.strip()
    return token or None
