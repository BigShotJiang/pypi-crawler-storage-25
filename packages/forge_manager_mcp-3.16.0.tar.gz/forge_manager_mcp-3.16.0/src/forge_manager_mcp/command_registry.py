"""Command registry + parser — text command grammar (#387 / #13 / #392).

The skill exposes a small `/<noun> <verb> [args] [--flags]` grammar
across Claude / MCP / daemon / SSE per Discussion #13's "partial
symmetry" model: symmetric in wire form, asymmetric in dispatch
(each surface routes to its own typed implementation).

Wire form is **noun-verb** as of 3.10.0 D2 / #392 (e.g.
`/issues search feature`, `/issue close 42`); pre-3.10.0 the
form was verb-noun. Migration drove from #389 / #387 design
reconciliation — noun-verb matches `<resource>.<action>` REST
convention, scales as new verbs accrue per resource, and reads
more naturally for mutating commands. Verb-only meta-commands
(notably `/help`) keep verb-only form per #392 OQ2.

Schema field names `verb` and `noun` retain their semantic
labels — "verb" is the action word ("search", "show", "list"),
"noun" is the resource ("issues", "discussions"). Only the
**wire-form ordering** of the two tokens swapped.

Module exports
--------------

- :class:`Command` / :class:`CommandArg` / :class:`ParsedCommand`
  Pydantic models behind @cache-decorated factories per Schema-as-data
  Rule 5.
- :class:`CommandRegistry` with ``get(verb, noun)`` / ``list_verbs()``
  accessors.
- :func:`load_commands` — parse ``commands.yaml`` into a registry.
- :func:`parse_command` — tokenize a raw ``/<verb> <noun> [args]``
  string into a :class:`ParsedCommand` against the registry.
- :exc:`CommandRegistryError` — schema / duplicate / unknown failures.

Why a custom parser
-------------------

Same rationale as ``gate_registry.py``: the grammar is small,
quoted-arg + flag handling is bounded, and an off-the-shelf parser
(argparse / a parser-combinator) would be heavier than ~150 LOC.
The pure-function parsers (Python here, TypeScript twin in the UI)
stay auditable.

The YAML loader reuses ``gate_registry.parse_yaml_text`` —
constrained YAML subset is identical (no nested mappings; nested
sequences-of-mappings supported); ``commands.yaml`` encodes per-
command dispatch arg templates as JSON-string fields
(``mcp_args_json`` / ``daemon_params_json``) so the existing parser
shape applies without extension.
"""
from __future__ import annotations

import json
import shlex
from functools import cache
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from forge_manager_mcp.gate_registry import (
    GateRegistryError,
    parse_yaml_text,
)


class CommandRegistryError(Exception):
    """Raised on YAML parse / schema / duplicate / unknown failures."""


ArgType = Literal["string", "integer", "boolean"]


@cache
def _command_arg_class() -> type:
    class CommandArg(BaseModel):
        """Argument declaration for a registered command."""

        model_config = {"frozen": True, "extra": "forbid"}

        name: str = Field(..., description="Argument identifier; matches {placeholder}.")
        type: ArgType = Field(..., description="Argument type for validation.")
        positional: bool = Field(
            default=True,
            description=(
                "True → positional (consumed in declaration order). "
                "False → flag form (--name=value or --name value)."
            ),
        )
        required: bool = Field(
            default=True,
            description="True → parser raises if absent.",
        )

    return CommandArg


CommandArg = _command_arg_class()


@cache
def _command_class() -> type:
    class Command(BaseModel):
        """Registered command: verb-noun pair + dispatch + args."""

        model_config = {"frozen": True, "extra": "forbid"}

        verb: str = Field(..., description="First token of the slash form.")
        noun: str = Field(
            default="",
            description=(
                "Second token (e.g. 'issues' for `/search issues`). "
                "Empty for verb-only commands like `/help`."
            ),
        )
        summary: str = Field(..., description="One-line operator-facing description.")
        # Dispatch surfaces — at least one MUST be set per validator.
        mcp_tool: str | None = Field(
            None,
            description=(
                "Underlying MCP tool name. When set, the run_command "
                "MCP tool dispatches via this."
            ),
        )
        mcp_args_json: str | None = Field(
            None,
            description=(
                "JSON-encoded args template for mcp_tool dispatch. "
                "Use {placeholder} substitution from args[*].name."
            ),
        )
        daemon_endpoint: str | None = Field(
            None,
            description=(
                "HTTP method + path for daemon dispatch (e.g. "
                "'GET /search'). Consumed by POST /command."
            ),
        )
        daemon_params_json: str | None = Field(
            None,
            description=(
                "JSON-encoded params template for daemon dispatch."
            ),
        )
        ui_route: str | None = Field(
            None,
            description=(
                "URL fragment template for UI-side navigation (e.g. "
                "'#files?repo=docs&path=issues/{number}'). No IO."
            ),
        )
        args: tuple[CommandArg, ...] = Field(
            default_factory=tuple,
            description="Ordered argument declarations.",
        )
        aliases: tuple[str, ...] = Field(
            default_factory=tuple,
            description=(
                "Alternate `<noun> <verb>` strings that resolve to "
                "this command (or single-token form for verb-only "
                "meta-commands). Aliases share the same registry "
                "slot. 3.10.0 D2 / #392: noun-verb wire form."
            ),
        )
        introduced_in: str = Field(..., description="Skill version when first declared.")

        @model_validator(mode="after")
        def _has_dispatch(self) -> "Command":
            surfaces = (self.mcp_tool, self.daemon_endpoint, self.ui_route)
            if not any(s is not None for s in surfaces):
                raise ValueError(
                    f"command {self.verb}/{self.noun!r} has no dispatch "
                    f"surface (set mcp_tool, daemon_endpoint, or ui_route)"
                )
            return self

        @model_validator(mode="after")
        def _args_json_pair_with_surface(self) -> "Command":
            if self.mcp_args_json is not None and self.mcp_tool is None:
                raise ValueError(
                    f"command {self.verb}/{self.noun!r} has mcp_args_json "
                    f"but no mcp_tool"
                )
            if self.daemon_params_json is not None and self.daemon_endpoint is None:
                raise ValueError(
                    f"command {self.verb}/{self.noun!r} has daemon_params_json "
                    f"but no daemon_endpoint"
                )
            for raw, field in (
                (self.mcp_args_json, "mcp_args_json"),
                (self.daemon_params_json, "daemon_params_json"),
            ):
                if raw is None:
                    continue
                try:
                    json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"command {self.verb}/{self.noun!r} has invalid "
                        f"JSON in {field}: {exc}"
                    ) from None
            return self

        def key(self) -> tuple[str, str]:
            """Registry key — (verb, noun) pair."""
            return (self.verb, self.noun)

    return Command


Command = _command_class()


@cache
def _parsed_command_class() -> type:
    class ParsedCommand(BaseModel):
        """Result of parsing a raw `/<verb> <noun> [args]` string."""

        model_config = {"frozen": True, "extra": "forbid"}

        command: Command = Field(..., description="Resolved registry entry.")
        positional: tuple[str, ...] = Field(
            default_factory=tuple,
            description="Positional arg values, in declaration order.",
        )
        flags: dict[str, str] = Field(
            default_factory=dict,
            description="Flag args by name (--name=value or --name value).",
        )

        def substitute(self, template: str) -> str:
            """Substitute {name} placeholders in ``template`` with the
            parsed args. Used to render mcp_args_json / daemon_params_json
            / ui_route at dispatch time.

            Unknown placeholders are left as-is (caller's choice to
            error or surface).
            """
            out = template
            for i, decl in enumerate(self.command.args):
                if decl.positional and i < len(self.positional):
                    out = out.replace(f"{{{decl.name}}}", self.positional[i])
                elif not decl.positional and decl.name in self.flags:
                    out = out.replace(f"{{{decl.name}}}", self.flags[decl.name])
                elif not decl.required:
                    out = out.replace(f"{{{decl.name}}}", "")
            return out

    return ParsedCommand


ParsedCommand = _parsed_command_class()


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class CommandRegistry:
    """Read-only collection of :class:`Command` records.

    Keyed by (verb, noun) tuple. Aliases register additional keys
    pointing at the same Command.
    """

    __slots__ = ("_by_key",)

    def __init__(self, commands: list[Command]) -> None:
        self._by_key: dict[tuple[str, str], Command] = {}
        for command in commands:
            key = command.key()
            if key in self._by_key:
                raise CommandRegistryError(
                    f"duplicate command in registry: {key!r}"
                )
            self._by_key[key] = command
            for alias in command.aliases:
                # Alias format: "<noun> <verb>" or just "<verb>"
                # (3.10.0 D2 / #392: noun-verb wire form).
                # Verb-only aliases (single token) bind to (verb, "").
                # Two-token aliases bind to (verb=token[1], noun=token[0]).
                parts = alias.strip().split(maxsplit=1)
                if len(parts) == 1:
                    alias_key = (parts[0], "")
                else:
                    alias_key = (parts[1], parts[0])
                if alias_key in self._by_key:
                    raise CommandRegistryError(
                        f"alias {alias!r} on {key!r} collides with existing entry"
                    )
                self._by_key[alias_key] = command

    def get(self, verb: str, noun: str = "") -> Command | None:
        """Return the Command for (verb, noun), or None."""
        return self._by_key.get((verb, noun))

    def list_verbs(self) -> list[str]:
        """Return all registered verbs (sorted, deduplicated)."""
        return sorted({verb for verb, _ in self._by_key})

    def list_for_verb(self, verb: str) -> list[Command]:
        """Return all Commands for a given verb (across nouns)."""
        return [
            cmd for (v, _), cmd in self._by_key.items() if v == verb
        ]

    def __len__(self) -> int:
        return len(self._by_key)

    def __contains__(self, key: tuple[str, str]) -> bool:
        return key in self._by_key


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


def load_commands(path: Path) -> CommandRegistry:
    """Parse a commands.yaml file into a :class:`CommandRegistry`.

    Reuses :func:`gate_registry.parse_yaml_text` for the constrained
    YAML subset; converts each parsed dict into a :class:`Command`
    via Pydantic's validation. Raises :exc:`CommandRegistryError` on
    file-not-found / parse / schema / duplicate failures.
    """
    if not path.exists():
        raise CommandRegistryError(f"commands file not found: {path}")
    text = path.read_text(encoding="utf-8")
    try:
        items = parse_yaml_text(text, root_key="commands")
    except GateRegistryError as exc:
        raise CommandRegistryError(f"{path}: {exc}") from None

    commands: list[Command] = []
    for raw in items:
        # The constrained YAML parser yields nested args as list[dict];
        # Pydantic validates each into a CommandArg.
        try:
            commands.append(Command(**raw))
        except (TypeError, ValueError) as exc:
            raise CommandRegistryError(
                f"{path}: invalid command entry {raw!r}: {exc}"
            ) from None
    return CommandRegistry(commands)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def parse_command(text: str, registry: CommandRegistry) -> ParsedCommand:
    """Tokenize a raw `/<noun> <verb> [args] [--flags]` string.

    Resolves the leading noun-verb pair against ``registry``; binds
    remaining tokens to the command's declared args. Quoted-arg
    support via ``shlex.split`` (#13 OQ6 → option (b)).

    Wire-form ordering is **noun-verb** as of 3.10.0 D2 / #392; e.g.
    ``/issues search feature``, ``/issue close 42``. Verb-only
    meta-commands (notably ``/help``) stay verb-only — when the
    leading token resolves directly as a verb-only registry entry,
    no noun is consumed.

    Resolution algorithm:
      1. With ≥2 tokens, try registry.get(verb=tokens[1], noun=tokens[0]).
      2. If miss, fall back to registry.get(verb=tokens[0], noun="")
         — covers verb-only meta-commands.
      3. With 1 token, only the verb-only fallback applies.

    Flag forms accepted:
      * ``--name=value``
      * ``--name value`` (consumes the next token as the value)
      * ``--name`` (boolean — sets flag to "true")

    Raises :exc:`CommandRegistryError` for:
      * empty input
      * missing leading slash (``/``)
      * unknown noun-verb / verb-only command
      * required positional missing
      * unknown flag

    Returns a :class:`ParsedCommand` with positional + flag bindings;
    caller dispatches via ``parsed.command.mcp_tool`` /
    ``daemon_endpoint`` / ``ui_route`` and ``parsed.substitute(...)``.
    """
    raw = text.strip()
    if not raw:
        raise CommandRegistryError("empty command")
    if not raw.startswith("/"):
        raise CommandRegistryError(
            f"command must start with '/': {raw!r}"
        )
    body = raw[1:].strip()
    if not body:
        raise CommandRegistryError("command has only the leading slash")
    try:
        tokens = shlex.split(body)
    except ValueError as exc:
        raise CommandRegistryError(
            f"could not tokenize {raw!r}: {exc}"
        ) from None

    # 3.10.0 D2 / #392: noun-verb wire form. tokens[0] = noun candidate,
    # tokens[1] = verb candidate. Verb-only commands (e.g. /help) take
    # tokens[0] as the verb directly.
    leading = tokens[0]
    rest = tokens[1:]

    cmd: Command | None = None
    consumed_verb_token = False
    if rest:
        # Noun-verb form: registry.get(verb=tokens[1], noun=tokens[0]).
        cmd = registry.get(rest[0], leading)
        if cmd is not None:
            consumed_verb_token = True
    if cmd is None:
        # Verb-only fallback: tokens[0] alone is a verb (e.g. /help).
        cmd = registry.get(leading, "")
    if cmd is None:
        verbs = ", ".join(registry.list_verbs())
        head = leading + ((" " + rest[0]) if rest else "")
        raise CommandRegistryError(
            f"unknown command: /{head}; known verbs: {verbs}"
        )
    arg_tokens = rest[1:] if consumed_verb_token else rest

    positional: list[str] = []
    flags: dict[str, str] = {}

    declared_flags = {a.name: a for a in cmd.args if not a.positional}
    declared_positionals = [a for a in cmd.args if a.positional]

    i = 0
    while i < len(arg_tokens):
        token = arg_tokens[i]
        if token.startswith("--"):
            name, sep, value = token[2:].partition("=")
            if name not in declared_flags:
                raise CommandRegistryError(
                    f"unknown flag for /{cmd.noun} {cmd.verb}: --{name}".strip()
                )
            if sep:
                flags[name] = value
                i += 1
            elif declared_flags[name].type == "boolean":
                flags[name] = "true"
                i += 1
            else:
                if i + 1 >= len(arg_tokens):
                    raise CommandRegistryError(
                        f"flag --{name} requires a value"
                    )
                flags[name] = arg_tokens[i + 1]
                i += 2
        else:
            positional.append(token)
            i += 1

    # Validate required positionals.
    for j, decl in enumerate(declared_positionals):
        if decl.required and j >= len(positional):
            raise CommandRegistryError(
                f"required positional arg missing: <{decl.name}> "
                f"for /{cmd.noun} {cmd.verb}".strip()
            )

    return ParsedCommand(
        command=cmd,
        positional=tuple(positional),
        flags=flags,
    )


__all__ = [
    "ArgType",
    "Command",
    "CommandArg",
    "CommandRegistry",
    "CommandRegistryError",
    "ParsedCommand",
    "load_commands",
    "parse_command",
]
