"""Multi-user version coordination data layer (3.8.0 D1 / Discussion #8).

Surfaces drift signals across the version surfaces a project owner needs
to keep aligned in a multi-user setup:

  * The user's installed MCP wheel version (``__version__``).
  * The project's required version, declared by the skill prose
    ``**Version:**`` header in ``.claude/skills/forge-manager/SKILL.md``
    and propagated to collaborators via ``git pull``.
  * The latest published version on PyPI (``pypi.org/pypi/forge-
    manager-mcp/json``), cached in the daemon state-dir per Discussion
    #8 OQ3 closure (every-6-hours cadence).

The detector lives outside of ``open_session`` so the daemon's
``GET /upgrade/status`` endpoint (3.8.0 D2 / Theme B) and the
``check_mcp_version`` MCP tool can consume it without re-implementing
the comparison logic. ``open_session`` calls ``compute_drift`` and
embeds the result as a ``version_drift`` field.

Drift outcomes:
  * ``match`` — installed == required; nothing to surface.
  * ``behind`` — installed < required; banner + recommended command.
  * ``ahead`` — installed > required (typical mid-release); silent
    by default per #8 OQ4 closure.
  * ``unknown`` — required can't be read (no SKILL.md / unparseable);
    silent.

PyPI probe is best-effort: HTTP failures, parse failures, and missing
cache files all return ``None`` for ``pypi_latest``; the comparison
falls through to the project-required vs installed axis.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from functools import cache
from pathlib import Path

from forge_manager_mcp.parsers import parse_skill_version, semver_gt


def _read_mcp_version() -> str:
    """Resolve the running MCP package version.

    Avoids the import cycle that would arise from
    ``from forge_manager_mcp import __version__`` (the package's
    ``__init__.py`` re-exports the canonical store types and pulls in
    a chain that doesn't belong in this leaf module). Tries
    ``importlib.metadata`` first (works for installed wheels), falls
    back to reading ``__init__.py`` directly via the package
    resource path (works in source-tree dev mode).
    """
    import importlib.metadata
    try:
        return importlib.metadata.version("forge-manager-mcp")
    except importlib.metadata.PackageNotFoundError:
        pass
    init_path = Path(__file__).parent / "__init__.py"
    try:
        for line in init_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("__version__"):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return "0.0.0"


MCP_VERSION = _read_mcp_version()


_PYPI_CACHE_TTL = timedelta(hours=6)
"""Cache TTL for the PyPI version probe per Discussion #8 OQ3 closure.

Re-probe every 6 hours; respects rate-limits on pypi.org without
requiring explicit operator action. Cache file path:
``<state_dir>/pypi-version.json``.
"""

_PYPI_URL = "https://pypi.org/pypi/forge-manager-mcp/json"

_PYPI_PROBE_TIMEOUT = 5.0  # seconds


@cache
def _drift_class() -> type:
    @dataclass(frozen=True)
    class VersionDrift:
        """Snapshot of multi-source version drift.

        Mirror_warnings-style envelope: every field is either a
        ``str`` value or ``None`` for "couldn't read." The ``status``
        field tags the comparison result so consumers don't reconstruct
        it from the raw fields.
        """

        installed: str
        required: str | None
        pypi_latest: str | None
        pypi_probed_at: str | None
        status: str           # match / behind / ahead / unknown
        severity: str         # info / warn / fail
        recommendation: str | None
        message: str | None

    return VersionDrift


VersionDrift = _drift_class()


def read_required_version(project_dir: Path | None) -> str | None:
    """Read the project's required MCP version from the skill prose.

    Resolves ``<project_dir>/.claude/skills/forge-manager/SKILL.md``;
    parses the ``**Version:**`` header. Returns None for any failure
    (missing project_dir, missing file, unparseable header).
    """
    if project_dir is None:
        return None
    skill_md = project_dir / ".claude" / "skills" / "forge-manager" / "SKILL.md"
    if not skill_md.is_file():
        return None
    try:
        content = skill_md.read_text(encoding="utf-8")
    except OSError:
        return None
    return parse_skill_version(content)


def _cache_file(state_dir: Path) -> Path:
    return state_dir / "pypi-version.json"


def read_pypi_cache(
    state_dir: Path | None,
) -> "tuple[str | None, datetime | None]":
    """Read the cached PyPI version probe (raw, no TTL enforcement).

    Returns ``(version, fetched_at)`` whatever is on disk; ``(None,
    None)`` when the cache is absent or malformed. Callers that need
    freshness use ``is_cache_fresh(fetched_at)``.
    """
    if state_dir is None:
        return None, None
    path = _cache_file(state_dir)
    if not path.is_file():
        return None, None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None, None
    version = payload.get("version")
    fetched_at_str = payload.get("fetched_at")
    if not isinstance(version, str) or not isinstance(fetched_at_str, str):
        return None, None
    try:
        fetched_at = datetime.fromisoformat(fetched_at_str)
    except ValueError:
        return None, None
    return version, fetched_at


def is_cache_fresh(fetched_at: datetime | None) -> bool:
    """Return True when ``fetched_at`` is within the TTL window."""
    if fetched_at is None:
        return False
    return datetime.now(timezone.utc) - fetched_at <= _PYPI_CACHE_TTL


def write_pypi_cache(
    state_dir: Path | None, version: str, fetched_at: datetime,
) -> None:
    """Write the PyPI cache file. Best-effort; OSErrors swallowed."""
    if state_dir is None or not version:
        return
    path = _cache_file(state_dir)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({
                "version": version,
                "fetched_at": fetched_at.isoformat(),
            }),
            encoding="utf-8",
        )
    except OSError:
        pass


def probe_pypi_latest(state_dir: Path | None) -> "tuple[str | None, datetime | None]":
    """Resolve the latest published forge-manager-mcp on PyPI.

    Reads the cache first. On cache miss / stale, fetches
    ``pypi.org/pypi/forge-manager-mcp/json`` with a short timeout,
    extracts ``info.version``, refreshes the cache, returns the
    result. HTTP / parse failures fall back to the stale-cache value
    (if any) or None — the wizard's banner stays accurate without
    crashing on a transient outage.
    """
    cached_version, cached_at = read_pypi_cache(state_dir)
    if cached_version is not None and is_cache_fresh(cached_at):
        return cached_version, cached_at
    try:
        with urllib.request.urlopen(_PYPI_URL, timeout=_PYPI_PROBE_TIMEOUT) as resp:
            payload = json.load(resp)
    except (urllib.error.URLError, OSError, json.JSONDecodeError):
        return cached_version, cached_at  # may be None or stale
    info = payload.get("info") or {}
    version = info.get("version")
    if not isinstance(version, str):
        return cached_version, cached_at
    now = datetime.now(timezone.utc)
    write_pypi_cache(state_dir, version, now)
    return version, now


def _classify(installed: str, required: str | None) -> str:
    """Compare installed against required → match / behind / ahead / unknown."""
    if required is None:
        return "unknown"
    if installed == required:
        return "match"
    if semver_gt(installed, required):
        return "ahead"
    return "behind"


def _format_message(
    status: str, installed: str, required: str | None,
    pypi_latest: str | None,
) -> "tuple[str | None, str | None]":
    """Return ``(message, recommendation)`` for the operator.

    None / None when there's nothing to surface (match / ahead /
    unknown). Behind drives the banner + recommended command.
    """
    if status != "behind":
        return None, None
    target = required if required else pypi_latest
    if target is None:
        return None, None
    msg = (
        f"This project requires forge-manager-mcp {target}; "
        f"you're running {installed}."
    )
    if pypi_latest is not None and pypi_latest != installed:
        msg += f" Latest published is {pypi_latest}."
    rec = "pipx upgrade forge-manager-mcp"
    if pypi_latest is not None and semver_gt(target, pypi_latest):
        # Project requires a version newer than what's published —
        # mid-release window. Surface the gap honestly so the operator
        # waits for publish or builds from source.
        msg += (
            f" Note: {target} isn't on PyPI yet — "
            "wait for publish or build from source."
        )
    return msg, rec


def compute_drift(
    *, project_dir: Path | None, state_dir: Path | None,
    severity_override: str | None = None,
) -> "object":
    """Run the full drift detection across the three sources and
    return a ``VersionDrift`` snapshot.

    ``severity_override`` lets project rules tighten ``warn`` to
    ``fail`` per Discussion #8 OQ2 closure (path c — banner +
    project-rule-configurable severity). Default severity for
    behind = ``warn``; match / ahead / unknown = ``info``.
    """
    required = read_required_version(project_dir)
    pypi_latest, pypi_at = probe_pypi_latest(state_dir)
    status = _classify(MCP_VERSION, required)
    severity = "info"
    if status == "behind":
        severity = severity_override or "warn"
    message, recommendation = _format_message(
        status, MCP_VERSION, required, pypi_latest,
    )
    return VersionDrift(
        installed=MCP_VERSION,
        required=required,
        pypi_latest=pypi_latest,
        pypi_probed_at=pypi_at.isoformat() if pypi_at else None,
        status=status,
        severity=severity,
        recommendation=recommendation,
        message=message,
    )


def to_dict(drift) -> dict:
    """JSON-serializable view of the VersionDrift envelope."""
    return {
        "installed": drift.installed,
        "required": drift.required,
        "pypi_latest": drift.pypi_latest,
        "pypi_probed_at": drift.pypi_probed_at,
        "status": drift.status,
        "severity": drift.severity,
        "recommendation": drift.recommendation,
        "message": drift.message,
    }
