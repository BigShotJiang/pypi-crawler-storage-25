"""Project-rules separation framework (#288).

Skill protocol gates (#287) declare *what* the skill checks; project
rules declare *how a specific project extends, overrides, or
open/closes those checks*. Pre-3.2 this all lived in CLAUDE.md
``## Overrides`` as free-form prose with no formal handle. This
module gives projects a stable surface — ``.claude/project-rules.md``
— and converts each parsed rule into an :class:`Interceptor`
instance keyed by the gate it targets.

Surface
-------

The canonical file is ``.claude/project-rules.md`` — peer of
``.claude/skills/forge-manager/``. Standardized level-2 sections:

* ``## Independent rules`` — project-internal policy with no skill
  interaction. Loaded into :attr:`ProjectRules.independent` for
  diagnostic / audit purposes; never composes into a gate chain.
* ``## Gate extensions`` — tighter rules layered on top of named
  gates. Each level-3 entry begins with ``### Extends \`<gate.name>\```.
* ``## Gate overrides`` — replacement rules. Each level-3 entry begins
  with ``### Overrides \`<gate.name>\```.
* ``## Gate state declarations`` — open / close declarations. Each
  level-3 entry begins with ``### Closes \`<gate.name>\``` or
  ``### Opens \`<gate.name>\```.

Within each level-3 entry, bold-prefixed fields capture the rule's
content: ``**Extension:** ...``, ``**Replacement:** ...``,
``**Reason:** ...``, ``**Why:** ...``, ``**Cross-link:** ...``,
``**Re-open when:** ...``. Free-form paragraphs after the bold
fields are preserved as the rule's :attr:`body`.

Loader exports
--------------

* :func:`parse_project_rules` — text → :class:`ProjectRules`.
* :func:`load_project_rules` — file path → :class:`ProjectRules`.
* :func:`validate_against_registry` — every gate reference must
  resolve to a known gate name.
* :func:`build_state_interceptors` /
  :func:`build_override_interceptors` /
  :func:`build_extension_interceptors` — convert parsed rules into
  the per-section :class:`Interceptor` lists that :func:`build_gate_chain`
  composes.
* :exc:`ProjectRulesError` — raised on parse / schema / unknown-gate
  failure.

Interceptor semantics (per #288 § Implementation):

============================== ===================================================================================
Section                        Interceptor behavior
============================== ===================================================================================
Independent rules              Not interceptors. Never compose into a gate chain.
Gate extensions                ``enter`` augments request with rule context; ``leave`` tightens response by
                               appending an ``extensions`` entry. Multiple extensions chain in declaration order.
                               ``error`` is pass-through unless the rule body declares a fallback.
Gate overrides                 ``enter`` writes the replacement response and sets ``ctx.halt = True``; ``leave``
                               no-op; ``error`` pass-through. Default evaluator never runs after override.
Gate state — Closes            ``enter`` writes a closed-state response and sets ``ctx.halt = True``; ``leave``
                               no-op; ``error`` no-op. Short-circuits at the outermost layer.
Gate state — Opens             No interceptor — gates default open; ``Opens`` is a documentation marker
                               (and overrides a project's own prior ``Closes`` declaration in inheritance
                               scenarios; today's single-file form makes this a no-op).
============================== ===================================================================================
"""
from __future__ import annotations

import re
from dataclasses import replace
from functools import cache
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Literal

from pydantic import BaseModel, Field

from .interceptors import Context, Interceptor

if TYPE_CHECKING:
    from .gate_registry import Gate, GateRegistry


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

class ProjectRulesError(Exception):
    """Raised on parse / schema / unknown-gate failure."""


@cache
def _independent_rule_class() -> type:
    class IndependentRule(BaseModel):
        """A project-internal rule with no skill-protocol interaction."""

        model_config = {"frozen": True, "extra": "forbid"}

        name: str = Field(..., description="Heading text, free-form.")
        body: str = Field(default="", description="Prose body of the rule.")

    return IndependentRule


IndependentRule = _independent_rule_class()


@cache
def _gate_rule_class() -> type:
    class _GateRule(BaseModel):
        """Shared base for rules that target a named gate."""

        model_config = {"frozen": True, "extra": "forbid"}

        gate_name: str = Field(..., description="Dot-namespaced gate identifier.")
        why: str | None = Field(
            None, description="Project-specific rationale, optional."
        )
        cross_link: str | None = Field(
            None, description="Optional link to a Discussion / Issue / RFC."
        )
        body: str = Field(
            default="",
            description="Free-form paragraphs after the bold-prefixed fields.",
        )

    return _GateRule


_GateRule = _gate_rule_class()


class GateExtension(_GateRule):
    """A rule that tightens a named gate."""

    extension: str = Field(..., description="One-line extension description.")


class GateOverride(_GateRule):
    """A rule that replaces a named gate's evaluator."""

    replacement: str = Field(..., description="One-line replacement description.")


class GateStateDeclaration(_GateRule):
    """A rule that opens or closes a named gate."""

    state: Literal["open", "closed"] = Field(
        ..., description="Target state."
    )
    reason: str | None = Field(
        None,
        description="Optional explanation for closing the gate (omitted on opens).",
    )
    reopen_when: str | None = Field(
        None,
        description="Optional condition under which the gate should reopen.",
    )


@cache
def _project_rules_class() -> type:
    class ProjectRules(BaseModel):
        """Parsed contents of ``.claude/project-rules.md``."""

        model_config = {"frozen": True, "extra": "forbid"}

        independent: tuple[IndependentRule, ...] = Field(default_factory=tuple)
        extensions: dict[str, tuple[GateExtension, ...]] = Field(default_factory=dict)
        overrides: dict[str, tuple[GateOverride, ...]] = Field(default_factory=dict)
        state_declarations: dict[str, GateStateDeclaration] = Field(
            default_factory=dict
        )

    return ProjectRules


ProjectRules = _project_rules_class()


# ---------------------------------------------------------------------------
# Markdown parser
# ---------------------------------------------------------------------------

_KNOWN_SECTIONS: tuple[str, ...] = (
    "Independent rules",
    "Gate extensions",
    "Gate overrides",
    "Gate state declarations",
)

_GATE_REF_RE = re.compile(r"^(Extends|Overrides|Closes|Opens)\s+`([^`]+)`\s*$")
_BOLD_FIELD_RE = re.compile(r"^\*\*([^*:]+):\*\*\s*(.*)$")


def parse_project_rules(text: str) -> ProjectRules:
    """Parse a project-rules.md body into a :class:`ProjectRules`."""
    sections = _split_into_sections(text)
    independent: list[IndependentRule] = []
    extensions: dict[str, list[GateExtension]] = {}
    overrides: dict[str, list[GateOverride]] = {}
    state_declarations: dict[str, GateStateDeclaration] = {}

    for section_name, entries in sections.items():
        if section_name == "Independent rules":
            for entry in entries:
                independent.append(_build_independent(entry))
        elif section_name == "Gate extensions":
            for entry in entries:
                ext = _build_extension(entry)
                extensions.setdefault(ext.gate_name, []).append(ext)
        elif section_name == "Gate overrides":
            for entry in entries:
                ovr = _build_override(entry)
                overrides.setdefault(ovr.gate_name, []).append(ovr)
        elif section_name == "Gate state declarations":
            for entry in entries:
                decl = _build_state_declaration(entry)
                if decl is None:
                    continue  # Opens declarations are no-ops at this layer.
                if decl.gate_name in state_declarations:
                    raise ProjectRulesError(
                        f"duplicate state declaration for gate "
                        f"{decl.gate_name!r}"
                    )
                state_declarations[decl.gate_name] = decl
        # Unknown sections are silently dropped — _split_into_sections
        # already filters; if we got here, _KNOWN_SECTIONS contains the
        # name. (No else branch needed.)

    return ProjectRules(
        independent=tuple(independent),
        extensions={k: tuple(v) for k, v in extensions.items()},
        overrides={k: tuple(v) for k, v in overrides.items()},
        state_declarations=dict(state_declarations),
    )


def load_project_rules(path: Path) -> ProjectRules:
    """Read and parse a project-rules.md file."""
    if not path.exists():
        raise ProjectRulesError(f"project-rules file not found: {path}")
    text = path.read_text(encoding="utf-8")
    return parse_project_rules(text)


def validate_against_registry(
    rules: ProjectRules, registry: "GateRegistry"
) -> None:
    """Assert every gate reference resolves to a registered gate.

    Raises :exc:`ProjectRulesError` listing every unknown reference at
    once (parser-friendly: don't make the operator iterate one fix at
    a time).
    """
    unknown: list[str] = []
    for gate_name in rules.extensions:
        if gate_name not in registry:
            unknown.append(f"Extends `{gate_name}`")
    for gate_name in rules.overrides:
        if gate_name not in registry:
            unknown.append(f"Overrides `{gate_name}`")
    for gate_name in rules.state_declarations:
        if gate_name not in registry:
            decl = rules.state_declarations[gate_name]
            verb = "Closes" if decl.state == "closed" else "Opens"
            unknown.append(f"{verb} `{gate_name}`")
    if unknown:
        joined = ", ".join(unknown)
        raise ProjectRulesError(
            f"project-rules references unknown gates: {joined}"
        )


# ---------------------------------------------------------------------------
# Section + entry parsing
# ---------------------------------------------------------------------------


def _split_into_sections(text: str) -> dict[str, list["_RawEntry"]]:
    """Split markdown body into the four canonical sections.

    Each section's value is the list of level-3 entries belonging to
    it. Unknown level-2 headings are skipped (no error) so projects
    can add their own commentary sections without breaking the parser.
    """
    sections: dict[str, list[_RawEntry]] = {name: [] for name in _KNOWN_SECTIONS}
    current_section: str | None = None
    current_entry: _RawEntry | None = None

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if line.startswith("## "):
            if current_section is not None and current_entry is not None:
                sections[current_section].append(current_entry)
                current_entry = None
            heading = line[3:].strip()
            current_section = heading if heading in _KNOWN_SECTIONS else None
            continue
        if line.startswith("### "):
            if current_entry is not None and current_section is not None:
                sections[current_section].append(current_entry)
            current_entry = _RawEntry(heading=line[4:].strip(), lines=[])
            continue
        if current_entry is not None and current_section is not None:
            current_entry.lines.append(line)

    if current_entry is not None and current_section is not None:
        sections[current_section].append(current_entry)
    return sections


class _RawEntry:
    """Internal — a level-3 entry plus its body lines."""

    __slots__ = ("heading", "lines")

    def __init__(self, heading: str, lines: list[str]) -> None:
        self.heading = heading
        self.lines = lines


def _parse_bold_fields(lines: list[str]) -> tuple[dict[str, str], str]:
    """Split entry body into bold-prefixed fields plus residual prose.

    Returns (fields, body). ``fields`` keys are the bold prefix names
    (lower-cased, dashes preserved). ``body`` is the remaining prose
    after the bold-prefixed lines are removed.
    """
    fields: dict[str, str] = {}
    body_lines: list[str] = []
    for line in lines:
        match = _BOLD_FIELD_RE.match(line.strip())
        if match:
            key = match.group(1).strip().lower().replace(" ", "_")
            fields[key] = match.group(2).strip()
        else:
            body_lines.append(line)
    body = "\n".join(body_lines).strip()
    return fields, body


def _gate_ref_from_heading(heading: str) -> tuple[str, str]:
    """Parse ``Extends|Overrides|Closes|Opens \`gate.name\``` heading.

    Returns (verb, gate_name). Raises ProjectRulesError on malformed.
    """
    match = _GATE_REF_RE.match(heading)
    if match is None:
        raise ProjectRulesError(
            f"malformed gate-rule heading (expected "
            f"`Extends|Overrides|Closes|Opens \\`gate.name\\``): {heading!r}"
        )
    return match.group(1), match.group(2)


def _build_independent(entry: _RawEntry) -> IndependentRule:
    body = "\n".join(entry.lines).strip()
    return IndependentRule(name=entry.heading, body=body)


def _build_extension(entry: _RawEntry) -> GateExtension:
    verb, gate_name = _gate_ref_from_heading(entry.heading)
    if verb != "Extends":
        raise ProjectRulesError(
            f"§ Gate extensions must use Extends, got {verb!r}"
        )
    fields, body = _parse_bold_fields(entry.lines)
    if "extension" not in fields:
        raise ProjectRulesError(
            f"Extends `{gate_name}` is missing required **Extension:** field"
        )
    return GateExtension(
        gate_name=gate_name,
        extension=fields["extension"],
        why=fields.get("why"),
        cross_link=fields.get("cross-link") or fields.get("cross_link"),
        body=body,
    )


def _build_override(entry: _RawEntry) -> GateOverride:
    verb, gate_name = _gate_ref_from_heading(entry.heading)
    if verb != "Overrides":
        raise ProjectRulesError(
            f"§ Gate overrides must use Overrides, got {verb!r}"
        )
    fields, body = _parse_bold_fields(entry.lines)
    if "replacement" not in fields:
        raise ProjectRulesError(
            f"Overrides `{gate_name}` is missing required **Replacement:** field"
        )
    return GateOverride(
        gate_name=gate_name,
        replacement=fields["replacement"],
        why=fields.get("why"),
        cross_link=fields.get("cross-link") or fields.get("cross_link"),
        body=body,
    )


def _build_state_declaration(entry: _RawEntry) -> GateStateDeclaration | None:
    verb, gate_name = _gate_ref_from_heading(entry.heading)
    if verb not in ("Closes", "Opens"):
        raise ProjectRulesError(
            f"§ Gate state declarations must use Closes or Opens, got {verb!r}"
        )
    if verb == "Opens":
        # Opens is a documentation marker — gates default open, so it
        # produces no interceptor. We don't surface an entry in the
        # parsed rules either, since downstream consumers only care
        # about Closed declarations.
        return None
    fields, body = _parse_bold_fields(entry.lines)
    return GateStateDeclaration(
        gate_name=gate_name,
        state="closed",
        reason=fields.get("reason"),
        reopen_when=fields.get("re-open_when") or fields.get("reopen_when"),
        why=fields.get("why"),
        cross_link=fields.get("cross-link") or fields.get("cross_link"),
        body=body,
    )


# ---------------------------------------------------------------------------
# Project-rule → Interceptor conversion
# ---------------------------------------------------------------------------

def build_state_interceptors(
    gate: "Gate", rules: ProjectRules
) -> list[Interceptor]:
    """State-closure interceptors for ``gate``.

    A closed-state declaration short-circuits the chain at the
    outermost layer: ``enter`` writes a closed-state response,
    sets ``halt=True``, and unwinding runs through ``leave`` (no-op
    here) on the way out. The default evaluator never runs.
    """
    decl = rules.state_declarations.get(gate.name)
    if decl is None:
        return []
    return [_state_closed_interceptor(gate.name, decl)]


def build_override_interceptors(
    gate: "Gate", rules: ProjectRules
) -> list[Interceptor]:
    """Override interceptors for ``gate``.

    Each override writes the replacement response and halts. Multiple
    overrides on the same gate run in declaration order — the first
    halts the chain, so subsequent overrides are dead code (parser
    accepts them but they don't fire). This matches the spec's
    "replace → halt" semantic.
    """
    overrides = rules.overrides.get(gate.name, ())
    return [_override_interceptor(gate.name, ovr) for ovr in overrides]


def build_extension_interceptors(
    gate: "Gate", rules: ProjectRules
) -> list[Interceptor]:
    """Extension interceptors for ``gate``.

    Each extension augments the request on enter and tightens the
    response on leave. Multiple extensions chain in declaration order
    — first declared is outer-most.
    """
    extensions = rules.extensions.get(gate.name, ())
    return [_extension_interceptor(gate.name, ext) for ext in extensions]


# ---------------------------------------------------------------------------
# Per-section interceptor factories — the actual handlers.
# ---------------------------------------------------------------------------


def _state_closed_interceptor(
    gate_name: str, decl: GateStateDeclaration
) -> Interceptor:
    """Build an Interceptor that halts the chain with a closed-state response."""

    async def enter(ctx: Context) -> Context:
        return replace(
            ctx,
            halt=True,
            response={
                **ctx.response,
                gate_name: {
                    "state": "closed",
                    "reason": decl.reason,
                    "reopen_when": decl.reopen_when,
                    "source": "project_rules.state_declarations",
                },
            },
        )

    return Interceptor(
        enter=enter, name=f"project_rule.{gate_name}.state.closed"
    )


def _override_interceptor(gate_name: str, ovr: GateOverride) -> Interceptor:
    """Build an Interceptor that halts the chain with an override response."""

    async def enter(ctx: Context) -> Context:
        return replace(
            ctx,
            halt=True,
            response={
                **ctx.response,
                gate_name: {
                    "verdict": "override",
                    "replacement": ovr.replacement,
                    "why": ovr.why,
                    "cross_link": ovr.cross_link,
                    "source": "project_rules.overrides",
                },
            },
        )

    return Interceptor(enter=enter, name=f"project_rule.{gate_name}.override")


def _extension_interceptor(gate_name: str, ext: GateExtension) -> Interceptor:
    """Build an Interceptor that records the extension on the request + response.

    The `enter` handler appends a marker to ``ctx.request['extensions']``
    so the inner default evaluator sees the rule context. The `leave`
    handler appends to ``ctx.response[gate_name]['extensions']`` so the
    final response carries the audit trail. Neither handler short-
    circuits — extensions layer alongside the default evaluator.
    """

    async def enter(ctx: Context) -> Context:
        existing = ctx.request.get("extensions", ())
        new_request = dict(ctx.request)
        new_request["extensions"] = (
            *existing,
            {
                "gate": gate_name,
                "extension": ext.extension,
                "why": ext.why,
                "cross_link": ext.cross_link,
            },
        )
        return replace(ctx, request=new_request)

    async def leave(ctx: Context) -> Context:
        gate_response = dict(ctx.response.get(gate_name, {}))
        existing_exts = gate_response.get("extensions", ())
        gate_response["extensions"] = (
            *existing_exts,
            {
                "extension": ext.extension,
                "why": ext.why,
                "cross_link": ext.cross_link,
                "source": "project_rules.extensions",
            },
        )
        return replace(
            ctx, response={**ctx.response, gate_name: gate_response}
        )

    return Interceptor(
        enter=enter,
        leave=leave,
        name=f"project_rule.{gate_name}.extension",
    )


# ---------------------------------------------------------------------------
# Convenience iteration helpers
# ---------------------------------------------------------------------------

def all_referenced_gate_names(rules: ProjectRules) -> Iterable[str]:
    """Yield every gate name referenced in the rules. Used by the
    skill validator's anchor-resolution checks (#287)."""
    yield from rules.extensions.keys()
    yield from rules.overrides.keys()
    yield from rules.state_declarations.keys()


__all__ = [
    "GateExtension",
    "GateOverride",
    "GateStateDeclaration",
    "IndependentRule",
    "ProjectRules",
    "ProjectRulesError",
    "all_referenced_gate_names",
    "build_extension_interceptors",
    "build_override_interceptors",
    "build_state_interceptors",
    "load_project_rules",
    "parse_project_rules",
    "validate_against_registry",
]
