"""Thread handlers: post_turn, create_thread, fork_discussion,
update_project_toc, mark_discussion_decided, get_thread_comments.

Extended beyond #82's `{post_turn, create_thread, fork_discussion}`
spec to also host the orphan Discussion-side tools
(update_project_toc, mark_discussion_decided) and the general thread
reader (get_thread_comments). Keeping all Discussion-side tools
together matches the natural grouping of their github.discussions
dependencies and keeps issues.py focused on Issue-side workflow.
"""
from __future__ import annotations

from pathlib import Path

from mcp.types import TextContent

from ...adapters.types import Comment, Discussion
from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import dispatch_read, dispatch_write
from ...models import CreateThreadResult, ForkResult, PostTurnResult
from ...toc_composer import compose_post_reframe_toc
from ...utils import (
    check_deprecated_toc_sections,
    check_overwrite_size,
    resolve_new_body,
)
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import coord_ref, fetch_project_toc_body, make_canonical_ref, ok
from ._issue_creation import (
    classify_discussion_origin_id,
    create_issue_via_replication,
)


async def post_turn(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    speaker: str,
    body: str,
    proj_dir: Path,
) -> list[TextContent]:
    prefix = "**Claude:**" if speaker == "claude" else "**User:**"
    formatted = f"{prefix} {body}"

    # (#355 / D5.3) Daemon-routed append_comment. Pre-D5.3 this went
    # through ctx.replication.write directly; post-D5 the canonical
    # write boundary lives at the daemon's /writes endpoint. The
    # daemon reconstructs the typed ArtifactRef from the wire-level
    # fields + threads per-platform coords (#296) into each adapter.
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    parent_ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "append_comment",
        {
            "parent_kind": parent_kind,
            "parent_native_id": parent_ref.native_id,
            "owner": parent_ref.owner,
            "repo": parent_ref.repo,
            "body": formatted,
            "repo_role": "private",
        },
    )
    comment = Comment.model_validate(response["value"])

    ctx.activity.turns_posted += 1
    ctx.activity.turns_by_thread[thread_id] = (
        ctx.activity.turns_by_thread.get(thread_id, 0) + 1
    )

    toc_body = None
    if thread_id == ctx.config.project_discussion_id:
        toc_body = await fetch_project_toc_body(ctx)

    return ok(
        PostTurnResult(
            comment_id=comment.ref.native_id,
            comment_url=comment.url,
            project_toc_body=toc_body,
        ).model_dump()
    )


async def create_thread(
    ctx: ServerContext,
    thread_type: str,
    category_or_label: str,
    title: str,
    opening_body: str,
    discussion_origin_id: str,
    owner: str,
    repo: str,
    milestone: str | int | None = None,
) -> list[TextContent]:
    # (#484) Classify the origin-id shape at the boundary. Same
    # rationale as create_issue_tool — rejecting malformed strings
    # surfaces the misroute permanently rather than buffering for
    # replay. See classify_discussion_origin_id docstring for the
    # accepted forms.
    classify_discussion_origin_id(discussion_origin_id)
    if thread_type == "discussion":
        # #232 — milestones are an Issue concept; reject for Discussions
        # rather than silently dropping (caught at the boundary).
        if milestone is not None:
            raise ValueError(
                "milestone parameter is not supported for type='discussion'. "
                "GitHub Discussions cannot be assigned to milestones; pass "
                "milestone only when type='issue'."
            )
        # #295 — validate the category name early so callers see a
        # clear error before the dispatch runs. The set mirrors the
        # legacy GitHub-only path's cat_map plus the two
        # Announcements / Project running-log aliases (#191).
        valid_categories = {"Architecture", "UX / UI", "Ideas",
                            "Announcements", "Project"}
        if category_or_label not in valid_categories:
            raise ValueError(
                f"Unknown Discussion category: {category_or_label!r}. "
                "Must be one of: Architecture, UX / UI, Ideas, "
                "Announcements (or its legacy alias Project)"
            )
        # #295 — Discussion creation now dispatches through the
        # ReplicationManager (canonical-first; mirror fan-out queues
        # on failure). Pre-#295 this branch went GitHub-direct,
        # bypassing the canonical store and failing entirely on
        # GitHub-down. Each adapter handles category resolution per
        # its own conventions: GitHub looks up the GraphQL node ID
        # via the per-adapter `_discussion_categories` map captured
        # in `from_config`; Forgejo / GitLab encode as `category:*`
        # labels per the 3.0 OQ1 design; LocalStore writes the
        # category into `meta.json`.
        # (#355 / D5.4) Daemon-routed Discussion creation. Pre-D5.4
        # this went through ctx.replication.write directly; post-D5
        # the canonical write boundary lives at the daemon's /writes
        # endpoint. The daemon threads per-platform coords (#296)
        # into each adapter's create_discussion call.
        response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "create_discussion",
            {
                "owner": owner,
                "repo": repo,
                "title": title,
                "body": opening_body,
                "category": category_or_label,
                "repo_role": "private",
            },
        )
        discussion = Discussion.model_validate(response["value"])
        ctx.activity.discussions_created += 1
        return ok(
            CreateThreadResult(
                thread_id=discussion.ref.native_id,
                thread_number=discussion.ref.number or 0,
                thread_url=discussion.url or "",
                type="discussion",
                project_toc_body=await fetch_project_toc_body(ctx),
            ).model_dump()
        )

    # #274 — Issue branch dispatches through `create_issue_via_replication`,
    # the shared helper used by both create_thread and create_issue_tool.
    issue, _project_item_id = await create_issue_via_replication(
        ctx,
        owner=owner, repo=repo, title=title, body=opening_body,
        labels=[category_or_label], milestone=milestone,
    )
    return ok(
        CreateThreadResult(
            thread_id=issue.ref.native_id,
            thread_number=issue.ref.number,
            thread_url=issue.url,
            type="issue",
            project_toc_body=await fetch_project_toc_body(ctx),
        ).model_dump()
    )


async def fork_discussion(
    ctx: ServerContext,
    arguments: dict,
    owner: str,
    repo: str,
) -> list[TextContent]:
    """Execute fork sequence. Not atomic — no canonical store offers
    cross-artifact transactions. Partial failures are reported so the
    caller can retry.

    (#364, 3.9.0 D5) Refactored from GitHub-direct (`_s.*` calls) to
    daemon-routed dispatch through ``dispatch_write``. Each step
    (create_discussion + two append_comment posts) routes through
    the daemon's /writes endpoint so the canonical-store write
    succeeds first and mirror fan-out queues on failure. Same
    fix-class as #295 (3.4.1 — create_thread Discussion branch) and
    the broader Capability 8 read/write boundary work (#355 / #356).
    """
    original_id = arguments["original_id"]
    fork_point_comment_id = arguments["fork_point_comment_id"]  # noqa: F841 — reserved
    new_title = arguments["new_title"]
    category_name = arguments["category_name"]
    summary = arguments["summary"]
    original_url = arguments["original_discussion_url"]
    fork_point_url = arguments["fork_point_url"]

    # Mirror create_thread's category-validation: the four legacy
    # Discussion categories plus the Announcements / Project legacy
    # alias for running-log Discussions (#191).
    valid_categories = {"Architecture", "UX / UI", "Ideas",
                        "Announcements", "Project"}
    if category_name not in valid_categories:
        raise ValueError(
            f"Unknown Discussion category: {category_name!r}. Must be "
            f"one of: {sorted(valid_categories)}"
        )

    new_opening = (
        f"## Forked from: [{original_url}]({original_url})\n"
        f"Fork point: [{fork_point_url}]({fork_point_url})\n\n"
        f"## Context Summary\n{summary}\n\n"
        f"---\n*Conversation continues from here.*"
    )
    # (#364) Daemon-routed Discussion creation — same dispatch shape
    # as create_thread's Discussion branch (#295 / #355 D5.4). The
    # daemon resolves per-backend coords + category (label or node
    # ID) via the per-adapter `_discussion_categories` map.
    create_response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "create_discussion",
        {
            "owner": owner,
            "repo": repo,
            "title": new_title,
            "body": new_opening,
            "category": category_name,
            "repo_role": "private",
        },
    )
    new_disc = Discussion.model_validate(create_response["value"])
    new_disc_id = new_disc.ref.native_id
    new_disc_url = new_disc.url or ""

    # (#364) Daemon-routed comment append — same dispatch shape as
    # _record_turn_canonical (#355 D5.3). The original Discussion's
    # canonical ref is constructed via make_canonical_ref so the
    # daemon resolves it against the canonical store.
    original_ref = make_canonical_ref(
        ctx, kind="discussion", native_id=original_id,
    )

    fork_notice = (
        f"> ⚠️ This thread was partially forked.\n"
        f"> Content from [{fork_point_url}]({fork_point_url}) onward "
        f"continues in: **[{new_title}]({new_disc_url})**\n\n"
    )
    original_updated = False
    try:
        await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "append_comment",
            {
                "parent_kind": "discussion",
                "parent_native_id": original_ref.native_id,
                "owner": original_ref.owner,
                "repo": original_ref.repo,
                "body": fork_notice,
                "repo_role": "private",
            },
        )
        original_updated = True
    except Exception:  # noqa: BLE001 — best-effort notice
        # Per pre-#364 contract: notice failure doesn't cancel the
        # fork — the new Discussion is already created and the
        # canonical fork-comment below is the authoritative marker.
        original_updated = False

    fork_comment_body = (
        f"---\n"
        f"*Thread continues in [{new_title}]({new_disc_url}) from this point.*\n"
        f"---"
    )
    fork_comment_response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "append_comment",
        {
            "parent_kind": "discussion",
            "parent_native_id": original_ref.native_id,
            "owner": original_ref.owner,
            "repo": original_ref.repo,
            "body": fork_comment_body,
            "repo_role": "private",
        },
    )
    fork_comment = Comment.model_validate(fork_comment_response["value"])

    ctx.activity.forks_executed += 1
    return ok(
        ForkResult(
            new_discussion_id=new_disc_id,
            new_discussion_url=new_disc_url,
            original_updated=original_updated,
            fork_comment_id=fork_comment.ref.native_id,
            project_toc_body=await fetch_project_toc_body(ctx),
        ).model_dump()
    )


async def update_project_toc(
    ctx: ServerContext,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    body = resolve_new_body(new_body, new_body_path)
    # (#444) Pre-write validation against #439-deprecated section
    # reintroduction. Raises ValueError (permanent error per #465)
    # before the daemon round-trip when violated.
    check_deprecated_toc_sections(body, force)
    ref = make_canonical_ref(
        ctx, kind="discussion",
        native_id=ctx.config.project_discussion_id,
    )
    # (#356, 3.7.0 D8.2) Daemon-routed read mirroring D8.1.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "get_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    current_body = read_response.get("value", "")
    check_overwrite_size(current_body, body, force)
    # (#355 / D5.5) Daemon-routed body update.
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": body,
            "force": force,
            "repo_role": "private",
        },
    )
    # (#467 / #468 / 3.13.0 D-Friction.7+8) Fan out to per-platform
    # Project Index targets. The update_discussion_body call above
    # writes to the GitHub-side project_discussion_id; Codeberg /
    # Forgejo backends have the Project Index encoded as an Issue
    # whose body the new op replaces. Skipped platforms surface in
    # the response's mirror_skipped field.
    target_response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_body_on_per_platform_target",
        {
            "target_kind": "project_index",
            "body": body,
            "force": force,
        },
    )
    target_value = target_response.get("value") or {}
    mirror_skipped = target_value.get("skipped", [])
    if mirror_skipped:
        return ok({
            "message": "Project Discussion TOC updated.",
            "mirror_skipped": mirror_skipped,
        })
    return ok("Project Discussion TOC updated.")


async def update_discussion_body_tool(
    ctx: ServerContext,
    discussion_id: str,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    """Replace the opening post body of an arbitrary Discussion (#231).

    Mirrors `update_issue_toc` and `update_project_toc` — same fetch-
    then-replace semantics with size guardrail (#48), `new_body_path`
    file-path alternative for large bodies (#193 Phase A), and
    auto-buffer-on-failure dispatch wrapper.

    `update_project_toc` is the specialization for the configured
    Project Index Discussion. This tool is the generalization for any
    other Discussion — running-log Discussions in particular
    (Hermeticity log, Test coverage log, Protocol-rules-to-MCP-tools
    maps), where the opening post evolves session-by-session.
    """
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(ctx, kind="discussion", native_id=discussion_id)
    # (#356, 3.7.0 D8.2) Daemon-routed read mirroring D8.1.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "get_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    current_body = read_response.get("value", "")
    check_overwrite_size(current_body, body, force)
    # (#355 / D5.5) Daemon-routed body update.
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": body,
            "force": force,
            "repo_role": "private",
        },
    )
    return ok("Discussion opening post updated.")


async def unmark_decided(
    ctx: ServerContext,
    discussion_id: str,
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506 G5) Inverse of mark_discussion_decided
    — remove the "decided" axis from a Discussion's state.

    Multi-axis state.txt preserves non-decided axes. Idempotent
    on undecided Discussions. Closes the operator-undo gap for
    premature Decided ✓ markings.
    """
    ref = make_canonical_ref(ctx, kind="discussion", native_id=discussion_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "unmark_decided",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    return ok({
        "discussion_id": ref.native_id,
        "decided_removed": True,
    })


async def update_discussion_meta(
    ctx: ServerContext,
    discussion_id: str,
    fields: dict,
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506) Generic field-bag mutation for a
    Discussion. Closes G3 — pre-3.16.0 the only way to set
    ``anchored_milestone`` (consumed by the 3.10.0 D6.2
    stale_milestone_plan_gap detector) was direct meta.json file
    edits. This tool surfaces the generic field-bag updater
    introduced at the adapter layer by e2f3e0a.

    Field allowlist (enforced by the adapter):
      * ``title`` — Discussion title
      * ``body`` — Discussion opening post
      * ``category`` — Discussion category name (matches
        forge-config.json discussion_categories)
      * ``anchored_milestone`` — string version OR list of versions
        per 3.10.0 D6.2 OQ2 (multi-anchor support).
      * ``decided_at`` — Decided-✓ timestamp (ISO8601 string).

    Narrow ``update_discussion_body`` stays registered through one
    minor per OQ-02; new callers should use this tool for any
    discussion mutation that isn't body-only.
    """
    ref = make_canonical_ref(ctx, kind="discussion", native_id=discussion_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_discussion_meta",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "fields": dict(fields or {}),
            "repo_role": "private",
        },
    )
    return ok({
        "discussion_id": ref.native_id,
        "updated_fields": sorted(fields.keys()) if fields else [],
    })


async def compose_post_reframe_toc_tool(
    ctx: ServerContext,
    project_name: str,
    preamble: str,
    releases: str,
    milestones: str,
    discussions: str,
    cross_repo_activity: str,
    project_board_url: str,
    repos: str,
    pointer_line: str | None,
) -> list[TextContent]:
    """Compose the post-reframe TOC body from caller-supplied section
    markdown (#237, per Discussion #235).

    Pure-layout MCP wrapper around `toc_composer.compose_post_reframe_toc`.
    No GraphQL reads, no IO — the caller assembles per-section content
    from whatever sources fit (CHANGELOG.md for releases, GraphQL
    milestone reads, existing TOC for cross-repo activity, etc.) and
    this tool just enforces the canonical layout per #235.

    Returns:
      ``{"body": str, "size_bytes": int}``

    The body is suitable for direct round-trip through `update_project_toc(
    new_body=body, force=True)` — the post-reframe shrink will trip the
    size guardrail, which `force=True` bypasses legitimately.
    """
    body = compose_post_reframe_toc(
        project_name=project_name,
        preamble=preamble,
        releases=releases,
        milestones=milestones,
        discussions=discussions,
        cross_repo_activity=cross_repo_activity,
        project_board_url=project_board_url,
        repos=repos,
        pointer_line=pointer_line,
    )
    return ok({"body": body, "size_bytes": len(body)})


async def mark_decided(
    ctx: ServerContext,
    discussion_id: str,
    decision_comment_id: str,
    category_name: str,
) -> list[TextContent]:
    """(#486) Canonical-first Discussion-decided marker.

    Pre-#486 the handler ran two daemon ops in sequence —
    ``mark_decided`` (state.txt flip) then ``mark_answer`` (GitHub
    comment-as-answer). The pair worked when both succeeded, but
    when GitHub was unreachable the second op's failure left the
    canonical store with state flipped but no comment-as-answer
    marker. Worse: a caller passing a canonical-store comment
    path like ``discussions/22/comments/<ts>-<author>.md`` to the
    second op walked into a GraphQL call against GitHub that 403'd
    on the suspended account and propagated past the canonical
    success.

    Post-#486 the handler dispatches a single combined daemon op
    (``mark_discussion_decided``) that the canonical adapter
    executes atomically — LocalStore writes both state.txt and a
    sibling comment-marker file. Mirror fan-out (GitHub answer-
    mutation; Forgejo/GitLab decided-label) lands as
    MirrorWarning entries rather than propagating.

    ``decision_comment_id`` is classified at the boundary:
        * empty string → no comment marker; state-only flip.
        * canonical-store path
          (``discussions/<N>/comments/<file>`` or
          ``local://discussions/<N>/comments/<file>``) → passed
          through verbatim; LocalStore writes the metadata
          alongside; GitHub mirror skips the GraphQL mutation.
        * GitHub Discussion comment node ID (``DC_kwDO...``) →
          passed through verbatim; both adapters can act on it.
        * any other shape raises ValueError (permanent per
          #465/#485; doesn't buffer).

    ``category_name`` is preserved for backward-compatibility but
    no longer drives dispatch — every adapter handles the
    state-vs-answer surface internally via the combined Protocol
    method (#486).
    """
    from ...daemon_client import DaemonUnavailableError

    classified_comment = _classify_decision_comment_id(decision_comment_id)

    disc_ref = make_canonical_ref(
        ctx, kind="discussion", native_id=discussion_id,
    )

    args: dict = {
        "disc_native_id": disc_ref.native_id,
        "owner": disc_ref.owner,
        "repo": disc_ref.repo,
        "repo_role": "private",
    }
    if classified_comment is not None:
        args["comment_native_id"] = classified_comment

    state_flipped = False
    answer_marked = False
    mirror_warnings: list[dict] = []
    try:
        response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "mark_discussion_decided",
            args,
        )
        state_flipped = True
        # Answer marker is "performed canonically" whenever a comment
        # ref was passed — the LocalStore writes the sibling
        # metadata atomically with state.txt. Remote-side answer
        # mutation success is reflected in the absence of a
        # mirror warning for the operation.
        answer_marked = classified_comment is not None
        mirror_warnings = response.get("mirror_warnings", []) or []
    except (DaemonUnavailableError, NotImplementedError):
        state_flipped = False

    ctx.activity.discussions_decided += 1
    if state_flipped and answer_marked:
        message = (
            "Discussion marked as decided; comment marked as answer "
            "(canonical metadata written; mirror fan-out per state.txt + "
            "decided-label / Q&A answer mutation where supported)."
        )
    elif state_flipped:
        message = "Discussion marked as decided (state.txt flipped canonical-side)."
    else:
        message = "Decision comment posted. No canonical adapter reachable."
    return ok(
        {
            "state_flipped": state_flipped,
            "answer_marked": answer_marked,
            "message": message,
            "mirror_warnings": mirror_warnings,
            "project_toc_body": await fetch_project_toc_body(ctx),
        }
    )


# (#486) Decision-comment-id classification — same pattern as #484's
# discussion_origin_id classifier. Two accepted forms post-#486:
#   * Canonical-store comment path —
#     ``discussions/<N>/comments/<file>`` or
#     ``local://discussions/<N>/comments/<file>``.
#   * GitHub Discussion comment GraphQL node ID — ``DC_kwDO<rest>``.
# Empty string is accepted as "no comment marker"; any other shape
# raises ValueError so the misroute surfaces immediately per
# #465/#485.

import re as _re_for_classify  # local alias to keep top-of-file imports tidy

_CANONICAL_COMMENT_REF_RE = _re_for_classify.compile(
    r"^(?:local://)?discussions/\d+/comments/[^/]+$"
)
_GITHUB_COMMENT_NODE_ID_RE_HANDLER = _re_for_classify.compile(
    r"^DC_kwDO[A-Za-z0-9_\-]+$"
)


def _classify_decision_comment_id(value: str) -> str | None:
    """(#486) Validate + classify a decision_comment_id argument.

    Returns the verbatim string when it matches an accepted form;
    returns None for the empty-string case (no comment marker).
    Raises ValueError on any other shape — the dispatch wrapper
    classifies ValueError as permanent (#465/#485) so the misroute
    surfaces immediately rather than buffering.

    Pure function; no I/O.
    """
    if not value:
        return None
    if _CANONICAL_COMMENT_REF_RE.match(value) is not None:
        return value
    if _GITHUB_COMMENT_NODE_ID_RE_HANDLER.match(value) is not None:
        return value
    raise ValueError(
        "decision_comment_id must be one of: empty string (no "
        f"comment marker), a canonical-store comment path "
        f"('discussions/<N>/comments/<file>' or "
        f"'local://discussions/<N>/comments/<file>'), or a GitHub "
        f"Discussion comment GraphQL node ID ('DC_kwDO...'). Got: "
        f"{value!r}. The canonical-store form is recommended for "
        f"post-3.0 callers — LocalStore writes the answer metadata "
        f"alongside the comment file atomically with the parent "
        f"Discussion's state.txt flip (#486)."
    )


async def get_thread_comments(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    limit: int,
) -> list[TextContent]:
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    # (#356, 3.7.0 D8.3) Daemon-routed list_comments. Comment values
    # arrive as JSON dicts (model_dump output); reshape to legacy
    # `{comment_id, author, created_at, body}` for caller compat.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "list_comments",
        {
            "parent_kind": parent_kind,
            "parent_native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "limit": limit,
            "repo_role": "private",
        },
    )
    comments = read_response.get("value", [])
    # Pydantic mode="json" datetime → "...Z" suffix; pre-D8.3 path
    # used `.isoformat()` which emits "...+00:00". Normalize to the
    # latter for caller-visible string-format stability.
    legacy = [
        {
            "comment_id": (c.get("ref") or {}).get("native_id", ""),
            "author": c.get("author", ""),
            "created_at": (c.get("created_at") or "").replace("Z", "+00:00"),
            "body": c.get("body", ""),
        }
        for c in comments
    ]
    return ok({"comments": legacy})
