"""check_code_design handler (Phase D2.6 / #330 / #308).

Thin MCP-tool wrapper that walks the code_design registry and
dispatches each registered evaluator. Per #330 OQ5: effective
severity per gate flows from the gate registry's default state
plus project-rules `Extends` tightening; the evaluator receives
the resolved severity and emits findings carrying it.

The handler returns the structured response per the #330 sub-RFC
schema:

    {
        "findings": [...],
        "summary": {
            "rules_run": [...],
            "files_scanned": int,
            "findings_by_rule": {rule: count},
            "findings_by_severity": {severity: count}
        }
    }
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal

from mcp.types import TextContent

from ...code_design import (
    all_rules,
    finding_to_dict,
    get_evaluator,
)
from ...context import ServerContext
from ..helpers import err, ok
from ...models import OperationError


_VALID_RULES = frozenset({
    "schema_as_functions",
    "test_purity_tagging",
    "schema_tests_tagged",
    "negative_tests_tagged",
    "utility_dir_isolation",
    # (#344 / D3b.4q) Advisory tier — info-severity heuristics for
    # the judgment-heavy Rules 1/2/3. effect_inline_advisory ships
    # a real heuristic; the other two are 3.5.0 stubs (registered
    # but emit no findings) — full impl in 3.5.x.
    "effect_inline_advisory",
    "async_parity_advisory",
    "interceptor_reuse_advisory",
    "refactor_advisory",
})

# (#344, #346) Advisory rule names — used by the handler to surface
# `findings_by_tier` so operators can see at-a-glance which findings
# are mechanical (definitive) vs advisory (heuristic candidates).
_ADVISORY_RULES = frozenset({
    "effect_inline_advisory",
    "async_parity_advisory",
    "interceptor_reuse_advisory",
    "refactor_advisory",
})


def _resolve_severity(
    ctx: ServerContext,
    rule_name: str,
) -> Literal["fail", "warn", "info"]:
    """Compute the effective severity for a code_design rule.

    Per #330 OQ2 closure: default `warn` for all 5 mechanical
    gates. Project rules `Extends` can tighten to `fail` per the
    #288 framework. Registry default is the gate's `default_state`
    if loaded; otherwise hardcoded `warn`.

    The full evaluate_gate dispatch (#287 four-layer chain) is the
    canonical path; this resolver is the fast path that reads the
    same inputs without round-tripping through the chain. Same
    inputs → same output.
    """
    gate_name = f"code_design.{rule_name}"
    default = "warn"
    if ctx.gate_registry is not None:
        gate = ctx.gate_registry.get_gate(gate_name)
        if gate is not None:
            # gate.default_state is one of: "open", "closed", "deprecated"
            # — that's the lifecycle state, not the severity. The
            # severity defaults to `warn` for code_design gates per
            # #330 OQ2.
            pass
    if ctx.project_rules is not None:
        for ext in getattr(ctx.project_rules, "extends", []) or []:
            if getattr(ext, "gate_name", "") == gate_name:
                tightened = getattr(ext, "severity", None)
                if tightened in ("fail", "warn", "info"):
                    return tightened
    return default


async def check_code_design(
    ctx: ServerContext,
    *,
    rules: list[str] | None = None,
    paths: list[str] | None = None,
    severity_filter: str | None = None,
) -> list[TextContent]:
    """Run mechanical code-design evaluators against the project.

    Parameters mirror the #330 sub-RFC tool surface:

    - ``rules`` — subset of rules to run; empty / None → run all 5.
    - ``paths`` — subset of project-relative paths to scan; empty
      / None → walk from project root.
    - ``severity_filter`` — suppress findings below this severity
      in the response. None → include all.
    """
    if rules is not None:
        invalid = [r for r in rules if r not in _VALID_RULES]
        if invalid:
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"Unknown rules: {invalid}. Valid: "
                        f"{sorted(_VALID_RULES)}"
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

    selected_rules = rules if rules else all_rules()
    scan_paths = (
        [Path(p) for p in paths] if paths else None
    )

    severity_rank = {"fail": 3, "warn": 2, "info": 1}
    min_severity = severity_rank.get(severity_filter, 0) if severity_filter else 0

    findings = []
    findings_by_rule: dict[str, int] = {}

    for rule_name in selected_rules:
        evaluator = get_evaluator(rule_name)
        if evaluator is None:
            continue
        severity = _resolve_severity(ctx, rule_name)
        rule_findings = evaluator(ctx.project_dir, scan_paths, severity)
        kept = [
            f for f in rule_findings
            if severity_rank.get(f.severity, 0) >= min_severity
        ]
        findings.extend(kept)
        findings_by_rule[rule_name] = len(kept)

    findings_by_severity: dict[str, int] = {"fail": 0, "warn": 0, "info": 0}
    for f in findings:
        findings_by_severity[f.severity] = findings_by_severity.get(
            f.severity, 0,
        ) + 1

    # (#344) Distinguish mechanical vs advisory findings so the
    # operator sees at-a-glance which are definitive (mechanical
    # AST-pattern matches) vs candidates-for-review (heuristic
    # advisories for the judgment-heavy Rules 1/2/3).
    findings_by_tier: dict[str, int] = {"mechanical": 0, "advisory": 0}
    for f in findings:
        tier = "advisory" if f.rule in _ADVISORY_RULES else "mechanical"
        findings_by_tier[tier] += 1

    return ok({
        "findings": [finding_to_dict(f) for f in findings],
        "summary": {
            "rules_run": list(selected_rules),
            "findings_by_rule": findings_by_rule,
            "findings_by_severity": findings_by_severity,
            "findings_by_tier": findings_by_tier,
        },
    })
