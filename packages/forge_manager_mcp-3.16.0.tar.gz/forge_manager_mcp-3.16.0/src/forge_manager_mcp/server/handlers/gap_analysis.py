"""analyze_gaps handler (Phase 3.6.0 D1 / #348).

Runs registered gap detectors against the project. Mirrors
``check_code_design`` shape — same `rules` / `paths` /
`severity_filter` surface; returns findings + by_category +
by_severity summaries.
"""
from __future__ import annotations

from pathlib import Path

from mcp.types import TextContent

# Side-effect import: registers all detectors at module-load time.
import forge_manager_mcp.gap_analysis  # noqa: F401

from ...context import ServerContext
from ...gap_analysis import (
    all_detectors,
    gap_finding_to_dict,
    get_detector,
)
from ...models import OperationError
from ..helpers import err, ok


async def analyze_gaps(
    ctx: ServerContext,
    *,
    detectors: list[str] | None = None,
    paths: list[str] | None = None,
    severity_filter: str | None = None,
) -> list[TextContent]:
    """Run registered gap detectors and return aggregated findings.

    Parameters:
    - ``detectors`` — subset to run; empty / None → run all
      registered.
    - ``paths`` — project-relative paths to scan; empty / None →
      walk from project root.
    - ``severity_filter`` — suppress findings below this severity
      in the response. None → include all.
    """
    valid = set(all_detectors())
    if detectors is not None:
        invalid = [d for d in detectors if d not in valid]
        if invalid:
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"Unknown detectors: {invalid}. Valid: "
                        f"{sorted(valid)}"
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

    selected = detectors if detectors else list(valid)
    scan_paths = [Path(p) for p in paths] if paths else None

    severity_rank = {"fail": 3, "warn": 2, "info": 1}
    min_severity = (
        severity_rank.get(severity_filter, 0) if severity_filter else 0
    )

    findings: list = []
    by_detector: dict[str, int] = {}

    for det_name in selected:
        det = get_detector(det_name)
        if det is None:
            continue
        # Default severity: warn for all detectors. Project rules
        # can tighten via Extends entries on `gap_analysis.<name>`
        # gates (3.6.x extension).
        results = det(ctx.project_dir, scan_paths, "warn")
        kept = [
            f for f in results
            if severity_rank.get(f.severity, 0) >= min_severity
        ]
        findings.extend(kept)
        by_detector[det_name] = len(kept)

    by_severity: dict[str, int] = {"fail": 0, "warn": 0, "info": 0}
    by_category: dict[str, int] = {}
    for f in findings:
        by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
        by_category[f.category] = by_category.get(f.category, 0) + 1

    return ok({
        "findings": [gap_finding_to_dict(f) for f in findings],
        "summary": {
            "detectors_run": list(selected),
            "by_detector": by_detector,
            "by_severity": by_severity,
            "by_category": by_category,
        },
    })
