"""Gap-as-compound-doc MCP tool handlers (#405 / 3.11.0 D1.b Phase 2b).

Four state-transition tools forming the operator-driven triage
workflow per #405:

- ``triage_gap`` — flip back to triage state (re-open accepted/filed/ignored).
- ``accept_gap`` — commit to addressing in current plan; sets
  anchored_milestone + accepted_phase.
- ``file_gap`` — file Issue on future milestone; sets filed_issue +
  filed_target_milestone; gap closes-as-forwarded.
- ``ignore_gap`` — won't-fix decision; gap closes-as-rejected.

All four route through the daemon ``/writes`` endpoint via
``dispatch_write``. LocalStoreAdapter is the canonical for gap
artifacts in 3.11.0; remote backends raise NotImplementedError per
``has_gap_artifacts=False``.

The ``release.no_triage_gaps_against_cut`` plan-close gate (Phase
3) blocks cuts when any gap has state=triage anchored to the cut
milestone, so the workflow's load-bearing semantic is forcing a
decision (accept / file / ignore) before each cut.
"""
from __future__ import annotations

from typing import Any

from mcp.types import TextContent

from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import DaemonUnavailableError, dispatch_write
from ..helpers import ok


async def triage_gap(
    *,
    category: str,
    note: str | None = None,
    changed_by: str = "operator",
) -> list[TextContent]:
    """Flip a gap back to ``triage`` state.

    Used to re-open ``accepted`` / ``filed`` / ``ignored`` gaps when
    the operator wants to reconsider. Idempotent if already triage.
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_gap_state",
        {
            "category": category,
            "state": "triage",
            "changed_by": changed_by,
            "note": note,
            "repo_role": "private",
        },
    )
    return ok({
        "gap": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def accept_gap(
    *,
    category: str,
    anchored_milestone: str,
    accepted_phase: str | None = None,
    note: str | None = None,
    changed_by: str = "operator",
) -> list[TextContent]:
    """Accept a gap into the current plan's scope.

    Pins ``anchored_milestone`` so the gate knows which cut this
    decision applies to. ``accepted_phase`` optionally records which
    plan phase the gap belongs under.
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_gap_state",
        {
            "category": category,
            "state": "accepted",
            "changed_by": changed_by,
            "note": note,
            "anchored_milestone": anchored_milestone,
            "accepted_phase": accepted_phase,
            "repo_role": "private",
        },
    )
    return ok({
        "gap": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def file_gap(
    *,
    category: str,
    filed_issue: int,
    filed_target_milestone: str,
    note: str | None = None,
    changed_by: str = "operator",
) -> list[TextContent]:
    """File a gap as an Issue on a future milestone.

    The Issue creation itself happens via ``create_issue`` separately;
    this tool records the resulting Issue number + target milestone
    in ``meta.json.filed_issue`` / ``meta.json.filed_target_milestone``
    and flips state to ``filed``. The gap closes-as-forwarded — the
    operator's decision is captured, plan-close gate unblocks.
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_gap_state",
        {
            "category": category,
            "state": "filed",
            "changed_by": changed_by,
            "note": note,
            "filed_issue": filed_issue,
            "filed_target_milestone": filed_target_milestone,
            "repo_role": "private",
        },
    )
    return ok({
        "gap": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def ignore_gap(
    *,
    category: str,
    note: str,
    changed_by: str = "operator",
) -> list[TextContent]:
    """Mark a gap as won't-fix.

    ``note`` is required to force the operator to capture rationale
    (per #405 S3 — won't-fix decisions need a reason).
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_gap_state",
        {
            "category": category,
            "state": "ignored",
            "changed_by": changed_by,
            "note": note,
            "repo_role": "private",
        },
    )
    return ok({
        "gap": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def gaps_for_file(
    project_dir,
    path: str,
) -> list[TextContent]:
    """(#406 / 3.11.0 D2.a) Return active findings touching ``path``.

    Pure read over the canonical-store gap docs. Filters out
    findings on ``ignored`` gaps (per #406 decision rubric —
    ignored gaps stay silent always). Each returned finding carries
    its parent gap's ``state`` so Claude knows whether to surface
    in a pre-action statement (state=triage, severity≥warn) or
    address in-line (state=accepted).

    Returns an envelope ``{path, findings, categories_touching_path}``.
    Empty findings list when no gap has findings on the path or
    when the canonical store doesn't have a gaps/ directory yet.
    """
    from ...gap_analysis.walker import (
        categories_touching_path,
        findings_for_path,
        resolve_docs_root,
        walk_gap_metas,
    )

    docs_root = resolve_docs_root(project_dir)
    if docs_root is None:
        return ok({
            "path": path,
            "findings": [],
            "categories_touching_path": [],
        })
    metas = walk_gap_metas(docs_root)
    return ok({
        "path": path,
        "findings": findings_for_path(metas, path),
        "categories_touching_path": categories_touching_path(metas, path),
    })
