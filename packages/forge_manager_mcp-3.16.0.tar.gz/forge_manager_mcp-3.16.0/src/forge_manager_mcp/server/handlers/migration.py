"""Migration handlers: migrate_to_3_0, migrate_to_3_0_rollback,
add_backend (3.0 / Phase 7).

The handlers are thin wrappers over the ``forge_manager_mcp.migration``
package — detector + runner — plus a small ``add_backend`` shim that
appends a platform entry to the project's forge-config.json.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mcp.types import TextContent

from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import (
    dispatch_migration_remove,
    dispatch_migration_upsert,
)
from ...flows.migration import build_migration_chain
from ...interceptors import aexecute
from ...migration import (
    detect_legacy_state,
    rollback_plan as _rollback_plan,
)
from ..helpers import ok


# Map MigrationPlan step.kind → chain interceptor's response key. The
# chain wrappers locate their target step in plan.steps by `kind`; this
# dict reverses that for the response-shape reconstruction.
_KIND_TO_CHAIN_STEP: dict[str, str] = {
    "translate_config_schema": "translate_schema",
    "rename_skill_dir": "rename_skill_dir",
    "bootstrap_docs_repo": "bootstrap_docs_repo",
    "update_claude_md": "rewrite_claude_md",
}


def _reconstruct_steps_list(
    plan: Any, response: dict[str, Any], apply: bool,
) -> list[dict[str, Any]]:
    """Project chain-step responses back onto the plan-step list.

    The pre-#294 handler returned ``result["steps"]`` from
    ``_apply_plan``, where each entry was
    ``{"kind", "description", "executed"}`` (with ``"dry_run": True``
    in dry-run mode). The chain stores per-step state in
    ``ctx.response[<chain-step-name>]``; this helper re-projects that
    into the response shape the existing tests + downstream consumers
    expect.
    """
    out: list[dict[str, Any]] = []
    for step in plan.steps:
        chain_name = _KIND_TO_CHAIN_STEP.get(step.kind)
        chain_state = response.get(chain_name, {}) if chain_name else {}
        status = chain_state.get("status")
        entry: dict[str, Any] = {
            "kind": step.kind,
            "description": step.description,
        }
        if not apply:
            entry["executed"] = False
            entry["dry_run"] = True
        else:
            entry["executed"] = status == "ok"
            if status not in ("ok", None):  # pragma: no cover — DEFENSIVE: current migration chain steps either return status="ok" or raise; no step writes a non-ok / non-None status string. Reachable only if a future step adopts a "failed-but-don't-raise" convention.
                entry["error"] = chain_state.get(
                    "error", f"status={status}",
                )
        out.append(entry)
    return out


_FORGE_CONFIG = Path(".claude/forge-config.json")
_LEGACY_CONFIG = Path(".claude/github-config.json")


# (3.16.0 D1 / A.1 write-back) Operator-facing titles for the
# migration chain's steps. Keyed by the chain-step name (the same
# names that appear in _STEP_FACTORIES + _FULL_MIGRATION_ORDER in
# flows/migration/__init__.py). Used to populate the migration
# state holder so the UI's <MigrationSwimlane> renders step titles
# rather than raw kebab-case identifiers.
_MIGRATION_STEP_TITLES: dict[str, str] = {
    "backup_claude_dir": "Backup .claude/ directory",
    "detect_legacy_state": "Detect legacy state",
    "translate_schema": "Translate config schema",
    "rename_skill_dir": "Rename skill directory",
    "bootstrap_docs_repo": "Bootstrap docs repo",
    "rewrite_claude_md": "Rewrite CLAUDE.md",
    "backfill_canonical_from_remote": "Backfill canonical from remote",
    "finalize": "Finalize",
}


def _build_migration_state_record(
    migration_id: str, title: str, chain_step_names: list[str],
) -> dict[str, Any]:
    """Construct the migration-state record passed to
    ``dispatch_migration_upsert`` for a chain run.

    All steps default to ``"preview"`` state at upsert time. Per-step
    "running" / "complete" flips happen via separate
    ``dispatch_migration_step`` calls (deferred to a follow-up commit
    that wraps each interceptor with a publishing wrapper).
    """
    return {
        "id": migration_id,
        "title": title,
        "steps": [
            {
                "id": name,
                "title": _MIGRATION_STEP_TITLES.get(name, name),
                "state": "preview",
            }
            for name in chain_step_names
        ],
    }


# Chain step ordering for the 3.0 migration. Matches
# flows/migration/__init__.py::_FULL_MIGRATION_ORDER minus the
# excluded ``backfill_canonical_from_remote`` (that step is operator-
# driven via ``import_remote_changes`` per the handler comment).
_MIGRATION_3_0_CHAIN_STEPS: tuple[str, ...] = (
    "backup_claude_dir",
    "detect_legacy_state",
    "translate_schema",
    "rename_skill_dir",
    "bootstrap_docs_repo",
    "rewrite_claude_md",
    "finalize",
)


# Manual-step notes attached to migrate_to_3_0 responses (G7-G10).
# These cover the parts of the 2.x → 3.0 migration the runner can't
# automate either because they're operator-environment-specific
# (PyPI, env vars, shell config) or because they touch the live
# project beyond the .claude/ directory the migration owns.
_POST_MIGRATION_MANUAL_STEPS: tuple[str, ...] = (
    # G7 — replication_order is a default; operator may want to reorder
    # or extend it once they've added Forgejo / GitLab platforms.
    "Review `.claude/forge-config.json` `replication_order` (defaults to "
    "`[\"local\", \"github\"]`). To add a non-GitHub backend, run "
    "`add_backend` with the platform_id (`forgejo` / `gitlab` / `codeberg`) "
    "and the platform-specific config dict. Reorder `replication_order` "
    "manually to choose canonical / fan-out order.",
    # G8 — skill prose itself isn't translated; the rename only moves the
    # directory. Operator must re-install the 3.0 skill bundle.
    "Re-install the 3.0 skill bundle into "
    "`.claude/skills/forge-manager/` (the migration renamed the directory "
    "but kept its contents — content still references the 2.x name in "
    "places). Download the latest `forge-manager.md` from the public "
    "mirror's release assets and write it to "
    "`.claude/skills/forge-manager/SKILL.md`.",
    # G9 — env var rename / new defaults.
    "If you previously set `$ACTIVE_CLAUDE_GITHUB_DOCS_REPO` (rare — was "
    "not a documented 2.x var), rename it to `$FORGE_MANAGER_DOCS_REPO`. "
    "If you want the docs repo at a non-default location, set "
    "`$FORGE_MANAGER_DOCS_REPO` in your shell profile.",
    # G10 — PyPI package + .mcp.json command rename.
    "Update the MCP install: `pipx uninstall active-claude-github-mcp && "
    "pipx install forge-manager-mcp` (or `pip` equivalent). Edit "
    "`.mcp.json` so the entry's `command` is `forge-manager-mcp` (was "
    "`active-claude-github-mcp` in 2.x). Restart Claude Code so it "
    "picks up the new server binary.",
)


async def migrate_to_3_0(
    ctx: ServerContext,
    apply: bool = False,
) -> list[TextContent]:
    """Detect 2.x legacy state in ctx.project_dir and produce/apply a
    migration plan.

    ``apply=False`` (default) → dry-run; returns the steps the
    migration would take without modifying the filesystem.

    ``apply=True`` → creates a backup of .claude/ and applies each
    step in order. The returned dict carries the backup path; use
    it with ``migrate_to_3_0_rollback`` to revert.
    """
    plan = detect_legacy_state(ctx.project_dir)
    if plan.is_clean:
        return ok({
            "success": True,
            "is_clean": True,
            "summary": plan.summary(),
            "manual_steps": [],
        })

    # ----- Dispatch via migration chain (#294 Phase B) ----------------------
    # The chain wraps backup_claude_dir → detect_legacy_state →
    # translate_schema → rename_skill_dir → bootstrap_docs_repo →
    # rewrite_claude_md → finalize as compensating-transaction
    # interceptors per Discussion #3 §"Per-flow application table —
    # migrate_to_3_0". RAII pattern on backup_claude_dir: success path
    # deletes the tarball; error path preserves it for rollback. The
    # backfill_canonical_from_remote step is excluded today — backfill
    # is a separate operator-driven flow via import_remote_changes.
    chain = build_migration_chain(apply=apply, include_backfill=False)

    # (3.16.0 D1 / A.1 write-back) Register the in-flight migration
    # with the daemon's holder so the UI's <MigrationSwimlane> can
    # show live progress. Best-effort: if the daemon's unreachable
    # or returns 4xx/5xx, the migration still runs locally; only the
    # UI loses live-view. dry-run (apply=False) skips the upsert
    # entirely — no in-flight migration to broadcast.
    migration_id: str | None = None
    if apply:
        migration_id = "migration:to-3-0"
        await dispatch_migration_upsert(
            state_dir(DEFAULT_PROJECT_NAME),
            _build_migration_state_record(
                migration_id=migration_id,
                title="Migrate to 3.0",
                chain_step_names=list(_MIGRATION_3_0_CHAIN_STEPS),
            ),
        )

    final_ctx = await aexecute(
        chain,
        request={
            "project_dir": ctx.project_dir,
            "apply": apply,
            "plan": plan,
        },
    )

    # (3.16.0 D1 / A.1 write-back) On chain completion, dismiss the
    # migration from the holder so the swimlane clears for the next
    # run. On failure path we leave the holder populated so the
    # operator can inspect via the UI which step was in-flight at
    # the failure boundary. (Per-step "running" / "complete"
    # transitions during the chain run are deferred to a follow-up
    # commit that wraps each interceptor with a publishing wrapper —
    # today the UI sees preview → preview-disappear on success and
    # preview-stays on failure; not ideal but functional.)
    if migration_id is not None and final_ctx.error is None:
        await dispatch_migration_remove(
            state_dir(DEFAULT_PROJECT_NAME), migration_id,
        )

    backup_path = final_ctx.response.get(
        "backup_claude_dir", {},
    ).get("backup_path")

    if final_ctx.error is not None:
        return ok({
            "success": False,
            "error": str(final_ctx.error),
            "summary": plan.summary(),
            "backup_path": str(backup_path) if backup_path else None,
        })

    return ok({
        "success": True,
        "applied": apply,
        "summary": plan.summary(),
        # G7-G10: post-migration operator checklist that the runner can't
        # automate — replication_order tuning, skill-prose re-install,
        # env var rename, PyPI/MCP wiring update.
        "manual_steps": list(_POST_MIGRATION_MANUAL_STEPS),
        "project_dir": str(plan.project_dir),
        "steps": _reconstruct_steps_list(plan, final_ctx.response, apply),
        "backup_path": str(backup_path) if backup_path else None,
        "warnings": list(plan.warnings),
    })


async def migrate_to_3_0_rollback(
    ctx: ServerContext,
    backup_path: str,
) -> list[TextContent]:
    """Restore .claude/ from a backup produced by migrate_to_3_0(apply=True)."""
    try:
        result = _rollback_plan(
            project_dir=ctx.project_dir,
            backup_path=Path(backup_path),
        )
    except Exception as exc:
        return ok({"success": False, "error": str(exc)})
    return ok({"success": True, **result})


async def migrate_to_3_5(
    ctx: ServerContext,
    apply: bool = False,
) -> list[TextContent]:
    """(#332 / D3b.4f) Capture env-var tokens into the daemon's
    encrypted credentials store.

    ``apply=False`` (default) → dry-run; returns the planned steps
    + per-platform sources without writing.

    ``apply=True`` → backs up the state-dir + .claude/, then writes
    `credentials.enc` + `credentials.key` to the daemon's state-
    dir. Returns the backup path for use with
    `migrate_to_3_5_rollback`.

    Idempotent: re-run when credentials.enc already exists →
    `is_clean=True` no-op.
    """
    from forge_manager_mcp.daemon.paths import (
        DEFAULT_PROJECT_NAME, state_dir,
    )
    from forge_manager_mcp.migrations.migrate_3_5 import (
        apply_migration, detect_3_5_state,
    )

    sd = state_dir(DEFAULT_PROJECT_NAME)
    platform_ids = (
        [p.id for p in ctx.config.platforms]
        if (ctx.config is not None and ctx.config.platforms)
        else []
    )
    plan = detect_3_5_state(ctx.project_dir, sd, platform_ids)

    if plan.is_clean:
        return ok({
            "success": True,
            "is_clean": True,
            "summary": (
                f"Already migrated or no work needed: {', '.join(plan.warnings) or '(no warnings)'}"
            ),
            "manual_steps": [],
            "warnings": list(plan.warnings),
        })

    summary = (
        f"3.4.x → 3.5.0 credentials migration. "
        f"Platforms: {list(plan.platform_ids)}. "
        f"Env-present: {list(plan.env_present)}. "
        f"Env-missing: {list(plan.env_missing)}. "
        f"State-dir: {plan.state_dir}."
    )

    if not apply:
        # Dry-run — no mutation.
        return ok({
            "success": True,
            "applied": False,
            "is_clean": False,
            "summary": summary,
            "platform_ids": list(plan.platform_ids),
            "env_present": list(plan.env_present),
            "env_missing": list(plan.env_missing),
            "warnings": list(plan.warnings),
            "manual_steps": [
                "Re-run with apply=True to perform the migration.",
            ],
        })

    try:
        result = apply_migration(plan)
    except Exception as exc:
        return ok({
            "success": False,
            "error": str(exc),
            "summary": summary,
        })

    return ok({
        "success": result["success"],
        "applied": True,
        "is_clean": False,
        "summary": summary,
        "captured": result["captured"],
        "backup_path": result["backup_path"],
        "manual_steps": result["manual_steps"],
        "platform_ids": list(plan.platform_ids),
        "env_missing": list(plan.env_missing),
        "warnings": list(plan.warnings),
    })


async def migrate_to_3_5_rollback(
    ctx: ServerContext,
    backup_path: str,
) -> list[TextContent]:
    """Restore the state-dir + .claude/ from a backup produced by
    migrate_to_3_5(apply=True)."""
    from forge_manager_mcp.daemon.paths import (
        DEFAULT_PROJECT_NAME, state_dir,
    )
    from forge_manager_mcp.migrations.migrate_3_5 import restore_to_targets

    sd = state_dir(DEFAULT_PROJECT_NAME)
    try:
        result = restore_to_targets(
            Path(backup_path),
            project_dir=ctx.project_dir,
            state_dir=sd,
        )
    except Exception as exc:
        return ok({"success": False, "error": str(exc)})
    return ok(result)


async def migrate_to_4_0(
    ctx: ServerContext,
    apply: bool = False,
) -> list[TextContent]:
    """(#299 / 3.6.0 D3) Schema 3.x → 4.0 forge-config.json migration.

    Hard-cutover per Discussion #6 OQ1. Moves top-level
    `discussion_categories` into per-platform configuration so each
    backend can declare its own category map (today GitHub-only).

    ``apply=False`` (default) → dry-run; returns the plan shape
    + transformations that would happen.

    ``apply=True`` → backs up `.claude/`; rewrites forge-config.json
    to the 4.0 shape; returns backup_path for rollback.

    Idempotent: re-run when schema_version == "4.0" → no-op.
    """
    from forge_manager_mcp.migrations.migrate_4_0 import (
        apply_migration as apply_4_0,
        detect_4_0_state,
    )

    plan = detect_4_0_state(ctx.project_dir)

    if plan.is_clean:
        return ok({
            "success": True,
            "is_clean": True,
            "summary": (
                f"Already at schema 4.0 or no migration needed: "
                f"{', '.join(plan.warnings) or '(no warnings)'}"
            ),
            "current_schema": plan.current_schema,
            "manual_steps": [],
            "warnings": list(plan.warnings),
        })

    summary = (
        f"3.x → 4.0 schema migration. "
        f"Current schema: {plan.current_schema!r}. "
        f"Top-level discussion_categories present: "
        f"{plan.has_top_level_categories}. "
        f"GitHub platform index: {plan.github_platform_index}."
    )

    if not apply:
        return ok({
            "success": True,
            "applied": False,
            "is_clean": False,
            "summary": summary,
            "current_schema": plan.current_schema,
            "has_top_level_categories": plan.has_top_level_categories,
            "github_platform_index": plan.github_platform_index,
            "warnings": list(plan.warnings),
            "manual_steps": [
                "Re-run with apply=True to perform the migration.",
            ],
        })

    try:
        result = apply_4_0(plan)
    except Exception as exc:
        return ok({
            "success": False,
            "error": str(exc),
            "summary": summary,
        })

    return ok({
        "success": result["success"],
        "applied": True,
        "is_clean": False,
        "summary": summary,
        "transformations": result["transformations"],
        "backup_path": result["backup_path"],
        "manual_steps": result["manual_steps"],
        "warnings": list(plan.warnings),
    })


async def migrate_to_4_0_rollback(
    ctx: ServerContext,
    backup_path: str,
) -> list[TextContent]:
    """Restore .claude/ from a backup produced by migrate_to_4_0(apply=True)."""
    from forge_manager_mcp.migrations.migrate_4_0 import (
        restore_to_targets as restore_4_0,
    )
    try:
        result = restore_4_0(
            Path(backup_path), project_dir=ctx.project_dir,
        )
    except Exception as exc:
        return ok({"success": False, "error": str(exc)})
    return ok(result)


async def migrate_to_4_1(
    ctx: ServerContext,
    apply: bool = False,
) -> list[TextContent]:
    """(#397 / 3.11.0 D1.a Phase 3b) Backfill milestones-as-compound-docs.

    Walks ``<docs>/issues/*/meta.json`` for unique ``milestone``
    values, then creates a corresponding ``milestones/<version>/``
    compound doc for each version that doesn't yet have one.
    Tier defaults to semver-inferred (major / minor / patch);
    hotfix defaults to False; plan_discussion defaults to None
    (operator pins later via ``set_milestone_plan``).

    ``apply=False`` (default) → dry-run; reports the versions
    that would be materialized.

    ``apply=True`` → creates the compound docs. Idempotent —
    versions with an existing compound doc are skipped.

    No rollback module: creation is reversible by deleting
    ``<docs>/milestones/<version>/`` directly. The
    ``release.milestone_has_plan`` gate (Phase 3a / #397) returns
    ``inconclusive`` against pre-D1.a milestones until this
    migration materializes the compound docs.

    MVP scope per #397 D4 — full migration (prose-heuristic
    plan_discussion resolution + CHANGELOG body.md backfill) ships
    as a follow-on enhancement.
    """
    from forge_manager_mcp.migrations.migrate_4_1 import (
        apply_migration as apply_4_1,
        detect_4_1_state,
    )

    plan = detect_4_1_state(ctx.project_dir)

    if plan.is_clean:
        return ok({
            "success": True,
            "is_clean": True,
            "summary": (
                f"No milestones to migrate. "
                f"{len(plan.versions_already_materialized)} versions "
                f"already materialized; "
                f"{len(plan.versions_present)} versions referenced "
                f"by Issues. "
                f"{', '.join(plan.warnings) or '(no warnings)'}"
            ),
            "versions_already_materialized": list(
                plan.versions_already_materialized,
            ),
            "warnings": list(plan.warnings),
        })

    summary = (
        f"Migration plan: materialize "
        f"{len(plan.versions_to_create)} milestone compound docs. "
        f"{len(plan.versions_already_materialized)} already present; "
        f"{len(plan.versions_present)} versions referenced overall."
    )

    if not apply:
        return ok({
            "success": True,
            "applied": False,
            "is_clean": False,
            "summary": summary,
            "versions_to_create": list(plan.versions_to_create),
            "versions_already_materialized": list(
                plan.versions_already_materialized,
            ),
            "warnings": list(plan.warnings),
            "manual_steps": [
                "Re-run with apply=True to materialize the compound docs.",
                "After apply, optionally use set_milestone_plan(version, "
                "plan_discussion=<N>) to pin anchored planning Discussion(s) "
                "for each milestone.",
                "After apply, optionally use update_milestone_body(version, "
                "body=<...>) to populate the narrative summary from each "
                "milestone's CHANGELOG entry.",
            ],
        })

    try:
        result = apply_4_1(plan)
    except Exception as exc:
        return ok({
            "success": False,
            "error": str(exc),
            "summary": summary,
        })

    return ok({
        "success": result["success"],
        "applied": True,
        "is_clean": False,
        "summary": summary,
        "materialized": result["materialized"],
        "skipped": result["skipped"],
        "warnings": result["warnings"],
        "manual_steps": [
            f"Pin plan_discussion for the materialized "
            f"{len(result['materialized'])} milestones via "
            "set_milestone_plan(version, plan_discussion=<N>).",
        ],
    })


async def add_backend(
    ctx: ServerContext,
    platform_id: str,
    config: dict[str, Any],
) -> list[TextContent]:
    """Append a new platform entry to the project's forge-config.json
    platforms list.

    The handler validates that the new platform_id isn't already
    registered (idempotent — second call with same platform_id is a
    no-op + reports already-present), and writes the updated config
    back. Token validation is deferred to the next session start;
    surfacing it here would require the adapter classes which are a
    separate import surface.
    """
    config_path = ctx.project_dir / _FORGE_CONFIG
    if not config_path.is_file():
        # Fall back to the legacy config path; common during partial
        # migration windows.
        legacy_path = ctx.project_dir / _LEGACY_CONFIG
        if legacy_path.is_file():
            return ok({
                "success": False,
                "error": (
                    "Project still on legacy github-config.json. Run "
                    "migrate_to_3_0 with apply=True before adding "
                    "additional backends."
                ),
            })
        return ok({
            "success": False,
            "error": f"forge-config.json not found at {config_path}",
        })

    try:
        existing = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return ok({"success": False, "error": f"could not parse forge-config: {exc}"})

    platforms = existing.setdefault("platforms", [])
    for entry in platforms:
        if entry.get("id") == platform_id:
            return ok({
                "success": True,
                "already_present": True,
                "platform_id": platform_id,
                "platforms": platforms,
            })

    new_entry = {"id": platform_id, **config}
    platforms.append(new_entry)

    # Replication order — append the new platform if not already there.
    repl_order = existing.setdefault("replication_order", ["local"])
    if platform_id not in repl_order:
        repl_order.append(platform_id)

    config_path.write_text(
        json.dumps(existing, indent=2) + "\n", encoding="utf-8",
    )
    return ok({
        "success": True,
        "added": True,
        "platform_id": platform_id,
        "platforms": platforms,
        "replication_order": repl_order,
    })
