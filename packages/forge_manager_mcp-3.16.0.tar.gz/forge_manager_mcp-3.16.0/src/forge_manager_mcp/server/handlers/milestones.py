"""Milestone-artifact MCP tool handlers (#397 / 3.11.0 D1.a Phase 2b).

Five tools:

- ``create_milestone`` — write a new ``milestones/<version>/`` compound doc.
- ``update_milestone_body`` — replace the narrative ``body.md``.
- ``mark_milestone_active`` — flip lifecycle planned → active.
- ``close_milestone`` — flip lifecycle active → closed; stamps cut_at.
- ``set_milestone_plan`` — pin ``meta.json.plan_discussion`` to a Discussion.

All five route through the daemon ``/writes`` endpoint so the
canonical-store write succeeds first and mirror fan-out queues on
failure (per #355 / 3.6.0 D5 contract). LocalStoreAdapter is the
canonical for milestone artifacts in 3.11.0 — GitHub / Forgejo /
GitLab adapters raise NotImplementedError per
``has_milestone_artifacts=False``; the dispatch layer handles graceful
degrade through the existing buffer-on-failure path.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from mcp.types import TextContent

from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import DaemonUnavailableError, dispatch_write
from ..helpers import ok


async def create_milestone(
    *,
    version: str,
    tier: str,
    hotfix: bool = False,
    plan_discussion: int | list[int] | None = None,
    title: str = "",
    body: str = "",
) -> list[TextContent]:
    """Create a new milestone compound-doc."""
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "create_milestone",
        {
            "version": version,
            "tier": tier,
            "hotfix": hotfix,
            "plan_discussion": plan_discussion,
            "title": title,
            "body": body,
            "repo_role": "private",
        },
    )
    return ok({
        "milestone": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def update_milestone_body(
    *,
    version: str,
    body: str,
) -> list[TextContent]:
    """Replace ``body.md`` for an existing milestone."""
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_milestone_meta",
        {
            "version": version,
            "fields": {"body": body},
            "repo_role": "private",
        },
    )
    return ok({
        "milestone": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def update_milestone_meta(
    *,
    version: str,
    fields: dict,
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506 G4 strict) Generic field-bag mutation
    for a milestone. The narrow shims (``update_milestone_body``,
    ``set_milestone_plan``) stay registered for one minor per
    OQ-02, but this is the canonical tool going forward.

    Closes the originally-surfaced gap that motivated RFC #506:
    operators no longer need to edit ``title.md`` directly to
    rename a milestone. The adapter's ``update_milestone_meta``
    already accepted the title field (and tier / hotfix /
    cut_at / tag_sha etc.); this commit just routes the MCP tool
    surface through the generic dispatch instead of narrow shims.

    Field allowlist (adapter-enforced):
      * ``title`` — milestone display title.
      * ``body`` — milestone body.md.
      * ``plan_discussion`` — int or list of ints.
      * ``cut_at`` — ISO8601 timestamp string.
      * ``tag_sha`` — git commit SHA.
      * ``hotfix`` — boolean.
      * ``tier`` — "major" | "minor" | "patch".
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_milestone_meta",
        {
            "version": version,
            "fields": dict(fields or {}),
            "repo_role": "private",
        },
    )
    return ok({
        "milestone": response.get("value"),
        "updated_fields": sorted(fields.keys()) if fields else [],
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def mark_milestone_active(
    *,
    version: str,
) -> list[TextContent]:
    """Flip a planned milestone to active. Idempotent if already active."""
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_milestone_state",
        {
            "version": version,
            "state": "active",
            "repo_role": "private",
        },
    )
    return ok({
        "milestone": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })


async def close_milestone(
    *,
    version: str,
    tag_sha: str | None = None,
) -> list[TextContent]:
    """Close a milestone (state → closed, cut_at stamped).

    When ``tag_sha`` is provided, also pins ``meta.json.tag_sha`` to
    the cut commit so the milestone records which SHA was tagged.
    """
    state_response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_milestone_state",
        {
            "version": version,
            "state": "closed",
            "repo_role": "private",
        },
    )
    final_value = state_response.get("value")
    mirror_warnings = list(state_response.get("mirror_warnings", []))
    if tag_sha is not None:
        meta_response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "update_milestone_meta",
            {
                "version": version,
                "fields": {"tag_sha": tag_sha},
                "repo_role": "private",
            },
        )
        final_value = meta_response.get("value")
        mirror_warnings.extend(meta_response.get("mirror_warnings", []))
    return ok({
        "milestone": final_value,
        "mirror_warnings": mirror_warnings,
    })


async def set_milestone_plan(
    *,
    version: str,
    plan_discussion: int | list[int] | None,
) -> list[TextContent]:
    """Pin ``meta.json.plan_discussion`` on an existing milestone.

    Pass a single int when one plan scopes the milestone, a list of
    ints for multi-anchor (#390 OQ2 b symmetric shape), or None to
    clear (e.g. when a hotfix milestone shouldn't carry a plan link).
    """
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_milestone_meta",
        {
            "version": version,
            "fields": {"plan_discussion": plan_discussion},
            "repo_role": "private",
        },
    )
    return ok({
        "milestone": response.get("value"),
        "mirror_warnings": response.get("mirror_warnings", []),
    })
