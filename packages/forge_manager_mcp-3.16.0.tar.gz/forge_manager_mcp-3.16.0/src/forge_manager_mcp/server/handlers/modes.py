"""Mode-registry MCP tool handlers (#501).

Three tools:

- ``list_modes`` — resolved mode list (skill + per-project), each
  with its gate-state declarations. Reads ``modes.yaml`` directly;
  no daemon round-trip needed (the registry is small + filesystem-
  local).
- ``get_current_mode`` — currently-computed mode label. Round-trips
  through the daemon's ``GET /modes/current`` so the canonical
  gate-state snapshot lives in one place.
- ``set_mode`` — apply a mode by name (or preview via ``dry_run``).
  Round-trips through ``POST /modes/{name}`` so the daemon broadcasts
  ``mode.changed`` and persists the transition to the audit log.

Per Issue #501 the surface stays narrow on purpose: modes are
derived state, so the read paths return the *current label* and
list, not a separate state machine. ``set_mode`` returns the diff
``{applied_gates, previous_mode, new_mode}`` so the caller can show
the operator what changed.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx
from mcp.types import TextContent

from ...daemon.discovery import read_discovery
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...mode_registry import (
    ModeRegistryError,
    load_modes,
)
from ..helpers import ok


_SKILL_MODES_PATH = (
    Path(".claude") / "skills" / "forge-manager" / "modes.yaml"
)


def _resolve_modes_yaml(project_dir: Path) -> Path:
    """Resolve the project's ``modes.yaml`` path.

    Lives at the project's skill directory by convention; matches the
    layout the daemon already walks for ``gates.yaml`` /
    ``processes.yaml``.
    """
    return project_dir / _SKILL_MODES_PATH


def _mode_to_payload(mode) -> dict[str, Any]:
    """Serialize a :class:`Mode` for the MCP tool response.

    The wire shape mirrors what ``GET /modes`` returns from the daemon
    so callers (the UI's mode-picker, the operator's CLI debugging
    session) see the same JSON regardless of which surface they
    queried.
    """
    return {
        "name": mode.name,
        "description": mode.description,
        "gate_states": [
            {
                "gate": decl.gate,
                "state": decl.state,
                "scope": list(decl.scope),
            }
            for decl in mode.gate_states
        ],
    }


async def list_modes(
    project_dir: Path,
    *,
    include_project: bool = True,
) -> list[TextContent]:
    """Return the resolved mode list (skill + per-project per #501).

    ``include_project`` is accepted for forward-compatibility per
    Issue #501's tool surface — the project-rules extension layer
    lands separately (Issue #501 §Project-rules integration), so
    today the flag is documented but has no per-project additions
    to layer in.
    """
    path = _resolve_modes_yaml(project_dir)
    if not path.exists():
        return ok({
            "loaded": False,
            "reason": f"modes.yaml not found at {path}",
            "modes": [],
        })
    try:
        registry = load_modes(path)
    except ModeRegistryError as exc:
        return ok({
            "loaded": False,
            "reason": str(exc),
            "modes": [],
        })
    return ok({
        "loaded": True,
        "include_project": include_project,
        "modes": [_mode_to_payload(m) for m in registry.list_modes()],
    })


async def get_current_mode(project_dir: Path) -> list[TextContent]:
    """Return the currently-computed mode label.

    Routes through the daemon's ``GET /modes/current`` so the
    computation happens against the canonical gate-state snapshot the
    daemon maintains. Falls back to a degraded payload when the
    daemon isn't running — same surface the other daemon-routed MCP
    tools use.
    """
    sd = state_dir(DEFAULT_PROJECT_NAME)
    df = read_discovery(sd)
    if df is None:
        return ok({
            "available": False,
            "reason": "daemon not running (no discovery file)",
            "current_mode": None,
            "matching_modes": [],
        })
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(
                f"http://127.0.0.1:{df.port}/modes/current",
                headers={"Authorization": f"Bearer {df.auth_token}"},
            )
    except (httpx.HTTPError, OSError) as exc:
        return ok({
            "available": False,
            "reason": f"daemon unreachable: {exc}",
            "current_mode": None,
            "matching_modes": [],
        })
    if response.status_code != 200:
        return ok({
            "available": False,
            "reason": (
                f"daemon /modes/current returned "
                f"HTTP {response.status_code}: {response.text[:200]}"
            ),
            "current_mode": None,
            "matching_modes": [],
        })
    body = response.json()
    return ok({"available": True, **body})


async def set_mode(
    name: str,
    *,
    dry_run: bool = False,
) -> list[TextContent]:
    """Apply a mode by name (or preview with ``dry_run``).

    Dispatches to ``POST /modes/{name}`` with ``dry_run`` in the body.
    The daemon resolves the named mode against the registry, batch-
    applies its ``gate_states``, persists the transition to the audit
    log, and broadcasts ``mode.changed``.

    Returns ``{applied_gates, previous_mode, new_mode, dry_run}`` per
    Issue #501's MCP-surface contract.
    """
    sd = state_dir(DEFAULT_PROJECT_NAME)
    df = read_discovery(sd)
    if df is None:
        return ok({
            "applied": False,
            "reason": "daemon not running (no discovery file)",
            "applied_gates": [],
            "previous_mode": None,
            "new_mode": None,
            "dry_run": dry_run,
        })
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/modes/{name}",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"dry_run": dry_run},
            )
    except (httpx.HTTPError, OSError) as exc:
        return ok({
            "applied": False,
            "reason": f"daemon unreachable: {exc}",
            "applied_gates": [],
            "previous_mode": None,
            "new_mode": None,
            "dry_run": dry_run,
        })
    if response.status_code == 404:
        return ok({
            "applied": False,
            "reason": f"unknown mode: {name!r}",
            "applied_gates": [],
            "previous_mode": None,
            "new_mode": None,
            "dry_run": dry_run,
        })
    if response.status_code != 200:
        return ok({
            "applied": False,
            "reason": (
                f"daemon POST /modes/{name} returned "
                f"HTTP {response.status_code}: {response.text[:200]}"
            ),
            "applied_gates": [],
            "previous_mode": None,
            "new_mode": None,
            "dry_run": dry_run,
        })
    body = response.json()
    return ok({"applied": True, **body})
