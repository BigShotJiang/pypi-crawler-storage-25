"""``shadow_query`` MCP tool handler (Issue #475 / 3.14.0 framework).

Opens a read-only sqlite connection to the daemon's action-log
database and executes the caller's SQL. Per Discussion #22 OQ9
closure: Claude's MCP surface gets raw SQL for ad-hoc analysis;
DDL/DML rejection happens at the sqlite layer via URI
``?mode=ro`` rather than as a string-matching prefilter.

The read-only mode means:

* ``CREATE`` / ``DROP`` / ``INSERT`` / ``UPDATE`` / ``DELETE`` /
  ``PRAGMA <writable>`` all raise ``sqlite3.OperationalError``.
* ``SELECT`` against shadow ``_facts`` tables, ``_current`` views,
  and the action-log's existing FTS5 indices all work.
* ``ATTACH DATABASE`` is blocked (would need write access to the
  page cache).

Effect-then-interceptor split: the handler is the effect — opens
a sqlite connection + runs a query. The result-shaping into the
``{rows, row_count}`` payload is pure.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from mcp.types import TextContent

from ...context import ServerContext
from ...models import OperationError
from ..helpers import err, ok


def _readonly_uri(db_path: Path) -> str:
    """Compose the sqlite URI for a read-only connection.

    Returns ``file:<absolute-path>?mode=ro`` per the sqlite3 URI spec.
    Caller passes this with ``uri=True`` to :func:`sqlite3.connect`.

    The ``mode=ro`` query parameter is what enforces the read-only
    contract — any write statement raises sqlite3.OperationalError
    instead of silently mutating.
    """
    return f"file:{db_path.as_posix()}?mode=ro"


def _shape_rows(cursor: sqlite3.Cursor) -> list[dict[str, Any]]:
    """Convert a sqlite cursor's result set into a list of dicts.

    Uses ``cursor.description`` to get column names — works with any
    SELECT regardless of whether the connection's row_factory is set.
    Defensive shape so the result is JSON-serializable for MCP wire
    return without further conversion.
    """
    if cursor.description is None:
        # Statement was a no-op (e.g., empty SELECT against an empty
        # FTS5 table); no description means no columns.
        return []
    column_names = [d[0] for d in cursor.description]
    return [dict(zip(column_names, row)) for row in cursor.fetchall()]


async def shadow_query(
    ctx: ServerContext,
    *,
    sql: str,
) -> list[TextContent]:
    """Execute ``sql`` against the daemon's sqlite action-log in
    read-only mode. Returns the rows + row count.

    Args:
        ctx: Server context; we read ``ctx.state_dir`` to locate the
            sqlite file. Falls back to the conventional state-dir
            when ``ctx.state_dir`` isn't populated (most contexts
            today resolve via :func:`daemon.paths.state_dir`).
        sql: The SQL statement to run. Single statement; multi-
            statement scripts are blocked by sqlite3's
            ``Connection.execute`` contract (one statement per call).

    Returns:
        MCP TextContent payload wrapping
        ``{"rows": [{...}, ...], "row_count": N}`` on success.
        ``OperationError`` payload on:

        * Missing database file (daemon never bootstrapped the
          schema; user needs to run the daemon or
          ``shadow rebuild`` first).
        * ``sqlite3.OperationalError`` — covers attempted DDL/DML
          rejection by the read-only connection + malformed SQL +
          unknown-table errors. The exception message is forwarded
          verbatim so the operator sees what sqlite said.
    """
    from forge_manager_mcp.daemon.action_log import (
        DATABASE_FILENAME, database_path,
    )
    from forge_manager_mcp.daemon.paths import (
        DEFAULT_PROJECT_NAME, state_dir,
    )

    # Resolve state-dir: prefer the context override, fall back to
    # the conventional path. Tests inject ctx.state_dir; production
    # context constructor sets it post-3.7.0.
    sd: Path
    candidate = getattr(ctx, "state_dir", None)
    if candidate is not None:
        sd = Path(candidate)
    else:
        sd = state_dir(DEFAULT_PROJECT_NAME)

    db_path = database_path(sd)
    if not db_path.is_file():
        return err(
            OperationError(
                success=False,
                error=(
                    f"shadow_query: sqlite database not found at "
                    f"{db_path}. The daemon's action-log isn't "
                    f"bootstrapped yet — start the daemon (`forge-"
                    f"manager-daemon`) or run "
                    f"`forge-manager-daemon shadow rebuild` against "
                    f"this state-dir."
                ),
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )
        )

    uri = _readonly_uri(db_path)
    try:
        con = sqlite3.connect(uri, uri=True)
    except sqlite3.OperationalError as exc:
        return err(
            OperationError(
                success=False,
                error=f"shadow_query: open read-only connection failed: {exc}",
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )
        )
    try:
        try:
            cursor = con.execute(sql)
        except sqlite3.OperationalError as exc:
            # Covers: SQL syntax errors, attempted writes against the
            # read-only connection ("attempt to write a readonly
            # database"), unknown tables. All forward to the operator.
            return err(
                OperationError(
                    success=False,
                    error=f"shadow_query: sqlite error: {exc}",
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )
        rows = _shape_rows(cursor)
    finally:
        con.close()

    return ok({
        "rows": rows,
        "row_count": len(rows),
    })


__all__ = ["shadow_query", "_readonly_uri", "_shape_rows", "DATABASE_FILENAME"]


# Re-export DATABASE_FILENAME so tests can locate the expected sqlite
# path without round-tripping through daemon.action_log. Late-import
# guard against accidental cycles — fetched at module-load.
from forge_manager_mcp.daemon.action_log import (  # noqa: E402
    DATABASE_FILENAME,
)
