"""Shared Issue-creation orchestration (#274 follow-up; DRY refactor).

`create_issue_tool` (issues.py) and `create_thread` Issue branch
(threads.py) both need the same four-step sequence:

  1. Dispatch through the daemon's ``POST /writes`` endpoint
     (#355 / D5.2 / capability 8 — pre-D5.2 this went through
     ``ctx.replication.write``; the migration moves the canonical
     write boundary to the daemon per Discussion #6 OQ2 closure).
  2. Attach the new Issue to the project board (forgejo #10 / 3.4.0
     sub-Protocol — first replication adapter with
     ``has_project_boards=True`` wins; skips silently when none).
  3. Increment ``ctx.activity.issues_created``.

Factored here so the test surface is one helper, not two near-
duplicate handler call sites. The result-model shaping
(``CreateIssueResult`` vs ``CreateThreadResult``) and the
project-TOC-body fetch stay at the call sites — those genuinely
diverge between the two handlers.
"""
from __future__ import annotations

import re

from ...adapters.errors import ForgeError, ForgeUnavailableError
from ...adapters.types import Issue
from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import dispatch_write


# (#484) discussion_origin_id ref-form classification.
#
# Two accepted forms post-#484:
#   * Canonical-store ref — path-shaped, points at a LocalStore
#     Discussion: ``discussions/<N>`` or ``local://discussions/<N>``.
#     Treated as cross-link metadata only; the visible link is
#     already carried in the Issue body's "Anchored on Discussion
#     #N" prose, so the handler skips any backend-side cross-link
#     write entirely.
#   * GitHub GraphQL node ID — base64-ish opaque token of the form
#     ``D_kwDO<rest>``. Pass-through for any future GitHub-side
#     cross-link implementation (today's handler doesn't actually
#     post a GitHub mutation for the link — the parameter is
#     accepted at the schema boundary and recorded for traceability;
#     when GitHub-tight cross-link support lands, the call should
#     dispatch only on this form).
#
# Empty string ``""`` is the "no origin" signal — passes both
# detectors as None.
#
# Anything else (malformed string, mid-migration legacy shape, raw
# number, etc.) raises ValueError so the caller learns about the
# misroute immediately. is_permanent_error classifies ValueError
# as permanent, so the error surfaces cleanly rather than buffering
# (#465 / #485 combined contract).

_CANONICAL_DISCUSSION_REF_RE = re.compile(
    r"^(?:local://)?discussions/(\d+)$"
)
_GITHUB_DISCUSSION_NODE_ID_RE = re.compile(
    r"^D_kwDO[A-Za-z0-9_\-]+$"
)


class _ClassifiedOriginRef:
    """Schema-as-functions (Rule 5) — explicit shape for the result
    of classify_discussion_origin_id. Lives behind a factory
    helper; not a top-level Pydantic class.

    Fields:
      * kind: ``"canonical"`` / ``"github_node_id"`` / ``"none"``.
      * number: int when kind == "canonical"; None otherwise.
      * node_id: str when kind == "github_node_id"; None otherwise.
      * raw: the original input string, preserved for diagnostics.
    """

    __slots__ = ("kind", "number", "node_id", "raw")

    def __init__(
        self,
        *,
        kind: str,
        raw: str,
        number: int | None = None,
        node_id: str | None = None,
    ):
        self.kind = kind
        self.raw = raw
        self.number = number
        self.node_id = node_id


def classify_discussion_origin_id(value: str) -> _ClassifiedOriginRef:
    """(#484) Classify a ``discussion_origin_id`` argument.

    Returns a ``_ClassifiedOriginRef`` describing the accepted form:
      * empty string → ``kind="none"``.
      * ``discussions/<N>`` / ``local://discussions/<N>`` →
        ``kind="canonical"``, ``number=<N>``.
      * ``D_kwDO<rest>`` → ``kind="github_node_id"``,
        ``node_id=<value>``.

    Raises ``ValueError`` on any other shape. The dispatch wrapper
    classifies ValueError as permanent (#465 / #485 combined
    contract) so a malformed origin id surfaces immediately rather
    than buffering for replay.

    Pure function; no I/O. Safe to call from sync or async paths.
    """
    if value == "" or value is None:
        return _ClassifiedOriginRef(kind="none", raw=value or "")
    canonical_match = _CANONICAL_DISCUSSION_REF_RE.match(value)
    if canonical_match is not None:
        return _ClassifiedOriginRef(
            kind="canonical",
            raw=value,
            number=int(canonical_match.group(1)),
        )
    if _GITHUB_DISCUSSION_NODE_ID_RE.match(value) is not None:
        return _ClassifiedOriginRef(
            kind="github_node_id",
            raw=value,
            node_id=value,
        )
    raise ValueError(
        "discussion_origin_id must be one of: empty string (no "
        f"origin), 'discussions/<N>' / 'local://discussions/<N>' "
        f"(canonical-store ref), or a GitHub Discussion node ID "
        f"('D_kwDO...'). Got: {value!r}. The canonical-store form "
        f"is recommended for post-3.0 callers — the visible link "
        f"is carried by the Issue body's 'Anchored on Discussion "
        f"#N' prose, so the parameter records the cross-link for "
        f"traceability without requiring a reachable GitHub backend."
    )


async def _attach_to_project_board_if_supported(
    ctx: ServerContext, issue: Issue,
) -> str:
    """Attach an Issue to the configured project board on whichever
    replication adapter supports it (forgejo #10 / 3.4.0).

    Walks ``ctx.replication.entries()`` in order; the first adapter
    with ``has_project_boards=True`` performs the attach. If no
    adapter supports project boards, or no ``project_board`` is
    configured on this project, returns "" cleanly — the caller
    treats the empty string as "no board attachment performed".

    Any ``ForgeError`` (including ``ForgeUnavailableError``,
    backend-specific HTTP failures like the GitHub-suspension 403,
    and adapter-side validation errors) from the supporting adapter
    falls through to the next adapter; if no adapter succeeds, the
    helper returns "" cleanly. The board attach is best-effort —
    the canonical Issue write has already succeeded by the time this
    helper runs, and a board-attach failure must not propagate
    upstream and mask the canonical-success outcome (#297-class bug
    at the handler-helper layer; 3.4.2 fix).

    On a LocalStore-only or Forgejo-only project, this returns ""
    every call — the calling handler should accept project_item_id
    being optional in its response model.
    """
    if ctx.config.project_board is None:
        return ""
    # (#356, 3.7.0 D8 carryover) Daemon-routed attach. Pre-D8.7 this
    # helper walked `ctx.replication.entries()` for a project-board-
    # capable adapter; now the daemon does the walk via the
    # `attach_to_project_board` op. The adapter-level ForgeError
    # fallthrough semantics from 3.4.2 are preserved server-side.
    from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ...daemon_client import (
        DaemonUnavailableError,
        RemoteOpError,
        dispatch_write,
    )
    try:
        response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "attach_to_project_board",
            {
                "board_id": ctx.config.project_board.id,
                "native_id": issue.ref.native_id,
                "owner": issue.ref.owner,
                "repo": issue.ref.repo,
                "kind": issue.ref.kind,
            },
        )
        return response.get("value") or ""
    except (DaemonUnavailableError, RemoteOpError):
        # (#513, 3.16.0 D0) Daemon down OR daemon-op failure (e.g., a
        # non-ForgeError exception from the project-board adapter
        # path that escaped the daemon op's ForgeError fallthrough)
        # → treat as clean no-op (canonical Issue write has already
        # succeeded; board attach is best-effort per 3.4.2 contract).
        return ""


async def create_issue_via_replication(
    ctx: ServerContext,
    *,
    owner: str,
    repo: str,
    title: str,
    body: str,
    labels: list[str],
    milestone: str | int | None = None,
) -> tuple[Issue, str]:
    """Create an Issue through the canonical ReplicationManager and
    attach it to the project board.

    Returns ``(issue, project_item_id)``. Increments
    ``ctx.activity.issues_created`` after the canonical adapter call
    succeeds; the board-attach result no longer gates the counter
    (3.4.2 fix — pre-3.4.2 a board-attach failure propagated and
    masked the canonical-success outcome of the Issue write).

    Failure semantics:

      * Adapter ``create_issue`` raises (typically wrapped as
        ``ReplicationWriteError``) → propagates; board attach is
        skipped; counter unchanged.
      * Adapter succeeds but board attach raises → the helper
        catches every ``ForgeError`` (including HTTP 4xx like the
        GitHub-suspension 403, ``ForgeUnavailableError``, validation
        errors). ``project_item_id`` is ``""``; counter increments
        because the Issue exists in the canonical store. Operator
        can re-attach manually post-recovery.
      * No adapter supports project boards → ``project_item_id`` is
        ``""`` and counter increments. Caller's response model
        treats project_item_id as optional.

    Caller is responsible for any ``ok(...)`` / ``err(...)`` shaping
    around the return value.
    """
    # (#355 / D5.2) Daemon-routed canonical write. MCP becomes a
    # thin caller per Discussion #6 OQ2 closure ("Option C — stdio
    # MCP delegates to daemon"). The daemon owns ReplicationManager
    # and threads per-platform coords (#296) into each adapter's
    # ``create_issue`` call.
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "create_issue",
        {
            "owner": owner,
            "repo": repo,
            "title": title,
            "body": body,
            "labels": labels,
            "milestone": milestone,
            "repo_role": "private",
        },
    )
    issue = Issue.model_validate(response["value"])
    project_item_id = await _attach_to_project_board_if_supported(ctx, issue)
    ctx.activity.issues_created += 1
    return issue, project_item_id
