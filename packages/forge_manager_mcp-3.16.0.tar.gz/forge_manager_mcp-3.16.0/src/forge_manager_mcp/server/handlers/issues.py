"""Issue-side handlers: create_issue, update_issue_toc, move_project_item,
close_issue_with_comment, search_issues, close_triaged_public_issues.

create_issue dispatches through ``ctx.replication.write`` via the
``create_issue_via_replication`` helper (#274); close_triaged_public_issues
dispatches mirror-side writes through ``ctx.public_face`` (#281). The
remaining handlers still call ``_s.*`` directly until the adapter Protocol
grows ArtifactRef-vs-id reconciliation."""
from __future__ import annotations

from mcp.types import TextContent

from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import dispatch_read, dispatch_write
from ...github.triage import (
    extract_public_mirror_urls,
    is_pre_release_version,
    list_triaged_closed_issues,
)
from ...models import (
    CreateIssueResult,
    OperationError,
    SearchIssueHit,
    SearchIssuesResult,
)
from ...parsers import parse_owner_repo
from ...utils import check_overwrite_size, resolve_new_body
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import (
    TYPE_LABELS,
    coord_ref,
    err,
    fetch_project_toc_body,
    make_canonical_ref,
    ok,
)
from ._issue_creation import (
    classify_discussion_origin_id,
    create_issue_via_replication,
)


def _validate_issue_labels(labels: list[str]) -> None:
    """Validate the multi-label list a caller passed for create_issue.

    Rejects non-string / empty entries, duplicates, and label sets
    that don't include exactly one type label from ``TYPE_LABELS``.
    Raises ``ValueError`` on any violation. Pure function — no I/O,
    no ctx.
    """
    seen: set[str] = set()
    type_labels: set[str] = set()
    for name in labels:
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                f"Each label must be a non-empty string, got: {name!r}"
            )
        if name in seen:
            raise ValueError(f"Duplicate label: {name!r}")
        seen.add(name)
        if name in TYPE_LABELS:
            type_labels.add(name)
    if len(type_labels) != 1:
        raise ValueError(
            "Exactly one type label is required from "
            f"{sorted(TYPE_LABELS)}. Got: {sorted(type_labels) or '(none)'}"
        )


async def create_issue_tool(
    ctx: ServerContext,
    title: str,
    body: str,
    labels: list[str],
    discussion_origin_id: str,
    owner: str,
    repo: str,
    milestone: str | int | None = None,
) -> list[TextContent]:
    _validate_issue_labels(labels)
    # (#484) Classify the origin-id shape before dispatching. The
    # current handler doesn't post a backend-side cross-link for any
    # form — the visible "Anchored on Discussion #N" link is carried
    # by the body prose — but rejecting malformed strings at the
    # boundary catches the pre-#484 misroute where a canonical-store
    # ref like "discussions/22" got passed as if it were a GitHub
    # node ID, triggering a GitHub GraphQL call against the
    # suspended account that 403'd and buffered the entire create.
    # ValueError classifies as permanent per #465/#485 so a malformed
    # input surfaces immediately rather than polluting the retry
    # buffer.
    classify_discussion_origin_id(discussion_origin_id)
    issue, project_item_id = await create_issue_via_replication(
        ctx,
        owner=owner, repo=repo, title=title, body=body,
        labels=labels, milestone=milestone,
    )
    return ok(
        CreateIssueResult(
            issue_id=issue.ref.native_id,
            issue_number=issue.ref.number,
            issue_url=issue.url,
            project_item_id=project_item_id,
            project_toc_body=await fetch_project_toc_body(ctx),
        ).model_dump()
    )


async def update_issue_toc(
    ctx: ServerContext,
    issue_id: str,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(ctx, kind="issue", native_id=issue_id)
    # (#356, 3.7.0 D8.1) Read now dispatches through the daemon's
    # POST /reads endpoint, mirroring the 3.6.0 D5 dispatch_write
    # pattern. Pre-D8 this called ``ctx.replication.read`` directly
    # against the MCP's ReplicationManager — the asymmetric "writes
    # via daemon, reads via MCP" shape that #356 closes.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "get_issue_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    current_body = read_response.get("value", "")
    check_overwrite_size(current_body, body, force)
    # (#355 / D5.5) Daemon-routed body update.
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_issue_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": body,
            "force": force,
            "repo_role": "private",
        },
    )
    return ok("Issue opening post updated.")


async def update_issue_meta(
    ctx: ServerContext,
    issue_id: str,
    fields: dict,
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506) Generic field-bag mutation for an Issue.

    Closes G1 (title mutation) for issues + extends G4 (milestone
    mutation already had a narrow shim ``update_issue_milestone``;
    this is the generic-tool version per OQ-01 / RFC #506).

    Field allowlist (enforced by the adapter):
      * ``title`` — issue title
      * ``body`` — issue body
      * ``milestone`` — milestone title (string) or None to clear

    Pre-3.16.0 only ``update_issue_body`` + ``update_issue_milestone``
    surfaces existed; updating the title required direct
    canonical-store file edits. This tool surfaces the generic
    field-bag updater introduced at the adapter layer by e2f3e0a.
    Narrow shims stay registered through one minor per OQ-02.
    """
    ref = make_canonical_ref(ctx, kind="issue", native_id=issue_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_issue_meta",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "fields": dict(fields or {}),
            "repo_role": "private",
        },
    )
    return ok({
        "issue_id": ref.native_id,
        "updated_fields": sorted(fields.keys()) if fields else [],
    })


async def triage_classify(
    ctx: ServerContext,
    title: str,
    body: str,
    existing_titles: list[str] | None = None,
) -> list[TextContent]:
    """(3.16.0 D5) Run the public-issue triage classifier on a single
    (title, body) pair. Returns the classification record
    {category, confidence, reasons}.

    Operator UX: call against an open public-mirror Issue to get a
    suggested triage action (duplicate / needs_info / spam /
    valid). The classifier is heuristic per RFC #25 OQ-D1; bulk
    classify (iterate every open public-mirror Issue) is a
    follow-up MCP tool that loops through this.

    Optional ``existing_titles`` — supply the corpus of existing
    Issue titles to enable duplicate detection (exact-title match,
    case-insensitive). Omit when running standalone.
    """
    from ...daemon_client import dispatch_triage_classify
    result = await dispatch_triage_classify(
        state_dir(DEFAULT_PROJECT_NAME),
        title=title,
        body=body,
        existing_titles=existing_titles,
    )
    if result is None:
        return ok({
            "category": "unclassified",
            "confidence": 0.0,
            "reasons": [
                "daemon unreachable or classifier endpoint returned "
                "non-200; classification skipped"
            ],
        })
    return ok(result)


async def reopen_issue(
    ctx: ServerContext,
    issue_id: str,
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506 G5) Reopen a closed Issue.

    Closes the reopen-not-available gap — pre-3.16.0 close_issue
    existed but no reopen path existed at any layer. Operators
    catching a premature close had to edit state.txt directly,
    bypassing shadow + history.
    """
    ref = make_canonical_ref(ctx, kind="issue", native_id=issue_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "reopen_issue",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    return ok({
        "issue_id": ref.native_id,
        "state": "open",
    })


async def add_label(
    ctx: ServerContext,
    target_id: str,
    label_name: str,
    kind: str = "issue",
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506 G2) Add a label to an Issue or Discussion.

    Closes the labels-mutation gap: LocalStoreAdapter.add_label
    existed pre-3.16.0 but no daemon op + MCP tool surface
    registered it, leaving labels unreachable through normal
    write paths. Operators had to edit ``labels.txt`` directly,
    which silently bypassed shadow + history infrastructure.

    Accepts ``kind="issue"`` (default) or ``kind="discussion"`` so
    one tool serves both compound-doc kinds.
    """
    ref = make_canonical_ref(ctx, kind=kind, native_id=target_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "add_label",
        {
            "native_id": ref.native_id,
            "kind": kind,
            "owner": ref.owner,
            "repo": ref.repo,
            "label_name": label_name,
            "repo_role": "private",
        },
    )
    return ok({
        "target_id": ref.native_id,
        "kind": kind,
        "label_added": label_name,
    })


async def remove_label(
    ctx: ServerContext,
    target_id: str,
    label_name: str,
    kind: str = "issue",
) -> list[TextContent]:
    """(3.16.0 D4 / RFC #506 G2) Remove a label from an Issue or
    Discussion. Mirror of ``add_label`` with the inverse semantics.
    Idempotent — removing a label that's not present is a no-op
    (no history entry written)."""
    ref = make_canonical_ref(ctx, kind=kind, native_id=target_id)
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "remove_label",
        {
            "native_id": ref.native_id,
            "kind": kind,
            "owner": ref.owner,
            "repo": ref.repo,
            "label_name": label_name,
            "repo_role": "private",
        },
    )
    return ok({
        "target_id": ref.native_id,
        "kind": kind,
        "label_removed": label_name,
    })


async def move_project_item(
    ctx: ServerContext,
    column_name: str,
    issue_id: str,
) -> list[TextContent]:
    """Move an Issue to a different Status column on the project board.

    forgejo #10 / 3.4.0 — dispatches via the new project-board
    sub-Protocol. Walks ``ctx.replication.entries()`` and uses the
    first adapter with ``has_project_boards=True``. When no adapter
    supports project boards (LocalStore-only / Forgejo-only project),
    or no ``project_board`` is configured, returns a clear error
    rather than crashing on a missing capability.
    """
    board = ctx.config.project_board
    if board is None:
        return err(
            OperationError(
                success=False,
                error=(
                    "move_project_item: no project_board configured in "
                    "forge-config.json. This project doesn't have a "
                    "project board declared, so column moves are a "
                    "no-op. Add a project_board section to "
                    "forge-config.json or skip the tool for this project."
                ),
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )
        )

    # (#356, 3.7.0 D8.8 carryover) Daemon-routed composite move.
    # Pre-D8.8 the handler walked ctx.replication.entries() to find
    # a project-board-capable adapter, then made 3 adapter calls in
    # sequence. The composite `move_project_item_to_column` op moves
    # the walk + the sequence server-side. On any failure the daemon
    # returns {error: <message>}; surface it as OperationError.
    ref = make_canonical_ref(ctx, kind="issue", native_id=issue_id)
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "move_project_item_to_column",
        {
            "board_id": board.id,
            "column_name": column_name,
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "kind": "issue",
            "status_field_id": board.status_field_id,
            "status_options": dict(board.status_options or {}),
        },
    )
    error_message = response.get("error")
    if error_message:
        return err(
            OperationError(
                success=False,
                error=str(error_message),
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )
        )
    success_message = response.get("value") or f"Moved to {column_name}."
    return ok(success_message)


async def close_issue_with_comment(
    ctx: ServerContext,
    issue_id: str,
    comment: str,
    state_reason: str,
) -> list[TextContent]:
    if not comment.strip():
        raise ValueError("comment must not be empty.")
    ref = make_canonical_ref(ctx, kind="issue", native_id=issue_id)
    # Post the comment first so it appears above the close event on
    # the Issue timeline (#59). Both writes go through the daemon's
    # /writes endpoint (#355 / D5.6).
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "append_comment",
        {
            "parent_kind": "issue",
            "parent_native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": comment,
            "repo_role": "private",
        },
    )
    close_response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "close_issue",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "state_reason": state_reason,
            "repo_role": "private",
        },
    )
    from ...adapters.types import Issue
    closed = Issue.model_validate(close_response["value"])
    closed_at_iso = (
        closed.updated_at.isoformat() if closed.updated_at is not None else None
    )
    return ok(
        {
            "issue_url": closed.url,
            "closed_at": closed_at_iso,
        }
    )


async def search_issues_tool(
    ctx: ServerContext,
    query: str,
    state: str,
    labels: list[str] | None,
    milestone: str | None,
    owner: str,
    repo: str,
    limit: int,
) -> list[TextContent]:
    """Wrap GitHub's GraphQL Issue search with shaped output (#236).

    Surfaced from #235 §OQ3 (Decided 2026-04-28) as the canonical
    replacement for the dropped ## Issues table grep capability after
    the TOC reframe landed.
    Read-only; failures propagate without buffering (read tools don't
    buffer per `recording.md` §Failure Handling).

    `query` is GitHub search-syntax — the caller can include their own
    operators (`in:body`, `author:`, `created:>2026-01-01`, etc.). The
    structured params (`state`, `labels`, `milestone`) are layered on
    top to produce the final query string, which is included in the
    response so callers can debug without a separate roundtrip.
    """
    # (#356, 3.7.0 D8.4) Daemon-routed search. SearchResult arrives
    # as a JSON dict; reshape `results` to legacy SearchIssueHit
    # so callers see the same surface as before the migration.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "search_issues",
        {
            "owner": owner,
            "repo": repo,
            "query": query,
            "state": state,
            "labels": labels,
            "milestone": milestone,
            "limit": limit,
            "repo_role": "private",
        },
    )
    search_payload = read_response.get("value", {}) or {}
    raw_results = search_payload.get("results", []) or []
    # Reconstruct Issue Pydantic instances so the legacy shaper
    # (`_issue_to_search_hit`) keeps its existing surface — it
    # reads `issue.number`, `issue.title`, etc. as attribute
    # accesses, not dict lookups.
    from ...adapters.types import Issue
    hits = [
        _issue_to_search_hit(Issue(**raw) if isinstance(raw, dict) else raw)
        for raw in raw_results
    ]
    return ok(
        SearchIssuesResult(
            results=hits,
            total_count=int(search_payload.get("total_count") or 0),
            query=str(search_payload.get("query") or ""),
        ).model_dump()
    )


def _issue_to_search_hit(issue) -> SearchIssueHit:
    """Convert a canonical adapter ``Issue`` into the legacy
    ``SearchIssueHit`` shape the search_issues tool surface uses
    (#236). Pure shaper — keeps the migration surface small."""
    return SearchIssueHit(
        number=issue.ref.number or 0,
        title=issue.title,
        url=issue.url,
        # Tool surface uses upper-case state literals.
        state="CLOSED" if issue.state == "closed" else "OPEN",
        labels=list(issue.labels),
        milestone=issue.milestone,
        repository=f"{issue.ref.owner}/{issue.ref.repo}",
        created_at=issue.created_at.isoformat() if issue.created_at else "",
        updated_at=issue.updated_at.isoformat() if issue.updated_at else "",
    )
def _publish_targets(ctx: ServerContext) -> list[str]:
    """Collect publish-target `owner/repo` paths from project config.

    Per #233 OQ1: only public-mirror URLs that resolve to a configured
    publish target count as triage cross-links. Includes the main
    `repos.public` plus any `related_repos` with `publish_target`
    relationship (so subsystem mirrors are also recognized).
    """
    return [
        ctx.config.repos.public,
        *(
            r.repo for r in ctx.config.related_repos
            if r.relationship == "publish_target"
        ),
    ]


def _close_comment_body(
    version: str,
    dev_issue_url: str,
    is_pre_release: bool,
) -> str:
    """Compose the closing comment body posted on the public-mirror Issue.

    Mirrors the Rule A comment template applied to #2 in this project
    (the precedent for Rule B's automation).
    """
    pre_release_note = (
        " (pre-release; the GA release will be tagged when the line "
        "is finalized)"
    ) if is_pre_release else ""
    return (
        f"Fixed in **v{version}**{pre_release_note}.\n\n"
        f"The fix landed via the dev-repo Issue at {dev_issue_url}. "
        "To pick up the fix, upgrade to the released version.\n\n"
        "Closed automatically by `close_triaged_public_issues` "
        "(#249) per the §Public Issue triage closure rules in "
        "the project's `.claude/skills/forge-manager/multi-repo.md`."
    )


def _partition_candidates(
    candidates: list[dict],
    publish_targets: list[str],
    *,
    dev_owner: str,
    dev_repo: str,
    url_regex: "re.Pattern[str] | None" = None,
) -> tuple[list[dict], list[dict]]:
    """Pure split of candidate Issues into matched / unmatched.

    No I/O — operates only on the dict shape returned by
    ``list_triaged_closed_issues`` plus the ``publish_targets`` list
    derived from project config. Each ``candidate`` with a body
    cross-link to one of the publish targets becomes a ``matched``
    entry carrying the dev + public coordinates; everything else
    becomes ``unmatched`` with the reason. First match wins —
    multiple cross-links to the same publish target imply duplicates
    the URL parser already dedupes.

    ``url_regex`` (#11): per-adapter Issue URL pattern obtained from
    ``ctx.public_face.public_issue_url_regex()``. When None falls back
    to the github.com pattern — preserves pre-#11 behavior for callers
    that haven't been routed through an adapter.
    """
    matched: list[dict] = []
    unmatched: list[dict] = []
    for candidate in candidates:
        urls = extract_public_mirror_urls(
            candidate["body"], publish_targets, url_regex=url_regex,
        )
        if not urls:
            unmatched.append({
                "dev_issue": f"{dev_owner}/{dev_repo}#{candidate['number']}",
                "reason": "no public-mirror URL in body",
            })
            continue
        public = urls[0]
        matched.append({
            "dev_issue": f"{dev_owner}/{dev_repo}#{candidate['number']}",
            "dev_url": candidate["url"],
            "public_owner": public["owner"],
            "public_repo": public["repo"],
            "public_number": public["number"],
            "public_url": public["url"],
        })
    return matched, unmatched


def _annotate_dry_run(
    matched: list[dict], *, version: str, skip_label: bool,
) -> None:
    """In-place: mark every matched entry with the would-have-been
    label / comment / close fields for dry-run output."""
    for entry in matched:
        entry["label_applied"] = (
            None if skip_label else f"fixedin:{version}"
        )
        entry["comment_posted"] = False
        entry["closed"] = False


async def _apply_close(
    ctx: ServerContext,
    entry: dict,
    *,
    version: str,
    pre_release: bool,
    skip_label: bool,
    label_ensured_for: set[str],
) -> None:
    """Live close-set for one matched Issue: comment → label → close.

    Mutates ``entry`` in place with the result fields
    (``comment_posted`` / ``label_applied`` / ``closed``). The
    ``label_ensured_for`` set is shared across the per-entry loop so
    we call ``ensure_label`` only once per (public_owner, public_repo)
    per release run; the set is the caller's "label was created or
    confirmed for these repos" surface.

    Mirror-side ops dispatch through ``ctx.public_face`` (#281) — the
    configured public-face platform adapter handles the actual
    backend calls (GitHub / Forgejo / GitLab). The handler asserts
    public_face is non-None before dispatching, so this helper trusts
    the configuration.
    """
    assert ctx.public_face is not None, (
        "close_triaged_public_issues handler must verify "
        "ctx.public_face before dispatch"
    )
    adapter = ctx.public_face
    public_owner = entry["public_owner"]
    public_repo = entry["public_repo"]
    repo_key = f"{public_owner}/{public_repo}"
    label_name = f"fixedin:{version}"

    issue = await adapter.get_issue(
        public_owner, public_repo, entry["public_number"],
    )

    # Comment + close (always).
    comment_body = _close_comment_body(
        version, entry["dev_url"], pre_release,
    )
    await adapter.append_comment(issue.ref, comment_body)
    entry["comment_posted"] = True

    # Label (skip on pre-release per OQ5).
    if not skip_label:
        if repo_key not in label_ensured_for:
            await adapter.ensure_label(
                owner=public_owner,
                repo=public_repo,
                name=label_name,
                description=f"Released in v{version}",
            )
            label_ensured_for.add(repo_key)
        await adapter.add_label(issue.ref, label_name)
        entry["label_applied"] = label_name
    else:
        entry["label_applied"] = None

    # Close.
    await adapter.close_issue(issue.ref, state_reason="completed")
    entry["closed"] = True


async def close_triaged_public_issues(
    ctx: ServerContext,
    version: str,
    dry_run: bool,
    skip_pre_release: bool,
) -> list[TextContent]:
    """Auto-close upstream public-mirror Issues at release time (#233 Rule B, #249).

    Scans closed dev-repo Issues in the milestone matching `version`
    for `area:public-mirror` + body cross-link to a public-mirror Issue.
    For each match, posts a closing comment, applies the
    `fixedin:<version>` label (created on demand; skipped on pre-
    releases per #233 OQ5 when `skip_pre_release=True`), and closes
    the public Issue with `state_reason: completed`.

    `dry_run=True` (default at the dispatch layer) returns the close
    set without any GitHub writes. `dry_run=False` performs the
    full action.

    The handler decomposes into:
      1. ``list_triaged_closed_issues`` (one GraphQL read).
      2. ``_partition_candidates`` (pure split into matched / unmatched).
      3. Pre-release gate.
      4. Either ``_annotate_dry_run`` (no I/O) or a per-entry
         ``_apply_close`` loop (live writes).
    """
    if not version.strip():
        raise ValueError("version must not be empty.")

    if not dry_run and ctx.public_face is None:
        raise ValueError(
            "close_triaged_public_issues requires a configured public face. "
            "Set `public_face` in forge-config.json to the platform_id of "
            "the adapter that fronts your project's public mirror, then "
            "restart the MCP server."
        )

    dev_owner, dev_repo = parse_owner_repo(ctx.config.repos.private)
    publish_targets = _publish_targets(ctx)

    candidates = await list_triaged_closed_issues(
        ctx.github_token, dev_owner, dev_repo, version,
    )
    # (#11) Per-adapter URL pattern — falls back to github.com when no
    # public_face is wired (dry_run path that doesn't require it).
    url_regex = (
        ctx.public_face.public_issue_url_regex()
        if ctx.public_face is not None
        else None
    )
    matched, unmatched = _partition_candidates(
        candidates, publish_targets,
        dev_owner=dev_owner, dev_repo=dev_repo,
        url_regex=url_regex,
    )

    pre_release = is_pre_release_version(version)
    skip_label = pre_release and skip_pre_release

    if dry_run:
        _annotate_dry_run(matched, version=version, skip_label=skip_label)
        return ok({
            "version": version,
            "is_pre_release": pre_release,
            "skipped_due_to_pre_release": skip_label,
            "scanned_issues": len(candidates),
            "matched": matched,
            "unmatched": unmatched,
            "label_created": False,
            "dry_run": True,
            "public_face_platform_id": (
                getattr(ctx.public_face, "platform_id", None)
                if ctx.public_face is not None
                else None
            ),
        })

    label_ensured_for: set[str] = set()
    for entry in matched:
        await _apply_close(
            ctx, entry,
            version=version,
            pre_release=pre_release,
            skip_label=skip_label,
            label_ensured_for=label_ensured_for,
        )

    return ok({
        "version": version,
        "is_pre_release": pre_release,
        "skipped_due_to_pre_release": skip_label,
        "scanned_issues": len(candidates),
        "matched": matched,
        "unmatched": unmatched,
        "label_created": len(label_ensured_for) > 0,
        "dry_run": False,
        "public_face_platform_id": getattr(
            ctx.public_face, "platform_id", None
        ),
    })
