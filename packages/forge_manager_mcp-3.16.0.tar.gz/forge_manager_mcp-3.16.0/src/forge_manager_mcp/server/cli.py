"""CLI entry point for forge-manager-mcp.

Dispatches to:
  - default mode (no subcommand) — runs as MCP server on stdio
  - ``daemon-status`` — read-only health snapshot (Phase D3b.4i / #335)
  - ``open-ui`` — launch a browser to the daemon UI (#335)
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

import mcp.server.stdio
from mcp.server import NotificationOptions
from mcp.server.models import InitializationOptions

from .. import __version__
from ..config import ConfigError
from ..daemon.discovery import discovery_path, read_discovery
from ..daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ..daemon_client import (
    DaemonStatus, probe_daemon, spawn_daemon, spawn_if_needed,
    wait_for_discovery,
)
from .build import build_server


def main(argv: list[str] | None = None) -> None:
    """
    Entry point for forge-manager-mcp.

    Default (no subcommand): parses --project-dir, loads config,
    starts MCP server on stdio. Fails immediately (exit code 1)
    if config is invalid.

    Subcommands (#335 / D3b.4i): ``daemon-status``, ``open-ui``.
    """
    parser = _make_parser()
    args = parser.parse_args(argv)

    if args.subcommand == "daemon-status":
        sys.exit(_run_daemon_status(args))
    if args.subcommand == "open-ui":
        sys.exit(_run_open_ui(args))
    if args.subcommand == "daemon-stop":
        sys.exit(_run_daemon_stop(args))
    if args.subcommand == "daemon-restart":
        sys.exit(_run_daemon_restart(args))
    if args.subcommand == "daemon-logs":
        sys.exit(_run_daemon_logs(args))
    if args.subcommand == "check-design":
        sys.exit(_run_check_design(args))
    if args.subcommand == "action-log":
        sys.exit(_run_action_log(args))

    # Default: run MCP server.
    try:
        server, config, _, _ = build_server(args.project_dir.resolve())
    except ConfigError as exc:
        print(f"[forge-manager-mcp] FATAL: {exc}", file=sys.stderr)
        sys.exit(1)

    if config is None:
        # Pre-bootstrap mode (#156). Server runs with a reduced tool
        # surface — scaffold_project and check_skill_version only —
        # so the operator can bootstrap without restarting first.
        print(
            f"[forge-manager-mcp] v{__version__} started in "
            f"PRE-BOOTSTRAP mode: .claude/github-config.json not found "
            f"under {args.project_dir.resolve()}. Run `scaffold_project` "
            "or follow §Self-Bootstrap. Restart Claude Code after "
            "bootstrap to load the full tool surface.",
            file=sys.stderr,
        )
    else:
        print(
            f"[forge-manager-mcp] v{__version__} started. "
            f"Project: {config.repos.private}",
            file=sys.stderr,
        )

    # (#360, 3.7.0 D0) Auto-spawn the daemon at MCP startup so every
    # fresh session has the daemon running by the time `open_session`
    # / first canonical write fires. Pre-#360 the daemon was lazily
    # spawned only when specific tool entry points called
    # `spawn_if_needed` directly — operators saw `daemon_status.running:
    # false` in every session-open banner until something happened to
    # invoke the orchestrator. With 3.6.0 D5 routing canonical writes
    # through `daemon/writes`, the daemon is now load-bearing for
    # writes; shipping it as opt-in / on-demand was a regression in
    # default operator UX. Spawn is best-effort: failure logs +
    # continues so MCP startup never blocks on daemon availability.
    try:
        sd = state_dir(DEFAULT_PROJECT_NAME)
        result = spawn_if_needed(
            sd,
            DEFAULT_PROJECT_NAME,
            auto_spawn=True,
            project_dir=args.project_dir.resolve(),
        )
        if result.spawned:
            df = read_discovery(sd)
            url = f"http://127.0.0.1:{df.port}/" if df else "(unknown port)"
            print(
                f"[forge-manager-mcp] daemon spawned: PID={result.pid} "
                f"URL={url}",
                file=sys.stderr,
            )
        elif result.status == DaemonStatus.RUNNING:
            df = read_discovery(sd)
            url = f"http://127.0.0.1:{df.port}/" if df else "(unknown port)"
            print(
                f"[forge-manager-mcp] daemon already running: PID="
                f"{result.pid} URL={url}",
                file=sys.stderr,
            )
        else:
            print(
                f"[forge-manager-mcp] daemon spawn failed (status="
                f"{result.status.value}); continuing without daemon. "
                f"Canonical writes will fall through dispatch_write's "
                f"DaemonUnavailableError buffer-fallback path.",
                file=sys.stderr,
            )
    except Exception as exc:  # noqa: BLE001 — spawn must never crash MCP
        print(
            f"[forge-manager-mcp] daemon auto-spawn raised: {exc!r}; "
            f"continuing without daemon (#360).",
            file=sys.stderr,
        )

    async def _serve() -> None:
        try:
            async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
                await server.run(
                    read_stream,
                    write_stream,
                    InitializationOptions(
                        server_name="forge-manager",
                        server_version=__version__,
                        capabilities=server.get_capabilities(
                            notification_options=NotificationOptions(),
                            experimental_capabilities={},
                        ),
                    ),
                )
        finally:
            # Release the shared httpx.AsyncClient connection pool on
            # graceful shutdown (#176).
            from ..github.core import aclose_client
            await aclose_client()

    asyncio.run(_serve())


def _make_parser() -> argparse.ArgumentParser:
    """Top-level argparse with subcommand routing (#335).

    Default (no subcommand) preserves the pre-3.5.0 behavior: runs
    as MCP server on stdio. Existing operator scripts +
    `claude_desktop_config.json` MCP wiring keep working without
    edits.
    """
    parser = argparse.ArgumentParser(
        prog="forge-manager-mcp",
        description="MCP server for the forge-manager skill",
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=Path("."),
        help=(
            "Path to the *-dev repo root containing "
            ".claude/github-config.json"
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    subparsers = parser.add_subparsers(dest="subcommand")

    p_status = subparsers.add_parser(
        "daemon-status",
        help="Show daemon health snapshot for the per-project state-dir.",
    )
    p_status.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_status.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path (testing).",
    )
    p_status.add_argument(
        "--json", action="store_true",
        help="Emit machine-readable JSON instead of human prose.",
    )

    p_ui = subparsers.add_parser(
        "open-ui",
        help="Open the daemon's UI in the default browser.",
    )
    p_ui.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_ui.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path (testing).",
    )
    p_ui.add_argument(
        "--no-browser", action="store_true",
        help="Print the URL but do not launch a browser.",
    )

    p_stop = subparsers.add_parser(
        "daemon-stop",
        help="Send SIGTERM (or SIGKILL with --force) to the daemon.",
    )
    p_stop.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_stop.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path.",
    )
    p_stop.add_argument(
        "--force", action="store_true",
        help="Send SIGKILL instead of SIGTERM.",
    )

    p_restart = subparsers.add_parser(
        "daemon-restart",
        help="Stop the daemon then re-spawn with --project-dir.",
    )
    p_restart.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_restart.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path.",
    )
    # (#498) Use argparse.SUPPRESS so the subparser-level default does
    # NOT clobber the parent-level ``--project-dir`` value. Pre-#498
    # the subparser declared ``default=None`` which won the merge over
    # the parent CLI's value, so ``forge-manager-mcp --project-dir
    # <path> daemon-restart`` spawned a daemon WITHOUT ``--project-dir``
    # threaded through to its argv — the resulting daemon ran with
    # ``config_loaded: false`` until the operator restarted it manually.
    # With SUPPRESS the subparser only writes the attribute when the
    # operator passes ``--project-dir`` to the sub form explicitly;
    # otherwise the parent's value flows through. Sibling fix to #338
    # (which fixed the MCP-side auto-spawn path).
    p_restart.add_argument(
        "--project-dir", type=Path, default=argparse.SUPPRESS,
        help=(
            "Project directory threaded to the spawned daemon "
            "(#338 / #498) so /config + /backends populate correctly. "
            "Defaults to the parent CLI's --project-dir value when "
            "not passed to the sub form."
        ),
    )

    p_design = subparsers.add_parser(
        "check-design",
        help=(
            "Run code-design evaluators against the project. "
            "Exits non-zero when fail-severity findings exist."
        ),
    )
    p_design.add_argument(
        "--severity-filter",
        choices=["fail", "warn", "info"],
        default="info",
        help=(
            "Minimum severity to include in output. Default 'info' "
            "(all findings)."
        ),
    )
    p_design.add_argument(
        "--diff",
        default=None,
        help=(
            "(3.5.x; not yet implemented) Run only against files "
            "changed since this git ref."
        ),
    )

    p_logs = subparsers.add_parser(
        "daemon-logs",
        help="Tail the daemon's log file.",
    )
    p_logs.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_logs.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path.",
    )
    p_logs.add_argument(
        "-n", "--lines", type=int, default=100,
        help="How many trailing lines to show (default 100).",
    )
    p_logs.add_argument(
        "-f", "--follow", action="store_true",
        help="Stream new lines as they're appended (tail -f).",
    )

    # (#354 / D4.4) Action-log maintenance — currently the rebuild
    # subcommand. Future: stats, vacuum, etc.
    p_action = subparsers.add_parser(
        "action-log",
        help="Action-log maintenance (sqlite cache).",
    )
    action_subs = p_action.add_subparsers(dest="action_log_subcommand")
    p_rebuild = action_subs.add_parser(
        "rebuild",
        help="Drop + repopulate FTS5 indices from canonical store.",
    )
    p_rebuild.add_argument(
        "--project-name", default=None,
        help="Per-project state-dir name (default: forge-manager).",
    )
    p_rebuild.add_argument(
        "--state-dir", type=Path, default=None,
        help="Override the auto-resolved state-dir path.",
    )
    p_rebuild.add_argument(
        "--docs-repo", type=Path, default=None,
        help=(
            "Path to the canonical docs repo to walk. "
            "Defaults to $FORGE_MANAGER_DOCS_REPO or the "
            "conventional ~/<project>-docs/ location."
        ),
    )

    return parser


def _resolve_state_dir(args) -> Path:
    """Shared resolution for the daemon-status / open-ui subcommands.
    Mirrors the daemon's own argparse logic in daemon/main.py."""
    if args.state_dir is not None:
        return args.state_dir
    name = args.project_name or DEFAULT_PROJECT_NAME
    return state_dir(name)


def _run_daemon_status(args) -> int:
    """``forge-manager-mcp daemon-status`` (#335).

    Reads the discovery file, probes /health, prints a one-screen
    summary. Exit codes:
      0 = daemon RUNNING
      1 = daemon ABSENT
      2 = daemon STALE (discovery file present but /health
          unreachable)
    """
    from datetime import datetime, timezone
    sd = _resolve_state_dir(args)
    df = read_discovery(sd)
    status = probe_daemon(sd)

    name = args.project_name or "forge-manager"

    if df is None:
        payload = {
            "project_name": name,
            "status": "absent",
            "state_dir": str(sd),
            "discovery_path": str(discovery_path(sd)),
            "next_step": (
                "MCP auto-spawns on first call when --project-dir is "
                "passed; or run `forge-manager-daemon --project-dir "
                "<repo-root>` directly."
            ),
        }
        if args.json:
            import json as _json
            print(_json.dumps(payload, indent=2))
        else:
            print(f"Daemon for project {name}:")
            print(f"  Status:     ABSENT")
            print(f"  State-dir:  {sd}")
            print(f"  Discovery:  {discovery_path(sd)}")
            print(f"")
            print(f"  No daemon found. {payload['next_step']}")
        return 1

    # df present — STALE or RUNNING.
    now = datetime.now(timezone.utc)
    uptime = (now - df.started_at).total_seconds()
    url = f"http://127.0.0.1:{df.port}/"
    payload = {
        "project_name": name,
        "status": status.value,
        "version": df.version,
        "pid": df.pid,
        "port": df.port,
        "started_at": df.started_at.isoformat(),
        "uptime_seconds": uptime,
        "url": url,
        "state_dir": str(sd),
        "discovery_path": str(discovery_path(sd)),
    }
    if status != DaemonStatus.RUNNING:
        payload["next_step"] = (
            "Discovery file is stale (PID running but /health "
            "unreachable, or PID gone). Run `forge-manager-mcp "
            "daemon-restart` to clear and respawn."
        )

    if args.json:
        import json as _json
        print(_json.dumps(payload, indent=2))
    else:
        print(f"Daemon for project {name}:")
        print(f"  Status:     {status.value.upper()}")
        print(f"  Version:    {df.version}")
        print(f"  PID:        {df.pid}")
        print(f"  Port:       {df.port}")
        print(f"  Started:    {df.started_at.isoformat()}")
        print(f"  Uptime:     {uptime:.1f}s")
        print(f"  URL:        {url}")
        print(f"  State-dir:  {sd}")
        print(f"  Discovery:  {discovery_path(sd)}")
        if status != DaemonStatus.RUNNING:
            print(f"")
            print(f"  {payload['next_step']}")

    if status == DaemonStatus.RUNNING:
        return 0
    return 2  # STALE


def _run_open_ui(args) -> int:
    """``forge-manager-mcp open-ui`` (#335).

    Opens the default browser to the daemon's UI when running.
    Exits non-zero with guidance when no daemon is running.
    """
    sd = _resolve_state_dir(args)
    df = read_discovery(sd)
    if df is None:
        print(
            "No daemon running for this project. Run "
            "`forge-manager-mcp daemon-status` for diagnostics, or "
            "trigger an auto-spawn via the MCP.",
            file=sys.stderr,
        )
        return 1

    status = probe_daemon(sd)
    url = f"http://127.0.0.1:{df.port}/"
    if status != DaemonStatus.RUNNING:
        print(
            f"Daemon discovery file points to {url} but /health is "
            f"unreachable. Run `forge-manager-mcp daemon-restart` "
            f"first.",
            file=sys.stderr,
        )
        return 2

    print(url)
    if args.no_browser:
        return 0
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception as exc:  # noqa: BLE001 — webbrowser failures
        print(
            f"(Failed to launch browser: {exc}; URL printed above.)",
            file=sys.stderr,
        )
        return 0
    return 0


def _run_daemon_stop(args) -> int:
    """``forge-manager-mcp daemon-stop`` (#339).

    (#497, 3.14.0) Pre-signal zombie / dead detection: signals on a
    zombie are no-ops, so pre-#497 ``--force`` against a zombie always
    reported "did not exit within 5s of SIGKILL." New path detects via
    Layer-1 helpers and cleans up the stale discovery file directly.

    Exit codes: 0 = stopped cleanly; 1 = no daemon running;
    2 = process didn't exit within timeout.
    """
    import os
    import signal
    import time

    from forge_manager_mcp.daemon_client import (
        is_pid_alive,
        is_pid_zombie,
    )

    sd = _resolve_state_dir(args)
    df = read_discovery(sd)
    if df is None:
        print("No daemon running.", file=sys.stderr)
        return 1

    # (#497) Zombie-first detection — signals are no-ops on zombies.
    if is_pid_zombie(df.pid):
        from forge_manager_mcp.daemon.discovery import remove_discovery
        remove_discovery(sd)
        print(
            f"Daemon PID {df.pid} was zombie; cleaned up discovery "
            f"file.",
        )
        return 0

    # (#497) Dead-PID detection upfront for symmetry with zombie branch.
    if not is_pid_alive(df.pid):
        from forge_manager_mcp.daemon.discovery import remove_discovery
        remove_discovery(sd)
        print(
            f"Daemon PID {df.pid} not found; removed stale "
            f"discovery file.",
        )
        return 0

    sig = signal.SIGKILL if args.force else signal.SIGTERM
    sig_name = "SIGKILL" if args.force else "SIGTERM"
    try:
        os.kill(df.pid, sig)
    except ProcessLookupError:
        # PID gone between alive-check and signal — race.
        from forge_manager_mcp.daemon.discovery import remove_discovery
        remove_discovery(sd)
        print(
            f"Daemon PID {df.pid} not found; removed stale "
            f"discovery file.",
        )
        return 0
    except OSError as exc:
        print(f"kill({df.pid}, {sig_name}) failed: {exc}", file=sys.stderr)
        return 2

    # Wait for the process to exit.
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        try:
            os.kill(df.pid, 0)
        except ProcessLookupError:
            print(f"Daemon PID {df.pid} stopped via {sig_name}.")
            from forge_manager_mcp.daemon.discovery import remove_discovery
            remove_discovery(sd)
            return 0
        # (#497) Mid-shutdown zombie check.
        if is_pid_zombie(df.pid):
            from forge_manager_mcp.daemon.discovery import remove_discovery
            remove_discovery(sd)
            print(
                f"Daemon PID {df.pid} became zombie during shutdown; "
                f"cleaned up discovery file.",
            )
            return 0
        time.sleep(0.1)

    print(
        f"Daemon PID {df.pid} did not exit within 5s of {sig_name}. "
        f"Re-run with --force.",
        file=sys.stderr,
    )
    return 2


def _run_daemon_restart(args) -> int:
    """``forge-manager-mcp daemon-restart`` (#339).

    Stop + spawn-with-project-dir. Useful after `pipx upgrade` so
    the new on-disk wheel's daemon process replaces the old one.
    """
    import time

    sd = _resolve_state_dir(args)

    # Stop the running daemon (if any).
    df = read_discovery(sd)
    if df is not None:
        stop_args = argparse.Namespace(
            project_name=args.project_name,
            state_dir=args.state_dir,
            force=False,
        )
        rc = _run_daemon_stop(stop_args)
        if rc not in (0, 1):
            print(
                f"daemon-stop reported exit {rc}; not respawning.",
                file=sys.stderr,
            )
            return rc

    # Spawn the new daemon. Reuse the existing spawn helper; pass
    # project_dir for full /config + /backends population (#338 /
    # #498). ``args.project_dir`` resolves to the parent CLI's
    # ``--project-dir`` value via ``argparse.SUPPRESS`` on the
    # subparser (#498) — pre-#498 the subparser's ``default=None``
    # clobbered the parent value, so the spawned daemon ran without
    # ``--project-dir`` threaded into its argv. Mirror main-mode's
    # ``.resolve()`` (cli.py line 60 + 101) so symlinks + relative
    # paths normalize identically across the two spawn entry points.
    spawn_project_dir = args.project_dir.resolve()
    pid = spawn_daemon(
        sd,
        args.project_name or DEFAULT_PROJECT_NAME,
        project_dir=spawn_project_dir,
    )
    if not wait_for_discovery(sd):
        print(
            f"Spawned PID {pid} but no daemon.json appeared within 5s. "
            f"Check `forge-manager-mcp daemon-logs`.",
            file=sys.stderr,
        )
        return 2

    new_df = read_discovery(sd)
    if new_df is None:
        print(
            "Discovery file appeared but disappeared again; check "
            "daemon-logs.",
            file=sys.stderr,
        )
        return 2

    print(
        f"Daemon respawned. PID={new_df.pid} port={new_df.port} "
        f"version={new_df.version}",
    )
    print(f"URL: http://127.0.0.1:{new_df.port}/")
    return 0


def _run_daemon_logs(args) -> int:
    """``forge-manager-mcp daemon-logs`` (#339).

    Tails the daemon's log file. ``--lines N`` controls the
    initial chunk; ``--follow`` streams new lines.

    Exit codes: 0 success; 1 no log file (daemon never ran or
    operator opted out of file logging).
    """
    import time
    from forge_manager_mcp.daemon.paths import (
        DEFAULT_PROJECT_NAME, log_dir,
    )

    name = args.project_name or DEFAULT_PROJECT_NAME
    log_path = log_dir(name) / "forge-manager.log"
    if not log_path.exists():
        print(
            f"No log file at {log_path}. Daemon may not have run "
            f"yet, or file logging is disabled.",
            file=sys.stderr,
        )
        return 1

    # Initial tail.
    try:
        with log_path.open("r", encoding="utf-8") as f:
            buf = f.readlines()
    except OSError as exc:
        print(f"Read failed: {exc}", file=sys.stderr)
        return 1

    tail = buf[-args.lines:] if args.lines > 0 else buf
    sys.stdout.write("".join(tail))
    sys.stdout.flush()

    if not args.follow:
        return 0

    # Follow mode — poll for appended bytes. Simple loop; in 3.5.x
    # we can swap for inotify / kqueue if perf matters.
    try:
        with log_path.open("r", encoding="utf-8") as f:
            f.seek(0, 2)  # end
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.25)
                    continue
                sys.stdout.write(line)
                sys.stdout.flush()
    except KeyboardInterrupt:
        return 0


def _run_check_design(args) -> int:
    """``forge-manager-mcp check-design`` (#345 / D3b.4r).

    Runs all registered code-design evaluators against the
    project. Useful as a pre-commit hook target — exits 0 on
    clean / warn-only, non-zero on fail.

    Exit codes:
      0 = no fail-severity findings
      1 = ≥1 fail-severity finding
      2 = unexpected error during evaluation
    """
    from pathlib import Path
    # Side-effect import: register evaluators.
    import forge_manager_mcp.code_design  # noqa: F401
    from forge_manager_mcp.code_design.registry import (
        all_rules, get_evaluator,
    )

    project_dir = Path(".").resolve()
    severity_rank = {"info": 0, "warn": 1, "fail": 2}
    min_rank = severity_rank.get(args.severity_filter, 0)

    if args.diff:
        print(
            "(--diff is 3.5.x scope; running full check instead)",
            file=sys.stderr,
        )

    findings_total: list = []
    fail_count = 0
    warn_count = 0
    info_count = 0
    try:
        for rule_name in all_rules():
            evaluator = get_evaluator(rule_name)
            if evaluator is None:
                continue
            # 3.5.0 default severity: warn for mechanical rules,
            # info for advisories. Match the handler's contract via
            # a simple lookup (advisory rules → info; rest → warn).
            severity = "info" if rule_name.endswith("_advisory") else "warn"
            for f in evaluator(project_dir, None, severity):
                rank = severity_rank.get(f.severity, 0)
                if rank < min_rank:
                    continue
                findings_total.append(f)
                if f.severity == "fail":
                    fail_count += 1
                elif f.severity == "warn":
                    warn_count += 1
                else:
                    info_count += 1
    except Exception as exc:
        print(f"check-design failed: {exc}", file=sys.stderr)
        return 2

    print(
        f"check-design: {len(findings_total)} finding(s) — "
        f"{fail_count} fail / {warn_count} warn / {info_count} info",
    )
    for f in findings_total[:50]:  # cap output for readability
        loc = f"{f.location.path}:{f.location.line}"
        print(f"  [{f.severity.upper()}] {f.rule} @ {loc}: {f.message}")
    if len(findings_total) > 50:
        print(f"  (... {len(findings_total) - 50} more)")

    return 1 if fail_count > 0 else 0


def _resolve_docs_repo_for_action_log(args) -> Path:
    """Resolve the canonical docs-repo path for the rebuild subcommand.

    Resolution order:
    1. ``--docs-repo`` CLI flag.
    2. ``$FORGE_MANAGER_DOCS_REPO`` env var (matches site.py's
       legacy resolver and the common operator pattern).
    3. ``~/<project>-docs/`` if the project has a corresponding
       directory under $HOME — same fallback the SiteRenderer used.

    Returns the resolved path. Caller verifies it exists.
    """
    import os
    if args.docs_repo is not None:
        return args.docs_repo
    env = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if env:
        return Path(env)
    name = args.project_name or DEFAULT_PROJECT_NAME
    return Path.home() / f"{name}-docs"


def _run_action_log(args) -> int:
    """``forge-manager-mcp action-log <subcommand>`` (#354 / D4.4).

    Currently the only subcommand is ``rebuild`` — drop+repopulate
    FTS5 indices from canonical. Future: stats, vacuum, etc.

    Exit codes:
      0 = success
      1 = invalid args / missing canonical / sqlite error
    """
    if args.action_log_subcommand != "rebuild":
        print(
            "Usage: forge-manager-mcp action-log rebuild [options]",
            file=sys.stderr,
        )
        return 1

    from forge_manager_mcp.daemon.action_log import (
        ensure_schema, open_connection, rebuild_fts5,
    )

    sd = _resolve_state_dir(args)
    docs_root = _resolve_docs_repo_for_action_log(args)
    if not docs_root.is_dir():
        print(
            f"action-log rebuild: docs repo not found at {docs_root}. "
            f"Pass --docs-repo or set $FORGE_MANAGER_DOCS_REPO.",
            file=sys.stderr,
        )
        return 1

    print(
        f"action-log rebuild: state-dir={sd} docs={docs_root}",
        file=sys.stderr,
    )
    con = open_connection(sd)
    try:
        ensure_schema(con)
        # (#384, 3.9.0 D3.1) Pass project_dir so the rebuild also
        # populates code_fts. CLI default is the cwd; operator can
        # override with --project-dir for ad-hoc rebuilds against a
        # different tree.
        project_root = (
            args.project_dir.resolve()
            if getattr(args, "project_dir", None) is not None
            else None
        )
        counts = rebuild_fts5(con, docs_root, project_root=project_root)
    except Exception as exc:
        print(f"action-log rebuild failed: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            con.close()
        except Exception:
            pass

    print(
        f"action-log rebuild: indexed "
        f"{counts['issues']} issue(s), "
        f"{counts['discussions']} discussion(s), "
        f"{counts['sessions']} session(s)",
    )
    return 0


if __name__ == "__main__":  # pragma: no cover — module-script entry; only fires when cli.py is invoked directly (`python -m forge_manager_mcp.server.cli`), not reachable from import-driven tests.
    main()
