"""Shared helpers for the server package (#82 Phase 2b).

These helpers were at module-level in `server.py` pre-split. They are
used by dispatch in `server.build` and by the handler modules in
`server.handlers.*`. They intentionally import no handler modules.

Tests that monkey-patch names like `forge_manager_mcp.server.
validate_node_id` continue to work: helpers look up github helpers
through `forge_manager_mcp.server` (late-bound) rather than
early-binding via `from ..github.foo import bar`. `server/__init__.py`
re-exports every such name so the lookup resolves.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

from mcp.types import TextContent

# Late binding — see module docstring.
from forge_manager_mcp import server as _s
from ..adapters.protocol import PlatformAdapter
from ..adapters.types import ArtifactKind, ArtifactRef
from ..models import GithubConfig, OperationError
from ..parsers import parse_owner_repo
from ..utils import NODE_ID_PARAMS
from .preflight import check_cross_repo_mutation

if TYPE_CHECKING:
    from ..context import ServerContext

_MAX_RETRIES = 3


# Candidate locations a project may keep its installed skill file.
# Probed in order; first existing path wins.
#
# 3.0 canonical install path is `.claude/skills/forge-manager/SKILL.md`
# (directory + SKILL.md with frontmatter, auto-loaded by Claude Code).
# 2.x and pre-2.0 paths remain in the candidate list so freshly-migrated
# projects (and broken installs) still resolve. The migration tool
# renames the directory; this list covers both pre- and post-migration
# state plus the legacy non-directory layouts. (G2)
_SKILL_FILE_CANDIDATES: tuple[Path, ...] = (
    # 3.0+ canonical
    Path(".claude") / "skills" / "forge-manager" / "SKILL.md",
    # 2.x canonical (#136, RFC #132) — kept for projects mid-migration
    Path(".claude") / "skills" / "active-claude-github" / "SKILL.md",
    # Pre-2.0 fallbacks (broken-install / dev-repo artefact)
    Path(".claude") / "skills" / "forge-manager.md",
    Path(".claude") / "skills" / "active-claude-github.md",
    Path("forge-manager.md"),
    Path("active-claude-github.md"),
)


async def validate_tool_node_ids(name: str, arguments: dict, token: str) -> None:
    """Validate every node-ID argument for the given tool before dispatch.

    Raises InvalidNodeIdError on the first bad ID. Empty / missing
    optional IDs are skipped.
    """
    for param in NODE_ID_PARAMS.get(name, []):
        value = arguments.get(param, "")
        if value:
            await _s.validate_node_id(token, param, value)


def resolve_local_skill_path(project_dir: Path) -> Path | None:
    """Return the first existing candidate skill-file path under
    `project_dir`, or None if none exists. (#90)"""
    for rel in _SKILL_FILE_CANDIDATES:
        candidate = project_dir / rel
        if candidate.exists():
            return candidate
    return None


# Candidate (repo, path) pairs probed when fetching the upstream skill
# text for drift detection. Order matters — first hit wins. (#159, G2)
#
# After the 2.0 monorepo merge the public mirror's main branch carries
# neither the root-level skill file nor the `.claude/skills/<name>/`
# tree, because the mirror sync excludes `.claude/`. The release asset
# is the canonical "what users install" source, but fetching it
# requires a separate release-API call. As a pragmatic interim, also
# try the dev (private) repo — the MCP server's token has access to
# it, and it carries the canonical multi-file SKILL.md. This works for
# self-managed projects (skill's own dev repo); external consumers
# without private access fall through to None and the banner shows no
# drift info.
def _upstream_skill_candidates(public_repo: str, dev_repo: str) -> tuple[
    tuple[str, str], ...
]:
    # 3.0 canonical paths first; 2.x paths kept so check_skill_version
    # against an unmigrated upstream still resolves. (G2)
    return (
        (public_repo, "forge-manager.md"),
        (public_repo, ".claude/skills/forge-manager/SKILL.md"),
        (dev_repo, ".claude/skills/forge-manager/SKILL.md"),
        (public_repo, "active-claude-github.md"),
        (public_repo, ".claude/skills/active-claude-github/SKILL.md"),
        (dev_repo, ".claude/skills/active-claude-github/SKILL.md"),
    )


async def fetch_upstream_skill_text(
    token: str, public_repo: str, dev_repo: str
) -> str | None:
    """Fetch the upstream skill file's text, trying multiple candidates.

    Returns the first non-empty response, or None if every candidate
    misses (404 or empty). Catches read failures per-candidate so a
    private-repo 403 on the last fallback doesn't poison earlier
    hits. (#159 / #388 3.9.0 D5)

    (#388, 3.9.0 D5) Migrated from GitHub-direct
    ``_s.get_file_content`` to daemon-routed ``dispatch_read``. Per-
    adapter failures now properly degrade the adapter state machine
    via ReplicationManager.read instead of silently swallowing the
    error and bypassing degradation entirely. Falls through to None
    on any exception (graceful-degrade contract preserved — caller
    treats None as "couldn't fetch").
    """
    # (#388) Lazy daemon import — tolerant of test contexts whose
    # BUILD deps don't include daemon (test_check_skill_version,
    # test_open_session). On ImportError fall back to the legacy
    # GitHub-direct path so old tests keep working unchanged.
    try:
        from ..daemon.paths import DEFAULT_PROJECT_NAME, state_dir
        from ..daemon_client import dispatch_read
        sd = state_dir(DEFAULT_PROJECT_NAME)
        _daemon_available = True
    except ImportError:
        sd = None
        dispatch_read = None
        _daemon_available = False

    for repo_full, path in _upstream_skill_candidates(public_repo, dev_repo):
        try:
            owner, name = parse_owner_repo(repo_full)
        except ValueError:
            continue
        text: str | None = None
        if _daemon_available:
            try:
                response = await dispatch_read(
                    sd, "get_file_content",
                    {
                        "owner": owner,
                        "repo": name,
                        "branch": "main",
                        "path": path,
                        "repo_role": "public",
                    },
                )
                text = response.get("value")
            except Exception:
                # Daemon-routed read failed — fall through to the
                # legacy GitHub-direct path on this candidate.
                text = None
        if text is None:
            # Legacy GitHub-direct fallback. Pre-#388 this was the
            # primary path; post-#388 it's the test-time + daemon-
            # absent fallback. Still graceful-degrade — silently
            # skip on GitHubError.
            try:
                text = await _s.get_file_content(
                    token, owner, name, "main", path,
                )
            except _s.GitHubError:
                continue
        if text:
            return text
    return None


async def fetch_project_toc_body(ctx: "ServerContext") -> str | None:
    """Fetch the current Project Discussion body via the canonical adapter.

    Returns None if no adapter has the body or the fetch fails for any
    reason (#63 graceful-degrade contract preserved).

    Pre-3.5.0 (#309 fix-class follow-up) this was a GitHub-direct read
    via ``_s.get_discussion_body(token, ...)``. Same bug pattern as
    #297 / 3.4.2 / #309 but on a post-canonical-write helper —
    ``post_turn`` / ``create_thread`` / ``fork_discussion`` /
    ``mark_decided`` / ``create_issue_tool`` all call this to attach
    the current TOC body to their response. With GitHub 403'd the
    helper silently returned ``None`` even though the canonical store
    has the body. This refactor reads canonical-first via
    ``ctx.replication.read``, so projects with a healthy local
    canonical (the 3.0+ default) get the actual body in the response
    even when every remote mirror is unreachable.
    """
    ref = make_canonical_ref(
        ctx, kind="discussion",
        native_id=ctx.config.project_discussion_id,
    )
    # (#356, 3.7.0 D8.2) Daemon-routed read mirroring D8.1's
    # get_issue_body migration. Helper stays graceful-degrade
    # (returns None on any failure including DaemonUnavailableError);
    # callers attach this to response envelopes as best-effort
    # context.
    from ..daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ..daemon_client import dispatch_read
    try:
        response = await dispatch_read(
            state_dir(DEFAULT_PROJECT_NAME),
            "get_discussion_body",
            {
                "native_id": ref.native_id,
                "owner": ref.owner,
                "repo": ref.repo,
                "repo_role": "private",
            },
        )
        return response.get("value")
    except Exception:
        return None


def coord_ref(ref: ArtifactRef, coords: tuple[str, str]) -> ArtifactRef:
    """Rewrite a ref's ``owner`` / ``repo`` with per-platform coords (#296).

    Used inside ``ctx.replication.write`` / ``read`` lambdas to thread
    the coords the manager passes per-iteration into ref-based adapter
    methods. Empty-string coords (``("", "")`` from the local
    canonical or 2.x fallback) are treated as "no override" — the
    ref's existing owner/repo passes through.

    Pure (no IO). Returns a frozen copy via Pydantic's
    ``model_copy(update=...)``.
    """
    new_owner = coords[0] or ref.owner
    new_repo = coords[1] or ref.repo
    if new_owner == ref.owner and new_repo == ref.repo:
        return ref
    return ref.model_copy(update={"owner": new_owner, "repo": new_repo})


def make_canonical_ref(
    ctx: "ServerContext",
    *,
    kind: ArtifactKind,
    native_id: str,
    number: int | None = None,
    owner: str | None = None,
    repo: str | None = None,
) -> ArtifactRef:
    """Construct an ``ArtifactRef`` pointed at the canonical adapter (#274).

    Defaults ``owner`` / ``repo`` to the project's primary repo from
    ``ctx.config.repos.private`` so callers that only know a node-ID
    can still produce a complete ref. ``platform_id`` is read from the
    canonical adapter's ``platform_id`` so multi-platform projects
    produce refs the ReplicationManager can route correctly.

    Pure (no IO). Intended for handlers that take a node-ID input but
    need to dispatch through ``ctx.replication.<read|write>`` against
    a method that accepts ``ArtifactRef``.
    """
    if owner is None or repo is None:
        default_owner, default_repo = parse_owner_repo(ctx.config.repos.private)
        owner = owner or default_owner
        repo = repo or default_repo
    # (#356, 3.7.0 D8 carryover) Read the cached platform_id from
    # ServerContext rather than calling `ctx.replication.canonical()`
    # at request time — one of the carryovers blocking final
    # `replication` field deletion.
    return ArtifactRef(
        platform_id=ctx.canonical_platform_id,
        native_id=native_id,
        kind=kind,
        owner=owner,
        repo=repo,
        number=number,
    )


async def resolve_thread_identifier(
    arguments: dict,
    primary_id_param: str,
    kind: str,
    default_owner: str,
    default_repo: str,
) -> str:
    """Return a canonical native_id from either primary-id arg or (number, owner, repo).

    Pre-3.5.0 (#56 original) translated `number` → GitHub node ID via a GraphQL
    roundtrip. That made every `number=` call site fail in degraded mode (GitHub
    unreachable) even when canonical had the artifact indexed by number — exactly
    the bug pattern #297 / 3.4.2 closed at the write layer. 3.5.0 Phase C closed
    it at the MCP-side resolver layer by dispatching to the canonical adapter.
    3.7.0 D8.9 (#356) closes the asymmetry by moving the resolution daemon-side
    so the MCP can delete its own ReplicationManager. 3.14.0 (#464) added the
    optional ``platform_id`` arg for per-call platform disambiguation — the
    canonical-on-local 3.0+ posture gives each backend its own number space, so
    operators need a path to resolve "this number means GitHub specifically"
    rather than always walking canonical first.

    Resolution order:
    - explicit primary-id arg → return as-is (caller already has the canonical ID)
    - `number=` → daemon-routed lookup via `dispatch_read("resolve_thread_
      identifier", ...)`; the daemon resolves against either the canonical
      adapter (default) or the adapter named by ``platform_id`` (#464).

    Pre-D8.9 the helper took a `canonical: PlatformAdapter` argument; that
    parameter is removed since the daemon owns the resolution.

    No GitHub-direct calls. Mirror fan-out happens later via ReplicationManager
    and surfaces failures as MirrorWarning per #297.
    """
    node_id = arguments.get(primary_id_param, "")
    number = arguments.get("number")

    if node_id and number is not None:
        raise ValueError(
            f"Provide either {primary_id_param} or number, not both."
        )
    if node_id:
        return node_id
    if number is None:
        raise ValueError(
            f"Either {primary_id_param} or number must be provided."
        )
    try:
        number_int = int(number)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"number must be an integer, got: {number!r}"
        ) from exc

    owner_arg = arguments.get("owner") or default_owner
    repo_arg = arguments.get("repo") or default_repo
    platform_id_arg = arguments.get("platform_id")

    # (#356, 3.7.0 D8.9 carryover) Daemon-routed canonical lookup.
    # (#464, 3.14.0) Optional ``platform_id`` plumbs through to the
    # daemon op — when set, the resolver skips canonical-first and
    # walks the named adapter directly.
    from ..daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ..daemon_client import dispatch_read
    response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "resolve_thread_identifier",
        {
            "primary_id": "",
            "number": number_int,
            "kind": kind,
            "owner": owner_arg,
            "repo": repo_arg,
            "platform_id": platform_id_arg,
        },
    )
    return response.get("value", "")


def preflight_cross_repo_mutation(
    config: GithubConfig, arguments: dict
) -> None:
    """Gate mutation tools against `related_repos` policy (#98).

    No-op when the caller did not specify an explicit `owner` / `repo`
    (the tool then targets the project's own dev repo). When explicit,
    defer to `check_cross_repo_mutation` which raises
    `CrossRepoMutationBlocked` for `cousin` / `foreign` targets.
    """
    owner_arg = arguments.get("owner")
    repo_arg = arguments.get("repo")
    if not owner_arg and not repo_arg:
        return

    default_owner, default_repo = parse_owner_repo(config.repos.private)
    owner_final = owner_arg or default_owner
    repo_final = repo_arg or default_repo
    check_cross_repo_mutation(config, owner_final, repo_final)


def ok(data: dict | list | str) -> list[TextContent]:
    """Wrap a successful result as MCP TextContent."""
    if isinstance(data, str):
        return [TextContent(type="text", text=data)]
    return [TextContent(type="text", text=json.dumps(data, indent=2))]


def err(error: OperationError) -> list[TextContent]:
    """Wrap an OperationError as MCP TextContent."""
    return [TextContent(type="text", text=json.dumps(error.model_dump(), indent=2))]


def with_retry(fn, *args, **kwargs):
    """Call fn up to _MAX_RETRIES times; raise the last exception on
    persistent failure."""
    last_exc = None
    for attempt in range(_MAX_RETRIES):
        try:
            return fn(*args, **kwargs)
        except (_s.GitHubError, _s.ClassificationError) as exc:
            last_exc = exc
            if attempt < _MAX_RETRIES - 1:
                continue
    raise last_exc


# Label catalogues used by handlers in multiple modules.
STANDARD_LABELS: tuple[tuple[str, str, str], ...] = (
    ("bug", "d73a4a", "Something isn't working"),
    ("feature", "a2eeef", "New feature or enhancement"),
    ("refactor", "ededed", "Internal restructure with no external behaviour change"),
    ("rfc", "fbca04", "RFC for a significant change"),
    ("chore", "cccccc", "Tooling, deps, config, CI"),
    ("area:skill", "0e8a16", "Changes to the forge-manager skill prose"),
    ("area:mcp", "0e8a16", "Changes to MCP server code or behaviour"),
    ("area:public-mirror", "5319e7", "Triaged from or targeted at a public mirror"),
    ("area:bootstrap", "5319e7", "Bootstrap sequence"),
)

TYPE_LABELS: frozenset[str] = frozenset({"bug", "rfc", "feature", "refactor", "chore"})
