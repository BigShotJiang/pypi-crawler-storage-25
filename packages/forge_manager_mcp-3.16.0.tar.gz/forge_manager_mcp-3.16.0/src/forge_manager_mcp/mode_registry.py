"""Mode registry — first-class abstraction (#501).

Operator-facing "modes" (``default`` / ``autonomous`` / ``plan`` /
project-defined) are computed labels over current gate-state, not a
separate state machine. Selecting a mode batch-applies its
``gate_states`` declarations; manually toggling a constituent gate
re-computes the displayed mode label.

This module is sibling to :mod:`forge_manager_mcp.gate_registry` —
same shape (YAML registry + pydantic schema + read-only registry
class) so projects can extend the surface via
``.claude/project-rules.md`` with the same mental model.

Loader exports
--------------

- :class:`Mode` / :class:`GateStateDeclaration` Pydantic models.
- :class:`ModeRegistry` with ``get_mode(name)`` / ``list_modes()``
  accessors.
- :func:`load_modes` — parse ``modes.yaml`` into a registry.
- :func:`compute_current_mode` — pure label computation over a
  current-gate-state snapshot. The bidirectional core: given the
  live gate state, returns the mode names whose constituent
  declarations all match (sorted alphabetically for determinism).
- :func:`mode_gate_targets` — flatten a mode's declarations into
  the ``(gate_name, target_state, scope)`` tuples a daemon batch-
  apply call consumes.
- :exc:`ModeRegistryError` — raised on schema violation, duplicate
  name, or malformed YAML.

YAML shape
----------

Re-uses the constrained-YAML parser from
:mod:`forge_manager_mcp.gate_registry` (``parse_yaml_text`` with
``root_key="modes"``). Each entry is a mapping with ``name``,
``description``, and ``gate_states`` keys; ``gate_states`` is a
sequence-of-mappings (one level of nesting, same shape
``processes[*].steps`` uses).
"""
from __future__ import annotations

from functools import cache
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, ValidationError, model_validator

from forge_manager_mcp.gate_registry import (
    GateRegistryError,
    parse_yaml_text,
)


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

TargetState = Literal["open", "closed"]


class ModeRegistryError(Exception):
    """Raised on YAML parse / schema / duplicate-name failure.

    Sibling of :exc:`GateRegistryError` — same role; separate class so
    handlers can catch modes-specific failures without swallowing
    gate-registry diagnostics.
    """


@cache
def _gate_state_class() -> type:
    class GateStateDeclaration(BaseModel):
        """One gate-state declaration inside a :class:`Mode`.

        Names a gate by registered name + target state + optional
        scope tokens. The daemon's batch-apply path resolves
        ``gate`` against the project's gate registry, applies
        ``state``, and (when present) narrows the effect to
        ``scope``-listed tokens (e.g. ``[protocol_required_input,
        blocker]`` on ``autonomous_mode.pause_conditions``).
        """

        model_config = {"frozen": True, "extra": "forbid"}

        gate: str = Field(
            ...,
            description=(
                "Dot-namespaced gate identifier "
                "(e.g. ``autonomous_mode.pause_conditions``)."
            ),
        )
        state: TargetState = Field(
            ...,
            description=(
                "Target state the mode pins this gate to. "
                "``open`` fires the evaluator; ``closed`` is a no-op."
            ),
        )
        scope: tuple[str, ...] = Field(
            default_factory=tuple,
            description=(
                "Optional scope-narrowing tokens. When present, the "
                "daemon applies the state only for the listed tokens "
                "rather than the gate as a whole — e.g. autonomous "
                "mode keeps ``protocol_required_input`` + ``blocker`` "
                "pause conditions engaged while opening the rest."
            ),
        )

        @model_validator(mode="after")
        def _gate_is_dot_namespaced(self) -> "GateStateDeclaration":
            if "." not in self.gate:
                raise ValueError(
                    f"gate reference must be dot-namespaced "
                    f"(e.g. 'autonomous_mode.pause_conditions'), got "
                    f"{self.gate!r}"
                )
            return self

    return GateStateDeclaration


GateStateDeclaration = _gate_state_class()


@cache
def _mode_class() -> type:
    GateState = _gate_state_class()

    class Mode(BaseModel):
        """Named bundle of gate-state declarations.

        Selecting a mode applies every declaration in ``gate_states``
        atomically (within one operator action); the UI re-computes
        the displayed mode label from the resulting gate-state snap.
        Modes with empty ``gate_states`` (``default`` is the
        canonical example) act as identity labels — they're
        recognized when no other mode matches.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        name: str = Field(
            ...,
            description=(
                "Mode identifier. Lowercase letters / digits / "
                "underscores; no dots (modes aren't dot-namespaced "
                "because they're operator-facing labels, not the "
                "dot-namespaced gates they bundle)."
            ),
        )
        description: str = Field(
            ..., description="One-line operator-facing description."
        )
        gate_states: tuple = Field(
            default_factory=tuple,
            description=(
                "Sequence of gate-state declarations applied as a "
                "batch when the mode is selected. Empty for "
                "identity labels (``default`` / ``gated``)."
            ),
        )

        @model_validator(mode="after")
        def _name_shape(self) -> "Mode":
            if not self.name:
                raise ValueError("mode name must be non-empty")
            for ch in self.name:
                if not (ch.isalnum() or ch == "_"):
                    raise ValueError(
                        f"mode name must be alnum / underscore only "
                        f"(got {self.name!r})"
                    )
            if "." in self.name:
                raise ValueError(
                    f"mode names are not dot-namespaced; got {self.name!r}"
                )
            return self

    return Mode


Mode = _mode_class()


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class ModeRegistry:
    """Read-only collection of :class:`Mode` records, keyed by name."""

    __slots__ = ("_by_name",)

    def __init__(self, modes: list) -> None:
        self._by_name: dict = {}
        for mode in modes:
            if mode.name in self._by_name:
                raise ModeRegistryError(
                    f"duplicate mode name in registry: {mode.name!r}"
                )
            self._by_name[mode.name] = mode

    def get_mode(self, name: str):
        """Return the mode with the given name, or None if absent."""
        return self._by_name.get(name)

    def list_modes(self) -> list:
        """Return all modes in insertion order."""
        return list(self._by_name.values())

    def names(self) -> list[str]:
        """Return all mode names in insertion order."""
        return list(self._by_name.keys())

    def __len__(self) -> int:
        return len(self._by_name)

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._by_name


# ---------------------------------------------------------------------------
# Loader entry point
# ---------------------------------------------------------------------------

def load_modes(path: Path) -> ModeRegistry:
    """Parse a ``modes.yaml`` file into a :class:`ModeRegistry`.

    Raises :exc:`ModeRegistryError` on any failure (missing file,
    parse error, schema violation, duplicate name).
    """
    parsed = _parse_modes_yaml(path)
    GateState = _gate_state_class()
    ModeCls = _mode_class()
    modes: list = []
    for idx, item in enumerate(parsed):
        gate_states_raw = item.get("gate_states", [])
        if isinstance(gate_states_raw, list):
            try:
                item["gate_states"] = tuple(
                    GateState(**g) for g in gate_states_raw
                )
            except ValidationError as exc:
                raise ModeRegistryError(
                    f"modes.yaml entry {idx} gate_states failed "
                    f"schema validation: {exc}"
                ) from exc
        try:
            modes.append(ModeCls(**item))
        except ValidationError as exc:
            raise ModeRegistryError(
                f"modes.yaml entry {idx} failed schema validation: {exc}"
            ) from exc
    return ModeRegistry(modes)


def _parse_modes_yaml(path: Path) -> list[dict]:
    """File → parsed-list adapter. Wraps :func:`parse_yaml_text` so
    the loader's caller catches ``ModeRegistryError`` rather than
    the underlying ``GateRegistryError``.
    """
    if not path.exists():
        raise ModeRegistryError(f"modes.yaml not found: {path}")
    text = path.read_text(encoding="utf-8")
    try:
        return parse_yaml_text(text, root_key="modes")
    except GateRegistryError as exc:
        raise ModeRegistryError(f"{path}: {exc}") from None


# ---------------------------------------------------------------------------
# Bidirectional helpers — pure functions over registry + gate state
# ---------------------------------------------------------------------------

def mode_gate_targets(mode) -> list[tuple[str, str, tuple[str, ...]]]:
    """Flatten a mode's gate_states into ``(gate, state, scope)`` tuples.

    Used by the daemon's batch-apply path: iterate the result list,
    call ``apply_gate_state(gate, state, scope)`` for each entry, then
    publish the resulting ``mode.changed`` event.
    """
    return [
        (decl.gate, decl.state, tuple(decl.scope))
        for decl in mode.gate_states
    ]


def compute_current_mode(
    registry: ModeRegistry,
    gate_state: dict[str, str],
) -> list[str]:
    """Compute which mode(s) match the current ``gate_state`` snapshot.

    ``gate_state`` is a ``{gate_name: target_state}`` map; missing gates
    are treated as ``open`` (the gate registry's default-state
    contract).

    Returns the list of matching mode names sorted alphabetically for
    deterministic display. A mode matches when every declaration's
    ``state`` equals the gate's current state. Modes with empty
    ``gate_states`` always match — they're identity labels.

    **Empty result handling.** The caller (the daemon) substitutes
    ``"custom"`` when no registered mode matches AND no identity
    mode (e.g. ``default``) is registered. The substitution lives at
    the call site so this function stays a pure shape-mapping.

    **Composition.** Multiple modes can match simultaneously when
    their gate-state sets touch disjoint gates (autonomous + plan
    per Issue #501). The returned list preserves that — callers
    render compound labels by joining the entries.
    """
    matches: list[str] = []
    for mode in registry.list_modes():
        if _mode_matches(mode, gate_state):
            matches.append(mode.name)
    return sorted(matches)


def _mode_matches(mode, gate_state: dict[str, str]) -> bool:
    """Single-mode predicate for :func:`compute_current_mode`.

    Identity modes (empty gate_states) always match; constrained
    modes match when every declaration's gate is at the declared
    target state. Scope tokens are advisory at the registry layer —
    they narrow the daemon's apply semantics, not the label-
    computation predicate (the daemon resolves scoped state separately).
    """
    if not mode.gate_states:
        return True
    for decl in mode.gate_states:
        actual = gate_state.get(decl.gate, "open")
        if actual != decl.state:
            return False
    return True


def label_for_gate_state(
    registry: ModeRegistry,
    gate_state: dict[str, str],
    *,
    blocking_gate: str | None = None,
    fallback: str = "custom",
) -> str:
    """Operator-facing string label for the status display.

    Layered over :func:`compute_current_mode`:

    1. If ``blocking_gate`` is non-None, return the computed
       label ``"gated"`` — a fail-severity gate is blocking the
       next expected operation. (``gated`` is computed by the
       daemon's blocker-detection, per Issue #501's "fourth
       implicit state".)
    2. Otherwise, return the joined match list (``"autonomous"``,
       ``"autonomous + plan"``, ``"default"``), or ``fallback``
       when no mode matches.
    """
    if blocking_gate is not None:
        return "gated"
    matches = compute_current_mode(registry, gate_state)
    if not matches:
        return fallback
    return " + ".join(matches)


__all__ = [
    "GateStateDeclaration",
    "Mode",
    "ModeRegistry",
    "ModeRegistryError",
    "TargetState",
    "compute_current_mode",
    "label_for_gate_state",
    "load_modes",
    "mode_gate_targets",
]
