"""MCP-side daemon client (Phase D3a / 3.5.0).

The MCP discovers the running daemon via the discovery file
(``daemon.json`` under the per-project state-dir). When the daemon
is absent or stale, ``spawn_if_needed`` auto-spawns a fresh one
via ``subprocess.Popen`` with detachment flags.

Per #298 sub-RFC §Install tiers, this is **Tier 1 — Auto-spawn
from MCP** — the default install. No OS-level service required.
The MCP first-call detects no daemon → spawns one → daemon
double-forks (Unix) or detaches (Windows) → writes discovery
file → MCP retries.

Per #298 OQ2 closure: ``forge-config.json.daemon.auto_spawn = false``
forces degraded mode (MCP runs in-process LocalStoreAdapter; no
daemon-only features). The auto-spawn knob is read by the caller
(build_server) before this helper is invoked.

**Effect-then-interceptor split (code-design.md Rule 2).**
``probe_daemon`` (HTTP /health probe) and ``spawn_daemon`` (subprocess
spawn) are effect functions. ``spawn_if_needed`` is the orchestrator
that combines them with the discovery-file-read effect.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from forge_manager_mcp.daemon.discovery import (
    discovery_path,
    read_discovery,
)


_HEALTH_TIMEOUT_SECONDS = 2.0
"""Total wall-time for a /health probe. The daemon should respond
in milliseconds; 2s gives generous headroom for cold starts on
slow filesystems."""

_SPAWN_WAIT_SECONDS = 5.0
"""How long to wait for a freshly-spawned daemon to write its
discovery file before giving up. Five seconds is enough for the
HTTP server to bind a port + write the file even on slow VMs."""

_SPAWN_POLL_INTERVAL = 0.1


def is_pid_alive(pid: int) -> bool:
    """(#497) Return True iff ``pid`` is a live process.

    Uses ``os.kill(pid, 0)`` — signal 0 is the "no-op" liveness probe.
    Returns False on ProcessLookupError (PID gone); True for live AND
    zombie PIDs (zombies still occupy a kernel slot). Chain with
    :func:`is_pid_zombie` for the zombie distinction. Cross-platform:
    PermissionError + generic OSError both classify as alive
    (conservative — better than colliding with a live foreign PID).
    """
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return True


def read_proc_status_state(pid: int) -> str | None:
    """(#497) Linux-only: return the ``State:`` token from
    ``/proc/<pid>/status`` (e.g. ``"R"``, ``"S"``, ``"Z"``), or None
    on any failure (non-Linux platform, PID gone, malformed file).
    """
    try:
        with open(f"/proc/{pid}/status", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("State:"):
                    parts = line.split(None, 2)
                    if len(parts) >= 2:
                        return parts[1]
                    return None
        return None
    except (FileNotFoundError, PermissionError, OSError):
        return None


def is_pid_zombie(pid: int) -> bool:
    """(#497) True iff ``pid`` is a Linux zombie (state ``Z``).

    Zombies have exited but the parent hasn't ``wait()``ed. Signals
    are no-ops on them — Layer 3's daemon-stop detects this and
    cleans up the discovery file directly rather than waiting for
    the signal-loop timeout. On non-Linux platforms returns False.
    """
    state = read_proc_status_state(pid)
    if state is None:
        return False
    return state.startswith("Z")


def is_pid_dead_or_zombie(pid: int) -> bool:
    """(#497) Combined predicate: dead PID OR zombie PID.

    Used by Layer 1 (:func:`probe_daemon`) and Layer 4
    (:func:`_classify_dispatch_failure`) to short-circuit the
    /health-timeout path.
    """
    if not is_pid_alive(pid):
        return True
    return is_pid_zombie(pid)


def read_auth_token(state_dir: Path) -> str | None:
    """Read auth_token from daemon.json. Returns None if no
    discovery file is present.

    Pure file read — does NOT probe /health. Callers that need
    liveness should pair this with ``probe_daemon``. The token is
    used as ``Authorization: Bearer <token>`` for daemon API calls
    that aren't on the unauth allowlist.

    Effect — file read.
    """
    df = read_discovery(state_dir)
    if df is None:
        return None
    return df.auth_token


async def full_status_probe(
    state_dir: Path,
    expected_version: str,
    *,
    timeout: float = 1.0,
) -> dict:
    """(#340) Comprehensive daemon-health snapshot.

    Returns a dict with the shape::

        {
          "running": bool,
          "version": str | None,
          "version_match": bool,
          "credentials_loaded": bool,    # /credentials reported encrypted_store
          "config_loaded": bool,         # /config returned loaded: true
          "url": str | None,             # http://127.0.0.1:<port>/ when running (#360)
          "warnings": list[str],         # human-readable, operator-actionable
        }

    Best-effort: every probe hop tolerates failure and contributes a
    warning rather than raising. When the daemon is absent the
    snapshot still returns successfully with ``running=False``.

    The MCP calls this once per session-open and exposes the result
    as ``open_session.daemon_status``. Operators / Claude also call
    it mid-session via the ``get_daemon_status`` tool to re-probe
    without re-doing session open.

    (#360, 3.7.0 D0) ``url`` field added so operators can open the UI
    in a browser without ``cat``-ing the discovery file by hand. The
    static-bypass ``/`` mount serves the SolidJS UI without auth, so
    just-the-URL is enough for browser-open; the Bearer token is
    still required for authenticated curl-against-endpoints (lives
    in ``daemon.json`` next to the URL). ``url`` is ``None`` when
    ``running`` is False.
    """
    df = read_discovery(state_dir)
    if df is None:
        return {
            "running": False,
            "version": None,
            "version_match": False,
            "credentials_loaded": False,
            "config_loaded": False,
            "url": None,
            "warnings": [],  # No daemon → no probe → no actionable warnings
        }

    warnings: list[str] = []
    version_match = df.version == expected_version
    if not version_match:
        warnings.append(
            f"daemon version {df.version} does not match MCP "
            f"version {expected_version} — consider `forge-manager-"
            f"mcp daemon-restart` to align"
        )

    # Probe /health to confirm liveness (catches stale-PID).
    running = False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            health = await client.get(
                f"http://127.0.0.1:{df.port}/health",
            )
            running = health.status_code == 200
    except (httpx.HTTPError, OSError):
        running = False
    if not running:
        warnings.append(
            "daemon discovery file present but /health unreachable "
            "— daemon may have crashed; try `forge-manager-mcp "
            "daemon-restart`"
        )
        return {
            "running": False,
            "version": df.version,
            "version_match": version_match,
            "credentials_loaded": False,
            "config_loaded": False,
            "url": None,  # not running → no clickable URL (#360)
            "warnings": warnings,
        }

    # Probe /config + /credentials with auth.
    headers = {"Authorization": f"Bearer {df.auth_token}"}
    config_loaded = False
    credentials_loaded = False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            config_resp = await client.get(
                f"http://127.0.0.1:{df.port}/config", headers=headers,
            )
            if config_resp.status_code == 200:
                payload = config_resp.json()
                config_loaded = bool(payload.get("loaded"))
            cred_resp = await client.get(
                f"http://127.0.0.1:{df.port}/credentials",
                headers=headers,
            )
            if cred_resp.status_code == 200:
                cpayload = cred_resp.json()
                if cpayload.get("loaded") is False:
                    # Daemon has no state-dir / platform list — same
                    # state as no encrypted store; not a warning.
                    credentials_loaded = False
                else:
                    entries = cpayload.get("credentials", [])
                    has_store = any(
                        e.get("source") == "encrypted_store" for e in entries
                    )
                    has_error = any(
                        e.get("source") == "error" for e in entries
                    )
                    credentials_loaded = has_store
                    if has_error:
                        warnings.append(
                            "encrypted credential store could not be "
                            "decrypted; using env-var fallback — "
                            "consider `migrate_to_3_5 --apply` to "
                            "rebuild"
                        )
    except (httpx.HTTPError, OSError, ValueError):
        warnings.append(
            "daemon /config or /credentials probe failed — daemon "
            "may be in a partial-init state; check `daemon-logs`"
        )

    if not config_loaded:
        warnings.append(
            "daemon has not loaded forge-config.json — likely "
            "spawned without --project-dir (#338 / #498) or "
            "pre-bootstrap; MCP restart may resolve"
        )

    return {
        "running": running,
        "version": df.version,
        "version_match": version_match,
        "credentials_loaded": credentials_loaded,
        "config_loaded": config_loaded,
        # (#360, 3.7.0 D0) Operator can paste this URL into a browser
        # to open the SolidJS UI without inspecting daemon.json.
        "url": f"http://127.0.0.1:{df.port}/",
        "warnings": warnings,
    }


async def fetch_alerts(
    state_dir: Path,
    *,
    since: str | None = None,
    level: str | None = None,
    limit: int | None = None,
    timeout: float = 1.0,
) -> list[dict]:
    """Poll the daemon's GET /alerts (#341).

    Returns the list of alerts (newest-first) or [] on any failure
    (no discovery file, daemon down, network error, auth reject,
    non-200, malformed JSON). Best-effort: callers MUST not depend
    on freshness; the daemon's retained log is a fallback channel,
    not the source of truth.

    The MCP polls this on session-open via ``open_session`` to
    surface daemon-side events the operator missed while the UI was
    closed. Cursor management (which alerts have been observed) is
    the caller's job — pass ``since=<iso-ts>`` of the last observed
    alert to get just-since-then.

    Callers that need the truncation metadata (total_count /
    truncated) should use :func:`fetch_alerts_bounded` instead —
    this wrapper returns only the list for back-compat.
    """
    bundle = await fetch_alerts_bounded(
        state_dir, since=since, level=level, limit=limit, timeout=timeout,
    )
    return bundle["alerts"]


async def fetch_alerts_bounded(
    state_dir: Path,
    *,
    since: str | None = None,
    level: str | None = None,
    limit: int | None = None,
    timeout: float = 1.0,
) -> dict:
    """(#488 / 3.14.0) Bounded variant of :func:`fetch_alerts`.

    Returns ``{"alerts": [...], "total_count": N, "truncated": bool}``
    instead of just the list. ``total_count`` is the count of matching
    rows under the same ``since`` / ``level`` filter BEFORE the
    ``limit`` cap; ``truncated`` is True when ``len(alerts) <
    total_count``. The operator-visible surface (``daemon_alerts`` in
    ``open_session``) uses this metadata to surface "N more" hints
    without unbounded payload size.

    Same failure semantics as :func:`fetch_alerts` — every error path
    returns ``{"alerts": [], "total_count": 0, "truncated": False}``
    so callers never have to handle exceptions for missing daemon /
    network failure / malformed response.
    """
    empty = {"alerts": [], "total_count": 0, "truncated": False}
    df = read_discovery(state_dir)
    if df is None:
        return empty
    params: dict[str, str] = {}
    if since:
        params["since"] = since
    if level:
        params["level"] = level
    if limit is not None:
        params["limit"] = str(limit)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.get(
                f"http://127.0.0.1:{df.port}/alerts",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                params=params,
            )
            if response.status_code != 200:
                return empty
            payload = response.json()
            if not isinstance(payload, dict):
                return empty
            alerts = payload.get("alerts", [])
            if not isinstance(alerts, list):
                return empty
            # total_count / truncated are 3.14.0+ additions; older
            # daemons (during a daemon-old / mcp-new mismatch window)
            # may omit them — fall back to inferring from the list.
            total_count = payload.get("total_count")
            if not isinstance(total_count, int):
                total_count = len(alerts)
            truncated = payload.get("truncated")
            if not isinstance(truncated, bool):
                truncated = (
                    limit is not None and len(alerts) >= limit
                    and total_count > len(alerts)
                )
            return {
                "alerts": alerts,
                "total_count": total_count,
                "truncated": truncated,
            }
    except (httpx.HTTPError, OSError, ValueError):
        return empty


async def post_alert_to_daemon(
    state_dir: Path, alert: dict, *, timeout: float = 0.5,
) -> bool:
    """MCP→daemon alert publish (#341).

    The MCP's natural alert surface — version-mismatch detection,
    daemon-spawn failures, etc. — pushes into the same retained log
    the UI sees. Best-effort: silently returns False on any failure
    so an unreachable daemon doesn't poison MCP startup paths.

    ``alert`` is a dict matching ``alert_to_dict`` shape:
    ``{level, message, detail, platform_id, timestamp, tags}`` —
    daemon-side ``alert_from_dict`` tolerates partials (missing
    timestamp → daemon-now).
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/alerts",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json=alert,
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


# --- Alert cursor (per-project state-dir) ---------------------------------

_ALERT_CURSOR_FILENAME = "observed_alerts_cursor.json"


def _alert_cursor_path(state_dir: Path) -> Path:
    return state_dir / _ALERT_CURSOR_FILENAME


def read_alert_cursor(state_dir: Path) -> str | None:
    """Read the last-observed-alert cursor (#341).

    Returns the ISO-8601 timestamp of the newest alert observed
    in the previous session, or None if no cursor exists yet
    (first run / never-observed). Used by ``open_session`` to fetch
    just the alerts the operator hasn't seen.

    Effect — file read. Returns None on missing-file, malformed
    JSON, or any IO error so cursor failures degrade to "show
    everything" rather than crash session startup.
    """
    p = _alert_cursor_path(state_dir)
    if not p.exists():
        return None
    try:
        import json
        payload = json.loads(p.read_text(encoding="utf-8"))
        cursor = payload.get("cursor")
        return cursor if isinstance(cursor, str) else None
    except (OSError, ValueError):
        return None


def write_alert_cursor(state_dir: Path, cursor: str) -> None:
    """Persist the latest-observed-alert cursor (#341).

    Atomic-replace via tmp + os.replace so a crash mid-write doesn't
    leave a half-written file the next read can't parse. Effect —
    file write.
    """
    import json
    p = _alert_cursor_path(state_dir)
    state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(
        json.dumps({"cursor": cursor}), encoding="utf-8",
    )
    import os as _os
    _os.replace(tmp, p)


class DaemonUnavailableError(RuntimeError):
    """Raised by ``dispatch_write`` when the daemon's /writes
    endpoint can't be reached or returns an error.

    Per #355 D5: each migrated MCP write handler catches this and
    surfaces an ``OperationError`` envelope to Claude rather than
    propagating to the user. Auto-spawn (#352) closes the operator-
    visible gap by ensuring the daemon is up before any write
    fires.
    """


class DaemonDeadError(DaemonUnavailableError):
    """(#497, 3.14.0) Raised when the daemon process is dead or a
    zombie — discovery file references a PID that can't answer.

    Subclass of :class:`DaemonUnavailableError` for back-compat;
    classified as **permanent** by ``is_permanent_error`` so the
    dispatch wrapper skips the buffer path (replay against a dead
    daemon would time out identically). Error message points at
    ``forge-manager-mcp daemon-restart``.
    """


class RemoteOpError(RuntimeError):
    """(#513, 3.16.0 D0) Raised by ``dispatch_write`` / ``dispatch_read``
    when the daemon was reached and responded with a 500 op-failure
    envelope (handler raised). Carries the original exception shape
    (``status_code`` + ``body`` + ``error_type``) walked from the
    daemon-side cause chain so ``is_permanent_error`` can classify
    the failure correctly.

    Distinct from :class:`DaemonUnavailableError` — DaemonUnavailable
    means the daemon itself can't answer (connection failure, no
    discovery file, 5xx without a recognized envelope shape). Remote
    op errors mean the daemon answered cleanly with a structured
    op-failure.

    The MCP-side dispatch wrapper (server/build.py) runs
    ``is_permanent_error(exc)`` which duck-types on ``status_code``
    + ``body`` — those attrs are forwarded from the daemon envelope
    so the predicate works identically to the pre-D5 in-process
    path that had native exception access.

    Pre-#513 every 500 from the daemon became
    DaemonUnavailableError(text_only); the lost status_code dropped
    the 403-from-suspended-GitHub class into the "transient" bucket
    so it buffered for infinite retry.
    """

    def __init__(
        self,
        op: str,
        error_type: str,
        message: str,
        *,
        status_code: int | None = None,
        body: object = None,
        is_permanent: bool = False,
    ):
        self.op = op
        self.error_type = error_type
        self.status_code = status_code
        self.body = body
        self.is_permanent = is_permanent
        super().__init__(message)


def _raise_remote_op_or_unavailable(
    response: "httpx.Response", op: str, route: str,
) -> None:
    """(#513, 3.16.0 D0) Disambiguate a non-200 daemon response.

    The daemon's post_write / post_read handler returns a structured
    JSON envelope with ``error_type`` on handler-exception (status 500).
    This helper raises :class:`RemoteOpError` carrying the original
    status_code + body + is_permanent flag so the MCP-side
    ``is_permanent_error`` predicate classifies the failure correctly.

    On any other non-200 (503 no-replication-manager, 400 bad input,
    malformed 500 envelope without ``error_type``), falls back to
    :class:`DaemonUnavailableError` preserving the pre-#513 contract.

    Never returns — always raises.
    """
    try:
        envelope = response.json()
    except Exception:
        # Includes ValueError (bad JSON) + AttributeError (response
        # shape missing .json()) + any httpx-specific decode failure.
        # Fall through to the unstructured-envelope path.
        envelope = None
    if isinstance(envelope, dict) and "error_type" in envelope:
        # Daemon returned the structured op-failure envelope.
        raise RemoteOpError(
            op=op,
            error_type=envelope.get("error_type", "Unknown"),
            message=envelope.get("error") or f"daemon {route} op failed",
            status_code=envelope.get("status_code"),
            body=envelope.get("body"),
            is_permanent=bool(envelope.get("is_permanent", False)),
        )
    # Fallback: unrecognized shape; treat as daemon-unavailable.
    raise DaemonUnavailableError(
        f"daemon {route} returned HTTP {response.status_code}: "
        f"{response.text[:300]}"
    )


def _classify_dispatch_failure(
    state_dir: Path,
    op_label: str,
    exc: Exception,
) -> DaemonUnavailableError:
    """(#497) Pick DaemonDeadError vs DaemonUnavailableError.

    Re-reads the discovery file + checks PID liveness via
    :func:`is_pid_dead_or_zombie`. On dead/zombie → DaemonDeadError
    (permanent). Otherwise → DaemonUnavailableError (transient,
    buffered).
    """
    df = read_discovery(state_dir)
    if df is not None and is_pid_dead_or_zombie(df.pid):
        return DaemonDeadError(
            f"daemon {op_label} unreachable: process PID {df.pid} is "
            f"dead or zombie; run `forge-manager-mcp daemon-restart` "
            f"to recover"
        )
    return DaemonUnavailableError(
        f"daemon {op_label} unreachable: {type(exc).__name__}: {exc}"
    )


async def dispatch_write(
    state_dir: Path,
    op: str,
    args: dict,
    *,
    timeout: float = 30.0,
) -> dict:
    """Dispatch a canonical write through the daemon (Phase D5 /
    #355 / capability 8).

    Reads the discovery file, posts ``{op, args}`` to the daemon's
    ``POST /writes`` with Bearer auth, returns the response JSON.

    Raises ``DaemonUnavailableError`` on:
        * No discovery file (daemon never started).
        * Connection failure / timeout.
        * Non-2xx HTTP response.
        * Malformed JSON in the response.

    The MCP-side handlers that migrate onto this surface in D5.2+
    catch this exception and wrap it into an ``OperationError``
    envelope so Claude sees a structured failure rather than a
    Python traceback. Per Discussion #6 OQ2 closure: "MCP becomes
    a thin adapter that POSTs canonical writes to the daemon".

    Timeout default 30s — accommodates worst-case mirror fan-out
    (canonical write + GitHub round-trip + Codeberg round-trip
    in serial). Faster ops complete in well under a second; the
    timeout is a runaway-process backstop, not a happy-path SLA.
    """
    df = read_discovery(state_dir)
    if df is None:
        raise DaemonUnavailableError(
            "no daemon discovery file — daemon is not running"
        )
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/writes",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"op": op, "args": args},
            )
    except (httpx.HTTPError, OSError) as exc:
        # (#497) Classify dead-daemon failures as permanent.
        raise _classify_dispatch_failure(state_dir, "/writes", exc) from exc
    if response.status_code != 200:
        _raise_remote_op_or_unavailable(response, op, "/writes")
    try:
        return response.json()
    except ValueError as exc:
        raise DaemonUnavailableError(
            f"daemon /writes response was not valid JSON: {exc}"
        ) from exc


async def dispatch_read(
    state_dir: Path,
    op: str,
    args: dict,
    *,
    timeout: float = 30.0,
) -> dict:
    """(#356, 3.7.0 D8) Dispatch a canonical read through the daemon.

    Mirrors :func:`dispatch_write`: reads the discovery file, posts
    ``{op, args}`` to the daemon's ``POST /reads`` with Bearer auth,
    returns the response JSON.

    Raises ``DaemonUnavailableError`` on:
        * No discovery file (daemon never started).
        * Connection failure / timeout.
        * Non-2xx HTTP response.
        * Malformed JSON in the response.

    The MCP-side handlers that migrate onto this surface in D8.2+
    catch this exception and either propagate (per #356 OQ1
    closure — read-paths handle graceful degradation case-by-case)
    or wrap into an ``OperationError`` envelope, matching the
    handler's existing failure semantics.

    Timeout default 30s — matches dispatch_write. Localhost reads
    complete in milliseconds; the timeout is a runaway-process
    backstop. Reads against a remote canonical (rare today) eat
    the network round-trip.

    Wire shape: returns ``{value: <op-result>}`` (writes return
    ``{value, mirror_warnings}``; reads omit mirror_warnings since
    failover is silent at the manager layer).
    """
    df = read_discovery(state_dir)
    if df is None:
        raise DaemonUnavailableError(
            "no daemon discovery file — daemon is not running"
        )
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/reads",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"op": op, "args": args},
            )
    except (httpx.HTTPError, OSError) as exc:
        # (#497) Classify dead-daemon failures as permanent.
        raise _classify_dispatch_failure(state_dir, "/reads", exc) from exc
    if response.status_code != 200:
        _raise_remote_op_or_unavailable(response, op, "/reads")
    try:
        return response.json()
    except ValueError as exc:
        raise DaemonUnavailableError(
            f"daemon /reads response was not valid JSON: {exc}"
        ) from exc


async def dispatch_migration_upsert(
    state_dir: Path,
    migration: dict,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.1) Best-effort POST /migrations/upsert.

    Register an in-flight migration with the daemon's holder so the
    UI's <MigrationSwimlane> sees it via /migrations/status + SSE.

    ``migration`` must match the make_migration shape: ``{id, title,
    steps: [{id, title, state}, ...]}``. Returns True on success;
    False on any failure (no daemon, network error, auth rejected,
    non-200). **Failures are intentionally silent** — the migration
    still runs locally; the UI just doesn't show live progress.

    Effect — file read (discovery) + network IO.
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/migrations/upsert",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json=migration,
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_migration_step(
    state_dir: Path,
    migration_id: str,
    step_id: str,
    new_state: str,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.1) Best-effort POST
    /migrations/{migration_id}/step/{step_id}.

    Flip a single step's lifecycle state (preview → running → complete).
    Returns True on success; False on any failure (no daemon, network
    error, auth rejected, 404 unknown step, non-200). **Failures are
    intentionally silent** for the same reason as
    ``dispatch_migration_upsert``."""
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}"
                f"/migrations/{migration_id}/step/{step_id}",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"state": new_state},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_migration_remove(
    state_dir: Path,
    migration_id: str,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.1) Best-effort DELETE /migrations/{migration_id}.

    Drop a migration from the holder (typical: after a grace period
    post-completion, or when the operator explicitly dismisses the
    swimlane via the title-bar ×). Returns True on success (including
    idempotent no-op on missing id); False on any failure."""
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.delete(
                f"http://127.0.0.1:{df.port}/migrations/{migration_id}",
                headers={"Authorization": f"Bearer {df.auth_token}"},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_release_upsert(
    state_dir: Path,
    release: dict,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.2) Best-effort POST /release/upsert.

    Register an in-flight release with the daemon's holder so the
    UI's <ReleaseSwimlane> sees it via /release/status + SSE. Same
    best-effort contract as dispatch_migration_upsert — failures
    return False without raising so the calling release_project
    handler isn't gated on daemon availability.
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/release/upsert",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json=release,
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_release_step(
    state_dir: Path,
    release_id: str,
    step_id: str,
    new_state: str,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.2) Best-effort POST
    /release/{release_id}/step/{step_id}. Flip a single step's
    lifecycle state per the 5-state vocab (pending/running/done/
    failed/skipped)."""
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}"
                f"/release/{release_id}/step/{step_id}",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"state": new_state},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_release_remove(
    state_dir: Path,
    release_id: str,
    *,
    timeout: float = 2.0,
) -> bool:
    """(3.16.0 D1 / A.2) Best-effort DELETE /release/{release_id}.
    Same best-effort idempotent contract as
    dispatch_migration_remove."""
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.delete(
                f"http://127.0.0.1:{df.port}/release/{release_id}",
                headers={"Authorization": f"Bearer {df.auth_token}"},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


async def dispatch_triage_classify(
    state_dir: Path,
    *,
    title: str,
    body: str,
    existing_titles: list[str] | None = None,
    timeout: float = 5.0,
) -> dict | None:
    """(3.16.0 D5) Run the public-issue triage classifier via the
    daemon's POST /triage/classify endpoint. Returns the
    classification dict (``{category, confidence, reasons}``) on
    success, ``None`` on any failure (no daemon, network error,
    auth rejected, non-200 — the heuristic classifier never raises
    server-side so non-200 indicates a deeper issue).

    Pure pass-through; no canonical-store mutation. Used by MCP
    tools that want to run the classifier without instantiating
    it locally (keeps the classifier vocabulary single-sourced
    at the daemon)."""
    df = read_discovery(state_dir)
    if df is None:
        return None
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/triage/classify",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={
                    "title": title,
                    "body": body,
                    "existing_titles": list(existing_titles or []),
                },
            )
            if response.status_code != 200:
                return None
            return response.json()
    except (httpx.HTTPError, OSError):
        return None


async def post_event(
    state_dir: Path, event: str, data: dict, *, timeout: float = 0.5,
) -> bool:
    """Publish an event to the daemon's POST /events. Best-effort.

    Returns True on success (daemon accepted + broadcast); False on
    any failure (no discovery file, daemon down, network error,
    auth rejected, non-200 response). **Failures are intentionally
    silent** — the canonical write that triggered this publish has
    already succeeded; daemon-side event publishing is purely
    decorative for the UI.

    The 0.5s timeout caps how long a slow / unresponsive daemon can
    delay the MCP's flow. localhost should respond in milliseconds;
    beyond half a second we treat the daemon as effectively down.

    Effect — file read (auth_token + port from daemon.json) +
    network IO. Async because httpx's AsyncClient context-managed
    pattern matches the MCP's existing async event-loop runtime.
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/events",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"event": event, "data": data},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


def probe_daemon(state_dir: Path) -> "DaemonStatus":
    """Read the discovery file + probe /health. Returns status.

    Returns:
        DaemonStatus.RUNNING — discovery file present + PID alive +
            /health 200.
        DaemonStatus.STALE   — discovery file present, PID alive,
            /health failed.
        DaemonStatus.ABSENT  — no discovery file OR discovery file
            references a dead/zombie PID (per (#497)).

    (#497, 3.14.0) Short-circuits dead/zombie PIDs to ABSENT before
    the /health probe so :func:`spawn_if_needed` respawns immediately
    instead of waiting ``_HEALTH_TIMEOUT_SECONDS`` for a guaranteed-
    dead daemon.
    """
    df = read_discovery(state_dir)
    if df is None:
        return DaemonStatus.ABSENT
    # (#497) Cheap PID liveness check before slow HTTP probe.
    if is_pid_dead_or_zombie(df.pid):
        return DaemonStatus.ABSENT
    try:
        with httpx.Client(timeout=_HEALTH_TIMEOUT_SECONDS) as client:
            response = client.get(
                f"http://127.0.0.1:{df.port}/health",
            )
            if response.status_code == 200:
                return DaemonStatus.RUNNING
    except (httpx.HTTPError, OSError):
        pass
    return DaemonStatus.STALE


def spawn_daemon(
    state_dir: Path,
    project_name: str,
    *,
    project_dir: Path | None = None,
) -> int:
    """Spawn a daemon process via subprocess.Popen with detachment.

    Returns the spawned PID. Does NOT wait for the daemon's
    discovery file — the caller polls for that via
    ``wait_for_discovery``.

    Detachment:
    - Unix: ``start_new_session=True`` causes setsid; the daemon
      becomes its own session leader and survives the parent's
      exit. ``stdout`` / ``stderr`` go to ``DEVNULL``.
    - Windows: ``CREATE_NEW_PROCESS_GROUP`` flag detaches the
      process group; ``DETACHED_PROCESS`` would also work but
      ``CREATE_NEW_PROCESS_GROUP`` plays better with pythonw.

    The daemon binary is invoked via ``sys.executable -m
    forge_manager_mcp.daemon.main`` rather than the
    ``forge-manager-daemon`` console script, so this works in
    development trees + Bazel sandbox contexts where the script
    isn't on PATH.

    ``project_dir`` (#338): when provided, threads through as
    ``--project-dir <path>`` so the spawned daemon loads the
    project's forge-config.json + constructs its ReplicationManager.
    Without it the daemon is /health-only — capabilities 1 (backend
    pause/resume) and 4 (repo viewer) require a loaded config.
    """
    cmd = [
        sys.executable, "-m", "forge_manager_mcp.daemon.main",
        "--project-name", project_name,
        "--state-dir", str(state_dir),
    ]
    if project_dir is not None:
        cmd.extend(["--project-dir", str(project_dir)])
    kwargs: dict[str, Any] = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        # Windows: detach via CREATE_NEW_PROCESS_GROUP.
        kwargs["creationflags"] = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    else:
        # Unix: become session leader; survives parent exit.
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(cmd, **kwargs)
    return proc.pid


def wait_for_discovery(
    state_dir: Path,
    timeout: float = _SPAWN_WAIT_SECONDS,
) -> bool:
    """Poll for discovery file existence until timeout. Returns
    True if the file appears in time, False otherwise.

    Effect — file IO. Used after ``spawn_daemon`` to bridge the
    spawn → ready window.
    """
    target = discovery_path(state_dir)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if target.exists():
            return True
        time.sleep(_SPAWN_POLL_INTERVAL)
    return False


def wait_for_ready(
    host: str,
    port: int,
    *,
    timeout: float = _SPAWN_WAIT_SECONDS,
) -> tuple[bool, float]:
    """(#469) Poll ``/health/ready`` until ``ready=True`` or timeout.

    Distinct from :func:`wait_for_port_bound` (which returns once
    uvicorn answers HTTP, i.e. liveness) — this returns once the
    daemon's post-bind initialization sequence completes:

      * Credentials populated (or env-var fall-through done).
      * Replication manager constructed (or explicitly None when
        --project-dir wasn't passed; either way the construction
        attempt has finished).
      * Startup probe task scheduled (first per-adapter probe
        dispatched).
      * Canonical-reconciler task scheduled (#470 sub-fix 2b
        sibling).

    Why two probes: the 3.13.0 / pre-#469 auto-restart contract
    returned ok=True after :func:`wait_for_port_bound`, which only
    guarantees uvicorn accepts connections. Audit dispatch + mirror
    fan-out in ``open_session`` could fire against the post-restart
    daemon BEFORE startup_probe ran, surfacing transient
    DEGRADED state on every non-canonical adapter. The
    ``/health/ready`` endpoint distinguishes "alive" from "ready";
    this poller bridges the gap so callers can sequence dependent
    work safely.

    Returns ``(ready, elapsed_seconds)``. On True, elapsed_seconds
    is wall-time from call-start to the first ready=True response.
    On False, elapsed_seconds equals timeout.

    Effect — sync HTTP probe. Synchronous so :func:`restart_daemon`
    (also sync) can use it inline without a running event loop.
    Polls at ``_SPAWN_POLL_INTERVAL`` (100ms default) with a tight
    per-request timeout (300ms) — readiness is binary, no need to
    pay long timeouts.

    Best-effort: every per-request failure (ConnectError, JSON
    parse, HTTPError) treats this tick as "not ready" and loops.
    On older daemons that don't expose ``/health/ready`` (404), the
    poller never sees ready=True and exits via timeout —
    caller-visible False return, deliberate fallback to the
    pre-#469 wait-for-port-bound semantics. The
    ``decide_wait_for_ready_required`` helper lets callers gate this
    poll on a known-ready-bearing version contract.
    """
    deadline = time.monotonic() + timeout
    started = time.monotonic()
    url = f"http://{host}:{port}/health/ready"
    with httpx.Client(timeout=0.3) as client:
        while time.monotonic() < deadline:
            try:
                resp = client.get(url)
                if resp.status_code == 200:
                    payload = resp.json()
                    if bool(payload.get("ready")):
                        return True, time.monotonic() - started
            except (httpx.HTTPError, OSError, ValueError):
                pass
            time.sleep(_SPAWN_POLL_INTERVAL)
    return False, timeout


def wait_for_port_bound(
    host: str,
    port: int,
    *,
    timeout: float = _SPAWN_WAIT_SECONDS,
) -> tuple[bool, float]:
    """(#426 / 3.12.0 D9) Poll /health until 200 or timeout.

    Bridges the gap between ``wait_for_discovery`` (file appears)
    and "daemon HTTP server is accepting connections." On a fresh
    spawn, the daemon writes its discovery file slightly before
    its uvicorn listener has bound the port, so any caller that
    fires HTTP requests immediately after ``wait_for_discovery``
    can hit ``ConnectError: All connection attempts failed``.

    Returns ``(bound, elapsed_seconds)``. On True, ``elapsed_seconds``
    is the time from call-start to the first 200 response. On False,
    ``elapsed_seconds`` equals ``timeout``.

    Effect — sync HTTP probe. Synchronous so callers like
    :func:`restart_daemon` (also synchronous) can use it without
    a running event loop.

    Polls at ``_SPAWN_POLL_INTERVAL`` (50ms by default), giving
    ``timeout / interval`` attempts. Per-attempt request timeout is
    deliberately short (200ms) — a slow first response means the
    server is starting; a normal response means it's ready.
    """
    deadline = time.monotonic() + timeout
    started = time.monotonic()
    url = f"http://{host}:{port}/health"
    with httpx.Client(timeout=0.2) as client:
        while time.monotonic() < deadline:
            try:
                resp = client.get(url)
                if resp.status_code == 200:
                    return True, time.monotonic() - started
            except (httpx.HTTPError, OSError):
                pass
            time.sleep(_SPAWN_POLL_INTERVAL)
    return False, timeout


def installed_package_version(
    name: str = "forge-manager-mcp",
) -> str | None:
    """(#382) Return the on-disk installed version of ``name``.

    Reads via ``importlib.metadata.version``. Returns None on lookup
    failure (package not registered, dev tree without metadata, etc.).

    Compared against the running process's ``__version__`` to detect
    "running process is stale relative to installed wheel" — i.e.,
    ``pipx upgrade`` ran but Claude Code wasn't restarted, so the MCP
    process is still on the older code. Same wheel feeds both, so a
    mismatch only happens across an upgrade window.

    Effect — file IO via importlib's metadata cache. Synchronous and
    fast (microseconds); safe to call from inside an async path.
    """
    try:
        from importlib.metadata import version as _v
        return _v(name)
    except Exception:  # noqa: BLE001 — every failure mode is "unknown"
        return None


def decide_auto_restart_action(
    daemon_version: str | None,
    mcp_version: str,
    installed_version: str | None,
) -> str:
    """(#382 / #16 OQ7) Pure 3-way decision: should auto-restart fire?

    The daemon-vs-MCP version mismatch needs differentiated handling:

    * ``"no_action"`` — daemon matches MCP, OR no daemon to restart.
      Nothing to do.
    * ``"restart"`` — daemon is stale BUT mcp matches the on-disk
      wheel, so a daemon-restart will pick up the matching version.
      Safe to fire.
    * ``"skip_mcp_stale"`` — daemon is stale AND mcp also lags the
      on-disk wheel. The MCP process itself is out of date — the
      operator hasn't restarted Claude Code since ``pipx upgrade``.
      Restarting the daemon would still leave it on a different
      version from MCP, so skip and surface a "restart Claude Code"
      hint instead.
    * ``"skip_unknown"`` — installed version lookup failed (importlib
      metadata couldn't find the wheel). Skip out of caution: we
      can't verify whether restarting would actually align things.

    Pure: depends only on the three input strings. Tests cover every
    decision branch in isolation; the IO-bearing wrapper
    ``_probe_daemon_status_for_session`` consumes the decision.
    """
    # MCP itself diverges from the on-disk wheel (most common cause:
    # `pipx upgrade` ran but Claude Code wasn't restarted, so this MCP
    # process is stale relative to the wheel) → daemon-restart spawned
    # by THIS MCP would still be on the stale code. Operator needs to
    # restart Claude Code; surface that hint regardless of daemon state.
    if installed_version is not None and installed_version != mcp_version:
        return "skip_mcp_stale"
    if daemon_version is None or daemon_version == mcp_version:
        return "no_action"
    if installed_version is None:
        return "skip_unknown"
    return "restart"


def restart_daemon(
    state_dir: Path,
    project_name: str,
    *,
    project_dir: Path | None = None,
    timeout: float = _SPAWN_WAIT_SECONDS,
) -> dict:
    """(#382) Stop running daemon (if any), spawn a fresh one.

    Synchronous. SIGTERM the existing PID, wait up to ``timeout`` for
    it to exit, clean up the stale discovery file, then ``spawn_daemon``
    + ``wait_for_discovery``. Mirrors ``server.cli._run_daemon_restart``
    but returns a structured dict instead of printing + exiting.

    Returns dict::

        {
          "ok": bool,
          "from_pid": int | None,    # PID of the daemon we killed
          "to_pid": int | None,      # PID of the spawned daemon
          "from_version": str | None,
          "to_version": str | None,
          "message": str,            # human-readable outcome
        }

    Best-effort — every failure mode degrades to ``ok=False`` with a
    diagnostic ``message`` rather than raising. The auto-restart
    caller uses ``message`` for banner display.

    ``project_dir`` is threaded through to ``spawn_daemon`` so the
    new daemon loads forge-config.json + constructs its
    ReplicationManager. Without it the new daemon is /health-only
    (regression on the pre-restart capability set).
    """
    import signal

    from_df = read_discovery(state_dir)
    from_pid = from_df.pid if from_df else None
    from_version = from_df.version if from_df else None

    if from_df is not None:
        try:
            os.kill(from_df.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass  # Already gone — proceed to spawn.
        except OSError as exc:
            return {
                "ok": False, "from_pid": from_pid, "to_pid": None,
                "from_version": from_version, "to_version": None,
                "message": f"SIGTERM failed: {exc}",
            }
        deadline = time.monotonic() + timeout
        exited = False
        while time.monotonic() < deadline:
            try:
                os.kill(from_df.pid, 0)
            except ProcessLookupError:
                exited = True
                break
            time.sleep(_SPAWN_POLL_INTERVAL)
        if not exited:
            return {
                "ok": False, "from_pid": from_pid, "to_pid": None,
                "from_version": from_version, "to_version": None,
                "message": (
                    f"daemon PID {from_pid} did not exit within "
                    f"{timeout}s of SIGTERM"
                ),
            }
        # Defense-in-depth: clean up stale discovery file.
        from forge_manager_mcp.daemon.discovery import remove_discovery
        remove_discovery(state_dir)

    try:
        new_pid = spawn_daemon(
            state_dir, project_name, project_dir=project_dir,
        )
    except Exception as exc:  # noqa: BLE001 — see docstring
        return {
            "ok": False, "from_pid": from_pid, "to_pid": None,
            "from_version": from_version, "to_version": None,
            "message": f"spawn failed: {exc}",
        }

    if not wait_for_discovery(state_dir, timeout=timeout):
        return {
            "ok": False, "from_pid": from_pid, "to_pid": new_pid,
            "from_version": from_version, "to_version": None,
            "message": (
                f"spawned PID {new_pid} but no daemon.json appeared "
                f"within {timeout}s"
            ),
        }

    new_df = read_discovery(state_dir)
    if new_df is None:
        return {
            "ok": False, "from_pid": from_pid, "to_pid": new_pid,
            "from_version": from_version, "to_version": None,
            "message": "discovery file appeared but disappeared again",
        }

    # (#426 / 3.12.0 D9) Barrier: wait for the new daemon's HTTP
    # listener to bind before returning success. Discovery file
    # appears slightly before uvicorn is accepting connections; any
    # downstream code that dispatches HTTP requests immediately
    # after seeing ok=True would otherwise hit ConnectError on a
    # fresh restart. The 2026-05-10 open_session diagnosis surfaced
    # exactly this race — `repo_shape` audits ran with ConnectError
    # despite restart_action.ok = True.
    bound, port_bound_after = wait_for_port_bound(
        "127.0.0.1", new_df.port, timeout=timeout,
    )
    if not bound:
        return {
            "ok": False, "from_pid": from_pid, "to_pid": new_df.pid,
            "from_version": from_version, "to_version": new_df.version,
            "port_bound_after_seconds": None,
            "ready_after_seconds": None,
            "message": (
                f"spawned PID {new_df.pid} (version {new_df.version}) "
                f"but /health did not respond 200 within {timeout}s of "
                "discovery file appearing — daemon HTTP server failed "
                "to bind"
            ),
        }

    # (#469) Second barrier: wait for the new daemon's startup-probe
    # + credentials + replication construction to complete. The bind
    # signal (above) only guarantees uvicorn accepts connections;
    # /health/ready=true guarantees the post-bind init sequence
    # finished. Pre-#469 audit dispatch + mirror fan-out in
    # open_session raced this window and saw transient DEGRADED on
    # every non-canonical adapter. The 2026-05-14 open_session
    # diagnosis filed both symptoms (phantom UNREACHABLE audit +
    # unknown-write-op fan-out) and identified this as the root
    # cause.
    #
    # Best-effort: on older daemons that don't expose /health/ready
    # the poll exits via timeout, ``ready_after_seconds`` is None,
    # but ``ok`` stays True because the bind barrier was the only
    # contract before #469. This preserves back-compat for the
    # transition window when an MCP from this commit talks to a
    # daemon from the prior version.
    ready, ready_after = wait_for_ready(
        "127.0.0.1", new_df.port, timeout=timeout,
    )

    return {
        "ok": True, "from_pid": from_pid, "to_pid": new_df.pid,
        "from_version": from_version, "to_version": new_df.version,
        "port_bound_after_seconds": port_bound_after,
        "ready_after_seconds": ready_after if ready else None,
        "ready": ready,
        "message": (
            f"daemon restarted: {from_version or 'absent'} → "
            f"{new_df.version}"
        ),
    }


def spawn_if_needed(
    state_dir: Path,
    project_name: str,
    *,
    auto_spawn: bool = True,
    project_dir: Path | None = None,
) -> "SpawnResult":
    """Probe + spawn-if-needed orchestrator.

    Returns:
        SpawnResult with `.status`, `.pid` (when known), `.spawned`
        (True if this call started the daemon).

    `auto_spawn=False` forces probe-only mode (per #298 OQ2). The
    caller (build_server) reads `forge-config.json.daemon
    .auto_spawn` and passes through. False keeps degraded-mode
    semantics: returns RUNNING if a daemon is already up, ABSENT
    otherwise — never spawns.

    `project_dir` (#338): threaded through to ``spawn_daemon`` so
    the spawned daemon loads forge-config.json + constructs its
    ReplicationManager. Pre-bootstrap mode (no config file) is
    handled daemon-side via tolerant ``_load_project_config``;
    pass through ``ctx.project_dir`` regardless of bootstrap state.
    """
    status = probe_daemon(state_dir)
    if status == DaemonStatus.RUNNING:
        df = read_discovery(state_dir)
        return SpawnResult(
            status=status,
            pid=df.pid if df else None,
            spawned=False,
        )

    if not auto_spawn:
        return SpawnResult(status=status, pid=None, spawned=False)

    # ABSENT or STALE → spawn fresh. Stale-PID daemons never reply
    # to /health, so the discovery file we have is dead-letter;
    # writing a new daemon's discovery file overwrites it.
    pid = spawn_daemon(state_dir, project_name, project_dir=project_dir)
    if not wait_for_discovery(state_dir):
        return SpawnResult(
            status=DaemonStatus.SPAWN_TIMEOUT, pid=pid, spawned=True,
        )
    # Re-probe to confirm the new daemon is healthy.
    final = probe_daemon(state_dir)
    return SpawnResult(status=final, pid=pid, spawned=True)


# --- Status enum + result dataclass (factory pattern per Rule 5) ---

from enum import Enum
from dataclasses import dataclass
from functools import cache


class DaemonStatus(str, Enum):
    """Daemon liveness states.

    Values are strings so they serialize cleanly in JSON responses
    + log lines. ``str, Enum`` mixin keeps equality with strings
    (``status == "running"`` works).
    """
    RUNNING = "running"
    STALE = "stale"
    ABSENT = "absent"
    SPAWN_TIMEOUT = "spawn_timeout"


@cache
def _spawn_result_class() -> type:
    @dataclass(frozen=True)
    class SpawnResult:
        status: DaemonStatus
        pid: int | None
        spawned: bool
    return SpawnResult


def SpawnResult(*, status, pid, spawned):
    """Factory for SpawnResult values. Per Rule 5 the dataclass
    lives inside the cached helper, not at module level."""
    Cls = _spawn_result_class()
    return Cls(status=status, pid=pid, spawned=spawned)
