"""Bitemporal insert helper for shadow fact tables (OQ2 + OQ13).

Per Discussion #22 OQ2 closure: every shadow fact table is pure
insert-only. Both supersession (transaction-time) and ``valid_to``
(valid-time) are derived from window functions in hand-written
``_current`` views rather than stored as mutable columns. There is no
``UPDATE`` path; every fact mutation is one ``INSERT``.

Per Discussion #22 OQ13 closure: every fact table carries
``CREATE UNIQUE INDEX <name>_idempotent ON <table>(pk_columns, source_event)``.
Repeated dispatches for the same ``(key, source_event)`` raise
``sqlite3.IntegrityError``; this helper catches that and returns
``False`` so the caller treats "already applied" as success.

Effect-then-interceptor split (Rule 2): this module is the
effect — the ``conn.execute`` call. Caller composes the parameterized
SQL from its per-table typed wrapper. No table-specific knowledge
leaks in here.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def _bitemporal_insert_sql(table: str, columns: tuple[str, ...]) -> str:
    """Compose the parameterized ``INSERT INTO <table> (...) VALUES (...)``
    statement for a bitemporal fact row.

    Pure helper — no IO. The shape mirrors every fact table:
    ``<entity_columns> + (valid_from, recorded_at, source_event, recorded_by)``.

    Caller-supplied ``table`` and ``columns`` are interpolated into the
    SQL text (sqlite parameter binding doesn't accept identifiers).
    Both inputs come from per-table typed wrappers — never untrusted
    operator input. The values themselves bind via ``?`` placeholders.
    """
    all_columns = columns + (
        "valid_from", "recorded_at", "source_event", "recorded_by",
    )
    placeholders = ", ".join("?" for _ in all_columns)
    columns_sql = ", ".join(all_columns)
    return f"INSERT INTO {table} ({columns_sql}) VALUES ({placeholders})"


def _insert_bitemporal_row(
    conn: sqlite3.Connection,
    *,
    table: str,
    columns: tuple[str, ...],
    values: tuple[Any, ...],
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Pure ``INSERT`` into a bitemporal fact table.

    Returns ``True`` when the row landed; returns ``False`` on
    ``sqlite3.IntegrityError`` (the table's idempotency index already
    has a row for this ``(pk_columns, source_event)`` — that's the
    "already applied" signal per OQ13).

    Caller contract:

    * ``table`` and ``columns`` are statically-known per-table
      identifiers, NOT operator input. Per-table typed wrappers
      (e.g., ``insert_labels_fact``) supply these; the helper itself
      makes no validation pass on the strings.
    * ``values`` aligns positionally with ``columns``.
    * ``valid_from`` and ``recorded_at`` are ISO-8601 UTC strings.
    * ``source_event`` is the history-log filename, op name, or
      walker-rebuild sentinel — combined with the PK columns in the
      table's UNIQUE idempotency index.
    * ``recorded_by`` is the session_id or ``None`` for walker fills.

    Effect — issues one ``conn.execute`` against the connection. Does
    not commit; the caller (dispatch layer / walker batch) controls
    transaction boundaries.
    """
    sql = _bitemporal_insert_sql(table, columns)
    bound = (*values, valid_from, recorded_at, source_event, recorded_by)
    try:
        conn.execute(sql, bound)
    except sqlite3.IntegrityError:
        # OQ13: the idempotency index hit. Re-dispatch for the same
        # source_event landed; caller treats False as "already applied,
        # success".
        return False
    return True
