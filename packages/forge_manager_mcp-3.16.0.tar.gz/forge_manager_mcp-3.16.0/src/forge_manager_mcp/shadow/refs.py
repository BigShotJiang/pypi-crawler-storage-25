"""``refs_facts`` shadow table (Issue #477 / 3.14.0 Cluster A Phase 3).

Bitemporal fact log of ``#NNN`` cross-references parsed from canonical
artifact bodies + comments. Each ``(source_kind, source_id, target_kind,
ref_text, recorded_at)`` row records that ``source`` mentioned
``target`` at a specific point in time; the latest fact per partition
surfaces via the ``refs_current`` view.

Per Discussion #22 OQ11 closure: every ref carries a ``ref_source``
value drawn from the closed vocabulary in :mod:`shadow.types`.
``target_id`` is the canonical LocalStore number when the source's
``ref_source`` is authoritative-by-construction
(``localstore`` / ``git_commit``); rows backfilled from a remote
mirror (``github_backfill`` / ``forgejo_backfill`` / ``gitlab_backfill``
/ ``pre_3_0_backfill`` / ``unknown``) carry ``target_id = NULL`` so
strict-fidelity queries can filter them out via
``WHERE ref_source IN ('localstore', 'git_commit')``.

Walker scope (3.14.0):

* Reads ``<docs>/<kind>/<n>/body.md`` for every numbered artifact dir
  under ``issues/`` / ``discussions/`` / ``pulls/``.
* Reads ``<docs>/<kind>/<n>/comments/*.md`` when the directory exists;
  each comment file becomes one ``source_kind = 'comment'`` row whose
  ``source_id`` encodes the parent artifact + comment file.
* Tags every fact ``ref_source = 'localstore'`` — post-3.0 canonical
  authoring is canonical-by-construction. Backfill-derived rows land
  via ``import_remote_changes`` calling :func:`insert_refs_fact`
  directly (future work).
* Resolves ``target_id`` to the canonical number when a directory at
  ``<docs>/<target_kind>/<NNN>/`` exists; ``target_id = NULL``
  otherwise (the ref points at an artifact the canonical store hasn't
  ingested yet, or at a non-existent number).

Effect-then-interceptor split (Rule 2): the parse + filesystem read
are pure; INSERTs go through :func:`insert_refs_fact` on the caller's
connection.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .core import _insert_bitemporal_row
from .git_log import file_introduction_timestamp
from .registry import register_op_refresh, register_table
from .types import (
    DERIVABLE,
    GIT_COMMIT,
    LOCALSTORE,
    VALID_SOURCES,
)
from .views import current_view_ddl


TABLE_NAME: str = "refs_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/refs_facts`` endpoint + the registry lookup."""


_REF_COLUMNS: tuple[str, ...] = (
    "source_kind", "source_id", "target_kind", "target_id",
    "ref_text", "ref_source",
)
"""Entity-identifier + state columns bound positionally by
:func:`insert_refs_fact`. The framework columns (``valid_from``,
``recorded_at``, ``source_event``, ``recorded_by``) get appended
inside ``_insert_bitemporal_row``."""


_KIND_DIRECTORIES: tuple[tuple[str, str], ...] = (
    ("issue", "issues"),
    ("discussion", "discussions"),
    ("pull", "pulls"),
)
"""Mapping from canonical ``source_kind`` value to the docs-root subdir
the walker scans. Stable order so test assertions don't drift; first
tuple element lands in the row's ``source_kind`` / ``target_kind``
column, second is the docs subdir."""


_RESOLVABLE_SOURCES: frozenset[str] = frozenset({LOCALSTORE, GIT_COMMIT})
"""Closed set of ``ref_source`` values whose ``target_id`` the walker
resolves to a canonical LocalStore number per OQ11. Everything else
keeps ``target_id = NULL`` so unresolvable backfill refs stay
forensically distinguishable from refs that genuinely resolve."""


_REF_PATTERN: re.Pattern[str] = re.compile(r"#(\d+)")
"""Compiled ``#NNN`` regex. Matches every ``#`` followed by one-or-
more digits. The walker iterates ``finditer`` results so a single body
yields one fact row per distinct ``#NNN`` mention; the idempotency
index dedupes repeated walks against the same source_event."""


# Subdirs that contain canonical ref targets keyed by ``target_kind``.
_TARGET_KIND_TO_SUBDIR: dict[str, str] = dict(
    (kind, subdir) for kind, subdir in _KIND_DIRECTORIES
)
"""Lookup from canonical ``target_kind`` to the docs subdir the
resolver checks for ``<target_id>/`` directory existence. Built from
the same kind-table the walker uses so the two stay coherent."""


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS refs_facts (
      source_kind  TEXT NOT NULL,
      source_id    TEXT NOT NULL,
      target_kind  TEXT NOT NULL,
      target_id    TEXT,
      ref_text     TEXT NOT NULL,
      ref_source   TEXT NOT NULL,
      valid_from   TEXT NOT NULL,
      recorded_at  TEXT NOT NULL,
      source_event TEXT NOT NULL,
      recorded_by  TEXT,
      PRIMARY KEY (source_kind, source_id, target_kind, ref_text, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_refs_idempotent "
    "ON refs_facts(source_kind, source_id, target_kind, ref_text, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_refs_target "
    "ON refs_facts(target_kind, target_id)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=(
            "source_kind", "source_id", "target_kind", "ref_text",
        ),
        select_columns=(
            "source_kind", "source_id", "target_kind", "target_id",
            "ref_text", "ref_source",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``refs_current`` view exposes the latest fact per
``(source_kind, source_id, target_kind, ref_text)`` partition — the
window of mutability for a single mention (the same body re-walked
against a fresh ``source_event`` writes a new fact row whose
``recorded_at`` outranks the earlier walk)."""


def insert_refs_fact(
    conn,
    *,
    source_kind: str,
    source_id: str,
    target_kind: str,
    target_id: str | None,
    ref_text: str,
    ref_source: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Enforces the ``ref_source`` vocabulary (OQ11) at call time —
    callers passing an unknown source string hit a ``ValueError`` before
    the row binds, so the closed vocabulary stays closed.

    Args:
        conn: sqlite3 connection (must have ``refs_facts`` table).
        source_kind: ``'issue'`` / ``'discussion'`` / ``'pull'`` /
            ``'commit'`` / ``'comment'`` — the kind of artifact the
            ref appears in.
        source_id: Canonical LocalStore number (as string for
            commit-source rows that carry a SHA), or a
            ``"<parent_kind>/<parent_id>/comments/<file>"`` path for
            comment-source rows.
        target_kind: One of the canonical kinds the ref points at.
        target_id: Canonical LocalStore number of the target (string
            form), or ``None`` when the ``ref_source`` is in the
            backfill vocabulary per OQ11.
        ref_text: Verbatim ref text (e.g. ``"#441"``). Carries the
            ``#`` so query consumers can distinguish from raw integer
            target_id values.
        ref_source: One of :data:`shadow.types.VALID_SOURCES`. Raises
            ``ValueError`` on unknown values.
        valid_from: ISO-8601 timestamp the ref became true in the
            world.
        recorded_at: ISO-8601 timestamp the row was written.
        source_event: ``body.md_walk_<iso8601>`` /
            ``comment_walk_<iso8601>`` sentinel composed by the
            walker, op name when the dispatch layer calls in, or
            ``git_log_walk_<commit_hash>`` for commit-source rows.
        recorded_by: session_id, or ``None`` for walker fills.

    Returns:
        ``True`` on insert; ``False`` when the UNIQUE idempotency
        index hits (per OQ13 "already applied" contract).

    Raises:
        ValueError: when ``ref_source`` isn't in
            :data:`shadow.types.VALID_SOURCES`.
    """
    if ref_source not in VALID_SOURCES:
        raise ValueError(
            f"insert_refs_fact: ref_source {ref_source!r} not in "
            f"{sorted(VALID_SOURCES)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_REF_COLUMNS,
        values=(
            source_kind, source_id, target_kind, target_id,
            ref_text, ref_source,
        ),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Microsecond precision matters because the PK includes
    ``recorded_at`` — back-to-back walks in the same second would
    otherwise collide and silently dedup. Microseconds drop the
    resolution below typical walker timing.

    Abstracted so tests can monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _file_mtime_iso(path: Path) -> str | None:
    """Return the file's mtime as ISO-8601 UTC, or None when unreadable.

    Mirrors :func:`shadow.labels._file_mtime_iso`'s shape. The walker
    uses this as the second-tier ``valid_from`` source between the
    history-derived timestamp (not applicable for refs) and the git
    introduction-commit fallback.
    """
    try:
        ts = path.stat().st_mtime
    except OSError:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ",
    )


def _resolve_valid_from(
    body_path: Path,
    project_root: Path | None,
) -> str:
    """Resolve a ``valid_from`` timestamp for a body's refs.

    Resolution order:

    1. ``body.md``'s mtime (post-3.0 canonical authoring lands a
       fresh mtime per write).
    2. Git introduction-commit timestamp via
       :func:`shadow.git_log.file_introduction_timestamp` — the OQ12
       pre-3.0 backfill fallback when the file isn't writable / lost
       its mtime in a clone.
    3. Sentinel ``1970-01-01T00:00:00Z`` — keeps the NOT NULL
       constraint satisfied in pathological cases.

    Pure modulo the IO inside :func:`file_introduction_timestamp` +
    ``stat()``.
    """
    mtime_iso = _file_mtime_iso(body_path)
    if mtime_iso is not None:
        return mtime_iso
    if project_root is not None:
        git_ts = file_introduction_timestamp(project_root, body_path)
        if git_ts is not None:
            return git_ts
    return "1970-01-01T00:00:00Z"


def _parse_ref_numbers(text: str) -> list[str]:
    """Return every ``#NNN`` ref number from ``text`` in encounter order.

    Deduplicates via insertion-ordered dict so a body that mentions
    ``#441`` twice yields one fact row (matches the canonical
    "this body references issue 441" semantic). Returns the integer
    portion as a string so the caller can either compose the verbatim
    ``"#NNN"`` ref_text or use it as the candidate ``target_id``.

    Pure regex walk — no IO.
    """
    seen: dict[str, None] = {}
    for match in _REF_PATTERN.finditer(text):
        seen.setdefault(match.group(1), None)
    return list(seen.keys())


def _resolve_target_id(
    docs_root: Path,
    target_kind: str,
    target_number: str,
    ref_source: str,
) -> str | None:
    """Resolve a ref's ``target_id`` per the OQ11 vocabulary contract.

    Returns ``None`` immediately when ``ref_source`` is in the
    backfill vocabulary — the canonical-vs-native-id ambiguity means
    the number on the wire might not correspond to any LocalStore
    artifact, so the strict-fidelity contract says don't pretend.

    For resolvable sources (``localstore`` / ``git_commit``), checks
    that ``<docs_root>/<subdir>/<target_number>/`` exists and returns
    ``target_number`` (string form, matches column type). Missing
    directory → ``None``; the ref points at a number the canonical
    store hasn't ingested yet (or that doesn't exist).

    Pure modulo the directory-exists check.
    """
    if ref_source not in _RESOLVABLE_SOURCES:
        return None
    subdir = _TARGET_KIND_TO_SUBDIR.get(target_kind)
    if subdir is None:
        return None
    target_dir = docs_root / subdir / target_number
    return target_number if target_dir.is_dir() else None


def _iter_artifact_dirs(
    docs_root: Path,
    subdir: str,
) -> Iterable[tuple[int, Path]]:
    """Yield ``(canonical_number, artifact_dir)`` for every numbered
    subdir under ``<docs_root>/<subdir>/``.

    Mirrors :func:`shadow.labels._iter_artifact_dirs`. Pure read-IO;
    sorted ascending so tests + log output stay stable.
    """
    base = docs_root / subdir
    if not base.is_dir():
        return
    entries: list[tuple[int, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        if not entry.name.isdigit():
            continue
        entries.append((int(entry.name), entry))
    entries.sort(key=lambda pair: pair[0])
    yield from entries


def _comment_files(artifact_dir: Path) -> list[Path]:
    """Return every comment file under ``<artifact_dir>/comments/``.

    Filters to ``*.md`` files sorted alphabetically so walker output is
    deterministic. Missing / non-directory ``comments/`` → empty list.

    Pure read-IO.
    """
    comments_dir = artifact_dir / "comments"
    if not comments_dir.is_dir():
        return []
    return sorted(
        path for path in comments_dir.iterdir()
        if path.is_file() and path.suffix == ".md"
    )


def _read_text(path: Path) -> str:
    """Read a UTF-8 text file; empty string on read failure.

    Walker treats unreadable files as "no refs" rather than raising —
    operator might have deleted the file mid-walk, a permission bit
    might be wrong, etc. The fact log captures the actual canonical
    state at walk time and the next walk picks up changes naturally.
    """
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _comment_source_id(parent_subdir: str, parent_id: int, comment: Path) -> str:
    """Compose the deterministic ``source_id`` for a comment-source ref.

    Shape: ``"<parent_subdir>/<parent_id>/comments/<filename>"`` —
    matches the canonical-store on-disk path so a query consumer can
    pivot from the row back to the file directly.

    Pure string composition.
    """
    return f"{parent_subdir}/{parent_id}/comments/{comment.name}"


def _emit_refs(
    conn,
    *,
    docs_root: Path,
    source_kind: str,
    source_id: str,
    ref_numbers: list[str],
    valid_from: str,
    recorded_at: str,
    source_event: str,
) -> int:
    """INSERT one fact row per ``(target_kind, ref_text)`` pair.

    Walks the kind table so a single ``#NNN`` mention emits one row per
    target_kind whose directory carries an artifact at that number — a
    bare ``#441`` ambiguously refers to issue / discussion / pull #441,
    and the resolver carries enough information to attribute each
    cleanly. When no kind resolves, the row still lands for
    ``target_kind = 'issue'`` (the dominant kind in this codebase) with
    ``target_id = NULL`` — the operator can still query for "what refs
    point at unknown numbers".

    Effect — issues one INSERT per emitted row. Returns the count of
    rows newly inserted (idempotency-hits don't count).
    """
    inserted = 0
    for number in ref_numbers:
        ref_text = f"#{number}"
        # Try to resolve target_id under each possible kind in turn.
        # Emit one row per kind whose directory matches; emit a single
        # NULL-target row for ``issue`` when nothing matches so the
        # mention is still represented in the fact log.
        matched = False
        for kind, _subdir in _KIND_DIRECTORIES:
            resolved = _resolve_target_id(
                docs_root, kind, number, LOCALSTORE,
            )
            if resolved is None:
                continue
            ok = insert_refs_fact(
                conn,
                source_kind=source_kind,
                source_id=source_id,
                target_kind=kind,
                target_id=resolved,
                ref_text=ref_text,
                ref_source=LOCALSTORE,
                valid_from=valid_from,
                recorded_at=recorded_at,
                source_event=source_event,
                recorded_by=None,
            )
            if ok:
                inserted += 1
            matched = True
        if not matched:
            # Unresolvable canonical ref — record with target_id=NULL
            # under the dominant kind so queries still surface the
            # mention. Kind defaults to ``issue`` per the convention
            # used across this codebase.
            ok = insert_refs_fact(
                conn,
                source_kind=source_kind,
                source_id=source_id,
                target_kind="issue",
                target_id=None,
                ref_text=ref_text,
                ref_source=LOCALSTORE,
                valid_from=valid_from,
                recorded_at=recorded_at,
                source_event=source_event,
                recorded_by=None,
            )
            if ok:
                inserted += 1
    return inserted


def _walk_kind(
    conn,
    docs_root: Path,
    project_root: Path | None,
    source_kind: str,
    subdir: str,
    now_iso: str,
) -> int:
    """Walk one ``kind`` subtree and emit ref fact rows.

    For each artifact:

    * Parse ``body.md`` for ``#NNN`` refs → ``source_kind`` row per
      ref.
    * Parse every ``comments/*.md`` for ``#NNN`` refs →
      ``source_kind='comment'`` row per ref. ``source_id`` encodes the
      parent artifact + comment filename so the row is uniquely
      identifiable.

    Returns the count of fact rows newly INSERTed.

    Effect — INSERT side via :func:`insert_refs_fact`.
    """
    inserted = 0
    rebuild_event = f"walker_rebuild_{now_iso}"
    for canonical_id, artifact_dir in _iter_artifact_dirs(docs_root, subdir):
        body_path = artifact_dir / "body.md"
        body_text = _read_text(body_path)
        body_refs = _parse_ref_numbers(body_text)
        if body_refs:
            valid_from = _resolve_valid_from(body_path, project_root)
            inserted += _emit_refs(
                conn,
                docs_root=docs_root,
                source_kind=source_kind,
                source_id=str(canonical_id),
                ref_numbers=body_refs,
                valid_from=valid_from,
                recorded_at=now_iso,
                source_event=f"{rebuild_event}_body",
            )

        for comment_path in _comment_files(artifact_dir):
            comment_text = _read_text(comment_path)
            comment_refs = _parse_ref_numbers(comment_text)
            if not comment_refs:
                continue
            valid_from = _resolve_valid_from(comment_path, project_root)
            source_id = _comment_source_id(
                subdir, canonical_id, comment_path,
            )
            inserted += _emit_refs(
                conn,
                docs_root=docs_root,
                source_kind="comment",
                source_id=source_id,
                ref_numbers=comment_refs,
                valid_from=valid_from,
                recorded_at=now_iso,
                source_event=(
                    f"{rebuild_event}_comment_{comment_path.name}"
                ),
            )
    return inserted


def walk_refs(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``refs_facts`` from canonical.

    Called by :func:`shadow.migration.rebuild_derivable_tables` (drift
    rebuild path) and :func:`daemon.action_log.refresh_shadow_for_op`
    (per-op refresh path) with a context dict carrying the docs root +
    project root.

    Args:
        conn: sqlite3 connection (must have ``refs_facts`` + the
            ``refs_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"docs_root"`` — :class:`Path` to the canonical store.
              Required; ``None``/missing → zero rows.
            * ``"project_root"`` — :class:`Path` to the project's git
              working tree, used for the OQ12 pre-3.0 backfill via
              :func:`shadow.git_log.file_introduction_timestamp`.
              Optional.

    Returns:
        Total fact rows INSERTed across all three kinds + comments.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    docs_root = ctx.get("docs_root")
    if docs_root is None:
        return 0
    if not isinstance(docs_root, Path):
        docs_root = Path(docs_root)
    project_root = ctx.get("project_root")
    if project_root is not None and not isinstance(project_root, Path):
        project_root = Path(project_root)
    now_iso = _iso_now()
    total = 0
    for source_kind, subdir in _KIND_DIRECTORIES:
        total += _walk_kind(
            conn, docs_root, project_root, source_kind, subdir, now_iso,
        )
    return total


def register() -> None:
    """Register ``refs_facts`` with the shadow registry + per-op map.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract. Called by
    :func:`shadow.register_all` at daemon startup.

    Per-op refresh wiring: every canonical op that mutates body.md or
    comment content re-derives ``refs_facts`` for the affected
    artifact. The walker reads the full canonical store, so this is
    conservative — any op that COULD change ref content registers.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_refs,
    )
    for op_name in (
        "create_issue",
        "update_issue_body",
        "create_discussion",
        "update_discussion_body",
        "create_pull",
        "post_turn",
        "create_thread",
        "add_comment",
        "edit_comment",
    ):
        register_op_refresh(op_name, (TABLE_NAME,))

