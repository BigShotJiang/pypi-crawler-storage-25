"""Bitemporal sqlite shadow tables (Cluster A / 3.14.0 / Discussion #22).

The shadow package extends the 3.6.0 D4 sqlite layer with per-table
bitemporal shadow tables for the canonical-store shapes that benefit
from aggregate query. Per OQ1 + OQ2 closures the schema is per-table
and pure insert-only. Supersession (transaction time) and ``valid_to``
(valid time) are both derived from window functions in hand-written
``_current`` views (OQ3) rather than stored as mutable columns.

Framework PR (Issue #475) lands the infrastructure only — no shadow
tables are registered yet. Per-table PRs (Issues #476-#483) populate
the registry by calling :func:`shadow.registry.register_table` at
import time.

Module map:

* :mod:`shadow.core` — the ``_insert_bitemporal_row`` generic helper
  + ``IntegrityError``-as-success contract (OQ13).
* :mod:`shadow.types` — module-level constants for the ``ref_source``
  / ``body_source`` vocabulary (OQ11 + OQ12).
* :mod:`shadow.registry` — pure module-level registry where per-table
  shadow modules register DDL + classification + walker callable.
* :mod:`shadow.views` — the hand-written ``_current`` view DDL
  generator (per-table PRs call ``current_view_ddl`` at registration
  time to embed the view inside their own DDL tuple).
* :mod:`shadow.migration` — derivable-vs-stateful drop+rebuild
  dispatch (OQ7 refinement). Reads from the registry; preserves
  stateful tables across schema-version bumps.
* :mod:`shadow.git_log` — shared git-log helpers used by the future
  refs_facts (Issue #477) + code_complete_facts (Issue #478) walkers
  plus the OQ12 pre-3.0 backfill path every walker uses.

See :mod:`shadow.README.md` for the full design rationale + Discussion
#22 anchor.

Per-table registration (Issues #476+): each per-table module exposes a
:func:`register` callable. The framework invokes them from
:func:`register_all` so the daemon's startup path triggers
registration in one place — avoids forcing every leaf ``shadow_*``
py_library to carry a transitive dep on every per-table module.

Pure module — no IO at import time. ``register_all`` is the explicit
trigger.
"""
from __future__ import annotations


def register_all() -> None:
    """Register every per-table shadow module with the registry.

    Called by the daemon's HTTP startup (``daemon.http.make_app``) and
    the CLI ``shadow rebuild`` subcommand
    (``daemon.main._run_shadow_rebuild``) so the registry is populated
    before any route / dispatch call hits it.

    Idempotent: each ``<module>.register()`` overwrites the previous
    entry per :func:`shadow.registry.register_table`'s contract, so
    repeat calls (test setup, daemon restart) are safe.

    Late imports keep the per-table module dep out of the leaf
    ``shadow_*`` library closures (Test Dep-Graph Discipline #72) —
    ``shadow_core`` / ``shadow_types`` / ``shadow_views`` tests stay
    fast because they don't transitively pull every per-table module.
    """
    # (#476) Cluster A exemplar — labels_facts.
    from . import labels
    labels.register()
    # (#477) Cluster A Phase 3 — refs_facts.
    from . import refs
    refs.register()
    # (#478) Cluster A Phase 3 — code_complete_facts.
    from . import code_complete
    code_complete.register()
    # (#479) Cluster A Phase 3 — issues_native_ids_facts stub.
    from . import native_ids
    native_ids.register()
    # (#480) Cluster A Phase 4 — history_log_facts cross-cutting walker.
    from . import history_log
    history_log.register()
    # (#481) Cluster A Phase 5 — pending_writes_facts (Tier 2).
    from . import pending_writes
    pending_writes.register()
    # (#482) Cluster A Phase 5 — replication_state_facts (Tier 2).
    from . import replication_state
    replication_state.register()
    # (#483) Cluster A Phase 5 — findings_facts (Tier 2).
    from . import findings
    findings.register()
    # (#487) Cluster A Phase 5b — issues_facts (Tier 1 slot-in).
    from . import issues
    issues.register()
    # (Discussion #23 A.5 / OQ5 / 3.15.0) — per-push outcome ledger.
    # Replaces (alongside the retirement of) replication_state_facts
    # whose state-transition substrate goes away with the A.5 refactor.
    from . import replication_push
    replication_push.register()
