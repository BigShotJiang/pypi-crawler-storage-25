"""``code_complete_facts`` shadow table (Issue #478 / 3.14.0 Cluster A
Phase 3).

Bitemporal fact log of "Issue closed by commit" facts auto-extracted
from ``git log --grep``. Each row records that a specific commit's
message contains a close-keyword reference to an Issue (``closes #N`` /
``fixes #N`` / ``resolves #N`` / ``(#N)`` etc) — the canonical signal
that code-complete work landed for that Issue, disentangled from the
state-flip timestamp recorded when an operator runs
``close_issue_with_comment`` later.

Per Discussion #22 OQ5 closure: shipping this fact table lets the
``issue_code_complete_since`` view answer the question "when did this
Issue's implementation actually land?" without conflating it with
"when did somebody flip its state to closed?" — the distinction
matters for milestone burn-down reporting + cluster-progress
dashboards.

All rows carry an implicit ``ref_source = 'git_commit'`` semantic
because the commit message itself is canonical-by-construction (the
author wrote it against LocalStore Issue numbering). The shadow row
schema doesn't carry ``ref_source`` as a column because the entire
table's source is uniform — it's the column's value for every row.

Walker shape:

1. ``git log --grep='#[0-9]+'`` via
   :func:`shadow.git_log.commit_log_with_message_pattern`.
2. For each commit, parse the message for close-keyword patterns.
3. Emit one fact row per ``(commit_hash, issue_id, ref_pattern)``
   triple.
4. Each row's ``source_event`` is ``git_log_walk_<commit_hash>`` so
   the idempotency index dedupes re-walks against the same commit.

The ``issue_code_complete_since`` view aggregates per-issue to surface
the earliest ``valid_from`` (= earliest commit timestamp that closed
the issue via keyword reference). That earliest-timestamp is the
"code-complete since" answer.

Effect-then-interceptor split (Rule 2): subprocess invocation lives in
:mod:`shadow.git_log`; this module is pure parse + INSERT dispatch.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .core import _insert_bitemporal_row
from .git_log import commit_log_with_message_pattern
from .registry import register_op_refresh, register_table
from .types import DERIVABLE


TABLE_NAME: str = "code_complete_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/code_complete_facts`` endpoint + the registry lookup."""


_CODE_COMPLETE_COLUMNS: tuple[str, ...] = (
    "issue_id", "commit_hash", "ref_pattern", "commit_at",
)
"""Entity-identifier + state columns the typed wrapper binds
positionally. The framework columns (``valid_from``, ``recorded_at``,
``source_event``, ``recorded_by``) get appended inside
``_insert_bitemporal_row``."""


# Compiled once at import time — used per-commit-message by the walker.
_CLOSE_KEYWORD_PATTERN: re.Pattern[str] = re.compile(
    r"(?:(closes|closed|close|fixes|fixed|fix|resolves|resolved|resolve)"
    r"\s+#(\d+))|\(#(\d+)\)",
    re.IGNORECASE,
)
"""Compiled regex matching close-keyword Issue refs:

* ``closes|closed|close|fixes|fixed|fix|resolves|resolved|resolve``
  followed by whitespace + ``#NNN``.
* Parenthetical ``(#NNN)`` — the conventional commit-summary suffix
  used across this codebase.

Case-insensitive so ``Closes #441`` / ``CLOSES #441`` / ``closes #441``
all match. The walker uses ``finditer`` so a single commit message
yields one match per close-keyword reference (the idempotency index
dedupes the ``(commit_hash, issue_id, ref_pattern)`` triple on
re-walk).
"""


# Pattern passed to git log --grep. Matches any #NNN ref (the
# git-level filter is broad — the regex above narrows to close-keyword
# matches in Python so the filter stays simple + extensible).
_GIT_GREP_PATTERN: str = r"#[0-9]+"
"""``git log --grep=<pattern>`` filter. Matches any commit message
containing ``#`` followed by digits — overly inclusive on purpose so
the Python-side regex handles the close-keyword refinement
(adding/removing keywords doesn't require re-walking git history)."""


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS code_complete_facts (
      issue_id      INTEGER NOT NULL,
      commit_hash   TEXT NOT NULL,
      ref_pattern   TEXT NOT NULL,
      commit_at     TEXT NOT NULL,
      valid_from    TEXT NOT NULL,
      recorded_at   TEXT NOT NULL,
      source_event  TEXT NOT NULL,
      recorded_by   TEXT,
      PRIMARY KEY (issue_id, commit_hash, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_code_complete_idempotent "
    "ON code_complete_facts(issue_id, commit_hash, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_code_complete_issue "
    "ON code_complete_facts(issue_id, valid_from)",
    # The aggregate view answering "when did this issue's
    # implementation land?" — the per-issue earliest
    # ``valid_from`` is the code-complete-since answer.
    """
    CREATE VIEW IF NOT EXISTS issue_code_complete_since AS
    SELECT issue_id, MIN(valid_from) AS code_complete_since
    FROM code_complete_facts
    GROUP BY issue_id
    """,
)
"""DDL tuple registered with the shadow registry. Note this table
ships a custom aggregate view (``issue_code_complete_since``) rather
than the standard ``ROW_NUMBER`` window-function ``_current`` view —
the question consumers ask of this table is "when first?" not
"what's the latest?". The aggregate view is fine here because
``code_complete_facts`` is monotone-additive: once a commit landed
with ``Closes #441`` you can't un-land it. The OQ3 ``_current``
shape isn't needed."""


def insert_code_complete_fact(
    conn,
    *,
    issue_id: int,
    commit_hash: str,
    ref_pattern: str,
    commit_at: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the code-complete schema. Returns
    ``True`` on insert; ``False`` when the UNIQUE idempotency index
    hits (per OQ13 "already applied" contract).

    Args:
        conn: sqlite3 connection (must have ``code_complete_facts``
            table).
        issue_id: Canonical Issue number the commit references.
        commit_hash: The full commit SHA (40-char hex). Walker uses
            ``%H`` so we get the full SHA, not the short form.
        ref_pattern: Verbatim matched text from the commit message —
            e.g. ``"closes #441"`` or ``"(#441)"``. Keeps the original
            casing so query consumers can distinguish forms.
        commit_at: ISO-8601 commit-author timestamp. Equals
            ``valid_from`` for code-complete facts (the "in-the-world"
            timestamp is the commit).
        valid_from: Same as ``commit_at`` per the OQ5 contract —
            represented separately so the column shape matches every
            other shadow fact table.
        recorded_at: ISO-8601 timestamp the row was written.
        source_event: ``git_log_walk_<commit_hash>`` so re-walks hit
            the idempotency index.
        recorded_by: session_id, or ``None`` for walker fills.
    """
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_CODE_COMPLETE_COLUMNS,
        values=(issue_id, commit_hash, ref_pattern, commit_at),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in :mod:`shadow.labels` + :mod:`shadow.refs`
    so the recorded_at columns sort cleanly across tables.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _parse_close_refs(message: str) -> list[tuple[int, str]]:
    """Return ``(issue_id, verbatim_ref_pattern)`` tuples extracted from
    a commit message.

    Deduplicates on ``(issue_id, ref_pattern)`` — the same exact
    ``Closes #441`` mentioned twice in a single commit message
    collapses to one entry. Distinct patterns referencing the same
    issue (e.g. ``Closes #441`` and ``(#441)`` in one message) yield
    distinct entries because the ref_pattern column distinguishes them.

    Returns entries in encounter order so the walker emits rows
    deterministically.

    Pure regex walk — no IO.
    """
    seen: dict[tuple[int, str], None] = {}
    for match in _CLOSE_KEYWORD_PATTERN.finditer(message):
        # The regex has three capture groups: (keyword, NNN) for the
        # close-keyword form, or (None, None, NNN) for the (#NNN) form.
        keyword, kw_number, paren_number = match.groups()
        if kw_number is not None:
            issue_id = int(kw_number)
            verbatim = match.group(0)
        elif paren_number is not None:
            issue_id = int(paren_number)
            verbatim = match.group(0)
        else:  # pragma: no cover — DEFENSIVE: regex shape guarantees one group always matches
            continue
        seen.setdefault((issue_id, verbatim), None)
    return list(seen.keys())


def _iter_close_commits(
    project_root: Path,
) -> Iterable[tuple[str, str, list[tuple[int, str]]]]:
    """Yield ``(commit_hash, commit_at, close_refs)`` triples for every
    commit whose message contains a close-keyword Issue ref.

    Wraps :func:`shadow.git_log.commit_log_with_message_pattern` with
    the close-keyword filter applied in Python. Commits whose message
    matched the broad ``#NNN`` git-grep but carry no close-keyword
    refs (e.g. an Issue reference without ``closes``) get filtered out
    here — they don't belong in ``code_complete_facts``.

    Pure modulo the git subprocess inside
    :func:`commit_log_with_message_pattern`.
    """
    for commit_hash, commit_at, message in commit_log_with_message_pattern(
        project_root, _GIT_GREP_PATTERN,
    ):
        close_refs = _parse_close_refs(message)
        if close_refs:
            yield commit_hash, commit_at, close_refs


def _emit_commit_rows(
    conn,
    commit_hash: str,
    commit_at: str,
    close_refs: list[tuple[int, str]],
    now_iso: str,
) -> int:
    """INSERT one fact row per close-ref in a commit message.

    Returns the count of rows newly INSERTed.

    Effect — issues INSERTs via :func:`insert_code_complete_fact`.
    """
    inserted = 0
    source_event = f"git_log_walk_{commit_hash}"
    for issue_id, ref_pattern in close_refs:
        ok = insert_code_complete_fact(
            conn,
            issue_id=issue_id,
            commit_hash=commit_hash,
            ref_pattern=ref_pattern,
            commit_at=commit_at,
            valid_from=commit_at,
            recorded_at=now_iso,
            source_event=source_event,
            recorded_by=None,
        )
        if ok:
            inserted += 1
    return inserted


def walk_code_complete(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``code_complete_facts`` from
    git history.

    Args:
        conn: sqlite3 connection (must have ``code_complete_facts`` +
            the ``issue_code_complete_since`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"project_root"`` — :class:`Path` to the project's git
              working tree. Required; ``None``/missing → zero rows.
            * ``"docs_root"`` — accepted but ignored (this walker
              reads git, not canonical filesystem). Present so the
              dispatch layer can pass a uniform ctx shape across all
              walkers.

    Returns:
        Total fact rows INSERTed. Idempotency-hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    project_root = ctx.get("project_root")
    if project_root is None:
        return 0
    if not isinstance(project_root, Path):
        project_root = Path(project_root)
    now_iso = _iso_now()
    total = 0
    for commit_hash, commit_at, close_refs in _iter_close_commits(
        project_root,
    ):
        total += _emit_commit_rows(
            conn, commit_hash, commit_at, close_refs, now_iso,
        )
    return total


def register() -> None:
    """Register ``code_complete_facts`` with the shadow registry.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    Per-op refresh wiring: this table is git-driven, not canonical-
    op-driven, so the per-op map carries no entries. Refresh happens
    via the periodic walker invocation
    (:func:`shadow.migration.rebuild_derivable_tables` on schema-
    version drift, or an out-of-band ``shadow rebuild`` CLI). Future
    work could wire a ``post_commit`` hook here; out of scope for
    3.14.0.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_code_complete,
    )
    # No per-op refresh — git-driven, not canonical-op-driven.
