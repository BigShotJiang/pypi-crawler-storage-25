"""Derivable-vs-stateful shadow rebuild dispatch (OQ7 refinement).

Per Discussion #22 OQ7 closure: schema-version bumps trigger
drop+rebuild for ``derivable`` tables (all ``_facts`` tables + FTS5)
but preserve ``stateful`` tables (the existing ``action_log.events``
runtime alert history from 3.13.0 #454). Per-table classification
lives in :mod:`shadow.registry`.

This module exposes :func:`rebuild_derivable_tables` as the panic-
button rebuild path invoked by:

* The ``forge-manager-daemon shadow rebuild`` CLI subcommand
  (OQ7 path b).
* The ``ensure_schema``-driven rebuild path when user_version drift
  is detected (OQ7 path a — wiring lives in
  :mod:`forge_manager_mcp.daemon.action_log`).

Effect-then-interceptor split (Rule 2): the registry is the data
layer (pure module). This module is the effect — drops + creates +
calls walker functions against a real sqlite connection.

Injectable seam (Rule 10): the ``registry_module`` parameter defaults
to the real :mod:`shadow.registry` but tests inject fakes so per-test
registrations don't leak through the shared registry singleton.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def rebuild_derivable_tables(
    con: sqlite3.Connection,
    registry_module: Any = None,
    walker_context: dict[str, Any] | None = None,
) -> dict[str, int]:
    """Drop + re-create + walker-repopulate every registered
    ``derivable`` table.

    Stateful tables are preserved untouched. Returns a per-table row-
    count dict for diagnostics: ``{"labels_facts": 17, ...}``. Tables
    whose walker is ``None`` (stub tables per OQ14) are dropped +
    re-created but yield ``0`` rows.

    Args:
        con: The shadow's sqlite connection (typically the
            :func:`forge_manager_mcp.daemon.action_log.open_connection`
            handle).
        registry_module: Override the registry source — tests pass a
            stub module with ``derivable_tables`` / ``ddl_for`` /
            ``walker_for`` shims. ``None`` resolves to the real
            :mod:`shadow.registry`.
        walker_context: Per-table walker context (e.g.,
            ``{"docs_root": Path(...), "project_root": Path(...)}``).
            Walkers accept this dict as a single positional argument
            so the dispatch layer doesn't need to know each walker's
            signature. ``None`` is treated as an empty context (stub
            tables don't need it).

    Returns:
        Dict mapping each rebuilt table name to its post-rebuild row
        count. Stateful tables don't appear in the dict (the contract
        is "what got rebuilt").

    Effect — drops + recreates tables. Calls ``con.commit()`` once at
    the end so a partial rebuild aborts cleanly under transaction
    semantics.
    """
    # Late import keeps registry_module=None tests from accidentally
    # carrying the registry into the test's import closure when the
    # test never touches the real registry.
    if registry_module is None:
        from . import registry as registry_module  # noqa: PLW0127

    ctx = walker_context or {}
    counts: dict[str, int] = {}
    for table in registry_module.derivable_tables():
        # Drop the table; sqlite IF EXISTS makes this safe on a
        # fresh-schema run where the table was never created.
        con.execute(f"DROP TABLE IF EXISTS {table}")
        # Drop the matching _current view explicitly — sqlite views
        # tied to a dropped table become uncallable but linger in
        # sqlite_master until DROP VIEW.
        view_name = _view_name_for_table(table)
        con.execute(f"DROP VIEW IF EXISTS {view_name}")
        # Re-create via the registered DDL tuple.
        for stmt in registry_module.ddl_for(table):
            con.execute(stmt)
        # Walker repopulates. None signals stub table (per OQ14).
        walker = registry_module.walker_for(table)
        if walker is None:
            counts[table] = 0
            continue
        counts[table] = walker(con, ctx)
    con.commit()
    return counts


def _view_name_for_table(table_name: str) -> str:
    """Compute the ``_current`` view name a table's DDL registered.

    Convention mirrors :func:`shadow.views._view_name_for_table`:
    strip trailing ``_facts``, append ``_current``. Falls back to
    appending ``_current`` for tables that don't end in ``_facts``.

    Duplicated here (not imported from views.py) because the migration
    module shouldn't have a runtime dep on views.py — views.py is
    used at registration time, not at rebuild time. Splitting keeps
    the dep graph minimal.
    """
    if table_name.endswith("_facts"):
        stem = table_name[: -len("_facts")]
    else:
        stem = table_name
    return f"{stem}_current"
