"""``replication_push_facts`` shadow table (Discussion #23 A.5 / OQ5).

Per-push outcome ledger — one fact row per attempted push to a
mirror. Replaces (alongside the retirement of) the
``replication_state_facts`` table whose substrate (state-machine
transitions) goes away with the A.5 mirror-push refactor.

Each row records:

- The push attempt's adapter + canonical artifact identity
  (``canonical_kind`` + ``canonical_number``).
- Outcome: ``success`` boolean. On success, the mirror's per-mirror
  number when the adapter returned one. On failure, ``error_class``
  + ``error_message``.
- Timestamps via the bitemporal framework: ``valid_from``,
  ``recorded_at``, ``attempted_at`` (the wall-clock moment the
  attempt finished).

Queries powered by this table:

- **recent_failure_count per adapter** — the rich ``health`` object
  in ``GET /backends`` (OQ6) reads
  ``SELECT COUNT(*) FROM replication_push_facts_current WHERE
  adapter=? AND success=0 AND attempted_at > <window>``.
- **first-of-N consecutive failures alert** — A.5 OQ4 (c) needs a
  query that walks recent rows per-adapter to detect the threshold
  crossing.
- **per-artifact push history** — debugging "why is this Issue not
  on Codeberg" reads as a query for canonical_kind+canonical_number.
- **mirror-number resolution** — the runtime ``MirrorNumberMap``
  (commit ``052f4b8``) handles in-process lookup; this table is
  the persistence substrate (focused-session follow-up).

Both Tier 2 (operational signal) and DERIVABLE (every fact row is
re-derivable from the canonical history log + manager logs).
"""
from __future__ import annotations

from datetime import datetime, timezone

from .core import _insert_bitemporal_row
from .registry import register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "replication_push_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/replication_push_facts`` endpoint + the registry
lookup."""


_PUSH_COLUMNS: tuple[str, ...] = (
    "adapter", "canonical_kind", "canonical_number",
    "success", "mirror_number", "error_class", "error_message",
    "attempted_at",
)
"""Entity + outcome columns the typed wrapper binds positionally. The
framework columns (``valid_from``, ``recorded_at``, ``source_event``,
``recorded_by``) get appended inside ``_insert_bitemporal_row``."""


# Canonical-kind vocabulary — small + structural like the
# surface_set vocab. Future kinds extend deliberately.
VALID_CANONICAL_KINDS: frozenset[str] = frozenset({
    "issue", "discussion", "milestone", "comment",
    "release", "label",
})


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS replication_push_facts (
      adapter           TEXT NOT NULL,
      canonical_kind    TEXT NOT NULL,
      canonical_number  INTEGER NOT NULL,
      success           INTEGER NOT NULL,
      mirror_number     INTEGER,
      error_class       TEXT,
      error_message     TEXT,
      attempted_at      TEXT NOT NULL,
      valid_from        TEXT NOT NULL,
      recorded_at       TEXT NOT NULL,
      source_event      TEXT NOT NULL,
      recorded_by       TEXT,
      PRIMARY KEY (adapter, canonical_kind, canonical_number, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_repl_push_idempotent "
    "ON replication_push_facts(adapter, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_repl_push_adapter_success "
    "ON replication_push_facts(adapter, success, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_repl_push_artifact "
    "ON replication_push_facts(canonical_kind, canonical_number, "
    "valid_from)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=(
            "adapter", "canonical_kind", "canonical_number",
        ),
        select_columns=(
            "adapter", "canonical_kind", "canonical_number",
            "success", "mirror_number", "error_class", "error_message",
            "attempted_at",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. The
``replication_push_facts_current`` view returns the latest fact per
(adapter, canonical_kind, canonical_number) — useful for "did the
most recent push to <adapter> for <artifact> succeed?" queries.
History traversal walks the raw fact table."""


def insert_replication_push_fact(
    conn,
    *,
    adapter: str,
    canonical_kind: str,
    canonical_number: int,
    success: bool,
    mirror_number: int | None,
    error_class: str | None,
    error_message: str | None,
    attempted_at: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the push-outcome schema and
    forwards to the generic helper. Returns ``True`` on insert;
    ``False`` when the UNIQUE idempotency index hits.

    Validates:
    - ``canonical_kind`` against :data:`VALID_CANONICAL_KINDS` —
      typos raise ValueError before reaching sqlite.
    - On ``success=True``: ``error_class`` + ``error_message`` should
      be ``None`` (caller contract; not asserted here so out-of-band
      records can carry both for compound success-with-warnings).
    - On ``success=False``: ``mirror_number`` should be ``None``
      (no mirror number assigned when the push failed).
    """
    if canonical_kind not in VALID_CANONICAL_KINDS:
        raise ValueError(
            f"shadow.replication_push: canonical_kind {canonical_kind!r} "
            f"not in {sorted(VALID_CANONICAL_KINDS)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_PUSH_COLUMNS,
        values=(
            adapter, canonical_kind, canonical_number,
            1 if success else 0,
            mirror_number,
            error_class,
            error_message,
            attempted_at,
        ),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in sibling shadow modules so recorded_at
    columns sort cleanly across tables. Abstracted so tests can
    monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def emit_push_outcome(
    conn,
    *,
    adapter: str,
    canonical_kind: str,
    canonical_number: int,
    success: bool,
    mirror_number: int | None = None,
    error_class: str | None = None,
    error_message: str | None = None,
    source_event: str,
    recorded_by: str | None = None,
) -> bool:
    """Live-emit hook for the dispatch path's per-push call site.

    Called after every push attempt (success or failure) by the
    A.5 best-effort additive pusher. Composes the fact row from the
    attempt details + the current timestamp; both ``valid_from`` +
    ``attempted_at`` coincide at emit time.

    Graceful skip: returns ``False`` if the table isn't registered
    (daemon could be running pre-shadow-schema in some configs).
    The dispatch path stays healthy regardless of whether the
    shadow table is bootstrapped.

    Args:
        conn: sqlite3 connection.
        adapter: ``platform_id`` of the adapter the push targeted.
        canonical_kind: One of :data:`VALID_CANONICAL_KINDS`.
        canonical_number: The canonical-store-assigned number for
            the artifact.
        success: ``True`` if the mirror confirmed the write;
            ``False`` if the adapter raised.
        mirror_number: On success when the adapter returned a
            mirror-specific number (e.g., GitHub Issue number);
            otherwise ``None``.
        error_class: On failure, ``type(exc).__name__``; ``None``
            on success.
        error_message: On failure, ``str(exc)``; ``None`` on success.
        source_event: Op name that triggered the push (e.g.,
            ``"create_issue"``, ``"append_comment"``). Uniqueness
            within the per-adapter source_event index is the
            caller's contract — append a monotonic suffix when
            multiple pushes in the same dispatch share the op name.
        recorded_by: session_id, or ``None`` for daemon-internal
            fills.
    """
    now_iso = _iso_now()
    try:
        return insert_replication_push_fact(
            conn,
            adapter=adapter,
            canonical_kind=canonical_kind,
            canonical_number=canonical_number,
            success=success,
            mirror_number=mirror_number,
            error_class=error_class,
            error_message=error_message,
            attempted_at=now_iso,
            valid_from=now_iso,
            recorded_at=now_iso,
            source_event=source_event,
            recorded_by=recorded_by,
        )
    except Exception:
        # Pre-shadow-schema state — the table doesn't exist yet.
        # Live emit is best-effort; the dispatch path continues.
        return False


def register() -> None:
    """Register ``replication_push_facts`` with the shadow registry.

    Called from :func:`forge_manager_mcp.shadow.register_all` so the
    daemon's startup-time shadow-bootstrap chain ensures the schema.
    The DERIVABLE classification means
    :func:`shadow.migration.rebuild_derivable_tables` drops + rebuilds
    this table on each call — the underlying canonical history log
    is the source of truth.
    """
    register_table(
        name=TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
    )
