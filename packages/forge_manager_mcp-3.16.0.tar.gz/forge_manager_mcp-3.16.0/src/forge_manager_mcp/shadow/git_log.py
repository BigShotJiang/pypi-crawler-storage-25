"""Shared git-log helpers for shadow walkers (OQ12 backfill + Issues
#477 / #478).

Per Discussion #22:

* OQ12 — pre-3.0 artifacts have no history-log entries. The walker
  reconstructs an approximate first-fact-row using
  ``git log --diff-filter=A --follow -- <file>`` to find the
  introduction-commit timestamp; tags those rows with
  ``body_source = pre_3_0_backfill`` for fidelity transparency.
* Issue #478 (``code_complete_facts``) — walker uses
  ``git log --grep='<close-keyword pattern>'`` to find every commit
  referencing an Issue via close keywords.
* Issue #477 (``refs_facts``) — same ``git log --grep`` infrastructure
  used by both feeds, factored once here.

Both helpers are pure subprocess wrappers — no sqlite imports, no
canonical-store filesystem knowledge. Callers (the per-table
walkers in Issues #477 / #478) compose them with whatever per-table
parsing they need.

Effect-then-interceptor split (Rule 2): subprocess.run is the effect;
parsing the output is pure. The helpers here are the effect side; the
per-table walkers consume the iterator and do their own parsing.
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Iterator


# Sentinel used to split commit-log records — vanishingly unlikely
# to appear in commit messages. Wraps every record with leading +
# trailing markers so trailing-newline whitespace doesn't trip the
# parser.
_RECORD_SEP = "\x1e"
"""ASCII Record Separator (0x1E). Used between commits in the
``--pretty=format`` template; lets the parser split commits even when
the messages contain newlines."""

_FIELD_SEP = "\x1f"
"""ASCII Unit Separator (0x1F). Used between hash / timestamp /
message inside a single commit record."""


def commit_log_with_message_pattern(
    project_root: Path,
    pattern: str,
) -> Iterator[tuple[str, str, str]]:
    """Yield ``(commit_hash, commit_at_iso, full_message)`` for every
    commit whose message matches the given regex pattern.

    Wraps ``git log --grep=<pattern> --extended-regexp`` with a
    custom pretty-format that emits hash + author-date + full body
    separated by ASCII unit separators. The author-date is ISO-8601
    (``%aI``) so it round-trips into bitemporal ``valid_from`` /
    ``recorded_at`` columns without re-parsing.

    Args:
        project_root: Directory where ``git`` runs — typically the
            project's git working tree.
        pattern: Extended-regexp passed to ``git log --grep``.
            Callers escape their own metacharacters; the helper
            doesn't sanitize.

    Yields:
        ``(commit_hash, commit_at_iso, full_message)`` triples in
        ``git log`` order (newest first by default). ``full_message``
        retains the commit's body including newlines so the per-table
        walker can do its own ref extraction.

    Effect — invokes ``git`` as a subprocess. Returns an empty
    iterator when:

    * The directory isn't a git repo (``git log`` exits non-zero;
      stderr is swallowed).
    * No commits match the pattern (empty stdout).

    Errors that produce empty output rather than raising — keeps the
    walker tolerant of edge cases (fresh checkout, shallow clone,
    operator-managed projects without git history).
    """
    pretty = (
        f"--pretty=format:%H{_FIELD_SEP}%aI{_FIELD_SEP}%B{_RECORD_SEP}"
    )
    try:
        result = subprocess.run(
            [
                "git", "log", f"--grep={pattern}", "--extended-regexp",
                pretty,
            ],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        # git binary unavailable — return empty iterator. Walker
        # treats this as "no commits", same as the no-match case.
        return
    if result.returncode != 0:
        return
    raw = result.stdout
    if not raw.strip():
        return
    # Split on record separator; drop the trailing empty entry from
    # the format template's trailing _RECORD_SEP.
    for record in raw.split(_RECORD_SEP):
        record = record.strip("\n")
        if not record:
            continue
        parts = record.split(_FIELD_SEP, 2)
        if len(parts) != 3:
            # Malformed record — skip rather than raise. Robustness
            # against weird commits.
            continue
        commit_hash, commit_at, message = parts
        yield commit_hash, commit_at, message


def file_introduction_timestamp(
    project_root: Path,
    file_path: Path,
) -> str | None:
    """Return the ISO-8601 timestamp of the commit that introduced
    ``file_path``, following renames, or ``None`` when no commit
    history is available.

    Wraps ``git log --diff-filter=A --follow --format=%aI -1 -- <file>``
    per OQ12 closure. The ``--diff-filter=A`` clause keeps only
    additions; ``--follow`` traces renames so files moved between
    paths still report their original introduction date.

    Args:
        project_root: Directory where ``git`` runs.
        file_path: Path to query. Can be absolute or project-relative;
            git accepts either when passed via the ``-- <file>``
            separator.

    Returns:
        ISO-8601 timestamp string (e.g. ``"2026-05-14T10:23:00-07:00"``)
        when git finds an introducing commit. ``None`` when:

        * The path isn't tracked by git (operator just created it).
        * git is unavailable (FileNotFoundError on subprocess).
        * git returns non-zero (corrupt repo, etc.).

    Effect — invokes git as a subprocess.
    """
    try:
        result = subprocess.run(
            [
                "git", "log", "--diff-filter=A", "--follow",
                "--format=%aI", "-1", "--", str(file_path),
            ],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    stdout = result.stdout.strip()
    return stdout if stdout else None
