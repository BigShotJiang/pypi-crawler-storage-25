"""``pending_writes_facts`` shadow table (Issue #481 / 3.14.0 Cluster A
Phase 5 — Tier 2 operational signal).

Bitemporal fact log of the ``.claude/pending-posts.md`` buffer plus
its drain attempts. Each enqueue lands one fact row with
``status='enqueued'``; each drain attempt lands another fact row
(``status='drained'`` for success, ``status='failed'`` for retry-
class failures). The ``pending_writes_current`` view exposes the
latest fact per ``(op_name, target_kind, target_id)`` partition so
queries can answer "what's still stuck" without re-scanning the
canonical buffer.

Per Discussion #22 OQ2 closure: enqueue + drain are modeled as
separate fact rows (no special-case columns). Per OQ13 closure: the
UNIQUE idempotency index combines
``(op_name, target_kind, target_id, source_event)`` so re-walks of
the same buffer file land idempotently while drain events from a
distinct ``source_event`` (the replay run ID) are recorded as fresh
facts.

Schema purpose:

* ``op_name`` — the MCP tool name (``"create_issue"`` /
  ``"post_turn"`` etc) — matches the buffer entry's ``Tool:`` field.
* ``target_kind`` + ``target_id`` — identify the artifact the op
  targeted. Derived from buffer-entry args (best-effort heuristic
  — sometimes the args don't carry an obvious target; walker tags
  ``target_kind='unknown'`` / ``target_id=''`` in that case so the
  PK + idempotency index still has stable values).
* ``error_class`` — ``"permanent"`` / ``"transient"`` per the
  :func:`is_permanent_error` predicate; ``NULL`` when the walker
  can't reconstruct an exception class from the buffer text
  (buffer stores the error as a string, not a Python exception).
* ``error_message`` — verbatim error string from the buffer.
* ``status`` — ``"enqueued"`` / ``"draining"`` / ``"drained"`` /
  ``"failed"`` — the lifecycle position for this fact row.
* ``retry_count`` — how many drain attempts have hit this row.
  Resets only when a fresh enqueue lands (a new entry in
  ``.claude/pending-posts.md`` with the same op + target).

Population paths:

* **Walker** — :func:`walk_pending_writes` parses
  ``<project_root>/.claude/pending-posts.md`` and emits one
  ``status='enqueued'`` fact row per buffer entry.
* **Live drain emit** — :func:`emit_drain_attempt` is called from
  the ``replay_pending`` MCP handler for each entry (one fact row
  with ``status='drained'`` on success / ``status='failed'`` on
  retry-class failure).

Effect-then-interceptor split (Rule 2): walker is pure read-effect
over the canonical buffer; live emits are the interceptor side that
``replay_pending`` invokes alongside its existing dispatch path.
Both INSERT side goes through :func:`insert_pending_writes_fact`.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .core import _insert_bitemporal_row
from .registry import register_op_refresh, register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "pending_writes_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/pending_writes_facts`` endpoint + the registry lookup."""


_PENDING_COLUMNS: tuple[str, ...] = (
    "op_name", "target_kind", "target_id",
    "error_class", "error_message", "status", "retry_count",
)
"""Entity + state columns the typed wrapper binds positionally. The
framework columns (``valid_from``, ``recorded_at``, ``source_event``,
``recorded_by``) get appended inside ``_insert_bitemporal_row``."""


# Status vocabulary — closed set per the Issue #481 schema.
STATUS_ENQUEUED: str = "enqueued"
STATUS_DRAINING: str = "draining"
STATUS_DRAINED: str = "drained"
STATUS_FAILED: str = "failed"
VALID_STATUSES: frozenset[str] = frozenset({
    STATUS_ENQUEUED, STATUS_DRAINING, STATUS_DRAINED, STATUS_FAILED,
})


ERROR_CLASS_PERMANENT: str = "permanent"
ERROR_CLASS_TRANSIENT: str = "transient"
VALID_ERROR_CLASSES: frozenset[str] = frozenset({
    ERROR_CLASS_PERMANENT, ERROR_CLASS_TRANSIENT,
})


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS pending_writes_facts (
      op_name        TEXT NOT NULL,
      target_kind    TEXT NOT NULL,
      target_id      TEXT NOT NULL,
      error_class    TEXT,
      error_message  TEXT,
      status         TEXT NOT NULL,
      retry_count    INTEGER NOT NULL DEFAULT 0,
      valid_from     TEXT NOT NULL,
      recorded_at    TEXT NOT NULL,
      source_event   TEXT NOT NULL,
      recorded_by    TEXT,
      PRIMARY KEY (op_name, target_kind, target_id, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_pending_idempotent "
    "ON pending_writes_facts(op_name, target_kind, target_id, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_pending_status "
    "ON pending_writes_facts(status, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_pending_error "
    "ON pending_writes_facts(error_class, status)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("op_name", "target_kind", "target_id"),
        select_columns=(
            "op_name", "target_kind", "target_id",
            "error_class", "error_message", "status", "retry_count",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``pending_writes_current`` view returns the latest
fact per partition — callers querying "stuck >24h" filter on
``status='enqueued' AND valid_from < date('now', '-1 day')``."""


def insert_pending_writes_fact(
    conn,
    *,
    op_name: str,
    target_kind: str,
    target_id: str,
    error_class: str | None,
    error_message: str | None,
    status: str,
    retry_count: int,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the pending-writes schema and
    forwards to the generic helper. Returns ``True`` on insert;
    ``False`` when the UNIQUE idempotency index hits (per OQ13
    "already applied" contract).

    Args:
        conn: sqlite3 connection (must have ``pending_writes_facts``
            table).
        op_name: MCP tool name from the buffer entry's ``Tool:``
            field.
        target_kind: Canonical-kind string for the target artifact.
            Walker derives best-effort from the args; ``'unknown'``
            when the args don't carry a discernible target.
        target_id: Stringified target identifier. Empty string when
            unknown — stays non-NULL so the PK partition is stable.
        error_class: One of :data:`ERROR_CLASS_PERMANENT` /
            :data:`ERROR_CLASS_TRANSIENT`, or ``None`` when the
            walker can't classify (buffer stores errors as strings,
            not Python exceptions — only the live-emit path receives
            a real exception to classify).
        error_message: Verbatim error string. ``None`` when emitting
            a success-side drain fact.
        status: One of :data:`VALID_STATUSES`. Validated via
            :func:`ValueError` for typo protection — the closed
            vocabulary is the contract.
        retry_count: How many drain attempts have hit this op +
            target. ``0`` for fresh enqueues; incremented by the
            live emit path on each subsequent drain attempt.
        valid_from: ISO-8601 UTC of when the fact became true in
            the world.
        recorded_at: ISO-8601 UTC of when this row was written.
        source_event: Walker-rebuild sentinel
            (``walker_rebuild_<iso>``) for enqueue facts; replay-run
            identifier (``replay_<iso>_<entry_index>``) for drain
            facts. The idempotency index includes this column so
            repeated dispatches collapse.
        recorded_by: session_id, or ``None`` for walker fills.
    """
    if status not in VALID_STATUSES:
        raise ValueError(
            f"shadow.pending_writes: status {status!r} not in "
            f"{sorted(VALID_STATUSES)}"
        )
    if error_class is not None and error_class not in VALID_ERROR_CLASSES:
        raise ValueError(
            f"shadow.pending_writes: error_class {error_class!r} not in "
            f"{sorted(VALID_ERROR_CLASSES)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_PENDING_COLUMNS,
        values=(
            op_name, target_kind, target_id,
            error_class, error_message, status, retry_count,
        ),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def classify_error_string(error_message: str | None) -> str | None:
    """Heuristic classification of a buffered error string.

    The buffer stores errors as their ``str()`` form — by the time the
    walker reads them, the original Python exception class is lost.
    This helper inspects the message for substring markers that
    correlate with the :func:`is_permanent_error` predicate's
    classified-permanent set:

    * ``"InvalidArtifactRefError"`` / ``"ConsentRequiredError"`` /
      ``"InvalidNodeIdError"`` / ``"ClassificationError"`` /
      ``"ValueError"`` — class names that may appear in the
      pre-formatted error string.
    * Caller-fault HTTP statuses (400 / 404 / 405 / 409 / 422) —
      ``ForgeError`` ``__str__`` doesn't include the status code by
      default, but :class:`adapters.errors.ForgeError` carriers that
      bubble through the dispatch wrapper carry a substring like
      ``"HTTP 404"`` per the write-handler's error-formatting path.

    Returns :data:`ERROR_CLASS_PERMANENT` on match,
    :data:`ERROR_CLASS_TRANSIENT` otherwise (including when the
    string doesn't match any known permanent marker). Returns
    ``None`` when the input is ``None`` / empty — the walker treats
    that as "no error classification available".

    Pure string-inspection. The live-emit path
    (:func:`classify_live_exception`) is the authoritative classifier;
    this helper is the walker-only fallback for entries that predate
    the live-emit wiring.
    """
    if not error_message:
        return None
    permanent_markers = (
        "InvalidArtifactRefError",
        "ConsentRequiredError",
        "InvalidNodeIdError",
        "ClassificationError",
        "ValueError",
        "HTTP 400",
        "HTTP 404",
        "HTTP 405",
        "HTTP 409",
        "HTTP 422",
    )
    for marker in permanent_markers:
        if marker in error_message:
            return ERROR_CLASS_PERMANENT
    return ERROR_CLASS_TRANSIENT


def classify_live_exception(exc: BaseException | None) -> str | None:
    """Classify a live Python exception for the live-emit drain path.

    Returns :data:`ERROR_CLASS_PERMANENT` when
    :func:`is_permanent_error` matches the exception, otherwise
    :data:`ERROR_CLASS_TRANSIENT`. Returns ``None`` when ``exc`` is
    ``None`` — the drain-success path passes ``None`` so the fact
    row has no error_class.

    Late import of :func:`is_permanent_error` keeps this module's
    runtime closure narrow (the walker doesn't need adapters/errors).
    """
    if exc is None:
        return None
    from forge_manager_mcp.adapters.errors import is_permanent_error
    return (
        ERROR_CLASS_PERMANENT if is_permanent_error(exc)
        else ERROR_CLASS_TRANSIENT
    )


def derive_target(op_name: str, args: dict[str, Any]) -> tuple[str, str]:
    """Best-effort ``(target_kind, target_id)`` extraction from buffered
    args.

    Heuristic — different tool surfaces use different arg shapes.
    The walker tries common keys in order and falls back to
    ``('unknown', '')`` so the PK partition is always populated.

    Recognized shapes:

    * ``{"ref_native_id": "..."}`` — direct artifact ref.
    * ``{"issue_number": N}`` / ``{"number": N}`` — issue target.
    * ``{"discussion_number": N}`` — discussion target.
    * ``{"thread_number": N}`` — thread target (post_turn).
    * ``{"session_id": "..."}`` — session target.
    * ``{"gap_id": "..."}`` — gap target.
    * ``{"milestone_version": "..."}`` / ``{"version": "..."}`` —
      milestone target.

    The ``target_kind`` is derived from the matching key's prefix
    (``"issue"`` / ``"discussion"`` / ``"thread"`` / etc); for the
    ref_native_id case ``target_kind`` falls to the op name's first
    word as a heuristic (``"create_issue"`` → ``"issue"``).

    Pure — operates on already-parsed JSON args.
    """
    if not isinstance(args, dict):
        return ("unknown", "")
    # Direct-target shapes (most specific first).
    if "issue_number" in args:
        return ("issue", str(args["issue_number"]))
    if "discussion_number" in args:
        return ("discussion", str(args["discussion_number"]))
    if "thread_number" in args:
        return ("thread", str(args["thread_number"]))
    if "session_id" in args:
        return ("session", str(args["session_id"]))
    if "gap_id" in args:
        return ("gap", str(args["gap_id"]))
    if "milestone_version" in args:
        return ("milestone", str(args["milestone_version"]))
    if "version" in args and op_name.startswith(("create_milestone", "close_milestone", "update_milestone")):
        return ("milestone", str(args["version"]))
    # ref_native_id is generic; pair with op-name heuristic for kind.
    if "ref_native_id" in args:
        kind = _kind_from_op_name(op_name)
        return (kind, str(args["ref_native_id"]))
    if "number" in args:
        kind = _kind_from_op_name(op_name)
        return (kind, str(args["number"]))
    return ("unknown", "")


def _kind_from_op_name(op_name: str) -> str:
    """Derive a target_kind heuristic from the op name's prefix.

    ``"create_issue"`` → ``"issue"``; ``"post_turn"`` → ``"thread"``
    (post_turn writes to a thread); ``"close_milestone"`` →
    ``"milestone"``. Returns ``"unknown"`` when no marker matches.

    Pure string-inspection.
    """
    markers = (
        ("issue", "issue"),
        ("discussion", "discussion"),
        ("thread", "thread"),
        ("session", "session"),
        ("gap", "gap"),
        ("milestone", "milestone"),
        ("turn", "thread"),
        ("comment", "issue"),
    )
    op_lower = op_name.lower()
    for marker, kind in markers:
        if marker in op_lower:
            return kind
    return "unknown"


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in sibling shadow modules so recorded_at
    columns sort cleanly across tables. Abstracted so tests can
    monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _walker_rebuild_event(now_iso: str) -> str:
    """Compose the ``walker_rebuild_<iso8601>`` source-event sentinel.

    Mirrors :func:`shadow.labels._walker_rebuild_event`. Pure string
    composition.
    """
    return f"walker_rebuild_{now_iso}"


def _retry_count_for_entry(
    conn,
    *,
    op_name: str,
    target_kind: str,
    target_id: str,
) -> int:
    """Look up how many drain attempts have hit this op + target.

    Counts rows with ``status IN (draining, drained, failed)`` for the
    given partition. Returns 0 for fresh entries (no drain history).

    Effect — issues one SELECT against the connection.
    """
    cur = conn.execute(
        "SELECT COUNT(*) FROM pending_writes_facts "
        "WHERE op_name = ? AND target_kind = ? AND target_id = ? "
        "AND status IN ('draining', 'drained', 'failed')",
        (op_name, target_kind, target_id),
    )
    row = cur.fetchone()
    return int(row[0]) if row else 0


def emit_enqueue_fact(
    conn,
    *,
    op_name: str,
    args: dict[str, Any],
    error_message: str,
    valid_from: str,
    source_event: str,
    recorded_by: str | None = None,
) -> bool:
    """Live-emit hook for the buffer-write path.

    Called from :func:`forge_manager_mcp.buffer.write_pending` (via
    the daemon's per-op refresh dispatch) when a fresh entry lands in
    ``.claude/pending-posts.md``. Composes the
    ``(target_kind, target_id, error_class)`` triple via the
    walker's helpers + inserts one ``status='enqueued'`` fact row.

    Graceful skip: if the table isn't registered (daemon running
    pre-shadow-schema), returns ``False`` without raising. The
    write-pending path stays functional even when the shadow
    framework hasn't bootstrapped.
    """
    target_kind, target_id = derive_target(op_name, args)
    error_class = classify_error_string(error_message)
    try:
        return insert_pending_writes_fact(
            conn,
            op_name=op_name,
            target_kind=target_kind,
            target_id=target_id,
            error_class=error_class,
            error_message=error_message,
            status=STATUS_ENQUEUED,
            retry_count=0,
            valid_from=valid_from,
            recorded_at=_iso_now(),
            source_event=source_event,
            recorded_by=recorded_by,
        )
    except Exception:  # noqa: BLE001 — graceful skip when table absent
        return False


def emit_drain_attempt(
    conn,
    *,
    op_name: str,
    args: dict[str, Any],
    success: bool,
    error: BaseException | None,
    valid_from: str,
    source_event: str,
    recorded_by: str | None = None,
) -> bool:
    """Live-emit hook for the replay-pending drain path.

    Called from :func:`server.handlers.infra.replay_pending` for each
    buffer entry after the replay attempt completes. Composes the
    ``(target_kind, target_id, error_class, status)`` tuple + emits
    one fact row reflecting the drain outcome.

    Status mapping:

    * ``success=True`` → :data:`STATUS_DRAINED`, error_class None.
    * ``success=False`` and ``error`` permanent → :data:`STATUS_FAILED`.
    * ``success=False`` and ``error`` transient → :data:`STATUS_FAILED`
      (still tracked so the retry_count progresses; transient retries
      re-buffer naturally via the dispatch path).

    ``retry_count`` is looked up from existing rows so each drain
    attempt advances the counter — supports the "stuck after N
    retries" query shape.

    Graceful skip: returns ``False`` if the table isn't registered.
    """
    target_kind, target_id = derive_target(op_name, args)
    if success:
        status = STATUS_DRAINED
        error_class = None
        error_message = None
    else:
        status = STATUS_FAILED
        error_class = classify_live_exception(error)
        error_message = str(error) if error is not None else None
    try:
        retry_count = _retry_count_for_entry(
            conn,
            op_name=op_name,
            target_kind=target_kind,
            target_id=target_id,
        ) + 1
    except Exception:  # noqa: BLE001 — table absent; skip the retry lookup
        return False
    try:
        return insert_pending_writes_fact(
            conn,
            op_name=op_name,
            target_kind=target_kind,
            target_id=target_id,
            error_class=error_class,
            error_message=error_message,
            status=status,
            retry_count=retry_count,
            valid_from=valid_from,
            recorded_at=_iso_now(),
            source_event=source_event,
            recorded_by=recorded_by,
        )
    except Exception:  # noqa: BLE001 — graceful skip when table absent
        return False


def walk_pending_writes(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``pending_writes_facts`` from
    canonical.

    Reads ``<project_root>/.claude/pending-posts.md`` (or
    ``<docs_root>/.claude/pending-posts.md`` as fallback when the
    project_root isn't supplied) and emits one ``status='enqueued'``
    fact row per buffer entry. Drain history is not re-derived by
    the walker — only the live-emit drain path produces drain facts.

    Args:
        conn: sqlite3 connection (must have ``pending_writes_facts``
            table + the ``pending_writes_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"project_root"`` — :class:`Path` to the project root
              (where ``.claude/`` lives). Preferred; the buffer file
              path is ``<project_root>/.claude/pending-posts.md``.
            * ``"docs_root"`` — :class:`Path`; accepted as fallback
              when ``project_root`` is absent (the docs repo
              sometimes carries its own ``.claude/`` in pre-3.0
              layouts).

    Returns:
        Total fact rows newly INSERTed. Idempotency-hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    project_root = ctx.get("project_root")
    if project_root is None:
        project_root = ctx.get("docs_root")
    if project_root is None:
        return 0
    if not isinstance(project_root, Path):
        project_root = Path(project_root)
    buffer_path = project_root / ".claude" / "pending-posts.md"
    if not buffer_path.exists():
        return 0
    # Late-import the buffer reader to keep this module's runtime
    # closure narrow (tests on walk logic don't need the buffer
    # module's IO unless they exercise this code path).
    from forge_manager_mcp.buffer import read_pending
    try:
        entries = read_pending(project_root)
    except Exception:  # noqa: BLE001 — corrupted buffer; skip cleanly
        return 0
    now_iso = _iso_now()
    rebuild_event = _walker_rebuild_event(now_iso)
    inserted = 0
    for idx, entry in enumerate(entries):
        op_name = entry.get("tool", "") or "unknown"
        args = entry.get("args", {}) or {}
        error_message = entry.get("error", "") or ""
        timestamp = entry.get("timestamp", "") or now_iso
        target_kind, target_id = derive_target(op_name, args)
        error_class = classify_error_string(error_message)
        # source_event embeds the entry's timestamp + index so
        # multiple entries for the same op+target in one walk hit
        # distinct UNIQUE-index rows.
        source_event = f"{rebuild_event}_entry_{idx}_{timestamp}"
        ok = insert_pending_writes_fact(
            conn,
            op_name=op_name,
            target_kind=target_kind,
            target_id=target_id,
            error_class=error_class,
            error_message=error_message,
            status=STATUS_ENQUEUED,
            retry_count=0,
            valid_from=timestamp,
            recorded_at=now_iso,
            source_event=source_event,
            recorded_by=None,
        )
        if ok:
            inserted += 1
    return inserted


def register() -> None:
    """Register ``pending_writes_facts`` with the shadow registry +
    per-op map.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    Per-op refresh wiring: the ``replay_pending_writes`` op (the
    daemon-side drain orchestrator) is the canonical trigger; the
    walker re-derives the enqueue facts from the buffer file on
    every dispatch so a drain that completed mid-fan-out leaves the
    shadow consistent.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_pending_writes,
    )
    # Per-op refresh: any op that mutates the pending buffer
    # re-triggers the walker. The replay path also emits drain
    # facts live via emit_drain_attempt — the walker complements it
    # by ingesting the current enqueue state.
    for op_name in (
        "replay_pending",
        "replay_pending_writes",
    ):
        register_op_refresh(op_name, (TABLE_NAME,))
