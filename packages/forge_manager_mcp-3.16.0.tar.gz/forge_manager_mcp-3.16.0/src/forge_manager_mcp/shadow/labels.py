"""``labels_facts`` shadow table (Issue #476 / 3.14.0 Cluster A exemplar).

Bitemporal fact log of label presence on canonical artifacts (Issues /
Discussions / Pulls). Each ``(issue_id, kind, label)`` triple gets a
fact row per state transition — ``present=1`` for adds, ``present=0``
for removes. The latest fact per key surfaces via the
``labels_current`` view (OQ3 ``ROW_NUMBER()`` partition).

Per Discussion #22 + Issue #476 scope:

* Walks ``<docs>/<kind>/<n>/labels.txt`` — one label per line.
* ``valid_from`` derives from each artifact's ``history/<ts>.json``
  entries when present; falls back to git introduction-commit
  timestamp via :func:`shadow.git_log.file_introduction_timestamp`
  for pre-3.0 artifacts (OQ12).
* ``source_event`` is the ``history/<ts>.json`` filename for
  history-derived facts, or ``walker_rebuild_<iso8601>`` sentinel
  for the initial walk on a fresh shadow.
* ``recorded_by`` is ``None`` for walker fills (walker is not a
  session).
* Idempotent: rerunning the walker against the same canonical store
  hits the UNIQUE ``(issue_id, kind, label, source_event)`` index
  and returns ``False`` from the underlying insert helper; no
  duplicate rows.

The ``add then remove`` semantics map to two distinct fact rows
because the second walk's ``source_event`` is the remove-op's
``history/<ts>.json`` filename — different from the add. A
re-add later writes a third row.

``labels_facts`` does NOT carry ``body_source`` or ``ref_source``:
labels are metadata, not artifact content, so the vocabulary
distinction (OQ11) doesn't apply.

Effect-then-interceptor split (Rule 2): the walker is pure read-
effect over the canonical filesystem; the INSERT is the effect side
performed by :func:`insert_labels_fact` against a caller-supplied
connection.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .core import _insert_bitemporal_row
from .git_log import file_introduction_timestamp
from .registry import register_op_refresh, register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "labels_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/labels_facts`` endpoint + the registry lookup."""


_LABEL_COLUMNS: tuple[str, ...] = ("issue_id", "kind", "label", "present")
"""Entity-identifier + state columns the walker binds positionally.
The bitemporal framework columns (``valid_from``, ``recorded_at``,
``source_event``, ``recorded_by``) are appended inside
``_insert_bitemporal_row``."""


_KIND_DIRECTORIES: tuple[tuple[str, str], ...] = (
    ("issue", "issues"),
    ("discussion", "discussions"),
    ("pull", "pulls"),
)
"""Mapping from canonical ``kind`` value to the docs-root subdir the
walker scans. Order is deterministic so test assertions stay stable.
``kind`` is what lands in the fact row's ``kind`` column; the second
tuple element is the docs subdir name."""


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS labels_facts (
      issue_id     INTEGER NOT NULL,
      kind         TEXT NOT NULL,
      label        TEXT NOT NULL,
      present      INTEGER NOT NULL,
      valid_from   TEXT NOT NULL,
      recorded_at  TEXT NOT NULL,
      source_event TEXT NOT NULL,
      recorded_by  TEXT,
      PRIMARY KEY (issue_id, kind, label, recorded_at)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_labels_present "
    "ON labels_facts(label, present, recorded_at)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_labels_idempotent "
    "ON labels_facts(issue_id, kind, label, source_event)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("issue_id", "kind", "label"),
        select_columns=(
            "issue_id", "kind", "label", "present",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``labels_current`` view filters
``WHERE rn = 1 AND present = 1`` indirectly — the view returns the
latest fact per key; callers wanting only currently-present labels
filter on ``present = 1`` post-view (the view itself keeps all latest
rows including removes so query consumers can see the
``most-recently removed`` state too)."""


def insert_labels_fact(
    conn,
    *,
    issue_id: int,
    kind: str,
    label: str,
    present: bool,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the labels-facts schema and forwards
    to the generic helper. Returns ``True`` on insert; ``False`` when
    the UNIQUE idempotency index hits (per OQ13 "already applied"
    contract).

    Args:
        conn: sqlite3 connection (must have ``labels_facts`` table).
        issue_id: Canonical LocalStore number of the artifact.
        kind: One of ``'issue'``, ``'discussion'``, ``'pull'``.
        label: The label string (matches one line of labels.txt).
        present: ``True`` for an add-fact (``present=1``); ``False``
            for a remove-fact (``present=0``). Maps to sqlite INTEGER
            ``1`` / ``0``.
        valid_from: ISO-8601 timestamp of when the fact became true
            in the world.
        recorded_at: ISO-8601 timestamp of when this row was written.
        source_event: ``history/<ts>.json`` filename, op name, or
            ``walker_rebuild_<iso8601>`` sentinel — combined with the
            PK in the idempotency index.
        recorded_by: session_id, or ``None`` for walker fills.
    """
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_LABEL_COLUMNS,
        values=(issue_id, kind, label, 1 if present else 0),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def _read_labels_file(labels_path: Path) -> list[str]:
    """Read ``labels.txt`` and return a deduped list of label strings.

    One label per line; blank lines and surrounding whitespace are
    skipped. Returns an empty list when the file is absent or
    unreadable — the walker treats both cases as "no labels currently
    present" so removes get detected correctly.

    Pure read-IO; deduplicates via insertion-order-preserving dict.
    """
    try:
        raw = labels_path.read_text(encoding="utf-8")
    except OSError:
        return []
    seen: dict[str, None] = {}
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        seen.setdefault(stripped, None)
    return list(seen.keys())


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Microsecond precision matters for the PRIMARY KEY
    ``(issue_id, kind, label, recorded_at)`` shape: back-to-back walks
    (add then immediate remove in the same second) would otherwise
    collide on PK and silently dedup the second row. Microseconds
    push the resolution below typical walker timing so subsequent
    walks land distinct fact rows.

    Pure modulo the system clock — abstracted so tests can monkey-patch
    in deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _walker_rebuild_event(now_iso: str) -> str:
    """Compose the ``walker_rebuild_<iso8601>`` source-event sentinel.

    Pure string composition. The timestamp lives in the event name so
    re-walking on a different clock tick produces a distinct
    source_event — re-walking the same canonical state under the same
    sentinel hits the idempotency index and returns False (success).
    """
    return f"walker_rebuild_{now_iso}"


def _file_mtime_iso(path: Path) -> str | None:
    """Return the file's mtime as ISO-8601 UTC, or None when unreadable.

    Used as the second-tier ``valid_from`` source after history-derived
    timestamps. Falls back to git's introduction-commit timestamp via
    :func:`file_introduction_timestamp` when this returns None.
    """
    try:
        ts = path.stat().st_mtime
    except OSError:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ",
    )


def _label_add_ops_from_history(history_dir: Path) -> dict[str, str]:
    """Return a ``{label: history_filename}`` map of add-ops per label.

    Walks ``<artifact>/history/<ts>.json`` entries; for any entry whose
    ``operation`` is a label-add op carrying a ``label`` field,
    associates the label with the entry filename. Later entries win on
    duplicate labels (chronological filename sort places newest last) —
    the walker uses each entry's filename as its ``source_event`` so
    the idempotency index still distinguishes them; the map is only
    used to attribute ``valid_from`` to the latest add per label.

    Tolerates malformed JSON / missing fields by skipping the entry
    silently. Empty / missing history dir → empty dict.

    Pure read-IO.
    """
    out: dict[str, str] = {}
    if not history_dir.is_dir():
        return out
    for entry in sorted(history_dir.iterdir()):
        if entry.suffix != ".json":
            continue
        try:
            payload = json.loads(entry.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        op = payload.get("operation")
        # Accept the canonical-store label-add variants. The
        # canonical history-log shape (#270) uses these op names;
        # walker accepts any of them to stay tolerant of vocabulary
        # drift.
        if op not in {"add_label", "label_add", "labels_add"}:
            continue
        label = payload.get("label") or payload.get("name")
        if not isinstance(label, str) or not label:
            continue
        ts = payload.get("timestamp") or entry.stem
        # The history filename itself is the canonical source_event
        # identifier; the parsed timestamp is for valid_from only.
        out[label] = ts if isinstance(ts, str) else entry.stem
    return out


def _valid_from_for_label(
    label: str,
    history_map: dict[str, str],
    labels_path: Path,
    project_root: Path | None,
) -> str:
    """Resolve a ``valid_from`` timestamp for a currently-present label.

    Resolution order:

    1. The history-log add-op timestamp for the label (when present).
    2. ``labels.txt``'s mtime (post-3.0 file existed before the
       history log entry — rare; happens when label was added before
       the history walker's coverage).
    3. The git introduction-commit timestamp of ``labels.txt`` via
       :func:`file_introduction_timestamp` — the OQ12 pre-3.0
       backfill fallback.
    4. Final fallback: a sentinel of ``1970-01-01T00:00:00Z`` so the
       INSERT never NULL-fails the ``NOT NULL`` constraint.
       Operator-visible only when the file isn't tracked by git AND
       has no readable mtime — rare edge case.

    Pure modulo the IO inside :func:`file_introduction_timestamp`
    and ``stat()``.
    """
    if label in history_map:
        return history_map[label]
    mtime_iso = _file_mtime_iso(labels_path)
    if mtime_iso is not None:
        return mtime_iso
    if project_root is not None:
        git_ts = file_introduction_timestamp(project_root, labels_path)
        if git_ts is not None:
            return git_ts
    return "1970-01-01T00:00:00Z"


def _existing_present_labels(
    conn,
    issue_id: int,
    kind: str,
) -> set[str]:
    """Return the set of labels currently flagged ``present=1`` for an
    artifact per the latest fact row.

    Queries the ``labels_current`` view (which exposes the latest fact
    per key via the OQ3 ``ROW_NUMBER()`` partition) and filters on
    ``present = 1``. Used by the walker to detect removed labels
    (labels in this set but absent from labels.txt → emit a
    ``present=0`` fact row).

    Effect — issues one SELECT. Returns empty set when the view is
    empty (fresh schema).
    """
    cur = conn.execute(
        "SELECT label FROM labels_current "
        "WHERE issue_id = ? AND kind = ? AND present = 1",
        (issue_id, kind),
    )
    return {row[0] for row in cur.fetchall()}


def _iter_artifact_dirs(
    docs_root: Path,
    subdir: str,
) -> Iterable[tuple[int, Path]]:
    """Yield ``(issue_id, artifact_dir)`` for every numbered subdir
    under ``<docs_root>/<subdir>/``.

    Mirrors :func:`daemon.canonical_walker._is_numbered_dir` filtering
    — directories whose name isn't a positive integer are skipped
    (operator README.md, .gitignore, etc.).

    Pure read-IO; sorted by numeric id for deterministic walker
    ordering (test assertions + log readability).
    """
    base = docs_root / subdir
    if not base.is_dir():
        return
    entries: list[tuple[int, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        if not entry.name.isdigit():
            continue
        entries.append((int(entry.name), entry))
    entries.sort(key=lambda pair: pair[0])
    yield from entries


def _walk_kind(
    conn,
    docs_root: Path,
    project_root: Path | None,
    kind: str,
    subdir: str,
    now_iso: str,
) -> int:
    """Walk one ``kind`` subtree under docs_root and emit fact rows.

    Returns the number of fact rows newly INSERTed (idempotency-hits
    don't count toward the total).

    For each artifact:

    * Read currently-present labels from ``labels.txt``.
    * Read the existing ``present=1`` set from
      ``labels_current``.
    * Currently-present minus existing-present → adds. Emit
      ``present=1`` rows.
    * Existing-present minus currently-present → removes. Emit
      ``present=0`` rows.
    * Currently-present intersect existing-present → already
      recorded as present; only re-emit if the latest fact's
      ``source_event`` differs from the would-be one (idempotency
      handles the dedup).

    Effect — INSERT side via :func:`insert_labels_fact`.
    """
    inserted = 0
    rebuild_event = _walker_rebuild_event(now_iso)
    for issue_id, artifact_dir in _iter_artifact_dirs(docs_root, subdir):
        labels_path = artifact_dir / "labels.txt"
        history_dir = artifact_dir / "history"
        current = _read_labels_file(labels_path)
        history_map = _label_add_ops_from_history(history_dir)
        existing = _existing_present_labels(conn, issue_id, kind)

        # Emit present=1 rows for every currently-present label.
        # Idempotency index dedupes re-walks against the same
        # source_event; new add-ops in history naturally pick up
        # the history filename as source_event so they land as
        # fresh rows.
        for label in current:
            valid_from = _valid_from_for_label(
                label, history_map, labels_path, project_root,
            )
            source_event = history_map.get(label, rebuild_event)
            ok = insert_labels_fact(
                conn,
                issue_id=issue_id,
                kind=kind,
                label=label,
                present=True,
                valid_from=valid_from,
                recorded_at=now_iso,
                source_event=source_event,
                recorded_by=None,
            )
            if ok:
                inserted += 1

        # Emit present=0 rows for labels that vanished since last
        # walk. The remove's source_event is the rebuild sentinel
        # since labels.txt's absence-of-line is what triggered the
        # detection — there's no per-remove history file the walker
        # can attribute to.
        for label in existing - set(current):
            ok = insert_labels_fact(
                conn,
                issue_id=issue_id,
                kind=kind,
                label=label,
                present=False,
                valid_from=now_iso,
                recorded_at=now_iso,
                source_event=f"{rebuild_event}_remove_{label}",
                recorded_by=None,
            )
            if ok:
                inserted += 1
    return inserted


def walk_labels(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``labels_facts`` from canonical.

    Called by :func:`shadow.migration.rebuild_derivable_tables` (drift
    rebuild path) and :func:`daemon.action_log.refresh_shadow_for_op`
    (per-op refresh path) with a context dict carrying the docs root
    and optional project root.

    Args:
        conn: sqlite3 connection (must have ``labels_facts`` + the
            ``labels_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"docs_root"`` — :class:`Path` to the canonical store.
              Required; ``None``/missing → zero rows.
            * ``"project_root"`` — :class:`Path` to the project's git
              working tree, used for the OQ12 pre-3.0 backfill via
              :func:`shadow.git_log.file_introduction_timestamp`.
              Optional; absence skips the git fallback (final
              sentinel timestamp takes over).

    Returns:
        Total fact rows INSERTed across all three kinds. Idempotency-
        hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit
    (the migration / refresh dispatch commits once at the end).
    """
    docs_root = ctx.get("docs_root")
    if docs_root is None:
        return 0
    if not isinstance(docs_root, Path):
        docs_root = Path(docs_root)
    project_root = ctx.get("project_root")
    if project_root is not None and not isinstance(project_root, Path):
        project_root = Path(project_root)
    now_iso = _iso_now()
    total = 0
    for kind, subdir in _KIND_DIRECTORIES:
        total += _walk_kind(
            conn, docs_root, project_root, kind, subdir, now_iso,
        )
    return total


def register() -> None:
    """Register ``labels_facts`` with the shadow registry + per-op map.

    Idempotent — re-registration overwrites the previous entry, which
    is the contract :func:`shadow.registry.register_table` documents.
    Called at module import time by ``shadow/__init__.py``; tests that
    need a clean registry call :func:`shadow.registry.reset_for_testing`
    and re-invoke this function (or skip it and register their own
    fakes via ``register_table``).

    Per-op refresh wiring: every canonical op that touches labels
    (create_issue / add_label / remove_label / similar) re-derives
    ``labels_facts`` for the affected artifact. The walker reads the
    full canonical store, so registration is conservative — any op
    that COULD touch labels triggers a refresh.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_labels,
    )
    # Per-op refresh: any op that mutates labels.txt re-triggers the
    # walker. The canonical-store op vocabulary (#270 + the 3.0
    # history log) uses these names; new vocabulary lands via per-op
    # registration in whichever PR introduces it.
    for op_name in (
        "create_issue",
        "close_issue",
        "add_label",
        "remove_label",
        "set_labels",
        "create_discussion",
        "create_pull",
    ):
        register_op_refresh(op_name, (TABLE_NAME,))

