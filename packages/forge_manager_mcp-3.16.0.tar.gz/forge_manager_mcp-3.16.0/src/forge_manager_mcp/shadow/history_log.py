"""``history_log_facts`` shadow table (Issue #480 / 3.14.0 Cluster A
Phase 4 — cross-cutting append-stream walker).

Bitemporal fact log of every history-log entry across every canonical
artifact kind. Each ``<docs>/<kind>/<id>/history/<ts>.json`` file
(or, for sessions, ``<docs>/sessions/<session_id>/<ts>-<event>.json``)
maps to exactly one fact row. The fact log is itself an append-only
stream — newer history entries land as new rows; older rows never
mutate (the underlying canonical history files are immutable per the
LocalStoreAdapter's append-only contract).

Per Discussion #22 Phase 4 scope: this table is the cross-cutting
shadow. Where ``labels_facts`` / ``refs_facts`` / ``code_complete_facts``
each walk one specific filesystem slice, ``history_log_facts`` walks
the union — every kind's ``history/`` dir, plus the sessions flat-
layout exception. Population is exclusively walker-driven (no
per-op live-write dispatch — the history-log writer in
:class:`LocalStoreAdapter._append_history` already wrote the file the
walker is about to ingest).

Filename shape (kind-specific):

* Numbered kinds (``issues`` / ``discussions`` / ``pulls`` /
  ``milestones`` / ``gaps``) — ``history/<YYYYMMDDTHHMMSSmicrosZ>-<op>.json``.
  Compact ISO-8601 form (no dashes/colons) per
  :func:`LocalStoreAdapter._append_history`.
* Sessions — ``<YYYY-MM-DDTHH-MM-SS-microsZ>-<event>.json`` directly
  under ``sessions/<session_id>/`` (no nested ``history/`` subdir).
  Dash-separated form per the legacy session-event convention.

Pre-3.0 artifacts (no history dir) yield zero rows here — by
construction, a fact row only exists when a history file exists.
Per-table walkers (labels, refs) carry the OQ12 pre-3.0 backfill via
``git_log.file_introduction_timestamp``; ``history_log_facts`` doesn't
need that fallback because its rows are literally one-per-history-file.

Effect-then-interceptor split (Rule 2): the walker is pure read-effect
over the canonical filesystem; the INSERT is the effect side performed
by :func:`insert_history_log_fact` against a caller-supplied
connection.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .core import _insert_bitemporal_row
from .registry import register_op_refresh, register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "history_log_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/history_log_facts`` endpoint + the registry lookup."""


_HISTORY_COLUMNS: tuple[str, ...] = (
    "entity_kind", "entity_id", "operation", "payload_sha", "actor",
)
"""Entity-identifier + state columns bound positionally by
:func:`insert_history_log_fact`. The framework columns (``valid_from``,
``recorded_at``, ``source_event``, ``recorded_by``) get appended inside
``_insert_bitemporal_row``."""


_NUMBERED_KINDS: tuple[tuple[str, str], ...] = (
    ("issue", "issues"),
    ("discussion", "discussions"),
    ("pull", "pulls"),
)
"""Numbered-kind mapping where ``entity_id`` is the directory name as
an integer-formatted string. The walker scans
``<docs_root>/<subdir>/<n>/history/*.json`` for each entry. Order is
deterministic so test assertions stay stable."""


_NAMED_KINDS: tuple[tuple[str, str], ...] = (
    ("milestone", "milestones"),
    ("gap", "gaps"),
)
"""Named-kind mapping where ``entity_id`` is the directory name
verbatim (milestone version string like ``"3.14.0"`` or gap_id like
``"code_design.flat_functions"``). The walker scans
``<docs_root>/<subdir>/<name>/history/*.json`` for each entry."""


_SESSIONS_SUBDIR: str = "sessions"
"""Sessions live as a flat layout — ``<docs_root>/sessions/<session_id>/
<ts>-<event>.json``. No nested ``history/`` subdir; the event files
sit directly under the session directory."""


# ---------------------------------------------------------------------------
# Filename → ISO-8601 timestamp parsing
# ---------------------------------------------------------------------------


# Compact form: 20260514T024058541549Z (issue/discussion/pull/milestone/gap
# history files written by LocalStoreAdapter._append_history).
# strftime("%Y%m%dT%H%M%S%fZ") — 6 microsecond digits + Z suffix.
_COMPACT_TS_PATTERN: re.Pattern[str] = re.compile(
    r"^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(\d{6})Z",
)
"""Matches the compact ISO-8601 prefix at the start of a numbered-kind
history filename. The 7 capture groups are year/month/day/hour/min/
sec/microseconds; ``Z`` is the literal UTC marker. The pattern is
anchored at start-of-string so the regex doesn't accidentally pick up
a timestamp later in the filename."""


# Dash-separated form: 2026-05-07T22-07-24-825373Z (sessions/<id>/
# <ts>-<event>.json written by the session-event code path).
# Format: YYYY-MM-DDTHH-MM-SS-microsZ (dashes between every part).
_DASH_TS_PATTERN: re.Pattern[str] = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})T(\d{2})-(\d{2})-(\d{2})-(\d{6})Z",
)
"""Matches the dash-separated ISO-8601 prefix used by session event
filenames. Same 7 capture groups as :data:`_COMPACT_TS_PATTERN`. The
dash-separated form is the legacy session-event convention; the
walker recognizes both so the same parser works across every kind."""


# Older session form: 2026-05-02T18:49:48Z (older session entries with
# colon-separated time + no microseconds). Found in some 3.0-era
# session dirs.
_COLON_TS_PATTERN: re.Pattern[str] = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})Z",
)
"""Matches the older colon-separated ISO-8601 form (no microseconds).
A fallback for legacy session entries written before the dash-
separated convention stabilized. Yields second-precision
``valid_from`` (microseconds default to zero in the parsed datetime)."""


def _parse_filename_timestamp(filename: str) -> str | None:
    """Parse the timestamp prefix of a history-entry filename to ISO-8601.

    Returns the normalized ISO-8601 UTC string (``YYYY-MM-DDTHH:MM:SS.ffffffZ``)
    on match; returns ``None`` when the filename doesn't start with a
    recognized timestamp form (filename will be skipped by the walker).

    Recognized forms (in order):

    1. Compact: ``YYYYMMDDTHHMMSSmicrosZ`` (numbered-kind history files).
    2. Dash-separated: ``YYYY-MM-DDTHH-MM-SS-microsZ`` (session events).
    3. Colon-separated: ``YYYY-MM-DDTHH:MM:SSZ`` (legacy session events
       without microseconds).

    Pure regex + datetime composition. No IO.
    """
    for pattern in (_COMPACT_TS_PATTERN, _DASH_TS_PATTERN):
        match = pattern.match(filename)
        if match is not None:
            y, mo, d, h, mi, s, us = (int(g) for g in match.groups())
            try:
                dt = datetime(y, mo, d, h, mi, s, us, tzinfo=timezone.utc)
            except ValueError:
                return None
            return dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    match = _COLON_TS_PATTERN.match(filename)
    if match is not None:
        y, mo, d, h, mi, s = (int(g) for g in match.groups())
        try:
            dt = datetime(y, mo, d, h, mi, s, 0, tzinfo=timezone.utc)
        except ValueError:
            return None
        return dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    return None


# ---------------------------------------------------------------------------
# Payload field extraction
# ---------------------------------------------------------------------------


_OPERATION_FIELDS: tuple[str, ...] = ("operation", "op", "event")
"""Payload fields the walker probes (in order) to extract the
operation name. Different history-log vocabularies wrote different
field names across this codebase's history — numbered-kind history
entries use ``operation`` (per
:meth:`LocalStoreAdapter._append_history`); some legacy entries used
``op``; session events use ``event``. Walker accepts whichever lands
first."""


_ACTOR_FIELDS: tuple[str, ...] = ("actor", "author", "recorded_by")
"""Payload fields the walker probes (in order) to extract the actor.
Optional in payloads — absence yields ``actor = NULL`` per the schema's
nullable column. ``actor``/``author``/``recorded_by`` cover the three
conventional spellings observed across the corpus."""


def _extract_first_str_field(
    payload: dict[str, Any], fields: tuple[str, ...],
) -> str | None:
    """Return the first non-empty string value from ``payload`` whose key
    is in ``fields`` (probed in order).

    Returns ``None`` when no field matches or every match is empty /
    non-string. Pure — operates on already-parsed JSON.
    """
    for field in fields:
        value = payload.get(field)
        if isinstance(value, str) and value:
            return value
    return None


def _payload_sha(raw_bytes: bytes) -> str:
    """Compute a stable sha256 hash of a history-entry payload.

    Re-parses the bytes as JSON then re-serializes with sorted keys +
    no whitespace so identical logical payloads with different
    formatting (indented vs not, dict-key reorder) produce identical
    hashes. Falls back to hashing the raw bytes when JSON parsing
    fails — a malformed entry still hashes deterministically so the
    idempotency index doesn't fail-open for re-walks.

    Pure modulo the hash computation.
    """
    try:
        parsed = json.loads(raw_bytes.decode("utf-8"))
        canonical = json.dumps(
            parsed, sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")
    except (UnicodeDecodeError, json.JSONDecodeError):
        canonical = raw_bytes
    return hashlib.sha256(canonical).hexdigest()


# ---------------------------------------------------------------------------
# Schema DDL
# ---------------------------------------------------------------------------


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS history_log_facts (
      entity_kind   TEXT NOT NULL,
      entity_id     TEXT NOT NULL,
      operation     TEXT NOT NULL,
      payload_sha   TEXT,
      actor         TEXT,
      valid_from    TEXT NOT NULL,
      recorded_at   TEXT NOT NULL,
      source_event  TEXT NOT NULL,
      recorded_by   TEXT,
      PRIMARY KEY (entity_kind, entity_id, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_history_idempotent "
    "ON history_log_facts(entity_kind, entity_id, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_history_operation "
    "ON history_log_facts(operation, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_history_actor "
    "ON history_log_facts(actor, valid_from)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("entity_kind", "entity_id", "source_event"),
        select_columns=(
            "entity_kind", "entity_id", "operation", "payload_sha",
            "actor", "valid_from", "recorded_at", "source_event",
            "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``history_log_current`` view's partition is
``(entity_kind, entity_id, source_event)`` — each source_event maps
to exactly one logical history entry, so the "latest per partition"
shape returns the canonical row for each entry on rebuild (a re-walk
under a new ``recorded_at`` supersedes the older row even though the
content is identical)."""


# ---------------------------------------------------------------------------
# Typed insert wrapper
# ---------------------------------------------------------------------------


def insert_history_log_fact(
    conn,
    *,
    entity_kind: str,
    entity_id: str,
    operation: str,
    payload_sha: str | None,
    actor: str | None,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the history-log schema and forwards
    to the generic helper. Returns ``True`` on insert; ``False`` when
    the UNIQUE idempotency index hits (per OQ13 "already applied"
    contract — a re-walk over the same source_event collapses safely).

    Args:
        conn: sqlite3 connection (must have ``history_log_facts`` table).
        entity_kind: Singular form of the canonical kind — ``'issue'`` /
            ``'discussion'`` / ``'pull'`` / ``'session'`` /
            ``'milestone'`` / ``'gap'``.
        entity_id: The artifact's directory name as a string. Canonical
            integer for numbered kinds; session_id verbatim for
            sessions; milestone version string for milestones; gap_id
            for gaps.
        operation: Operation name extracted from the payload (the
            ``operation`` / ``op`` / ``event`` field — whichever the
            walker found first).
        payload_sha: sha256 of the canonicalized JSON payload. Used for
            change-detection across re-walks of the same source_event
            (same hash → no semantic change). Nullable when the file
            failed to read / hash.
        actor: Who performed the operation. Nullable — payloads
            without an actor field land NULL.
        valid_from: ISO-8601 timestamp parsed from the filename.
        recorded_at: ISO-8601 timestamp of when this row was written.
        source_event: ``<entity_kind>/<entity_id>/history/<filename>``
            relative path within docs (for numbered + named kinds), or
            ``sessions/<session_id>/<filename>`` (for sessions).
        recorded_by: session_id, or ``None`` for walker fills.
    """
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_HISTORY_COLUMNS,
        values=(entity_kind, entity_id, operation, payload_sha, actor),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


# ---------------------------------------------------------------------------
# Walker helpers
# ---------------------------------------------------------------------------


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in :mod:`shadow.labels` + :mod:`shadow.refs`
    + :mod:`shadow.code_complete` so recorded_at columns sort cleanly
    across tables.

    Used as the per-walker timestamp prefix; :func:`_recorded_at_for_row`
    composes per-row uniqueness on top so the PK
    ``(entity_kind, entity_id, recorded_at)`` doesn't collide when one
    walker call emits many rows for the same artifact.

    Abstracted so tests can monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _recorded_at_for_row(now_iso: str, row_index: int) -> str:
    """Compose a per-row ``recorded_at`` from the walker's base timestamp.

    Appends a row-index suffix to the base ISO-8601 timestamp so a
    single walker invocation emitting many rows for the same artifact
    doesn't collide on the PK
    ``(entity_kind, entity_id, recorded_at)``. The suffix carries a
    zero-padded counter; ordering across rows stays monotonic since
    string comparison of equal-length suffixes is numeric.

    Pure string composition.
    """
    return f"{now_iso}#{row_index:09d}"


def _read_payload(path: Path) -> tuple[dict[str, Any], bytes]:
    """Read a history-entry file and return ``(parsed_payload, raw_bytes)``.

    Returns ``({}, b"")`` on read or parse failure — the walker treats
    unreadable files as zero-payload entries (still emits a fact row
    with a sha of the empty bytes so the operator can see the entry
    was attempted).

    Pure read-IO + json decode.
    """
    try:
        raw = path.read_bytes()
    except OSError:
        return {}, b""
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}, raw
    if not isinstance(payload, dict):
        return {}, raw
    return payload, raw


def _iter_numbered_entity_dirs(
    docs_root: Path, subdir: str,
) -> Iterable[tuple[str, Path]]:
    """Yield ``(entity_id_str, entity_dir)`` for every numeric-named
    subdir under ``<docs_root>/<subdir>/``.

    Mirrors :func:`shadow.labels._iter_artifact_dirs` but returns the
    entity_id as a string (matches the shadow column type). Sorted by
    numeric value for deterministic walker ordering.

    Pure read-IO.
    """
    base = docs_root / subdir
    if not base.is_dir():
        return
    entries: list[tuple[int, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        if not entry.name.isdigit():
            continue
        entries.append((int(entry.name), entry))
    entries.sort(key=lambda pair: pair[0])
    yield from ((str(n), path) for n, path in entries)


def _iter_named_entity_dirs(
    docs_root: Path, subdir: str,
) -> Iterable[tuple[str, Path]]:
    """Yield ``(entity_id_str, entity_dir)`` for every subdir under
    ``<docs_root>/<subdir>/``.

    Used for milestone (version string like ``3.14.0``) + gap (gap_id
    like ``code_design.flat_functions``) kinds where the directory
    name is the entity_id verbatim. Sorted alphabetically for
    deterministic walker ordering.

    Pure read-IO.
    """
    base = docs_root / subdir
    if not base.is_dir():
        return
    entries: list[tuple[str, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        entries.append((entry.name, entry))
    entries.sort(key=lambda pair: pair[0])
    yield from entries


def _iter_session_dirs(docs_root: Path) -> Iterable[tuple[str, Path]]:
    """Yield ``(session_id, session_dir)`` for every subdir under
    ``<docs_root>/sessions/``.

    Session_id is the directory name verbatim (16-char hex hash form
    per :func:`forge_manager_mcp.session.open_session`). Sorted
    alphabetically for deterministic walker ordering.

    Pure read-IO.
    """
    base = docs_root / _SESSIONS_SUBDIR
    if not base.is_dir():
        return
    entries: list[tuple[str, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        entries.append((entry.name, entry))
    entries.sort(key=lambda pair: pair[0])
    yield from entries


def _history_entry_files(entity_dir: Path) -> list[Path]:
    """Return every ``*.json`` file under ``<entity_dir>/history/``.

    Sorted alphabetically (which equals chronological for the compact
    timestamp prefix format). Missing / non-directory ``history/`` →
    empty list.

    Pure read-IO.
    """
    history_dir = entity_dir / "history"
    if not history_dir.is_dir():
        return []
    return sorted(
        path for path in history_dir.iterdir()
        if path.is_file() and path.suffix == ".json"
    )


def _session_event_files(session_dir: Path) -> list[Path]:
    """Return every ``*.json`` file directly under ``<session_dir>/``.

    Sessions use a flat layout — event files sit directly under the
    session dir, no nested ``history/`` subdir. Sorted alphabetically.

    Pure read-IO.
    """
    return sorted(
        path for path in session_dir.iterdir()
        if path.is_file() and path.suffix == ".json"
    )


# ---------------------------------------------------------------------------
# Walker dispatch
# ---------------------------------------------------------------------------


def _emit_history_row(
    conn,
    *,
    entity_kind: str,
    entity_id: str,
    entry_path: Path,
    source_event: str,
    recorded_at: str,
) -> bool:
    """Read one history entry file and emit its fact row.

    Returns ``True`` when a row landed; ``False`` when the filename's
    timestamp didn't parse (entry skipped) or when the idempotency
    index dedup'd a re-walk.

    Args:
        conn: sqlite connection.
        entity_kind: Singular kind (e.g., ``'issue'``).
        entity_id: String form of the entity identifier.
        entry_path: Path to the history-entry file on disk.
        source_event: Relative path within docs used as the row's
            source_event (also the idempotency-index key).
        recorded_at: Per-row recorded_at timestamp — composed by
            :func:`_recorded_at_for_row` so a single walker call
            emitting many rows per artifact doesn't collide on the
            ``(entity_kind, entity_id, recorded_at)`` PK.

    Effect — issues one INSERT via :func:`insert_history_log_fact`.
    """
    valid_from = _parse_filename_timestamp(entry_path.name)
    if valid_from is None:
        return False
    payload, raw = _read_payload(entry_path)
    operation = _extract_first_str_field(payload, _OPERATION_FIELDS)
    if operation is None:
        # NOT NULL on operation; fall back to a sentinel derived from
        # the filename's suffix-portion (post-timestamp). This keeps
        # the fact log complete even when the payload's operation
        # field is malformed.
        operation = _operation_from_filename(entry_path.name) or "unknown"
    actor = _extract_first_str_field(payload, _ACTOR_FIELDS)
    payload_sha = _payload_sha(raw) if raw else None
    return insert_history_log_fact(
        conn,
        entity_kind=entity_kind,
        entity_id=entity_id,
        operation=operation,
        payload_sha=payload_sha,
        actor=actor,
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=None,
    )


def _operation_from_filename(filename: str) -> str | None:
    """Extract the operation name from a history filename's suffix.

    Filenames look like ``<timestamp>-<operation>.json``. Returns the
    middle portion when both delimiters are present; ``None`` when the
    filename doesn't follow the convention.

    Pure string parse.
    """
    stem = filename.rsplit(".json", 1)[0]
    # Find the first dash after the timestamp prefix.
    parts = stem.split("-", maxsplit=-1)
    if len(parts) < 2:
        return None
    # For compact-form numbered-kind names ("20260514T024058541549Z-close_issue"),
    # the timestamp is the first part and the op is parts[1:] joined.
    # For dash-form session names ("2026-05-07T22-07-24-825373Z-opened"),
    # the timestamp itself contains dashes (7 parts), so the op is
    # the last part. Use the simpler heuristic: take the trailing
    # segments after the last ``Z-`` marker.
    z_marker = stem.find("Z-")
    if z_marker == -1:
        return None
    return stem[z_marker + 2:] or None


def _walk_numbered_kind(
    conn,
    docs_root: Path,
    entity_kind: str,
    subdir: str,
    now_iso: str,
    row_index: int,
) -> tuple[int, int]:
    """Walk one numbered-kind subtree and emit fact rows.

    Returns ``(inserted, next_row_index)`` — the count of fact rows
    newly INSERTed (idempotency-hits don't count) and the updated
    monotonic row-index counter the caller passes to the next walker.

    Effect — INSERT side via :func:`_emit_history_row`.
    """
    inserted = 0
    for entity_id, entity_dir in _iter_numbered_entity_dirs(
        docs_root, subdir,
    ):
        for entry_path in _history_entry_files(entity_dir):
            source_event = f"{subdir}/{entity_id}/history/{entry_path.name}"
            recorded_at = _recorded_at_for_row(now_iso, row_index)
            row_index += 1
            if _emit_history_row(
                conn,
                entity_kind=entity_kind,
                entity_id=entity_id,
                entry_path=entry_path,
                source_event=source_event,
                recorded_at=recorded_at,
            ):
                inserted += 1
    return inserted, row_index


def _walk_named_kind(
    conn,
    docs_root: Path,
    entity_kind: str,
    subdir: str,
    now_iso: str,
    row_index: int,
) -> tuple[int, int]:
    """Walk one named-kind subtree (milestones / gaps) and emit fact rows.

    Same shape as :func:`_walk_numbered_kind` but yields entity_id
    verbatim from directory names instead of integer-formatting.

    Returns ``(inserted, next_row_index)``.

    Effect — INSERT side via :func:`_emit_history_row`.
    """
    inserted = 0
    for entity_id, entity_dir in _iter_named_entity_dirs(
        docs_root, subdir,
    ):
        for entry_path in _history_entry_files(entity_dir):
            source_event = f"{subdir}/{entity_id}/history/{entry_path.name}"
            recorded_at = _recorded_at_for_row(now_iso, row_index)
            row_index += 1
            if _emit_history_row(
                conn,
                entity_kind=entity_kind,
                entity_id=entity_id,
                entry_path=entry_path,
                source_event=source_event,
                recorded_at=recorded_at,
            ):
                inserted += 1
    return inserted, row_index


def _walk_sessions(
    conn,
    docs_root: Path,
    now_iso: str,
    row_index: int,
) -> tuple[int, int]:
    """Walk the sessions flat-layout subtree and emit fact rows.

    Sessions don't use a nested ``history/`` subdir — event files sit
    directly under ``sessions/<session_id>/``. Walker enumerates each
    session dir and emits one fact row per ``*.json`` event file.

    Returns ``(inserted, next_row_index)``.

    Effect — INSERT side via :func:`_emit_history_row`.
    """
    inserted = 0
    for session_id, session_dir in _iter_session_dirs(docs_root):
        for entry_path in _session_event_files(session_dir):
            source_event = (
                f"{_SESSIONS_SUBDIR}/{session_id}/{entry_path.name}"
            )
            recorded_at = _recorded_at_for_row(now_iso, row_index)
            row_index += 1
            if _emit_history_row(
                conn,
                entity_kind="session",
                entity_id=session_id,
                entry_path=entry_path,
                source_event=source_event,
                recorded_at=recorded_at,
            ):
                inserted += 1
    return inserted, row_index


def walk_history_log(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``history_log_facts`` from canonical.

    Called by :func:`shadow.migration.rebuild_derivable_tables` (drift
    rebuild path) and :func:`daemon.action_log.refresh_shadow_for_op`
    (per-op refresh path) with a context dict carrying the docs root.

    Args:
        conn: sqlite3 connection (must have ``history_log_facts`` + the
            ``history_log_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"docs_root"`` — :class:`Path` to the canonical store.
              Required; ``None``/missing → zero rows.
            * ``"project_root"`` — accepted but unused (history_log
              doesn't need the git-introduction fallback; rows exist
              only when history files do).

    Returns:
        Total fact rows INSERTed across all six kinds. Idempotency-
        hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    docs_root = ctx.get("docs_root")
    if docs_root is None:
        return 0
    if not isinstance(docs_root, Path):
        docs_root = Path(docs_root)
    now_iso = _iso_now()
    total = 0
    row_index = 0
    # Numbered kinds (issues / discussions / pulls).
    for entity_kind, subdir in _NUMBERED_KINDS:
        delta, row_index = _walk_numbered_kind(
            conn, docs_root, entity_kind, subdir, now_iso, row_index,
        )
        total += delta
    # Named kinds (milestones / gaps).
    for entity_kind, subdir in _NAMED_KINDS:
        delta, row_index = _walk_named_kind(
            conn, docs_root, entity_kind, subdir, now_iso, row_index,
        )
        total += delta
    # Sessions (flat layout exception).
    delta, row_index = _walk_sessions(conn, docs_root, now_iso, row_index)
    total += delta
    return total


# ---------------------------------------------------------------------------
# Registry wiring
# ---------------------------------------------------------------------------


def register() -> None:
    """Register ``history_log_facts`` with the shadow registry + per-op
    map.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    Per-op refresh wiring: every canonical op that writes a history-
    log entry (the LocalStoreAdapter's ``_append_history`` call site
    runs from every state-mutating method) re-triggers this walker
    for the affected artifact. Walker reads the full canonical store,
    so registration is conservative: any op that COULD write a
    history entry triggers a refresh.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_history_log,
    )
    # Per-op refresh: every canonical write op invokes
    # LocalStoreAdapter._append_history. The op vocabulary covers the
    # known surface; new ops register via per-table PRs.
    for op_name in (
        "create_issue",
        "update_issue_body",
        "close_issue",
        "add_label",
        "remove_label",
        "set_labels",
        "create_discussion",
        "update_discussion_body",
        "mark_answer",
        "create_pull",
        "post_turn",
        "create_thread",
        "add_comment",
        "edit_comment",
        "open_session",
        "close_session",
        "create_milestone",
        "close_milestone",
        "update_milestone",
        "file_gap",
        "accept_gap",
        "ignore_gap",
        "triage_gap",
    ):
        register_op_refresh(op_name, (TABLE_NAME,))
