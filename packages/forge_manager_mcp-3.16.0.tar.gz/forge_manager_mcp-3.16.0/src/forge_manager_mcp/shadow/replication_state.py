"""``replication_state_facts`` shadow table (Issue #482 / 3.14.0
Cluster A Phase 5 — Tier 2 operational signal).

Bitemporal fact log of every ``ReplicationManager._set_state``
transition. Each transition lands one fact row carrying the new
state + the operation that triggered it, so queries can answer
"when did codeberg first DEGRADE this week" / "MTTR per adapter" /
"replay state-machine evolution as of last Wednesday" without
walking history files. Today's #470 sticky-DEGRADED would have
surfaced as a queryable trend rather than a one-shot observation.

Per Discussion #22 OQ7 closure: the walker reads the steady-state
``<state-dir>/replication-state.json`` (#377 persistent state) and
emits one fact row per adapter representing "state observed at
walker-rebuild moment". Loses transition history that occurred
while shadow was offline — acceptable per OQ7.

Population paths:

* **Live transitions** — :func:`emit_state_transition` is called
  from :meth:`ReplicationManager._set_state` (interceptor side)
  after the in-memory state mutation lands. Steady-state hot path.
* **Walker rebuild** — :func:`walk_replication_state` reads
  ``<state-dir>/replication-state.json`` and emits one fact row
  per adapter on full rebuild / fresh shadow bootstrap.

Effect-then-interceptor split (Rule 2): walker is pure read-effect
over the persisted state file; live emit is the interceptor side
the manager invokes post-mutation. Both go through
:func:`insert_replication_state_fact`.

Composability with #470: the regression test asserting "local
adapter never re-DEGRADES from already-exists" reads as a SQL
query against this table:
``SELECT COUNT(*) FROM replication_state_facts WHERE adapter='local'
AND state='degraded' AND last_error LIKE '%already exists%'`` → 0.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .core import _insert_bitemporal_row
from .registry import register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "replication_state_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/replication_state_facts`` endpoint + the registry
lookup."""


_REPL_COLUMNS: tuple[str, ...] = (
    "adapter", "state", "last_error", "state_changed_at",
)
"""Entity + state columns the typed wrapper binds positionally. The
framework columns (``valid_from``, ``recorded_at``, ``source_event``,
``recorded_by``) get appended inside ``_insert_bitemporal_row``."""


# State vocabulary — closed set mirroring AdapterState's str values.
STATE_HEALTHY: str = "healthy"
STATE_DEGRADED: str = "degraded"
# (#23 A.5 OQ3) STATE_RECONCILING RETIRED with the canonical_reconcile
# loop (commit 54581bc).
# (#23 A.5 OQ1) STATE_PAUSED RETIRED — operator-pause migrated to the
# durable ``platforms[i].enabled`` config flag.
# (#23 A.5 OQ2) STATE_DEGRADED retired from the in-memory enum, but
# kept in the shadow's VALID_STATES for historical row validation —
# the bitemporal table preserves pre-A.5 rows that recorded the
# DEGRADED transition. Post-A.5 no new DEGRADED rows are emitted
# (per OQ5 the replication_push_facts shadow table at commit
# 5bc6f02 is the substrate for new push outcomes).
VALID_STATES: frozenset[str] = frozenset({
    STATE_HEALTHY, STATE_DEGRADED,
})


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS replication_state_facts (
      adapter          TEXT NOT NULL,
      state            TEXT NOT NULL,
      last_error       TEXT,
      state_changed_at TEXT NOT NULL,
      valid_from       TEXT NOT NULL,
      recorded_at      TEXT NOT NULL,
      source_event     TEXT NOT NULL,
      recorded_by      TEXT,
      PRIMARY KEY (adapter, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_repl_state_idempotent "
    "ON replication_state_facts(adapter, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_repl_state_adapter "
    "ON replication_state_facts(adapter, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_repl_state_kind "
    "ON replication_state_facts(state, valid_from)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("adapter",),
        select_columns=(
            "adapter", "state", "last_error", "state_changed_at",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``replication_state_current`` view returns the
latest fact per adapter — queries like "when did codeberg DEGRADE"
filter on ``state = 'degraded'`` over the raw fact table to traverse
transition history; the current view answers "what state is each
adapter in right now"."""


def insert_replication_state_fact(
    conn,
    *,
    adapter: str,
    state: str,
    last_error: str | None,
    state_changed_at: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the replication-state schema and
    forwards to the generic helper. Returns ``True`` on insert;
    ``False`` when the UNIQUE idempotency index hits.

    Args:
        conn: sqlite3 connection (must have
            ``replication_state_facts`` table).
        adapter: ``platform_id`` of the adapter (e.g., ``"github"``
            / ``"forgejo"`` / ``"local"``).
        state: One of :data:`VALID_STATES`. Validated via
            :class:`ValueError` for typo protection — the closed
            vocabulary is the contract.
        last_error: Verbatim ``str(exc)`` from the transition's
            error; ``None`` for healthy / paused transitions or
            when no error context is available.
        state_changed_at: ISO-8601 UTC of the in-memory
            ``state_changed_at`` value; usually equal to
            ``valid_from`` but kept separate so an out-of-band
            replay-from-persisted-state run can backdate
            ``state_changed_at`` to the persisted timestamp while
            tagging ``valid_from`` with the actual import moment.
        valid_from: ISO-8601 UTC of when the fact became true in
            the world.
        recorded_at: ISO-8601 UTC of when this row was written.
        source_event: Op name that triggered the transition for
            live emits (``"create_issue"`` / ``"replay_pending"``
            / etc), or ``walker_rebuild_<iso>`` sentinel for walker
            rebuilds, or ``startup_probe`` for the per-adapter
            whoami probe (#378). The idempotency index includes
            this column so repeated dispatches collapse.
        recorded_by: session_id, or ``None`` for walker fills.
    """
    if state not in VALID_STATES:
        raise ValueError(
            f"shadow.replication_state: state {state!r} not in "
            f"{sorted(VALID_STATES)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_REPL_COLUMNS,
        values=(adapter, state, last_error, state_changed_at),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in sibling shadow modules so recorded_at
    columns sort cleanly across tables. Abstracted so tests can
    monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _walker_rebuild_event(now_iso: str, adapter: str) -> str:
    """Compose the ``walker_rebuild_<iso>_<adapter>`` source-event
    sentinel.

    The adapter suffix prevents the idempotency index from
    collapsing two adapters' rebuild rows under the same wall-clock
    moment (the partition is on ``adapter``, so the source_event
    must be distinct per-adapter for the UNIQUE-index hit semantics
    to work correctly).

    Pure string composition.
    """
    return f"walker_rebuild_{now_iso}_{adapter}"


def _iso_or_none(value: Any) -> str | None:
    """Coerce a datetime-or-str-or-None value to ISO-8601 string.

    The persisted state's ``state_changed_at`` field already comes
    through as a ``datetime`` (after the persistence layer's
    ``fromisoformat`` parse); the in-memory ``_set_state`` path
    passes ``datetime`` instances directly. This helper handles
    both shapes plus the bare-string case (defensive).

    Returns ``None`` for ``None``; otherwise returns the
    canonical ISO-8601 form. Pure.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, str):
        return value
    return str(value)


def emit_state_transition(
    conn,
    *,
    adapter: str,
    state: str,
    last_error: BaseException | str | None,
    state_changed_at: datetime | str,
    source_event: str,
    recorded_by: str | None = None,
) -> bool:
    """Live-emit hook for :meth:`ReplicationManager._set_state`.

    Called from the manager's single state-mutation site after the
    in-memory entry mutation lands. Composes the fact row from the
    transition details and inserts it.

    Graceful skip: returns ``False`` if the table isn't registered
    (daemon could be running pre-shadow-schema in some configs per
    the Issue #482 explicit requirement). The manager's state
    machine stays healthy regardless of whether the shadow table is
    bootstrapped.

    Args:
        conn: sqlite3 connection.
        adapter: ``platform_id`` of the adapter.
        state: The new state's string value (``AdapterState.value``).
        last_error: The triggering exception, or its string form, or
            ``None``. Coerced to ``str()`` for storage.
        state_changed_at: The in-memory ``state_changed_at``
            datetime (or its string form) — both
            ``valid_from`` and ``state_changed_at`` columns land
            with this value (the bitemporal axes coincide for live
            transitions).
        source_event: Op name that triggered the transition; the
            manager passes the ``operation_name`` from the
            originating write / read / replay call. Uniqueness
            within the per-adapter source_event index is the
            caller's contract — the manager appends a monotonic
            suffix when multiple transitions in the same dispatch
            need distinct identities.
        recorded_by: session_id, or ``None`` for daemon-internal
            fills.
    """
    state_changed_iso = _iso_or_none(state_changed_at) or _iso_now()
    last_error_str: str | None
    if last_error is None:
        last_error_str = None
    elif isinstance(last_error, str):
        last_error_str = last_error
    else:
        last_error_str = str(last_error)
    try:
        return insert_replication_state_fact(
            conn,
            adapter=adapter,
            state=state,
            last_error=last_error_str,
            state_changed_at=state_changed_iso,
            valid_from=state_changed_iso,
            recorded_at=_iso_now(),
            source_event=source_event,
            recorded_by=recorded_by,
        )
    except Exception:  # noqa: BLE001 — graceful skip when table absent
        return False


def walk_replication_state(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``replication_state_facts``
    from canonical persisted state (#377).

    Reads ``<state_dir>/replication-state.json`` and emits one
    ``walker_rebuild`` fact row per adapter representing the
    "current state at rebuild moment". Loses transition history
    that occurred while shadow was offline — acceptable per OQ7.

    Args:
        conn: sqlite3 connection (must have
            ``replication_state_facts`` + the
            ``replication_state_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"state_dir"`` — :class:`Path` to the daemon's
              per-project state-dir (where
              ``replication-state.json`` lives). Required for the
              walker to do anything.
            * ``"docs_root"`` / ``"project_root"`` — accepted but
              unused. Preserved for signature uniformity with other
              walkers.

    Returns:
        Total fact rows newly INSERTed. Idempotency-hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    state_dir = ctx.get("state_dir")
    if state_dir is None:
        return 0
    if not isinstance(state_dir, Path):
        state_dir = Path(state_dir)
    # Late-import the persistence reader to keep this module's
    # runtime closure narrow (tests on walk logic don't need the
    # persistence module unless exercising this path).
    from forge_manager_mcp.replication.persistence import (
        read_replication_state,
    )
    persisted = read_replication_state(state_dir)
    if persisted is None:
        return 0
    now_iso = _iso_now()
    inserted = 0
    for entry in persisted.entries:
        state_changed_iso = _iso_or_none(entry.state_changed_at) or now_iso
        ok = insert_replication_state_fact(
            conn,
            adapter=entry.platform_id,
            state=entry.state,
            last_error=entry.last_error_message,
            state_changed_at=state_changed_iso,
            valid_from=state_changed_iso,
            recorded_at=now_iso,
            source_event=_walker_rebuild_event(now_iso, entry.platform_id),
            recorded_by=None,
        )
        if ok:
            inserted += 1
    return inserted


def register() -> None:
    """Register ``replication_state_facts`` with the shadow registry.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    No per-op refresh wiring: live transitions emit directly via
    :func:`emit_state_transition` (called from
    :meth:`ReplicationManager._set_state`); walker rebuild only
    fires on explicit ``forge-manager-daemon shadow rebuild`` or
    schema-drift drop+rebuild. There's no canonical-op that
    "touches" replication-state in a meaningful way that the per-op
    refresh dispatch should react to — every op transition already
    fires the live emit.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_replication_state,
    )
