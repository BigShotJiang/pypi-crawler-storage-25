"""Hand-written ``_current`` view DDL generator (OQ3).

Per Discussion #22 OQ3 closure: each shadow fact table ships a
hand-written ``CREATE VIEW <name>_current AS`` carrying a
``ROW_NUMBER() OVER (PARTITION BY <pk> ORDER BY recorded_at DESC)``
CTE that surfaces the latest (= unsuperseded) fact row per key. This
module exposes :func:`current_view_ddl` as a small pure helper that
mechanically composes that DDL — every per-table PR calls it with
its specifics rather than re-typing the CTE shape.

OQ3 explicitly rejected codegen (path b) and inline windowing in
every query (path c). The helper here is the middle path: pure
string composition, no build step, no codegen layer — just a tiny
formatting function the registry shape carries.

Pure module — no IO, no sqlite imports, stdlib-only.
"""
from __future__ import annotations


def current_view_ddl(
    table_name: str,
    partition_columns: tuple[str, ...],
    select_columns: tuple[str, ...],
) -> str:
    """Compose ``CREATE VIEW <table_name>_current AS …`` DDL.

    Args:
        table_name: The fact table the view shadows (e.g.,
            ``"issues_facts"``). The view name is
            ``<table_name without _facts suffix>_current`` —
            conventional per OQ3 exemplar (``issues_facts`` →
            ``issues_current``). When the table name doesn't end in
            ``_facts`` the helper appends ``_current`` to the full
            table name (covers ``issues_native_ids_facts`` →
            ``issues_native_ids_current`` correctly).
        partition_columns: The PK columns the CTE partitions over —
            typically the entity-identifier columns (e.g.,
            ``("number",)`` for ``issues_facts``,
            ``("issue_id", "kind", "label")`` for ``labels_facts``).
        select_columns: The columns the view projects (entity fields
            + valid_from / recorded_at / body_source — whatever the
            caller wants exposed to query consumers). ``recorded_at``
            must appear in this list since the view's filtering uses
            it via the CTE's ``rn`` column.

    Returns:
        The ``CREATE VIEW … AS WITH ranked AS (…) SELECT …`` DDL as a
        single multi-line string. Caller embeds this in their own
        per-table DDL tuple alongside the ``CREATE TABLE`` +
        ``CREATE INDEX`` statements.

    Naming convention: ``<table>_facts`` → ``<table>_current``.
    Stripping the ``_facts`` suffix keeps the view name compact for
    the day-to-day query path while leaving the table name
    self-describing as a fact log.

    Pure — string composition only. No IO.
    """
    view_name = _view_name_for_table(table_name)
    partition_sql = ", ".join(partition_columns)
    select_sql = ", ".join(select_columns)
    return (
        f"CREATE VIEW IF NOT EXISTS {view_name} AS\n"
        f"WITH ranked AS (\n"
        f"  SELECT *, ROW_NUMBER() OVER (\n"
        f"    PARTITION BY {partition_sql} ORDER BY recorded_at DESC\n"
        f"  ) AS rn\n"
        f"  FROM {table_name}\n"
        f")\n"
        f"SELECT {select_sql}\n"
        f"FROM ranked WHERE rn = 1"
    )


def _view_name_for_table(table_name: str) -> str:
    """Compute the ``_current`` view name from a ``_facts`` table.

    Convention: strip the trailing ``_facts`` and append ``_current``.
    Falls back to appending ``_current`` to the full name when the
    suffix is missing — defensive, since the registry only allows
    `_facts` tables today but the convention is generic.
    """
    if table_name.endswith("_facts"):
        stem = table_name[: -len("_facts")]
    else:
        stem = table_name
    return f"{stem}_current"
