"""Per-table shadow registry — pure module-level registration.

Per Discussion #22 acceptance criteria: each per-table PR
(``labels_facts`` / ``refs_facts`` / etc.) registers its DDL +
classification + walker callable at import time via
:func:`register_table`. The framework PR ships the registry shape;
per-table PRs populate it.

Per-table classification (OQ7 refinement):

* ``derivable`` — drop + rebuild via walker on user_version mismatch.
* ``stateful`` — preserve across schema-version bumps (runtime data
  not derivable from canonical; migrated in place via explicit
  migration scripts when its schema evolves).

The registry is process-global by design — it mirrors the
``daemon.action_log._OP_TO_KINDS`` and ``daemon.writes.OP_HANDLERS``
patterns where module-level dicts hold the mapping from per-op to
implementation. Tests get isolation via
:func:`reset_for_testing` (callable from teardown) or by injecting a
fake module into ``rebuild_derivable_tables(registry_module=...)``.

Pure-data module — no IO, no sqlite imports, stdlib-only.
"""
from __future__ import annotations

from typing import Any, Callable

from .types import DERIVABLE, STATEFUL, VALID_CLASSIFICATIONS


WalkerFn = Callable[..., Any]
"""The walker callable signature is per-table — different walkers
need different argument shapes (some need docs_root, some need
project_root, some need both). The registry stores them as bare
callables and the dispatch layer
(:func:`shadow.migration.rebuild_derivable_tables`) passes whatever
context the caller supplied."""


_REGISTRY: dict[str, dict[str, Any]] = {}
"""Process-global registry. Keyed by table name; value is a dict with
``ddl`` (tuple of CREATE statements), ``classification`` (string from
:data:`shadow.types.VALID_CLASSIFICATIONS`), and ``walker_fn``
(callable or None — None for stub tables like
``issues_native_ids_facts`` per OQ14)."""


def register_table(
    name: str,
    *,
    ddl: tuple[str, ...],
    classification: str,
    walker_fn: WalkerFn | None = None,
) -> None:
    """Register a per-table shadow.

    Per-table PRs call this at import time from their module's
    top-level. Repeated registration of the same ``name`` overwrites
    the previous entry — supports test-side fakery via ``monkeypatch``
    + a separate ``reset_for_testing`` call.

    Args:
        name: The fact table name (e.g., ``"labels_facts"``). Must be
            a valid sqlite identifier; the framework doesn't validate
            beyond rejecting empty strings.
        ddl: Tuple of CREATE statements (CREATE TABLE + indexes +
            ``_current`` view). Executed in order at schema bootstrap.
        classification: One of :data:`shadow.types.DERIVABLE` or
            :data:`shadow.types.STATEFUL`. Anything else raises
            ``ValueError``.
        walker_fn: Optional callable that repopulates the table from
            canonical when called by
            :func:`shadow.migration.rebuild_derivable_tables`. Pass
            ``None`` for stub tables (per OQ14) that aren't walker-
            populated today but exist so callers don't dispatch
            around table presence.

    Raises:
        ValueError: when ``name`` is empty or ``classification`` is
            not a member of :data:`shadow.types.VALID_CLASSIFICATIONS`.
    """
    if not name:
        raise ValueError("shadow.register_table: name must not be empty")
    if classification not in VALID_CLASSIFICATIONS:
        raise ValueError(
            f"shadow.register_table: classification {classification!r} "
            f"not in {sorted(VALID_CLASSIFICATIONS)}"
        )
    _REGISTRY[name] = {
        "ddl": ddl,
        "classification": classification,
        "walker_fn": walker_fn,
    }


def registered_tables() -> list[str]:
    """Return every registered table name, sorted.

    Sorted return for deterministic iteration order — the migration
    path drops + recreates tables in this order, and deterministic
    order makes test assertions and operator log messages stable
    across Python's dict-ordering guarantees (insertion order is
    stable post-3.7 but registration order varies with import
    order under test fakery).
    """
    return sorted(_REGISTRY.keys())


def derivable_tables() -> list[str]:
    """Return every registered table classified as ``derivable``."""
    return sorted(
        name for name, entry in _REGISTRY.items()
        if entry["classification"] == DERIVABLE
    )


def stateful_tables() -> list[str]:
    """Return every registered table classified as ``stateful``."""
    return sorted(
        name for name, entry in _REGISTRY.items()
        if entry["classification"] == STATEFUL
    )


def ddl_for(name: str) -> tuple[str, ...]:
    """Return the DDL tuple for a registered table.

    Raises ``KeyError`` for unknown table names — the framework's
    contract is that callers ask only for registered tables (the
    dispatch path iterates :func:`registered_tables` first).
    """
    return _REGISTRY[name]["ddl"]


def walker_for(name: str) -> WalkerFn | None:
    """Return the walker callable for a registered table, or ``None``
    when the table registered without a walker (stub tables per OQ14).

    Raises ``KeyError`` for unknown table names.
    """
    return _REGISTRY[name]["walker_fn"]


def classification_for(name: str) -> str:
    """Return the classification (derivable / stateful) for a
    registered table.

    Raises ``KeyError`` for unknown table names.
    """
    return _REGISTRY[name]["classification"]


def reset_for_testing() -> None:
    """Clear the registry. Tests call this in teardown so cross-test
    registrations don't leak.

    Not exported for production use — production registrations happen
    once at module import time and stay for the daemon's lifetime.
    """
    _REGISTRY.clear()
    _OP_TABLE_MAP.clear()


# ---------------------------------------------------------------------------
# Per-op refresh dispatch (extension point for #386)
# ---------------------------------------------------------------------------

_OP_TABLE_MAP: dict[str, tuple[str, ...]] = {}
"""Operation-name → registered-table tuple. The daemon's
``refresh_fts5_for_op`` extension consults this to refresh shadow
fact tables alongside the FTS5 kinds for each ``write.completed``
event. Per-table PRs register their op-touch contracts via
:func:`register_op_refresh`; the framework PR ships the dict + the
empty default so the existing #386 dispatch stays a no-op for
shadow until the per-table PRs land."""


def register_op_refresh(op_name: str, tables: tuple[str, ...]) -> None:
    """Declare that ``op_name`` touches the listed shadow tables.

    Per-table PRs call this at import time so the daemon's per-op
    refresh dispatch (#386, extended for #475) refreshes the
    affected shadow tables alongside the FTS5 kinds when a
    ``write.completed`` event lands.

    Repeated calls for the same ``op_name`` overwrite the previous
    mapping. Unknown table names are accepted at registration time —
    the framework defers validation until dispatch (the table
    actually needing to exist is a runtime concern).

    Pure — mutates the module-level dict. Tests use
    :func:`reset_for_testing` for isolation.
    """
    if not op_name:
        raise ValueError("shadow.register_op_refresh: op_name must not be empty")
    _OP_TABLE_MAP[op_name] = tuple(tables)


def tables_for_op(op_name: str) -> tuple[str, ...]:
    """Return the shadow tables associated with ``op_name``, or an
    empty tuple when no per-table PR has registered the op.

    The daemon's #386 refresh dispatch calls this for every
    ``write.completed`` event; an empty return value means "no
    shadow tables affected by this op" — the dispatch reverts to
    FTS5-only refresh.
    """
    return _OP_TABLE_MAP.get(op_name, ())
