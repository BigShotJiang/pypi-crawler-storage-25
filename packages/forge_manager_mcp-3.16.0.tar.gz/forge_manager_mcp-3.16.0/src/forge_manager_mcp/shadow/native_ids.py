"""``issues_native_ids_facts`` shadow table — empty stub (Issue #479 /
3.14.0 Cluster A Phase 3).

Bitemporal fact log mapping canonical LocalStore numbers to
per-platform native IDs. The 3.14.0 shipping shape registers the
table + view + insert wrapper + no-op walker so the schema is
fully present in the action-log database; the population path lands
later when ``import_remote_changes`` ships per-backend.

Per Discussion #22 OQ14 closure: shipping the empty stub now means
schema migrations don't fork between "before native_ids" and "after
native_ids" — every project that's running 3.14.0+ has the table.
``import_remote_changes`` can call :func:`insert_native_id_fact`
directly without dispatching around table presence.

Schema purpose:

* ``canonical_kind`` + ``canonical_number`` identify the LocalStore
  artifact (e.g., ``("issue", 441)``).
* ``platform_id`` is the forge-config.json platform identifier
  (``"github"`` / ``"forgejo"`` / ``"gitlab"`` / etc).
* ``native_id`` is the platform's own ID string for the same artifact
  (e.g., GitHub Issue's REST integer ID, Forgejo's project-scoped
  iid, GitLab's project-scoped iid).
* ``valid_from`` / ``recorded_at`` track the bitemporal axes.
* ``source_event`` distinguishes mapping events (e.g.,
  ``"github_backfill_<sha>"`` for an import_remote_changes run).

The ``issues_native_ids_current`` view exposes the latest mapping per
``(canonical_kind, canonical_number, platform_id)`` partition — the
window of mutability for one logical canonical-↔-platform mapping.
The ``idx_native_lookup`` index supports the reverse query
"given a platform_id + native_id, which canonical number does it map
to?" which is the inbound webhook + backfill resolution path.

Walker contract:

* The 3.14.0 walker is a no-op — no canonical-store input lets the
  walker independently fabricate native IDs. Population is exclusively
  via :func:`insert_native_id_fact` from the future
  ``import_remote_changes`` path.

Effect-then-interceptor split (Rule 2): wrapper is pure dispatch to
:func:`shadow.core._insert_bitemporal_row`; walker is pure no-op.
"""
from __future__ import annotations

from typing import Any

from .core import _insert_bitemporal_row
from .registry import register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "issues_native_ids_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/issues_native_ids_facts`` endpoint + the registry
lookup. The plural ``issues`` prefix reflects the table's scope —
"every kind of artifact that needs native-id mapping" — not
just-issues; the name is historical from RFC #264's vocabulary."""


_NATIVE_ID_COLUMNS: tuple[str, ...] = (
    "canonical_kind", "canonical_number", "platform_id", "native_id",
)
"""Entity-identifier columns the typed wrapper binds positionally.
The framework columns get appended inside ``_insert_bitemporal_row``."""


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS issues_native_ids_facts (
      canonical_kind   TEXT NOT NULL,
      canonical_number INTEGER NOT NULL,
      platform_id      TEXT NOT NULL,
      native_id        TEXT NOT NULL,
      valid_from       TEXT NOT NULL,
      recorded_at      TEXT NOT NULL,
      source_event     TEXT NOT NULL,
      recorded_by      TEXT,
      PRIMARY KEY (canonical_kind, canonical_number, platform_id, recorded_at)
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_issues_native_idempotent "
    "ON issues_native_ids_facts(canonical_kind, canonical_number, "
    "platform_id, source_event)",
    "CREATE INDEX IF NOT EXISTS idx_native_lookup "
    "ON issues_native_ids_facts(platform_id, native_id)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=(
            "canonical_kind", "canonical_number", "platform_id",
        ),
        select_columns=(
            "canonical_kind", "canonical_number", "platform_id",
            "native_id",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. The view name lands
as ``issues_native_ids_current`` per :func:`shadow.views.current_view_ddl`
(strips the ``_facts`` suffix and appends ``_current``)."""


def insert_native_id_fact(
    conn,
    *,
    canonical_kind: str,
    canonical_number: int,
    platform_id: str,
    native_id: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Future ``import_remote_changes`` callers populate the table via
    this helper. Returns ``True`` on insert; ``False`` when the UNIQUE
    idempotency index hits (per OQ13 "already applied" contract — the
    same backfill rerun against the same source_event collapses
    cleanly).

    Args:
        conn: sqlite3 connection (must have
            ``issues_native_ids_facts`` table).
        canonical_kind: ``'issue'`` / ``'discussion'`` / ``'pull'`` —
            the canonical-store artifact kind.
        canonical_number: Canonical LocalStore number.
        platform_id: forge-config platform identifier (e.g.,
            ``"github"`` / ``"forgejo"`` / ``"gitlab"``). Matches the
            ``platform_id`` value the ReplicationManager uses to
            address adapters.
        native_id: The platform's native ID for the same artifact.
            Stored as string so platforms with non-integer IDs
            (future GraphQL global IDs, opaque tokens) work without
            schema change.
        valid_from: ISO-8601 timestamp of when the mapping became
            true in the world (typically the import_remote_changes
            run timestamp, or the original platform-issue creation
            time when known).
        recorded_at: ISO-8601 timestamp of the row write.
        source_event: A backfill-identifying string —
            ``"<platform_id>_backfill_<run_id>"`` for routine
            backfills, ``"<platform_id>_webhook_<event_id>"`` for
            inbound webhook resolution. The idempotency index
            includes this column so repeated dispatches against the
            same source_event collapse safely.
        recorded_by: session_id, or ``None`` for backfill fills.
    """
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_NATIVE_ID_COLUMNS,
        values=(
            canonical_kind, canonical_number, platform_id, native_id,
        ),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def walk_native_ids(conn, ctx: dict[str, Any]) -> int:
    """No-op walker for 3.14.0 per OQ14 closure.

    The canonical store doesn't carry per-platform native IDs in a
    parseable form — they live in remote-mirror state that
    ``import_remote_changes`` rehydrates. Until that ships per-backend,
    the walker has no input it can independently translate.

    Returns 0 unconditionally. The signature matches every other
    shadow walker so the dispatch layer can call it uniformly without
    a presence check.

    Args:
        conn: sqlite3 connection. Unused — preserved for signature
            uniformity.
        ctx: Walker context dict. Unused — preserved for signature
            uniformity.

    Returns:
        Always 0.
    """
    # OQ14: stub walker. Future replacement is the
    # ``import_remote_changes`` per-backend population path; that path
    # calls :func:`insert_native_id_fact` directly rather than going
    # through this walker.
    _ = conn  # explicit unused-marker for static checkers
    _ = ctx
    return 0


def register() -> None:
    """Register ``issues_native_ids_facts`` with the shadow registry.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    Per-op refresh wiring: no canonical ops touch native_ids today.
    Future ``import_remote_changes`` may register its own
    cross-table refresh contract, but that's out-of-scope for 3.14.0.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_native_ids,
    )
    # No per-op refresh — population is exclusively via
    # import_remote_changes calling insert_native_id_fact directly.
