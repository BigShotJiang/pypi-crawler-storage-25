"""``findings_facts`` shadow table (Issue #483 / 3.14.0 Cluster A
Phase 5 — Tier 2 operational signal).

Bitemporal fact log of every ``code_design`` finding. Separates code-
design findings from operational alerts (today they share the
:class:`SqliteAlertLog` ``events`` table per 3.7.0 D4 + 3.13.0 #454);
the separate table lets ``GROUP BY rule, file`` queries answer #471's
FP-sweep questions in O(1) instead of by walking the alert log.

Per the Issue body: the idempotency index uses ``finding_hash`` (not
``source_event``) so :mod:`daemon.watch`'s mtime-poll can re-emit the
same finding without producing duplicate fact rows; message-content
changes (different hash) produce new rows naturally + the
``findings_current`` view's ``ROW_NUMBER`` partition surfaces the
latest one per ``(rule, file_path, line)`` partition for supersession.

Population paths:

* **Live emit** — :func:`emit_finding_fact` is called from
  :func:`daemon.watch.watch_loop`. (#489 / 3.14.0) Code_design
  findings flow to ``findings_facts`` ONLY; the alerts table is
  reserved for operational events (backend transitions, credential
  failures, daemon lifecycle, upgrade drifts). Pre-#489 the watch
  loop dispatched to both surfaces; the doubled emit bloated the
  ``open_session`` response (companion Issue #488). The split makes
  ``findings_facts`` the sole canonical surface for code_design
  analytical queries.
* **Walker** — no walker for 3.14.0. Findings are mtime-poll-only
  by construction; there's no canonical-store snapshot to walk over
  (every finding exists because :func:`evaluate_paths` ran). The
  registered walker is a no-op for signature uniformity with the
  rest of the shadow framework. Future option: re-run
  :func:`evaluate_paths` against the full project tree on `shadow
  rebuild`. Out-of-scope for 3.14.0.

Effect-then-interceptor split (Rule 2): emit hook is the
interceptor side the watch loop invokes after the alert dispatch.
INSERT goes through :func:`insert_findings_fact`.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any

from .core import _insert_bitemporal_row
from .registry import register_table
from .types import DERIVABLE
from .views import current_view_ddl


TABLE_NAME: str = "findings_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/findings_facts`` endpoint + the registry lookup."""


_FINDING_COLUMNS: tuple[str, ...] = (
    "rule", "file_path", "line", "severity", "message", "finding_hash",
)
"""Entity + state columns the typed wrapper binds positionally. The
framework columns (``valid_from``, ``recorded_at``, ``source_event``,
``recorded_by``) get appended inside ``_insert_bitemporal_row``."""


# Severity vocabulary — mirrors `code_design._types.Severity`.
SEVERITY_INFO: str = "info"
SEVERITY_WARN: str = "warn"
SEVERITY_FAIL: str = "fail"
VALID_SEVERITIES: frozenset[str] = frozenset({
    SEVERITY_INFO, SEVERITY_WARN, SEVERITY_FAIL,
})


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS findings_facts (
      rule          TEXT NOT NULL,
      file_path     TEXT NOT NULL,
      line          INTEGER,
      severity      TEXT NOT NULL,
      message       TEXT NOT NULL,
      finding_hash  TEXT NOT NULL,
      valid_from    TEXT NOT NULL,
      recorded_at   TEXT NOT NULL,
      source_event  TEXT NOT NULL,
      recorded_by   TEXT,
      PRIMARY KEY (rule, file_path, line, recorded_at)
    )
    """,
    # Idempotency uses finding_hash (not source_event) — daemon/watch.py
    # mtime-poll re-emits the same finding without producing duplicates;
    # message-content changes (different hash) produce new rows naturally.
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_findings_idempotent "
    "ON findings_facts(rule, file_path, line, finding_hash)",
    "CREATE INDEX IF NOT EXISTS idx_findings_rule "
    "ON findings_facts(rule, severity, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_findings_file "
    "ON findings_facts(file_path, valid_from)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("rule", "file_path", "line"),
        select_columns=(
            "rule", "file_path", "line", "severity", "message",
            "finding_hash",
            "valid_from", "recorded_at", "source_event", "recorded_by",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``findings_current`` view returns the latest fact per
``(rule, file_path, line)`` partition — supports #471's FP-sweep
query ``SELECT rule, file_path, COUNT(*) FROM findings_current GROUP BY
rule, file_path`` natively."""


def insert_findings_fact(
    conn,
    *,
    rule: str,
    file_path: str,
    line: int | None,
    severity: str,
    message: str,
    finding_hash: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Constrains the column tuple to the findings schema and forwards
    to the generic helper. Returns ``True`` on insert; ``False`` when
    the UNIQUE idempotency index hits (the mtime-poll re-emit case
    per the Issue body).

    Args:
        conn: sqlite3 connection (must have ``findings_facts`` table).
        rule: Rule name minus ``code_design.`` prefix (matches
            :func:`make_finding`'s ``rule`` field).
        file_path: Project-relative file path. Forward-slashed,
            normalized — same shape :func:`make_location` produces.
        line: 1-based source-line, or ``None`` for whole-file
            findings.
        severity: One of :data:`VALID_SEVERITIES`. Validated via
            :class:`ValueError`.
        message: Single-sentence violation statement.
        finding_hash: Content hash for dedup — see
            :func:`compute_finding_hash`. The UNIQUE idempotency
            index combines this with ``(rule, file_path, line)`` so
            re-emits of an unchanged finding hit the idempotency
            index; message-content changes hash to a different value
            and land as new rows.
        valid_from: ISO-8601 UTC of when the fact became true in
            the world.
        recorded_at: ISO-8601 UTC of when this row was written.
        source_event: Watch-loop iteration identifier (e.g.,
            ``watch_iter_<iso>``); pinned to the dispatch-time
            timestamp so distinct iterations get distinct events
            even when the idempotency key collapses.
        recorded_by: session_id, or ``None`` for daemon-internal
            fills.
    """
    if severity not in VALID_SEVERITIES:
        raise ValueError(
            f"shadow.findings: severity {severity!r} not in "
            f"{sorted(VALID_SEVERITIES)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_FINDING_COLUMNS,
        values=(
            rule, file_path, line, severity, message, finding_hash,
        ),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


def compute_finding_hash(
    *,
    rule: str,
    file_path: str,
    line: int | None,
    severity: str,
    message: str,
) -> str:
    """Compute a stable content hash for a finding.

    sha256 over the canonical-string form of the finding's content
    fields. ``finding_hash`` lets the UNIQUE idempotency index
    distinguish "same finding" from "same location with new message"
    — the former hits the index (re-emit dedup), the latter lands as
    a fresh row that supersedes the old one in the current view.

    The hash combines:

    * ``rule`` — finding identity.
    * ``file_path`` — location.
    * ``line`` — location (``"None"`` for whole-file findings).
    * ``severity`` — content (severity changes hash to a new value).
    * ``message`` — content (message changes hash to a new value).

    Pure modulo the hash computation.
    """
    line_str = "None" if line is None else str(line)
    canonical = f"{rule}|{file_path}|{line_str}|{severity}|{message}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Matches the shape used in sibling shadow modules so recorded_at
    columns sort cleanly across tables. Abstracted so tests can
    monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def emit_finding_fact(
    conn,
    *,
    finding,
    valid_from: str | None = None,
    source_event: str,
    recorded_by: str | None = None,
) -> bool:
    """Live-emit hook for the :func:`daemon.watch.watch_loop`.

    Called once per Finding alongside the existing
    ``alerts_for_findings`` + ``alert_log.record`` dispatch. The
    Finding-shape is duck-typed (read-only access to ``rule`` /
    ``severity`` / ``location.path`` / ``location.line`` /
    ``message``) so this module doesn't import :mod:`code_design`
    (Test Dep-Graph Discipline #72 — keeps the leaf shadow_findings
    py_library closure narrow).

    Graceful skip: returns ``False`` if the table isn't registered
    (daemon running pre-shadow-schema).

    Args:
        conn: sqlite3 connection.
        finding: A :class:`Finding` instance from
            :mod:`code_design._types` (duck-typed).
        valid_from: ISO-8601 UTC of when the finding was observed.
            Defaults to current wall-clock — that's the "observed
            at this watch-loop tick" semantic the issue body calls
            out.
        source_event: Watch-loop iteration identifier — typically
            ``watch_iter_<iso>``. The idempotency index uses
            ``finding_hash`` (not this column), so distinct
            source_events for an unchanged finding still hit the
            dedup naturally.
        recorded_by: session_id, or ``None`` for daemon-internal
            fills.
    """
    if valid_from is None:
        valid_from = _iso_now()
    location = getattr(finding, "location", None)
    file_path = (
        getattr(location, "path", None) or "?" if location is not None else "?"
    )
    line = getattr(location, "line", None) if location is not None else None
    rule = getattr(finding, "rule", "") or ""
    severity = getattr(finding, "severity", "info") or "info"
    if severity not in VALID_SEVERITIES:
        severity = "info"
    message = getattr(finding, "message", "") or ""
    finding_hash = compute_finding_hash(
        rule=rule, file_path=file_path, line=line,
        severity=severity, message=message,
    )
    try:
        return insert_findings_fact(
            conn,
            rule=rule,
            file_path=file_path,
            line=line,
            severity=severity,
            message=message,
            finding_hash=finding_hash,
            valid_from=valid_from,
            recorded_at=_iso_now(),
            source_event=source_event,
            recorded_by=recorded_by,
        )
    except Exception:  # noqa: BLE001 — graceful skip when table absent
        return False


def walk_findings(conn, ctx: dict[str, Any]) -> int:
    """No-op walker for 3.14.0.

    Findings exist only because the watch loop ran
    :func:`evaluate_paths` against a changed file — there's no
    canonical-store snapshot to walk over. Future iterations may
    re-run the full evaluator suite on `shadow rebuild`; deferred to
    3.15.0+ per the Issue body's scoping ("daemon/watch.py emits
    fact rows alongside the existing alerts dispatch").

    Returns 0 unconditionally. Signature matches every other shadow
    walker so the dispatch layer can call it uniformly.
    """
    _ = conn  # explicit unused-marker
    _ = ctx
    return 0


def register() -> None:
    """Register ``findings_facts`` with the shadow registry.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract.

    No per-op refresh wiring: findings live entirely outside the
    canonical-op vocabulary. Live emit from the watch loop is the
    sole population path; the no-op walker exists for signature
    uniformity in the dispatch layer.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_findings,
    )
