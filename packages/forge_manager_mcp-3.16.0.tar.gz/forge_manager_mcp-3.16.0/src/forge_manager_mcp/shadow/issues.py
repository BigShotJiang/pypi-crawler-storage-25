"""``issues_facts`` shadow table (Issue #487 / 3.14.0 Cluster A Phase 5b
slot-in — the ninth Tier 1 table).

Bitemporal fact log of issue state across the canonical store. Each
``<docs>/issues/<n>/`` directory contributes one or more fact rows —
one per history-log entry when the artifact has a ``history/`` dir,
plus a synthetic ``pre_3_0_backfill`` row when there's no history (the
git-introduction-commit timestamp anchors valid_from for pre-3.0
artifacts). The latest fact per ``number`` partition surfaces via the
``issues_current`` view.

Per Discussion #22 "Exemplar schema (issues)" — this is the table the
RFC's `CREATE TABLE issues_facts` block literally references; it just
wasn't enumerated in the first-wave Tier 1 / Tier 2 lists, which is
the gap this slot-in PR closes. Once it lands,
``release.milestone_open_issues_against_cut`` (#363) migrates from
filesystem-walk to one SQL query against ``issues_current``.

Walker scope:

* Walks every numbered subdir under ``<docs>/issues/``.
* Reads ``state.txt`` (first line: state), ``meta.json`` (parses
  ``milestone`` field; nullable), ``title.md`` (first non-empty line as
  ``title``), and ``body.md`` (sha256 hashed → ``body_sha``).
* Per-entry ``valid_from``: prefers the history-entry timestamp
  (parsed from filename) when ``<n>/history/<ts>.json`` is present;
  falls back to ``state.txt`` mtime; final fallback per OQ12 is the
  git introduction-commit timestamp via
  :func:`shadow.git_log.file_introduction_timestamp`.
* ``body_source`` per OQ11+OQ12:

  - ``localstore`` for artifacts WITH a history dir (post-3.0
    canonical authoring).
  - ``pre_3_0_backfill`` for artifacts WITHOUT a history dir (walker
    fabricated the row from current state + git introduction
    timestamp).
  - ``unknown`` as final fallback when neither path produced anything
    useful (rare; surfaces operator-induced file edits the walker
    can't attribute).

* ``source_event``: ``history/<filename>`` for history-driven rows,
  ``walker_rebuild_<iso8601>`` sentinel for the synthetic
  pre-3.0-backfill row.

Per-op live emit (extends #386): ``create_issue`` / ``close_issue`` /
``update_issue_body`` / ``update_issue_milestone`` register the walker
so each ``write.completed`` event re-derives the affected issue.
Walker is cheap (single-issue scan) when called per-op; full-rebuild
runs in one pass over every numbered dir.

Effect-then-interceptor split (Rule 2): walker is pure read-effect;
INSERT is the effect side via :func:`insert_issues_fact`.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .core import _insert_bitemporal_row
from .git_log import file_introduction_timestamp
from .registry import register_op_refresh, register_table
from .types import (
    DERIVABLE,
    LOCALSTORE,
    PRE_3_0_BACKFILL,
    UNKNOWN,
    VALID_SOURCES,
)
from .views import current_view_ddl


TABLE_NAME: str = "issues_facts"
"""Canonical fact-table name. Used by the daemon's
``GET /shadow/issues_facts`` endpoint + the registry lookup."""


_ISSUES_SUBDIR: str = "issues"
"""Single docs-root subdir scanned by the walker. ``issues_facts`` is
issue-specific (the RFC's exemplar shape); discussions / pulls have
their own per-kind facts tables when those land."""


_ISSUES_COLUMNS: tuple[str, ...] = (
    "number", "state", "milestone", "title", "body_sha", "body_source",
)
"""Entity-identifier + state columns bound positionally by
:func:`insert_issues_fact`. The framework columns (``valid_from``,
``recorded_at``, ``source_event``, ``recorded_by``) get appended
inside ``_insert_bitemporal_row``."""


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS issues_facts (
      number       INTEGER NOT NULL,
      state        TEXT,
      milestone    TEXT,
      title        TEXT,
      body_sha     TEXT,
      body_source  TEXT NOT NULL,
      valid_from   TEXT NOT NULL,
      recorded_at  TEXT NOT NULL,
      source_event TEXT NOT NULL,
      recorded_by  TEXT,
      PRIMARY KEY (number, recorded_at)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_issues_valid_from "
    "ON issues_facts(number, valid_from)",
    "CREATE INDEX IF NOT EXISTS idx_issues_open "
    "ON issues_facts(state, milestone, recorded_at)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_issues_idempotent "
    "ON issues_facts(number, source_event)",
    current_view_ddl(
        TABLE_NAME,
        partition_columns=("number",),
        select_columns=(
            "number", "state", "milestone", "title",
            "body_sha", "body_source",
            "valid_from", "recorded_at",
        ),
    ),
)
"""DDL tuple registered with the shadow registry. ``CREATE … IF NOT
EXISTS`` everywhere so partial bootstraps + ``ensure_schema`` re-runs
are no-ops. The ``issues_current`` view partitions on ``number``
alone — the latest fact per canonical issue."""


# ---------------------------------------------------------------------------
# Typed insert wrapper
# ---------------------------------------------------------------------------


def insert_issues_fact(
    conn,
    *,
    number: int,
    state: str | None,
    milestone: str | None,
    title: str | None,
    body_sha: str | None,
    body_source: str,
    valid_from: str,
    recorded_at: str,
    source_event: str,
    recorded_by: str | None,
) -> bool:
    """Typed wrapper around :func:`shadow.core._insert_bitemporal_row`.

    Enforces the ``body_source`` vocabulary (OQ11) at call time — callers
    passing an unknown source string hit a ``ValueError`` before the row
    binds, so the closed vocabulary stays closed.

    Args:
        conn: sqlite3 connection (must have ``issues_facts`` table).
        number: Canonical LocalStore issue number.
        state: ``'open'`` / ``'closed'``. Nullable when the walker
            couldn't determine state.
        milestone: Milestone version string (e.g., ``'3.14.0'``);
            ``None`` for un-milestoned issues.
        title: Title text from ``title.md``'s first non-empty line.
        body_sha: sha256 hex digest of ``body.md`` content; ``None``
            when ``body.md`` is missing or unreadable.
        body_source: One of :data:`shadow.types.VALID_SOURCES`. Raises
            ``ValueError`` on unknown values.
        valid_from: ISO-8601 timestamp the fact became true in the
            world.
        recorded_at: ISO-8601 timestamp the row was written.
        source_event: ``history/<filename>`` for history-driven rows;
            ``walker_rebuild_<iso8601>`` sentinel otherwise. Combined
            with ``number`` in the idempotency UNIQUE index.
        recorded_by: session_id, or ``None`` for walker fills.

    Returns:
        ``True`` on insert; ``False`` when the UNIQUE idempotency
        index hits (per OQ13 "already applied" contract).

    Raises:
        ValueError: when ``body_source`` isn't in
            :data:`shadow.types.VALID_SOURCES`.
    """
    if body_source not in VALID_SOURCES:
        raise ValueError(
            f"insert_issues_fact: body_source {body_source!r} not in "
            f"{sorted(VALID_SOURCES)}"
        )
    return _insert_bitemporal_row(
        conn,
        table=TABLE_NAME,
        columns=_ISSUES_COLUMNS,
        values=(number, state, milestone, title, body_sha, body_source),
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=recorded_by,
    )


# ---------------------------------------------------------------------------
# Pure helpers — filesystem reads + parsers
# ---------------------------------------------------------------------------


def _iso_now() -> str:
    """Return current UTC time as an ISO-8601 string with microsecond
    precision + ``Z`` suffix.

    Microsecond precision matters because the PK includes
    ``recorded_at`` — back-to-back walks would otherwise collide and
    silently dedup. Microseconds push resolution below typical walker
    timing. Abstracted so tests can monkey-patch deterministic values.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _walker_rebuild_event(now_iso: str) -> str:
    """Compose the ``walker_rebuild_<iso8601>`` source-event sentinel.

    Pure string composition. Same shape used across every walker so
    re-walks under a new clock tick get a fresh source_event while
    same-clock walks idempotently dedupe.
    """
    return f"walker_rebuild_{now_iso}"


def _recorded_at_for_row(now_iso: str, row_index: int) -> str:
    """Compose a per-row ``recorded_at`` from the walker's base timestamp.

    The PK is ``(number, recorded_at)``; if a walker run emits multiple
    rows for distinct issues at the exact same base clock tick, the
    PK is still distinct by ``number``. But when a single issue
    contributes multiple history-derived rows in one walk we still
    need PK uniqueness — the row-index suffix keeps adjacent rows
    distinct without changing string ordering semantics.

    Pure string composition.
    """
    return f"{now_iso}#{row_index:09d}"


def _file_mtime_iso(path: Path) -> str | None:
    """Return the file's mtime as ISO-8601 UTC, or None when unreadable.

    Used as the second-tier ``valid_from`` source after history-derived
    timestamps and before the git introduction-commit fallback.
    """
    try:
        ts = path.stat().st_mtime
    except OSError:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ",
    )


def _read_state(state_path: Path) -> str | None:
    """Return the first non-empty line of ``state.txt`` as the canonical
    state.

    Returns ``None`` when the file is missing / unreadable / empty —
    walker still emits a fact row so the operator can see the
    inconsistency.
    """
    try:
        raw = state_path.read_text(encoding="utf-8")
    except OSError:
        return None
    for line in raw.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return None


def _read_meta(meta_path: Path) -> dict[str, Any]:
    """Parse ``meta.json`` to a dict; empty dict on read / parse failure.

    Walker treats a missing or malformed meta.json as an issue with no
    milestone — the fact row's ``milestone`` field lands NULL.
    """
    try:
        raw = meta_path.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _milestone_from_meta(meta: dict[str, Any]) -> str | None:
    """Extract the ``milestone`` field from a parsed meta.json dict.

    Returns ``None`` when the field is absent / null / non-string.
    Centralized so the walker can stay declarative.
    """
    value = meta.get("milestone")
    return value if isinstance(value, str) and value else None


def _read_title(title_path: Path) -> str | None:
    """Return the first non-empty line of ``title.md`` as the title.

    Returns ``None`` when the file is missing / unreadable / empty.
    The canonical store writes titles as the first line of title.md;
    walker mirrors that convention.
    """
    try:
        raw = title_path.read_text(encoding="utf-8")
    except OSError:
        return None
    for line in raw.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return None


def _body_sha256(body_path: Path) -> str | None:
    """Return sha256 hex digest of ``body.md`` content; None when absent.

    Matches the ``payload_sha`` pattern from history_log.py (#480) —
    sha256 of raw bytes (no normalization). The hash detects body
    changes across re-walks: same hash = no semantic change.
    """
    try:
        raw = body_path.read_bytes()
    except OSError:
        return None
    return hashlib.sha256(raw).hexdigest()


# ---------------------------------------------------------------------------
# History walker
# ---------------------------------------------------------------------------


def _history_entry_files(history_dir: Path) -> list[Path]:
    """Return every ``*.json`` file under ``<history_dir>/``, sorted.

    Sorted alphabetically (= chronological for compact timestamp
    prefix). Missing / non-directory ``history/`` → empty list. Pure
    read-IO.
    """
    if not history_dir.is_dir():
        return []
    return sorted(
        path for path in history_dir.iterdir()
        if path.is_file() and path.suffix == ".json"
    )


def _parse_history_filename_timestamp(filename: str) -> str | None:
    """Parse the compact ISO-8601 prefix from a history filename to ISO.

    Issue / discussion / pull history files are written by
    ``LocalStoreAdapter._append_history`` with a compact-form prefix:
    ``YYYYMMDDTHHMMSSmicrosZ-<op>.json``. This helper extracts that
    prefix and returns the normalized
    ``YYYY-MM-DDTHH:MM:SS.ffffffZ`` form for the bitemporal
    ``valid_from`` column.

    Returns ``None`` when the filename doesn't carry a recognizable
    prefix.

    Pure string parse + datetime composition. No IO. Mirrors
    :func:`shadow.history_log._parse_filename_timestamp`'s compact-form
    branch — kept as a small local helper so this module stays leaf
    rather than depending on history_log.
    """
    # 20260514T024058541549Z-close_issue.json
    if len(filename) < 16:
        return None
    head = filename[:16]
    if head[8] != "T":
        return None
    if not head[:8].isdigit() or not head[9:15].isdigit():
        return None
    rest = filename[15:]
    # Microseconds (6 digits) then Z
    if len(rest) < 7 or not rest[:6].isdigit() or rest[6] != "Z":
        return None
    try:
        dt = datetime(
            int(head[0:4]), int(head[4:6]), int(head[6:8]),
            int(head[9:11]), int(head[11:13]), int(head[13:15]),
            int(rest[:6]),
            tzinfo=timezone.utc,
        )
    except ValueError:
        return None
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _history_payload(entry_path: Path) -> dict[str, Any]:
    """Parse one history entry payload; empty dict on read / parse error.

    Pure IO + json decode.
    """
    try:
        raw = entry_path.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _state_for_history_entry(
    payload: dict[str, Any], current_state: str | None,
) -> str | None:
    """Resolve the ``state`` for a history-derived fact row.

    History payloads carry an explicit ``new_state`` field (per
    LocalStoreAdapter._append_history); walker prefers that when
    present. Falls back to ``current_state`` (the value read from
    ``state.txt``) for entries that don't model state transitions
    (e.g., ``update_issue_body`` events).
    """
    new_state = payload.get("new_state")
    if isinstance(new_state, str) and new_state:
        return new_state
    return current_state


# ---------------------------------------------------------------------------
# Per-issue walker
# ---------------------------------------------------------------------------


def _walk_issue_with_history(
    conn,
    *,
    artifact_dir: Path,
    number: int,
    state: str | None,
    milestone: str | None,
    title: str | None,
    body_sha: str | None,
    now_iso: str,
    row_index_start: int,
) -> tuple[int, int]:
    """Walk one issue's history dir and emit fact rows.

    Returns ``(inserted, next_row_index)``. One fact row per history
    entry — ``valid_from`` from the filename's timestamp prefix,
    ``source_event`` from the relative ``issues/<n>/history/<filename>``
    path, ``body_source = localstore`` (post-3.0 authoring).

    Effect — INSERT side via :func:`insert_issues_fact`.
    """
    history_dir = artifact_dir / "history"
    inserted = 0
    row_index = row_index_start
    for entry_path in _history_entry_files(history_dir):
        valid_from = _parse_history_filename_timestamp(entry_path.name)
        if valid_from is None:
            continue
        payload = _history_payload(entry_path)
        entry_state = _state_for_history_entry(payload, state)
        source_event = f"issues/{number}/history/{entry_path.name}"
        recorded_at = _recorded_at_for_row(now_iso, row_index)
        row_index += 1
        ok = insert_issues_fact(
            conn,
            number=number,
            state=entry_state,
            milestone=milestone,
            title=title,
            body_sha=body_sha,
            body_source=LOCALSTORE,
            valid_from=valid_from,
            recorded_at=recorded_at,
            source_event=source_event,
            recorded_by=None,
        )
        if ok:
            inserted += 1
    return inserted, row_index


def _resolve_pre_3_0_valid_from(
    artifact_dir: Path,
    project_root: Path | None,
) -> tuple[str, str]:
    """Resolve ``(valid_from, body_source)`` for an artifact with no
    history dir.

    Resolution order:

    1. ``state.txt`` mtime — second-tier source per the Issue body.
    2. Git introduction-commit timestamp via
       :func:`shadow.git_log.file_introduction_timestamp` for the
       artifact's ``state.txt`` — the OQ12 pre-3.0 backfill path.
       Walker tags the row ``pre_3_0_backfill``.
    3. Sentinel ``1970-01-01T00:00:00Z`` + ``unknown`` source — final
       fallback when even git can't attribute the file (operator just
       created the dir + state.txt; not tracked yet).

    The state.txt mtime path also tags ``pre_3_0_backfill`` per OQ12 —
    the absence of a history dir is what classifies the row, not the
    timestamp source. ``unknown`` is reserved for cases where the walker
    couldn't determine a valid timestamp at all.

    Pure modulo the IO inside ``stat()`` and
    :func:`file_introduction_timestamp`.
    """
    state_path = artifact_dir / "state.txt"
    mtime_iso = _file_mtime_iso(state_path)
    if mtime_iso is not None:
        return mtime_iso, PRE_3_0_BACKFILL
    if project_root is not None:
        git_ts = file_introduction_timestamp(project_root, state_path)
        if git_ts is not None:
            return git_ts, PRE_3_0_BACKFILL
    return "1970-01-01T00:00:00Z", UNKNOWN


def _walk_issue_pre_3_0(
    conn,
    *,
    artifact_dir: Path,
    project_root: Path | None,
    number: int,
    state: str | None,
    milestone: str | None,
    title: str | None,
    body_sha: str | None,
    now_iso: str,
    row_index_start: int,
) -> tuple[int, int]:
    """Walk one issue with no history dir; emit a single backfill row.

    Returns ``(inserted, next_row_index)``. Tags the row
    ``body_source = pre_3_0_backfill`` (or ``unknown`` when even git
    can't supply a timestamp).

    Effect — INSERT side via :func:`insert_issues_fact`.
    """
    valid_from, body_source = _resolve_pre_3_0_valid_from(
        artifact_dir, project_root,
    )
    source_event = (
        f"walker_rebuild_{now_iso}_pre_3_0_issues_{number}"
    )
    recorded_at = _recorded_at_for_row(now_iso, row_index_start)
    ok = insert_issues_fact(
        conn,
        number=number,
        state=state,
        milestone=milestone,
        title=title,
        body_sha=body_sha,
        body_source=body_source,
        valid_from=valid_from,
        recorded_at=recorded_at,
        source_event=source_event,
        recorded_by=None,
    )
    return (1 if ok else 0), row_index_start + 1


def _iter_issue_dirs(docs_root: Path) -> Iterable[tuple[int, Path]]:
    """Yield ``(number, artifact_dir)`` for every numeric subdir under
    ``<docs_root>/issues/``.

    Mirrors :func:`shadow.labels._iter_artifact_dirs` — non-numeric
    names (README.md, .gitignore, …) skip. Sorted by integer value
    for deterministic walker ordering.

    Pure read-IO.
    """
    base = docs_root / _ISSUES_SUBDIR
    if not base.is_dir():
        return
    entries: list[tuple[int, Path]] = []
    for entry in base.iterdir():
        if not entry.is_dir():
            continue
        if not entry.name.isdigit():
            continue
        entries.append((int(entry.name), entry))
    entries.sort(key=lambda pair: pair[0])
    yield from entries


def _walk_one_issue(
    conn,
    *,
    artifact_dir: Path,
    project_root: Path | None,
    number: int,
    now_iso: str,
    row_index: int,
) -> tuple[int, int]:
    """Walk a single issue dir and emit its fact row(s).

    Dispatches to either the history-driven path (when ``history/``
    exists) or the pre-3.0 backfill path (when it doesn't). Both
    share the same state / milestone / title / body_sha read pass.

    Returns ``(inserted, next_row_index)``.
    """
    state = _read_state(artifact_dir / "state.txt")
    meta = _read_meta(artifact_dir / "meta.json")
    milestone = _milestone_from_meta(meta)
    title = _read_title(artifact_dir / "title.md")
    body_sha = _body_sha256(artifact_dir / "body.md")
    history_dir = artifact_dir / "history"
    if history_dir.is_dir():
        return _walk_issue_with_history(
            conn,
            artifact_dir=artifact_dir,
            number=number,
            state=state,
            milestone=milestone,
            title=title,
            body_sha=body_sha,
            now_iso=now_iso,
            row_index_start=row_index,
        )
    return _walk_issue_pre_3_0(
        conn,
        artifact_dir=artifact_dir,
        project_root=project_root,
        number=number,
        state=state,
        milestone=milestone,
        title=title,
        body_sha=body_sha,
        now_iso=now_iso,
        row_index_start=row_index,
    )


def walk_issues(conn, ctx: dict[str, Any]) -> int:
    """Walker entry point — repopulates ``issues_facts`` from canonical.

    Called by :func:`shadow.migration.rebuild_derivable_tables` (drift
    rebuild path) and :func:`daemon.action_log.refresh_shadow_for_op`
    (per-op refresh path) with a context dict carrying the docs root +
    project root.

    Args:
        conn: sqlite3 connection (must have ``issues_facts`` + the
            ``issues_current`` view).
        ctx: Walker context dict. Recognized keys:

            * ``"docs_root"`` — :class:`Path` to the canonical store.
              Required; ``None``/missing → zero rows.
            * ``"project_root"`` — :class:`Path` to the project's git
              working tree, used for the OQ12 pre-3.0 backfill via
              :func:`shadow.git_log.file_introduction_timestamp`.
              Optional; absence skips the git fallback (sentinel
              ``1970-…`` + ``body_source = 'unknown'`` takes over).

    Returns:
        Total fact rows INSERTed. Idempotency-hits don't count.

    Effect — issues INSERTs against ``conn``. Caller controls commit.
    """
    docs_root = ctx.get("docs_root")
    if docs_root is None:
        return 0
    if not isinstance(docs_root, Path):
        docs_root = Path(docs_root)
    project_root = ctx.get("project_root")
    if project_root is not None and not isinstance(project_root, Path):
        project_root = Path(project_root)
    now_iso = _iso_now()
    total = 0
    row_index = 0
    for number, artifact_dir in _iter_issue_dirs(docs_root):
        delta, row_index = _walk_one_issue(
            conn,
            artifact_dir=artifact_dir,
            project_root=project_root,
            number=number,
            now_iso=now_iso,
            row_index=row_index,
        )
        total += delta
    return total


# ---------------------------------------------------------------------------
# Registry wiring
# ---------------------------------------------------------------------------


def register() -> None:
    """Register ``issues_facts`` with the shadow registry + per-op map.

    Idempotent — re-registration overwrites the previous entry per
    :func:`shadow.registry.register_table`'s contract. Called by
    :func:`shadow.register_all` at daemon startup.

    Per-op refresh wiring: the canonical-write ops the Issue body lists
    (``create_issue`` / ``close_issue`` / ``update_issue_body`` /
    ``update_issue_milestone``) re-trigger the walker for the affected
    artifact. Walker reads the full canonical store, so registration is
    conservative — any op that COULD change issue state registers.
    """
    register_table(
        TABLE_NAME,
        ddl=SCHEMA_DDL,
        classification=DERIVABLE,
        walker_fn=walk_issues,
    )
    for op_name in (
        "create_issue",
        "close_issue",
        "update_issue_body",
        "update_issue_milestone",
    ):
        register_op_refresh(op_name, (TABLE_NAME,))
