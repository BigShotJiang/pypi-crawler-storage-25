"""Typed write helpers for the Issues canonical-DB table (3.15.0 cluster A.2.1).

Per Discussion #23 (3.15.0 plan-Discussion). A.2 migrates the write
path from filesystem-canonical to DB-canonical. This module ships
the per-entity SQL-composition layer for Issues — pure functions
that take a sqlite connection + typed inputs and execute the right
INSERT / UPDATE / DELETE statements.

Effects-then-interceptor split per Rule 2 / Rule 10: each function
issues exactly one conn.execute (or two for atomic update+select)
and returns the typed result. No commit() — the caller owns
transaction boundaries (matches the shadow.core insert helper's
convention).

For the both-authoritative window (OQ8), these helpers are invoked
by the daemon's /writes endpoint AFTER the existing filesystem
canonical write succeeds. Both surfaces hold the same data until
A.4 (filesystem regenerator) ships and the cut to DB-canonical
completes.

Numbering per OQ28: callers fetch ``next_issue_number(conn)`` for
new Issues; existing-number-preserving inserts pass the existing
number. The function rejects collisions via the PK constraint.

Function inventory:

* :func:`insert_issue` — create a new row; raises on duplicate
  number.
* :func:`update_issue_state` — flip open ↔ closed (with optional
  state_reason + closed_at).
* :func:`update_issue_body` — replace body markdown.
* :func:`update_issue_milestone` — set/clear milestone reference.
* :func:`add_issue_label` — INSERT INTO issue_labels.
* :func:`remove_issue_label` — DELETE FROM issue_labels.
* :func:`delete_issue` — DELETE (cascades to issue_labels).
* :func:`select_issue` — read by number (for the both-authoritative
  read-fallback path per OQ8).
* :func:`list_issue_labels` — read labels for an issue.
* :func:`next_issue_number` — ``MAX(number) + 1`` for new inserts.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_issue(
    conn: sqlite3.Connection,
    *,
    number: int,
    title: str,
    state: str,
    created_at: str,
    updated_at: str,
    body: str = "",
    state_reason: str | None = None,
    milestone: str | None = None,
    author: str = "",
    url: str = "",
    closed_at: str | None = None,
) -> None:
    """Insert one row into ``issues``.

    Raises ``sqlite3.IntegrityError`` on:

    * Duplicate ``number`` (PK collision).
    * Invalid ``state`` (CHECK constraint — must be open|closed).
    * Invalid ``state_reason`` (CHECK — completed|not_planned|NULL).
    * NULL ``title`` (NOT NULL).

    The function does not commit. Caller composes the transaction.
    """
    conn.execute(
        """
        INSERT INTO issues (
          number, title, body, state, state_reason,
          milestone, author, url, created_at, closed_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            number, title, body, state, state_reason,
            milestone, author, url, created_at, closed_at, updated_at,
        ),
    )


def update_issue_state(
    conn: sqlite3.Connection,
    *,
    number: int,
    state: str,
    updated_at: str,
    state_reason: str | None = None,
    closed_at: str | None = None,
) -> int:
    """Update an issue's state + state_reason + closed_at.

    Returns the number of rows affected (0 = no such issue, 1 =
    updated). Per the CHECK constraints, ``state`` must be open|closed
    and ``state_reason`` must be completed|not_planned|NULL.

    Convention for callers:

    * Re-opening: ``state='open'``, ``state_reason=None``,
      ``closed_at=None``.
    * Closing as completed: ``state='closed'``,
      ``state_reason='completed'``, ``closed_at=<iso8601>``.
    * Closing as not_planned: ``state='closed'``,
      ``state_reason='not_planned'``, ``closed_at=<iso8601>``.
    """
    cursor = conn.execute(
        """
        UPDATE issues
           SET state = ?, state_reason = ?, closed_at = ?, updated_at = ?
         WHERE number = ?
        """,
        (state, state_reason, closed_at, updated_at, number),
    )
    return cursor.rowcount


def update_issue_body(
    conn: sqlite3.Connection,
    *,
    number: int,
    body: str,
    updated_at: str,
) -> int:
    """Update an issue's body markdown. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE issues SET body = ?, updated_at = ? WHERE number = ?",
        (body, updated_at, number),
    )
    return cursor.rowcount


def update_issue_milestone(
    conn: sqlite3.Connection,
    *,
    number: int,
    milestone: str | None,
    updated_at: str,
) -> int:
    """Set or clear an issue's milestone reference. Returns rowcount.

    Passing ``milestone=None`` clears the assignment. The column is
    TEXT (no FK in A.1.2 because milestones table lands A.1.4 —
    by A.2 both tables exist but the FK isn't added; write-path
    validates referenced milestone existence if desired).
    """
    cursor = conn.execute(
        "UPDATE issues SET milestone = ?, updated_at = ? WHERE number = ?",
        (milestone, updated_at, number),
    )
    return cursor.rowcount


def add_issue_label(
    conn: sqlite3.Connection,
    *,
    number: int,
    label: str,
) -> bool:
    """Add a label to an issue.

    Returns ``True`` if the label was added; ``False`` if the
    ``(number, label)`` pair already exists (idempotent on
    duplicate). Raises ``sqlite3.IntegrityError`` on FK violation
    (issue number doesn't exist).
    """
    try:
        conn.execute(
            "INSERT INTO issue_labels (issue_number, label) VALUES (?, ?)",
            (number, label),
        )
    except sqlite3.IntegrityError as exc:
        # Differentiate duplicate-label (PK) from missing-issue (FK).
        msg = str(exc).upper()
        if "FOREIGN KEY" in msg:
            raise
        # PK collision — already present. Idempotent success.
        return False
    return True


def remove_issue_label(
    conn: sqlite3.Connection,
    *,
    number: int,
    label: str,
) -> int:
    """Remove a label from an issue. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM issue_labels WHERE issue_number = ? AND label = ?",
        (number, label),
    )
    return cursor.rowcount


def delete_issue(conn: sqlite3.Connection, *, number: int) -> int:
    """Delete an issue. Cascades to issue_labels per the FK. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM issues WHERE number = ?",
        (number,),
    )
    return cursor.rowcount


def select_issue(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> dict[str, Any] | None:
    """Read an issue by number. Returns dict of columns or ``None``.

    Used by the both-authoritative window's read-fallback path
    (OQ8): callers check the DB first; on None, fall back to
    filesystem.
    """
    row = conn.execute(
        """
        SELECT number, title, body, state, state_reason,
               milestone, author, url, created_at, closed_at, updated_at
          FROM issues
         WHERE number = ?
        """,
        (number,),
    ).fetchone()
    if row is None:
        return None
    return {
        "number": row[0], "title": row[1], "body": row[2],
        "state": row[3], "state_reason": row[4], "milestone": row[5],
        "author": row[6], "url": row[7], "created_at": row[8],
        "closed_at": row[9], "updated_at": row[10],
    }


def list_issue_labels(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> list[str]:
    """Return labels on an issue, sorted. Empty list when no labels
    or no such issue.
    """
    rows = conn.execute(
        "SELECT label FROM issue_labels WHERE issue_number = ? ORDER BY label",
        (number,),
    ).fetchall()
    return [row[0] for row in rows]


def next_issue_number(conn: sqlite3.Connection) -> int:
    """Return the next available issue number per OQ28.

    ``MAX(number) + 1``; returns 1 on an empty table. Caller passes
    the result to :func:`insert_issue` for new issues. Existing-number
    preservation (backfill walker) bypasses this function and inserts
    with the existing number directly.

    Concurrency note: this is single-writer-safe under sqlite's
    serialized writes. The canonical-DB layer is single-writer by
    design (daemon owns the connection); the function is not safe
    against concurrent writers if that contract changes.
    """
    row = conn.execute("SELECT MAX(number) FROM issues").fetchone()
    return 1 if row[0] is None else int(row[0]) + 1
