"""Canonical-DB schema for Sessions (3.15.0 cluster A.1.7).

Per Discussion #23 (3.15.0 plan-Discussion). Sessions are time-
anchored work units; the canonical filesystem store places them at
``<docs>/sessions/<session_id>/*.json``. This table tracks
session-level state; per-event records live in
:mod:`forge_manager_mcp.daemon.action_log` (3.6.0 D4) and the
shadow ``history_log_facts`` table (3.14.0 #480) — those are
derived from the canonical write events.

Schema design notes:

* **session_id is TEXT PK.** A hex string (e.g.
  ``7259e54287626136``) minted by ``open_session``. No invented
  numbering — the session_id is the natural identifier.

* **opened_at / closed_at.** ``closed_at`` is NULL while the
  session is open; set at ``close_session`` time. Index supports
  "find open sessions" via ``WHERE closed_at IS NULL``.

* **prior_session_clean as INTEGER (0/1).** Records whether the
  prior session closed cleanly (mirrors ``open_session``'s
  ``prior_session_clean`` return field). Default 1 for greenfield
  bootstraps.

* **summary TEXT.** Populated at close_session time by either the
  server-composed default (#62) or the operator-supplied summary.
  Empty string while the session is open.

* **No event log here.** The per-turn / per-write event history
  lives in the daemon's action_log + shadow's history_log_facts.
  Sessions table is the session-level rollup.
"""
from __future__ import annotations

from .registry import register_table


_SESSIONS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS sessions (
      session_id TEXT PRIMARY KEY,
      opened_at TEXT NOT NULL,
      closed_at TEXT,
      prior_session_clean INTEGER NOT NULL DEFAULT 1
        CHECK (prior_session_clean IN (0, 1)),
      summary TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sessions_opened_at ON sessions(opened_at)",
    "CREATE INDEX IF NOT EXISTS idx_sessions_closed_at ON sessions(closed_at)",
)


def register() -> None:
    """Register the sessions table."""
    register_table("sessions", ddl=_SESSIONS_DDL)
