"""Typed write helpers for Comments (3.15.0 cluster A.2.5).

Per Discussion #23. Polymorphic parent via (parent_kind,
parent_number) + optional self-FK parent_id for threading. id is
auto-increment PK — :func:`insert_comment` returns it.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_comment(
    conn: sqlite3.Connection,
    *,
    parent_kind: str,
    parent_number: int,
    body: str,
    created_at: str,
    updated_at: str,
    parent_id: int | None = None,
    author: str = "",
    url: str = "",
) -> int:
    """Insert a comment row and return the new id.

    Raises ``sqlite3.IntegrityError`` on invalid parent_kind (CHECK:
    issue|discussion) or parent_id FK violation. The write-path is
    responsible for validating parent_number references a real
    artifact (SQL can't enforce polymorphic FKs).
    """
    cursor = conn.execute(
        """
        INSERT INTO comments (
          parent_kind, parent_number, parent_id,
          author, body, url, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            parent_kind, parent_number, parent_id,
            author, body, url, created_at, updated_at,
        ),
    )
    return int(cursor.lastrowid)


def update_comment_body(
    conn: sqlite3.Connection,
    *,
    id: int,
    body: str,
    updated_at: str,
) -> int:
    """Replace comment body markdown. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE comments SET body = ?, updated_at = ? WHERE id = ?",
        (body, updated_at, id),
    )
    return cursor.rowcount


def delete_comment(conn: sqlite3.Connection, *, id: int) -> int:
    """Delete a comment. Cascades to replies via parent_id FK. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM comments WHERE id = ?",
        (id,),
    )
    return cursor.rowcount


def select_comment(
    conn: sqlite3.Connection,
    *,
    id: int,
) -> dict[str, Any] | None:
    """Read a comment by id. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT id, parent_kind, parent_number, parent_id,
               author, body, url, created_at, updated_at
          FROM comments
         WHERE id = ?
        """,
        (id,),
    ).fetchone()
    if row is None:
        return None
    return {
        "id": row[0], "parent_kind": row[1],
        "parent_number": row[2], "parent_id": row[3],
        "author": row[4], "body": row[5], "url": row[6],
        "created_at": row[7], "updated_at": row[8],
    }


def list_comments_on(
    conn: sqlite3.Connection,
    *,
    parent_kind: str,
    parent_number: int,
) -> list[dict[str, Any]]:
    """Return all comments on an artifact, sorted by created_at."""
    rows = conn.execute(
        """
        SELECT id, parent_id, author, body, url, created_at, updated_at
          FROM comments
         WHERE parent_kind = ? AND parent_number = ?
         ORDER BY created_at, id
        """,
        (parent_kind, parent_number),
    ).fetchall()
    return [
        {
            "id": r[0], "parent_id": r[1], "author": r[2],
            "body": r[3], "url": r[4],
            "created_at": r[5], "updated_at": r[6],
        }
        for r in rows
    ]


def list_replies_to(
    conn: sqlite3.Connection,
    *,
    parent_id: int,
) -> list[dict[str, Any]]:
    """Return direct replies to a comment, sorted by created_at."""
    rows = conn.execute(
        """
        SELECT id, author, body, created_at, updated_at
          FROM comments
         WHERE parent_id = ?
         ORDER BY created_at, id
        """,
        (parent_id,),
    ).fetchall()
    return [
        {
            "id": r[0], "author": r[1], "body": r[2],
            "created_at": r[3], "updated_at": r[4],
        }
        for r in rows
    ]
