"""Canonical-DB authoritative-state tables (3.15.0 cluster A.1 framework).

Per Discussion #23 (3.15.0 plan-Discussion / canonical-DB cut RFC).
Lifts authority from filesystem to SQL. This package ships the
framework + per-entity schemas (issues / issue_labels / discussions /
discussion_labels / milestones / plans / comments / sessions / gaps /
artifact_history) registered with :mod:`canonical_db.registry` at
import time.

* DB file location per OQ1: ``<docs_repo>/.forge-manager.db``.
* Schema versioning per OQ2: independent of skill semver, bumped at
  milestone cuts. ``SCHEMA_VERSION = 1`` introduced 3.15.0.
* Numbering per OQ28: per-entity tables preserve existing
  filesystem numbers; new entities pick up at ``max(existing) + 1``.

Distinct from :mod:`forge_manager_mcp.shadow` — that package's
``user_version`` (currently 11) lives in the daemon's sqlite file
and tracks the bitemporal derived-fact layer. Canonical-DB has its
own DB file with its own ``user_version`` starting at 1.

Per OQ4, :class:`LocalStoreAdapter` stays read-only post-cut for
regenerator + DR + debugging. This package is purely additive
during the A.1 / A.2 / A.3 transition window per OQ8's
both-authoritative contract.

Per-entity registration: each entity module's import-time body
calls :func:`canonical_db.registry.register_table`. The framework
exposes :func:`register_all` (below) for production callers to
trigger every per-entity registration in one place — avoids forcing
every leaf ``canonical_db_*`` py_library to carry a transitive dep
on every per-entity module (Test Dep-Graph Discipline #72).

Mirrors the :mod:`forge_manager_mcp.shadow` framework's
``register_all`` pattern. Tests get isolation via
:func:`canonical_db.registry.reset_for_testing` + targeted
``register_table`` calls; production daemon startup invokes
``register_all`` once before ``ensure_initialized``.
"""
from __future__ import annotations


def register_all() -> None:
    """Register every per-entity canonical-DB module with the registry.

    Called by daemon startup (A.2.N hookup) so the registry is
    populated before :func:`canonical_db.core.ensure_initialized`
    runs. Each per-entity module registers its DDL via top-level
    ``register_table`` calls when imported — late imports here
    ensure idempotent registration (repeat calls overwrite the
    previous entry per the registry contract).

    Late imports keep the per-entity dep out of the leaf
    ``canonical_db_*`` library closures (Test Dep-Graph Discipline
    #72) — ``canonical_db_core`` / ``canonical_db_registry`` tests
    stay fast because they don't transitively pull every entity
    module.
    """
    # A.1.2 through A.1.9 — cluster A.1 entity registrations.
    from . import (
        comments,
        discussions,
        gaps,
        history,
        issues,
        milestones,
        plans,
        sessions,
    )
    issues.register()
    discussions.register()
    milestones.register()
    plans.register()
    comments.register()
    sessions.register()
    gaps.register()
    history.register()
