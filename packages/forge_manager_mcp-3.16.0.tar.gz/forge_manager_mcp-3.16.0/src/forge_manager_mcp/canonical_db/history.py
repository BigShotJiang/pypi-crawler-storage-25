"""Canonical-DB schema for History (3.15.0 cluster A.1.9).

Per Discussion #23 (3.15.0 plan-Discussion). Mirrors the
filesystem ``<artifact>/history/<ts>.json`` append-only convention
(3.0.0 Phase 6 / #270) as a flat insert-only DB table. Each row
records one mutation event against a canonical artifact.

Schema design notes:

* **Auto-increment id PK.** History rows have no human-meaningful
  number — they're a time-ordered log.

* **Polymorphic artifact reference.** ``artifact_kind`` CHECK
  constrained to the canonical entity vocabulary. ``artifact_id``
  carries the string representation of the artifact's PK
  (``number`` as text for Issues/Discussions/Plans/Gaps,
  ``version`` for Milestones, ``session_id`` for Sessions,
  ``id`` for Comments).

* **operation column.** The mutation kind — ``create`` /
  ``update_state`` / ``update_body`` / ``add_label`` /
  ``remove_label`` / ``add_comment`` / ``close`` / etc. Open
  vocabulary at SQL layer (operations come from the write path);
  validation lives at the write-path layer in A.2.

* **payload TEXT.** JSON-serialized payload of the change.
  Captures what changed (e.g. ``{"from": "open", "to": "closed"}``
  for an update_state operation). Empty string for operations
  without payload.

* **Insert-only.** No UPDATE / DELETE expected. The table is the
  immutable audit log. The shadow ``history_log_facts`` walker
  (#480) reads this AND the filesystem (during transition)
  to populate the bitemporal fact tables.

* **Indexes on (artifact_kind, artifact_id) + recorded_at.**
  Fast lookup of "history of artifact X" plus chronological
  filter.
"""
from __future__ import annotations

from .registry import register_table


_HISTORY_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS artifact_history (
      id INTEGER PRIMARY KEY,
      artifact_kind TEXT NOT NULL CHECK (artifact_kind IN (
        'issue', 'discussion', 'milestone', 'plan',
        'comment', 'gap', 'session'
      )),
      artifact_id TEXT NOT NULL,
      operation TEXT NOT NULL,
      payload TEXT NOT NULL DEFAULT '',
      actor TEXT NOT NULL DEFAULT '',
      session_id TEXT
        REFERENCES sessions(session_id) ON DELETE SET NULL,
      recorded_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_history_artifact "
    "ON artifact_history(artifact_kind, artifact_id)",
    "CREATE INDEX IF NOT EXISTS idx_history_operation "
    "ON artifact_history(operation)",
    "CREATE INDEX IF NOT EXISTS idx_history_session_id "
    "ON artifact_history(session_id)",
    "CREATE INDEX IF NOT EXISTS idx_history_recorded_at "
    "ON artifact_history(recorded_at)",
)


def register() -> None:
    """Register the artifact_history table."""
    register_table("artifact_history", ddl=_HISTORY_DDL)
