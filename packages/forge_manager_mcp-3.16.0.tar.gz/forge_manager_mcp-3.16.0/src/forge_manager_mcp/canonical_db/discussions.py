"""Canonical-DB schema for Discussions (3.15.0 cluster A.1.3).

Per Discussion #23 (3.15.0 plan-Discussion). Registers the
``discussions`` + ``discussion_labels`` tables. Schema-only per
OQ8 scope of A.1; insert/read helpers land in A.2.

Schema design notes:

* **Number is the primary key.** Per OQ28, preserves filesystem
  numbering. Distinct namespace from issues — the canonical store
  has separate counters for ``<docs>/issues/<n>/`` and
  ``<docs>/discussions/<n>/``.

* **Category as TEXT.** Project category vocabulary —
  ``Architecture`` / ``UX/UI`` / ``Ideas`` / ``Claude-use-only`` /
  ``General`` / ``Announcements`` — but the canonical-DB does not
  enforce the closed set at the SQL layer. Categories evolve per
  project (project-rules.md can extend); a CHECK constraint here
  would lock the schema to the skill's default set. Validation
  happens at the write-path layer in A.2.

* **Decided as INTEGER (0/1).** sqlite has no native boolean.
  Convention: 0 = undecided, 1 = decided. Encoded as INTEGER for
  index efficiency and explicit-int semantics. Matches the
  multi-axis ``state.txt`` resolution-axis vocabulary (#22 OQ4
  era).

* **No state_reason on Discussions.** Issues have completed /
  not_planned closure semantics; Discussions just open / closed
  (the resolution axis is captured separately by ``decided``).

* **Labels normalized.** ``discussion_labels`` join table mirrors
  ``issue_labels``. Same vocabulary (kind:* / category:* / etc.).
"""
from __future__ import annotations

from .registry import register_table


_DISCUSSIONS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS discussions (
      number INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      state TEXT NOT NULL CHECK (state IN ('open', 'closed')),
      category TEXT,
      decided INTEGER NOT NULL DEFAULT 0
        CHECK (decided IN (0, 1)),
      author TEXT NOT NULL DEFAULT '',
      url TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_discussions_state ON discussions(state)",
    "CREATE INDEX IF NOT EXISTS idx_discussions_category "
    "ON discussions(category)",
    "CREATE INDEX IF NOT EXISTS idx_discussions_decided "
    "ON discussions(decided)",
    "CREATE INDEX IF NOT EXISTS idx_discussions_updated_at "
    "ON discussions(updated_at)",
)


_DISCUSSION_LABELS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS discussion_labels (
      discussion_number INTEGER NOT NULL
        REFERENCES discussions(number) ON DELETE CASCADE,
      label TEXT NOT NULL,
      PRIMARY KEY (discussion_number, label)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_discussion_labels_label "
    "ON discussion_labels(label)",
)


def register() -> None:
    """Register both discussions + discussion_labels tables."""
    register_table("discussions", ddl=_DISCUSSIONS_DDL)
    register_table("discussion_labels", ddl=_DISCUSSION_LABELS_DDL)
