"""Canonical-DB schema for Issues (3.15.0 cluster A.1.2).

Per Discussion #23 (3.15.0 plan-Discussion / canonical-DB cut RFC).
Registers the ``issues`` + ``issue_labels`` tables with the
canonical-DB framework registry at import time. A.1 is strictly
schema-only; typed insert / read / update helpers ship in A.2
(write-path migration).

Schema design notes:

* **Number is the primary key.** Per OQ28, canonical-DB preserves
  existing filesystem Issue numbers. The backfill walker
  (A.8 — separate from A.1) reads ``<docs>/issues/<n>/*`` and
  inserts each row with its existing ``number``. New Issues filed
  post-A.2 sequence from ``max(existing) + 1`` via the write path's
  explicit max-query (sqlite's ``AUTOINCREMENT`` is correct under
  single-writer; the canonical-DB layer is single-writer per
  process per the daemon-owned write path).

* **Labels normalized into a join table.** ``issue_labels`` carries
  one row per (issue, label) pair. Allows efficient
  ``WHERE label = 'area:ui'`` queries and avoids serialization
  ambiguity that LIKE-on-JSON-array would introduce. The shadow
  layer's ``labels_facts`` (#476) tracks label transitions
  bitemporally; ``issue_labels`` is current-state-only.

* **No FK to milestones in A.1.2.** The ``milestone`` column is
  ``TEXT`` (the version string). The ``milestones`` table lands in
  A.1.4. A.1.2 deliberately does not add the FK constraint because
  registration order is alphabetical and ``issue_labels`` and
  ``issues`` already register before ``milestones``. Adding the FK
  in A.1.4 (or later) is one ALTER TABLE migration if needed.

* **State + state_reason CHECK constraints.** Encode the protocol
  vocabulary at the schema layer. ``state`` is
  ``'open'`` / ``'closed'``; ``state_reason`` is
  ``'completed'`` / ``'not_planned'`` or NULL.

* **Timestamps as ISO-8601 UTC TEXT.** sqlite has no native
  datetime; convention is ISO-8601 UTC strings ending in ``Z`` or
  ``+00:00``. Matches the shadow layer + the existing
  filesystem-stored timestamps in ``history/<ts>.json`` filenames.
"""
from __future__ import annotations

from .registry import register_table


_ISSUES_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS issues (
      number INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      state TEXT NOT NULL CHECK (state IN ('open', 'closed')),
      state_reason TEXT CHECK (
        state_reason IS NULL OR
        state_reason IN ('completed', 'not_planned')
      ),
      milestone TEXT,
      author TEXT NOT NULL DEFAULT '',
      url TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      closed_at TEXT,
      updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_issues_state ON issues(state)",
    "CREATE INDEX IF NOT EXISTS idx_issues_milestone ON issues(milestone)",
    "CREATE INDEX IF NOT EXISTS idx_issues_updated_at ON issues(updated_at)",
)


_ISSUE_LABELS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS issue_labels (
      issue_number INTEGER NOT NULL
        REFERENCES issues(number) ON DELETE CASCADE,
      label TEXT NOT NULL,
      PRIMARY KEY (issue_number, label)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_issue_labels_label ON issue_labels(label)",
)


def register() -> None:
    """Register both issues + issue_labels tables.

    Invoked by :func:`canonical_db.register_all` at daemon startup.
    Direct call from tests is fine too — idempotent per the registry
    contract (repeated registration overwrites).
    """
    register_table("issues", ddl=_ISSUES_DDL)
    register_table("issue_labels", ddl=_ISSUE_LABELS_DDL)
