"""Typed write helpers for the Discussions canonical-DB table (A.2.2).

Per Discussion #23 (3.15.0 plan-Discussion). Mirrors
:mod:`canonical_db.issues_writes` for Discussions + discussion_labels.

Differences from issues_writes:

* No ``state_reason`` (Discussions just open/closed; resolution
  captured separately by ``decided``).
* ``decided`` boolean as INTEGER 0/1 — separate update helper.
* ``category`` open-vocabulary TEXT — separate update helper.

Function inventory mirrors issues_writes shape: insert_discussion,
update_discussion_state, update_discussion_decided,
update_discussion_category, update_discussion_body,
add_discussion_label, remove_discussion_label, delete_discussion,
select_discussion, list_discussion_labels, next_discussion_number.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_discussion(
    conn: sqlite3.Connection,
    *,
    number: int,
    title: str,
    state: str,
    created_at: str,
    updated_at: str,
    body: str = "",
    category: str | None = None,
    decided: int = 0,
    author: str = "",
    url: str = "",
) -> None:
    """Insert one row into ``discussions``.

    Raises ``sqlite3.IntegrityError`` on:

    * Duplicate ``number`` (PK collision).
    * Invalid ``state`` (CHECK — must be open|closed).
    * ``decided`` not in {0, 1} (CHECK).
    """
    conn.execute(
        """
        INSERT INTO discussions (
          number, title, body, state, category, decided,
          author, url, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            number, title, body, state, category, decided,
            author, url, created_at, updated_at,
        ),
    )


def update_discussion_state(
    conn: sqlite3.Connection,
    *,
    number: int,
    state: str,
    updated_at: str,
) -> int:
    """Flip lifecycle open ↔ closed. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE discussions SET state = ?, updated_at = ? WHERE number = ?",
        (state, updated_at, number),
    )
    return cursor.rowcount


def update_discussion_decided(
    conn: sqlite3.Connection,
    *,
    number: int,
    decided: int,
    updated_at: str,
) -> int:
    """Set the ``decided`` resolution flag (0 or 1). Returns rowcount."""
    cursor = conn.execute(
        "UPDATE discussions SET decided = ?, updated_at = ? WHERE number = ?",
        (decided, updated_at, number),
    )
    return cursor.rowcount


def update_discussion_category(
    conn: sqlite3.Connection,
    *,
    number: int,
    category: str | None,
    updated_at: str,
) -> int:
    """Set or clear the category TEXT field. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE discussions SET category = ?, updated_at = ? "
        "WHERE number = ?",
        (category, updated_at, number),
    )
    return cursor.rowcount


def update_discussion_body(
    conn: sqlite3.Connection,
    *,
    number: int,
    body: str,
    updated_at: str,
) -> int:
    """Replace body markdown. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE discussions SET body = ?, updated_at = ? WHERE number = ?",
        (body, updated_at, number),
    )
    return cursor.rowcount


def add_discussion_label(
    conn: sqlite3.Connection,
    *,
    number: int,
    label: str,
) -> bool:
    """Add a label. Returns True on add, False on already-present."""
    try:
        conn.execute(
            "INSERT INTO discussion_labels "
            "(discussion_number, label) VALUES (?, ?)",
            (number, label),
        )
    except sqlite3.IntegrityError as exc:
        if "FOREIGN KEY" in str(exc).upper():
            raise
        return False
    return True


def remove_discussion_label(
    conn: sqlite3.Connection,
    *,
    number: int,
    label: str,
) -> int:
    """Remove a label. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM discussion_labels "
        "WHERE discussion_number = ? AND label = ?",
        (number, label),
    )
    return cursor.rowcount


def delete_discussion(conn: sqlite3.Connection, *, number: int) -> int:
    """Delete a discussion. Cascades to discussion_labels. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM discussions WHERE number = ?",
        (number,),
    )
    return cursor.rowcount


def select_discussion(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> dict[str, Any] | None:
    """Read a discussion by number. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT number, title, body, state, category, decided,
               author, url, created_at, updated_at
          FROM discussions
         WHERE number = ?
        """,
        (number,),
    ).fetchone()
    if row is None:
        return None
    return {
        "number": row[0], "title": row[1], "body": row[2],
        "state": row[3], "category": row[4], "decided": row[5],
        "author": row[6], "url": row[7],
        "created_at": row[8], "updated_at": row[9],
    }


def list_discussion_labels(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> list[str]:
    """Return labels on a discussion, sorted."""
    rows = conn.execute(
        "SELECT label FROM discussion_labels "
        "WHERE discussion_number = ? ORDER BY label",
        (number,),
    ).fetchall()
    return [row[0] for row in rows]


def next_discussion_number(conn: sqlite3.Connection) -> int:
    """Return next available discussion number per OQ28."""
    row = conn.execute("SELECT MAX(number) FROM discussions").fetchone()
    return 1 if row[0] is None else int(row[0]) + 1
