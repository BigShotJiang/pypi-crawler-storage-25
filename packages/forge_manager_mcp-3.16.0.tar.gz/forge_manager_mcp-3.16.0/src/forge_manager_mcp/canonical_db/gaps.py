"""Canonical-DB schema for Gaps (3.15.0 cluster A.1.8).

Per Discussion #23 (3.15.0 plan-Discussion). Gaps are surfaced by
the analyze_gaps detectors (3.11.0 D1.b / #405): test_coverage_gap,
acceptance_unmet_gap, capability_gap, security_gap, usability_gap,
stale_milestone_plan_gap, registry_coverage_gap. Each gap is a
compound-doc artifact with a four-state lifecycle.

Schema design notes:

* **Number is the primary key.** Filesystem layout is
  ``<docs>/gaps/<n>/`` keyed by sequential number per OQ28.

* **Four-state lifecycle.** Per #405 state machine:
  ``triage`` / ``accepted`` / ``filed`` / ``ignored``. CHECK
  constraint enforces closure.
  - triage: detector surfaced; awaiting operator decision.
  - accepted: operator wants this; not yet filed as Issue.
  - filed: an Issue has been created (filed_issue_number set).
  - ignored: operator decided no action.

* **Detector vocabulary.** ``detector`` column carries the name of
  the gap-analysis detector that produced the row. Open vocabulary
  at SQL layer (detectors come from the gap_analysis registry);
  validation lives at the write-path layer.

* **Severity.** Three-level ``info`` / ``warn`` / ``fail`` per
  the existing gates.yaml severity convention.

* **filed_issue_number FK.** Set when state transitions to
  ``filed``. ON DELETE SET NULL so deleting the Issue doesn't
  cascade-delete the gap (the gap retains historical value).
"""
from __future__ import annotations

from .registry import register_table


_GAPS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS gaps (
      number INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      state TEXT NOT NULL CHECK (state IN (
        'triage', 'accepted', 'filed', 'ignored'
      )),
      detector TEXT NOT NULL,
      severity TEXT NOT NULL CHECK (severity IN ('info', 'warn', 'fail')),
      filed_issue_number INTEGER
        REFERENCES issues(number) ON DELETE SET NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      CHECK (
        (state = 'filed' AND filed_issue_number IS NOT NULL) OR
        (state != 'filed' AND filed_issue_number IS NULL)
      )
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_gaps_state ON gaps(state)",
    "CREATE INDEX IF NOT EXISTS idx_gaps_detector ON gaps(detector)",
    "CREATE INDEX IF NOT EXISTS idx_gaps_severity ON gaps(severity)",
    "CREATE INDEX IF NOT EXISTS idx_gaps_updated_at ON gaps(updated_at)",
)


def register() -> None:
    """Register the gaps table."""
    register_table("gaps", ddl=_GAPS_DDL)
