"""Canonical-DB schema for Plans (3.15.0 cluster A.1.5).

Per Discussion #23 OQ3 (plans first-class promotion). Plans become
their own canonical-DB entity, equal in standing with milestones.
Pre-3.15.0 plans lived as Discussions with the
``meta.anchored_milestone`` field; the backfill walker (A.8)
migrates existing plan-Discussions into rows here.

Schema design notes:

* **Number is the primary key.** Inherits the canonical numbering
  per OQ28 — backfill preserves existing plan-Discussion numbers
  (e.g. plan #23 stays #23). New plans filed post-A.2 sequence
  from ``max(existing) + 1``.

* **Distinct lifecycle states.** From the swimlane v1 design
  (Discussion #24): ``in_process`` / ``defined`` / ``executing`` /
  ``completed``. CHECK constraint encodes the closed vocabulary:
  - ``in_process`` — OQs open; card displays "N/M questions left".
  - ``defined`` — all OQs resolved; ▶ play affordance.
  - ``executing`` — Begin Development pressed; ⟳ throbber.
  - ``completed`` — all phases done; ✓ glyph.

* **Optional milestone link.** ``milestone_version`` references
  milestones.version; nullable because plans can exist without a
  milestone anchor per swimlane v1 design. ON DELETE SET NULL so
  a milestone deletion doesn't cascade-destroy plans (which carry
  their own historical value).

* **OQ counter fields.** Two integers: ``open_questions`` +
  ``total_questions``. The N/M questions-left display in swimlane
  v1 card reads these. NULL on plans that don't use the OQ
  convention. CHECK constraint enforces ``open <= total`` and
  both non-negative when present.

* **Discussion link.** ``discussion_number`` references the
  Discussion that originated this plan (the prose surface for the
  plan content). Foreign key to discussions(number). Required —
  every plan has a Discussion as its prose source per the
  protocol convention (plan-Discussions carry the actual content;
  the plans table tracks state + structured fields).

* **No body column.** The plan body lives in the linked
  Discussion (which is canonical for prose). Plans table tracks
  structured state only.
"""
from __future__ import annotations

from .registry import register_table


_PLANS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS plans (
      number INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      discussion_number INTEGER NOT NULL
        REFERENCES discussions(number) ON DELETE RESTRICT,
      state TEXT NOT NULL CHECK (state IN (
        'in_process', 'defined', 'executing', 'completed'
      )),
      milestone_version TEXT
        REFERENCES milestones(version) ON DELETE SET NULL,
      open_questions INTEGER
        CHECK (open_questions IS NULL OR open_questions >= 0),
      total_questions INTEGER
        CHECK (total_questions IS NULL OR total_questions >= 0),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      CHECK (
        (open_questions IS NULL AND total_questions IS NULL) OR
        (open_questions IS NOT NULL AND total_questions IS NOT NULL
         AND open_questions <= total_questions)
      )
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_plans_state ON plans(state)",
    "CREATE INDEX IF NOT EXISTS idx_plans_milestone ON plans(milestone_version)",
    "CREATE INDEX IF NOT EXISTS idx_plans_discussion ON plans(discussion_number)",
    "CREATE INDEX IF NOT EXISTS idx_plans_updated_at ON plans(updated_at)",
)


def register() -> None:
    """Register the plans table."""
    register_table("plans", ddl=_PLANS_DDL)
