"""Canonical-DB schema for Milestones (3.15.0 cluster A.1.4).

Per Discussion #23 (3.15.0 plan-Discussion). Models the
3.11.0 D1.a (#397) milestones-as-compound-doc convention as a
first-class canonical-DB table. Schema-only per A.1 scope.

Schema design notes:

* **Version is the primary key.** Unlike Issues / Discussions
  (number PK), milestones are keyed by semver version string
  (``3.14.0``, ``3.15.0``, etc.). Numbers don't apply — the
  filesystem layout is ``<docs>/milestones/<version>/`` keyed by
  the version directory name. Preserves existing filesystem
  identity per OQ28 spirit (preserve external identifiers).

* **State machine.** Single-axis lifecycle from
  :data:`adapters.types.MilestoneLifecycle`:
  ``planned`` / ``active`` / ``closed``. Encoded as CHECK
  constraint. Matches the 3.11.0 D1.a convention (#397 OQ7
  decision: single-axis for 3.11.0; multi-axis deferred).

* **Tier vocabulary.** ``major`` / ``minor`` / ``patch`` from
  :data:`adapters.types.MilestoneTier`. CHECK constraint encodes.
  Major / minor require an anchored plan (per
  ``release.milestone_has_plan`` gate); patch with ``hotfix=True``
  is exempt.

* **Hotfix as INTEGER (0/1).** Same convention as Discussion
  ``decided`` — sqlite has no native bool. CHECK constraint on
  vocabulary.

* **No plan_discussion field here.** Plans become first-class in
  A.1.5 with their own table. The milestone→plan(s) relation lives
  in the ``plans`` table via ``plans.milestone_version`` FK.
  Pre-3.15.0 ``meta.json.plan_discussion`` migrates to
  ``plans.discussion_number`` during the A.8 backfill walker.

* **cut_at + tag_sha nullable.** Set when the milestone closes (cut
  event). Planned/active milestones have NULL on both.
"""
from __future__ import annotations

from .registry import register_table


_MILESTONES_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS milestones (
      version TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      state TEXT NOT NULL CHECK (state IN ('planned', 'active', 'closed')),
      tier TEXT NOT NULL CHECK (tier IN ('major', 'minor', 'patch')),
      hotfix INTEGER NOT NULL DEFAULT 0
        CHECK (hotfix IN (0, 1)),
      cut_at TEXT,
      tag_sha TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_milestones_state ON milestones(state)",
    "CREATE INDEX IF NOT EXISTS idx_milestones_tier ON milestones(tier)",
    "CREATE INDEX IF NOT EXISTS idx_milestones_updated_at "
    "ON milestones(updated_at)",
)


def register() -> None:
    """Register the milestones table."""
    register_table("milestones", ddl=_MILESTONES_DDL)
