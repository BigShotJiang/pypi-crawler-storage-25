"""Typed write helpers for Gaps (3.15.0 cluster A.2.7).

Per Discussion #23. 4-state lifecycle with the cross-CHECK that
state='filed' iff filed_issue_number IS NOT NULL.
:func:`transition_gap_state` is the atomic primitive that updates
both fields together so the cross-CHECK holds.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_gap(
    conn: sqlite3.Connection,
    *,
    number: int,
    title: str,
    detector: str,
    severity: str,
    state: str,
    created_at: str,
    updated_at: str,
    body: str = "",
    filed_issue_number: int | None = None,
) -> None:
    """Insert a gap row. New gaps typically have state='triage' +
    filed_issue_number=None.

    Raises ``sqlite3.IntegrityError`` on duplicate number, invalid
    state CHECK, invalid severity CHECK, or the cross-CHECK that
    state='filed' iff filed_issue_number IS NOT NULL (and FK on
    that field).
    """
    conn.execute(
        """
        INSERT INTO gaps (
          number, title, body, state, detector, severity,
          filed_issue_number, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            number, title, body, state, detector, severity,
            filed_issue_number, created_at, updated_at,
        ),
    )


def transition_gap_state(
    conn: sqlite3.Connection,
    *,
    number: int,
    state: str,
    updated_at: str,
    filed_issue_number: int | None = None,
) -> int:
    """Atomically update state + filed_issue_number.

    The cross-CHECK requires both fields move together when
    transitioning to/from 'filed'. This helper enforces the
    contract: filed_issue_number must be set when state='filed',
    None otherwise.

    Returns rowcount. Raises ``sqlite3.IntegrityError`` if the
    contract is violated (e.g. state='accepted' with
    filed_issue_number set).
    """
    cursor = conn.execute(
        """
        UPDATE gaps
           SET state = ?, filed_issue_number = ?, updated_at = ?
         WHERE number = ?
        """,
        (state, filed_issue_number, updated_at, number),
    )
    return cursor.rowcount


def update_gap_body(
    conn: sqlite3.Connection,
    *,
    number: int,
    body: str,
    updated_at: str,
) -> int:
    """Replace gap body markdown. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE gaps SET body = ?, updated_at = ? WHERE number = ?",
        (body, updated_at, number),
    )
    return cursor.rowcount


def delete_gap(conn: sqlite3.Connection, *, number: int) -> int:
    """Delete a gap. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM gaps WHERE number = ?",
        (number,),
    )
    return cursor.rowcount


def select_gap(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> dict[str, Any] | None:
    """Read a gap by number. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT number, title, body, state, detector, severity,
               filed_issue_number, created_at, updated_at
          FROM gaps
         WHERE number = ?
        """,
        (number,),
    ).fetchone()
    if row is None:
        return None
    return {
        "number": row[0], "title": row[1], "body": row[2],
        "state": row[3], "detector": row[4], "severity": row[5],
        "filed_issue_number": row[6],
        "created_at": row[7], "updated_at": row[8],
    }


def list_gaps_by_state(
    conn: sqlite3.Connection,
    *,
    state: str,
) -> list[dict[str, Any]]:
    """Return gaps in the given lifecycle state, sorted by number."""
    rows = conn.execute(
        """
        SELECT number, title, detector, severity, filed_issue_number
          FROM gaps
         WHERE state = ?
         ORDER BY number
        """,
        (state,),
    ).fetchall()
    return [
        {
            "number": r[0], "title": r[1], "detector": r[2],
            "severity": r[3], "filed_issue_number": r[4],
        }
        for r in rows
    ]


def list_gaps_by_detector(
    conn: sqlite3.Connection,
    *,
    detector: str,
) -> list[dict[str, Any]]:
    """Return gaps produced by a specific detector, sorted by number."""
    rows = conn.execute(
        """
        SELECT number, title, state, severity
          FROM gaps
         WHERE detector = ?
         ORDER BY number
        """,
        (detector,),
    ).fetchall()
    return [
        {
            "number": r[0], "title": r[1], "state": r[2],
            "severity": r[3],
        }
        for r in rows
    ]


def next_gap_number(conn: sqlite3.Connection) -> int:
    """Return next available gap number per OQ28."""
    row = conn.execute("SELECT MAX(number) FROM gaps").fetchone()
    return 1 if row[0] is None else int(row[0]) + 1
