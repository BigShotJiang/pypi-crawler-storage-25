"""Canonical-DB schema for Comments (3.15.0 cluster A.1.6).

Per Discussion #23 (3.15.0 plan-Discussion). Comments are
sub-artifacts attached to Issues or Discussions; the canonical
store today places them under
``<docs>/<kind>/<n>/comments/<iso8601>-<author>.md``.

Schema design notes:

* **Auto-increment integer PK.** Comments don't have a
  human-meaningful number — they exist only as children of
  Issues/Discussions. The PK is the insertion-order id;
  ``parent_kind`` + ``parent_number`` carries the cross-link to
  the canonical parent.

* **Polymorphic parent via (kind, number).** Comments can attach
  to Issues OR Discussions. Tracked via ``parent_kind`` (CHECK
  constrained to ``issue|discussion``) + ``parent_number``. SQL
  FK can't directly enforce a polymorphic relation; the write-path
  validates membership in A.2. Indexes on
  (parent_kind, parent_number) for fast lookup of an artifact's
  comments.

* **Body markdown.** ``body`` is the comment markdown text. The
  filesystem layout used per-comment files; the canonical-DB
  stores body inline.

* **created_at as natural ordering.** The filesystem layout sorted
  by ISO-8601 prefix in filename; the canonical-DB sorts by
  created_at. Index supports chronological queries.

* **parent_id for threading.** Optional self-FK for reply-to
  relationships. Nullable when comment is top-level. ON DELETE
  CASCADE — a deleted parent comment removes its replies.
"""
from __future__ import annotations

from .registry import register_table


_COMMENTS_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY,
      parent_kind TEXT NOT NULL CHECK (parent_kind IN ('issue', 'discussion')),
      parent_number INTEGER NOT NULL,
      parent_id INTEGER
        REFERENCES comments(id) ON DELETE CASCADE,
      author TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL DEFAULT '',
      url TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_comments_parent "
    "ON comments(parent_kind, parent_number)",
    "CREATE INDEX IF NOT EXISTS idx_comments_parent_id "
    "ON comments(parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_comments_created_at "
    "ON comments(created_at)",
)


def register() -> None:
    """Register the comments table."""
    register_table("comments", ddl=_COMMENTS_DDL)
