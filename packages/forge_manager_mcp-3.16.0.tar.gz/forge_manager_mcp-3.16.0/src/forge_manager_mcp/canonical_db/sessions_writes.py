"""Typed write helpers for Sessions (3.15.0 cluster A.2.6).

Per Discussion #23. session_id TEXT PK; open/close lifecycle via
closed_at nullability. ``close_session_row`` is the atomic
close-with-summary primitive.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_session(
    conn: sqlite3.Connection,
    *,
    session_id: str,
    opened_at: str,
    created_at: str,
    updated_at: str,
    prior_session_clean: int = 1,
) -> None:
    """Insert an open session row (closed_at NULL).

    Raises ``sqlite3.IntegrityError`` on duplicate session_id or
    invalid prior_session_clean (CHECK: 0|1).
    """
    conn.execute(
        """
        INSERT INTO sessions (
          session_id, opened_at, prior_session_clean,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?)
        """,
        (session_id, opened_at, prior_session_clean, created_at, updated_at),
    )


def close_session_row(
    conn: sqlite3.Connection,
    *,
    session_id: str,
    closed_at: str,
    summary: str,
    updated_at: str,
) -> int:
    """Atomically set closed_at + summary at session-end.

    Returns rowcount. Convention: caller invokes from the
    close_session MCP tool's handler.
    """
    cursor = conn.execute(
        """
        UPDATE sessions
           SET closed_at = ?, summary = ?, updated_at = ?
         WHERE session_id = ?
        """,
        (closed_at, summary, updated_at, session_id),
    )
    return cursor.rowcount


def update_session_summary(
    conn: sqlite3.Connection,
    *,
    session_id: str,
    summary: str,
    updated_at: str,
) -> int:
    """Replace summary text only. Useful for post-close edits."""
    cursor = conn.execute(
        "UPDATE sessions SET summary = ?, updated_at = ? "
        "WHERE session_id = ?",
        (summary, updated_at, session_id),
    )
    return cursor.rowcount


def select_session(
    conn: sqlite3.Connection,
    *,
    session_id: str,
) -> dict[str, Any] | None:
    """Read a session row. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT session_id, opened_at, closed_at,
               prior_session_clean, summary,
               created_at, updated_at
          FROM sessions
         WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if row is None:
        return None
    return {
        "session_id": row[0], "opened_at": row[1],
        "closed_at": row[2],
        "prior_session_clean": row[3], "summary": row[4],
        "created_at": row[5], "updated_at": row[6],
    }


def list_open_sessions(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Return sessions with closed_at IS NULL.

    The number of open sessions surfaces in the swimlane v1
    user-widget badge (parallel-session count).
    """
    rows = conn.execute(
        """
        SELECT session_id, opened_at, prior_session_clean
          FROM sessions
         WHERE closed_at IS NULL
         ORDER BY opened_at
        """
    ).fetchall()
    return [
        {
            "session_id": r[0], "opened_at": r[1],
            "prior_session_clean": r[2],
        }
        for r in rows
    ]


def list_sessions_since(
    conn: sqlite3.Connection,
    *,
    since: str,
) -> list[dict[str, Any]]:
    """Return sessions opened at or after ``since`` (ISO-8601), sorted."""
    rows = conn.execute(
        """
        SELECT session_id, opened_at, closed_at, summary
          FROM sessions
         WHERE opened_at >= ?
         ORDER BY opened_at
        """,
        (since,),
    ).fetchall()
    return [
        {
            "session_id": r[0], "opened_at": r[1],
            "closed_at": r[2], "summary": r[3],
        }
        for r in rows
    ]
