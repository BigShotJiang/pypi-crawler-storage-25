"""Canonical-DB framework: connection helpers + schema init + version dispatch.

Per Discussion #23 (3.15.0 plan-Discussion). This module is the
effect layer for canonical-DB lifecycle operations — opening the
sqlite connection, applying pragmas, reading/writing
``PRAGMA user_version``, dispatching schema creation against
:mod:`canonical_db.registry`.

Distinct from :mod:`forge_manager_mcp.shadow.core` — that module is
the bitemporal insert helper for derived facts. Canonical-DB stores
current-state authoritative rows; per-entity modules ship their own
typed insert/update helpers.

Effects (Rule 2 / Rule 10) are split into pure helpers so callers can
test the orchestration without sqlite. Per OQ1, DB file path is
resolved from the docs-repo path; callers inject the path so the
framework stays infrastructure-blind.

Schema versioning per OQ2: ``SCHEMA_VERSION`` is the framework's
declared target. ``ensure_initialized`` reads the file's
``PRAGMA user_version`` and dispatches schema creation when below
target. Bumped at milestone cuts; not coupled to skill semver.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

from . import registry


SCHEMA_VERSION: int = 1
"""Canonical-DB schema version. Independent of skill protocol semver
per Discussion #23 OQ2. Started at 1 in 3.15.0 cluster A.1. Bump at
milestone cuts when entity-table shape changes."""


_DB_FILENAME: str = ".forge-manager.db"
"""Per Discussion #23 OQ1: DB file lives at
``<docs_repo>/.forge-manager.db``. Hidden filename so the docs-repo
directory listing stays operator-friendly. Binary file; sqlite
handles git binary commits cleanly under the debounced commit
strategy."""


# ---------------------------------------------------------------------------
# Path resolution (pure)
# ---------------------------------------------------------------------------

def resolve_db_path(docs_repo_path: Path) -> Path:
    """Resolve the canonical-DB file location from a docs-repo path.

    Per Discussion #23 OQ1: ``<docs_repo>/.forge-manager.db``. Pure
    function — no IO, no filesystem checks. Caller is responsible
    for ensuring the docs-repo directory exists before opening the
    connection.
    """
    return docs_repo_path / _DB_FILENAME


# ---------------------------------------------------------------------------
# Connection effects
# ---------------------------------------------------------------------------

def _apply_startup_pragmas(conn: sqlite3.Connection) -> None:
    """Apply WAL journal mode + foreign-key enforcement.

    WAL allows concurrent readers while a writer is open — required
    for the swimlane UI's live SSE subscribers reading while
    handlers write. Foreign keys are off by default in sqlite; we
    enable them at every connection for referential integrity (e.g.
    comments referencing their parent Issue).
    """
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")


def open_connection(
    db_path: Path,
    *,
    read_only: bool = False,
) -> sqlite3.Connection:
    """Open a sqlite connection to the canonical-DB file.

    ``read_only=True`` opens via the URI ``?mode=ro`` flag —
    matches the daemon's ``shadow_query`` MCP tool pattern (OQ9 in
    Discussion #22). The sqlite engine rejects DDL/DML on read-only
    connections; this is enforcement at the engine layer not just
    convention.

    Pragmas are NOT applied on read-only connections — WAL mode is
    a database-level setting (already persisted from the first
    writer) and foreign-key checks are a connection-level setting
    only meaningful for writes.
    """
    if read_only:
        uri = f"file:{db_path}?mode=ro"
        return sqlite3.connect(uri, uri=True)
    conn = sqlite3.connect(str(db_path))
    _apply_startup_pragmas(conn)
    return conn


# ---------------------------------------------------------------------------
# Version pragma effects
# ---------------------------------------------------------------------------

def current_schema_version(conn: sqlite3.Connection) -> int:
    """Read ``PRAGMA user_version`` from the open connection.

    Returns 0 for a freshly-created sqlite file (sqlite's default).
    The framework treats 0 as "uninitialized — needs full schema
    init". Per OQ2, this is the canonical-DB's own version namespace
    (shadow has its own ``user_version`` in a separate DB file).
    """
    row = conn.execute("PRAGMA user_version").fetchone()
    return int(row[0]) if row else 0


def set_schema_version(conn: sqlite3.Connection, version: int) -> None:
    """Write ``PRAGMA user_version = <version>`` to the open
    connection.

    The pragma value is part of the sqlite file header — persists
    across connection close/open. sqlite enforces non-negative
    32-bit integers; the framework declares ``SCHEMA_VERSION`` as a
    Python ``int`` with the same constraint implicit.
    """
    # sqlite doesn't accept parameter binding on PRAGMA values; safe
    # because callers pass the framework constant or an int read
    # back from the same connection.
    conn.execute(f"PRAGMA user_version = {int(version)}")


# ---------------------------------------------------------------------------
# Schema initialization (composes effects + registry)
# ---------------------------------------------------------------------------

def init_schema(
    conn: sqlite3.Connection,
    *,
    target_version: int = SCHEMA_VERSION,
) -> bool:
    """Create every registered table and bump the schema version.

    Iterates :func:`registry.registered_tables` in registration
    order (sorted) and executes each table's DDL statements against
    the connection. Idempotent: every DDL statement uses
    ``CREATE TABLE IF NOT EXISTS`` (per the per-table DDL contract);
    re-running is safe.

    Returns ``True`` when the version was bumped (initialization
    ran); ``False`` when the connection was already at or above the
    target. Caller commits the transaction; this helper does not.

    The DDL execution is wrapped in a savepoint so a mid-init
    failure leaves the connection in a clean state — partial
    creation is rolled back; the version is not bumped.
    """
    starting = current_schema_version(conn)
    if starting >= target_version:
        return False
    conn.execute("SAVEPOINT canonical_db_init")
    try:
        for name in registry.registered_tables():
            for ddl_stmt in registry.ddl_for(name):
                conn.execute(ddl_stmt)
        set_schema_version(conn, target_version)
    except Exception:
        conn.execute("ROLLBACK TO SAVEPOINT canonical_db_init")
        conn.execute("RELEASE SAVEPOINT canonical_db_init")
        raise
    conn.execute("RELEASE SAVEPOINT canonical_db_init")
    return True


def ensure_initialized(conn: sqlite3.Connection) -> bool:
    """High-level: bring the connection's schema up to
    :data:`SCHEMA_VERSION`.

    Convenience wrapper around :func:`init_schema` that uses the
    framework's declared target. Returns ``True`` when init ran;
    ``False`` when already at target.

    Callers in production daemon startup invoke this once per
    process-lifetime against the live DB. Tests use it against
    in-memory or tmp-path sqlite connections.
    """
    return init_schema(conn, target_version=SCHEMA_VERSION)
