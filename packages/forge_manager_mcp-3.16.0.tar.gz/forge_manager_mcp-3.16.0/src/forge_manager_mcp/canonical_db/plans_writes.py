"""Typed write helpers for Plans (3.15.0 cluster A.2.4 / OQ3).

Per Discussion #23. Plans table has FK to discussions(number)
ON DELETE RESTRICT (every plan has a prose-source Discussion) and
optional FK to milestones(version) ON DELETE SET NULL.

The four-state lifecycle (in_process / defined / executing /
completed) drives the swimlane v1 plan card's affordances. OQ
counters (open_questions / total_questions) update independently
from state for the "N/M questions left" display.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_plan(
    conn: sqlite3.Connection,
    *,
    number: int,
    title: str,
    discussion_number: int,
    state: str,
    created_at: str,
    updated_at: str,
    milestone_version: str | None = None,
    open_questions: int | None = None,
    total_questions: int | None = None,
) -> None:
    """Insert a plan row.

    Raises ``sqlite3.IntegrityError`` on duplicate number, FK
    violations, invalid state CHECK, or OQ-counter CHECK (both
    NULL or both non-negative with open <= total).
    """
    conn.execute(
        """
        INSERT INTO plans (
          number, title, discussion_number, state,
          milestone_version, open_questions, total_questions,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            number, title, discussion_number, state,
            milestone_version, open_questions, total_questions,
            created_at, updated_at,
        ),
    )


def update_plan_state(
    conn: sqlite3.Connection,
    *,
    number: int,
    state: str,
    updated_at: str,
) -> int:
    """Transition the plan state. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE plans SET state = ?, updated_at = ? WHERE number = ?",
        (state, updated_at, number),
    )
    return cursor.rowcount


def update_plan_milestone(
    conn: sqlite3.Connection,
    *,
    number: int,
    milestone_version: str | None,
    updated_at: str,
) -> int:
    """Set/clear the plan's milestone anchor. Returns rowcount.

    FK to milestones; passing a non-existent version raises
    IntegrityError. Pass None to clear (plans-without-milestones
    supported per swimlane v1).
    """
    cursor = conn.execute(
        "UPDATE plans SET milestone_version = ?, updated_at = ? "
        "WHERE number = ?",
        (milestone_version, updated_at, number),
    )
    return cursor.rowcount


def update_plan_questions(
    conn: sqlite3.Connection,
    *,
    number: int,
    open_questions: int | None,
    total_questions: int | None,
    updated_at: str,
) -> int:
    """Update the plan's OQ counters atomically.

    Both NULL clears the counter display. Both non-negative with
    open <= total satisfies the table CHECK. Returns rowcount.
    """
    cursor = conn.execute(
        """
        UPDATE plans
           SET open_questions = ?, total_questions = ?,
               updated_at = ?
         WHERE number = ?
        """,
        (open_questions, total_questions, updated_at, number),
    )
    return cursor.rowcount


def delete_plan(conn: sqlite3.Connection, *, number: int) -> int:
    """Delete a plan. Returns rowcount."""
    cursor = conn.execute(
        "DELETE FROM plans WHERE number = ?",
        (number,),
    )
    return cursor.rowcount


def select_plan(
    conn: sqlite3.Connection,
    *,
    number: int,
) -> dict[str, Any] | None:
    """Read a plan by number. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT number, title, discussion_number, state,
               milestone_version, open_questions, total_questions,
               created_at, updated_at
          FROM plans
         WHERE number = ?
        """,
        (number,),
    ).fetchone()
    if row is None:
        return None
    return {
        "number": row[0], "title": row[1],
        "discussion_number": row[2], "state": row[3],
        "milestone_version": row[4],
        "open_questions": row[5], "total_questions": row[6],
        "created_at": row[7], "updated_at": row[8],
    }


def list_plans_by_milestone(
    conn: sqlite3.Connection,
    *,
    milestone_version: str | None,
) -> list[dict[str, Any]]:
    """Return plans anchored to a milestone, or unmilestoned plans
    when ``milestone_version=None``. Sorted by plan number.
    """
    if milestone_version is None:
        sql = (
            "SELECT number, title, state, discussion_number "
            "FROM plans WHERE milestone_version IS NULL "
            "ORDER BY number"
        )
        params: tuple[Any, ...] = ()
    else:
        sql = (
            "SELECT number, title, state, discussion_number "
            "FROM plans WHERE milestone_version = ? "
            "ORDER BY number"
        )
        params = (milestone_version,)
    rows = conn.execute(sql, params).fetchall()
    return [
        {
            "number": r[0], "title": r[1], "state": r[2],
            "discussion_number": r[3],
        }
        for r in rows
    ]


def next_plan_number(conn: sqlite3.Connection) -> int:
    """Return next available plan number per OQ28."""
    row = conn.execute("SELECT MAX(number) FROM plans").fetchone()
    return 1 if row[0] is None else int(row[0]) + 1
