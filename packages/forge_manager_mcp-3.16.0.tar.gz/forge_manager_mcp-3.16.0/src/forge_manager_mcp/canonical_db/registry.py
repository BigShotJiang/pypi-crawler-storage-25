"""Canonical-DB table registry — pure module-level registration.

Per Discussion #23 (3.15.0 plan-Discussion). Each per-entity schema
module (issues / discussions / milestones / plans / comments /
sessions / gaps / history) registers its DDL at import time via
:func:`register_table`. The framework PR ships the registry shape;
per-entity PRs populate it across A.1.2 through A.1.9.

Distinct from :mod:`forge_manager_mcp.shadow.registry`:

* Shadow registry tracks bitemporal derived-fact tables — each entry
  carries ``ddl`` + ``classification`` (derivable / stateful) +
  ``walker_fn`` (rebuilds from canonical).
* Canonical-DB registry tracks authoritative current-state tables —
  each entry carries only ``ddl``. There's no "derivable from
  canonical" semantic because *these tables are canonical*. No
  walker because there's nothing to walk from.

The registry is process-global by design — mirrors the
shadow.registry pattern. Tests get isolation via
:func:`reset_for_testing` (callable from teardown).

Pure-data module — no IO, no sqlite imports, stdlib-only. Sits as a
leaf in the dep graph so :mod:`canonical_db.core` can depend on it
without dragging in entity-specific code.
"""
from __future__ import annotations


_REGISTRY: dict[str, dict[str, tuple[str, ...]]] = {}
"""Process-global registry. Keyed by table name; value is a dict
with ``ddl`` (tuple of CREATE statements). Single-field-dict shape
matches :mod:`forge_manager_mcp.shadow.registry` so future
extensions (indexes, triggers, views) layer cleanly without API
churn."""


def register_table(name: str, *, ddl: tuple[str, ...]) -> None:
    """Register a canonical-DB table.

    Per-entity schema modules call this at import time from their
    module's top-level. Repeated registration of the same ``name``
    overwrites the previous entry — supports test-side fakery via
    ``monkeypatch`` + :func:`reset_for_testing` calls.

    Args:
        name: The table name (e.g., ``"issues"``). Must be a
            non-empty string. The framework doesn't validate sqlite
            identifier syntax — that's enforced at DDL execution
            time by sqlite itself.
        ddl: Tuple of CREATE statements (CREATE TABLE + indexes +
            views). Executed in order by
            :func:`canonical_db.core.init_schema`. Each statement
            should use ``CREATE TABLE IF NOT EXISTS`` semantics so
            re-initialization is idempotent.

    Raises:
        ValueError: when ``name`` is empty.
    """
    if not name:
        raise ValueError(
            "canonical_db.register_table: name must not be empty"
        )
    _REGISTRY[name] = {"ddl": ddl}


def registered_tables() -> list[str]:
    """Return every registered table name, sorted.

    Sorted return for deterministic init order — relevant when
    tables have foreign-key dependencies on each other (FKs evaluate
    at insert time, but creation order can still surface clearer
    errors when a referenced table is missing). Sorted is also
    stable across Python's dict-ordering guarantees under test
    fakery (which can vary registration order).
    """
    return sorted(_REGISTRY.keys())


def ddl_for(name: str) -> tuple[str, ...]:
    """Return the DDL tuple for a registered table.

    Raises ``KeyError`` for unknown table names — the framework's
    contract is that callers ask only for registered tables (the
    dispatch path iterates :func:`registered_tables` first).
    """
    return _REGISTRY[name]["ddl"]


def reset_for_testing() -> None:
    """Clear the registry. Tests call this in teardown so cross-test
    registrations don't leak.

    Not exported for production use — production registrations
    happen once at module import time and stay for the process
    lifetime.
    """
    _REGISTRY.clear()
