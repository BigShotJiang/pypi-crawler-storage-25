"""Typed write helpers for Milestones (3.15.0 cluster A.2.3).

Per Discussion #23. PK is the semver version string (no labels
table). State machine: planned → active → closed via
:func:`mark_milestone_cut` which atomically sets state='closed' +
cut_at + tag_sha.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def insert_milestone(
    conn: sqlite3.Connection,
    *,
    version: str,
    title: str,
    state: str,
    tier: str,
    created_at: str,
    updated_at: str,
    body: str = "",
    hotfix: int = 0,
    cut_at: str | None = None,
    tag_sha: str | None = None,
) -> None:
    """Insert a new milestone row.

    Raises ``sqlite3.IntegrityError`` on duplicate version, invalid
    state (CHECK: planned|active|closed), invalid tier (CHECK:
    major|minor|patch), or hotfix not in {0, 1}.
    """
    conn.execute(
        """
        INSERT INTO milestones (
          version, title, body, state, tier, hotfix,
          cut_at, tag_sha, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            version, title, body, state, tier, hotfix,
            cut_at, tag_sha, created_at, updated_at,
        ),
    )


def update_milestone_state(
    conn: sqlite3.Connection,
    *,
    version: str,
    state: str,
    updated_at: str,
) -> int:
    """Transition the milestone state (planned/active/closed). Returns rowcount.

    Use :func:`mark_milestone_cut` for the close→cut transition that
    also sets cut_at + tag_sha atomically.
    """
    cursor = conn.execute(
        "UPDATE milestones SET state = ?, updated_at = ? WHERE version = ?",
        (state, updated_at, version),
    )
    return cursor.rowcount


def update_milestone_body(
    conn: sqlite3.Connection,
    *,
    version: str,
    body: str,
    updated_at: str,
) -> int:
    """Replace milestone body markdown. Returns rowcount."""
    cursor = conn.execute(
        "UPDATE milestones SET body = ?, updated_at = ? WHERE version = ?",
        (body, updated_at, version),
    )
    return cursor.rowcount


def mark_milestone_cut(
    conn: sqlite3.Connection,
    *,
    version: str,
    cut_at: str,
    tag_sha: str,
    updated_at: str,
) -> int:
    """Atomically mark a milestone closed at its cut event.

    Sets state='closed', cut_at, tag_sha in one UPDATE. Returns
    rowcount. Convention: caller invokes this from the release flow's
    post-tag step.
    """
    cursor = conn.execute(
        """
        UPDATE milestones
           SET state = 'closed', cut_at = ?, tag_sha = ?, updated_at = ?
         WHERE version = ?
        """,
        (cut_at, tag_sha, updated_at, version),
    )
    return cursor.rowcount


def delete_milestone(conn: sqlite3.Connection, *, version: str) -> int:
    """Delete a milestone. plans.milestone_version FK uses SET NULL,
    so plans survive. Returns rowcount.
    """
    cursor = conn.execute(
        "DELETE FROM milestones WHERE version = ?",
        (version,),
    )
    return cursor.rowcount


def select_milestone(
    conn: sqlite3.Connection,
    *,
    version: str,
) -> dict[str, Any] | None:
    """Read a milestone by version. Returns dict or ``None``."""
    row = conn.execute(
        """
        SELECT version, title, body, state, tier, hotfix,
               cut_at, tag_sha, created_at, updated_at
          FROM milestones
         WHERE version = ?
        """,
        (version,),
    ).fetchone()
    if row is None:
        return None
    return {
        "version": row[0], "title": row[1], "body": row[2],
        "state": row[3], "tier": row[4], "hotfix": row[5],
        "cut_at": row[6], "tag_sha": row[7],
        "created_at": row[8], "updated_at": row[9],
    }


def list_milestones_by_state(
    conn: sqlite3.Connection,
    *,
    state: str,
) -> list[dict[str, Any]]:
    """Return all milestones in the given lifecycle state.

    Useful for "show me active milestones" (the swimlane v1 current
    milestone lane reads this).
    """
    rows = conn.execute(
        """
        SELECT version, title, state, tier, hotfix, cut_at, tag_sha,
               created_at, updated_at
          FROM milestones
         WHERE state = ?
         ORDER BY version
        """,
        (state,),
    ).fetchall()
    return [
        {
            "version": r[0], "title": r[1], "state": r[2],
            "tier": r[3], "hotfix": r[4], "cut_at": r[5],
            "tag_sha": r[6], "created_at": r[7], "updated_at": r[8],
        }
        for r in rows
    ]
