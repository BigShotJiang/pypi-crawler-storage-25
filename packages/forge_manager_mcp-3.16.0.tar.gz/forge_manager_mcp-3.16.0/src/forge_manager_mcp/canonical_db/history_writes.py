"""Typed write helpers for artifact_history (3.15.0 cluster A.2.8).

Per Discussion #23. Insert-only audit log — no update/delete
helpers. The shadow ``history_log_facts`` walker (#480) reads this
table to populate bitemporal fact rows.

Functions are read-heavy: one insert + four query patterns for the
operator-facing surfaces (audit trail per artifact, per session,
since timestamp, count).
"""
from __future__ import annotations

import sqlite3
from typing import Any


def record_event(
    conn: sqlite3.Connection,
    *,
    artifact_kind: str,
    artifact_id: str,
    operation: str,
    recorded_at: str,
    payload: str = "",
    actor: str = "",
    session_id: str | None = None,
) -> int:
    """Append one row to artifact_history. Returns the new id.

    Raises ``sqlite3.IntegrityError`` on invalid artifact_kind CHECK
    (must be issue|discussion|milestone|plan|comment|gap|session)
    or session_id FK violation.

    The write-path orchestrator (A.2.9 daemon hookup) calls this
    after every canonical-DB mutation so the history table mirrors
    what the filesystem history/<ts>.json layout used to capture.
    """
    cursor = conn.execute(
        """
        INSERT INTO artifact_history (
          artifact_kind, artifact_id, operation,
          payload, actor, session_id, recorded_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            artifact_kind, artifact_id, operation,
            payload, actor, session_id, recorded_at,
        ),
    )
    return int(cursor.lastrowid)


def list_events_for_artifact(
    conn: sqlite3.Connection,
    *,
    artifact_kind: str,
    artifact_id: str,
) -> list[dict[str, Any]]:
    """Return all history events for an artifact, sorted by recorded_at."""
    rows = conn.execute(
        """
        SELECT id, operation, payload, actor, session_id, recorded_at
          FROM artifact_history
         WHERE artifact_kind = ? AND artifact_id = ?
         ORDER BY recorded_at, id
        """,
        (artifact_kind, artifact_id),
    ).fetchall()
    return [
        {
            "id": r[0], "operation": r[1], "payload": r[2],
            "actor": r[3], "session_id": r[4], "recorded_at": r[5],
        }
        for r in rows
    ]


def list_events_for_session(
    conn: sqlite3.Connection,
    *,
    session_id: str,
) -> list[dict[str, Any]]:
    """Return all events recorded under a session, chronological."""
    rows = conn.execute(
        """
        SELECT id, artifact_kind, artifact_id, operation,
               payload, actor, recorded_at
          FROM artifact_history
         WHERE session_id = ?
         ORDER BY recorded_at, id
        """,
        (session_id,),
    ).fetchall()
    return [
        {
            "id": r[0], "artifact_kind": r[1],
            "artifact_id": r[2], "operation": r[3],
            "payload": r[4], "actor": r[5], "recorded_at": r[6],
        }
        for r in rows
    ]


def list_events_since(
    conn: sqlite3.Connection,
    *,
    since: str,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """Return all events at or after ``since`` (ISO-8601 UTC), chronological.

    Optional ``limit`` caps the result set; useful for the swimlane
    v1 status display's "recent events" surface.
    """
    if limit is None:
        rows = conn.execute(
            """
            SELECT id, artifact_kind, artifact_id, operation,
                   actor, session_id, recorded_at
              FROM artifact_history
             WHERE recorded_at >= ?
             ORDER BY recorded_at, id
            """,
            (since,),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT id, artifact_kind, artifact_id, operation,
                   actor, session_id, recorded_at
              FROM artifact_history
             WHERE recorded_at >= ?
             ORDER BY recorded_at, id
             LIMIT ?
            """,
            (since, int(limit)),
        ).fetchall()
    return [
        {
            "id": r[0], "artifact_kind": r[1],
            "artifact_id": r[2], "operation": r[3],
            "actor": r[4], "session_id": r[5], "recorded_at": r[6],
        }
        for r in rows
    ]


def count_events(conn: sqlite3.Connection) -> int:
    """Return total event count. Useful for daemon-status diagnostics."""
    row = conn.execute(
        "SELECT COUNT(*) FROM artifact_history"
    ).fetchone()
    return int(row[0])
