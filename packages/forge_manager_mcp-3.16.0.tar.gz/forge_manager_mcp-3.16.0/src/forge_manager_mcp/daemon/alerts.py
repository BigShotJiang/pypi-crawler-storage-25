"""Daemon alert log (Phase D3b.4o / #341).

The daemon publishes events via the broadcaster (live SSE for the
UI). When the UI is closed, no one sees them. This module retains
a bounded ring buffer of recent alerts that the MCP can poll on
session start + mid-session, so the operator never misses a
significant daemon-side change just because the UI happened to be
closed at the moment of publication.

**Why a separate channel from events.** Events are fire-and-forget
notifications; subscribers either get them or don't. Alerts are
the subset of events the operator must not miss. They get retention
+ severity classification + an MCP polling surface. Per the Issue
#341 dependency note: this layered with #340 (proactive operator
error surface) — #340 is "current state snapshot", this is
"events since last seen".

**Scope for 3.5.0.** In-memory ring buffer; alerts pre-restart are
lost. Acceptable per the Issue's Out-of-scope: persistent alert
history is capability 2 / 3.6.0 (sqlite-backed log).

**Code-design.** `Alert` follows Rule 5 (cached dataclass class
inside a helper). `AlertLog` is a small effect-bearing class
holding the ring buffer; query methods are pure functions on the
buffer state.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import cache
from typing import Deque, Iterable


# Severity ordering — used by `level_at_least` filter.
_LEVEL_ORDER: dict[str, int] = {
    "info": 0,
    "warning": 1,
    "error": 2,
    "critical": 3,
}


def _level_rank(level: str) -> int:
    """Return ordinal of a level; -1 for unknown levels (always
    matches `level_at_least` filtering — unknowns surface)."""
    return _LEVEL_ORDER.get(level, -1)


DEFAULT_RING_CAPACITY = 1000
"""Ring-buffer capacity. Sized so a daemon running across a
multi-week vacation doesn't lose recent alerts even if every
backend transitions multiple times. Configurable per Issue body
but defaulted here for the per-project state-dir's no-config
case."""


@cache
def _alert_class() -> type:
    @dataclass(frozen=True)
    class Alert:
        """One alert entry. Frozen + hashable so reprocessing is
        idempotent (same alert published twice is the same value).

        Fields:
            level — one of ``info`` / ``warning`` / ``error`` /
                ``critical``. Drives Claude's session-start surface
                formatting (per recording.md prose update).
            message — one-line operator-facing summary. Should be
                actionable on its own without reading ``detail``.
            detail — optional multi-line structured context (stack
                trace, full error string, payload). May be None.
            platform_id — when alert is backend-scoped; None for
                daemon-wide alerts (credentials.decrypt-fail,
                version-mismatch).
            timestamp — UTC publish time.
            tags — tuple of structural tags so the UI / MCP can
                filter by category (e.g. ``("backend", "degraded")``,
                ``("credentials", "decrypt-fail")``). Tuple (not
                list) so the dataclass stays hashable.
        """
        level: str
        message: str
        detail: str | None
        platform_id: str | None
        timestamp: datetime
        tags: tuple[str, ...]
    return Alert


def make_alert(
    *,
    level: str,
    message: str,
    detail: str | None = None,
    platform_id: str | None = None,
    timestamp: datetime | None = None,
    tags: Iterable[str] = (),
):
    """Factory for Alert values. Defaults timestamp to UTC-now."""
    if timestamp is None:
        timestamp = datetime.now(timezone.utc)
    Cls = _alert_class()
    return Cls(
        level=level,
        message=message,
        detail=detail,
        platform_id=platform_id,
        timestamp=timestamp,
        tags=tuple(tags),
    )


def alert_to_dict(alert) -> dict:
    """Serialize an Alert for JSON over HTTP. Timestamp → ISO-8601;
    tags → list (JSON has no tuple)."""
    return {
        "level": alert.level,
        "message": alert.message,
        "detail": alert.detail,
        "platform_id": alert.platform_id,
        "timestamp": alert.timestamp.isoformat(),
        "tags": list(alert.tags),
    }


def alert_from_dict(payload: dict):
    """Deserialize an Alert from a POST /alerts body. Timestamp
    parsed back from ISO-8601 if present, else now."""
    ts_raw = payload.get("timestamp")
    if ts_raw:
        timestamp = datetime.fromisoformat(ts_raw)
    else:
        timestamp = datetime.now(timezone.utc)
    return make_alert(
        level=payload.get("level", "info"),
        message=payload.get("message", ""),
        detail=payload.get("detail"),
        platform_id=payload.get("platform_id"),
        timestamp=timestamp,
        tags=tuple(payload.get("tags", ())),
    )


# --- AlertLog ring buffer --------------------------------------------------


class AlertLog:
    """Bounded FIFO ring buffer of recent alerts.

    The daemon's single instance is constructed at startup and
    shared between the alert-source publishers (backend transitions,
    credentials failures) and the GET /alerts endpoint. In-memory
    only; restart drops history.

    Effect surface — append + query operations only. No persistence
    side. The MCP's auto-memory cursor plus this in-memory buffer
    together give cross-session alert continuity without daemon-
    side persistence.
    """

    def __init__(self, capacity: int = DEFAULT_RING_CAPACITY):
        if capacity <= 0:
            raise ValueError(f"capacity must be > 0, got {capacity}")
        self._buf: Deque = deque(maxlen=capacity)

    def record(self, alert) -> None:
        """Append an alert to the log. When the buffer is full the
        oldest entry is dropped per ``deque.maxlen`` semantics."""
        self._buf.append(alert)

    def recent(
        self,
        *,
        since: datetime | None = None,
        level_at_least: str | None = None,
        limit: int | None = None,
    ) -> list:
        """Return matching alerts newest-first.

        Filters:
            since — only alerts with ``timestamp > since``. None
                means no lower bound.
            level_at_least — minimum severity (inclusive). None
                means all levels.
            limit — cap on number of returned entries; None = all.

        Returns a list (not iterator) so callers can len() / index
        without consuming. Newest-first ordering matches the UI's
        natural "recent activity" rendering.
        """
        if level_at_least is not None:
            min_rank = _level_rank(level_at_least)
        else:
            min_rank = None
        out: list = []
        # deque iterates oldest-first; reverse to get newest-first.
        for alert in reversed(self._buf):
            if since is not None and alert.timestamp <= since:
                continue
            if min_rank is not None:
                alert_rank = _level_rank(alert.level)
                # Unknown levels (rank -1) always surface — they
                # signal a daemon-side bug; better visible than
                # silently dropped under a level_at_least filter.
                if alert_rank >= 0 and alert_rank < min_rank:
                    continue
            out.append(alert)
            if limit is not None and len(out) >= limit:
                break
        return out

    def __len__(self) -> int:
        return len(self._buf)

    def clear(self) -> None:
        """Drop all retained alerts. Used by tests."""
        self._buf.clear()
