"""Daemon path resolution (Phase D3a / 3.5.0).

Stdlib-only for 3.5.0. ``platformdirs`` integration arrives in D4
alongside the install-service CLI; until then the daemon uses XDG
paths on Linux + reasonable approximations on macOS / Windows.

Per #298 sub-RFC §File-system conventions:

| Purpose | Linux | macOS | Windows |
|---|---|---|---|
| State (daemon.json, sqlite, logs) | ~/.local/state/forge-manager/ | ~/Library/Application Support/forge-manager/ | %LOCALAPPDATA%\\forge-manager\\ |
| Logs (split target) | ~/.local/state/forge-manager/logs/ | ~/Library/Logs/forge-manager/ | %LOCALAPPDATA%\\forge-manager\\logs\\ |

Per-project subdirectory under each: ``<state-root>/<project-name>/``
so multiple projects on the same workstation don't collide.

Pure module — no IO. Functions return ``Path`` values; callers do
the IO.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


DEFAULT_PROJECT_NAME = "forge-manager"
"""Used for the bare ``state_dir()`` call when no project name is
supplied. Per-project setups should pass an explicit name."""


def _state_root() -> Path:
    """Return the platform-appropriate state-dir root.

    Linux: ``$XDG_STATE_HOME`` if set, else ``~/.local/state``.
    macOS: ``~/Library/Application Support`` (Apple's convention
        treats Application Support as the catch-all; macOS doesn't
        have a separate state dir).
    Windows: ``%LOCALAPPDATA%`` if set, else
        ``~/AppData/Local`` (the canonical fallback).
    """
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support"
    if sys.platform == "win32":
        local_app = os.environ.get("LOCALAPPDATA")
        if local_app:
            return Path(local_app)
        return Path.home() / "AppData" / "Local"
    # Linux / FreeBSD / etc.
    xdg = os.environ.get("XDG_STATE_HOME")
    if xdg:
        return Path(xdg)
    return Path.home() / ".local" / "state"


def _log_root() -> Path:
    """Return the platform-appropriate log-dir root.

    On macOS logs live under ``~/Library/Logs/`` (Apple
    convention). On Linux + Windows we co-locate logs under the
    state dir's ``logs/`` subdir.
    """
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Logs"
    return _state_root() / "forge-manager" / "logs"


def state_dir(project_name: str = DEFAULT_PROJECT_NAME) -> Path:
    """Return the per-project state directory.

    Layout: ``<state-root>/forge-manager/<project>/``.

    The directory is NOT created here — callers create on first
    write. Returns the path unconditionally so the caller can
    construct child paths (sqlite cache, daemon.json) without IO.
    """
    return _state_root() / "forge-manager" / project_name


def log_dir(project_name: str = DEFAULT_PROJECT_NAME) -> Path:
    """Return the per-project log directory.

    Layout: ``<log-root>/forge-manager/<project>/`` on macOS;
    ``<state-root>/forge-manager/<project>/logs/`` on Linux /
    Windows (the state dir's logs/ subdir).
    """
    if sys.platform == "darwin":
        return _log_root() / "forge-manager" / project_name
    return state_dir(project_name) / "logs"


def ensure_dir(path: Path, mode: int = 0o700) -> Path:
    """Create ``path`` (and parents) with restricted permissions.

    ``0o700`` keeps the daemon's tokens and cache files out of
    reach of peer users on the same machine — sufficient threat
    model for a localhost service. On Windows the mode is advisory
    (Python's mkdir doesn't translate it to ACLs); proper Windows
    ACL hardening lands in D4.
    """
    path.mkdir(parents=True, exist_ok=True)
    if sys.platform != "win32":
        try:
            path.chmod(mode)
        except OSError:
            # Best-effort — chmod can fail on some filesystems
            # (e.g. NFS without execute permission). Permissions
            # are a defense-in-depth layer; the discovery file's
            # session token is still the primary auth mechanism.
            pass
    return path
