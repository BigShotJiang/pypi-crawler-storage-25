"""Durable preferred-port file (Issue #472 / 3.14.0).

The daemon's port allocation history sticks to a single integer in
``<state-dir>/preferred-port``. The file is **separate from
``daemon.json``** because ``daemon.json`` is deleted on clean shutdown
(SIGTERM/SIGINT handler in ``daemon/main.py``), so its lifetime can't
carry "remember the last-bound port across daemon restarts."

Lifecycle:

* **Written** at port-allocation success (post-bind, before serving).
* **Read** at daemon spawn before binding.
* **NOT deleted** on daemon shutdown — operator can delete the file
  to reset the preference; the next spawn picks ephemeral and writes
  the new value.

Atomic write: temp + ``os.replace`` (same atomic-rename pattern as
``daemon/discovery.py`` and the #377 ``replication-state.json``
helper). 0o600 perms.

Pure-IO module — :func:`read_preferred_port` / :func:`write_preferred_port`
encapsulate the only effects. The port-selection logic lives in
:func:`pick_port` so it composes with both real ``socket.bind`` and
test-injected seams (Rule 10 — injectable seams).
"""
from __future__ import annotations

import os
import socket
import sys
from pathlib import Path
from typing import Callable


PREFERRED_PORT_FILENAME = "preferred-port"
"""Sibling-of-``daemon.json`` filename under the per-project state-dir."""


def preferred_port_path(state_dir: Path) -> Path:
    """Return the durable preferred-port file path under ``state_dir``.

    Pure: returns a path without touching the filesystem.
    """
    return state_dir / PREFERRED_PORT_FILENAME


def read_preferred_port(state_dir: Path) -> int | None:
    """Read the preferred-port file. Returns the integer, or ``None``.

    Returns ``None`` on every failure mode — file absent, unreadable,
    or malformed content. The caller (``pick_port``) treats ``None``
    identically to "first spawn ever" — fall through to ephemeral.

    Failure modes covered:
      * ``FileNotFoundError`` — never spawned before, or operator
        deleted the file as a reset.
      * ``PermissionError`` / ``OSError`` — peer-owned or unreadable
        file; surface as "no preference known."
      * ``ValueError`` — file contains non-integer content (truncated
        write, manual hand-edit gone wrong).
      * Out-of-range values (<=0 or >65535) — same fall-through.
    """
    target = preferred_port_path(state_dir)
    try:
        raw = target.read_text(encoding="utf-8")
    except (FileNotFoundError, PermissionError, OSError):
        return None
    try:
        port = int(raw.strip())
    except ValueError:
        return None
    if not (1 <= port <= 65535):
        return None
    return port


def write_preferred_port(state_dir: Path, port: int) -> Path:
    """Write the preferred-port file atomically with 0o600 perms.

    Pattern: temp + chmod + ``os.replace`` (atomic rename on POSIX,
    near-atomic on Windows). Matches ``daemon/discovery.py`` and the
    #377 ``replication-state.json`` helper.

    Raises ``ValueError`` on out-of-range ``port`` so the caller can't
    accidentally persist a placeholder.
    """
    if not (1 <= port <= 65535):
        raise ValueError(f"port out of range: {port}")
    state_dir.mkdir(parents=True, exist_ok=True)
    target = preferred_port_path(state_dir)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(f"{port}\n", encoding="utf-8")
    if sys.platform != "win32":
        try:
            tmp.chmod(0o600)
        except OSError:  # pragma: no cover — EXTERNAL: chmod fails on certain non-POSIX filesystems; daemon's POSIX-on-Linux runtime never trips this.
            pass
    tmp.replace(target)
    return target


def _try_bind(port: int) -> bool:
    """Bind a fresh socket to ``127.0.0.1:port`` and close. Returns
    True on success, False on ``OSError`` (port taken / privileged).

    Test seam — :func:`pick_port` accepts a ``try_bind`` override so
    deterministic tests don't race a real kernel socket allocation.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False
    finally:
        sock.close()


def _pick_ephemeral(
    bind_ephemeral: Callable[[], int],
) -> int:
    """Allocate an ephemeral port via the injected callable.

    The default callable binds ``127.0.0.1:0`` and reads the kernel-
    chosen port back via ``getsockname``. Tests inject deterministic
    seams.
    """
    return bind_ephemeral()


def _default_bind_ephemeral() -> int:
    """Real-socket ephemeral allocation. Pulled into a named function
    so :func:`pick_port` stays one assignment + one branch — the
    sequential effect lives here, the policy lives in
    :func:`pick_port`.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]
    finally:
        sock.close()


def pick_port(
    state_dir: Path,
    *,
    try_bind: Callable[[int], bool] | None = None,
    bind_ephemeral: Callable[[], int] | None = None,
) -> int:
    """Pick the port the daemon should serve on.

    Policy:
      1. Read the preferred-port file. If present + bindable, return
         that port — the operator's bookmark survives the restart.
      2. Otherwise, allocate a fresh ephemeral via
         ``bind_ephemeral`` and return it.

    Composability: the caller is responsible for writing the chosen
    port back via :func:`write_preferred_port` after the real listen
    socket binds; that keeps the preference in sync when case 2
    fires (transient conflict permanently shifts the preference; the
    Issue's case 3 path).

    ``try_bind`` / ``bind_ephemeral`` are injectable seams (Rule 10)
    so tests don't race the kernel. ``None`` resolves through this
    module's namespace at call time so a monkeypatch of
    ``preferred_port._try_bind`` / ``preferred_port._default_bind_ephemeral``
    affects this function — keeps the daemon-main shim
    (:func:`_pick_port_with_persistence`) testable without
    threading seams through its signature.
    """
    bind_check = try_bind if try_bind is not None else _try_bind
    ephemeral_alloc = (
        bind_ephemeral if bind_ephemeral is not None
        else _default_bind_ephemeral
    )
    preferred = read_preferred_port(state_dir)
    if preferred is not None and bind_check(preferred):
        return preferred
    return _pick_ephemeral(ephemeral_alloc)
