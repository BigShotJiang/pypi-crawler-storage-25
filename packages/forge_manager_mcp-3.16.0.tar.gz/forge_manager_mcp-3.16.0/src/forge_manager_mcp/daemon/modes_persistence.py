"""Persistent audit log for mode transitions (Issue #501 §Audit deferral).

Lives alongside :mod:`daemon.action_log` as a sibling sqlite-backed
event log. Pre-this-module the :class:`ModesStateHolder` from
:mod:`daemon.modes_state` carried transitions in an in-memory list
that lost everything across daemon restart. This module persists
them.

Schema mirrors the ModeTransition record shape: transition_id (uuid
hex), timestamp, actor, from_mode, to_mode, trigger (CHECK
constrained), gate_state_before / gate_state_after / changes
JSON-encoded.

Per :class:`SqliteAlertLog`'s pattern (3.6.0 D4.2 / #354): the daemon
owns the connection lifecycle. This module exposes
:func:`ensure_schema` for table bootstrap +
:class:`SqliteModeTransitionsLog` as the append/read surface.
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any, Iterable


SCHEMA_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS mode_transitions (
      transition_id TEXT PRIMARY KEY,
      timestamp TEXT NOT NULL,
      actor TEXT NOT NULL,
      from_mode TEXT NOT NULL,
      to_mode TEXT NOT NULL,
      trigger TEXT NOT NULL CHECK (trigger IN (
        'select_mode', 'manual_toggle',
        'startup_compute', 'auto_recompute'
      )),
      gate_state_before TEXT NOT NULL,
      gate_state_after TEXT NOT NULL,
      changes TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_mode_transitions_timestamp "
    "ON mode_transitions(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_mode_transitions_trigger "
    "ON mode_transitions(trigger)",
)
"""DDL is additive — uses CREATE TABLE IF NOT EXISTS so re-running
on an existing schema is safe. The table is `stateful` per
shadow.types.STATEFUL classification: not derivable from canonical;
must survive schema-version bumps via CREATE-IF-NOT-EXISTS rather
than drop-and-rebuild."""


def ensure_schema(con: sqlite3.Connection) -> None:
    """Bootstrap or refresh the mode_transitions schema.

    Pure additive (CREATE TABLE IF NOT EXISTS for the table +
    CREATE INDEX IF NOT EXISTS for both indices). Caller invokes
    once at daemon startup. Idempotent across reruns.
    """
    for ddl in SCHEMA_DDL:
        con.execute(ddl)
    con.commit()


class SqliteModeTransitionsLog:
    """Persistent audit log of mode transitions.

    API mirrors :class:`SqliteAlertLog`:

    * :meth:`record` — append one transition row. PK collision on
      ``transition_id`` raises sqlite3.IntegrityError.
    * :meth:`recent` — chronological read with optional cursor + limit.
    * :meth:`__len__` — row count.
    * :meth:`clear` — DELETE FROM mode_transitions; tests + operator
      audit-log reset.

    Per the daemon-owned-connection pattern: the caller passes a
    live sqlite3.Connection. This class holds a reference and never
    closes it.
    """

    def __init__(self, con: sqlite3.Connection):
        self._con = con

    def record(self, transition: Any) -> None:
        """Append a ModeTransition to the table.

        Expects a record with attributes matching
        :class:`forge_manager_mcp.daemon.modes_state.ModeTransition`:
        transition_id (str), timestamp (str), actor (str),
        from_mode (str), to_mode (str), trigger (str),
        gate_state_before (dict), gate_state_after (dict),
        changes (tuple of GateChange).

        Idempotent on ``transition_id`` collision: each ModeTransition
        carries a uuid4 hex id, so collisions imply duplicate-record
        (the holder's _audit_log shouldn't double-append). Raises
        IntegrityError on duplicate so the caller can surface the
        bug rather than silently dropping.
        """
        gate_state_before_json = json.dumps(
            transition.gate_state_before, sort_keys=True,
        )
        gate_state_after_json = json.dumps(
            transition.gate_state_after, sort_keys=True,
        )
        changes_json = json.dumps(
            [
                {
                    "gate": c.gate,
                    "before": c.before,
                    "after": c.after,
                    "scope": list(c.scope),
                }
                for c in transition.changes
            ],
            sort_keys=True,
        )
        self._con.execute(
            """
            INSERT INTO mode_transitions (
              transition_id, timestamp, actor,
              from_mode, to_mode, trigger,
              gate_state_before, gate_state_after, changes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                transition.transition_id,
                transition.timestamp,
                transition.actor,
                transition.from_mode,
                transition.to_mode,
                transition.trigger,
                gate_state_before_json,
                gate_state_after_json,
                changes_json,
            ),
        )
        self._con.commit()

    def recent(
        self,
        *,
        since: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Read transitions sorted by timestamp ascending.

        ``since`` filters to rows with ``timestamp >= since`` (ISO-8601
        UTC string match). ``limit`` caps the result set; None means
        return all. JSON fields decode back to dict/list.
        """
        sql = "SELECT * FROM mode_transitions"
        params: list[Any] = []
        if since is not None:
            sql += " WHERE timestamp >= ?"
            params.append(since)
        sql += " ORDER BY timestamp, transition_id"
        if limit is not None:
            sql += " LIMIT ?"
            params.append(int(limit))
        cur = self._con.execute(sql, params)
        rows = cur.fetchall()
        return [
            {
                "transition_id": row[0],
                "timestamp": row[1],
                "actor": row[2],
                "from_mode": row[3],
                "to_mode": row[4],
                "trigger": row[5],
                "gate_state_before": json.loads(row[6]),
                "gate_state_after": json.loads(row[7]),
                "changes": json.loads(row[8]),
            }
            for row in rows
        ]

    def __len__(self) -> int:
        row = self._con.execute(
            "SELECT COUNT(*) FROM mode_transitions"
        ).fetchone()
        return int(row[0])

    def clear(self) -> None:
        """Delete all rows — operator audit-log reset / tests."""
        self._con.execute("DELETE FROM mode_transitions")
        self._con.commit()
