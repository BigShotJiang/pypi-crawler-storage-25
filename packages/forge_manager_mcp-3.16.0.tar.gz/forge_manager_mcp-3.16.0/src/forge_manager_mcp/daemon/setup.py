"""Daemon-side scaffold orchestration (3.8.0 D3.2 / Discussion #11).

Mirror of the MCP-side ``scaffold_project_multi`` handler's adapter
dispatch loop, exposed via ``POST /setup/scaffold`` so the config
wizard can run scaffold without the operator having to drop into
Claude conversational mode.

D3.2 ships the adapter-walk + per-adapter ``bootstrap_project``
call. Local file generation (``CLAUDE.md`` + ``.claude/project-
rules.md``) deferred to D3.6 so the daemon endpoint stays focused
on the cross-backend orchestration that's hard to do from the UI
side.

Per Discussion #11 OQ8 path b: the daemon dispatches via the
shared ``PLATFORM_ADAPTERS`` registry rather than coupling to the
MCP-server-handler import chain. Adapters not in the registry
raise ``ValueError`` from the call site (matches the MCP handler's
behavior).
"""
from __future__ import annotations

from typing import Any


async def run_scaffold(
    *,
    project_name: str,
    description: str,
    platforms: "list[dict]",
    replication_order: "list[str]",
) -> dict:
    """Walk ``replication_order``, dispatch ``bootstrap_project`` on
    every adapter with ``has_scaffold = True``, return aggregated
    results.

    ``platforms`` is a list of platform-config entries; the
    ``replication_order`` strings index into them. Adapters with
    ``has_scaffold = False`` (LocalStore-only setups don't need
    GitHub-style scaffolding) are skipped with a note in the
    response.

    Returns ``{per_platform, pending_manual, skipped}``:

    * ``per_platform`` — list of ``{platform_id, artifacts, phase,
      manual_steps}`` dicts, one per adapter that ran.
    * ``pending_manual`` — flattened manual_steps across all
      adapters (operator-action items the wizard surfaces).
    * ``skipped`` — adapter ids with ``has_scaffold = False``.

    Raises ``ValueError`` for unknown platform_ids in
    replication_order; the wizard surfaces the message in its error
    state.
    """
    from forge_manager_mcp.adapters.registry import PLATFORM_ADAPTERS

    if not project_name.strip():
        raise ValueError("project_name must not be empty")
    if not replication_order:
        raise ValueError("replication_order must list at least one platform")

    platforms_by_id = {entry.get("id", ""): entry for entry in platforms}
    existing_state: dict = {}
    per_platform: list[dict] = []
    pending_manual: list[str] = []
    skipped: list[str] = []

    for platform_id in replication_order:
        adapter_cls = PLATFORM_ADAPTERS.get(platform_id)
        if adapter_cls is None:
            raise ValueError(
                f"unknown platform_id {platform_id!r}; "
                f"known: {sorted(PLATFORM_ADAPTERS)}"
            )
        platform_config = platforms_by_id.get(
            platform_id, {"id": platform_id},
        )
        if not adapter_cls.has_scaffold:
            skipped.append(platform_id)
            continue

        adapter = _construct_adapter(
            adapter_cls, platform_id, platform_config, project_name,
        )
        owner = platform_config.get("owner", "")
        result = await adapter.bootstrap_project(
            owner=owner,
            project_name=project_name,
            description=description,
            existing_state=existing_state,
        )
        existing_state[platform_id] = dict(result.artifacts)
        per_platform.append({
            "platform_id": result.platform_id,
            "artifacts": dict(result.artifacts),
            "phase": result.phase,
            "manual_steps": list(result.manual_steps),
        })
        pending_manual.extend(result.manual_steps)

    return {
        "per_platform": per_platform,
        "pending_manual": pending_manual,
        "skipped": skipped,
    }


def _construct_adapter(
    adapter_cls: Any, platform_id: str, platform_config: dict,
    project_name: str,
):
    """Construct one adapter for the scaffold walk.

    LocalStore needs a docs-repo path that the wizard caller hasn't
    necessarily set yet; we synthesize a default under the
    operator's home directory matching the project name. Other
    adapters use their ``from_config`` factory.
    """
    if platform_id == "local":
        from pathlib import Path
        from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
        docs_path_str = platform_config.get("docs_repo_path")
        if docs_path_str:
            docs_path = Path(docs_path_str).expanduser()
        else:
            docs_path = Path.home() / f"{project_name}-docs"
        return LocalStoreAdapter(docs_repo_path=docs_path)
    return adapter_cls.from_config(platform_config)
