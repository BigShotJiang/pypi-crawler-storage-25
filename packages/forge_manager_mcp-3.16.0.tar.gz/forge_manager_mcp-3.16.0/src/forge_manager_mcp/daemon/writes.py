"""Daemon-side write dispatcher (Phase D5 / #355 / 3.6.0).

Capability 8 — HTTP-for-MCP per Discussion #6 OQ2 closure
("Option C — stdio MCP delegates to daemon"). MCP becomes a
thin adapter that POSTs canonical writes to the daemon's
``POST /writes`` endpoint; daemon owns ReplicationManager + all
state.

This module is the daemon-side dispatcher: a name → handler
registry that turns a wire-level ``{op, args}`` payload into a
``ReplicationManager.write`` call. Handlers know how to construct
the per-adapter closure for each op type.

**Effect-then-interceptor split (Rule 2).** The registry itself is
data; ``register`` is a decorator that mutates module state once
at import time; ``get_handler`` / ``all_ops`` are pure queries.
The handler functions themselves are async effect functions.

**Schema-as-data (Rule 5).** No Pydantic schemas at module level.
Per-op argument validation is handler-internal duck typing for
3.6.0 (#355 OQ2 closure: "formalize to Pydantic schemas as the
surface stabilizes"). The serialization functions (``_serialize_*``)
are factories invoked per-call.

**Migration policy.** D5.1 ships ``create_issue`` as the reference
op; D5.2+ migrate the rest of the write surface in dependency
order (#355 §Migration order).
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable

# An op handler takes the daemon's ReplicationManager + the op args
# dict; returns the WriteResult-equivalent dict for JSON
# serialization. Async because ReplicationManager.write is async.
OpHandler = Callable[[Any, dict], Awaitable[dict]]


_OP_REGISTRY: dict[str, OpHandler] = {}


def register(op_name: str):
    """Decorator: register a write-op handler under ``op_name``.

    Idempotent within a single import — re-registering the same
    name overrides (useful for tests that monkeypatch a handler).
    """
    def deco(fn: OpHandler) -> OpHandler:
        _OP_REGISTRY[op_name] = fn
        return fn
    return deco


def get_handler(op_name: str) -> OpHandler | None:
    """Look up a registered handler. Returns None for unknown ops —
    caller turns this into a 400 response."""
    return _OP_REGISTRY.get(op_name)


def all_ops() -> list[str]:
    """Return all registered op names, sorted. Used by the
    daemon's diagnostics surface."""
    return sorted(_OP_REGISTRY.keys())


# --- Serialization helpers ------------------------------------------------


def _serialize_mirror_warnings(warnings: tuple) -> list[dict]:
    """Convert a tuple of MirrorWarning dataclass instances into the
    JSON-friendly list-of-dicts shape the wire protocol uses."""
    return [
        {
            "platform_id": w.platform_id,
            "operation": w.operation,
            "error_type": w.error_type,
            "error_message": w.error_message,
        }
        for w in warnings
    ]


def _serialize_artifact(artifact) -> Any:
    """Convert a Pydantic adapter type (Issue, Discussion, Comment,
    etc.) to a dict via model_dump. Returns None for None inputs.

    The MCP-side caller deserializes back to the matching Pydantic
    type at the handler boundary — same shape, just round-tripped
    through JSON.
    """
    if artifact is None:
        return None
    if hasattr(artifact, "model_dump"):
        return artifact.model_dump(mode="json")
    # Fallback for plain values (str, int, dict). Adapters return
    # rich types in normal use, but tests sometimes stub primitives.
    return artifact


# --- Op handlers (D5.1: create_issue) -------------------------------------


@register("append_comment")
async def _op_append_comment(replication, args: dict) -> dict:
    """Dispatch an append_comment canonical write (D5.3 / post_turn).

    Args:
        parent_kind: Literal["issue", "discussion"]
        parent_native_id: str — the parent's ref.native_id.
        owner: str
        repo: str
        body: str
        repo_role: str (optional, default "private")

    The daemon reconstructs the parent ``ArtifactRef`` from the
    typed fields + per-platform coords; the adapter dispatches
    to ``add_discussion_comment`` vs ``add_issue_comment`` based
    on ``parent_kind``.

    Returns:
        ``{value: <Comment dict>, mirror_warnings: [...]}``
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    parent_kind = args["parent_kind"]
    parent_native_id = args["parent_native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        parent_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=parent_native_id,
            kind=parent_kind,
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.append_comment(parent_ref, body)

    write_result = await replication.write(
        operation_name="append_comment",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("create_discussion")
async def _op_create_discussion(replication, args: dict) -> dict:
    """Dispatch a create_discussion canonical write (D5.4).

    Args:
        owner: str
        repo: str
        title: str
        body: str
        category: str — Discussion category name; each adapter
            resolves to its own backend representation (GitHub
            GraphQL category node ID via per-adapter
            ``_discussion_categories`` map; Forgejo / GitLab
            encode as ``category:*`` labels per OQ1 design;
            LocalStore writes the name into meta.json).
        repo_role: str (optional, default "private")

    Returns:
        ``{value: <Discussion dict>, mirror_warnings: [...]}``
    """
    title = args["title"]
    body = args["body"]
    category = args["category"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.create_discussion(
            owner=c_owner or owner,
            repo=c_repo or repo,
            title=title,
            body=body,
            category=category,
        )

    write_result = await replication.write(
        operation_name="create_discussion",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_issue_body")
async def _op_update_issue_body(replication, args: dict) -> dict:
    """Dispatch an update_issue_body canonical write (D5.5).

    Args:
        native_id: str — issue ref native_id (``issues/<n>``).
        owner: str
        repo: str
        body: str — new body text.
        force: bool — bypass size guardrail.
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}`` — the
    underlying adapter method returns None on success.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    force = args.get("force", False)
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_issue_body(ref, body, force=force)

    write_result = await replication.write(
        operation_name="update_issue_body",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_issue_milestone")
async def _op_update_issue_milestone(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch an update_issue_milestone canonical write.

    Args:
        native_id: str — issue ref native_id (``issues/<n>``).
        owner: str
        repo: str
        milestone_title: str | None — None clears the milestone.
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}`` — the
    underlying adapter method returns None on success.

    Closes the meta-bypass that surfaced during 3.9.0 planning:
    queueing Issues onto a milestone required direct meta.json edits
    because no MCP / daemon dispatch existed for milestone mutation.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    milestone_title = args.get("milestone_title")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_issue_milestone(ref, milestone_title)

    write_result = await replication.write(
        operation_name="update_issue_milestone",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_discussion_body")
async def _op_update_discussion_body(replication, args: dict) -> dict:
    """Dispatch an update_discussion_body canonical write (D5.5).

    Mirrors ``update_issue_body`` but ref.kind = "discussion".
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    force = args.get("force", False)
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_discussion_body(ref, body, force=force)

    write_result = await replication.write(
        operation_name="update_discussion_body",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("close_issue")
async def _op_close_issue(replication, args: dict) -> dict:
    """Dispatch a close_issue canonical write (D5.6).

    Args:
        native_id: str — issue ref native_id.
        owner: str
        repo: str
        state_reason: str — typically "completed" / "not_planned".
        repo_role: str (optional, default "private")

    Returns ``{value: <Issue dict>, mirror_warnings: [...]}`` —
    the closed Issue's post-close state (Phase C2 contract).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    state_reason = args["state_reason"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.close_issue(ref, state_reason=state_reason)

    write_result = await replication.write(
        operation_name="close_issue",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("mark_answer")
async def _op_mark_answer(replication, args: dict) -> dict:
    """Dispatch a mark_answer canonical write (D5.6).

    Args:
        native_id: str — comment ref native_id.
        owner: str
        repo: str
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}``. Adapters
    without a Discussion-mark-answer surface raise
    NotImplementedError → daemon returns 500 → MCP turns it into
    DaemonUnavailableError (caught by the dispatch layer per
    #355 / D5.3 wrapping).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        comment_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="comment",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.mark_answer(comment_ref)

    write_result = await replication.write(
        operation_name="mark_answer",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("mark_decided")
async def _op_mark_decided(replication, args: dict) -> dict:
    """Dispatch a mark_decided canonical write (#409).

    Flips the parent Discussion's state.txt second axis to add
    ``decided``. Distinct from ``mark_answer`` (which marks a
    specific comment as the GitHub answer); ``mark_decided`` is the
    portable Discussion-level decision marker that LocalStore can
    fulfill (filesystem state.txt) and remote backends without a
    comment-level answer surface can implement via their native
    ``decided``-equivalent.

    Args:
        native_id: str — discussion ref native_id.
        owner: str
        repo: str
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}``.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.mark_decided(ref)

    write_result = await replication.write(
        operation_name="mark_decided",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("mark_discussion_decided")
async def _op_mark_discussion_decided(replication, args: dict) -> dict:
    """(#486) Combined Discussion-decided canonical write.

    Atomic alternative to the pre-#486 two-call sequence
    ``mark_decided`` + ``mark_answer``. Routes through
    ``adapter.mark_discussion_decided(disc_ref, comment_ref)`` so
    the canonical LocalStore adapter writes both state.txt and
    the comment-as-answer metadata together; mirror fan-out lands
    as warnings rather than propagating past canonical success.

    Args:
        disc_native_id: str — Discussion ref native_id.
        owner: str
        repo: str
        comment_native_id: str | None — optional comment ref
            native_id. Path-form (``discussions/<N>/comments/<file>``)
            is canonical-store-only; GitHub node IDs (``DC_kwDO...``)
            also drive the GitHub markDiscussionCommentAsAnswer
            mutation on the mirror.
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}``.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    disc_native_id = args["disc_native_id"]
    owner = args["owner"]
    repo = args["repo"]
    comment_native_id = args.get("comment_native_id")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        disc_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=disc_native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        comment_ref = None
        if comment_native_id:
            comment_ref = ArtifactRef(
                platform_id=adapter.platform_id,
                native_id=comment_native_id,
                kind="comment",
                owner=c_owner or owner,
                repo=c_repo or repo,
                number=None,
            )
        return await adapter.mark_discussion_decided(disc_ref, comment_ref)

    write_result = await replication.write(
        operation_name="mark_discussion_decided",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("upsert_gap")
async def _op_upsert_gap(replication, args: dict) -> dict:
    """(#405 / 3.11.0 D1.b) Detector-driven gap upsert.

    Args:
        category: str — detector category name.
        tier: str — 'mechanical' or 'advisory'.
        findings: list[dict] — each {path, line, severity, message,
            first_seen_at, last_seen_at}.
        title: str (optional, defaults to category).
        repo_role: str (optional, default "private").
    """
    from forge_manager_mcp.adapters.types import GapFinding
    from datetime import datetime

    category = args["category"]
    tier = args["tier"]
    title = args.get("title", "")
    repo_role = args.get("repo_role", "private")

    findings_in = args.get("findings", [])
    findings = [
        GapFinding(
            path=f["path"],
            line=f.get("line"),
            severity=f["severity"],
            message=f["message"],
            first_seen_at=datetime.fromisoformat(f["first_seen_at"]),
            last_seen_at=datetime.fromisoformat(f["last_seen_at"]),
        )
        for f in findings_in
    ]

    async def op(adapter, coords):
        return await adapter.upsert_gap(
            category=category, tier=tier,
            findings=findings, title=title,
        )

    write_result = await replication.write(
        operation_name="upsert_gap",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_gap_state")
async def _op_update_gap_state(replication, args: dict) -> dict:
    """(#405 / 3.11.0 D1.b) Operator-driven state transition."""
    category = args["category"]
    state = args["state"]
    repo_role = args.get("repo_role", "private")
    transition_kwargs = {
        k: args.get(k)
        for k in (
            "changed_by", "note", "anchored_milestone",
            "accepted_phase", "filed_issue", "filed_target_milestone",
        )
    }

    async def op(adapter, coords):
        return await adapter.update_gap_state(
            category, state, **transition_kwargs,
        )

    write_result = await replication.write(
        operation_name="update_gap_state",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_gap_meta")
async def _op_update_gap_meta(replication, args: dict) -> dict:
    """(#405 / 3.11.0 D1.b) Update meta.json fields on a gap doc."""
    category = args["category"]
    fields = args.get("fields", {})
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        return await adapter.update_gap_meta(category, **fields)

    write_result = await replication.write(
        operation_name="update_gap_meta",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("create_milestone")
async def _op_create_milestone(replication, args: dict) -> dict:
    """Dispatch a create_milestone canonical write (#397 / 3.11.0 D1.a).

    Args:
        version: str — semver version string (e.g. "3.11.0")
        tier: str — "major" / "minor" / "patch"
        hotfix: bool (optional, default False)
        plan_discussion: int | list[int] | None (optional)
        title: str (optional, defaults to version)
        body: str (optional)
        repo_role: str (optional, default "private")

    Returns ``{value: <MilestoneArtifact dict>, mirror_warnings: [...]}``.
    Adapters with ``has_milestone_artifacts=False`` raise
    NotImplementedError → daemon returns 500 → MCP turns it into
    DaemonUnavailableError.
    """
    version = args["version"]
    tier = args["tier"]
    hotfix = args.get("hotfix", False)
    plan_discussion = args.get("plan_discussion")
    title = args.get("title", "")
    body = args.get("body", "")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        return await adapter.create_milestone(
            version=version,
            tier=tier,
            hotfix=hotfix,
            plan_discussion=plan_discussion,
            title=title,
            body=body,
        )

    write_result = await replication.write(
        operation_name="create_milestone",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_milestone_state")
async def _op_update_milestone_state(replication, args: dict) -> dict:
    """Dispatch a milestone state-transition (#397 / 3.11.0 D1.a)."""
    version = args["version"]
    state = args["state"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        return await adapter.update_milestone_state(version, state)

    write_result = await replication.write(
        operation_name="update_milestone_state",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_issue_meta")
async def _op_update_issue_meta(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506) Dispatch an update_issue_meta canonical
    write — generic field-bag mutation for an issue.

    Args:
        kind: str (default "issue")
        native_id: str
        owner: str
        repo: str
        fields: dict — per-kind allowlist enforced by the adapter
            (title / body / milestone). Only present keys mutate;
            unknown keys raise ForgeError at the adapter boundary.
        repo_role: str (optional, default "private")

    Returns ``{value: null, mirror_warnings: [...]}`` —
    update_issue_meta returns None (the existing
    update_issue_body convention); callers fetch the post-mutation
    state via a separate read if needed.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    fields = args.get("fields", {})
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_issue_meta(ref, **fields)

    write_result = await replication.write(
        operation_name="update_issue_meta",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_discussion_meta")
async def _op_update_discussion_meta(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506) Dispatch an update_discussion_meta
    canonical write — generic field-bag mutation for a discussion.

    Mirror of update_issue_meta with ref.kind = "discussion". The
    per-kind allowlist (title / body / category / anchored_milestone
    / decided_at) is enforced by the adapter.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    fields = args.get("fields", {})
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_discussion_meta(ref, **fields)

    write_result = await replication.write(
        operation_name="update_discussion_meta",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("reopen_issue")
async def _op_reopen_issue(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506 G5) Reopen a closed Issue. Inverse of
    close_issue. Multi-axis state.txt preserves non-lifecycle axes.
    Idempotent on already-open issues."""
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.reopen_issue(ref)

    write_result = await replication.write(
        operation_name="reopen_issue",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("unmark_decided")
async def _op_unmark_decided(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506 G5) Inverse of mark_decided — remove
    the "decided" axis from a Discussion's state. Multi-axis
    preserves non-decided axes. Idempotent on undecided
    Discussions."""
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.unmark_decided(ref)

    write_result = await replication.write(
        operation_name="unmark_decided",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("add_label")
async def _op_add_label(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506 G2) Add a label to an Issue or
    Discussion. The LocalStoreAdapter.add_label method existed
    pre-3.16.0 but no daemon op registered it, leaving labels
    mutation unreachable from MCP. This op closes that gap.

    Args:
        native_id: str (e.g. "issues/42")
        kind: str ("issue" | "discussion")
        owner: str
        repo: str
        label_name: str
        repo_role: str (optional, default "private")

    Returns ``{value: null, mirror_warnings: [...]}``.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    kind = args.get("kind", "issue")
    owner = args["owner"]
    repo = args["repo"]
    label_name = args["label_name"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind=kind,
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.add_label(ref, label_name)

    write_result = await replication.write(
        operation_name="add_label",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("remove_label")
async def _op_remove_label(replication, args: dict) -> dict:
    """(3.16.0 D4 / RFC #506 G2) Remove a label from an Issue or
    Discussion. Mirror of ``add_label`` with the inverse semantics.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef
    native_id = args["native_id"]
    kind = args.get("kind", "issue")
    owner = args["owner"]
    repo = args["repo"]
    label_name = args["label_name"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind=kind,
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.remove_label(ref, label_name)

    write_result = await replication.write(
        operation_name="remove_label",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_milestone_meta")
async def _op_update_milestone_meta(replication, args: dict) -> dict:
    """Dispatch a milestone meta.json patch (#397 / 3.11.0 D1.a).

    Args:
        version: str
        fields: dict — only present keys are mutated; values follow
            kwargs semantics (None = clear, value = set, omit = leave).
        repo_role: str (optional, default "private")
    """
    version = args["version"]
    fields = args.get("fields", {})
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        return await adapter.update_milestone_meta(version, **fields)

    write_result = await replication.write(
        operation_name="update_milestone_meta",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("create_issue")
async def _op_create_issue(replication, args: dict) -> dict:
    """Dispatch a create_issue canonical write.

    Args (all required unless noted):
        owner: str — repo owner.
        repo: str — repo name.
        title: str
        body: str
        labels: list[str] (optional, default empty)
        milestone: str | None (optional)
        repo_role: str (optional, default "private") — for
            per-platform coord resolution per #296.

    Returns:
        ``{value: <Issue dict>, mirror_warnings: [...]}``

    The daemon's ReplicationManager handles canonical-first write
    + mirror fan-out + warning accumulation per the existing
    contract; this handler is the thin shim that constructs the
    op closure.
    """
    title = args["title"]
    body = args["body"]
    labels = list(args.get("labels", []))
    milestone = args.get("milestone")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        owner, repo = coords
        return await adapter.create_issue(
            owner=owner,
            repo=repo,
            title=title,
            body=body,
            labels=labels,
            milestone=milestone,
        )

    write_result = await replication.write(
        operation_name="create_issue",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("attach_to_project_board")
async def _op_attach_to_project_board(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8 carryover) Attach an Issue to the configured
    project board on whichever replication adapter supports project
    boards (forgejo #10 / 3.4.0).

    Pre-D8 the MCP-side helper `_attach_to_project_board_if_supported`
    walked `ctx.replication.entries()` directly. This op moves the
    walk daemon-side so the MCP can delete its own ReplicationManager.

    Args:
        board_id: str — the configured project board's node ID.
        native_id: str — the Issue's ref.native_id.
        owner: str
        repo: str
        kind: str (default "issue")

    Returns:
        ``{value: <project_item_id>, mirror_warnings: []}`` —
        ``value`` is the empty string on no-op (no project_board
        configured, no adapter supports project_boards, or every
        supporting adapter raised ForgeError per the 3.4.2 fix).
        Mirror_warnings is always empty since this isn't a
        replication.write — single canonical adapter on a probe
        chain, not a fan-out.
    """
    from forge_manager_mcp.adapters.errors import ForgeError
    from forge_manager_mcp.adapters.types import ArtifactRef

    board_id = args.get("board_id")
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    kind = args.get("kind", "issue")

    if not board_id:
        return {"value": "", "mirror_warnings": []}

    for _platform_id, adapter in replication.entries():
        if not getattr(adapter, "has_project_boards", False):
            continue
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind=kind,
            owner=owner,
            repo=repo,
            number=None,
        )
        try:
            project_item_id = await adapter.add_to_project_board(
                board_id=board_id, ref=ref,
            )
            return {"value": project_item_id, "mirror_warnings": []}
        except ForgeError:
            # Per 3.4.2 fix: any ForgeError (Unavailable / HTTP 4xx /
            # validation / backend-specific subclass) falls through to
            # the next adapter; if no adapter succeeds, return "" so
            # the caller treats it as a clean no-op.
            continue

    return {"value": "", "mirror_warnings": []}


@register("move_project_item_to_column")
async def _op_move_project_item_to_column(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.8 carryover) Composite project-board move op.

    Encapsulates the 3 adapter calls the MCP-side ``move_project_item``
    handler used to make: walk entries() for has_project_boards →
    optional get_project_status_field (if status_options not pre-
    cached) → get_project_item_id → move_project_item. Pre-D8.8 the
    handler walked `ctx.replication.entries()` directly; this op
    moves the walk + the per-adapter sequence daemon-side so the
    MCP can delete its own ReplicationManager.

    Args:
        board_id: str — project board node ID.
        column_name: str — target Status column name (e.g. "Done").
        native_id: str — Issue's ref.native_id.
        owner: str
        repo: str
        kind: str (default "issue")
        status_field_id: str | None — pre-cached field ID; when
            None or empty, the daemon fetches via
            get_project_status_field.
        status_options: dict | None — pre-cached
            ``{column_name: option_id}`` map; same fetch-when-None
            semantics as status_field_id.

    Returns:
        ``{value: <success_message>, mirror_warnings: []}`` on
        success — value is e.g. "Moved to Done.". On no-supporting-
        adapter / unknown-column / per-adapter failure, returns
        ``{value: "", error: <message>}`` so the MCP can surface
        the structured error envelope to Claude.
    """
    from forge_manager_mcp.adapters.errors import ForgeError
    from forge_manager_mcp.adapters.types import ArtifactRef

    board_id = args["board_id"]
    column_name = args["column_name"]
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    kind = args.get("kind", "issue")
    status_field_id = args.get("status_field_id")
    status_options = args.get("status_options") or {}

    adapter = None
    for _platform_id, candidate in replication.entries():
        if getattr(candidate, "has_project_boards", False):
            adapter = candidate
            break
    if adapter is None:
        return {
            "value": "",
            "error": (
                "move_project_item_to_column: no configured platform "
                "supports project boards. GitHub is the only backend "
                "with a live impl today; Forgejo / GitLab / LocalStore "
                "raise NotImplementedError on the project-board "
                "surface."
            ),
            "mirror_warnings": [],
        }

    # (#459 / 3.13.0 D-Friction.4) Aggregation now lives in the
    # adapter via set_project_item_column. The daemon op routes
    # through the single Protocol entry point; chain knowledge no
    # longer leaks across the daemon-op boundary.
    ref = ArtifactRef(
        platform_id=adapter.platform_id,
        native_id=native_id,
        kind=kind,
        owner=owner,
        repo=repo,
        number=None,
    )
    try:
        await adapter.set_project_item_column(
            board_id=board_id,
            ref=ref,
            column_name=column_name,
            status_field_id=status_field_id,
            status_options=status_options,
        )
    except NotImplementedError:
        return {
            "value": "",
            "error": (
                f"set_project_item_column not implemented on "
                f"{adapter.platform_id}"
            ),
            "mirror_warnings": [],
        }
    except ForgeError as exc:
        # Surface the adapter's error verbatim — preserves the
        # "Column {name!r} not found" wording that callers depended
        # on pre-#459.
        msg = str(exc)
        if "not found on board" in msg.lower():
            return {
                "value": "",
                "error": f"Column {column_name!r} not found on board.",
                "mirror_warnings": [],
            }
        return {
            "value": "",
            "error": (
                f"project-board move failed: {type(exc).__name__}: {exc}"
            ),
            "mirror_warnings": [],
        }
    return {
        "value": f"Moved to {column_name}.",
        "mirror_warnings": [],
    }


@register("append_comment_to_per_platform_target")
async def _op_append_comment_to_per_platform_target(
    replication, args: dict,
) -> dict:
    """(#467 / #468 / 3.13.0 D-Friction.7+8) Fan out an append_comment
    write to each platform's configured Issue-encoded-as-Discussion
    target.

    Used by session-event handlers (close_session / open_session) and
    Project Index TOC writes to land their comment payloads on
    Codeberg / Forgejo backends where session-lock / project-index
    surfaces are encoded as Issues rather than native Discussions.

    Args:
        target_kind: "session_lock" or "project_index"
        body: str (comment content)

    Behavior: walks ``replication.entries()`` and skips canonical
    (local — its surface is the JSON event-file). For each remaining
    platform, resolves the target Issue number via
    ``replication.target_for_platform(platform_id, target_kind)``;
    when configured, builds an ``ArtifactRef`` carrying that number
    and dispatches ``adapter.append_comment``. Per-platform outcomes
    captured in the return so the caller can surface
    ``mirror_skipped`` / ``mirror_failures`` for visibility.

    Returns:
        ``{value: {"wrote_to": [<platform_id>...], "skipped":
        [{"platform_id", "reason"}...]}, "mirror_warnings": []}``.

    The op never raises — per-platform failures land in ``skipped``
    rather than propagating. The caller dispatches in
    best-effort-fan-out mode (session-event writes shouldn't fail
    the session-close).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    target_kind = args["target_kind"]
    body = args["body"]

    wrote_to: list[str] = []
    skipped: list[dict] = []

    for platform_id, adapter in replication.entries():
        if platform_id == "local":
            # Canonical-local has its own session-event surface; this
            # fan-out is for the non-canonical adapters that encode
            # Discussions as Issues.
            continue
        target_number = replication.target_for_platform(
            platform_id, target_kind,
        )
        if target_number is None:
            skipped.append({
                "platform_id": platform_id,
                "reason": (
                    f"no {target_kind}_issue_number configured on "
                    f"platforms[{platform_id}]"
                ),
            })
            continue
        owner, repo = replication._coords_for(platform_id, "private")
        if not owner or not repo:
            skipped.append({
                "platform_id": platform_id,
                "reason": (
                    f"private-repo coords missing for "
                    f"platforms[{platform_id}]"
                ),
            })
            continue
        ref = ArtifactRef(
            platform_id=platform_id,
            native_id="",
            kind="issue",
            owner=owner,
            repo=repo,
            number=int(target_number),
        )
        try:
            await adapter.append_comment(ref, body)
            wrote_to.append(platform_id)
        except Exception as exc:  # noqa: BLE001 — best-effort fan-out
            skipped.append({
                "platform_id": platform_id,
                "reason": f"{type(exc).__name__}: {exc}",
            })

    return {
        "value": {"wrote_to": wrote_to, "skipped": skipped},
        "mirror_warnings": [],
    }


@register("update_body_on_per_platform_target")
async def _op_update_body_on_per_platform_target(
    replication, args: dict,
) -> dict:
    """(#467 / #468 / 3.13.0 D-Friction.7+8) Fan out an
    update_issue_body write to each platform's configured Issue-
    encoded-as-Discussion target.

    Sibling op to ``append_comment_to_per_platform_target`` — same
    walk semantics, but replaces the target Issue's body (used for
    Project Index TOC updates on Codeberg / Forgejo where the
    Project Index is encoded as an Issue whose opening post is the
    TOC).

    Args:
        target_kind: "project_index" (session_lock targets only
            accumulate comments; this op is body-replacement only)
        body: str (new body content)
        force: bool (optional; passed to adapter.update_issue_body)

    Returns: same shape as the comment fan-out op
        ``{value: {"wrote_to": [...], "skipped": [...]},
        "mirror_warnings": []}``.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    target_kind = args["target_kind"]
    body = args["body"]
    force = bool(args.get("force", False))

    wrote_to: list[str] = []
    skipped: list[dict] = []

    for platform_id, adapter in replication.entries():
        if platform_id == "local":
            continue
        target_number = replication.target_for_platform(
            platform_id, target_kind,
        )
        if target_number is None:
            skipped.append({
                "platform_id": platform_id,
                "reason": (
                    f"no {target_kind}_issue_number configured on "
                    f"platforms[{platform_id}]"
                ),
            })
            continue
        owner, repo = replication._coords_for(platform_id, "private")
        if not owner or not repo:
            skipped.append({
                "platform_id": platform_id,
                "reason": (
                    f"private-repo coords missing for "
                    f"platforms[{platform_id}]"
                ),
            })
            continue
        ref = ArtifactRef(
            platform_id=platform_id,
            native_id="",
            kind="issue",
            owner=owner,
            repo=repo,
            number=int(target_number),
        )
        try:
            await adapter.update_issue_body(ref, body, force=force)
            wrote_to.append(platform_id)
        except Exception as exc:  # noqa: BLE001 — best-effort fan-out
            skipped.append({
                "platform_id": platform_id,
                "reason": f"{type(exc).__name__}: {exc}",
            })

    return {
        "value": {"wrote_to": wrote_to, "skipped": skipped},
        "mirror_warnings": [],
    }


@register("set_repo_visibility")
async def _op_set_repo_visibility(replication, args: dict) -> dict:
    """(#456 / 3.13.0 D-Friction.2) Flip a repo's visibility on the
    first adapter that supports it.

    Walks ``replication.entries()`` for an adapter that implements
    ``set_visibility`` (currently GitHub only; Forgejo / GitLab /
    LocalStore raise NotImplementedError until they add the impl).

    Args:
        owner: str
        repo: str
        target: "public" | "private"
        confirmed_consequences: bool — operator's explicit
            acknowledgment of the blast-radius. Threaded directly
            into the adapter call; the adapter raises
            ``ConsentRequiredError`` when False on backends that
            require consent (GitHub).
        repo_role: str (optional) — used by ReplicationManager for
            coord resolution per #296.

    Returns:
        ``{value: "<target> applied to <owner>/<repo>", mirror_warnings: []}``
        on success; ``{value: "", error: <message>, mirror_warnings: []}``
        on failure.
    """
    from forge_manager_mcp.adapters.errors import (
        ConsentRequiredError, ForgeError,
    )

    owner = args["owner"]
    repo = args["repo"]
    target = args["target"]
    confirmed_consequences = bool(args.get("confirmed_consequences", False))

    # Walk adapters for one that implements set_visibility. The
    # Protocol default raises NotImplementedError so try/except
    # selects the first supporting adapter without a capability flag.
    for _platform_id, candidate in replication.entries():
        try:
            await candidate.set_visibility(
                owner=owner, repo=repo, target=target,
                confirmed_consequences=confirmed_consequences,
            )
            return {
                "value": (
                    f"visibility set to '{target}' on {owner}/{repo} "
                    f"via {_platform_id}"
                ),
                "mirror_warnings": [],
            }
        except NotImplementedError:
            continue
        except ConsentRequiredError as exc:
            # Consent gate failure is permanent — surface immediately.
            return {
                "value": "",
                "error": f"ConsentRequiredError: {exc}",
                "mirror_warnings": [],
            }
        except ForgeError as exc:
            return {
                "value": "",
                "error": (
                    f"set_visibility failed on {_platform_id}: "
                    f"{type(exc).__name__}: {exc}"
                ),
                "mirror_warnings": [],
            }

    return {
        "value": "",
        "error": (
            "set_repo_visibility: no configured platform supports "
            "visibility flips. GitHub is the only backend with a live "
            "impl today; Forgejo / GitLab / LocalStore raise "
            "NotImplementedError on the set_visibility surface."
        ),
        "mirror_warnings": [],
    }


@register("replay_pending_writes")
async def _op_replay_pending_writes(replication, args: dict) -> dict:
    """(#23 A.5 OQ2 / 3.15.0) Compat stub — the ReplicationManager's
    pending_writes queue retired with the DEGRADED state machine.
    Returns an empty report so the MCP-side replay_pending handler's
    legacy daemon-dispatch path doesn't 404. Always returns
    ``{value: {}, mirror_warnings: []}``.

    The replay_pending MCP tool still drains the file buffer at
    ``.claude/pending-posts.md`` (the permanent-error post-buffering
    surface from 3.13.0 #462/#465); this stub just handles the
    `replication` target's no-op case.
    """
    return {"value": {}, "mirror_warnings": []}


@register("record_session_event")
async def _op_record_session_event(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.11 carryover) Record a session-lifecycle event
    on the canonical adapter's session-event surface.

    Pre-D8.11 the MCP-side `open_session` / `close_session` handlers
    fetched `ctx.replication.canonical()` directly and called
    `record_session_event` against the adapter. Post-D8.11 the
    daemon owns the canonical access; the handler just dispatches.

    Args:
        session_id: str
        event: str ("opened" or "closed")
        body: str (event payload — timestamp + skill version for
            "opened"; close summary for "closed")

    Behavior:
        - Probes the canonical adapter for ``has_session_event_
          surface``. Only LocalStoreAdapter has this surface today
          (#270 native session-lock); other backends encode session
          events as Discussion comments via add_comment.
        - When the canonical surface is unavailable, returns a
          structured no-op envelope so the MCP-side handler can
          surface "skipped" rather than treating it as an error.

    Returns:
        ``{value: <event_dict>, mirror_warnings: []}`` on success
        (event_dict is the recorded SessionEvent's model_dump).
        ``{value: None, "skipped_reason": <str>, mirror_warnings: []}``
        when the canonical adapter doesn't support the surface.
    """
    session_id = args["session_id"]
    event = args["event"]
    body = args.get("body", "")

    canonical = replication.canonical()
    if not getattr(canonical, "has_session_event_surface", False):
        return {
            "value": None,
            "skipped_reason": (
                f"canonical adapter platform_id="
                f"{canonical.platform_id!r} has "
                "has_session_event_surface=False; session events "
                "encode as Discussion comments via the legacy path."
            ),
            "mirror_warnings": [],
        }

    try:
        recorded = await canonical.record_session_event(
            session_id=session_id, event=event, body=body,
        )
    except Exception as exc:
        return {
            "value": None,
            "error": (
                f"{canonical.platform_id}: record_session_event "
                f"failed: {type(exc).__name__}: {exc}"
            ),
            "mirror_warnings": [],
        }

    if hasattr(recorded, "model_dump"):
        return {
            "value": recorded.model_dump(mode="json"),
            "mirror_warnings": [],
        }
    return {"value": recorded, "mirror_warnings": []}
