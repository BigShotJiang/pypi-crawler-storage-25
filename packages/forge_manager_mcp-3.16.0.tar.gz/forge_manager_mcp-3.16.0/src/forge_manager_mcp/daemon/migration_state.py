"""In-memory migration state holder for the daemon (3.16.0 D1 / A.1).

Tracks in-flight migrations and their per-step lifecycle state so the
UI's <MigrationSwimlane> (consumer of `GET /migrations/status` + SSE
`migration.*` events) can render a live view across daemon-MCP
boundary.

**Persistence posture: in-memory only.** Migrations are infrequent
one-shot operations; persisting through daemon restart would add
complexity without operational value at 3.16.0 scope. A daemon crash
mid-migration is operator-visible (`.claude/backups/migration-<ts>/`
tarball stays put; rollback path documented in
`flows/migration/__init__.py`), so losing the live-view payload across
a crash is acceptable. A future `migrations_facts` shadow table (per
3.14.0 OQ8 Tier 4 deferral) can promote this to durable storage
without changing the holder's API.

**Concurrency posture: single-threaded.** Daemon serves requests via
uvicorn's asyncio event loop. Holder mutations happen from within
HTTP handlers + write-completed event consumers, all on the same loop.
No locks needed; we never await between read-then-write.

Schema-as-functions per Rule 5: the MigrationStep + Migration dicts
are constructed via factory helpers below, not top-level Pydantic
classes. Adheres to the project's code-design.md Rule 5
(@code_design.schema_as_functions).
"""
from __future__ import annotations

from typing import Any, Callable


# ---------------------------------------------------------------------------
# Factory helpers — Schema-as-functions (Rule 5)
# ---------------------------------------------------------------------------


def make_step(
    *,
    step_id: str,
    title: str,
    state: str = "preview",
) -> dict[str, Any]:
    """Construct a migration-step record matching the UI's MigrationStep
    interface (ui/src/migrationCard.ts:86-90):
      {id, title, state: 'preview' | 'running' | 'complete'}

    ``state`` is validated against the lifecycle vocabulary; unknown
    states raise ValueError so callers learn at the boundary rather
    than producing UI rendering surprises.
    """
    if state not in ("preview", "running", "complete"):
        raise ValueError(
            f"MigrationStep state must be 'preview' / 'running' / "
            f"'complete', got {state!r}"
        )
    return {"id": step_id, "title": title, "state": state}


def make_migration(
    *,
    migration_id: str,
    title: str,
    steps: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Construct a migration envelope record:
      {id, title, steps: [step_dict, ...]}

    Convention: ``migration_id`` is a slug describing the target
    (e.g. ``"migration:to-4-0"``, ``"migration:bootstrap-docs-repo"``);
    used as the SSE event key + the holder's primary key.
    """
    return {
        "id": migration_id,
        "title": title,
        "steps": list(steps or []),
    }


# ---------------------------------------------------------------------------
# State holder
# ---------------------------------------------------------------------------


class MigrationStateHolder:
    """In-memory store of in-flight migrations keyed by migration_id.

    Lifecycle:
      * ``upsert_migration`` — register a new migration or replace an
        existing one's step list (the MCP migration handler calls this
        at run-start with the full step plan).
      * ``update_step_state`` — flip a single step's state. Returns
        the (migration_id, step_id, prev_state, new_state) tuple for
        downstream SSE publish.
      * ``remove_migration`` — drop a migration entirely (operator
        dismissed via the title-bar × on <MigrationSwimlane>, or a
        cleanup pass post-completion).
      * ``list_migrations`` — return the current snapshot as a list.

    Optional event-publishing side-effect: when constructed with an
    ``event_publisher`` callable, each mutation fires the corresponding
    SSE event (``migration.upserted`` / ``migration.step_changed`` /
    ``migration.removed``) via that callable. The callable receives
    ``(event_name, payload_dict)`` and is expected to publish onto
    whichever broadcaster the caller wired. The publisher path is
    optional so the holder stays unit-testable without a broadcaster
    fixture; ``daemon/http.py`` wires the real publisher at app
    construction time. Publisher exceptions are swallowed so a
    broken broadcaster can't poison the holder's primary mutation
    contract.
    """

    def __init__(
        self,
        *,
        event_publisher: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        # migration_id → migration dict from make_migration.
        # Preserves insertion order (Python 3.7+ dict ordering).
        self._migrations: dict[str, dict[str, Any]] = {}
        self._event_publisher = event_publisher

    def _publish(self, event_name: str, payload: dict[str, Any]) -> None:
        """Fire an event via the wired publisher. Swallows publisher
        exceptions — the holder's primary contract is data
        consistency; broadcasting is best-effort."""
        if self._event_publisher is None:
            return
        try:
            self._event_publisher(event_name, payload)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Mutation
    # -----------------------------------------------------------------

    def upsert_migration(
        self, migration: dict[str, Any],
    ) -> None:
        """Register a new migration or replace an existing one.

        Idempotent: calling with the same id replaces the step list
        wholesale (caller decides whether to merge or reset state).

        Fires ``migration.upserted`` event when the wired publisher is
        present. Payload is the migration record itself
        (``{id, title, steps[]}``) so subscribers can rebuild local
        state from the event alone without a follow-up
        /migrations/status probe.
        """
        self._migrations[migration["id"]] = migration
        # Deep-copy steps in the payload so subsequent
        # update_step_state mutations don't retroactively change the
        # published event's snapshot. (Step dicts are shared by
        # reference between the holder's internal record and the
        # event payload; without the copy here, an SSE consumer
        # replaying the upsert event would see whatever step state
        # the holder eventually settled on, not the upsert-time
        # snapshot.)
        self._publish(EVENT_MIGRATION_UPSERTED, {
            "migration_id": migration["id"],
            "title": migration["title"],
            "steps": [dict(s) for s in migration["steps"]],
        })

    def update_step_state(
        self,
        migration_id: str,
        step_id: str,
        new_state: str,
    ) -> tuple[str, str, str, str] | None:
        """Flip a single step's state.

        Returns ``(migration_id, step_id, prev_state, new_state)`` on
        success; ``None`` when the migration or step isn't known
        (caller treats as a no-op — typical when an SSE consumer
        replays state-change events out of order or after a holder
        reset).

        Raises ValueError on an unknown ``new_state`` per
        ``make_step``'s vocabulary check.
        """
        if new_state not in ("preview", "running", "complete"):
            raise ValueError(
                f"new_state must be 'preview' / 'running' / "
                f"'complete', got {new_state!r}"
            )
        migration = self._migrations.get(migration_id)
        if migration is None:
            return None
        for step in migration["steps"]:
            if step["id"] == step_id:
                prev_state = step["state"]
                step["state"] = new_state
                self._publish(EVENT_MIGRATION_STEP_CHANGED, {
                    "migration_id": migration_id,
                    "step_id": step_id,
                    "prev_state": prev_state,
                    "new_state": new_state,
                })
                return (migration_id, step_id, prev_state, new_state)
        return None

    def remove_migration(self, migration_id: str) -> bool:
        """Drop a migration from the holder. Returns True if removed,
        False if it wasn't present (idempotent — operator can dismiss
        a swimlane that already auto-cleared on completion).

        Fires ``migration.removed`` event only on actual removal — a
        no-op call against an unknown id doesn't broadcast, since
        there's nothing for subscribers to react to."""
        removed = self._migrations.pop(migration_id, None) is not None
        if removed:
            self._publish(EVENT_MIGRATION_REMOVED, {
                "migration_id": migration_id,
            })
        return removed

    def clear(self) -> None:
        """Reset the holder to empty. Used by tests + daemon restart
        flow (state is in-memory only — restart resets)."""
        self._migrations.clear()

    # -----------------------------------------------------------------
    # Read
    # -----------------------------------------------------------------

    def list_migrations(self) -> list[dict[str, Any]]:
        """Return the current migrations as a list, preserving the
        order they were upserted in.

        Returns dict references to the holder's internal records —
        callers SHOULD treat them as read-only. The HTTP response
        serializer copies via ``json.dumps`` so mutation through the
        returned reference doesn't leak. For test isolation use
        ``snapshot()`` which returns deep copies."""
        return list(self._migrations.values())

    def snapshot(self) -> list[dict[str, Any]]:
        """Deep-copied snapshot for test isolation. Mutating the
        return value does not affect the holder's internal state."""
        return [
            {
                "id": m["id"],
                "title": m["title"],
                "steps": [dict(s) for s in m["steps"]],
            }
            for m in self._migrations.values()
        ]

    def get(self, migration_id: str) -> dict[str, Any] | None:
        """Fetch one migration by id, or None when absent."""
        return self._migrations.get(migration_id)

    def __len__(self) -> int:
        return len(self._migrations)


# ---------------------------------------------------------------------------
# SSE event names (vocabulary)
# ---------------------------------------------------------------------------

# Published when a new migration is registered with the holder.
# Payload: {migration_id, title, steps: [...]}.
EVENT_MIGRATION_UPSERTED = "migration.upserted"

# Published when a step's state transitions.
# Payload: {migration_id, step_id, prev_state, new_state}.
EVENT_MIGRATION_STEP_CHANGED = "migration.step_changed"

# Published when a migration is removed from the holder (operator
# dismissed via UI, or daemon cleanup pass on stale entries).
# Payload: {migration_id}.
EVENT_MIGRATION_REMOVED = "migration.removed"
