"""Effect functions for daemon HTTP handlers (Phase D3b.4p / #343).

Per code-design Rule 2 (Effect-then-interceptor pattern): every
effect — filesystem read, ReplicationManager mutation, broadcaster
publish — lives behind a named function with explicit inputs and
outputs. Handlers compose these effects.

Pre-#343 the daemon's handlers inlined effects, which works at
3.5.0's small scale but doesn't scale to capabilities 2 / 3 / 8 / 9
without the same refactor cost paid later. This module is the
3.5.0 conformance step.

**Scope cut for 3.5.0.** The full Issue body specifies
interceptor-chain wrappers + a `DaemonRequestContext` shape
threading effects together. That ceremony is deferred to 3.5.x —
the value-added piece (testable effect functions, handlers reduced
to thin orchestration) is delivered here. When capabilities 2/8/9
land they can use the full chain pattern from the start.

**Structure:**

* ``replication_state`` — pause / resume / list backends.
* ``files`` — directory tree + file content read (with traversal
  validation).
* ``events`` — broadcaster publishes (event + alert dual-publish
  helpers live in ``daemon/events.py`` proper; this module exposes
  the orchestration surface for handler reuse).
"""
