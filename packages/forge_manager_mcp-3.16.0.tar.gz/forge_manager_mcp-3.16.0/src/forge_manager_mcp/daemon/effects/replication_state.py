"""ReplicationManager-bound effects (Phase D3b.4p / #343).

The handlers' interactions with ReplicationManager — pause /
resume / snapshot — extracted to standalone functions so each is
testable with a stub manager + asserts on call shape, without a
full TestClient round-trip.

Per Rule 2 each effect:
  * takes explicit inputs (no Context coupling)
  * returns explicit outputs OR raises a typed exception
  * has a single call site at the boundary that mocks it cleanly
"""
from __future__ import annotations


class UnknownPlatform(KeyError):
    """Raised when a platform_id isn't in the manager's adapter list.
    Distinct subclass so handlers can map it to 404 without confusing
    it with other KeyError-raising bugs."""


# (#23 A.5 OQ1 / 3.15.0) pause_backend / resume_backend effects
# RETIRED — replaced by the inline enable_backend/disable_backend
# helpers in daemon/http.py that write directly to forge-config.json
# via atomic_write_config.


def list_backends(
    replication,
    config_payload: dict | None = None,
) -> list[dict]:
    """Snapshot the manager's per-adapter state into the wire shape
    used by GET /backends.

    Returns ``[]`` when ``replication is None`` so the handler can
    emit ``{"backends": []}`` without branching.

    Wire shape per Discussion #23 A.5 (3.15.0):

        {platform_id, canonical, enabled, health, last_error,
         last_error_at}

    - ``enabled`` (OQ1): operator-pause as a durable config flag.
    - ``health`` (OQ6): ``{level, last_failure_at,
      recent_failure_count}`` derived from per-push outcomes.
    - Legacy ``state`` / ``display_status`` / ``state_changed_at`` /
      ``next_attempt_at`` fields RETIRED (commit drops them; UI
      consumers migrated to ``health.level`` + ``enabled``).

    ``config_payload`` is the parsed forge-config.json dict (or None
    if no config loaded). When supplied, ``platforms[i].enabled`` is
    consulted via :func:`forge_manager_mcp.replication.enabled.is_enabled`
    to populate the per-entry ``enabled`` field. When None, defaults
    True for every entry.
    """
    if replication is None:
        return []
    from forge_manager_mcp.replication.enabled import is_enabled
    # Build a platform_id → platform_entry index so per-adapter enabled
    # lookups stay O(1) per entry rather than O(N) per platforms list.
    platforms_by_id: dict[str, dict] = {}
    if config_payload is not None:
        for plat in config_payload.get("platforms", []) or []:
            if isinstance(plat, dict):
                pid = plat.get("id")
                if isinstance(pid, str):
                    platforms_by_id[pid] = plat
    out: list[dict] = []
    for idx, entry in enumerate(replication._entries):
        plat_entry = platforms_by_id.get(entry.platform_id, {})
        enabled = is_enabled(plat_entry) if plat_entry else True
        # (A.5 / OQ6) Health derived from last_error: healthy when no
        # recent error; warn when last_error is recorded. The
        # recent_failure_count refines this with shadow-table data in
        # a follow-up (populated by the dispatch path's
        # emit_push_outcome call site).
        health_level = "warn" if entry.last_error is not None else "healthy"
        last_failure_at = (
            entry.last_error_at.isoformat()
            if entry.last_error_at is not None else None
        )
        out.append({
            "platform_id": entry.platform_id,
            "canonical": idx == 0,
            "last_error": (
                str(entry.last_error)
                if entry.last_error is not None else None
            ),
            "last_error_at": last_failure_at,
            "enabled": enabled,
            "health": {
                "level": health_level,
                "last_failure_at": last_failure_at,
                # `recent_failure_count` populated by the per-push
                # outcome substrate (replication_push_facts per OQ5);
                # 0 until that ships.
                "recent_failure_count": 0,
            },
        })
    return out
