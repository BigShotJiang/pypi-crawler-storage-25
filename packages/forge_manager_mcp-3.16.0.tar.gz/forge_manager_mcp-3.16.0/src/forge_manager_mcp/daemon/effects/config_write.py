"""Atomic config-file writes (#374 / 3.8.0 D3.1 / Discussion #11).

Helper for the daemon's ``POST /config`` endpoint. Writes to a
temp file in the target's directory, fsyncs, then atomically
renames into place — a power loss / crash mid-write leaves the
prior config intact rather than half-written.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


def atomic_write_config(target: Path, payload: dict) -> None:
    """Write ``payload`` (JSON) to ``target`` atomically.

    Creates parent directories if needed. The temp file lives in the
    same directory as ``target`` so the rename is on the same
    filesystem (cross-fs renames aren't atomic).

    Permissions: 0o644 — the config file isn't sensitive (tokens
    live in the encrypted credentials store, not here).
    """
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    body = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    fd, tmp_path = tempfile.mkstemp(
        prefix=".forge-config-",
        suffix=".tmp",
        dir=str(target.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(body)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_path, 0o644)
        os.replace(tmp_path, target)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
