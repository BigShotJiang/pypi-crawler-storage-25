"""Broadcaster-bound publish effects (Phase D3b.4p / #343).

Thin wrapper around the broadcaster API so handlers don't import
``make_event`` directly + so tests can assert on the called
broadcaster method without instantiating a full EventBroadcaster.

The dual-publish helper (``publish_alert`` to broadcaster + log)
already lives in ``daemon/events.py`` proper — this module is for
the simpler single-publish path used by ``POST /events``.
"""
from __future__ import annotations


def publish(broadcaster, event_name: str, data: dict) -> int:
    """Publish a single event; returns the subscriber count at
    publish time.

    Caller is responsible for validation (event is non-empty,
    data is a dict). Returns subscriber count so the handler's
    response can include it for operator debugging.
    """
    from forge_manager_mcp.daemon.events import make_event
    broadcaster.publish(make_event(event=event_name, data=data))
    return broadcaster.subscriber_count()
