"""Canonical-DB initialization for daemon startup (3.15.0 cluster A.2.9).

Per Discussion #23 (3.15.0 plan-Discussion). Opens the
canonical-DB sqlite connection at daemon startup, runs
:func:`canonical_db.register_all` so the registry is populated, and
calls :func:`canonical_db.core.ensure_initialized` to create the
schema if it's not at the current SCHEMA_VERSION.

Tolerant fallback: when the docs-repo path can't be resolved (no
forge-config.json / pre-bootstrap project / missing directory), the
function returns ``None`` and the daemon proceeds without canonical-DB.
This is the both-authoritative transition contract per OQ8 — during
3.15.x development cycles, the filesystem stays authoritative when
canonical-DB isn't available.

Per OQ27: the ``canonical_db_ready`` feature flag flips when A.4
(filesystem regenerator) ships. Until then, canonical-DB
initialization is best-effort; failures don't block daemon startup.

Effect-then-interceptor split (Rule 2): :func:`resolve_docs_repo`
is the pure path-resolution effect; :func:`startup` is the
composition (resolve → open → register → init) with structured
return.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
from pathlib import Path
from typing import NamedTuple

logger = logging.getLogger(__name__)


class CanonicalDBStartup(NamedTuple):
    """Structured result of :func:`startup`.

    Either ``connection`` is a live :class:`sqlite3.Connection` and
    ``db_path`` points at the canonical-DB file, OR ``connection`` is
    None and ``reason`` explains why init was skipped. Tolerant
    fallback contract per OQ8.
    """
    connection: sqlite3.Connection | None
    db_path: Path | None
    schema_version: int | None
    reason: str | None  # populated when connection is None


def resolve_docs_repo(project_dir: Path) -> Path | None:
    """Resolve the docs-repo path for a project_dir.

    Resolution chain (first match wins):

    1. ``<project_dir>/.claude/forge-config.json::docs_repo_path`` —
       configured path per 3.0+ schema.
    2. ``$FORGE_MANAGER_DOCS_REPO`` env var — operator override.
    3. ``~/<project_dir.name>-docs/`` — convention.
    4. ``~/<project_dir.name minus -dev suffix>-docs/`` — trio
       convention per #263 (dev directory named ``<project>-dev``,
       docs repo named ``<project>-docs``).

    Returns the first path that is a directory, or None if all four
    candidates fail. Mirrors the resolver in
    :mod:`server.handlers.release` without the dep on that module
    (keeps canonical_db_init at the daemon-init dep layer).
    """
    config_path = project_dir / ".claude" / "forge-config.json"
    if config_path.is_file():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            configured = cfg.get("docs_repo_path")
            if isinstance(configured, str) and configured.strip():
                p = Path(configured).expanduser().resolve()
                if p.is_dir():
                    return p
        except (OSError, json.JSONDecodeError):
            pass
    env = os.environ.get("FORGE_MANAGER_DOCS_REPO", "").strip()
    if env:
        p = Path(env).expanduser().resolve()
        if p.is_dir():
            return p
    home = Path.home()
    project_name = project_dir.name
    candidate = home / f"{project_name}-docs"
    if candidate.is_dir():
        return candidate
    if project_name.endswith("-dev"):
        trimmed = project_name[: -len("-dev")]
        candidate = home / f"{trimmed}-docs"
        if candidate.is_dir():
            return candidate
    return None


def startup(project_dir: Path | None) -> CanonicalDBStartup:
    """Initialize canonical-DB at daemon startup.

    Tolerant fallback semantics:

    * ``project_dir is None`` → skipped (pre-bootstrap or daemon
      spawned without --project-dir).
    * docs-repo unresolvable → skipped.
    * sqlite open / init failure → logged + skipped.

    On success: opens the canonical-DB connection, runs
    :func:`canonical_db.register_all` so the registry is populated,
    calls :func:`canonical_db.core.ensure_initialized` to create any
    missing tables, and returns the connection + path + schema
    version.
    """
    if project_dir is None:
        return CanonicalDBStartup(
            connection=None, db_path=None, schema_version=None,
            reason="project_dir is None (pre-bootstrap or "
                   "daemon spawned without --project-dir)",
        )
    docs_repo = resolve_docs_repo(project_dir)
    if docs_repo is None:
        return CanonicalDBStartup(
            connection=None, db_path=None, schema_version=None,
            reason=f"docs-repo unresolvable for {project_dir}",
        )
    # Late imports keep canonical_db out of the daemon's leaf-library
    # dep graph for code paths that don't need it.
    from forge_manager_mcp import canonical_db
    from forge_manager_mcp.canonical_db import core as cdb_core

    db_path = cdb_core.resolve_db_path(docs_repo)
    try:
        canonical_db.register_all()
        conn = cdb_core.open_connection(db_path)
        cdb_core.ensure_initialized(conn)
        schema_version = cdb_core.current_schema_version(conn)
    except (sqlite3.Error, OSError) as exc:
        logger.warning(
            "canonical_db_init skipped: %s (db_path=%s)",
            exc, db_path,
        )
        return CanonicalDBStartup(
            connection=None, db_path=db_path, schema_version=None,
            reason=f"open/init failed: {exc}",
        )
    return CanonicalDBStartup(
        connection=conn, db_path=db_path,
        schema_version=schema_version, reason=None,
    )
