"""forge-manager-daemon — long-lived per-project HTTP service
(Phase D3a / #311 / parent RFC #5).

Per the parent RFC, the daemon is a per-project, localhost-bound
HTTP service that:

- Owns persistent state too expensive to rebuild per MCP session
  (sqlite cache, pending writes queue, classification log,
  action log) — D3b adds the sqlite layer.
- Hosts the operator-facing UI (D-UI brings SolidJS).
- Mediates between short-lived MCP sessions and the canonical
  filesystem store.
- Reconciles backends continuously (D3b).

D3a is the SKELETON: paths + discovery file + HTTP listener +
/health endpoint + auto-spawn helper. Capabilities 1-9 from the
planning Discussion #4 (status, action log, credentials UI, repo
viewer, SSE updates, etc.) land in D3b through D-UI.

Cross-platform note: this skeleton uses stdlib `pathlib.Path.home`
+ XDG-on-Linux paths. ``platformdirs`` integration for proper
macOS / Windows path resolution lands in D4 alongside the
install-service CLI.
"""
from forge_manager_mcp.daemon.discovery import (
    DiscoveryFile,
    discovery_path,
    read_discovery,
    write_discovery,
)
from forge_manager_mcp.daemon.paths import (
    DEFAULT_PROJECT_NAME,
    log_dir,
    state_dir,
)


__all__ = [
    "DEFAULT_PROJECT_NAME",
    "DiscoveryFile",
    "discovery_path",
    "log_dir",
    "read_discovery",
    "state_dir",
    "write_discovery",
]
