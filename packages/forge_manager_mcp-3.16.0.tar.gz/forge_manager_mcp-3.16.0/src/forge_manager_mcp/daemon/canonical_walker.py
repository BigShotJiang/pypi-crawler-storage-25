"""Canonical-store walker (Phase D4.3 / #354 / 3.6.0).

Iterates the LocalStoreAdapter filesystem layout and yields
``(ref_native_id, title, body)`` tuples per artifact for FTS5
population. Three artifact kinds: Issues, Discussions, Sessions.

Layout reference (set by LocalStoreAdapter):

    <docs>/issues/<n>/
        title.md
        body.md
        meta.json
        comments/<utc-ts>-claude.md  (zero or more)
        ...
    <docs>/discussions/<n>/
        title.md
        body.md
        ...
    <docs>/sessions/<session_id>/
        <utc-ts>-opened.json
        <utc-ts>-closed.json
        ...

``ref_native_id`` matches what ``LocalStoreAdapter`` constructs in
``ArtifactRef.native_id`` — ``issues/<n>``, ``discussions/<n>``,
or the session_id verbatim. So an FTS5 hit can map back to the
adapter via the existing ref machinery.

Pure module — read-only IO, no sqlite imports. Effect-then-
interceptor split (Rule 2): the walker is the read-effect; the
caller (``populate_fts5`` in ``action_log.py``) decides what to
do with the rows.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator


def _read_optional(path: Path) -> str:
    """Return file contents, or empty string when absent / unreadable.

    Tolerant of every IO failure mode — the canonical store is
    operator-managed and may have hand-edits, missing files, or
    permission quirks. FTS5 population is best-effort: a single
    unreadable file shouldn't halt the walk.
    """
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _is_numbered_dir(entry: Path) -> bool:
    """True iff the entry is a directory whose name parses as int.

    Filters out non-artifact entries the operator may have placed
    in issues/ or discussions/ (`.gitignore`, README, stray files).
    """
    return entry.is_dir() and entry.name.isdigit()


def walk_issues(docs_root: Path) -> Iterator[tuple[str, str, str]]:
    """Yield ``(ref_native_id, title, body)`` per Issue artifact.

    ``body`` aggregates the issue's opening-post body plus every
    comment file (concatenated with double-newlines). Per #354 OQ3
    closure: comments live inside the parent's FTS5 row rather than
    a separate comments table — keeps the search surface returning
    artifact-level hits.
    """
    issues_dir = docs_root / "issues"
    if not issues_dir.is_dir():
        return
    for entry in sorted(issues_dir.iterdir()):
        if not _is_numbered_dir(entry):
            continue
        title = _read_optional(entry / "title.md").strip()
        body = _read_optional(entry / "body.md")
        comments_dir = entry / "comments"
        if comments_dir.is_dir():
            for comment_file in sorted(comments_dir.iterdir()):
                if comment_file.suffix != ".md":
                    continue
                body += "\n\n" + _read_optional(comment_file)
        yield f"issues/{entry.name}", title, body


def walk_discussions(docs_root: Path) -> Iterator[tuple[str, str, str]]:
    """Yield ``(ref_native_id, title, body)`` per Discussion artifact.

    Same shape as ``walk_issues`` but rooted at ``discussions/`` —
    Discussions also accept comments via the canonical store's
    comments/ subdir (per recording.md two-turn rule).
    """
    discussions_dir = docs_root / "discussions"
    if not discussions_dir.is_dir():
        return
    for entry in sorted(discussions_dir.iterdir()):
        if not _is_numbered_dir(entry):
            continue
        title = _read_optional(entry / "title.md").strip()
        body = _read_optional(entry / "body.md")
        comments_dir = entry / "comments"
        if comments_dir.is_dir():
            for comment_file in sorted(comments_dir.iterdir()):
                if comment_file.suffix != ".md":
                    continue
                body += "\n\n" + _read_optional(comment_file)
        yield f"discussions/{entry.name}", title, body


# (#384, 3.9.0 D3.1) Code-source subdirs the FTS walker covers per
# #16 OQ2 closure. Wider project-tree scope is opt-in via a future
# forge-config.json.fts_sources field — see Issue #384 for the
# extension point. Each entry is project-relative.
_CODE_SOURCE_DIRS: tuple[str, ...] = (
    "mcp-server/src",
    "mcp-server/tests",
    "ui/src",
    ".claude/skills",
)

# Extensions the walker indexes. Any file inside a _CODE_SOURCE_DIR
# whose suffix matches goes into code_fts. BUILD / MODULE.bazel
# files are treated as code by exact-name match below.
_CODE_FILE_SUFFIXES: frozenset[str] = frozenset({
    ".py", ".ts", ".tsx", ".js", ".jsx",
    ".yaml", ".yml", ".toml", ".json",
    ".md", ".bzl",
    ".html", ".css",
})

# Same denylist shape as #380's watch.py. Skips per-segment names.
_CODE_DENYLIST_SEGMENTS: frozenset[str] = frozenset({
    "build", "dist", "__pycache__",
    ".venv", "venv", "node_modules",
    ".git", ".pytest_cache", "ui_dist",
})


def _is_code_file(path: Path) -> bool:
    """True iff ``path`` is a code file by suffix or special filename."""
    if path.name in {"BUILD", "BUILD.bazel", "MODULE.bazel", "WORKSPACE", "WORKSPACE.bazel"}:
        return True
    return path.suffix in _CODE_FILE_SUFFIXES


def _path_in_code_denylist(path: Path) -> bool:
    """True iff any path component matches a code-walker denylist entry."""
    return any(part in _CODE_DENYLIST_SEGMENTS for part in path.parts)


def walk_code_files(project_root: Path) -> Iterator[tuple[str, str]]:
    """(#384, 3.9.0 D3.1) Yield ``(project_relative_path, content)``
    for every code file under ``project_root`` matching one of the
    canonical-store-code subdirs, with denylisted dirs skipped.

    Best-effort — unreadable files are silently dropped (raced
    delete, permission deny, decode failure). Missing ``project_root``
    or absent code-source subdirs yields zero rows; the FTS5 table
    still works against the populated subset.

    Pure read-IO; no sqlite imports. Same effect-then-interceptor
    pattern as walk_issues / walk_discussions / walk_sessions —
    populate_fts5 owns the INSERT side.
    """
    if not project_root.is_dir():
        return
    for source_dir in _CODE_SOURCE_DIRS:
        root = project_root / source_dir
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if _path_in_code_denylist(path):
                continue
            if not _is_code_file(path):
                continue
            try:
                content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            try:
                rel = path.relative_to(project_root)
            except ValueError:  # pragma: no cover — DEFENSIVE: rglob from project_root always yields paths under it; this guards against symlink-traversed-out-of-tree edge cases that don't happen in practice.
                rel = path
            yield str(rel), content


def walk_sessions(docs_root: Path) -> Iterator[tuple[str, str]]:
    """Yield ``(session_id, body)`` per Session.

    ``body`` is the concatenation of every session-event JSON's
    ``body`` field, joined with newlines, in chronological order
    (filename sort is chronological since events are timestamped).
    """
    sessions_dir = docs_root / "sessions"
    if not sessions_dir.is_dir():
        return
    for session_dir in sorted(sessions_dir.iterdir()):
        if not session_dir.is_dir():
            continue
        bodies: list[str] = []
        for event_file in sorted(session_dir.iterdir()):
            if event_file.suffix != ".json":
                continue
            try:
                payload = json.loads(event_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            body_field = payload.get("body")
            if isinstance(body_field, str) and body_field:
                bodies.append(body_field)
        yield session_dir.name, "\n".join(bodies)
