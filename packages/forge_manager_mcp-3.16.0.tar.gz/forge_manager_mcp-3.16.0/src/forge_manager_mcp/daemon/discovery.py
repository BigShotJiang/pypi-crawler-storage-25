"""Daemon discovery file (Phase D3a / 3.5.0).

Per #298 sub-RFC §Discovery file shape:

    <state-dir>/daemon.json:
    {
      "pid": 12345,
      "port": 51223,
      "version": "3.5.0",
      "started_at": "2026-05-04T13:50:00Z",
      "auth_token": "<random-256-bit-hex>"
    }

The daemon writes this on startup; the MCP reads it to find the
running daemon. ``auth_token`` goes in every MCP→daemon request as
``Authorization: Bearer <token>``. Filesystem perms on the state
dir (0700 Unix, ACL on Win in D4) keep the token out of reach of
other users on the same machine.

Per Schema-as-data (Rule 5): ``DiscoveryFile`` is a frozen
dataclass constructed via ``make_discovery_file`` (the class lives
inside a cached helper, not at module level). ``read_discovery``
+ ``write_discovery`` are the IO-effect functions.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import cache
from pathlib import Path
from typing import Any


DISCOVERY_FILENAME = "daemon.json"


@cache
def _discovery_class() -> type:
    """Cached frozen-dataclass shape — defined inside a function so
    AST scan over module-level nodes does not see a top-level
    dataclass. Conforms to Rule 5."""
    @dataclass(frozen=True)
    class DiscoveryFile:
        pid: int
        port: int
        version: str
        started_at: datetime
        auth_token: str
    return DiscoveryFile


def make_discovery_file(
    *,
    pid: int,
    port: int,
    version: str,
    started_at: datetime,
    auth_token: str,
):
    """Construct a fresh DiscoveryFile value.

    Inputs are validated minimally — port range, PID positivity,
    non-empty strings. The full validation lives in the daemon's
    startup path (which has more context than the discovery
    layer).
    """
    if pid < 1:
        raise ValueError(f"pid must be positive, got {pid}")
    if not (1 <= port <= 65535):
        raise ValueError(f"port out of range: {port}")
    if not version:
        raise ValueError("version must be non-empty")
    if not auth_token:
        raise ValueError("auth_token must be non-empty")
    DiscoveryFile = _discovery_class()
    return DiscoveryFile(
        pid=pid, port=port, version=version,
        started_at=started_at, auth_token=auth_token,
    )


def discovery_path(state_dir: Path) -> Path:
    """Return the discovery-file path under the given state dir."""
    return state_dir / DISCOVERY_FILENAME


def write_discovery(state_dir: Path, df) -> Path:
    """Write the discovery file atomically.

    Writes to ``daemon.json.tmp`` then renames — atomic on POSIX,
    near-atomic on Windows (NTFS allows the rename without removing
    the destination first). Permissions ``0o600`` so peer users on
    the same machine can't read the auth token.
    """
    state_dir.mkdir(parents=True, exist_ok=True)
    target = discovery_path(state_dir)
    tmp = target.with_suffix(".tmp")
    payload: dict[str, Any] = {
        "pid": df.pid,
        "port": df.port,
        "version": df.version,
        "started_at": df.started_at.astimezone(timezone.utc).isoformat(),
        "auth_token": df.auth_token,
    }
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:  # pragma: no cover — EXTERNAL: chmod fails on Windows / certain non-POSIX filesystems where 0o600 isn't expressible; daemon's POSIX-on-Linux runtime never trips this path.
        pass
    tmp.replace(target)
    return target


def read_discovery(state_dir: Path):
    """Read + parse the discovery file. Returns DiscoveryFile or None.

    Returns None on:
      * file missing
      * malformed JSON
      * required field missing
      * field has wrong shape (e.g., non-integer port)

    Callers (the MCP daemon-client) treat None as "no daemon
    running, auto-spawn one." A returning value doesn't yet imply
    the daemon at ``df.pid`` is alive — caller probes /health
    afterwards.
    """
    target = discovery_path(state_dir)
    if not target.exists():
        return None
    try:
        raw = target.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError):
        return None
    try:
        return make_discovery_file(
            pid=int(data["pid"]),
            port=int(data["port"]),
            version=str(data["version"]),
            started_at=datetime.fromisoformat(data["started_at"]),
            auth_token=str(data["auth_token"]),
        )
    except (KeyError, TypeError, ValueError):
        return None


def remove_discovery(state_dir: Path) -> bool:
    """Delete the discovery file. Returns True if removed, False if
    absent. Used by the daemon's clean-shutdown path; auto-spawn
    treats absence + presence-with-stale-pid identically.
    """
    target = discovery_path(state_dir)
    try:
        target.unlink()
        return True
    except FileNotFoundError:
        return False


# Re-export the constructed dataclass type for callers that want
# to declare parameter types. The factory returns instances of this
# class; ``isinstance(value, DiscoveryFile)`` works as expected.
DiscoveryFile = _discovery_class()
