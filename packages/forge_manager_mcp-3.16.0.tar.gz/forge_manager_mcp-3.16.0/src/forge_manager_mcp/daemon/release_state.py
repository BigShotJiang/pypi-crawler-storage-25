"""In-memory release state holder for the daemon (3.16.0 D1 / A.2).

Tracks an in-flight release-flow execution and its per-step lifecycle
state so the UI's <ReleaseSwimlane> consumer can render a live view of
the release process with operator-clickable step buttons.

Mirrors ``daemon/migration_state.py`` in shape but with the release
domain's 5-state lifecycle vocabulary: **pending / running / done /
failed / skipped**. The richer state machine reflects the operator-
driven nature of release flows — release_project chains can fail
mid-execution and either re-run a step (post-fix) or skip with
explicit ``confirmed_consequences=true`` (operator override). The
migration domain's 3-state vocab (preview/running/complete) doesn't
need the "failed" / "skipped" cases because migrations either run
to completion or roll back via the compensating-transaction chain
without operator branching.

**Persistence posture: in-memory only.** Same rationale as migration
state — release flows are infrequent operator-driven operations.
Daemon-crash mid-release leaves the canonical-store + git state
intact (per the existing compensating-transaction guarantees from
3.2.0 #294); losing the live-view payload is acceptable. A future
``releases_facts`` shadow table can promote this to durable storage
without changing the holder's API.

Schema-as-functions per Rule 5: the ReleaseStep + Release dicts are
constructed via factory helpers, not top-level Pydantic classes.
"""
from __future__ import annotations

from typing import Any, Callable


_VALID_STATES = ("pending", "running", "done", "failed", "skipped")


# ---------------------------------------------------------------------------
# Factory helpers — Schema-as-functions (Rule 5)
# ---------------------------------------------------------------------------


def make_release_step(
    *,
    step_id: str,
    title: str,
    state: str = "pending",
) -> dict[str, Any]:
    """Construct a release-step record matching the UI's ReleaseStep
    contract:
      {id, title, state: 'pending' | 'running' | 'done' | 'failed' | 'skipped'}

    State vocabulary is validated; unknown states raise ValueError so
    callers learn at the boundary rather than producing UI rendering
    surprises (the UI's CardSurface state-glyph mapping depends on a
    known vocabulary).
    """
    if state not in _VALID_STATES:
        raise ValueError(
            f"ReleaseStep state must be one of {_VALID_STATES}, "
            f"got {state!r}"
        )
    return {"id": step_id, "title": title, "state": state}


def make_release(
    *,
    release_id: str,
    title: str,
    steps: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Construct a release envelope record:
      {id, title, steps: [step_dict, ...]}

    Convention: ``release_id`` is a slug describing the target
    (e.g. ``"release:3.16.0"``, ``"release:3.16.0-pypi-only"``); used
    as the SSE event key + the holder's primary key.
    """
    return {
        "id": release_id,
        "title": title,
        "steps": list(steps or []),
    }


# ---------------------------------------------------------------------------
# State holder
# ---------------------------------------------------------------------------


class ReleaseStateHolder:
    """In-memory store of in-flight releases keyed by release_id.

    Lifecycle (mirrors MigrationStateHolder):
      * ``upsert_release`` — register a new release or replace an
        existing one's step list (the MCP release handler calls this
        at start with the full step plan from build_release_chain).
      * ``update_step_state`` — flip a single step's state. Returns
        the (release_id, step_id, prev_state, new_state) tuple for
        downstream SSE publish.
      * ``remove_release`` — drop a release entirely (operator
        dismissed via the title-bar × on <ReleaseSwimlane>, or a
        cleanup pass post-completion).
      * ``list_releases`` — return the current snapshot as a list.

    Optional ``event_publisher`` constructor argument wires the
    holder to a broadcaster (typically the daemon's EventBroadcaster
    via a closure that calls ``broadcaster.publish(make_event(...))``).
    Each mutation method calls the publisher with the corresponding
    SSE event name. Publisher exceptions are swallowed — broadcast
    is best-effort; the holder's primary contract is data
    consistency.

    Concurrency posture: single-threaded. Daemon serves requests
    via uvicorn's asyncio event loop; all mutations happen on the
    same loop without awaits between read-then-write.
    """

    def __init__(
        self,
        *,
        event_publisher: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        # release_id → release dict from make_release.
        # Preserves insertion order (Python 3.7+ dict ordering).
        self._releases: dict[str, dict[str, Any]] = {}
        self._event_publisher = event_publisher

    def _publish(self, event_name: str, payload: dict[str, Any]) -> None:
        """Fire an event via the wired publisher. Swallows publisher
        exceptions per the best-effort contract."""
        if self._event_publisher is None:
            return
        try:
            self._event_publisher(event_name, payload)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Mutation
    # -----------------------------------------------------------------

    def upsert_release(
        self, release: dict[str, Any],
    ) -> None:
        """Register a new release or replace an existing one.

        Idempotent: calling with the same id replaces the step list
        wholesale. Fires ``release.upserted`` event with a deep-copied
        steps snapshot so subsequent state mutations don't
        retroactively change the published payload.
        """
        self._releases[release["id"]] = release
        self._publish(EVENT_RELEASE_UPSERTED, {
            "release_id": release["id"],
            "title": release["title"],
            "steps": [dict(s) for s in release["steps"]],
        })

    def update_step_state(
        self,
        release_id: str,
        step_id: str,
        new_state: str,
    ) -> tuple[str, str, str, str] | None:
        """Flip a single step's state.

        Returns ``(release_id, step_id, prev_state, new_state)`` on
        success; ``None`` when the release or step isn't known
        (caller treats as a no-op).

        Raises ValueError on unknown ``new_state`` per the 5-state
        vocabulary check.
        """
        if new_state not in _VALID_STATES:
            raise ValueError(
                f"new_state must be one of {_VALID_STATES}, "
                f"got {new_state!r}"
            )
        release = self._releases.get(release_id)
        if release is None:
            return None
        for step in release["steps"]:
            if step["id"] == step_id:
                prev_state = step["state"]
                step["state"] = new_state
                self._publish(EVENT_RELEASE_STEP_CHANGED, {
                    "release_id": release_id,
                    "step_id": step_id,
                    "prev_state": prev_state,
                    "new_state": new_state,
                })
                return (release_id, step_id, prev_state, new_state)
        return None

    def remove_release(self, release_id: str) -> bool:
        """Drop a release from the holder. Returns True if removed,
        False if it wasn't present (idempotent). Fires
        ``release.removed`` event only on actual removal."""
        removed = self._releases.pop(release_id, None) is not None
        if removed:
            self._publish(EVENT_RELEASE_REMOVED, {
                "release_id": release_id,
            })
        return removed

    def clear(self) -> None:
        """Reset the holder to empty. Used by tests + daemon restart
        flow (state is in-memory only — restart resets)."""
        self._releases.clear()

    # -----------------------------------------------------------------
    # Read
    # -----------------------------------------------------------------

    def list_releases(self) -> list[dict[str, Any]]:
        """Return the current releases as a list, preserving insertion
        order. Callers SHOULD treat returned dict references as
        read-only; for test isolation use ``snapshot()``."""
        return list(self._releases.values())

    def snapshot(self) -> list[dict[str, Any]]:
        """Deep-copied snapshot for test isolation."""
        return [
            {
                "id": r["id"],
                "title": r["title"],
                "steps": [dict(s) for s in r["steps"]],
            }
            for r in self._releases.values()
        ]

    def get(self, release_id: str) -> dict[str, Any] | None:
        """Fetch one release by id, or None when absent."""
        return self._releases.get(release_id)

    def __len__(self) -> int:
        return len(self._releases)


# ---------------------------------------------------------------------------
# SSE event names (vocabulary)
# ---------------------------------------------------------------------------

# Published when a new release is registered with the holder.
# Payload: {release_id, title, steps: [...]}.
EVENT_RELEASE_UPSERTED = "release.upserted"

# Published when a step's state transitions.
# Payload: {release_id, step_id, prev_state, new_state}.
EVENT_RELEASE_STEP_CHANGED = "release.step_changed"

# Published when a release is removed from the holder.
# Payload: {release_id}.
EVENT_RELEASE_REMOVED = "release.removed"
