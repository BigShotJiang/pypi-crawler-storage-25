"""Canonical-DB read dispatch (3.15.0 cluster A.3.1).

Per Discussion #23 OQ8 (both-authoritative transition / reads
consult DB first, fall back to filesystem). Sibling of
:mod:`canonical_db_dispatch` for the read side. When the daemon's
``POST /reads`` endpoint receives an op, this module gets the
first crack: if the canonical-DB has the row, it short-circuits
the existing ReplicationManager.read path. If not, the caller
falls through to the existing filesystem-canonical handler.

Module-level connection singleton :func:`set_connection` /
:func:`reset_connection` matches the write-dispatch pattern.
``daemon/main.py`` calls both ``canonical_db_dispatch.set_connection``
and ``canonical_db_read_dispatch.set_connection`` with the same
connection at startup.

A.3.1 ships ``get_issue_body`` and ``get_discussion_body`` as the
reference reads. A.3.2+ migrate the rest of the read surface.

Wire shape: dispatch_read returns either:

* ``None`` — the handler isn't registered, or the connection isn't
  set, or the helper returned None (row not in DB). Caller falls
  through to the existing read handler.
* ``{"value": <op-result>}`` — the DB has the row; caller returns
  this directly without invoking the filesystem read.

Failures inside handlers are caught and logged; on error, the
function returns None so the caller falls through to filesystem
read. Reads never block — they degrade silently to FS when DB is
unavailable or has bugs.
"""
from __future__ import annotations

import logging
import sqlite3
from typing import Any, Callable


# A canonical-DB read handler: takes (connection, args).
# Returns the op-result dict (e.g. {"value": ...}) or None when
# the row isn't in canonical-DB.
ReadHandler = Callable[[sqlite3.Connection, dict], dict | None]


_CONNECTION: sqlite3.Connection | None = None
"""Process-global canonical-DB connection. Mirrors the write-side
singleton. Set by daemon startup; reset by tests."""


_REGISTRY: dict[str, ReadHandler] = {}


_log = logging.getLogger(__name__)


def register(op_name: str):
    """Decorator: register a canonical-DB read handler."""
    def deco(fn: ReadHandler) -> ReadHandler:
        _REGISTRY[op_name] = fn
        return fn
    return deco


def get_handler(op_name: str) -> ReadHandler | None:
    return _REGISTRY.get(op_name)


def all_ops() -> list[str]:
    return sorted(_REGISTRY.keys())


def set_connection(conn: sqlite3.Connection | None) -> None:
    global _CONNECTION
    _CONNECTION = conn


def reset_connection() -> None:
    global _CONNECTION
    _CONNECTION = None


def dispatch_read(op_name: str, args: dict) -> dict | None:
    """Attempt to satisfy a read op from canonical-DB.

    Returns the result dict when the DB has the row; None when:

    * Connection isn't set (canonical-DB unavailable).
    * No handler registered for ``op_name``.
    * Handler returned None (row not in DB).
    * Handler raised (logged + fall through).

    Per OQ8 best-effort contract: failures degrade to FS-fallback
    silently — never raise from this function.
    """
    if _CONNECTION is None:
        return None
    handler = _REGISTRY.get(op_name)
    if handler is None:
        return None
    try:
        return handler(_CONNECTION, args)
    except Exception as exc:  # pragma: no cover - defensive log
        _log.warning(
            "canonical_db_read_dispatch %s failed: %s; falling back to FS",
            op_name, exc,
        )
        return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_native_id_number(native_id: str) -> int | None:
    """Parse a ``<kind>/<n>`` native_id into the integer number.

    Duplicates the helper in :mod:`canonical_db_dispatch` rather
    than importing — keeps read-dispatch dep graph independent.
    """
    if not isinstance(native_id, str):
        return None
    _, _, suffix = native_id.rpartition("/")
    if not suffix or not suffix.isdigit():
        return None
    return int(suffix)


# ---------------------------------------------------------------------------
# Per-op read handlers
# ---------------------------------------------------------------------------

@register("get_issue_body")
def _read_issue_body(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Read an issue body from canonical-DB.

    Returns ``{"value": <body string>}`` matching the existing
    handler's wire shape. None when the issue isn't in DB.
    """
    from forge_manager_mcp.canonical_db import issues_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return None
    row = issues_writes.select_issue(conn, number=number)
    if row is None:
        return None
    return {"value": row["body"]}


@register("get_discussion_body")
def _read_discussion_body(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Read a discussion body from canonical-DB.

    Returns ``{"value": <body string>}`` matching the existing
    handler's wire shape.
    """
    from forge_manager_mcp.canonical_db import discussions_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return None
    row = discussions_writes.select_discussion(conn, number=number)
    if row is None:
        return None
    return {"value": row["body"]}


@register("get_milestone_body")
def _read_milestone_body(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Read a milestone body from canonical-DB by version string.

    The version is in ``args["version"]`` (string, not number).
    Returns ``{"value": <body>}`` or None.
    """
    from forge_manager_mcp.canonical_db import milestones_writes

    version = args.get("version")
    if not isinstance(version, str) or not version:
        return None
    row = milestones_writes.select_milestone(conn, version=version)
    if row is None:
        return None
    return {"value": row["body"]}


@register("list_all_issue_numbers")
def _read_list_all_issue_numbers(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Enumerate all issue numbers in the canonical-DB.

    Returns ``{"value": [<int>, ...]}`` sorted ascending. The
    list may be empty when the DB has no issues; that's still a
    DB-hit (just an empty result), so we return the dict rather
    than None — falling through to filesystem would yield the
    same empty answer.
    """
    rows = conn.execute(
        "SELECT number FROM issues ORDER BY number"
    ).fetchall()
    return {"value": [int(r[0]) for r in rows]}


@register("list_all_discussion_numbers")
def _read_list_all_discussion_numbers(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Enumerate all discussion numbers, sorted."""
    rows = conn.execute(
        "SELECT number FROM discussions ORDER BY number"
    ).fetchall()
    return {"value": [int(r[0]) for r in rows]}


@register("list_all_milestone_versions")
def _read_list_all_milestone_versions(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Enumerate all milestone version strings, sorted."""
    rows = conn.execute(
        "SELECT version FROM milestones ORDER BY version"
    ).fetchall()
    return {"value": [r[0] for r in rows]}


@register("list_comments")
def _read_list_comments(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """List comments on an issue or discussion.

    Returns ``{"value": [<comment dict>, ...]}`` sorted by
    created_at. None when the parent kind isn't issue|discussion
    or native_id is unparseable.

    Wire shape mirrors what the existing handler returns — but
    note that the existing handler returns adapter-typed Comment
    dicts which include a ``ref`` field with platform_id. We don't
    have platform_id here (canonical-DB doesn't track per-adapter
    identity), so the returned comments use ``local`` as a
    sentinel platform_id. Callers should be lenient about
    platform_id during the both-authoritative window.
    """
    from forge_manager_mcp.canonical_db import comments_writes

    parent_kind = args.get("parent_kind", "")
    if parent_kind not in ("issue", "discussion"):
        return None
    parent_number = _parse_native_id_number(args.get("parent_native_id", ""))
    if parent_number is None:
        return None
    rows = comments_writes.list_comments_on(
        conn,
        parent_kind=parent_kind,
        parent_number=parent_number,
    )
    return {"value": rows}


@register("get_gap_body")
def _read_gap_body(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Read a gap body from canonical-DB by detector category.

    Gaps are identified at the artifact / read-op layer by
    ``category`` (a detector-name string) — but the canonical-DB
    ``gaps`` table is keyed by an integer ``number`` primary key
    with ``detector`` as the category column (see the sibling
    write-dispatch ``_lookup_gap_number_by_detector`` helper). We
    look up by detector and return the body directly.

    Args:
        category: str — detector name (e.g.
            ``"test_coverage_gap"``).

    Returns:
        ``{"value": <body string>}`` matching the existing
        ``daemon/reads.py:get_gap_body`` handler's wire shape.
        ``None`` when the category isn't a non-empty string or
        no row matches.
    """
    category = args.get("category")
    if not isinstance(category, str) or not category:
        return None
    row = conn.execute(
        "SELECT body FROM gaps WHERE detector = ? LIMIT 1",
        (category,),
    ).fetchone()
    if row is None:
        return None
    return {"value": row[0]}


@register("list_gap_categories")
def _read_list_gap_categories(
    conn: sqlite3.Connection,
    args: dict,
) -> dict | None:
    """Enumerate distinct gap detector categories.

    The artifact-side ``list_gap_categories`` adapter method
    returns the list of detector names with at least one gap
    materialized. We satisfy it via ``SELECT DISTINCT detector``
    against the canonical-DB ``gaps`` table.

    Returns:
        ``{"value": [<detector string>, ...]}`` sorted ascending.
        Empty list when no gaps exist — still a DB-hit (falling
        through to filesystem would yield the same empty answer),
        so we return the dict rather than ``None``.
    """
    rows = conn.execute(
        "SELECT DISTINCT detector FROM gaps ORDER BY detector"
    ).fetchall()
    return {"value": [r[0] for r in rows]}
