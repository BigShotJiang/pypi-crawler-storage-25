"""Daemon action log — sqlite-backed (Phase D4 / #354 / 3.6.0).

Persistent replacement for the in-memory ``AlertLog`` ring buffer
(#341), plus FTS5 indices over canonical artifacts (Issues /
Discussions / Sessions) for the future ``search_local`` MCP tool.

Per Discussion #6 OQ3 closure: sqlite is a derived cache, NOT in
the docs repo (which is the git-versioned canonical). Per-project
state-dir keeps it expendable; rebuild-from-canonical handles
corruption / version upgrades / fresh-machine scenarios.

Per-project layout: ``<state-dir>/action-log.db``.

**D4.1 scope.** This module ships connection management + schema
bootstrap + version-mismatch detection. The events-table writer
(D4.2 — replaces AlertLog), FTS5 population (D4.3), rebuild helper
(D4.4), and ``search_local`` MCP surface (D4.5) layer on top.

**Effect-then-interceptor split (code-design.md Rule 2).**

* ``SCHEMA_DDL`` — pure data; tuple of CREATE statements.
* ``database_path`` — pure path resolver.
* ``_read_user_version`` / ``_set_user_version`` — pure functions
  over an existing ``Connection``.
* ``open_connection`` and ``ensure_schema`` — effect functions
  (mkdir + sqlite open + DDL execution).

**Concurrency model (#354 OQ2).** Daemon is single-process; the MCP
issues serialized requests over stdio. Single ``sqlite3.Connection``
with default ``check_same_thread=True`` is sufficient. Capability 8
(HTTP-for-MCP) brings concurrent writers — at that point WAL +
per-thread connections become the answer. For 3.6.0 ship single-
thread; revisit at capability 8.

**Schema versioning (#354 OQ1).** PRAGMA ``user_version``;
mismatch triggers full drop+recreate. No forward-migrations table —
FTS5 is fully derivable from canonical, so rebuild is correct by
construction.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path


SCHEMA_VERSION = 11  # (#487, 3.14.0) bumped when issues_facts Tier 1 slot-in landed
"""Current schema version. Incremented when DDL changes; mismatch
triggers rebuild-from-canonical."""

DATABASE_FILENAME = "action-log.db"
"""sqlite file name within the per-project state-dir."""


SCHEMA_DDL: tuple[str, ...] = (
    # Append-only events table — replaces in-memory AlertLog ring
    # buffer (#341). Columns mirror the Alert dataclass shape;
    # ``tags`` is JSON-encoded since sqlite has no native list type.
    """
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        level TEXT NOT NULL,
        message TEXT NOT NULL,
        detail TEXT,
        platform_id TEXT,
        tags TEXT NOT NULL DEFAULT '[]'
    )
    """,
    # Index on events.timestamp accelerates the recent(since=...)
    # query that the AlertLog API supports.
    "CREATE INDEX IF NOT EXISTS events_timestamp_idx ON events(timestamp)",
    # FTS5 virtual table over canonical Issues. ``ref_native_id`` is
    # UNINDEXED so it's stored verbatim and not tokenized — caller
    # uses it as a join key back to LocalStoreAdapter records.
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS issues_fts USING fts5(
        ref_native_id UNINDEXED,
        title,
        body
    )
    """,
    # FTS5 over canonical Discussions. Same shape as issues_fts —
    # MCP search dispatch unions across both tables.
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS discussions_fts USING fts5(
        ref_native_id UNINDEXED,
        title,
        body
    )
    """,
    # FTS5 over canonical Sessions. Sessions don't have a separate
    # title field — body carries the close-comment summary text.
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS sessions_fts USING fts5(
        session_id UNINDEXED,
        body
    )
    """,
    # (#384, 3.9.0 D3.1) FTS5 over canonical-store code files —
    # Python / TypeScript / YAML / BUILD / Markdown / etc. under
    # the four code-source subdirs (mcp-server/src/,
    # mcp-server/tests/, ui/src/, .claude/skills/). ``path`` is
    # UNINDEXED so it stores the project-relative path verbatim
    # for hit→file navigation in the UI. Wider project-tree scope
    # is opt-in via forge-config.json.fts_sources per #16 OQ2.
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS code_fts USING fts5(
        path UNINDEXED,
        content
    )
    """,
)
"""Schema definition as data. Each entry is one DDL statement
executed in order at bootstrap. ``CREATE … IF NOT EXISTS`` so a
partially-applied bootstrap is resumable."""


_FTS5_TABLES: tuple[str, ...] = (
    "issues_fts",
    "discussions_fts",
    "sessions_fts",
    "code_fts",  # (#384, 3.9.0 D3.1)
)
"""FTS5 virtual tables — listed separately so rebuild-from-canonical
(D4.4) can drop+repopulate just the search side without touching
the events log."""


_ALL_TABLES: tuple[str, ...] = ("events",) + _FTS5_TABLES
"""Every table the schema creates — historical drop list used by
pre-#475 ``ensure_schema``. Retained for back-compat / introspection;
the new derivable-vs-stateful classification (#475 / Discussion #22
OQ7 refinement) supersedes it as the actual drop dispatch."""


# (#475 / 3.14.0 / OQ7 refinement) Per-table classification for the
# action-log's own tables. The `events` table carries runtime alert
# history not derivable from canonical (per 3.13.0 #454); it must be
# preserved across schema-version bumps. The FTS5 tables are
# derivable from canonical via the walker, so they drop+rebuild on
# user_version mismatch.
#
# Shadow `_facts` tables (the #475+ tables) classify the same way
# via `shadow.registry`. This dict carries only the action-log's own
# tables; the shadow registry handles its own membership.
_STATEFUL_TABLES: frozenset[str] = frozenset({"events"})
"""Tables that survive ``ensure_schema``'s drop-and-rebuild path on
``user_version`` drift. The runtime alert history (3.13.0 #454)
lives here — not derivable from canonical, so dropping it on every
schema-version bump would discard real signal."""


_DERIVABLE_ACTION_LOG_TABLES: tuple[str, ...] = _FTS5_TABLES
"""Action-log tables that are fully derivable from canonical — the
FTS5 indices. Drop+rebuild on user_version drift via the canonical
walker. Lives separately from ``_STATEFUL_TABLES`` so ``ensure_schema``
can dispatch on classification cleanly."""


def is_stateful_table(name: str) -> bool:
    """Return True iff ``name`` is classified as stateful (preserved
    across user_version-drift drop+rebuild).

    Per OQ7 refinement, today this is just the ``events`` table (the
    3.13.0 #454 alert history). Shadow `_facts` tables are classified
    via :mod:`forge_manager_mcp.shadow.registry` separately — this
    helper covers only the action_log's own tables.

    Pure — frozenset lookup, no IO.
    """
    return name in _STATEFUL_TABLES


def database_path(state_dir: Path) -> Path:
    """Return the action-log sqlite path under the given state-dir.

    Pure — no IO; caller decides when to create.
    """
    return state_dir / DATABASE_FILENAME


def _read_user_version(con: sqlite3.Connection) -> int:
    """Return the current PRAGMA ``user_version``. 0 on a fresh DB."""
    cur = con.execute("PRAGMA user_version")
    row = cur.fetchone()
    return int(row[0]) if row else 0


def _set_user_version(con: sqlite3.Connection, version: int) -> None:
    """Set PRAGMA ``user_version``. Effect on the connection."""
    # PRAGMA can't take a parameter binding; integer is sanitized
    # via int() so SQL injection is impossible.
    con.execute(f"PRAGMA user_version = {int(version)}")


def open_connection(state_dir: Path) -> sqlite3.Connection:
    """Open or create the action-log sqlite database.

    Effect — creates the state-dir if absent + opens the connection.
    Configures ``row_factory = sqlite3.Row`` for name-based column
    access on subsequent queries.

    Caller closes via context manager or explicit ``con.close()``.
    The daemon's lifetime owns the connection — paired with daemon
    spawn / shutdown.

    ``check_same_thread=False`` is set: in production the daemon's
    asyncio event loop is single-threaded so this is moot, but
    Starlette's TestClient bridges sync test code to async handlers
    via anyio threads — without this flag the test surface fails
    with ProgrammingError on cross-thread connection use. The
    daemon's serialized-handler dispatch keeps writes safe under
    the loosened check; capability 8 (HTTP-for-MCP, concurrent
    writers) is the point at which we revisit and switch to WAL +
    per-thread connections (#354 OQ2).
    """
    state_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(
        database_path(state_dir),
        check_same_thread=False,
    )
    con.row_factory = sqlite3.Row
    return con


def ensure_schema(con: sqlite3.Connection) -> bool:
    """Bootstrap or refresh the schema.

    Returns True when the schema was created or rebuilt (caller may
    want to populate FTS5 from canonical); False when the existing
    schema matched ``SCHEMA_VERSION`` and no work was done.

    Behavior:

    * ``user_version == SCHEMA_VERSION`` → no-op, return False.
    * ``user_version == 0`` (fresh DB) → run all DDL, set version,
      return True.
    * ``user_version != SCHEMA_VERSION`` (drift) → drop **derivable**
      tables (FTS5 indices) + re-run DDL + set version, return True.
      Stateful tables (``events``, the 3.13.0 alert history) survive
      the rebuild per OQ7 refinement (Issue #475 / Discussion #22).

    Pre-#475 this dropped every table including ``events``; #454's
    persistent alert log made that unsafe (operator loses real signal
    on every schema bump). The OQ7-refined behavior preserves stateful
    tables. ``CREATE … IF NOT EXISTS`` makes the re-run of
    ``SCHEMA_DDL`` a no-op for the preserved tables.
    """
    current = _read_user_version(con)
    if current == SCHEMA_VERSION:
        return False
    if current != 0:
        # Drift — drop only derivable tables. Stateful tables
        # (currently `events`) are preserved across the bump per
        # OQ7 refinement; their DDL is `CREATE … IF NOT EXISTS` so
        # the re-run of SCHEMA_DDL skips them safely.
        for name in _DERIVABLE_ACTION_LOG_TABLES:
            con.execute(f"DROP TABLE IF EXISTS {name}")
    for ddl in SCHEMA_DDL:
        con.execute(ddl)
    _set_user_version(con, SCHEMA_VERSION)
    con.commit()
    return True


def close_connection(con: sqlite3.Connection) -> None:
    """Close the connection. Idempotent — safe on already-closed
    connections (sqlite3 raises ProgrammingError on double-close;
    swallowed here so the daemon's shutdown path doesn't have to
    track open/closed state)."""
    try:
        con.close()
    except sqlite3.ProgrammingError:  # pragma: no cover — DEFENSIVE: sqlite3.Connection.close() is idempotent on a closed con; raise only happens for cross-thread access scenarios that the daemon's single-thread sqlite usage doesn't hit.
        pass


# --- SqliteAlertLog (D4.2 / #354) -----------------------------------------


class SqliteAlertLog:
    """sqlite-backed replacement for the in-memory ``AlertLog`` ring
    buffer (#341).

    API parity with ``forge_manager_mcp.daemon.alerts.AlertLog`` —
    ``record(alert)`` / ``recent(*, since, level_at_least, limit)`` /
    ``__len__()`` / ``clear()``. Callers pre-existing-to-#354 keep
    working under the same surface; the daemon's ``main.py`` swaps
    one constructor for the other.

    Persistence: every ``record`` writes to the ``events`` table
    (auto-commit). Daemon restart preserves history — the headline
    behavior change vs the in-memory version.

    Connection ownership: the daemon owns the lifecycle. This class
    holds a reference and never closes it. ``ensure_schema`` must be
    called on the connection before construction.
    """

    def __init__(self, con: sqlite3.Connection):
        self._con = con

    def record(self, alert) -> None:
        """Append an alert to the events table, with dedup-by-content
        (#454).

        ``timestamp`` serializes via ``datetime.isoformat()`` —
        round-trips exactly via ``fromisoformat`` on the read side.
        ``tags`` JSON-encodes since sqlite has no native list type.
        Auto-commit per write.

        Dedup contract (#454): the content key
        ``(level, message, detail, platform_id, tags)`` identifies an
        alert by its observable shape. When ``record`` is called with
        a content-key match to an existing row, the existing row's
        ``timestamp`` is updated to the new sighting and no new row
        is INSERTed. This collapses re-fired alerts (e.g. the
        ``code_design.*`` watch-loop publishing the same finding on
        every mtime change for a touched file) into a single
        canonical row whose timestamp tracks the most-recent
        observation.

        Pre-#454, every call appended; the daemon's alert log grew
        unboundedly with duplicates — 6,780 unobserved rows for what
        was structurally ~100 distinct findings on 2026-05-13.
        """
        tags_json = json.dumps(list(alert.tags))
        cur = self._con.execute(
            "SELECT id FROM events WHERE "
            "level = ? AND message = ? AND "
            "IFNULL(detail, '') = IFNULL(?, '') AND "
            "IFNULL(platform_id, '') = IFNULL(?, '') AND "
            "tags = ? "
            "LIMIT 1",
            (
                alert.level,
                alert.message,
                alert.detail,
                alert.platform_id,
                tags_json,
            ),
        )
        row = cur.fetchone()
        if row is not None:
            # Dedup match — update timestamp to track latest sighting.
            self._con.execute(
                "UPDATE events SET timestamp = ? WHERE id = ?",
                (alert.timestamp.isoformat(), row["id"]),
            )
        else:
            self._con.execute(
                "INSERT INTO events "
                "(timestamp, level, message, detail, platform_id, tags) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    alert.timestamp.isoformat(),
                    alert.level,
                    alert.message,
                    alert.detail,
                    alert.platform_id,
                    tags_json,
                ),
            )
        self._con.commit()

    def recent(
        self,
        *,
        since: datetime | None = None,
        level_at_least: str | None = None,
        limit: int | None = None,
    ) -> list:
        """Return matching alerts newest-first.

        Filters mirror ``AlertLog.recent``:

        * ``since`` — only alerts with ``timestamp > since``.
        * ``level_at_least`` — minimum severity (inclusive); unknown
          levels always surface (same semantics as in-memory).
        * ``limit`` — cap on returned entries.

        Implementation: SQL applies ``since`` filter (uses
        ``events_timestamp_idx``); ``level_at_least`` filter runs
        in Python over the result rows so unknown-level handling
        matches the in-memory implementation exactly.
        """
        # Late import to keep action_log's runtime closure narrow —
        # tests that don't exercise SqliteAlertLog don't pull alerts.py.
        from forge_manager_mcp.daemon.alerts import _level_rank, make_alert

        conditions: list[str] = []
        params: list = []
        if since is not None:
            conditions.append("timestamp > ?")
            params.append(since.isoformat())
        sql = (
            "SELECT timestamp, level, message, detail, platform_id, tags "
            "FROM events"
        )
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY id DESC"
        cur = self._con.execute(sql, params)

        min_rank = _level_rank(level_at_least) if level_at_least is not None else None
        out: list = []
        for row in cur:
            if min_rank is not None:
                row_rank = _level_rank(row["level"])
                # Unknown levels (rank -1) always surface — matches
                # AlertLog.recent behavior.
                if row_rank >= 0 and row_rank < min_rank:
                    continue
            out.append(make_alert(
                level=row["level"],
                message=row["message"],
                detail=row["detail"],
                platform_id=row["platform_id"],
                timestamp=datetime.fromisoformat(row["timestamp"]),
                tags=tuple(json.loads(row["tags"] or "[]")),
            ))
            if limit is not None and len(out) >= limit:
                break
        return out

    def __len__(self) -> int:
        cur = self._con.execute("SELECT COUNT(*) FROM events")
        return int(cur.fetchone()[0])

    def clear(self) -> None:
        """Drop all retained alerts. Used by tests."""
        self._con.execute("DELETE FROM events")
        self._con.commit()


# --- FTS5 population (D4.3 / #354) ----------------------------------------


def populate_fts5(
    con: sqlite3.Connection,
    docs_root: Path,
    project_root: Path | None = None,
) -> dict[str, int]:
    """Walk the canonical store and populate the FTS5 indices.

    Returns a per-kind row-count dict (``{"issues": N, "discussions": M,
    "sessions": K, "code": L}``) for diagnostics.

    **Does not clear existing rows** — caller is responsible for
    invoking ``rebuild_fts5`` (D4.4) when it wants drop+repopulate
    semantics. ``populate_fts5`` on a freshly-bootstrapped schema is
    the typical "first run" path; the rebuild helper layers on top.

    Tolerant of missing canonical subdirectories: a docs-root
    without ``issues/`` or ``discussions/`` or ``sessions/`` simply
    yields zero rows for that kind. (A pre-bootstrap project may
    have only some of the three; FTS5 still works against the
    populated subset.)

    (#384, 3.9.0 D3.1) ``project_root`` opt-in: when set, also
    populates ``code_fts`` from the project's canonical-store code
    subdirs. ``None`` (default) skips code indexing — useful for
    test environments and pre-bootstrap projects without a
    ``--project-dir``. Code rows count under the ``"code"`` key.

    Effect — wraps the canonical_walker's read-effects + executes
    INSERTs against the connection.
    """
    # Late import keeps action_log's runtime deps narrow + matches
    # the alerts.py late-import pattern. canonical_walker is pure.
    from forge_manager_mcp.daemon.canonical_walker import (
        walk_code_files, walk_discussions, walk_issues, walk_sessions,
    )

    # (#273 F2, 3.7.0 D7) Batch inserts via executemany + a single
    # transaction. Pre-F2 each row was a separate `con.execute(...)`
    # call inside an implicit autocommit cycle — for a docs store
    # with N issues + M discussions + K sessions, that's N+M+K
    # individual SQL roundtrips + commits. With executemany +
    # explicit commit, all inserts batch into one prepared
    # statement per kind + one final commit. Hot path for the
    # 3.6.0 D4.6 incremental refresh on every `write.completed`
    # event — pre-F2 a 1000-issue project re-paid this overhead
    # on every canonical write. Materialize the generator into a
    # list per kind so the count stays accurate even on iterator
    # exhaustion semantics.
    issues_rows = list(walk_issues(docs_root))
    discussions_rows = list(walk_discussions(docs_root))
    sessions_rows = list(walk_sessions(docs_root))
    code_rows = (
        list(walk_code_files(project_root)) if project_root is not None else []
    )

    if issues_rows:
        con.executemany(
            "INSERT INTO issues_fts (ref_native_id, title, body) "
            "VALUES (?, ?, ?)",
            issues_rows,
        )
    if discussions_rows:
        con.executemany(
            "INSERT INTO discussions_fts (ref_native_id, title, body) "
            "VALUES (?, ?, ?)",
            discussions_rows,
        )
    if sessions_rows:
        con.executemany(
            "INSERT INTO sessions_fts (session_id, body) "
            "VALUES (?, ?)",
            sessions_rows,
        )
    if code_rows:
        con.executemany(
            "INSERT INTO code_fts (path, content) VALUES (?, ?)",
            code_rows,
        )

    con.commit()
    return {
        "issues": len(issues_rows),
        "discussions": len(discussions_rows),
        "sessions": len(sessions_rows),
        "code": len(code_rows),
    }


def rebuild_fts5(
    con: sqlite3.Connection,
    docs_root: Path,
    project_root: Path | None = None,
) -> dict[str, int]:
    """Drop + re-create + re-populate the FTS5 indices from canonical.

    Triggered by: PRAGMA mismatch (paired with ``ensure_schema``),
    integrity check failure, ``forge-manager-mcp action-log rebuild``
    CLI subcommand, or any operator action that wants a clean FTS5
    state without dropping the events log.

    Returns the per-kind count dict from the underlying
    ``populate_fts5`` call.

    **Events table is preserved** — alert log entries are not
    derivable from canonical. Only FTS5 tables (``issues_fts`` /
    ``discussions_fts`` / ``sessions_fts``) get dropped + rebuilt.

    The CREATE statements use ``IF NOT EXISTS`` so re-running the
    full ``SCHEMA_DDL`` after dropping just the FTS5 tables is safe
    (events / index DDL becomes no-op).
    """
    for name in _FTS5_TABLES:
        con.execute(f"DROP TABLE IF EXISTS {name}")
    for ddl in SCHEMA_DDL:
        con.execute(ddl)
    con.commit()
    return populate_fts5(con, docs_root, project_root)


# (#386, 3.9.0 D3.3) Per-operation rebuild dispatch — maps the
# write.completed event's operation_name to the FTS5 kinds it can
# affect, so the post-write refresh touches only relevant tables
# instead of the full all-tables rebuild. Pre-D3.3 every canonical
# write paid a full FTS5 rebuild; on a 1000-Issue store the cost
# was N*walk + N*INSERT every time a single Discussion comment
# landed. Post-D3.3, an Issue-create rebuilds only issues_fts.
_OP_TO_KINDS: dict[str, tuple[str, ...]] = {
    "create_issue": ("issues",),
    "update_issue_body": ("issues",),
    "close_issue": ("issues",),
    "append_comment": ("issues", "discussions"),  # could be either
    "create_discussion": ("discussions",),
    "update_discussion_body": ("discussions",),
    "mark_answer": ("discussions",),
}


def refresh_shadow_for_op(
    con: sqlite3.Connection,
    operation_name: str,
    walker_context: dict | None = None,
    registry_module=None,
) -> dict[str, int]:
    """(#475 / 3.14.0) Refresh the shadow tables an operation touches.

    Companion to :func:`refresh_fts5_for_op` — same dispatch shape,
    but reads :mod:`shadow.registry`'s op→table map (populated by
    per-table PRs via ``shadow.registry.register_op_refresh``) and
    invokes each affected table's walker to re-derive its rows.

    Returns a per-table row-count dict. Empty when no shadow tables
    are registered for ``operation_name`` (the framework PR's
    "no-op when shadow registry is empty" contract).

    Args:
        con: The action-log sqlite connection.
        operation_name: ``write.completed`` event's operation_name.
        walker_context: Per-table walker context dict (e.g.,
            ``{"docs_root": Path(...), "project_root": Path(...)}``).
            Forwarded verbatim to each walker.
        registry_module: Override the registry source — tests inject
            fakes; production callers leave as ``None`` to use the
            real :mod:`shadow.registry`.
    """
    if registry_module is None:
        from forge_manager_mcp.shadow import registry as registry_module
    tables = registry_module.tables_for_op(operation_name)
    if not tables:
        # No-op for the empty-registry case the framework PR ships.
        return {}
    ctx = walker_context or {}
    counts: dict[str, int] = {}
    for table in tables:
        # Drop + recreate the table's DDL then re-walker. Mirrors the
        # FTS5 refresh shape: derived tables are always safe to drop
        # before repopulating.
        from forge_manager_mcp.shadow.migration import _view_name_for_table
        con.execute(f"DROP TABLE IF EXISTS {table}")
        con.execute(f"DROP VIEW IF EXISTS {_view_name_for_table(table)}")
        for stmt in registry_module.ddl_for(table):
            con.execute(stmt)
        walker = registry_module.walker_for(table)
        if walker is None:
            counts[table] = 0
            continue
        counts[table] = walker(con, ctx)
    con.commit()
    return counts


def refresh_fts5_for_op(
    con: sqlite3.Connection,
    docs_root: Path,
    operation_name: str,
    project_root: Path | None = None,
) -> dict[str, int]:
    """(#386, 3.9.0 D3.3) Rebuild only the FTS5 tables an operation
    can affect, instead of the full multi-table rebuild.

    Maps ``operation_name`` (from ``write.completed`` event payload)
    to the affected FTS5 kinds via ``_OP_TO_KINDS``. Unknown ops
    fall back to the full rebuild — safer to over-rebuild than miss
    state that depends on the write.

    Returns the per-kind row-count dict for the touched kinds (other
    kinds aren't in the dict). For an unknown operation, returns
    the full ``populate_fts5`` shape.

    Effect — drops + recreates the affected FTS5 tables, then
    re-populates them from canonical. Other tables (events_log,
    untouched FTS5 kinds) are preserved.
    """
    from forge_manager_mcp.daemon.canonical_walker import (
        walk_code_files, walk_discussions, walk_issues, walk_sessions,
    )

    kinds = _OP_TO_KINDS.get(operation_name)
    if kinds is None:
        # Unknown op — full rebuild for safety.
        return rebuild_fts5(con, docs_root, project_root)

    # Drop + recreate just the affected FTS5 tables.
    table_for_kind = {
        "issues": "issues_fts",
        "discussions": "discussions_fts",
        "sessions": "sessions_fts",
        "code": "code_fts",
    }
    affected_tables = [table_for_kind[k] for k in kinds]
    for name in affected_tables:
        con.execute(f"DROP TABLE IF EXISTS {name}")
    # Re-create via the shared SCHEMA_DDL — events / index DDL are
    # IF NOT EXISTS so they're no-op when present.
    for ddl in SCHEMA_DDL:
        con.execute(ddl)
    con.commit()

    counts: dict[str, int] = {}
    for kind in kinds:
        if kind == "issues":
            rows = list(walk_issues(docs_root))
            if rows:
                con.executemany(
                    "INSERT INTO issues_fts (ref_native_id, title, body) "
                    "VALUES (?, ?, ?)",
                    rows,
                )
            counts["issues"] = len(rows)
        elif kind == "discussions":
            rows = list(walk_discussions(docs_root))
            if rows:
                con.executemany(
                    "INSERT INTO discussions_fts (ref_native_id, title, body) "
                    "VALUES (?, ?, ?)",
                    rows,
                )
            counts["discussions"] = len(rows)
        elif kind == "sessions":
            rows = list(walk_sessions(docs_root))
            if rows:
                con.executemany(
                    "INSERT INTO sessions_fts (session_id, body) "
                    "VALUES (?, ?)",
                    rows,
                )
            counts["sessions"] = len(rows)
        elif kind == "code" and project_root is not None:
            rows = list(walk_code_files(project_root))
            if rows:
                con.executemany(
                    "INSERT INTO code_fts (path, content) VALUES (?, ?)",
                    rows,
                )
            counts["code"] = len(rows)
    con.commit()
    return counts
