"""Pre-save credential test (#366 / 3.8.0 D6 / Theme F).

Validates a freshly-entered token against the platform's whoami
endpoint without persisting it. The wizard / CredentialsPanel use
this so the operator gets immediate auth feedback rather than
waiting for the next mirror write to fail with a 401/403.

Per Discussion-decision in #366: the daemon never stores the
token from this path — it lives only in the request body and the
transient httpx call's auth header. The persistence-no-op
assertion test in D6's test suite enforces this.
"""
from __future__ import annotations

import asyncio
from typing import Any


_PROBE_TIMEOUT = 8.0  # seconds; covers slow remote APIs but bounded


async def test_credential(platform_id: str, token: str) -> dict:
    """Validate ``token`` against ``platform_id``'s whoami endpoint.

    Returns ``{ok: bool, platform_id, identity?, error?}``. Never
    raises — every failure path returns a structured ``{ok: false,
    error: ...}`` envelope so the wizard can render a status line
    without exception handling.

    Implementations dispatch by ``platform_id``:
      * ``local`` — trivially ok (no token concept).
      * ``github`` — GET https://api.github.com/user with Bearer.
      * ``codeberg`` / ``forgejo`` — GET <base>/api/v1/user with token.
      * ``gitlab`` — GET https://gitlab.com/api/v4/user with Bearer.
    """
    if platform_id == "local":
        return {
            "ok": True, "platform_id": platform_id,
            "identity": "local-store (no token required)",
        }
    handler = _HANDLERS.get(platform_id)
    if handler is None:
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"no test handler for platform {platform_id!r}",
        }
    try:
        return await handler(platform_id, token)
    except Exception as exc:  # noqa: BLE001 — best-effort; surface as error
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"{type(exc).__name__}: {exc}",
        }


async def _test_github(platform_id: str, token: str) -> dict:
    import httpx
    async with httpx.AsyncClient(timeout=_PROBE_TIMEOUT) as client:
        resp = await client.get(
            "https://api.github.com/user",
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
            },
        )
    if resp.status_code != 200:
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"HTTP {resp.status_code}",
        }
    payload = resp.json()
    return {
        "ok": True, "platform_id": platform_id,
        "identity": payload.get("login") or payload.get("name") or "?",
    }


async def _test_forgejo(platform_id: str, token: str) -> dict:
    import httpx
    base = (
        "https://codeberg.org" if platform_id == "codeberg"
        else "https://codeberg.org"  # default; per-instance Forgejo URLs supplied by config
    )
    async with httpx.AsyncClient(timeout=_PROBE_TIMEOUT) as client:
        resp = await client.get(
            f"{base}/api/v1/user",
            headers={"Authorization": f"token {token}"},
        )
    if resp.status_code != 200:
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"HTTP {resp.status_code}",
        }
    payload = resp.json()
    return {
        "ok": True, "platform_id": platform_id,
        "identity": payload.get("login") or payload.get("username") or "?",
    }


async def _test_gitlab(platform_id: str, token: str) -> dict:
    import httpx
    async with httpx.AsyncClient(timeout=_PROBE_TIMEOUT) as client:
        resp = await client.get(
            "https://gitlab.com/api/v4/user",
            headers={"Authorization": f"Bearer {token}"},
        )
    if resp.status_code != 200:
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"HTTP {resp.status_code}",
        }
    payload = resp.json()
    return {
        "ok": True, "platform_id": platform_id,
        "identity": payload.get("username") or payload.get("name") or "?",
    }


_HANDLERS: dict[str, Any] = {
    "github": _test_github,
    "codeberg": _test_forgejo,
    "forgejo": _test_forgejo,
    "gitlab": _test_gitlab,
}
