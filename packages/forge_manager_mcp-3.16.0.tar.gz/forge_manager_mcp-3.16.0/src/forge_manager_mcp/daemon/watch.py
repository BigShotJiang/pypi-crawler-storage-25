"""(#347 / 3.7.0 D4) Live code-design analyzer via filesystem polling.

Runs as a daemon background task. Polls ``project_dir`` for ``*.py``
mtime changes; on change, invokes the registered ``code_design``
evaluators against each changed file and pushes findings into the
daemon's alert log. Findings show up via the existing
``GET /alerts`` endpoint and SSE channel — same surface as
backend-transition + credentials-failure alerts.

**Why polling rather than ``watchfiles``.** Polling-based design
keeps the runtime dep tree at stdlib only — ``watchfiles`` would
add a Rust-backed wheel for sub-second latency that's overkill
for the target use case (operator wants feedback the next time
they check the alert log or open a session). The full LSP-tier
sub-second-latency alternative is tracked in #347 as the higher-
fidelity follow-up; the watch-daemon path is the bounded "lighter-
weight" alternative the issue body itself suggests.

**No initial-tree scan.** ``check_code_design`` (the MCP tool)
covers the snapshot scan; the watch loop's job is the
since-last-poll delta. This means the loop's first poll captures
the mtime baseline silently — only post-baseline edits surface as
alerts.

**Test purity.** All four primitive functions (``snapshot_mtimes``
/ ``changed_paths`` / ``evaluate_paths`` / ``alerts_for_findings``)
are pure relative to their inputs (the directory walk + stat is
deterministic given the filesystem). The async ``watch_loop``
wraps them with sleep + record-into-alert-log; tests cover each
primitive independently and use ``asyncio.timeout`` to bound the
loop test.
"""
from __future__ import annotations

import asyncio
import fnmatch
import logging
import os
from pathlib import Path

from .alerts import make_alert


_LOG = logging.getLogger(__name__)


_DEFAULT_SCOPE: tuple[str, ...] = ("**/*.py",)
_DEFAULT_POLL_INTERVAL = 2.0  # seconds

# (#380) Path-component fnmatch patterns the watch loop skips. Covers
# Bazel build artifacts (``build/lib/<pkg>/``), Python bytecode caches,
# editable-install eggs, virtualenvs, JS toolchain output, VCS plumbing,
# and pytest scratch — all of which contain ``*.py`` files but mirror
# canonical sources (so scanning them double/triple-fires every
# code_design finding). Matched against each path component via
# ``fnmatch.fnmatchcase`` so glob suffixes (``*.egg-info``, ``bazel-*``)
# work without per-pattern special-casing.
_DEFAULT_DENYLIST: tuple[str, ...] = (
    "build", "dist", "__pycache__", "*.egg-info",
    ".venv", "venv", "node_modules", ".git",
    ".pytest_cache", "bazel-*",
)


def path_in_denylist(path: Path, denylist: tuple[str, ...]) -> bool:
    """True when any segment of ``path`` matches any ``denylist`` pattern.

    Pure: depends only on its inputs. Tests cover it directly.
    """
    return any(
        fnmatch.fnmatchcase(part, pattern)
        for part in path.parts
        for pattern in denylist
    )


def snapshot_mtimes(
    project_dir: Path, *,
    scope: tuple[str, ...] = _DEFAULT_SCOPE,
    denylist: tuple[str, ...] = _DEFAULT_DENYLIST,
) -> "dict[Path, float]":
    """Walk ``project_dir`` for files matching ``scope`` glob patterns
    and return a path → mtime mapping.

    Files whose path includes a denylisted segment are skipped (#380 —
    Bazel build artifacts, ``__pycache__``, etc. would otherwise
    fire every code_design finding multiple times).

    Symlinked or otherwise duplicate paths that resolve to the same
    real file are deduped: the first appearance wins, subsequent
    aliases are silently skipped (#380 — the project's Bazel symlink
    layout has ``mcp-server/forge_manager_mcp/<name>.py`` symlinked to
    ``mcp-server/src/forge_manager_mcp/<name>.py``; both used to scan).

    Files that fail to stat (raced delete) are silently skipped —
    they'll either reappear on the next poll or stay absent.
    """
    out: dict[Path, float] = {}
    seen_realpaths: set[str] = set()
    for pattern in scope:
        for path in project_dir.glob(pattern):
            if not path.is_file():
                continue
            if path_in_denylist(path, denylist):
                continue
            try:
                real = os.path.realpath(path)
            except OSError:
                continue
            if real in seen_realpaths:
                continue
            seen_realpaths.add(real)
            try:
                out[path] = path.stat().st_mtime
            except OSError:
                continue
    return out


def changed_paths(
    prev: "dict[Path, float]", curr: "dict[Path, float]",
) -> "list[Path]":
    """Return the paths whose mtime changed (or appeared) between
    snapshots.

    Removed files are NOT returned — there's no current state to
    evaluate against. Their absence shows up implicitly: the next
    snapshot won't include them.
    """
    return [
        path for path, mtime in curr.items()
        if path not in prev or prev[path] != mtime
    ]


def evaluate_paths(
    project_dir: Path, paths: "list[Path]",
) -> list:
    """Run every registered ``code_design`` evaluator against
    ``paths``.

    Returns a flat list of ``Finding`` values. Each evaluator
    receives the project root + a list of paths (relative when
    possible — that matches the ``check_code_design`` tool's
    contract) + a default ``warn`` severity.

    Per-evaluator exceptions are logged and skipped rather than
    aborting the whole run — a single buggy evaluator should not
    take down the watch loop.
    """
    from forge_manager_mcp.code_design import all_rules, get_evaluator

    relative_paths: list[Path] = []
    for path in paths:
        try:
            relative_paths.append(path.relative_to(project_dir))
        except ValueError:
            relative_paths.append(path)

    findings: list = []
    for rule_name in all_rules():
        evaluator = get_evaluator(rule_name)
        if evaluator is None:
            continue
        try:
            rule_findings = evaluator(project_dir, relative_paths, "warn")
        except Exception as exc:  # noqa: BLE001 — see docstring
            _LOG.warning(
                "code_design rule %r raised on changed paths %s: %s",
                rule_name, relative_paths, exc,
            )
            continue
        findings.extend(rule_findings)
    return findings


def is_code_design_finding(finding) -> bool:
    """True when ``finding`` originates from a code_design evaluator.

    (#489 / 3.14.0) Code-design findings flow to ``shadow.findings_facts``
    only — they're advisory analytical signals, not operational events.
    Non-code_design findings (if any future evaluator emits them through
    the watch loop) still hit the alerts dispatch as operational events.

    Pure predicate. Detection is by-construction: every evaluator the
    watch loop iterates comes from ``code_design.all_rules()`` so every
    Finding the loop produces is a code_design finding. The predicate
    exists as a named seam so future non-code_design evaluators can
    join the loop without rewiring the dispatch decision.
    """
    # ``Finding.rule`` is the rule name minus the ``code_design.``
    # prefix (per ``make_finding``'s contract). The watch loop only
    # consults ``code_design.all_rules()``; any finding it produces is
    # code_design by construction. Best-effort attribute access — a
    # missing rule attr falls through to False (treat as operational).
    return getattr(finding, "rule", None) is not None


def operational_findings(findings: list) -> list:
    """Return only the non-code_design findings from ``findings``.

    (#489 / 3.14.0) Pre-#489, every Finding the watch loop produced
    flowed through ``alerts_for_findings`` → ``alert_log.record`` AND
    through ``shadow_emit``. Post-#489, code_design findings flow to
    findings_facts only; operational findings (none today, future-
    proofing seam) retain the alerts dispatch.

    Effect-then-interceptor split (Rule 2): this is the pure decision
    function; ``watch_loop`` does the alert-log effect. Tests can
    assert this predicate directly without spinning up the async loop.
    """
    return [f for f in findings if not is_code_design_finding(f)]


def alerts_for_findings(findings: list) -> list:
    """Build one ``Alert`` per ``Finding`` for the alert-log push.

    Tags: ``("code_design", "<rule>", "<severity>")`` so the UI's
    backend-filter pattern from #341 generalises (filter by tag).
    Detail carries the finding's message; the headline message is
    ``code_design.<rule>: <path>:<line>``.

    (#489 / 3.14.0) Callers should pre-filter via
    :func:`operational_findings` so code_design findings don't land
    in the alerts table. This helper preserves its pre-#489 contract
    (build alerts for any Finding shape) so callers that legitimately
    want operational-event alert tags from non-watch sources keep
    working unchanged.
    """
    out: list = []
    for f in findings:
        location = getattr(f, "location", None)
        path = getattr(location, "path", None) or "?"
        line = getattr(location, "line", None)
        location_str = f"{path}:{line}" if line is not None else str(path)
        severity = getattr(f, "severity", "info")
        level = severity if severity in ("info", "warn", "fail") else "info"
        out.append(make_alert(
            level=level,
            message=f"code_design.{f.rule}: {location_str}",
            detail=getattr(f, "message", ""),
            tags=("code_design", f.rule, severity),
        ))
    return out


async def watch_loop(
    project_dir: "Path | None",
    alert_log,
    *,
    poll_interval: float = _DEFAULT_POLL_INTERVAL,
    scope: tuple[str, ...] = _DEFAULT_SCOPE,
    persist_upsert=None,
    shadow_emit=None,
) -> None:
    """Long-running async task. Polls ``project_dir`` for changes and
    emits ``code_design`` findings to ``alert_log``.

    When ``persist_upsert`` is provided (#405 / 3.11.0 D1.b Phase 5),
    findings are also persisted as ``gaps/code_design.<rule>/``
    compound docs via ``persist_code_design_findings``. The upsert
    callable typically wraps ``ReplicationManager.write`` so the
    canonical store gets the finding-set state alongside the
    transient SSE alert.

    (#483 / 3.14.0) When ``shadow_emit`` is provided, every Finding
    is also recorded as a row in ``shadow.findings_facts`` alongside
    the alert dispatch. The callable shape is
    ``shadow_emit(finding, source_event) -> None`` — daemon.main
    attaches a closure over the action-log connection +
    :func:`shadow.findings.emit_finding_fact`. Best-effort: any
    failure is logged + the watch loop continues so a shadow-emit
    bug can't break operational alerting.

    No-op (returns immediately) when:
      * ``project_dir`` is None — daemon started without
        ``--project-dir``.
      * ``alert_log`` is None — test contexts that disable it.
      * ``project_dir`` doesn't exist or isn't a directory.

    Cancellation: respects ``asyncio.CancelledError``. The daemon's
    main loop cancels this task on shutdown so the polling stops
    cleanly.

    Per-iteration exceptions are logged and the loop continues —
    one bad poll should not break the whole watcher.
    """
    if project_dir is None or alert_log is None:
        return
    if not project_dir.exists() or not project_dir.is_dir():
        return

    prev = snapshot_mtimes(project_dir, scope=scope)

    # Track per-rule finding-set hash to debounce persistence —
    # only re-upsert a gap doc when the rule's finding-set changes.
    # Maps rule_name → tuple of (path, line, severity, message)
    # tuples (sorted for determinism).
    last_finding_signatures: dict[str, tuple] = {}

    while True:
        try:
            await asyncio.sleep(poll_interval)
            curr = snapshot_mtimes(project_dir, scope=scope)
            changed = changed_paths(prev, curr)
            prev = curr
            if not changed:
                continue
            findings = evaluate_paths(project_dir, changed)
            # (#489 / 3.14.0) Code_design findings flow ONLY to
            # ``shadow.findings_facts`` — the alerts table stays for
            # operational events (backend transitions, credential
            # failures, daemon lifecycle, upgrade drifts). The pre-
            # #489 dispatch fired alerts AND shadow_emit for every
            # Finding, producing ~500 code_design alerts per heavy
            # build cycle that bloated ``open_session.daemon_alerts``.
            # ``operational_findings`` returns only non-code_design
            # findings; today that's always empty (the watch loop
            # only registers code_design evaluators), but the seam
            # exists so future operational evaluators added to the
            # loop continue to hit the alerts dispatch.
            for alert in alerts_for_findings(operational_findings(findings)):
                alert_log.record(alert)
            # (#483 / 3.14.0) Emit each Finding to the bitemporal
            # shadow alongside the operational alert dispatch.
            # Best-effort: emitter failures are logged + the watch
            # loop continues so a shadow-emit bug can't break
            # operational alerting. The watch-iteration timestamp
            # serves as the source_event identifier for the
            # idempotency-via-finding_hash semantics.
            if shadow_emit is not None and findings:
                from datetime import datetime as _datetime
                from datetime import timezone as _timezone
                iter_event = (
                    f"watch_iter_"
                    f"{_datetime.now(_timezone.utc).isoformat()}"
                )
                for finding in findings:
                    try:
                        shadow_emit(finding, iter_event)
                    except Exception as exc:  # noqa: BLE001
                        _LOG.warning(
                            "shadow_emit failed for finding %r: %s",
                            getattr(finding, "rule", "?"), exc,
                        )
            if persist_upsert is not None:
                from forge_manager_mcp.gap_analysis.persist import (
                    persist_code_design_findings,
                    group_code_design_findings_by_rule,
                )
                # Debounce: only persist when the per-category
                # finding-set has actually changed since last run.
                grouped = group_code_design_findings_by_rule(findings)
                changed_categories: list = []
                for category, group in grouped.items():
                    signature = tuple(sorted(
                        (
                            getattr(f.location, "path", ""),
                            getattr(f.location, "line", None),
                            f.severity,
                            f.message,
                        )
                        for f in group
                    ))
                    if last_finding_signatures.get(category) != signature:
                        last_finding_signatures[category] = signature
                        changed_categories.append(category)
                if changed_categories:
                    # Persist only the categories whose finding-set changed.
                    filtered = [
                        f for f in findings
                        if f"code_design.{f.rule}" in changed_categories
                    ]
                    try:
                        await persist_code_design_findings(
                            filtered, upsert=persist_upsert,
                        )
                    except Exception as exc:  # noqa: BLE001
                        _LOG.warning(
                            "persist_code_design_findings failed: %s", exc,
                        )
        except asyncio.CancelledError:
            return
        except Exception as exc:  # noqa: BLE001 — see docstring
            _LOG.warning("watch_loop iteration failed: %s", exc)
