"""Daemon entry point — ``forge-manager-daemon`` console script
(Phase D3a / 3.5.0).

Starts the HTTP server bound to ``127.0.0.1:0`` (kernel-picked
ephemeral port), generates the auth token, writes the discovery
file, runs the event loop forever (or until idle-timeout — D4
adds that).

**Args.** Optional ``--project-name <name>`` (defaults to
DEFAULT_PROJECT_NAME). Optional ``--state-dir <path>`` overrides
the default state-dir resolution; primarily for testing.

**Lifecycle.**

1. Resolve state-dir + ensure permissions (0o700).
2. Generate session auth_token (256 bits of secrets.token_hex).
3. Find an ephemeral port via ``socket.bind(('127.0.0.1', 0))``.
4. Write daemon.json with PID + port + version + token.
5. Start the starlette app on that port.
6. On clean shutdown (SIGTERM / SIGINT), remove daemon.json.

**Out of scope for D3a.** Auto-spawn detached double-fork (D3a.3
adds the MCP-side spawn helper; the daemon binary itself doesn't
do daemonization here — the MCP's spawn helper handles process
detachment via ``subprocess.Popen(..., start_new_session=True,
stdout=DEVNULL, stderr=DEVNULL)``). Sqlite cache (D3b). Idle-
timeout (D4 / #298 OQ1 — 24h default, configurable).
"""
from __future__ import annotations

import argparse
import asyncio
import secrets
import signal
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path

from forge_manager_mcp import __version__
from forge_manager_mcp.daemon.discovery import (
    make_discovery_file,
    remove_discovery,
    write_discovery,
)
from forge_manager_mcp.daemon.http import make_app, resolve_ui_dist
from forge_manager_mcp.daemon.paths import (
    DEFAULT_PROJECT_NAME,
    ensure_dir,
    log_dir,
    state_dir,
)
from forge_manager_mcp.daemon.preferred_port import (
    pick_port,
    write_preferred_port,
)


def _load_and_populate_credentials(
    state_dir: Path,
    *,
    alert_log=None,
    broadcaster=None,
) -> None:
    """Phase D3b.4e / #331. Read encrypted credentials from state-dir
    + populate ``os.environ`` so ``_build_daemon_replication`` reads
    daemon-managed tokens transparently via the existing
    ``config.get_platform_token`` dispatcher.

    Tolerant: missing-file is silent (first-run / migrate_to_3_5
    not yet executed); decrypt failure logs a warning to stderr,
    publishes a `credentials.decrypt-fail` alert (#341), and falls
    through to env-var path so the daemon stays useful.

    Effect — env mutation + alert publish. Must run BEFORE
    ``_build_daemon_replication``; that's enforced by call ordering
    in ``main()``.
    """
    from forge_manager_mcp.daemon.credentials import (
        CredentialsError,
        load_credentials,
        populate_environ_from_credentials,
    )
    try:
        creds = load_credentials(state_dir)
    except CredentialsError as exc:
        sys.stderr.write(
            f"[forge-manager-daemon] WARN: encrypted credentials "
            f"unreadable, falling through to env vars: {exc}\n"
        )
        # (#341) Publish an alert so the MCP / UI sees this on next
        # session-start poll. Tolerant of missing alert_log /
        # broadcaster (call-site default None for tests / partial
        # initialization).
        if alert_log is not None and broadcaster is not None:
            from forge_manager_mcp.daemon.alerts import make_alert
            from forge_manager_mcp.daemon.events import publish_alert
            publish_alert(broadcaster, alert_log, make_alert(
                level="error",
                message=(
                    "Encrypted credential store failed to decrypt; "
                    "running on environment variables."
                ),
                detail=str(exc),
                tags=("credentials", "decrypt-fail"),
            ))
        return
    if creds is None:
        return  # No encrypted store → env-var path stays authoritative.
    populate_environ_from_credentials(creds)


def _platform_ids_from_config(config_payload: dict | None) -> list[str] | None:
    """Extract platform ids from the parsed config payload.

    Returns None when no config is loaded (so /credentials reports
    not-loaded). Returns a (possibly empty) list otherwise; an
    empty list means the operator's config has no platforms
    declared, which is unusual but valid (pre-bootstrap edit).
    """
    if config_payload is None:
        return None
    platforms = config_payload.get("platforms") or []
    return [p["id"] for p in platforms if "id" in p]


def _build_daemon_replication(
    project_dir: Path | None,
    *,
    state_dir: Path | None = None,
):
    """Construct the daemon's ReplicationManager from project_dir.

    Reuses the MCP's ``_build_replication`` factory so the daemon
    sees the same backend list. Returns None on any failure
    (missing project_dir, config load failure, manager-construction
    failure) — the daemon stays useful for /health + /config even
    when /backends has nothing to report.

    GitHub token resolution: defaults to ``os.environ['GITHUB_TOKEN']``
    when set, empty string otherwise. Empty string triggers the 2.x
    fallback path's GitHubAdapter degraded-mode behavior; non-GitHub
    adapter token resolution goes through ``config.get_platform_token``
    per the 3.2.0 #283 dispatcher.

    Per #331: ``_load_and_populate_credentials`` runs before this so
    daemon-managed tokens land in ``os.environ`` first; the existing
    dispatcher then reads them on the env-var path.

    ``state_dir`` (#377 / 3.8.1 D1) — when set, the manager persists
    adapter state to ``<state_dir>/replication-state.json`` and
    rehydrates from it at construction so backend state survives
    daemon restart.
    """
    if project_dir is None:
        return None
    try:
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        import os
        config = load_config(project_dir)
        github_token = os.environ.get("GITHUB_TOKEN", "")
        return _build_replication(
            config, github_token, state_dir=state_dir,
        )
    except Exception:
        # Tolerate every failure mode — the daemon stays useful
        # without backend state. The /backends endpoint reports
        # an empty list when replication is None.
        return None


def _load_project_config(
    project_dir: Path | None,
) -> tuple[dict | None, str | None]:
    """Load the project's GithubConfig if ``project_dir`` is set.

    Returns ``(payload, error)`` — exactly one is non-None.
    ``payload`` is the JSON-serializable dict (model_dump output).
    ``error`` is a string describing why load failed.

    When ``project_dir`` is None, returns ``(None, None)`` —
    /config will report ``loaded=False, reason="no --project-dir
    passed"`` from the make_app fallback.

    Failure modes covered (each returns a specific reason string):
      * Path doesn't exist
      * Path isn't a directory
      * No forge-config.json / github-config.json under .claude/
      * JSON parse error
      * Pydantic validation error
    """
    if project_dir is None:
        return (None, None)
    if not project_dir.exists():
        return (None, f"project_dir does not exist: {project_dir}")
    if not project_dir.is_dir():
        return (None, f"project_dir is not a directory: {project_dir}")
    try:
        from forge_manager_mcp.config import ConfigError, load_config
        config = load_config(project_dir)
        return (config.model_dump(mode="json"), None)
    except Exception as exc:
        # Catch broadly per the daemon's tolerate-everything contract;
        # ConfigError is the expected case but other exceptions
        # (filesystem permission, Pydantic version mismatch) get the
        # same fall-through.
        return (None, f"config load failed: {type(exc).__name__}: {exc}")


def _pick_ephemeral_port() -> int:
    """Bind to 127.0.0.1:0 to let the kernel pick a free port,
    then close. Race window between close and re-bind is small
    enough that production use is safe; tests bind directly via
    uvicorn config.

    Legacy helper — kept for back-compat with #428 unit tests. The
    daemon now goes through :func:`_pick_port_with_persistence`
    instead so the preferred-port file (#472) gets honored.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]
    finally:
        sock.close()


def _pick_port_with_persistence(sd: Path) -> int:
    """(#472 / 3.14.0) Compose the durable-preference flow.

    Reads ``<sd>/preferred-port`` and tries to bind that port. Falls
    back to ephemeral on conflict. Writes the chosen port back via
    :func:`write_preferred_port` so:

    * First spawn ever (no file) → ephemeral allocated + file
      written.
    * Subsequent spawn, preferred bindable → bound, file rewritten
      idempotently with the same value (cheap atomic-rename).
    * Subsequent spawn, preferred taken → ephemeral allocated, file
      rewritten with the new value (transient conflict permanently
      shifts the preference).

    Tolerant of write failure — if ``write_preferred_port`` raises
    ``OSError`` (read-only filesystem, perms), the daemon proceeds
    on the bound port without persistence. The session is still
    usable; just no preference-update.
    """
    port = pick_port(sd)
    try:
        write_preferred_port(sd, port)
    except OSError:  # pragma: no cover — write failure on the persistence path is non-fatal; daemon proceeds on the bound port.
        pass
    return port


def _generate_token(nbits: int = 256) -> str:
    """Random hex token. 256 bits = 64 hex chars; sufficient
    entropy for localhost-only auth."""
    return secrets.token_hex(nbits // 8)


def _parse_args(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(
        prog="forge-manager-daemon",
        description=(
            "Long-lived per-project HTTP service for forge-manager. "
            "Listens on 127.0.0.1:<random>; writes discovery file "
            "with auth token; serves MCP requests until shutdown."
        ),
    )
    parser.add_argument(
        "--project-name",
        default=DEFAULT_PROJECT_NAME,
        help="Per-project state-dir name (default: %(default)s).",
    )
    parser.add_argument(
        "--state-dir",
        type=Path,
        default=None,
        help="Override the default state-dir resolution. Primarily "
        "for testing; production runs use the auto-resolved path.",
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=None,
        help="Path to the forge-managed project's working directory "
        "(parent of `.claude/forge-config.json`). When provided, the "
        "daemon loads the project's GithubConfig at startup and "
        "serves it via GET /config. When omitted, /config returns "
        "{loaded: false, reason: ...}.",
    )

    # (#475 / 3.14.0) Subcommands for one-shot operator actions.
    # The default invocation (no subcommand) starts the HTTP server;
    # subcommands run a single task and exit. argparse subparsers
    # with `required=False` keep the no-subcommand path intact.
    subparsers = parser.add_subparsers(dest="subcommand")
    p_shadow = subparsers.add_parser(
        "shadow",
        help="Bitemporal shadow-table maintenance (Cluster A / 3.14.0).",
    )
    shadow_subs = p_shadow.add_subparsers(dest="shadow_subcommand")
    shadow_subs.add_parser(
        "rebuild",
        help=(
            "Drop + repopulate every derivable shadow table via its "
            "registered walker. Stateful tables (events) are "
            "preserved. Per OQ7 path b."
        ),
    )

    return parser.parse_args(argv)


def _run_shadow_rebuild(args) -> int:
    """``forge-manager-daemon shadow rebuild`` (Issue #475 / OQ7 b).

    Opens the action-log sqlite connection at the resolved state-dir,
    ensures the framework schema is bootstrapped, then dispatches to
    :func:`shadow.migration.rebuild_derivable_tables`. Logs per-table
    row counts to stderr and exits.

    Exit codes:

    * ``0`` — rebuild succeeded (zero or more tables rebuilt).
    * ``1`` — sqlite open or rebuild failure; error to stderr.
    """
    import sys

    from forge_manager_mcp.daemon.action_log import (
        ensure_schema, open_connection,
    )
    from forge_manager_mcp.shadow import migration, register_all

    # (#476 / 3.14.0) Populate the shadow registry before the rebuild
    # dispatcher consults it. Without this the registry stays empty
    # and the rebuild path is a no-op even when per-table modules
    # ship in the same wheel.
    register_all()

    sd = args.state_dir if args.state_dir is not None else state_dir(
        args.project_name,
    )
    ensure_dir(sd, mode=0o700)
    print(
        f"shadow rebuild: state-dir={sd}", file=sys.stderr,
    )
    con = open_connection(sd)
    try:
        ensure_schema(con)
        # Walker context is empty for the CLI invocation — per-table
        # walkers that need docs_root / project_root accept ``None``
        # gracefully (per OQ12 walker tolerance contract). Operator
        # uses the daemon's startup path when richer context is
        # needed.
        counts = migration.rebuild_derivable_tables(con)
    except Exception as exc:  # noqa: BLE001
        print(f"shadow rebuild failed: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            con.close()
        except Exception:  # noqa: BLE001 — best-effort close
            pass

    if not counts:
        print("shadow rebuild: no derivable tables registered (no-op).",
              file=sys.stderr)
    else:
        for table, n in sorted(counts.items()):
            print(f"shadow rebuild: {table} → {n} row(s)", file=sys.stderr)
    return 0


def _configure_file_logging(project_name: str) -> None:
    """(#339) Wire a RotatingFileHandler into the daemon's logging.

    Path: ``<log-dir>/forge-manager.log`` per ``daemon/paths.log_dir``.
    Rotation: 10 MB × 5 files per #298 OQ5 closure.

    Uvicorn's logger (and the root logger) both pick up the handler
    so request-level + application-level messages land in the same
    file. This makes ``forge-manager-mcp daemon-logs`` useful.
    """
    import logging
    from logging.handlers import RotatingFileHandler

    ld = log_dir(project_name)
    ensure_dir(ld, mode=0o700)
    log_path = ld / "forge-manager.log"

    handler = RotatingFileHandler(
        log_path, maxBytes=10 * 1024 * 1024, backupCount=5,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s",
    ))
    handler.setLevel(logging.INFO)

    # Wire into root + uvicorn loggers so both paths land in the
    # file. Idempotent across daemon restarts because Python's
    # logging keeps a singleton-per-name registry — duplicate
    # adds via fresh process == new handler instance.
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logging.getLogger(name).addHandler(handler)


# OPERATOR: uvicorn server invocation; only reachable by running
# the daemon as a subprocess. Unit tests cover the helpers around
# it; the lifecycle itself is exercised at integration time via
# tests/test_daemon_auto_restart_barrier.py + the live-startup-
# probe tests.
async def _serve(app, host: str, port: int) -> None:  # pragma: no cover
    """Run the starlette app via uvicorn (the de-facto starlette
    runner). Blocks until the server stops.
    """
    import uvicorn
    config = uvicorn.Config(
        app, host=host, port=port,
        log_level="warning",   # quiet by default; daemon logs to file in D4
        access_log=False,
    )
    server = uvicorn.Server(config)
    await server.serve()


# OPERATOR: daemon entry point; orchestrates module-level effects
# (signal handlers, event loop, uvicorn run). Exercised at integration
# time when the daemon spawns; unit tests cover the constituent
# helpers (_parse_args, _generate_token, _pick_ephemeral_port,
# _load_project_config, _build_daemon_replication,
# _load_and_populate_credentials, _platform_ids_from_config,
# _configure_file_logging) directly.
def main(argv: list[str] | None = None) -> int:  # pragma: no cover
    """Entry point. Returns process exit code.

    The console script in pyproject.toml binds this to
    ``forge-manager-daemon``.
    """
    args = _parse_args(argv)

    # (#475 / 3.14.0) Subcommand dispatch — `shadow rebuild` runs the
    # one-shot rebuild path and exits without spawning the HTTP
    # server. Other subcommands route through their own runners as
    # they're added.
    if getattr(args, "subcommand", None) == "shadow":
        if getattr(args, "shadow_subcommand", None) == "rebuild":
            return _run_shadow_rebuild(args)
        import sys as _sys
        print(
            "Usage: forge-manager-daemon shadow rebuild",
            file=_sys.stderr,
        )
        return 1

    sd = args.state_dir if args.state_dir is not None else state_dir(args.project_name)
    ensure_dir(sd, mode=0o700)

    # (#339) Configure file logging — writes to <log-dir>/forge-
    # manager.log so `forge-manager-mcp daemon-logs` has something
    # to tail. Call early so startup messages are captured.
    _configure_file_logging(args.project_name)

    auth_token = _generate_token()
    # (#472 / 3.14.0) Honor the durable preferred-port file before
    # falling back to a fresh ephemeral. The chosen port is persisted
    # back to <sd>/preferred-port so the next spawn picks up where
    # this one left off, even after clean shutdown wipes daemon.json.
    port = _pick_port_with_persistence(sd)
    started_at = datetime.now(timezone.utc)

    # Phase D3b.3: load the project's GithubConfig if --project-dir
    # was passed. Tolerate every failure mode (missing file,
    # malformed JSON, validation error) — the daemon stays useful
    # for /health probes and future endpoint surfaces even when no
    # config is loaded.
    config_payload, config_load_error = _load_project_config(
        args.project_dir,
    )

    # (#333 / #341 / #354) Construct broadcaster + alert log up front
    # so they can be threaded into both the credentials-load path
    # (decrypt-fail alert source) and the ReplicationManager state-
    # change listener (degraded alert source) before the HTTP app
    # is built. Per #354 / D4.2 the alert log is sqlite-backed —
    # alerts survive daemon restart. ensure_schema() is idempotent
    # so the second-and-subsequent daemon-of-this-project run is a
    # no-op.
    from forge_manager_mcp.daemon.events import (
        EventBroadcaster, make_event, publish_alert,
    )
    from forge_manager_mcp.daemon.alerts import make_alert
    from forge_manager_mcp.daemon.action_log import (
        SqliteAlertLog,
        ensure_schema,
        open_connection,
    )
    broadcaster = EventBroadcaster()
    action_log_con = open_connection(sd)
    ensure_schema(action_log_con)
    alert_log = SqliteAlertLog(action_log_con)

    # (#501 audit deferral / 3.15.0) Persistent audit log for mode
    # transitions, sharing the action_log connection. Schema lives
    # alongside the action_log + FTS5 + shadow `_facts` tables.
    # Idempotent ensure_schema; safe on every startup. The log is
    # threaded into ModesStateHolder via make_app so /modes/* mutations
    # survive daemon restart.
    from forge_manager_mcp.daemon import modes_persistence
    modes_persistence.ensure_schema(action_log_con)
    mode_transitions_log = modes_persistence.SqliteModeTransitionsLog(
        action_log_con,
    )

    # (#500 / 3.15.0) Populate the shadow registry + rebuild
    # derivable tables on startup. Pre-fix, the daemon called
    # ensure_schema (which creates action_log + FTS5 tables only)
    # without running shadow.migration.rebuild_derivable_tables —
    # so the 9 Cluster A `_facts` tables registered by per-table
    # modules never got their DDL executed. PRAGMA user_version
    # reported the post-3.14.0 SCHEMA_VERSION=11 because
    # ensure_schema set it, but the shadow tables themselves
    # were missing.
    #
    # The CLI `forge-manager-daemon shadow rebuild` subcommand
    # always called both register_all() + rebuild_derivable_tables;
    # the daemon startup path now mirrors that.
    #
    # Idempotent: rebuild_derivable_tables drops+recreates every
    # `derivable` table on each call. Walker repopulation runs
    # against the canonical filesystem if context is available,
    # or no-ops gracefully when the docs-repo isn't resolvable
    # (per the OQ12 walker tolerance contract).
    from forge_manager_mcp.shadow import migration as _shadow_migration
    from forge_manager_mcp.shadow import register_all as _shadow_register_all
    _shadow_register_all()
    try:
        _shadow_migration.rebuild_derivable_tables(action_log_con)
    except Exception as _exc:  # noqa: BLE001 - best-effort startup
        # Walker errors / per-table DDL bugs shouldn't block daemon
        # startup. Log and continue; the action_log + FTS5 schema
        # bootstrap already succeeded above, so /alerts + /search
        # endpoints still work.
        import logging as _logging
        _logging.getLogger("forge_manager_mcp.daemon").warning(
            "shadow.rebuild_derivable_tables on startup failed: %s",
            _exc,
        )

    # (A.2.9 / 3.15.0 / #23) Initialize canonical-DB at daemon
    # startup. Tolerant fallback: skipped when docs-repo unresolvable
    # (pre-bootstrap projects or docs_repo_path not configured).
    # Per OQ8 the filesystem stays authoritative until A.4 (filesystem
    # regenerator) ships and `canonical_db_ready` flips; in the
    # meantime canonical-DB is best-effort.
    import logging as _logging
    from forge_manager_mcp.daemon.canonical_db_init import (
        startup as _canonical_db_startup,
    )
    canonical_db_state = _canonical_db_startup(args.project_dir)
    _canonical_db_logger = _logging.getLogger("forge_manager_mcp.daemon")
    if canonical_db_state.connection is not None:
        _canonical_db_logger.info(
            "canonical_db_init: schema_version=%d at %s",
            canonical_db_state.schema_version,
            canonical_db_state.db_path,
        )
    elif canonical_db_state.reason is not None:
        _canonical_db_logger.info(
            "canonical_db_init: skipped (%s)",
            canonical_db_state.reason,
        )

    # (A.2.10 / 3.15.0 / #23) Wire the canonical-DB connection into
    # the dual-write dispatch module so the /writes hook can mirror
    # canonical filesystem writes into the DB. set_connection
    # accepts None — dispatch is a no-op until A.2.9 init succeeds.
    from forge_manager_mcp.daemon import canonical_db_dispatch
    canonical_db_dispatch.set_connection(canonical_db_state.connection)

    # (A.3.2 / 3.15.0 / #23) Same connection threaded into the
    # read-dispatch module so /reads can short-circuit to DB when
    # the row is present. Both dispatch modules use the same
    # singleton-per-process connection.
    from forge_manager_mcp.daemon import canonical_db_read_dispatch
    canonical_db_read_dispatch.set_connection(
        canonical_db_state.connection,
    )

    # (A.4.3 / 3.15.0 / #23) Construct the canonical-DB → filesystem
    # regenerator. The Regenerator class composes the pure dispatcher
    # (regenerate_all_to_filesystem) with a debounced asyncio task;
    # start() is called inside the event loop below, stop() is awaited
    # on shutdown. When canonical_db_state.connection is None
    # (pre-bootstrap or docs-repo unresolvable), we skip construction;
    # the regenerator pattern is no-op gracefully but we avoid the
    # task spawn entirely to keep the daemon's task graph clean.
    canonical_db_regenerator = None
    if canonical_db_state.connection is not None:
        from forge_manager_mcp.daemon.canonical_db_regenerator import (
            Regenerator as _Regenerator,
        )
        # docs_repo_path = parent of the db file, matching the
        # canonical_db_init resolution chain.
        _docs_repo_path = canonical_db_state.db_path.parent
        canonical_db_regenerator = _Regenerator(
            canonical_db_state.connection, _docs_repo_path,
        )

    # Phase D3b.4e (#331): populate os.environ from the encrypted
    # credentials store BEFORE _build_daemon_replication so the
    # existing get_platform_token dispatcher reads daemon-managed
    # tokens transparently. Tolerant of missing-file (first-run /
    # pre-migrate_to_3_5) and decrypt failures (logged, env-var
    # fallthrough). #341: decrypt failure publishes an alert.
    _load_and_populate_credentials(
        sd, alert_log=alert_log, broadcaster=broadcaster,
    )

    # Phase D3b.4: construct the daemon's own ReplicationManager
    # from the loaded config. Per parent RFC #5 §What state the
    # daemon owns: Backend health state is in-memory + cache snapshot,
    # rebuildable from canonical filesystem store. The daemon's
    # manager sees the same backend list the MCP sees (shared
    # forge-config.json) but maintains its own state map. /backends
    # endpoint exposes that map.
    replication = _build_daemon_replication(
        args.project_dir, state_dir=sd,
    )

    # (#333 / D3b.4g) Wire the ReplicationManager's state-change
    # listener to the (already-constructed) broadcaster +
    # alert log. State transitions emit a `backend.state_changed`
    # event for the UI; transitions to DEGRADED additionally
    # publish a `backend.degraded` alert (#341) for cross-session
    # surfaces (MCP poll + Claude session-start).
    if replication is not None:
        def _publish_state_change(entry) -> None:
            broadcaster.publish(make_event(
                event="backend.state_changed",
                data={
                    "platform_id": entry.platform_id,
                    "state": entry.state.value,
                    "display_status": entry.state.value,
                    "state_changed_at": entry.state_changed_at.isoformat(),
                    "last_error": (
                        str(entry.last_error)
                        if entry.last_error is not None else None
                    ),
                    "last_error_at": (
                        entry.last_error_at.isoformat()
                        if entry.last_error_at is not None else None
                    ),
                    "next_attempt_at": (
                        entry.next_attempt_at.isoformat()
                        if entry.next_attempt_at is not None else None
                    ),
                },
            ))
            # (#23 A.5 OQ2 / 3.15.0) DEGRADED-alert publish retired;
            # push failures now fire push_failed alerts at the
            # dispatch caller's site (per OQ4 chatty + first-of-N
            # adapter.unhealthy via replication.push_alerts helpers).

        replication.set_on_state_change(_publish_state_change)

        # (#482, 3.14.0) Wire the shadow.replication_state_facts emit
        # hook. Each ReplicationManager._set_state transition lands one
        # bitemporal fact row alongside the existing event publish +
        # persisted-state write. Best-effort: any sqlite / shadow
        # bootstrap failure is swallowed inside _set_state so a
        # mis-bootstrapped shadow table cannot poison the state
        # machine. Schema bootstrap happens before this wiring (the
        # ``ensure_schema`` + ``register_all`` invocations on app
        # startup register the table; the closure here references the
        # shadow.replication_state module lazily so a partial
        # bootstrap still degrades gracefully).
        def _emit_replication_state_fact(
            adapter_id: str,
            state_value: str,
            last_error,
            state_changed_at,
            source_event: str,
        ) -> None:
            from forge_manager_mcp.shadow.replication_state import (
                emit_state_transition,
            )
            emit_state_transition(
                action_log_con,
                adapter=adapter_id,
                state=state_value,
                last_error=last_error,
                state_changed_at=state_changed_at,
                source_event=source_event,
                recorded_by=None,
            )
            action_log_con.commit()

        replication.set_shadow_state_emitter(_emit_replication_state_fact)

        # (#368) Enable async mirror fan-out for the daemon's
        # ReplicationManager: canonical writes return immediately;
        # mirrors run as background tasks and publish their outcomes
        # to the broadcaster. Eliminates the ReadTimeout false-
        # positive class that buffers successful canonical writes
        # whenever a remote mirror is slow / failing.
        def _publish_mirror_event(event_name: str, data: dict) -> None:
            broadcaster.publish(make_event(event=event_name, data=data))

        replication.set_background_mirror_mode(
            publisher=_publish_mirror_event,
        )

    df = make_discovery_file(
        pid=__import__("os").getpid(),
        port=port,
        version=__version__,
        started_at=started_at,
        auth_token=auth_token,
    )
    write_discovery(sd, df)

    app = make_app(
        version=__version__,
        auth_token=auth_token,
        started_at=started_at,
        ui_dist=resolve_ui_dist(),
        broadcaster=broadcaster,
        config_payload=config_payload,
        config_load_error=config_load_error,
        replication=replication,
        state_dir=sd,
        platform_ids=_platform_ids_from_config(config_payload),
        alert_log=alert_log,
        action_log_con=action_log_con,  # (#354 / D4.5) /search endpoint
        mode_transitions_log=mode_transitions_log,  # (#501 audit deferral)
        project_dir=args.project_dir,  # (#351 / D5) per-repo enumeration
    )

    # Install signal handlers so we clean up the discovery file on
    # SIGTERM / SIGINT. uvicorn handles its own shutdown via the
    # signal; we just add the discovery-file cleanup.
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    def _cleanup_discovery():
        # (#472 audit / 3.14.0) Only daemon.json is removed here.
        # The durable <sd>/preferred-port file (written by
        # _pick_port_with_persistence) is intentionally retained
        # across clean shutdown — that's the whole point of the
        # second file. Operator deletes it manually to reset the
        # preference.
        remove_discovery(sd)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _cleanup_discovery)
        except NotImplementedError:
            # Windows doesn't support add_signal_handler in the
            # event loop. The daemon there relies on the OS signal
            # → uvicorn shutdown path; discovery cleanup runs in
            # the finally below.
            pass

    # (#347 / 3.7.0 D4) Live code-design analyzer — polls
    # project_dir/**/*.py for mtime changes, runs the registered
    # code_design evaluators against each changed file, pushes
    # findings into the alert log. No-op when --project-dir is
    # absent or when the alert log isn't available.
    from forge_manager_mcp.daemon.watch import watch_loop

    # (#373 / 3.8.0 D2.6) Upgrade-drift auto-poll — runs detect on
    # a 6h cadence; publishes upgrade.drift_detected alerts when the
    # repair count grows. Surfaces in the existing alert log so the
    # operator sees a banner without opening the Upgrade tab first.
    from forge_manager_mcp.daemon.alerts import alert_from_dict
    from forge_manager_mcp.daemon.events import publish_alert
    from forge_manager_mcp.upgrade.poll import poll_loop as _upgrade_poll_loop

    def _publish_upgrade_alert(payload: dict) -> None:
        try:
            alert = alert_from_dict(payload)
        except Exception:  # noqa: BLE001 — best-effort
            return
        publish_alert(broadcaster, alert_log, alert)

    def _config_provider() -> "dict | None":
        return config_payload

    # (#378 / 3.8.1 D2) Startup whoami probe — runs once after
    # serve starts. Fires per-adapter in parallel via asyncio.gather
    # with a bounded timeout. Probe failure transitions DEGRADED;
    # probe success on a #377-persisted-DEGRADED adapter promotes
    # back to HEALTHY. Disabled via daemon.startup_probe = false.
    from forge_manager_mcp.daemon.startup_probe import (
        get_startup_probe_timeout,
        is_startup_probe_enabled,
        run_startup_probe,
    )

    # (#405 / 3.11.0 D1.b Phase 5) persist_upsert callable — closure
    # over replication.write so watch_loop's debounced detection cycle
    # also persists code_design findings as gap compound docs.
    # No-op when replication is unavailable (test-only daemon contexts).
    async def _persist_upsert(*, category: str, tier: str, findings) -> None:
        if replication is None:
            return
        async def op(adapter, coords):
            return await adapter.upsert_gap(
                category=category, tier=tier,
                findings=list(findings), title=category,
            )
        try:
            await replication.write(
                operation_name="upsert_gap",
                op=op,
                repo_role="private",
            )
        except Exception:
            # Persistence failure is non-fatal — alert path still
            # delivers findings to the SSE channel.
            pass

    # (#483, 3.14.0) Shadow emit hook for findings_facts. The watch
    # loop invokes this once per Finding alongside the alert dispatch
    # so the structured query surface (GROUP BY rule, file) stays in
    # sync with the operational alert log. Best-effort: failures are
    # caught inside the watch loop so they can't break alerting.
    def _emit_finding_to_shadow(finding, source_event: str) -> None:
        from forge_manager_mcp.shadow.findings import emit_finding_fact
        emit_finding_fact(
            action_log_con,
            finding=finding,
            source_event=source_event,
        )
        action_log_con.commit()

    # (#470 sub-fix 2b) Periodic canonical-adapter reconciler. Wakes
    # every cadence_seconds (60s default) and re-probes the canonical
    # adapter's reachability; auto-promotes DEGRADED → HEALTHY when
    # the underlying cause has cleared. Closes the structural gap
    # the startup_probe leaves (which skips canonical adapters by
    # design — its whoami probe doesn't fit a filesystem-canonical).
    # The ~12h sticky-DEGRADED bug filed in #470 was exactly the case
    # this loop now handles.
    # (#23 A.5 OQ3) canonical_reconcile loop retired with the
    # state machine. Post-A.2 canonical-DB cut the canonical store
    # is the local sqlite + filesystem regenerator — there's no
    # "canonical unavailable → DEGRADED → auto-promote" cycle to
    # reconcile. The legacy module + tests were deleted; this
    # block is the seam where they were wired.

    async def _serve_with_watch():
        watch_task = asyncio.create_task(
            watch_loop(
                args.project_dir, alert_log,
                persist_upsert=_persist_upsert,
                shadow_emit=_emit_finding_to_shadow,
            )
        )
        upgrade_task = asyncio.create_task(
            _upgrade_poll_loop(
                project_dir=args.project_dir,
                state_dir=sd,
                config_provider=_config_provider,
                publisher=_publish_upgrade_alert,
            )
        )
        # (A.4.3 / 3.15.0 / #23) Start the canonical-DB → filesystem
        # regenerator's background task. The Regenerator owns its own
        # asyncio.Event + debounce loop; start() schedules
        # `_run_loop` via asyncio.create_task. No-op when the
        # regenerator wasn't constructed (canonical-DB unavailable).
        if canonical_db_regenerator is not None:
            canonical_db_regenerator.start()
        probe_task: asyncio.Task | None = None
        if (
            replication is not None
            and is_startup_probe_enabled(config_payload)
        ):
            probe_task = asyncio.create_task(
                run_startup_probe(
                    replication,
                    timeout=get_startup_probe_timeout(config_payload),
                )
            )
        # (#23 A.5 OQ3) canonical_reconcile task retired — see note
        # at the import block above. Post-A.2 the local canonical
        # store has no unavailable state worth auto-promoting from.
        # (#469) Signal that startup-time replication readiness has
        # been reached: credentials populated, replication
        # constructed, startup probe (if any) scheduled, canonical
        # reconciler scheduled. The MCP-side ``wait_for_ready`` polls
        # ``/health/ready`` and reads this flag through
        # ``app.state.ready`` so audit + mirror fan-out in
        # open_session don't race the post-restart daemon's
        # initialization window. Set once; never reset for the
        # daemon's lifetime.
        try:
            app.state.ready = True
        except AttributeError:  # pragma: no cover — DEFENSIVE: starlette always exposes app.state on construction; here for the case where a future framework swap drops the contract.
            pass
        try:
            await _serve(app, "127.0.0.1", port)
        finally:
            watch_task.cancel()
            upgrade_task.cancel()
            if probe_task is not None:
                probe_task.cancel()
            tasks_to_drain = [watch_task, upgrade_task]
            if probe_task is not None:
                tasks_to_drain.append(probe_task)
            for task in tasks_to_drain:
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
            # (A.4.3 / 3.15.0 / #23) Stop the canonical-DB regenerator
            # cleanly — await its own task drain + final flush so the
            # trailing debounce window of work is projected to the
            # filesystem before daemon exit. The Regenerator's stop()
            # is best-effort and tolerates its own flush failures.
            if canonical_db_regenerator is not None:
                try:
                    await canonical_db_regenerator.stop()
                except Exception:  # noqa: BLE001 — best-effort
                    pass

    try:
        loop.run_until_complete(_serve_with_watch())
    finally:
        _cleanup_discovery()
        loop.close()

    return 0


if __name__ == "__main__":  # pragma: no cover — OPERATOR: only fires when daemon/main.py is run as a script (`python -m forge_manager_mcp.daemon.main`); not reachable through import-driven test harness.
    sys.exit(main())
