"""In-memory mode + gate-state holder for the daemon (#501).

The daemon's modes endpoints (``GET /modes`` / ``GET /modes/current``
/ ``POST /modes/{name}``) read and mutate a small in-memory state
holder. Per Issue #501 §State transitions the holder records:

- The currently-applied gate-state map (gate_name → "open" | "closed").
  Defaults are the gate registry's ``default_state`` values — populated
  lazily by ``apply_mode`` calls or seeded from the gate registry at
  startup.
- The audit-log of mode transitions (transition_id, timestamp, actor,
  from/to mode, gate-state-before / gate-state-after, trigger).

This is **not** a canonical store — the daemon's process-local memory
holds it. Canonical persistence lands when the audit-log facts table
(per Issue #501 §Audit trail's ``mode_transitions_facts`` shadow
table) is wired in a later commit. Today the holder is sufficient
for the bidirectional UX (mode picker + status-display label) the
swimlane needs.

The module is pure of HTTP / starlette dependencies — handlers thread
the holder through their closures so unit tests can construct one
standalone and assert on the diffs.

Per Effects + Async parity (code-design.md): the holder owns the
mutation effect (Rule 2). The diff-computing functions
(``apply_mode_to_state``, ``revert_mode_diff``) are pure and live in
this module too — they're called from the holder, exposed for tests,
and stay free of asyncio / starlette.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import cache
from typing import Any


# Schema-as-functions per Rule 5: @dataclass class definitions live
# inside @cache-decorated factory functions so module-top-level AST
# scans see only function definitions, not class statements. Tests +
# production code access these via the module-level names below.


@cache
def _gate_change_class() -> type:
    @dataclass(frozen=True)
    class GateChange:
        """Single ``(gate, before_state, after_state, scope)`` record.

        Returned from ``apply_mode_to_state`` so the audit-log + SSE
        event can show the operator exactly which gates flipped.
        """
        gate: str
        before: str
        after: str
        scope: tuple[str, ...] = field(default_factory=tuple)

    return GateChange


GateChange = _gate_change_class()


@cache
def _mode_transition_class() -> type:
    @dataclass(frozen=True)
    class ModeTransition:
        """One mode-transition record for the audit log.

        Fields mirror Issue #501 §Audit trail's contract:
        ``transition_id`` (uuid4 hex), ``timestamp`` (UTC ISO-8601),
        ``actor`` (``operator`` / ``claude`` / ``daemon``),
        ``from_mode`` / ``to_mode`` (labels at start / end),
        ``trigger`` (one of ``select_mode`` / ``manual_toggle`` /
        ``startup_compute`` / ``auto_recompute``),
        ``gate_state_before`` / ``gate_state_after`` (snapshots),
        and ``changes`` (the per-gate diff for UI rendering).
        """
        transition_id: str
        timestamp: str
        actor: str
        from_mode: str
        to_mode: str
        trigger: str
        gate_state_before: dict[str, str]
        gate_state_after: dict[str, str]
        changes: tuple[GateChange, ...]

    return ModeTransition


ModeTransition = _mode_transition_class()


def apply_mode_to_state(
    current: dict[str, str],
    mode,
) -> tuple[dict[str, str], list[GateChange]]:
    """Compute the post-apply gate-state map + the diff record.

    Pure function — returns a new map, never mutates ``current``.
    The diff list captures every gate the mode's declarations
    touched, including no-op assignments (so the audit trail
    distinguishes "no change because already at target" from
    "gate not in mode").

    Scope tokens travel with the diff record but don't currently
    parameterize the state map shape — the daemon's gate evaluator
    consumes scope at evaluation time, not at state-mutation time.
    """
    new_state = dict(current)
    changes: list[GateChange] = []
    for decl in mode.gate_states:
        before = new_state.get(decl.gate, "open")
        new_state[decl.gate] = decl.state
        changes.append(GateChange(
            gate=decl.gate,
            before=before,
            after=decl.state,
            scope=tuple(decl.scope),
        ))
    return new_state, changes


def diff_changes(
    before: dict[str, str], after: dict[str, str],
) -> list[GateChange]:
    """Return the per-gate diff between two state snapshots.

    Used by ``revert_mode_diff`` + the manual-toggle recompute path
    to surface which gates the operator flipped (vs the mode-driven
    change). Walks the union of keys so additions / removals both
    register.
    """
    out: list[GateChange] = []
    for key in sorted(set(before) | set(after)):
        b = before.get(key, "open")
        a = after.get(key, "open")
        if a != b:
            out.append(GateChange(gate=key, before=b, after=a))
    return out


class ModesStateHolder:
    """Single-process in-memory holder for the daemon's gate state.

    Owns the active gate-state map + the audit log of mode
    transitions. Methods are sync (no IO) — the daemon's async
    request handlers call into them directly. Thread-safety: single
    asyncio event loop, single owner, no contention by construction.
    """

    def __init__(self, persistent_log: Any = None) -> None:
        """Construct an empty holder.

        ``persistent_log`` (#501 audit deferral): when supplied, every
        :meth:`record_transition` call also writes to this log via
        its ``record()`` method. The log's connection lifecycle is
        owned by the caller — typically a
        :class:`daemon.modes_persistence.SqliteModeTransitionsLog`
        sharing the daemon's action_log sqlite connection.

        ``None`` is fine and preserves the original in-memory-only
        behavior for tests + pre-persistence callers. Write failures
        on the persistent log are swallowed + logged (best-effort);
        the in-memory log still gets the record so daemon-side
        operations stay consistent.
        """
        self._gate_state: dict[str, str] = {}
        self._audit_log: list[ModeTransition] = []
        self._current_mode_label: str = "default"
        self._persistent_log = persistent_log

    @property
    def gate_state(self) -> dict[str, str]:
        """Snapshot of the current gate-state map.

        Returns a fresh dict each call so callers can't mutate the
        holder's interior state by reference. Cheap because the
        registry is small (dozens of entries, not thousands).
        """
        return dict(self._gate_state)

    @property
    def current_mode_label(self) -> str:
        """Last-computed mode label (default ``default`` until a
        transition runs)."""
        return self._current_mode_label

    @property
    def audit_log(self) -> list[ModeTransition]:
        """Tuple-equivalent read-only view of the transition log.

        Returns a fresh list so callers can iterate without
        mutating the holder's interior list.
        """
        return list(self._audit_log)

    def set_label(self, label: str) -> None:
        """Pin the displayed mode label without state mutation.

        Called by the recompute path when a manual gate toggle
        causes the label to change without a ``set_mode`` call —
        the gate state is already mutated by the caller; this
        method just synchronizes the displayed label.
        """
        self._current_mode_label = label

    def record_transition(
        self,
        *,
        actor: str,
        from_mode: str,
        to_mode: str,
        trigger: str,
        gate_state_before: dict[str, str],
        gate_state_after: dict[str, str],
        changes: list[GateChange],
    ) -> ModeTransition:
        """Append a ModeTransition to the audit log + return it.

        The returned record is the in-log instance so callers can
        reference its ``transition_id`` in the SSE payload
        without re-deriving it.
        """
        record = ModeTransition(
            transition_id=uuid.uuid4().hex,
            timestamp=datetime.now(timezone.utc).isoformat(),
            actor=actor,
            from_mode=from_mode,
            to_mode=to_mode,
            trigger=trigger,
            gate_state_before=dict(gate_state_before),
            gate_state_after=dict(gate_state_after),
            changes=tuple(changes),
        )
        self._audit_log.append(record)
        # (#501 audit deferral) Best-effort persistence to sqlite —
        # failures don't poison the in-memory state or the operation.
        if self._persistent_log is not None:
            try:
                self._persistent_log.record(record)
            except Exception as exc:  # noqa: BLE001 - best-effort
                import logging
                logging.getLogger(__name__).warning(
                    "mode-transition persistence failed: %s "
                    "(transition_id=%s); in-memory log still has the record",
                    exc, record.transition_id,
                )
        return record

    def apply_mode(
        self,
        mode,
        *,
        actor: str = "operator",
        trigger: str = "select_mode",
        dry_run: bool = False,
    ) -> tuple[ModeTransition | None, dict[str, Any]]:
        """Apply a mode to the holder's gate state.

        Returns ``(transition_or_None, response_payload)``. The
        payload mirrors Issue #501's set_mode contract:
        ``{applied_gates, previous_mode, new_mode, dry_run,
        transition_id?}``. Dry-run skips the mutation + audit-log
        append; the diff is still computed so the caller can
        preview.
        """
        before = self.gate_state
        new_state, changes = apply_mode_to_state(before, mode)
        previous_mode = self._current_mode_label
        new_mode = mode.name

        payload: dict[str, Any] = {
            "applied_gates": [_change_to_dict(c) for c in changes],
            "previous_mode": previous_mode,
            "new_mode": new_mode,
            "dry_run": dry_run,
        }

        if dry_run:
            return None, payload

        self._gate_state = new_state
        self._current_mode_label = new_mode
        record = self.record_transition(
            actor=actor,
            from_mode=previous_mode,
            to_mode=new_mode,
            trigger=trigger,
            gate_state_before=before,
            gate_state_after=new_state,
            changes=changes,
        )
        payload["transition_id"] = record.transition_id
        return record, payload

    def replace_gate_state(
        self,
        new_state: dict[str, str],
        *,
        actor: str = "operator",
        trigger: str = "manual_toggle",
        new_label: str | None = None,
    ) -> ModeTransition:
        """Replace the entire gate-state map.

        Used by the manual-toggle path: the operator flipped a gate
        directly (via the gate-map UI), the new label is computed
        externally, this method records the transition + replaces
        the snapshot.
        """
        before = self.gate_state
        previous_mode = self._current_mode_label
        changes = diff_changes(before, new_state)
        self._gate_state = dict(new_state)
        if new_label is not None:
            self._current_mode_label = new_label
        return self.record_transition(
            actor=actor,
            from_mode=previous_mode,
            to_mode=self._current_mode_label,
            trigger=trigger,
            gate_state_before=before,
            gate_state_after=new_state,
            changes=changes,
        )


def _change_to_dict(change: GateChange) -> dict[str, Any]:
    """Serialize a :class:`GateChange` for the HTTP response payload.

    Wire shape: ``{gate, before, after, scope}`` — list, not tuple,
    so JSON round-trips cleanly.
    """
    return {
        "gate": change.gate,
        "before": change.before,
        "after": change.after,
        "scope": list(change.scope),
    }


def transition_to_dict(transition: ModeTransition) -> dict[str, Any]:
    """Serialize a :class:`ModeTransition` for the SSE event payload.

    Wire shape matches Issue #501 §Audit trail's field list, with
    ``changes`` flattened to dicts via :func:`_change_to_dict`.
    """
    return {
        "transition_id": transition.transition_id,
        "timestamp": transition.timestamp,
        "actor": transition.actor,
        "from_mode": transition.from_mode,
        "to_mode": transition.to_mode,
        "trigger": transition.trigger,
        "gate_state_before": dict(transition.gate_state_before),
        "gate_state_after": dict(transition.gate_state_after),
        "changes": [_change_to_dict(c) for c in transition.changes],
    }
