"""Canonical-DB → filesystem regenerator (3.15.0 cluster A.4).

Per Discussion #23 OQ4 + OQ8 + OQ27. After canonical-DB became the
authoritative source for writes (A.2), the docs-repo filesystem
becomes a lazy projection. This module owns that projection — a
debounced background task that walks the canonical-DB and writes
each row back to the filesystem in the existing
``<docs>/<kind>/<n>/...`` layout.

Per OQ27: when A.4 stabilizes, the daemon flips
``canonical_db_ready=True``. Until then the flag stays False and
the swimlane UI gates on it; the existing IssuesTable surface
stays the default during the transition.

A.4 ships in sub-phases:

* A.4.0 (this commit) — module skeleton: Regenerator class with
  debounced ``notify()`` + ``flush()`` + ``run()`` async task,
  Issues entity regenerator as the reference, ``canonical_db_ready``
  flag set when first successful regeneration completes.
* A.4.1+ — per-entity regenerators for Discussions, Milestones,
  Plans, Comments, Sessions, Gaps, History (one each).
* A.4.N — incremental regeneration (per-write rather than full
  sweep); operator-visible flag flip.

Effects-then-interceptor split per Rule 2:

* :func:`regenerate_all_to_filesystem` — pure dispatcher that
  iterates registered per-entity regenerators against an
  injected sqlite connection + docs-repo path. No timer / no
  asyncio state. Testable as a single function call.
* :class:`Regenerator` — composes the dispatcher with a debounce
  timer + asyncio.Task lifecycle. Glue for daemon main().
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
from pathlib import Path
from typing import Callable


_log = logging.getLogger(__name__)


# Module-level flag per OQ27. False until A.4 finalizes; flipped
# True by the regenerator on first successful sweep.
_CANONICAL_DB_READY: bool = False


def is_canonical_db_ready() -> bool:
    """Per OQ27 — returns True after the first successful regenerator
    sweep. UI surfaces gate on this; the swimlane becomes default
    when it returns True. Until then the IssuesTable remains the
    default and the canonical-DB writes are a backup-only surface.
    """
    return _CANONICAL_DB_READY


def _set_canonical_db_ready(value: bool) -> None:
    """Test seam: explicitly flip the flag. Production code uses
    :class:`Regenerator` which flips it on first-successful-sweep.
    """
    global _CANONICAL_DB_READY
    _CANONICAL_DB_READY = value


# A per-entity regenerator takes (connection, docs_repo_path) and
# writes rows from canonical-DB back to filesystem. Returns the
# number of files written for diagnostics.
EntityRegenerator = Callable[[sqlite3.Connection, Path], int]


_REGISTRY: dict[str, EntityRegenerator] = {}


def register(entity: str):
    """Decorator: register an entity regenerator under ``entity``."""
    def deco(fn: EntityRegenerator) -> EntityRegenerator:
        _REGISTRY[entity] = fn
        return fn
    return deco


def registered_entities() -> list[str]:
    return sorted(_REGISTRY.keys())


def reset_registry_for_testing() -> None:
    _REGISTRY.clear()


def regenerate_all_to_filesystem(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> dict[str, int]:
    """Run every registered entity regenerator. Returns per-entity
    file-write counts. Pure dispatcher (no timer / async / state).

    Failures inside per-entity regenerators are caught + logged;
    the dispatcher continues with subsequent entities. Caller can
    detect partial-success by comparing the returned dict's keys
    to :func:`registered_entities`.
    """
    counts: dict[str, int] = {}
    for entity in registered_entities():
        try:
            counts[entity] = _REGISTRY[entity](conn, docs_repo_path)
        except Exception as exc:  # noqa: BLE001
            _log.warning(
                "regenerator entity=%s failed: %s; skipping",
                entity, exc,
            )
    return counts


# ---------------------------------------------------------------------------
# Per-entity regenerators
# ---------------------------------------------------------------------------

@register("issues")
def _regenerate_issues(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write every canonical-DB issue row to
    ``<docs>/issues/<n>/{title,body}.md`` + ``state.txt`` +
    ``labels.txt``.

    Reference entity per OQ4 + OQ8. The filesystem layout follows
    the existing pre-3.0 convention so that operators reading via
    ``cd ~/<project>-docs && grep`` see the same shape as before
    canonical-DB cut.

    Returns the number of files written.
    """
    rows = conn.execute(
        """
        SELECT number, title, body, state, state_reason, milestone,
               author, url, created_at, closed_at, updated_at
          FROM issues
         ORDER BY number
        """
    ).fetchall()
    issues_root = docs_repo_path / "issues"
    written = 0
    for row in rows:
        (
            number, title, body, state, state_reason, milestone,
            _author, _url, _created_at, _closed_at, _updated_at,
        ) = row
        issue_dir = issues_root / str(number)
        issue_dir.mkdir(parents=True, exist_ok=True)
        (issue_dir / "title.md").write_text(f"{title}\n")
        (issue_dir / "body.md").write_text(body or "")
        state_line = state
        if state == "closed" and state_reason:
            state_line = f"{state} ({state_reason})"
        (issue_dir / "state.txt").write_text(f"{state_line}\n")
        # Labels from the join table.
        label_rows = conn.execute(
            "SELECT label FROM issue_labels "
            "WHERE issue_number = ? ORDER BY label",
            (number,),
        ).fetchall()
        labels = [r[0] for r in label_rows]
        (issue_dir / "labels.txt").write_text(
            "\n".join(labels) + ("\n" if labels else ""),
        )
        # milestone field, optional.
        if milestone:
            (issue_dir / "milestone.txt").write_text(f"{milestone}\n")
        written += 4
    return written


@register("discussions")
def _regenerate_discussions(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write every discussion row to
    ``<docs>/discussions/<n>/{title,body}.md`` + ``state.txt`` +
    ``category.txt`` + ``labels.txt``.

    State layout writes both lifecycle + decided axis when decided=1
    (per multi-dim state convention pre-3.0).
    """
    rows = conn.execute(
        """
        SELECT number, title, body, state, category, decided
          FROM discussions
         ORDER BY number
        """
    ).fetchall()
    root = docs_repo_path / "discussions"
    written = 0
    for number, title, body, state, category, decided in rows:
        d = root / str(number)
        d.mkdir(parents=True, exist_ok=True)
        (d / "title.md").write_text(f"{title}\n")
        (d / "body.md").write_text(body or "")
        state_lines = [state]
        if decided:
            state_lines.append("decided")
        (d / "state.txt").write_text("\n".join(state_lines) + "\n")
        if category:
            (d / "category.txt").write_text(f"{category}\n")
        label_rows = conn.execute(
            "SELECT label FROM discussion_labels "
            "WHERE discussion_number = ? ORDER BY label",
            (number,),
        ).fetchall()
        labels = [r[0] for r in label_rows]
        (d / "labels.txt").write_text(
            "\n".join(labels) + ("\n" if labels else ""),
        )
        written += 4
    return written


@register("milestones")
def _regenerate_milestones(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write milestones to ``<docs>/milestones/<version>/``.

    PK is the semver version string; the filesystem directory uses
    the version directly. State + tier + cut_at + tag_sha go into
    meta.json (per 3.11.0 D1.a convention).
    """
    import json

    rows = conn.execute(
        """
        SELECT version, title, body, state, tier, hotfix,
               cut_at, tag_sha
          FROM milestones
         ORDER BY version
        """
    ).fetchall()
    root = docs_repo_path / "milestones"
    written = 0
    for version, title, body, state, tier, hotfix, cut_at, tag_sha in rows:
        d = root / version
        d.mkdir(parents=True, exist_ok=True)
        (d / "title.md").write_text(f"{title}\n")
        (d / "body.md").write_text(body or "")
        (d / "state.txt").write_text(f"{state}\n")
        meta = {
            "version": version,
            "tier": tier,
            "hotfix": bool(hotfix),
            "cut_at": cut_at,
            "tag_sha": tag_sha,
        }
        (d / "meta.json").write_text(
            json.dumps(meta, indent=2, sort_keys=True) + "\n",
        )
        written += 4
    return written


@register("plans")
def _regenerate_plans(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write plans to ``<docs>/plans/<n>/``.

    Plans are first-class per OQ3 — their filesystem layout is new
    in 3.15.0 (pre-3.15.0 plans lived as Discussions under
    ``<docs>/discussions/<n>/``). Layout: title.md, state.txt,
    meta.json (discussion_number, milestone_version,
    open_questions, total_questions).
    """
    import json

    rows = conn.execute(
        """
        SELECT number, title, discussion_number, state,
               milestone_version, open_questions, total_questions
          FROM plans
         ORDER BY number
        """
    ).fetchall()
    root = docs_repo_path / "plans"
    written = 0
    for (
        number, title, discussion_number, state,
        milestone_version, open_q, total_q,
    ) in rows:
        d = root / str(number)
        d.mkdir(parents=True, exist_ok=True)
        (d / "title.md").write_text(f"{title}\n")
        (d / "state.txt").write_text(f"{state}\n")
        meta = {
            "number": number,
            "discussion_number": discussion_number,
            "milestone_version": milestone_version,
            "open_questions": open_q,
            "total_questions": total_q,
        }
        (d / "meta.json").write_text(
            json.dumps(meta, indent=2, sort_keys=True) + "\n",
        )
        written += 3
    return written


@register("gaps")
def _regenerate_gaps(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write gaps to ``<docs>/gaps/<n>/`` per 3.11.0 D1.b.

    Layout: title.md, body.md, state.txt, meta.json (detector,
    severity, filed_issue_number).
    """
    import json

    rows = conn.execute(
        """
        SELECT number, title, body, state, detector, severity,
               filed_issue_number
          FROM gaps
         ORDER BY number
        """
    ).fetchall()
    root = docs_repo_path / "gaps"
    written = 0
    for (
        number, title, body, state, detector, severity,
        filed_issue_number,
    ) in rows:
        d = root / str(number)
        d.mkdir(parents=True, exist_ok=True)
        (d / "title.md").write_text(f"{title}\n")
        (d / "body.md").write_text(body or "")
        (d / "state.txt").write_text(f"{state}\n")
        meta = {
            "number": number,
            "detector": detector,
            "severity": severity,
            "filed_issue_number": filed_issue_number,
        }
        (d / "meta.json").write_text(
            json.dumps(meta, indent=2, sort_keys=True) + "\n",
        )
        written += 4
    return written


@register("comments")
def _regenerate_comments(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write comments to ``<docs>/<parent_kind>/<parent_number>/comments/<id>.md``.

    Comments don't have their own top-level directory — they live
    under their parent (issue or discussion). Pre-3.0 the
    filesystem convention was ``<iso8601>-<author>.md``; the
    canonical-DB row carries an auto-increment id so we use
    ``<id>-<created_at>.md`` for sortability + uniqueness.

    Each comment file body: a small frontmatter block (parent_id,
    author, created_at) followed by the comment body.
    """
    rows = conn.execute(
        """
        SELECT id, parent_kind, parent_number, parent_id,
               author, body, url, created_at, updated_at
          FROM comments
         ORDER BY parent_kind, parent_number, id
        """
    ).fetchall()
    written = 0
    for (
        id_, parent_kind, parent_number, parent_id,
        author, body, url, created_at, _updated_at,
    ) in rows:
        # Parent directory uses plural form per existing convention
        # (issue → issues/, discussion → discussions/).
        kind_dir = f"{parent_kind}s"
        comments_dir = (
            docs_repo_path / kind_dir / str(parent_number) / "comments"
        )
        comments_dir.mkdir(parents=True, exist_ok=True)
        fname = f"{id_:06d}-{created_at}.md".replace(":", "-")
        header_lines = [
            f"id: {id_}",
            f"author: {author}",
            f"created_at: {created_at}",
        ]
        if parent_id is not None:
            header_lines.append(f"parent_id: {parent_id}")
        if url:
            header_lines.append(f"url: {url}")
        header_block = "---\n" + "\n".join(header_lines) + "\n---\n\n"
        (comments_dir / fname).write_text(header_block + (body or ""))
        written += 1
    return written


@register("sessions")
def _regenerate_sessions(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write sessions to ``<docs>/sessions/<session_id>/session.json``.

    Pre-3.0 the filesystem layout was per-event JSON files
    (``<docs>/sessions/<id>/<ts>-<event>.json``). The canonical-DB
    sessions table holds session-level rollup only — opened_at,
    closed_at, summary. Daemon event payloads under sessions/<id>/
    are NOT touched here; they're written by the daemon's event
    log dispatch (orthogonal surface).

    The regenerator writes a single ``session.json`` per session
    carrying the canonical-DB row fields. This is additive — it
    coexists with whatever event JSON files the daemon writes.
    """
    import json

    rows = conn.execute(
        """
        SELECT session_id, opened_at, closed_at,
               prior_session_clean, summary
          FROM sessions
         ORDER BY opened_at
        """
    ).fetchall()
    written = 0
    for (
        session_id, opened_at, closed_at, prior_session_clean, summary,
    ) in rows:
        d = docs_repo_path / "sessions" / session_id
        d.mkdir(parents=True, exist_ok=True)
        payload = {
            "session_id": session_id,
            "opened_at": opened_at,
            "closed_at": closed_at,
            "prior_session_clean": bool(prior_session_clean),
            "summary": summary,
        }
        (d / "session.json").write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
        )
        written += 1
    return written


@register("artifact_history")
def _regenerate_artifact_history(
    conn: sqlite3.Connection,
    docs_repo_path: Path,
) -> int:
    """Write history events to
    ``<docs>/<artifact_kind>s/<artifact_id>/history/<id>-<recorded_at>.json``.

    Per-artifact append-only log (3.0.0 Phase 6 / #270 convention).
    The canonical-DB artifact_history table carries the structured
    rows; this regenerator projects them back to the filesystem.

    Each event JSON: ``{id, operation, payload, actor, session_id,
    recorded_at}``. Parent dir uses plural form
    (``<artifact_kind>s/<artifact_id>``) to match the
    issues/discussions/... convention.

    Skips artifact_kind values that aren't backed by a top-level
    dir (e.g., ``comment`` events log against the comment's parent
    rather than a comments/ dir).
    """
    import json

    rows = conn.execute(
        """
        SELECT id, artifact_kind, artifact_id, operation,
               payload, actor, session_id, recorded_at
          FROM artifact_history
         ORDER BY artifact_kind, artifact_id, recorded_at, id
        """
    ).fetchall()
    # Map artifact_kind to filesystem parent dir.
    _KIND_TO_DIR = {
        "issue": "issues",
        "discussion": "discussions",
        "milestone": "milestones",
        "plan": "plans",
        "gap": "gaps",
        "session": "sessions",
    }
    written = 0
    for (
        id_, artifact_kind, artifact_id, operation,
        payload, actor, session_id, recorded_at,
    ) in rows:
        parent_dir_name = _KIND_TO_DIR.get(artifact_kind)
        if parent_dir_name is None:
            # comment / unknown kinds — skip; their history doesn't
            # have a dedicated filesystem location.
            continue
        history_dir = (
            docs_repo_path / parent_dir_name / artifact_id / "history"
        )
        history_dir.mkdir(parents=True, exist_ok=True)
        fname = f"{id_:08d}-{recorded_at}.json".replace(":", "-")
        event = {
            "id": id_,
            "operation": operation,
            "payload": payload,
            "actor": actor,
            "session_id": session_id,
            "recorded_at": recorded_at,
        }
        (history_dir / fname).write_text(
            json.dumps(event, indent=2, sort_keys=True) + "\n",
        )
        written += 1
    return written


# ---------------------------------------------------------------------------
# Regenerator class — debounced background task glue
# ---------------------------------------------------------------------------

class Regenerator:
    """Debounced canonical-DB → filesystem regenerator.

    Lifecycle: daemon main() constructs one Regenerator instance,
    calls :meth:`start` to fire the asyncio background task,
    threads :meth:`notify` into canonical-DB write hooks so each
    write triggers an eventual flush. On daemon shutdown, calls
    :meth:`stop` to cancel the task cleanly.

    Debounce: ``notify()`` resets the timer. The task wakes after
    ``debounce_seconds`` of quiescence + runs the full
    :func:`regenerate_all_to_filesystem`. On first-success, sets
    the module flag :data:`_CANONICAL_DB_READY` to True (per OQ27).

    Tests: ``debounce_seconds=0`` makes notify-then-await-flush
    deterministic without sleeping; verify via the
    :func:`is_canonical_db_ready` flag.
    """

    def __init__(
        self,
        conn: sqlite3.Connection,
        docs_repo_path: Path,
        *,
        debounce_seconds: float = 1.5,
    ) -> None:
        self._conn = conn
        self._docs_repo_path = docs_repo_path
        self._debounce_seconds = debounce_seconds
        self._notify_event: asyncio.Event | None = None
        self._task: asyncio.Task | None = None
        self._stopped = False

    def notify(self) -> None:
        """Signal that a canonical-DB write happened. Resets the
        debounce timer; the background task wakes after
        ``debounce_seconds`` of quiescence and runs a full sweep.

        Safe to call from any thread that reaches the running event
        loop (the daemon's write-hook context).
        """
        if self._notify_event is not None:
            self._notify_event.set()

    def flush(self) -> dict[str, int]:
        """Run regeneration synchronously and return per-entity
        counts. Used by tests + daemon shutdown to ensure no
        debounce-window work is lost.

        On success, flips :data:`_CANONICAL_DB_READY` to True per
        OQ27.
        """
        counts = regenerate_all_to_filesystem(
            self._conn, self._docs_repo_path,
        )
        if counts:
            _set_canonical_db_ready(True)
        return counts

    async def _run_loop(self) -> None:
        """Background loop. Waits on notify_event, debounces, then
        flushes. Cancellable via :meth:`stop`.
        """
        assert self._notify_event is not None
        while not self._stopped:
            try:
                await self._notify_event.wait()
            except asyncio.CancelledError:
                break
            self._notify_event.clear()
            # Debounce — wait for quiescence. Each new notify()
            # extends the wait.
            while True:
                try:
                    await asyncio.wait_for(
                        self._notify_event.wait(),
                        timeout=self._debounce_seconds,
                    )
                    self._notify_event.clear()
                except asyncio.TimeoutError:
                    break  # quiescent — flush now
                except asyncio.CancelledError:
                    return
            try:
                self.flush()
            except Exception as exc:  # noqa: BLE001
                _log.warning(
                    "regenerator flush failed: %s; will retry on next notify",
                    exc,
                )

    def start(self) -> None:
        """Start the background asyncio task. Must run inside an
        asyncio event loop.
        """
        if self._notify_event is None:
            self._notify_event = asyncio.Event()
        if self._task is None:
            self._task = asyncio.create_task(self._run_loop())

    async def stop(self) -> None:
        """Cancel the background task + final flush.

        Final flush is best-effort: any pending write triggers fire
        synchronously before the task exits, so a daemon shutdown
        doesn't lose the trailing window of work.
        """
        self._stopped = True
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._task = None
        try:
            self.flush()
        except Exception as exc:  # noqa: BLE001
            _log.warning(
                "regenerator final flush on stop failed: %s", exc,
            )
