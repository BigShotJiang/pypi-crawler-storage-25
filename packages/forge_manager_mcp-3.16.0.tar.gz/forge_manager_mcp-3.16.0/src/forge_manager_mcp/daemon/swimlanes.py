"""Swimlane composition for the operator UI (Discussion #24 / Phase 3+).

The UI's swimlane shell (``ui/src/Swimlane.tsx`` + ``SwimlaneStack.tsx``)
consumes a list of typed swimlane records and renders them in stack
order. This module is the canonical-store-facing composer: it walks
the docs filesystem (and, post Cluster A.4, the canonical DB) and
emits the swimlane list.

Phase 3 ships the shape + a focused stub. The current_milestone +
unassigned swimlanes are surfaced with their headline cards; full
per-column composition (issues by milestone, phases by plan, gap
intake, migration step state, release orchestrator state) lands
incrementally in Phases 4-7 of Discussion #24.

The data contract mirrors ``ui/src/swimlane.ts``'s TypeScript
shape one-for-one:

    SwimlaneType: migration / current_milestone / release /
                  unassigned / future_milestone
    CardKind:     issue / milestone / plan / phase /
                  migration_step / feature / gap / release_step
    CardState:    done / in_process / defined /
                  blocked / locked / pending

The composer is a pure function over the project filesystem — no
network IO, no daemon-state mutation. The daemon's HTTP handler
wraps it in a JSONResponse.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


# Stack order per Discussion #24 §"Swimlanes — composition rules":
# 1. Migration (singleton, always-top-when-present)
# 2. Current milestone/plan (active work track)
# 3. Release (singleton, conditional — ready-to-cut)
# 4. Unassigned (orphaned work)
# 5. Future milestones/plans (multi-instance)
STACK_ORDER: tuple[str, ...] = (
    "migration",
    "current_milestone",
    "release",
    "unassigned",
    "future_milestone",
)

SINGLETON_TYPES: frozenset[str] = frozenset({"migration", "release"})


def compose_swimlanes(project_dir: Path | None) -> list[dict[str, Any]]:
    """Compose the operator-visible swimlane list.

    Returns the swimlanes in stack order, with each swimlane carrying
    its 4-column composition (milestone / plan / issues / code). Empty
    columns are present-but-empty arrays — the UI renders a placeholder.

    Stub posture for Phase 3: surfaces the active-milestone headline +
    an always-present empty unassigned lane. Full per-column population
    is Phases 4-7 work.

    Returns ``[]`` when ``project_dir`` is None (pre-bootstrap daemon
    invocation; UI handles the empty state).
    """
    if project_dir is None:
        return []

    lanes: list[dict[str, Any]] = []
    active = _find_active_milestone(project_dir)
    if active is not None:
        lanes.append(_current_milestone_lane(active, project_dir))
    lanes.append(_unassigned_lane(project_dir))
    return _sort_lanes(lanes)


# ---------------------------------------------------------------------------
# Composition helpers — pure functions over the docs filesystem
# ---------------------------------------------------------------------------

def _find_active_milestone(project_dir: Path) -> dict[str, Any] | None:
    """Locate the single ``state=active`` milestone, if any.

    Walks ``<docs>/milestones/<version>/`` directories and returns the
    first one whose ``state.txt`` reads ``active``. The canonical
    invariant (per release.md §State machine) is that **at most one**
    milestone is active at a time; this composer trusts that — the
    first match wins.

    Returns ``None`` when no milestone is active, no docs root is
    resolvable, or no ``milestones/`` directory exists (greenfield
    project pre-D1.a migration).
    """
    from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
    docs_root = resolve_docs_root(project_dir)
    if docs_root is None:
        return None
    ms_root = docs_root / "milestones"
    if not ms_root.is_dir():
        return None
    for entry in sorted(ms_root.iterdir()):
        if not entry.is_dir():
            continue
        state_path = entry / "state.txt"
        if not state_path.is_file():
            continue
        try:
            state = state_path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if state == "active":
            return _read_milestone_meta(entry)
    return None


def _read_milestone_meta(path: Path) -> dict[str, Any]:
    """Read a milestone's headline fields off the filesystem.

    Same shape the ``milestones_endpoint`` returns, scoped to the
    fields the swimlane card needs: version / title / state /
    plan_discussion.
    """
    meta_path = path / "meta.json"
    meta: dict[str, Any] = {}
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            meta = {}
    title_path = path / "title.md"
    title = (
        title_path.read_text(encoding="utf-8").strip()
        if title_path.is_file() else path.name
    )
    state_path = path / "state.txt"
    state = (
        state_path.read_text(encoding="utf-8").strip()
        if state_path.is_file() else "planned"
    )
    return {
        "version": meta.get("version", path.name),
        "title": title,
        "state": state,
        "plan_discussion": meta.get("plan_discussion"),
    }


def _current_milestone_lane(
    milestone: dict[str, Any],
    project_dir: Path | None = None,
) -> dict[str, Any]:
    """Build the ``current_milestone`` swimlane from a milestone dict.

    Milestone column carries the milestone card. Plan column carries
    the plan-Discussion card when ``plan_discussion`` is set. Code
    column (Phase 10) carries phase cards parsed from the plan-
    Discussion body's ``## Phased plan`` section — numbered items
    (``1.``, ``2.``) and ``### Cluster X — name`` headings are
    both recognized. Issues column reserved for plan-side intake
    issues (Phase 11+ work).
    """
    columns: dict[str, list[dict[str, Any]]] = {
        "milestone": [_milestone_card(milestone)],
        "plan": [],
        "issues": [],
        "code": [],
    }
    plan_number = milestone.get("plan_discussion")
    if plan_number:
        columns["plan"].append(_plan_card_stub(plan_number))
        if project_dir is not None:
            columns["code"] = _phase_cards_from_plan(
                project_dir, plan_number,
            )

    return {
        "type": "current_milestone",
        "id": f"current_milestone:{milestone['version']}",
        "title": f"Current — {milestone['version']}: {milestone['title']}",
        "dismissible": False,
        "columns": columns,
    }


def _unassigned_lane(project_dir: Path) -> dict[str, Any]:
    """Build the ``unassigned`` swimlane.

    Populates the ``issues`` column with three card kinds per
    Discussion #24 §"Unassigned swimlane":

    - Issues (visual color A) — open + no-milestone bug/chore/etc.
    - Features (visual color B) — open + no-milestone, ``feature``
      label present.
    - Gaps (visual color C) — gap-detector entries in ``triage`` state.

    Order: issues+features first (newest issue-number descending),
    then gaps (alphabetical by category). UI distinguishes color
    via ``card.kind`` (``issue`` / ``feature`` / ``gap``).

    The lane is always present even when all three card kinds are
    empty so the UI shell can render the always-visible orphan-work
    track.
    """
    issue_feature_cards = _unassigned_issue_cards(project_dir)
    gap_cards = _triage_gap_cards(project_dir)
    return {
        "type": "unassigned",
        "id": "unassigned",
        "title": "Unassigned",
        "dismissible": False,
        "columns": {
            "milestone": [],
            "plan": [],
            "issues": issue_feature_cards + gap_cards,
            "code": [],
        },
    }


def _unassigned_issue_cards(project_dir: Path) -> list[dict[str, Any]]:
    """Walk ``<docs>/issues/<n>/`` and emit cards for open + no-milestone.

    Filter:
    - ``state.txt`` reads ``open``
    - ``meta.json``'s ``milestone`` field is null / absent / empty string

    The ``feature`` label in ``labels.txt`` flips the card kind from
    ``issue`` to ``feature`` (visual color B vs A). All other labels
    surface as card tags.

    Order: numeric issue-number descending (newest first). Skips
    entries whose ``state.txt`` or ``meta.json`` are missing or
    malformed — same tolerance contract as the milestone walker.
    """
    from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
    docs_root = resolve_docs_root(project_dir)
    if docs_root is None:
        return []
    issues_root = docs_root / "issues"
    if not issues_root.is_dir():
        return []
    cards: list[dict[str, Any]] = []
    for entry in issues_root.iterdir():
        if not entry.is_dir():
            continue
        try:
            number = int(entry.name)
        except ValueError:
            continue
        state_path = entry / "state.txt"
        if not state_path.is_file():
            continue
        try:
            state = state_path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if state != "open":
            continue
        meta_path = entry / "meta.json"
        meta: dict[str, Any] = {}
        if meta_path.is_file():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                meta = {}
        milestone = meta.get("milestone")
        if milestone:  # truthy: skip (assigned to a milestone)
            continue
        cards.append(_issue_card(entry, number))
    # Numeric descending so newest issues lead the lane.
    cards.sort(key=lambda c: int(c["number"]), reverse=True)
    return cards


def _issue_card(path: Path, number: int) -> dict[str, Any]:
    """Build an issue card from a ``<docs>/issues/<n>/`` directory.

    Card kind is ``feature`` when ``labels.txt`` contains the
    ``feature`` label on its own line; otherwise ``issue``. All
    labels surface as card tags.
    """
    title_path = path / "title.md"
    title = (
        title_path.read_text(encoding="utf-8").strip()
        if title_path.is_file() else f"#{number}"
    )
    labels: list[str] = []
    labels_path = path / "labels.txt"
    if labels_path.is_file():
        try:
            raw = labels_path.read_text(encoding="utf-8")
            labels = [line.strip() for line in raw.splitlines() if line.strip()]
        except OSError:
            labels = []
    kind = "feature" if "feature" in labels else "issue"
    return {
        "id": f"{kind}:#{number}",
        "kind": kind,
        "number": str(number),
        "title": title,
        "state": "defined",
        "tags": labels,
        "metrics": {},
        "last_action": None,
        "affordance": None,
        "decision_of_record": None,
    }


def _triage_gap_cards(project_dir: Path) -> list[dict[str, Any]]:
    """Walk ``<docs>/gaps/<category>/`` and emit cards for triage-state.

    The canonical gap layout is category-keyed (not number-keyed) —
    each entry's ``state.txt`` carries one of ``triage`` / ``accepted``
    / ``ignored`` / ``filed_as_issue``. Phase 5 surfaces only
    ``triage`` entries (the operator-actionable bucket per the gap
    state machine).

    Returns ``[]`` when no docs root is resolvable or no ``gaps/``
    directory exists. Skips entries whose ``state.txt`` is missing
    or malformed.
    """
    from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
    docs_root = resolve_docs_root(project_dir)
    if docs_root is None:
        return []
    gaps_root = docs_root / "gaps"
    if not gaps_root.is_dir():
        return []
    cards: list[dict[str, Any]] = []
    for entry in sorted(gaps_root.iterdir()):
        if not entry.is_dir():
            continue
        state_path = entry / "state.txt"
        if not state_path.is_file():
            continue
        try:
            state = state_path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if state != "triage":
            continue
        cards.append(_gap_card(entry))
    return cards


def _gap_card(path: Path) -> dict[str, Any]:
    """Build a gap card from a ``<docs>/gaps/<category>/`` directory.

    Title comes from ``title.md`` (the detector_category name).
    Severity + finding_count from ``meta.json`` surface as metrics.
    """
    category = path.name
    title_path = path / "title.md"
    title = (
        title_path.read_text(encoding="utf-8").strip()
        if title_path.is_file() else category
    )
    meta: dict[str, Any] = {}
    meta_path = path / "meta.json"
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            meta = {}
    metrics: dict[str, str | int] = {}
    finding_count = meta.get("finding_count")
    if isinstance(finding_count, int):
        metrics["findings"] = finding_count
    severity = meta.get("severity")
    if isinstance(severity, str):
        metrics["severity"] = severity
    tier = meta.get("tier")
    if isinstance(tier, str):
        metrics["tier"] = tier
    return {
        "id": f"gap:{category}",
        "kind": "gap",
        "number": None,
        "title": title,
        "state": "pending",
        "tags": ["gap"],
        "metrics": metrics,
        "last_action": None,
        "affordance": "Triage",
        "decision_of_record": None,
    }


def _milestone_card(milestone: dict[str, Any]) -> dict[str, Any]:
    """Map a milestone dict to a swimlane card record.

    State machine per Discussion #24 §"State machines per entity type":
    ``future`` → ``current`` (in_process) → ``completed``. Active
    milestone surfaces as ``in_process``.
    """
    state_map = {
        "active": "in_process",
        "planned": "defined",
        "completed": "done",
        "released": "done",
    }
    return {
        "id": f"milestone:{milestone['version']}",
        "kind": "milestone",
        "number": milestone["version"],
        "title": milestone["title"],
        "state": state_map.get(milestone["state"], "pending"),
        "tags": [],
        "metrics": {},
        "last_action": None,
        "affordance": None,
        "decision_of_record": None,
    }


def _plan_card_stub(plan_number: int | str) -> dict[str, Any]:
    """Minimal plan-Discussion card for Phase 3.

    Full plan-card composition (OQs-left count, ▶ play affordance when
    defined) is Phase 4 work — for now the card carries the number +
    a generic title; the UI renders what it gets.
    """
    return {
        "id": f"plan:{plan_number}",
        "kind": "plan",
        "number": str(plan_number),
        "title": f"Plan Discussion #{plan_number}",
        "state": "in_process",
        "tags": [],
        "metrics": {},
        "last_action": None,
        "affordance": None,
        "decision_of_record": None,
    }


def _phase_cards_from_plan(
    project_dir: Path,
    plan_number: int | str,
) -> list[dict[str, Any]]:
    """Parse the plan-Discussion's phased-plan section into phase cards.

    Reads ``<docs>/discussions/<plan_number>/body.md`` and looks for
    a section heading starting with ``## Phased plan`` (matches both
    ``## Phased plan (rough)`` and ``## Phased plan — N clusters``).
    Within that section parses two patterns:

    - Numbered list items: ``1. **Foundation** — ...`` →
      one phase per line. Card title is the line text minus the
      ``N.`` prefix; ``id`` is ``phase:<plan>:<n>``.
    - Cluster headings: ``### Cluster X — name`` →
      one phase per heading. Card title is the heading text minus
      the ``###`` prefix; ``id`` is ``phase:<plan>:cluster_<X>``.

    Parsing stops at the next ``##`` heading. Cards emitted in
    document order (top-to-bottom). All cards default to state
    ``pending`` — state derivation from canonical-store data
    (e.g. ``shadow.code_complete_facts``) is future work.

    Returns ``[]`` when the body is missing, the section is absent,
    or no recognized phase patterns appear.
    """
    from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
    docs_root = resolve_docs_root(project_dir)
    if docs_root is None:
        return []
    body_path = (
        docs_root / "discussions" / str(plan_number) / "body.md"
    )
    if not body_path.is_file():
        return []
    try:
        body = body_path.read_text(encoding="utf-8")
    except OSError:
        return []
    return _parse_phases(body, str(plan_number))


_PHASE_SECTION_RE = re.compile(
    r"^## Phased plan\b.*$", re.MULTILINE,
)
_NUMBERED_RE = re.compile(r"^(\d+)\.\s+(.+)$")
_CLUSTER_RE = re.compile(r"^### Cluster\s+(\S+)\s*(?:—|-)?\s*(.*)$")
_SECTION_END_RE = re.compile(r"^##\s")


def _parse_phases(body: str, plan_id: str) -> list[dict[str, Any]]:
    """Pure parser: body text → list of phase-card dicts.

    Exposed for testing — the filesystem wrapper above is one-step
    away.

    (3.16.0 D1) Tree-indented sub-phases: leading whitespace on a
    numbered-list line is interpreted as nesting depth. Heuristic:
    ``depth = leading_whitespace_chars // 2`` so 2-space, 3-space,
    and 4-space markdown indent conventions all map to depth 1.
    Tabs count as 1 char (treated as half an indent); 2-tab indent
    works out to depth 1 too. Sub-phase cards carry ``parent_id``
    pointing at the most-recent ancestor at depth ``depth - 1``;
    orphaned sub-items (no preceding parent) fall through to
    ``parent_id=None`` and behave as top-level phases.

    Cluster headings (``### Cluster X``) stay at depth 0 always —
    the heading prefix anchors to column 0 by markdown convention.
    """
    match = _PHASE_SECTION_RE.search(body)
    if match is None:
        return []
    start = match.end()
    rest = body[start:]
    cards: list[dict[str, Any]] = []
    # Stack of most-recent card id at each depth — for parent_id
    # resolution. Cleared at depths >= current_depth when a new
    # parent at lower depth appears, so sibling at the same depth
    # doesn't become a child of the prior sibling's last child.
    parents_at_depth: dict[int, str] = {}
    for line in rest.splitlines():
        if _SECTION_END_RE.match(line):
            break
        stripped = line.strip()
        if not stripped:
            continue
        # Compute depth from leading whitespace on the original
        # (un-stripped) line. Per the heuristic in the docstring:
        # 2-char indent = depth 1, 4-char = depth 2, etc.
        leading_ws = len(line) - len(line.lstrip())
        depth = leading_ws // 2
        m_num = _NUMBERED_RE.match(stripped)
        if m_num is not None:
            n = m_num.group(1)
            title = _clean_phase_title(m_num.group(2))
            parent_id = parents_at_depth.get(depth - 1) if depth > 0 else None
            card = _phase_card(
                plan_id, n, title,
                parent_id=parent_id, depth=depth,
            )
            cards.append(card)
            parents_at_depth[depth] = card["id"]
            # Clear deeper levels so a sibling at this depth doesn't
            # accidentally become a child of a prior sibling's leaf.
            for d in list(parents_at_depth):
                if d > depth:
                    del parents_at_depth[d]
            continue
        m_cluster = _CLUSTER_RE.match(stripped)
        if m_cluster is not None:
            letter = m_cluster.group(1).strip().lower()
            name = m_cluster.group(2).strip() or f"Cluster {letter.upper()}"
            # Cluster headings anchor to depth 0 by markdown
            # convention — ``###`` always at column 0.
            card = _phase_card(
                plan_id, f"cluster_{letter}",
                f"Cluster {letter.upper()} — {name}",
                parent_id=None, depth=0,
            )
            cards.append(card)
            parents_at_depth[0] = card["id"]
            # Clear deeper levels — a new cluster heading resets
            # the nesting context.
            for d in list(parents_at_depth):
                if d > 0:
                    del parents_at_depth[d]
            continue
    return cards


def _clean_phase_title(raw: str) -> str:
    """Strip leading ``**Bold**`` formatting from a phase title.

    The plan-Discussion convention is ``N. **<short name>** — <details>``.
    For card display we keep the whole line minus the bold markers so
    operators see both the short name + the description.
    """
    return raw.replace("**", "").strip()


def _phase_card(
    plan_id: str, index: str, title: str,
    *,
    parent_id: str | None = None,
    depth: int = 0,
) -> dict[str, Any]:
    """Build a phase card record.

    Per Discussion #24 §"State machines per entity type":
    Phase cards default to ``pending`` (◯). State transitions to
    ``in_process`` (⟳) when work starts, ``done`` (✓) when complete.
    Today the state is derived from nothing — Phase 10 ships the
    structural shape; state-tracking integration is future work.

    (3.16.0 D1) ``parent_id`` + ``depth`` carry tree-indent
    structure for the phase column. ``parent_id`` is the id of the
    immediate ancestor phase card (or None for top-level). ``depth``
    is the nesting depth (0 = top-level, 1+ = sub-phases under a
    parent). UI consumers render the indent at each level; phase
    cards with the same parent_id form a sibling group.
    """
    return {
        "id": f"phase:{plan_id}:{index}",
        "kind": "phase",
        "number": index,
        "title": title,
        "state": "pending",
        "tags": [],
        "metrics": {},
        "last_action": None,
        "affordance": None,
        "decision_of_record": None,
        "parent_id": parent_id,
        "depth": depth,
    }


def _sort_lanes(lanes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Order swimlanes per STACK_ORDER; preserve within-type order.

    Mirrors ``ui/src/swimlane.ts::sortSwimlanes`` — same comparator
    semantics so daemon-emitted ordering matches the UI's expected
    stack.
    """
    order = {t: i for i, t in enumerate(STACK_ORDER)}
    return sorted(
        lanes,
        key=lambda lane: order.get(lane["type"], len(STACK_ORDER)),
    )
