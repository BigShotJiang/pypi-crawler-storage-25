"""SSE channel skeleton (Phase D3b.2 / 3.5.0).

Minimal event-source plumbing that D3b.4+ wires concrete event
publishers into. The skeleton:

- Exposes a ``GET /events`` route that returns ``text/event-stream``
- Maintains an in-memory broadcast queue (asyncio-friendly
  ``EventBroadcaster``)
- Each connected client gets its own iterator over the broadcaster's
  fan-out queue; disconnect cleans up the queue subscription

D3b.4+ wires concrete events:

- ``backend.status_changed`` — ReplicationManager state transitions
  (HEALTHY ↔ DEGRADED ↔ RECONCILING)
- ``write.completed`` — every successful canonical write
  (operation_name + ref + delta)
- ``backfill.progress`` — import_remote_changes progress (#296 OQ4)

For D3b.2 the broadcaster is constructed but the event-source's
output is just a startup ``hello`` event + heartbeats on a
configurable interval. This validates the wiring + tests.

**Per Effects + Async parity (code-design.md):**

- ``EventBroadcaster`` is the effect-bearing class — manages the
  asyncio queue lifecycle.
- ``make_event_stream(broadcaster)`` returns an async-iterator
  factory (pure of the broadcaster's state shape).
- Tests stub the broadcaster with a frozen list of events so the
  output stream is deterministic.
"""
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import cache
from typing import AsyncIterator


HEARTBEAT_INTERVAL_SECONDS = 15.0
"""SSE heartbeat cadence. Long enough that an idle daemon doesn't
flood the channel; short enough that proxies don't time out the
connection (most reverse proxies idle-disconnect at 30-60s)."""


@cache
def _event_class() -> type:
    """Cached frozen-dataclass shape for emitted events. Per
    Schema-as-data Rule 5 the class definition lives inside a
    cached function, not at module level."""
    @dataclass(frozen=True)
    class Event:
        event: str          # SSE event-type field, e.g. "backend.status_changed"
        data: dict          # JSON-serializable payload
        timestamp: datetime
    return Event


def make_event(*, event: str, data: dict, timestamp: datetime | None = None):
    """Factory for Event values. Per Rule 5 the dataclass class
    lives inside the cached helper, not at module level.
    """
    if not event:
        raise ValueError("event must be non-empty")
    if timestamp is None:
        timestamp = datetime.now(timezone.utc)
    Event = _event_class()
    return Event(event=event, data=data, timestamp=timestamp)


def serialize_sse(evt) -> str:
    """Serialize an Event into the SSE wire format.

    Format per https://html.spec.whatwg.org/multipage/server-sent-events.html:

        event: <event-name>
        data: <json-payload>

    Trailing blank line marks the end of a message. ``timestamp``
    is encoded into the ``data`` payload as an ISO-8601 string.
    """
    payload = dict(evt.data)
    payload["timestamp"] = evt.timestamp.isoformat()
    return f"event: {evt.event}\ndata: {json.dumps(payload)}\n\n"


def publish_alert(broadcaster, alert_log, alert) -> None:
    """(#341) Dual-publish an Alert: append to the retained log
    AND emit a live SSE event for any open UI subscribers.

    The wire-format for the SSE event matches the alert's dict
    serialization (per ``alert_to_dict``) so subscribers can use
    the same shape for live + replay paths. Event name is
    ``alert.<level>`` so SSE clients can filter by severity at the
    EventSource layer.

    Effect — log append + broadcaster fan-out. Both are synchronous
    + non-blocking; safe to call from inside ``_set_state`` or
    request handlers.
    """
    from forge_manager_mcp.daemon.alerts import alert_to_dict
    alert_log.record(alert)
    broadcaster.publish(make_event(
        event=f"alert.{alert.level}",
        data=alert_to_dict(alert),
    ))


class EventBroadcaster:
    """In-memory pub/sub for SSE events.

    One instance per daemon process; constructed at app-build time
    and shared across all subscribers. Thread-safe within a single
    asyncio event loop (the daemon's runtime).

    Subscribers get their own ``asyncio.Queue`` populated by
    ``publish``. ``unsubscribe`` removes the queue from the fan-
    out set. Per D3b.4+ wiring: the daemon publishes events from
    its reconciliation loop / write-completion hooks; the SSE
    handler subscribes per-client and streams.
    """

    def __init__(self):
        self._subscribers: list[asyncio.Queue] = []

    def subscribe(self, *, maxsize: int = 100) -> asyncio.Queue:
        """Create a per-client queue. Bounded so a slow client
        can't accumulate unbounded memory; overflow drops oldest."""
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        """Remove a subscriber's queue. Idempotent on already-
        removed queues."""
        try:
            self._subscribers.remove(q)
        except ValueError:
            pass

    def publish(self, evt) -> None:
        """Fan out an event to every subscribed queue. Slow
        subscribers' queues fill; on overflow the oldest event is
        dropped (FIFO drop) so the publish path stays non-blocking.
        """
        dead: list[asyncio.Queue] = []
        for q in self._subscribers:
            try:
                q.put_nowait(evt)
            except asyncio.QueueFull:
                # Drop the oldest event to make room.
                try:
                    q.get_nowait()
                    q.put_nowait(evt)
                except (asyncio.QueueEmpty, asyncio.QueueFull):
                    # Race with another writer; mark dead and move on.
                    dead.append(q)
        for q in dead:
            self.unsubscribe(q)

    def subscriber_count(self) -> int:
        """Diagnostic — used by /events handler logging + tests."""
        return len(self._subscribers)


async def stream_events(
    broadcaster: EventBroadcaster,
    *,
    heartbeat_interval: float = HEARTBEAT_INTERVAL_SECONDS,
) -> AsyncIterator[str]:
    """Async iterator yielding SSE-formatted strings for one
    subscriber. The handler awaits this iterator's items and
    writes them to the response stream.

    Lifecycle:
      - Subscribe to the broadcaster (acquire a queue)
      - Yield a startup ``hello`` event
      - Loop: yield events from the queue, or a heartbeat after
        ``heartbeat_interval`` of silence
      - On disconnect (caller stops iterating), unsubscribe

    The unsubscribe runs in a finally clause so it fires even
    if the consumer crashes or disconnects mid-stream.
    """
    queue = broadcaster.subscribe()
    try:
        # Startup event so the client knows the channel is open.
        yield serialize_sse(make_event(
            event="hello",
            data={"channel": "events"},
        ))

        while True:
            try:
                evt = await asyncio.wait_for(
                    queue.get(), timeout=heartbeat_interval,
                )
                yield serialize_sse(evt)
            except asyncio.TimeoutError:
                # Heartbeat to keep the connection alive.
                yield serialize_sse(make_event(
                    event="heartbeat",
                    data={},
                ))
    finally:
        broadcaster.unsubscribe(queue)


# Re-export the constructed event class for type hints.
Event = _event_class()
