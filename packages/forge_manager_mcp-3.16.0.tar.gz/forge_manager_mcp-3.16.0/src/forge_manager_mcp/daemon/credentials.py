"""Encrypted credentials store for the daemon (Phase D3b.4e / #331).

The daemon owns backend tokens at rest in
``<state-dir>/credentials.enc`` (Fernet-encrypted JSON,
``{platform_id: token, ...}``). The decrypted tokens populate
``os.environ`` before ``_build_daemon_replication`` runs, so the
existing ``config.get_platform_token`` dispatcher reads daemon-
managed tokens transparently — no adapter-side change needed.

**Why daemon-owned, not env-only.** The daemon already owns
forge-config.json (D3b.3), backend health (D3b.4), and pause/resume
actions (D3b.4c). Splitting where config-fields-that-aren't-tokens
are daemon-owned but tokens are env-var-owned is incoherent. Tokens
ARE backend config. (Also addresses the `git remote -v` token-leak
hygiene gap — operators stop needing token-in-URL once daemon-
managed credentials work.)

**Threat model.** The Fernet key file (``credentials.key``, 0o400)
and the ciphertext file (``credentials.enc``, 0o600) live side-by-
side in the per-project state-dir. An attacker with filesystem
access to BOTH files gets the tokens — same threat-floor as
plaintext env vars at rest. What this resists: backup/dotfile-sync
that captures the data file but misses the key (key's stricter
mode + smaller filename surface helps), screen-share / shell-
history exposure (tokens never reach a URL form once captured),
off-machine theft (key is per-machine; ciphertext alone won't
decrypt elsewhere). Not in scope: privileged on-machine attack,
live process-memory capture, malicious credential helpers.

**Code-design.** ``Credentials`` follows Rule 5 (schema-as-data
factory: cached dataclass class lives inside the helper, not at
module level). The IO/encryption functions are effects (Rule 2);
``init_from_env`` and ``populate_environ_from_credentials`` are
the orchestrators that combine them.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import cache
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken


CREDENTIALS_FILENAME = "credentials.enc"
KEY_FILENAME = "credentials.key"
"""Per-state-dir filenames. Stable so the migrate_to_3_5 tool
(#332) can locate them deterministically."""

_PLATFORM_ENV_VAR: dict[str, str] = {
    "github": "GITHUB_TOKEN",
    "forgejo": "FORGEJO_TOKEN",
    "forgejo-self": "FORGEJO_TOKEN",
    "codeberg": "CODEBERG_TOKEN",
    "gitlab": "GITLAB_TOKEN",
}
"""First-position env var per platform — matches the head of each
platform's discovery chain in ``config._PLATFORM_TOKEN_SOURCES``.
The daemon writes here so ``get_platform_token`` finds the token
on its normal env-var lookup pass."""


def env_var_for(platform_id: str) -> str | None:
    """Canonical env-var name for a platform's token.

    Returns None for platforms with no remote auth (``local``) or
    unknown ids — callers skip those.
    """
    return _PLATFORM_ENV_VAR.get(platform_id)


class CredentialsError(RuntimeError):
    """Raised on decrypt failure / corrupted ciphertext / missing
    key. Daemon main.py catches and falls through to env-var path
    so the daemon stays useful."""


# --- Schema-as-data: Credentials value type (Rule 5 factory) ---------------


@cache
def _credentials_class() -> type:
    @dataclass(frozen=True)
    class Credentials:
        """Decrypted credentials snapshot.

        ``tokens`` is a frozen mapping (platform_id → token). Empty
        when ``credentials.enc`` is absent or empty. The dataclass
        is frozen so a daemon doesn't accidentally mutate the
        snapshot it loaded at startup.
        """
        tokens: dict[str, str]
    return Credentials


def make_credentials(*, tokens: dict[str, str]):
    """Factory for Credentials values."""
    Cls = _credentials_class()
    return Cls(tokens=dict(tokens))


# --- Key management --------------------------------------------------------


def _key_path(state_dir: Path) -> Path:
    return state_dir / KEY_FILENAME


def _credentials_path(state_dir: Path) -> Path:
    return state_dir / CREDENTIALS_FILENAME


def _load_or_generate_key(state_dir: Path) -> bytes:
    """Read the Fernet key, or generate + persist a fresh one.

    Returns the urlsafe-base64-encoded key bytes (Fernet's native
    format). The key file is written with 0o400 perms so it is
    read-only even to the owner — accidental ``cat`` doesn't expose
    it via shell-history quite as easily, and `cp -p` preserves
    perms across backup tools.

    Effect — file IO. Idempotent: subsequent calls read the same
    key; only the first call generates.
    """
    kp = _key_path(state_dir)
    if kp.exists():
        return kp.read_bytes().strip()
    key = Fernet.generate_key()
    state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    kp.write_bytes(key)
    kp.chmod(0o400)
    return key


# --- Load / save effects ---------------------------------------------------


def load_credentials(state_dir: Path):
    """Read + decrypt the credentials file. Returns Credentials or None.

    None when the ciphertext file is absent (first-run / no
    credentials configured). Raises CredentialsError on a decrypt
    failure (corrupted ciphertext, key/data mismatch, malformed
    JSON) so the daemon distinguishes "no credentials" from
    "credentials are broken" and can log the latter.

    Effect — file IO + decryption.
    """
    cp = _credentials_path(state_dir)
    if not cp.exists():
        return None
    key = _load_or_generate_key(state_dir)
    try:
        ciphertext = cp.read_bytes()
        plaintext = Fernet(key).decrypt(ciphertext)
        payload = json.loads(plaintext.decode("utf-8"))
    except InvalidToken as exc:
        raise CredentialsError(
            f"failed to decrypt {CREDENTIALS_FILENAME}: invalid token "
            "(key/data mismatch?)"
        ) from exc
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise CredentialsError(
            f"failed to parse decrypted {CREDENTIALS_FILENAME}: {exc}"
        ) from exc
    if not isinstance(payload, dict):
        raise CredentialsError(
            f"{CREDENTIALS_FILENAME} payload is not a JSON object"
        )
    # Coerce values to str — JSON allows other types but tokens must be
    # strings. Reject non-str so we fail early instead of letting a
    # bad value flow into os.environ.
    for k, v in payload.items():
        if not isinstance(v, str):
            raise CredentialsError(
                f"token for platform {k!r} is not a string"
            )
    return make_credentials(tokens=payload)


def save_credentials(state_dir: Path, tokens: dict[str, str]) -> None:
    """Encrypt + atomic-replace write to credentials.enc.

    Atomic via ``tmp + os.replace`` so a crash mid-write doesn't
    leave a half-written file the next load can't decrypt.

    Effect — file IO + encryption.
    """
    state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    key = _load_or_generate_key(state_dir)
    ciphertext = Fernet(key).encrypt(
        json.dumps(tokens, sort_keys=True).encode("utf-8"),
    )
    cp = _credentials_path(state_dir)
    tmp = cp.with_suffix(cp.suffix + ".tmp")
    tmp.write_bytes(ciphertext)
    tmp.chmod(0o600)
    os.replace(tmp, cp)


# --- Per-platform CRUD (#313 cap 3 / 3.7.0 D6) -----------------------------


def set_credential(
    state_dir: Path, platform_id: str, token: str,
) -> None:
    """Write or update one platform's token in the encrypted store.

    Loads the existing store (or starts fresh when absent / corrupt),
    sets ``platform_id → token``, atomic-writes back. Empty token
    string is rejected — the operator should call
    ``delete_credential`` to remove an entry rather than store an
    empty value (which would silently fall through the dispatcher's
    ``.strip()`` check).
    """
    if not token or not token.strip():
        raise CredentialsError(
            "token must be non-empty; use delete_credential to remove",
        )
    try:
        creds = load_credentials(state_dir)
        tokens = dict(creds.tokens) if creds is not None else {}
    except CredentialsError:
        # Corrupt store — start fresh. Same posture as init_from_env.
        tokens = {}
    tokens[platform_id] = token
    save_credentials(state_dir, tokens)


def delete_credential(state_dir: Path, platform_id: str) -> bool:
    """Remove one platform's token from the encrypted store.

    Returns True when the platform's token was present and removed,
    False when it was absent (no-op). Atomic-writes the trimmed
    map back.
    """
    try:
        creds = load_credentials(state_dir)
    except CredentialsError:
        return False
    if creds is None:
        return False
    tokens = dict(creds.tokens)
    if platform_id not in tokens:
        return False
    tokens.pop(platform_id)
    save_credentials(state_dir, tokens)
    return True


# --- Orchestrators ---------------------------------------------------------


def init_from_env(
    state_dir: Path, platform_ids: list[str],
) -> "list[str]":
    """Capture tokens from env vars + persist to encrypted store.

    Returns the list of platform ids that were captured (i.e., had a
    non-empty env var). Platforms with no env var set, or no env
    var at all (``local``), are silently skipped — first-run
    bootstrap is best-effort.

    Idempotent at the file level: re-running with the same env
    state writes the same ciphertext. Re-running with different
    env state OVERWRITES — this is intentional for the migration-
    tool flow where the operator updates env vars between runs.
    """
    captured: dict[str, str] = {}
    for pid in platform_ids:
        var = env_var_for(pid)
        if var is None:
            continue
        token = os.environ.get(var, "").strip()
        if token:
            captured[pid] = token
    if captured:
        save_credentials(state_dir, captured)
    return sorted(captured.keys())


def populate_environ_from_credentials(creds) -> "list[str]":
    """Write each captured token into ``os.environ`` under its
    canonical env-var name.

    Returns the list of platforms whose env var was populated. Does
    NOT overwrite already-set env vars — explicit env wins over
    daemon-managed credentials so operators can still override
    per-process for debugging without rewriting the encrypted store.

    Effect — env-var mutation. Called once at daemon startup before
    ``_build_daemon_replication``.
    """
    populated: list[str] = []
    for pid, token in creds.tokens.items():
        var = env_var_for(pid)
        if var is None:
            continue
        if os.environ.get(var, "").strip():
            continue  # explicit env already set; don't overwrite
        os.environ[var] = token
        populated.append(pid)
    return sorted(populated)


# --- Operator status (no token reveal) -------------------------------------


def credential_status(
    state_dir: Path, platform_ids: list[str],
) -> "list[dict]":
    """Per-platform diagnostics. Never returns the token itself.

    Each entry: ``{platform_id, has_credential, source}`` where
    ``source`` is one of:
      * ``"encrypted_store"`` — token loaded from credentials.enc
      * ``"env"`` — token present only in os.environ (encrypted
        store has no entry)
      * ``"missing"`` — no token from either source
      * ``"error"`` — credentials file present but failed to decrypt

    Effect — file read + env read. Used by the GET /credentials
    endpoint; safe to surface to the operator UI.
    """
    try:
        creds = load_credentials(state_dir)
    except CredentialsError:
        # Surface decrypt failure as ``error`` for every platform
        # the operator's config declares — they need to know the
        # store is broken even though the daemon kept running on
        # env vars.
        return [
            {"platform_id": pid, "has_credential": False, "source": "error"}
            for pid in platform_ids
        ]
    out: list[dict] = []
    for pid in platform_ids:
        in_store = bool(creds and pid in creds.tokens and creds.tokens[pid])
        var = env_var_for(pid)
        in_env = bool(var and os.environ.get(var, "").strip())
        if in_store:
            source = "encrypted_store"
        elif in_env:
            source = "env"
        else:
            source = "missing"
        out.append({
            "platform_id": pid,
            "has_credential": in_store or in_env,
            "source": source,
        })
    return out
