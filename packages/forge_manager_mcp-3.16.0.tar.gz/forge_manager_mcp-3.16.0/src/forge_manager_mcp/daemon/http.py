"""Daemon HTTP application (Phase D3a / 3.5.0).

Starlette app exposing the foundation endpoints:

- ``GET /health`` — version, uptime, PID. Used by the MCP daemon-
  client to verify the discovered daemon is alive + the right
  version.

D3b adds the rest of the endpoint surface (``GET /config``,
``POST /writes/{op}``, ``GET /pending``, ``WS /events``) per the
parent RFC #5 §To the MCP server.

**Auth model.** Every endpoint except ``/health`` requires
``Authorization: Bearer <auth_token>`` matching the token written
to the discovery file at startup. ``/health`` is auth-free so the
MCP can probe a daemon's liveness before reading the discovery
file's auth_token (e.g., to detect a stale-PID daemon owned by
another tenant). This is the localhost-only contract described in
parent RFC #5 §To external tools.

**Per Effects + Async parity (code-design.md):** the request
handlers are async (starlette's contract); the underlying state
(start time, version, etc.) is captured at construction and read
without IO. Pure-function payload composition; only the wrapping
``Request → Response`` IO happens via starlette.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from forge_manager_mcp.daemon.auth import BearerTokenMiddleware
from forge_manager_mcp.daemon.events import (
    EventBroadcaster,
    make_event,
    stream_events,
)


_MAX_FILE_BYTES = 1_048_576
"""1 MiB cap on /files/content responses. Larger files require an
operator workflow (e.g. download via the canonical store directly);
the JSON-API surface targets human-readable text files."""


# #343: path-resolution + IO effects extracted to daemon/effects/.
# Re-exported here for any external callers that imported the
# legacy name; new code calls effects/files.py directly.
def _resolve_files_path(replication, rel: str):
    from forge_manager_mcp.daemon.effects.files import resolve_path
    target, err = resolve_path(replication, rel)
    if err is None:
        return target, None
    # Pre-#343 callers used a single (path, error_msg) tuple where
    # error_msg was a string. Map (status_code, msg) → msg for
    # back-compat. Tests covering the legacy shape stay green.
    return None, err[1]


# Phase D-UI / 3.5.0. The daemon serves the SolidJS app shell from
# ``ui/dist/`` when present. Resolution order:
#   1. ``$FORGE_MANAGER_UI_DIST`` env var (operator override)
#   2. ``<package-root>/ui_dist/`` (installed-wheel layout — D-UI.3
#      Bazel-hermetic build will populate this in the wheel)
#   3. ``<repo-root>/ui/dist/`` (dev-tree layout — operator runs
#      ``cd ui && pnpm build`` to populate this)
# Returns None if no dist tree is found; the daemon then serves
# only ``/health`` + future API routes without a UI.
def resolve_ui_dist() -> Path | None:
    """Resolve the UI dist directory, or None if not present."""
    override = os.environ.get("FORGE_MANAGER_UI_DIST")
    if override:
        path = Path(override)
        if path.is_dir() and (path / "index.html").is_file():
            return path
        return None

    # Installed-wheel layout (D-UI.3 will produce this).
    package_root = Path(__file__).resolve().parent.parent
    in_package = package_root / "ui_dist"
    if in_package.is_dir() and (in_package / "index.html").is_file():
        return in_package

    # Dev-tree layout: from src/forge_manager_mcp/daemon/http.py walk
    # up to mcp-server/ (3 levels: daemon/ → forge_manager_mcp/ →
    # src/ → mcp-server/) and look at ui/dist/. (D7.1 / 3.6.0:
    # ui/ moved from repo-root to mcp-server/ui/ so it lives inside
    # the Bazel workspace.)
    mcp_server_root = package_root.parent.parent
    in_repo = mcp_server_root / "ui" / "dist"
    if in_repo.is_dir() and (in_repo / "index.html").is_file():
        return in_repo

    return None


def _innermost_cause(exc: BaseException) -> BaseException:
    """Walk an exception chain to the innermost original cause.

    Handles two chain shapes:
      * ``ReplicationWriteError`` carries an explicit ``.cause``
        attribute (replication/errors.py:38-51).
      * Standard Python ``raise X from Y`` chains expose ``__cause__``.

    Returns the deepest cause; falls back to ``exc`` itself when the
    chain is one-deep. Used by the daemon http error path (#513,
    3.16.0 D0) so structured shape (``status_code``, ``body``) from
    e.g. ``GitHubError(403, body=...)`` survives across the
    daemon→MCP JSON boundary.
    """
    cur: BaseException = exc
    seen: set[int] = set()
    while True:
        next_exc: BaseException | None = None
        cause_attr = getattr(cur, "cause", None)
        if isinstance(cause_attr, BaseException):
            next_exc = cause_attr
        elif cur.__cause__ is not None:
            next_exc = cur.__cause__
        if next_exc is None or id(next_exc) in seen:
            return cur
        seen.add(id(cur))
        cur = next_exc


def _build_op_error_envelope(exc: BaseException, op_name: str) -> dict:
    """(#513, 3.16.0 D0) Build the JSON error envelope returned by
    ``post_write`` / ``post_read`` on handler-exception. Walks the
    exception chain via ``_innermost_cause`` to surface structured
    shape (``status_code`` + ``body``) from the original adapter-
    level exception so the MCP-side ``is_permanent_error`` predicate
    can classify the failure correctly.

    Also pre-classifies daemon-side via ``is_permanent_error`` and
    surfaces ``is_permanent`` so the MCP-side dispatch wrapper can
    skip the buffer-write path without re-running classification on
    a potentially-lost exception shape.

    Pre-#513 the envelope was ``{error, error_type, op}`` only; the
    status_code + body attrs from GitHubError / ForgeError instances
    were dropped, so a suspended-account 403 from a project-board
    attach (or any other adapter-level call) buffered to
    ``.claude/pending-posts.md`` for infinite retry instead of
    surfacing as a clean ``OperationError`` envelope.
    """
    from forge_manager_mcp.adapters.errors import is_permanent_error
    cause = _innermost_cause(exc)
    status_code = getattr(cause, "status_code", None)
    body = getattr(cause, "body", None)
    envelope: dict = {
        "error": str(exc),
        "error_type": type(exc).__name__,
        "op": op_name,
        "cause_type": type(cause).__name__ if cause is not exc else None,
        "cause_message": str(cause) if cause is not exc else None,
        "status_code": status_code,
        "body": body if isinstance(body, (str, dict, list, type(None))) else str(body),
        "is_permanent": is_permanent_error(cause),
    }
    return envelope


def make_app(
    *,
    version: str,
    auth_token: str,
    started_at: datetime | None = None,
    ui_dist: Path | None = None,
    broadcaster: EventBroadcaster | None = None,
    config_payload: dict | None = None,
    config_load_error: str | None = None,
    replication=None,
    state_dir: Path | None = None,
    platform_ids: list[str] | None = None,
    alert_log=None,
    action_log_con=None,
    mode_transitions_log=None,
    project_dir: Path | None = None,
) -> Starlette:
    """Construct the daemon's HTTP application.

    Pure factory — captures the version + auth_token + start time
    in the route closures; no module-level state. Each call returns
    a fresh Starlette instance, so tests can construct multiple
    independent apps without interference.

    ``started_at`` defaults to ``datetime.now(timezone.utc)`` when
    omitted. Tests pass an explicit value to make uptime
    deterministic.

    ``ui_dist`` is the explicit dist-tree path. When None, the
    daemon serves only ``/health`` + future API routes — the
    factory does NOT auto-resolve. Auto-resolution happens in
    ``daemon/main.py`` so tests get a deterministic surface (pass
    ``ui_dist=None`` to keep the static mount off; pass an
    explicit path to enable it). When set, the daemon mounts the
    dist tree at ``/`` so ``http://127.0.0.1:<port>/`` returns the
    SolidJS app shell.
    """
    if started_at is None:
        started_at = datetime.now(timezone.utc)
    if broadcaster is None:
        broadcaster = EventBroadcaster()

    # (#501) Single-process in-memory mode state holder. Modes are
    # operator-facing labels over current gate state; the holder
    # tracks the gate-state map + the audit log of transitions.
    # When ``mode_transitions_log`` is supplied, every transition is
    # also written to sqlite (best-effort; in-memory log is the
    # source of truth on persistence failure). main.py constructs
    # the log from the shared ``action_log_con``; tests pass None.
    from forge_manager_mcp.daemon.modes_state import ModesStateHolder
    modes_holder = ModesStateHolder(persistent_log=mode_transitions_log)

    # (#476 / 3.14.0) Populate the shadow registry before any route
    # closure can consult it. Late import keeps `from
    # forge_manager_mcp.daemon.http import make_app` cheap when
    # callers don't actually construct the app (CLI introspection,
    # docs builds). Idempotent — re-registration overwrites prior
    # entries per shadow.registry.register_table's contract, so
    # restart / repeated factory calls are safe.
    from forge_manager_mcp.shadow import register_all
    register_all()

    pid = os.getpid()

    # (#493 successor / 3.16.0 D1 / A.1) In-memory migration state
    # holder. Constructed once per daemon instance; lifetime matches
    # the app. MCP migration handlers publish state transitions via
    # the `migration.*` SSE events documented in
    # ``daemon/migration_state.py``; the UI's <MigrationSwimlane>
    # subscribes to those events + polls /migrations/status on mount
    # for the initial snapshot.
    from forge_manager_mcp.daemon.migration_state import (
        MigrationStateHolder,
    )

    # Wire the holder's optional event_publisher to broadcaster.publish
    # via make_event. The holder fires `migration.upserted` /
    # `migration.step_changed` / `migration.removed` events on each
    # mutation; subscribers on /events receive them in SSE shape.
    # Without a broadcaster (test contexts that don't pass one),
    # publish is a no-op via the holder's None-publisher fallthrough.
    def _publish_migration_event(event_name: str, payload: dict) -> None:
        if broadcaster is None:
            return
        broadcaster.publish(make_event(event=event_name, data=payload))

    migration_state_holder = MigrationStateHolder(
        event_publisher=_publish_migration_event,
    )

    # (3.16.0 D1 / A.2) In-memory release state holder. Same shape
    # + wiring pattern as the migration holder above. Publishes
    # ``release.upserted`` / ``release.step_changed`` /
    # ``release.removed`` events to the broadcaster on each mutation.
    from forge_manager_mcp.daemon.release_state import (
        ReleaseStateHolder,
    )

    def _publish_release_event(event_name: str, payload: dict) -> None:
        if broadcaster is None:
            return
        broadcaster.publish(make_event(event=event_name, data=payload))

    release_state_holder = ReleaseStateHolder(
        event_publisher=_publish_release_event,
    )

    async def health(request) -> JSONResponse:
        """Auth-free liveness probe. Returns version + uptime + PID.

        The MCP daemon-client uses this to:
        - Confirm the discovered daemon is alive (vs stale-PID).
        - Confirm version match between MCP and daemon (mismatch
          triggers graceful daemon restart per RFC #5 §Lifecycle).
        """
        now = datetime.now(timezone.utc)
        uptime = (now - started_at).total_seconds()
        payload: dict[str, Any] = {
            "version": version,
            "pid": pid,
            "started_at": started_at.isoformat(),
            "uptime_seconds": uptime,
        }
        return JSONResponse(payload)

    async def health_ready(request) -> JSONResponse:
        """(#469) Auth-free readiness probe. Distinct from ``/health``
        (process alive) — returns 200 with ``ready=true`` only after
        the daemon has finished post-bind initialization:

          * Credentials loaded into os.environ (or fall-through to
            env vars completed).
          * Replication manager constructed (or explicitly None when
            project_dir wasn't passed — readiness still flips when
            the construction sequence finishes).
          * Startup probe task scheduled (the first per-adapter
            probe-and-classify cycle is dispatched).
          * Canonical-reconciler task scheduled (#470 sub-fix 2b
            sibling).

        The signal flips True once in ``daemon/main.py``'s
        ``_serve_with_watch`` after all of the above complete and
        BEFORE uvicorn enters the request-serving loop. Until that
        point ``/health/ready`` returns 200 with ``ready=false`` so
        the MCP-side ``wait_for_ready`` distinguishes "daemon
        accepting connections but not initialized" from "daemon
        crashed."

        Pre-#469 the MCP's auto-restart path returned ok=True after
        ``wait_for_port_bound`` succeeded — which guarantees uvicorn
        is accepting connections but NOT that startup_probe + cred
        load completed. Audit dispatch + mirror fan-out in
        open_session immediately fired against the post-restart
        daemon and saw transient DEGRADED / unknown-op states from
        the bind→ready gap. ``/health/ready`` closes that gap.

        Contract:

          * HTTP 200 always (the daemon is alive when this endpoint
            answers — that fact alone is a liveness signal,
            independent of the ``ready`` field).
          * ``ready: bool`` — True once initialization finished.
          * ``uptime_seconds: float`` — same as ``/health``, so
            callers polling /health/ready can also see uptime
            without a second round trip.

        Auth-free same as /health — readiness is operational state,
        not sensitive data.
        """
        # Read the readiness flag from app.state, defaulting to
        # False. The setter in daemon/main.py flips it True after
        # initialization completes; tests can construct the app
        # standalone and observe ready=false without wiring the
        # daemon-main flow.
        ready_flag = bool(getattr(request.app.state, "ready", False))
        now = datetime.now(timezone.utc)
        uptime = (now - started_at).total_seconds()
        return JSONResponse({
            "ready": ready_flag,
            "version": version,
            "pid": pid,
            "uptime_seconds": uptime,
        })

    async def whoami(request) -> JSONResponse:
        """Auth-required minimal endpoint (D3b.1).

        Returns the requesting client's effective auth state. This
        endpoint exists primarily as a 200 target for end-to-end
        auth tests and as the simplest auth-required handler shape
        for D3b.4+ to clone. Will be replaced or extended by /config
        in D3b.3.
        """
        return JSONResponse({"authenticated": True})

    async def config(request) -> JSONResponse:
        """Resolved GithubConfig (Phase D3b.3 / 3.5.0).

        Returns ``{"loaded": True, "config": {...}}`` when the
        daemon was started with ``--project-dir`` and load_config
        succeeded; otherwise ``{"loaded": False, "reason": "..."}``.

        Per #299 sub-RFC closure (D0): 3.5.0 ships read-only —
        write surface (PATCH /config/backends/{id}) is 3.6.0+.
        The shared loader code path between daemon and MCP per
        #299 OQ6 closure means both processes parse the same
        forge-config.json with the same Pydantic model; this
        endpoint exposes the daemon's parsed result.
        """
        if config_payload is None:
            return JSONResponse({
                "loaded": False,
                "reason": (
                    config_load_error
                    or "no --project-dir passed; daemon has no config"
                ),
            })
        return JSONResponse({"loaded": True, "config": config_payload})

    async def backends(request) -> JSONResponse:
        """List configured backends + per-adapter state (Phase D3b.4
        / Capability 1 read surface; #333 timestamp extensions;
        A.4.3 / #23 canonical_db_ready surface).

        Returns ``{"backends": [...], "canonical_db_ready": bool}``
        where each backends entry is::

            {
              platform_id, state, display_status, canonical,
              last_error, state_changed_at, last_error_at,
              next_attempt_at,
            }

        - ``platform_id`` — adapter's identifier (e.g., ``local``,
          ``github``, ``codeberg``)
        - ``state`` — raw AdapterState: ``healthy`` / ``degraded`` /
          ``reconciling`` / ``paused``
        - ``display_status`` — same set as ``state`` for D3b.4g;
          allows future shape changes without breaking UI conditional
          rendering (UI can switch on display_status alone)
        - ``canonical`` — true for the first entry (the
          replication-order canonical adapter)
        - ``last_error`` — string of the most recent error if any,
          else None
        - ``state_changed_at`` — ISO-8601 UTC; when ``state`` last
          transitioned (#333). UI renders relative-time + absolute.
        - ``last_error_at`` — ISO-8601 UTC; when ``last_error`` was
          recorded; None when error is None
        - ``next_attempt_at`` — ISO-8601 UTC; when the manager's
          next reconciliation attempt is expected; None for HEALTHY
          / PAUSED

        Top-level ``canonical_db_ready`` (A.4.3 / Discussion #23
        OQ27) — False until the canonical-DB → filesystem regenerator
        completes its first successful sweep; True thereafter. UI
        swimlane surfaces gate on this flag; the existing
        IssuesTable stays the default while False. Chosen to extend
        /backends rather than add a new /status endpoint because the
        existing payload is already the daemon's per-session
        operational-state summary (per-adapter array under a
        top-level wrapper); canonical_db_ready is the read/write
        substrate's analogue of per-adapter readiness, so it lives
        as a sibling field rather than a fresh route surface.

        When the daemon was started without ``--project-dir``, or
        config loading failed, returns
        ``{"backends": [], "canonical_db_ready": <flag>}``.
        """
        # #343: snapshot effect lives in effects/replication_state.py
        # so the handler is a one-liner over the standalone-testable
        # effect.
        from forge_manager_mcp.daemon.effects.replication_state import (
            list_backends,
        )
        # (A.4.3 / 3.15.0 / #23) Late import — keeps the daemon_http
        # → daemon_canonical_db_regenerator dep edge a runtime concern.
        # is_canonical_db_ready() is a pure boolean read; no exception
        # surface.
        from forge_manager_mcp.daemon.canonical_db_regenerator import (
            is_canonical_db_ready,
        )
        return JSONResponse({
            "backends": list_backends(replication, config_payload),
            "canonical_db_ready": is_canonical_db_ready(),
        })

    async def files_tree(request) -> JSONResponse:
        """Directory listing under the canonical store (Phase D3b.4d
        / capability 4 read surface).

        Query string: ``?path=<relative-path>`` (default empty =
        canonical store root).

        Returns ``{"path": "<resolved>", "entries": [...]}`` where
        each entry is ``{"name": "<basename>", "type": "file|dir",
        "size": <bytes-or-null>}``. Sorted alphabetically with dirs
        first.

        404 when no LocalStore canonical is configured (the daemon
        was started without --project-dir, or the canonical adapter
        is a remote backend with no filesystem path).

        400 on path traversal attempts (`..` components, absolute
        paths, anything that resolves outside the canonical store
        root).
        """
        # #343: path-resolution + listing effects in effects/files.py.
        # 3.7.0 D5 / #351: optional ?repo=<id> selects which repo's
        # tree to walk; absent defaults to canonical store (back-compat).
        from forge_manager_mcp.daemon.effects.files import (
            list_directory, resolve_path,
        )
        rel = request.query_params.get("path", "")
        repo_id = request.query_params.get("repo") or None
        target, err = resolve_path(
            replication, rel,
            repo_id=repo_id,
            project_dir=project_dir,
            config_payload=config_payload,
        )
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        entries, err = list_directory(target)
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        return JSONResponse({
            "path": rel, "repo": repo_id, "entries": entries,
        })

    async def files_content(request) -> JSONResponse:
        """File contents (Phase D3b.4d / capability 4 read surface).

        Query string: ``?path=<relative-path>`` (required, non-empty).

        Returns ``{"path": "<resolved>", "content": "<text>",
        "size": <bytes>}``. Content is decoded as UTF-8; binary or
        non-UTF-8 files return 415.

        Same path-traversal validation as ``/files/tree``. The 1MB
        max-content guard prevents an accidental huge-file load
        from blocking the response thread; over-cap returns 413.
        """
        # #343: resolution + read effects in effects/files.py.
        # 3.7.0 D5 / #351: optional ?repo=<id> selects which repo's
        # tree to read from; absent defaults to canonical (back-compat).
        from forge_manager_mcp.daemon.effects.files import (
            read_text_file, resolve_path,
        )
        rel = request.query_params.get("path", "")
        repo_id = request.query_params.get("repo") or None
        if not rel:
            return JSONResponse(
                {"error": "path query parameter is required"},
                status_code=400,
            )
        target, err = resolve_path(
            replication, rel,
            repo_id=repo_id,
            project_dir=project_dir,
            config_payload=config_payload,
        )
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        result, err = read_text_file(target)
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        return JSONResponse({
            "path": rel,
            "repo": repo_id,
            "content": result["content"],
            "size": result["size"],
        })

    async def test_credential_endpoint(request) -> JSONResponse:
        """Pre-save credential test (#366 / 3.8.0 D6 / Theme F).

        Body: ``{"token": "<plaintext>"}``. Validates the token
        against the platform's whoami endpoint. Returns ``{ok,
        platform_id, identity?, error?}``. **The token is not
        persisted** — it lives only in the request body and the
        transient httpx call. Use ``PUT /credentials/{platform_id}``
        to persist after a successful test.

        400 on bad input. Network / auth failures surface as
        ``{ok: false, error: "..."}`` with a 200 status — the
        wizard renders the structured error rather than handling
        HTTP-level exceptions.
        """
        platform_id = request.path_params["platform_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        token = body.get("token", "")
        if not isinstance(token, str) or not token.strip():
            return JSONResponse(
                {"error": "token must be a non-empty string"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.credential_test import (
            test_credential,
        )
        result = await test_credential(platform_id, token)
        return JSONResponse(result)

    async def setup_scaffold(request) -> JSONResponse:
        """Run multi-platform scaffold from the wizard
        (#374 / 3.8.0 D3.2 / Discussion #11).

        Body: ``{project_name, description, platforms,
        replication_order}``. Walks every platform with
        ``has_scaffold = True`` and runs ``bootstrap_project``.
        Returns ``{per_platform, pending_manual, skipped}``.

        Local file generation (CLAUDE.md, project-rules.md) deferred
        to D3.6; the daemon endpoint stays focused on cross-backend
        orchestration. The wizard's UX flow is: scaffold → POST /config
        → CLAUDE.md merger.

        400 on bad input. 500 wraps adapter exceptions so the wizard
        sees a structured error rather than a starlette traceback.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"},
                status_code=400,
            )
        project_name = body.get("project_name", "")
        description = body.get("description", "")
        platforms_in = body.get("platforms", [])
        replication_order = body.get("replication_order", [])
        if not isinstance(platforms_in, list) or not isinstance(
            replication_order, list,
        ):
            return JSONResponse(
                {
                    "error": (
                        "platforms must be a list and replication_order "
                        "must be a list of platform_ids"
                    ),
                },
                status_code=400,
            )
        from forge_manager_mcp.daemon.setup import run_scaffold
        try:
            result = await run_scaffold(
                project_name=project_name,
                description=description,
                platforms=platforms_in,
                replication_order=replication_order,
            )
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                },
                status_code=500,
            )
        return JSONResponse(result)

    async def write_config(request) -> JSONResponse:
        """Write a new forge-config.json (#374 / 3.8.0 D3.1 / Discussion #11).

        Body: full GithubConfig payload (the same shape ``GET /config``
        returns under the ``config`` key). Validates via Pydantic
        before any disk write; rejects malformed payloads with 400.
        Atomic-writes to ``<project_dir>/.claude/forge-config.json``
        — temp file in the same directory + fsync + rename — so a
        partial write can't corrupt the operator's existing config.

        Returns ``{written: true, config: <validated payload>}`` on
        success. The daemon's in-memory ``config_payload`` snapshot
        is updated so subsequent ``GET /config`` calls reflect the
        new state without a daemon restart.

        503 when no ``--project-dir`` was passed (no canonical
        location for the file).
        """
        if project_dir is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no --project-dir; "
                        "cannot resolve a forge-config.json path."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"}, status_code=400,
            )
        try:
            from forge_manager_mcp.models import GithubConfig
            from pydantic import ValidationError
            try:
                validated = GithubConfig.model_validate(body)
            except ValidationError as exc:
                return JSONResponse(
                    {
                        "error": "config validation failed",
                        "details": [
                            {
                                "loc": list(e.get("loc", ())),
                                "msg": e.get("msg", ""),
                                "type": e.get("type", ""),
                            }
                            for e in exc.errors()
                        ],
                    },
                    status_code=400,
                )
        except ImportError:
            return JSONResponse(
                {"error": "config validator unavailable"},
                status_code=503,
            )
        from forge_manager_mcp.daemon.effects.config_write import (
            atomic_write_config,
        )
        target = project_dir / ".claude" / "forge-config.json"
        payload = validated.model_dump(mode="json", exclude_none=True)
        try:
            atomic_write_config(target, payload)
        except OSError as exc:
            return JSONResponse(
                {"error": f"could not write config: {exc}"},
                status_code=500,
            )
        # Refresh the daemon's in-memory snapshot so subsequent reads
        # see the new state without a restart. The closure-captured
        # variable is rebound via the helper-cell pattern; for
        # simplicity we also keep the existing config_payload alive
        # so other endpoints (probe_schema_version, etc.) don't see
        # a None until restart.
        nonlocal config_payload
        config_payload = payload
        return JSONResponse({"written": True, "config": payload})

    async def upgrade_execute(request) -> JSONResponse:
        """Run dry_run / execute / rollback for one upgrade step
        (#373 / 3.8.0 D2.4 / Discussion #12).

        URL: ``POST /upgrade/execute/{step}`` where ``step`` is one
        of the registered ``repair_type`` keys (pipx_upgrade,
        daemon_restart, schema_migration, skill_prose_pull,
        config_patch, claude_md_merge, verify).

        Body: ``{"action": "dry_run" | "execute" | "rollback",
        "ctx": {...}, "prior_state": {...}}``.

        Returns the executor's StepDryRun (for action=dry_run) or
        StepResult (for execute / rollback) as JSON. 400 on unknown
        action / unknown step / malformed body.
        """
        from forge_manager_mcp.upgrade import executors
        step = request.path_params["step"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        action = body.get("action")
        ctx = body.get("ctx", {})
        prior_state = body.get("prior_state")
        if action not in ("dry_run", "execute", "rollback"):
            return JSONResponse(
                {"error": f"unknown action: {action!r}"},
                status_code=400,
            )
        if not isinstance(ctx, dict):
            return JSONResponse(
                {"error": "ctx must be a JSON object"}, status_code=400,
            )
        try:
            ex = executors.get_executor(step)
        except executors.UnknownExecutorError:
            return JSONResponse(
                {"error": f"unknown step: {step!r}"}, status_code=400,
            )
        try:
            if action == "dry_run":
                outcome = ex.dry_run_fn(ctx)
                payload = executors.to_dry_run_dict(outcome)
            elif action == "execute":
                outcome = ex.execute_fn(ctx)
                payload = executors.to_result_dict(outcome)
            else:  # rollback
                outcome = ex.rollback_fn(ctx, prior_state)
                payload = executors.to_result_dict(outcome)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "step": step,
                    "action": action,
                },
                status_code=500,
            )
        return JSONResponse(payload)

    async def findings_endpoint(request) -> JSONResponse:
        """Full code-design findings list + per-path index
        (#369 / 3.8.0 D7.1). Sibling of /gates which returns the
        truncated top-10 inside its code_design_status field; this
        endpoint returns the full untruncated list suitable for a
        tree-icon roll-up or a dedicated Findings index view.

        Returns ``{ran_at, scope, findings, by_path, by_rule}``.
        Falls back to ``status: skipped`` shape on any failure
        (matches the status helper's tolerant pattern).
        """
        if project_dir is None:
            return JSONResponse({
                "ran_at": None,
                "scope": "skipped",
                "findings": [],
                "by_path": {},
                "by_rule": {},
                "reason": "daemon has no --project-dir",
            })
        try:
            from forge_manager_mcp.code_design.probe import (
                probe_code_design_findings,
            )
            payload = probe_code_design_findings(project_dir)
            # Normalize paths to project_dir-relative so the UI's
            # tree-sidebar paths (repo-relative) match by_path keys.
            project_root = str(project_dir.resolve())
            prefix = project_root + "/"

            def _norm(p: str) -> str:
                if p.startswith(prefix):
                    return p[len(prefix):]
                return p

            payload["findings"] = [
                {**f, "path": _norm(f["path"])}
                for f in payload.get("findings", [])
            ]
            payload["by_path"] = {
                _norm(k): v for k, v in (payload.get("by_path") or {}).items()
            }
            return JSONResponse(payload)
        except Exception as exc:
            return JSONResponse({
                "ran_at": None,
                "scope": "skipped",
                "findings": [],
                "by_path": {},
                "by_rule": {},
                "reason": f"probe failed: {exc}",
            })

    async def milestones_endpoint(request) -> JSONResponse:
        """Milestone compound-doc enumeration for MilestonesTable
        (#398 D4 / 3.11.0 D3.d). Walks
        ``<docs>/milestones/<version>/meta.json`` and returns each
        milestone's headline fields suitable for a tabular view:

            {
              "milestones": [
                {version, title, state, tier, hotfix,
                 plan_discussion, cut_at, tag_sha},
                ...
              ]
            }

        Sorted semver-descending; non-semver entries trail by string
        order. Empty list when ``<docs>/milestones/`` is absent
        (greenfield project pre-D1.a migration).
        """
        from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
        if project_dir is None:
            return JSONResponse({"milestones": []})
        docs_root = resolve_docs_root(project_dir)
        if docs_root is None:
            return JSONResponse({"milestones": []})
        ms_root = docs_root / "milestones"
        if not ms_root.is_dir():
            return JSONResponse({"milestones": []})

        milestones: list = []
        for entry in ms_root.iterdir():
            if not entry.is_dir():
                continue
            meta_path = entry / "meta.json"
            if not meta_path.is_file():
                continue
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            title_path = entry / "title.md"
            title = (
                title_path.read_text(encoding="utf-8").strip()
                if title_path.exists() else entry.name
            )
            state_path = entry / "state.txt"
            state = (
                state_path.read_text(encoding="utf-8").strip()
                if state_path.exists() else "planned"
            )
            milestones.append({
                "version": meta.get("version", entry.name),
                "title": title,
                "state": state,
                "tier": meta.get("tier"),
                "hotfix": bool(meta.get("hotfix", False)),
                "plan_discussion": meta.get("plan_discussion"),
                "cut_at": meta.get("cut_at"),
                "tag_sha": meta.get("tag_sha"),
            })

        # Semver-descending sort (non-semver trails).
        def semver_key(m: dict) -> tuple:
            version = m.get("version", "")
            parts = version.split(".")
            try:
                return (1, [int(p) for p in parts])
            except ValueError:
                return (0, parts)
        milestones.sort(key=semver_key, reverse=True)
        return JSONResponse({"milestones": milestones})

    async def session_state_endpoint(request) -> JSONResponse:
        """Live operator-state snapshot for HeaderStatus (#402 MVP /
        3.11.0 D5). Surfaces the headline values an operator wants
        at-a-glance: current active milestone + its anchored plan
        Discussion. Returns ``{milestone, plan_discussion}``:

            milestone:        {version, state} | null
            plan_discussion:  int | list[int] | null

        Resolution: walk ``<docs>/milestones/<v>/state.txt`` for the
        first entry with ``state.txt`` line-1 == "active"; semver-
        descending sort breaks ties (most likely the in-flight
        version). Plan discussion read from that milestone's
        ``meta.json.plan_discussion``.

        Full #402 spec (session-aware stacks, SSE channel, processing
        throbber via Claude Code hooks, multi-axis chips) deferred —
        this endpoint is the read-only minimal-MVP surface that
        unblocks the header-status visual without the multi-phase
        infrastructure ride. Empty payload when ``<docs>/milestones/``
        is absent or no milestone is active.
        """
        from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
        if project_dir is None:
            return JSONResponse({"milestone": None, "plan_discussion": None})
        docs_root = resolve_docs_root(project_dir)
        if docs_root is None:
            return JSONResponse({"milestone": None, "plan_discussion": None})
        ms_root = docs_root / "milestones"
        if not ms_root.is_dir():
            return JSONResponse({"milestone": None, "plan_discussion": None})

        active: list[tuple[str, dict]] = []
        for entry in ms_root.iterdir():
            if not entry.is_dir():
                continue
            state_path = entry / "state.txt"
            if not state_path.is_file():
                continue
            try:
                state_raw = state_path.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            # Multi-axis state.txt: lifecycle axis is line 1.
            lifecycle = state_raw.split("\n")[0].strip()
            if lifecycle != "active":
                continue
            meta_path = entry / "meta.json"
            meta: dict = {}
            if meta_path.is_file():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    meta = {}
            active.append((meta.get("version", entry.name), meta))

        if not active:
            return JSONResponse({"milestone": None, "plan_discussion": None})

        # Semver-descending sort — newest active wins.
        def _semver_key(pair: tuple[str, dict]) -> tuple:
            try:
                return (1, [int(p) for p in pair[0].split(".")])
            except ValueError:
                return (0, pair[0])
        active.sort(key=_semver_key, reverse=True)
        version, meta = active[0]
        return JSONResponse({
            "milestone": {"version": version, "state": "active"},
            "plan_discussion": meta.get("plan_discussion"),
        })

    async def sessions_endpoint(request) -> JSONResponse:
        """Session compound-doc enumeration for SessionsTimeline
        (#398 D3.d / 3.11.0). Walks ``<docs>/sessions/<id>/*.json``,
        aggregates the per-session event log into one row per session,
        and returns:

            {
              "sessions": [
                {session_id, opened_at, closed_at, skill_version,
                 status, duration_seconds},
                ...
              ]
            }

        Sorted descending by opened_at (newest first). Sessions with
        no opened.json (canonical fix-up gaps) are skipped silently.
        ``status`` is "open" when no closed event exists, "closed"
        otherwise. ``skill_version`` extracted from the opened event
        body's ``skill_version=<x.y.z>`` token (legacy 2.x text
        format) when present.

        Empty list when ``<docs>/sessions/`` is absent (greenfield
        project pre-3.0).
        """
        from forge_manager_mcp.gap_analysis.walker import resolve_docs_root
        if project_dir is None:
            return JSONResponse({"sessions": []})
        docs_root = resolve_docs_root(project_dir)
        if docs_root is None:
            return JSONResponse({"sessions": []})
        s_root = docs_root / "sessions"
        if not s_root.is_dir():
            return JSONResponse({"sessions": []})

        # skill_version=3.6.0 token extractor — opened-event body is
        # space-separated key=value pairs per LocalStore.append_session_event.
        def _extract_skill_version(body: str) -> str | None:
            for tok in body.split():
                if tok.startswith("skill_version="):
                    return tok.split("=", 1)[1]
            return None

        sessions: list = []
        for entry in s_root.iterdir():
            if not entry.is_dir():
                continue
            opened_at: str | None = None
            closed_at: str | None = None
            skill_version: str | None = None
            for event_file in entry.iterdir():
                if not event_file.is_file() or event_file.suffix != ".json":
                    continue
                try:
                    raw = json.loads(event_file.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    continue
                event = raw.get("event")
                ts = raw.get("timestamp")
                if not ts:
                    continue
                if event == "opened":
                    if opened_at is None or ts < opened_at:
                        opened_at = ts
                        sv = _extract_skill_version(str(raw.get("body", "")))
                        if sv:
                            skill_version = sv
                elif event == "closed":
                    if closed_at is None or ts > closed_at:
                        closed_at = ts
            if opened_at is None:
                continue
            duration: float | None = None
            if closed_at is not None:
                try:
                    from datetime import datetime
                    duration = (
                        datetime.fromisoformat(closed_at)
                        - datetime.fromisoformat(opened_at)
                    ).total_seconds()
                except ValueError:
                    duration = None
            sessions.append({
                "session_id": entry.name,
                "opened_at": opened_at,
                "closed_at": closed_at,
                "skill_version": skill_version,
                "status": "closed" if closed_at else "open",
                "duration_seconds": duration,
            })

        sessions.sort(key=lambda s: s["opened_at"], reverse=True)
        return JSONResponse({"sessions": sessions})

    async def gaps_endpoint(request) -> JSONResponse:
        """Gap compound-doc enumeration for the GapsView surface
        (#406 / 3.11.0 D3.d sibling). Walks ``<docs>/gaps/<category>/``
        and returns each gap's headline fields:

            {
              "gaps": [
                {category, state, severity, tier, finding_count,
                 anchored_milestone, last_run_at, filed_issue,
                 filed_target_milestone},
                ...
              ],
              "summary": {cut_blocked, blocking_count, accepted_count,
                          filed_count, ignored_count, total_active_findings,
                          highest_severity}
            }

        Excludes ``ignored`` gaps from per-category list (per #406
        decision rubric — ignored stay silent always). Empty list +
        clean summary when ``<docs>/gaps/`` is absent.
        """
        from forge_manager_mcp.gap_analysis.walker import (
            build_category_snapshots,
            build_summary,
            resolve_docs_root,
            walk_gap_metas,
        )
        from dataclasses import asdict
        if project_dir is None:
            empty_summary = build_summary([])
            return JSONResponse({
                "gaps": [],
                "summary": asdict(empty_summary),
            })
        docs_root = resolve_docs_root(project_dir)
        if docs_root is None:
            empty_summary = build_summary([])
            return JSONResponse({
                "gaps": [],
                "summary": asdict(empty_summary),
            })
        metas = walk_gap_metas(docs_root)
        anchored = sorted({
            m.get("anchored_milestone") for m in metas
            if m.get("anchored_milestone")
        })
        active_milestone = anchored[-1] if anchored else None
        summary = build_summary(metas, active_milestone=active_milestone)
        snapshots = build_category_snapshots(metas)
        return JSONResponse({
            "gaps": [asdict(s) for s in snapshots],
            "summary": asdict(summary),
        })

    async def shadow_endpoint(request) -> JSONResponse:
        """(#475 / 3.14.0) Per-table bitemporal shadow accessor.

        Path: ``GET /shadow/{table}``. The framework PR ships the
        route shape + registry lookup; per-table PRs (Issues
        #476-#483) populate :mod:`shadow.registry` so the route
        starts returning rows.

        Query parameters:

        * ``filter=col1=v1,col2=v2`` — column-equality filters
          AND'd together. Unknown column names surface as 400
          errors via the sqlite layer.
        * ``sort=col`` or ``sort=col:asc|desc`` — single-column
          ORDER BY clause. Defaults to ``recorded_at DESC``.
        * ``limit=N`` — row cap. Defaults to 100.
        * ``offset=N`` — pagination offset. Defaults to 0.

        Returns ``{rows, total_count, table, filters_applied}``
        on success; ``404`` for unknown tables; ``503`` when the
        daemon was started without a sqlite connection.
        """
        from forge_manager_mcp.shadow import registry as shadow_registry

        table = request.path_params["table"]
        if table not in shadow_registry.registered_tables():
            return JSONResponse(
                {
                    "error": f"unknown shadow table: {table!r}",
                    "registered_tables": shadow_registry.registered_tables(),
                },
                status_code=404,
            )
        if action_log_con is None:
            return JSONResponse(
                {
                    "error": (
                        "shadow endpoint requires a bootstrapped "
                        "action-log connection; daemon was started "
                        "without one"
                    ),
                },
                status_code=503,
            )

        filters_param = request.query_params.get("filter")
        filters_applied: dict[str, str] = {}
        where_clauses: list[str] = []
        bind_values: list[Any] = []
        if filters_param:
            for chunk in filters_param.split(","):
                if "=" not in chunk:
                    continue
                col, _, val = chunk.partition("=")
                col = col.strip()
                val = val.strip()
                if not col:
                    continue
                filters_applied[col] = val
                where_clauses.append(f"{col} = ?")
                bind_values.append(val)

        sort_param = request.query_params.get("sort", "recorded_at:desc")
        sort_col, _, sort_dir = sort_param.partition(":")
        sort_col = sort_col.strip() or "recorded_at"
        sort_dir = (sort_dir.strip().upper() or "DESC")
        if sort_dir not in ("ASC", "DESC"):
            sort_dir = "DESC"

        try:
            limit = int(request.query_params.get("limit", "100"))
        except ValueError:
            limit = 100
        try:
            offset = int(request.query_params.get("offset", "0"))
        except ValueError:
            offset = 0

        where_sql = ""
        if where_clauses:
            where_sql = " WHERE " + " AND ".join(where_clauses)
        sql = (
            f"SELECT * FROM {table}{where_sql} "
            f"ORDER BY {sort_col} {sort_dir} "
            f"LIMIT ? OFFSET ?"
        )
        bind_values_with_paging = bind_values + [limit, offset]

        count_sql = f"SELECT COUNT(*) FROM {table}{where_sql}"

        try:
            cur = action_log_con.execute(sql, bind_values_with_paging)
            cols = [d[0] for d in cur.description] if cur.description else []
            rows = [dict(zip(cols, row)) for row in cur.fetchall()]
            total_row = action_log_con.execute(count_sql, bind_values).fetchone()
            total_count = int(total_row[0]) if total_row else 0
        except Exception as exc:  # noqa: BLE001 — surface sqlite errors verbatim
            return JSONResponse(
                {
                    "error": f"shadow query failed: {type(exc).__name__}: {exc}",
                    "table": table,
                },
                status_code=400,
            )

        return JSONResponse({
            "rows": rows,
            "total_count": total_count,
            "table": table,
            "filters_applied": filters_applied,
        })

    async def upgrade_status(request) -> JSONResponse:
        """Multi-source drift snapshot for the upgrade wizard
        (#373 / 3.8.0 D2.2 / Discussion #12).

        Aggregates eight drift sources (currently 5 active + 3
        stubbed for D2.x) and returns the wizard's punch-list:

            {
              "drifts": [{source, current, target, status, severity,
                          repair_type, message, recommendation}, ...],
              "summary": {by_status, by_severity, needs_repair},
            }

        Auth-required like the rest of the daemon's API surface.
        """
        from forge_manager_mcp.upgrade import detect
        drifts = detect.aggregate(
            project_dir=project_dir,
            state_dir=state_dir,
            config_payload=config_payload,
        )
        return JSONResponse({
            "drifts": [detect.to_dict(d) for d in drifts],
            "summary": detect.summary(drifts),
        })

    async def gates_endpoint(request) -> JSONResponse:
        """Skill gate + process registry snapshot for the UI's Gates view.

        Reads ``<project_dir>/.claude/skills/forge-manager/gates.yaml``
        and ``processes.yaml`` and returns the parsed registries plus
        a fresh ``code_design_status`` snapshot (same shape that
        ``open_session`` already returns) so the UI can render live
        finding counts per ``code_design.*`` rule.

        ``{"loaded": false, "reason": "..."}`` on missing project_dir
        or YAML files; ``{"loaded": true, "gates": [...], "processes":
        [...], "code_design_status": {...}}`` on success.
        """
        if project_dir is None:
            return JSONResponse({
                "loaded": False,
                "reason": "daemon has no --project-dir",
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })
        skill_dir = project_dir / ".claude" / "skills" / "forge-manager"
        gates_path = skill_dir / "gates.yaml"
        processes_path = skill_dir / "processes.yaml"
        if not gates_path.is_file() or not processes_path.is_file():
            return JSONResponse({
                "loaded": False,
                "reason": (
                    f"skill prose not found at {skill_dir} "
                    "(gates.yaml and/or processes.yaml missing)"
                ),
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })
        try:
            from forge_manager_mcp.gate_registry import (
                load_gates, load_processes,
            )
            gates_reg = load_gates(gates_path)
            procs_reg = load_processes(processes_path)
        except Exception as exc:
            return JSONResponse({
                "loaded": False,
                "reason": f"registry parse failed: {exc}",
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })

        gates_payload = [
            {
                "name": g.name,
                "type": g.type,
                "summary": g.summary,
                "default_state": g.default_state,
                "extension_semantics": g.extension_semantics,
                "override_semantics": g.override_semantics,
                "location": g.location,
                "rationale_doc": g.rationale_doc,
                "introduced_in": g.introduced_in,
                "last_changed_in": g.last_changed_in,
                "related": list(g.related),
                "runbook_url": g.runbook_url,
            }
            for g in gates_reg.list_gates()
        ]
        processes_payload = [
            {
                "name": p.name,
                "type": p.type,
                "summary": p.summary,
                "location": p.location,
                "rationale_doc": p.rationale_doc,
                "introduced_in": p.introduced_in,
                "last_changed_in": p.last_changed_in,
                "related_processes": list(p.related_processes),
                "steps": [
                    {
                        "id": s.id,
                        "location": s.location,
                        "gates": list(s.gates),
                    }
                    for s in p.steps
                ],
            }
            for p in procs_reg.list_processes()
        ]
        try:
            from forge_manager_mcp.code_design.probe import (
                probe_code_design_status,
            )
            code_design_status = probe_code_design_status(project_dir)
        except Exception:
            code_design_status = None
        return JSONResponse({
            "loaded": True,
            "gates": gates_payload,
            "processes": processes_payload,
            "code_design_status": code_design_status,
        })

    def _load_modes_registry():
        """Resolve ``modes.yaml`` against the project skill dir.

        Returns ``(registry_or_None, error_reason)``. Used by every
        modes endpoint as the single source of truth for the
        registry's shape; lazy-loaded per-request so operator edits
        to ``modes.yaml`` take effect without a daemon restart.
        """
        if project_dir is None:
            return None, "daemon has no --project-dir"
        modes_path = (
            project_dir / ".claude" / "skills"
            / "forge-manager" / "modes.yaml"
        )
        if not modes_path.is_file():
            return None, f"modes.yaml not found at {modes_path}"
        from forge_manager_mcp.mode_registry import (
            ModeRegistryError, load_modes,
        )
        try:
            return load_modes(modes_path), None
        except ModeRegistryError as exc:
            return None, str(exc)

    def _mode_to_payload(mode) -> dict:
        """Same shape ``server/handlers/modes.py::_mode_to_payload``
        emits — keep the wire format identical across both surfaces
        so UI consumers can swap between MCP-tool + daemon-endpoint
        without a client-side translator."""
        return {
            "name": mode.name,
            "description": mode.description,
            "gate_states": [
                {
                    "gate": decl.gate,
                    "state": decl.state,
                    "scope": list(decl.scope),
                }
                for decl in mode.gate_states
            ],
        }

    async def list_modes_endpoint(request) -> JSONResponse:
        """(#501) GET /modes — resolved mode list for the UI's
        status-display mode picker.

        Returns ``{"loaded": true, "modes": [...]}`` on success;
        ``{"loaded": false, "reason": "..."}`` when modes.yaml is
        absent / malformed / project_dir unset.
        """
        registry, reason = _load_modes_registry()
        if registry is None:
            return JSONResponse({
                "loaded": False, "reason": reason, "modes": [],
            })
        return JSONResponse({
            "loaded": True,
            "modes": [_mode_to_payload(m) for m in registry.list_modes()],
        })

    async def current_mode_endpoint(request) -> JSONResponse:
        """(#501) GET /modes/current — currently-computed mode label.

        Computes the label over the holder's live gate-state snap
        using :func:`compute_current_mode` + the registry. Returns
        ``{"current_mode": "<label>", "matching_modes": [...],
        "gate_state": {...}}``. The ``matching_modes`` list carries
        every mode whose declarations all match — compound labels
        per Issue #501 §Composability.
        """
        registry, reason = _load_modes_registry()
        if registry is None:
            return JSONResponse({
                "available": True,
                "current_mode": modes_holder.current_mode_label,
                "matching_modes": [],
                "gate_state": modes_holder.gate_state,
                "reason": reason,
            })
        from forge_manager_mcp.mode_registry import (
            compute_current_mode, label_for_gate_state,
        )
        gate_state = modes_holder.gate_state
        matches = compute_current_mode(registry, gate_state)
        label = label_for_gate_state(registry, gate_state)
        return JSONResponse({
            "available": True,
            "current_mode": label,
            "matching_modes": matches,
            "gate_state": gate_state,
        })

    async def apply_mode_endpoint(request) -> JSONResponse:
        """(#501) POST /modes/{name} — apply a mode by name.

        Body: ``{"dry_run": bool}``. Resolves the named mode
        against the registry, batch-applies its ``gate_states``,
        records the transition to the audit log, and broadcasts
        ``mode.changed`` via SSE. Dry-run returns the diff without
        mutating.

        Returns the standard set_mode envelope per Issue #501:
        ``{applied, applied_gates, previous_mode, new_mode,
        dry_run, transition_id?}``.

        404 when the named mode isn't registered; 503 when no
        modes registry could be resolved.
        """
        name = request.path_params["name"]
        try:
            body = await request.json()
        except Exception:
            body = {}
        if not isinstance(body, dict):
            body = {}
        dry_run = bool(body.get("dry_run", False))

        registry, reason = _load_modes_registry()
        if registry is None:
            return JSONResponse(
                {"error": reason or "modes registry unavailable"},
                status_code=503,
            )
        mode = registry.get_mode(name)
        if mode is None:
            return JSONResponse(
                {"error": f"unknown mode: {name!r}"},
                status_code=404,
            )
        _record, payload = modes_holder.apply_mode(
            mode,
            actor=body.get("actor", "operator"),
            trigger="select_mode",
            dry_run=dry_run,
        )
        if not dry_run:
            try:
                from forge_manager_mcp.daemon.effects.events import publish
                publish(broadcaster, "mode.changed", {
                    "previous_mode": payload["previous_mode"],
                    "new_mode": payload["new_mode"],
                    "applied_gates": payload["applied_gates"],
                    "transition_id": payload.get("transition_id"),
                })
            except Exception:  # pragma: no cover — defensive
                pass
        payload["applied"] = not dry_run
        return JSONResponse(payload)

    async def swimlanes_endpoint(request) -> JSONResponse:
        """Swimlane composition for the operator UI (Discussion #24 / Phase 3).

        Returns ``{"swimlanes": [SwimlaneData, ...]}`` matching the
        ``ui/src/swimlane.ts`` TypeScript contract one-for-one. The
        list is stack-ordered (migration / current_milestone / release
        / unassigned / future_milestone) so the UI can iterate
        directly without re-sorting.

        Stub posture for Phase 3 — surfaces the active-milestone
        headline + the always-present empty unassigned lane. Phases
        4-7 fill the per-column composition for current_milestone /
        unassigned / migration / release respectively.

        Returns ``{"swimlanes": []}`` when ``project_dir`` is None
        (pre-bootstrap daemon).
        """
        from forge_manager_mcp.daemon.swimlanes import compose_swimlanes
        return JSONResponse({
            "swimlanes": compose_swimlanes(project_dir),
        })

    async def migrations_status_endpoint(request) -> JSONResponse:
        """(#493 successor / 3.16.0 D1 / A.1) Initial-state probe for
        the UI's <MigrationSwimlane> consumer.

        Returns ``{"migrations": [Migration, ...]}`` matching the
        ``ui/src/migrationCard.ts`` MigrationStep contract. The list
        preserves upsert order; clients render top-to-bottom.

        Empty list means no in-flight migrations. Operators visiting
        the UI fresh see an empty migration swimlane (or no migration
        swimlane at all per the composition rules — Migration is a
        singleton-when-present).

        SSE updates land on the existing ``/events`` channel under
        the ``migration.upserted`` / ``migration.step_changed`` /
        ``migration.removed`` event names. The endpoint here is the
        snapshot-on-mount probe; live updates ride SSE.

        Pre-3.16.0 D1: no endpoint, no holder, no SSE events.
        MigrationCard prototype shipped standalone with explicit
        "intentionally NOT wired into App.tsx" contract per #493.
        """
        return JSONResponse({
            "migrations": migration_state_holder.list_migrations(),
        })

    async def migrations_upsert_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.1 write-back) Upsert a migration into the
        holder. Body: a full migration record matching
        ``daemon/migration_state.make_migration``'s output shape —
        ``{id, title, steps: [{id, title, state}, ...]}``.

        Idempotent: posting against an existing migration_id replaces
        the step list wholesale. Fires ``migration.upserted`` SSE
        event via the holder's wired publisher.

        Used by the MCP migrate_to_* handler write-back (deferred to
        follow-up commit) to register an in-flight migration at chain
        start. The handler builds the step list from the migration
        chain's planned order, then calls this endpoint once per
        migration.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a migration object"},
                status_code=400,
            )
        required = ("id", "title", "steps")
        missing = [k for k in required if k not in body]
        if missing:
            return JSONResponse(
                {"error": f"migration missing required fields: {missing}"},
                status_code=400,
            )
        # Validate each step matches the make_step vocabulary —
        # state must be one of preview/running/complete; bad input
        # surfaces here rather than corrupting the holder.
        from forge_manager_mcp.daemon.migration_state import make_step
        try:
            normalized_steps = [
                make_step(
                    step_id=s["id"], title=s["title"],
                    state=s.get("state", "preview"),
                )
                for s in body["steps"]
            ]
        except (KeyError, ValueError) as exc:
            return JSONResponse(
                {"error": f"invalid step: {exc}"},
                status_code=400,
            )
        migration_state_holder.upsert_migration({
            "id": body["id"],
            "title": body["title"],
            "steps": normalized_steps,
        })
        return JSONResponse({"ok": True, "id": body["id"]})

    async def migrations_step_state_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.1 write-back) Update a single step's state.

        Body: ``{"state": "running" | "complete" | "preview"}``.
        Path params: migration_id, step_id.

        Returns 404 with ``{found: false}`` when the migration or
        step isn't known (idempotent — replaying out of order is
        observable, not fatal). Returns 200 with the resulting
        ``{migration_id, step_id, prev_state, new_state}`` on
        success.

        Fires ``migration.step_changed`` SSE event on actual state
        flip.
        """
        migration_id = request.path_params["migration_id"]
        step_id = request.path_params["step_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict) or "state" not in body:
            return JSONResponse(
                {"error": "body must include {state: ...}"},
                status_code=400,
            )
        try:
            result = migration_state_holder.update_step_state(
                migration_id, step_id, body["state"],
            )
        except ValueError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=400,
            )
        if result is None:
            return JSONResponse(
                {"found": False, "migration_id": migration_id,
                 "step_id": step_id},
                status_code=404,
            )
        m_id, s_id, prev, new = result
        return JSONResponse({
            "ok": True,
            "migration_id": m_id, "step_id": s_id,
            "prev_state": prev, "new_state": new,
        })

    async def release_upsert_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.2 write-back) Upsert a release into the
        holder. Body: full release record matching
        ``daemon/release_state.make_release``'s output —
        ``{id, title, steps: [{id, title, state}, ...]}``.

        Idempotent: existing release_id is replaced wholesale.
        Validates step state against the 5-state vocabulary
        (pending/running/done/failed/skipped) via make_release_step.
        Fires ``release.upserted`` SSE event.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a release object"},
                status_code=400,
            )
        required = ("id", "title", "steps")
        missing = [k for k in required if k not in body]
        if missing:
            return JSONResponse(
                {"error": f"release missing required fields: {missing}"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.release_state import (
            make_release_step,
        )
        try:
            normalized_steps = [
                make_release_step(
                    step_id=s["id"], title=s["title"],
                    state=s.get("state", "pending"),
                )
                for s in body["steps"]
            ]
        except (KeyError, ValueError) as exc:
            return JSONResponse(
                {"error": f"invalid step: {exc}"},
                status_code=400,
            )
        release_state_holder.upsert_release({
            "id": body["id"],
            "title": body["title"],
            "steps": normalized_steps,
        })
        return JSONResponse({"ok": True, "id": body["id"]})

    async def release_step_state_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.2 write-back) Update a single step's state.

        Body: ``{"state": "<one of 5 vocab>"}``.
        Path params: release_id, step_id.

        Operator-driven state transitions per the release UX:
          * pending → running (operator clicked "Start step")
          * running → done (step completed successfully)
          * running → failed (step raised; awaits operator
            decision: retry or skip)
          * failed → running (operator clicked "Retry" after fix)
          * pending → skipped (operator clicked "Skip" with
            confirmed_consequences=true)

        Returns 200 with prev/new tuple on success, 404 on unknown
        release or step. Fires ``release.step_changed`` SSE event.
        """
        release_id = request.path_params["release_id"]
        step_id = request.path_params["step_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict) or "state" not in body:
            return JSONResponse(
                {"error": "body must include {state: ...}"},
                status_code=400,
            )
        try:
            result = release_state_holder.update_step_state(
                release_id, step_id, body["state"],
            )
        except ValueError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=400,
            )
        if result is None:
            return JSONResponse(
                {"found": False, "release_id": release_id,
                 "step_id": step_id},
                status_code=404,
            )
        r_id, s_id, prev, new = result
        return JSONResponse({
            "ok": True,
            "release_id": r_id, "step_id": s_id,
            "prev_state": prev, "new_state": new,
        })

    async def release_remove_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.2 write-back) Remove a release from the
        holder. Idempotent; fires ``release.removed`` SSE event
        only on actual removal."""
        release_id = request.path_params["release_id"]
        removed = release_state_holder.remove_release(release_id)
        return JSONResponse({
            "ok": True,
            "removed": removed,
            "release_id": release_id,
        })

    async def triage_classify_endpoint(request) -> JSONResponse:
        """(3.16.0 D5) Run the public-issue triage classifier
        against a single Issue body+title.

        POST body: ``{title: str, body: str, existing_titles: [str]?}``.
        Returns the classifier output: ``{category, confidence, reasons}``.

        The endpoint exposes the heuristic classifier per RFC #25
        OQ-D1 — operator-driven dogfood seam before promoting to
        LLM-backed if precision drops below 70%. Bulk-classify
        (iterate every open public-mirror Issue) is a follow-up
        MCP tool; this endpoint is the per-Issue primitive that
        the bulk path will call in a loop.
        """
        from forge_manager_mcp.triage_classifier import classify_issue
        try:
            body_json = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body_json, dict):
            return JSONResponse(
                {"error": "body must be an object"},
                status_code=400,
            )
        title = body_json.get("title", "")
        body = body_json.get("body", "")
        existing_titles = body_json.get("existing_titles", [])
        if not isinstance(title, str) or not isinstance(body, str):
            return JSONResponse(
                {"error": "title and body must be strings"},
                status_code=400,
            )
        if not isinstance(existing_titles, list):
            return JSONResponse(
                {"error": "existing_titles must be a list of strings"},
                status_code=400,
            )
        # Coerce non-string entries to strings rather than reject —
        # operator-facing tool ergonomics; caller may pass ints / None
        # for unset titles.
        existing_titles = [str(t) for t in existing_titles if t is not None]
        result = classify_issue(
            body=body, title=title, existing_titles=existing_titles,
        )
        return JSONResponse(result)

    async def session_rotation_last_trigger_endpoint(
        request,
    ) -> JSONResponse:
        """(3.16.0 D5 / session-rotation gate-card) Surface the most
        recent phase-boundary trigger from the history-log facts so
        the UI's session-rotation gate-card can render a "rotation
        opportunity detected" affordance.

        Walks shadow.history_log_facts newest-first for operations
        that map to TriggerType per session_rotation.py's vocabulary
        (release_project / pr_merge / mark_discussion_decided /
        phase_completed) and returns the first match as a Trigger
        record. Returns ``{"trigger": null}`` when no recent matching
        event exists (typical when sessions are continuous within a
        phase).

        SSE notification on new triggers is a follow-up — for the
        v1 the UI polls this endpoint via createResource refetch or
        a manual refresh.
        """
        from forge_manager_mcp.session_rotation import (
            detect_phase_boundary,
        )
        # Query the history-log facts table directly. Falls back to
        # null on any failure (table missing / DB unopened / query
        # error) so the operator UI degrades gracefully.
        try:
            from forge_manager_mcp.daemon.action_log import database_path
            from forge_manager_mcp.daemon.paths import (
                DEFAULT_PROJECT_NAME, state_dir,
            )
            import sqlite3
            sd = state_dir(DEFAULT_PROJECT_NAME)
            db_path = database_path(sd)
            con = sqlite3.connect(str(db_path))
            try:
                cur = con.execute(
                    "SELECT operation, valid_from FROM history_log_facts "
                    "WHERE operation IN ("
                    "'release_project', 'pr_merge', 'git_merge_to_main', "
                    "'discussion_ac_closed', 'mark_discussion_decided', "
                    "'phase_completed'"
                    ") ORDER BY valid_from DESC LIMIT 50"
                )
                events = [
                    {"operation": row[0], "timestamp": row[1]}
                    for row in cur
                ]
            finally:
                con.close()
        except Exception:
            events = []

        trigger = detect_phase_boundary(events)
        if trigger is None:
            return JSONResponse({"trigger": None})
        return JSONResponse({
            "trigger": {
                "type": trigger.type.value,
                "source_event": trigger.source_event,
                "detail": trigger.detail,
            },
        })

    async def release_status_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.2) Initial-state probe for the UI's
        <ReleaseSwimlane> consumer.

        Returns ``{"releases": [Release, ...]}`` matching the UI's
        ReleaseStep contract — each release carries
        ``{id, title, steps: [{id, title, state}, ...]}`` with state
        in the 5-state vocabulary (pending/running/done/failed/skipped).

        Empty list means no in-flight releases. SSE updates land on
        the existing ``/events`` channel under the
        ``release.upserted`` / ``release.step_changed`` /
        ``release.removed`` event vocabulary.
        """
        return JSONResponse({
            "releases": release_state_holder.list_releases(),
        })

    async def migrations_remove_endpoint(request) -> JSONResponse:
        """(3.16.0 D1 / A.1 write-back) Remove a migration from the
        holder. Idempotent — removing a missing id returns
        ``{removed: false}`` cleanly.

        Fires ``migration.removed`` SSE event only when the holder
        actually carried the migration_id.
        """
        migration_id = request.path_params["migration_id"]
        removed = migration_state_holder.remove_migration(migration_id)
        return JSONResponse({
            "ok": True,
            "removed": removed,
            "migration_id": migration_id,
        })

    async def triage_scan_now(request) -> JSONResponse:
        """Manual public-issue triage scan trigger (Discussion #23 A.5.6 /
        Cluster G).

        3.15.0 stub: publishes a ``triage.scan_started`` + immediately
        a ``triage.scan_completed`` SSE event so the UI's Scan-now
        button (StatusDisplay row, #8225e09) wires through to a real
        endpoint instead of 404-ing. The real triage classifier
        (severity + fit advice computation per Discussion #24 §
        "Public-issue triage classifier") is 3.16.0 framework work
        — this stub closes the operator-visible gap that the button
        couldn't trigger anything.

        Returns ``{"accepted": true, "scan_id": <uuid-hex>}``. The
        scan_id mirrors the SSE event payloads so consumers can
        correlate the trigger with the resulting events.

        Auth-required. Idempotent — repeated calls each yield a new
        scan_id; no rate-limiting in v1 (operator-driven, low volume).
        """
        import uuid as _uuid
        from forge_manager_mcp.daemon.events import make_event
        scan_id = _uuid.uuid4().hex
        for event_name in ("triage.scan_started", "triage.scan_completed"):
            try:
                broadcaster.publish(make_event(
                    event=event_name,
                    data={
                        "scan_id": scan_id,
                        "result_count": 0,  # Stub — no real scan ran.
                    },
                ))
            except Exception:  # pragma: no cover - defensive
                # Broadcaster overflow / consumer error must not
                # poison the operator-visible accept signal.
                pass
        return JSONResponse({
            "accepted": True,
            "scan_id": scan_id,
        })

    async def repos(request) -> JSONResponse:
        """Repo enumeration for the per-repo tab strip (3.7.0 D5 / #351).

        Returns ``{"repos": [{id, label, path, kind}, ...]}``. Each
        entry corresponds to a locally-cloned repo in the project's
        scope: docs canonical, code (project_dir), public mirror,
        related repos. Repos with no local clone are omitted (per
        #351 OQ2 closure: skip rather than grey-out).

        Auth-required like /files/*. Returns an empty list when no
        replication / project_dir / config is configured.
        """
        from forge_manager_mcp.daemon.effects.files import enumerate_repos
        return JSONResponse({
            "repos": enumerate_repos(replication, project_dir, config_payload),
        })

    async def _set_backend_enabled(
        platform_id: str, enabled: bool,
    ) -> JSONResponse:
        """Shared helper for /backends/{id}/enable + /disable.

        Writes ``platforms[i].enabled`` to ``forge-config.json`` for
        the matching platform_id, refreshes the daemon's in-memory
        config_payload, and returns the new entry shape. The destructive
        state machine retirement (#23 A.5 OQ1) replaces the legacy
        pause/resume in-memory transitions with this durable config
        edit so operator intent survives daemon restart.

        Errors:
        - 404 when no project_dir / config (pre-bootstrap)
        - 404 when platform_id doesn't match any configured platform
        - 500 on config-file write failure
        """
        nonlocal config_payload
        if project_dir is None or config_payload is None:
            return JSONResponse(
                {"error": "no config — daemon started without --project-dir"},
                status_code=404,
            )
        platforms = config_payload.get("platforms", []) or []
        target_idx: int | None = None
        for idx, plat in enumerate(platforms):
            if isinstance(plat, dict) and plat.get("id") == platform_id:
                target_idx = idx
                break
        if target_idx is None:
            return JSONResponse(
                {"error": f"unknown platform_id: {platform_id}"},
                status_code=404,
            )
        # Mutate in-place + atomic-write. The validation pass through
        # GithubConfig happens implicitly by re-loading on next read;
        # for the in-memory cache we directly update the dict.
        new_platforms = list(platforms)
        new_platforms[target_idx] = {
            **new_platforms[target_idx],
            "enabled": bool(enabled),
        }
        new_payload = {**config_payload, "platforms": new_platforms}
        from forge_manager_mcp.daemon.effects.config_write import (
            atomic_write_config,
        )
        target_path = project_dir / ".claude" / "forge-config.json"
        try:
            atomic_write_config(target_path, new_payload)
        except OSError as exc:
            return JSONResponse(
                {"error": f"could not write config: {exc}"},
                status_code=500,
            )
        config_payload = new_payload
        return JSONResponse({
            "platform_id": platform_id,
            "enabled": bool(enabled),
        })

    async def enable_backend(request) -> JSONResponse:
        """A.5 / OQ1 — Operator-enable a platform (durable).

        Sets ``platforms[i].enabled = True`` in forge-config.json for
        the matching platform_id. Idempotent — re-enabling an already-
        enabled platform is a no-op write (current behavior would
        re-fire the same config bytes).

        Replaces the legacy ``POST /backends/{id}/resume`` semantics
        with config-durable storage so operator intent survives daemon
        restart. The old endpoint stays for compat during the A.5
        transition.
        """
        return await _set_backend_enabled(
            request.path_params["platform_id"], enabled=True,
        )

    async def disable_backend(request) -> JSONResponse:
        """A.5 / OQ1 — Operator-disable a platform (durable).

        Sets ``platforms[i].enabled = False`` in forge-config.json
        for the matching platform_id. Dispatched writes will skip
        this platform once dispatch-time gating ships in the focused
        A.5 follow-up.

        Replaces the legacy ``POST /backends/{id}/pause`` semantics
        with config-durable storage. The old endpoint stays for
        compat during the A.5 transition.
        """
        return await _set_backend_enabled(
            request.path_params["platform_id"], enabled=False,
        )

    # (#23 A.5 OQ1 / 3.15.0) pause_backend / resume_backend HTTP
    # endpoints RETIRED — replaced by the durable enable/disable
    # endpoints (commit fbd9c53) that round-trip through forge-
    # config.json's `enabled` flag. Operator intent survives daemon
    # restart without the in-memory PAUSED state field.

    async def publish_event(request) -> JSONResponse:
        """Accept a `{event, data}` payload and publish to the
        broadcaster (Phase D3b.4b).

        Auth-required. The MCP is the primary publisher: when an
        MCP-initiated write completes (via the MCP's own
        ReplicationManager), it POSTs an event here so the
        daemon's SSE subscribers (the UI) see it.

        Validation:
        - `event` must be a non-empty string
        - `data` must be a JSON-object (dict)
        - timestamps are server-stamped (clients can't backdate
          events — keeps the SSE timeline coherent)

        400 on validation failure; 200 on publish. Publish is
        always successful from the publisher's perspective —
        slow-subscriber overflow is handled by the broadcaster's
        FIFO-drop semantics, not surfaced to the caller.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        event_name = body.get("event")
        data = body.get("data", {})
        if not isinstance(event_name, str) or not event_name:
            return JSONResponse(
                {"error": "event must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(data, dict):
            return JSONResponse(
                {"error": "data must be a JSON object"},
                status_code=400,
            )
        # #343: publish effect in effects/events.py.
        from forge_manager_mcp.daemon.effects.events import publish
        subs = publish(broadcaster, event_name, data)

        # (#354 / D4.6) Incremental FTS5 refresh on write.completed
        # events. Best-effort: any failure (no action_log connection,
        # no canonical store path, sqlite error) is swallowed so the
        # canonical write's success isn't masked by a cache-refresh
        # bug. Full rebuild rather than incremental-by-ref because
        # the hook's ``write.completed`` payload doesn't carry the
        # changed-artifact ref today; capability 8 (HTTP-for-MCP)
        # will redesign the write boundary and at that point the ref
        # becomes available for true incremental updates.
        if event_name == "write.completed" and action_log_con is not None:
            docs_root = None
            if replication is not None:
                try:
                    docs_root = replication.canonical_store_path()
                except Exception:
                    docs_root = None
            if docs_root is not None:
                try:
                    # (#386, 3.9.0 D3.3) Use refresh_fts5_for_op when
                    # the event payload carries an operation_name —
                    # rebuilds only the affected FTS5 kind instead
                    # of the full multi-table rebuild. Pre-D3.3 every
                    # canonical write rebuilt all 4 FTS5 tables on a
                    # single-Issue change; post-D3.3, create_issue
                    # touches only issues_fts.
                    op_name = (data or {}).get("operation_name")
                    from forge_manager_mcp.daemon.action_log import (
                        refresh_fts5_for_op,
                    )
                    if op_name is not None:
                        refresh_fts5_for_op(
                            action_log_con, docs_root, op_name,
                            project_root=project_dir,
                        )
                    else:
                        # Backward-compat: payload without operation_name
                        # (legacy publishers) → full rebuild.
                        from forge_manager_mcp.daemon.action_log import (
                            rebuild_fts5,
                        )
                        rebuild_fts5(
                            action_log_con, docs_root,
                            project_root=project_dir,
                        )
                except Exception:
                    pass

        return JSONResponse({"published": True, "subscribers": subs})

    async def events(request) -> StreamingResponse:
        """SSE channel (Phase D3b.2).

        Long-lived ``text/event-stream`` connection. The skeleton
        emits a ``hello`` event on connect + heartbeats every 15s
        of silence. D3b.4+ wires concrete event publishers
        (backend status changes, write completions, backfill
        progress).

        Auth-required per the middleware. Browsers' EventSource
        cannot send custom headers, so the UI's auth-cookie boot
        flow (RFC #5 OQ6) sets a cookie that the middleware
        accepts as an alternative to Bearer; that cookie support
        lands in D-UI's auth-cookie wiring.
        """
        return StreamingResponse(  # pragma: no cover — SSE streaming response; TestClient blocks on the open connection so this constructor isn't reachable from the import-driven test harness. Live exercise only.
            stream_events(broadcaster),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",  # disable nginx-style buffering
            },
        )

    async def auth_bootstrap(request):
        """Hand the auth token to a browser client via cookie (#334).

        Auth-free at the middleware layer (in DEFAULT_UNAUTH_PATHS)
        because this IS the bootstrap. Origin-restricted to
        localhost — an external attacker can't reach this endpoint
        to harvest the token.

        Cookie attributes:
        * ``HttpOnly`` — JS in the static bundle can't read it; XSS
          can't exfiltrate the token.
        * ``Secure`` — won't travel over plain HTTP if the daemon
          ever fronts behind TLS. Modern browsers honor Secure on
          plain-HTTP localhost (Chrome / Firefox both treat
          127.0.0.1 + localhost as a secure context).
        * ``SameSite=Strict`` — cross-origin sites can't trigger
          authenticated requests.
        * ``Path=/`` — cookie travels with every request to the
          daemon's surface, including SSE.

        Returns 204 No Content on success; 403 from a non-localhost
        origin.
        """
        from forge_manager_mcp.daemon.auth import (
            AUTH_COOKIE_NAME,
            is_localhost_request,
        )
        if not is_localhost_request(request):
            return JSONResponse(
                {"error": "bootstrap requires localhost origin"},
                status_code=403,
            )
        response = Response(status_code=204)
        response.set_cookie(
            key=AUTH_COOKIE_NAME,
            value=auth_token,
            httponly=True,
            secure=True,
            samesite="strict",
            path="/",
        )
        return response

    async def get_alerts(request) -> JSONResponse:
        """List retained alerts (Phase D3b.4o / #341).

        Query params:
            ``since=<iso-ts>`` — only alerts with timestamp > since
            ``level=<min>`` — minimum severity (info/warning/error/
                critical)
            ``limit=<int>`` — cap on returned entries

        Returns ``{"alerts": [...], "total_count": <N>,
        "truncated": <bool>}`` newest-first; each entry per
        ``alert_to_dict``. ``total_count`` is the count of all
        matching rows (under ``since``/``level``) BEFORE the limit
        cap; ``truncated`` is True iff a limit applied and
        ``len(alerts) < total_count``. (#488 / 3.14.0) Callers use
        the metadata to surface "N more alerts" indicators without
        having to poll uncapped.

        When the daemon has no alert log configured (factory called
        without one), returns ``{"alerts": [], "total_count": 0,
        "truncated": false}`` so the MCP's polling path is graceful.
        """
        if alert_log is None:
            return JSONResponse({
                "alerts": [], "total_count": 0, "truncated": False,
            })
        from datetime import datetime as _dt
        from forge_manager_mcp.daemon.alerts import alert_to_dict

        since_raw = request.query_params.get("since")
        level = request.query_params.get("level")
        limit_raw = request.query_params.get("limit")
        since = None
        if since_raw:
            try:
                since = _dt.fromisoformat(since_raw)
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid since timestamp: {since_raw!r}"},
                    status_code=400,
                )
        limit = None
        if limit_raw:
            try:
                limit = int(limit_raw)
                if limit <= 0:
                    raise ValueError("limit must be positive")
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid limit: {limit_raw!r}"},
                    status_code=400,
                )
        # (#488 / 3.14.0) Compute total_count via uncapped recent() so
        # the response can surface "more alerts exist" metadata. The
        # uncapped query reuses the same since + level filters; the
        # cost is one extra read against the events table (cheap; the
        # events_timestamp_idx covers the since predicate). Limit is
        # then applied via a second recent() call so the response
        # body itself stays bounded.
        all_entries = alert_log.recent(
            since=since, level_at_least=level, limit=None,
        )
        total_count = len(all_entries)
        if limit is not None and total_count > limit:
            entries = all_entries[:limit]
            truncated = True
        else:
            entries = all_entries
            truncated = False
        return JSONResponse({
            "alerts": [alert_to_dict(a) for a in entries],
            "total_count": total_count,
            "truncated": truncated,
        })

    async def post_alert(request) -> JSONResponse:
        """Accept an MCP-published alert (Phase D3b.4o / #341).

        The MCP uses this to surface its own concerns (version
        mismatch detected at probe time, daemon-spawn fallthrough)
        into the same retained log the UI sees. Auth-required.

        Body: JSON with the alert_to_dict shape. ``alert_from_dict``
        tolerates partial payloads — missing level → "info",
        missing timestamp → now.

        Dual-publishes to the broadcaster (live) + log (retained).
        """
        if alert_log is None:
            return JSONResponse(
                {"error": "daemon has no alert log"},
                status_code=503,
            )
        try:
            payload = await request.json()
        except Exception as exc:
            return JSONResponse(
                {"error": f"invalid JSON: {exc}"},
                status_code=400,
            )
        if not isinstance(payload, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.alerts import alert_from_dict
        from forge_manager_mcp.daemon.events import publish_alert
        alert = alert_from_dict(payload)
        publish_alert(broadcaster, alert_log, alert)
        return JSONResponse({"published": True})

    async def credentials(request) -> JSONResponse:
        """Per-platform credential diagnostics (Phase D3b.4e / #331).

        Returns ``{"credentials": [{platform_id, has_credential,
        source}, ...]}`` where ``source`` is one of
        ``"encrypted_store"`` / ``"env"`` / ``"missing"`` /
        ``"error"``. **Never returns the token itself** — operator
        UI uses this to render presence indicators without exposing
        secrets to the browser.

        Returns ``{"loaded": False, "reason": "..."}`` when the
        daemon was started without ``--project-dir`` (no platforms
        to report on) or without ``--state-dir`` (no place to
        check for an encrypted store).

        Auth-required per the middleware.
        """
        if state_dir is None or platform_ids is None:
            return JSONResponse({
                "loaded": False,
                "reason": (
                    "daemon has no state-dir or platform list "
                    "(was --project-dir passed?)"
                ),
            })
        from forge_manager_mcp.daemon.credentials import credential_status
        return JSONResponse({
            "credentials": credential_status(state_dir, platform_ids),
        })

    async def put_credential(request) -> JSONResponse:
        """Write or update one platform's token (#313 cap 3 / D6).

        Body: ``{"token": "<plaintext>"}``. Loads the existing
        encrypted store, sets ``platform_id → token``, atomic-writes
        back. The token is also pushed into ``os.environ`` under
        the platform's canonical env-var name so the daemon's
        already-running ReplicationManager picks it up on the next
        write/read without a restart.

        404 when the daemon has no state-dir.
        400 when the body is invalid or the token is empty.
        """
        if state_dir is None:
            return JSONResponse(
                {"error": "daemon has no state-dir"}, status_code=404,
            )
        platform_id = request.path_params["platform_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        token = body.get("token", "")
        if not isinstance(token, str) or not token.strip():
            return JSONResponse(
                {"error": "token must be a non-empty string"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.credentials import (
            CredentialsError, env_var_for, set_credential,
        )
        try:
            set_credential(state_dir, platform_id, token)
        except CredentialsError as exc:
            return JSONResponse(
                {"error": str(exc)}, status_code=400,
            )
        # Live-promote to env so the running ReplicationManager
        # adapter dispatcher picks up the new value next request.
        var = env_var_for(platform_id)
        if var is not None:
            import os
            os.environ[var] = token
        return JSONResponse({"platform_id": platform_id, "stored": True})

    async def delete_credential(request) -> JSONResponse:
        """Remove one platform's token from the encrypted store
        (#313 cap 3 / D6).

        Atomic-writes the trimmed map back. Also unsets the
        corresponding ``os.environ`` entry so subsequent
        ReplicationManager calls see the credential as absent.

        404 when the daemon has no state-dir.
        Returns ``{platform_id, removed: bool}`` — `removed=False`
        when the platform had no entry (no-op).
        """
        if state_dir is None:
            return JSONResponse(
                {"error": "daemon has no state-dir"}, status_code=404,
            )
        platform_id = request.path_params["platform_id"]
        from forge_manager_mcp.daemon.credentials import (
            delete_credential as do_delete, env_var_for,
        )
        removed = do_delete(state_dir, platform_id)
        if removed:
            var = env_var_for(platform_id)
            if var is not None:
                import os
                os.environ.pop(var, None)
        return JSONResponse(
            {"platform_id": platform_id, "removed": removed},
        )

    async def post_write(request) -> JSONResponse:
        """Dispatch a canonical write through the daemon (Phase D5 /
        #355 / capability 8).

        Body: ``{"op": <op_name>, "args": <op-specific dict>}``.
        Looks up the op in ``daemon.writes._OP_REGISTRY``; 400 if
        unknown. Calls the handler with the daemon's
        ``replication`` manager + the args dict; serializes the
        ``WriteResult`` envelope back to JSON.

        Returns ``{value: <op-result>, mirror_warnings: [...]}``.

        503 when the daemon was started without a replication
        manager (no --project-dir or pre-bootstrap mode).

        500 on any handler exception — body carries the error
        type + message so the MCP can wrap it into an
        ``OperationError`` envelope without parsing.

        Per #355 OQ3 closure: this handler also publishes a
        ``write.completed`` event to the broadcaster on success,
        moving that side-effect from the MCP to the daemon
        (matches "daemon owns state → daemon owns the event").
        """
        if replication is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no replication manager — was "
                        "--project-dir passed? Pre-bootstrap mode "
                        "rejects writes."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        op_name = body.get("op")
        args = body.get("args", {})
        if not isinstance(op_name, str) or not op_name:
            return JSONResponse(
                {"error": "op must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(args, dict):
            return JSONResponse(
                {"error": "args must be a JSON object"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.writes import get_handler
        handler = get_handler(op_name)
        if handler is None:
            return JSONResponse(
                {
                    "error": f"unknown write op: {op_name!r}",
                    "op": op_name,
                },
                status_code=400,
            )
        try:
            result = await handler(replication, args)
        except Exception as exc:
            # (#513, 3.16.0 D0) Rich error envelope preserves the
            # original exception's status_code + body so the MCP-side
            # is_permanent_error predicate can classify the failure.
            # Pre-#513 the response dropped status_code/body and the
            # 403-from-suspended-GitHub class buffered for infinite
            # retry.
            return JSONResponse(
                _build_op_error_envelope(exc, op_name),
                status_code=500,
            )

        # (A.2.10 / 3.15.0 / #23) Dual-write into canonical-DB
        # after the filesystem-canonical write succeeded. Best-
        # effort per OQ8 — failures attach as warnings on the
        # response envelope; the filesystem write already
        # succeeded, so the operator's call still succeeds.
        try:
            from forge_manager_mcp.daemon import canonical_db_dispatch
            cdb_warning = canonical_db_dispatch.dispatch_after_write(
                op_name, args, result,
            )
            if cdb_warning is not None:
                # Attach to mirror_warnings list (existing wire-shape)
                # with a synthetic platform_id so MCP-side consumers
                # surface it uniformly.
                if isinstance(result, dict):
                    warnings_list = result.setdefault("mirror_warnings", [])
                    if isinstance(warnings_list, list):
                        warnings_list.append({
                            "platform_id": "canonical_db",
                            "operation": op_name,
                            "error_type": "CanonicalDBWriteFailed",
                            "error_message": cdb_warning,
                        })
        except Exception:  # pragma: no cover - defensive
            pass

        # (#355 OQ3) Publish write.completed daemon-side. Best-
        # effort — broadcaster failure must not poison the
        # already-succeeded canonical write.
        try:
            from forge_manager_mcp.daemon.effects.events import publish
            publish(broadcaster, "write.completed", {
                "operation_name": op_name,
            })
        except Exception:
            pass

        return JSONResponse(result)

    async def post_read(request) -> JSONResponse:
        """(#356, 3.7.0 D8) Dispatch a canonical read through the daemon.

        Mirrors ``post_write``: body ``{"op": <op_name>, "args": <op-
        specific dict>}``; looks up the op in
        ``daemon.reads._READ_OP_REGISTRY``; calls the handler with
        the daemon's ``replication`` manager + the args dict.

        Wire-shape: ``{value: <op-result>}`` (reads don't generate
        ``mirror_warnings`` — read failover is silent per
        ``ReplicationManager.read``'s existing contract).

        503 when no replication manager. 400 on bad input or
        unknown op. 500 on handler exception (mirrored from
        ``post_write``).

        Per #356 OQ1 closure: failures propagate. Read paths that
        need graceful degradation handle it case-by-case at the
        MCP-side ``dispatch_read`` boundary.
        """
        if replication is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no replication manager — was "
                        "--project-dir passed? Pre-bootstrap mode "
                        "rejects reads."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        op_name = body.get("op")
        args = body.get("args", {})
        if not isinstance(op_name, str) or not op_name:
            return JSONResponse(
                {"error": "op must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(args, dict):
            return JSONResponse(
                {"error": "args must be a JSON object"},
                status_code=400,
            )

        # (A.3.2 / 3.15.0 / #23) Try canonical-DB read-dispatch
        # first per OQ8 (both-authoritative transition / reads
        # consult DB first, fall back to filesystem). If the DB
        # has the row, short-circuit the existing FS read. On
        # miss / handler-not-registered / error, fall through.
        try:
            from forge_manager_mcp.daemon import (
                canonical_db_read_dispatch,
            )
            db_result = canonical_db_read_dispatch.dispatch_read(
                op_name, args,
            )
            if db_result is not None:
                return JSONResponse(db_result)
        except Exception:  # pragma: no cover - defensive
            pass

        from forge_manager_mcp.daemon.reads import get_handler
        handler = get_handler(op_name)
        if handler is None:
            return JSONResponse(
                {
                    "error": f"unknown read op: {op_name!r}",
                    "op": op_name,
                },
                status_code=400,
            )
        try:
            result = await handler(replication, args)
        except Exception as exc:
            # (#513, 3.16.0 D0) Same rich envelope as post_write.
            return JSONResponse(
                _build_op_error_envelope(exc, op_name),
                status_code=500,
            )
        return JSONResponse(result)

    async def search_local(request) -> JSONResponse:
        """Full-text search across canonical Issues / Discussions /
        Sessions / code files (Phase D4.5 / #354; D3.1 / #384 added
        ``code`` kind for code-content FTS).

        Query params:
            ``q`` — FTS5 MATCH query string. Required.
            ``kind`` — optional filter; one of ``issue``,
                ``discussion``, ``session``, ``code``. Omitted =
                union all.
            ``limit`` — cap on returned hits (default 50).

        Returns the shaped envelope:

            {
              "results": [
                {"kind": "issue", "ref_native_id": "...", "title": "...", "snippet": "..."},
                ...
              ],
              "total_count": <int>,
              "query": "<echo-back>"
            }

        ``snippet`` uses sqlite's FTS5 ``snippet()`` function to
        return a 32-token contextual snippet around the match.
        Sessions have no title field; their ``title`` is empty.

        Returns 503 when the daemon was started without an
        action_log connection.
        """
        import sqlite3
        if action_log_con is None:
            return JSONResponse(
                {"error": "daemon has no action-log connection"},
                status_code=503,
            )
        q = request.query_params.get("q", "").strip()
        if not q:
            return JSONResponse(
                {"error": "query parameter 'q' is required"},
                status_code=400,
            )
        kind = request.query_params.get("kind")
        limit_raw = request.query_params.get("limit")
        limit = 50
        if limit_raw:
            try:
                limit = int(limit_raw)
                if limit <= 0:
                    raise ValueError("limit must be positive")
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid limit: {limit_raw!r}"},
                    status_code=400,
                )

        results: list[dict] = []
        per_kind_limit = limit  # cap per query; final list may be less

        def _search(
            table: str, kind_label: str, *,
            id_col: str = "ref_native_id",
            has_title: bool = True,
        ) -> None:
            """Run one FTS5 query against ``table`` + append hits.

            ``id_col`` names the UNINDEXED column that uniquely
            identifies the row — ``ref_native_id`` for issues_fts /
            discussions_fts, ``session_id`` for sessions_fts,
            ``path`` for code_fts (#384, 3.9.0 D3.1).
            """
            try:
                title_clause = "title, " if has_title else ""
                sql = (
                    f"SELECT {id_col} AS ref_native_id, {title_clause}"
                    f"snippet({table}, -1, '<mark>', '</mark>', '...', 32) AS snippet "
                    f"FROM {table} WHERE {table} MATCH ? "
                    f"LIMIT ?"
                )
                cur = action_log_con.execute(sql, (q, per_kind_limit))
                for row in cur:
                    entry: dict = {
                        "kind": kind_label,
                        "ref_native_id": row["ref_native_id"],
                        "snippet": row["snippet"],
                    }
                    entry["title"] = row["title"] if has_title else ""
                    results.append(entry)
            except sqlite3.OperationalError:
                # Malformed FTS5 query → skip this table; let the
                # caller see whatever did parse.
                pass

        if kind in (None, "issue"):
            _search("issues_fts", "issue")
        if kind in (None, "discussion"):
            _search("discussions_fts", "discussion")
        if kind in (None, "session"):
            _search(
                "sessions_fts", "session",
                id_col="session_id", has_title=False,
            )
        if kind in (None, "code"):
            # (#384, 3.9.0 D3.1) Code hits use the file path as the
            # ref_native_id; UI maps to /files/content?path=<path>.
            _search(
                "code_fts", "code",
                id_col="path", has_title=False,
            )

        # Apply final cross-kind limit.
        results = results[:limit]
        return JSONResponse({
            "results": results,
            "total_count": len(results),
            "query": q,
        })

    async def get_commands(request) -> JSONResponse:
        """(3.10.0 D3) GET /commands — return the loaded text-grammar
        registry as JSON for the UI omnibar's autocomplete + help
        rendering.

        Each command is serialized as
        ``{verb, noun, summary, args, dispatch_kind, mutating}``
        — enough for the omnibar to:

        * suggest noun-verb pairs as the operator types,
        * render argument hints,
        * decide whether to run a confirmation modal (mutating
          commands per #392 G5).

        Response: ``{commands: [...], schema_version: "3.10.0"}``.

        Returns 404 if commands.yaml is absent (greenfield project
        without scaffolded skill prose).
        """
        if project_dir is None:
            return JSONResponse(
                {"error": (
                    "daemon was started without --project-dir; "
                    "commands.yaml not in scope"
                )},
                status_code=503,
            )
        commands_path = (
            project_dir / ".claude" / "skills" / "forge-manager"
            / "commands.yaml"
        )
        if not commands_path.exists():
            return JSONResponse(
                {"error": f"commands.yaml not found at {commands_path}"},
                status_code=404,
            )
        from forge_manager_mcp.command_registry import (
            CommandRegistryError, load_commands,
        )
        try:
            registry = load_commands(commands_path)
        except CommandRegistryError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=500,
            )

        # Mutating-command heuristic: any command whose verb belongs
        # to a small set of mutating-shaped verbs gets flagged. The
        # operator-facing UX is "show confirm modal before
        # dispatching." Read-only verbs (search, show, list, open,
        # help) bypass the modal and run directly.
        MUTATING_VERBS = frozenset({
            "add", "create", "close", "open-issue", "delete",
            "update", "edit", "move", "mark-decided", "merge",
            "release", "publish", "tag",
        })

        commands_out: list = []
        # Use a dict to dedupe — aliases register multiple keys but
        # point to the same Command instance.
        seen_keys: set = set()
        for (key_verb, key_noun), cmd in registry._by_key.items():
            canonical_key = (cmd.verb, cmd.noun)
            if canonical_key in seen_keys:
                continue
            seen_keys.add(canonical_key)
            dispatch_kind = (
                "ui_route" if cmd.ui_route is not None
                else ("daemon" if cmd.daemon_endpoint is not None
                      else "mcp_tool")
            )
            commands_out.append({
                "verb": cmd.verb,
                "noun": cmd.noun,
                "summary": cmd.summary,
                "args": [
                    {
                        "name": a.name,
                        "type": a.type,
                        "positional": a.positional,
                        "required": a.required,
                    } for a in cmd.args
                ],
                "dispatch_kind": dispatch_kind,
                "mutating": cmd.verb in MUTATING_VERBS,
                "introduced_in": cmd.introduced_in,
            })
        # Stable sort by (noun, verb) for deterministic UI rendering.
        commands_out.sort(key=lambda c: (c["noun"], c["verb"]))

        return JSONResponse({
            "commands": commands_out,
            "schema_version": "3.10.0",
        })

    async def post_command(request) -> JSONResponse:
        """(#387, 3.9.0 D4.4) POST /command — text-grammar dispatch
        from the daemon side.

        Mirrors the MCP-side ``run_command`` tool: parse via
        ``commands.yaml`` registry, route to the resolved dispatch
        surface. The daemon-side variant is the execution surface
        the Cmd-K UI palette posts to (#13 §"Surface-by-surface
        dispatch").

        Routing differences from MCP:
          * ``daemon_endpoint`` commands → call ourselves over
            localhost HTTP (uvicorn handles concurrent self-calls
            fine; recursion depth is bounded to 1 since the inner
            call hits a non-/command endpoint).
          * ``ui_route`` commands → return the rendered route as
            data; UI consumer follows it.
          * ``mcp_tool`` commands → return a hint pointing at the
            typed MCP tool; daemon can't invoke MCP tools.
          * ``/help`` → in-line meta handler reads the registry.

        Body: ``{"command": "<raw text>"}``.
        Response shape mirrors run_command's: ``kind`` ∈ {help,
        ui_route, daemon, mcp_tool_hint, error}.
        """
        import json as _json
        try:
            body = await request.json()
        except _json.JSONDecodeError:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        raw = (body or {}).get("command", "")
        if not isinstance(raw, str):
            return JSONResponse(
                {"error": "command field must be a string"},
                status_code=400,
            )
        if project_dir is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon was started without --project-dir; "
                        "commands.yaml not in scope"
                    ),
                    "command": raw,
                },
                status_code=503,
            )
        commands_path = (
            project_dir / ".claude" / "skills" / "forge-manager"
            / "commands.yaml"
        )
        if not commands_path.exists():
            return JSONResponse(
                {
                    "error": (
                        f"commands.yaml not found at {commands_path}"
                    ),
                    "command": raw,
                },
                status_code=404,
            )
        from forge_manager_mcp.command_registry import (
            CommandRegistryError, load_commands, parse_command,
        )
        try:
            registry = load_commands(commands_path)
            parsed = parse_command(raw, registry)
        except CommandRegistryError as exc:
            return JSONResponse(
                {"error": str(exc), "command": raw},
                status_code=400,
            )

        cmd = parsed.command

        def _publish_executed(payload: dict) -> None:
            """(#387, 3.9.0 D4.6) Publish ``command.executed`` event.

            Best-effort — broadcaster failure must not poison the
            already-dispatched command. Subscribers (UI palette
            history, action_log capture, external SSE consumers)
            see the operator-typed string + the resolved kind.
            """
            try:
                from forge_manager_mcp.daemon.effects.events import publish
                publish(broadcaster, "command.executed", {
                    "command": raw,
                    "kind": payload.get("kind"),
                    "verb": cmd.verb,
                    "noun": cmd.noun,
                })
            except Exception:
                pass

        # Inline /help handler.
        if cmd.verb == "help":
            target_verb = (
                parsed.positional[0] if parsed.positional else None
            )
            if target_verb is None:
                payload = {
                    "kind": "help",
                    "verbs": registry.list_verbs(),
                    "command": raw,
                }
                _publish_executed(payload)
                return JSONResponse(payload)
            matches = [
                {"verb": c.verb, "noun": c.noun, "summary": c.summary}
                for c in registry.list_for_verb(target_verb)
            ]
            payload = {
                "kind": "help",
                "verb": target_verb,
                "commands": matches,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # ui_route — return the rendered fragment as data.
        if cmd.ui_route is not None and cmd.daemon_endpoint is None:
            rendered = parsed.substitute(cmd.ui_route)
            payload = {
                "kind": "ui_route",
                "route": rendered,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # daemon_endpoint — recursive localhost dispatch.
        if cmd.daemon_endpoint is not None:
            method, _, path = cmd.daemon_endpoint.partition(" ")
            params_raw = parsed.substitute(cmd.daemon_params_json or "{}")
            try:
                params = _json.loads(params_raw)
            except _json.JSONDecodeError as exc:
                return JSONResponse({
                    "error": (
                        f"daemon_params_json template did not render to "
                        f"valid JSON: {exc}"
                    ),
                    "rendered": params_raw,
                    "command": raw,
                }, status_code=500)
            # Recursive self-call. The auth header from this request
            # is reused — the inner call has the same Bearer token
            # as the operator's POST.
            auth = request.headers.get("Authorization", "")
            base = f"http://127.0.0.1:{request.url.port}{path}"
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    if method.upper() == "GET":
                        resp = await client.get(
                            base,
                            headers={"Authorization": auth},
                            params={k: str(v) for k, v in params.items()},
                        )
                    else:
                        resp = await client.request(
                            method, base,
                            headers={"Authorization": auth},
                            json=params,
                        )
            except httpx.HTTPError as exc:
                return JSONResponse({
                    "error": f"daemon self-dispatch failed: {exc}",
                    "command": raw,
                }, status_code=500)
            try:
                inner_body = resp.json()
            except _json.JSONDecodeError:
                inner_body = {"raw": resp.text}
            payload = {
                "kind": "daemon",
                "endpoint": cmd.daemon_endpoint,
                "status_code": resp.status_code,
                "result": inner_body,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # mcp_tool-only — surface the typed tool name.
        payload = {
            "kind": "mcp_tool_hint",
            "tool_name": cmd.mcp_tool,
            "args_template": cmd.mcp_args_json,
            "args_rendered": parsed.substitute(cmd.mcp_args_json or "{}"),
            "message": (
                f"This command dispatches via the typed MCP tool "
                f"{cmd.mcp_tool!r}. The daemon cannot invoke MCP tools "
                f"directly; call the tool via your MCP client."
            ),
            "command": raw,
        }
        _publish_executed(payload)
        return JSONResponse(payload)

    routes: list = [
        Route("/health", health, methods=["GET"]),
        # (#469) Readiness probe — distinct from /health (liveness).
        # ready=True only after startup-probe + credentials + canonical-
        # reconciler are wired. MCP polls this after auto-restart so
        # audit / fan-out doesn't race the bind→ready gap.
        Route("/health/ready", health_ready, methods=["GET"]),
        Route("/auth/bootstrap", auth_bootstrap, methods=["GET"]),
        Route("/whoami", whoami, methods=["GET"]),
        Route("/config", config, methods=["GET"]),
        Route("/config", write_config, methods=["POST"]),
        Route(
            "/setup/scaffold", setup_scaffold, methods=["POST"],
        ),
        Route("/backends", backends, methods=["GET"]),
        Route("/credentials", credentials, methods=["GET"]),
        Route(  # (#313 cap 3 / D6)
            "/credentials/{platform_id}",
            put_credential, methods=["PUT", "POST"],
        ),
        Route(  # (#313 cap 3 / D6)
            "/credentials/{platform_id}",
            delete_credential, methods=["DELETE"],
        ),
        Route(  # (#366 / 3.8.0 D6 / Theme F)
            "/credentials/{platform_id}/test",
            test_credential_endpoint, methods=["POST"],
        ),
        Route("/alerts", get_alerts, methods=["GET"]),
        Route("/alerts", post_alert, methods=["POST"]),
        Route("/files/tree", files_tree, methods=["GET"]),
        Route("/files/content", files_content, methods=["GET"]),
        Route("/repos", repos, methods=["GET"]),  # (#351, 3.7.0 D5)
        Route("/gates", gates_endpoint, methods=["GET"]),
        # (#501) Mode registry endpoints — status-display mode picker.
        Route("/modes", list_modes_endpoint, methods=["GET"]),
        Route(
            "/modes/current", current_mode_endpoint, methods=["GET"],
        ),
        Route(
            "/modes/{name}", apply_mode_endpoint, methods=["POST"],
        ),
        Route("/findings", findings_endpoint, methods=["GET"]),
        # (#398 D4 / 3.11.0 D3.d) Milestone compound-doc table source.
        Route("/milestones", milestones_endpoint, methods=["GET"]),
        # (#406 / 3.11.0 D3.d sibling) Gap compound-doc table source.
        Route("/gaps", gaps_endpoint, methods=["GET"]),
        # (3.11.0 D3.d) Session compound-doc table source.
        Route("/sessions", sessions_endpoint, methods=["GET"]),
        # (#402 MVP / 3.11.0 D5) Live operator-state for HeaderStatus.
        Route("/session/state", session_state_endpoint, methods=["GET"]),
        # (Discussion #24 Phase 3) Swimlane composition source.
        Route("/swimlanes", swimlanes_endpoint, methods=["GET"]),
        # (#493 successor / 3.16.0 D1 / A.1) Initial-state probe for
        # the UI's <MigrationSwimlane>. SSE live updates land on
        # /events under the migration.* event vocabulary.
        Route(
            "/migrations/status", migrations_status_endpoint,
            methods=["GET"],
        ),
        # (3.16.0 D1 / A.1 write-back) MCP-side mutation surface for
        # in-flight migration state. Used by the migrate_to_*
        # handler write-back to upsert at chain start, flip step
        # state per interceptor, remove on completion grace.
        Route(
            "/migrations/upsert", migrations_upsert_endpoint,
            methods=["POST"],
        ),
        Route(
            "/migrations/{migration_id}/step/{step_id}",
            migrations_step_state_endpoint, methods=["POST"],
        ),
        Route(
            "/migrations/{migration_id}", migrations_remove_endpoint,
            methods=["DELETE"],
        ),
        # (3.16.0 D1 / A.2) Initial-state probe for the UI's
        # <ReleaseSwimlane>. SSE live updates land on /events under
        # the release.* event vocabulary.
        Route(
            "/release/status", release_status_endpoint,
            methods=["GET"],
        ),
        # (3.16.0 D5 / session-rotation gate-card) Most-recent
        # phase-boundary trigger surfaced from history_log_facts.
        # UI's session-rotation gate-card renders the trigger as
        # a "rotation opportunity detected" affordance.
        Route(
            "/session-rotation/last-trigger",
            session_rotation_last_trigger_endpoint,
            methods=["GET"],
        ),
        # (3.16.0 D5) Public-issue triage classifier per-Issue
        # primitive. Operator-driven bulk-classify (iterate open
        # public-mirror Issues) wraps this endpoint in an MCP
        # tool.
        Route(
            "/triage/classify",
            triage_classify_endpoint,
            methods=["POST"],
        ),
        # (3.16.0 D1 / A.2 write-back) MCP-side mutation surface for
        # in-flight release state. Mirror of /migrations/* writes.
        Route(
            "/release/upsert", release_upsert_endpoint,
            methods=["POST"],
        ),
        Route(
            "/release/{release_id}/step/{step_id}",
            release_step_state_endpoint, methods=["POST"],
        ),
        Route(
            "/release/{release_id}", release_remove_endpoint,
            methods=["DELETE"],
        ),
        # (Discussion #23 A.5.6 / Cluster G) Manual triage scan trigger.
        Route(
            "/triage/scan-now", triage_scan_now, methods=["POST"],
        ),
        Route("/upgrade/status", upgrade_status, methods=["GET"]),
        Route(
            "/upgrade/execute/{step}", upgrade_execute,
            methods=["POST"],
        ),
        # (#23 A.5 OQ1 / 3.15.0) /pause + /resume routes RETIRED;
        # /enable + /disable round-trip durable config instead.
        Route(
            "/backends/{platform_id}/enable", enable_backend, methods=["POST"],
        ),
        Route(
            "/backends/{platform_id}/disable", disable_backend, methods=["POST"],
        ),
        Route("/events", events, methods=["GET"]),
        Route("/events", publish_event, methods=["POST"]),
        Route("/search", search_local, methods=["GET"]),
        # (#475 / 3.14.0) Per-table bitemporal shadow accessor.
        Route("/shadow/{table}", shadow_endpoint, methods=["GET"]),
        Route("/writes", post_write, methods=["POST"]),
        Route("/reads", post_read, methods=["POST"]),  # (#356, 3.7.0 D8)
        Route("/command", post_command, methods=["POST"]),  # (#387, 3.9.0 D4.4)
        Route("/commands", get_commands, methods=["GET"]),  # (3.10.0 D3)
    ]
    # The static mount goes LAST so /health (and future API routes)
    # match before the catch-all static handler.
    if ui_dist is not None:
        routes.append(
            Mount(
                "/",
                app=StaticFiles(directory=str(ui_dist), html=True),
                name="ui",
            )
        )

    middleware = [
        Middleware(BearerTokenMiddleware, expected_token=auth_token),
    ]
    app = Starlette(routes=routes, middleware=middleware)
    # (#469) Initialize readiness flag to False. ``daemon/main.py``
    # flips it True after credentials + replication + startup-probe
    # + canonical-reconciler tasks are scheduled — that's the
    # ready-to-serve contract. Direct factory callers (tests that
    # construct ``make_app`` standalone) keep ready=False; tests
    # exercise the flip explicitly when they need to.
    app.state.ready = False
    return app
