"""Canonical-DB dual-write dispatch (3.15.0 cluster A.2.10).

Per Discussion #23 OQ8 (both-authoritative transition) +
operator decision 2026-05-15 (best-effort with warning when the
canonical-DB write fails after the filesystem write succeeds).

This module wires the daemon's ``POST /writes`` endpoint to the
canonical-DB write helpers (A.2.1-A.2.8). After the canonical
filesystem write succeeds, :func:`dispatch_after_write` looks up
the op's canonical-DB handler, calls it with the original args +
the result envelope, and returns either ``None`` (success or no
mapping registered) or a warning string the http layer attaches
to the response.

Module-level singleton ``_CONNECTION`` is set by daemon startup
(:func:`set_connection`) and reset for tests
(:func:`reset_connection`). Mirrors the shadow.registry pattern.

A.2.10 ships ``create_issue`` as the reference op handler. A.2.11+
add the rest of the write surface. A.2.12 adds gap + milestone ops
(``upsert_gap`` / ``update_gap_state`` / ``create_milestone`` /
``update_milestone_state``).
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from typing import Any, Callable


# A canonical-DB op handler: takes (connection, args, result_envelope).
# Returns None on success; raises on failure (caller catches).
OpHandler = Callable[[sqlite3.Connection, dict, dict], None]


_CONNECTION: sqlite3.Connection | None = None
"""Process-global canonical-DB connection. Set by daemon startup
:func:`set_connection`; reset by tests via :func:`reset_connection`.
None means canonical-DB is unavailable (pre-bootstrap project / docs
repo unresolvable / A.2.9 init skipped). When None,
:func:`dispatch_after_write` is a no-op."""


_REGISTRY: dict[str, OpHandler] = {}
"""Op-name → canonical-DB handler. Populated by ``@register``
decorator calls at module import time."""


_log = logging.getLogger(__name__)


def register(op_name: str):
    """Decorator: register a canonical-DB handler for an op_name."""
    def deco(fn: OpHandler) -> OpHandler:
        _REGISTRY[op_name] = fn
        return fn
    return deco


def get_handler(op_name: str) -> OpHandler | None:
    """Look up the registered handler. Returns None when no handler."""
    return _REGISTRY.get(op_name)


def all_ops() -> list[str]:
    """Return registered op names, sorted."""
    return sorted(_REGISTRY.keys())


def set_connection(conn: sqlite3.Connection | None) -> None:
    """Set the daemon-wide canonical-DB connection.

    Called by daemon/main.py after :func:`canonical_db_init.startup`
    succeeds. None when init skipped.
    """
    global _CONNECTION
    _CONNECTION = conn


def reset_connection() -> None:
    """Reset the module-level connection. Tests call this in teardown."""
    global _CONNECTION
    _CONNECTION = None


def dispatch_after_write(op_name: str, args: dict, result: dict) -> str | None:
    """Run the canonical-DB write for an op after the filesystem write
    succeeded.

    Returns ``None`` on success or no-op (no handler registered /
    no connection / handler-internal skip). Returns a warning string
    when the handler raised — caller attaches it to the HTTP
    response envelope so operators see what was missed.

    Per OQ8 best-effort semantics: this function NEVER raises. The
    filesystem write already succeeded; any canonical-DB failure is
    transition-window degradation, not operator-facing error.
    """
    if _CONNECTION is None:
        return None
    handler = _REGISTRY.get(op_name)
    if handler is None:
        return None
    try:
        handler(_CONNECTION, args, result)
    except Exception as exc:  # pragma: no cover - defensive log
        _log.warning(
            "canonical_db_dispatch %s failed: %s", op_name, exc,
        )
        return f"canonical_db {op_name} failed: {exc!r}"
    return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    """ISO-8601 UTC timestamp ending in '+00:00'."""
    return datetime.now(timezone.utc).isoformat()


def _extract_number(result: dict) -> int | None:
    """Extract the canonical issue/discussion number from a write result.

    Handlers serialize the typed artifact via ``model_dump(mode='json')``;
    the result envelope is ``{value: <dict>, mirror_warnings: [...]}``.
    The number is in ``value.ref.number`` for Issues / Discussions.
    """
    value = result.get("value")
    if not isinstance(value, dict):
        return None
    ref = value.get("ref")
    if not isinstance(ref, dict):
        return None
    number = ref.get("number")
    return int(number) if isinstance(number, int) else None


def _parse_native_id_number(native_id: str) -> int | None:
    """Parse a ``<kind>/<n>`` native_id into the integer number.

    LocalStore convention: ``issues/123`` / ``discussions/23`` /
    ``milestones/3.15.0`` (non-numeric for milestones). Returns
    None when the suffix isn't a positive integer.
    """
    if not isinstance(native_id, str):
        return None
    _, _, suffix = native_id.rpartition("/")
    if not suffix or not suffix.isdigit():
        return None
    return int(suffix)


# ---------------------------------------------------------------------------
# Per-op handlers
# ---------------------------------------------------------------------------

@register("create_issue")
def _dispatch_create_issue(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror a create_issue canonical write into the issues +
    issue_labels tables.

    No-op when the result didn't yield a canonical number (test
    stubs / dry-run shapes). Otherwise: insert the issue row +
    one row per label. Caller commits the transaction.
    """
    from forge_manager_mcp.canonical_db import issues_writes

    number = _extract_number(result)
    if number is None:
        return
    value = result.get("value", {})
    now = _now_iso()
    title = value.get("title") or args.get("title", "")
    body = value.get("body") or args.get("body", "")
    state = value.get("state", "open")
    labels = list(value.get("labels") or args.get("labels", []))
    milestone = value.get("milestone") or args.get("milestone")
    author = value.get("author", "")
    url = value.get("url", "")
    created_at = value.get("created_at") or now
    updated_at = value.get("updated_at") or now
    issues_writes.insert_issue(
        conn,
        number=number,
        title=title,
        body=body,
        state=state,
        milestone=milestone,
        author=author,
        url=url,
        created_at=created_at,
        updated_at=updated_at,
    )
    for label in labels:
        issues_writes.add_issue_label(conn, number=number, label=label)
    conn.commit()


@register("append_comment")
def _dispatch_append_comment(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an append_comment canonical write into the comments table.

    Extracts parent_number from the args' ``parent_native_id`` (e.g.
    ``issues/123``) and inserts the comment row. The new comment's
    id is sqlite-assigned via lastrowid.
    """
    from forge_manager_mcp.canonical_db import comments_writes

    parent_number = _parse_native_id_number(args.get("parent_native_id", ""))
    if parent_number is None:
        return
    parent_kind = args.get("parent_kind", "")
    if parent_kind not in ("issue", "discussion"):
        return
    value = result.get("value") or {}
    now = _now_iso()
    body = value.get("body") or args.get("body", "")
    author = value.get("author", "")
    url = value.get("url", "")
    created_at = value.get("created_at") or now
    comments_writes.insert_comment(
        conn,
        parent_kind=parent_kind,
        parent_number=parent_number,
        body=body,
        author=author,
        url=url,
        created_at=created_at,
        updated_at=created_at,
    )
    conn.commit()


@register("create_discussion")
def _dispatch_create_discussion(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror a create_discussion canonical write into discussions +
    discussion_labels.
    """
    from forge_manager_mcp.canonical_db import discussions_writes

    number = _extract_number(result)
    if number is None:
        return
    value = result.get("value", {})
    now = _now_iso()
    title = value.get("title") or args.get("title", "")
    body = value.get("body") or args.get("body", "")
    state = value.get("state", "open")
    category = value.get("category") or args.get("category")
    decided = 1 if value.get("decided") else 0
    labels = list(value.get("labels") or [])
    author = value.get("author", "")
    url = value.get("url", "")
    created_at = value.get("created_at") or now
    discussions_writes.insert_discussion(
        conn,
        number=number,
        title=title,
        body=body,
        state=state,
        category=category,
        decided=decided,
        author=author,
        url=url,
        created_at=created_at,
        updated_at=created_at,
    )
    for label in labels:
        discussions_writes.add_discussion_label(
            conn, number=number, label=label,
        )
    conn.commit()


@register("close_issue")
def _dispatch_close_issue(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror a close_issue canonical write into the issues table.

    Translates the close to state='closed' + state_reason +
    closed_at. The native_id carries the issue number.
    """
    from forge_manager_mcp.canonical_db import issues_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return
    value = result.get("value") or {}
    now = _now_iso()
    state_reason = args.get("state_reason") or value.get("state_reason")
    closed_at = value.get("closed_at") or now
    issues_writes.update_issue_state(
        conn,
        number=number,
        state="closed",
        state_reason=state_reason,
        closed_at=closed_at,
        updated_at=closed_at,
    )
    conn.commit()


@register("update_issue_body")
def _dispatch_update_issue_body(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an update_issue_body canonical write."""
    from forge_manager_mcp.canonical_db import issues_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return
    body = args.get("body", "")
    issues_writes.update_issue_body(
        conn,
        number=number,
        body=body,
        updated_at=_now_iso(),
    )
    conn.commit()


@register("update_discussion_body")
def _dispatch_update_discussion_body(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an update_discussion_body canonical write."""
    from forge_manager_mcp.canonical_db import discussions_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return
    body = args.get("body", "")
    discussions_writes.update_discussion_body(
        conn,
        number=number,
        body=body,
        updated_at=_now_iso(),
    )
    conn.commit()


@register("update_issue_milestone")
def _dispatch_update_issue_milestone(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an update_issue_milestone canonical write."""
    from forge_manager_mcp.canonical_db import issues_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return
    milestone = args.get("milestone")
    issues_writes.update_issue_milestone(
        conn,
        number=number,
        milestone=milestone,
        updated_at=_now_iso(),
    )
    conn.commit()


@register("mark_discussion_decided")
def _dispatch_mark_discussion_decided(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror a mark_discussion_decided canonical write."""
    from forge_manager_mcp.canonical_db import discussions_writes

    number = _parse_native_id_number(args.get("native_id", ""))
    if number is None:
        return
    discussions_writes.update_discussion_decided(
        conn,
        number=number,
        decided=1,
        updated_at=_now_iso(),
    )
    conn.commit()


# ---------------------------------------------------------------------------
# A.2.12 — Gap + Milestone op handlers
# ---------------------------------------------------------------------------

def _lookup_gap_number_by_detector(
    conn: sqlite3.Connection,
    *,
    detector: str,
) -> int | None:
    """Return the existing gap row's number for a detector category, or None.

    The canonical_db gaps table uses an INTEGER ``number`` PK while the
    artifact-side ``GapArtifact`` identifies a gap by ``detector_category``
    (string). A.2.12 maps category → detector column for the lookup and
    allocates the next available number when no row exists yet.
    """
    row = conn.execute(
        "SELECT number FROM gaps WHERE detector = ? LIMIT 1",
        (detector,),
    ).fetchone()
    return int(row[0]) if row is not None else None


@register("upsert_gap")
def _dispatch_upsert_gap(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an upsert_gap canonical write into the gaps table.

    The artifact identifies a gap by ``detector_category`` (string), but
    the canonical_db gaps table is keyed by integer ``number``. We look
    up by detector first: if a row exists, no-op (the body / state
    transitions go through their own ops); if not, allocate the next
    number via ``next_gap_number`` and insert a new row in ``triage``
    state with severity + tier from the result envelope.
    """
    from forge_manager_mcp.canonical_db import gaps_writes

    value = result.get("value") or {}
    category = value.get("detector_category") or args.get("category")
    if not isinstance(category, str) or not category:
        return
    existing = _lookup_gap_number_by_detector(conn, detector=category)
    if existing is not None:
        # Idempotent: gap row already present. State + body transitions
        # land via update_gap_state / update_gap_body op handlers.
        return
    title = value.get("title") or args.get("title") or category
    severity = value.get("severity") or "info"
    tier = value.get("tier") or args.get("tier") or "advisory"
    state = value.get("state") or "triage"
    now = _now_iso()
    number = gaps_writes.next_gap_number(conn)
    gaps_writes.insert_gap(
        conn,
        number=number,
        title=title,
        detector=category,
        severity=severity,
        state=state,
        created_at=now,
        updated_at=now,
    )
    conn.commit()


@register("update_gap_state")
def _dispatch_update_gap_state(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an update_gap_state canonical write.

    Uses :func:`gaps_writes.transition_gap_state` for the atomic
    state + filed_issue_number transition (the cross-CHECK requires
    both fields move together to/from 'filed').
    """
    from forge_manager_mcp.canonical_db import gaps_writes

    category = args.get("category")
    state = args.get("state") or (result.get("value") or {}).get("state")
    if not isinstance(category, str) or not category or not state:
        return
    number = _lookup_gap_number_by_detector(conn, detector=category)
    if number is None:
        return
    # Cross-CHECK: filed_issue_number IS NOT NULL iff state == 'filed'.
    filed_issue = args.get("filed_issue")
    if state == "filed":
        if not isinstance(filed_issue, int):
            return
        filed_issue_number = filed_issue
    else:
        filed_issue_number = None
    gaps_writes.transition_gap_state(
        conn,
        number=number,
        state=state,
        filed_issue_number=filed_issue_number,
        updated_at=_now_iso(),
    )
    conn.commit()


@register("create_milestone")
def _dispatch_create_milestone(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror a create_milestone canonical write into the milestones table.

    Milestones are keyed by semver ``version`` string (not number);
    ``_extract_number`` doesn't apply. Pulls ``version`` from the result
    envelope first, falling back to args.
    """
    from forge_manager_mcp.canonical_db import milestones_writes

    value = result.get("value") or {}
    version = value.get("version") or args.get("version")
    if not isinstance(version, str) or not version:
        return
    title = value.get("title") or args.get("title") or version
    tier = value.get("tier") or args.get("tier")
    if tier not in ("major", "minor", "patch"):
        return
    state = value.get("state") or "planned"
    hotfix = 1 if (value.get("hotfix") or args.get("hotfix")) else 0
    body = args.get("body", "")
    now = _now_iso()
    milestones_writes.insert_milestone(
        conn,
        version=version,
        title=title,
        state=state,
        tier=tier,
        hotfix=hotfix,
        body=body,
        created_at=now,
        updated_at=now,
    )
    conn.commit()


@register("update_milestone_state")
def _dispatch_update_milestone_state(
    conn: sqlite3.Connection,
    args: dict,
    result: dict,
) -> None:
    """Mirror an update_milestone_state canonical write."""
    from forge_manager_mcp.canonical_db import milestones_writes

    version = args.get("version") or (result.get("value") or {}).get("version")
    state = args.get("state") or (result.get("value") or {}).get("state")
    if not isinstance(version, str) or not version:
        return
    if state not in ("planned", "active", "closed"):
        return
    milestones_writes.update_milestone_state(
        conn,
        version=version,
        state=state,
        updated_at=_now_iso(),
    )
    conn.commit()
