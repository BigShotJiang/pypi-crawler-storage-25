"""Migration runner for 3.x → 4.0 schema (Phase 3.6.0 D3 / #299).

The 3.0+ schema declares `discussion_categories` at the top level
of `forge-config.json` — implicitly tied to the GitHub backend
(category IDs are GitHub-GraphQL node IDs, not portable).
Schema 4.0 moves this map into per-platform configuration so each
backend can declare its own category mapping.

**Wire-format change:**

Pre-4.0::

    {
      "schema_version": "3.0",
      "platforms": [
        {"id": "github", ...},
        {"id": "codeberg", ...}
      ],
      "discussion_categories": {
        "Architecture": {"id": "DIC_kw..."},
        "Ideas": {"id": "DIC_kw..."}
      }
    }

Post-4.0::

    {
      "schema_version": "4.0",
      "platforms": [
        {
          "id": "github",
          "discussion_categories": {
            "Architecture": {"id": "DIC_kw..."},
            "Ideas": {"id": "DIC_kw..."}
          }
        },
        {"id": "codeberg", ...}
      ]
      // top-level discussion_categories removed
    }

**Hard cutover** per Discussion #6 OQ1 closure (2026-05-06): no
N-1 read-compat surface in the 4.0 code path. Operators run
``migrate_to_4_0(apply=True)`` once before upgrading.

**Backup strategy.** Mirror ``migrate_to_3_5``: archive `.claude/`
(including the pre-migration forge-config.json) under
`.claude/backups/migration-4.0-<utc-ts>/`. Rollback restores the
pre-3.x version verbatim.

**Idempotency.** When `forge-config.json` already declares
`schema_version == "4.0"`, the migration short-circuits as
`is_clean=True` and emits no changes.

**Code-design.** ``MigrationPlan`` follows Rule 5 (cached frozen
dataclass inside helper). detect / apply / rollback are effect
functions.
"""
from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import cache
from pathlib import Path
from typing import Iterable


SCHEMA_VERSION_TARGET = "4.0"
"""The schema version this migration targets. After apply, the
config's `schema_version` field is rewritten to this value."""

GITHUB_BACKEND_ID = "github"
"""Top-level `discussion_categories` is implicitly GitHub-side
(category IDs are GitHub-GraphQL node IDs). Migration moves the
map onto the platforms entry whose `id == GITHUB_BACKEND_ID`."""


# --- Plan factory ---------------------------------------------------------


@cache
def _migration_plan_class() -> type:
    @dataclass(frozen=True)
    class MigrationPlan:
        """Pre-apply assessment of a project's 3.x → 4.0 state.

        Fields:
            is_clean — True when no migration needed (config already
                at 4.0 OR no forge-config.json present).
            project_dir — path passed in by caller.
            config_path — resolved path to `.claude/forge-config.json`.
            current_schema — `schema_version` field value, or None
                if the config can't be parsed.
            has_top_level_categories — True when 3.x-shape category
                map exists at top level.
            github_platform_index — index into `platforms` array of
                the entry whose id matches `GITHUB_BACKEND_ID`; None
                when no GitHub backend is configured (then no
                migration is possible — categories have nowhere to
                go).
            warnings — non-fatal observations.
        """
        is_clean: bool
        project_dir: Path
        config_path: Path
        current_schema: str | None
        has_top_level_categories: bool
        github_platform_index: int | None
        warnings: tuple[str, ...]
    return MigrationPlan


def make_plan(
    *,
    is_clean: bool,
    project_dir: Path,
    config_path: Path,
    current_schema: str | None = None,
    has_top_level_categories: bool = False,
    github_platform_index: int | None = None,
    warnings: Iterable[str] = (),
):
    Cls = _migration_plan_class()
    return Cls(
        is_clean=is_clean,
        project_dir=project_dir,
        config_path=config_path,
        current_schema=current_schema,
        has_top_level_categories=has_top_level_categories,
        github_platform_index=github_platform_index,
        warnings=tuple(warnings),
    )


# --- Detection ------------------------------------------------------------


def _config_path(project_dir: Path) -> Path:
    return project_dir / ".claude" / "forge-config.json"


def detect_4_0_state(project_dir: Path) -> "MigrationPlan":
    """Build a MigrationPlan from the project's forge-config.json.

    Detection cases:
    * No config file → `is_clean=True` (nothing to migrate).
    * Malformed JSON → `is_clean=True` + warning (operator runs
      a different recovery path; this migration won't help).
    * `schema_version == "4.0"` → already migrated.
    * `schema_version == "3.x"` + top-level `discussion_categories` →
      migration needed.
    * `schema_version == "3.x"` + no top-level categories → already
      effectively migrated; just bump the version field.
    * No GitHub platform entry → cannot migrate; emit warning.
    """
    cp = _config_path(project_dir)
    if not cp.is_file():
        return make_plan(
            is_clean=True,
            project_dir=project_dir,
            config_path=cp,
            warnings=("no forge-config.json found",),
        )
    try:
        config = json.loads(cp.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return make_plan(
            is_clean=True,
            project_dir=project_dir,
            config_path=cp,
            warnings=(f"config unreadable / malformed: {exc}",),
        )
    if not isinstance(config, dict):
        return make_plan(
            is_clean=True,
            project_dir=project_dir,
            config_path=cp,
            warnings=("config is not a JSON object",),
        )

    current_schema = config.get("schema_version")
    if current_schema == SCHEMA_VERSION_TARGET:
        return make_plan(
            is_clean=True,
            project_dir=project_dir,
            config_path=cp,
            current_schema=current_schema,
            warnings=(f"already at schema {SCHEMA_VERSION_TARGET}",),
        )

    has_top_level = (
        "discussion_categories" in config
        and isinstance(config.get("discussion_categories"), dict)
        and len(config["discussion_categories"]) > 0
    )

    platforms = config.get("platforms") or []
    github_idx: int | None = None
    if isinstance(platforms, list):
        for i, p in enumerate(platforms):
            if isinstance(p, dict) and p.get("id") == GITHUB_BACKEND_ID:
                github_idx = i
                break

    warnings: list[str] = []
    if has_top_level and github_idx is None:
        warnings.append(
            "config has top-level discussion_categories but no "
            "GitHub platform entry to host them; migration will "
            "drop the categories. File a follow-up if a different "
            "backend should own them."
        )

    # Migration is needed when either:
    #   - schema is not 4.0 yet (need version bump), OR
    #   - top-level categories need to move onto a platform entry.
    is_clean = (current_schema == SCHEMA_VERSION_TARGET)

    return make_plan(
        is_clean=is_clean,
        project_dir=project_dir,
        config_path=cp,
        current_schema=current_schema,
        has_top_level_categories=has_top_level,
        github_platform_index=github_idx,
        warnings=warnings,
    )


# --- Apply / rollback -----------------------------------------------------


def _backup_path(project_dir: Path) -> Path:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return project_dir / ".claude" / "backups" / f"migration-4.0-{ts}"


def _archive_dir(src: Path, dst: Path) -> None:
    """Copy ``src`` to ``dst`` recursively, excluding `backups/`
    so the archive doesn't recurse into itself."""
    if not src.exists():
        return
    shutil.copytree(
        src, dst, dirs_exist_ok=True,
        ignore=shutil.ignore_patterns("backups"),
    )


def transform_config(config: dict, github_idx: int | None) -> dict:
    """Pure transformer: input pre-4.0 config dict → post-4.0 dict.

    Rules:
    1. If a GitHub platform entry exists AND top-level
       `discussion_categories` is non-empty: copy the map onto
       `platforms[github_idx].discussion_categories`.
    2. Drop the top-level `discussion_categories` field.
    3. Bump `schema_version` to "4.0".

    Idempotent: running on a 4.0-shape config returns the same
    config (drop step is no-op; bump is no-op).
    """
    out = dict(config)
    top_cats = out.get("discussion_categories") or {}
    if github_idx is not None and top_cats:
        platforms = list(out.get("platforms") or [])
        gh_entry = dict(platforms[github_idx])
        # Don't overwrite an existing per-platform map (4.0-already-
        # migrated case caught by detect; this is a safety net).
        if "discussion_categories" not in gh_entry:
            gh_entry["discussion_categories"] = dict(top_cats)
        platforms[github_idx] = gh_entry
        out["platforms"] = platforms
    if "discussion_categories" in out:
        del out["discussion_categories"]
    out["schema_version"] = SCHEMA_VERSION_TARGET
    return out


def apply_migration(plan: "MigrationPlan") -> dict:
    """Execute the migration. Backs up `.claude/`; rewrites
    forge-config.json to the 4.0 shape; returns result dict.

    Returns ``{success, backup_path, transformations, manual_steps}``.
    """
    bdir = _backup_path(plan.project_dir)
    bdir.mkdir(parents=True, exist_ok=True)
    _archive_dir(plan.project_dir / ".claude", bdir / ".claude")

    config = json.loads(plan.config_path.read_text(encoding="utf-8"))
    transformed = transform_config(config, plan.github_platform_index)

    transformations: list[str] = []
    if plan.has_top_level_categories and plan.github_platform_index is not None:
        transformations.append(
            f"Moved top-level discussion_categories onto "
            f"platforms[{plan.github_platform_index}] (id="
            f"{GITHUB_BACKEND_ID})."
        )
    elif plan.has_top_level_categories:
        transformations.append(
            "Dropped top-level discussion_categories (no GitHub "
            "platform to receive them — see warnings)."
        )
    if plan.current_schema != SCHEMA_VERSION_TARGET:
        transformations.append(
            f"Bumped schema_version "
            f"{plan.current_schema!r} → {SCHEMA_VERSION_TARGET!r}."
        )

    # Atomic-replace write.
    tmp = plan.config_path.with_suffix(plan.config_path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(transformed, indent=2) + "\n", encoding="utf-8",
    )
    import os
    os.replace(tmp, plan.config_path)

    manual_steps: list[str] = []
    manual_steps.append(
        "Verify ./mcp-server tests pass (`bazel test //tests:unit_tests`); "
        "the 4.0 model schemas + caller updates land alongside this "
        "migration in the 3.6.0 cut."
    )
    if plan.github_platform_index is None and plan.has_top_level_categories:
        manual_steps.append(
            "Top-level discussion_categories were dropped because no "
            "GitHub platform is configured. If a different backend "
            "should own these category IDs, hand-edit the migrated "
            "config to add `discussion_categories` to that platform "
            "entry."
        )

    return {
        "success": True,
        "backup_path": str(bdir),
        "transformations": transformations,
        "manual_steps": manual_steps,
    }


def restore_to_targets(
    backup_path: Path, *, project_dir: Path,
) -> dict:
    """Restore .claude/ from a backup produced by apply_migration.

    Mirrors `migrate_3_5.restore_to_targets` shape; idempotent on
    re-run.
    """
    if not backup_path.exists():
        return {
            "success": False,
            "error": f"backup not found: {backup_path}",
            "restored": [],
        }
    claude_backup = backup_path / ".claude"
    if not claude_backup.exists():
        return {
            "success": False,
            "error": f".claude/ archive missing inside {backup_path}",
            "restored": [],
        }
    target_claude = project_dir / ".claude"
    target_claude.mkdir(parents=True, exist_ok=True)
    for item in claude_backup.rglob("*"):
        if item.is_file():
            rel = item.relative_to(claude_backup)
            target = target_claude / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
    return {
        "success": True,
        "backup_path": str(backup_path),
        "restored": [str(target_claude)],
    }
