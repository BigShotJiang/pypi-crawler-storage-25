"""Migration runner for milestone-as-compound-doc backfill (#397 / 3.11.0 D1.a Phase 3b).

Walks the canonical store's existing ``issues/*/meta.json`` for
unique ``milestone`` values, then creates a corresponding
``milestones/<version>/`` compound doc for each version that
doesn't yet have one. The compound doc seeds with default
``tier`` inferred from semver delta vs prior versions, ``hotfix``
defaulting to False, ``plan_discussion`` defaulting to None
(operator pins later via ``set_milestone_plan``).

Idempotent — re-running skips versions whose compound doc already
exists. No rollback module because creation is reversible via
filesystem delete (``rm -rf <docs>/milestones/<version>/``).

MVP scope per #397 D4. Full migration (prose-heuristic
``plan_discussion`` resolution + CHANGELOG ``body.md`` backfill)
ships as a follow-on enhancement once the MVP exposes operator
pain points.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import cache
from pathlib import Path
from typing import Iterable


@cache
def _migration_plan_class() -> type:
    @dataclass(frozen=True)
    class MigrationPlan:
        """Plan output from ``detect_4_1_state``.

        ``versions_present`` are versions referenced by Issue
        meta.milestone fields. ``versions_already_materialized``
        are versions that already have a compound doc.
        ``versions_to_create`` is the diff (versions to materialize
        on apply).
        """

        docs_root: Path
        versions_present: tuple[str, ...]
        versions_already_materialized: tuple[str, ...]
        versions_to_create: tuple[str, ...]
        warnings: tuple[str, ...]

        @property
        def is_clean(self) -> bool:
            return len(self.versions_to_create) == 0

    return MigrationPlan


MigrationPlan = _migration_plan_class()


_SEMVER_PATTERN = re.compile(r"^(\d+)\.(\d+)\.(\d+)([a-zA-Z][\w]*)?$")


def parse_semver(version: str) -> tuple[int, int, int, str] | None:
    """Parse a semver-like version string. Returns ``(major, minor, patch, suffix)``
    or None when unparseable.

    Suffix captures pre-release tails like ``a1`` / ``rc1`` (PEP-440 style)
    consistent with ``release.py`` regex tolerance.
    """
    m = _SEMVER_PATTERN.match(version.strip())
    if m is None:
        return None
    major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
    suffix = m.group(4) or ""
    return (major, minor, patch, suffix)


def infer_tier(version: str, prior_versions: Iterable[str]) -> str:
    """Infer tier (major / minor / patch) by semver delta vs the
    most-recently-shipped prior version.

    Decision rubric:
        * No prior version → 'major' (greenfield first cut).
        * major bump (X+1.0.0 vs X.Y.Z) → 'major'.
        * minor bump (X.Y+1.0 vs X.Y.Z) → 'minor'.
        * patch bump (X.Y.Z+1 vs X.Y.Z) → 'patch'.
        * Unparseable / equal / older than priors → 'minor' (safe default).
    """
    cur = parse_semver(version)
    if cur is None:
        return "minor"
    cur_major, cur_minor, cur_patch, _ = cur

    parsed_priors = [
        p for p in (parse_semver(v) for v in prior_versions) if p is not None
    ]
    # Find priors strictly less than cur.
    less_than_cur = [p for p in parsed_priors if p[:3] < (cur_major, cur_minor, cur_patch)]
    if not less_than_cur:
        return "major"
    nearest = max(less_than_cur, key=lambda p: p[:3])
    n_major, n_minor, n_patch, _ = nearest
    if cur_major > n_major:
        return "major"
    if cur_major == n_major and cur_minor > n_minor:
        return "minor"
    if cur_major == n_major and cur_minor == n_minor and cur_patch > n_patch:
        return "patch"
    return "minor"  # pragma: no cover — DEFENSIVE: nearest is strict-less than cur per the less_than_cur filter, so tuple ordering guarantees one of the major/minor/patch comparisons above must succeed. The fallback exists as a safe default if the parse logic ever changes.


def collect_milestone_versions(docs_root: Path) -> tuple[set[str], list[str]]:
    """Walk ``<docs_root>/issues/*/meta.json`` and collect unique
    ``milestone`` field values. Returns ``(versions_set, warnings)``.

    Pure read; no writes. Skips entries that fail to parse so a
    corrupt meta.json doesn't abort the whole walk.
    """
    versions: set[str] = set()
    warnings: list[str] = []
    issues_dir = docs_root / "issues"
    if not issues_dir.is_dir():
        warnings.append(
            f"No issues/ directory under {docs_root} — nothing to migrate."
        )
        return versions, warnings
    for entry in issues_dir.iterdir():
        if not entry.is_dir():
            continue
        meta_path = entry / "meta.json"
        if not meta_path.is_file():
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            warnings.append(
                f"Skipping {entry.name}: meta.json unparseable ({exc})."
            )
            continue
        version = meta.get("milestone")
        if isinstance(version, str) and version.strip():
            versions.add(version.strip())
    return versions, warnings


def list_already_materialized(docs_root: Path) -> set[str]:
    """Return versions that already have a ``milestones/<version>/``
    compound doc (directory with meta.json)."""
    ms_root = docs_root / "milestones"
    if not ms_root.is_dir():
        return set()
    materialized: set[str] = set()
    for entry in ms_root.iterdir():
        if entry.is_dir() and (entry / "meta.json").is_file():
            materialized.add(entry.name)
    return materialized


def detect_4_1_state(project_dir: Path) -> "MigrationPlan":
    """Compose a migration plan: which versions need compound docs.

    Resolves docs_root via the same chain as
    ``_check_milestone_open_issues_against_cut`` —
    ``$FORGE_MANAGER_DOCS_REPO`` env var, then
    ``~/<project>-docs/`` fallback.
    """
    docs_root = None
    env = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if env:
        docs_root = Path(env)
    if docs_root is None or not docs_root.is_dir():
        candidate = (Path.home() / f"{project_dir.name}-docs").resolve()
        if candidate.is_dir():
            docs_root = candidate
    if docs_root is None or not docs_root.is_dir():
        return MigrationPlan(
            docs_root=Path(),
            versions_present=(),
            versions_already_materialized=(),
            versions_to_create=(),
            warnings=(
                f"Canonical docs repo not found "
                f"($FORGE_MANAGER_DOCS_REPO unset and "
                f"~/{project_dir.name}-docs/ absent). Nothing to migrate.",
            ),
        )

    present, walk_warnings = collect_milestone_versions(docs_root)
    materialized = list_already_materialized(docs_root)
    to_create = present - materialized
    return MigrationPlan(
        docs_root=docs_root,
        versions_present=tuple(sorted(present)),
        versions_already_materialized=tuple(sorted(materialized)),
        versions_to_create=tuple(sorted(to_create)),
        warnings=tuple(walk_warnings),
    )


def _write_milestone_compound_doc(
    docs_root: Path, version: str, tier: str,
) -> None:
    """Atomic per-version write of the milestone compound doc.

    Writes title.md / body.md / state.txt / labels.txt / meta.json
    in one ms_dir.mkdir + per-file pass. Mirrors the
    ``LocalStoreAdapter.create_milestone`` shape exactly so a
    subsequent ``get_milestone_body`` / ``list_all_milestone_versions``
    call sees the migrated docs as native compound docs.
    """
    ms_dir = docs_root / "milestones" / version
    ms_dir.mkdir(parents=True, exist_ok=False)
    (ms_dir / "title.md").write_text(version + "\n", encoding="utf-8")
    (ms_dir / "body.md").write_text("", encoding="utf-8")
    (ms_dir / "state.txt").write_text("planned\n", encoding="utf-8")
    (ms_dir / "labels.txt").write_text(
        f"kind:milestone\ntier:{tier}\n", encoding="utf-8",
    )
    meta = {
        "version": version,
        "tier": tier,
        "hotfix": False,
        "plan_discussion": None,
        "cut_at": None,
        "tag_sha": None,
        "migrated_at": datetime.now(timezone.utc).isoformat(),
    }
    (ms_dir / "meta.json").write_text(
        json.dumps(meta, indent=2) + "\n", encoding="utf-8",
    )


def apply_migration(plan: "MigrationPlan") -> dict:
    """Apply the migration plan: create compound docs for every
    version in ``plan.versions_to_create``.

    Returns ``{success, materialized: [{version, tier}, ...],
    skipped: [...], warnings: [...]}`` for handler consumption.

    Tier inference uses semver delta vs already-shipped versions
    (``versions_already_materialized`` ∪ already-created ones from
    this run, so consecutive creates within one apply step see
    each other). Failures on individual versions don't abort the
    whole pass — they're collected as warnings.
    """
    if plan.is_clean:
        return {
            "success": True,
            "materialized": [],
            "skipped": list(plan.versions_already_materialized),
            "warnings": list(plan.warnings),
        }

    materialized: list[dict] = []
    warnings: list[str] = list(plan.warnings)
    # Walk in semver-ascending order so tier inference sees prior versions.
    def sort_key(v: str) -> tuple:
        parsed = parse_semver(v)
        if parsed is None:
            return (0, v)
        return (1, parsed[:3])

    pending = sorted(plan.versions_to_create, key=sort_key)
    seen_versions = set(plan.versions_already_materialized)
    for version in pending:
        tier = infer_tier(version, seen_versions)
        try:
            _write_milestone_compound_doc(plan.docs_root, version, tier)
        except OSError as exc:
            warnings.append(
                f"Failed to materialize milestone {version!r}: {exc}",
            )
            continue
        materialized.append({"version": version, "tier": tier})
        seen_versions.add(version)
    return {
        "success": True,
        "materialized": materialized,
        "skipped": list(plan.versions_already_materialized),
        "warnings": warnings,
    }
