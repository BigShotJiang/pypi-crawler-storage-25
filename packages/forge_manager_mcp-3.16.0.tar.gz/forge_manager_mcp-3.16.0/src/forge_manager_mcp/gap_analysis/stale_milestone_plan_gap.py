"""stale_milestone_plan_gap detector (3.10.0 D6.2 / #390).

Walks Discussions in the local canonical store and flags ones
whose anchored_milestone has shipped but whose lifecycle axis is
still ``open``. Catches the pattern surfaced 2026-05-09: 9 plan/
RFC Discussions still open after their milestone shipped (D4, D6,
D7, D8, D11, D12, D14, D16; plus D1's lifecycle/resolution split).

**Anchor resolution.** Two paths:

1. **Machine-readable** — ``meta.json.anchored_milestone`` field
   (string OR list of strings per #390 OQ2 path b — multi-version
   plans require ALL anchors to ship before the gate fires).
2. **Prose heuristic fallback** — first 50 lines of body.md
   regex-match against ``[0-9]+\\.[0-9]+\\.[0-9]+`` near tokens
   like ``milestone``, ``plan``, ``RFC``, ``design``. Less
   reliable; the backfill tool will write the explicit field
   based on this heuristic + operator review (#390 OQ3 path a).

**Lifecycle vs resolution.** state.txt is multi-line per the
3.0.0 convention. Line 1 is lifecycle (``open`` / ``closed``);
subsequent lines are orthogonal resolution axes (``decided`` /
``undecided``). Per #390 OQ4 path a, the gate fires on
``open`` lifecycle regardless of resolution — the multi-dim
state convention only earns its complexity if both axes are
eventually consistent.

**Shipped-milestone determination.** A milestone is shipped if
the canonical store has ≥1 closed Issue with that milestone in
its meta.json. Lightweight; doesn't depend on remote backends.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "stale_milestone_plan_gap"

# Match a semver-ish version near anchoring tokens. Conservative
# — prefers explicit "X.Y.Z plan" / "milestone X.Y.Z" patterns.
_VERSION_PROSE = re.compile(
    r"\b(\d+\.\d+\.\d+(?:[a-z]\d+)?)\b"
    r"\s*(?:milestone|plan|RFC|design|cut|release)"
    r"|"
    r"(?:milestone|plan|RFC|design|cut|release)"
    r"\s+(\d+\.\d+\.\d+(?:[a-z]\d+)?)\b",
    re.IGNORECASE,
)


def find_docs_repo(project_root: Path) -> Path | None:
    """Locate the canonical docs repo. Same pattern as
    acceptance_unmet_gap.find_docs_repo. Lifted here for parity;
    eventually share via a common helper module."""
    override = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if override:
        path = Path(override)
        if path.is_dir():
            return path
        return None
    base = project_root.name
    if base.endswith("-dev"):
        candidate_name = base[:-4] + "-docs"
    else:
        candidate_name = base + "-docs"
    candidate = project_root.parent / candidate_name
    if candidate.is_dir():
        return candidate
    return None


def shipped_milestones(docs_repo: Path) -> set[str]:
    """Walk closed Issues + Discussions in the canonical store and
    return the set of milestones that have ≥1 closed thread.

    A milestone is "shipped" iff at least one thread on it is
    closed (lifecycle axis). Defensive: handles missing files /
    parse errors silently per the project's gap-analysis
    convention (graceful degradation > spurious findings)."""
    shipped: set[str] = set()
    for kind in ("issues", "discussions"):
        kind_dir = docs_repo / kind
        if not kind_dir.is_dir():
            continue
        for entry in kind_dir.iterdir():
            if not entry.is_dir():
                continue
            meta_path = entry / "meta.json"
            state_path = entry / "state.txt"
            if not (meta_path.is_file() and state_path.is_file()):
                continue
            try:
                state = state_path.read_text(encoding="utf-8")
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            lifecycle = (state.splitlines() or [""])[0].strip().lower()
            if lifecycle != "closed":
                continue
            ms = meta.get("milestone")
            if isinstance(ms, str) and ms:
                shipped.add(ms)
    return shipped


def parse_anchored_milestone(meta: dict) -> tuple[str, ...]:
    """Read meta.json's anchored_milestone field. Returns a tuple
    of milestone strings (length 1 for the singular case, ≥1 for
    the multi-anchor case per #390 OQ2 path b). Empty tuple when
    absent."""
    raw = meta.get("anchored_milestone")
    if raw is None:
        return ()
    if isinstance(raw, str):
        return (raw,)
    if isinstance(raw, list):
        return tuple(str(v) for v in raw if v)
    return ()


def heuristic_anchored_milestone(body: str) -> tuple[str, ...]:
    """Fallback prose heuristic when meta.json lacks the explicit
    field. Walks the first 50 lines of body.md and extracts any
    matching version numbers near anchor-shaped tokens.

    Conservative — duplicate matches dedupe; 50-line cap avoids
    matching versions buried deep in long discussions that aren't
    actually anchors."""
    lines = body.splitlines()[:50]
    head = "\n".join(lines)
    found: set[str] = set()
    for m in _VERSION_PROSE.finditer(head):
        v = m.group(1) or m.group(2)
        if v:
            found.add(v)
    return tuple(sorted(found))


def is_stale(
    *,
    lifecycle: str,
    anchors: tuple[str, ...],
    shipped: set[str],
) -> bool:
    """Decision predicate. Stale iff:
      * lifecycle is open
      * at least one anchor is set
      * ALL anchors are shipped (multi-anchor: must all ship; per
        #390 OQ2 path b — single-anchor is the common case).
    """
    if lifecycle != "open":
        return False
    if not anchors:
        return False
    return all(a in shipped for a in anchors)


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Walks discussions/<n>/ (and issues
    too — some Issue-shaped trackers also anchor a milestone)
    looking for stale plans."""
    docs_repo = find_docs_repo(project_root)
    if docs_repo is None:
        return []

    shipped = shipped_milestones(docs_repo)
    if not shipped:
        return []

    findings: list = []
    # Discussions are the primary site for plan-anchoring. Issues
    # rarely carry anchored_milestone (they're scoped to a single
    # milestone via meta.milestone). Walk both anyway — false
    # negatives are quieter than missed Discussions.
    for kind in ("discussions", "issues"):
        kind_dir = docs_repo / kind
        if not kind_dir.is_dir():
            continue
        for entry in sorted(kind_dir.iterdir()):
            if not entry.is_dir():
                continue
            meta_path = entry / "meta.json"
            state_path = entry / "state.txt"
            body_path = entry / "body.md"
            if not (meta_path.is_file() and state_path.is_file()):
                continue
            try:
                state = state_path.read_text(encoding="utf-8")
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            lifecycle = (state.splitlines() or [""])[0].strip().lower()
            anchors = parse_anchored_milestone(meta)
            if not anchors and body_path.is_file():
                # Heuristic fallback only when explicit field absent.
                try:
                    body = body_path.read_text(encoding="utf-8")
                    anchors = heuristic_anchored_milestone(body)
                except OSError:
                    pass
            if not is_stale(
                lifecycle=lifecycle,
                anchors=anchors,
                shipped=shipped,
            ):
                continue
            location_path = f"{kind}/{entry.name}/state.txt"
            findings.append(make_gap_finding(
                detector=DETECTOR_NAME,
                category="process",
                severity=severity,
                location=make_gap_location(path=location_path),
                message=(
                    f"{kind[:-1].capitalize()} #{entry.name} is "
                    f"open on lifecycle axis but anchored "
                    f"milestone(s) {list(anchors)} have shipped"
                ),
                suggestion=(
                    "Close on lifecycle axis (set state.txt to "
                    "`closed` on line 1) and optionally mark "
                    "decided on resolution axis if not already. "
                    "If the plan is still active, update "
                    "anchored_milestone to the next milestone."
                ),
                tags=("process", "milestone_lifecycle"),
            ))
    return findings


register_detector(DETECTOR_NAME, detect)
