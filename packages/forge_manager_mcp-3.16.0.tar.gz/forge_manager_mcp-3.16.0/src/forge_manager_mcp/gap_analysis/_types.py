"""Shared types for gap-analysis detectors (Phase 3.6.0 D1 / #348).

Sibling of `code_design/_types.py`. Both follow the same factory
pattern (Rule 5) and serialize to similar wire shapes — but the
*kind* of finding differs: code-design findings flag what's
*wrong* with present code; gap-analysis findings flag what's
*missing* (capability not implemented, security concern not
addressed, usability gap not closed, etc.).

The registry, Protocol, and orchestrator follow code_design/'s
shape so detectors slot into the same MCP-tool dispatch contract.

Pure module — no IO. Test target ``test_gap_finding`` is the
§schema-tests gate target for ``make_gap_finding`` and carries
the `pure` + `schema` tags per Rules 6 / 7.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import cache
from typing import Literal


GapSeverity = Literal["fail", "warn", "info"]
"""Effective severity for a gap finding. Same three-tier system as
code-design findings; gap-detector authors set the default and the
gate registry's four-layer chain (#287) can elevate / suppress per
project rules."""


GapCategory = Literal[
    "capability",      # missing capability (e.g. "no rollback flow for X")
    "security",        # security gap (e.g. "no rate limit on POST endpoint")
    "usability",       # operator-experience gap (e.g. "no progress display")
    "test_coverage",   # untested path
    "reliability",     # error-handling / failure-mode gap
    "documentation",   # missing or stale prose
    "performance",     # latency / throughput concern
    "cross_platform",  # platform-specific gap (e.g. "no Windows path handling")
    "accessibility",   # a11y gap
    "observability",   # missing log / metric / trace
    "api_consistency", # surface-shape inconsistency
    "migration",       # missing migration path
    "backward_compatibility",  # break-without-migration
    "dependency_health",       # outdated / unmaintained dep
    "resource_leak",   # connection / file / memory leak
    "concurrency",     # race / deadlock concern
    "internationalization",   # i18n gap
    "operational",     # ops / release gap
    "cost",            # resource cost concern
    "type_safety",     # missing / wrong type annotations
]
"""Closed taxonomy of gap categories per #348's catalog. New
categories require a code change (deliberate; the taxonomy is the
contract). Per-detector implementations subset this list."""


@cache
def _gap_location_class() -> type:
    """Cached frozen-dataclass shape — defined inside a function so
    AST scan over module-level nodes does not see a top-level
    dataclass. Conforms to Rule 5."""
    @dataclass(frozen=True)
    class GapLocation:
        """Where the gap lives. ``path`` may be a file, a directory,
        a feature surface name (e.g. "POST /writes"), or empty for
        gaps that are project-wide. ``line``/``symbol`` only apply
        when ``path`` resolves to a file."""
        path: str
        line: int | None = None
        symbol: str | None = None
    return GapLocation


@cache
def _gap_finding_class() -> type:
    @dataclass(frozen=True)
    class GapFinding:
        """A detected gap.

        Fields:
            detector — detector name (e.g. ``capability_gap``)
            category — one of ``GapCategory``
            severity — ``fail`` / ``warn`` / ``info``
            location — ``GapLocation`` value
            message — single-sentence "what's missing"
            suggestion — optional remediation hint
            tags — structural tags for filter (e.g.
                ``("backend", "github")``); empty tuple by default
        """
        detector: str
        category: str
        severity: str
        location: object
        message: str
        suggestion: str | None = None
        tags: tuple[str, ...] = ()
    return GapFinding


def make_gap_location(
    *, path: str, line: int | None = None, symbol: str | None = None,
):
    """Factory for GapLocation values."""
    Cls = _gap_location_class()
    return Cls(path=path, line=line, symbol=symbol)


def make_gap_finding(
    *,
    detector: str,
    category: str,
    severity: GapSeverity,
    location,
    message: str,
    suggestion: str | None = None,
    tags: tuple[str, ...] = (),
):
    """Factory for GapFinding values.

    Per Rule 5 the dataclass class lives inside a cached helper.
    Detectors call this; consumers iterate over the returned list.
    """
    Cls = _gap_finding_class()
    return Cls(
        detector=detector,
        category=category,
        severity=severity,
        location=location,
        message=message,
        suggestion=suggestion,
        tags=tuple(tags),
    )


def gap_finding_to_dict(finding) -> dict:
    """Serialize a GapFinding to a plain dict for the MCP response."""
    out: dict = {
        "detector": finding.detector,
        "category": finding.category,
        "severity": finding.severity,
        "location": {
            "path": finding.location.path,
            "line": finding.location.line,
            "symbol": finding.location.symbol,
        },
        "message": finding.message,
        "tags": list(finding.tags),
    }
    if finding.suggestion is not None:
        out["suggestion"] = finding.suggestion
    return out
