"""registry_coverage_gap meta-detector (3.10.0 D6.3 / #391).

Audits the gap-analysis registry's category coverage against
gap-discovery signals in the canonical store. Surfaces categories
of gap that recently surfaced as Issues but aren't represented by
any registered detector — the "we discovered a class of gap;
should we file a detector?" loop made visible.

**Signal sources** (per #391 design):

1. Issues whose body prose matches gap-discovery patterns:
   "how did this happen", "this gap", "no detector",
   "process gap", "missed by", "we shipped X without".
2. Issues whose Causal note section names a release as the
   discovery point.
3. Issues that propose new detectors (pattern: "new
   <name>_gap detector" in body prose).

**Categorization** uses ``detector_categories.yaml`` mapping each
registered detector to one or more category labels (e.g.,
``test_coverage_gap`` covers ``coverage``;
``acceptance_unmet_gap`` covers ``acceptance_lifecycle``). Per
#391 OQ1 path b — explicit, version-controlled, no LLM-call cost.

**Output** is one finding per uncovered category. Severity climbs
with surfacing count: 1 → info, 2 → warn, 3+ → fail (when
release-gated). Single surfacings might be one-off; recurring
surfacings are the strong signal.

**Audit window** defaults to 90 days per #391 OQ2 path c. Older
surfacings are excluded — recent surfacings carry more signal.
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "registry_coverage_gap"
DEFAULT_AUDIT_WINDOW_DAYS = 90

# Gap-discovery prose patterns. Heuristic — matches phrasings the
# project's recent surfacing Issues used (#389, #390, #391).
_DISCOVERY_PATTERNS = [
    re.compile(r"how did (?:this|these) gap[s]? happen", re.IGNORECASE),
    re.compile(r"\bno detector\b", re.IGNORECASE),
    re.compile(r"\bprocess gap\b", re.IGNORECASE),
    re.compile(r"\bmissed by\b", re.IGNORECASE),
    re.compile(r"shipped .* without", re.IGNORECASE),
    re.compile(r"(?:wasn't|isn't|wasn|isnt) (?:wired|tracked|caught)", re.IGNORECASE),
]

# Detector-name extraction. Matches "new <name>_gap detector" or
# "new `<name>_gap` detector" patterns in proposal Issues.
_DETECTOR_PROPOSAL = re.compile(
    r"new\s+`?(\w+_gap)`?\s+detector",
    re.IGNORECASE,
)


def find_docs_repo(project_root: Path) -> Path | None:
    """Same resolution as siblings. TODO: factor into shared helper."""
    override = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if override:
        path = Path(override)
        if path.is_dir():
            return path
        return None
    base = project_root.name
    if base.endswith("-dev"):
        candidate_name = base[:-4] + "-docs"
    else:
        candidate_name = base + "-docs"
    candidate = project_root.parent / candidate_name
    if candidate.is_dir():
        return candidate
    return None


def load_detector_categories(skill_dir: Path) -> dict[str, list[str]]:
    """Load the detector_categories.yaml mapping. Returns
    {detector_name: [category_label, ...]}.

    The file format is the same constrained YAML the rest of the
    skill uses (gates.yaml / processes.yaml / commands.yaml). For
    simplicity here we treat it as a key→list-of-strings mapping
    with one detector per top-level key under ``detectors``.

    Returns empty dict if the file is missing — degrades gracefully.
    """
    path = skill_dir / "detector_categories.yaml"
    if not path.is_file():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    return _parse_categories_yaml(text)


def _parse_categories_yaml(text: str) -> dict[str, list[str]]:
    """Minimal parser for the constrained shape:

        detectors:
          test_coverage_gap: [coverage]
          acceptance_unmet_gap: [acceptance_lifecycle]
          ...

    The shared gate_registry parse_yaml_text doesn't quite fit
    (it expects nested-mapping-of-records). Roll a tiny parser
    here for the specific shape.
    """
    out: dict[str, list[str]] = {}
    in_detectors = False
    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line.rstrip().endswith(":") and not line.startswith(" "):
            in_detectors = line.strip() == "detectors:"
            continue
        if in_detectors and line.startswith("  ") and ":" in line:
            key, _, val = line.strip().partition(":")
            cats: list[str] = []
            v = val.strip()
            if v.startswith("[") and v.endswith("]"):
                inner = v[1:-1].strip()
                if inner:
                    cats = [c.strip() for c in inner.split(",") if c.strip()]
            out[key.strip()] = cats
    return out


def is_gap_discovery_body(body: str) -> bool:
    """True if the body's first 80 lines contain ≥1 gap-discovery
    pattern. Capping at 80 lines avoids matching versions buried
    deep in long discussions that aren't actually gap surfaces."""
    head = "\n".join(body.splitlines()[:80])
    return any(p.search(head) for p in _DISCOVERY_PATTERNS)


def proposed_detectors(body: str) -> list[str]:
    """Extract detector-name proposals from the body."""
    return [m.group(1) for m in _DETECTOR_PROPOSAL.finditer(body)]


def categorize_proposal(detector_name: str) -> str:
    """Heuristic mapping of a proposed detector name to a category
    label. Strips the conventional ``_gap`` suffix and uses the
    remaining root as the category label.

    e.g. "infra_without_ui_gap" → "infra_without_ui";
         "stale_milestone_plan_gap" → "stale_milestone_plan".
    """
    if detector_name.endswith("_gap"):
        return detector_name[:-4]
    return detector_name


def parse_filed_at(meta: dict) -> datetime | None:
    """Read a Filed timestamp from meta.json. Tolerant of missing
    or malformed values — None means "audit-window-eligible by
    default" (don't filter out surfacings just because the
    timestamp isn't readable)."""
    raw = meta.get("filed_at") or meta.get("created_at")
    if not raw or not isinstance(raw, str):
        return None
    try:
        # Tolerant ISO-8601 parser: accept "Z" suffix.
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Walks Issues + Discussions for gap-
    discovery signals; cross-references against the registered
    detectors via detector_categories.yaml; emits one finding per
    uncovered category surfacing."""
    docs_repo = find_docs_repo(project_root)
    if docs_repo is None:
        return []

    skill_dir = project_root / ".claude" / "skills" / "forge-manager"
    cats = load_detector_categories(skill_dir)
    covered_categories: set[str] = set()
    for category_list in cats.values():
        covered_categories.update(category_list)

    cutoff = datetime.now(timezone.utc) - timedelta(
        days=DEFAULT_AUDIT_WINDOW_DAYS,
    )

    # Walk Issues + Discussions; collect surfacings keyed by
    # proposed-detector category.
    surfacings: dict[str, list[dict]] = {}
    for kind in ("issues", "discussions"):
        kind_dir = docs_repo / kind
        if not kind_dir.is_dir():
            continue
        for entry in sorted(kind_dir.iterdir()):
            if not entry.is_dir():
                continue
            body_path = entry / "body.md"
            meta_path = entry / "meta.json"
            if not body_path.is_file():
                continue
            try:
                body = body_path.read_text(encoding="utf-8")
            except OSError:
                continue
            if not is_gap_discovery_body(body):
                continue
            # Audit window filter — skip Issues older than the cutoff.
            if meta_path.is_file():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    meta = {}
                filed = parse_filed_at(meta)
                if filed is not None and filed < cutoff:
                    continue
            else:
                meta = {}
            # Skip if explicitly resolved.
            if meta.get("detector_proposal_resolved") is True:
                continue
            for proposed in proposed_detectors(body):
                category = categorize_proposal(proposed)
                if category in covered_categories:
                    continue
                surfacings.setdefault(category, []).append({
                    "kind": kind,
                    "number": meta.get("number") or entry.name,
                    "proposed_detector": proposed,
                })

    findings: list = []
    for category, items in surfacings.items():
        # Severity climbs with surfacing count.
        count = len(items)
        if count >= 3:
            sev: GapSeverity = "fail"
        elif count == 2:
            sev = "warn"
        else:
            sev = "info"
        # Honor caller-passed severity as a ceiling — caller
        # may force lower.
        if severity == "info":
            sev = "info"
        elif severity == "warn" and sev == "fail":
            sev = "warn"
        sample = ", ".join(
            f"#{i['number']}" for i in items[:3]
        )
        suffix = f" (+{count - 3} more)" if count > 3 else ""
        findings.append(make_gap_finding(
            detector=DETECTOR_NAME,
            category="meta",
            severity=sev,
            location=make_gap_location(path=f"{items[0]['kind']}/{items[0]['number']}/body.md"),
            message=(
                f"Gap category {category!r} has {count} "
                f"surfacing(s) without a covering detector: "
                f"{sample}{suffix}"
            ),
            suggestion=(
                f"Either implement a {items[0]['proposed_detector']} "
                f"detector covering this category, or close the "
                f"surfacing Issue(s) as not_planned (sets "
                f"detector_proposal_resolved in meta.json) to "
                f"acknowledge the gap-class as out-of-scope."
            ),
            tags=("meta", "registry_coverage"),
        ))
    return findings


register_detector(DETECTOR_NAME, detect)
