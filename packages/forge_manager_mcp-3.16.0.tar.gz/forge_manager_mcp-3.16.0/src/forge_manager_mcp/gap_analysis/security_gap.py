"""security_gap detector (Phase 3.7.0 D3 / #348).

Walks the project's `.gitignore` looking for missing entries that
commonly hide secrets. Surfaces a finding when a token-shaped or
credential-shaped filename pattern isn't excluded.

**Scope.** First-pass check: gitignore hygiene for known
secret-file patterns. Real secret-scanning (running gitleaks /
trufflehog against the working tree) is a separate concern + adds
runtime deps; this detector is a structural heuristic that runs
cheaply on every plan-time review.

**Why this matters.** The 2026-04-28 Codeberg-token-leak in
`git remote -v` surfaced because the operator embedded the token
in the remote URL — git tracks remotes via `.git/config` (not
gitignored, but local-only), but a careless `git remote -v` print
publicly leaks. A `.codeberg-token` file at repo root that the
operator wrote tokens to but forgot to gitignore would have
leaked to the public mirror push.

**Heuristic, not policy.** Some projects deliberately track
``token.example`` files (template / docs); the detector flags
every pattern match and the operator triages.

Per Rule 2 the file IO is the effect; gap-finding emission is
pure. ``analyze_gitignore`` takes the gitignore text + project
root + returns findings; ``detect`` does the file walk.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "security_gap"


# Filename patterns that commonly hold secrets. If any of these
# match a tracked file in the repo and aren't covered by
# `.gitignore`, the detector flags. Patterns target the most
# frequent operator slip-up cases — env files, per-platform
# token files, and AWS-style credential files. Not exhaustive;
# treat as the minimum-viable check.
_SECRET_FILENAME_PATTERNS: tuple[str, ...] = (
    ".env",
    ".env.*",
    "*-token",
    ".*token",
    ".*-token",
    "*.pem",
    "credentials",
    ".credentials",
    "*.p12",
    "*.key",
)


def analyze_gitignore(
    *,
    gitignore_text: str,
    severity: GapSeverity,
    project_root_label: str = ".",
) -> list:
    """Pure analyzer: given the .gitignore content + a label for
    the project root path, return findings for missing common
    secret-file patterns. Returns one finding per missing pattern.
    """
    # Normalize: strip blank lines + comments.
    gitignore_lines = {
        line.strip()
        for line in gitignore_text.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }

    findings: list = []
    for pattern in _SECRET_FILENAME_PATTERNS:
        if pattern in gitignore_lines:
            continue
        # Allow a less-specific match. E.g., `.env` covers
        # `.env.local` if the operator listed only `.env`.
        # That's rarely the intent (`.env*` is what you'd write).
        # Keep the strict match — operators add `.env*` not `.env`
        # for full coverage.
        findings.append(make_gap_finding(
            detector=DETECTOR_NAME,
            category="security",
            severity=severity,
            location=make_gap_location(
                path=f"{project_root_label}/.gitignore",
                line=None,
                symbol=pattern,
            ),
            message=(
                f"`.gitignore` doesn't exclude `{pattern}` "
                "— secret-file pattern unprotected"
            ),
            suggestion=(
                f"Append `{pattern}` to .gitignore. Catches the "
                "common operator slip of writing tokens / keys / "
                "env files that get tracked into a public mirror."
            ),
            tags=("gitignore", "secret_pattern"),
        ))
    return findings


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Reads `.gitignore` at the project
    root (and any subdirectory `.gitignore` if `scan_paths` is
    supplied)."""
    targets: list[Path]
    if scan_paths:
        targets = [
            p if p.is_absolute() else project_root / p for p in scan_paths
        ]
    else:
        targets = [project_root]

    findings: list = []
    for target in targets:
        if not target.is_dir():
            continue
        gitignore = target / ".gitignore"
        if not gitignore.is_file():
            findings.append(make_gap_finding(
                detector=DETECTOR_NAME,
                category="security",
                severity=severity,
                location=make_gap_location(
                    path=str(gitignore),
                    line=None,
                    symbol=".gitignore",
                ),
                message=(
                    f"No `.gitignore` at {target} — secret-file "
                    "patterns unprotected by default"
                ),
                suggestion=(
                    "Add a .gitignore covering common secret "
                    "patterns: .env*, *-token, *.pem, *.key, "
                    "credentials, etc."
                ),
                tags=("gitignore", "missing"),
            ))
            continue
        try:
            text = gitignore.read_text(encoding="utf-8")
        except OSError:
            continue
        try:
            label = str(target.relative_to(project_root))
        except ValueError:
            label = str(target)
        findings.extend(analyze_gitignore(
            gitignore_text=text,
            severity=severity,
            project_root_label=label or ".",
        ))
    return findings


register_detector(DETECTOR_NAME, detect)
