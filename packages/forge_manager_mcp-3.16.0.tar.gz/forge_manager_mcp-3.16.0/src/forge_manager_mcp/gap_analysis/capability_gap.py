"""capability_gap detector (Phase 3.7.0 D3 / #348).

Walks Python source files under the project's adapters/ tree
looking for ``raise NotImplementedError(...)`` patterns. Each
match flags a capability the backend declares but doesn't yet
implement.

**Scope.** First-pass catalog of unimplemented Protocol surfaces.
The ``adapters/*.py`` tree is the obvious target — every adapter
is expected to fully implement ``PlatformAdapter``, but in practice
gaps exist (e.g., ``LocalStoreAdapter`` raises
``NotImplementedError`` on ``compute_drift`` because LocalStore
has no remote to drift against, and that's by design).

**Heuristic, not policy.** Some ``NotImplementedError`` raises are
deliberate (per-backend N/A) and some are pending work. The
detector flags every match; operators triage. Future enhancement:
read the docstring on the raise site for `(intentional)` or
`(deferred)` markers and suppress.

Per Rule 2 the file walk is the effect; gap-finding emission is
pure of file IO. ``analyze_module`` takes parsed AST + returns
findings; ``detect`` walks the filesystem.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "capability_gap"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
})


# Default scan roots — adapter implementations are the obvious
# target. Other directories (handlers, replication) raise NIE for
# different reasons (e.g., dispatch-not-yet-wired) and surfacing
# those is left to a future per-directory detector.
_DEFAULT_SCAN_SUBDIRS: tuple[str, ...] = (
    "src/forge_manager_mcp/adapters",
    "forge_manager_mcp/adapters",
)


def _is_not_implemented_raise(node: ast.AST) -> bool:
    """True if `node` is `raise NotImplementedError(...)` or `raise NotImplementedError`."""
    if not isinstance(node, ast.Raise) or node.exc is None:
        return False
    exc = node.exc
    # `raise NotImplementedError` (bare name)
    if isinstance(exc, ast.Name) and exc.id == "NotImplementedError":
        return True
    # `raise NotImplementedError(...)`
    if (
        isinstance(exc, ast.Call)
        and isinstance(exc.func, ast.Name)
        and exc.func.id == "NotImplementedError"
    ):
        return True
    return False


def _enclosing_method_name(
    raise_node: ast.AST, module: ast.Module,
) -> str | None:
    """Find the nearest enclosing FunctionDef / AsyncFunctionDef
    name for a raise node. Returns None if the raise is at module
    or class level."""
    raise_lineno = getattr(raise_node, "lineno", None)
    if raise_lineno is None:  # pragma: no cover — DEFENSIVE: ast.parse always populates lineno on raise nodes; the None-fallback guards against synthesized AST inputs that don't.
        return None
    candidates: list[tuple[int, str]] = []
    for n in ast.walk(module):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            start = n.lineno
            end = getattr(n, "end_lineno", start)
            if start <= raise_lineno <= end:
                candidates.append((start, n.name))
    if not candidates:
        return None
    candidates.sort(key=lambda item: -item[0])
    return candidates[0][1]


def analyze_module(
    *,
    path: Path,
    source: str,
    severity: GapSeverity,
) -> list:
    """Pure analyzer: parse `source` and yield findings for every
    `raise NotImplementedError` site. Returns empty list on parse
    error rather than raising — the detector is best-effort.
    """
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []

    findings: list = []
    for node in ast.walk(tree):
        if not _is_not_implemented_raise(node):
            continue
        method_name = _enclosing_method_name(node, tree)
        symbol = method_name or "<module-level>"
        findings.append(make_gap_finding(
            detector=DETECTOR_NAME,
            category="capability",
            severity=severity,
            location=make_gap_location(
                path=str(path),
                line=getattr(node, "lineno", None),
                symbol=symbol,
            ),
            message=(
                f"`{symbol}` raises NotImplementedError — "
                "capability declared but not implemented"
            ),
            suggestion=(
                "Implement the method, or document the deliberate "
                "no-op with an explanation of which backend / "
                "feature surface it's N/A for."
            ),
            tags=("adapter", "unimplemented"),
        ))
    return findings


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Walks Python files under the adapter
    tree (default) or under the operator-supplied `scan_paths`."""
    if scan_paths:
        roots = [
            p if p.is_absolute() else project_root / p for p in scan_paths
        ]
    else:
        roots = [
            project_root / sub for sub in _DEFAULT_SCAN_SUBDIRS
            if (project_root / sub).is_dir()
        ]
        if not roots:
            return []

    findings: list = []
    for root in roots:
        if not root.is_dir():
            continue
        for py_path in root.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in py_path.parts):
                continue
            try:
                source = py_path.read_text(encoding="utf-8")
            except OSError:
                continue
            findings.extend(analyze_module(
                path=py_path, source=source, severity=severity,
            ))
    return findings


register_detector(DETECTOR_NAME, detect)
