"""test_coverage_gap detector (Phase 3.6.0 D1 / #348).

Walks BUILD files under the project. For each `py_library` target
that lacks a corresponding `py_test` target referencing the
library in its `deps`, emits a `test_coverage` gap finding.

**Heuristic, not coverage-percentage.** Real coverage measurement
requires running tests with `coverage.py`; that's a different
scope. This detector flags the structural gap: "this library has
no test target wired to it" — usually a sign that the module
has zero direct tests.

**False positives expected.** A library may be tested transitively
via a sibling target's deps. Or the library is a re-export shim
with no testable surface (e.g., `__init__.py` aggregates).
Operators treat findings as candidates.

**Why this would have caught #350.** The 3.5.0 GA escape — `log_dir`
not imported in `daemon/main.py` — slipped because no test target
exercised `daemon/main.py`'s startup path. `daemon_main` py_library
existed; no `test_main` py_test referenced it. Running this
detector on the 3.5.0 plan retrospectively (D2) surfaces it.

Per Rule 2 the BUILD scan is the effect; gap-finding emission is
pure of file IO. ``analyze_build_files`` takes parsed targets +
returns findings; ``detect`` walks the filesystem.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable

from forge_manager_mcp.code_design.build_parser import is_test_rule, parse_file
from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "test_coverage_gap"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
})


# Library rules that should have test coverage. Excludes binaries
# and aliases; binaries are typically tested via integration paths
# rather than unit tests.
_LIBRARY_RULES: frozenset[str] = frozenset({
    "py_library",
})


def _is_library_target(target) -> bool:
    return target.rule in _LIBRARY_RULES


def _normalize_dep(dep: str) -> str:
    """Strip leading colons + workspace-prefixes for comparison.

    `:foo` → `foo`
    `//forge_manager_mcp:bar` → `bar`
    `@pip//:requirement_x` → `requirement_x` (irrelevant here but
    consistent).
    """
    if dep.startswith(":"):
        return dep[1:]
    if ":" in dep:
        return dep.split(":")[-1]
    return dep


def analyze_build_files(
    *,
    library_targets: dict[Path, list],
    test_targets: dict[Path, list],
    severity: GapSeverity,
) -> list:
    """Pure analyzer: given parsed library + test targets keyed by
    BUILD path, return findings for libraries without coverage.

    A library is "covered" when at least one py_test in the same
    BUILD file (or any test BUILD file in the project) references
    it via a `:name`-style or workspace-relative dep.
    """
    # Index test deps across all test BUILD files: every dep an
    # py_test references gets added to a global "covered" set.
    covered_names: set[str] = set()
    for path, tests in test_targets.items():
        for t in tests:
            for dep in t.deps:
                covered_names.add(_normalize_dep(dep))

    findings: list = []
    for build_path, libs in library_targets.items():
        for lib in libs:
            if lib.name is None:
                continue
            if lib.name in covered_names:
                continue
            # Library has no test referencing it.
            findings.append(make_gap_finding(
                detector=DETECTOR_NAME,
                category="test_coverage",
                severity=severity,
                location=make_gap_location(
                    path=str(build_path),
                    line=lib.line,
                    symbol=lib.name,
                ),
                message=(
                    f"py_library '{lib.name}' has no py_test "
                    f"target referencing it in deps"
                ),
                suggestion=(
                    f"Add `py_test(name='test_{lib.name}', "
                    f"deps=[':{lib.name}'])` in tests/ — even a "
                    "smoke test that imports the module catches "
                    "import-miss bugs (e.g., 3.5.0 #350 log_dir)."
                ),
                tags=("library", "missing_test"),
            ))
    return findings


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Walks BUILD files under ``project_root``
    (or each path in ``scan_paths``); returns gap findings."""
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    library_targets: dict[Path, list] = {}
    test_targets: dict[Path, list] = {}

    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if not full.is_dir():
            continue
        for build_path in full.rglob("BUILD*"):
            if any(part in _DEFAULT_DENYLIST for part in build_path.parts):
                continue
            if build_path.name not in ("BUILD", "BUILD.bazel"):
                continue
            try:
                parsed = parse_file(build_path)
            except Exception:
                continue
            libs_here = [t for t in parsed if _is_library_target(t)]
            tests_here = [t for t in parsed if is_test_rule(t)]
            if libs_here:
                library_targets[build_path] = libs_here
            if tests_here:
                test_targets[build_path] = tests_here

    return analyze_build_files(
        library_targets=library_targets,
        test_targets=test_targets,
        severity=severity,
    )


register_detector(DETECTOR_NAME, detect)
