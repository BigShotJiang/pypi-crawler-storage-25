"""acceptance_unmet_gap detector (Phase 3.6.0 D1+ / #348).

Walks closed Issues + Discussions in the local canonical store
(``<docs-repo>/issues/<n>/`` and ``<docs-repo>/discussions/<n>/``).
For each closed item with an ``## Acceptance criteria`` section,
parses the markdown checklist and flags items with unchecked
boxes (``- [ ]`` markers).

**Plan-vs-reality heuristic.** When an Issue closes-as-completed
with unchecked acceptance criteria, that's a *promise made vs.
promise kept* gap — either the criterion was actually met but the
checkbox wasn't ticked (process gap), or the criterion was
dropped during scope-cut without explicit acknowledgment (scope
gap). Either way: surface it for operator triage.

**Not authoritative — heuristic.** A checkbox left unchecked in a
closed Issue may be:
- Intentional (deferred via documented scope cut; the close
  comment narrates the decision).
- Forgotten (the criterion was met but nobody ticked the box).
- Real gap (the close shipped without the criterion).

The detector emits findings; operators triage. The same closed-
Issue review that approves the close should tick all met boxes.

**Where this fits #348.** Detector class operating on PLANNING
artifacts (Issue/Discussion bodies in the canonical store), not
code. Complementary to `test_coverage_gap` which scans BUILD
files. Together they cover both "code we shipped" + "promises we
made" surface area.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Iterable

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "acceptance_unmet_gap"


# Match any heading whose text starts with "Acceptance criteria"
# (case-insensitive; allows trailing parenthetical like
# "Acceptance criteria (for 3.5.1 patch)").
_ACCEPTANCE_HEADING = re.compile(
    r"^#+\s+acceptance\s+criteria\b", re.IGNORECASE | re.MULTILINE,
)

# Match the next heading after the acceptance section starts (any
# `#` prefix at line start; bounds the section).
_ANY_HEADING = re.compile(r"^#+\s+\S", re.MULTILINE)

_UNCHECKED_BOX = re.compile(r"^\s*[-*]\s+\[\s\]\s+(.+)$", re.MULTILINE)
_CHECKED_BOX = re.compile(r"^\s*[-*]\s+\[[xX]\]\s+.+$", re.MULTILINE)


def find_docs_repo(project_root: Path) -> Path | None:
    """Locate the canonical docs repo for ``project_root``.

    Resolution order:
      1. ``$FORGE_MANAGER_DOCS_REPO`` env var (operator override).
      2. Sibling-by-convention: ``<project>-docs`` next to project,
         where ``<project>`` is the dev repo's basename minus the
         ``-dev`` suffix if present.

    Returns None if no candidate exists. Detector returns empty
    findings when this resolves to None — graceful degradation.
    """
    override = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if override:
        path = Path(override)
        if path.is_dir():
            return path
        return None

    base = project_root.name
    if base.endswith("-dev"):
        candidate_name = base[:-4] + "-docs"
    else:
        candidate_name = base + "-docs"
    candidate = project_root.parent / candidate_name
    if candidate.is_dir():
        return candidate
    return None


def parse_acceptance_section(body: str) -> "tuple[list[str], list[str]] | None":
    """Pure parser. Returns ``(unchecked_items, checked_items)`` or
    None if no Acceptance criteria heading found.

    Items are the text after the ``- [ ]`` / ``- [x]`` marker.
    """
    match = _ACCEPTANCE_HEADING.search(body)
    if match is None:
        return None
    section_start = match.end()
    # Find the next heading after the acceptance section starts;
    # bound the section there. If none, take the rest of the body.
    next_heading = _ANY_HEADING.search(body, pos=section_start)
    section_end = next_heading.start() if next_heading else len(body)
    section = body[section_start:section_end]
    unchecked = [m.group(1).strip() for m in _UNCHECKED_BOX.finditer(section)]
    checked = [m.group(0).strip() for m in _CHECKED_BOX.finditer(section)]
    return unchecked, checked


def is_closed(state_text: str) -> bool:
    """Cheap closed-state check.

    State files contain ``"open"`` or ``"closed"`` (with possible
    trailing newline / whitespace). Match case-insensitive.
    """
    return state_text.strip().lower() == "closed"


def analyze_thread(
    *,
    body: str,
    state_text: str,
    location_path: str,
    detector_severity: GapSeverity,
) -> list:
    """Pure analyzer for one Issue/Discussion's body+state.

    Emits findings only when:
    - The thread is closed (state == "closed").
    - The body has an ``## Acceptance criteria`` section.
    - That section contains ≥1 unchecked checkbox.
    """
    if not is_closed(state_text):
        return []
    parsed = parse_acceptance_section(body)
    if parsed is None:
        return []
    unchecked, _checked = parsed
    if not unchecked:
        return []
    return [make_gap_finding(
        detector=DETECTOR_NAME,
        category="capability",
        severity=detector_severity,
        location=make_gap_location(path=location_path),
        message=(
            f"Closed thread has {len(unchecked)} unchecked "
            f"acceptance-criteria item(s); review for scope-cut "
            f"vs forgotten-tick"
        ),
        suggestion=(
            "Re-open + tick the boxes that were met, "
            "OR add a closing comment narrating the deferred items + "
            "the follow-up tracker."
        ),
        tags=("plan", "acceptance"),
    )]


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point.

    Walks ``<docs-repo>/{issues,discussions}/`` for closed threads
    with unchecked acceptance criteria. Returns gap findings.

    Graceful degradation: when the docs repo can't be located,
    returns empty findings (no false negatives surfaced as
    actionable findings).
    """
    docs_repo = find_docs_repo(project_root)
    if docs_repo is None:
        return []

    findings: list = []
    for kind in ("issues", "discussions"):
        kind_dir = docs_repo / kind
        if not kind_dir.is_dir():
            continue
        for thread_dir in sorted(kind_dir.iterdir()):
            if not thread_dir.is_dir():
                continue
            body_file = thread_dir / "body.md"
            state_file = thread_dir / "state.txt"
            if not body_file.is_file() or not state_file.is_file():
                continue
            try:
                body = body_file.read_text(encoding="utf-8")
                state_text = state_file.read_text(encoding="utf-8")
            except OSError:
                continue
            location_path = (
                f"{kind}/{thread_dir.name}/body.md"
            )
            findings.extend(analyze_thread(
                body=body,
                state_text=state_text,
                location_path=location_path,
                detector_severity=severity,
            ))
    return findings


register_detector(DETECTOR_NAME, detect)
