"""Detector → gap-compound-doc bridge (#405 / 3.11.0 D1.b Phase 4).

Bridges the existing gap_analysis detector framework to the new
``gaps/<category>/`` compound-doc surface (3.11.0 D1.b Phase 1).
Detector findings get persisted as durable triage state via
``upsert_gap``; the operator's state-transition decisions
(triage / accepted / filed / ignored) survive across detector runs
per #405 S2's re-detection rules.

The orchestrator is callable-injected so MCP-side code (passing a
``dispatch_write``-driven upsert) and daemon-side code (passing a
``ReplicationManager.write``-driven upsert) share the same logic.
Watch.py wires the daemon variant into the live detection cycle
(Phase 5).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Awaitable, Callable

from ..adapters.types import GapFinding as StorageGapFinding


# Tier classification — mechanical detectors fire on hard rules
# (gates can fail on these); advisory detectors are info-severity
# nudges. Centralized here so one place owns the policy.
_MECHANICAL_DETECTORS: frozenset[str] = frozenset({
    "test_coverage_gap",
    "capability_gap",
    "security_gap",
    "usability_gap",
    "acceptance_unmet_gap",
    "discussion_lifecycle_gap",
    "stale_milestone_plan_gap",
    "registry_coverage_gap",
    # code_design rules (mechanical tier per the 3.4.1 / 3.5.0 framework)
    "test_purity_tagging",
    "schema_tests_tagged",
    "negative_tests_tagged",
    "schema_as_functions",
    "utility_dir_isolation",
})

_ADVISORY_DETECTORS: frozenset[str] = frozenset({
    "effect_inline_advisory",
})


def infer_tier(detector_name: str) -> str:
    """Return ``mechanical`` or ``advisory`` for a detector name.

    Defaults to ``advisory`` for unknown detectors (safer; advisory
    tier is info-severity by default and won't fail a cut even at
    severity rollup time). Operators can re-tier by editing the
    gap doc's ``meta.json.tier`` field via ``update_gap_meta``.
    """
    if detector_name in _MECHANICAL_DETECTORS:
        return "mechanical"
    if detector_name in _ADVISORY_DETECTORS:
        return "advisory"
    # Code-design rules conventionally namespace as
    # ``code_design.<rule>`` per the 3.5.0 framework.
    if detector_name.startswith("code_design."):
        # Strip prefix to check the suffix against the registry.
        suffix = detector_name.split(".", 1)[1]
        if suffix in _MECHANICAL_DETECTORS:
            return "mechanical"
        if suffix in _ADVISORY_DETECTORS:
            return "advisory"
    return "advisory"


def group_findings_by_detector(
    findings: list,
) -> dict[str, list]:
    """Group gap_analysis findings by their ``detector`` field.

    One gap compound doc per detector — operators triage at the
    category granularity per #405 OQ1 closure. Multi-finding
    detectors get one document with all findings; single-finding
    detectors get a 1-row document.

    Pure function — no side effects.
    """
    grouped: dict[str, list] = {}
    for finding in findings:
        detector = getattr(finding, "detector", None)
        if not detector:
            continue
        grouped.setdefault(detector, []).append(finding)
    return grouped


def to_storage_finding(detector_finding) -> StorageGapFinding:
    """Convert a gap_analysis ``GapFinding`` (with ``detector`` /
    ``category`` / ``location.path|line`` / ``severity`` /
    ``message``) to the storage ``GapFinding`` shape (``path`` /
    ``line`` / ``severity`` / ``message`` / timestamps).

    ``first_seen_at`` / ``last_seen_at`` default to now() — the
    persistence layer (LocalStoreAdapter.upsert_gap) preserves
    ``first_seen_at`` from prior persisted findings on re-runs per
    the merge logic.
    """
    now = datetime.now(timezone.utc)
    location = detector_finding.location
    return StorageGapFinding(
        path=location.path,
        line=location.line,
        severity=detector_finding.severity,
        message=detector_finding.message,
        first_seen_at=now,
        last_seen_at=now,
    )


def to_storage_finding_from_code_design(code_design_finding) -> StorageGapFinding:
    """Convert a code_design ``Finding`` (with ``.rule`` /
    ``.severity`` / ``.location.path|line`` / ``.message``) to the
    storage ``GapFinding`` shape.

    Code_design findings live in a parallel package
    (``forge_manager_mcp.code_design``) with a different field
    layout than gap_analysis. This converter handles them so
    watch.py can persist code_design findings without first
    re-shaping them into gap_analysis form.
    """
    now = datetime.now(timezone.utc)
    location = code_design_finding.location
    return StorageGapFinding(
        path=location.path,
        line=getattr(location, "line", None),
        severity=code_design_finding.severity,
        message=code_design_finding.message,
        first_seen_at=now,
        last_seen_at=now,
    )


def group_code_design_findings_by_rule(
    findings: list,
) -> dict[str, list]:
    """Group code_design findings by their ``.rule`` field. One gap
    compound doc per rule (e.g. ``code_design.test_purity_tagging``).
    """
    grouped: dict[str, list] = {}
    for finding in findings:
        rule = getattr(finding, "rule", None)
        if not rule:
            continue
        category = f"code_design.{rule}"
        grouped.setdefault(category, []).append(finding)
    return grouped


async def persist_code_design_findings(
    findings: list,
    *,
    upsert: Callable[..., Awaitable],
) -> dict[str, dict]:
    """Persist code_design findings as ``code_design.<rule>`` gap docs.

    Sibling of ``persist_findings`` for the parallel code_design
    finding shape. Watch.py invokes this every detection cycle.
    """
    grouped = group_code_design_findings_by_rule(findings)
    results: dict[str, dict] = {}
    for category, rule_findings in grouped.items():
        tier = infer_tier(category)
        storage_findings = [
            to_storage_finding_from_code_design(f) for f in rule_findings
        ]
        await upsert(
            category=category,
            tier=tier,
            findings=storage_findings,
        )
        results[category] = {
            "persisted_count": len(storage_findings),
            "tier": tier,
        }
    return results


async def persist_findings(
    findings: list,
    *,
    upsert: Callable[..., Awaitable],
) -> dict[str, dict]:
    """Persist a flat list of gap_analysis findings as gap
    compound-docs, one per detector category.

    ``upsert`` is the call-site-bound persistence callable. Both
    invocations are awaited per category:

        await upsert(category=<str>, tier=<str>, findings=<list>)

    MCP-side: pass ``dispatch_write``-driven upsert that POSTs to
    the daemon's ``/writes`` ``upsert_gap`` op.
    Daemon-side (watch.py): pass a closure over
    ``ReplicationManager.write`` directly.

    Returns ``{category: {persisted_count, tier}}`` for caller
    consumption (logging, telemetry, action_log entries).
    """
    grouped = group_findings_by_detector(findings)
    results: dict[str, dict] = {}
    for detector, detector_findings in grouped.items():
        tier = infer_tier(detector)
        storage_findings = [
            to_storage_finding(f) for f in detector_findings
        ]
        await upsert(
            category=detector,
            tier=tier,
            findings=storage_findings,
        )
        results[detector] = {
            "persisted_count": len(storage_findings),
            "tier": tier,
        }
    return results
