"""GapDetector registry (Phase 3.6.0 D1 / #348).

Sibling of `code_design/registry.py`. Each gap detector registers
itself via ``register_detector`` at import time; the orchestrator
walks the registry to dispatch.

Detector signature: pure-ish function returning gap findings.

    Detector = (project_root, scan_paths, severity) -> list[GapFinding]

Module-level state: the registry dict itself, same one-time-write
pattern as the code_design registry.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Literal


GapDetector = Callable[
    [Path, "list[Path] | None", Literal["fail", "warn", "info"]],
    list,
]


_REGISTRY: dict[str, GapDetector] = {}


def register_detector(detector_name: str, detector: GapDetector) -> None:
    """Register a gap detector under its name. Idempotent — re-
    registration overwrites silently to support test-time rebinding.
    """
    _REGISTRY[detector_name] = detector


def get_detector(detector_name: str) -> GapDetector | None:
    """Return the registered detector or None."""
    return _REGISTRY.get(detector_name)


def all_detectors() -> list[str]:
    """Return registered detector names in registration order."""
    return list(_REGISTRY.keys())


def clear_registry() -> None:
    """Test helper. Production code never calls this."""
    _REGISTRY.clear()
