"""Canonical-store walkers for gap compound docs (#406 / 3.11.0 D2.a).

Pure read-only helpers that walk ``<docs>/gaps/*/meta.json`` to
build the data structures the Claude Code surface consumes
(``open_session.gaps`` summary, ``recover_context.gaps`` bundle,
``gaps_for_file`` per-file lookup).

Pure functions — no side effects beyond filesystem reads. The
docs-root resolution chain matches the existing release-time
gates (``$FORGE_MANAGER_DOCS_REPO`` → ``~/<project>-docs/``).
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import cache
from pathlib import Path


@cache
def _gap_summary_class() -> type:
    @dataclass(frozen=True)
    class GapSummary:
        """Headline session-open summary (#406 S1).

        Per-category detail lives in ``categories``; this is the
        glance-level view Claude consumes first.
        """
        cut_blocked: bool
        blocking_count: int
        blocking_categories: tuple[str, ...]
        accepted_count: int
        filed_count: int
        ignored_count: int
        total_active_findings: int
        highest_severity: str

    return GapSummary


GapSummary = _gap_summary_class()


@cache
def _gap_category_snapshot_class() -> type:
    @dataclass(frozen=True)
    class GapCategorySnapshot:
        """Per-category snapshot in the open_session response."""
        category: str
        state: str
        severity: str
        finding_count: int
        anchored_milestone: str | None
        last_run_at: str | None
        url: str
        filed_issue: int | None
        filed_target_milestone: str | None

    return GapCategorySnapshot


GapCategorySnapshot = _gap_category_snapshot_class()


_SEVERITY_PRECEDENCE: dict[str, int] = {"fail": 3, "warn": 2, "info": 1}


def _severity_max(severities: list[str]) -> str:
    """Highest-wins rollup. Empty list → 'info'."""
    if not severities:
        return "info"
    return max(severities, key=lambda s: _SEVERITY_PRECEDENCE.get(s, 0))


def resolve_docs_root(project_dir: Path) -> Path | None:
    """Resolve canonical docs root via env-var → conventional-path
    chain. Returns None when no docs root resolves.

    Pure; no fallback creates a directory or surfaces warnings —
    callers handle the None case (typically: skip the gap surface).
    """
    env = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if env:
        candidate = Path(env)
        if candidate.is_dir():
            return candidate
    fallback = (Path.home() / f"{project_dir.name}-docs").resolve()
    if fallback.is_dir():
        return fallback
    return None


def walk_gap_metas(docs_root: Path) -> list[dict]:
    """Walk ``<docs>/gaps/*/meta.json`` and return parsed dicts.

    Pure read; no enrichment. Skips entries that fail to parse
    (corrupt meta.json shouldn't abort the walk). Returns empty
    list when ``<docs>/gaps/`` is absent.
    """
    gaps_dir = docs_root / "gaps"
    if not gaps_dir.is_dir():
        return []
    metas: list[dict] = []
    for entry in sorted(gaps_dir.iterdir()):
        if not entry.is_dir():
            continue
        meta_path = entry / "meta.json"
        if not meta_path.is_file():
            continue
        try:
            metas.append(json.loads(meta_path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError):
            continue
    return metas


def build_summary(
    metas: list[dict], *, active_milestone: str | None = None,
):
    """Compose ``GapSummary`` from a list of parsed gap metas.

    ``cut_blocked`` semantics match the
    ``release.no_triage_gaps_against_cut`` gate (Phase 3): blocks
    when state=triage AND (anchored == active OR unanchored).
    """
    blocking: list[str] = []
    accepted = 0
    filed = 0
    ignored = 0
    total_findings = 0
    severities: list[str] = []
    for meta in metas:
        state = meta.get("state", "triage")
        finding_count = int(meta.get("finding_count", 0))
        total_findings += finding_count
        if finding_count > 0:
            severities.append(meta.get("severity", "info"))
        if state == "triage":
            anchored = meta.get("anchored_milestone")
            if anchored == active_milestone or anchored is None:
                blocking.append(meta.get("detector_category", ""))
        elif state == "accepted":
            accepted += 1
        elif state == "filed":
            filed += 1
        elif state == "ignored":
            ignored += 1
    return GapSummary(
        cut_blocked=bool(blocking),
        blocking_count=len(blocking),
        blocking_categories=tuple(c for c in blocking if c),
        accepted_count=accepted,
        filed_count=filed,
        ignored_count=ignored,
        total_active_findings=total_findings,
        highest_severity=_severity_max(severities),
    )


def build_category_snapshots(
    metas: list[dict],
):
    """Compose per-category snapshot tuples for the open_session
    ``categories`` list.

    Excludes ``ignored`` gaps from the per-category list — Claude's
    decision rubric (#406 S4) treats ignored as "silent always" so
    surfacing them at session-open is noise.
    """
    out: list = []
    for meta in metas:
        state = meta.get("state", "triage")
        if state == "ignored":
            continue
        category = meta.get("detector_category", "")
        out.append(GapCategorySnapshot(
            category=category,
            state=state,
            severity=meta.get("severity", "info"),
            finding_count=int(meta.get("finding_count", 0)),
            anchored_milestone=meta.get("anchored_milestone"),
            last_run_at=meta.get("last_run_at"),
            url=f"local://gaps/{category}",
            filed_issue=meta.get("filed_issue"),
            filed_target_milestone=meta.get("filed_target_milestone"),
        ))
    return out


def findings_for_path(metas: list[dict], path: str) -> list[dict]:
    """Walk gap metas for findings whose path matches the given path.

    Filters out findings on ``ignored`` gaps (per #406 decision
    rubric — ignored gaps stay silent always). Each returned dict
    carries ``category`` + ``state`` so Claude knows the parent gap's
    triage state when deciding whether to surface the finding in a
    pre-action statement.
    """
    out: list[dict] = []
    for meta in metas:
        state = meta.get("state", "triage")
        if state == "ignored":
            continue
        category = meta.get("detector_category", "")
        for finding in meta.get("findings", []):
            if finding.get("path") == path:
                out.append({
                    "category": category,
                    "state": state,
                    "path": finding.get("path"),
                    "line": finding.get("line"),
                    "severity": finding.get("severity"),
                    "message": finding.get("message"),
                })
    return out


def categories_touching_path(metas: list[dict], path: str) -> list[str]:
    """Return the set of category names whose findings touch ``path``,
    sorted ascending. Ignored categories excluded."""
    cats: set[str] = set()
    for meta in metas:
        if meta.get("state") == "ignored":
            continue
        for finding in meta.get("findings", []):
            if finding.get("path") == path:
                cats.add(meta.get("detector_category", ""))
                break
    return sorted(c for c in cats if c)
