"""Public-issue triage classifier (3.16.0 D5).

Heuristic + keyword-based classifier for public-mirror Issues per
RFC #25 OQ-D1 recommendation: ship a simple heuristic at 3.16.0;
upgrade to LLM-backed (via verify_existing_code_assumptions infra)
if heuristic precision drops below 70% in dogfood.

Output contract: ``classify_issue`` returns a dict matching the
operator-facing triage vocabulary:

  - ``category``: one of {"duplicate", "needs_info", "spam",
    "valid", "unclassified"}.
  - ``confidence``: float in [0.0, 1.0].
  - ``reasons``: list of human-readable strings explaining the
    classification ("body shorter than 50 chars", "matches
    existing Issue #42 by title fuzz", etc.).

Classifier is pure (no I/O, no global state). Caller fetches the
inputs (body / title / existing-issue corpus when checking for
duplicates) and dispatches via this function. Daemon-side
integration (endpoint + corpus build) ships in a follow-up.

Schema-as-functions per Rule 5: result dict constructed via
:func:`make_classification` factory; no top-level Pydantic.
"""
from __future__ import annotations

import re
from typing import Any, Iterable


# ---------------------------------------------------------------------------
# Category vocabulary
# ---------------------------------------------------------------------------

VALID_CATEGORIES = (
    "duplicate",
    "needs_info",
    "spam",
    "valid",
    "unclassified",
)


# ---------------------------------------------------------------------------
# Heuristic thresholds + signals
# ---------------------------------------------------------------------------

# Body shorter than this → likely needs_info. Threshold picked from
# operator dogfood: real triage-ready reports are typically 80+ chars
# (one sentence of context + one of repro). Anything under 50 is
# usually a stub.
MIN_USEFUL_BODY_CHARS = 50

# Spam markers — clear off-topic / promotional content. Conservative
# list; false positives are worse than false negatives here (an
# operator will eyeball misclassifications, but a real bug auto-
# spam-classified gets lost).
_SPAM_MARKERS = (
    "buy now",
    "click here",
    "viagra",
    "casino",
    "make money fast",
    "free crypto",
    "subscribe to my channel",
    # Common SEO-spam patterns: heavy emoji + URL combo.
    # Per OQ-D1: keep the list short; expand only when operator
    # surfaces false negatives.
)

# Needs-info markers — phrases that signal the report is incomplete.
# Triggers needs_info classification even if body length is fine.
_NEEDS_INFO_MARKERS = (
    "todo",
    "fill this in",
    "more details to follow",
    "tbd",
    "wip",
)

# Whitespace + URL regex for body normalization (for length check).
_URL_RE = re.compile(r"https?://\S+")
_WHITESPACE_RUN_RE = re.compile(r"\s+")


# ---------------------------------------------------------------------------
# Schema-as-functions factory
# ---------------------------------------------------------------------------


def make_classification(
    *,
    category: str,
    confidence: float,
    reasons: list[str],
) -> dict[str, Any]:
    """Construct a classification record. Validates the category
    against the operator-facing vocabulary; unknown categories
    raise ValueError so callers learn at the boundary."""
    if category not in VALID_CATEGORIES:
        raise ValueError(
            f"category must be one of {VALID_CATEGORIES}, "
            f"got {category!r}"
        )
    if not (0.0 <= confidence <= 1.0):
        raise ValueError(
            f"confidence must be in [0.0, 1.0], got {confidence!r}"
        )
    return {
        "category": category,
        "confidence": float(confidence),
        "reasons": list(reasons),
    }


# ---------------------------------------------------------------------------
# Per-category detectors
# ---------------------------------------------------------------------------


def _normalized_body_length(body: str) -> int:
    """Body length with URLs stripped + whitespace collapsed —
    avoids inflating the length count for a body that's mostly a
    pasted URL."""
    no_urls = _URL_RE.sub("", body)
    collapsed = _WHITESPACE_RUN_RE.sub(" ", no_urls).strip()
    return len(collapsed)


def _detect_spam(body: str, title: str) -> tuple[bool, list[str]]:
    """Spam detection: returns (is_spam, reasons)."""
    blob = (title + "\n" + body).lower()
    matches = [m for m in _SPAM_MARKERS if m in blob]
    if matches:
        return True, [
            f"spam marker matched: {m!r}" for m in matches
        ]
    return False, []


def _detect_needs_info(body: str, title: str) -> tuple[bool, list[str]]:
    """Needs-info: body too short OR contains stub markers."""
    reasons: list[str] = []
    norm_len = _normalized_body_length(body)
    if norm_len < MIN_USEFUL_BODY_CHARS:
        reasons.append(
            f"normalized body shorter than {MIN_USEFUL_BODY_CHARS} "
            f"chars ({norm_len})"
        )
    blob = (title + "\n" + body).lower()
    marker_hits = [m for m in _NEEDS_INFO_MARKERS if m in blob]
    if marker_hits:
        reasons.extend([
            f"stub marker matched: {m!r}" for m in marker_hits
        ])
    return bool(reasons), reasons


def _detect_duplicate(
    body: str,
    title: str,
    existing_titles: Iterable[str],
) -> tuple[bool, list[str]]:
    """Conservative duplicate detection: exact title match against
    an existing Issue (case-insensitive). Fuzzy / semantic
    matching deferred until the heuristic + LLM-backed split per
    OQ-D1; bare exact-match has trivial false-positive rate."""
    needle = title.strip().lower()
    if not needle:
        return False, []
    for existing in existing_titles:
        if existing.strip().lower() == needle:
            return True, [f"exact title match against existing Issue"]
    return False, []


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def classify_issue(
    *,
    body: str,
    title: str,
    existing_titles: Iterable[str] = (),
) -> dict[str, Any]:
    """Classify a public-mirror Issue into one of the operator-facing
    triage categories.

    Precedence (most-specific wins):
      1. spam — body or title hits a known spam marker.
      2. duplicate — title exactly matches an existing Issue.
      3. needs_info — body too short OR contains stub markers.
      4. valid — none of the above; passes triage to a human dev.

    Confidence is heuristic: 0.9 for high-confidence matches
    (spam markers, exact-title duplicate), 0.6 for medium
    (multiple needs_info signals), 0.4 for catchall valid.
    Operator UX renders confidence as a chip alongside the
    category.
    """
    spam_match, spam_reasons = _detect_spam(body, title)
    if spam_match:
        return make_classification(
            category="spam",
            confidence=0.9,
            reasons=spam_reasons,
        )

    dup_match, dup_reasons = _detect_duplicate(
        body, title, existing_titles,
    )
    if dup_match:
        return make_classification(
            category="duplicate",
            confidence=0.9,
            reasons=dup_reasons,
        )

    needs_match, needs_reasons = _detect_needs_info(body, title)
    if needs_match:
        return make_classification(
            category="needs_info",
            confidence=0.6 if len(needs_reasons) > 1 else 0.5,
            reasons=needs_reasons,
        )

    return make_classification(
        category="valid",
        confidence=0.4,
        reasons=["no spam / duplicate / needs-info signals matched"],
    )
