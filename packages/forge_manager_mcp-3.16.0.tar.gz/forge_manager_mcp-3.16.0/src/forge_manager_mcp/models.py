"""
Pydantic models for forge-manager-mcp.

All models are strict — missing fields raise immediately at
construction time, not at use time. This is the first line of
fail-fast enforcement.
"""

from __future__ import annotations

from functools import cache
from typing import Literal

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator


RelationshipType = Literal[
    "subsystem",
    "publish_target",
    "sibling",
    "cousin",
    "neighbor",
    "foreign",
    # Deprecated — pre-1.3.0 umbrella type that lumped sibling/cousin/
    # neighbor/foreign into one. Parsed with a deprecation warning in
    # config.py so existing configs continue to load. Migrate to the
    # precise sub-type at next config edit.
    "contribution_target",
]


@cache
def _repo_config_class() -> type:
    class RepoConfig(BaseModel):
        """Public/private/docs repo triple for a project.

        The docs repo is the canonical source the SiteRenderer (Hugo) reads
        from; bootstrap creates it as a third PUBLIC repo (e.g. `<project>-docs`)
        alongside the public mirror and private dev repo. Optional so configs
        written before the docs-repo bootstrap addition still validate.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        public: str = Field(..., description="org/repo-name for public mirror")
        private: str = Field(..., description="org/repo-name for private dev repo")
        docs: str | None = Field(
            None,
            description=(
                "org/repo-name for the docs repo (canonical source the "
                "SiteRenderer reads from). None on configs written before "
                "docs-repo bootstrap support landed."
            ),
        )

    return RepoConfig


RepoConfig = _repo_config_class()


@cache
def _related_repo_class() -> type:
    class RelatedRepo(BaseModel):
        """A repo connected to this project via a typed relationship.

        Six relationship types govern how Claude may act on the repo (#98,
        paired with skill §Multi-repo relations / §Cross-repo work protocol
        #97). See that prose for the full execution protocol per type.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        repo: str = Field(
            ...,
            description="owner/name fullname for the related repo (e.g. 'other-org/foo').",
        )
        relationship: RelationshipType = Field(
            ..., description="Relationship type; governs cross-repo mutation rules."
        )
        description: str | None = Field(
            None, description="Optional free-text note about the relationship."
        )

        @field_validator("repo")
        @classmethod
        def _repo_has_slash(cls, v: str) -> str:
            if "/" not in v or v.count("/") != 1 or not all(v.split("/")):
                raise ValueError(
                    f"repo must be in 'owner/name' form, got {v!r}"
                )
            return v

    return RelatedRepo


RelatedRepo = _related_repo_class()


@cache
def _project_board_class() -> type:
    class ProjectBoard(BaseModel):
        """GitHub Projects v2 board identifiers."""

        model_config = {"frozen": True, "extra": "forbid"}

        id: str = Field(..., description="GraphQL node ID")
        number: int = Field(..., gt=0)
        url: str = Field(..., description="Web URL for the board")
        status_field_id: str | None = Field(
            None, description="Status single-select field ID"
        )
        status_options: dict[str, str] | None = Field(
            None, description="Column name → option ID"
        )

    return ProjectBoard


ProjectBoard = _project_board_class()


@cache
def _discussion_category_class() -> type:
    class DiscussionCategory(BaseModel):
        """A single GitHub Discussion category."""

        model_config = {"frozen": True, "extra": "forbid", "populate_by_name": True}

        id: str = Field(..., description="GraphQL node ID")
        is_answerable: bool = Field(..., alias="isAnswerable")
        note: str | None = Field(None, description="Human-readable annotation")

    return DiscussionCategory


DiscussionCategory = _discussion_category_class()


@cache
def _discussion_categories_class() -> type:
    class DiscussionCategories(BaseModel):
        """Discussion categories declared in github-config.json.

        The named fields mirror the bootstrap defaults. `Announcements`
        is the GitHub-default Announcement-format category, used as-is
        from 2.0.0a2 onwards (#152); `Project` was the pre-2.0.0a2 name
        for the same role. Both are optional so existing and new configs
        both validate. Additional project-specific categories — e.g. a
        `General` category for admin session records — are accepted as
        extras and reachable via `model_extra`.
        """

        model_config = {
            "frozen": True,
            "extra": "allow",
            "populate_by_name": True,
        }

        Announcements: DiscussionCategory | None = Field(None)
        Project: DiscussionCategory | None = Field(None)
        Architecture: DiscussionCategory
        UX_UI: DiscussionCategory = Field(..., alias="UX / UI")
        Ideas: DiscussionCategory
        claude_use_only: DiscussionCategory = Field(..., alias="claude-use-only")

        @model_validator(mode="after")
        def all_ids_non_empty(self) -> "DiscussionCategories":
            entries: list[tuple[str, DiscussionCategory]] = [
                ("Architecture", self.Architecture),
                ("UX / UI", self.UX_UI),
                ("Ideas", self.Ideas),
                ("claude-use-only", self.claude_use_only),
            ]
            if self.Announcements is not None:
                entries.append(("Announcements", self.Announcements))
            if self.Project is not None:
                entries.append(("Project", self.Project))
            extras = self.model_extra if self.model_extra is not None else {}
            for name, value in list(extras.items()):
                if isinstance(value, DiscussionCategory):
                    extra_category = value
                else:
                    try:
                        extra_category = DiscussionCategory.model_validate(value)
                    except ValidationError as exc:
                        raise ValueError(
                            f"Extra discussion category '{name}' is invalid: {exc}"
                        ) from exc
                    extras[name] = extra_category
                entries.append((name, extra_category))
            for field_name, category in entries:
                if not category.id.strip():
                    raise ValueError(
                        f"Discussion category '{field_name}' has an empty ID. "
                        "Re-run bootstrap to regenerate github-config.json."
                    )
            return self

    return DiscussionCategories


DiscussionCategories = _discussion_categories_class()


# (Phase H / 3.5.0) SiteConfig REMOVED with Hugo. The static-site
# role moves to the daemon (D3a+ — D-UI's SolidJS app replaces
# Hugo). Pre-3.5.0 projects with a ``site`` block in
# forge-config.json silently ignore it on load (the field is
# stripped from GithubConfig); a future schema version will surface
# a deprecation warning.


@cache
def _github_config_class() -> type:
    class GithubConfig(BaseModel):
        """
        Parsed and validated github-config.json.

        Fails immediately at construction if any required field is
        missing or invalid. Downstream code can trust all fields exist.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        version: str
        # Accept both names through the 3.x line so 2.x → 3.0 migrations
        # don't have to rewrite this field on day one. The migration
        # translator does rewrite it (idempotently) so freshly-migrated
        # configs end up with the canonical name. (G1 — pre-release)
        skill: Literal["forge-manager", "active-claude-github"]
        account_type: Literal["org", "personal"]
        owner: str = Field(..., min_length=1)
        repos: RepoConfig
        project_board: ProjectBoard
        project_discussion_id: str = Field(..., min_length=1)
        session_lock_discussion_id: str = Field(..., min_length=1)
        discussion_categories: DiscussionCategories
        related_repos: list[RelatedRepo] = Field(default_factory=list)
        skill_version_at_bootstrap: str
        bootstrapped_at: str
        publish_target_outside_org: bool = Field(
            False,
            description=(
                "When True, the repo-shape audit (#116, #118) does not flag a "
                "publish_target whose owner differs from the project's org as "
                "drift. Used for personal-attribution OSS projects whose "
                "publish target intentionally lives outside the org."
            ),
        )
        publish_target_outside_org_reason: str | None = Field(
            None,
            description=(
                "Optional one-line reason recorded alongside "
                "publish_target_outside_org=True so future operators can see why "
                "the cross-owner placement is intentional."
            ),
        )
        docs_repo_path: str | None = Field(
            None,
            description=(
                "Absolute filesystem path to the local clone of the docs "
                "repo. The SiteRenderer reads from this path. When None, "
                "site.py falls back to $FORGE_MANAGER_DOCS_REPO env var, "
                "then to the conventional ~/<project>-docs/ location."
            ),
        )
        running_log_discussion_number: int | None = Field(
            None,
            ge=1,
            description=(
                "Repo-scoped number of the project's running-log Discussion "
                "(an Announcements-format Discussion that maps every skill "
                "protocol rule to its enforcing tool, or any analogous "
                "evolving reference). Optional. When set, "
                "verify_diff_covers_plan auto-applies a built-in rule (#192) "
                "that flags PRs touching skill prose without a paired edit "
                "to this Discussion."
            ),
        )
    
        # ---------------- 3.0 multi-platform fields (#274 Phase D) ---------------
        #
        # These three fields land via the 2.x → 3.0 migration tool
        # (migration/detector.py::_translate_config_schema). 2.x configs
        # leave them at their defaults (empty list / "2.x"), and
        # `_build_replication` falls back to the single-GitHubAdapter
        # path. 3.0 configs populate them and `_build_replication`
        # constructs a multi-adapter ReplicationManager from
        # `platforms` ordered by `replication_order`.
    
        schema_version: str = Field(
            "2.x",
            description=(
                "Config-schema version. ``2.x`` means single-GitHub legacy; "
                "``3.0`` means multi-platform via ``platforms`` + "
                "``replication_order``. Migration tooling sets this to "
                "``3.0`` when emitting forge-config.json."
            ),
        )
    
        platforms: list[dict] = Field(
            default_factory=list,
            description=(
                "Per-platform entries. Each dict has at minimum ``id`` "
                "(matching one of the adapter ``platform_id`` classvars: "
                "github / codeberg / forgejo / gitlab / local) plus the "
                "platform-specific fields the corresponding "
                "``Adapter.from_config`` reads. Validation defers to each "
                "adapter so the schema stays loose — adapters add fields "
                "without changing the top-level model."
            ),
        )
    
        replication_order: list[str] = Field(
            default_factory=list,
            description=(
                "Ordered list of ``platform_id`` strings (canonical first). "
                "``ReplicationManager`` writes hit the canonical first and "
                "fan out to subsequent entries; reads try each in order "
                "until one succeeds. Empty list falls back to the 2.x "
                "single-GitHubAdapter wrapper."
            ),
        )
    
        # (Phase H / 3.5.0) GithubConfig.site field REMOVED with Hugo.
        # Pre-3.5.0 projects with a ``site`` block in forge-config.json
        # have it silently dropped during config load (model_config's
        # ``extra="forbid"`` is relaxed for this one field-name via the
        # config-load helper).
    
        public_face: str | None = Field(
            None,
            description=(
                "Platform_id of the configured public-facing backend. Must "
                "match one of ``platforms[*].id``. Drives release "
                "mirror-sync target (#282), public-Issue triage tool (#281), "
                "and bootstrap public-repo creation. When None on a "
                "schema 3.0 config with ``repos.public`` set, the "
                "translator defaults to the first non-``local`` entry in "
                "``replication_order``. When ``platforms`` is empty (2.x "
                "compat fallback), this field has no effect; the legacy "
                "single-GitHubAdapter path treats ``repos.public`` as the "
                "implicit public face."
            ),
        )
    
        def find_related_repo(self, repo_fullname: str) -> RelatedRepo | None:
            """Return the RelatedRepo entry matching `owner/name`, or None."""
            target = repo_fullname.strip().lower()
            for entry in self.related_repos:
                if entry.repo.lower() == target:
                    return entry
            return None
    
        def public_face_coords(self) -> tuple[str, str] | None:
            """Return ``(owner, repo)`` for the configured public_face, or None.
    
            Resolution order (forgejo #8 — public_face plumbing into release flow):
    
            1. ``public_face`` is set + ``platforms[id == public_face]`` exists +
               that entry has a ``public`` field of shape ``"owner/repo"``:
               split and return.
            2. ``public_face`` is unset (2.x-compat fallback): split the legacy
               ``repos.public`` field. This preserves pre-3.2.0 behavior so
               the GitHub-only release flow still works on un-migrated configs.
            3. Anything else returns None — handlers fall back to whatever
               GitHub-hardcoded behavior they already had pre-#8.
            """
            if self.public_face is not None:
                for entry in self.platforms:
                    if entry.get("id") == self.public_face:
                        full = entry.get("public", "") or ""
                        if "/" in full:
                            owner, repo = full.split("/", 1)
                            return owner, repo
                        return None
                return None
            legacy = self.repos.public
            if legacy and "/" in legacy:
                owner, repo = legacy.split("/", 1)
                return owner, repo
            return None
    
        def coords_for_platform(
            self, platform_id: str, repo_role: str = "private",
        ) -> tuple[str, str]:
            """Return ``(owner, repo)`` for the named platform + repo role (#296).
    
            Used by ``ReplicationManager`` to thread per-platform
            coordinates into write / read fan-out so each adapter receives
            the coords for its OWN backend, not the project's GitHub
            coords. Fixes the #296 class of bug — pre-#296 every adapter
            got ``ctx.config.repos.<role>`` (GitHub coords), causing
            Codeberg fan-out to 404 against Codeberg's API.
    
            Resolution order:
    
            1. ``platform_id == "local"`` — the canonical store doesn't
               use real backend coords. Returns the project's own coords
               from ``repos.<role>`` for informational symmetry; the
               LocalStoreAdapter ignores them.
            2. ``platforms[id == platform_id][repo_role]`` is set with
               shape ``"owner/repo"`` — split and return.
            3. 2.x fallback: ``repos.<role>`` (same single-tenant field
               every backend used pre-3.0). Preserves pre-#296 behavior
               on un-migrated configs.
            4. Returns ``("", "")`` if nothing resolves — caller is
               responsible for handling missing coords.
    
            ``repo_role`` is one of "private" / "public" / "docs"; matches
            the field names on ``RepoConfig`` and ``platforms[*]`` entries.
            """
            # Normalize legacy field name → 3.0+ field name.
            if repo_role not in ("private", "public", "docs"):
                raise ValueError(
                    f"repo_role must be one of 'private', 'public', 'docs'; "
                    f"got {repo_role!r}"
                )
    
            # Local canonical: return project's own identity coords for
            # informational symmetry. LocalStoreAdapter ignores them.
            if platform_id == "local":
                legacy = getattr(self.repos, repo_role, "") or ""
                if "/" in legacy:
                    owner, repo = legacy.split("/", 1)
                    return owner, repo
                return ("", "")
    
            # 3.0+ multi-platform path.
            for entry in self.platforms:
                if entry.get("id") == platform_id:
                    full = entry.get(repo_role, "") or ""
                    if "/" in full:
                        owner, repo = full.split("/", 1)
                        return owner, repo
                    return ("", "")
    
            # 2.x fallback — un-migrated configs have no `platforms` list.
            legacy = getattr(self.repos, repo_role, "") or ""
            if "/" in legacy:
                owner, repo = legacy.split("/", 1)
                return owner, repo
            return ("", "")

        def target_issue_number_for_platform(
            self, platform_id: str, target_kind: str,
        ) -> int | None:
            """(#467 / #468) Return the configured Issue number on the
            given platform that hosts the named target, or None if not
            configured.

            ``target_kind`` is one of:
              * ``"session_lock"`` — Issue-encoded-as-Discussion used
                for session-event comments (parallel to GitHub's
                ``session_lock_discussion_id``).
              * ``"project_index"`` — Issue-encoded-as-Discussion used
                for the Project Index TOC body (parallel to GitHub's
                ``project_discussion_id``).

            Resolution: ``platforms[id == platform_id][f"{target_kind}_issue_number"]``.
            Returns None when:
              * Platform isn't in the list (un-migrated config or
                unknown platform_id)
              * Field absent on the entry (project bootstrapped before
                this surface landed; ``add_backend`` / migration is the
                fix path)
              * Value isn't a positive int

            Per the Issue's design lean: this is a generic per-platform
            "Issue-encoded-as-Discussion" target slot, not specific to
            Forgejo / GitLab. GitHub's parallel surface uses the
            top-level ``project_discussion_id`` / ``session_lock_discussion_id``
            fields (GraphQL node IDs); those continue to drive GitHub's
            target resolution. This method covers backends where
            Discussions are encoded as Issues (Forgejo, future GitLab).
            """
            if target_kind not in ("session_lock", "project_index"):
                raise ValueError(
                    f"target_kind must be 'session_lock' or "
                    f"'project_index'; got {target_kind!r}"
                )
            field_name = f"{target_kind}_issue_number"
            for entry in self.platforms:
                if entry.get("id") == platform_id:
                    raw = entry.get(field_name)
                    if isinstance(raw, int) and raw > 0:
                        return raw
                    return None
            return None

        @model_validator(mode="after")
        def ids_look_like_node_ids(self) -> "GithubConfig":
            """
            Rough sanity check — GitHub node IDs are base64-ish strings.
            Catches copy-paste errors and truncated values early.
            """
            for field, value in [
                ("project_discussion_id", self.project_discussion_id),
                ("session_lock_discussion_id", self.session_lock_discussion_id),
                ("project_board.id", self.project_board.id),
            ]:
                if len(value) < 10:
                    raise ValueError(
                        f"Field '{field}' value '{value}' is suspiciously short "
                        "for a GitHub node ID. Check github-config.json."
                    )
            return self
    
        @model_validator(mode="after")
        def public_face_references_known_platform(self) -> "GithubConfig":
            """Validate ``public_face`` (when set) names one of ``platforms[].id``.
    
            Skipped when ``platforms`` is empty (2.x-compat config) — there's
            no platform list to check against, and the legacy code path
            ignores ``public_face`` entirely.
            """
            if self.public_face is None:
                return self
            if not self.platforms:
                return self  # 2.x fallback; field has no effect
            known_ids = {p.get("id", "") for p in self.platforms}
            if self.public_face not in known_ids:
                raise ValueError(
                    f"public_face={self.public_face!r} does not match any "
                    f"platforms[].id (known: {sorted(known_ids)})."
                )
            return self

    return GithubConfig


GithubConfig = _github_config_class()


@cache
def _repo_shape_entry_class() -> type:
    class RepoShapeEntry(BaseModel):
        """A single managed-repo entry in the open_session repo-shape audit (#116).

        Reported to Claude at session start so the startup banner can render
        each managed repo's current visibility plus a compliance flag, and
        can offer corrective steps when drift is found (per §Step 3.5
        Migration Completion Checklist).
        """

        model_config = {"frozen": True, "extra": "forbid"}

        path: str = Field(
            ..., description="owner/name fullname for the repo being audited."
        )
        role: Literal["publish_target", "dev", "subsystem", "subsystem_publish"] = Field(
            ..., description="Which managed-repo role this entry represents."
        )
        visibility: Literal["PUBLIC", "PRIVATE", "INTERNAL", "ABSENT", "UNREACHABLE"] = Field(
            ...,
            description=(
                "GitHub `visibility` enum (PUBLIC/PRIVATE/INTERNAL); `ABSENT` "
                "for a repo path that returned 404 (we know it isn't there); "
                "`UNREACHABLE` (#381) when the API call itself failed (we "
                "don't know — public face degraded). UNREACHABLE pairs with "
                "`compliant: null` so the banner suppresses ⚠ for rows we "
                "can't actually evaluate."
            ),
        )
        compliant: bool | None = Field(
            ...,
            description=(
                "True iff the entry passes §Step 3.5 compliance rules. "
                "Tri-state since #381: `null` when the audit couldn't "
                "evaluate (visibility=UNREACHABLE) — the row is reported "
                "but not flagged as drift."
            ),
        )
        compliance_note: str | None = Field(
            None,
            description=(
                "Reason this row is non-compliant or unevaluable. Set when "
                "compliant is False (drift) OR null (audit unreachable). "
                "Plain English, suitable for direct display in the banner."
            ),
        )

    return RepoShapeEntry


RepoShapeEntry = _repo_shape_entry_class()


@cache
def _toc_drift_class() -> type:
    class TocDrift(BaseModel):
        """Project Discussion TOC drift report from `open_session` (#194).

        The TOC is updated best-effort by Claude after every Discussion /
        Issue mutation. Compliance is not guaranteed across sessions —
        network blips, hand-edits, MCP-down fallbacks, and pure operator
        forgetfulness all produce drift. This report compares the
        referenced-numbers set parsed from the active TOC body against
        every issue + discussion number actually present in the dev repo,
        and returns the difference so the session-start banner can warn
        about backlog the operator may want to backfill.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        stale: bool = Field(
            ...,
            description="True iff `missing_issues` or `missing_discussions` is non-empty.",
        )
        missing_issues: list[int] = Field(
            default_factory=list,
            description=(
                "Issue numbers present in the dev repo but absent from the "
                "Project TOC's referenced-numbers set. Sorted ascending."
            ),
        )
        missing_discussions: list[int] = Field(
            default_factory=list,
            description=(
                "Discussion numbers present in the dev repo but absent "
                "from the Project TOC's referenced-numbers set. Sorted ascending."
            ),
        )
        highest_issue_in_toc: int | None = Field(
            None,
            description=(
                "Highest issue number that the TOC references AND that exists "
                "in the repo. None if the TOC is empty or none of its refs "
                "match any actual issue."
            ),
        )
        highest_issue_in_repo: int | None = Field(
            None,
            description=(
                "Highest issue number actually present in the dev repo. None "
                "iff the repo has no issues."
            ),
        )
        suggested_action: str = Field(
            ...,
            description=(
                "One-line operator-facing suggestion. When `stale=True`, "
                "directs the operator to compose + call update_project_toc; "
                "when `stale=False`, confirms the TOC is current."
            ),
        )

    return TocDrift


TocDrift = _toc_drift_class()


@cache
def _session_state_class() -> type:
    class SessionState(BaseModel):
        """
        Runtime session state — returned by open_session() and held
        in Claude's context for the duration of the session.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        session_id: str
        prior_session_clean: bool
        prior_session_timestamp: str | None
        project_discussion_id: str
        session_lock_discussion_id: str
        category_architecture_id: str
        category_ux_ui_id: str
        category_ideas_id: str
        category_claude_use_only_id: str
        project_board_id: str
        account_type: Literal["org", "personal"]
        skill_version: str | None = Field(
            None,
            description=(
                "Local skill file's `**Version:**` header at session-open time, or "
                "None if the skill file isn't present at the canonical path. (#116)"
            ),
        )
        mcp_server_version: str = Field(
            ...,
            description="Running MCP server's __version__ at session-open time. (#116)",
        )
        latest_skill_version: str | None = Field(
            None,
            description=(
                "Upstream skill version on the public mirror's main branch, or None "
                "on lookup failure (network, repo-not-found, etc.). Compare to "
                "skill_version to detect drift. (#116)"
            ),
        )
        repo_shape: list[RepoShapeEntry] = Field(
            default_factory=list,
            description=(
                "Repo-shape audit — one entry per managed repo (publish_target, "
                "dev, plus each `related_repos` entry typed `subsystem` or "
                "`publish_target`). Empty list if the audit was skipped (e.g. "
                "in the bash MCP-down fallback). (#116)"
            ),
        )
        toc_drift: TocDrift | None = Field(
            None,
            description=(
                "Project Discussion TOC drift report (#194). None iff the "
                "drift fetch failed (the surface is advisory; failure does "
                "not gate session-open)."
            ),
        )

    return SessionState


SessionState = _session_state_class()


@cache
def _post_turn_result_class() -> type:
    class PostTurnResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        comment_id: str
        comment_url: str
        # Present only when the post was to the Project Discussion (#63).
        project_toc_body: str | None = None

    return PostTurnResult


PostTurnResult = _post_turn_result_class()


@cache
def _create_thread_result_class() -> type:
    class CreateThreadResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        thread_id: str
        thread_number: int
        thread_url: str
        type: Literal["discussion", "issue"]
        # Post-mutation Project Discussion body for callers about to update
        # the TOC. Saves one GraphQL round trip (#63).
        project_toc_body: str | None = None

    return CreateThreadResult


CreateThreadResult = _create_thread_result_class()


@cache
def _classify_result_class() -> type:
    class ClassifyResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        destination: Literal["discussion", "issue"]
        category: Literal["Architecture", "UX / UI", "Ideas"] | None
        issue_label: Literal["bug", "rfc", "feature", "refactor", "chore"] | None
        suggested_title: str
        confidence: Literal["high", "medium", "low"]

    return ClassifyResult


ClassifyResult = _classify_result_class()


@cache
def _theme_change_result_class() -> type:
    class ThemeChangeResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        theme_changed: bool
        confidence: Literal["high", "medium", "low"]
        fork_point_comment_id: str | None
        original_theme: str
        new_theme: str
        suggested_title: str

    return ThemeChangeResult


ThemeChangeResult = _theme_change_result_class()


@cache
def _fork_result_class() -> type:
    class ForkResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        new_discussion_id: str
        new_discussion_url: str
        original_updated: bool
        fork_comment_id: str
        # Post-mutation Project Discussion body (#63).
        project_toc_body: str | None = None

    return ForkResult


ForkResult = _fork_result_class()


@cache
def _create_issue_result_class() -> type:
    class CreateIssueResult(BaseModel):
        model_config = {"frozen": True, "extra": "forbid"}

        issue_id: str
        issue_number: int
        issue_url: str
        project_item_id: str
        # Post-mutation Project Discussion body (#63).
        project_toc_body: str | None = None

    return CreateIssueResult


CreateIssueResult = _create_issue_result_class()


@cache
def _search_issue_hit_class() -> type:
    class SearchIssueHit(BaseModel):
        """One Issue match returned by `search_issues` (#236)."""

        model_config = {"frozen": True, "extra": "forbid"}

        number: int
        title: str
        url: str
        state: Literal["OPEN", "CLOSED"]
        labels: list[str]
        milestone: str | None
        repository: str  # owner/name
        created_at: str
        updated_at: str

    return SearchIssueHit


SearchIssueHit = _search_issue_hit_class()


@cache
def _search_issues_result_class() -> type:
    class SearchIssuesResult(BaseModel):
        """Aggregate result for `search_issues` (#236)."""

        model_config = {"frozen": True, "extra": "forbid"}

        results: list[SearchIssueHit]
        total_count: int  # Total matches available; len(results) is capped by `limit`.
        query: str  # The fully-resolved search query string sent to GitHub.

    return SearchIssuesResult


SearchIssuesResult = _search_issues_result_class()


@cache
def _operation_error_class() -> type:
    class OperationError(BaseModel):
        """
        Returned by tools when a GitHub operation fails after retries.
        The MCP server stays alive; Claude receives this and reports
        to the user.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        success: Literal[False] = False
        error: str
        buffered: bool
        buffer_file: str | None
        retry_tool: str | None
        retry_args: dict | None
        # Set when the failure represents a protocol gate rather than a
        # transient GitHub/network error — e.g. cousin-repo mutation
        # requires explicit user permission per #97 §Cross-repo work
        # protocol. Distinguishes "ask the user, then re-run" from "retry
        # the API call". (#98)
        manual_step: str | None = None

    return OperationError


OperationError = _operation_error_class()
