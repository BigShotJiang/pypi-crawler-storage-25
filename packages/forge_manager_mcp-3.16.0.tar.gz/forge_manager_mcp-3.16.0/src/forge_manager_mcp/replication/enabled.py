"""Per-mirror enabled-flag helper (Discussion #23 A.5 / OQ1 / 3.15.0).

Per A.5's recommended-default OQ1 resolution: operator-pause migrates
from an in-memory ``AdapterState.PAUSED`` to a durable
``platforms[i].enabled: bool`` field on the config. Operator intent
survives daemon restart without the state machine.

This module ships the **enabled-flag helper** as an additive 3.15.0
piece — dormant, like the sibling ``surface_set`` module. The
endpoint shape (POST /backends/{id}/enable, POST /backends/{id}/
disable) + dispatch-time gating + config rewriting belong in the
focused A.5 implementation session.

Default semantics:
- ``enabled`` absent or None → ``True`` (the legacy default —
  pre-A.5 every adapter participated unless explicitly PAUSED).
- ``enabled: False`` → adapter is operator-disabled; dispatch
  short-circuits to skip this mirror.
- ``enabled: True`` → adapter is operator-enabled; normal dispatch.
- Non-boolean values (e.g. ``"true"`` string, ``1`` int) → coerce
  via Python truthiness, but the schema convention is boolean.
  Configs that supply non-booleans should be normalized at write
  time; this helper is permissive at read time.

The `enabled: False` semantic is **distinct** from removing the
entry from ``platforms[]`` entirely:
- Removed entry: not configured; bootstrap may re-add it.
- ``enabled: False``: configured + intentional + restartable; the
  operator can re-enable without re-typing credentials etc.

This distinction is why OQ1 picked (b) over (a) — durable + reversible
disable is operationally meaningful.
"""
from __future__ import annotations

from typing import Any


def is_enabled(platform_entry: dict[str, Any]) -> bool:
    """Resolve the enabled state for one ``platforms[i]`` entry.

    Reads the optional ``enabled`` field; defaults to ``True`` when
    absent or None (legacy compat — pre-A.5 configs implicitly
    enabled every adapter).

    Truthiness coercion: any value passed through ``bool()`` returns
    the conventional truthy/falsy mapping. Configs that supply
    non-booleans get the intuitive interpretation rather than a
    schema error — the helper is permissive at read time. Config
    writers should still normalize to bool at write time.
    """
    raw = platform_entry.get("enabled")
    if raw is None:
        return True  # Legacy default — pre-A.5 enabled-by-omission.
    return bool(raw)


def filter_enabled(
    platforms: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return the platforms list with operator-disabled entries dropped.

    Used by the dispatch path post-A.5: read all configured platforms,
    filter to enabled-only, dispatch to each survivor. Preserves
    input order so the canonical-first convention from
    ``replication_order`` stays intact.

    Pure — returns a new list, doesn't mutate the input.
    """
    return [entry for entry in platforms if is_enabled(entry)]


def with_enabled(
    platform_entry: dict[str, Any], enabled: bool,
) -> dict[str, Any]:
    """Return a copy of ``platform_entry`` with ``enabled`` set.

    Used by the (future) enable/disable endpoint to produce the new
    config dict that gets serialized back to ``forge-config.json``.
    Pure — doesn't mutate the input.

    The returned dict carries an explicit ``enabled: True`` even
    for the default-true case, so the persisted config records the
    operator's explicit decision (no ambiguity between "not yet
    configured" and "operator chose enabled").
    """
    out = dict(platform_entry)
    out["enabled"] = bool(enabled)
    return out
