"""Per-mirror surface-set helper (Discussion #23 A.5 / 3.15.0).

A.5's broader scope retires the HEALTHY/DEGRADED/RECONCILING/PAUSED
state machine and shrinks ``ReplicationManager`` to a best-effort
additive-only pusher. Two structural inputs come along for the ride:

- **Per-mirror surface set.** Per OQ5 of Discussion #23: each mirror
  declares which surfaces it cares to receive pushes for. Default is
  ``[bodies, releases]`` — the operationally-significant surfaces.
  Comments / labels / milestones are opt-in per-mirror.
- **Per-mirror canonical-id → mirror-number map.** Per OQ7: each
  mirror's number-space diverges (canonical Issue #42 might be
  GitHub #117 + Codeberg #23). The map lets pushes resolve the
  remote number from the canonical id.

This module ships the **surface-set helper** as an additive 3.15.0
piece. The map is a separate module (deferred until consumption
exists). State-machine removal + dispatch-time filtering land in a
focused 3.15.x or 3.16.0 follow-up — that's the destructive piece
that touches ReplicationManager, the /backends endpoint, the alert
log, the watch loop, and dispatch_write.

For 3.15.0 the helper is **dormant** — exposed for tests + adapter
self-introspection, not yet consumed by the dispatch path. Adapters
that want to short-circuit their own pushes can already consult it.
Once dispatch-time filtering ships, this becomes the single source
of truth.

Surface vocabulary (kept small + structural — adding a new surface
is a deliberate API extension, not an ad-hoc string):

- ``bodies`` — Issue / Discussion / Milestone body + title (the
  canonical artifact text).
- ``comments`` — append-only comment thread.
- ``releases`` — release tags + release notes + binary artifacts.
- ``labels`` — Issue / PR label set.
- ``milestones`` — milestone metadata + assignment.

Adapters that publish only some of these can declare so via the
optional ``surface_set`` key on their platform-entry dict — same
extra-fields contract as every other adapter setting today (per
``GithubConfig.platforms`` docstring).
"""
from __future__ import annotations

from typing import Any


# The five canonical surfaces. Adding a new surface here is the API
# extension point — bump the version + document the new surface's
# semantics. Adapters can declare which subset they accept pushes for.
VALID_SURFACES: frozenset[str] = frozenset({
    "bodies",
    "comments",
    "releases",
    "labels",
    "milestones",
})


# Default when a platform-entry dict omits ``surface_set``. Per
# Discussion #23 OQ5: the operationally-significant surfaces are
# bodies + releases; the rest opt in per-mirror. Tuple-not-frozenset
# so the order is stable for display / diagnostic surfaces.
DEFAULT_SURFACE_SET: tuple[str, ...] = ("bodies", "releases")


def get_surface_set(platform_entry: dict[str, Any]) -> tuple[str, ...]:
    """Resolve the surface-set for one ``platforms[i]`` entry.

    Reads the optional ``surface_set`` field; falls back to
    :data:`DEFAULT_SURFACE_SET` when absent or malformed. Unknown
    surface tokens are dropped (defensive — adapters that emit
    typos shouldn't poison the dispatch path).

    Returns a tuple in stable display order (insertion order from
    the input, deduplicated).

    Tolerance contract:
    - ``None`` / missing field → default set
    - non-list type (str, int) → default set (configs that try
      ``surface_set: "bodies"`` get the default rather than a
      single-element tuple — keeps the schema rigorous)
    - list with non-string entries → string entries kept,
      non-strings dropped silently
    - list with unknown surface tokens → unknown dropped silently
    - empty list → empty tuple (operator's explicit choice to push
      nothing; ReplicationManager should respect this)
    """
    raw = platform_entry.get("surface_set")
    if raw is None:
        return DEFAULT_SURFACE_SET
    if not isinstance(raw, list):
        return DEFAULT_SURFACE_SET
    seen: set[str] = set()
    out: list[str] = []
    for entry in raw:
        if not isinstance(entry, str):
            continue
        if entry not in VALID_SURFACES:
            continue
        if entry in seen:
            continue
        seen.add(entry)
        out.append(entry)
    return tuple(out)


def accepts_surface(
    platform_entry: dict[str, Any], surface: str,
) -> bool:
    """Convenience predicate: does this platform accept ``surface``?

    Equivalent to ``surface in get_surface_set(platform_entry)``,
    but reads more cleanly at call sites that gate one specific
    dispatch on a known surface name.
    """
    return surface in get_surface_set(platform_entry)
