"""Push-failure alert helpers (Discussion #23 A.5 / OQ4).

OQ4 (c) — chatty + stateful: every push failure fires a low-sev
``adapter.push_failed`` (content-hashed dedup via #454's
SqliteAlertLog), and the first-of-N consecutive-failures threshold
fires a higher-sev ``adapter.unhealthy`` (operator-actionable).

This module ships the **alert-construction helpers** + the
**threshold predicate**. Adapter-integration / dispatch-time
emission belong in the focused A.5 follow-up.

Default threshold: 3 consecutive failures → ``adapter.unhealthy``.
Matches the legacy DEGRADED-on-failure-threshold semantics from
the retired state machine (kept for operator familiarity).
"""
from __future__ import annotations

from typing import Any


DEFAULT_UNHEALTHY_THRESHOLD: int = 3
"""Number of consecutive push failures before ``adapter.unhealthy``
fires. Matches the pre-A.5 DEGRADED-on-failure-threshold semantics
so operator expectations carry over."""


def make_push_failed_alert(
    *,
    platform_id: str,
    error_class: str,
    error_message: str,
    canonical_kind: str,
    canonical_number: int,
    source_event: str,
) -> dict[str, Any]:
    """Compose an ``adapter.push_failed`` alert payload.

    Returns the dict shape that the daemon's alert pipeline (alert_log
    + SSE publish) consumes — same shape as :func:`alert_to_dict`
    output. The caller wraps with ``make_alert`` for the in-memory
    Alert dataclass when needed; the dict shape is the wire format.

    Tagging convention:
    - ``tags`` carries ``push_failed`` + ``adapter:<platform_id>``
      so consumers can filter SSE/alerts by event class + scope.
    - ``platform_id`` field populated for the per-adapter index.

    Per OQ4 (c) this alert is **low-severity / info** — chatty +
    content-hashed via #454's dedup. The operator-actionable signal
    is the sibling ``adapter.unhealthy`` alert; ``push_failed`` is
    pure observability.
    """
    detail = (
        f"{error_class}: {error_message}\n"
        f"artifact: {canonical_kind}:#{canonical_number}\n"
        f"source_event: {source_event}"
    )
    message = (
        f"push to {platform_id} failed for "
        f"{canonical_kind}:#{canonical_number}"
    )
    return {
        "level": "info",
        "message": message,
        "detail": detail,
        "platform_id": platform_id,
        "tags": ("push_failed", f"adapter:{platform_id}"),
    }


def make_unhealthy_alert(
    *,
    platform_id: str,
    consecutive_failures: int,
    most_recent_error: str | None = None,
) -> dict[str, Any]:
    """Compose an ``adapter.unhealthy`` alert payload.

    Higher severity than ``push_failed`` (warning level) — fires on
    the first-of-N threshold crossing per OQ4 (c). Operator-actionable:
    the alert message names the adapter + the count, the detail field
    carries the most recent error message for context.

    Caller is responsible for the threshold check (use
    :func:`is_at_unhealthy_threshold`); this helper only constructs
    the payload.

    Per OQ4 (c) tagging:
    - ``adapter_unhealthy`` + ``adapter:<platform_id>``.
    """
    message = (
        f"{platform_id} unhealthy: {consecutive_failures} consecutive "
        f"push failures"
    )
    detail_lines = [
        f"consecutive_failures: {consecutive_failures}",
    ]
    if most_recent_error:
        detail_lines.append(f"most_recent_error: {most_recent_error}")
    return {
        "level": "warning",
        "message": message,
        "detail": "\n".join(detail_lines),
        "platform_id": platform_id,
        "tags": ("adapter_unhealthy", f"adapter:{platform_id}"),
    }


def is_at_unhealthy_threshold(
    consecutive_failures: int,
    *,
    threshold: int = DEFAULT_UNHEALTHY_THRESHOLD,
) -> bool:
    """First-of-N threshold predicate per OQ4 (c).

    Returns True when ``consecutive_failures == threshold`` (the
    transition moment). Subsequent calls with higher counts return
    False so the alert only fires once per consecutive-failure
    streak — operators don't get a fresh notification on every
    failure once the threshold trips.

    Reset to False when the streak breaks (caller's responsibility to
    track via the replication_push_facts shadow table; once a success
    row lands the consecutive count drops to 0 and the next failure
    starts from 1).
    """
    return consecutive_failures == threshold


def count_consecutive_failures(
    conn,
    *,
    adapter: str,
    window_max: int = 10,
) -> int:
    """Walk the most recent ``replication_push_facts`` rows for the
    adapter and return the consecutive-failure count from the head.

    Returns 0 on first success encountered (streak broken). Caps the
    walk at ``window_max`` rows so the query stays bounded even when
    the table is large; in practice the threshold (3) is hit well
    before the cap, and operators care about the immediate streak,
    not historical totals.

    Returns 0 when the table is empty or absent (graceful).

    The caller invokes this AFTER inserting the new push outcome
    via :func:`shadow.replication_push.emit_push_outcome`. The
    returned count is the post-emit consecutive failure count;
    pass directly to :func:`is_at_unhealthy_threshold`.
    """
    try:
        cursor = conn.execute(
            "SELECT success FROM replication_push_facts "
            "WHERE adapter = ? "
            "ORDER BY recorded_at DESC "
            "LIMIT ?",
            (adapter, window_max),
        )
        rows = cursor.fetchall()
    except Exception:
        # Table absent / sqlite error → no signal; caller treats as
        # zero failures (no spurious alerts).
        return 0
    count = 0
    for row in rows:
        success = row[0]
        if success == 0:
            count += 1
        else:
            break
    return count
