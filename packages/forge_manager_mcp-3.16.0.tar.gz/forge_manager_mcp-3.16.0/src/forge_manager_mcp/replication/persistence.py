"""ReplicationManager adapter-state persistence (#377 / 3.8.1 D1).

Persists `ReplicationManager._entries[*]` state across daemon restart
to ``<state-dir>/replication-state.json``. Pre-#377 the in-memory
state was lost on every restart; the operator saw "fresh-start
healthy" backend display until an actual op fanned out and
re-degraded. With this module, state survives.

Per Schema-as-data (Rule 5): factory pattern + cached dataclass class
inside helper. Atomic writes via temp + fsync + rename, mirroring the
``daemon/discovery.py`` shape.

Persisted per entry:
  * platform_id
  * state (AdapterState enum value)
  * last_error_message (str — exception objects don't round-trip)
  * last_error_type (str class name; informational only)
  * state_changed_at (ISO 8601 UTC)
  * last_error_at (ISO 8601 UTC | None)
  * next_attempt_at (ISO 8601 UTC | None)

NOT persisted:
  * pending_writes queue — separate concern; the MCP-side buffered-
    posts layer handles write recovery for that surface.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from functools import cache
from pathlib import Path
from typing import Any

# AdapterState imported lazily inside the parsing path to avoid a
# BUILD-layer dep cycle with replication_manager (the manager imports
# this module's writers + readers via lazy in-method imports).


REPLICATION_STATE_FILENAME = "replication-state.json"
REPLICATION_STATE_SCHEMA_VERSION = 1
"""Bump on incompatible-shape changes. Mismatch on read discards the
file with a warning and rehydrate falls back to default-healthy."""


@cache
def _persisted_entry_class() -> type:
    """Cached frozen-dataclass for one persisted adapter entry. Lives
    inside a function so the AST scan over module-level nodes does
    not see a top-level dataclass (Rule 5).

    ``state`` is a raw string (one of ``healthy`` / ``degraded`` /
    ``reconciling`` / ``paused``). Conversion to/from
    ``AdapterState`` happens in ``ReplicationManager._persist_state``
    and ``_rehydrate_state``; this module stays free of any
    ``replication.manager`` import so the BUILD-layer dep graph is
    one-way (manager → persistence)."""
    @dataclass(frozen=True)
    class PersistedAdapterEntry:
        platform_id: str
        state: str
        last_error_message: str | None
        last_error_type: str | None
        state_changed_at: datetime
        last_error_at: datetime | None
        next_attempt_at: datetime | None
    return PersistedAdapterEntry


@cache
def _replication_state_class() -> type:
    """Cached frozen-dataclass for the persisted file shape."""
    @dataclass(frozen=True)
    class ReplicationState:
        schema_version: int
        entries: tuple
    return ReplicationState


@cache
def _persisted_error_class() -> type:
    """Cached carrier for a deserialized error from a prior daemon
    run. Holds the original error type-name + message so
    ``str(entry.last_error)`` yields the same string the operator
    saw before restart. Not raised anywhere — assigned as a stable
    carrier on rehydrated ``_AdapterEntry.last_error``."""
    class PersistedAdapterError(Exception):
        def __init__(self, *, type_name: str, message: str):
            self.original_type_name = type_name
            super().__init__(message)
    return PersistedAdapterError


_VALID_STATE_VALUES: frozenset[str] = frozenset({
    "healthy", "degraded", "reconciling", "paused",
})


def make_persisted_entry(
    *,
    platform_id: str,
    state: str,
    last_error_message: str | None,
    last_error_type: str | None,
    state_changed_at: datetime,
    last_error_at: datetime | None,
    next_attempt_at: datetime | None,
):
    """Construct a fresh PersistedAdapterEntry value. ``state`` is
    a raw string in ``_VALID_STATE_VALUES``; the manager passes
    ``adapter_state.value``."""
    if not platform_id:
        raise ValueError("platform_id must be non-empty")
    if state not in _VALID_STATE_VALUES:
        raise ValueError(
            f"state {state!r} not in {sorted(_VALID_STATE_VALUES)}"
        )
    cls = _persisted_entry_class()
    return cls(
        platform_id=platform_id,
        state=state,
        last_error_message=last_error_message,
        last_error_type=last_error_type,
        state_changed_at=state_changed_at,
        last_error_at=last_error_at,
        next_attempt_at=next_attempt_at,
    )


def make_replication_state(
    *,
    entries: tuple,
    schema_version: int = REPLICATION_STATE_SCHEMA_VERSION,
):
    """Construct a fresh ReplicationState value."""
    cls = _replication_state_class()
    return cls(schema_version=schema_version, entries=tuple(entries))


def make_persisted_error(*, type_name: str, message: str):
    """Construct a carrier exception for a rehydrated error."""
    cls = _persisted_error_class()
    return cls(type_name=type_name, message=message)


def replication_state_path(state_dir: Path) -> Path:
    """Return the persistence-file path under ``state_dir``."""
    return state_dir / REPLICATION_STATE_FILENAME


def _serialize_entry(entry) -> dict[str, Any]:
    return {
        "platform_id": entry.platform_id,
        "state": entry.state,
        "last_error_message": entry.last_error_message,
        "last_error_type": entry.last_error_type,
        "state_changed_at": entry.state_changed_at.isoformat(),
        "last_error_at": (
            entry.last_error_at.isoformat()
            if entry.last_error_at is not None else None
        ),
        "next_attempt_at": (
            entry.next_attempt_at.isoformat()
            if entry.next_attempt_at is not None else None
        ),
    }


def write_replication_state(state_dir: Path, state) -> Path:
    """Write the replication-state file atomically.

    Writes to ``replication-state.json.tmp`` then ``rename`` —
    atomic on POSIX, near-atomic on Windows. ``fsync`` between
    write and rename so a kernel-buffered write isn't lost on
    abrupt power loss. ``0o600`` permissions.

    Raises ``OSError`` on filesystem failures (caller decides
    whether to swallow — ReplicationManager swallows since
    persistence is best-effort and must not poison the state
    machine).
    """
    state_dir.mkdir(parents=True, exist_ok=True)
    target = replication_state_path(state_dir)
    tmp = target.with_suffix(".json.tmp")
    payload = {
        "schema_version": state.schema_version,
        "entries": [_serialize_entry(e) for e in state.entries],
    }
    body = json.dumps(payload, indent=2)
    fd = os.open(
        tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600,
    )
    try:
        os.write(fd, body.encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, target)
    return target


def _parse_entry(raw: dict):
    """Parse one entry dict. Returns the entry or None if any field
    is malformed — caller drops malformed entries while keeping the
    rest, so a single-row corruption doesn't lose the whole file."""
    try:
        platform_id = str(raw["platform_id"])
        state = str(raw["state"])
        if state not in _VALID_STATE_VALUES:
            return None
        state_changed_at = datetime.fromisoformat(raw["state_changed_at"])
        last_error_message = raw.get("last_error_message")
        last_error_type = raw.get("last_error_type")
        last_error_at_raw = raw.get("last_error_at")
        next_attempt_at_raw = raw.get("next_attempt_at")
    except (KeyError, TypeError, ValueError):
        return None
    try:
        last_error_at = (
            datetime.fromisoformat(last_error_at_raw)
            if last_error_at_raw is not None else None
        )
        next_attempt_at = (
            datetime.fromisoformat(next_attempt_at_raw)
            if next_attempt_at_raw is not None else None
        )
    except (TypeError, ValueError):
        return None
    if last_error_message is not None and not isinstance(
        last_error_message, str,
    ):
        return None
    if last_error_type is not None and not isinstance(last_error_type, str):
        return None
    return make_persisted_entry(
        platform_id=platform_id,
        state=state,
        last_error_message=last_error_message,
        last_error_type=last_error_type,
        state_changed_at=state_changed_at,
        last_error_at=last_error_at,
        next_attempt_at=next_attempt_at,
    )


def read_replication_state(state_dir: Path):
    """Read + parse the replication-state file. Returns ``ReplicationState``
    or None.

    Returns None on:
      * file missing
      * malformed JSON
      * schema-version mismatch (caller's rehydrate falls back to
        default-healthy; the file is left in place so a future code
        version with a compatible reader can still consume it)
      * top-level shape errors

    Per-entry parse failures drop just that entry and keep the rest.
    """
    target = replication_state_path(state_dir)
    if not target.exists():
        return None
    try:
        raw = target.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("schema_version") != REPLICATION_STATE_SCHEMA_VERSION:
        return None
    raw_entries = data.get("entries")
    if not isinstance(raw_entries, list):
        return None
    parsed: list = []
    for raw_entry in raw_entries:
        if not isinstance(raw_entry, dict):
            continue
        entry = _parse_entry(raw_entry)
        if entry is not None:
            parsed.append(entry)
    return make_replication_state(entries=tuple(parsed))


# Re-export the constructed dataclass types so callers can declare
# parameter types and ``isinstance`` checks work as expected.
PersistedAdapterEntry = _persisted_entry_class()
ReplicationState = _replication_state_class()
PersistedAdapterError = _persisted_error_class()
