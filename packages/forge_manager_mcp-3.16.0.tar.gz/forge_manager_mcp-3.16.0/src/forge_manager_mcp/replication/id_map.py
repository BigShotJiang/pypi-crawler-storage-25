"""Per-mirror canonical-id ↔ mirror-number map (Discussion #23 A.5).

Each mirror's number-space diverges from the canonical: canonical
Issue #42 might be GitHub #117 + Codeberg #23. Today the mapping
lives implicitly in each artifact's ``meta.json`` (the URL +
node_id fields capture the per-platform shape), but the lookups
are O(filesystem-walk) and don't survive when the platform
endpoint goes away.

This module ships the **map data shape** as an additive 3.15.0
piece — dormant, like the sibling ``surface_set`` and ``enabled``
modules. Adapter integrations (Codeberg push, Forgejo push) get
wired to populate the map after each successful push in the
focused A.5 follow-up. Persistence to ``<state-dir>/
mirror-number-map.json`` deferred to the same session.

Shape rationale:
- The canonical id is a structured tuple ``(kind, number)`` where
  ``kind`` is one of ``issue`` / ``discussion`` / ``milestone`` /
  ``release`` / ``comment`` / etc. Today the canonical store
  enumerates Issues + Discussions; milestones are version-keyed
  (not numbered) but get an analogous entry when the mirror
  surfaces them.
- The mirror number is platform-specific — GitHub uses int
  Issue numbers, Codeberg uses int Issue numbers, Forgejo
  similarly. The map exposes ``int`` for those cases; an
  open generic ``str`` form is reserved for platforms with
  non-int identifiers.

The map is **single-writer per (platform, kind)** — only the push
dispatch records new entries, and only for successful pushes
where the platform returned a confirmed remote number. Lookups
are read-only from anywhere.

(No persistence in 3.15.0 — focused A.5 follow-up adds the
sqlite-backed table per OQ5 of #23's canonical-DB cut.)
"""
from __future__ import annotations

from typing import Iterable


CanonicalId = tuple[str, int]
"""(kind, number) pair identifying a canonical-store artifact.

E.g. ``("issue", 42)`` or ``("discussion", 17)``. The number is
the canonical-store-assigned identifier — preserved unchanged
even when the per-mirror remote number differs.
"""


class MirrorNumberMap:
    """In-memory canonical-id → mirror-number map for one (platform,
    kind) pair. Pre-persistence (the focused-session follow-up
    promotes this to a sqlite table); for now the class lets
    adapters track per-push results within a single daemon
    lifetime.

    Single-writer contract: the dispatch path records successful
    pushes via :meth:`record`; lookups via :meth:`get_mirror_number`
    are read-only from anywhere. No locking — the daemon is
    single-event-loop, so no contention.
    """

    def __init__(self) -> None:
        self._forward: dict[CanonicalId, int] = {}
        # Reverse index for the (rarer) mirror_number → canonical_id
        # query that some dispatch paths need (e.g. handling a
        # webhook from the mirror referencing its own number).
        self._reverse: dict[tuple[str, int], CanonicalId] = {}

    def record(
        self,
        canonical_id: CanonicalId,
        mirror_number: int,
    ) -> None:
        """Record a successful push: canonical → mirror_number.

        Idempotent — recording the same (canonical_id, mirror_number)
        pair multiple times is a no-op. Conflicting records (same
        canonical_id, different mirror_number) raise ValueError —
        the canonical store guarantees number-stability per
        artifact-creation event, so a conflict signals dispatch
        corruption that should fail loud.
        """
        if not isinstance(canonical_id, tuple) or len(canonical_id) != 2:
            raise ValueError(
                "canonical_id must be a (kind, number) tuple"
            )
        kind, _ = canonical_id
        existing = self._forward.get(canonical_id)
        if existing is not None and existing != mirror_number:
            raise ValueError(
                f"conflicting mirror_number for {canonical_id}: "
                f"existing={existing}, new={mirror_number}"
            )
        self._forward[canonical_id] = mirror_number
        self._reverse[(kind, mirror_number)] = canonical_id

    def get_mirror_number(
        self, canonical_id: CanonicalId,
    ) -> int | None:
        """Look up the mirror number for a canonical id. Returns
        ``None`` when no push has succeeded yet for this artifact."""
        return self._forward.get(canonical_id)

    def get_canonical_id(
        self, kind: str, mirror_number: int,
    ) -> CanonicalId | None:
        """Reverse lookup — given a kind + mirror number, return the
        canonical id. Useful when a webhook / pull-side reference
        names the mirror's number and the daemon needs to resolve
        back to the canonical store."""
        return self._reverse.get((kind, mirror_number))

    def __len__(self) -> int:
        """Number of recorded mappings."""
        return len(self._forward)

    def __contains__(self, canonical_id: object) -> bool:
        """Membership test for canonical id presence."""
        if not isinstance(canonical_id, tuple) or len(canonical_id) != 2:
            return False
        return canonical_id in self._forward

    def iter_entries(self) -> Iterable[tuple[CanonicalId, int]]:
        """Iterate ``(canonical_id, mirror_number)`` pairs in
        insertion order. Used by persistence / diagnostic surfaces
        when the focused A.5 session ships the sqlite-backed
        replacement."""
        return iter(self._forward.items())

    def clear(self) -> None:
        """Reset both indexes. Test fixture support."""
        self._forward.clear()
        self._reverse.clear()
