"""Multi-host replication orchestrator (3.0 / Phase 6).

Public surface:

  * ``ReplicationManager`` — coordinates writes + reads across the
    configured adapters per OQ3 + OQ6. Local first; remote mirrors
    follow.
  * ``AdapterState`` — per-adapter state-machine value
    (HEALTHY / DEGRADED / RECONCILING).
  * ``ReplicationError`` — base exception for replication failures.
"""
from __future__ import annotations

from .errors import (
    AllAdaptersFailedError,
    ReplicationError,
    ReplicationWriteError,
)
from .manager import (
    AdapterState,
    MirrorWarning,
    ReplicationManager,
    WriteResult,
)

__all__ = [
    "AdapterState",
    "AllAdaptersFailedError",
    "MirrorWarning",
    "ReplicationError",
    "ReplicationManager",
    "ReplicationWriteError",
    "WriteResult",
]
