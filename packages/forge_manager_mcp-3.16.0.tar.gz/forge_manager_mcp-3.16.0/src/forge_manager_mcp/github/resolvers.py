"""GitHub node-ID resolvers and generic file fetch (#83)."""
from __future__ import annotations

import httpx

from .core import GitHubError, InvalidNodeIdError, _get_client, _graphql


async def validate_node_id(token: str, param_name: str, node_id: str) -> None:
    """Raise InvalidNodeIdError if node_id does not resolve on GitHub.

    Cheap existence query (`node(id: $id) { id }`). Transient GitHub
    failures (HTTP 5xx, network) propagate as GitHubError and remain
    retry-eligible at the tool layer.
    """
    if not node_id.strip():
        raise ValueError(f"{param_name} must not be empty.")

    query = "query($id: ID!) { node(id: $id) { id } }"
    try:
        data = await _graphql(token, query, {"id": node_id})
    except GitHubError as exc:
        # GitHub rejects a syntactically-invalid ID with `errors` rather
        # than returning `data.node = null`. Treat "Could not resolve"
        # error messages as client-side (invalid ID), everything else as
        # transient.
        if "Could not resolve to a node" in str(exc):
            raise InvalidNodeIdError(param_name, node_id) from exc
        raise

    if not (data.get("node") or {}).get("id"):
        raise InvalidNodeIdError(param_name, node_id)


async def get_repo_node_id(token: str, owner: str, repo: str) -> str:
    """Return the GraphQL node ID for a repository."""
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    query = """
    query GetRepoId($owner: String!, $repo: String!) {
      repository(owner: $owner, name: $repo) { id }
    }
    """
    data = await _graphql(token, query, {"owner": owner, "repo": repo})
    repo_node = data.get("repository")
    if not repo_node:
        raise GitHubError(f"Repository {owner}/{repo} not found.")
    return repo_node["id"]


async def resolve_thread_id(
    token: str,
    owner: str,
    repo: str,
    number: int,
    kind: str,
) -> str:
    """Resolve (owner, repo, number) to an Issue or Discussion node ID.

    kind must be "issue" or "discussion". Raises GitHubError if the
    thread is not found.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if not isinstance(number, int) or number < 1:
        raise ValueError("number must be a positive integer.")
    if kind not in ("issue", "discussion"):
        raise ValueError(f"kind must be 'issue' or 'discussion', got: {kind!r}")

    if kind == "issue":
        query = """
        query($owner: String!, $repo: String!, $number: Int!) {
          repository(owner: $owner, name: $repo) {
            issue(number: $number) { id }
          }
        }
        """
    else:
        query = """
        query($owner: String!, $repo: String!, $number: Int!) {
          repository(owner: $owner, name: $repo) {
            discussion(number: $number) { id }
          }
        }
        """
    data = await _graphql(
        token, query, {"owner": owner, "repo": repo, "number": number}
    )
    repo_node = data.get("repository") or {}
    node = repo_node.get(kind) or {}
    node_id = node.get("id")
    if not node_id:
        raise GitHubError(
            f"{kind.capitalize()} {owner}/{repo}#{number} not found."
        )
    return node_id


async def get_repo_visibility(token: str, owner: str, repo: str) -> str | None:
    """Return the GraphQL `visibility` of a repo (`PUBLIC`/`PRIVATE`/`INTERNAL`).

    Returns None if the repo does not exist (distinguishes "missing" from
    transient API errors, which still raise GitHubError). Used by the
    repo-shape audit in `open_session` (#116) to evaluate whether each
    managed repo's current visibility matches §Step 3.5 compliance rules.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    query = """
    query($owner: String!, $repo: String!) {
      repository(owner: $owner, name: $repo) { visibility }
    }
    """
    data = await _graphql(token, query, {"owner": owner, "repo": repo})
    repo_node = data.get("repository")
    if not repo_node:
        return None
    return repo_node.get("visibility")


async def upload_release_asset_binary(
    token: str,
    owner: str,
    repo: str,
    *,
    release_id: str,
    asset_path: str,
    name: str,
    content_type: str = "application/octet-stream",
) -> None:
    """(#460 / 3.13.0 D-Friction.5) POST a binary asset to a GitHub
    release via uploads.github.com.

    GitHub splits create-release (api.github.com, JSON body) from
    upload-asset (uploads.github.com, raw binary). The hosts differ
    by design — uploads.github.com is a separate CDN endpoint for
    large-binary handling. Auth header is identical; request shape
    differs (raw binary body + ``?name=`` query param vs JSON body).

    Replaces the existing subprocess-based ``gh release upload``
    helper (github/releases.py::upload_release_asset) for the
    PlatformAdapter Protocol path. The subprocess form stays in
    place for the existing release.py call site; migration to this
    Protocol path is a separate Issue.

    Raises:
      ValueError: owner/repo/release_id/asset_path blank
      GitHubError: API failure (non-2xx, network timeout)
      OSError: asset_path can't be read
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if not release_id.strip():
        raise ValueError("release_id must not be empty.")
    if not asset_path.strip():
        raise ValueError("asset_path must not be empty.")
    if not name.strip():
        raise ValueError("name must not be empty.")

    from pathlib import Path
    body = Path(asset_path).read_bytes()
    url = (
        f"https://uploads.github.com/repos/{owner}/{repo}/"
        f"releases/{release_id}/assets"
    )
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "Content-Type": content_type,
    }
    client = _get_client()
    try:
        response = await client.post(
            url,
            headers=headers,
            params={"name": name},
            content=body,
        )
    except httpx.TimeoutException as exc:
        raise GitHubError(
            f"GitHub API timeout uploading release asset "
            f"{name} to release {release_id}."
        ) from exc
    except httpx.RequestError as exc:
        raise GitHubError(
            f"GitHub API network error uploading release asset: "
            f"{exc}."
        ) from exc
    if not (200 <= response.status_code < 300):
        raise GitHubError(
            f"GitHub API returned HTTP {response.status_code} on "
            f"POST {url}.",
            status_code=response.status_code,
            body=response.text,
        )


async def set_repo_visibility(
    token: str, owner: str, repo: str, *, target: str,
) -> None:
    """(#458 / 3.13.0 D-Friction.1) PATCH a repo's visibility.

    Wraps GitHub's REST endpoint
    ``PATCH /repos/{owner}/{repo}`` with body
    ``{"private": <bool>, "accept_visibility_change_consequences": true}``.

    GitHub mandates the consent acknowledgment for any visibility flip
    — public → private breaks public clones, forks lose lineage, search
    indexes invalidate; private → public exposes history. Sending the
    PATCH without the consent flag fails with HTTP 422. Callers that
    have explicit operator consent reach this helper with
    ``confirmed_consequences=True`` already validated at the
    PlatformAdapter Protocol boundary.

    ``target`` is ``"public"`` or ``"private"`` (lower-case). Maps to
    ``private: false`` / ``private: true`` respectively.

    Raises:
      ValueError: owner/repo blank, target outside the allowed set
      GitHubError: API failure (non-2xx response, network timeout)
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if target not in ("public", "private"):
        raise ValueError(
            f"target must be 'public' or 'private'; got {target!r}"
        )

    private = (target == "private")
    payload = {
        "private": private,
        "accept_visibility_change_consequences": True,
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "Content-Type": "application/json",
    }
    url = f"https://api.github.com/repos/{owner}/{repo}"
    client = _get_client()
    try:
        response = await client.patch(url, headers=headers, json=payload)
    except httpx.TimeoutException as exc:
        raise GitHubError(
            f"GitHub API timeout PATCHing repo visibility for "
            f"{owner}/{repo}."
        ) from exc
    except httpx.RequestError as exc:
        raise GitHubError(
            f"GitHub API network error PATCHing repo visibility for "
            f"{owner}/{repo}: {exc}."
        ) from exc
    if not (200 <= response.status_code < 300):
        raise GitHubError(
            f"GitHub API returned HTTP {response.status_code} on PATCH "
            f"/repos/{owner}/{repo}.",
            status_code=response.status_code,
            body=response.text,
        )


async def find_milestone_node_id(
    token: str,
    owner: str,
    repo: str,
    milestone: str | int,
) -> str:
    """Resolve a milestone identifier to its GitHub node ID (#232).

    `milestone` is matched as:
      - int → milestone number, via `milestone(number: $n)`.
      - str → milestone title, via a `milestones(first: 50, states:
        [OPEN, CLOSED])` nodes scan with exact-title match.

    Both OPEN and CLOSED states are searched so closed milestones can
    still receive Issue assignments — see #193's mid-cycle move from
    open 2.3.0 to closed 2.2.0 for the precedent.

    Raises:
      ValueError: owner/repo blank, milestone empty/zero, or wrong type.
      GitHubError: milestone cannot be found. The error message lists
        available titles (str form) or names the missing number (int
        form) to aid debugging.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    if isinstance(milestone, bool):
        # bool is a subclass of int in Python; reject explicitly.
        raise ValueError("milestone must be a non-empty string or positive int.")

    if isinstance(milestone, int):
        if milestone < 1:
            raise ValueError("milestone number must be a positive integer.")
        query = """
        query($owner: String!, $repo: String!, $number: Int!) {
          repository(owner: $owner, name: $repo) {
            milestone(number: $number) { id }
          }
        }
        """
        data = await _graphql(
            token, query, {"owner": owner, "repo": repo, "number": milestone}
        )
        repo_node = data.get("repository") or {}
        ms = repo_node.get("milestone") or {}
        node_id = ms.get("id")
        if not node_id:
            raise GitHubError(
                f"Milestone #{milestone} not found in {owner}/{repo}."
            )
        return node_id

    if not isinstance(milestone, str) or not milestone.strip():
        raise ValueError("milestone must be a non-empty string or positive int.")

    query = """
    query($owner: String!, $repo: String!) {
      repository(owner: $owner, name: $repo) {
        milestones(first: 50, states: [OPEN, CLOSED]) {
          nodes { id title }
        }
      }
    }
    """
    data = await _graphql(token, query, {"owner": owner, "repo": repo})
    repo_node = data.get("repository") or {}
    nodes = (repo_node.get("milestones") or {}).get("nodes") or []
    for n in nodes:
        if n["title"] == milestone:
            return n["id"]
    titles = [n["title"] for n in nodes]
    raise GitHubError(
        f"Milestone {milestone!r} not found in {owner}/{repo}. "
        f"Available milestones: {titles}"
    )


async def get_file_content(
    token: str,
    owner: str,
    repo: str,
    ref: str,
    path: str,
) -> str | None:
    """Fetch the text of a file from a repo at a given ref (#60).

    Returns the file's text content, or None if the file does not exist
    at that ref (distinguishes "upstream doesn't have the file" from
    transient API errors, which still raise GitHubError).

    Uses GraphQL's `object(expression: "ref:path")` pattern so auth is
    consistent with the rest of the server (no separate raw.github-
    usercontent.com fetch needed for private repos).
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if not ref.strip():
        raise ValueError("ref must not be empty.")
    if not path.strip():
        raise ValueError("path must not be empty.")

    expression = f"{ref}:{path}"
    query = """
    query($owner: String!, $repo: String!, $expr: String!) {
      repository(owner: $owner, name: $repo) {
        object(expression: $expr) {
          ... on Blob { text }
        }
      }
    }
    """
    data = await _graphql(
        token, query, {"owner": owner, "repo": repo, "expr": expression}
    )
    repo_node = data.get("repository") or {}
    obj = repo_node.get("object")
    if obj is None:
        return None
    return obj.get("text")
