"""Phase-boundary autonomous session rotation
(3.8.0 D6 / Theme G / Discussion #15 / #375).

This module ships the **pure-function foundations** for phase-
boundary autonomous rotation. The MCP turn-handler integration +
the ``undo_session_rotation`` typed MCP tool follow as separate
slices since they require deeper changes to ``open_session`` /
``close_session`` / the post_turn handler.

**Default state in 3.8.0: OFF (operator-opt-in).** The structural
infrastructure ships behind a project-rule flag
(``session.rotation: conditional`` to enable autonomous triggers;
default ``off``). Operator's directive 2026-05-08 confirmed phase-
boundary rotation is "safe to me"; default-OFF posture lets the
infrastructure observe in the wild before we flip the default in
3.8.x.

Per Discussion #15 trigger taxonomy:

  * **Autonomous**: post_release, post_pr_merge,
    post_discussion_ac, post_development_phase. Each fires from
    an action_log event the daemon publishes. Detection runs at
    operator-turn boundaries (never mid-tool-call per OQ2).
  * **Suggest-only**: time elapsed, turn count, topic boundary,
    pre-compaction. The detector here doesn't surface them
    autonomously; they remain operator-confirmation triggers in
    the protocol prose.

Saved as ``feedback_phase_boundary_session_rotation`` in the
auto-memory rule set.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from functools import cache
from typing import Iterable


class TriggerType(str, Enum):
    """Autonomous-rotation trigger taxonomy."""

    POST_RELEASE = "post_release"
    POST_PR_MERGE = "post_pr_merge"
    POST_DISCUSSION_AC = "post_discussion_ac"
    POST_DEVELOPMENT_PHASE = "post_development_phase"


@cache
def _trigger_class() -> type:
    @dataclass(frozen=True)
    class Trigger:
        """One detected phase-boundary trigger.

        ``source_event`` carries the raw action_log event that
        produced the trigger so the visible-signal marker can
        reference it ("rotated due to release_project completion at
        2026-05-08T18:42:49Z"). ``detail`` is a human-readable
        description; the marker uses it directly.
        """

        type: TriggerType
        source_event: str
        detail: str

    return Trigger


Trigger = _trigger_class()


# Policy levels: off / conditional / aggressive.
class RotationPolicy(str, Enum):
    OFF = "off"
    CONDITIONAL = "conditional"
    AGGRESSIVE = "aggressive"


# ---------------------------------------------------------------------------
# Phase-boundary detector
# ---------------------------------------------------------------------------

# Events the daemon publishes that trigger autonomous rotation. The
# action_log records these with structured ``operation`` /
# ``trigger`` tags; we map them to TriggerType values here.
_RELEASE_OPS = {"release_project"}
_PR_MERGE_OPS = {"pr_merge", "git_merge_to_main"}
_DISCUSSION_AC_OPS = {"discussion_ac_closed", "mark_discussion_decided"}
_DEVELOPMENT_PHASE_OPS = {"phase_completed"}


def detect_phase_boundary(events: "Iterable[dict]") -> "object | None":
    """Walk ``events`` newest-first; return the first matching trigger.

    Each event is a dict with at minimum ``operation`` (string) and
    optional ``timestamp`` (ISO-8601). Returns a :class:`Trigger`
    when a phase-boundary event is found, or None when none match.

    The detector is order-sensitive — callers should pass events in
    reverse chronological order so the most recent boundary wins.
    """
    for event in events:
        op = (event.get("operation") or "").strip()
        if not op:
            continue
        ts = event.get("timestamp", "")
        if op in _RELEASE_OPS:
            return Trigger(
                type=TriggerType.POST_RELEASE,
                source_event=op,
                detail=f"release_project completion at {ts}" if ts else op,
            )
        if op in _PR_MERGE_OPS:
            return Trigger(
                type=TriggerType.POST_PR_MERGE,
                source_event=op,
                detail=f"PR merge at {ts}" if ts else op,
            )
        if op in _DISCUSSION_AC_OPS:
            return Trigger(
                type=TriggerType.POST_DISCUSSION_AC,
                source_event=op,
                detail=(
                    f"Discussion AC closure at {ts}" if ts else op
                ),
            )
        if op in _DEVELOPMENT_PHASE_OPS:
            return Trigger(
                type=TriggerType.POST_DEVELOPMENT_PHASE,
                source_event=op,
                detail=f"development phase complete at {ts}" if ts else op,
            )
    return None


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------

def should_rotate(
    trigger: "object | None", *,
    policy: RotationPolicy = RotationPolicy.OFF,
    disabled_triggers: "Iterable[str] | None" = None,
) -> bool:
    """Decide whether the operator-turn-boundary should fire a rotation.

    * ``trigger is None`` → never rotate.
    * ``policy == off`` → never rotate (default per #375 / D6 cut).
    * ``policy == conditional`` → rotate when trigger is one of the
      four autonomous types AND not in ``disabled_triggers``.
    * ``policy == aggressive`` → rotate on any non-None trigger
      (operator-explicit opt-in only; matches #15 OQ2 path c
      "expert-mode override hidden behind toggle").
    """
    if trigger is None:
        return False
    if policy == RotationPolicy.OFF:
        return False
    disabled = set(disabled_triggers or [])
    if trigger.type.value in disabled:
        return False
    return True


# ---------------------------------------------------------------------------
# Visible-signal marker
# ---------------------------------------------------------------------------

def make_rotation_marker(
    *, prior_session_id: str, new_session_id: str,
    trigger: "object",
) -> str:
    """Build the ``[Session rotated: ...]`` marker per Discussion #15
    visible-signal pattern.

    The marker is structured (parseable by external tools — three
    semicolon-separated key:value pairs after the colon) and human-
    readable. Operators see it in the model's response so the
    mental model stays accurate; external tools can extract the
    new session_id for follow-up actions.
    """
    return (
        f"[Session rotated: {trigger.detail}; "
        f"prior session: {prior_session_id}; "
        f"new session: {new_session_id}]"
    )


# ---------------------------------------------------------------------------
# Action-log event payload for session.rotated.autonomous
# ---------------------------------------------------------------------------

def make_rotation_event(
    *, prior_session_id: str, new_session_id: str,
    trigger: "object", timestamp: str,
) -> dict:
    """Build the action_log event payload for a successful rotation.

    Per Discussion #15 OQ8 closure: the event carries the trigger
    type + both session IDs + timestamp so the audit trail stays
    coherent across rotations.
    """
    return {
        "operation": "session.rotated.autonomous",
        "trigger_type": trigger.type.value,
        "prior_session_id": prior_session_id,
        "new_session_id": new_session_id,
        "timestamp": timestamp,
        "detail": trigger.detail,
    }
