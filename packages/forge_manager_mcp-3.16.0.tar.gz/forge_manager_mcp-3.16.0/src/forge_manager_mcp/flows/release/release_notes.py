"""Step ``release_notes`` for the release chain (#294 Phase A).

State-mutating step: creates the GitHub Release page on both the
mirror (consumer-facing) and the dev repo (contributor-facing) per
#174. Compensation: delete-release (or mark-as-draft if delete is
unavailable).
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .validate import ReleaseStepFailed


def make_release_notes_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...server.handlers.release import _run_release_notes

        request = ctx.request
        server_ctx = request["server_ctx"]
        version = request["version"]
        notes = request.get("notes", "")
        repo_role = request["repo_role"]
        mirror_clone = request.get("mirror_clone")
        dry_run = request.get("dry_run", True)

        step = await _run_release_notes(
            server_ctx,
            mirror_clone,
            version,
            notes,
            repo_role,
            dry_run,
            dev_full=server_ctx.config.repos.private,
        )
        out_response = {**ctx.response, "release_notes": dict(step)}
        out_steps = ctx.steps_taken + (
            {
                "step": "release_notes",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": step["status"]},
            },
        )
        out = replace(ctx, response=out_response, steps_taken=out_steps)
        if step["status"] == "failed":
            return replace(out, error=ReleaseStepFailed("release_notes failed"))
        return out

    async def error(ctx: Context) -> Context:
        # Compensation: delete the Release page(s) the step created.
        # Per #174, release_notes writes Release pages on both the
        # mirror (public) and the dev (private) repo. Compensation
        # deletes both via ctx.public_face.delete_release (#294 Phase
        # A primitive). Each delete is idempotent — the underlying
        # gh / REST DELETE tolerates already-deleted.
        recorded = ctx.response.get("release_notes", {})
        if recorded.get("status") != "ok":
            return ctx
        request = ctx.request
        server_ctx = request.get("server_ctx")
        public_face = (
            getattr(server_ctx, "public_face", None)
            if server_ctx is not None
            else None
        )
        version = request.get("version")
        if public_face is None or version is None:
            failed = ctx.response.get("failed_compensations", ())
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {
                            "step": "release_notes",
                            "reason": (
                                "ctx.public_face is None — operator "
                                "must manually delete Release pages "
                                "via the platform web UI."
                            ),
                        },
                    ),
                },
            )

        tag = f"v{version}"
        config = getattr(server_ctx, "config", None)
        repos = getattr(config, "repos", None) if config is not None else None
        public = getattr(repos, "public", None) if repos is not None else None
        private = getattr(repos, "private", None) if repos is not None else None

        targets: list[tuple[str, str]] = []
        for full in (public, private):
            if not full or "/" not in full:
                continue
            owner, repo = full.split("/", 1)
            targets.append((owner, repo))

        compensation_detail: dict = {
            "step": "release_notes",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": True,
            "detail": {"action": "delete_release", "tag": tag,
                       "targets": [f"{o}/{r}" for o, r in targets]},
        }
        errors: list[dict] = []
        for owner, repo in targets:
            try:
                await public_face.delete_release(
                    owner=owner, repo=repo, tag=tag,
                )
            except Exception as exc:  # noqa: BLE001
                errors.append(
                    {"target": f"{owner}/{repo}", "error": str(exc)}
                )
        if errors:
            failed = ctx.response.get("failed_compensations", ())
            compensation_detail["detail"]["errors"] = errors
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {"step": "release_notes",
                         "errors": errors, "tag": tag},
                    ),
                },
                steps_taken=ctx.steps_taken + (compensation_detail,),
            )
        return replace(
            ctx, steps_taken=ctx.steps_taken + (compensation_detail,),
        )

    return Interceptor(
        enter=enter, error=error, name="release.release_notes",
    )
