"""Common exception hierarchy for the PlatformAdapter contract (3.0 / Phase 2).

Renames the 2.4.0-line ``GitHubUnavailableError`` to
``ForgeUnavailableError`` per OQ6 — the 3.0 abstraction sits above
multiple platforms, so a GitHub-named exception is no longer correct.
The semantics are unchanged: every adapter raises ``ForgeUnavailableError``
for service-availability failures (suspension, rate limit, network),
and adapters / handlers can use ``is_forge_unavailable(exc)`` to
decide whether to fall back / queue replay.

Adapters MAY raise additional, more specific exceptions that subclass
``ForgeError``. The ``is_forge_unavailable`` predicate accepts any
exception type and returns False for non-forge errors.
"""
from __future__ import annotations

import httpx


class ForgeError(RuntimeError):
    """Base for any adapter-raised error.

    Carries optional ``status_code`` (HTTP status when applicable) and
    ``body`` (response body for diagnosis) fields, matching the 2.x
    GitHubError shape. Adapters may subclass for backend-specific
    error categories (rate-limit, validation, etc.).
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        body: str = "",
    ):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class ForgeUnavailableError(ForgeError):
    """Raised when a forge backend is unreachable or returning service-
    availability errors.

    Subclass of ``ForgeError``, so existing ``except ForgeError`` clauses
    catch it. Phase 2's ``with_local_fallback`` decorator (refactored in
    Phase 6 to per-adapter dispatch) catches this specifically.

    Triggered by:
      - HTTP 401 / 403 (unauthorized / forbidden — could be account suspension)
      - HTTP 429 (rate limit)
      - HTTP 5xx service responses (502 / 503 / 504)
      - Network errors (timeout, DNS, connect refused)

    Reserved for "we couldn't talk to the backend." Caller-fault errors
    (404 / 422 / malformed query) raise base ``ForgeError`` and are NOT
    classified as unavailable — those propagate.
    """

    pass


class ConsentRequiredError(ForgeError):
    """(#458) Raised when an operation requires explicit operator
    consent that wasn't provided.

    Used by ``set_visibility`` when the caller passes
    ``confirmed_consequences=False`` and the underlying backend
    requires explicit acknowledgment of the blast-radius (GitHub
    requires ``--accept-visibility-change-consequences`` /
    ``accept_visibility_change_consequences: true`` for any
    visibility flip — public → private breaks public clones, forks
    lose lineage, search indexes invalidate; private → public exposes
    history that may include sensitive data).

    The fix is operator-driven (re-call with
    ``confirmed_consequences=True``). Classified as permanent per
    ``is_permanent_error`` — the dispatch wrapper surfaces
    immediately without buffering.
    """

    def __init__(self, message: str):
        super().__init__(message)


class InvalidArtifactRefError(ForgeError):
    """Raised when an ArtifactRef does not resolve on the backend.

    The fix is client-side (caller passed a stale or bogus ref). Tool
    layer must NOT buffer the failing operation — retry would fail
    identically. Distinct from ``ForgeUnavailableError`` because
    fallback wouldn't help.
    """

    def __init__(self, param_name: str, value: str):
        self.param_name = param_name
        self.value = value
        super().__init__(
            f"{param_name} does not resolve to a reachable forge artifact: `{value}`"
        )


class LocalStoreAlreadyExistsError(ForgeError):
    """(#470 sub-fix 2a) Raised when a LocalStore create-* operation
    targets an artifact that already exists on the filesystem.

    Idempotency violation, not a service-availability failure. The
    canonical store is healthy, the filesystem is reachable; the
    caller asked to create something already created. Three reasons
    this gets its own class:

    * ``is_forge_unavailable`` must return False — the canonical
      adapter is fine; transitioning it to DEGRADED on this signal
      causes the sticky-DEGRADED bug filed as #470 (the canonical
      local adapter sat DEGRADED for ~12h because a single stale
      create_milestone fired during release prep). DEGRADED canonical
      = writes skip canonical = writes accumulate in pending_writes
      or land only in mirrors — structurally fragile.

    * ``is_permanent_error`` must return True — retry with the same
      args fails identically. The caller must either upgrade to an
      ``update_*`` path or treat the existing artifact as success.
      Buffering the failed op pollutes the retry queue.

    * Distinct exception type lets callers catch this specifically
      (e.g., ``create_milestone`` wrappers that want to fall back to
      ``find_milestone`` + skip).

    ``status_code`` is intentionally None — there's no HTTP semantics
    here; this is a filesystem-side idempotency check. Predicate
    classifies via isinstance, not duck-typed status.

    Raised by LocalStoreAdapter's create-* methods that detect an
    existing target before doing destructive work:

      * ``create_milestone`` — milestone compound-doc already at
        ``milestones/<version>/``.
    """

    def __init__(self, message: str, *, artifact_kind: str = "", artifact_id: str = ""):
        super().__init__(message)
        self.artifact_kind = artifact_kind
        """Kind of the existing artifact ('milestone', 'issue', etc.)
        for caller routing."""
        self.artifact_id = artifact_id
        """Identifier of the existing artifact (version, number, etc.)
        — the value the caller passed that already resolves."""


# Status codes the predicate classifies as "service unavailable"
# rather than caller-fault.
_UNAVAILABLE_STATUS_CODES = frozenset({401, 403, 429, 502, 503, 504})

# (#485) Substrings in an exception's message or body that indicate
# an auth-failure path: missing/invalid/revoked token, suspended
# account, or insufficient scope. HTTP 401/403 carrying any of these
# markers classifies as permanent — retry-with-same-args fails
# identically and buffering pollutes the retry queue.
#
# Patterns are matched case-insensitively against ``str(exc)`` and
# any ``body`` attribute. The list is intentionally narrow: well-known
# auth-failure phrases that every supported backend (GitHub /
# Forgejo / GitLab) emits or that the daemon's own startup probe
# synthesizes (``"no token available in environment"``). Generic 403
# without an auth marker stays transient so legitimate temporary
# permission flips (visibility-change races, mid-rotation tokens)
# preserve their buffer-and-retry safety net.
_AUTH_FAILURE_MARKERS: tuple[str, ...] = (
    "no token available",
    "bad credentials",
    "token is invalid",
    "token has expired",
    "token expired",
    "account has been suspended",
    "account is suspended",
    "must be authenticated",
    "requires authentication",
    "resource not accessible by integration",
    "insufficient_scope",
    "401 unauthorized",
)


def _matches_auth_failure(exc: BaseException) -> bool:
    """(#485) Return True if the exception's message / body carries
    an auth-failure marker from ``_AUTH_FAILURE_MARKERS``.

    Surfaces in two places:
      * ``str(exc)`` — the message the adapter passed to the
        exception constructor (e.g. GitHubError(\"GitHub API
        returned HTTP 403.\") + body, or StartupProbeError(\"no
        token available in environment\")).
      * ``getattr(exc, 'body', '')`` — GitHubError preserves the
        raw HTTP body; Bad credentials / suspension messages come
        through here verbatim from GitHub's error envelope.
    """
    haystacks: list[str] = [str(exc)]
    body = getattr(exc, "body", "")
    if body:
        haystacks.append(str(body))
    blob = "\n".join(haystacks).lower()
    return any(marker in blob for marker in _AUTH_FAILURE_MARKERS)


def is_permanent_error(exc: BaseException) -> bool:
    """(#465) Predicate: is this exception class always permanent
    (retry futile, no transient recovery path)?

    Permanent errors are caller-fault or schema/validation failures
    where retrying with the same args will fail identically. The
    dispatch wrapper must NOT buffer permanent failures — buffering
    them pollutes ``.claude/pending-posts.md`` with entries that fail
    on every replay attempt.

    Classified as permanent:
        * ``InvalidArtifactRefError`` — bad ArtifactRef (canonical-vs-remote
          number resolution miss, stale ref, etc.). Already documented
          in the class docstring as no-buffer.
        * Legacy ``InvalidNodeIdError`` (github.core) — same shape as
          ``InvalidArtifactRefError`` for the legacy GitHub-direct path.
        * ``ClassificationError`` — rule violation; the operator must
          fix the input, not retry.
        * ``ValueError`` — input/schema validation; retry won't fix
          bad input.
        * ``ForgeError`` with a caller-fault HTTP status (400, 404,
          405, 409, 422) — these are explicit "your request is bad"
          responses from the backend.
        * (#485) Any exception with HTTP 401 status — auth always
          fails with the same token; the operator must rotate
          credentials, not retry.
        * (#485) Any exception with HTTP 401/403 status AND a known
          auth-failure marker in the message or body (e.g. ``no
          token available`` from the daemon's startup probe; ``Bad
          credentials`` / ``account is suspended`` from GitHub's
          REST/GraphQL error envelope). Includes legacy
          ``GitHubError`` shapes that pre-date the ForgeError
          normalization (#465 / 3.13.0 caveat — duck-types via
          ``status_code`` attribute so non-``ForgeError`` exception
          classes still classify).

    NOT permanent (transient → caller may want to buffer):
        * ``ForgeUnavailableError`` without an auth-failure marker —
          generic service availability failure. Handled by
          ``is_forge_unavailable``.
        * ``DaemonUnavailableError`` — daemon may come back; buffering
          for replay is correct semantics.
        * Plain ``ReplicationWriteError`` without status — ambiguous;
          err on transient to preserve today's buffering behavior.
        * HTTP 429 (rate limit) / 5xx (service hiccup) — transient
          even when wrapped in ForgeError.

    Companion predicate to ``is_forge_unavailable``. The two are not
    inverses — there's a transient-but-not-forge-unavailable middle
    ground (daemon outage, opaque network errors) that buffers without
    triggering adapter degradation. And there is an
    auth-failure-AND-unavailable overlap (#485): a suspended-account
    403 is BOTH permanent (don't buffer) AND classifies as
    forge-unavailable (state-machine should mark DEGRADED). The two
    predicates run independently — DEGRADED state prevents future
    dispatches; permanent classification prevents the buffer
    pollution today's failure would otherwise produce.

    Per #465 / public-mirror #7 Bug 2 (3.13.0 baseline);
    #485 (3.14.0 GitHub-tightness audit) for the HTTP 401/403
    auth-failure extension.
    """
    # Explicit permanent-class checks via duck-typing on attributes
    # to avoid circular imports. ClassificationError lives in
    # forge_manager_mcp.classification; InvalidNodeIdError in
    # github/core.py — both at higher layers than this module.

    # (#513, 3.16.0 D0) RemoteOpError carries an explicit
    # is_permanent flag forwarded from the daemon's
    # ``_build_op_error_envelope`` — daemon-side classification with
    # native exception access. Honor the flag directly so the
    # downstream status_code / body duck-typing branches don't
    # have to re-classify potentially-lost shape.
    if getattr(exc, "is_permanent", False) is True:
        return True
    if isinstance(exc, InvalidArtifactRefError):
        return True
    if isinstance(exc, ConsentRequiredError):
        return True
    # (#470 sub-fix 2a) LocalStoreAlreadyExistsError — caller asked
    # to create an artifact that already exists on the canonical
    # filesystem. Same retry-futile shape as InvalidArtifactRefError:
    # re-running with identical args fails identically.
    if isinstance(exc, LocalStoreAlreadyExistsError):
        return True
    # (#497, 3.14.0) DaemonDeadError — discovery file points at a dead
    # / zombie PID. Replay would time out identically; surface
    # immediately with operator-actionable message. Duck-typed via
    # class name to avoid circular import.
    if exc.__class__.__name__ == "DaemonDeadError":
        return True
    if exc.__class__.__name__ in ("InvalidNodeIdError", "ClassificationError"):
        return True
    if isinstance(exc, ValueError):
        return True
    # ForgeError with caller-fault status_code.
    if isinstance(exc, ForgeError) and not isinstance(exc, ForgeUnavailableError):
        if exc.status_code in {400, 404, 405, 409, 422}:
            return True
    # (#485) HTTP auth-failure classification. Duck-types on
    # ``status_code`` so legacy GitHubError (not a ForgeError
    # subclass) classifies the same as the normalized ForgeError /
    # ForgeUnavailableError paths.
    status = getattr(exc, "status_code", None)
    if status == 401:
        # Bare 401 — every supported backend (GitHub / Forgejo /
        # GitLab) means "your credentials are invalid." Retry-with-
        # same-args fails identically; operator must rotate token.
        return True
    if status == 403 and _matches_auth_failure(exc):
        # 403 is ambiguous on its own (permission denied could be
        # transient — visibility-change race, scope misconfig that
        # the operator fixes server-side without redeploying). Only
        # classify as permanent when a known auth-failure marker
        # is present in the message/body.
        return True
    return False


def is_forge_unavailable(exc: BaseException) -> bool:
    """Predicate: should this exception trigger fallback / replay queue?

    Returns True for failures classified as backend-side service /
    availability problems. Returns False for caller-fault errors
    (404 not-found, 422 validation, malformed query) and for any
    non-forge exception class.

    Phase 2 (#266) — used by adapter-routing logic to decide whether
    to switch to a different replication target on a failed call.
    Phase 6 (#270) extends this to per-adapter state-machine
    transitions.

    (#362, 3.7.0 D1) Duck-types on ``status_code`` attribute so legacy
    ``GitHubError`` (which doesn't subclass ``ForgeError``) is still
    classified correctly when its status_code is in the unavailable
    set. Pre-#362 the predicate matched only ``ForgeError`` subclasses;
    a 403 raised as ``GitHubError`` from the github/* layer fell
    through and the ReplicationManager's state machine never
    transitioned the adapter to DEGRADED.
    """
    # (#470 sub-fix 2a) LocalStoreAlreadyExistsError is an idempotency
    # violation, NOT a service-availability failure — canonical
    # filesystem is fine; the caller asked to create something
    # already created. Check first so the subsequent ForgeError
    # branches can't accidentally classify it. The exception also
    # carries no status_code so the duck-typed status check below
    # wouldn't catch it; this guard is defense-in-depth + explicit
    # intent.
    if isinstance(exc, LocalStoreAlreadyExistsError):
        return False
    # Direct subclass match — anything explicitly raised as unavailable.
    if isinstance(exc, ForgeUnavailableError):
        return True
    # Status-code match — covers ForgeError raised with a known
    # status_code field AND duck-types legacy GitHubError-shape errors
    # (any exception carrying ``status_code`` in the unavailable set).
    status = getattr(exc, "status_code", None)
    if status in _UNAVAILABLE_STATUS_CODES:
        return True
    # Network-error case: ForgeError raised from httpx without a
    # status code, with the underlying httpx exception linked via
    # __cause__ (raise X from exc semantics).
    if isinstance(exc, ForgeError):
        if exc.status_code is None and exc.__cause__ is not None:
            if isinstance(exc.__cause__, httpx.TimeoutException):
                return True
            if isinstance(exc.__cause__, httpx.RequestError):
                return True
    return False
