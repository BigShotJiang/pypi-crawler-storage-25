"""Canonical data types used by every PlatformAdapter (3.0 / Phase 2).

Adapters normalize backend-native shapes (GitHub GraphQL nodes, Forgejo
REST objects, GitLab API responses, filesystem records) into these
common types. Handlers in ``server/handlers/*`` consume adapter output
through these types — never raw backend payloads.

Pydantic-backed for parity with existing models.py types. ``frozen=True``
on every type — adapters return immutable snapshots; mutations go
through adapter methods.

Per Rule 5 (schema_as_functions): every class lives behind a cached
factory helper; module-level re-exports preserve the public surface.
"""
from __future__ import annotations

from datetime import datetime
from functools import cache
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# References
# ---------------------------------------------------------------------------

ArtifactKind = Literal["issue", "discussion", "comment", "milestone", "release"]
"""The five kinds of artifact every adapter must round-trip."""


IssueState = Literal["open", "closed"]
"""Lifecycle state for an Issue. Multi-dimensional state (decided,
archived, etc.) lives in the labels / state.txt parallel surface, not
in this single-axis field. See ``vocab.py`` § State axes."""


@cache
def _artifact_ref_class() -> type:
    class ArtifactRef(BaseModel):
        """Opaque reference to a forge artifact across platforms.

        Adapters populate ``native_id`` with whatever identifier the backend
        uses (GitHub GraphQL node ID, Forgejo REST URL, local filesystem
        path, etc.). Handlers don't introspect ``native_id`` — they pass
        refs back to the same adapter that produced them.

        ``platform_id`` lets a multi-adapter workflow keep refs typed by
        origin: a ref produced by GitHubAdapter goes back to GitHubAdapter,
        not Forgejo. The ``ReplicationManager`` in Phase 6 uses this to
        route operations correctly during multi-host replication.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        platform_id: str = Field(
            ..., description="Adapter that produced this ref ('github', 'codeberg', 'local', etc.)"
        )
        native_id: str = Field(
            ..., description="Backend-native identifier (GraphQL node ID, REST URL, file path, etc.)"
        )
        kind: ArtifactKind
        owner: str = Field(..., description="Repo owner / org")
        repo: str = Field(..., description="Repo name")
        number: int | None = Field(
            None,
            description=(
                "Repo-scoped artifact number when applicable (Issues, "
                "Discussions, PRs). None for comments and other artifacts "
                "that don't have a repo-scoped number."
            ),
        )

    return ArtifactRef


ArtifactRef = _artifact_ref_class()


# ---------------------------------------------------------------------------
# Artifact types
# ---------------------------------------------------------------------------

@cache
def _label_class() -> type:
    class Label(BaseModel):
        """A label applied to an Issue or Discussion."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        name: str
        color: str = Field("0E8A16", description="6-digit hex without leading #")
        description: str = ""

    return Label


Label = _label_class()


@cache
def _milestone_class() -> type:
    class Milestone(BaseModel):
        """A repo-scoped milestone (release target)."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        title: str
        number: int
        state: Literal["open", "closed"]
        description: str = ""
        due_on: datetime | None = None
        percent_complete: float = Field(
            0.0,
            ge=0.0,
            le=100.0,
            description=(
                "Percent of milestone-attached issues closed (0.0–100.0). "
                "GitHub reports this directly via GraphQL "
                "progressPercentage; backends without a native field "
                "compute it from {open, closed} issue counts or default "
                "to 0.0."
            ),
        )

    return Milestone


Milestone = _milestone_class()


MilestoneTier = Literal["major", "minor", "patch"]
"""Semver tier of a milestone-as-compound-doc (#397). Major / minor
require an anchored plan Discussion (per `release.milestone_has_plan`
gate, severity tiered in #397 D3). Patch with `hotfix=True` is exempt."""


MilestoneLifecycle = Literal["planned", "active", "closed"]
"""Single-axis lifecycle for milestones-as-compound-docs (#397, OQ7
decision: single-axis for 3.11.0). `planned` — created, no Issues
assigned. `active` — at least one Issue assigned + still open.
`closed` — cut event has run. Multi-axis (`closed-shipped` /
`closed-rolled-forward`) deferred to follow-up minor if demand
surfaces."""


@cache
def _milestone_artifact_class() -> type:
    class MilestoneArtifact(BaseModel):
        """A milestone as a first-class compound-document artifact (#397).

        Distinct from ``Milestone`` (forge-native shape carrying the
        external ``number`` / ``percent_complete`` view). ``MilestoneArtifact``
        is the canonical-store shape under ``milestones/<version>/`` —
        directory-shaped with ``title.md`` / ``body.md`` /
        ``state.txt`` / ``labels.txt`` / ``meta.json`` parallel to the
        issues / discussions / pulls compound docs (3.8.0 D5 / #371).

        Adopted in 3.11.0 D1.a. Bidirectional plan link
        (``plan_discussion``) closes the asymmetry from 3.10.0 D6.2:
        plans previously knew their milestone via
        ``meta.json.anchored_milestone`` but milestones had no
        back-reference.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        version: str = Field(
            ...,
            description=(
                "Semver version string — primary identifier on the "
                "canonical store (directory name). e.g. '3.11.0'."
            ),
        )
        title: str = Field(
            "",
            description=(
                "Human-readable title; defaults to version when "
                "unspecified."
            ),
        )
        state: MilestoneLifecycle = "planned"
        tier: MilestoneTier
        hotfix: bool = Field(
            False,
            description=(
                "When true and tier='patch', exempts this milestone "
                "from the `release.milestone_has_plan` gate. Default "
                "false — even patch releases benefit from a plan when "
                "scope > 1 Issue."
            ),
        )
        plan_discussion: int | list[int] | None = Field(
            None,
            description=(
                "Back-reference to the anchored planning Discussion(s). "
                "Single int when one plan scopes this milestone; list "
                "when multiple plans cross-anchor (mirrors the symmetric "
                "shape on Discussion `meta.json.anchored_milestone` from "
                "3.10.0 D6.2 OQ2 b). None when no plan is anchored "
                "(hotfix milestones)."
            ),
        )
        cut_at: datetime | None = Field(
            None,
            description=(
                "ISO8601 timestamp of the cut event when state="
                "'closed'. None for planned / active milestones."
            ),
        )
        tag_sha: str | None = Field(
            None,
            description=(
                "Git tag SHA of the cut commit when state='closed'. "
                "None for planned / active milestones."
            ),
        )

    return MilestoneArtifact


MilestoneArtifact = _milestone_artifact_class()


GapState = Literal["triage", "accepted", "filed", "ignored"]
"""Single-axis four-state triage model for gaps-as-compound-docs (#405 /
3.11.0 D1.b). Initial state on first detection: ``triage``. Operator
moves through ``accept_gap`` (into current plan) / ``file_gap`` (Issue
on future milestone) / ``ignore_gap`` (won't fix). New findings on
previously-``filed`` / ``ignored`` gaps re-flip to ``triage`` so the
operator re-decides per #405 S2."""


GapSeverity = Literal["fail", "warn", "info"]
"""Severity rollup for a gap category (#405 OQ5 highest-wins). When a
category has mixed-severity findings, the highest tier wins for
``labels.txt`` so a single ``fail`` finding tags the whole category
``severity:fail``."""


GapTier = Literal["mechanical", "advisory"]
"""Mechanical (gates can fail on these) vs advisory (info-severity
nudges only). Maps to the existing code_design rule classification."""


@cache
def _gap_finding_class() -> type:
    class GapFinding(BaseModel):
        """A single detector finding inside a gap compound doc.

        Stored in ``meta.json.findings[]`` per #405 schema; rendered
        into ``body.md`` as a row in the findings table.
        ``first_seen_at`` survives across detector runs (preserves the
        finding's history); ``last_seen_at`` updates every run that
        sees the finding; both drop when the finding clears.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        path: str = Field(..., description="Project-dir-relative path.")
        line: int | None = Field(
            None, description="Line number when applicable; None for file-level findings.",
        )
        severity: GapSeverity
        message: str
        first_seen_at: datetime
        last_seen_at: datetime

    return GapFinding


GapFinding = _gap_finding_class()


@cache
def _gap_artifact_class() -> type:
    class GapArtifact(BaseModel):
        """A detector category as a first-class compound document (#405).

        Stored at canonical-store ``gaps/<category>/`` with the same
        compound-doc shape as issues / discussions / pulls / milestones
        (per 3.8.0 D5 / #371). One document per detector category, not
        one per finding — per-finding granularity stays in the
        action_log (3.6.0 D4); the compound doc is the durable
        per-category triage state.

        State machine (single-axis, 4 values per OQ from #405):
            * ``triage`` — initial state on first detection; needs
              operator decision; **blocks plan close** via the
              ``release.no_triage_gaps_against_cut`` gate.
            * ``accepted`` — operator commits to addressing in the
              current plan; gates allow.
            * ``filed`` — operator filed an Issue on a future milestone;
              closed-as-forwarded.
            * ``ignored`` — operator decided not to fix; closed-as-rejected.

        Re-detection rules (#405 S2):
            * Zero findings + state in (accepted/triage) → state stays
              (operator decision still applies; finding_count=0 surfaces
              as ``clean``).
            * Zero findings + state in (filed/ignored) → state stays.
            * New findings + state=triage → state stays triage.
            * New findings + state=accepted → state stays accepted.
            * New findings + state in (filed/ignored) → state flips to
              triage (re-decide; original disposition may be stale).
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        detector_category: str = Field(
            ...,
            description=(
                "Category name — directory name on the canonical "
                "store (e.g. 'test_purity_tagging', "
                "'code_design.test_purity_tagging')."
            ),
        )
        title: str = Field(
            "",
            description="Human-readable title; defaults to category when empty.",
        )
        state: GapState = "triage"
        severity: GapSeverity = "info"
        tier: GapTier
        finding_count: int = Field(0, ge=0)
        findings: tuple[GapFinding, ...] = Field(default_factory=tuple)
        last_run_at: datetime | None = Field(
            None,
            description="Most-recent detector run that updated this gap.",
        )
        state_changed_at: datetime | None = Field(
            None,
            description="Timestamp of most-recent state transition.",
        )
        state_changed_by: str | None = Field(
            None,
            description="Operator (or 'detector' when re-flipped automatically).",
        )
        state_change_note: str | None = Field(
            None,
            description="Free-text rationale captured at state-transition time.",
        )
        anchored_milestone: str | None = Field(
            None,
            description=(
                "Milestone version this gap's triage decision applies "
                "to (set when ``state=accepted``)."
            ),
        )
        accepted_phase: str | None = Field(
            None,
            description=(
                "Plan phase the operator put this gap under when "
                "accepting (e.g. ``D2`` for phase D2's scope)."
            ),
        )
        filed_issue: int | None = Field(
            None,
            description="Issue number created when filed for later.",
        )
        filed_target_milestone: str | None = Field(
            None,
            description="Milestone version the filed Issue targets.",
        )
        cross_links: tuple[int, ...] = Field(
            default_factory=tuple,
            description="Additional Issue numbers that reference this gap.",
        )

    return GapArtifact


GapArtifact = _gap_artifact_class()


@cache
def _comment_class() -> type:
    class Comment(BaseModel):
        """A comment on an Issue or Discussion."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        ref: ArtifactRef
        body: str
        author: str
        created_at: datetime
        parent: ArtifactRef = Field(
            ..., description="The Issue or Discussion this comment is on."
        )
        url: str = Field(
            "",
            description=(
                "Backend-native URL to the comment when available — usually "
                "the deep-linked anchor on the parent's web page. Empty "
                "string when the backend doesn't expose a per-comment URL "
                "(e.g., LocalStoreAdapter)."
            ),
        )

    return Comment


Comment = _comment_class()


@cache
def _issue_class() -> type:
    class Issue(BaseModel):
        """An Issue across any backend."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        ref: ArtifactRef
        title: str
        body: str
        state: IssueState
        labels: list[str] = Field(
            default_factory=list,
            description="Label names. Includes reserved labels (kind:*, category:*) plus open-set labels.",
        )
        milestone: str | None = None
        author: str = ""
        created_at: datetime | None = None
        updated_at: datetime | None = None
        url: str = Field(
            "",
            description=(
                "Backend-native URL when available. May be a 'local://...' "
                "synthetic URL for the LocalStoreAdapter."
            ),
        )

    return Issue


Issue = _issue_class()


@cache
def _discussion_class() -> type:
    class Discussion(BaseModel):
        """A Discussion across any backend.

        On GitHub, Discussions have a separate surface. On Forgejo / GitLab,
        Discussions are Issues with a ``kind:discussion`` label per the
        OQ1 resolution. Adapters present them through this canonical type
        regardless of backend representation.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        ref: ArtifactRef
        title: str
        body: str
        state: IssueState = "open"
        category: str | None = Field(
            None,
            description=(
                "Discussion category — 'Architecture' / 'Ideas' / 'UX/UI' on "
                "GitHub Discussions; the value of the ``category:*`` label on "
                "Forgejo / GitLab. None when no category applies."
            ),
        )
        labels: list[str] = Field(default_factory=list)
        decided: bool = Field(
            False,
            description=(
                "True when the Discussion has reached Decided ✓ — encoded as "
                "the ``decided`` state value in the multi-dim state model."
            ),
        )
        author: str = ""
        created_at: datetime | None = None
        url: str = ""

    return Discussion


Discussion = _discussion_class()


@cache
def _release_class() -> type:
    class Release(BaseModel):
        """A tagged release across any backend."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        tag: str
        name: str
        body: str = ""
        prerelease: bool = False
        created_at: datetime | None = None
        url: str = ""

    return Release


Release = _release_class()


@cache
def _search_result_class() -> type:
    class SearchResult(BaseModel):
        """Result envelope returned by ``PlatformAdapter.search_issues``.

        Carries the canonical issue list plus the two caller-visible
        paging / debug fields the legacy MCP tool surface needs:

          * ``total_count`` — total matches the backend reports for the
            full query (may exceed ``len(results)`` when ``limit`` clips).
          * ``query`` — the final query string the adapter dispatched,
            echoed so callers can debug-print the layered structured
            params (state / labels / milestone) without a separate
            round-trip.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        results: list[Issue]
        total_count: int = Field(..., ge=0)
        query: str

    return SearchResult


SearchResult = _search_result_class()


@cache
def _history_entry_class() -> type:
    class HistoryEntry(BaseModel):
        """One audit-log entry on a LocalStore artifact (#274 Phase D).

        Each mutation (body update, state change, label add/remove,
        decision marker, close) writes one JSON file under
        ``<artifact_dir>/history/<utc-ts>-<op>.json``. ``query_history``
        parses these into typed entries.

        ``payload`` carries the operation-specific details — for
        ``update_body`` it has ``prior_length`` / ``new_length``; for
        ``close_issue`` it has ``prior_state`` / ``state_reason`` /
        ``new_state``; for ``add_label`` / ``remove_label`` it has
        ``label``; etc. Schema lives in
        ``LocalStoreAdapter._append_history`` call sites — entries are
        intentionally extensible per-operation rather than fully typed.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        ref: ArtifactRef
        timestamp: datetime
        operation: str = Field(
            ...,
            description=(
                "The mutation kind: ``update_body``, ``close_issue``, "
                "``add_label``, ``remove_label``, ``mark_decided``, "
                "``add_comment`` etc. Matches the file-suffix in "
                "``history/<ts>-<operation>.json``."
            ),
        )
        payload: dict = Field(
            default_factory=dict,
            description=(
                "Operation-specific fields. Per-op shape documented at "
                "the LocalStoreAdapter call site."
            ),
        )

    return HistoryEntry


HistoryEntry = _history_entry_class()


@cache
def _remote_change_class() -> type:
    class RemoteChange(BaseModel):
        """One change observed on a remote backend (#274 Phase D foundation
        for OQ4 import_remote_changes).

        Adapter-specific ``fetch_remote_changes(since=...)`` methods return
        a list of these — each describing one mutation the remote performed
        since the cutoff. ``LocalStoreAdapter.apply_remote_change`` writes
        the change into the canonical store, with conflict detection
        against local history.

        Schema is intentionally loose at the ``payload`` level — different
        operations carry different fields (``update_body`` has ``new_body``;
        ``close_issue`` has ``state_reason``; etc.). Per-op shape is
        documented at the adapter call site that constructs the
        ``RemoteChange``.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        source_platform_id: str = Field(
            ...,
            description=(
                "Which backend observed this change — ``github`` / "
                "``forgejo`` / ``gitlab`` / etc. Used by conflict detection "
                "to attribute which side originated the divergence."
            ),
        )
        ref: ArtifactRef = Field(
            ...,
            description=(
                "The artifact this change targets. ``ref.platform_id`` is "
                "the source platform; the canonical store maps to its own "
                "matching artifact via meta.json node-id lookup."
            ),
        )
        operation: str = Field(
            ...,
            description=(
                "Mutation kind: ``create_issue``, ``update_body``, "
                "``close_issue``, ``add_label``, ``add_comment`` etc. "
                "Matches the corresponding LocalStoreAdapter method name."
            ),
        )
        observed_at: datetime = Field(
            ...,
            description=(
                "When the remote reported the change. Used as the "
                "watermark for conflict detection — if local has a "
                "history entry with timestamp > observed_at on the same "
                "ref, that's a conflict."
            ),
        )
        payload: dict = Field(
            default_factory=dict,
            description="Operation-specific fields (op-shape per adapter).",
        )

    return RemoteChange


RemoteChange = _remote_change_class()


@cache
def _import_conflict_class() -> type:
    class ImportConflict(BaseModel):
        """A RemoteChange that couldn't auto-apply because local history
        on the same artifact diverges. Surfaced in ``ImportReport`` so
        callers can resolve manually."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        change: RemoteChange
        reason: str
        local_history: list[HistoryEntry] = Field(
            default_factory=list,
            description=(
                "Local history entries that triggered the conflict — "
                "typically the entries with timestamp > change.observed_at."
            ),
        )

    return ImportConflict


ImportConflict = _import_conflict_class()


@cache
def _import_report_class() -> type:
    class ImportReport(BaseModel):
        """Result of a ``ReplicationManager.import_remote_changes`` run.

        ``applied`` carries the changes that wrote cleanly to canonical.
        ``conflicts`` carries the ones that needed manual resolution.
        ``source_platform_id`` echoes which backend was being imported
        from. Caller decides what to do with conflicts (re-run with a
        different watermark, accept-remote, accept-local, manual merge,
        etc.).
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        source_platform_id: str
        since: datetime
        applied: list[RemoteChange] = Field(default_factory=list)
        conflicts: list[ImportConflict] = Field(default_factory=list)
        skipped: list[RemoteChange] = Field(
            default_factory=list,
            description=(
                "Changes the canonical adapter explicitly declined to "
                "apply (unsupported operation, malformed payload, etc.). "
                "Distinct from conflicts — callers shouldn't retry these."
            ),
        )

    return ImportReport


ImportReport = _import_report_class()


@cache
def _recovery_bundle_class() -> type:
    class RecoveryBundle(BaseModel):
        """Bundled session-recovery payload returned by
        ``PlatformAdapter.bundle_recover_context`` (#274 Phase C5).

        Carries every artifact ``recover_context`` needs in a single
        typed envelope so the handler doesn't make N separate round-
        trips. GitHubAdapter populates this from the existing aliased
        GraphQL bundle (#181) for one-round-trip perf; other adapters
        decompose into separate ``list_*`` + ``get_discussion_body``
        calls via the shared default helper.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        toc_body: str | None = Field(
            None,
            description=(
                "Current opening-post body of the Project Index Discussion, "
                "or None if the fetch failed (best-effort — TOC fetch "
                "failures don't poison the rest of the bundle)."
            ),
        )
        open_issues: list[Issue] = Field(default_factory=list)
        recent_discussions: list[Discussion] = Field(default_factory=list)
        milestones: list[Milestone] = Field(default_factory=list)

    return RecoveryBundle


RecoveryBundle = _recovery_bundle_class()


# ---------------------------------------------------------------------------
# Session lock (canonical-side groundwork for open_session GitHub-down fix)
# ---------------------------------------------------------------------------

@cache
def _session_event_class() -> type:
    class SessionEvent(BaseModel):
        """One session-lifecycle event (opened / closed / heartbeat).

        LocalStoreAdapter writes these to ``<docs_repo>/sessions/<session_id>/
        <utc-ts>-<event>.json`` so a session_id can be minted and persisted
        even when the GitHub mirror's Session Lock Discussion is unreachable.
        The future ``open_session`` handler migration reads from the
        canonical store first and falls back to GitHub for legacy projects;
        until then, this is a foundation surface.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        session_id: str
        event: str = Field(
            ...,
            description=(
                "The lifecycle marker — ``opened`` / ``closed`` / "
                "``heartbeat``. Open-set so projects with bespoke "
                "session-lifecycle hooks can record additional kinds."
            ),
        )
        body: str = ""
        timestamp: datetime

    return SessionEvent


SessionEvent = _session_event_class()


# ---------------------------------------------------------------------------
# Bootstrap (multi-platform scaffold C1)
# ---------------------------------------------------------------------------

@cache
def _bootstrap_result_class() -> type:
    class BootstrapResult(BaseModel):
        """Per-platform bootstrap output (multi-platform scaffold C1).

        Returned by ``PlatformAdapter.bootstrap_project``. The top-level
        ``scaffold_project`` handler accumulates a list of these — one per
        platform in ``replication_order`` — and merges ``artifacts`` into
        the next adapter's ``existing_state`` so subsequent adapters can
        skip work the canonical already did.

        ``artifacts`` is platform-specific and treated opaquely by the
        handler — GitHub populates it with Discussion / project-board /
        repo node IDs; LocalStore populates it with paths and per-step
        action codes.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        platform_id: str
        artifacts: dict = Field(
            default_factory=dict,
            description=(
                "Per-platform IDs / paths created. Schema is platform-"
                "specific; the top-level handler treats it opaquely."
            ),
        )
        manual_steps: list[str] = Field(
            default_factory=list,
            description=(
                "Operator-pick steps the adapter couldn't automate. "
                "GitHub's Discussion-category creation is the canonical "
                "example — no API exists, so the adapter pauses and asks "
                "the operator to click through the web UI then re-run "
                "the bootstrap."
            ),
        )
        phase: Literal["complete", "awaiting_manual"] = Field(
            "complete",
            description=(
                "``complete`` when the adapter finished all of its work. "
                "``awaiting_manual`` when manual_steps is non-empty and "
                "a re-run is required."
            ),
        )

    return BootstrapResult


BootstrapResult = _bootstrap_result_class()


# ---------------------------------------------------------------------------
# Drift detection (Phase 6 will populate these)
# ---------------------------------------------------------------------------

@cache
def _drift_report_class() -> type:
    class DriftReport(BaseModel):
        """Per-adapter drift report (Phase 6 / #270).

        Compares a local snapshot against a backend's actual state and
        reports the diff. Phase 6 is when this gets exercised; Phase 2
        declares the type so adapters can stub the method.
        """

        model_config = ConfigDict(frozen=True, extra="forbid")

        platform_id: str
        is_clean: bool = Field(
            ...,
            description="True iff every diff list below is empty.",
        )
        issues_only_local: list[int] = Field(
            default_factory=list,
            description="Issue numbers present locally but absent on the backend.",
        )
        issues_only_remote: list[int] = Field(
            default_factory=list,
            description="Issue numbers present on the backend but absent locally.",
        )
        issues_diverged: list[int] = Field(
            default_factory=list,
            description="Issue numbers where local and backend disagree on state/labels/body.",
        )
        discussions_only_local: list[int] = Field(default_factory=list)
        discussions_only_remote: list[int] = Field(default_factory=list)
        discussions_diverged: list[int] = Field(default_factory=list)
        notes: list[str] = Field(
            default_factory=list,
            description="Human-readable notes on the diff. Adapter-specific quirks land here.",
        )

    return DriftReport


DriftReport = _drift_report_class()


# ---------------------------------------------------------------------------
# Release artifacts (#460 / 3.13.0 D-Friction.5)
# ---------------------------------------------------------------------------

# Release backends split into two semantics:
#   1. Binary upload — backend hosts the asset and serves it directly
#      (GitHub via uploads.github.com; Forgejo via the unified releases
#      endpoint). Caller provides path + content-type.
#   2. Link reference — backend stores a URL pointing at externally-
#      hosted storage (GitLab releases attach link refs; Forgejo
#      supports both shapes). Caller provides url + display name.
#
# `attach_release_artifact` on the PlatformAdapter Protocol accepts
# either shape; per-adapter capability flags
# (`supports_binary_release_uploads` / `supports_link_release_references`)
# declare which shapes the backend implements.


@cache
def _binary_upload_class() -> type:
    class BinaryUpload(BaseModel):
        """A binary release asset to upload to the backend's storage."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        path: str = Field(
            ..., description="Filesystem path to the asset file"
        )
        content_type: str = Field(
            "application/octet-stream",
            description="MIME type for the upload (Content-Type header)",
        )
        name: str | None = Field(
            None,
            description=(
                "Display name for the asset on the release page. "
                "Defaults to the basename of `path` when omitted."
            ),
        )

    return BinaryUpload


BinaryUpload = _binary_upload_class()


@cache
def _link_reference_class() -> type:
    class LinkReference(BaseModel):
        """A reference link to an externally-hosted release asset."""

        model_config = ConfigDict(frozen=True, extra="forbid")

        url: str = Field(
            ..., description="Public URL of the externally-hosted artifact"
        )
        name: str = Field(
            ..., description="Display name for the link on the release page"
        )
        link_type: str = Field(
            "other",
            description=(
                "Backend-specific link category. GitLab takes "
                "{'other', 'runbook', 'package', 'image'}; Forgejo "
                "ignores. Default 'other' is safe across backends."
            ),
        )

    return LinkReference


LinkReference = _link_reference_class()


# The union type `BinaryUpload | LinkReference` is declared inline at
# the call site (`PlatformAdapter.attach_release_artifact`); Python
# Union types aren't classes so no @cache factory is needed.
