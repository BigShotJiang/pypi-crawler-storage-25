"""Per-step executor framework for the upgrade wizard
(3.8.0 D2.3 / Discussion #12 / #373).

Each executor implements three operations:

  * ``dry_run(ctx)`` — describe what the action would do; surface
    any preconditions or required operator handoffs (e.g., pipx).
  * ``execute(ctx)`` — perform the action; return outcome + any
    rollback handle the wizard should hold for the operator's
    "Mark upgrade complete" decision.
  * ``rollback(ctx, prior_state)`` — reverse the action.

The dispatch surface mirrors :mod:`daemon.writes` — a name → handler
registry with a small set of well-typed exceptions.

D2.3 ships:

  * Framework + registry.
  * ``pipx_upgrade`` — operator-handoff (no daemon execute; copy-
    paste shell command; rollback handoff to ``pipx install
    --force forge-manager-mcp==<prior>``).
  * ``daemon_restart`` — graceful restart via SIGTERM-and-respawn
    handoff to the supervisor (or, when the supervisor isn't
    available, a copy-paste ``forge-manager-mcp daemon-restart``).
  * Stub executors for ``schema_migration`` / ``skill_prose_pull`` /
    ``config_patch`` / ``claude_md_merge`` / ``verify`` returning
    ``deferred`` outcomes — full impls land in 3.8.x as their
    underlying tools mature.

D2.4 wires ``POST /upgrade/execute/<step>`` against this registry.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cache
from typing import Any, Callable


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@cache
def _step_dry_run_class() -> type:
    @dataclass(frozen=True)
    class StepDryRun:
        """What an executor would do.

        ``operator_action`` is the copy-paste command (or other
        operator-side instruction) the wizard surfaces. Empty for
        steps the daemon can run autonomously.
        """

        repair_type: str
        description: str
        operator_action: str | None
        preconditions_ok: bool
        preconditions_message: str | None

    return StepDryRun


StepDryRun = _step_dry_run_class()


@cache
def _step_result_class() -> type:
    @dataclass(frozen=True)
    class StepResult:
        """Outcome of an execute / rollback call.

        ``status`` ∈ {"ok", "deferred", "failed", "operator_handoff"}.
        ``rollback_handle`` carries any state the wizard needs to
        undo the action; opaque to the framework.
        """

        repair_type: str
        status: str
        message: str
        operator_action: str | None
        rollback_handle: Any | None

    return StepResult


StepResult = _step_result_class()


# ---------------------------------------------------------------------------
# Errors + registry
# ---------------------------------------------------------------------------

class UnknownExecutorError(Exception):
    """Raised when a repair_type has no registered executor."""


class _Executor:
    """Three-method tuple for one repair_type."""

    __slots__ = ("repair_type", "dry_run_fn", "execute_fn", "rollback_fn")

    def __init__(
        self, repair_type: str,
        dry_run_fn: Callable, execute_fn: Callable,
        rollback_fn: Callable,
    ):
        self.repair_type = repair_type
        self.dry_run_fn = dry_run_fn
        self.execute_fn = execute_fn
        self.rollback_fn = rollback_fn


_REGISTRY: dict[str, _Executor] = {}


def register(
    repair_type: str, *,
    dry_run: Callable, execute: Callable, rollback: Callable,
) -> None:
    """Register an executor under ``repair_type``."""
    _REGISTRY[repair_type] = _Executor(
        repair_type, dry_run, execute, rollback,
    )


def get_executor(repair_type: str) -> _Executor:
    """Look up an executor or raise :class:`UnknownExecutorError`."""
    if repair_type not in _REGISTRY:
        raise UnknownExecutorError(repair_type)
    return _REGISTRY[repair_type]


def all_repair_types() -> list[str]:
    """Return all registered repair_types, sorted."""
    return sorted(_REGISTRY.keys())


def to_dry_run_dict(dry_run) -> dict:
    return {
        "repair_type": dry_run.repair_type,
        "description": dry_run.description,
        "operator_action": dry_run.operator_action,
        "preconditions_ok": dry_run.preconditions_ok,
        "preconditions_message": dry_run.preconditions_message,
    }


def to_result_dict(result) -> dict:
    return {
        "repair_type": result.repair_type,
        "status": result.status,
        "message": result.message,
        "operator_action": result.operator_action,
        "rollback_handle": result.rollback_handle,
    }


# ---------------------------------------------------------------------------
# pipx_upgrade — operator-handoff (no daemon execute)
# ---------------------------------------------------------------------------

def _pipx_dry_run(ctx: dict) -> "object":
    target = ctx.get("target_version")
    cmd = "pipx upgrade forge-manager-mcp"
    if target:
        cmd = f"pipx install --force forge-manager-mcp=={target}"
    return StepDryRun(
        repair_type="pipx_upgrade",
        description=(
            f"Upgrade the forge-manager-mcp wheel to "
            f"{target or 'latest'} via pipx."
        ),
        operator_action=cmd,
        preconditions_ok=True,
        preconditions_message=None,
    )


def _pipx_execute(ctx: dict) -> "object":
    """Pipx upgrade can't run from the daemon — the running daemon's
    binary would change underneath it (lifecycle race per
    Discussion #12 OQ3). Returns ``operator_handoff`` with the
    copy-paste command; the wizard waits for the operator to click
    "I've done this" before advancing.
    """
    target = ctx.get("target_version")
    cmd = "pipx upgrade forge-manager-mcp"
    if target:
        cmd = f"pipx install --force forge-manager-mcp=={target}"
    return StepResult(
        repair_type="pipx_upgrade",
        status="operator_handoff",
        message=(
            "Run the copy-paste command in your shell, then click "
            "Continue. The daemon can't pipx-upgrade itself."
        ),
        operator_action=cmd,
        rollback_handle={"prior_version": ctx.get("current_version")},
    )


def _pipx_rollback(ctx: dict, prior_state: Any) -> "object":
    prior = (prior_state or {}).get("prior_version", "the previous version")
    return StepResult(
        repair_type="pipx_upgrade",
        status="operator_handoff",
        message="Run the rollback command to restore the prior wheel.",
        operator_action=f"pipx install --force forge-manager-mcp=={prior}",
        rollback_handle=None,
    )


register(
    "pipx_upgrade",
    dry_run=_pipx_dry_run,
    execute=_pipx_execute,
    rollback=_pipx_rollback,
)


# ---------------------------------------------------------------------------
# daemon_restart — daemon-side action (handoff to supervisor)
# ---------------------------------------------------------------------------

def _restart_dry_run(ctx: dict) -> "object":
    return StepDryRun(
        repair_type="daemon_restart",
        description=(
            "Restart the forge-manager-mcp daemon to align its "
            "running version with the freshly-installed wheel."
        ),
        operator_action="forge-manager-mcp daemon-restart",
        preconditions_ok=True,
        preconditions_message=None,
    )


def _restart_execute(ctx: dict) -> "object":
    """Daemon restart is operator-handoff for the same reason as
    pipx — restarting from inside the daemon's request handler
    would deadlock (the response would never return). The wizard
    surfaces the command and waits for the operator's
    confirmation.

    A supervisor-driven restart (systemd, docker, etc.) is a
    natural extension when the daemon detects it's running under
    one; defer until operator UX surfaces the gap.
    """
    return StepResult(
        repair_type="daemon_restart",
        status="operator_handoff",
        message=(
            "Run `forge-manager-mcp daemon-restart` in your shell, "
            "then click Continue. The daemon can't gracefully "
            "restart itself from inside a request handler."
        ),
        operator_action="forge-manager-mcp daemon-restart",
        rollback_handle=None,
    )


def _restart_rollback(ctx: dict, prior_state: Any) -> "object":
    return StepResult(
        repair_type="daemon_restart",
        status="ok",
        message="Daemon restart is idempotent — no rollback needed.",
        operator_action=None,
        rollback_handle=None,
    )


register(
    "daemon_restart",
    dry_run=_restart_dry_run,
    execute=_restart_execute,
    rollback=_restart_rollback,
)


# ---------------------------------------------------------------------------
# Stub executors (D2.3 → 3.8.x flesh-out)
# ---------------------------------------------------------------------------

def _stub_dry_run(repair_type: str, description: str):
    def _impl(ctx: dict) -> "object":
        return StepDryRun(
            repair_type=repair_type,
            description=description,
            operator_action=None,
            preconditions_ok=False,
            preconditions_message=(
                f"{repair_type} executor lands in 3.8.x — "
                "skip this step manually for now."
            ),
        )
    return _impl


def _stub_execute(repair_type: str):
    def _impl(ctx: dict) -> "object":
        return StepResult(
            repair_type=repair_type,
            status="deferred",
            message=(
                f"{repair_type} execution lands in 3.8.x. "
                "Use the underlying tool directly for now."
            ),
            operator_action=None,
            rollback_handle=None,
        )
    return _impl


def _stub_rollback(repair_type: str):
    def _impl(ctx: dict, prior_state: Any) -> "object":
        return StepResult(
            repair_type=repair_type,
            status="deferred",
            message=f"{repair_type} rollback lands in 3.8.x.",
            operator_action=None,
            rollback_handle=None,
        )
    return _impl


for _rt, _desc in (
    ("schema_migration",
     "Run the canonical-schema migrator (e.g. migrate_to_4_0)."),
    ("skill_prose_pull",
     "Pull the latest skill prose into the project's "
     ".claude/skills/forge-manager/ directory."),
    ("config_patch",
     "Apply additive config patches to forge-config.json."),
    ("claude_md_merge",
     "Merge the current CLAUDE.md template against the project's "
     "CLAUDE.md, surfacing diffs for operator review."),
    ("verify",
     "Re-run detect + assert no remaining drift."),
):
    register(
        _rt,
        dry_run=_stub_dry_run(_rt, _desc),
        execute=_stub_execute(_rt),
        rollback=_stub_rollback(_rt),
    )
