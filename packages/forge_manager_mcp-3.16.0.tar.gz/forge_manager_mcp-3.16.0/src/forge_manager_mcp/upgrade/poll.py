"""Auto-poll loop for upgrade-wizard drift detection
(3.8.0 D2.6 / Discussion #12 / #373).

Runs ``detect.aggregate`` on a fixed cadence (6h default per
Discussion #12 OQ1 closure path b). When a poll surfaces
*newly-needed-repair* drifts that weren't present in the prior
poll, publishes an ``upgrade.drift_detected`` alert so the operator
sees a banner in the Daemon view's existing alert list (Discussion
#12 OQ6 closure path c — banner via the existing alert surface,
no new UI affordance needed).

Pure helpers (``should_alert``, ``make_drift_alert``) live alongside
the async ``poll_loop`` so the decision logic is testable without
spinning up an event loop.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


POLL_INTERVAL_SECONDS = 6 * 60 * 60  # 6 hours


def should_alert(prev_summary: dict | None, current_summary: dict) -> bool:
    """Return True when the current poll's needs_repair count
    exceeds the previous poll's. The first poll (``prev_summary
    is None``) emits an alert iff there's anything to repair so the
    operator gets the initial signal at daemon startup.
    """
    current = current_summary.get("needs_repair", 0)
    if prev_summary is None:
        return current > 0
    prev = prev_summary.get("needs_repair", 0)
    return current > prev


def make_drift_alert(summary: dict, drifts: list, when: datetime | None = None) -> dict:
    """Build the alert payload for the broadcaster + alert_log.

    Returns the dict shape ``alert_to_dict`` produces so the daemon's
    existing alert publishing path consumes it without adapter glue.
    """
    when = when or datetime.now(timezone.utc)
    needs_repair = summary.get("needs_repair", 0)
    behind_sources = [
        d.source for d in drifts if d.status == "behind"
    ]
    detail = (
        ", ".join(behind_sources) if behind_sources else None
    )
    return {
        "level": "warning",
        "message": (
            f"{needs_repair} upgrade{'s' if needs_repair != 1 else ''} "
            "available — open the Upgrade tab to repair drift."
        ),
        "detail": detail,
        "platform_id": None,
        "timestamp": when.isoformat(),
        "tags": ("upgrade", "drift_detected"),
    }


def resolved_sources(prev_drifts: list, current_drifts: list) -> list[str]:
    """(#455) Return source names that transitioned from ``behind``
    to anything-not-``behind`` (typically ``match``) between
    consecutive polls.

    Pure: comparison-only over the prev/current drift snapshots.
    Returns the list in the order sources appeared in ``prev_drifts``.
    Empty list when no transitions; the caller decides whether to
    publish based on that.
    """
    prev_behind = {d.source for d in prev_drifts if d.status == "behind"}
    current_behind = {d.source for d in current_drifts if d.status == "behind"}
    resolved = prev_behind - current_behind
    # Preserve prev-list order; stable surface across calls.
    return [d.source for d in prev_drifts if d.source in resolved]


def make_resolved_alert(
    sources: list[str], when: datetime | None = None,
) -> dict:
    """(#455) Build the inverse of ``make_drift_alert`` — published
    when a previously-``behind`` source transitions back to ``match``.

    Symmetric companion to ``upgrade.drift_detected`` (tags=("upgrade",
    "drift_detected"), level="warning"). This alert uses
    tags=("upgrade", "drift_resolved"), level="info" — resolution is
    good news, not a warning.

    Per the open AC question, alert-log query / acknowledgement of
    matching prior alerts is out of scope for this surface; a
    follow-up commit can either filter resolved-source alerts from
    the operator-facing list or write an ack record in the action log
    keyed on this event's tags.
    """
    when = when or datetime.now(timezone.utc)
    detail = ", ".join(sources) if sources else None
    return {
        "level": "info",
        "message": (
            f"Drift resolved for {len(sources)} source"
            f"{'s' if len(sources) != 1 else ''}: {detail or '(none)'}."
        ),
        "detail": detail,
        "platform_id": None,
        "timestamp": when.isoformat(),
        "tags": ("upgrade", "drift_resolved"),
    }


async def poll_loop(
    *,
    project_dir: Path | None,
    state_dir: Path | None,
    config_provider: Callable[[], "dict | None"],
    publisher: Callable[[dict], None],
    interval_seconds: float = POLL_INTERVAL_SECONDS,
    max_iterations: int | None = None,
) -> None:
    """Sleep-then-poll loop. Designed to run as an
    ``asyncio.create_task`` for the daemon's lifetime.

    ``config_provider`` is called per-iteration so config updates
    (D2 / Theme A's config write API) reflect on the next poll
    without restarting the daemon.

    ``publisher`` receives the alert dict — the daemon wraps the
    publish_alert call so the alert lands in both broadcaster and
    sqlite alert_log.

    ``max_iterations`` lets tests bound the loop deterministically;
    None runs forever.
    """
    from forge_manager_mcp.upgrade import detect

    prev_summary: dict | None = None
    prev_drifts: list = []  # (#455) track per-iteration drifts for resolved comparison
    iteration = 0
    while True:
        if max_iterations is not None and iteration >= max_iterations:
            return
        try:
            await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            return
        try:
            config_payload = config_provider()
            drifts = detect.aggregate(
                project_dir=project_dir,
                state_dir=state_dir,
                config_payload=config_payload,
            )
            summary = detect.summary(drifts)
            if should_alert(prev_summary, summary):
                try:
                    publisher(make_drift_alert(summary, drifts))
                except Exception:  # noqa: BLE001 — publisher is best-effort
                    pass
            # (#455) Symmetric publish — when any previously-behind
            # source has resolved, emit drift_resolved.
            resolved = resolved_sources(prev_drifts, drifts)
            if resolved:
                try:
                    publisher(make_resolved_alert(resolved))
                except Exception:  # noqa: BLE001 — best-effort
                    pass
            prev_summary = summary
            prev_drifts = drifts
        except Exception:  # noqa: BLE001 — poll loop must not die
            pass
        iteration += 1
