"""Multi-source drift aggregator (3.8.0 D2.1 / Discussion #12).

Each ``probe_*`` function returns a uniform :class:`Drift` envelope
for one source; :func:`aggregate` calls them all and returns the
punch-list the wizard renders.

Per Discussion #12 §What detection covers, eight sources:

  1. PyPI ``info.version`` — latest published wheel.
  2. Project repo HEAD ``**Version:**`` — required-by-project.
  3. User's installed wheel — running MCP version.
  4. Daemon's ``/health.version`` — running daemon process version.
  5. ``forge-config.json.schema_version`` — canonical schema.
  6. Skill prose drift via ``check_skill_version`` — local prose vs
     upstream.
  7. Project rules schema in ``.claude/project-rules.md``.
  8. CLAUDE.md template — template vs current contents.

Sources 1-3 reuse :mod:`forge_manager_mcp.version_coord`. Source 4
probes the daemon's discovery file. Source 5 reads the config payload.
Sources 6-8 are stubbed for D2.1 (return ``status="unknown"``); their
implementations land in 3.8.x as the underlying probes mature.

Each :class:`Drift` carries a ``repair_type`` enum value that the
wizard's state machine uses to dispatch to the correct executor:
``pipx_upgrade`` / ``daemon_restart`` / ``schema_migration`` /
``skill_prose_pull`` / ``config_patch`` / ``claude_md_merge`` /
``none``.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from functools import cache
from pathlib import Path

from forge_manager_mcp import version_coord


_DAEMON_PROBE_TIMEOUT = 1.0  # seconds


@cache
def _drift_class() -> type:
    @dataclass(frozen=True)
    class Drift:
        """One source's drift snapshot.

        ``status`` ∈ {match, behind, ahead, unknown}. ``severity``
        ∈ {info, warn, fail}. ``repair_type`` is the executor dispatch
        key — ``"none"`` when nothing to repair (status=match) or
        when the source isn't yet implemented (status=unknown).
        """

        source: str
        current: str | None
        target: str | None
        status: str
        severity: str
        repair_type: str
        message: str | None
        recommendation: str | None

    return Drift


Drift = _drift_class()


def _drift(
    *, source: str, current: str | None, target: str | None,
    status: str, severity: str = "info", repair_type: str = "none",
    message: str | None = None, recommendation: str | None = None,
) -> "object":
    return Drift(
        source=source, current=current, target=target,
        status=status, severity=severity, repair_type=repair_type,
        message=message, recommendation=recommendation,
    )


# ---------------------------------------------------------------------------
# Source 1+2+3: installed vs required vs PyPI latest (delegate to version_coord)
# ---------------------------------------------------------------------------

def probe_mcp_version(
    *, project_dir: Path | None, state_dir: Path | None,
) -> "object":
    """Combined drift for installed MCP / project required / PyPI latest.

    Wraps :func:`version_coord.compute_drift`; reformats into the
    Drift envelope the aggregator expects. ``repair_type`` maps to
    ``pipx_upgrade`` for behind status, ``none`` otherwise.
    """
    snap = version_coord.compute_drift(
        project_dir=project_dir, state_dir=state_dir,
    )
    repair = "pipx_upgrade" if snap.status == "behind" else "none"
    return _drift(
        source="mcp_version",
        current=snap.installed,
        target=snap.required or snap.pypi_latest,
        status=snap.status,
        severity=snap.severity,
        repair_type=repair,
        message=snap.message,
        recommendation=snap.recommendation,
    )


# ---------------------------------------------------------------------------
# Source 4: daemon's running version
# ---------------------------------------------------------------------------

def probe_daemon_version(state_dir: Path | None) -> "object":
    """Probe the local daemon's ``/health`` for its running version.

    Returns a Drift comparing the daemon's reported version against
    :data:`version_coord.MCP_VERSION` (the user's installed wheel).
    A mismatch indicates ``pipx upgrade`` happened but the daemon
    wasn't restarted — repair = ``daemon_restart``.

    Uses the discovery file at ``<state_dir>/daemon.json`` to find
    the URL + auth token. Health endpoint is unauthenticated, so we
    don't need to extract the token. Probe timeout is short (1s)
    because we're hitting localhost.
    """
    if state_dir is None:
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
        )
    discovery_path = state_dir / "daemon.json"
    if not discovery_path.is_file():
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
            message="No daemon discovery file — daemon isn't running.",
        )
    try:
        discovery = json.loads(discovery_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
            message="Daemon discovery file unreadable.",
        )
    port = discovery.get("port")
    if not port:
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
        )
    url = f"http://127.0.0.1:{port}/health"
    try:
        with urllib.request.urlopen(url, timeout=_DAEMON_PROBE_TIMEOUT) as resp:
            payload = json.load(resp)
    except (urllib.error.URLError, OSError, json.JSONDecodeError):
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
            message="Daemon /health unreachable — daemon may be down.",
        )
    daemon_v = payload.get("version")
    if not isinstance(daemon_v, str):
        return _drift(
            source="daemon_version",
            current=None, target=version_coord.MCP_VERSION,
            status="unknown",
        )
    if daemon_v == version_coord.MCP_VERSION:
        return _drift(
            source="daemon_version",
            current=daemon_v, target=version_coord.MCP_VERSION,
            status="match",
        )
    # Daemon version differs from MCP — this is the post-pipx-upgrade
    # case. Repair = restart the daemon to pick up the new wheel.
    return _drift(
        source="daemon_version",
        current=daemon_v, target=version_coord.MCP_VERSION,
        status="behind",
        severity="warn",
        repair_type="daemon_restart",
        message=(
            f"Daemon is running {daemon_v}; MCP wheel is "
            f"{version_coord.MCP_VERSION}. Restart the daemon to "
            "align."
        ),
        recommendation="forge-manager-mcp daemon-restart",
    )


# ---------------------------------------------------------------------------
# Source 5: forge-config.json schema_version
# ---------------------------------------------------------------------------

# Latest known schema. Bumped per release; the migrator detects
# transitions and wires its runner. Value lives here so the upgrade
# detector can reference it without importing the migrator chain.
LATEST_SCHEMA_VERSION = "4.0"


def probe_schema_version(config_payload: dict | None) -> "object":
    """Compare the project's declared schema_version to the latest
    known. Repair = ``schema_migration`` when behind.

    ``config_payload`` is the dict shape returned by
    :func:`config.load_config`'s ``model_dump()`` (or the daemon's
    cached payload). Returns ``status="unknown"`` when no payload is
    available (daemon started without --project-dir).
    """
    if config_payload is None:
        return _drift(
            source="schema_version",
            current=None, target=LATEST_SCHEMA_VERSION,
            status="unknown",
        )
    current = config_payload.get("schema_version") or "3.0"
    if current == LATEST_SCHEMA_VERSION:
        return _drift(
            source="schema_version",
            current=current, target=LATEST_SCHEMA_VERSION,
            status="match",
        )
    return _drift(
        source="schema_version",
        current=current, target=LATEST_SCHEMA_VERSION,
        status="behind",
        severity="warn",
        repair_type="schema_migration",
        message=(
            f"forge-config.json declares schema_version={current!r}; "
            f"latest is {LATEST_SCHEMA_VERSION}. Run the migrator to "
            "align canonical-store layout."
        ),
        recommendation=f"migrate_to_{LATEST_SCHEMA_VERSION.replace('.', '_')}",
    )


# ---------------------------------------------------------------------------
# Sources 6-8: skill prose / project rules / CLAUDE.md (stubbed for D2.1)
# ---------------------------------------------------------------------------

def probe_skill_prose(project_dir: Path | None) -> "object":
    """(D2.1 stub) Skill prose drift between local and upstream.

    The full implementation wraps :func:`check_skill_version`'s
    upstream-probe logic. D2.1 returns ``status="unknown"`` so the
    aggregator's punch-list shape is stable; the real probe lights
    up in D2.x once the wrapper lands.
    """
    return _drift(
        source="skill_prose",
        current=None, target=None,
        status="unknown",
        message="Skill-prose drift detection lands in D2.x.",
    )


def probe_project_rules(project_dir: Path | None) -> "object":
    """(D2.1 stub) project-rules schema drift."""
    return _drift(
        source="project_rules",
        current=None, target=None,
        status="unknown",
        message="Project-rules drift detection lands in D2.x.",
    )


def probe_claude_md(project_dir: Path | None) -> "object":
    """(D2.1 stub) CLAUDE.md template drift."""
    return _drift(
        source="claude_md",
        current=None, target=None,
        status="unknown",
        message="CLAUDE.md template drift detection lands in D2.x.",
    )


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

def aggregate(
    *, project_dir: Path | None, state_dir: Path | None,
    config_payload: dict | None,
) -> "list[object]":
    """Run every probe and return the punch-list in display order.

    Order matters for the wizard's state machine: pipx_upgrade →
    daemon_restart → schema_migration → skill_prose_pull →
    config_patch → claude_md_merge. The aggregator preserves this
    order; the executor enforces it (D2.4).
    """
    return [
        probe_mcp_version(project_dir=project_dir, state_dir=state_dir),
        probe_daemon_version(state_dir),
        probe_schema_version(config_payload),
        probe_skill_prose(project_dir),
        probe_project_rules(project_dir),
        probe_claude_md(project_dir),
    ]


def to_dict(drift) -> dict:
    """JSON-serializable view of a Drift entry."""
    return {
        "source": drift.source,
        "current": drift.current,
        "target": drift.target,
        "status": drift.status,
        "severity": drift.severity,
        "repair_type": drift.repair_type,
        "message": drift.message,
        "recommendation": drift.recommendation,
    }


def summary(drifts: "list[object]") -> dict:
    """Roll-up across drifts: counts by status + by severity."""
    by_status: dict[str, int] = {}
    by_severity: dict[str, int] = {}
    needs_repair = 0
    for d in drifts:
        by_status[d.status] = by_status.get(d.status, 0) + 1
        by_severity[d.severity] = by_severity.get(d.severity, 0) + 1
        if d.status == "behind":
            needs_repair += 1
    return {
        "by_status": by_status,
        "by_severity": by_severity,
        "needs_repair": needs_repair,
    }
