"""Upgrade-wizard data layer (3.8.0 D2 / Discussion #12 / #373).

Detection helpers + per-step executors for the daemon-driven upgrade
wizard. The `detect` module aggregates drift across every surface a
project owner needs to keep aligned across release boundaries
(installed wheel, project required version, PyPI latest, daemon
running version, schema version, skill prose, project rules, CLAUDE.md
template).

D2.1 + D2.2 (this commit) ship the detection foundation + ``GET
/upgrade/status`` daemon endpoint. D2.3 + D2.4 add per-step executors
+ ``POST /upgrade/execute/<step>``. D2.5 + D2.6 wire the wizard UI +
auto-poll banner.
"""
