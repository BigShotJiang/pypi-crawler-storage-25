"""async_parity_advisory evaluator (Phase D3b.4q / #344, Rule 1).

Heuristic advisory for Rule 1 (Async parity). Detects async
functions without sync siblings (or vice versa) when the project's
call graph mixes both. Emits ``info`` severity by default.

**Stub implementation in 3.5.0.** Per #344's scope, this evaluator
is registered and invoked but emits no findings. Cross-module call
graph analysis is non-trivial and would risk false positives at
this iteration. The full heuristic ships in 3.5.x as a follow-up.

The registration here ensures:
  * The rule is discoverable via ``check_code_design(rules=[...])``
  * Project rules can ``Extends`` it to tighten severity
  * The handler's ``findings_by_tier`` summary includes it
  * The dogfood gate's regression baseline reflects the empty
    state today; a 3.5.x impl that fires findings will require
    operator-acknowledged baseline updates
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import Severity
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "async_parity_advisory"
RULE_ANCHOR = "code-design.md#rule-async-first-parity"


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """3.5.0 stub — returns empty findings. Full heuristic in 3.5.x."""
    return []


register_evaluator(RULE_NAME, evaluate)
