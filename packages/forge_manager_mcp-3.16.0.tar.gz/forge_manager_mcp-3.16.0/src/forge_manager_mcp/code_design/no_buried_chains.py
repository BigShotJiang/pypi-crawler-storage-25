"""no_buried_chains evaluator (Rule 11 / #433 / 3.12.0).

Flags functions whose inner work is buried under deeply-nested
constructs (with / async-with / try-except / nested-function) that
test code can't drive without mocking the entire wrapping chain.

The #428 drain found multiple cases where the only path to a piece
of logic required mocking 4+ context managers. Extraction creates
a test seam without changing the production call flow.

Heuristic: count the maximum nesting depth of (With / AsyncWith /
Try / nested FunctionDef) inside each top-level FunctionDef. Flag
when depth exceeds a threshold (default 3).

Exemptions: tests/ directory denylisted per project convention.

Pure AST analysis — no IO outside the walker entry point.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "no_buried_chains"
RULE_ANCHOR = "code-design.md#rule-no-buried-chains"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})

# Node types that count toward nesting depth — each represents a
# layer test code would need to drive around to reach the inner work.
#
# (#471 FP sweep) Nested FunctionDef / AsyncFunctionDef removed from
# the depth count: the rule prose explicitly says nested functions
# ARE the extraction mechanism (`extracted into named functions that
# tests can drive directly`), not a target of the rule. Counting
# them produced FPs on framework decorator patterns like
# `@server.call_tool()` where the nested def is the registered
# callback — the with/try inside the callback is the legitimate
# IO chain, but the callback def itself doesn't add a test-
# reachability barrier (tests reach the callback by registering
# their own variant against the same decorator).
_NESTING_NODE_TYPES: tuple[type[ast.AST], ...] = (
    ast.With,
    ast.AsyncWith,
    ast.Try,
)


_DEFAULT_DEPTH_THRESHOLD = 3
"""Max nesting depth before a finding fires. Set to match the #428
drain's observed shape (4+ context managers = test-reachability
problem)."""


def _max_nesting_depth(
    node: ast.AST,
    current_depth: int = 0,
) -> int:
    """Return the maximum nesting depth among children of ``node``,
    counting only the construct types in _NESTING_NODE_TYPES.

    The function body itself doesn't count as a level — only nested
    constructs INSIDE the body do.
    """
    max_depth = current_depth
    for child in ast.iter_child_nodes(node):
        if isinstance(child, _NESTING_NODE_TYPES):
            child_depth = _max_nesting_depth(child, current_depth + 1)
            if child_depth > max_depth:
                max_depth = child_depth
        else:
            child_depth = _max_nesting_depth(child, current_depth)
            if child_depth > max_depth:
                max_depth = child_depth
    return max_depth


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
    depth_threshold: int = _DEFAULT_DEPTH_THRESHOLD,
) -> list:
    """Pure analyzer — find top-level functions whose body has
    nesting depth exceeding the threshold."""
    findings: list = []
    # Iterate top-level functions (and classes' methods) but skip
    # nested function defs to avoid double-flagging.
    seen_nested: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if id(node) in seen_nested:
            continue
        # Mark any nested function defs within so they don't fire
        # their own finding.
        for sub in ast.walk(node):
            if (
                sub is not node
                and isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef))
            ):
                seen_nested.add(id(sub))

        depth = _max_nesting_depth(node)
        if depth <= depth_threshold:
            continue
        findings.append(make_finding(
            rule=RULE_NAME,
            severity=severity,
            location=make_location(
                path=str(file_path),
                line=node.lineno,
                symbol=node.name,
            ),
            message=(
                f"function {node.name!r} has nesting depth {depth} "
                f"of (with/async-with/try/nested-function) — exceeds "
                f"threshold {depth_threshold}. Inner work likely needs "
                f"extraction into a named function to be test-"
                f"addressable per Rule 11."
            ),
            rule_anchor=RULE_ANCHOR,
            suggestion=(
                "Extract the inner work into a named helper function. "
                "Tests call the helper directly; the outer chain stays "
                "in production but is no longer the only path to the "
                "logic."
            ),
        ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Effect — file walk + parse."""
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
