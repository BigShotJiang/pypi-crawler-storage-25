"""no_partial_dependency_protection evaluator (Rule 12 / #433 / 3.12.0).

Flags functions that import the SAME module in both a protected
(`try: import X; except: ...`) AND unprotected (bare `import X` /
direct `X.foo()` reference) shape. The mixed pattern produces dead-
code branches: the protected fallback can't be tested because the
unprotected use earlier in the same call path would have already
crashed.

Surfaced in the #428 drain on session.py — the protected ImportError
fallback at L290-299 was unreachable because L319-321 imported the
same module unprotected; reaching the fallback required patching
sys.modules to crash the L319-321 site, but the patch would have
crashed the function before reaching the fallback.

Pure AST analysis — no IO outside the walker entry point.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "no_partial_dependency_protection"
RULE_ANCHOR = "code-design.md#rule-no-partial-dep-protection"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})


def _collect_imports_in_function(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> tuple[dict[str, int], dict[str, int]]:
    """Return (protected_modules, unprotected_modules) used in this
    function body, each as ``{module_name: earliest_line_number}``.

    A module is "protected" when its `import X` / `from X import ...`
    statement is inside a `try` block whose handlers explicitly catch
    ImportError (or ModuleNotFoundError). Bare ``except:`` and broad
    ``except Exception:`` are NOT treated as protection (#471 FP
    sweep): those are general error handling, not optional-import
    semantics.

    A module is "unprotected" when its import statement is NOT inside
    such a try block.

    Tracking the earliest line lets the analyzer apply the
    "unprotected-before-protected" flow rule — see ``analyze_module``.
    """
    protected: dict[str, int] = {}
    unprotected: dict[str, int] = {}

    def _record(target: dict[str, int], module: str, line: int) -> None:
        existing = target.get(module)
        if existing is None or line < existing:
            target[module] = line

    # Walk the function body. Track current "protected-import" context.
    # `ast.walk` is iterative; we need recursive descent to know whether
    # we're inside a try block that catches ImportError.
    def walk(n: ast.AST, in_protected_try: bool) -> None:
        # (#471 FP sweep) Do NOT descend into nested function / lambda /
        # nested-class bodies. Imports inside a nested function belong
        # to that function's analysis scope, not the enclosing one;
        # mixing nested-function imports with the outer function's
        # imports produced FPs where a protected nested-route handler
        # was treated as protection for the outer factory's
        # construction-time imports (request-time path vs
        # construction-time path are independent).
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)):
            return

        # If this is a Try with an ImportError-catching handler, the
        # body of the Try gets in_protected_try=True; the handlers
        # are unprotected (the catch path).
        if isinstance(n, ast.Try):
            catches_import = _try_catches_import_error(n)
            for body_node in n.body:
                walk(body_node, in_protected_try or catches_import)
            for handler in n.handlers:
                for body_node in handler.body:
                    walk(body_node, in_protected_try)
            for else_node in n.orelse:
                walk(else_node, in_protected_try)
            for final_node in n.finalbody:
                walk(final_node, in_protected_try)
            return

        # Import / ImportFrom — extract module name; classify by
        # current context.
        if isinstance(n, ast.Import):
            for alias in n.names:
                module = alias.name.split(".")[0]
                _record(
                    protected if in_protected_try else unprotected,
                    module,
                    n.lineno,
                )
        elif isinstance(n, ast.ImportFrom):
            if n.module:
                module = n.module.split(".")[0]
                _record(
                    protected if in_protected_try else unprotected,
                    module,
                    n.lineno,
                )

        # Recurse into child nodes.
        for child in ast.iter_child_nodes(n):
            walk(child, in_protected_try)

    for body_node in node.body:
        walk(body_node, in_protected_try=False)
    return protected, unprotected


def _try_catches_import_error(try_node: ast.Try) -> bool:
    """Return True iff the try block has at least one handler that
    *explicitly* catches ImportError or ModuleNotFoundError.

    (#471 FP sweep) Pre-fix this returned True for bare except or
    broad ``except Exception`` handlers too — Rule 12's intent is
    specifically "optional-import protection", not general error
    catching. Functions that wrap large blocks in
    ``except Exception:`` for orthogonal runtime-error handling
    (e.g. the MCP-server ``call_tool`` dispatch wrapper) are not
    making protected-import claims; treating them as such conflated
    runtime-error handling with optional-import semantics and
    produced FPs on every function with a broad try/except whose
    body happened to also contain lazy imports.
    """
    for handler in try_node.handlers:
        exc_type = handler.type
        if exc_type is None:
            continue  # bare except — not an explicit import-protection signal
        if isinstance(exc_type, ast.Name):
            if exc_type.id in {"ImportError", "ModuleNotFoundError"}:
                return True
        elif isinstance(exc_type, ast.Tuple):
            for elt in exc_type.elts:
                if isinstance(elt, ast.Name) and elt.id in {
                    "ImportError", "ModuleNotFoundError",
                }:
                    return True
    return False


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
) -> list:
    """Pure analyzer — find functions whose imports mix protected and
    unprotected access to the same module.

    Returns one finding per (function, conflicting-module) pair.
    """
    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        protected, unprotected = _collect_imports_in_function(node)
        # (#471 FP sweep) Only flag when an unprotected use comes
        # LEXICALLY BEFORE the protected use. Order matters for
        # reachability: if the unprotected import fails first, the
        # protected branch never executes (the function crashes
        # before reaching the try). When protected is first and
        # unprotected is later, the protected branch IS reachable
        # — and the unprotected use only runs if the protected
        # branch returned successfully. That's the
        # ``write_config`` (#374) shape and the
        # ``test_returns_503_when_validator_unavailable`` shape;
        # both are reachable, both are tested, and both must not
        # be flagged.
        conflicts = sorted(
            m for m in (protected.keys() & unprotected.keys())
            if unprotected[m] < protected[m]
        )
        for module in conflicts:
            findings.append(make_finding(
                rule=RULE_NAME,
                severity=severity,
                location=make_location(
                    path=str(file_path),
                    line=node.lineno,
                    symbol=node.name,
                ),
                message=(
                    f"function {node.name!r} imports {module!r} both "
                    f"in a try/except (protected) and outside one "
                    f"(unprotected). The protected fallback is "
                    f"unreachable — the unprotected use crashes the "
                    f"function before the fallback executes."
                ),
                rule_anchor=RULE_ANCHOR,
                suggestion=(
                    "Choose one protection style and apply it "
                    "consistently across the function. Either "
                    "guard every use of the module with try/except, "
                    "OR remove the try/except and let an absent "
                    "import propagate as ImportError."
                ),
            ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Matches the registered signature
    (project_root, scan_paths, severity).

    Effect — file walk + parse. Pure analyzer split per Rule 2.
    """
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
