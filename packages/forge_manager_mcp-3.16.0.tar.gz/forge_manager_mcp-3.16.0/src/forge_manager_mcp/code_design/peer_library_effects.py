"""peer_library_effects evaluator (Rule 13 / #433 / 3.12.0).

Flags Python files in effect-implementation directories that share a
Bazel `py_library` with multiple other source files. The §Effects /
§Utility-isolation pattern wants each effect to be its own
build-system unit so the registry can enumerate them and tests can
substitute the entire registry per scenario.

Heuristic: an effect file is "peer-library-shaped" when there's a
py_library whose srcs contains ONLY that file (1 src). Files sharing
a multi-source py_library are flagged.

Exemptions:
- Files in `__init__.py` shape (they ARE the package aggregator;
  bundling helpers is fine)
- The `_types.py` / `errors.py` / `protocol.py` shapes (canonical
  shared-shape modules)

Effect directories: per existing factory_inventory.py convention —
flows/, adapters/, replication/, migration/, plus interceptors.py
(file-level).

Pure analysis — file walk + BUILD parse — no IO outside the walker.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.build_parser import parse_file
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "peer_library_effects"
RULE_ANCHOR = "code-design.md#rule-peer-library-effects"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})

# Effect-implementation directories — files here are the rule's
# scope. Mirrors factory_inventory.py's effect-directory set.
_EFFECT_DIR_SEGMENTS = frozenset({
    "flows", "adapters", "replication", "migration",
})

# File-level effect modules — checked by stem match against any
# directory.
_EFFECT_FILE_STEMS = frozenset({
    "interceptors",
})

# File stems exempt from the rule even when in an effect directory:
# package aggregators + canonical shared-shape modules.
_EXEMPT_STEMS = frozenset({
    "__init__", "_types", "types", "errors", "protocol",
    "manager",  # ReplicationManager is the dispatcher, not an effect
    "registry",  # adapters/registry.py is the dispatcher
})


# (#471 FP sweep) Library-name prefixes that mark the library as a
# multi-step flow aggregator — by construction every src is a step
# of the same flow and the library IS the runtime composition unit
# (Rule 13's "registry substituted per scenario" applies AT this
# library, not at individual step files). A `flow_release` library
# whose srcs are `flows/release/*.py` is one such aggregator; tests
# substitute the entire flow_release library when stubbing the
# release flow, never an individual step file.
_AGGREGATOR_LIBRARY_PREFIXES: tuple[str, ...] = (
    "flow_",
)


def _is_effect_file(file_path: Path) -> bool:
    """Return True if the file is an effect-implementation candidate
    (in an effect directory or named like one of the effect-file stems)."""
    if file_path.stem in _EXEMPT_STEMS:
        return False
    for part in file_path.parts:
        if part in _EFFECT_DIR_SEGMENTS:
            return True
    if file_path.stem in _EFFECT_FILE_STEMS:
        return True
    return False


def _find_build_file(file_path: Path, project_root: Path) -> Path | None:
    """Return the BUILD or BUILD.bazel file governing this source
    file. Walks up from the file's directory toward project_root."""
    current = file_path.parent
    while True:
        for candidate_name in ("BUILD", "BUILD.bazel"):
            candidate = current / candidate_name
            if candidate.is_file():
                return candidate
        # Stop at project_root or filesystem root.
        if current == project_root or current.parent == current:
            return None
        current = current.parent


def _src_matches_file(src: str, file_path: Path, build_file: Path) -> bool:
    """Return True if a BUILD `srcs` entry matches the given file path.

    BUILD srcs are paths relative to the BUILD's directory. e.g.
    ``srcs = ["adapters/github.py"]`` from
    ``forge_manager_mcp/BUILD`` matches
    ``forge_manager_mcp/adapters/github.py``.
    """
    build_dir = build_file.parent
    try:
        rel = file_path.relative_to(build_dir)
    except ValueError:
        return False
    return src == str(rel)


def _libraries_containing(
    file_path: Path, build_file: Path,
) -> list:
    """Return the BuildTargets that include this file in their srcs."""
    try:
        targets = parse_file(build_file)
    except (OSError, SyntaxError):
        return []
    return [
        t for t in targets
        if t.rule.startswith("py_library")
        and any(_src_matches_file(src, file_path, build_file) for src in t.srcs)
    ]


def analyze_file(
    *,
    file_path: Path,
    project_root: Path,
    severity: Severity,
) -> list:
    """Pure analyzer (over IO inputs) — find effect files that share
    a multi-source py_library with other files."""
    findings: list = []
    if not _is_effect_file(file_path):
        return findings
    build_file = _find_build_file(file_path, project_root)
    if build_file is None:
        return findings
    libs = _libraries_containing(file_path, build_file)
    if not libs:
        # Effect file with no governing py_library — different rule
        # would catch it; this rule stays silent.
        return findings
    for lib in libs:
        if len(lib.srcs) > 1:
            # (#471 FP sweep) Skip flow-aggregator libraries — by
            # construction these gather every step of one flow into
            # one runtime composition unit. Tests substitute the
            # entire flow library per scenario, not individual
            # step files; Rule 13's "registry substituted as a unit"
            # is satisfied AT the aggregator boundary.
            if lib.name and any(
                lib.name.startswith(p) for p in _AGGREGATOR_LIBRARY_PREFIXES
            ):
                continue
            findings.append(make_finding(
                rule=RULE_NAME,
                severity=severity,
                location=make_location(
                    path=str(file_path),
                    line=lib.line,
                    symbol=lib.name or "",
                ),
                message=(
                    f"effect file {file_path.name!r} shares "
                    f"py_library {lib.name!r} with {len(lib.srcs) - 1} "
                    f"other src(s). Per Rule 13 each effect is its "
                    f"own build-system unit so the registry can "
                    f"enumerate them and tests substitute the whole "
                    f"surface per scenario."
                ),
                rule_anchor=RULE_ANCHOR,
                suggestion=(
                    "Split the py_library so each effect file gets "
                    "its own target. The aggregator (e.g. the "
                    "package's `:package_name` lib) depends on each "
                    "peer library — runtime behavior unchanged."
                ),
            ))
            break  # one finding per file is sufficient
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Effect — file walk + BUILD parse."""
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        findings.extend(analyze_file(
            file_path=file_path,
            project_root=project_root,
            severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
