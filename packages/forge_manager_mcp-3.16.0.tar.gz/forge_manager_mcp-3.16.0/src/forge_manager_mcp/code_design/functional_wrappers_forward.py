"""functional_wrappers_forward evaluator (Rule 14 / #433 / 3.12.0).

Flags direct class-API method calls in business-logic code. The
rule's intent: new or modified functions should call flat-function
wrappers around class-centric APIs (Pydantic models, ORM sessions,
framework controllers, parser classes) rather than chaining the
class methods directly. Pre-existing class-direct sites are
grandfathered.

The "forward-going only" semantics are honored via the
``scan_paths`` parameter: when callers (CI / handler) pass a list
of changed-file paths, only those are scanned. Project-wide scans
will produce noisy findings against grandfathered code; callers
who want enforcement supply the recent-diff file set.

Initial detection targets the most-common class-API call patterns:

- Pydantic v2: ``.model_dump()`` / ``.model_dump_json()`` /
  ``.model_validate()`` / ``.model_validate_json()`` /
  ``.model_construct()``
- Pydantic v1 legacy: ``.parse_obj()`` / ``.parse_raw()`` /
  ``.dict()`` / ``.json()`` (when not on `Path` / `dict`)

This list is intentionally narrow at landing — broader detection
(ORM .query / .filter_by chains; framework controller methods)
needs project-specific context that the operator supplies via
project-rules.md extensions.

Exemptions:
- Effect-implementation directories (adapters/, flows/, etc.) per
  Rule 10's pattern. Effect implementations naturally chain class
  APIs for backend integration.
- tests/ directory.
- Module-level dict() builtin calls (not flagged — only `.dict()`
  on instance values).

Pure AST analysis — no IO outside the walker entry point.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "functional_wrappers_forward"
RULE_ANCHOR = "code-design.md#rule-functional-wrappers-forward"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})

# Effect-implementation directories — same exemption as Rule 10.
_EFFECT_IMPL_DIR_SEGMENTS = frozenset({
    "adapters", "flows", "replication", "migration",
    "github", "daemon", "site_renderer", "github_mocks",
})

# Method names that signal a direct Pydantic class-API call. When
# any of these appears as an Attribute call's .attr, and the called-
# on value is an instance (not a class-name reference itself), flag.
_CLASS_API_METHOD_NAMES: frozenset[str] = frozenset({
    "model_dump",
    "model_dump_json",
    "model_validate",
    "model_validate_json",
    "model_construct",
    "parse_obj",
    "parse_raw",
})


def _is_class_api_call(node: ast.Call) -> bool:
    """Return True if the call matches a known direct class-API
    method pattern."""
    func = node.func
    if not isinstance(func, ast.Attribute):
        return False
    return func.attr in _CLASS_API_METHOD_NAMES


def _is_exempt_path(file_path: Path) -> bool:
    """Skip files in effect-implementation directories."""
    for part in file_path.parts:
        if part in _EFFECT_IMPL_DIR_SEGMENTS:
            return True
    return False


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
) -> list:
    """Pure analyzer — find direct class-API method calls in
    function bodies."""
    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for sub in ast.walk(node):
            if isinstance(sub, ast.Call) and _is_class_api_call(sub):
                method_name = sub.func.attr if isinstance(sub.func, ast.Attribute) else ""
                findings.append(make_finding(
                    rule=RULE_NAME,
                    severity=severity,
                    location=make_location(
                        path=str(file_path),
                        line=getattr(sub, "lineno", node.lineno),
                        symbol=node.name,
                    ),
                    message=(
                        f"function {node.name!r} calls "
                        f"{method_name!r} directly on a class-API "
                        f"instance. Per Rule 14, new/modified "
                        f"functions wrap class-centric APIs behind "
                        f"flat-function helpers."
                    ),
                    rule_anchor=RULE_ANCHOR,
                    suggestion=(
                        f"Extract the {method_name!r} call into a "
                        "module-level helper function that takes the "
                        "instance as a parameter. Tests then call "
                        "the helper directly without setting up the "
                        "full class context. 'Wrap, don't refactor' — "
                        "existing call sites stay unchanged."
                    ),
                ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Forward-going semantics — see
    ``code-design.md#rule-functional-wrappers-forward``.

    (#471 FP sweep) Rule 14 explicitly says "Pre-existing
    class-direct call sites are grandfathered. Touching a function
    for an unrelated reason doesn't trigger the wrap requirement";
    the evaluator cannot tell new-vs-grandfathered code without
    diff context.

    Resolution: when ``scan_paths`` is None (project-wide scan, the
    open_session / cut-gate path), this evaluator returns no
    findings. When ``scan_paths`` is a list (the daemon-watch
    changed-files path, or a CI diff-scoped invocation), the listed
    files are scanned — only those are "new or modified" by
    construction of the scope. The watch.py invocation in 3.13.0
    passes the daemon's changed-file set per-iteration; that's the
    designed entry point for this rule.

    File-level diff-scoping is the floor; per-function diff-scoping
    would still over-flag grandfathered functions in a file that
    happened to be touched for an unrelated reason. The
    file-granularity tradeoff matches the rule prose: "touching a
    function for an unrelated reason doesn't trigger" applies to
    untouched files; once a file is in the diff the operator
    inspects its findings and decides per-call-site.
    """
    if scan_paths is None:
        return []

    targets: list[Path] = [Path(p) for p in scan_paths]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            if not _is_exempt_path(full):
                files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            if _is_exempt_path(entry):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
