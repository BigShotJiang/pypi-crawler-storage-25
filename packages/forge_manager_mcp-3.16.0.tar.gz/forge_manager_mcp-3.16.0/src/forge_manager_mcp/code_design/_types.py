"""Shared types for code-design evaluators (Phase D2 / #330 / #308).

Conforms to Rule 5 (`code_design.schema_as_functions`): the
``Finding`` schema is constructed inside ``make_finding``, not as a
top-level dataclass. The class definition lives inside a cached
helper function (``_finding_class``); AST scan over module-level
nodes sees only function definitions, not the schema class.

Conforms to Rule 4 (`code_design.utility_dir_isolation`): this
module is factor-of-three-or-more imported (every evaluator + the
registry + the handler), so it lives in a dedicated directory with
its own library target.

Pure module — no IO, no async. Test target ``test_finding`` is the
§schema-tests gate target for the ``make_finding`` factory and
carries the `pure` + `schema` tags per Rules 6 / 7.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cache
from typing import Literal


Severity = Literal["fail", "warn", "info"]
"""Effective severity for a finding. Computed by the gate registry's
four-layer chain (#287); the evaluator returns the chain's output
unchanged.
"""


@cache
def _location_class() -> type:
    """Return the cached Location dataclass. Defined inside the
    function so AST scan over module-level nodes does not see a
    top-level dataclass — conforms to Rule 5.
    """
    @dataclass(frozen=True)
    class Location:
        path: str
        line: int | None = None
        symbol: str | None = None
    return Location


@cache
def _finding_class() -> type:
    """Return the cached Finding dataclass. Same locality as
    ``_location_class``: definition inside a function, cached via
    ``functools.cache``.
    """
    @dataclass(frozen=True)
    class Finding:
        rule: str
        severity: Severity
        location: object
        message: str
        rule_anchor: str
        suggestion: str | None = None
    return Finding


def make_location(*, path: str, line: int | None = None,
                  symbol: str | None = None):
    """Factory returning a fresh Location value.

    `path` is project-relative, forward-slash, normalized — findings
    render identically across operating systems regardless of where
    the evaluator ran.
    """
    Location = _location_class()
    return Location(path=path, line=line, symbol=symbol)


def make_finding(
    *,
    rule: str,
    severity: Severity,
    location,
    message: str,
    rule_anchor: str,
    suggestion: str | None = None,
):
    """Factory returning a fresh Finding value.

    Per Schema-as-data (code-design.md §Schema-as-data): every
    Finding is constructed via this factory; the underlying class
    is cached one-time. Evaluators call this; consumers iterate
    over the returned list.

    Fields per #330 sub-RFC:

    | Field         | Required | Notes                                       |
    |---------------|----------|---------------------------------------------|
    | rule          | yes      | Rule name minus ``code_design.`` prefix      |
    | severity      | yes      | Effective severity from the gate chain      |
    | location      | yes      | Location value from ``make_location``       |
    | message       | yes      | Single-sentence violation statement         |
    | rule_anchor   | yes      | Topic-file fragment URL                     |
    | suggestion    | optional | Forward-looking remediation hint            |
    """
    Finding = _finding_class()
    return Finding(
        rule=rule,
        severity=severity,
        location=location,
        message=message,
        rule_anchor=rule_anchor,
        suggestion=suggestion,
    )


def finding_to_dict(finding) -> dict:
    """Serialize a Finding to a plain dict for the MCP response.

    Output shape matches the #330 sub-RFC's response schema:
    ``{rule, severity, location: {path, line, symbol}, message,
       rule_anchor, suggestion?}``. ``suggestion`` is omitted when
    None (matches the "optional" contract).
    """
    out = {
        "rule": finding.rule,
        "severity": finding.severity,
        "location": {
            "path": finding.location.path,
            "line": finding.location.line,
            "symbol": finding.location.symbol,
        },
        "message": finding.message,
        "rule_anchor": finding.rule_anchor,
    }
    if finding.suggestion is not None:
        out["suggestion"] = finding.suggestion
    return out
