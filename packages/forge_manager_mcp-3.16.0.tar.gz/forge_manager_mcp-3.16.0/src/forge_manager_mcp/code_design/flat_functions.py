"""flat_functions evaluator (Rule 9 / #433 / 3.12.0).

Flags class definitions that could be flattened to module-level
functions — i.e. classes whose methods don't actually use instance
state. Class APIs hide call dispatch behind attribute resolution
chains; flat functions present unambiguous test seams. The #428
drain found buried-in-class call chains were the dominant blocker
to test reachability.

Forward-going only — pre-existing class-shaped code is grandfathered.
The rule fires as advisory (warn) so operators can review case-by-
case rather than enforce blanket refactors.

Exemptions (these classes are valid even when "stateless"):
- Pydantic BaseModel subclasses (declarative schema; state IS the data)
- @dataclass decorated classes (same rationale)
- ABC / Protocol subclasses (interface declarations)
- Enum subclasses (enumeration members)
- Exception subclasses (Python's class-based exception model)
- Classes whose only methods are @staticmethod / @classmethod (those
  are already module-function-equivalent via the decorator)

A class triggers a finding when:
- It has at least one regular instance method (not static / class)
- AND no method accesses self.<attr> (or cls.<attr> on classmethods)
- AND its bases don't appear in the exemption list

Pure AST analysis — no IO outside the walker entry point.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "flat_functions"
RULE_ANCHOR = "code-design.md#rule-flat-functions"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})

# Base-class names that exempt a class from the rule. Match against
# the unqualified name (last segment of a dotted reference) — covers
# `BaseModel`, `pydantic.BaseModel`, `m.BaseModel` etc.
_EXEMPT_BASE_NAMES: frozenset[str] = frozenset({
    "BaseModel",       # Pydantic
    "Protocol",        # typing.Protocol
    "ABC",             # abc.ABC
    "ABCMeta",         # abc.ABCMeta
    "Enum",            # enum.Enum
    "IntEnum",
    "StrEnum",
    "Flag",
    "IntFlag",
    "NamedTuple",      # typing.NamedTuple
    "TypedDict",       # typing.TypedDict
    "Exception",
    "RuntimeError",
    "ValueError",
    "TypeError",
    "KeyError",
    "AttributeError",
    "IOError",
    "OSError",
    "LookupError",
    "Generic",         # typing.Generic
})


# Decorator names that mark a class as "schema-declarative" — same
# exemption as inheriting BaseModel.
_EXEMPT_DECORATORS: frozenset[str] = frozenset({
    "dataclass",
    "attrs_dataclass",
    "frozen",
})


def _base_name(base_node: ast.expr) -> str:
    """Extract the unqualified base-class name from a ClassDef base
    expression. Returns the last segment of a dotted reference; "" on
    unrecognized shapes."""
    if isinstance(base_node, ast.Name):
        return base_node.id
    if isinstance(base_node, ast.Attribute):
        return base_node.attr
    if isinstance(base_node, ast.Subscript):
        # Generic[T] / Protocol[T] etc. — recurse on the value.
        return _base_name(base_node.value)
    return ""


def _decorator_name(dec: ast.expr) -> str:
    """Extract the decorator's name from a Class/Function decorator
    expression."""
    if isinstance(dec, ast.Name):
        return dec.id
    if isinstance(dec, ast.Attribute):
        return dec.attr
    if isinstance(dec, ast.Call):
        return _decorator_name(dec.func)
    return ""


def _is_exempt_class(node: ast.ClassDef) -> bool:
    """Return True if the class is exempt from the rule per the
    declarative-class / interface / enumeration exemption list."""
    for base in node.bases:
        if _base_name(base) in _EXEMPT_BASE_NAMES:
            return True
    for dec in node.decorator_list:
        if _decorator_name(dec) in _EXEMPT_DECORATORS:
            return True
    # (#471 FP sweep) Custom exception subclasses follow Python's
    # `*Error` / `*Exception` naming convention. The base-name list
    # only catches direct `Exception` inheritance — projects with a
    # custom error hierarchy (`class ConsentRequiredError(ForgeError)`)
    # need the name-suffix heuristic to avoid FPs. Conservative: only
    # the *concrete* `Error` / `Exception` suffixes, not derived names.
    if node.name.endswith(("Error", "Exception")):
        return True
    return False


def _is_instance_method(method: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True for regular instance methods (not @staticmethod /
    @classmethod / @property).

    Properties count as instance methods for this rule — they're
    state accessors and almost always require self."""
    for dec in method.decorator_list:
        name = _decorator_name(dec)
        if name in {"staticmethod", "classmethod"}:
            return False
    # First positional arg must exist and be `self` (or any name —
    # we don't strictly enforce naming, just presence).
    args = method.args.args
    if not args:
        return False
    return True


def _method_accesses_state(
    method: ast.FunctionDef | ast.AsyncFunctionDef,
) -> bool:
    """Return True if the method reads any `self.<attr>` or
    `cls.<attr>` reference. Pure AST walk over the method body."""
    args = method.args.args
    if not args:
        return False
    first_arg_name = args[0].arg
    if first_arg_name not in {"self", "cls"}:
        return False
    for sub in ast.walk(method):
        if isinstance(sub, ast.Attribute) and isinstance(sub.value, ast.Name):
            if sub.value.id == first_arg_name:
                return True
    return False


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
) -> list:
    """Pure analyzer — find class definitions that have instance
    methods but no method accesses instance state.

    Skips exempt classes (BaseModel / Protocol / ABC / Enum / etc.).
    Returns one finding per flagged class.
    """
    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        if _is_exempt_class(node):
            continue

        instance_methods = [
            item
            for item in node.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            and _is_instance_method(item)
        ]
        if not instance_methods:
            # No instance methods at all — class is namespace / data-only.
            # Not the target of this rule.
            continue

        any_state_access = any(
            _method_accesses_state(m) for m in instance_methods
        )
        if any_state_access:
            continue

        # Flag: instance methods exist, none access state.
        findings.append(make_finding(
            rule=RULE_NAME,
            severity=severity,
            location=make_location(
                path=str(file_path),
                line=node.lineno,
                symbol=node.name,
            ),
            message=(
                f"class {node.name!r} has {len(instance_methods)} "
                f"instance method(s) but no method accesses instance "
                f"state. Consider flattening to module-level functions "
                f"per Rule 9 — class APIs hide dispatch behind "
                f"attribute resolution; flat functions present "
                f"unambiguous test seams."
            ),
            rule_anchor=RULE_ANCHOR,
            suggestion=(
                "Replace the class with module-level functions. If "
                "state-sharing across calls is needed, use a frozen "
                "dataclass + module functions taking the dataclass as "
                "a parameter. Exempt classes (BaseModel / Protocol / "
                "ABC / Enum / dataclass) are not flagged."
            ),
        ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Effect — file walk + parse."""
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
