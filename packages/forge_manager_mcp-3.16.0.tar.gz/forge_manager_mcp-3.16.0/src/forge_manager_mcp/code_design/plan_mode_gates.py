"""plan_mode.* gate evaluators (#441 / 3.13.0 D-Gates).

Registers default evaluators for the 6 plan_mode gates introduced
in 3.12.0 / #437:

- plan_mode.set_milestone_plan
- plan_mode.release_project
- plan_mode.migrate_tool
- plan_mode.skill_prose_edit
- plan_mode.project_rules_edit
- plan_mode.autonomous_mode_overrides (meta-gate)

Each evaluator (per #441 design lean — explicit caller attestation)
checks ``ctx.request['plan_mode_engaged']``. The caller (Claude /
operator / CI) asserts whether plan-mode was engaged before the
gated operation. Truthful attestation is on the operator; the
evaluator just routes pass/warn/fail based on the assertion.

Contract:
- ``plan_mode_engaged=True`` → status="passed"
- ``plan_mode_engaged=False`` or missing → status="warn" (default
  severity); project-rules tighten to "failed" when enforcement is
  needed
- The autonomous_mode_overrides meta-gate has different semantics:
  it returns the configured override set as info-tier metadata
  rather than gating an operation directly.

Per the 3.12.0 design lean: severity stays warn pending false-
positive sweep. Project rules tighten case-by-case via
``Overrides plan_mode.<gate>`` declarations in project-rules.md.
"""
from __future__ import annotations

from dataclasses import replace as _dataclass_replace
from typing import TYPE_CHECKING

from ..interceptors import Context, Interceptor
from ..server.gates import register_default_evaluator

if TYPE_CHECKING:
    from ..gate_registry import GateRegistry


# Gate name constants — one per gate declared in gates.yaml.
GATE_SET_MILESTONE_PLAN = "plan_mode.set_milestone_plan"
GATE_RELEASE_PROJECT = "plan_mode.release_project"
GATE_MIGRATE_TOOL = "plan_mode.migrate_tool"
GATE_SKILL_PROSE_EDIT = "plan_mode.skill_prose_edit"
GATE_PROJECT_RULES_EDIT = "plan_mode.project_rules_edit"
GATE_AUTONOMOUS_MODE_OVERRIDES = "plan_mode.autonomous_mode_overrides"


# Per-gate operation-name (for the warn-tier message); maps gate to
# the human-readable operation it gates.
_OPERATION_FOR_GATE: dict[str, str] = {
    GATE_SET_MILESTONE_PLAN: "set_milestone_plan",
    GATE_RELEASE_PROJECT: "release_project",
    GATE_MIGRATE_TOOL: "migrate_to_*",
    GATE_SKILL_PROSE_EDIT: "skill-prose edit (.claude/skills/forge-manager/*.md)",
    GATE_PROJECT_RULES_EDIT: "project-rules edit (.claude/project-rules.md)",
}


# Default override-set for the meta-gate per #437 design: the two
# global-blast-radius gates stay engaged regardless of autonomous-mode.
_DEFAULT_AUTONOMOUS_OVERRIDE_SET: tuple[str, ...] = (
    "skill_prose_edit",
    "project_rules_edit",
)


def _make_attestation_evaluator(gate_name: str) -> Interceptor:
    """Build an evaluator that checks plan_mode_engaged attestation
    in ctx.request. Pass on True; warn on False/missing.

    All 5 per-operation gates share this shape — the only thing that
    differs is the gate_name + operation label in the message.
    """
    operation = _OPERATION_FOR_GATE.get(gate_name, gate_name)

    async def enter(ctx: Context) -> Context:
        req = ctx.request or {}
        engaged = bool(req.get("plan_mode_engaged", False))
        if engaged:
            result = {
                "status": "passed",
                "gate_name": gate_name,
                "detail": (
                    f"plan_mode_engaged=True attested by caller for "
                    f"operation {operation!r}."
                ),
            }
        else:
            result = {
                "status": "warn",
                "gate_name": gate_name,
                "detail": (
                    f"plan_mode_engaged not attested for operation "
                    f"{operation!r}. Per #437, this operation should "
                    "be preceded by an EnterPlanMode / ExitPlanMode "
                    "cycle so the operator accepts the plan before "
                    "the operation executes. Pass "
                    "`plan_mode_engaged=true` on the call to attest."
                ),
            }
        new_response = {**ctx.response, gate_name: result}
        return _dataclass_replace(ctx, response=new_response)

    return Interceptor(
        enter=enter,
        name=f"plan_mode_evaluator[{gate_name}]",
    )


def _make_autonomous_mode_overrides_evaluator() -> Interceptor:
    """Build the meta-gate evaluator. Returns the configured override
    set as info-tier metadata.

    The override set is the list of gate names that stay engaged
    regardless of autonomous-mode state. Default per #437:
    [skill_prose_edit, project_rules_edit] — the two global-blast-
    radius gates can't be suspended by autonomous-mode.

    Project rules can extend the override set via:
        Extends plan_mode.autonomous_mode_overrides add: [...]
    """
    async def enter(ctx: Context) -> Context:
        req = ctx.request or {}
        # Project rules may pass a customized override set via
        # ``autonomous_override_set`` on the request; absent → default.
        override_set = req.get(
            "autonomous_override_set",
            list(_DEFAULT_AUTONOMOUS_OVERRIDE_SET),
        )
        result = {
            "status": "info",
            "gate_name": GATE_AUTONOMOUS_MODE_OVERRIDES,
            "override_set": list(override_set),
            "detail": (
                f"plan-mode override set under autonomous-mode: "
                f"{list(override_set)}. These gates stay engaged "
                "regardless of autonomous-mode state because their "
                "blast radius is global."
            ),
        }
        new_response = {
            **ctx.response,
            GATE_AUTONOMOUS_MODE_OVERRIDES: result,
        }
        return _dataclass_replace(ctx, response=new_response)

    return Interceptor(
        enter=enter,
        name=f"plan_mode_evaluator[{GATE_AUTONOMOUS_MODE_OVERRIDES}]",
    )


def register_plan_mode_gates(registry: "GateRegistry") -> int:
    """Register default evaluators for all 6 plan_mode gates.
    Returns the count of gates registered (skips ones absent from
    the registry — supports partial registries in tests)."""
    count = 0
    for gate_name in (
        GATE_SET_MILESTONE_PLAN,
        GATE_RELEASE_PROJECT,
        GATE_MIGRATE_TOOL,
        GATE_SKILL_PROSE_EDIT,
        GATE_PROJECT_RULES_EDIT,
    ):
        if registry.has(gate_name):
            register_default_evaluator(
                gate_name, _make_attestation_evaluator(gate_name),
            )
            count += 1
    if registry.has(GATE_AUTONOMOUS_MODE_OVERRIDES):
        register_default_evaluator(
            GATE_AUTONOMOUS_MODE_OVERRIDES,
            _make_autonomous_mode_overrides_evaluator(),
        )
        count += 1
    return count


__all__ = [
    "GATE_AUTONOMOUS_MODE_OVERRIDES",
    "GATE_MIGRATE_TOOL",
    "GATE_PROJECT_RULES_EDIT",
    "GATE_RELEASE_PROJECT",
    "GATE_SET_MILESTONE_PLAN",
    "GATE_SKILL_PROSE_EDIT",
    "register_plan_mode_gates",
]
