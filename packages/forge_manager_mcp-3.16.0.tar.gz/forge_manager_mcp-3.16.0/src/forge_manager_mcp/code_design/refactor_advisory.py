"""refactor_advisory evaluator (Phase D3b.4s / #346).

Diff-aware advisory: catches planned modifications that turn a
one-step process into a multi-step process. Distinct from the
state-aware advisories (#344) which only see post-state.

**Stub implementation in 3.5.0.** Per #346's scope, this evaluator
is registered but emits no findings. Diff parsing + AST-level
before/after comparison + threshold-tuning logic is non-trivial
and would risk false positives at first iteration. The full impl
ships in 3.5.x as a follow-up.

The registration here ensures:
  * The rule is discoverable via ``check_code_design(rules=[...])``
  * Project rules can ``Overrides`` it to tune thresholds
  * The handler's ``findings_by_tier`` summary includes it
  * The framework lands so the 3.5.x heuristic is a pure addition

**3.5.x heuristic scope (per Issue body):**
  * 1 effect → ≥3 effects: "function is becoming an orchestrator"
  * <50 lines → ≥50 lines: "approaching orchestrator threshold"
  * 0 try/except → ≥2: "compensation-pair pattern emerging"
  * Single-shot return → multi-stage with intermediate state:
    "request handler is multi-stepping"

Each transition would surface as an `info`-severity advisory
pointing at the relevant Rule (2 / 3 / Composability) and the
specific code locations involved.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import Severity
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "refactor_advisory"
RULE_ANCHOR = "code-design.md#advisory-tier-3-5-0"


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """3.5.0 stub — returns empty findings.

    For a state-aware run (no diff context), this evaluator has
    nothing to compare against — emits no findings. The 3.5.x impl
    will accept diff context via an additional parameter or
    sidecar input file. The framework lands here so rule
    registration + project-rules ``Overrides`` work today.
    """
    return []


register_evaluator(RULE_NAME, evaluate)
