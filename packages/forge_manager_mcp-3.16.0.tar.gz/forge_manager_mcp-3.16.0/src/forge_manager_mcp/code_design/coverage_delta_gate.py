"""Coverage-delta gate (#445 / 3.13.0 D-Gates.4).

Implements `commit.coverage_delta` — a pre-commit gate that asserts
new and modified lines (per git diff) are covered by the test
suite. Companion to `release.coverage_absolute` (#429, 3.12.0) which
checks codebase-wide coverage at tag time. The delta gate fires
earlier in the lifecycle — at commit / PR time — so coverage
regressions are caught before they land.

The gate is fail-fast: any uncovered new/modified line is a finding
(unless rationale-tagged via `# pragma: no cover` with one of the
#428 vocabulary tags — DEFENSIVE / OPERATOR / EXTERNAL / BAZEL).

Reuses parse_lcov_uncovered + discover_ignored_lines from
coverage_gate.py — same LCOV format, same pragma-rationale vocab.
The new piece is git-diff parsing + intersection with the
changed-line set.
"""
from __future__ import annotations

import re
from functools import cache
from pathlib import Path
from typing import TYPE_CHECKING

from ..interceptors import Context, Interceptor
from ..server.gates import register_default_evaluator
from .coverage_gate import (
    discover_ignored_lines,
    parse_lcov_uncovered,
)

if TYPE_CHECKING:
    from ..gate_registry import GateRegistry


GATE_DELTA = "commit.coverage_delta"


# ---------------------------------------------------------------------------
# Schema (Rule 5 — factory-pattern)
# ---------------------------------------------------------------------------


@cache
def _delta_summary_class() -> type:
    from dataclasses import dataclass
    @dataclass(frozen=True)
    class DeltaSummary:
        files_changed: int
        lines_changed: int
        lines_uncovered_in_delta: int
        lines_ignored_in_delta: int
        uncovered_by_file: tuple[tuple[str, tuple[int, ...]], ...]
    return DeltaSummary


def make_delta_summary(
    *,
    files_changed: int,
    lines_changed: int,
    lines_uncovered_in_delta: int,
    lines_ignored_in_delta: int,
    uncovered_by_file: tuple[tuple[str, tuple[int, ...]], ...] = (),
):
    cls = _delta_summary_class()
    return cls(
        files_changed=files_changed,
        lines_changed=lines_changed,
        lines_uncovered_in_delta=lines_uncovered_in_delta,
        lines_ignored_in_delta=lines_ignored_in_delta,
        uncovered_by_file=uncovered_by_file,
    )


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


_HUNK_HEADER_RE = re.compile(
    r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@",
)


def parse_git_diff_changed_lines(diff_text: str) -> dict[str, set[int]]:
    """Parse a unified diff (e.g. ``git diff -U0`` output); return
    ``{file_path: set(new_line_numbers)}`` for added / modified lines
    on the post-image (+++ side) of each hunk.

    Pure — no IO. Caller produces the diff text via ``git diff``.

    Removed lines (``-`` prefix) don't contribute to the changed set
    on the post-image since they're gone. Context lines (`` `` space
    prefix) increment the new-line counter but aren't flagged. Only
    `+` prefixed lines (excluding the `+++` header) get added.

    The diff-side file path is normalized: drops the leading ``b/``
    that ``git diff`` typically prepends.
    """
    by_file: dict[str, set[int]] = {}
    current_file: str | None = None
    current_new_line: int = 0
    in_hunk: bool = False

    for raw in diff_text.splitlines():
        if raw.startswith("+++ "):
            # +++ b/path/to/file.py  OR  +++ /dev/null (deleted file)
            path = raw[4:].strip()
            if path.startswith("b/"):
                path = path[2:]
            if path == "/dev/null":
                current_file = None
            else:
                current_file = path
                by_file.setdefault(current_file, set())
            in_hunk = False
            continue
        if raw.startswith("--- "):
            in_hunk = False
            continue
        if raw.startswith("diff --git"):
            current_file = None
            in_hunk = False
            continue
        m = _HUNK_HEADER_RE.match(raw)
        if m:
            current_new_line = int(m.group(1))
            in_hunk = True
            continue
        if not in_hunk or current_file is None:
            continue
        if raw.startswith("+") and not raw.startswith("+++"):
            by_file[current_file].add(current_new_line)
            current_new_line += 1
        elif raw.startswith("-") and not raw.startswith("---"):
            # Removed line on the pre-image — no advance on post-image.
            pass
        else:
            # Context line (space-prefix or blank) — present in both
            # sides; advance new-line counter.
            current_new_line += 1
    return by_file


def _match_lcov_path(
    diff_path: str,
    candidate_keys: list[str],
) -> str | None:
    """Match a diff-side path against an LCOV-side path. Tries exact
    match first; then suffix-match in either direction (the diff may
    be project-relative while LCOV is absolute, or vice versa)."""
    if diff_path in candidate_keys:
        return diff_path
    for lcov_path in candidate_keys:
        if lcov_path.endswith(diff_path) or diff_path.endswith(lcov_path):
            return lcov_path
    return None


def evaluate_delta(
    changed_by_file: dict[str, set[int]],
    uncovered_by_file: dict[str, set[int]],
    ignored_by_file: dict[str, set[int]],
):
    """Pure decision: of the changed lines, which are uncovered (and
    not rationale-tagged ignored)?

    Returns a DeltaSummary capturing per-file uncovered-in-delta sets
    and aggregate totals.
    """
    lcov_keys = list(uncovered_by_file.keys())
    truly_uncovered_by_file: dict[str, set[int]] = {}
    total_changed = 0
    total_uncovered_in_delta = 0
    total_ignored_in_delta = 0

    for path, changed in changed_by_file.items():
        total_changed += len(changed)
        match = _match_lcov_path(path, lcov_keys)
        if match is None:
            # No coverage data for the changed file. Could be a new
            # file with no tests yet, or a non-Python file, or a file
            # not in the test target's closure. Treat as "no overlap"
            # — silent.
            continue
        uncovered = uncovered_by_file.get(match, set())
        ignored = ignored_by_file.get(match, set())
        in_delta = changed & uncovered
        ignored_overlap = in_delta & ignored
        truly = in_delta - ignored
        if truly:
            truly_uncovered_by_file[path] = truly
            total_uncovered_in_delta += len(truly)
        total_ignored_in_delta += len(ignored_overlap)

    sorted_files: list[tuple[str, tuple[int, ...]]] = [
        (p, tuple(sorted(lines)))
        for p, lines in sorted(truly_uncovered_by_file.items())
    ]
    return make_delta_summary(
        files_changed=len(changed_by_file),
        lines_changed=total_changed,
        lines_uncovered_in_delta=total_uncovered_in_delta,
        lines_ignored_in_delta=total_ignored_in_delta,
        uncovered_by_file=tuple(sorted_files),
    )


# ---------------------------------------------------------------------------
# Gate evaluator
# ---------------------------------------------------------------------------


def evaluate_commit_coverage_delta() -> Interceptor:
    """Build the default-evaluator interceptor for the delta gate.

    Reads from ``ctx.request``:
    * ``git_diff`` — unified-diff text (caller produces via ``git
      diff``). Required; gate skips with status="info" when absent.
    * ``coverage_lcov_path`` — path to merged LCOV (default:
      ``./merged.lcov``)
    * ``source_root`` — path to walk for ignore directives
      (default: ``.``)

    Returns:
    * ``status="passed"`` when uncovered − ignored == 0 among changed lines
    * ``status="info"`` when git_diff is empty/missing (gate skipped)
    * ``status="warn"`` when uncovered lines remain (default severity)
    * ``status="failed"`` when project rules tighten to fail
    """
    from dataclasses import replace as _replace

    async def enter(ctx: Context) -> Context:
        req = ctx.request or {}
        diff_text = req.get("git_diff", "")
        if not diff_text:
            result = {
                "status": "info",
                "gate_name": GATE_DELTA,
                "detail": (
                    "commit.coverage_delta skipped — no git_diff "
                    "provided. Pre-commit hook supplies this via "
                    "`git diff --staged` or `git diff HEAD`."
                ),
            }
            new_response = {**ctx.response, GATE_DELTA: result}
            return _replace(ctx, response=new_response)

        lcov_path = Path(req.get("coverage_lcov_path", "./merged.lcov"))
        source_root = Path(req.get("source_root", "."))

        if not lcov_path.exists():
            result = {
                "status": "info",
                "gate_name": GATE_DELTA,
                "detail": (
                    f"commit.coverage_delta skipped — LCOV not found "
                    f"at {lcov_path}. Run `bazel coverage` + "
                    "tools/merge_coverage.py first."
                ),
            }
            new_response = {**ctx.response, GATE_DELTA: result}
            return _replace(ctx, response=new_response)

        lcov_text = lcov_path.read_text()
        changed = parse_git_diff_changed_lines(diff_text)
        uncovered = parse_lcov_uncovered(lcov_text)
        ignored = discover_ignored_lines(source_root)
        summary = evaluate_delta(changed, uncovered, ignored)

        if summary.lines_uncovered_in_delta == 0:
            result = {
                "status": "passed",
                "gate_name": GATE_DELTA,
                "summary": {
                    "files_changed": summary.files_changed,
                    "lines_changed": summary.lines_changed,
                    "lines_uncovered_in_delta": 0,
                    "lines_ignored_in_delta": summary.lines_ignored_in_delta,
                },
            }
        else:
            files_str = "; ".join(
                f"{p}: {len(lines)} line(s)"
                for p, lines in summary.uncovered_by_file[:5]
            )
            if len(summary.uncovered_by_file) > 5:
                files_str += f" (+{len(summary.uncovered_by_file) - 5} more)"
            result = {
                "status": "warn",
                "gate_name": GATE_DELTA,
                "detail": (
                    f"{summary.lines_uncovered_in_delta} new/modified "
                    f"line(s) uncovered across "
                    f"{len(summary.uncovered_by_file)} file(s): "
                    f"{files_str}. Add tests or rationale-tag "
                    "(DEFENSIVE / OPERATOR / EXTERNAL / BAZEL) with "
                    "`# pragma: no cover`."
                ),
                "summary": {
                    "files_changed": summary.files_changed,
                    "lines_changed": summary.lines_changed,
                    "lines_uncovered_in_delta": (
                        summary.lines_uncovered_in_delta
                    ),
                    "lines_ignored_in_delta": (
                        summary.lines_ignored_in_delta
                    ),
                    "uncovered_by_file": [
                        {"path": p, "lines": list(lines)}
                        for p, lines in summary.uncovered_by_file
                    ],
                },
            }

        new_response = {**ctx.response, GATE_DELTA: result}
        return _replace(ctx, response=new_response)

    return Interceptor(
        enter=enter,
        name=f"coverage_delta_evaluator[{GATE_DELTA}]",
    )


def register_coverage_delta_gate(registry: "GateRegistry") -> bool:
    """Register the default evaluator for commit.coverage_delta."""
    if not registry.has(GATE_DELTA):
        return False
    register_default_evaluator(
        GATE_DELTA, evaluate_commit_coverage_delta(),
    )
    return True


__all__ = [
    "GATE_DELTA",
    "evaluate_commit_coverage_delta",
    "evaluate_delta",
    "make_delta_summary",
    "parse_git_diff_changed_lines",
    "register_coverage_delta_gate",
]
