"""utility_dir_isolation evaluator (Phase D2.5 / Rule 4).

Per Rule 4 (`code_design.utility_dir_isolation` gate at
``code-design.md#rule-utility-dirs``):

> Functions used by three or more modules live in dedicated utility
> directories with their own library target and their own test
> directory + test target.

Implementation: static import-graph analysis.

1. Walk every Python source file under ``project_root``.
2. For each file, parse imports (``from X import Y`` and
   ``import X``) and record which modules it imports.
3. Build a reverse-index: for each imported module, count the
   distinct importing-modules.
4. For each imported-module with ``≥ threshold`` importers, check
   if it lives in a utility directory.
5. Flag the module if it's import-popular but lives in a non-
   utility location.

Utility directory heuristic per code-design.md §Utility isolation:
> Directory contains only modules and a BUILD file; no handlers,
> no flows, no adapters.

Concretely we exclude modules whose path contains any of the
non-utility-directory names (``handlers``, ``flows``, ``adapters``,
``replication``, ``migration``, ``server``, ``github``,
``site_renderer``, ``tools`` / ``tests`` themselves) — those are
handler/effect/integration code, not pure utilities.

The threshold (default 3) is overridable via project-rules
``Overrides`` per #330 OQ.

Pure / effect split:
- ``import_graph_from_modules`` — pure analyzer.
- ``evaluate`` — effect that walks files.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "utility_dir_isolation"
RULE_ANCHOR = "code-design.md#rule-utility-dirs"


# Default importer-count threshold per the rule's "three or more"
# wording. Overridable via project-rules `Overrides`.
DEFAULT_THRESHOLD = 3

# Directory components that disqualify a module from "utility"
# classification — these are handler / effect / integration sites
# per code-design.md §Utility isolation.
NON_UTILITY_DIRS = (
    "handlers",
    "flows",
    "adapters",
    "replication",
    "migration",
    "server",
    "github",
    "site_renderer",
    "tools",
    "tests",
)


def _module_dotted_name(rel_path: str) -> str:
    """Convert a project-relative .py path to its dotted module
    name. Drops the trailing ``.py`` and converts ``/`` to ``.``.
    """
    if rel_path.endswith(".py"):
        rel_path = rel_path[:-3]
    if rel_path.endswith("/__init__"):
        rel_path = rel_path[: -len("/__init__")]
    return rel_path.replace("/", ".").replace("\\", ".")


def _imports_from_tree(tree: ast.Module) -> set[str]:
    """Pure: extract dotted module names from import statements."""
    out: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                out.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                # `from A.B import C` — record A.B as the imported module.
                # We don't record the imported names themselves;
                # the module-level granularity is what matters.
                if node.level == 0:
                    out.add(node.module)
                # Relative imports (level > 0) are skipped — they
                # can be resolved against the importer's own
                # package, but the cross-importer count is the same
                # whether we resolve them or not. Keeping the
                # implementation simple.
    return out


def _is_utility_path(rel_path: str) -> bool:
    """True if the module's path contains no non-utility-dir
    components.
    """
    parts = rel_path.split("/")
    return not any(part in NON_UTILITY_DIRS for part in parts)


def _import_resolves_to(
    imported: str,
    project_modules: set[str],
) -> str | None:
    """If ``imported`` (e.g. ``forge_manager_mcp.parsers``) matches
    a known project module, return the project module name;
    otherwise None.

    Match is exact (a project module's dotted name) or a parent of
    a project package (e.g. ``forge_manager_mcp.flows.release``
    importing ``forge_manager_mcp.flows.release.notes`` resolves
    if the latter is a project module).
    """
    if imported in project_modules:
        return imported
    # Parent-package match: project module is `a.b.c`, importer
    # references `a.b` — count as an import of `a.b` (the
    # importing module is signaling a dependency on the package).
    # Implemented as: prefix match against any project module.
    # Conservative: only exact match.
    return None if imported not in project_modules else imported


def import_graph_from_modules(
    modules_with_trees: dict[str, ast.Module],
) -> dict[str, set[str]]:
    """Pure analyzer. Input: dict mapping project-relative module
    name → parsed AST. Output: dict mapping each imported module
    name → set of importing module names.

    Imports outside the project's module-set are ignored (stdlib,
    third-party).
    """
    project_modules = set(modules_with_trees.keys())
    importers: dict[str, set[str]] = {}
    for importer_name, tree in modules_with_trees.items():
        for imported in _imports_from_tree(tree):
            resolved = _import_resolves_to(imported, project_modules)
            if resolved is None:
                continue
            if resolved == importer_name:
                continue  # self-import, doesn't count
            importers.setdefault(resolved, set()).add(importer_name)
    return importers


def _walk_python_files(root: Path) -> Iterable[Path]:
    if root.is_file():
        if root.suffix == ".py":
            yield root
        return
    for p in root.rglob("*.py"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules",
                        "build", "dist", ".pytest_cache")
               for part in p.parts):
            continue
        yield p


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    configured_severity: Severity,
) -> list:
    """Walk project source, build import graph, flag import-popular
    modules outside utility directories.
    """
    targets = scan_paths if scan_paths else [project_root]
    parsed: dict[str, ast.Module] = {}
    paths_for_module: dict[str, str] = {}

    for target in targets:
        target_root = target if target.is_absolute() else project_root / target
        for py_file in _walk_python_files(target_root):
            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source)
            except (OSError, SyntaxError):
                continue
            try:
                rel = py_file.relative_to(project_root)
                rel_str = str(rel).replace("\\", "/")
            except ValueError:
                rel_str = str(py_file).replace("\\", "/")
            module_name = _module_dotted_name(rel_str)
            parsed[module_name] = tree
            paths_for_module[module_name] = rel_str

    importers = import_graph_from_modules(parsed)
    findings = []
    for imported_module, importer_set in importers.items():
        if len(importer_set) < DEFAULT_THRESHOLD:
            continue
        path = paths_for_module.get(imported_module, imported_module)
        if _is_utility_path(path):
            continue
        findings.append(
            make_finding(
                rule=RULE_NAME,
                severity=configured_severity,
                location=make_location(
                    path=path,
                    line=None,
                    symbol=imported_module,
                ),
                message=(
                    f"Module '{imported_module}' is imported by "
                    f"{len(importer_set)} other modules but lives "
                    f"outside a utility directory (path component "
                    f"matches handler / effect / integration class)."
                ),
                rule_anchor=RULE_ANCHOR,
                suggestion=(
                    f"Move '{imported_module}' into a dedicated "
                    f"utility directory with its own BUILD library "
                    f"target and matching tests/ test target. The "
                    f"current placement defeats Bazel's incremental-"
                    f"selection cache."
                ),
            )
        )
    return findings


# Register at import time.
register_evaluator(RULE_NAME, evaluate)
