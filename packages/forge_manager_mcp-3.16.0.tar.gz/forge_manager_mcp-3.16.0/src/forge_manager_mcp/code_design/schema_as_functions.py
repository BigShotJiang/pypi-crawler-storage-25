"""schema_as_functions evaluator (Phase D2 / Rule 5).

Static AST scan for schema definitions placed at module level. Per
Rule 5 (`code_design.schema_as_functions` gate at
``code-design.md#rule-schemas-as-functions``):

> Pydantic models, JSON Schema dicts, dataclasses, and other
> declarative shapes are values produced by factory functions, not
> top-level module constants.

Three patterns trigger a finding:

1. ``ClassDef`` at module level whose base list resolves to
   ``BaseModel`` (Pydantic) — ``class Foo(BaseModel): ...``
2. ``ClassDef`` at module level decorated with ``@dataclass`` or
   ``@dataclasses.dataclass``.
3. ``Assign`` at module level whose RHS is a call to ``TypedDict``
   — the functional ``Foo = TypedDict('Foo', {...})`` form.

False-positive guard per #330 sub-RFC: ``ClassVar``-only classes
(no fields, only ClassVar declarations) are exempt — they're
behaving as namespaces, not schemas.

Per Rule 2 (effect-then-interceptor): the AST analysis is split
from file IO. ``analyze_module`` is pure (takes a parsed AST,
returns findings); ``evaluate`` is the effect that walks the
filesystem and parses files. Pure tests cover the analyzer with
synthetic AST input; impure tests cover the evaluator end-to-end
against tmp directories.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable, Literal

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "schema_as_functions"
RULE_ANCHOR = "code-design.md#rule-schemas-as-functions"


# Directory names skipped during the file walk. Hardcoded per #330
# OQ3; future enhancement is `.gitignore` parsing for project-level
# exclusions.
_DEFAULT_DENYLIST = frozenset({
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".venv",
    "venv",
    ".env",
    ".bazel",
    ".git",
    ".pytest_cache",
})


def _is_pydantic_basemodel_base(base: ast.expr) -> bool:
    """True if the base reference resolves to ``BaseModel``.

    Matches both ``BaseModel`` and ``pydantic.BaseModel`` forms."""
    if isinstance(base, ast.Name):
        return base.id == "BaseModel"
    if isinstance(base, ast.Attribute):
        return base.attr == "BaseModel"
    return False


def _has_dataclass_decorator(node: ast.ClassDef) -> bool:
    """True if the class is decorated with ``@dataclass`` or
    ``@dataclasses.dataclass`` (with or without arguments).
    """
    for dec in node.decorator_list:
        # Bare: @dataclass or @dataclasses.dataclass
        if isinstance(dec, ast.Name) and dec.id == "dataclass":
            return True
        if isinstance(dec, ast.Attribute) and dec.attr == "dataclass":
            return True
        # Called: @dataclass(frozen=True), @dataclasses.dataclass(...)
        if isinstance(dec, ast.Call):
            inner = dec.func
            if isinstance(inner, ast.Name) and inner.id == "dataclass":
                return True
            if isinstance(inner, ast.Attribute) and inner.attr == "dataclass":
                return True
    return False


def _is_typed_dict_call(value: ast.expr) -> bool:
    """True if the RHS expression is a TypedDict functional-form
    call: ``TypedDict('Name', {...})`` or ``typing.TypedDict(...)``."""
    if not isinstance(value, ast.Call):
        return False
    func = value.func
    if isinstance(func, ast.Name) and func.id == "TypedDict":
        return True
    if isinstance(func, ast.Attribute) and func.attr == "TypedDict":
        return True
    return False


def _is_class_var_only(node: ast.ClassDef) -> bool:
    """True if every annotated class field is a ClassVar — exempts
    namespace-only classes per the rule's false-positive guard.

    Empty class bodies (only `pass`, only docstrings) also count as
    ClassVar-only since they declare no instance fields.
    """
    has_any_annotation = False
    for stmt in node.body:
        if isinstance(stmt, ast.AnnAssign):
            has_any_annotation = True
            anno = stmt.annotation
            # ClassVar[...] / ClassVar
            is_classvar = False
            if isinstance(anno, ast.Subscript):
                value = anno.value
                if isinstance(value, ast.Name) and value.id == "ClassVar":
                    is_classvar = True
                elif (
                    isinstance(value, ast.Attribute)
                    and value.attr == "ClassVar"
                ):
                    is_classvar = True
            elif isinstance(anno, ast.Name) and anno.id == "ClassVar":
                is_classvar = True
            if not is_classvar:
                return False
    return not has_any_annotation or True


def analyze_module(
    tree: ast.Module,
    path: str,
    severity: Severity,
) -> list:
    """Pure analyzer: walk module-level statements, return a list of
    findings. No IO. Inputs are the parsed AST and the project-
    relative path string.
    """
    findings = []
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            # Pydantic BaseModel subclass at module level.
            if any(_is_pydantic_basemodel_base(b) for b in node.bases):
                if _is_class_var_only(node):
                    continue
                findings.append(
                    make_finding(
                        rule=RULE_NAME,
                        severity=severity,
                        location=make_location(
                            path=path,
                            line=node.lineno,
                            symbol=node.name,
                        ),
                        message=(
                            f"Top-level Pydantic BaseModel class "
                            f"'{node.name}' violates Rule 5 "
                            f"(schema_as_functions). Move definition "
                            f"behind a factory function (e.g. "
                            f"make_{node.name.lower()}_schema)."
                        ),
                        rule_anchor=RULE_ANCHOR,
                        suggestion=(
                            "Wrap the class definition in a factory "
                            "function or @cache helper that returns the "
                            "class on first call."
                        ),
                    )
                )
                continue
            # Dataclass-decorated at module level.
            if _has_dataclass_decorator(node):
                if _is_class_var_only(node):
                    continue
                findings.append(
                    make_finding(
                        rule=RULE_NAME,
                        severity=severity,
                        location=make_location(
                            path=path,
                            line=node.lineno,
                            symbol=node.name,
                        ),
                        message=(
                            f"Top-level @dataclass class '{node.name}' "
                            f"violates Rule 5 (schema_as_functions)."
                        ),
                        rule_anchor=RULE_ANCHOR,
                        suggestion=(
                            "Move the dataclass definition inside a "
                            "factory function with @functools.cache."
                        ),
                    )
                )
        elif isinstance(node, ast.Assign):
            # TypedDict functional form at module level.
            if _is_typed_dict_call(node.value):
                target_name = "<unknown>"
                if node.targets and isinstance(node.targets[0], ast.Name):
                    target_name = node.targets[0].id
                findings.append(
                    make_finding(
                        rule=RULE_NAME,
                        severity=severity,
                        location=make_location(
                            path=path,
                            line=node.lineno,
                            symbol=target_name,
                        ),
                        message=(
                            f"Top-level TypedDict assignment "
                            f"'{target_name}' violates Rule 5 "
                            f"(schema_as_functions)."
                        ),
                        rule_anchor=RULE_ANCHOR,
                        suggestion=(
                            "Move the TypedDict definition inside a "
                            "factory function."
                        ),
                    )
                )
    return findings


def _walk_python_files(root: Path) -> Iterable[Path]:
    """Walk ``root`` yielding *.py paths, skipping the denylist
    directories. Effect — IO. Tested via tmp_path fixtures.
    """
    if root.is_file():
        if root.suffix == ".py":
            yield root
        return
    for p in root.rglob("*.py"):
        if any(part in _DEFAULT_DENYLIST for part in p.parts):
            continue
        # Skip bazel-* directory prefixes (per #330 OQ3 hardcoded
        # denylist; bazel-* contains output trees we never want to
        # audit).
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        yield p


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    configured_severity: Severity,
) -> list:
    """Evaluator entry point — registered via
    ``register_evaluator(RULE_NAME, evaluate)`` at import time.

    Walks every Python file under ``project_root`` (or under each
    path in ``scan_paths`` if provided), parses, runs
    ``analyze_module`` on each parse-success, accumulates findings.
    Parse failures are skipped silently — the gate is for code-
    design conformance, not syntax.

    Path output is project-relative + forward-slash, computed from
    the file's path relative to ``project_root``.
    """
    findings = []
    targets = scan_paths if scan_paths else [project_root]
    for target in targets:
        target_root = target if target.is_absolute() else project_root / target
        for py_file in _walk_python_files(target_root):
            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=str(py_file))
            except (OSError, SyntaxError):
                continue
            try:
                rel = py_file.relative_to(project_root)
            except ValueError:
                rel = py_file
            findings.extend(
                analyze_module(
                    tree, str(rel).replace("\\", "/"), configured_severity,
                )
            )
    return findings


# Register at import time.
register_evaluator(RULE_NAME, evaluate)
