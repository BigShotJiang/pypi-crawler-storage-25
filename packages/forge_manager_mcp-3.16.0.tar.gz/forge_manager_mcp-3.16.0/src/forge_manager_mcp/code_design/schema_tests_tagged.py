"""schema_tests_tagged evaluator (Phase D2.4 / Rule 7).

Per Rule 7 (`code_design.schema_tests_tagged` gate at
``code-design.md#rule-schema-tests``):

> Every schema factory has at least one positive test that imports
> the factory, calls it, and asserts on the result. Test target
> carries the `schema` tag.

Implementation: BUILD-target-level cross-reference.

1. Walk source files; for each, identify schema factories
   (``make_*`` functions). Map factories → containing source path.
2. Walk BUILD files; build a target-index of py_library / py_test
   targets with their srcs + tags + deps.
3. For each library that contains factories, find the test targets
   in the package (or sibling tests/ tree) whose ``deps`` reference
   that library. If none of them carry the `schema` tag, flag the
   library.

The enforcement is per-LIBRARY-with-factories, not per-factory —
a single `schema`-tagged test target whose deps include the
library satisfies the rule for every factory in that library. This
matches the rule's intent (every schema has explicit positive
test coverage in a tagged target) without forcing one tagged
target per factory.

Pure / effect split:
- ``find_libraries_needing_schema_tests`` — pure analyzer.
- ``evaluate`` — effect that walks BUILD + source files.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.build_parser import is_test_rule, parse_file
from forge_manager_mcp.code_design.factory_inventory import inventory_for_path
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "schema_tests_tagged"
RULE_ANCHOR = "code-design.md#rule-schema-tests"


def _normalize_dep(dep: str) -> str:
    """Strip leading ``:`` and ``//`` for matching purposes.

    BUILD ``deps`` entries use Bazel target syntax: ``:foo`` (same
    package), ``//path/to:target`` (absolute), ``@external//...``.
    For our cross-reference we extract the target name (last path
    component), which is enough to match library names.
    """
    if dep.startswith("@"):
        return ""
    if "//" in dep:
        return dep.split(":")[-1]
    if dep.startswith(":"):
        return dep[1:]
    return dep


def _libraries_with_factories(
    library_targets: list,
    project_root: Path,
) -> dict[str, list[str]]:
    """For each library target, scan its srcs for factories. Return
    {library_name: [factory_name, ...]}.
    """
    result = {}
    for lib in library_targets:
        if lib.name is None:
            continue
        factories: list[str] = []
        for src in lib.srcs:
            # srcs entries are package-relative; resolve via the
            # BUILD's location (caller passes parsed targets paired
            # with their containing dir).
            candidate = project_root / src if not Path(src).is_absolute() else Path(src)
            factories.extend(inventory_for_path(candidate))
        if factories:
            result[lib.name] = factories
    return result


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    configured_severity: Severity,
) -> list:
    """Walk BUILD files + source files; cross-reference library-
    factory inventory against `schema`-tagged test targets'
    declared deps.
    """
    targets = scan_paths if scan_paths else [project_root]
    library_targets: list = []
    test_targets: list = []
    findings = []

    for target in targets:
        target_root = target if target.is_absolute() else project_root / target
        for build_file in _walk_builds(target_root):
            parsed = parse_file(build_file)
            build_dir = build_file.parent
            for t in parsed:
                if t.rule == "py_library" or t.rule.endswith("_library"):
                    # Resolve srcs relative to the BUILD file's directory.
                    resolved_srcs = tuple(
                        str((build_dir / s).resolve()) for s in t.srcs
                    )
                    # Wrap with resolved srcs by reconstructing.
                    library_targets.append(
                        _LibTuple(
                            name=t.name,
                            srcs=resolved_srcs,
                            tags=t.tags,
                            line=t.line,
                            build_file=build_file,
                        )
                    )
                elif is_test_rule(t):
                    # (#471) is_test_rule covers py_test +
                    # py_test_with_coverage + other *_test_* macros.
                    test_targets.append(t)

    # Per-library factory inventory.
    libs_with_factories: dict[str, _LibTuple] = {}
    for lib in library_targets:
        factories: list[str] = []
        for src_abs in lib.srcs:
            factories.extend(inventory_for_path(Path(src_abs)))
        if factories:
            libs_with_factories[lib.name] = lib

    # Index of `schema`-tagged tests' normalized deps.
    schema_tested_libs: set[str] = set()
    for test in test_targets:
        if "schema" not in test.tags:
            continue
        for dep in test.deps:
            normalized = _normalize_dep(dep)
            if normalized:
                schema_tested_libs.add(normalized)

    # Flag libraries with factories that no `schema`-tagged test depends on.
    for lib_name, lib in libs_with_factories.items():
        if lib_name in schema_tested_libs:
            continue
        try:
            rel = lib.build_file.relative_to(project_root)
            rel_str = str(rel).replace("\\", "/")
        except ValueError:
            rel_str = str(lib.build_file)
        findings.append(
            make_finding(
                rule=RULE_NAME,
                severity=configured_severity,
                location=make_location(
                    path=rel_str, line=lib.line, symbol=lib_name,
                ),
                message=(
                    f"Library '{lib_name}' contains schema "
                    f"factories but no test target tagged "
                    f"`schema` declares deps on it."
                ),
                rule_anchor=RULE_ANCHOR,
                suggestion=(
                    f"Add `tags = [\"schema\", ...]` to a test "
                    f"target whose deps include `:{lib_name}` and "
                    f"that imports + calls the make_* factories."
                ),
            )
        )
    return findings


def _walk_builds(root: Path):
    if root.is_file():
        if root.name in ("BUILD", "BUILD.bazel"):
            yield root
        return
    for p in root.rglob("BUILD"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p
    for p in root.rglob("BUILD.bazel"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p


from dataclasses import dataclass as _dc
from functools import cache as _cache


@_cache
def _lib_tuple_class():
    @_dc(frozen=True)
    class LibTuple:
        name: str
        srcs: tuple[str, ...]
        tags: tuple[str, ...]
        line: int
        build_file: Path
    return LibTuple


def _LibTuple(*, name, srcs, tags, line, build_file):
    return _lib_tuple_class()(
        name=name, srcs=srcs, tags=tags, line=line, build_file=build_file,
    )


# Register at import time.
register_evaluator(RULE_NAME, evaluate)
