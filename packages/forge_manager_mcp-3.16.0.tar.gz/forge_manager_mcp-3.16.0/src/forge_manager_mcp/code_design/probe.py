"""Shared probe helper for code-design status snapshots.

Originally lived inline in ``server/handlers/session.py`` as
``_probe_code_design_status`` (#345). Extracted so the daemon's
``GET /gates`` endpoint can return the same shape without duplicating
the registry-walk logic.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path


def probe_code_design_status(project_dir: Path | None) -> dict:
    """Walk every registered evaluator against ``project_dir`` and
    return a snapshot suitable for inclusion in API responses.

    Returns ``{ran_at, scope, by_severity, by_tier, top_findings}``
    on success; ``{ran_at: None, scope: "skipped", ...}`` on any
    failure (import error, evaluator crash, missing project_dir).

    ``top_findings`` is truncated to the 10 highest-severity entries
    so the response stays compact.
    """
    try:
        import forge_manager_mcp.code_design  # noqa: F401
        from forge_manager_mcp.code_design.registry import (
            all_rules, get_evaluator,
        )
    except Exception:
        return {
            "ran_at": None,
            "scope": "skipped",
            "by_severity": {"fail": 0, "warn": 0, "info": 0},
            "by_tier": {"mechanical": 0, "advisory": 0},
            "top_findings": [],
        }

    by_severity = {"fail": 0, "warn": 0, "info": 0}
    by_tier = {"mechanical": 0, "advisory": 0}
    by_rule: dict[str, dict[str, int]] = {}
    severity_rank = {"info": 0, "warn": 1, "fail": 2}
    findings: list = []
    try:
        for rule_name in all_rules():
            evaluator = get_evaluator(rule_name)
            if evaluator is None:
                continue
            severity = "info" if rule_name.endswith("_advisory") else "warn"
            for f in evaluator(project_dir, None, severity):
                findings.append(f)
                by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
                tier = "advisory" if f.rule.endswith("_advisory") else "mechanical"
                by_tier[tier] += 1
                rule_counts = by_rule.setdefault(
                    f.rule, {"fail": 0, "warn": 0, "info": 0},
                )
                rule_counts[f.severity] = rule_counts.get(f.severity, 0) + 1
    except Exception:
        return {
            "ran_at": None,
            "scope": "skipped",
            "by_severity": by_severity,
            "by_tier": by_tier,
            "by_rule": by_rule,
            "top_findings": [],
        }

    findings.sort(
        key=lambda f: severity_rank.get(f.severity, 0), reverse=True,
    )
    top = [
        {
            "rule": f.rule,
            "severity": f.severity,
            "path": f.location.path,
            "line": f.location.line,
            "message": f.message,
        }
        for f in findings[:10]
    ]
    return {
        "ran_at": datetime.now(timezone.utc).isoformat(),
        "scope": "head",
        "by_severity": by_severity,
        "by_tier": by_tier,
        "by_rule": by_rule,
        "top_findings": top,
    }


def probe_code_design_findings(project_dir: Path | None) -> dict:
    """Walk every registered evaluator and return the full findings
    list + per-path index (#369 / 3.8.0 D7.1).

    Sibling of :func:`probe_code_design_status`; this returns
    untruncated findings + a ``by_path`` map suitable for the UI's
    tree-icon roll-up. The status helper stays the right shape for
    open_session (compact, top-10); the findings helper is the
    right shape for the operator-facing Findings surface.

    Returns ``{ran_at, scope, findings, by_path, by_rule}`` on
    success; ``{ran_at: None, scope: "skipped", ...}`` on any
    failure (matches the status helper's tolerant pattern).
    """
    try:
        import forge_manager_mcp.code_design  # noqa: F401
        from forge_manager_mcp.code_design.registry import (
            all_rules, get_evaluator,
        )
    except Exception:
        return {
            "ran_at": None,
            "scope": "skipped",
            "findings": [],
            "by_path": {},
            "by_rule": {},
        }

    by_path: dict[str, dict[str, int]] = {}
    by_rule: dict[str, dict[str, int]] = {}
    findings_out: list = []
    try:
        for rule_name in all_rules():
            evaluator = get_evaluator(rule_name)
            if evaluator is None:
                continue
            severity = "info" if rule_name.endswith("_advisory") else "warn"
            for f in evaluator(project_dir, None, severity):
                findings_out.append({
                    "rule": f.rule,
                    "severity": f.severity,
                    "path": f.location.path,
                    "line": f.location.line,
                    "message": f.message,
                })
                path_counts = by_path.setdefault(
                    f.location.path,
                    {"fail": 0, "warn": 0, "info": 0},
                )
                path_counts[f.severity] = path_counts.get(f.severity, 0) + 1
                rule_counts = by_rule.setdefault(
                    f.rule, {"fail": 0, "warn": 0, "info": 0},
                )
                rule_counts[f.severity] = rule_counts.get(f.severity, 0) + 1
    except Exception:
        return {
            "ran_at": None,
            "scope": "skipped",
            "findings": findings_out,
            "by_path": by_path,
            "by_rule": by_rule,
        }

    return {
        "ran_at": datetime.now(timezone.utc).isoformat(),
        "scope": "head",
        "findings": findings_out,
        "by_path": by_path,
        "by_rule": by_rule,
    }
