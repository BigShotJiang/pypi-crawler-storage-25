"""In-house Bazel BUILD file parser (Phase D2.3 / #330 OQ1).

Bazel BUILD files use Python syntax (Skylark is a Python subset),
so ``ast.parse`` accepts them directly. The semantics differ (no
imports, restricted builtins) but for our purposes — finding
target declarations and their ``tags`` / ``srcs`` / ``name``
kwargs — the AST is sufficient.

Per #330 OQ1 closure: in-house parser, ~100 LOC, matches the
constrained-shape parser pattern from `gates.yaml` (3.2.0 #287).
Avoids the `buildozer` shell-out (cross-platform shell-quoting
issues; external binary dep) and the `def py_test(...): pass` shim
approach (load(...) directives reference targets that don't exist
as Python imports).

Pure module: file IO is the only effect, isolated to ``parse_file``.
The pure analyzer ``parse_source`` operates on a string. Per Rule 2
(effect-then-interceptor) the split makes both independently
testable.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from functools import cache
from pathlib import Path


@cache
def _build_target_class():
    """Cached frozen-dataclass shape for parsed BUILD targets. Per
    Rule 5 the class definition is inside a function, not at module
    level."""
    @dataclass(frozen=True)
    class BuildTarget:
        rule: str            # e.g. "py_test", "py_library"
        name: str | None     # `name` kwarg if present
        srcs: tuple[str, ...]
        tags: tuple[str, ...]
        deps: tuple[str, ...]
        line: int            # source line number for finding location
    return BuildTarget


def make_build_target(
    *,
    rule: str,
    name: str | None,
    srcs: tuple[str, ...] = (),
    tags: tuple[str, ...] = (),
    deps: tuple[str, ...] = (),
    line: int = 0,
):
    """Factory for BuildTarget values."""
    BuildTarget = _build_target_class()
    return BuildTarget(
        rule=rule, name=name, srcs=srcs, tags=tags, deps=deps, line=line,
    )


def _extract_string_list(value: ast.expr) -> tuple[str, ...]:
    """Extract a tuple of string literals from a List node, including
    BinOp(Add) concatenations.

    ``["a", "b", "c"]`` → ``("a", "b", "c")``.
    ``_PYTEST_DEPS + ["foo", "bar"]`` → ``("foo", "bar")`` (the left
    Name reference contributes nothing statically; the right List
    contributes its literals).

    List comprehensions, variable references on their own, and
    function calls are skipped — they don't contribute to the
    parser's static view.
    """
    # Walk addition chains recursively. Operands that aren't Lists
    # (Name refs, function calls, etc.) contribute nothing — we just
    # want the static-string subset.
    if isinstance(value, ast.BinOp) and isinstance(value.op, ast.Add):
        return (
            _extract_string_list(value.left)
            + _extract_string_list(value.right)
        )
    if not isinstance(value, ast.List):
        return ()
    out = []
    for elt in value.elts:
        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
            out.append(elt.value)
        # `requirement("foo")` and `":local_target"` strings dropped
        # by the isinstance check; that's fine — we just want the
        # static-string subset for tag analysis.
    return tuple(out)


def _extract_string(value: ast.expr) -> str | None:
    """Extract a string literal, or None if the value is not a
    plain string."""
    if isinstance(value, ast.Constant) and isinstance(value.value, str):
        return value.value
    return None


def parse_source(source: str) -> list:
    """Pure parser: takes BUILD-file source text, returns
    BuildTargets. No IO.

    Walks every top-level expression-statement whose value is a
    Call, treating each as a rule declaration. Extracts the rule
    name (the called identifier) plus the ``name``, ``srcs``,
    ``tags``, ``deps`` keyword arguments.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    targets = []
    for node in tree.body:
        if not isinstance(node, ast.Expr):
            continue
        call = node.value
        if not isinstance(call, ast.Call):
            continue
        rule = _call_rule_name(call.func)
        if rule is None:
            continue
        name = None
        srcs = ()
        tags = ()
        deps = ()
        for kw in call.keywords:
            if kw.arg == "name":
                name = _extract_string(kw.value)
            elif kw.arg == "srcs":
                srcs = _extract_string_list(kw.value)
            elif kw.arg == "tags":
                tags = _extract_string_list(kw.value)
            elif kw.arg == "deps":
                deps = _extract_string_list(kw.value)
        targets.append(
            make_build_target(
                rule=rule, name=name, srcs=srcs,
                tags=tags, deps=deps, line=call.lineno,
            )
        )
    return targets


def _call_rule_name(func: ast.expr) -> str | None:
    """Return the rule identifier (e.g. ``"py_test"``) from a Call
    node's ``func``. Handles bare names; returns None for non-name
    forms (attribute access, lambdas) since BUILD-file rules are
    bare identifiers.
    """
    if isinstance(func, ast.Name):
        return func.id
    return None


def parse_file(path: Path) -> list:
    """Effect: read a BUILD file from disk and parse it.

    Returns an empty list on read failure or parse failure — the
    parser is best-effort, downstream evaluators flag missing-info
    as separate findings if needed.
    """
    try:
        source = path.read_text(encoding="utf-8")
    except OSError:
        return []
    return parse_source(source)


def is_test_rule(target) -> bool:
    """True if the rule name names a test target.

    Covers (a) native rules like ``py_test`` / ``rust_test`` /
    ``go_test`` whose names end in ``_test``, and (b) wrapper
    macros around them whose names contain ``_test_`` mid-string
    (e.g. ``py_test_with_coverage`` — this project's coverage
    macro used in every test target).

    ``test_suite`` is excluded because it aggregates rather than
    declares a test.

    (#471 FP sweep) Pre-fix the rule-name check was strict
    ``endswith("_test")`` and missed every ``py_test_with_coverage``
    target — all 75 in tests/BUILD. Downstream evaluators
    (``schema_tests_tagged``, ``negative_tests_tagged``) treated
    every schema/effect library as untested. Broadening the match
    to include ``_test_`` substring drops the FP rate to zero.
    """
    rule = target.rule
    if rule == "test_suite":
        return False
    return rule.endswith("_test") or "_test_" in rule
