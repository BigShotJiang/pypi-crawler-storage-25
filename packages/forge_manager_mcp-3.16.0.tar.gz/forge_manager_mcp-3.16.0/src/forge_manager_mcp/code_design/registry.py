"""Evaluator registry (Phase D2 / #330 / #308).

The five `code_design.*` mechanical evaluators register themselves
via ``register_evaluator``; the handler walks the registry to
dispatch. Each evaluator is a pure function of (project_root,
scan_paths, configured_severity) → list of findings.

Module-level state: the registry dict itself. Per Locality (Rule 3
+ Composability invariant): the registry is the only module-level
mutable surface, and it's an explicit one-time-write surface
(evaluators register at import time; nothing reads-then-writes
during request processing).
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Literal


_REGISTRY: dict[str, "Evaluator"] = {}


# Evaluator signature: pure function returning findings.
Evaluator = Callable[
    [Path, list[Path] | None, Literal["fail", "warn", "info"]],
    list,
]


def register_evaluator(rule_name: str, evaluator: Evaluator) -> None:
    """Register an evaluator under its rule name.

    Called once per evaluator at import time; idempotent — re-
    registration with the same name overwrites silently to support
    test-time rebinding.
    """
    _REGISTRY[rule_name] = evaluator


def get_evaluator(rule_name: str) -> Evaluator | None:
    """Return the registered evaluator or None if not registered."""
    return _REGISTRY.get(rule_name)


def all_rules() -> list[str]:
    """Return the registered rule names in registration order."""
    return list(_REGISTRY.keys())


def clear_registry() -> None:
    """Test helper: clear the registry. Production code never calls
    this — registration happens once at import time."""
    _REGISTRY.clear()
