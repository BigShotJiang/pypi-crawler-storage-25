"""test_purity_tagging evaluator (Phase D2.3 / Rule 6).

Walks every BUILD file under the project root, finds every test
target (rule ends in ``_test``, excluding ``test_suite``), and
asserts each carries exactly one of ``pure`` / ``impure`` in its
``tags`` list.

Per Rule 6 (`code_design.test_purity_tagging` gate at
``code-design.md#rule-test-purity``):

> Every test target carries exactly one of ``pure`` / ``impure``
> in its tags list.

Two failure modes flagged:

1. **Missing.** Neither tag present — finding severity is the
   gate's effective severity.
2. **Both.** Both tags present — same severity, different message
   ("ambiguous" vs "missing").

Per Rule 2 split: ``analyze_targets`` is pure (takes a list of
parsed targets, returns findings); ``evaluate`` is the effect
that walks BUILD files.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.build_parser import (
    is_test_rule,
    parse_file,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "test_purity_tagging"
RULE_ANCHOR = "code-design.md#rule-test-purity"

_PURITY_TAGS = frozenset({"pure", "impure"})


def analyze_targets(
    targets,
    path: str,
    severity: Severity,
) -> list:
    """Pure analyzer: iterate over parsed targets, flag missing /
    ambiguous purity tags.
    """
    findings = []
    for target in targets:
        if not is_test_rule(target):
            continue
        purity_tags = set(target.tags) & _PURITY_TAGS
        if len(purity_tags) == 0:
            findings.append(
                make_finding(
                    rule=RULE_NAME,
                    severity=severity,
                    location=make_location(
                        path=path, line=target.line, symbol=target.name,
                    ),
                    message=(
                        f"Test target '{target.name}' "
                        f"({target.rule}) is missing the purity "
                        f"tag. Add exactly one of `pure` or `impure` "
                        f"to its tags list."
                    ),
                    rule_anchor=RULE_ANCHOR,
                    suggestion=(
                        "Append `tags = [\"pure\"]` if the test "
                        "uses no infrastructure, mocks, or env "
                        "vars; otherwise `tags = [\"impure\"]`."
                    ),
                )
            )
        elif len(purity_tags) == 2:
            findings.append(
                make_finding(
                    rule=RULE_NAME,
                    severity=severity,
                    location=make_location(
                        path=path, line=target.line, symbol=target.name,
                    ),
                    message=(
                        f"Test target '{target.name}' carries both "
                        f"`pure` and `impure` tags. Choose one."
                    ),
                    rule_anchor=RULE_ANCHOR,
                )
            )
    return findings


def _walk_build_files(root: Path):
    """Yield every BUILD / BUILD.bazel file under ``root``,
    skipping the same denylist as schema_as_functions (bazel-*,
    __pycache__, etc.)."""
    if root.is_file():
        if root.name in ("BUILD", "BUILD.bazel"):
            yield root
        return
    for p in root.rglob("BUILD"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p
    for p in root.rglob("BUILD.bazel"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    configured_severity: Severity,
) -> list:
    """Walk BUILD files, parse each, dispatch the pure analyzer."""
    findings = []
    targets = scan_paths if scan_paths else [project_root]
    for target in targets:
        target_root = target if target.is_absolute() else project_root / target
        for build_file in _walk_build_files(target_root):
            parsed = parse_file(build_file)
            if not parsed:
                continue
            try:
                rel = build_file.relative_to(project_root)
            except ValueError:
                rel = build_file
            findings.extend(
                analyze_targets(
                    parsed,
                    str(rel).replace("\\", "/"),
                    configured_severity,
                )
            )
    return findings


# Register at import time.
register_evaluator(RULE_NAME, evaluate)
