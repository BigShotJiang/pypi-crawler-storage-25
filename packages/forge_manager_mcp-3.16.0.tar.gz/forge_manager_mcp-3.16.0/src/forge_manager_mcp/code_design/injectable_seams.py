"""injectable_seams evaluator (Rule 10 / #433 / 3.12.0).

Flags direct side-effecting API calls in business-logic code.
Every side effect (HTTP / subprocess / time / RNG / env var /
file IO) should be parameter-injected, registry-looked-up, or
dispatched through a middleware/interceptor stack — not called
directly from business logic.

Operationalizes the §Effects concept's "explicit inputs" property
as a binding rule for new code. Direct invocation hardcodes the
coupling to the world; injection inverts the dependency so tests
can substitute the effect surface as a whole.

Exemptions:
- Effect-implementation directories (adapters/ / flows/ / replication/ /
  migration/ / github/ / daemon/ / interceptors.py) — these ARE the
  effect implementations. Business logic that consumes them imports
  them via the injection seam.
- Test files (tests/) — pytest fixtures and stubs legitimately use
  direct effect calls for setup.

Pure AST analysis — no IO outside the walker entry point.
"""
from __future__ import annotations

import ast
from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "injectable_seams"
RULE_ANCHOR = "code-design.md#rule-injectable-seams"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
    "tests",
})

# Directories that house effect implementations — direct effect calls
# are expected here, not flagged. Per the §Utility-isolation /
# §Effect-then-interceptor pattern, business logic imports from these
# directories via injection seams.
#
# (#471 FP sweep) Added: `shadow` (shadow walkers ARE the IO surface
# per Rule 2 effect-then-interceptor — every walker is a peer-library
# effect function), `migrations` (the plural form — the singular was
# already in the list, but the actual project directory is plural;
# migration scripts are by definition effect implementations),
# `upgrade` (upgrade-poller drift detection is an effect surface).
_EFFECT_IMPL_DIR_SEGMENTS = frozenset({
    "adapters", "flows", "replication", "migration", "migrations",
    "github", "daemon", "site_renderer", "github_mocks",
    "shadow", "upgrade",
})

# Module-level files that ARE effect implementations even though not
# in a dedicated directory. Match against the file's stem (basename
# without .py).
#
# (#471 FP sweep) Added: `daemon_client` (HTTP/subprocess/time —
# the module docstring explicitly declares it as effect impl per
# Rule 2: "probe_daemon (HTTP /health probe) and spawn_daemon
# (subprocess spawn) are effect functions"), `probe` (the
# code_design/probe.py probe — the rule's own infrastructure that
# shells out to bazel run to gather findings).
_EFFECT_IMPL_FILE_STEMS = frozenset({
    "interceptors", "buffer", "automemory", "classification",
    "daemon_client", "probe",
})

# Effect-API patterns: (module-or-instance-name, attribute-suffix-set)
# Each pattern matches an ast.Attribute Call whose .value.id matches
# the first element and .attr is in the second.
_EFFECT_API_PATTERNS: tuple[tuple[str, frozenset[str]], ...] = (
    # HTTP — httpx + requests
    ("httpx", frozenset({"get", "post", "put", "patch", "delete", "head", "request"})),
    ("requests", frozenset({"get", "post", "put", "patch", "delete", "head", "request"})),
    # Subprocess
    ("subprocess", frozenset({"run", "check_call", "check_output", "Popen", "call"})),
    # Time
    ("time", frozenset({"sleep", "time", "monotonic", "perf_counter"})),
    ("datetime", frozenset({"now", "utcnow"})),
    # RNG
    ("random", frozenset({"random", "choice", "randint", "randrange", "uniform", "shuffle", "sample", "seed"})),
    # Env var via os module
    ("os", frozenset({"getenv"})),
    # File IO via os module (legacy patterns)
    ("os", frozenset({"system", "popen", "makedirs", "mkdir", "rmdir", "unlink", "remove", "rename"})),
)


# Bare-name calls that count as direct effect invocations.
_BARE_EFFECT_NAMES: frozenset[str] = frozenset({
    "open",  # builtins.open — file IO
})


def _is_effect_call(node: ast.Call) -> bool:
    """Return True if the call looks like a direct effect API call
    matching one of the known patterns."""
    func = node.func
    if isinstance(func, ast.Name) and func.id in _BARE_EFFECT_NAMES:
        return True
    if isinstance(func, ast.Attribute):
        attr = func.attr
        # ast.Attribute can chain (e.g. os.environ.get). Walk down to
        # find a Name to use as the module identity.
        target = func.value
        while isinstance(target, ast.Attribute):
            # `os.environ.get(...)` — the .value of the outer attr is
            # the `os.environ` Attribute. Drill down to find the Name.
            target = target.value
        if not isinstance(target, ast.Name):
            return False
        module_name = target.id
        for pattern_module, attrs in _EFFECT_API_PATTERNS:
            if module_name == pattern_module and attr in attrs:
                return True
    return False


def _is_env_var_subscript(node: ast.Subscript) -> bool:
    """Return True for `os.environ[...]` access patterns."""
    val = node.value
    if isinstance(val, ast.Attribute) and val.attr == "environ":
        if isinstance(val.value, ast.Name) and val.value.id == "os":
            return True
    return False


def _is_exempt_path(file_path: Path) -> bool:
    """Skip files in known effect-implementation directories /
    files."""
    for part in file_path.parts:
        if part in _EFFECT_IMPL_DIR_SEGMENTS:
            return True
    if file_path.stem in _EFFECT_IMPL_FILE_STEMS:
        return True
    return False


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
) -> list:
    """Pure analyzer — find direct effect calls in business-logic
    functions. Returns one finding per (function, effect-call)."""
    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for sub in ast.walk(node):
            if isinstance(sub, ast.Call) and _is_effect_call(sub):
                findings.append(make_finding(
                    rule=RULE_NAME,
                    severity=severity,
                    location=make_location(
                        path=str(file_path),
                        line=getattr(sub, "lineno", node.lineno),
                        symbol=node.name,
                    ),
                    message=(
                        f"function {node.name!r} makes a direct effect "
                        f"call — should be injected via parameter, "
                        f"registry lookup, or interceptor stack per "
                        f"Rule 10."
                    ),
                    rule_anchor=RULE_ANCHOR,
                    suggestion=(
                        "Replace direct calls (httpx / subprocess / "
                        "time / random / os.environ / open) with "
                        "parameter-injected client or registry-looked-"
                        "up effect function. Tests substitute the "
                        "injection seam rather than monkey-patching."
                    ),
                ))
            elif isinstance(sub, ast.Subscript) and _is_env_var_subscript(sub):
                findings.append(make_finding(
                    rule=RULE_NAME,
                    severity=severity,
                    location=make_location(
                        path=str(file_path),
                        line=getattr(sub, "lineno", node.lineno),
                        symbol=node.name,
                    ),
                    message=(
                        f"function {node.name!r} reads os.environ "
                        f"directly — should be parameter-injected "
                        f"per Rule 10."
                    ),
                    rule_anchor=RULE_ANCHOR,
                    suggestion=(
                        "Read env vars at module boundaries; thread "
                        "the resolved values through as parameters. "
                        "Tests pass synthetic values instead of "
                        "patching os.environ."
                    ),
                ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Effect — file walk + parse.

    (#471 FP sweep) Forward-going semantics — Rule 10 binds new code
    only ("Operationalizes the §Effects concept's 'explicit inputs'
    property as a binding rule for new code"). When `scan_paths` is
    None (project-wide scan from open_session / cut-gate), return
    no findings: the project has 65+ pre-existing direct-effect call
    sites which are all legitimate per the original architecture
    decisions, and the evaluator cannot tell new-vs-grandfathered
    without diff context. When `scan_paths` is a list (daemon
    watch.py changed-files path, or a CI diff invocation), scan the
    listed files — only those are "new or modified" by construction
    of the scope.

    Same shape as `functional_wrappers_forward`; see that evaluator's
    docstring for the rationale parallel.
    """
    if scan_paths is None:
        return []

    targets: list[Path] = [Path(p) for p in scan_paths]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            if not _is_exempt_path(full):
                files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            if _is_exempt_path(entry):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
