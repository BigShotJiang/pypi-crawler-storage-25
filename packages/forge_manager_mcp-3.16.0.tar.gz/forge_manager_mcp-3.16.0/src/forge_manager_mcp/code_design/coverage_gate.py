"""Coverage gates (#429 / 3.12.0 D-Coverage).

Implements `release.coverage_absolute` — a pre-tag gate that asserts
codebase-wide coverage is 100% of non-ignored lines. Reads the
merged LCOV report produced by `tools/merge_coverage.py` (#427) +
walks the source tree for `# pragma: no cover` / `/* c8 ignore */`
directives that carry a rationale tag matching the #428 vocabulary
(DEFENSIVE / OPERATOR / EXTERNAL / BAZEL).

Pass condition: every uncovered line is matched by a valid
rationale-tagged ignore directive.

The companion `commit.coverage_delta` (pre-commit, fires on PR
diffs) is deferred to a 3.12.x follow-up — the delta-coverage path
needs git-diff parsing which is its own subsystem. The absolute
gate at release time is the load-bearing piece for the milestone's
"no coverage gaps" contract.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import cache
from pathlib import Path
from typing import TYPE_CHECKING

from ..interceptors import Context, Interceptor
from ..server.gates import register_default_evaluator

if TYPE_CHECKING:
    from ..gate_registry import GateRegistry


GATE_ABSOLUTE = "release.coverage_absolute"


# Vocabulary tags allowed in rationale comments (#428).
_VALID_RATIONALES: frozenset[str] = frozenset({
    "DEFENSIVE", "OPERATOR", "EXTERNAL", "BAZEL",
})


# ---------------------------------------------------------------------------
# Schema (Rule 5 — factory-pattern)
# ---------------------------------------------------------------------------


@cache
def _coverage_summary_class() -> type:
    @dataclass(frozen=True)
    class CoverageSummary:
        lines_total: int
        lines_covered: int
        lines_uncovered: int
        lines_ignored: int
        percent: float
        uncovered_files: tuple[str, ...]
    return CoverageSummary


def make_coverage_summary(
    *,
    lines_total: int,
    lines_covered: int,
    lines_uncovered: int,
    lines_ignored: int,
    percent: float,
    uncovered_files: tuple[str, ...] = (),
):
    cls = _coverage_summary_class()
    return cls(
        lines_total=lines_total,
        lines_covered=lines_covered,
        lines_uncovered=lines_uncovered,
        lines_ignored=lines_ignored,
        percent=percent,
        uncovered_files=uncovered_files,
    )


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


def parse_lcov_uncovered(lcov_text: str) -> dict[str, set[int]]:
    """Parse LCOV; return {source_file: set(uncovered_line_numbers)}."""
    by_file: dict[str, set[int]] = {}
    current_path: str | None = None
    for line in lcov_text.splitlines():
        if line.startswith("SF:"):
            current_path = line[3:].strip()
            by_file.setdefault(current_path, set())
        elif line.startswith("DA:") and current_path:
            payload = line[3:].split(",")
            if len(payload) >= 2:
                try:
                    lineno = int(payload[0])
                    hits = int(payload[1])
                    if hits == 0:
                        by_file[current_path].add(lineno)
                except ValueError:
                    continue
        elif line == "end_of_record":
            current_path = None
    return by_file


_PRAGMA_PY = re.compile(r"#\s*pragma:\s*no\s*cover", re.IGNORECASE)
_PRAGMA_JS = re.compile(r"/\*\s*c8\s*ignore\s+(?:next|start|stop)", re.IGNORECASE)
_RATIONALE_PATTERN = re.compile(
    r"#\s*(" + "|".join(_VALID_RATIONALES) + r")\b",
    re.IGNORECASE,
)
_RATIONALE_PATTERN_JS = re.compile(
    r"/\*\s*(" + "|".join(_VALID_RATIONALES) + r")\b",
    re.IGNORECASE,
)


def discover_ignored_lines(
    source_root: Path,
) -> dict[str, set[int]]:
    """Walk the source tree; return {file: set(ignored_line_numbers)}.

    A line is "ignored" if it bears a `# pragma: no cover` directive
    AND the immediately-preceding line carries a rationale tag from
    the #428 vocabulary. Without the rationale, the directive is
    invalid and the line is treated as uncovered.

    Today's scope: Python `# pragma: no cover` only. JS / TS
    `/* c8 ignore */` slots in alongside #414/#417's vitest tier
    once JS coverage is wired.
    """
    ignored: dict[str, set[int]] = {}
    for path in source_root.rglob("*.py"):
        # Skip vendored / generated paths
        parts = set(path.parts)
        if "__pycache__" in parts or ".venv" in parts or "build" in parts:
            continue
        try:
            text = path.read_text()
        except (OSError, UnicodeDecodeError):
            continue
        lines = text.splitlines()
        for i, line in enumerate(lines, start=1):
            if not _PRAGMA_PY.search(line):
                continue
            # Check the IMMEDIATELY preceding line for the rationale tag
            if i >= 2:
                prev = lines[i - 2]
                if _RATIONALE_PATTERN.search(prev):
                    ignored.setdefault(str(path), set()).add(i)
    return ignored


def evaluate_absolute(
    uncovered_by_file: dict[str, set[int]],
    ignored_by_file: dict[str, set[int]],
):
    """Pure decision: subtract ignored from uncovered; summarize."""
    truly_uncovered_files: list[str] = []
    total_uncovered = 0
    total_ignored = 0
    total_lines = 0  # lines_total per file from LCOV not directly available
                    # — we report uncovered + ignored counts only

    for path, uncovered in uncovered_by_file.items():
        ignored = ignored_by_file.get(path, set())
        truly = uncovered - ignored
        total_uncovered += len(truly)
        total_ignored += len(uncovered & ignored)
        if truly:
            truly_uncovered_files.append(path)

    return make_coverage_summary(
        lines_total=total_lines,
        lines_covered=0,  # not derivable from uncovered-only LCOV parse
        lines_uncovered=total_uncovered,
        lines_ignored=total_ignored,
        percent=0.0 if total_uncovered > 0 else 100.0,
        uncovered_files=tuple(sorted(truly_uncovered_files)),
    )


# ---------------------------------------------------------------------------
# Gate evaluator
# ---------------------------------------------------------------------------


def evaluate_release_coverage_absolute() -> Interceptor:
    """Build the default-evaluator interceptor for the absolute gate.

    Reads:
    * ``ctx.request['coverage_lcov_path']`` — path to merged LCOV
      (default: ``./merged.lcov``)
    * ``ctx.request['source_root']`` — path to walk for ignore
      directives (default: ``.``)

    Returns:
    * ``status="passed"`` when uncovered − ignored == 0
    * ``status="warn"`` when above 0 and the project-rules haven't
      tightened to fail
    * ``status="failed"`` when project-rules have tightened (per #430)

    For 3.12.0's initial landing: severity is `warn` from this
    evaluator; #430 elevates to `fail` once #428's drain reaches
    100% baseline.

    Defensive: if the LCOV file is missing, surface as
    ``status="unconfirmed"`` with manual_steps pointing at the
    coverage workflow. The cut isn't blocked but operator gets a
    clear "run bazel coverage first" message.
    """
    from dataclasses import replace as _replace

    async def enter(ctx: Context) -> Context:
        lcov_path = Path(ctx.request.get(
            "coverage_lcov_path", "merged.lcov",
        ))
        source_root = Path(ctx.request.get("source_root", "."))

        if not lcov_path.exists():
            result: dict = {
                "status": "unconfirmed",
                "gate_name": GATE_ABSOLUTE,
                "message": (
                    f"coverage LCOV not found at {lcov_path}; "
                    "run `bazel coverage //tests:unit_tests && "
                    "bazel run //tools:merge_coverage -- --inputs "
                    "<...> --merged-output merged.lcov` first"
                ),
                "manual_steps": [
                    (
                        "bazel coverage //tests:unit_tests"
                    ),
                    (
                        "bazel run //tools:merge_coverage -- "
                        "--inputs bazel-out/_coverage/_coverage_report.dat "
                        "--merged-output merged.lcov"
                    ),
                    (
                        "Re-run validate_release"
                    ),
                ],
            }
        else:
            uncovered = parse_lcov_uncovered(lcov_path.read_text())
            ignored = discover_ignored_lines(source_root)
            summary = evaluate_absolute(uncovered, ignored)

            if summary.lines_uncovered == 0:
                result = {
                    "status": "passed",
                    "gate_name": GATE_ABSOLUTE,
                    "lines_uncovered": 0,
                    "lines_ignored": summary.lines_ignored,
                }
            else:
                # Initial 3.12.0 landing: warn-tier. #430 elevates to fail
                # once the codebase reaches 100%.
                result = {
                    "status": "warn",
                    "gate_name": GATE_ABSOLUTE,
                    "lines_uncovered": summary.lines_uncovered,
                    "lines_ignored": summary.lines_ignored,
                    "uncovered_files": list(summary.uncovered_files[:20]),
                    "manual_steps": [
                        (
                            f"{summary.lines_uncovered} line(s) across "
                            f"{len(summary.uncovered_files)} file(s) are "
                            "uncovered without rationale-tagged ignore "
                            "directives. See #428 for the drain plan."
                        ),
                        (
                            "Add tests OR add `# pragma: no cover` with "
                            "a rationale comment matching the vocabulary: "
                            "DEFENSIVE / OPERATOR / EXTERNAL / BAZEL."
                        ),
                    ],
                }

        new_response = {**ctx.response, GATE_ABSOLUTE: result}
        return _replace(ctx, response=new_response)

    return Interceptor(
        enter=enter,
        name=f"coverage_gate_evaluator[{GATE_ABSOLUTE}]",
    )


def register_coverage_gate(registry: "GateRegistry") -> bool:
    """Register the absolute coverage gate evaluator. Idempotent;
    no-op when the gate isn't in the registry."""
    if GATE_ABSOLUTE not in {g.name for g in registry.list_gates()}:
        return False
    register_default_evaluator(
        GATE_ABSOLUTE, evaluate_release_coverage_absolute(),
    )
    return True


__all__ = [
    "GATE_ABSOLUTE",
    "discover_ignored_lines",
    "evaluate_absolute",
    "evaluate_release_coverage_absolute",
    "make_coverage_summary",
    "parse_lcov_uncovered",
    "register_coverage_gate",
]
