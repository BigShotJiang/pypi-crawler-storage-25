"""Cut-time gate for code-design test rules (#423 / 3.12.0 D6).

Backstop for the 3 test code-design rules that ship `warn` severity
from the default evaluator (test_purity_tagging, schema_tests_tagged,
negative_tests_tagged). Pre-#423 these rules emitted warnings but
nothing blocked a cut from shipping with new untagged tests; the D5
sweeps (#420 / #421 / #422) drained the backlog to zero, but
post-cleanup commits could re-accumulate findings without any cut-
time gate.

This module registers `release.code_design_warns_against_cut` as a
default evaluator that:

1. Walks the project tree (CWD or explicit ``project_dir`` in request)
2. Runs the 3 test rules via the existing ``check_code_design`` registry
3. Returns ``status="passed"`` when zero warn-tier findings exist
4. Returns ``status="failed"`` with per-rule finding counts otherwise

Composition with project rules is automatic — the gate's interceptor
is the inner-most layer of the chain, so a project-rule ``loosen``
extension can downgrade ``failed`` → ``warn`` for forks that haven't
completed their own D5 sweep.

Public surface:

* :func:`evaluate_code_design_warns_against_cut` — the evaluator factory
  (returns an :class:`Interceptor`).
* :func:`register_cut_gate` — wire the evaluator into the registry.
"""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from ..interceptors import Context, Interceptor
from ..server.gates import register_default_evaluator
from .registry import get_evaluator

if TYPE_CHECKING:
    from ..gate_registry import GateRegistry


# The 3 test code-design rules this cut gate enforces.
_GUARDED_RULES: tuple[str, ...] = (
    "test_purity_tagging",
    "schema_tests_tagged",
    "negative_tests_tagged",
)


GATE_NAME = "release.code_design_warns_against_cut"


def evaluate_code_design_warns_against_cut() -> Interceptor:
    """Build the default-evaluator interceptor for the cut gate.

    Reads ``ctx.request['project_dir']`` (default: cwd). For each
    rule in :data:`_GUARDED_RULES`, invokes the registered evaluator
    and counts warn-tier findings. Returns:

    * ``status="passed"`` when the sum is 0
    * ``status="failed"`` with per-rule counts + first 5 findings as
      ``detail`` when > 0
    """
    async def enter(ctx: Context) -> Context:
        project_dir = Path(ctx.request.get("project_dir", "."))
        per_rule_findings: dict[str, list] = {}
        per_rule_missing: dict[str, bool] = {}
        total = 0
        for rule_name in _GUARDED_RULES:
            evaluator = get_evaluator(rule_name)
            if evaluator is None:
                # Defensive: rule should be registered. If not, surface
                # the gap as inconclusive rather than silently passing.
                per_rule_missing[rule_name] = True
                per_rule_findings[rule_name] = []
                total += 1
                continue
            # Evaluator signature: (project_root, scan_paths, severity)
            findings = list(evaluator(project_dir, None, "warn"))
            warn_findings = [f for f in findings if f.severity == "warn"]
            per_rule_findings[rule_name] = warn_findings
            total += len(warn_findings)

        if total == 0:
            result: dict = {
                "status": "passed",
                "gate_name": GATE_NAME,
                "guarded_rules": list(_GUARDED_RULES),
                "warn_findings_count": 0,
            }
        else:
            # First 5 findings across all rules for actionable detail
            sample: list[dict] = []
            for rule_name in _GUARDED_RULES:
                for f in per_rule_findings.get(rule_name, [])[:5]:
                    sample.append({
                        "rule": rule_name,
                        "path": str(f.location.path),
                        "line": f.location.line,
                        "symbol": f.location.symbol,
                        "message": f.message,
                    })
                    if len(sample) >= 5:
                        break
                if len(sample) >= 5:
                    break
            result = {
                "status": "failed",
                "gate_name": GATE_NAME,
                "guarded_rules": list(_GUARDED_RULES),
                "warn_findings_count": total,
                "by_rule": {
                    rule: (
                        "missing-evaluator" if per_rule_missing.get(rule)
                        else len(findings)
                    )
                    for rule, findings in per_rule_findings.items()
                },
                "detail": sample,
                "manual_steps": [
                    (
                        "Run `bazel run //tools:check_design -- "
                        "--rules test_purity_tagging schema_tests_tagged "
                        "negative_tests_tagged` to see the full list."
                    ),
                    (
                        "Tag any new test targets per the project rule "
                        "(see .claude/project-rules.md ## Gate extensions)."
                    ),
                    (
                        "Re-run validate_release once findings are at zero."
                    ),
                ],
            }

        new_response = {**ctx.response, GATE_NAME: result}
        return replace(ctx, response=new_response)

    return Interceptor(
        enter=enter,
        name=f"cut_gate_evaluator[{GATE_NAME}]",
    )


def register_cut_gate(registry: "GateRegistry") -> bool:
    """Register the cut-gate evaluator if the registry contains it.

    Idempotent — re-registering replaces the prior entry. Returns
    True when the gate is in the registry and the evaluator was
    registered; False when the gate is absent (forks of this skill
    that haven't migrated to gates.yaml's 3.12.0 entry).
    """
    if GATE_NAME not in {g.name for g in registry.list_gates()}:
        return False
    register_default_evaluator(GATE_NAME, evaluate_code_design_warns_against_cut())
    return True


__all__ = [
    "GATE_NAME",
    "evaluate_code_design_warns_against_cut",
    "register_cut_gate",
]
