"""interceptor_reuse_advisory evaluator (Phase D3b.4q / #344, Rule 3).

Heuristic advisory for Rule 3 (Interceptors reusable + context-
agnostic). Detects interceptor functions that read context fields
not declared in the canonical Context schema, or import sibling
interceptors directly (Rule 3 wants composability, not binding).

**Stub implementation in 3.5.0.** Like ``async_parity_advisory``,
this evaluator is registered but emits no findings. The heuristic
needs a Context-shape resolver (walk dataclass fields / Pydantic
model schema) plus per-module interceptor identification. Both are
non-trivial and risk false positives at first iteration. Full
implementation in 3.5.x.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import Severity
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "interceptor_reuse_advisory"
RULE_ANCHOR = "code-design.md#rule-interceptors-reusable-context-agnostic"


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """3.5.0 stub — returns empty findings. Full heuristic in 3.5.x."""
    return []


register_evaluator(RULE_NAME, evaluate)
