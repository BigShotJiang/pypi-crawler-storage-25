"""Factory inventory — shared helper for the two tagged-test
evaluators (Phase D2.4).

Walks Python source files, identifies "schema factories" via name
convention (function defs starting with ``make_``). Per the
heuristic settled in #330 OQ6 follow-up: schema factories follow
the ``make_<thing>`` naming convention established in code-design.md
§Schema-as-data; the rule's enforcement focuses on the tag-side
discipline (does a `schema`-tagged test cover this factory?), not
on the harder problem of detecting "what is a schema."

Pure module — IO is isolated to ``inventory_for_path``. The pure
``inventory_factories_in_source`` operates on a parsed AST.
"""
from __future__ import annotations

import ast
from pathlib import Path


def _is_factory_name(name: str) -> bool:
    """True if the function name follows the schema-factory
    convention ``make_<thing>``. Underscored helpers (``_make_*``)
    are excluded — they're internal.
    """
    return name.startswith("make_") and not name.startswith("_make_")


def inventory_factories_in_source(tree: ast.Module) -> list[str]:
    """Pure: return list of factory function names from the parsed
    module. Walks module-level statements only; nested functions
    aren't part of the public factory surface.
    """
    out = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if _is_factory_name(node.name):
                out.append(node.name)
    return out


def inventory_for_path(py_file: Path) -> list[str]:
    """Effect: read + parse a Python file, return its factories.
    Returns empty list on any read or parse failure.
    """
    try:
        source = py_file.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except (OSError, SyntaxError):
        return []
    return inventory_factories_in_source(tree)


# Canonical effect-function directories per code-design.md §Effects
# and #330 OQ6 closure. Module paths under these directories are
# treated as containing effect functions for the
# ``negative_tests_tagged`` evaluator's enforcement scope.
EFFECT_DIRECTORIES = (
    "flows",
    "adapters",
    "replication",
    "migration",
)

EFFECT_MODULES = (
    "interceptors.py",
)


def is_effect_path(rel_path: str) -> bool:
    """True if the path lives under a canonical effect-function
    directory or matches a canonical effect-module name.

    ``rel_path`` is project-relative, forward-slash. Examples that
    return True: ``forge_manager_mcp/flows/release/notes.py``,
    ``forge_manager_mcp/adapters/github.py``,
    ``forge_manager_mcp/interceptors.py``. Returns False for
    ``forge_manager_mcp/parsers.py`` (utility) or
    ``forge_manager_mcp/server/handlers/threads.py`` (handler).
    """
    parts = rel_path.split("/")
    for part in parts:
        if part in EFFECT_DIRECTORIES:
            return True
    name = parts[-1] if parts else ""
    return name in EFFECT_MODULES
