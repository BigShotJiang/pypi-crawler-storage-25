"""Per-session server context (#82 Phase 2a).

ServerContext bundles the state that `build_server` previously held in
its closure. Introducing it is a prerequisite for Phase 2b, where the
inner async handlers move out of `build_server` into their own modules
and receive `ctx` as an explicit parameter instead of closing over it.

Phase 2a itself is behavior-neutral: the handlers still live inside
`build_server`, still capture `ctx` by closure, and still read / mutate
the same underlying state — just through attribute access on `ctx`
rather than separate closure variables.

Concurrency model matches `SessionActivity`: one instance per
`build_server()` call (i.e. per MCP stdio subprocess). Serialized
handler dispatch means no locking is needed as long as that assumption
holds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import cache
from pathlib import Path
from typing import TYPE_CHECKING

from .models import GithubConfig
from .utils import SessionActivity

if TYPE_CHECKING:
    # Type-only import — keeps :context's runtime dep closure small.
    from .adapters.protocol import PlatformAdapter
    from .gate_registry import GateRegistry, ProcessRegistry
    from .project_rules import ProjectRules


@cache
def _server_context_class() -> type:
    """Cached factory for ServerContext (Rule 5 / schema_as_functions).

    The dataclass lives inside the cached helper so the module-level
    AST scan does not see a top-level ``@dataclass``. Module-level
    re-export below keeps ``ServerContext(...)`` constructors and
    ``isinstance(x, ServerContext)`` checks working unchanged.
    """
    @dataclass
    class ServerContext:
        """Per-session server state.

        `config` is `None` only in pre-bootstrap mode (#156): the project
        has no `.claude/github-config.json` yet because `scaffold_project`
        has not run. The dispatch in `build_server` rejects every tool
        that requires config in this mode, allowing only `scaffold_project`
        and `check_skill_version` (which operate without config) through.

        Per 3.7.0 D8.12 (#356) the MCP no longer holds a per-session
        ``ReplicationManager``; canonical reads / writes go through the
        daemon's ``/reads`` and ``/writes`` endpoints via
        ``forge_manager_mcp.daemon_client.dispatch_read`` /
        ``dispatch_write``. ``canonical_platform_id`` is the only
        snapshot the MCP keeps from the manager.
        """
        config: GithubConfig | None
        github_token: str
        anthropic_api_key: str
        project_dir: Path
        current_session: dict | None = None
        activity: SessionActivity = field(default_factory=SessionActivity)
        pre_bootstrap: bool = False

        canonical_platform_id: str = "local"
        """(#356, 3.7.0 D8 carryover) Cached canonical adapter platform_id
        snapshot at server-build time. Lets `make_canonical_ref` produce
        canonical-typed refs without contacting the daemon at request
        time. Defaults to ``"local"`` (the conventional canonical) when
        config is None (pre-bootstrap)."""

        public_face: "PlatformAdapter | None" = None
        """Configured public-facing platform adapter (#280). Resolved at
        server startup from ``config.public_face`` by instantiating the
        adapter from the matching ``config.platforms[]`` entry directly.
        None when ``config.public_face`` is None or when ``config`` is
        None (pre-bootstrap). Handlers that touch the public face
        (release mirror-sync in #282, public-Issue triage in #281)
        dispatch via this attribute rather than hardcoding
        GitHub-specific paths."""

        gate_registry: "GateRegistry | None" = None
        """Loaded gate registry (#287). Populated at server startup from
        ``.claude/skills/forge-manager/gates.yaml``. None when the YAML file
        is absent or fails to load — the server logs a warning and starts
        in degraded mode where ``evaluate_gate`` raises UnknownGate for
        every name."""

        process_registry: "ProcessRegistry | None" = None
        """Loaded process registry (#287). Populated at server startup from
        ``.claude/skills/forge-manager/processes.yaml``. None when the YAML
        file is absent or fails to load. Process records are reference-only
        today; runtime behavior is deferred to follow-up Issues."""

        project_rules: "ProjectRules | None" = None
        """Parsed project-rules surface (#288). Populated at server startup
        from ``.claude/project-rules.md`` when present. ``evaluate_gate``
        consumes this to compose the four-layer interceptor chain (state /
        override / extension / default). None means no project-specific
        layering — gates evaluate against the default evaluator alone."""

    return ServerContext


ServerContext = _server_context_class()
