"""Migration detector — walks a project directory and produces a
structured plan describing the changes a 2.x → 3.0 upgrade would
make. Pure Python, no external dependencies.

A project is considered "legacy" when any of these conditions hold:

  * ``.claude/skills/active-claude-github/`` exists (2.x skill name)
  * ``.claude/github-config.json`` exists (2.x config name)
  * No ``.claude/forge-config.json`` exists (3.0 target name)
  * CLAUDE.md mentions ``active-claude-github`` (2.x reference)

The detector reports each finding as a ``MigrationStep`` so the
runner (or the operator) can review before executing. A clean 3.0
project produces a plan with zero steps.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import cache
from pathlib import Path
from typing import Any, Literal


# 2.x → 3.0 paths and names — kept here as constants so they're easy
# to grep + maintain if conventions shift again.
_LEGACY_SKILL_DIR = Path(".claude/skills/active-claude-github")
_NEW_SKILL_DIR = Path(".claude/skills/forge-manager")
_LEGACY_CONFIG = Path(".claude/github-config.json")
_NEW_CONFIG = Path(".claude/forge-config.json")
_CLAUDE_MD = Path("CLAUDE.md")
_LEGACY_SKILL_NAME = "active-claude-github"
_NEW_SKILL_NAME = "forge-manager"


StepKind = Literal[
    "rename_skill_dir",
    "rename_config_file",
    "translate_config_schema",
    "update_claude_md",
    "bootstrap_docs_repo",
    "noop",
]


@cache
def _migration_step_class() -> type:
    @dataclass
    class MigrationStep:
        """One discrete change the migration would apply.

        ``source`` and ``target`` are project-relative paths when the step
        operates on filesystem entries; otherwise informational.

        ``payload`` carries step-specific data (e.g., the translated
        config dict for ``translate_config_schema``).
        """

        kind: StepKind
        description: str
        source: str | None = None
        target: str | None = None
        payload: dict[str, Any] = field(default_factory=dict)

    return MigrationStep


MigrationStep = _migration_step_class()


@cache
def _migration_plan_class() -> type:
    @dataclass
    class MigrationPlan:
        """The full set of changes for one project's migration."""

        project_dir: Path
        steps: list[MigrationStep] = field(default_factory=list)
        """Ordered; the runner applies them top-to-bottom."""

        warnings: list[str] = field(default_factory=list)
        """Non-fatal observations (e.g., 'CLAUDE.md absent — no update step')."""

        is_clean: bool = False
        """True iff zero steps + zero warnings — the project is already 3.0."""

        def summary(self) -> str:
            """Human-readable one-paragraph summary of the plan."""
            if self.is_clean:
                return f"Project at {self.project_dir} is already on 3.0; no migration needed."
            lines = [
                f"Migration plan for {self.project_dir}:",
                f"  {len(self.steps)} step(s); {len(self.warnings)} warning(s)",
            ]
            for i, step in enumerate(self.steps, 1):
                lines.append(f"  {i}. [{step.kind}] {step.description}")
            for w in self.warnings:
                lines.append(f"  ! {w}")
            return "\n".join(lines)

    return MigrationPlan


MigrationPlan = _migration_plan_class()


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------

def detect_legacy_state(project_dir: Path) -> MigrationPlan:
    """Walk ``project_dir`` and emit a structured migration plan.

    The detector reads but never writes. Path checks are filesystem-
    only; CLAUDE.md content scan is opportunistic — absent file just
    becomes a warning, not a failure.
    """
    project_dir = project_dir.resolve()
    plan = MigrationPlan(project_dir=project_dir)

    if not project_dir.is_dir():
        plan.warnings.append(f"project_dir {project_dir} is not a directory")
        return plan

    # 1. Skill directory rename.
    legacy_skill = project_dir / _LEGACY_SKILL_DIR
    new_skill = project_dir / _NEW_SKILL_DIR
    if legacy_skill.is_dir():
        if new_skill.exists():
            plan.warnings.append(
                f"both {_LEGACY_SKILL_DIR} and {_NEW_SKILL_DIR} exist; "
                f"manual review needed before applying skill rename"
            )
        else:
            plan.steps.append(MigrationStep(
                kind="rename_skill_dir",
                description=(
                    f"Rename .claude/skills/{_LEGACY_SKILL_NAME}/ → "
                    f".claude/skills/{_NEW_SKILL_NAME}/"
                ),
                source=str(_LEGACY_SKILL_DIR),
                target=str(_NEW_SKILL_DIR),
            ))

    # 2. Config rename + schema translation.
    legacy_config = project_dir / _LEGACY_CONFIG
    new_config = project_dir / _NEW_CONFIG
    if legacy_config.is_file():
        if new_config.exists():
            plan.warnings.append(
                f"both {_LEGACY_CONFIG} and {_NEW_CONFIG} exist; "
                f"manual review needed before applying config rename"
            )
        else:
            try:
                legacy_data = json.loads(legacy_config.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                plan.warnings.append(
                    f"could not parse {_LEGACY_CONFIG}: {exc}; "
                    f"config rename skipped"
                )
                legacy_data = None

            if legacy_data is not None:
                translated = _translate_config_schema(
                    legacy_data, project_dir=project_dir,
                )
                plan.steps.append(MigrationStep(
                    kind="translate_config_schema",
                    description=(
                        f"Translate {_LEGACY_CONFIG} schema to "
                        f"{_NEW_CONFIG} (adds platforms list with "
                        f"GitHub as the initial entry, plus repos.docs "
                        f"+ docs_repo_path for the SiteRenderer)"
                    ),
                    source=str(_LEGACY_CONFIG),
                    target=str(_NEW_CONFIG),
                    payload={
                        "legacy_data": legacy_data,
                        "translated_data": translated,
                    },
                ))
                # G6: emit a docs-repo bootstrap step iff the translator
                # was able to synthesize a docs_repo_path (we know the
                # project name) AND the operator hasn't already created
                # the local clone.
                docs_local = translated.get("docs_repo_path")
                if docs_local:
                    docs_path = Path(docs_local).expanduser()
                    if not (docs_path / ".git").is_dir():
                        plan.steps.append(MigrationStep(
                            kind="bootstrap_docs_repo",
                            description=(
                                f"Initialize local docs repo at "
                                f"{docs_path} (mkdir + git init + README + "
                                f"origin remote pointing at the GitHub "
                                f"docs repo from translated config)"
                            ),
                            source=None,
                            target=str(docs_path),
                            payload={
                                "docs_path": str(docs_path),
                                "project_name": _derive_project_name(
                                    project_dir, legacy_data,
                                ),
                                "docs_repo_full": (
                                    translated.get("repos", {}).get("docs", "")
                                ),
                            },
                        ))

    # 3. CLAUDE.md mention update.
    claude_md = project_dir / _CLAUDE_MD
    if claude_md.is_file():
        try:
            content = claude_md.read_text(encoding="utf-8")
        except OSError as exc:
            plan.warnings.append(f"could not read CLAUDE.md: {exc}")
        else:
            if _LEGACY_SKILL_NAME in content:
                plan.steps.append(MigrationStep(
                    kind="update_claude_md",
                    description=(
                        f"Replace 'active-claude-github' references in "
                        f"CLAUDE.md with 'forge-manager' "
                        f"(non-historical mentions only)"
                    ),
                    source=str(_CLAUDE_MD),
                    target=str(_CLAUDE_MD),
                    payload={
                        "occurrences": content.count(_LEGACY_SKILL_NAME),
                    },
                ))
    else:
        plan.warnings.append(
            "CLAUDE.md absent; skipping the directive-update step. "
            "Most projects have one; verify this is intentional."
        )

    plan.is_clean = not plan.steps and not plan.warnings
    return plan


# ---------------------------------------------------------------------------
# Schema translation
# ---------------------------------------------------------------------------

def _derive_project_name(project_dir: Path | None, legacy: dict[str, Any]) -> str:
    """Best-effort guess at the project name for docs-repo derivation.

    Order: ``repos.public`` basename (authoritative), then
    ``repos.private`` basename with trailing ``-dev`` stripped, then
    ``project_dir.name``, then empty. ``repos.public`` wins because
    it's the operator-curated identity in the config and matches the
    convention scaffold_project follows; the project_dir name is a
    last-resort fallback (which in tests is a random tmp dir).
    Empty string means the caller cannot synthesize a docs-repo name
    and should skip the step. (G6)
    """
    repos = legacy.get("repos") or {}
    public = repos.get("public", "") or ""
    if "/" in public:
        return public.split("/", 1)[1]
    private = repos.get("private", "") or ""
    if "/" in private:
        name = private.split("/", 1)[1]
        if name.endswith("-dev"):
            name = name[: -len("-dev")]
        return name
    if project_dir is not None and project_dir.name:
        return project_dir.name
    return ""


def _translate_config_schema(
    legacy: dict[str, Any], *, project_dir: Path | None = None,
) -> dict[str, Any]:
    """Convert a 2.x ``github-config.json`` dict into a 3.0
    ``forge-config.json`` shape.

    The 2.x shape (per ``models.GithubConfig``):

        {
          "owner": "...",
          "repos": {"private": "...", "public": "..."},
          "project_id": "...",
          "session_lock_discussion_id": "...",
          "project_discussion_id": "...",
          ...
        }

    The 3.0 shape adds a ``platforms`` list so multiple backends can
    coexist. The legacy GitHub config becomes the initial entry; the
    rest of the legacy fields stay at the top level for backward
    compatibility (some still apply project-wide rather than
    per-platform).
    """
    translated = dict(legacy)
    # Skill rename — 2.x configs literally store "active-claude-github"
    # in the `skill` field. The 3.0+ Literal accepts both names so the
    # config still validates pre-migration; this rewrite gets every
    # post-migrated config onto the canonical 3.0 name. (G1)
    if translated.get("skill") == "active-claude-github":
        translated["skill"] = "forge-manager"
    # Initial platform = GitHub, populated from the legacy fields.
    github_platform: dict[str, Any] = {
        "id": "github",
        "owner": legacy.get("owner", ""),
    }
    repos = legacy.get("repos") or {}
    if "private" in repos:
        github_platform["private"] = repos["private"]
    if "public" in repos:
        github_platform["public"] = repos["public"]
    if "docs" in repos:
        github_platform["docs"] = repos["docs"]
    translated["platforms"] = [github_platform]
    # 3.0 adds replication_order — local first, then GitHub.
    translated.setdefault("replication_order", ["local", "github"])
    # Schema version field for future compatibility.
    translated["schema_version"] = "3.0"
    # public_face default (#280): when repos.public is set, choose the
    # first non-`local` entry in replication_order. For freshly-migrated
    # 2.x configs this is "github", preserving 2.x behavior. Operators
    # who flip to forgejo / gitlab as the public face edit this field
    # in the post-migration forge-config.json directly.
    if "public_face" not in translated and repos.get("public"):
        non_local = [
            pid for pid in translated["replication_order"] if pid != "local"
        ]
        if non_local:
            translated["public_face"] = non_local[0]
    # Synthesize repos.docs + docs_repo_path so a 2.x → 3.0 migration
    # leaves the operator with a SiteRenderer-ready config (G6). The
    # local docs path mirrors what scaffold_project (Gap A) writes —
    # but $FORGE_MANAGER_DOCS_REPO wins over the convention if the
    # operator has set it (FIX-5). That env var is the documented
    # override for the SiteRenderer's resolver, so the migrated
    # config should respect it rather than silently overwrite to the
    # default.
    project_name = _derive_project_name(project_dir, legacy)
    if project_name:
        repos = dict(translated.get("repos") or {})
        if "docs" not in repos:
            owner = legacy.get("owner") or ""
            if owner:
                repos["docs"] = f"{owner}/{project_name}-docs"
        translated["repos"] = repos
        env_override = os.environ.get("FORGE_MANAGER_DOCS_REPO", "").strip()
        if env_override:
            docs_path = str(Path(env_override).expanduser().resolve())
        else:
            docs_path = str((Path.home() / f"{project_name}-docs").resolve())
        translated.setdefault("docs_repo_path", docs_path)
    return translated
