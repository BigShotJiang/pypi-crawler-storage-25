"""Validate the layout and frontmatter of a forge-manager skill (#140).

CI gate that runs on every PR touching skill prose, scaffold_project,
release_project, or README. Catches the class of bugs surfaced by the
1.4.x release cycle: prose claims a behavior, install/load doesn't
deliver, unit tests don't see it because they don't exercise the
install path.

This validator implements the lighter "parse frontmatter + verify
structure" path from #140's open implementation questions; the
headless-Claude-Code path is deferred to a follow-up.

Checks performed:

1. ``SKILL.md`` exists at the skill directory root.
2. SKILL.md has YAML frontmatter (delimited by ``---`` lines), with
   required keys ``name`` and ``description``, both non-empty.
3. Every required topic file exists in the same directory:
   bootstrap, classification, commit-rules, multi-repo, recording,
   release, tools.
4. Gate-registry anchor resolution (#287): when ``gates.yaml`` and
   ``processes.yaml`` are present, every ``location`` /
   ``rationale_doc`` field is parsed as ``<topic-file>#<anchor>``;
   the topic file must exist; the anchor must appear either as
   ``{#anchor}`` after a markdown heading or as
   ``<a id="anchor">`` somewhere in the file.

Run as ``python -m forge_manager_mcp.skill_validator``.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Sequence


REQUIRED_TOPICS: tuple[str, ...] = (
    "bootstrap.md",
    "classification.md",
    "commit-rules.md",
    "multi-repo.md",
    "recording.md",
    "release.md",
    "tools.md",
)

REQUIRED_FRONTMATTER_KEYS: tuple[str, ...] = ("name", "description")

DEFAULT_SKILL_DIR = Path(".claude/skills/forge-manager")

# Matches both `## Heading {#anchor-id}` and `<a id="anchor-id">`.
_HEADING_ANCHOR_RE = re.compile(r"\{#([A-Za-z0-9_.\-]+)\}")
_HTML_ANCHOR_RE = re.compile(r"""<a\s+id\s*=\s*["']([A-Za-z0-9_.\-]+)["']""")


class ValidationError(Exception):
    """Raised when a skill-validator check fails."""


def parse_frontmatter(content: str) -> dict[str, str]:
    """Extract a SKILL.md's YAML frontmatter as a flat key/value dict.

    Frontmatter is the block between the opening ``---`` line at the
    very start of the file and the next ``---`` line. Lines inside
    are parsed as ``key: value`` pairs; blank lines and lines without
    a colon are skipped. Values are trimmed.

    Raises ``ValidationError`` if frontmatter is missing or unterminated.
    """
    if not content.startswith("---\n"):
        raise ValidationError(
            "missing YAML frontmatter (file must start with `---`)"
        )
    end = content.find("\n---\n", 4)
    if end == -1:
        raise ValidationError("frontmatter not terminated by `---`")
    block = content[4:end]
    keys: dict[str, str] = {}
    for line in block.split("\n"):
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        keys[k.strip()] = v.strip()
    return keys


def validate_skill(skill_dir: Path) -> None:
    """Validate a skill directory's layout and SKILL.md frontmatter.

    Raises ``ValidationError`` on the first failure. Caller maps the
    raised message to a CI-friendly diagnostic.
    """
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        raise ValidationError(f"SKILL.md not found at {skill_md}")

    content = skill_md.read_text(encoding="utf-8")
    keys = parse_frontmatter(content)

    for required in REQUIRED_FRONTMATTER_KEYS:
        if required not in keys:
            raise ValidationError(
                f"frontmatter missing required key: {required!r}"
            )
        if not keys[required]:
            raise ValidationError(
                f"frontmatter key {required!r} is empty"
            )

    for topic in REQUIRED_TOPICS:
        path = skill_dir / topic
        if not path.exists():
            raise ValidationError(f"required topic file missing: {topic}")

    validate_registry_anchors(skill_dir)


def collect_anchors(text: str) -> set[str]:
    """Return every anchor ID declared in a topic-file body.

    Recognizes two forms:

    * ``{#anchor-id}`` after a Markdown heading (Pandoc / kramdown
      convention; rendered as the heading's anchor by GitHub's
      Primer-themed Markdown view).
    * ``<a id="anchor-id">`` anywhere in the file (HTML inline anchor,
      used when a heading isn't the natural attachment point — e.g.,
      table rows where each row needs a stable target).
    """
    found: set[str] = set()
    found.update(_HEADING_ANCHOR_RE.findall(text))
    found.update(_HTML_ANCHOR_RE.findall(text))
    return found


def validate_registry_anchors(skill_dir: Path) -> None:
    """Verify every gates.yaml / processes.yaml anchor resolves (#287).

    Both files are optional; absent means there is nothing to check.
    A malformed YAML registry surfaces as a :class:`ValidationError`
    via the gate-registry loader's own error.

    Implementation note: this module imports the gate registry lazily
    so the validator can run without the loader's transitive deps
    (pydantic) when no registry files exist.
    """
    gates_path = skill_dir / "gates.yaml"
    processes_path = skill_dir / "processes.yaml"
    if not gates_path.exists() and not processes_path.exists():
        return

    # Lazy import — keeps the validator runnable in environments
    # where the registry's dependencies aren't installed (e.g. a
    # plain Python checkout running just the layout check).
    try:
        from . import gate_registry as _gr
    except ImportError as exc:  # pragma: no cover — DEFENSIVE: gate_registry is a sibling module always shipped with the package; ImportError indicates a partial install corruption that doesn't happen under the wheel-smoke gate.
        raise ValidationError(
            f"gate registry present but loader unavailable: {exc}"
        ) from exc

    references: list[tuple[str, str]] = []
    if gates_path.exists():
        try:
            registry = _gr.load_gates(gates_path)
        except _gr.GateRegistryError as exc:
            raise ValidationError(f"gates.yaml: {exc}") from exc
        for gate in registry.list_gates():
            references.append(("location", gate.location))
            references.append(("rationale_doc", gate.rationale_doc))

    if processes_path.exists():
        try:
            proc_registry = _gr.load_processes(processes_path)
        except _gr.GateRegistryError as exc:
            raise ValidationError(f"processes.yaml: {exc}") from exc
        for proc in proc_registry.list_processes():
            references.append(("location", proc.location))
            references.append(("rationale_doc", proc.rationale_doc))
            for step in proc.steps:
                references.append((f"steps[{step.id}].location", step.location))

    # Group anchors by file so we read each file at most once.
    by_file: dict[str, list[tuple[str, str]]] = {}
    for field, ref in references:
        if "#" not in ref:
            raise ValidationError(
                f"gate-registry {field}={ref!r}: missing `#anchor` segment"
            )
        file_part, anchor = ref.split("#", 1)
        by_file.setdefault(file_part, []).append((field, anchor))

    for file_part, expected in by_file.items():
        topic_path = skill_dir / file_part
        if not topic_path.exists():
            raise ValidationError(
                f"gate-registry references missing topic file: {file_part}"
            )
        anchors = collect_anchors(topic_path.read_text(encoding="utf-8"))
        for field, anchor in expected:
            if anchor not in anchors:
                raise ValidationError(
                    f"gate-registry {field}={file_part}#{anchor}: "
                    f"anchor not declared in {file_part}"
                )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="forge_manager_mcp.skill_validator",
        description=(
            "Validate forge-manager skill layout (#140). "
            "Exits 0 on success, 1 on validation failure."
        ),
    )
    parser.add_argument(
        "--skill-dir",
        type=Path,
        default=DEFAULT_SKILL_DIR,
        help="Path to the skill directory (default: %(default)s)",
    )
    args = parser.parse_args(argv)

    try:
        validate_skill(args.skill_dir)
    except ValidationError as exc:
        print(f"::error::{exc}", file=sys.stderr)
        return 1

    print(
        f"OK: {args.skill_dir} validates; "
        f"{len(REQUIRED_TOPICS)} topic files present, "
        f"frontmatter complete"
    )
    return 0


if __name__ == "__main__":  # pragma: no cover — module-script entry; coverage isn't measured across subprocess launches but the module-script path is exercised via subprocess in tests.
    raise SystemExit(main())
