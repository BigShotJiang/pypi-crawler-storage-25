# alephantai-saas-api

Python client for the **Alephant SaaS** HTTP API. Generated with [Fern](https://buildwithfern.com/) from OpenAPI.

## Install

```bash
pip install alephantai-saas-api
```

## Usage

```python
from alephantai_saas import AlephantAi007131Api, AlephantAi007131ApiEnvironment

client = AlephantAi007131Api(
    environment=AlephantAi007131ApiEnvironment.DEFAULT,
    # token="Bearer <your-token>",
)
# client.workspaces.list_workspaces(...)
```

Async client:

```python
from alephantai_saas import AsyncAlephantAi007131Api, AlephantAi007131ApiEnvironment

async_client = AsyncAlephantAi007131Api(environment=AlephantAi007131ApiEnvironment.DEFAULT)
```

Replace the default environment URL with your deployment base URL as needed.

## Regenerating

From `backend-saas-service/fern`:

```bash
npx fern-api@latest generate --group python-sdk --api api
```

After Fern adds new API groups, update the `packages` list in `pyproject.toml` if new top-level folders appear.

## License

MIT
