import requests
from bs4 import BeautifulSoup

from mcp.server.fastmcp import FastMCP


# Initialize FastMCP server
mcp = FastMCP("daum_news_crawler")

@mcp.tool()
def get_crawling(keyword: str, numofpages: int) -> list:
    """
    Daum News titles are collected and stored in a list based on the number of news article pages related to the keywords requested by the user..
    
    Args:
        keyword (str): Keywords requested by users for Daum News search.
        numofpages (int): Number of Daum news pages to collect as requested by the user.
    
    Returns:
        list: Collected Daum News Titles.
    """
    
    base_url = 'https://search.daum.net/search?w=news&nil_search=btn&DA=NTB&enc=utf8&cluster=y&cluster_page=1&q=' + keyword + '&start='    

    naver_crawling = []
    
    for i in range(1, numofpages * 10, 10) :
        url = base_url + str(i)

        response = requests.get(url, headers={'User-Agent':'Moailla/5.0'})

        soup = BeautifulSoup(response.content, 'html.parser')

        headlines = soup.find_all('strong', {'class' : 'tit-g clamp-g'})

        for headline in headlines:
            title = headline.text
            naver_crawling.append(title)

    return Daum_crawling


def main() -> None:
    # Initialize and run the server
    print("Starting Daum News Crawler server...")
    mcp.run(transport='stdio')
    

if __name__ == "__main__":
   main()     