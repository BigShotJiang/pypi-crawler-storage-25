#!/usr/bin/env python3
# claude-gate v0.1.0
import json
import sys
import os
import time
import threading

# Add hooks dir to path so env_loader can be imported
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from env_loader import load_env

from slack_sdk import WebClient
from slack_sdk.socket_mode import SocketModeClient
from slack_sdk.socket_mode.response import SocketModeResponse

SESSION_FLAG         = '/tmp/claude-hook-allow-all'
SESSION_EXPIRY_MINS  = 15

def main():
    # If "Allow All Session" is active and not expired, auto-approve
    if os.path.exists(SESSION_FLAG):
        age_seconds = time.time() - os.path.getmtime(SESSION_FLAG)
        if age_seconds < SESSION_EXPIRY_MINS * 60:
            sys.exit(0)
        else:
            os.remove(SESSION_FLAG)  # expired — remove and ask again

    # Read tool info passed by Claude Code via stdin
    try:
        raw       = sys.stdin.read()
        hook_input = json.loads(raw) if raw.strip() else {}
        tool_name  = hook_input.get('tool_name', 'unknown')
        tool_input = hook_input.get('tool_input', {})
    except Exception:
        tool_name  = 'unknown'
        tool_input = {}

    def truncate(text, limit=300):
        return text[:limit] + ('...' if len(text) > limit else '')

    if tool_name == 'Bash':
        command = tool_input.get('command', '')
        action  = f"*Run bash command:*\n```\n{truncate(command)}\n```"

    elif tool_name == 'Write':
        file_path = tool_input.get('file_path', '')
        content   = tool_input.get('content', '')
        action = (
            f"*Create/overwrite file:*\n`{file_path}`\n\n"
            f"*Content preview:*\n```\n{truncate(content)}\n```"
        )

    elif tool_name == 'Edit':
        file_path  = tool_input.get('file_path', '')
        old_string = tool_input.get('old_string', '')
        new_string = tool_input.get('new_string', '')
        action = (
            f"*Edit file:*\n`{file_path}`\n\n"
            f"*Remove:*\n```\n{truncate(old_string, 150)}\n```\n"
            f"*Replace with:*\n```\n{truncate(new_string, 150)}\n```"
        )

    else:
        action = f"Use tool: `{tool_name}`"

    config    = load_env()
    bot_token = config['SLACK_BOT_TOKEN']
    app_token = config['SLACK_APP_TOKEN']
    user_id   = config['SLACK_USER_ID']

    client = WebClient(token=bot_token)

    result  = client.conversations_open(users=user_id)
    channel = result['channel']['id']

    client.chat_postMessage(
        channel=channel,
        text=f"🤖 Claude needs approval for: {tool_name}",
        blocks=[
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": (
                        f"🤖 *Claude needs your approval*\n\n"
                        f"*Action:* {action}\n\n"
                        f"_(Auto-blocks in 60 seconds if no response)_"
                    )
                }
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "✅  Allow"},
                        "style": "primary",
                        "action_id": "approve",
                        "value": "yes"
                    },
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "🚫  Block"},
                        "style": "danger",
                        "action_id": "deny",
                        "value": "no"
                    },
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "⚡  Allow All Session"},
                        "action_id": "allow_all",
                        "value": "allow_all"
                    }
                ]
            }
        ]
    )

    decision        = [None]
    decision_source = [None]
    decision_event  = threading.Event()

    # ── Thread 1: zenity GUI dialog (laptop) ──
    def wait_for_laptop():
        try:
            import subprocess
            clean_action = action.replace('*', '').replace('`', '').replace('```', '')
            result = subprocess.run(
                [
                    'zenity', '--question',
                    '--title', f'Claude needs approval — {tool_name}',
                    '--text', clean_action,
                    '--ok-label', 'Allow',
                    '--cancel-label', 'Block',
                    '--extra-button', 'Allow All Session',
                    '--width', '500'
                ],
                capture_output=True, text=True
            )
            if not decision_event.is_set():
                if result.returncode == 0:
                    decision[0] = 'yes'
                elif 'Allow All Session' in result.stdout:
                    open(SESSION_FLAG, 'w').close()
                    decision[0] = 'yes'
                else:
                    decision[0] = 'no'
                decision_source[0] = 'laptop'
                decision_event.set()
        except Exception:
            pass

    threading.Thread(target=wait_for_laptop, daemon=True).start()

    # ── Thread 2: Slack Socket Mode (phone) ──
    sm_client = SocketModeClient(app_token=app_token, web_client=client)

    def handle_event(sm, req):
        sm.send_socket_mode_response(SocketModeResponse(envelope_id=req.envelope_id))
        payload = req.payload
        if isinstance(payload, str):
            payload = json.loads(payload)

        for act in payload.get('actions', []):
            if not decision_event.is_set():
                action_id = act.get('action_id')
                if action_id == 'approve':
                    decision[0] = 'yes'
                    decision_source[0] = 'slack'
                    decision_event.set()
                elif action_id == 'deny':
                    decision[0] = 'no'
                    decision_source[0] = 'slack'
                    decision_event.set()
                elif action_id == 'allow_all':
                    open(SESSION_FLAG, 'w').close()
                    decision[0] = 'yes'
                    decision_source[0] = 'slack'
                    decision_event.set()

    sm_client.socket_mode_request_listeners.append(handle_event)
    sm_client.connect()
    decision_event.wait(timeout=60)
    sm_client.close()

    if decision[0] == 'yes':
        if decision_source[0] == 'laptop':
            client.chat_postMessage(channel=channel, text='✅ Approved from laptop! Claude is proceeding.')
        else:
            try:
                tty = open('/dev/tty', 'w')
                tty.write('\n\033[1;92m✅ Approved from Slack! Claude is proceeding.\033[0m\n')
                tty.flush()
                tty.close()
            except Exception:
                pass
        sys.exit(0)

    elif decision[0] == 'no':
        if decision_source[0] == 'laptop':
            client.chat_postMessage(channel=channel, text='🚫 Blocked from laptop! Claude has been stopped.')
        else:
            try:
                tty = open('/dev/tty', 'w')
                tty.write('\n\033[1;91m🚫 Blocked from Slack! Claude has been stopped.\033[0m\n')
                tty.flush()
                tty.close()
            except Exception:
                pass
        print(json.dumps({"decision": "block", "reason": "User denied the action."}))
        sys.exit(1)

    else:
        client.chat_postMessage(channel=channel, text='⏰ No response in 60s. Action blocked automatically.')
        print(json.dumps({"decision": "block", "reason": "Timeout — no response in 60 seconds."}))
        sys.exit(1)

if __name__ == '__main__':
    main()
