# claude-gate

Gate [Claude Code](https://claude.ai/code) tool use behind approvals and control it remotely from your phone via Slack DMs.

## What it does

- **Approval gate** — every Bash, Write, or Edit action Claude takes pops up on your phone as a Slack button. Allow, block, or grant a 15-minute "allow all" session.
- **Remote task execution** — send `!run fix the login bug` from Slack (or a voice message) and Claude Code runs it on your machine, streaming live progress back to you.
- **Interactive sessions** — `!start-session` opens a back-and-forth conversation with Claude directly from Slack.

## Install

```bash
pipx install claude-gate
```

## Setup

**1. Create a Slack app**

Use the included manifest for one-click setup:
- Go to https://api.slack.com/apps → Create New App → From manifest
- Paste the contents of `slack-manifest.yaml` (shown after `cg init`)
- Install the app to your workspace and copy the Bot Token (`xoxb-...`) and App Token (`xapp-...`)

**2. Initialise your project**

Run this from your project root:

```bash
cg init
```

This creates `.claude/` with all hook scripts and settings, then prompts for your tokens.

**3. Verify and start**

```bash
cg doctor   # confirms tokens work
cg up       # starts the daemon (Ctrl+C to stop)
cg up -d    # or run it in the background
```

## Slack commands

| Command | What it does |
|---|---|
| `!run <task>` | Run a Claude Code task (confirm via button) |
| `!start-session` | Open an interactive back-and-forth session |
| `!end-session` | Close the interactive session |
| `!status` | Show what's running and elapsed time |
| `!output [N]` | Dump the last N lines of output |
| `!stop` | Kill the running task |
| `!revoke` | Revoke the "Allow All Session" flag early |
| 🎙️ Voice message | Transcribed via Whisper, confirmed via button |

## CLI reference

```
cg init            Scaffold .claude/ and configure credentials
cg init --adopt    Existing .claude/ setup — just write .env
cg up              Start daemon in foreground
cg up -d           Start daemon detached (background)
cg down            Stop background daemon
cg status          Show daemon status and recent logs
cg logs [-f]       Tail activity and daemon logs
cg doctor          Verify tokens, deps, hook integrity
cg upgrade-hooks   Update hook files from package (backs up yours first)
```

## Requirements

- Python 3.10+
- A Slack workspace where you can install apps
- `claude` CLI installed and authenticated
- `notify-send` for desktop notifications (optional — `sudo apt install libnotify-bin`)
- OpenAI API key for voice message transcription (optional)

## How it works

Claude Code runs hooks before every tool use. The hooks in `.claude/hooks/` post an approval card to your Slack DM and wait for your response. The daemon (`cg up`) listens for incoming Slack messages and spawns `claude --print` subprocesses for remote tasks.

See [CLAUDE.md](CLAUDE.md) for the full architecture.

## License

MIT
