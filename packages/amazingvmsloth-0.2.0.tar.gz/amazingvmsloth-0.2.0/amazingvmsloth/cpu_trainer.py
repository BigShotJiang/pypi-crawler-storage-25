import os
import sys
import time
import gc
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from transformers import PreTrainedModel, PreTrainedTokenizer
from amazingvmsloth.optimizer import create_optimizer
from amazingvmsloth.gradient import GradientAccumulator, enable_gradient_checkpointing, set_gradient_requirements
from amazingvmsloth.packing import SmartCollator, prepack_dataset, BatchCollator


def _detect_cpu_features():
    """Detect CPU capabilities for optimal dtype selection."""
    info = {"avx512_bf16": False, "avx512": False, "avx2": False, "cores": os.cpu_count() or 4}
    try:
        import cpuinfo
        flags = cpuinfo.get_cpu_info().get("flags", [])
        info["avx512_bf16"] = "avx512_bf16" in flags or "avx512bf" in flags
        info["avx512"] = "avx512f" in flags
        info["avx2"] = "av2" in flags
    except Exception:
        pass
    return info


def optimize_cpu():
    if torch.cuda.is_available():
        return False, {}

    # Aggressive thread tuning ------------------------------------------------
    cpu_count = os.cpu_count() or 4
    # Use ALL logical cores for memory-bound transformer workloads
    # (Each core can saturate ~1 memory channel; hyperthreads help prefetch)
    optimal_threads = cpu_count

    # Set BEFORE any PyTorch operations
    torch.set_num_threads(optimal_threads)
    try:
        torch.set_num_interop_threads(1)
    except Exception:
        pass

    os.environ.setdefault("OMP_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("KMP_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("MKL_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("OPENBLAS_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("VECLIB_MAXIMUM_THREADS", str(optimal_threads))
    os.environ.setdefault("NUMEXPR_NUM_THREADS", str(optimal_threads))

    # Intel OpenMP: aggressive affinity to prevent thread migration
    os.environ.setdefault("KMP_AFFINITY", "granularity=fine,compact,1,0")
    os.environ.setdefault("KMP_BLOCKTIME", "0")
    os.environ.setdefault("KMP_SETTINGS", "0")
    os.environ.setdefault("KMP_WARNINGS", "0")
    os.environ.setdefault("OMP_PROC_BIND", "close")
    os.environ.setdefault("OMP_PLACES", "cores")

    # MKL / oneDNN
    try:
        if hasattr(torch.backends, 'mkl') and torch.backends.mkl.is_available():
            torch.backends.mkl.set_num_threads(optimal_threads)
            torch.backends.mkldnn.set_flags(True)
    except Exception:
        pass

    # Prevent denormal slowdowns (can cause 100x slowdowns on CPU)
    try:
        torch.set_flush_denormal(True)
    except Exception:
        pass

    # IPEX detection and optimization
    ipex_available = False
    try:
        import intel_extension_for_pytorch as ipex
        ipex_available = True
    except ImportError:
        pass

    # CPU features
    features = _detect_cpu_features()

    print(f"[amazingvmsloth] CPU Optimization:")
    print(f"  Threads:        {torch.get_num_threads()} (all logical cores)")
    print(f"  AVX-512 BF16:   {'Yes' if features['avx512_bf16'] else 'No'}")
    print(f"  IPEX:           {'Yes (2-4x speedup available)' if ipex_available else 'No (pip install intel-extension-for-pytorch)'}")
    print(f"  Denormal flush: {'Enabled' if hasattr(torch, 'set_flush_denormal') else 'N/A'}")

    return ipex_available, features


@dataclass
class CpuTrainingConfig:
    output_dir: str = "./output"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 16
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    max_grad_norm: float = 1.0
    logging_steps: int = 10
    save_steps: int = 500
    max_seq_length: int = 512
    seed: int = 42
    optim: str = "adamw"
    quant: str = "none"
    compile_model: bool = False  # torch.compile on Windows CPU is risky; use --compile to force
    use_ipex: bool = True
    use_prepacking: bool = True
    dtype: str = "auto"
    gradient_checkpointing: bool = False
    low_ram: bool = False
    max_steps: int = 0


class CpuTrainer:
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        train_dataset,
        config: Optional[CpuTrainingConfig] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.config = config or CpuTrainingConfig()
        self._global_step = 0
        self._start_time = None
        self._trainable_params = []

    def train(self) -> Dict[str, Any]:
        ipex_available, features = optimize_cpu()

        self._setup(ipex_available)

        self._start_time = time.time()
        accumulator = GradientAccumulator(self.config.gradient_accumulation_steps)
        model = self.model
        optimizer = self.optimizer
        scheduler = self.scheduler

        n_batches = len(self.dataloader)
        steps_per_epoch = max(1, (n_batches + self.config.gradient_accumulation_steps - 1) // self.config.gradient_accumulation_steps)
        if self.config.max_steps > 0:
            total_steps = self.config.max_steps
        else:
            total_steps = max(1, steps_per_epoch * self.config.num_train_epochs)

        print(f"\n{'='*60}")
        print(f"  amazingvmsloth CPU Training")
        print(f"{'='*60}")
        print(f"  Model:         {getattr(model, 'name_or_path', 'unknown')}")
        print(f"  Dtype:         {self._dtype}")
        print(f"  Quantization:  {self.config.quant}")
        print(f"  Optimizer:     {self.config.optim}")
        print(f"  Batch size:    {self.config.per_device_train_batch_size}")
        print(f"  Grad accum:    {self.config.gradient_accumulation_steps}")
        print(f"  Threads:       {torch.get_num_threads()}")
        if self.config.max_steps > 0:
            print(f"  Max steps:     {total_steps} (overrides epochs)")
        else:
            print(f"  Total steps:   {total_steps}")
        print(f"{'='*60}\n")

        # Warmup JIT / cache for first few iterations (PyTorch lazy initializes on first call)
        if len(self.dataloader) > 0:
            print("[amazingvmsloth] Warming up CPU caches with dummy forward pass...")
            warmup_batch = next(iter(self.dataloader))
            with torch.no_grad():
                try:
                    _ = model(**warmup_batch)
                except Exception:
                    pass
            print("[amazingvmsloth] Warmup complete\n")

        # torch.compile for CPU (Windows-safe backend)
        if self.config.compile_model and hasattr(torch, "compile"):
            try:
                if sys.platform.startswith("win"):
                    # aot_eager doesn't require Triton / MSVC; still fuses some ops
                    model = torch.compile(model, backend="aot_eager", mode="reduce-overhead")
                    print("[amazingvmsloth] Model compiled with torch.compile (aot_eager, CPU)")
                else:
                    model = torch.compile(model, mode="reduce-overhead")
                    print("[amazingvmsloth] Model compiled with torch.compile (inductor, CPU)")
            except Exception as e:
                print(f"[amazingvmsloth] torch.compile failed: {e}")

        # IPEX optimization if available
        if ipex_available and self.config.use_ipex:
            try:
                import intel_extension_for_pytorch as ipex
                model, optimizer = ipex.optimize(model, optimizer=optimizer, dtype=self._dtype)
                print("[amazingvmsloth] IPEX optimization applied")
            except Exception as e:
                print(f"[amazingvmsloth] IPEX optimization failed: {e}")

        fwd_time = 0.0
        bwd_time = 0.0
        opt_time = 0.0

        # Cache hot-loop values
        accum_should_step = accumulator.should_step
        accum_accumulate = accumulator.accumulate
        accum_reset = accumulator.reset
        grad_accum_steps = self.config.gradient_accumulation_steps
        use_bf16 = self._dtype == torch.bfloat16
        max_grad_norm = self.config.max_grad_norm
        logging_steps = self.config.logging_steps
        num_epochs = self.config.num_train_epochs

        should_stop = False
        for epoch in range(num_epochs):
            if should_stop:
                break
            model.train()
            epoch_loss = 0.0
            step_count = 0
            data_step = 0

            from tqdm import tqdm
            pbar = tqdm(total=steps_per_epoch, desc=f"Epoch {epoch+1}/{num_epochs}", unit="step")

            for batch in self.dataloader:
                data_step += 1

                # Forward pass
                t0 = time.time()
                if use_bf16:
                    with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
                        outputs = model(**batch)
                        loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                else:
                    outputs = model(**batch)
                    loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                t1 = time.time()
                fwd_time += (t1 - t0)

                # Backward pass
                t0 = time.time()
                scaled_loss = accum_accumulate(loss)
                scaled_loss.backward()
                t1 = time.time()
                bwd_time += (t1 - t0)

                if accum_should_step() or data_step == n_batches:
                    t0 = time.time()
                    if max_grad_norm > 0:
                        nn.utils.clip_grad_norm_(
                            self._trainable_params,
                            max_grad_norm,
                        )

                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)
                    t1 = time.time()
                    opt_time += (t1 - t0)

                    self._global_step += 1
                    epoch_loss += accumulator.mean_loss
                    step_count += 1
                    accum_reset()

                    if self.config.max_steps > 0 and self._global_step >= self.config.max_steps:
                        print(f"\n[amazingvmsloth] Max steps reached ({self.config.max_steps}). Stopping training.")
                        should_stop = True
                        break

                    # Update progress bar with live loss
                    avg_loss = epoch_loss / max(step_count, 1)
                    pbar.set_postfix({
                        "loss": f"{avg_loss:.4f}",
                        "batch": f"{data_step}/{n_batches}",
                        "fwd": f"{fwd_time/max(step_count,1):.1f}s",
                        "bwd": f"{bwd_time/max(step_count,1):.1f}s"
                    })

                    if self._global_step % logging_steps == 0:
                        elapsed = time.time() - self._start_time
                        steps_per_sec = self._global_step / elapsed if elapsed > 0 else 0
                        lr = scheduler.get_last_lr()[0]
                        remaining = total_steps - self._global_step
                        eta = remaining / steps_per_sec if steps_per_sec > 0 else 0
                        eta_str = f"{int(eta)//60}m{int(eta)%60}s"

                        ram_mb = 0
                        try:
                            import psutil
                            ram_mb = psutil.Process().memory_info().rss / 1024**2
                        except Exception:
                            pass

                        print(
                            f"Epoch [{epoch+1}/{num_epochs}] "
                            f"Step [{self._global_step}/{total_steps}] "
                            f"Loss: {avg_loss:.4f} | "
                            f"LR: {lr:.2e} | "
                            f"Speed: {steps_per_sec:.2f} steps/s | "
                            f"RAM: {ram_mb:.0f}MB | "
                            f"ETA: {eta_str}"
                        )

            pbar.close()

            avg_loss = epoch_loss / max(step_count, 1)
            elapsed = time.time() - self._start_time
            print(f"\nEpoch {epoch+1}/{num_epochs} | Loss: {avg_loss:.4f} | Time: {elapsed:.0f}s")

        self._save()
        total_time = time.time() - self._start_time
        total_opt_steps = self._global_step
        print(f"\n{'='*60}")
        print(f"  CPU Training complete in {total_time:.1f}s ({total_opt_steps} steps)")
        print(f"  Avg FWD/step: {fwd_time/max(total_opt_steps,1):.1f}s")
        print(f"  Avg BWD/step: {bwd_time/max(total_opt_steps,1):.1f}s")
        print(f"  Avg OPT/step: {opt_time/max(total_opt_steps,1):.1f}s")
        print(f"{'='*60}")

        return {"global_step": self._global_step, "training_time": total_time}

    def _setup(self, ipex_available: bool = False):
        torch.manual_seed(self.config.seed)

        # Determine optimal dtype
        if self.config.dtype == "auto":
            # Always try bf16: halves memory bandwidth (the CPU bottleneck)
            try:
                _ = torch.randn(2, 2, dtype=torch.bfloat16)
                self._dtype = torch.bfloat16
                print("[amazingvmsloth] Auto-selected bf16 for CPU (2x memory bandwidth reduction)")
            except Exception:
                self._dtype = torch.float32
                print("[amazingvmsloth] Auto-selected fp32 for CPU")
        elif self.config.dtype == "bf16":
            self._dtype = torch.bfloat16
        elif self.config.dtype == "fp16":
            self._dtype = torch.float16
        else:
            self._dtype = torch.float32

        # Convert model to optimal dtype if not already
        if self._dtype != torch.float32:
            print(f"[amazingvmsloth] Converting model to {self._dtype} for CPU training")
            self.model = self.model.to(self._dtype)

        # CPU: NEVER use gradient checkpointing — memory is not the bottleneck, compute is
        if self.config.gradient_checkpointing:
            print("[amazingvmsloth] WARNING: gradient_checkpointing=True ignored on CPU (it makes training slower)")
        self.config.gradient_checkpointing = False

        # Disable KV-cache during training (saves forward-pass compute + memory)
        if hasattr(self.model, "config") and hasattr(self.model.config, "use_cache"):
            self.model.config.use_cache = False

        set_gradient_requirements(self.model)
        self._trainable_params = [p for p in self.model.parameters() if p.requires_grad]

        pad_id = 0
        if self.tokenizer:
            pad_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id or 0

        # Use pre-packing for CPU too if enabled
        if self.config.use_prepacking:
            from amazingvmsloth.packing import prepack_dataset
            packed = prepack_dataset(self.train_dataset, self.tokenizer, max_seq_length=self.config.max_seq_length)
            print(f"[amazingvmsloth] Pre-packed into {len(packed)} chunks")
            collator = BatchCollator()
            dataset = packed
        else:
            collator = SmartCollator(
                max_seq_length=self.config.max_seq_length,
                pad_token_id=pad_id,
            )
            dataset = self.train_dataset

        self.dataloader = DataLoader(
            dataset,
            batch_size=self.config.per_device_train_batch_size,
            shuffle=True,
            collate_fn=collator,
            num_workers=0,
            pin_memory=False,
        )

        self.optimizer = create_optimizer(
            self.model,
            optimizer_type=self.config.optim,
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
        )

        from transformers import get_cosine_schedule_with_warmup
        total_steps = max(1, len(self.dataloader) * self.config.num_train_epochs // self.config.gradient_accumulation_steps)
        warmup = max(1, int(total_steps * self.config.warmup_ratio))
        self.scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup,
            num_training_steps=total_steps,
        )

    def _save(self):
        os.makedirs(self.config.output_dir, exist_ok=True)
        model_to_save = self.model

        # Save with fallback for shared tensors
        try:
            if hasattr(model_to_save, "save_pretrained"):
                model_to_save.save_pretrained(self.config.output_dir, safe_serialization=True)
        except RuntimeError as e:
            if "shared tensors" in str(e):
                state_dict = model_to_save.state_dict()
                seen = set()
                clean_dict = {}
                for k, v in state_dict.items():
                    if k not in seen:
                        clean_dict[k] = v
                        seen.add(k)
                torch.save(clean_dict, os.path.join(self.config.output_dir, "model.pt"))
                print(f"  Model state dict saved")
            else:
                raise

        if self.tokenizer:
            self.tokenizer.save_pretrained(self.config.output_dir)

        from amazingvmsloth.lora import get_lora_state_dict
        lora_dict = get_lora_state_dict(model_to_save)
        if lora_dict:
            torch.save(lora_dict, os.path.join(self.config.output_dir, "lora_weights.pt"))

        print(f"  Model saved to {self.config.output_dir}")
