"""
Tests for Nitro Plugins.
"""
