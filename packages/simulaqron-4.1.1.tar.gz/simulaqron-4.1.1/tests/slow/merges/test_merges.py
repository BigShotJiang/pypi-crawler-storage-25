import sys
from pathlib import Path

import os
import unittest
import logging
from typing import Callable, List

import numpy as np

from twisted.spread import pb
from twisted.internet.defer import inlineCallbacks

from multiprocess.context import ForkProcess as Process
from multiprocess.connection import Pipe, Connection
from logging import DEBUG
from simulaqron.general.host_config import SocketsConfig
from simulaqron.math import assemble_qubit
from simulaqron.local.setup import setup_local
from simulaqron.network import Network
from simulaqron.settings import simulaqron_settings, network_config
from simulaqron.settings.network_config import NodeConfigType
from simulaqron.settings.simulaqron_config import SimBackend
from simulaqron.toolbox.stabilizer_states import StabilizerState
from simulaqron.reactor import reactor

_logger = logging.getLogger("test_merges")

# Diego Rivera: 2026-01-16:
# Note about moving these tests to NetQASM API.
# NetQASM is a library that needs to be implemented by the simulators. It also
# aims to be a higher-level abstraction layer, so it does not expose implementation
# details from the underlying quantum simulator.
# On the other hand, these tests aim to check the functionality of merging two
# qubits into a single register. This functionality *is specific to the SimulaQron
# simulator*, since it is required to allow quantum simulation distributed in
# multiple hosts.
# Being this said, I see two main difficulties to move these tests to NetQASM API:
# * Since NetQASM aims to hide all implementation details, there is no NetQASM
#   primitive to express "moving a qubit from one host to another".
# * The functionality tested here is SimulaQron-specific. It would be difficult
#   to rewrite these tests in NetQASM, which might hide APIs needed to fully test
#   the underlying functionality.
# Stephanie: 2026-03-08
# There is no point in moving this test to netqasm: this is is not the role of netqasm here
# best refer to the documentaiton or the simulaqron paper of what the architeture of simulaqron
# is. And in this architecture the merge is done by the simulaqron backend always, I dont get
# why one would consider moving this to netqasm. It's something that only happens for simulated
# qubits. One can, however, make a similar test through the netqasm interface in addition to this one
# and this may be valuable. But this does not mean making merges. The below also doesnt make
# manual merges: rather it takes actions that will trigger a merge in the backend.


class localNode(pb.Root):
    def __init__(self, node, classicalNet):
        self.node = node
        self.classicalNet = classicalNet

        self.virtRoot = None
        self.qReg = None

        self.num_qubits_received = 0

    def set_virtual_node(self, virtRoot):
        self.virtRoot = virtRoot

    def set_virtual_reg(self, qReg):
        self.qReg = qReg

    # This can be called by Alice or Bob to tell Charlie where to get the qubit and what to do next
    @inlineCallbacks
    def remote_receive_two_qubits(self, virtualNum):
        """
        Recover the qubit from Alice. We should now have a tripartite GHZ state

        Arguments
        virtualNum	number of the virtual qubit corresponding to the EPR pair received
        """

        _logger.debug("LOCAL %s: Getting reference to qubit number %d.", self.node.name, virtualNum)

        if self.num_qubits_received == 0:
            self.q1 = yield self.virtRoot.callRemote("get_virtual_ref", virtualNum)
            self.num_qubits_received += 1
            return True
        else:
            self.q2 = yield self.virtRoot.callRemote("get_virtual_ref", virtualNum)
            correct = yield from self.got_both()
            return correct

    @inlineCallbacks
    def got_both(self):
        """
        Recover the qubit from Bob. We should now have a tripartite GHZ state

        Arguments
        virtualNum	number of the virtual qubit corresponding to the EPR pair received
        """

        _logger.debug("LOCAL %s: Got both qubits from Alice and Bob.", self.node.name)

        # We'll test an operation that will cause a merge of the two remote registers
        yield self.q1.callRemote("apply_H")
        yield self.q1.callRemote("cnot_onto", self.q2)

        if simulaqron_settings.sim_backend == SimBackend.QUTIP:
            # Output state
            (realRho, imagRho) = yield self.virtRoot.callRemote("get_multiple_qubits", [self.q1, self.q2])
            rho = assemble_qubit(realRho, imagRho)
            expectedRho = [[0.5, 0, 0, 0.5], [0, 0, 0, 0], [0, 0, 0, 0], [0.5, 0, 0, 0.5]]
            correct = np.all(np.isclose(rho, expectedRho))
        elif simulaqron_settings.sim_backend == SimBackend.PROJECTQ:
            _, (realvec, imagvec) = yield self.virtRoot.callRemote("get_register_RI", self.q1)
            state = [r + (1j * j) for r, j in zip(realvec, imagvec)]
            expectedState = [1 / np.sqrt(2), 0, 0, 1 / np.sqrt(2)]
            correct = np.all(np.isclose(state, expectedState))
        elif simulaqron_settings.sim_backend == SimBackend.STABILIZER:
            (array, _) = yield self.virtRoot.callRemote("get_register_RI", self.q1)
            state = StabilizerState(array)
            expectedState = StabilizerState([[1, 1, 0, 0], [0, 0, 1, 1]])
            correct = state == expectedState
        else:
            ValueError(f"Unknown backend {simulaqron_settings.sim_backend}")

        return bool(correct)

    # This can be called by Alice to tell Bob where to get the qubit and what corrections to apply
    @inlineCallbacks
    def remote_receive_one_qubit(self, virtualNum, cnot_direction=0):
        """
        Recover the qubit from teleportation.

        Arguments
        a,b		received measurement outcomes from Alice
        virtualNum	number of the virtual qubit corresponding to the EPR pair received
        """

        _logger.debug("LOCAL %s: Getting reference to qubit number %d.", self.node.name, virtualNum)

        # Get a reference to our side of the EPR pair
        qA = yield self.virtRoot.callRemote("get_virtual_ref", virtualNum)

        # Create a fresh qubit
        q = yield self.virtRoot.callRemote("new_qubit_inreg", self.qReg)

        # Create the GHZ state by entangling the fresh qubit
        if cnot_direction == 0:
            yield qA.callRemote("apply_H")
            yield qA.callRemote("cnot_onto", q)
        else:
            yield q.callRemote("apply_H")
            yield q.callRemote("cnot_onto", qA)

        if simulaqron_settings.sim_backend == SimBackend.QUTIP:
            # Output state
            (realRho, imagRho) = yield self.virtRoot.callRemote("get_multiple_qubits", [qA, q])
            rho = assemble_qubit(realRho, imagRho)
            expectedRho = [[0.5, 0, 0, 0.5], [0, 0, 0, 0], [0, 0, 0, 0], [0.5, 0, 0, 0.5]]
            correct = np.all(np.isclose(rho, expectedRho))
        elif simulaqron_settings.sim_backend == SimBackend.PROJECTQ:
            _, (realvec, imagvec) = yield self.virtRoot.callRemote("get_register_RI", qA)
            state = [r + (1j * j) for r, j in zip(realvec, imagvec)]
            expectedState = [1 / np.sqrt(2), 0, 0, 1 / np.sqrt(2)]
            correct = np.all(np.isclose(state, expectedState))
        elif simulaqron_settings.sim_backend == SimBackend.STABILIZER:
            (array, _) = yield self.virtRoot.callRemote("get_register_RI", qA)
            state = StabilizerState(array)
            expectedState = StabilizerState([[1, 1, 0, 0], [0, 0, 1, 1]])
            correct = state == expectedState
        else:
            ValueError(f"Unknown backend {simulaqron_settings.sim_backend}")

        return bool(correct)


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestMerge(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.nodes = []
        cls.node_codes = []

        cls.processes = []
        cls.processes_to_wait_for = None
        simulaqron_settings.default_settings()
        simulaqron_settings.sim_backend = SimBackend.PROJECTQ

        path_to_here = os.path.dirname(os.path.abspath(__file__))
        network_config_file = os.path.join(path_to_here, "configs", "network.json")
        network_config.read_from_file(network_config_file)
        nodes = ["Alice", "Bob", "Charlie"]
        cls.network = Network(nodes=nodes, network_config_file=Path(network_config_file))
        cls.network.start()

    @classmethod
    def tearDownClass(cls):
        for p in cls.processes:
            p.terminate()
            p.join()

        cls.network.stop()

    @staticmethod
    def setup_node(name: str, node_code: Callable, nodes_in_classical_network: List[str], send_end: Connection):
        if simulaqron_settings.log_level == DEBUG:
            stdout_file = open(f"stdout-setup-node-{name}-{os.getpid()}.out.txt", "w")
            stderr_file = open(f"stderr-setup-node-{name}-{os.getpid()}.out.txt", "w")
            sys.stdout = stdout_file
            sys.stderr = stderr_file
        # We get the virtual nodes network configuration from the loaded network config
        virtualNet = SocketsConfig(network_config, config_type=NodeConfigType.VNODE)

        # We get the classical nodes network configuration from the loaded network config
        classicalNet = SocketsConfig(network_config, config_type=NodeConfigType.APP)

        # We also filter the nodes that will participate in the classical network, so we don't
        # start local nodes unnecessarily
        classicalNet.filter(nodes_in_classical_network)

        # Check if we should run a local classical server. If so, initialize the code
        # to handle remote connections on the classical communication network
        if name in classicalNet.hostDict:
            lNode = localNode(classicalNet.hostDict[name], classicalNet)
        else:
            lNode = None

        # Set up the local classical server if applicable, and connect to the virtual
        # node and other classical servers. Once all connections are set up, this will
        # execute the function runClientNode
        setup_local(name, virtualNet, classicalNet, lNode, node_code, send_end)

    def run_test(self, nodes_in_class_network: List[str]):
        pipe_list = []
        for node_name, node_code in zip(self.nodes, self.node_codes):
            recv_end, send_end = Pipe(False)
            p = Process(target=self.setup_node,
                        args=[node_name, node_code, nodes_in_class_network, send_end],
                        name=node_name)
            self.processes.append(p)
            pipe_list.append(recv_end)

        for p in self.processes:
            p.start()

        if self.processes_to_wait_for is None:
            for p in self.processes:
                p.join()
        else:
            for i in self.processes_to_wait_for:
                self.processes[i].join()
        results = [pipe.recv() for pipe in pipe_list]
        self.assertTrue(all(results))


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestBothLocal(TestMerge):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.nodes = ["Alice"]
        cls.node_codes = [cls.alice]

    @classmethod
    @inlineCallbacks
    def alice(cls, qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create 2 qubits
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)
        qB = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # Put qubits A and B in an EPR state
        yield qA.callRemote("apply_H")
        yield qA.callRemote("cnot_onto", qB)

        if simulaqron_settings.sim_backend == SimBackend.QUTIP:
            # Output state
            (realRho, imagRho) = yield virtRoot.callRemote("get_multiple_qubits", [qA, qB])
            rho = assemble_qubit(realRho, imagRho)
            expectedRho = [[0.5, 0, 0, 0.5], [0, 0, 0, 0], [0, 0, 0, 0], [0.5, 0, 0, 0.5]]
            correct = np.all(np.isclose(rho, expectedRho))
        elif simulaqron_settings.sim_backend == SimBackend.PROJECTQ:
            (_, (realvec, imagvec), _, _, _) = yield virtRoot.callRemote("get_register", qA)
            state = [r + (1j * j) for r, j in zip(realvec, imagvec)]
            expectedState = [1 / np.sqrt(2), 0, 0, 1 / np.sqrt(2)]
            correct = np.all(np.isclose(state, expectedState))
        elif simulaqron_settings.sim_backend == SimBackend.STABILIZER:
            (array, _, _, _, _) = yield virtRoot.callRemote("get_register", qA)
            state = StabilizerState(array)
            expectedState = StabilizerState([[1, 1, 0, 0], [0, 0, 1, 1]])
            correct = state == expectedState
        else:
            ValueError(f"Unknown backend {simulaqron_settings.sim_backend}")

        send_end.send(correct)

        reactor.stop()

    def test(self):
        # Original arg: "Alice.cfg" -> specifies NO node in the classical network
        self.run_test([])


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestBothLocalNotSameReg(TestBothLocal):
    @classmethod
    @inlineCallbacks
    def alice(cls, qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)
        # Create a second register
        newReg = yield virtRoot.callRemote("add_register")

        # Create 2 qubits
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)
        qB = yield virtRoot.callRemote("new_qubit_inreg", newReg)

        # Put qubits A and B in an EPR state
        yield qA.callRemote("apply_H")
        yield qA.callRemote("cnot_onto", qB)

        if simulaqron_settings.sim_backend == SimBackend.QUTIP:
            # Output state
            (realRho, imagRho) = yield virtRoot.callRemote("get_multiple_qubits", [qA, qB])
            rho = assemble_qubit(realRho, imagRho)
            expectedRho = [[0.5, 0, 0, 0.5], [0, 0, 0, 0], [0, 0, 0, 0], [0.5, 0, 0, 0.5]]
            correct = np.all(np.isclose(rho, expectedRho))
        elif simulaqron_settings.sim_backend == SimBackend.PROJECTQ:
            (_, (realvec, imagvec), _, _, _) = yield virtRoot.callRemote("get_register", qA)
            state = [r + (1j * j) for r, j in zip(realvec, imagvec)]
            expectedState = [1 / np.sqrt(2), 0, 0, 1 / np.sqrt(2)]
            correct = np.all(np.isclose(state, expectedState))
        elif simulaqron_settings.sim_backend == SimBackend.STABILIZER:
            (array, _, _, _, _) = yield virtRoot.callRemote("get_register", qA)
            state = StabilizerState(array)
            expectedState = StabilizerState([[1, 1, 0, 0], [0, 0, 1, 1]])
            correct = state == expectedState
        else:
            ValueError(f"Unknown backend {simulaqron_settings.sim_backend}")

        send_end.send(correct)

        reactor.stop()


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestBothRemote(TestMerge):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.nodes = ["Alice", "Bob", "Charlie"]
        cls.node_codes = [cls.alice, cls.bob, cls.charlie]
        cls.processes_to_wait_for = [0, 1]  # Don't wait for charlie

    @staticmethod
    @inlineCallbacks
    def alice(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create qubit
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # Instruct the virtual node to transfer the qubit
        remoteNum = yield virtRoot.callRemote("send_qubit", qA, "Charlie")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNum)

        # Tell Charlie the number of the virtual qubit so the can use it locally
        # and extend it to a GHZ state with Charlie
        charlie = classicalNet.hostDict["Charlie"]
        correct = yield charlie.root.callRemote("receive_two_qubits", remoteNum)

        send_end.send(correct)

        reactor.stop()

    @staticmethod
    @inlineCallbacks
    def bob(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create qubits
        qB = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # Instruct the virtual node to transfer the qubit
        remoteNum = yield virtRoot.callRemote("send_qubit", qB, "Charlie")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNum)

        # Tell Charlie the number of the virtual qubit so the can use it locally
        # and extend it to a GHZ state with Charlie
        charlie = classicalNet.hostDict["Charlie"]
        correct = yield charlie.root.callRemote("receive_two_qubits", remoteNum)

        send_end.send(correct)

        reactor.stop()

    @staticmethod
    def charlie(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execture for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)
        send_end.send(True)

    def test(self):
        # Original arg: "AliceBobCharlie.cfg" -> specifies "Alice", "Bob", and "Charlie" in the classical network
        self.run_test(["Alice", "Bob", "Charlie"])


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestBothRemoteSameNodeDiffReg(TestMerge):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.nodes = ["Alice", "Bob"]
        cls.node_codes = [cls.alice, cls.bob]
        cls.processes_to_wait_for = [0]  # Don't wait for charlie

    @staticmethod
    @inlineCallbacks
    def alice(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create new register
        newReg = yield virtRoot.callRemote("new_register")

        # Create 2 qubits
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)
        qB = yield virtRoot.callRemote("new_qubit_inreg", newReg)

        # Instruct the virtual node to transfer the qubit
        remoteNumA = yield virtRoot.callRemote("send_qubit", qA, "Bob")
        remoteNumB = yield virtRoot.callRemote("send_qubit", qB, "Bob")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNumA)
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNumB)

        # Tell Charlie the number of the virtual qubit so the can use it locally
        # and extend it to a GHZ state with Charlie
        bob = classicalNet.hostDict["Bob"]
        correct1 = yield bob.root.callRemote("receive_two_qubits", remoteNumA)
        correct2 = yield bob.root.callRemote("receive_two_qubits", remoteNumB)
        correct = correct1 and correct2

        send_end.send(correct)

        reactor.stop()

    @staticmethod
    def bob(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execture for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)
        send_end.send(True)

    def test(self):
        # Original arg: "AliceBob.cfg" -> specifies "Alice", and "Bob" in the classical network
        self.run_test(["Alice", "Bob"])


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestBothRemoteSameNodeSameReg(TestBothRemoteSameNodeDiffReg):
    @staticmethod
    @inlineCallbacks
    def alice(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create 2 qubits
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)
        qB = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # # Put qubits A and B in an EPR state
        # yield qA.callRemote("apply_H")
        # yield qA.callRemote("cnot_onto", qB)

        # Send qubit B to Bob
        # Instruct the virtual node to transfer the qubit
        remoteNumA = yield virtRoot.callRemote("send_qubit", qA, "Bob")
        remoteNumB = yield virtRoot.callRemote("send_qubit", qB, "Bob")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNumA)
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNumB)

        # Tell Charlie the number of the virtual qubit so the can use it locally
        # and extend it to a GHZ state with Charlie
        bob = classicalNet.hostDict["Bob"]
        correct1 = yield bob.root.callRemote("receive_two_qubits", remoteNumA)
        correct2 = yield bob.root.callRemote("receive_two_qubits", remoteNumB)
        correct = correct1 and correct2

        send_end.send(correct)

        reactor.stop()


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestRemoteAtoB(TestBothRemoteSameNodeDiffReg):
    @staticmethod
    @inlineCallbacks
    def alice(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create qubit
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # Instruct the virtual node to transfer the qubit
        remoteNum = yield virtRoot.callRemote("send_qubit", qA, "Bob")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNum)

        # Tell Bob the number of the virtual qubit so the can use it locally
        bob = classicalNet.hostDict["Bob"]
        correct = yield bob.root.callRemote("receive_one_qubit", remoteNum, cnot_direction=0)

        send_end.send(correct)

        reactor.stop()


#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs refactoring to use NetQASM")
#@pytest.mark.skip(reason="Uses deprecated internal APIs - needs updating to new API")
class TestRemoteBtoA(TestBothRemoteSameNodeDiffReg):
    @staticmethod
    @inlineCallbacks
    def alice(qReg, virtRoot, myName, classicalNet, send_end):
        """
        Code to execute for the local client node. Called if all connections are established.

        Arguments
        qReg		quantum register (twisted object supporting remote method calls)
        virtRoot	virtual quantum ndoe (twisted object supporting remote method calls)
        myName		name of this node (string)
        classicalNet	servers in the classical communication network (dictionary of hosts)
        """

        _logger.debug("LOCAL %s: Runing client side program.", myName)

        # Create qubit
        qA = yield virtRoot.callRemote("new_qubit_inreg", qReg)

        # Instruct the virtual node to transfer the qubit
        remoteNum = yield virtRoot.callRemote("send_qubit", qA, "Bob")
        _logger.debug("LOCAL %s: Remote qubit is %d.", myName, remoteNum)

        # Tell Bob the number of the virtual qubit so the can use it locally
        bob = classicalNet.hostDict["Bob"]
        correct = yield bob.root.callRemote("receive_one_qubit", remoteNum, cnot_direction=1)

        send_end.send(correct)

        reactor.stop()


if __name__ == '__main__':
    unittest.main()
