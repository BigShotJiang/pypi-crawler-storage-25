"""fastapi-taskflow: decorator-driven background tasks with retries and a live dashboard.

Upgrades FastAPI ``BackgroundTasks`` with retries, status tracking, and SQLite
persistence without changing how you enqueue tasks.

Quick start::

    from fastapi import Depends, FastAPI
    from fastapi_taskflow import TaskAdmin, TaskManager

    task_manager = TaskManager(snapshot_db="tasks.db")

    @task_manager.task(retries=3, delay=2.0, backoff=2.0)
    def send_email(address: str) -> None:
        ...

    app = FastAPI()
    TaskAdmin(app, task_manager)  # mounts /tasks routes and manages lifecycle

    @app.post("/signup")
    def signup(email: str, tasks=Depends(task_manager.get_tasks)):
        task_id = tasks.add_task(send_email, email)
        return {"task_id": task_id}
"""

from .admin import TaskAdmin
from .auth import TaskAuthBackend
from .backends import RedisBackend, SnapshotBackend, SqliteBackend
from .executors import TaskExecutionContext
from .executors.process_executor import TaskArgumentError
from .loggers import (
    FileLogger,
    InMemoryLogger,
    LifecycleEvent,
    LogEvent,
    LoggerChain,
    StdoutLogger,
    TaskObserver,
)
from .manager import TaskManager
from .models import TaskConfig, TaskRecord, TaskStatus
from .snapshot import SnapshotScheduler
from .task_logging import TaskContext, get_task_context, task_log
from .wrapper import ManagedBackgroundTasks

__all__ = [
    "TaskAdmin",
    "TaskAuthBackend",
    "TaskManager",
    "ManagedBackgroundTasks",
    "TaskStatus",
    "TaskRecord",
    "TaskConfig",
    "SnapshotScheduler",
    "SnapshotBackend",
    "SqliteBackend",
    "RedisBackend",
    # Executor abstraction
    "TaskExecutionContext",
    "TaskArgumentError",
    # Logging
    "TaskObserver",
    "LogEvent",
    "LifecycleEvent",
    "LoggerChain",
    "FileLogger",
    "InMemoryLogger",
    "StdoutLogger",
    # Task logging
    "task_log",
    "TaskContext",
    "get_task_context",
]

try:
    from importlib.metadata import version as _version

    __version__ = _version("fastapi-taskflow")
except Exception:
    __version__ = "unknown"
