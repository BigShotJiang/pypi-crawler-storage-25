"""Task execution engine.

:func:`execute_task` is the single function responsible for running a task
function through its full lifecycle: status transitions, retry loop,
log capture, and optional persistence on completion.

:func:`make_background_func` wraps ``execute_task`` into a zero-argument
async callable that FastAPI's ``BackgroundTasks`` can call after the response
is sent.

Dispatch is routed through the :class:`~fastapi_taskflow.executors.base.Executor`
protocol so that async, thread, and process execution share a uniform interface.
The concrete executor instance is selected once at enqueue time (in
:class:`~fastapi_taskflow.wrapper.ManagedBackgroundTasks`) and carried through
to this module as the ``executor_obj`` parameter.
"""

import asyncio
import contextvars
import logging
import pickle
import sys
import traceback
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Optional

from .executors.base import TaskExecutionContext
from .models import TaskConfig, TaskStatus
from .store import TaskStore
from .task_logging import (
    TaskContext,
    _log_sink,
    _task_context,
)

if TYPE_CHECKING:
    from .backends.base import SnapshotBackend
    from .executors.base import Executor
    from .loggers.base import TaskObserver

from .loggers.base import LifecycleEvent, LogEvent


def _build_exec_ctx(
    captured_ctx: Optional[contextvars.Context],
    sink_fn: Callable,
    task_ctx: TaskContext,
) -> contextvars.Context:
    """Build an execution context for one task attempt.

    Starts from *captured_ctx* (preserving any trace context from the original
    request) and layers the task-specific ``_log_sink`` and ``_task_context``
    vars on top. When *captured_ctx* is ``None``, starts from a copy of the
    current context instead.

    The returned context is used to run the task function so that:

    * Trace context (OpenTelemetry spans, etc.) flows from the enqueue site
      into the background execution automatically.
    * ``task_log()`` and ``get_task_context()`` work correctly inside the
      task function regardless of whether it is sync or async.

    Args:
        captured_ctx: Context snapshot taken at ``add_task()`` time, or
            ``None`` when no context was captured (e.g. requeue, retry).
        sink_fn: The log sink closure for the current attempt.
        task_ctx: The :class:`~fastapi_taskflow.task_logging.TaskContext` for
            the current attempt.

    Returns:
        A :class:`contextvars.Context` ready to run the task function in.
    """
    result: list[contextvars.Context] = []

    def _setup() -> None:
        _log_sink.set(sink_fn)
        _task_context.set(task_ctx)
        result.append(contextvars.copy_context())

    base = captured_ctx if captured_ctx is not None else contextvars.copy_context()
    base.run(_setup)
    return result[0]


def _schedule_log(
    coro: "Any",
    loop: asyncio.AbstractEventLoop,
    pending: list,
) -> None:
    """Schedule *coro* and append the resulting future to *pending* for later draining.

    When called from the event loop thread, ``create_task`` is used and an
    ``asyncio.Task`` is appended. When called from a thread-pool thread (sync tasks
    run via ``asyncio.to_thread``), ``run_coroutine_threadsafe`` is used and a
    ``concurrent.futures.Future`` is appended. In both cases the caller drains
    *pending* with :func:`_drain_pending` after the task function returns.
    """
    try:
        asyncio.get_running_loop()
        pending.append(asyncio.ensure_future(coro))
    except RuntimeError:
        pending.append(asyncio.run_coroutine_threadsafe(coro, loop))


async def _drain_pending(pending: list) -> None:
    """Await all futures collected by :func:`_schedule_log`, then clear the list.

    ``asyncio.Task`` objects are awaited directly. ``concurrent.futures.Future``
    objects (from thread-pool log events) are wrapped via ``asyncio.wrap_future``
    before awaiting.
    """
    if not pending:
        return
    awaitables = [
        f if isinstance(f, asyncio.Task) else asyncio.wrap_future(f) for f in pending
    ]
    pending.clear()
    await asyncio.gather(*awaitables, return_exceptions=True)


async def execute_task(
    func: Callable,
    task_id: str,
    config: TaskConfig,
    store: TaskStore,
    args: tuple,
    kwargs: dict,
    executor_obj: "Optional[Executor]" = None,
    backend: "Optional[SnapshotBackend]" = None,
    on_success: "Optional[Callable]" = None,
    logger: "Optional[TaskObserver]" = None,
    encryptor: Any = None,
    captured_ctx: Optional[contextvars.Context] = None,
    running_tasks: Optional[dict] = None,
) -> None:
    """Run *func* through the full task lifecycle: PENDING -> RUNNING -> SUCCESS | FAILED.

    Handles the retry loop, records every status transition in *store*, and
    captures :func:`~fastapi_taskflow.task_logging.task_log` entries per attempt.
    The full traceback of the final failure is stored on the task record.

    Dispatch is routed through *executor_obj*, which encapsulates whether the
    function runs as a coroutine, in a thread pool, or in a process pool.
    When *executor_obj* is ``None`` the executor is inferred from the function
    signature (async -> event loop, sync -> thread pool), preserving backward
    compatibility for call sites that have not yet been updated.

    Args:
        func: The task function to run (sync or async).
        task_id: ID of the record already created in *store*.
        config: Retry/delay settings from ``@task_manager.task()``.
        store: The in-memory store where status updates are written.
        args: Positional arguments to pass to *func*. Ignored when the record
            carries an ``encrypted_payload`` and *encryptor* is provided.
        kwargs: Keyword arguments to pass to *func*. Ignored when the record
            carries an ``encrypted_payload`` and *encryptor* is provided.
        executor_obj: Concrete executor that handles the actual function
            dispatch. When ``None``, the legacy implicit dispatch path is used
            (auto-detect from ``asyncio.iscoroutinefunction``).
        backend: When provided, used to check cross-instance idempotency keys
            before running and to record the key on success.
        on_success: Async callable invoked with *task_id* right after SUCCESS.
            Used by the snapshot scheduler to flush the record immediately so
            a crash before the next periodic flush does not cause re-execution.
        logger: When provided, :class:`~fastapi_taskflow.loggers.LogEvent` and
            :class:`~fastapi_taskflow.loggers.LifecycleEvent` objects are
            dispatched to it for every log entry and status transition.
        encryptor: A ``cryptography.fernet.Fernet`` instance. When provided and
            the task record has an ``encrypted_payload``, the payload is decrypted
            to recover the original ``(args, kwargs)`` before calling *func*.
        captured_ctx: ``contextvars`` context snapshot taken at ``add_task()``
            time. When provided, the task function runs inside this context so
            trace context (OpenTelemetry spans, etc.) propagates from the
            originating request into the background execution.
        running_tasks: Shared dict mapping ``task_id`` to the asyncio Task or
            Future currently executing that function. Populated when the task
            enters ``RUNNING`` and removed on completion or cancellation. Used
            by ``POST /tasks/{task_id}/cancel`` to cancel running async tasks.
    """
    await _execute_task_inner(
        func=func,
        task_id=task_id,
        config=config,
        store=store,
        args=args,
        kwargs=kwargs,
        executor_obj=executor_obj,
        backend=backend,
        on_success=on_success,
        logger=logger,
        encryptor=encryptor,
        captured_ctx=captured_ctx,
        running_tasks=running_tasks,
    )


async def _execute_task_inner(
    func: Callable,
    task_id: str,
    config: TaskConfig,
    store: TaskStore,
    args: tuple,
    kwargs: dict,
    executor_obj: "Optional[Executor]" = None,
    backend: "Optional[SnapshotBackend]" = None,
    on_success: "Optional[Callable]" = None,
    logger: "Optional[TaskObserver]" = None,
    encryptor: Any = None,
    captured_ctx: Optional[contextvars.Context] = None,
    running_tasks: Optional[dict] = None,
) -> None:
    """Inner execution body, called by :func:`execute_task`. Not for direct use."""
    record = store.get(task_id)
    func_name = func.__name__
    tags: dict[str, str] = record.tags if record is not None else {}

    # Resolve actual args/kwargs. When encryption is active, the store record
    # holds an encrypted_payload and empty args/kwargs; we decrypt here once.
    if (
        record is not None
        and record.encrypted_payload is not None
        and encryptor is not None
    ):
        actual_args, actual_kwargs = pickle.loads(
            encryptor.decrypt(record.encrypted_payload)
        )
    else:
        actual_args, actual_kwargs = args, kwargs

    # Capture the running event loop now. The sink closure may be called from
    # a thread-pool thread (sync tasks via asyncio.to_thread), so we hold the
    # loop reference to schedule coroutines safely via run_coroutine_threadsafe.
    loop = asyncio.get_running_loop()

    # Cross-instance idempotency check.
    if record is not None and record.idempotency_key and backend is not None:
        try:
            existing_id = await backend.check_idempotency_key(record.idempotency_key)
        except Exception:
            logging.getLogger(__name__).exception(
                "fastapi-taskflow: idempotency key check failed for task %s, "
                "proceeding without deduplication.",
                task_id,
            )
            existing_id = None
        if existing_id is not None and existing_id != task_id:
            store.update(
                task_id,
                status=TaskStatus.SUCCESS,
                start_time=datetime.now(timezone.utc),
                end_time=datetime.now(timezone.utc),
            )
            return

    task_start = datetime.now(timezone.utc)
    store.update(task_id, status=TaskStatus.RUNNING, start_time=task_start)

    if logger is not None:
        await logger.on_lifecycle(
            LifecycleEvent(
                task_id=task_id,
                func_name=func_name,
                status=TaskStatus.RUNNING,
                timestamp=task_start,
                attempt=0,
                retries_used=0,
                tags=tags,
            )
        )

    # _state tracks the current attempt index so the sink closure always
    # attaches the right number to LogEvent objects. A dict avoids Python
    # cell-variable rebinding issues.
    _state: dict[str, int] = {"attempt": 0}

    # Pending log futures: collected by the sink, drained after each attempt
    # so all on_log() calls complete before the lifecycle event fires.
    _pending_log: list = []

    def sink(msg: str, level: str, extra: dict) -> None:
        ts = datetime.now(timezone.utc)
        store.append_log(task_id, f"{ts.strftime('%Y-%m-%dT%H:%M:%S')} {msg}")
        if logger is not None:
            event = LogEvent(
                task_id=task_id,
                func_name=func_name,
                message=msg,
                level=level,
                timestamp=ts,
                attempt=_state["attempt"],
                tags=tags,
                extra=extra,
            )
            _schedule_log(logger.on_log(event), loop, _pending_log)

    delay = config.delay
    last_error: Exception | None = None
    last_tb: str | None = None
    # exec_start default covers the case where CancelledError fires before the
    # first attempt sets it (e.g. during a retry sleep).
    exec_start = task_start
    # Reference to the asyncio Task/Future running the current dispatch.
    # Stored so the cancel endpoint can call .cancel() on it directly.
    _inner_task: Optional[asyncio.Task] = None

    try:
        for attempt in range(config.retries + 1):
            _state["attempt"] = attempt

            if attempt > 0:
                await asyncio.sleep(delay)
                delay *= config.backoff
                store.update(task_id, retries_used=attempt)
                store.append_log(task_id, f"--- Retry {attempt} ---")

            ctx_obj = TaskContext(
                task_id=task_id,
                func_name=func_name,
                attempt=attempt,
                tags=tags,
            )

            # Build an execution context that merges trace context (from captured_ctx)
            # with the task-specific log sink and TaskContext vars. Used by
            # async and thread executors; ignored by the process executor.
            exec_ctx = _build_exec_ctx(captured_ctx, sink, ctx_obj)

            # TaskExecutionContext carries the same fields in a plain-dict-
            # serializable form for cross-process transport by the process executor.
            task_exec_ctx = TaskExecutionContext(
                task_id=task_id,
                func_name=func_name,
                attempt=attempt,
                tags=tags,
            )

            exec_start = datetime.now(timezone.utc)

            try:
                if executor_obj is not None:
                    # Route through the registered executor (async, thread, or process).
                    dispatch_coro = executor_obj.dispatch(
                        func,
                        actual_args,
                        actual_kwargs,
                        task_exec_ctx,
                        exec_ctx,
                        sink,
                        loop,
                    )
                    _inner_task = asyncio.ensure_future(dispatch_coro)
                else:
                    # Legacy implicit dispatch: auto-detect from function signature.
                    # Preserved for backward compatibility with direct execute_task callers.
                    import inspect as _inspect

                    if _inspect.iscoroutinefunction(func):
                        if sys.version_info >= (3, 11):
                            _inner_task = asyncio.create_task(
                                func(*actual_args, **actual_kwargs), context=exec_ctx
                            )
                        else:

                            async def _run_in_ctx() -> None:
                                t1 = _log_sink.set(sink)
                                t2 = _task_context.set(ctx_obj)
                                try:
                                    await func(*actual_args, **actual_kwargs)
                                finally:
                                    _log_sink.reset(t1)
                                    _task_context.reset(t2)

                            _inner_task = asyncio.create_task(_run_in_ctx())
                    else:
                        _inner_task = asyncio.ensure_future(
                            asyncio.to_thread(
                                exec_ctx.run, func, *actual_args, **actual_kwargs
                            )
                        )

                if running_tasks is not None:
                    running_tasks[task_id] = _inner_task
                await _inner_task
                _inner_task = None

                await _drain_pending(_pending_log)

                end_time = datetime.now(timezone.utc)
                store.update(task_id, status=TaskStatus.SUCCESS, end_time=end_time)

                if logger is not None:
                    duration = (end_time - exec_start).total_seconds()
                    await logger.on_lifecycle(
                        LifecycleEvent(
                            task_id=task_id,
                            func_name=func_name,
                            status=TaskStatus.SUCCESS,
                            timestamp=end_time,
                            attempt=attempt,
                            retries_used=attempt,
                            duration=duration,
                            tags=tags,
                        )
                    )

                if on_success is not None:
                    await on_success(task_id)
                if (
                    record is not None
                    and record.idempotency_key
                    and backend is not None
                ):
                    try:
                        await backend.record_idempotency_key(
                            record.idempotency_key, task_id
                        )
                    except Exception:
                        logging.getLogger(__name__).exception(
                            "fastapi-taskflow: failed to record idempotency key for task %s, "
                            "duplicate execution is possible if this task is retried externally.",
                            task_id,
                        )
                return

            except Exception as exc:  # noqa: BLE001
                _inner_task = None
                last_error = exc
                # For process executor tasks, _WorkerException attaches the
                # full worker-side traceback as _worker_traceback so the
                # dashboard error panel shows the complete call stack.
                last_tb = (
                    getattr(exc, "_worker_traceback", None) or traceback.format_exc()
                )

        await _drain_pending(_pending_log)

        end_time = datetime.now(timezone.utc)
        store.update(
            task_id,
            status=TaskStatus.FAILED,
            end_time=end_time,
            error=str(last_error),
            stacktrace=last_tb,
        )

        if logger is not None:
            duration = (end_time - exec_start).total_seconds()
            await logger.on_lifecycle(
                LifecycleEvent(
                    task_id=task_id,
                    func_name=func_name,
                    status=TaskStatus.FAILED,
                    timestamp=end_time,
                    attempt=config.retries,
                    retries_used=config.retries,
                    duration=duration,
                    error=str(last_error),
                    stacktrace=last_tb,
                    tags=tags,
                )
            )

    except asyncio.CancelledError:
        # Cancel the inner dispatch task if it is still running (async tasks).
        # For sync tasks running in a thread pool or process pool, the
        # underlying work cannot be interrupted; cancellation stops the await
        # but the thread or worker runs to completion in the background.
        if _inner_task is not None and not _inner_task.done():
            _inner_task.cancel()
        await _drain_pending(_pending_log)
        end_time = datetime.now(timezone.utc)
        current = store.get(task_id)
        if current is not None and current.status == TaskStatus.RUNNING:
            store.update(task_id, status=TaskStatus.CANCELLED, end_time=end_time)
            if logger is not None:
                duration = (end_time - exec_start).total_seconds()
                await logger.on_lifecycle(
                    LifecycleEvent(
                        task_id=task_id,
                        func_name=func_name,
                        status=TaskStatus.CANCELLED,
                        timestamp=end_time,
                        attempt=_state["attempt"],
                        retries_used=_state["attempt"],
                        duration=duration,
                        tags=tags,
                    )
                )
            if on_success is not None:
                await on_success(task_id)

    finally:
        if running_tasks is not None:
            running_tasks.pop(task_id, None)


def make_background_func(
    func: Callable,
    task_id: str,
    config: TaskConfig,
    store: TaskStore,
    args: tuple,
    kwargs: dict,
    executor_obj: "Optional[Executor]" = None,
    backend: "Optional[SnapshotBackend]" = None,
    on_success: "Optional[Callable]" = None,
    logger: "Optional[TaskObserver]" = None,
    encryptor: Any = None,
    captured_ctx: Optional[contextvars.Context] = None,
    running_tasks: Optional[dict] = None,
) -> Callable:
    """Wrap *func* into a zero-argument async callable for ``BackgroundTasks.add_task``.

    FastAPI's ``BackgroundTasks`` requires callables that take no arguments.
    This closes over all the parameters needed by :func:`execute_task` so
    the wrapper can be handed directly to Starlette.

    Args:
        func: The task function to run.
        task_id: ID of the record created in *store*.
        config: Retry/delay settings.
        store: The in-memory task store.
        args: Positional arguments for *func* (empty when encryption is on).
        kwargs: Keyword arguments for *func* (empty when encryption is on).
        executor_obj: Concrete executor that handles the actual function
            dispatch. Passed through to :func:`execute_task`. ``None``
            triggers the legacy implicit dispatch path.
        backend: Optional snapshot backend for idempotency.
        on_success: Optional callback invoked after SUCCESS.
        logger: Optional observer chain for structured event delivery.
        encryptor: Optional ``Fernet`` instance for decrypting args at run time.
        captured_ctx: Optional ``contextvars`` context snapshot from enqueue time
            for trace context propagation.
        running_tasks: Shared dict forwarded to :func:`execute_task` so the
            executor can register and deregister the inner task handle for
            cancellation support.

    Returns:
        A zero-argument async callable named ``_bg_{func_name}_{task_id[:8]}``.
    """

    async def _wrapped() -> None:
        await execute_task(
            func,
            task_id,
            config,
            store,
            args,
            kwargs,
            executor_obj=executor_obj,
            backend=backend,
            on_success=on_success,
            logger=logger,
            encryptor=encryptor,
            captured_ctx=captured_ctx,
            running_tasks=running_tasks,
        )

    _wrapped.__name__ = f"_bg_{func.__name__}_{task_id[:8]}"
    return _wrapped
