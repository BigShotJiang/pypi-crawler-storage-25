import json
import logging
import os
from typing import Any, Dict, Optional
from .database import DatabaseManager, InferenceLog


logger = logging.getLogger(__name__)

class LoggingService:
    """
    Service responsible for logging inference metadata to either a database or a local file.
    """

    def __init__(self, db_manager: Optional[DatabaseManager] = None, log_file: Optional[str] = None) -> None:
        """
        Initializes the LoggingService with a DatabaseManager and/or a log file path.
        Args:
            db_manager (Optional[DatabaseManager]): The database manager instance for DB logging.
            log_file (Optional[str]): The path to the local file for file-based logging.
        """

        self.db_manager: Optional[DatabaseManager] = db_manager
        self.log_file: Optional[str] = log_file

    def log_inference(self, metadata: Dict[str, Any]) -> None:
        """
        Saves inference metadata to the configured target (database or file).
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if self.db_manager and self.db_manager._initialized:
            self._log_to_db(metadata)
        
        if self.log_file:
            self._log_to_file(metadata)

    def _log_to_db(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save inference metadata to the database using SQLAlchemy.
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if not self.db_manager:
            return

        session: Any = self.db_manager.Session()
        try:
            log_entry = InferenceLog(
                model_name=metadata.get("model_name"),
                timestamp=metadata.get("timestamp"),
                input_tokens=metadata.get("input_tokens"),
                output_tokens=metadata.get("output_tokens"),
                cpu_percent=metadata.get("cpu_percent"),
                ram_usage_percent=metadata.get("ram_usage_percent"),
                gpu_usage_percent=metadata.get("gpu_usage_percent"),
                duration=metadata.get("duration"),
                input=json.dumps(metadata.get("input")),
                output=json.dumps(metadata.get("output")),
                error=metadata.get("error"),
                extra=json.dumps(metadata.get("extra", {}))
            )
            session.add(log_entry)
            session.commit()
        except Exception as e:
            session.rollback()
            print(f"WARNING: Failed to log to database: {e}")
        finally:
            session.close()

    def _log_to_file(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save inference metadata to a local file in JSON lines format.
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if not self.log_file:
            return

        try:
            # Ensure the directory exists
            log_dir = os.path.dirname(self.log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

            with open(self.log_file, "a") as f:
                f.write(json.dumps(metadata) + "\n")
        except Exception as e:
            print(f"WARNING: Failed to log to file {self.log_file}: {e}")
