import json
import logging
from typing import Any, Dict, Optional
from sqlalchemy import create_engine, Column, Integer, String, Float, Text
from sqlalchemy.orm import sessionmaker, declarative_base

logger = logging.getLogger(__name__)

Base = declarative_base()


class InferenceLog(Base):
    __tablename__ = 'inference_logs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String)
    timestamp = Column(String)
    input_tokens = Column(Integer)
    output_tokens = Column(Integer)
    cpu_percent = Column(Float)
    ram_usage_percent = Column(Float)
    gpu_usage_percent = Column(Float, nullable=True)
    duration = Column(Float)
    input = Column(Text)
    output = Column(Text)
    error = Column(Text, nullable=True)
    extra = Column(Text)


class DatabaseManager:
    """
    Manages the database connection and schema initialization using SQLAlchemy.
    """

    def __init__(self, host: str = "localhost", port: int = 5432, user: str = "postgres", password: str = "postgres", dbname: str = "cognitor") -> None:
        """
        Initializes the DatabaseManager with connection parameters.
        Args:
            host (str): The database host address.
            port (int): The database port number.
            user (str): The database username.
            password (str): The database password.
            dbname (str): The name of the database.
        """

        self.db_url: str = f"postgresql://{user}:{password}@{host}:{port}/{dbname}"
        self.engine: Any = create_engine(self.db_url)
        self.Session: Any = sessionmaker(bind=self.engine)
        self._initialized: bool = False

    def init_db(self) -> None:
        """
        Initializes the database schema by creating all defined tables.
        Exits gracefully if the database is unreachable.
        """

        try:
            Base.metadata.create_all(self.engine)
            self._initialized = True
        except Exception as e:
            print(f"CRITICAL: Database unreachable at {self.engine.url}. Error: {e}")
            print("Exiting gracefully...")
            exit(0)
