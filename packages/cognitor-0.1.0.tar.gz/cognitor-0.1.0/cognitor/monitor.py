import time
from typing import Any, Dict, Optional, Union, List
from pydantic import BaseModel
from .utils import get_resource_usage, Timer
from .database import DatabaseManager
from .service import LoggingService
import torch

from .config import config


class InferenceMetadata(BaseModel):
    model_name: str
    timestamp: str
    input_tokens: int
    output_tokens: int
    cpu_percent: float
    ram_usage_percent: float
    gpu_usage_percent: Optional[float] = None
    duration: float
    input: Any
    output: Any
    error: Optional[str] = None
    extra: Dict[str, Any] = {}


class InferenceMonitor:
    """
    A context manager for monitoring a single inference call, capturing metrics and metadata.
    """

    def __init__(self, cognitor: 'Cognitor') -> None:
        """
        Initializes the InferenceMonitor with a Cognitor instance.
        Args:
            cognitor (Cognitor): The parent Cognitor instance.
        """

        self.cognitor: 'Cognitor' = cognitor
        self.input: Any = None
        self.output: Any = None
        self.error: Optional[str] = None
        self.start_usage: Optional[Dict[str, float]] = None
        self.full_timer: Timer = Timer()
        self.inference_timer: Timer = Timer()
        self.metadata: Optional[InferenceMetadata] = None

    def __enter__(self) -> 'InferenceMonitor':
        """
        Enters the monitoring context, recording initial resource usage and starting the timer.
        Returns:
            InferenceMonitor: The monitor instance.
        """

        self.start_usage = get_resource_usage()
        self.full_timer.__enter__()
        return self

    def track(self) -> Timer:
        """
        Returns a context manager to track the specific inference duration.
        Returns:
            Timer: The inference timer context manager.
        """

        return self.inference_timer

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """
        Exits the monitoring context, generating metadata and logging it to the configured target.
        Args:
            exc_type (Any): The exception type if an error occurred.
            exc_val (Any): The exception value if an error occurred.
            exc_tb (Any): The traceback if an error occurred.
        """

        self.full_timer.__exit__(exc_type, exc_val, exc_tb)
        if exc_type:
            self.error = str(exc_val)
        
        self.metadata = self.cognitor._generate_metadata(
            input_data=self.input,
            output=self.output,
            error=self.error,
            full_timer=self.full_timer,
            inference_timer=self.inference_timer,
            start_usage=self.start_usage if self.start_usage else {}
        )
        self.cognitor._last_metadata = self.metadata
        
        # Log to database via LoggingService
        if self.cognitor.logging_service:
            self.cognitor.logging_service.log_inference(self.metadata.model_dump())

    def capture(self, output: Any, input_data: Any = None) -> None:
        """
        Captures the output and optionally the input of the inference.
        Args:
            output (Any): The inference output data.
            input_data (Any, optional): The inference input data. Defaults to None.
        """

        if input_data is not None:
            self.input = input_data
        self.output = output


class Cognitor:
    """
    The main SDK class for monitoring SLM inference calls.
    """

    def __init__(
        self, model_name: str, tokenizer: Any = None, 
        log_type: str = config.LOG_TYPE, log_path: Optional[str] = None, 
        host: str = config.DB_HOST, port: int = config.DB_PORT, user: str = config.DB_USERNAME, 
        password: str = config.DB_PASSWORD, dbname: str = config.DB_NAME
    ) -> None:
        """
        Initializes the Cognitor instance with model, tokenizer, and logging configuration.
        Args:
            model_name (str): The name of the model being monitored.
            tokenizer (Any, optional): The tokenizer for token counting.
            log_type (str): The logging target ('database' or 'file').
            log_path (Optional[str]): The path for file logging.
            host (str): The database host.
            port (int): The database port.
            user (str): The database user.
            password (str): The database password.
            dbname (str): The database name.
        """

        self.model_name: str = model_name
        self.tokenizer: Any = tokenizer
        self._last_metadata: Optional[InferenceMetadata] = None
        
        self.db_manager: Optional[DatabaseManager] = None
        self.logging_service: Optional[LoggingService] = None

        if log_type == "database":
            self.db_manager = DatabaseManager(host=host, port=port, user=user, password=password, dbname=dbname)
            self.db_manager.init_db()
            self.logging_service = LoggingService(db_manager=self.db_manager)
        elif log_type == "file":
            if not log_path:
                log_path = f"{model_name}_logs.jsonl"
            self.logging_service = LoggingService(log_file=log_path)
        else:
            raise ValueError(f"Invalid log_type: {log_type}. Must be 'database' or 'file'.")

    def monitor(self) -> InferenceMonitor:
        """
        Returns a context manager to monitor an inference call.
        Returns:
            InferenceMonitor: The inference monitor context manager.
        """

        return InferenceMonitor(self)

    def get_last_metadata(self) -> Optional[Dict[str, Any]]:
        """
        Returns the metadata from the last monitored inference.
        Returns:
            Optional[Dict[str, Any]]: The metadata dictionary, or None if no inference has been monitored.
        """

        return self._last_metadata.model_dump() if self._last_metadata else None

    def monitor_inference(self, func: Any, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        """
        Monitors a single inference call using the context manager.
        Args:
            func (Callable): The inference function to monitor.
            *args: Positional arguments for the inference function.
            **kwargs: Keyword arguments for the inference function.
        Returns:
            Dict[str, Any]: A dictionary containing the 'output' and 'metadata'.
        """

        input_data: Any = args[0] if args else kwargs
        with self.monitor() as m:
            try:
                with m.track():
                    output = func(*args, **kwargs)
                m.capture(input_data=input_data, output=output)
                return {"output": output, "metadata": m.metadata.model_dump() if m.metadata else {}}
            except Exception as e:
                raise e

    def _generate_metadata(self, input_data: Any, output: Any, error: Optional[str], full_timer: Timer, inference_timer: Timer, start_usage: Dict[str, float]) -> InferenceMetadata:
        """
        Internal method to generate InferenceMetadata from collected metrics.
        Args:
            input_data (Any): The inference input data.
            output (Any): The inference output data.
            error (Optional[str]): The error message if an error occurred.
            full_timer (Timer): The timer for the full context duration.
            inference_timer (Timer): The timer for the specific inference duration.
            start_usage (Dict[str, float]): The initial resource usage metrics.
        Returns:
            InferenceMetadata: The generated metadata object.
        """

        end_usage: Dict[str, float] = get_resource_usage()
        
        # Extract token counts if tokenizer is available
        input_tokens: int = 0
        output_tokens: int = 0
        
        if self.tokenizer:
            if isinstance(input_data, str):
                input_tokens = len(self.tokenizer.encode(input_data))
            elif isinstance(input_data, list):
                if all(isinstance(i, str) for i in input_data):
                    input_tokens = sum(len(self.tokenizer.encode(i)) for i in input_data)
                elif all(isinstance(i, dict) for i in input_data):
                    # Handle chat-like inputs
                    for msg in input_data:
                        if isinstance(msg, dict) and "content" in msg:
                            input_tokens += len(self.tokenizer.encode(msg["content"]))

            if output:
                if isinstance(output, list):
                    for item in output:
                        if isinstance(item, dict):
                            if "generated_text" in item:
                                output_tokens += len(self.tokenizer.encode(item["generated_text"]))
                            elif "summary_text" in item:
                                output_tokens += len(self.tokenizer.encode(item["summary_text"]))
                            elif "translation_text" in item:
                                output_tokens += len(self.tokenizer.encode(item["translation_text"]))
                        elif isinstance(item, str):
                            output_tokens += len(self.tokenizer.encode(item))
                elif isinstance(output, dict):
                    if "generated_text" in output:
                        output_tokens = len(self.tokenizer.encode(output["generated_text"]))
                elif isinstance(output, str):
                    output_tokens = len(self.tokenizer.encode(output))

        gpu_usage_percent: Optional[float] = None
        if torch.cuda.is_available():
            device = torch.cuda.current_device()
            total_mem = torch.cuda.get_device_properties(device).total_memory
            peak_mem = torch.cuda.max_memory_allocated(device)
            gpu_usage_percent = (peak_mem / total_mem) * 100
            torch.cuda.reset_peak_memory_stats(device)

        return InferenceMetadata(
            model_name=self.model_name,
            timestamp=full_timer.timestamp,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cpu_percent=end_usage["cpu_percent"],
            ram_usage_percent=end_usage["ram_usage_percent"],
            gpu_usage_percent=gpu_usage_percent,
            duration=inference_timer.duration,
            input=input_data,
            output=output,
            error=error
        )
