import psutil
import time
import os
from datetime import datetime, timezone
from typing import Dict, Any


def get_resource_usage() -> Dict[str, float]:
    """
    Returns current CPU and RAM usage percentages.
    Returns:
        Dict[str, float]: A dictionary containing 'cpu_percent' and 'ram_usage_percent'.
    """

    process = psutil.Process(os.getpid())
    return {
        "cpu_percent": psutil.cpu_percent(interval=None),
        "ram_usage_percent": process.memory_percent()
    }

class Timer:
    """
    A context manager to measure duration and record a UTC timestamp.
    """

    def __init__(self) -> None:
        """
        Initializes the Timer instance.
        """

        self.start: float = 0.0
        self.end: float = 0.0
        self.duration: float = 0.0
        self.timestamp: str = ""

    def __enter__(self) -> 'Timer':
        """
        Starts the timer and records the current UTC timestamp.
        Returns:
            Timer: The timer instance.
        """

        self.start = time.perf_counter()
        self.timestamp = datetime.now(timezone.utc).isoformat()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """
        Stops the timer and calculates the duration.
        Args:
            exc_type (Any): The exception type if an error occurred.
            exc_val (Any): The exception value if an error occurred.
            exc_tb (Any): The traceback if an error occurred.
        """

        self.end = time.perf_counter()
        self.duration = self.end - self.start
