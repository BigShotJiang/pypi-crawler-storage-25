import pytest
from unittest.mock import MagicMock, patch
from cognitor.database import DatabaseManager

@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_database_manager_init(mock_sessionmaker, mock_create_engine):
    db_manager = DatabaseManager(
        host="test_host",
        port=9999,
        user="test_user",
        password="test_password",
        dbname="test_db"
    )
    
    assert db_manager.db_url == "postgresql://test_user:test_password@test_host:9999/test_db"
    mock_create_engine.assert_called_once_with(db_manager.db_url)
    mock_sessionmaker.assert_called_once_with(bind=db_manager.engine)
    assert db_manager._initialized is False

@patch("cognitor.database.Base.metadata.create_all")
@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_init_db_success(mock_sessionmaker, mock_create_engine, mock_create_all):
    db_manager = DatabaseManager()
    db_manager.init_db()
    
    mock_create_all.assert_called_once_with(db_manager.engine)
    assert db_manager._initialized is True

@patch("cognitor.database.Base.metadata.create_all")
@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_init_db_failure(mock_sessionmaker, mock_create_engine, mock_create_all):
    mock_create_all.side_effect = Exception("Connection failed")
    
    db_manager = DatabaseManager()
    
    with pytest.raises(SystemExit) as excinfo:
        db_manager.init_db()
    
    assert excinfo.value.code == 0
    assert db_manager._initialized is False
