import json
import os
import pytest
from unittest.mock import MagicMock, patch
from cognitor.service import LoggingService

@patch("cognitor.service.InferenceLog")
def test_log_to_db_success(mock_inference_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    
    service = LoggingService(db_manager=mock_db_manager)
    metadata = {
        "model_name": "test-model",
        "timestamp": "2023-01-01T00:00:00Z",
        "input": {"text": "hello"},
        "output": {"text": "world"},
        "extra": {"key": "value"}
    }
    
    service.log_inference(metadata)
    
    mock_session.add.assert_called_once()
    mock_session.commit.assert_called_once()
    mock_session.close.assert_called_once()

@patch("cognitor.service.InferenceLog")
def test_log_to_db_failure(mock_inference_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    mock_session.commit.side_effect = Exception("DB error")
    
    service = LoggingService(db_manager=mock_db_manager)
    metadata = {"model_name": "test-model"}
    
    service.log_inference(metadata)
    
    mock_session.rollback.assert_called_once()
    mock_session.close.assert_called_once()

def test_log_to_file_success(tmp_path):
    log_file = tmp_path / "subdir" / "test_logs.jsonl"
    service = LoggingService(log_file=str(log_file))
    metadata = {"model_name": "test-model", "input": "hello"}
    
    service.log_inference(metadata)
    
    assert log_file.exists()
    with open(log_file, "r") as f:
        data = json.loads(f.read())
        assert data["model_name"] == "test-model"

@patch("builtins.open")
def test_log_to_file_failure(mock_open):
    mock_open.side_effect = Exception("File error")
    service = LoggingService(log_file="test.jsonl")
    metadata = {"model_name": "test-model"}
    
    # Should not raise exception, just print warning
    service.log_inference(metadata)
