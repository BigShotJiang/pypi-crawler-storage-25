import os
import pytest
from cognitor.config import Config

def test_config_default_values(monkeypatch):
    # Clear environment variables to ensure defaults are used
    monkeypatch.delenv("DB_HOST", raising=False)
    monkeypatch.delenv("DB_PORT", raising=False)
    monkeypatch.delenv("DB_USERNAME", raising=False)
    monkeypatch.delenv("DB_PASSWORD", raising=False)
    monkeypatch.delenv("DB_NAME", raising=False)
    monkeypatch.delenv("LOG_TYPE", raising=False)
    monkeypatch.delenv("LOG_PATH", raising=False)
    
    # Pass _env_file=None to ignore .env file
    config = Config(_env_file=None)
    assert config.DB_HOST == "localhost"
    assert config.DB_PORT == 5432
    assert config.DB_USERNAME == "cognitoruser"
    assert config.DB_PASSWORD == "cognitorpassword"
    assert config.DB_NAME == "cognitor"
    assert config.LOG_TYPE == "database"
    assert config.LOG_PATH == "congitor_inference.jsonl"

def test_config_env_override(monkeypatch):
    monkeypatch.setenv("DB_HOST", "test_host")
    monkeypatch.setenv("DB_PORT", "9999")
    monkeypatch.setenv("DB_USERNAME", "test_user")
    monkeypatch.setenv("DB_PASSWORD", "test_pass")
    monkeypatch.setenv("DB_NAME", "test_db")
    monkeypatch.setenv("LOG_TYPE", "file")
    monkeypatch.setenv("LOG_PATH", "test_log.jsonl")
    
    # Re-instantiate Config to pick up env vars, ignoring .env file
    config = Config(_env_file=None)
    assert config.DB_HOST == "test_host"
    assert config.DB_PORT == 9999
    assert config.DB_USERNAME == "test_user"
    assert config.DB_PASSWORD == "test_pass"
    assert config.DB_NAME == "test_db"
    assert config.LOG_TYPE == "file"
    assert config.LOG_PATH == "test_log.jsonl"
