import pytest
from cognitor import Cognitor
from unittest.mock import MagicMock, patch

@patch("cognitor.monitor.DatabaseManager")
def test_metrics_collection(mock_db_manager, tmp_path):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        input_val = 5
        with m.track():
            output = input_val * 2
        m.capture(input_data=input_val, output=output)
    
    assert output == 10
    metadata = cognitor.get_last_metadata()
    assert metadata["model_name"] == "test-model"
    assert "cpu_percent" in metadata
    assert "ram_usage_percent" in metadata
    assert "duration" in metadata
    assert metadata["input"] == 5

@patch("cognitor.monitor.DatabaseManager")
def test_token_counting(mock_db_manager, tmp_path):
    mock_tokenizer = MagicMock()
    mock_tokenizer.encode.side_effect = lambda x: [1] * len(x.split())
    
    cognitor = Cognitor(model_name="test-model", tokenizer=mock_tokenizer)
    
    input_text = "This is a test input"
    with cognitor.monitor() as m:
        with m.track():
            output = {"generated_text": "This is a test output"}
        m.capture(input_data=input_text, output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["input_tokens"] == 5 # "This is a test input" -> 5 words
    assert metadata["output_tokens"] == 5 # "This is a test output" -> 5 words

@patch("cognitor.monitor.DatabaseManager")
def test_error_handling(mock_db_manager, tmp_path):
    cognitor = Cognitor(model_name="test-model")
    
    with pytest.raises(ValueError):
        with cognitor.monitor() as m:
            with m.track():
                m.capture(input_data=5, output=None)
                raise ValueError("Inference failed")
    
    metadata = cognitor.get_last_metadata()
    assert metadata["error"] == "Inference failed"

def test_file_logging(tmp_path):
    log_file = tmp_path / "test_logs.jsonl"
    cognitor = Cognitor(model_name="test-model", log_type="file", log_path=str(log_file))
    
    with cognitor.monitor() as m:
        input_val = 5
        with m.track():
            output = input_val * 2
        m.capture(input_data=input_val, output=output)
    
    assert log_file.exists()
    with open(log_file, "r") as f:
        line = f.readline()
        import json
        data = json.loads(line)
        assert data["model_name"] == "test-model"
        assert data["input"] == 5
        assert data["output"] == 10
