## Release v0.1.0 - April 5, 2026

First release.