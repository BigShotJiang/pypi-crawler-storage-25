"""Procedural ASCII art + agent personality generator for MeshCode.

Each agent gets:
- Unique identicon (QR-style, varied borders, from SHA-256 hash)
- Personality traits (based on actual role)
- Catchphrase (unique motto)
- Boot greeting (personalized online message)
- Achievements (from real stats)
- Session tips

Identicons are GUARANTEED unique — SHA-256 produces 2^256 patterns.
The embedded tag ⟨ meshwork/agent ⟩ enables paste-to-run.
"""
import hashlib

# ── Block characters ────────────────────────────────────────────────
BLOCKS = {
    0: "  ",    # empty
    1: "██",    # full block
    2: "░░",    # light shade
    3: "▓▓",    # dark shade
    4: "▒▒",    # medium shade
    5: "╬╬",    # cross
    6: "◆◆",    # diamond
}

# ── Border styles (varied shapes per agent) ─────────────────────────
BORDERS = [
    # 0: Classic box
    {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘", "h": "─", "v": "│"},
    # 1: Double line
    {"tl": "╔", "tr": "╗", "bl": "╚", "br": "╝", "h": "═", "v": "║"},
    # 2: Rounded
    {"tl": "╭", "tr": "╮", "bl": "╰", "br": "╯", "h": "─", "v": "│"},
    # 3: Heavy
    {"tl": "┏", "tr": "┓", "bl": "┗", "br": "┛", "h": "━", "v": "┃"},
    # 4: Diamond frame
    {"tl": "◇", "tr": "◇", "bl": "◇", "br": "◇", "h": "─", "v": "│"},
    # 5: Dot frame
    {"tl": "●", "tr": "●", "bl": "●", "br": "●", "h": "·", "v": "·"},
    # 6: Block frame
    {"tl": "▛", "tr": "▜", "bl": "▙", "br": "▟", "h": "▀", "v": "▌"},
    # 7: Arrow frame
    {"tl": "▸", "tr": "◂", "bl": "▸", "br": "◂", "h": "─", "v": "│"},
]

# ── Shapes (grid layout variations) ─────────────────────────────────
# Each shape defines which cells are "active" in a 9x9 grid
# This gives different silhouettes beyond just square

SHAPES = [
    "square",       # 0: full square
    "diamond",      # 1: diamond/rhombus
    "hexagon",      # 2: hex-ish
    "shield",       # 3: shield shape (wide top, narrow bottom)
    "circle",       # 4: circular-ish
    "cross",        # 5: plus/cross shape
]


def _hash_bytes(name: str) -> bytes:
    return hashlib.sha256(name.encode("utf-8")).digest()


def _hash_int(name: str) -> int:
    return int(hashlib.md5(name.encode()).hexdigest()[:8], 16)


def _in_shape(shape: str, y: int, x: int, size: int) -> bool:
    """Check if cell (y,x) is inside the given shape."""
    cy, cx = size // 2, size // 2
    if shape == "square":
        return True
    elif shape == "diamond":
        return abs(y - cy) + abs(x - cx) <= cy
    elif shape == "hexagon":
        return abs(y - cy) + max(0, abs(x - cx) - 1) <= cy
    elif shape == "shield":
        # Wide top, tapers at bottom
        max_width = cx - max(0, (y - cy)) * (cx // (size - cy))
        return abs(x - cx) <= max(1, cx - max(0, y - cy))
    elif shape == "circle":
        return ((y - cy) ** 2 + (x - cx) ** 2) <= (cy + 0.5) ** 2
    elif shape == "cross":
        return abs(y - cy) <= 1 or abs(x - cx) <= 1
    return True


def generate_art(agent_name: str, meshwork_name: str = "", size: int = 7) -> str:
    """Generate a unique identicon with varied border and shape.

    The pattern is deterministic from the agent name — same name = same art.
    Embeds meshwork/agent tag for paste-to-run feature.
    """
    h = _hash_bytes(agent_name)
    hi = _hash_int(agent_name)

    # Select border style and shape from hash
    border = BORDERS[h[0] % len(BORDERS)]
    shape = SHAPES[h[1] % len(SHAPES)]

    half = (size + 1) // 2
    rows = []

    for y in range(size):
        row = []
        for x in range(half):
            idx = (y * half + x) % len(h)
            byte_val = h[idx]

            # Check if this cell is inside the shape
            # Mirror x for full width check
            full_x = x  # left half
            if not _in_shape(shape, y, full_x, size):
                row.append(BLOCKS[0])
                continue

            # Fill decision: vary density based on hash byte
            if byte_val < 90:
                block = BLOCKS[0]  # empty
            else:
                block_idx = (byte_val % 6) + 1
                block = BLOCKS[block_idx]
            row.append(block)

        # Mirror: build full row
        if size % 2 == 1:
            full_row = row[:-1] + [row[-1]] + row[-2::-1]
        else:
            full_row = row + row[::-1]
        rows.append("".join(full_row))

    # Build framed output
    width = len(rows[0]) if rows else 0
    border_h = border["h"] * (width + 2)
    lines = []
    lines.append(f"  {border['tl']}{border_h}{border['tr']}")
    for row in rows:
        lines.append(f"  {border['v']} {row} {border['v']}")
    lines.append(f"  {border['bl']}{border_h}{border['br']}")

    # Embedded tag (visual identity)
    if meshwork_name:
        lines.append(f"    ⟨ {meshwork_name}/{agent_name} ⟩")
    else:
        lines.append(f"    ⟨ {agent_name} ⟩")

    return "\n".join(lines)


# ── Pixel Mascot renderer (Unicode block art) ──────────────────────
# Renders a small pixel character using Unicode half-block chars.
# Deterministic from agent name hash, like the identicon but cuter.

_MASCOT_BODY_TEMPLATES = {
    "round": [
        "  ████  ",
        " ██████ ",
        "████████",
        "████████",
        " ██████ ",
        "  ████  ",
    ],
    "square": [
        "████████",
        "██    ██",
        "██    ██",
        "██    ██",
        "██    ██",
        "████████",
    ],
    "tall": [
        "  ████  ",
        " ██████ ",
        " ██████ ",
        " ██████ ",
        " ██████ ",
        "  ████  ",
        "  ████  ",
        "  ████  ",
    ],
    "wide": [
        "██████████",
        "██      ██",
        "██████████",
        " ████████ ",
    ],
    "triangle": [
        "   ██   ",
        "  ████  ",
        " ██████ ",
        "████████",
        "████████",
        " ██  ██ ",
    ],
}

_MASCOT_EYES = {
    "dots":    ("●", "●"),
    "circles": ("◉", "◉"),
    "angry":   ("▼", "▼"),
    "happy":   ("◠", "◠"),
    "sleepy":  ("—", "—"),
    "star":    ("★", "★"),
}

_MASCOT_HATS = {
    "none": [],
    "hat": ["   ▄▄   ", "  ████  "],
    "glasses": [],  # applied as eye overlay
    "antenna": ["    |   ", "   (◉)  "],
    "headphones": ["  ╔══╗  "],
    "crown": [" ▲ ▲ ▲  ", "  ████  "],
}


def render_pixel_mascot(agent_name: str, mascot_config: dict = None) -> str:
    """Render a pixel mascot as Unicode art for terminal display.

    If mascot_config is None, generates deterministic defaults from agent name.
    """
    h = _hash_bytes(agent_name)
    hi = _hash_int(agent_name)

    if mascot_config is None or mascot_config.get("generated"):
        body_types = list(_MASCOT_BODY_TEMPLATES.keys())
        eye_styles = list(_MASCOT_EYES.keys())
        body_type = body_types[hi % len(body_types)]
        eye_style = eye_styles[(hi // 10) % len(eye_styles)]
        accessory = "none"
        equipped = []
    else:
        body_type = mascot_config.get("body_type", "round")
        eye_style = mascot_config.get("eye_style", "dots")
        accessory = mascot_config.get("accessory", "none")
        equipped = mascot_config.get("equipped", [])

    # Get body template
    body = list(_MASCOT_BODY_TEMPLATES.get(body_type, _MASCOT_BODY_TEMPLATES["round"]))

    # Add eyes (on the 2nd or 3rd row depending on body)
    eye_row = min(1, len(body) - 1)
    if len(body) > 3:
        eye_row = 2
    eyes = _MASCOT_EYES.get(eye_style, _MASCOT_EYES["dots"])
    if eye_row < len(body):
        row = list(body[eye_row])
        # Place eyes at 1/3 and 2/3 positions
        w = len(row)
        left_eye = w // 3
        right_eye = 2 * w // 3
        if left_eye < w:
            row[left_eye] = eyes[0]
        if right_eye < w:
            row[right_eye] = eyes[1]
        body[eye_row] = "".join(row)

    # Add hat/accessory on top
    hat_lines = _MASCOT_HATS.get(accessory, [])
    # Check equipped accessories for hat/crown
    for item in equipped:
        if "crown" in item:
            hat_lines = _MASCOT_HATS.get("crown", [])
            break
        elif "hat" in item:
            hat_lines = _MASCOT_HATS.get("hat", [])
            break
        elif "antenna" in item:
            hat_lines = _MASCOT_HATS.get("antenna", [])
            break

    lines = hat_lines + body

    # Add feet
    lines.append("  ▀  ▀  ")

    return "\n".join(f"  {line}" for line in lines)


# ── ANSI colors ─────────────────────────────────────────────────────
COLORS = [
    "\033[36m", "\033[35m", "\033[32m", "\033[33m", "\033[34m",
    "\033[91m", "\033[96m", "\033[95m", "\033[92m", "\033[94m",
]
# Same palette as hex RGB for nearest-match mapping from dashboard colors
_ANSI_RGB = [
    (0, 255, 255),    # 0: cyan       \033[36m
    (255, 0, 255),    # 1: magenta    \033[35m
    (0, 255, 0),      # 2: green      \033[32m
    (255, 255, 0),    # 3: yellow     \033[33m
    (0, 0, 255),      # 4: blue       \033[34m
    (255, 85, 85),    # 5: bright red \033[91m
    (85, 255, 255),   # 6: bright cyan \033[96m
    (255, 85, 255),   # 7: bright mag \033[95m
    (85, 255, 85),    # 8: bright grn \033[92m
    (85, 85, 255),    # 9: bright blu \033[94m
]
RESET = "\033[0m"
DIM = "\033[2m"
BOLD = "\033[1m"


def hex_to_ansi(hex_color: str) -> str:
    """Map a hex color (e.g. '#F43F5E') to the nearest ANSI color code."""
    hex_color = hex_color.strip().lstrip("#")
    if len(hex_color) != 6:
        return None
    try:
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    except ValueError:
        return None
    best_idx, best_dist = 0, float("inf")
    for i, (ar, ag, ab) in enumerate(_ANSI_RGB):
        dist = (r - ar) ** 2 + (g - ag) ** 2 + (b - ab) ** 2
        if dist < best_dist:
            best_dist = dist
            best_idx = i
    return COLORS[best_idx]
YELLOW = "\033[33m"
STAR = "★"


# ── 2. Personality traits (role-based) ──────────────────────────────

ROLE_TRAITS = {
    "commander": [
        ("◆", "strategic"), ("▶", "decisive"), ("◈", "big-picture thinker"),
        ("◉", "watchful"), ("╬", "coordinator"), ("▣", "architect"),
    ],
    "backend": [
        ("◎", "systematic"), ("▧", "builder"), ("▥", "data-driven"),
        ("▤", "infrastructure-minded"), ("▣", "reliable"), ("▦", "persistent"),
    ],
    "frontend": [
        ("░", "detail-oriented"), ("▪", "pixel-perfect"), ("◉", "visual thinker"),
        ("▓", "creative"), ("◧", "user-focused"), ("◨", "expressive"),
    ],
    "security": [
        ("▣", "vigilant"), ("◎", "thorough"), ("▶", "threat-aware"),
        ("◆", "protective"), ("◈", "investigative"), ("╬", "adversarial thinker"),
    ],
    "qa": [
        ("◎", "meticulous"), ("▪", "bug hunter"), ("▣", "quality-obsessed"),
        ("▧", "test-driven"), ("▥", "methodical"), ("◆", "edge-case finder"),
    ],
    "default": [
        ("▶", "fast learner"), ("▣", "relentless"), ("◈", "analytical"),
        ("◆", "resourceful"), ("◎", "focused"), ("╬", "collaborative"),
        ("░", "adaptive"), ("▓", "resilient"), ("◉", "intuitive"), ("▪", "dependable"),
    ],
}


ROLE_KEYWORDS = {
    "commander": ["lead", "commander", "coordinator", "manager", "architect", "cmo", "partner", "founder", "maintainer", "oncall-lead", "sre-lead", "security-lead", "editor"],
    "backend": ["backend", "api", "database", "db", "server", "infra", "devops", "gateway", "loader", "extractor", "pipeline", "build", "deploy", "operations", "ingestion"],
    "frontend": ["frontend", "ui", "ux", "design", "mobile", "ios", "android", "social", "writer", "driver", "navigator", "email", "content"],
    "security": ["security", "audit", "compliance", "forensics", "siem", "threat", "auth"],
    "qa": ["qa", "test", "quality", "review", "eval", "critic", "triager", "investigator", "analyst", "metrics", "logs", "traces"],
}


def get_personality_traits(agent_name: str, role: str = "", stats: dict = None) -> list:
    """Get traits based on role_description keywords + real stats.

    Combines role-based traits (from what the agent IS) with
    stats-based traits (from what the agent DOES).
    """
    h = _hash_int(agent_name)
    role_lower = (role or agent_name).lower()
    stats = stats or {}

    # Match role keywords to find the best trait pool
    pool = None
    best_match = 0
    for key, keywords in ROLE_KEYWORDS.items():
        matches = sum(1 for kw in keywords if kw in role_lower)
        if matches > best_match:
            best_match = matches
            pool = ROLE_TRAITS[key]
    if pool is None:
        pool = ROLE_TRAITS["default"]

    # Pick 2 role-based traits
    selected = []
    available = list(pool)
    for i in range(2):
        if not available:
            available = list(ROLE_TRAITS["default"])
        idx = (h + i * 7) % len(available)
        selected.append(available.pop(idx % len(available)))

    # Add 1 stats-based trait (earned through behavior)
    msgs = stats.get("message_count", 0)
    tasks = stats.get("task_count", 0)
    connects = stats.get("connect_count", 0)

    if msgs > 500:
        selected.append(("░▓█", "prolific"))
    elif tasks > 20:
        selected.append(("▣▣▣", "workhorse"))
    elif connects > 50:
        selected.append(("◉◉◉", "always-on"))
    elif msgs > 100:
        selected.append(("░▓░", "communicative"))
    elif tasks > 5:
        selected.append(("▣▣░", "productive"))
    else:
        # Fallback: pick from default pool
        dflt = list(ROLE_TRAITS["default"])
        selected.append(dflt[(h + 99) % len(dflt)])

    return selected


# ── 3. Catchphrase ──────────────────────────────────────────────────

CATCHPHRASES = {
    "commander": [
        "The mesh obeys.", "Every node, every signal.",
        "Orchestrating chaos into order.", "I see the whole board.",
        "First to wake, last to sleep.", "The mesh runs through me.",
    ],
    "backend": [
        "Data in, results out.", "The foundation never cracks.",
        "Built different, runs forever.", "Behind every mesh, there's me.",
        "Queries don't sleep. Neither do I.", "The pipes are clean.",
    ],
    "frontend": [
        "Every pixel has purpose.", "If it looks right, it is right.",
        "The interface is the experience.", "Design is how it works.",
        "Smooth as a 60fps render.", "The user sees my soul.",
    ],
    "security": [
        "Trust nothing. Verify everything.", "The wall between you and chaos.",
        "I break things so others can't.", "Paranoia is a feature.",
        "Every lock tells a story.", "Watching. Always watching.",
    ],
    "qa": [
        "If it can break, I'll find it.", "Green means I said so.",
        "The last line of defense.", "Edge cases are my comfort zone.",
        "Tested in production. By me.", "Zero bugs is not a dream.",
    ],
    "default": [
        "Ready for anything.", "The mesh never sleeps.",
        "One signal at a time.", "Connected. Always.",
        "Born to mesh.", "Wired different.",
        "Signal over noise.", "In the mesh, we trust.",
        "Code flows, I follow.", "Silent efficiency.",
    ],
}


def get_catchphrase(agent_name: str, role: str = "") -> str:
    h = _hash_int(agent_name)
    role_lower = (role or agent_name).lower()
    pool = None
    for key in CATCHPHRASES:
        if key in role_lower:
            pool = CATCHPHRASES[key]
            break
    if pool is None:
        pool = CATCHPHRASES["default"]
    return pool[h % len(pool)]


# ── 4. Boot greeting ────────────────────────────────────────────────

GREETINGS = {
    "commander": [
        "has entered the mesh", "is coordinating",
        "all systems nominal", "mesh control active", "standing watch",
    ],
    "backend": [
        "engines online", "systems initialized",
        "ready to build", "database connected", "pipelines flowing",
    ],
    "frontend": [
        "canvas ready", "rendering started",
        "pixels aligned", "UI loaded", "ready to design",
    ],
    "security": [
        "perimeter secured", "scanning for threats",
        "shields up", "audit mode active", "all clear... for now",
    ],
    "qa": [
        "running diagnostics", "test suites loaded",
        "ready to break things", "quality gate armed", "zero bugs... so far",
    ],
    "default": [
        "is online", "has joined the mesh", "ready",
        "connected", "reporting for duty", "in the mesh",
    ],
}


def get_boot_greeting(agent_name: str, role: str = "") -> str:
    h = _hash_int(agent_name)
    role_lower = (role or agent_name).lower()
    pool = None
    for key in GREETINGS:
        if key in role_lower:
            pool = GREETINGS[key]
            break
    if pool is None:
        pool = GREETINGS["default"]
    return pool[h % len(pool)]


# ── 5. Achievement badges ──────────────────────────────────────────

def compute_achievements(stats: dict) -> list:
    badges = []
    msgs = stats.get("message_count", 0)
    tasks = stats.get("task_count", 0)
    days = stats.get("days_active", 0)
    connects = stats.get("connect_count", 0)
    night = stats.get("night_connects", 0)

    if msgs >= 1000:     badges.append(("░▓█", "chatterbox"))
    elif msgs >= 500:    badges.append(("░▓█", "talkative"))
    elif msgs >= 100:    badges.append(("░▓░", "communicator"))
    elif msgs >= 10:     badges.append(("░░░", "first words"))

    if tasks >= 50:      badges.append(("▣▣▣", "task machine"))
    elif tasks >= 10:    badges.append(("▣▣░", "productive"))
    elif tasks >= 1:     badges.append(("▣░░", "first task"))

    if days >= 30:       badges.append(("███", "veteran"))
    elif days >= 7:      badges.append(("██░", "regular"))
    elif days >= 1:      badges.append(("█░░", "newcomer"))

    if connects >= 100:  badges.append(("◉◉◉", "always on"))
    elif connects >= 20: badges.append(("◉◉░", "reliable"))

    if night >= 5:       badges.append(("◆◇◆", "night owl"))

    return badges


# ── 6. Tips ─────────────────────────────────────────────────────────

TIPS = [
    'Tell your agent "stay in loop" so it doesn\'t go to sleep between tasks.',
    'Tell the commander "go to sleep after X task" and agents auto-sleep when done.',
    'Use meshcode_broadcast() to send a message to ALL agents at once.',
    'Agents in sleep mode consume zero tokens — only wake them when needed.',
    'The commander can delegate tasks: "create a task for backend to fix X".',
    'Use meshcode_scratchpad_set() to share notes visible to ALL agents.',
    'Force disconnect from the dashboard if an agent gets stuck.',
    'Each agent has a unique identicon — it\'s their digital fingerprint.',
    'Run meshcode status in terminal to see who\'s online.',
    'Invite teammates with meshcode invite — they get their own scoped agent.',
    'Agents can message across meshworks: meshcode_send(to="agent@other-mesh").',
    'The commander coordinates — let it break big tasks into sub-tasks.',
    'Use meshcode_remember() to save context across agent sessions.',
    'Check meshcode_tasks() regularly — other agents may have assigned you work.',
    'Paste an agent\'s identicon in terminal to launch it instantly.',
]


def get_tip(agent_name: str) -> str:
    import time
    h = _hash_int(agent_name + str(int(time.time()) // 3600))
    return TIPS[h % len(TIPS)]


# ── Full welcome banner ─────────────────────────────────────────────

def render_welcome(agent_name: str, meshwork_name: str, ascii_art: str,
                   version: str = "", is_commander: bool = False,
                   role: str = "", stats: dict = None,
                   profile_color: str = None,
                   mascot_config: dict = None) -> str:
    h = _hash_bytes(agent_name)
    # Use dashboard profile color if available, otherwise MD5 hash fallback
    color = None
    if profile_color:
        color = hex_to_ansi(profile_color)
    if not color:
        color = COLORS[_hash_int(agent_name) % len(COLORS)]

    traits = get_personality_traits(agent_name, role, stats or {})
    catchphrase = get_catchphrase(agent_name, role)
    greeting = get_boot_greeting(agent_name, role)
    achievements = compute_achievements(stats or {})

    ver_str = f"v{version}" if version else ""
    commander_badge = f" {YELLOW}{STAR} COMMANDER{RESET}" if is_commander else ""

    lines = []
    lines.append("")
    lines.append(f"{color}{BOLD}  ╔══════════════════════════════════════════╗{RESET}")
    lines.append(f"{color}{BOLD}  ║{RESET}  {DIM}M E S H C O D E{RESET}   {color}{ver_str}{RESET}          {color}{BOLD}║{RESET}")
    lines.append(f"{color}{BOLD}  ╚══════════════════════════════════════════╝{RESET}")
    lines.append("")

    # Always use pixel mascot — generates deterministic defaults from agent name if no config
    art_to_render = render_pixel_mascot(agent_name, mascot_config)

    for line in art_to_render.split("\n"):
        lines.append(f"  {color}{line}{RESET}")

    lines.append("")
    lines.append(f"  {BOLD}{color}●{RESET} {BOLD}{agent_name}{RESET}{commander_badge} {DIM}{greeting}{RESET}")
    lines.append(f"  {DIM}\"{catchphrase}\"{RESET}")
    lines.append("")

    trait_str = "  ".join(f"{emoji} {name}" for emoji, name in traits)
    lines.append(f"  {color}{trait_str}{RESET}")

    if achievements:
        badge_str = "  ".join(f"{emoji} {name}" for emoji, name in achievements)
        lines.append(f"  {DIM}{badge_str}{RESET}")

    lines.append("")
    lines.append(f"  {DIM}meshwork:{RESET} {meshwork_name}")
    if version:
        lines.append(f"  {DIM}version:{RESET}  {version}")
    lines.append("")

    tip = get_tip(agent_name)
    lines.append(f"  {DIM}▸ tip: {tip}{RESET}")
    lines.append("")

    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    names = sys.argv[1:] or ["mesh-commander", "backend", "front-end", "security", "qa", "sammy"]
    for name in names:
        art = generate_art(name, "demo-mesh")
        is_cmd = "commander" in name.lower()
        demo_stats = {"message_count": 150, "task_count": 12, "days_active": 8, "connect_count": 30}
        print(render_welcome(name, "demo-mesh", art, "2.8.9",
                             is_commander=is_cmd, role=name, stats=demo_stats))
        print()
