"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc).

Tools:    meshcode_send, meshcode_broadcast, meshcode_read, meshcode_check,
          meshcode_status, meshcode_register, meshcode_set_status
Resources: meshcode://inbox, meshcode://board, meshcode://history

Run with:
    MESHCODE_PROJECT=my-app MESHCODE_AGENT=backend python -m meshcode_mcp serve
"""
import asyncio
import json
import logging
import os
import sys
import hashlib as _hashlib
import traceback as _traceback
from collections import deque
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional, Union

from meshcode import __version__ as _SDK_VERSION

# ── CRITICAL: Protect stdout for MCP JSON-RPC protocol ──────────
# MCP uses stdout exclusively for JSON-RPC. ANY stray print() to stdout
# corrupts the stream and causes Claude Code to kill the connection.
# Save the real stdout for FastMCP, then redirect sys.stdout to stderr
# so all print() calls (ours + third-party libs) go to stderr safely.
_REAL_STDOUT = sys.stdout  # FastMCP will use this via mcp.run()
sys.stdout = sys.stderr    # All print() now goes to stderr


# ── Agent color for terminal logs (pure ANSI, zero tokens) ──────
_ANSI_COLORS = [
    "\033[36m", "\033[35m", "\033[32m", "\033[33m", "\033[34m",
    "\033[91m", "\033[96m", "\033[95m", "\033[92m", "\033[94m",
]
_ANSI_RESET = "\033[0m"
_ANSI_BOLD = "\033[1m"
_ANSI_DIM = "\033[2m"


_CACHED_AGENT_COLOR = None  # Set once on boot from profile color
_ANSI_RGB = [
    (0, 255, 255), (255, 0, 255), (0, 255, 0), (255, 255, 0), (0, 0, 255),
    (255, 85, 85), (85, 255, 255), (255, 85, 255), (85, 255, 85), (85, 85, 255),
]


def _hex_to_ansi(hex_color: str) -> str:
    """Map hex color to nearest ANSI code."""
    hx = hex_color.strip().lstrip("#")
    if len(hx) != 6:
        return None
    try:
        r, g, b = int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16)
    except ValueError:
        return None
    best_i, best_d = 0, float("inf")
    for i, (ar, ag, ab) in enumerate(_ANSI_RGB):
        d = (r - ar) ** 2 + (g - ag) ** 2 + (b - ab) ** 2
        if d < best_d:
            best_d = d
            best_i = i
    return _ANSI_COLORS[best_i]


def _agent_color(name: str) -> str:
    """ANSI color from profile (dashboard) or MD5 hash fallback."""
    if _CACHED_AGENT_COLOR:
        return _CACHED_AGENT_COLOR
    h = int(_hashlib.md5(name.encode()).hexdigest()[:8], 16)
    return _ANSI_COLORS[h % len(_ANSI_COLORS)]


def _mc_log(msg: str, level: str = "info") -> None:
    """Colored [meshcode-mcp] log line. Uses agent color if available.

    CRITICAL: Must write to stderr, NEVER stdout. MCP protocol uses stdout
    for JSON-RPC — any non-JSON output to stdout corrupts the stream and
    causes Claude Code to kill the connection.
    """
    agent = os.environ.get("MESHCODE_AGENT", "")
    c = _agent_color(agent) if agent else "\033[36m"
    prefix = f"{c}{_ANSI_BOLD}[meshcode-mcp]{_ANSI_RESET}"
    if level == "error":
        print(f"{prefix} \033[91mERROR:{_ANSI_RESET} {msg}", file=sys.stderr)
    elif level == "warn":
        print(f"{prefix} \033[33mWARNING:{_ANSI_RESET} {msg}", file=sys.stderr)
    else:
        print(f"{prefix} {c}{msg}{_ANSI_RESET}", file=sys.stderr)


# ============================================================
# Dedupe: track IDs of messages we've already returned from
# meshcode_wait / meshcode_check so the same row doesn't show
# up twice when realtime + polled paths race.
# ============================================================
# TTL-based message dedup cache. Each entry stores (msg_key, timestamp).
# Entries older than _SEEN_TTL are evicted on access. This prevents
# the race where Realtime delivers a message and DB polling returns the
# same one before mark-read completes. The TTL ensures the cache doesn't
# grow unbounded across long sessions.
_SEEN_MSG_IDS: dict = {}  # key -> timestamp (monotonic)
_SEEN_MSG_ORDER: deque = deque()
_SEEN_MSG_CAP = 2000
_SEEN_TTL = 300.0  # 5 minutes

# ============================================================
# Auto-wake: when agent is NOT in meshcode_wait and a message
# arrives, inject text into the terminal to wake the agent.
# ============================================================
_IN_WAIT = False  # True while meshcode_wait is blocking
# Default OFF — keystroke injection can corrupt stdin on some terminals.
# The primary nudge path is now in comms_v4.nudge_agent() which uses
# platform-specific window activation (SetForegroundWindow on Windows,
# AppleScript on macOS) + desktop notification.
# Set MESHCODE_AUTO_WAKE=1 to also inject text into the terminal from
# the MCP server side (useful if comms_v4 nudge doesn't reach the agent).
_AUTO_WAKE = os.environ.get("MESHCODE_AUTO_WAKE", "0").lower() in ("1", "true", "yes")

# ============================================================
# PID lockfile: prevent zombie MCP processes from accumulating.
# When Claude Code respawns the MCP server, the old process may
# still be alive. We write our PID to a lockfile on boot and
# kill any stale process found there first.
# ============================================================
import signal as _signal
import tempfile as _tempfile


def _pid_lockfile_path() -> str:
    """Return path to the PID lockfile for this agent."""
    agent = os.environ.get("MESHCODE_AGENT", "unknown")
    project = os.environ.get("MESHCODE_PROJECT", "unknown")
    safe_name = f"meshcode_mcp_{project}_{agent}.pid".replace("/", "_").replace(" ", "_")
    return os.path.join(_tempfile.gettempdir(), safe_name)


def _kill_stale_mcp_process() -> None:
    """Kill any stale MCP process for this agent found in the lockfile."""
    lockfile = _pid_lockfile_path()
    if not os.path.exists(lockfile):
        return
    try:
        with open(lockfile, "r") as f:
            old_pid = int(f.read().strip())
        if old_pid == os.getpid():
            return  # It's us
        # Check if process is alive
        os.kill(old_pid, 0)  # Signal 0 = existence check, no actual signal
        # Process is alive — kill it gracefully, then forcefully
        _mc_log(f"Killing stale MCP process (PID {old_pid})")
        os.kill(old_pid, _signal.SIGTERM)
        import time
        time.sleep(1)
        try:
            os.kill(old_pid, 0)  # Still alive?
            os.kill(old_pid, _signal.SIGKILL)
            _mc_log(f"Force-killed stale MCP process (PID {old_pid})")
        except OSError:
            pass  # Already dead after SIGTERM
    except (ValueError, FileNotFoundError):
        pass  # Corrupt or missing lockfile
    except OSError:
        pass  # Process not found (already dead)


def _write_pid_lockfile() -> None:
    """Write current PID to lockfile."""
    lockfile = _pid_lockfile_path()
    try:
        with open(lockfile, "w") as f:
            f.write(str(os.getpid()))
    except Exception as e:
        _mc_log(f"Warning: couldn't write PID lockfile: {e}", level="warn")


def _remove_pid_lockfile() -> None:
    """Remove PID lockfile on shutdown."""
    lockfile = _pid_lockfile_path()
    try:
        if os.path.exists(lockfile):
            os.remove(lockfile)
    except Exception:
        pass


def _try_auto_wake(from_agent: str, preview: str) -> None:
    """Inject a nudge into the terminal ONLY when agent is truly sleeping.

    macOS:  AppleScript → keystroke into Terminal/iTerm2
    Windows: PowerShell SendKeys to the console window
    Linux:  xdotool (best-effort)

    Conditions to fire (ALL must be true):
    - _AUTO_WAKE is enabled
    - from_agent != self  (never wake yourself on self-echo)
    - NOT in meshcode_wait (wait loop already handles delivery)
    - _current_state is 'sleeping' (truly idle, not working, not just online)
    - No tool calls in the last 30 seconds (broad idle window)
    - LLM CPU is low (not actively generating)
    Otherwise the keystroke would interrupt the user's typing or
    the LLM mid-thought.
    """
    if not _AUTO_WAKE or _IN_WAIT:
        return
    # Self-echo guard: never wake on a message you sent yourself.
    # Realtime can echo INSERTs back to the sender (or to all subscribers
    # in some routing paths) — without this guard, every meshcode_send by
    # the agent would inject AppleScript into its own terminal mid-session.
    if from_agent and AGENT_NAME and from_agent == AGENT_NAME:
        return
    # Only fire when agent is actually sleeping — never when working or online
    # (working = LLM generating; online = brief post-tool window; both would be interrupted)
    if _current_state != 'sleeping':
        return
    # Recent-activity guard: even if state says 'sleeping', any tool call
    # in the last 30s means the LLM was just typing or about to type. The
    # _IN_WAIT + state check has gaps between tool calls; this widens it.
    try:
        if (_time.time() - _last_tool_at) < 30.0:
            return
    except Exception:
        pass
    # Belt-and-suspenders: also check parent CPU is low (LLM not generating right now)
    try:
        if _get_parent_cpu() > 5.0:
            return  # LLM is actively generating, don't interrupt
    except Exception:
        pass
    import subprocess, platform, re
    # Sanitize inputs: strip everything except alphanumeric, spaces, basic punctuation
    safe_agent = re.sub(r'[^a-zA-Z0-9_\- ]', '', from_agent)[:50]
    safe_preview = re.sub(r'[^a-zA-Z0-9_\-.,!? ]', '', preview)[:60]
    # Plain-text nudge. ANSI colors were stripped 2026-04-16 because terminals
    # that don't interpret escape sequences (TypeScript runners, some VSCode
    # configurations, pipelines, tmux without termguicolors) render the raw
    # bytes — "[91m[1m[mesh][0m …" — which is worse UX than no color at all.
    nudge = f"[mesh] {safe_agent} > {safe_preview} — meshcode_check()"
    system = platform.system()
    try:
        if system == "Darwin":
            # Sanitize app_name — TERM_PROGRAM is an env var, not DB-sourced,
            # but defense-in-depth: only allow known terminal app names.
            parent_app = os.environ.get("TERM_PROGRAM", "Terminal")
            app_name = "iTerm" if "iTerm" in parent_app else "Terminal"
            # Escape for AppleScript string: replace backslash and double-quote.
            # nudge is already whitelist-sanitized (alphanum + _-.,!? space only).
            as_safe = nudge.replace("\\", "\\\\").replace('"', '\\"')
            script = f'''
            tell application "{app_name}"
                tell application "System Events"
                    keystroke "{as_safe}"
                    keystroke return
                end tell
            end tell
            '''
            subprocess.Popen(["osascript", "-e", script],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log.info(f"auto-wake: injected nudge via {app_name} AppleScript")
        elif system == "Windows":
            # Pass nudge text via environment variable instead of interpolating
            # into a PowerShell string — prevents any PS injection.
            ps_script = '''
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.SendKeys]::SendWait($env:MC_NUDGE_TEXT + "{ENTER}")
            '''
            env = {**os.environ, "MC_NUDGE_TEXT": nudge}
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_script],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=10, env=env)
            log.info("auto-wake: injected nudge via PowerShell SendKeys")
        else:
            # Linux — xdotool takes args directly, not shell-interpolated (safe)
            subprocess.Popen(["xdotool", "type", "--clearmodifiers", nudge + "\n"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log.info("auto-wake: injected nudge via xdotool")
    except Exception as e:
        log.debug(f"auto-wake failed: {e}")


def _seen_key(msg: Dict[str, Any]) -> str:
    """Build a dedupe key. Prefer the real row id; fall back to a synthetic."""
    mid = msg.get("id")
    if mid:
        return str(mid)
    payload = msg.get("payload") or {}
    try:
        payload_str = json.dumps(payload, sort_keys=True, default=str)[:50]
    except Exception:
        payload_str = str(payload)[:50]
    return f"{msg.get('from') or msg.get('from_agent')}|{msg.get('ts') or msg.get('created_at')}|{payload_str}"


def _evict_expired() -> None:
    """Remove entries older than _SEEN_TTL from the dedup cache."""
    now = _time.monotonic()
    while _SEEN_MSG_ORDER:
        oldest_key = _SEEN_MSG_ORDER[0]
        ts = _SEEN_MSG_IDS.get(oldest_key)
        if ts is not None and (now - ts) > _SEEN_TTL:
            _SEEN_MSG_ORDER.popleft()
            _SEEN_MSG_IDS.pop(oldest_key, None)
        else:
            break


def _mark_seen(key: str) -> None:
    now = _time.monotonic()
    if key in _SEEN_MSG_IDS:
        # Refresh timestamp on re-sight (extends TTL)
        _SEEN_MSG_IDS[key] = now
        return
    _SEEN_MSG_IDS[key] = now
    _SEEN_MSG_ORDER.append(key)
    # Evict expired + cap enforcement
    _evict_expired()
    while len(_SEEN_MSG_ORDER) > _SEEN_MSG_CAP:
        old = _SEEN_MSG_ORDER.popleft()
        _SEEN_MSG_IDS.pop(old, None)


def _filter_and_mark(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Drop already-seen messages; mark the rest as seen."""
    _evict_expired()  # Clean stale entries before checking
    out = []
    for m in messages:
        k = _seen_key(m)
        if k in _SEEN_MSG_IDS:
            continue
        _mark_seen(k)
        out.append(m)
    return out


def _split_messages(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Split a list of normalized message dicts into messages / acks / done_signals."""
    real: List[Dict[str, Any]] = []
    acks: List[Dict[str, Any]] = []
    dones: List[Dict[str, Any]] = []
    for m in messages:
        t = m.get("type", "msg")
        if t == "ack":
            acks.append(m)
        elif t == "done":
            dones.append(m)
        else:
            real.append(m)
    return {
        "messages": real,
        "acks": acks,
        "done_signals": dones,
        "count": len(real),
    }

from . import backend as be
from .realtime import RealtimeListener

# ============================================================
# Session Replay: unique session ID per MCP server boot.
# Events are recorded in background threads (fire-and-forget).
# ============================================================
import uuid as _uuid
_SESSION_ID = str(_uuid.uuid4())[:12]


def _record_event_bg(event_type: str, payload: dict = None) -> None:
    """Fire-and-forget: record a session event in background thread."""
    try:
        api_key = _get_api_key()
        import threading
        threading.Thread(
            target=be.record_event,
            args=(api_key, _PROJECT_ID, AGENT_NAME, _SESSION_ID, event_type, payload or {}),
            daemon=True,
        ).start()
    except Exception:
        pass


# ============================================================
# Hot-reload: detect when backend.py changes on disk (e.g. after
# pip install --upgrade meshcode) and reload without restart.
# Only backend.py is safe to reload (stateless). server.py has
# module-level state that would be destroyed by reload.
# ============================================================
import importlib as _importlib
_be_mtime: float = 0.0
try:
    _be_path = os.path.abspath(be.__file__)
    _be_mtime = os.path.getmtime(_be_path)
except Exception:
    _be_path = ""


def _capture_session() -> None:
    """Stash the MCP session ref for silent auto-wake when agent is idle."""
    global _STASHED_SESSION
    if _STASHED_SESSION is not None:
        return
    try:
        srv = mcp._mcp_server
        ctx = getattr(srv, "request_context", None)
        if ctx and getattr(ctx, "session", None):
            _STASHED_SESSION = ctx.session
            log.info("[meshcode] MCP session stashed for silent auto-wake")
    except Exception:
        pass


def _check_hot_reload() -> None:
    """If backend.py was modified since boot/last reload, reimport it."""
    global _be_mtime, be
    if not _be_path:
        return
    try:
        current_mtime = os.path.getmtime(_be_path)
        if current_mtime > _be_mtime:
            _be_mtime = current_mtime
            _importlib.reload(be)
            log.info("[meshcode] Hot-reloaded backend.py (new version detected)")
    except Exception as e:
        log.debug(f"hot-reload check failed: {e}")

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print(
        "[meshcode-mcp] ERROR: mcp package not installed. Run: pip install 'mcp[cli]>=1.0'",
        file=sys.stderr,
    )
    sys.exit(2)

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="[meshcode-mcp] %(message)s")
log = logging.getLogger("meshcode-mcp")


# ============================================================
# Server context — agent identity from env vars
# ============================================================

PROJECT_NAME = os.environ.get("MESHCODE_PROJECT", "")
AGENT_NAME = os.environ.get("MESHCODE_AGENT", "")
AGENT_ROLE = os.environ.get("MESHCODE_ROLE", "")
EDITOR_TYPE = os.environ.get("MESHCODE_EDITOR_TYPE", "")

if not PROJECT_NAME or not AGENT_NAME:
    print(
        "[meshcode-mcp] ERROR: MESHCODE_PROJECT and MESHCODE_AGENT env vars required",
        file=sys.stderr,
    )
    sys.exit(2)

# ============================================================
# CWD check — warn if user opened Claude from the wrong directory
# ============================================================
# On Windows (and sometimes macOS), users open Claude Code from their home
# directory instead of the workspace where .mcp.json lives. The MCP server
# still loads (env vars come from .mcp.json), but the agent can't access
# workspace files. Warn early so the user knows to use `meshcode run`.

_cwd = os.getcwd()
_cwd_has_mcp = os.path.exists(os.path.join(_cwd, ".mcp.json"))
_home = os.path.expanduser("~")
if not _cwd_has_mcp and os.path.normpath(_cwd) == os.path.normpath(_home):
    _mc_log(
        f"Current directory is your home folder ({_cwd}). "
        f"This agent's workspace may be elsewhere. "
        f"For best results, use: meshcode run {AGENT_NAME}",
        "warn",
    )
elif not _cwd_has_mcp:
    _mc_log(
        f"No .mcp.json found in {_cwd}. "
        f"If tools can't find your files, try: meshcode run {AGENT_NAME}",
        "warn",
    )

# ============================================================
# API key resolution — keychain first, env var fallback
# ============================================================
#
# 1.4.1+ stores api keys in the OS keychain. The setup_clients writer
# bakes only MESHCODE_KEYCHAIN_PROFILE into the .mcp.json env block, NOT
# the api key itself. The MCP server resolves the key at boot via the
# secrets module. The env-var path is preserved as a fallback for users
# whose OS doesn't have a keychain backend.

_API_KEY_CACHE: Optional[str] = None

def _get_api_key() -> str:
    """Resolve the api_key for this MCP server process. Cached after first call."""
    global _API_KEY_CACHE
    if _API_KEY_CACHE is not None:
        return _API_KEY_CACHE
    # 1. Direct env var (legacy / fallback path)
    val = os.environ.get("MESHCODE_API_KEY", "").strip()
    if val:
        _API_KEY_CACHE = val
        return val
    # 2. Keychain via profile name in env
    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE", "").strip()
    if profile:
        try:
            import importlib
            secrets_mod = importlib.import_module("meshcode.secrets")
            kc_val = secrets_mod.get_api_key(profile=profile)
            if kc_val:
                _API_KEY_CACHE = kc_val
                return kc_val
        except Exception as e:
            _mc_log(f" keychain lookup failed for profile '{profile}': {e}", "warn")
    _API_KEY_CACHE = ""
    return ""


# Resolve project_id at startup with retry+backoff. Try in order:
#   1. MESHCODE_PROJECT_ID env var (baked by `meshcode setup`, fastest)
#   2. mc_resolve_project RPC with the user's api_key (security definer, bypasses RLS)
#   3. Direct SELECT via get_project_id (only works if RLS is open / user is admin)
_PROJECT_ID: Optional[str] = os.environ.get("MESHCODE_PROJECT_ID") or None
if not _PROJECT_ID:
    _BOOT_MAX_RETRIES = 3
    _BOOT_BACKOFF = [2, 5, 10]  # seconds between retries
    for _boot_attempt in range(_BOOT_MAX_RETRIES):
        _api_key = _get_api_key()
        if _api_key:
            try:
                _r = be.sb_rpc("mc_resolve_project", {
                    "p_api_key": _api_key,
                    "p_project_name": PROJECT_NAME,
                })
                if isinstance(_r, dict) and _r.get("project_id"):
                    _PROJECT_ID = _r["project_id"]
                    break
                elif isinstance(_r, dict) and _r.get("error"):
                    _mc_log(f" mc_resolve_project: {_r['error']}", "warn")
            except Exception as _e:
                _mc_log(f" mc_resolve_project failed: {_e}", "warn")
        if not _PROJECT_ID:
            _PROJECT_ID = be.get_project_id(PROJECT_NAME)
        if _PROJECT_ID:
            break
        if _boot_attempt < _BOOT_MAX_RETRIES - 1:
            _wait = _BOOT_BACKOFF[_boot_attempt]
            _mc_log(f" project resolution failed (attempt {_boot_attempt+1}/{_BOOT_MAX_RETRIES}), retrying in {_wait}s...", "warn")
            import time; time.sleep(_wait)
if not _PROJECT_ID:
    _mc_log(f"project '{PROJECT_NAME}' not found after {_BOOT_MAX_RETRIES} attempts (check MESHCODE_KEYCHAIN_PROFILE / MESHCODE_API_KEY)", "error")
    sys.exit(2)

# Resolve project plan for adaptive features (heartbeat interval, etc.)
_PROJECT_PLAN = "free"
try:
    _plan_rows = be.sb_select("mc_projects", f"id=eq.{_PROJECT_ID}", limit=1)
    if _plan_rows and isinstance(_plan_rows, list) and len(_plan_rows) > 0:
        _PROJECT_PLAN = _plan_rows[0].get("plan", "free") or "free"
except Exception:
    pass  # default to free

_register_result = be.register_agent(PROJECT_NAME, AGENT_NAME, AGENT_ROLE or "MCP-connected agent", api_key=_get_api_key())
if isinstance(_register_result, dict) and _register_result.get("error"):
    _mc_log(f" register failed: {_register_result['error']}", "warn")

# ── Fetch profile color from dashboard (single source of truth) ──
try:
    _agent_rows = be.sb_select("mc_agents", f"project_id=eq.{_PROJECT_ID}&name=eq.{AGENT_NAME}", limit=1)
    if _agent_rows and isinstance(_agent_rows, list) and len(_agent_rows) > 0:
        _aid = _agent_rows[0].get("id")
        if _aid:
            _prof_rows = be.sb_select("mc_agent_profiles", f"agent_id=eq.{_aid}", limit=1)
            if _prof_rows and isinstance(_prof_rows, list) and len(_prof_rows) > 0:
                _hex = _prof_rows[0].get("color") or ""
                if _hex and len(_hex.lstrip("#")) == 6:
                    _resolved = _hex_to_ansi(_hex)
                    if _resolved:
                        _CACHED_AGENT_COLOR = _resolved
except Exception:
    pass  # Non-critical — falls back to hash

# Flip to online so the dashboard reflects the live MCP session.
# Use the SECURITY DEFINER RPC (mc_agent_set_status_by_api_key) so we
# bypass RLS — the publishable key has no JWT context and cannot UPDATE
# mc_agents directly. The RPC validates ownership via api_key.
def _flip_status(status: str, task: str = "", editor: Optional[str] = None) -> bool:
    """Write status via RPC for reliable updates (anon PATCH silently fails).

    Falls back to direct PATCH only when no api_key is available (tests).
    """
    try:
        result = be.set_status(_PROJECT_ID, AGENT_NAME, status, task, api_key=_get_api_key(), editor=editor)
        return isinstance(result, dict) and result.get("ok", False)
    except Exception:
        return False

if not _flip_status("idle", "", editor=EDITOR_TYPE or None):
    _mc_log(f" could not flip status to idle", "warn")


# ============================================================
# Automatic Agent Status State Machine
# States: ONLINE → WORKING → ONLINE → WAITING → ONLINE → IDLE → OFFLINE
# Transitions driven by tool calls and meshcode_wait, not the LLM.
# ============================================================
import functools as _functools
import threading as _threading
import time as _time

_flip_lock = _threading.Lock()
_current_state = "online"
_last_tool_at = _time.time()
_current_tool = ""
_IDLE_THRESHOLD_S = 120  # seconds without tool call → IDLE
_SLEEPING_THRESHOLD_S = 300  # seconds in waiting without activity → SLEEPING
_WORKING_COOLDOWN_S = 60  # seconds after last tool returns before flipping to ONLINE
_working_timer: Optional[_threading.Timer] = None


async def _async_flip_status(status: str, task: str = "") -> None:
    try:
        await asyncio.to_thread(_flip_status_locked, status, task)
    except Exception as e:
        log.debug(f"flip_status({status}) failed: {e}")


def _flip_status_locked(status: str, task: str = "") -> bool:
    """Thread-safe wrapper around _flip_status to prevent concurrent RPCs."""
    with _flip_lock:
        return _flip_status(status, task)


def _schedule_flip(status: str, task: str = "") -> None:
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_async_flip_status(status, task))
    except RuntimeError:
        # No running loop (sync context) — run in a throwaway thread
        _threading.Thread(
            target=_flip_status_locked, args=(status, task), daemon=True
        ).start()


def _set_state(state: str, tool: str = "") -> None:
    """Update the state machine and broadcast to dashboard."""
    global _current_state, _current_tool, _last_tool_at, _working_timer
    # Cancel any pending working→online timer
    if _working_timer is not None:
        _working_timer.cancel()
        _working_timer = None
    _current_state = state
    _current_tool = tool
    if state == "working":
        _last_tool_at = _time.time()
    _schedule_flip(state, tool)


def _working_to_online() -> None:
    """Called after WORKING cooldown expires — flip to ONLINE."""
    global _working_timer
    _working_timer = None
    if _current_state == "working":
        _set_state("online", "")


def _auto_learn_error(tool_name: str, error: Exception, args_keys: list) -> None:
    """Auto-save failed tool calls to agent memory for self-improvement."""
    try:
        import datetime as _dt
        key = f"error_{tool_name}_{_dt.date.today().isoformat()}"
        be.sb_rpc("mc_memory_set", {
            "p_api_key": _get_api_key(),
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_key": key,
            "p_value": {
                "tool": tool_name,
                "error": str(error)[:200],
                "args_keys": args_keys,
                "timestamp": _dt.datetime.utcnow().isoformat(),
            },
        })
    except Exception:
        pass  # Never let error-learning itself cause failures


# ── Activity feed auto-logger ──────────────────────────────────
# Logs tool calls to mc_activity for the live dashboard feed.
# Background thread, fire-and-forget — never blocks tool execution.
_ACTIVITY_LOG_SKIP = {"meshcode_wait", "meshcode_check", "meshcode_set_status",
                      "meshcode_recall", "meshcode_recall_keys", "meshcode_recall_search",
                      "meshcode_health", "meshcode_status", "meshcode_debug_sleep"}

def _log_activity_bg(event_type: str, summary: str) -> None:
    """Fire-and-forget activity logging in background thread."""
    try:
        import threading
        def _do():
            try:
                api_key = _get_api_key()
                if api_key:
                    be.sb_rpc("mc_log_activity", {
                        "p_api_key": api_key,
                        "p_event_type": event_type,
                        "p_summary": summary[:200],
                    })
            except Exception:
                pass
        threading.Thread(target=_do, daemon=True).start()
    except Exception:
        pass


def with_working_status(func):
    name = func.__name__
    skip = (name == "meshcode_wait")
    if asyncio.iscoroutinefunction(func):
        @_functools.wraps(func)
        async def awrapper(*args, **kwargs):
            _check_hot_reload()
            _capture_session()  # stash session on first tool call for silent auto-wake
            if not skip:
                global _CONSECUTIVE_IDLE_SECONDS
                _CONSECUTIVE_IDLE_SECONDS = 0  # any non-wait tool resets idle timer
                _set_state("working", name)
                # Estimate input tokens (chars/4) for usage tracking
                _est_tokens = sum(len(str(v)) for v in kwargs.values()) // 4
                _record_event_bg("tool_call", {"tool": name, "args_keys": list(kwargs.keys()), "estimated_tokens": _est_tokens})
            try:
                result = await func(*args, **kwargs)
                # Auto-log to activity feed (skip noisy read-only tools)
                if not skip and name not in _ACTIVITY_LOG_SKIP:
                    _log_activity_bg("tool_call", f"{AGENT_NAME}: {name}")
                return result
            except asyncio.CancelledError:
                log.debug(f"[meshcode] tool {name} cancelled by client (ESC)")
                return {"error": "cancelled_by_client", "tool": name}
            except Exception as e:
                if not skip:
                    _auto_learn_error(name, e, list(kwargs.keys()))
                raise
            finally:
                if not skip:
                    global _last_tool_at
                    _last_tool_at = _time.time()
        return awrapper
    else:
        @_functools.wraps(func)
        def swrapper(*args, **kwargs):
            _check_hot_reload()
            _capture_session()  # stash session on first tool call for silent auto-wake
            if not skip:
                global _CONSECUTIVE_IDLE_SECONDS
                _CONSECUTIVE_IDLE_SECONDS = 0  # any non-wait tool resets idle timer
                _set_state("working", name)
                _est_tokens = sum(len(str(v)) for v in kwargs.values()) // 4
                _record_event_bg("tool_call", {"tool": name, "args_keys": list(kwargs.keys()), "estimated_tokens": _est_tokens})
            try:
                result = func(*args, **kwargs)
                if not skip and name not in _ACTIVITY_LOG_SKIP:
                    _log_activity_bg("tool_call", f"{AGENT_NAME}: {name}")
                return result
            except Exception as e:
                if not skip:
                    _auto_learn_error(name, e, list(kwargs.keys()))
                raise
            finally:
                if not skip:
                    global _last_tool_at
                    _last_tool_at = _time.time()
        return swrapper


# ============================================================
# Single-instance lease — prevent split-brain when two windows
# run `meshcode run <same-agent>` simultaneously.
# ============================================================
import uuid as _uuid
_INSTANCE_ID = f"mcp-{_uuid.uuid4().hex[:12]}"

def _acquire_lease() -> bool:
    api_key = _get_api_key()
    if not api_key:
        return True  # legacy clients without api_key skip lease check
    import time as _time
    # Pre-clean any stale lease for our agent name before attempting.
    # This auto-heals ghost leases from dead sessions (any status).
    try:
        be.sb_rpc("mc_force_clear_stale_lease", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
        })
    except Exception as e:
        # Non-fatal: RPC might not exist on older servers.
        _mc_log(f"stale-lease pre-clean skipped: {e}", "warn")
    for attempt in range(3):
        try:
            r = be.sb_rpc("mc_acquire_agent_lease", {
                "p_api_key": api_key,
                "p_project_id": _PROJECT_ID,
                "p_agent_name": AGENT_NAME,
                "p_instance_id": _INSTANCE_ID,
            })
            if isinstance(r, dict) and r.get("ok"):
                return True
            if isinstance(r, dict) and r.get("error"):
                err = str(r.get("error", ""))
                if "already running" in err:
                    if attempt < 2:
                        # The old lease might be stale — wait and retry
                        # (the 90s stale check in the RPC should clear it)
                        _mc_log(f"Lease held by another instance — retrying in {2 * (attempt+1)}s...")
                        _time.sleep(2 * (attempt + 1))
                        continue
                    # Final attempt — force release the old lease and try once more
                    _mc_log("Force-releasing stale lease...")
                    try:
                        be.sb_rpc("mc_release_agent_lease", {
                            "p_api_key": api_key,
                            "p_project_id": _PROJECT_ID,
                            "p_agent_name": AGENT_NAME,
                            "p_instance_id": r.get("current_instance", r.get("held_by", "unknown")),
                        })
                    except Exception:
                        # Force clear via direct update
                        try:
                            be.set_status(_PROJECT_ID, AGENT_NAME, "offline", "", api_key=_get_api_key())
                        except Exception:
                            pass
                    _time.sleep(1)
                    # One more try after force-release
                    try:
                        r2 = be.sb_rpc("mc_acquire_agent_lease", {
                            "p_api_key": api_key,
                            "p_project_id": _PROJECT_ID,
                            "p_agent_name": AGENT_NAME,
                            "p_instance_id": _INSTANCE_ID,
                        })
                        if isinstance(r2, dict) and r2.get("ok"):
                            _mc_log("Lease acquired after force-release.")
                            return True
                    except Exception:
                        pass
                    _mc_log(f"Could not start — agent '{AGENT_NAME}' is running in another window.", "error")
                    _mc_log("Close the other window first, or use a different agent name.", "error")
                    return False
                _mc_log(f"lease attempt {attempt+1}: {r.get('error')}", "warn")
            else:
                return True
        except Exception as e:
            _mc_log(f"lease attempt {attempt+1} failed: {e}", "warn")
        if attempt < 2:
            _time.sleep(2)
    _mc_log(f" lease failed after 3 attempts — proceeding anyway", "warn")
    return True

if not _acquire_lease():
    sys.exit(2)


def _boot_diagnostic() -> None:
    """Run non-fatal boot health checks. Print clear warnings on failure."""
    checks_passed = 0
    checks_total = 4
    api_key = _get_api_key()

    # Check 1: API reachable
    try:
        be.sb_select("mc_projects", f"id=eq.{_PROJECT_ID}", limit=1)
        checks_passed += 1
    except Exception as e:
        print(f"[meshcode] BOOT CHECK FAILED: Supabase API unreachable ({e}). Fix: check network/VPN.", file=sys.stderr)

    # Check 2: Lease valid
    try:
        r = be.sb_select("mc_agents", f"project_id=eq.{_PROJECT_ID}&name=eq.{AGENT_NAME}", limit=1)
        if r and isinstance(r, list) and len(r) > 0:
            agent = r[0]
            if agent.get("instance_id") == _INSTANCE_ID:
                checks_passed += 1
            else:
                print(f"[meshcode] BOOT CHECK FAILED: Lease mismatch — expected {_INSTANCE_ID}, got {agent.get('instance_id')}. Fix: restart agent.", file=sys.stderr)
        else:
            print(f"[meshcode] BOOT CHECK FAILED: Agent '{AGENT_NAME}' not found in project. Fix: register agent first.", file=sys.stderr)
    except Exception as e:
        print(f"[meshcode] BOOT CHECK FAILED: Could not verify lease ({e}).", file=sys.stderr)

    # Check 3: Heartbeat recent
    try:
        if r and isinstance(r, list) and len(r) > 0:
            hb = agent.get("last_heartbeat")
            if hb:
                checks_passed += 1
            else:
                print(f"[meshcode] BOOT CHECK WARNING: No heartbeat recorded yet.", file=sys.stderr)
        else:
            checks_passed += 1  # skip if no agent data
    except Exception:
        checks_passed += 1  # skip on error

    # Check 4: Version tracking
    try:
        from meshcode import __version__
        be.sb_update("mc_agents",
                     f"project_id=eq.{_PROJECT_ID}&name=eq.{AGENT_NAME}",
                     {"mc_version": __version__})
        checks_passed += 1
    except Exception:
        checks_passed += 1  # non-critical

    # Check 5: Claude Code version compatibility
    checks_total += 1
    try:
        from meshcode.compat import check as cc_check, get_runtime_adjustments, RECOMMENDED_VERSION
        cc_ver, cc_status, cc_entry = cc_check()
        if cc_status == "safe":
            checks_passed += 1
        elif cc_status == "broken":
            issues = "; ".join(cc_entry.get("issues", []))
            print(f"[meshcode] WARNING: Claude Code {cc_ver} has known issues: {issues}", file=sys.stderr)
            print(f"[meshcode] Recommended: {RECOMMENDED_VERSION}. Run: meshcode doctor", file=sys.stderr)
            # Apply runtime adjustments for broken versions
            _cc_adjustments = get_runtime_adjustments(cc_ver)
            if _cc_adjustments.get("warn_on_boot"):
                try:
                    be.sb_rpc("mc_memory_set", {
                        "p_api_key": api_key,
                        "p_agent_name": AGENT_NAME,
                        "p_project_id": _PROJECT_ID,
                        "p_key": "cc_version_warning",
                        "p_value": {
                            "version": cc_ver,
                            "status": "broken",
                            "issues": cc_entry.get("issues", []),
                        },
                    })
                except Exception:
                    pass
        elif cc_status == "unknown":
            checks_passed += 1  # unknown = assume OK with note
            if cc_ver != "not found":
                print(f"[meshcode] Note: Claude Code {cc_ver} not in compatibility matrix (assuming OK).", file=sys.stderr)
        else:
            checks_passed += 1  # degraded = warn but count as passed
    except Exception:
        checks_passed += 1  # non-critical

    if checks_passed == checks_total:
        print(f"[meshcode] All boot checks passed ({checks_passed}/{checks_total}).", file=sys.stderr)
    else:
        print(f"[meshcode] Boot checks: {checks_passed}/{checks_total} passed. Agent starting anyway.", file=sys.stderr)


_boot_diagnostic()


def _release_lease() -> None:
    api_key = _get_api_key()
    if not api_key:
        return
    try:
        be.sb_rpc("mc_release_agent_lease", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_instance_id": _INSTANCE_ID,
        })
    except Exception:
        pass


# ── Crash logging + graceful shutdown ──────────────────────────
_SHUTDOWN_LOGGED = False


def _log_crash_to_db(reason: str = "unknown", error_detail: str = "") -> None:
    """Best-effort crash log to mc_agent_crash_logs table. Non-fatal if table doesn't exist."""
    global _SHUTDOWN_LOGGED
    # Only suppress duplicates for process-level shutdown events, not tool exceptions
    if reason in ("process_exit", "signal", "keyboard_interrupt", "system_exit", "unhandled_exception"):
        if _SHUTDOWN_LOGGED:
            return
        _SHUTDOWN_LOGGED = True
    try:
        be.sb_rpc("mc_log_error", {
            "p_api_key": _get_api_key(),
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_error_type": reason,
            "p_error_detail": error_detail[:2000],
            "p_instance_id": _INSTANCE_ID,
        })
    except Exception:
        # Table may not exist yet — fall back to status update
        try:
            be.set_status(_PROJECT_ID, AGENT_NAME, "offline",
                          f"crashed: {reason[:100]}", api_key=_get_api_key())
        except Exception:
            pass
    _mc_log(f" crash logged: {reason}", "warn")



# NOTE: Do NOT install custom SIGTERM handlers or atexit hooks here — network
# calls inside them can deadlock the event loop. The lease is released by the
# lifespan shutdown handler instead.
#
# SIGINT handling is special — see run_server() for why we set SIG_IGN there.


# ============================================================
# Agent identity from Supabase profile (for system instructions)
# ============================================================

_LAUNCH_PROMPT = ""
_ROLE_DESCRIPTION = AGENT_ROLE or ""
try:
    _profile = be.sb_rpc("mc_agent_get_profile", {
        "p_project_id": _PROJECT_ID,
        "p_agent_name": AGENT_NAME,
    })
    if isinstance(_profile, list) and _profile:
        _profile = _profile[0]
    if isinstance(_profile, dict):
        _inner = _profile.get("profile") if isinstance(_profile.get("profile"), dict) else _profile
        _LAUNCH_PROMPT = (_inner.get("launch_prompt") or _profile.get("launch_prompt") or "") if isinstance(_inner, dict) else ""
        _ROLE_DESCRIPTION = (
            (_inner.get("role_description") if isinstance(_inner, dict) else None)
            or _profile.get("role_description")
            or _profile.get("role")
            or AGENT_ROLE
            or "(unspecified)"
        )
except Exception as _e:
    log.warning(f"could not fetch agent profile: {_e}")


# ── Leader/commander detection (single source of truth) ───────
_LEADER_KEYWORDS = (
    'commander', 'lead', 'orchestrat', 'coordinator', 'coordinat',
    'coordinad', 'jefe', 'líder', 'lider', 'director', 'manager',
    'chief', 'captain', 'boss', 'head agent',
)

def _is_leader_agent() -> bool:
    """Check if this agent is a leader/commander based on name + role keywords."""
    haystack = ((_ROLE_DESCRIPTION or '') + ' ' + AGENT_NAME).lower()
    return any(k in haystack for k in _LEADER_KEYWORDS)


def _build_instructions() -> str:
    """Build the system-instructions block injected via the MCP InitializeResult.

    Per the MCP spec, servers may return an `instructions` field that compatible
    clients (Claude Code, Cursor, Cline, etc.) merge into the model's system
    context at session start. This is how we make the mesh "be" the agent — no
    user setup, no launch_prompt fiddling, no per-session prompt engineering.
    """
    role_block = f"\nROLE: {_ROLE_DESCRIPTION}\n" if _ROLE_DESCRIPTION else ""
    launch_block = (
        f"\nUSER-PROVIDED ROLE PROMPT (from the dashboard):\n---\n{_LAUNCH_PROMPT}\n---\n"
        if _LAUNCH_PROMPT else ""
    )
    # Pull the canonical loop directive from the DB so product can tune it
    # without a client release. Falls back to the baked-in version below if
    # the RPC isn't available (older DB) or the call fails.
    _db_loop = ""
    try:
        _r = be.sb_rpc("mc_get_loop_directive", {})
        if isinstance(_r, list) and _r:
            _r = _r[0]
        if isinstance(_r, str) and _r.strip():
            _db_loop = _r.strip() + "\n\n"
    except Exception:
        pass

    base = f"""You are agent "{AGENT_NAME}" in meshwork "{PROJECT_NAME}".{role_block}{launch_block}

{_db_loop}PERMANENT LOOP (MANDATORY — #1 RULE):
You MUST stay in meshcode_wait() forever. After EVERY action, call meshcode_wait().
NEVER exit. NEVER stop. NEVER say "standing by" without calling meshcode_wait().
The ONLY exits: user says "stop", got_done signal, or fatal error.
Timeout? Call meshcode_wait() again with 2x timeout (cap 1800s).

LOOP: act → meshcode_send if needed → meshcode_wait() → repeat.

RULES:
- Use MCP tools only (never CLI commands in bash).
- Tasks > messages. Claim tasks via meshcode_tasks/task_claim/task_complete.
- Messages <100 tokens. Long content → create task.
- No empty acks. JSON reports only.
- Threading: pass in_reply_to.
- sensitive=True for secrets/PII.

SESSION START (do these IMMEDIATELY — don't wait for user input):
The moment you see these instructions — whether the user said "boot", "hi",
nothing at all, or anything else — run the full protocol. Never reply with
only a memory summary and then idle. If your client defers MCP tool schemas
(shows tool names without parameters), your FIRST action is to load them:
  ToolSearch(query="select:meshcode_set_status,meshcode_check,meshcode_tasks,meshcode_auto_wake,meshcode_status,meshcode_wait,meshcode_send,meshcode_task_claim,meshcode_task_complete,meshcode_remember,meshcode_recall")
Then execute:
1. meshcode_set_status(status="online", task="ready")
2. meshcode_check() — read NEW messages only (last_seen is auto-restored from mesh memory on boot, old messages are skipped automatically)
3. meshcode_tasks() — check for assigned/pending tasks and claim any unclaimed ones
4. meshcode_auto_wake() — scan meshwork health, create tasks for issues found
5. meshcode_status() — see who's online
6. If other agents are online → meshcode_send them a greeting
7. meshcode_wait() — enter the loop
DO NOT ASK THE USER "what do you want to work on" — the mesh tells you via tasks/messages.

CRITICAL: You communicate by CALLING TOOLS, not by thinking or writing text.
To talk to another agent → call meshcode_send(to="agent", message="...")
To check who's online → call meshcode_status()
To wait for messages → call meshcode_wait()
NEVER just describe what you would do. DO IT by calling the tool.

CROSS-MESH: meshcode_send(to="agent@meshwork") routes via active link.
meshcode_link(target) creates pending link, target accepts. Expand with
meshcode_expand_link(). No sensitive msgs cross-mesh.

MEMORY: meshcode_remember(key, value) persists across sessions.
meshcode_recall(key?) retrieves. meshcode_forget(key) deletes.
Only remember reusable learnings: mistakes, feedback, patterns, preferences.
Do NOT save task summaries — tasks already persist in the task system.
Do NOT use memory for session state or ephemeral data.
Save reusable code patterns as template_* keys for instant recall.

SCRATCHPAD: meshcode_scratchpad_set/get for shared meshwork-level context
(decisions, conventions, architecture notes). All agents can read/write.

ACCOUNT MANAGEMENT: you can create meshworks (meshcode_create_meshwork),
add agents (meshcode_add_agent), edit roles/prompts (meshcode_edit_agent),
and edit other agents' memory (meshcode_edit_memory). Always tell the user
what CLI command to run next (e.g. "meshcode run backend in a new terminal").

Setup help → README.md or https://meshcode.io/docs
"""
    # Inject commander protocol if this agent is a leader
    is_leader = _is_leader_agent()
    if is_leader:
        base += """
COMMANDER PROTOCOL (you are the team lead):
- ALWAYS delegate via meshcode_task_create, NEVER via long messages.
- Tasks are the source of truth. Messages are signals only (<100 tokens).
- Workflow: identify work → create task → signal assignee → poll progress → verify → next.
- Poll meshcode_tasks() to track completion. Don't wait for messages.
- Verify builds/quality before approving. Don't approve blindly.
- Communicate changes to affected agents IMMEDIATELY after you make them.
- Organize: break big requests into multiple tasks, assign to the right agent.
- Keep the human informed with brief status updates at milestones.
- You are autonomous: fix small issues yourself, delegate big ones.
- After each sprint: consolidate learnings, update scratchpad, save to memory.
- PROACTIVE MAINTENANCE: call meshcode_auto_wake() on session start and after
  completing sprints. It scans meshwork health (stale agents, task backlog,
  empty memories). Turn suggestions into real tasks — quality over quantity.
"""
    return base


_INSTRUCTIONS = _build_instructions()

# Pre-load persistent memories into instructions (tiered, ~10x cheaper than legacy
# load-all). Strategy:
#   - critical: full content always preloaded (cap 10 keys per agent)
#   - reference: key list only (fetch values on demand via meshcode_recall)
#   - episodic: NEVER preloaded — search via meshcode_recall_search instead
# Falls back to legacy load-all if migration 080 isn't applied yet (overload missing).
try:
    _api_key = _get_api_key()
    _crit = be.sb_rpc("mc_memory_list", {
        "p_api_key": _api_key,
        "p_agent_name": AGENT_NAME,
        "p_tier": "critical",
        "p_project_name": PROJECT_NAME,
    })
    _ref = be.sb_rpc("mc_memory_list", {
        "p_api_key": _api_key,
        "p_agent_name": AGENT_NAME,
        "p_tier": "reference",
        "p_project_name": PROJECT_NAME,
    })

    _crit_ok = isinstance(_crit, dict) and _crit.get("ok")
    _ref_ok = isinstance(_ref, dict) and _ref.get("ok")

    if _crit_ok or _ref_ok:
        _sections = []
        if _crit_ok and _crit.get("memories"):
            _crit_lines = [f"  {m['key']}: {json.dumps(m['value'], default=str)}"
                           for m in _crit["memories"]]
            _sections.append("CRITICAL MEMORIES (always loaded):\n" + "\n".join(_crit_lines))
        if _ref_ok and _ref.get("memories"):
            _ref_keys = [m["key"] for m in _ref["memories"]]
            _sections.append(
                "REFERENCE MEMORIES (key list — fetch on demand via meshcode_recall(key)):\n  "
                + ", ".join(_ref_keys)
            )
        _sections.append(
            "EPISODIC MEMORIES: not preloaded. Search via "
            "meshcode_recall_search(query) when you need past incident context."
        )
        _INSTRUCTIONS += "\n" + "\n\n".join(_sections) + "\n"
        log.info(
            f"pre-loaded tiered memories: critical={len(_crit.get('memories', [])) if _crit_ok else 0}, "
            f"reference={len(_ref.get('memories', [])) if _ref_ok else 0}"
        )
    else:
        # Legacy fallback: migration 080 not applied → load all (old behavior)
        _legacy = be.sb_rpc("mc_memory_list", {
            "p_api_key": _api_key,
            "p_agent_name": AGENT_NAME,
            "p_project_name": PROJECT_NAME,
        })
        if isinstance(_legacy, dict) and _legacy.get("ok") and _legacy.get("memories"):
            _mem_lines = [f"  {m['key']}: {json.dumps(m['value'], default=str)}"
                          for m in _legacy["memories"]]
            _INSTRUCTIONS += "\nPRE-LOADED MEMORIES (legacy):\n" + "\n".join(_mem_lines) + "\n"
            log.info(f"pre-loaded {len(_mem_lines)} memories (legacy fallback)")
except Exception as _e:
    log.debug(f"memory pre-load skipped: {_e}")


# ============================================================
# Realtime listener (created in lifespan)
# ============================================================

_REALTIME: Optional[RealtimeListener] = None


async def _on_new_message(msg: Dict[str, Any]) -> None:
    """Best-effort: try to push an MCP resource-updated notification.

    If the underlying session supports send_resource_updated_notification,
    use it. If not (older MCP versions or unsupported), the message is
    still queued and meshcode_check / next-tool-call will surface it.

    If auto-wake is enabled and agent is NOT in meshcode_wait, inject a
    nudge into the terminal via OS automation (AppleScript/PowerShell).
    """
    # Auto-wake: if agent is idle (not in wait loop), nudge the terminal
    from_agent = msg.get("from") or msg.get("from_agent") or "unknown"
    payload = msg.get("payload") or {}
    if isinstance(payload, dict):
        # Try common content fields in order of usefulness
        preview = (
            payload.get("text")
            or payload.get("message")
            or payload.get("action")
            or payload.get("context")
            or payload.get("type")
            or (str(next(iter(payload.values()))) if payload else "")
        )
        preview = str(preview) if preview else "(see inbox)"
    else:
        preview = str(payload)
    try:
        _try_auto_wake(from_agent, preview[:60])
    except Exception:
        pass  # auto-wake is best-effort, never block message handling

    # SILENT WAKE: 3-tier strategy, all without OS keystrokes
    # 1. send_resource_updated  (lightweight cache invalidation)
    # 2. create_message (sampling) — server PUSH that wakes the LLM (if client supports)
    # 3. AppleScript (handled above) — fallback for clients that don't support either
    try:
        from pydantic import AnyUrl
        url = AnyUrl("meshcode://inbox")
        session = _STASHED_SESSION
        if session is None:
            srv = mcp._mcp_server
            ctx = getattr(srv, "request_context", None)
            if ctx and getattr(ctx, "session", None):
                session = ctx.session
        if session is not None:
            # 1. resource_updated (always cheap, may not wake)
            try:
                await session.send_resource_updated(url)
                log.info(f"silent wake A: resource_updated sent for msg from {msg.get('from')}")
            except Exception as _re:
                log.debug(f"resource_updated failed: {_re}")
            # 2. sampling/create_message — server PUSH that asks the LLM to think
            #    Only attempt if client advertised sampling capability
            try:
                client_caps = getattr(session, "client_capabilities", None)
                if client_caps and getattr(client_caps, "sampling", None):
                    from mcp.types import SamplingMessage, TextContent
                    nudge_text = f"You have a new mesh message from {from_agent}: {preview[:80]}. Call meshcode_check() to read your inbox, then process it. Stay in meshcode_wait() afterward."
                    await session.create_message(
                        messages=[SamplingMessage(role="user", content=TextContent(type="text", text=nudge_text))],
                        max_tokens=4096,
                        system_prompt="A new mesh message arrived while you were idle. Process it now.",
                    )
                    log.info(f"silent wake B: sampling/create_message PUSHED for msg from {msg.get('from')}")
            except Exception as _ce:
                log.debug(f"sampling/create_message failed: {_ce}")
    except Exception as e:
        log.debug(f"silent wake unavailable: {e}")


# Stashed MCP session for silent auto-wake (works when agent is idle, no active tool call)
_STASHED_SESSION = None

# Store the main asyncio event loop reference for use in the heartbeat daemon
# thread.  On Windows (ProactorEventLoop), asyncio.get_event_loop() inside a
# non-main thread returns a NEW, non-running loop — so is_running() is always
# False and run_coroutine_threadsafe silently does nothing.  By capturing the
# loop at lifespan start we guarantee the heartbeat thread can schedule
# Realtime restarts on the correct loop regardless of platform.
_MAIN_LOOP: asyncio.AbstractEventLoop | None = None

_heartbeat_stop = _threading.Event()

# Windows CPU tracking: (Get-Process).CPU returns cumulative seconds, not a
# real-time percentage like Unix `ps -o %cpu`.  We track the previous reading
# and timestamp so we can derive Δcpu/Δtime as a percentage.
_win_prev_cpu: float | None = None
_win_prev_ts: float | None = None


def _get_parent_cpu() -> float:
    """Return approximate real-time CPU usage (%) of the parent process.

    On Unix this delegates to ``ps -o %cpu`` which returns a percentage
    directly.  On Windows, ``(Get-Process).CPU`` returns *total CPU seconds*
    since process start — a monotonically increasing number.  To get a
    meaningful percentage we compute ``(Δcpu / Δtime) * 100`` between two
    consecutive heartbeat calls.
    """
    global _win_prev_cpu, _win_prev_ts
    try:
        import subprocess as _sp, platform as _pl
        ppid = os.getppid()
        if _pl.system() == "Windows":
            now = _time.time()
            r = _sp.run(
                ["powershell", "-NoProfile", "-Command",
                 f"(Get-Process -Id {ppid} -ErrorAction SilentlyContinue).CPU"],
                capture_output=True, text=True, timeout=5,
            )
            val = r.stdout.strip()
            if not val:
                log.debug(f"Windows CPU: empty output for ppid={ppid}")
                return 0.0
            cpu_total = float(val)
            if _win_prev_cpu is None or _win_prev_ts is None:
                # First reading — store baseline, return 0
                _win_prev_cpu = cpu_total
                _win_prev_ts = now
                log.debug(f"Windows CPU baseline: {cpu_total:.2f}s (ppid={ppid})")
                return 0.0
            dt = now - _win_prev_ts
            dcpu = cpu_total - _win_prev_cpu
            _win_prev_cpu = cpu_total
            _win_prev_ts = now
            if dt <= 0:
                return 0.0
            pct = (dcpu / dt) * 100.0
            log.debug(f"Windows CPU: Δcpu={dcpu:.3f}s Δt={dt:.1f}s → {pct:.1f}%")
            return max(pct, 0.0)
        else:
            r = _sp.run(["ps", "-p", str(ppid), "-o", "%cpu"], capture_output=True, text=True, timeout=5)
            lines = [l.strip() for l in r.stdout.strip().split("\n") if l.strip()]
            return float(lines[-1]) if len(lines) > 1 else 0.0
    except Exception as e:
        log.debug(f"CPU detection failed: {e}")
        return 0.0


_heartbeat_crash_count = 0

def _heartbeat_thread_fn():
    """Heartbeat in a DAEMON THREAD — independent of asyncio event loop.

    This ensures heartbeats continue even when tool calls are cancelled,
    meshcode_wait is rejected, or the asyncio loop is busy. The agent
    stays 'online' in the dashboard as long as the MCP process is alive.

    Wrapped in an outer try/except so uncaught exceptions (including from
    _heartbeat_stop.wait()) restart the loop instead of silently killing
    the thread — which would leave the agent as a ghost on the dashboard.
    """
    global _heartbeat_crash_count
    while not _heartbeat_stop.is_set():
        try:
            _heartbeat_loop_inner()
        except Exception as e:
            _heartbeat_crash_count += 1
            log.error(
                f"heartbeat thread crashed ({_heartbeat_crash_count}x): {e} — "
                f"restarting in 5s to prevent ghost agent"
            )
            # Brief sleep before restart to avoid tight crash loop
            _heartbeat_stop.wait(5)


def _heartbeat_loop_inner():
    """Single iteration of the heartbeat loop. Separated so the outer
    wrapper can catch any exception and restart cleanly."""
    import platform as _pl
    _is_windows = _pl.system() == "Windows"
    if _is_windows:
        log.info(
            f"[WIN-DEBUG] heartbeat thread started on Windows — "
            f"agent={AGENT_NAME} ppid={os.getppid()} "
            f"loop_captured={_MAIN_LOOP is not None} "
            f"realtime={'connected' if _REALTIME and _REALTIME.is_connected else 'none/disconnected'}"
        )
    lease_counter = 0
    while not _heartbeat_stop.is_set():
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME, "p_version": _SDK_VERSION})

            # CPU-based status detection
            parent_cpu = _get_parent_cpu()
            cur_state = _current_state
            in_wait = _IN_WAIT
            idle_secs = _time.time() - _last_tool_at

            if _is_windows and lease_counter % 12 == 0:
                # Periodic Windows debug dump (every ~60s on pro, ~180s on free)
                log.info(
                    f"[WIN-DEBUG] cpu={parent_cpu:.1f}% state={cur_state} "
                    f"in_wait={in_wait} idle={idle_secs:.0f}s "
                    f"rt_conn={_REALTIME.is_connected if _REALTIME else 'N/A'} "
                    f"rt_sub={_REALTIME.is_subscribed if _REALTIME else 'N/A'} "
                    f"loop_running={_MAIN_LOOP.is_running() if _MAIN_LOOP else False}"
                )

            if in_wait:
                # Actually in meshcode_wait right now — listening for messages
                if cur_state != "waiting":
                    _set_state("waiting", "listening for messages")
            elif parent_cpu > 3.0:
                # LLM is actively generating tokens or streaming
                if cur_state != "working":
                    _set_state("working", "generating response")
            elif cur_state == "working":
                # LLM just stopped — transition to online (not sleeping)
                _set_state("online", "")
            elif cur_state == "online" and idle_secs > 30:
                # Brief idle — show as idle, not sleeping yet
                _set_state("idle", "idle")
            elif cur_state == "idle" and idle_secs > 300 and parent_cpu < 2.0 and not _STAY_AWAKE and not in_wait:
                # Extended idle + no CPU activity + NOT in wait loop → sleeping
                # Never auto-sleep during meshcode_wait — the agent is actively
                # listening for messages, not truly idle.
                _set_state("sleeping", "sleeping")

            # Sync current state to DB (in case realtime missed it)
            try:
                be.set_status(_PROJECT_ID, AGENT_NAME, _current_state, _current_tool, api_key=_get_api_key())
            except Exception as e:
                log.warning(f"status sync failed (agent may show stale status): {e}")
            # Realtime subscription recovery: if the WebSocket is connected but
            # the channel subscription dropped (e.g. Supabase maintenance), or
            # the WebSocket itself disconnected, trigger a restart so agents
            # don't stay stuck in slow DB polling for the entire session.
            #
            # Use _MAIN_LOOP (captured at lifespan start) instead of
            # asyncio.get_event_loop() — on Windows the latter returns a new,
            # non-running loop inside daemon threads, silently preventing
            # Realtime restarts.
            if _REALTIME:
                if not _REALTIME.is_connected:
                    log.warning("heartbeat ok (HTTP) but WebSocket disconnected — scheduling Realtime restart")
                    try:
                        if _MAIN_LOOP and _MAIN_LOOP.is_running():
                            asyncio.run_coroutine_threadsafe(_REALTIME.restart(), _MAIN_LOOP)
                    except Exception as e:
                        log.debug(f"Realtime restart scheduling failed: {e}")
                elif not _REALTIME.is_subscribed:
                    log.warning("WebSocket connected but subscription lost — scheduling Realtime restart")
                    try:
                        if _MAIN_LOOP and _MAIN_LOOP.is_running():
                            asyncio.run_coroutine_threadsafe(_REALTIME.restart(), _MAIN_LOOP)
                    except Exception as e:
                        log.debug(f"Realtime restart scheduling failed: {e}")
                else:
                    log.debug(f"heartbeat ok for {AGENT_NAME}")
            else:
                log.debug(f"heartbeat ok for {AGENT_NAME} (no Realtime)")
        except Exception as e:
            log.warning(f"heartbeat failed: {e}")

        lease_counter += 1
        if lease_counter % 4 == 0:
            try:
                api_key = _get_api_key()
                if api_key:
                    be.sb_rpc("mc_acquire_agent_lease", {
                        "p_api_key": api_key,
                        "p_project_id": _PROJECT_ID,
                        "p_agent_name": AGENT_NAME,
                        "p_instance_id": _INSTANCE_ID,
                    })
            except Exception as e:
                log.warning(f"lease renewal failed: {e}")

        # Adaptive heartbeat: fast for paid plans, moderate for free
        # Free: 15s (~6K req/day/agent). Pro+: 5s (~17K req/day/agent).
        hb_interval = 5 if _PROJECT_PLAN in ("pro", "team", "enterprise", "unlimited") else 15
        _heartbeat_stop.wait(hb_interval)


@asynccontextmanager
async def lifespan(_app):
    """Start the Realtime listener when the MCP server boots; stop on shutdown."""
    global _REALTIME, _MAIN_LOOP
    _MAIN_LOOP = asyncio.get_running_loop()

    # Kill any stale MCP process for this agent before acquiring lease
    _kill_stale_mcp_process()
    _write_pid_lockfile()

    import platform as _pl
    if _pl.system() == "Windows":
        log.info(
            f"[WIN-DEBUG] lifespan start — loop={type(_MAIN_LOOP).__name__} "
            f"policy={type(asyncio.get_event_loop_policy()).__name__} "
            f"agent={AGENT_NAME}"
        )

    _REALTIME = RealtimeListener(
        supabase_url=be.SUPABASE_URL,
        supabase_key=be.SUPABASE_KEY,
        project_id=_PROJECT_ID,
        agent_name=AGENT_NAME,
        notify_callback=_on_new_message,
        service_role_key=be.SUPABASE_SERVICE_ROLE_KEY or None,
    )
    await _REALTIME.start()

    # Wait up to 5s for realtime to report connected before proceeding.
    # Without this, the lifespan yields before the WS is ready, and Claude
    # Code's handshake can time out on slower network paths — one agent
    # fails while siblings on the same box succeed.
    for _rt_check in range(10):
        if getattr(_REALTIME, '_connected', False):
            log.info(f"Realtime connected for {AGENT_NAME}")
            break
        await asyncio.sleep(0.5)
    else:
        log.warning(f"Realtime not connected after 5s for {AGENT_NAME} — continuing with polling fallback")

    # IMMEDIATE: send first heartbeat + set online status BEFORE any tool calls.
    # Without this, the agent appears offline for up to 30s after boot.
    for _attempt in range(3):
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME, "p_version": _SDK_VERSION})
            be.set_status(_PROJECT_ID, AGENT_NAME, "idle", "MCP session active", api_key=_get_api_key())
            log.info(f"[meshcode] Agent {AGENT_NAME} online — initial heartbeat sent")
            _log_activity_bg("agent_online", f"{AGENT_NAME} came online")
            break
        except Exception as e:
            log.warning(f"initial heartbeat attempt {_attempt+1} failed: {e}")
            import time; time.sleep(2)

    # Heartbeat in daemon thread — independent of asyncio event loop.
    _heartbeat_stop.clear()
    hb_thread = _threading.Thread(target=_heartbeat_thread_fn, daemon=True, name="meshcode-heartbeat")
    hb_thread.start()
    log.info(f"lifespan started — Realtime + heartbeat thread active for {AGENT_NAME}")
    # Enable session recording in backend.py (hot-reloadable)
    try:
        be.enable_recording(_get_api_key(), _PROJECT_ID, AGENT_NAME, _SESSION_ID)
    except Exception:
        pass
    _record_event_bg("boot", {"agent": AGENT_NAME, "project": PROJECT_NAME, "session_id": _SESSION_ID})
    try:
        yield {"realtime": _REALTIME}
    finally:
        # 2.10.31: minimal-risk shutdown. The previous body did network I/O,
        # a 5-second thread join, and an `await _REALTIME.stop()` inside the
        # lifespan's finally. Under Claude Code 2.1.111 ESC, that cancellation
        # path cascades through the awaits and unwinds the asyncio loop,
        # killing the subprocess. A bare FastMCP (no lifespan) in the same
        # bucket survives. To match that behavior without losing Realtime on
        # startup, we keep the startup logic and make the shutdown strictly
        # non-blocking, non-awaiting, non-raising. Daemon threads / realtime
        # socket die with the process; the lease expires on heartbeat timeout.
        try:
            _heartbeat_stop.set()
        except Exception:
            pass
        try:
            _remove_pid_lockfile()
        except Exception:
            pass
        try:
            _record_event_bg("shutdown", {"agent": AGENT_NAME, "session_id": _SESSION_ID})
        except Exception:
            pass
        # Fire-and-forget best-effort cleanup in a daemon thread so we do not
        # block, do not await, and any failure is confined to the thread.
        def _bg_cleanup():
            try:
                import datetime as _dt
                api_key = _get_api_key()
                if api_key:
                    be.sb_rpc("mc_memory_set", {
                        "p_api_key": api_key,
                        "p_project_id": _PROJECT_ID,
                        "p_agent_name": AGENT_NAME,
                        "p_key": f"session_retro_{_dt.date.today().isoformat()}",
                        "p_value": {
                            "session_id": _SESSION_ID,
                            "agent": AGENT_NAME,
                            "shutdown_at": _dt.datetime.utcnow().isoformat(),
                            "instance_id": _INSTANCE_ID,
                            "auto_generated": True,
                        },
                    })
            except Exception:
                pass
            try:
                _release_lease()
            except Exception:
                pass
        try:
            _threading.Thread(target=_bg_cleanup, daemon=True, name="meshcode-shutdown-cleanup").start()
        except Exception:
            pass


# ============================================================
# FastMCP server
# ============================================================

_DISABLE_LIFESPAN = os.environ.get("MESHCODE_DISABLE_LIFESPAN", "").lower() in ("1", "true", "yes")
if _DISABLE_LIFESPAN:
    # Diagnostic mode (2.10.33): bypass lifespan entirely to isolate whether
    # the Realtime + heartbeat + boot-event machinery is what dies under ESC.
    # Realtime won't subscribe; meshcode_wait will degrade to DB polling.
    # meshcode_debug_sleep still works and is our smoke test.
    mcp = FastMCP(
        name=f"meshcode-{PROJECT_NAME}-{AGENT_NAME}",
        instructions=_INSTRUCTIONS,
    )
    print("[meshcode-mcp] LIFESPAN DISABLED (MESHCODE_DISABLE_LIFESPAN=1) — diagnostic mode", file=sys.stderr, flush=True)
else:
    mcp = FastMCP(
        name=f"meshcode-{PROJECT_NAME}-{AGENT_NAME}",
        instructions=_INSTRUCTIONS,
        lifespan=lifespan,
    )
# Belt-and-suspenders: some FastMCP versions don't forward `instructions=` to
# the underlying lowlevel server's InitializeResult. Set it directly too.
try:
    mcp._mcp_server.instructions = _INSTRUCTIONS  # type: ignore[attr-defined]
except Exception:
    pass


# ----------------- TOOLS -----------------

@mcp.tool()
async def meshcode_debug_sleep(seconds: int = 30) -> Dict[str, Any]:
    """DEBUG-ONLY: sleep N seconds via pure asyncio.sleep (no Realtime, no DB).

    Exists to isolate whether ESC kills meshcode because of our Realtime
    listener / lifespan infrastructure, or regardless of the tool body.
    Matches armored.py's sleep_long byte-for-byte at the async layer.
    """
    import asyncio as _asyncio
    import os as _os
    try:
        await _asyncio.sleep(max(1, int(seconds)))
        return {"ok": True, "slept": int(seconds), "pid": _os.getpid()}
    except BaseException as e:
        sys.stderr.write(f"[meshcode-mcp] debug_sleep cancelled with {type(e).__name__}: {e}\n")
        sys.stderr.flush()
        raise


@mcp.tool()
@with_working_status
def meshcode_send(to: str, message: Any, in_reply_to: Optional[str] = None,
                  sensitive: bool = False, encrypted: bool = False) -> Dict[str, Any]:
    """Send message. Use "agent@meshwork" for cross-mesh. sensitive=True hides from exports. Pass encrypted=True for secrets/credentials (AES-256-GCM)."""
    if not to or not to.strip():
        return {"error": "recipient 'to' cannot be empty"}
    to = to.strip()
    if isinstance(message, str):
        # Auto-wrap strings into dict. Warn if very long but don't reject.
        if len(message) > 2000:
            return {"error": f"message too long ({len(message)} chars). Use meshcode_task_create for long content, or split into multiple messages. Max ~2000 chars."}
        payload: Dict[str, Any] = {"text": message}
    elif isinstance(message, dict):
        payload = message
    else:
        payload = {"text": str(message)}

    # Universal DM render guarantee: dashboard chat renderer keys on
    # payload.text. Structured-dict DMs without a text field render blank.
    import json as _json
    if "text" not in payload:
        _synth = _json.dumps(
            {k: v for k, v in payload.items() if not k.startswith("_")},
            default=str, ensure_ascii=False,
        )
        payload["text"] = _synth if len(_synth) <= 280 else _synth[:279] + "…"

    # Enforce message size limit — long content belongs in task descriptions
    _payload_len = len(_json.dumps(payload, default=str))
    if _payload_len > 2000:
        return {"error": f"message too large ({_payload_len} chars). Use meshcode_task_create for long content. Messages must be structured JSON <2000 chars."}

    # Cross-mesh routing: if 'to' contains '@', parse as agent@meshwork
    if "@" in to:
        target_agent, target_meshwork = to.split("@", 1)
        if sensitive and not encrypted:
            return {"error": "sensitive messages must use encrypted=True for cross-mesh"}
        api_key = _get_api_key()

        # Bridge re-encryption: encrypt payload with the TARGET mesh key so
        # the receiving agent decrypts normally. Uses mc_get_cross_mesh_key
        # RPC which validates the link exists before returning the key.
        if encrypted:
            key_result = be.sb_rpc("mc_get_cross_mesh_key", {
                "p_api_key": api_key,
                "p_source_project": PROJECT_NAME,
                "p_target_project": target_meshwork,
                "p_agent_name": AGENT_NAME,
            })
            if not isinstance(key_result, dict) or not key_result.get("ok"):
                err = key_result.get("error", "unknown") if isinstance(key_result, dict) else "RPC failed"
                return {"error": f"cross-mesh encryption failed: {err}"}
            tgt_key = key_result["key"]
            tgt_project_id = key_result.get("target_project_id", "")
            encrypted_data = be.encrypt_payload(payload, tgt_key, aad=tgt_project_id)
            payload = {"_encrypted": encrypted_data, "_aad": tgt_project_id}

        result = be.sb_rpc("mc_send_cross_mesh", {
            "p_api_key": api_key,
            "p_from_project": PROJECT_NAME,
            "p_from_agent": AGENT_NAME,
            "p_to_project": target_meshwork,
            "p_to_agent": target_agent,
            "p_payload": payload,
            "p_type": "msg",
        })
        if isinstance(result, dict) and result.get("ok") and encrypted:
            result["encrypted"] = True
        return result

    return be.send_message(_PROJECT_ID, AGENT_NAME, to, payload, msg_type="msg",
                           parent_msg_id=in_reply_to, sensitive=sensitive,
                           api_key=_get_api_key(), encrypted=encrypted)


@mcp.tool()
@with_working_status
def meshcode_broadcast(payload: Any) -> Dict[str, Any]:
    """Broadcast to ALL agents in this meshwork (except yourself).

    Accepts payload as either:
      - dict (structured): {"type": "...", "detail": "..."}
      - str (shorthand): wrapped internally as {"text": "..."}
    """
    if isinstance(payload, str):
        payload = {"text": payload}
    elif not isinstance(payload, dict):
        return {"error": "payload must be a string or object", "got_type": type(payload).__name__}

    # Canonical broadcast: one row with to_agent='*'. Every agent's inbox
    # query includes `to_agent = '*'` so all recipients see it, without the
    # N-row fanout that caused duplicate-render bugs.
    be.send_message(_PROJECT_ID, AGENT_NAME, "*", payload, msg_type="broadcast",
                    api_key=_get_api_key())
    return {"broadcast": True, "to": "*"}


@mcp.tool()
@with_working_status
def meshcode_read(include_acks: bool = False) -> Dict[str, Any]:
    """Read and consume pending messages. Returns {messages, acks, done_signals}."""
    raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, api_key=_get_api_key())
    normalized = [
        {
            "from": m["from_agent"],
            "type": m.get("type", "msg"),
            "ts": m.get("created_at"),
            "payload": m.get("payload", {}),
            "id": m.get("id"),
            "parent_id": m.get("parent_msg_id"),
        }
        for m in raw
    ]
    deduped = _filter_and_mark(normalized)
    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    return split


@mcp.tool()
@with_working_status
async def meshcode_call(to: str, function: str, args: Any = None, timeout_seconds: int = 30) -> Dict[str, Any]:
    """Synchronous RPC call to another agent. Blocks until response (max 30s).

    Sends a structured request, waits for the callee to respond with a matching
    call_id. Like gRPC over the mesh — enables agents to ask each other questions
    and get structured answers.

    Args:
        to: Target agent name.
        function: Function/action name the callee should execute.
        args: Arguments (any JSON-serializable value).
        timeout_seconds: Max wait time (default 30, max 60).
    """
    import uuid as _uuid
    if not to or not to.strip():
        return {"error": "recipient 'to' cannot be empty"}
    call_id = str(_uuid.uuid4())
    timeout_seconds = min(max(timeout_seconds, 5), 60)

    # Send the RPC request
    request_payload = {
        "type": "rpc_request",
        "call_id": call_id,
        "function": function,
        "args": args,
        "from": AGENT_NAME,
        "timeout": timeout_seconds,
    }
    send_result = be.send_message(
        _PROJECT_ID, AGENT_NAME, to, request_payload,
        msg_type="rpc", api_key=_get_api_key()
    )
    if not send_result.get("sent") and send_result.get("error"):
        return {"error": f"failed to send RPC request: {send_result['error']}"}

    # Poll for response with matching call_id
    import asyncio as _asyncio
    poll_interval = 1.0
    elapsed = 0.0
    while elapsed < timeout_seconds:
        try:
            await _asyncio.sleep(poll_interval)
        except _asyncio.CancelledError:
            log.debug("[meshcode] meshcode_call poll cancelled by ESC")
            return {"error": "cancelled_by_client", "call_id": call_id, "ok": False}
        elapsed += poll_interval

        # Check Realtime buffer first
        if _REALTIME:
            for msg in _REALTIME.peek():
                p = msg.get("payload") or {}
                if isinstance(p, dict) and p.get("type") == "rpc_response" and p.get("call_id") == call_id:
                    # Found response — drain it
                    _REALTIME.drain()
                    return {
                        "ok": True,
                        "call_id": call_id,
                        "from": msg.get("from"),
                        "result": p.get("result"),
                        "error": p.get("error"),
                    }

        # Fallback: check DB
        try:
            raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=True, api_key=_get_api_key())
            for m in (raw if isinstance(raw, list) else raw.get("messages", []) if isinstance(raw, dict) else []):
                p = m.get("payload") or {}
                if isinstance(p, dict) and p.get("type") == "rpc_response" and p.get("call_id") == call_id:
                    return {
                        "ok": True,
                        "call_id": call_id,
                        "from": m.get("from_agent") or m.get("from"),
                        "result": p.get("result"),
                        "error": p.get("error"),
                    }
        except Exception:
            pass

        # Exponential backoff on polling (1s → 2s → 3s, cap 3s)
        poll_interval = min(poll_interval + 0.5, 3.0)

    return {"error": f"RPC call to {to}.{function} timed out after {timeout_seconds}s", "call_id": call_id}


@mcp.tool()
@with_working_status
def meshcode_history(limit: int = 20, agent_filter: Optional[str] = None) -> Dict[str, Any]:
    """View past messages (read+unread). Optional agent_filter."""
    raw = be.get_history(_PROJECT_ID, limit=limit, agent_filter=agent_filter or "", api_key=_get_api_key())
    messages = [
        {
            "from": m.get("from_agent", ""),
            "to": m.get("to_agent", ""),
            "type": m.get("type", "msg"),
            "ts": m.get("created_at", ""),
            "payload": m.get("payload", {}),
            "id": m.get("id", ""),
            "read": m.get("read", False),
        }
        for m in raw
    ]
    return {"ok": True, "messages": messages, "count": len(messages)}


@mcp.tool()
@with_working_status
def meshcode_read_message(msg_id: str) -> Dict[str, Any]:
    """Fetch a specific message by its UUID."""
    msg = be.get_message_by_id(_PROJECT_ID, msg_id, api_key=_get_api_key())
    if not msg:
        return {"error": "message not found", "msg_id": msg_id}
    return {
        "ok": True,
        "message": {
            "from": msg.get("from_agent", ""),
            "to": msg.get("to_agent", ""),
            "type": msg.get("type", "msg"),
            "ts": msg.get("created_at", ""),
            "payload": msg.get("payload", {}),
            "id": msg.get("id", ""),
            "read": msg.get("read", False),
        },
    }


@mcp.tool()
@with_working_status
def meshcode_download_file(file_id: str) -> Dict[str, Any]:
    """Download a file attachment from a mesh message.

    Returns file content for text/JSON files, or saves to temp file and
    returns the path for images (Claude can view image files directly).

    Args:
        file_id: UUID of the file (from message payload's file.file_id).
    """
    import tempfile
    import urllib.request as _req
    import urllib.error as _uerr

    api_key = _get_api_key()
    if not api_key:
        return {"error": "no api key", "error_code": "auth_failed"}

    # Step 1: Get file metadata via RPC
    file_info = be.sb_rpc("mc_get_file_download", {
        "p_api_key": api_key,
        "p_file_id": file_id,
    })
    if not file_info or not file_info.get("ok"):
        return {"error": file_info.get("error", "file not found"), "error_code": "not_found"}

    storage_path = file_info["storage_path"]
    bucket = file_info.get("bucket", "meshcode-files")
    mime_type = file_info.get("mime_type", "application/octet-stream")
    file_name = file_info.get("file_name", "download")

    # Step 2: Download from Supabase Storage (using service-level anon key)
    sb_url = os.environ.get("SUPABASE_URL", be._sb_url if hasattr(be, '_sb_url') else "")
    sb_key = os.environ.get("SUPABASE_KEY", be._sb_key if hasattr(be, '_sb_key') else "")

    if not sb_url or not sb_key:
        return {"error": "storage not configured", "error_code": "config_error"}

    # URL-encode each path segment so filenames with spaces/unicode (the common
    # 400 cause when dashboard composer attaches files like "Screenshot 1.png")
    # don't produce a malformed Storage URL.
    from urllib.parse import quote as _quote
    _enc_path = "/".join(_quote(seg, safe="") for seg in storage_path.split("/") if seg)
    _enc_bucket = _quote(bucket, safe="")

    def _try_download(url: str):
        req = _req.Request(
            url,
            headers={
                "apikey": sb_key,
                "Authorization": f"Bearer {sb_key}",
            },
        )
        with _req.urlopen(req, timeout=30) as resp:
            return resp.read()

    # Try authenticated object endpoint first; fall back to public endpoint
    # for buckets that have public read enabled. Many 400/403 cases on private
    # buckets resolve when the bucket is configured as public-readable.
    auth_url = f"{sb_url}/storage/v1/object/{_enc_bucket}/{_enc_path}"
    public_url = f"{sb_url}/storage/v1/object/public/{_enc_bucket}/{_enc_path}"
    last_err = None
    content = None
    for _url in (auth_url, public_url):
        try:
            content = _try_download(_url)
            break
        except _uerr.HTTPError as e:
            last_err = f"HTTP {e.code} on {_url}: {e.reason}"
            continue
        except Exception as e:
            last_err = f"{type(e).__name__} on {_url}: {e}"
            continue
    if content is None:
        return {
            "error": f"download failed: {last_err}",
            "error_code": "download_error",
            "tried_urls": [auth_url, public_url],
            "storage_path": storage_path,
        }

    # Step 3: Return content based on type
    if mime_type.startswith("text/") or mime_type == "application/json":
        try:
            text = content.decode("utf-8")
            if mime_type == "application/json":
                return {"ok": True, "file_name": file_name, "mime_type": mime_type,
                        "content": json.loads(text)}
            return {"ok": True, "file_name": file_name, "mime_type": mime_type,
                    "content": text[:50000]}  # cap at 50k chars
        except Exception:
            pass

    # For images and binary: save to temp file, return path
    suffix = "." + file_name.rsplit(".", 1)[-1] if "." in file_name else ""
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix, prefix="meshcode_")
    tmp.write(content)
    tmp.close()

    return {
        "ok": True,
        "file_name": file_name,
        "mime_type": mime_type,
        "size_bytes": len(content),
        "local_path": tmp.name,
        "note": "File saved to local_path. For images, use Read tool to view.",
    }


def _detect_global_done(messages: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return {reason, from} if the list contains a global_done signal, else None."""
    for m in messages:
        if m.get("type") == "done":
            p = m.get("payload") or {}
            if p.get("type") == "global_done" or p.get("reason"):
                return {
                    "reason": p.get("reason"),
                    "from": p.get("from") or m.get("from"),
                }
    return None


# Auto-sleep: track consecutive idle timeouts to auto-sleep after threshold
_CONSECUTIVE_IDLE_SECONDS = 0
_AUTO_SLEEP_THRESHOLD = int(os.environ.get("MESHCODE_AUTO_SLEEP_SECONDS", "600"))  # default 10min
_STAY_AWAKE = False  # Set by meshcode_set_status("online") — prevents auto-sleep
_LAST_SEEN_TS: Optional[str] = None  # auto-persisted for message dedup

# Hydrate _LAST_SEEN_TS from mesh memory on boot so restarts skip old messages
try:
    _ls_result = be.sb_rpc("mc_memory_get", {
        "p_api_key": _get_api_key(),
        "p_agent_name": AGENT_NAME,
        "p_key": "last_seen",
    })
    if isinstance(_ls_result, dict) and _ls_result.get("ok"):
        _ls_val = _ls_result.get("value")
        if isinstance(_ls_val, dict) and _ls_val.get("_raw"):
            _LAST_SEEN_TS = str(_ls_val["_raw"])
        elif isinstance(_ls_val, str):
            _LAST_SEEN_TS = _ls_val
        if _LAST_SEEN_TS:
            print(f"[meshcode] Restored last_seen={_LAST_SEEN_TS} from mesh memory.", file=sys.stderr)
except Exception as _e:
    print(f"[meshcode] Could not restore last_seen: {_e}", file=sys.stderr)


def _get_pending_tasks_summary() -> Optional[List[Dict[str, str]]]:
    """Fetch tasks that THIS agent should work on. Returns compact list or None.

    Only blocks on tasks directly assigned to this agent or claimed by this agent.
    Tasks assigned to '*' (wildcard) that are unclaimed are NOT blocking —
    they're available for any agent but shouldn't prevent wait().
    """
    try:
        api_key = _get_api_key()
        if not api_key:
            return None
        result = be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter=None)
        if not isinstance(result, dict) or not result.get("ok"):
            return None
        tasks = result.get("tasks", [])
        pending = [
            {"id": t["id"][:8], "title": t["title"][:80], "priority": t.get("priority", "normal"), "status": t["status"]}
            for t in tasks
            if t.get("status") in ("open", "in_progress")
            and (
                t.get("claimed_by") == AGENT_NAME  # I claimed it — must work it
                or t.get("assignee") == AGENT_NAME  # Directly assigned to me
            )
        ]
        # For leader agents: also include unclaimed '*' tasks as pending
        # so commanders auto-triage them instead of letting them pile up.
        is_leader = _is_leader_agent()
        if is_leader:
            wildcard_tasks = [
                {"id": t["id"][:8], "title": t["title"][:80], "priority": t.get("priority", "normal"), "status": t["status"]}
                for t in tasks
                if t.get("status") == "open"
                and t.get("assignee") == "*"
                and not t.get("claimed_by")
            ]
            pending.extend(wildcard_tasks)
        # Sort by priority so urgent tasks surface first
        _PRIORITY_ORDER = {"urgent": 0, "high": 1, "normal": 2, "low": 3}
        pending.sort(key=lambda t: _PRIORITY_ORDER.get(t.get("priority", "normal"), 2))
        return pending if pending else None
    except Exception:
        return None


def _try_auto_claim_task() -> Optional[Dict[str, str]]:
    """Auto-claim the oldest open task matching this agent's role.

    Called during meshcode_wait idle loops. Only claims wildcard ('*')
    tasks to avoid stealing directly-assigned work. Returns the claimed
    task summary or None.
    """
    try:
        api_key = _get_api_key()
        if not api_key:
            return None
        result = be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter="open")
        if not isinstance(result, dict) or not result.get("ok"):
            return None
        tasks = result.get("tasks", [])
        # Only auto-claim wildcard tasks that nobody claimed yet
        claimable = [
            t for t in tasks
            if t.get("assignee") == "*"
            and not t.get("claimed_by")
            and t.get("status") == "open"
        ]
        if not claimable:
            return None
        # Sort by priority (urgent first), then oldest
        _PRIO = {"urgent": 0, "high": 1, "normal": 2, "low": 3}
        claimable.sort(key=lambda t: (_PRIO.get(t.get("priority", "normal"), 2), t.get("created_at", "")))
        target = claimable[0]
        # Claim it
        claim_result = be.sb_rpc("mc_task_claim", {
            "p_api_key": api_key,
            "p_task_id": target["id"],
        })
        if isinstance(claim_result, dict) and claim_result.get("ok"):
            log.info(f"[meshcode] auto-claimed task: {target['title'][:60]}")
            return {"id": target["id"][:8], "title": target["title"][:80], "priority": target.get("priority", "normal")}
    except Exception as e:
        log.debug(f"[meshcode] auto-claim failed: {e}")
    return None


@mcp.tool()
@with_working_status
async def meshcode_wait(timeout_seconds: int = 20, include_acks: bool = False) -> Dict[str, Any]:
    """Block until a mesh message arrives or a task needs attention.

    INTERNAL LOOP: This function loops internally and only returns when
    there is real work (message, task, or done signal). The agent NEVER
    needs to decide whether to call meshcode_wait() again — it just stays
    blocked here until something happens. This prevents agents from
    accidentally using ScheduleWakeup or exiting the loop.

    Args:
        timeout_seconds: Max wait time per poll cycle (default 20, hard cap 20).
            Short cap keeps the outer tool call bounded so the user can press
            ESC in Claude Code without killing the MCP server — the inner
            loop continues polling across cycles at zero token cost.
    """
    global _IN_WAIT, _CONSECUTIVE_IDLE_SECONDS, _LAST_SEEN_TS

    # PRODUCT RULE 1: If agent has open tasks, refuse to wait. Work first.
    # Exception: commander/leader agents can wait while monitoring — they
    # delegate tasks and need to stay in the wait loop to receive reports.
    pending_tasks = _get_pending_tasks_summary()
    if pending_tasks:
        if not _is_leader_agent():
            return {
                "refused": True,
                "reason": "You have open tasks. Work them before entering wait.",
                "pending_tasks": pending_tasks,
                "count": len(pending_tasks),
            }

    # PRODUCT RULE 2: If agent has unread messages in DB, refuse to wait.
    try:
        db_pending = be.count_pending(_PROJECT_ID, AGENT_NAME, api_key=_get_api_key())
        if db_pending and db_pending > 0:
            raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=True, api_key=_get_api_key())
            msgs = [
                {"from": m["from_agent"], "type": m.get("type", "msg"),
                 "ts": m.get("created_at"), "payload": m.get("payload", {}),
                 "id": m.get("id"), "parent_id": m.get("parent_msg_id")}
                for m in raw
            ]
            # Dedup against already-seen messages (fixes race where
            # background mark_read hasn't completed yet)
            deduped = _filter_and_mark(msgs)
            if not deduped:
                pass  # All messages already seen — fall through to wait loop
            else:
                split = _split_messages(deduped)
                # Only refuse for real messages — ack-only batches should not block wait
                if split["messages"] or split["done_signals"]:
                    return {
                        "refused": True,
                        "reason": f"You have {split['count']} unread messages. Process them before waiting.",
                        "got_message": True,
                        **split,
                    }
                # Ack-only batch — fall through to wait loop
    except Exception:
        pass

    _IN_WAIT = True
    _set_state("waiting", "listening for messages")
    capped_timeout = min(max(1, int(timeout_seconds)), 20)
    try:
        # ── INTERNAL LOOP ──────────────────────────────────────────
        # Keep polling until something actionable arrives.
        # The agent (LLM) is NOT called between iterations — zero token cost.
        while True:
            try:
                result = await _meshcode_wait_inner(actual_timeout=capped_timeout, include_acks=include_acks)
            except asyncio.CancelledError:
                # Safety net: if CancelledError escapes _meshcode_wait_inner
                # despite the inner shield, catch it here to prevent cascade.
                log.debug("[meshcode] meshcode_wait outer loop caught CancelledError")
                result = {"timed_out": True, "reason": "cancelled_by_client"}

            if result.get("got_message"):
                # Real message arrived — return to agent for processing
                _set_state("online", "")
                _CONSECUTIVE_IDLE_SECONDS = 0
                _msg_count = len(result.get("messages", []))
                if _msg_count:
                    _log_activity_bg("message_delivered", f"{AGENT_NAME} received {_msg_count} message(s)")
                break

            if result.get("timed_out"):
                _CONSECUTIVE_IDLE_SECONDS += capped_timeout

                # Check if new tasks appeared while we waited
                pending_tasks = _get_pending_tasks_summary()
                if pending_tasks:
                    result["pending_tasks"] = pending_tasks
                    break  # Return so agent can work tasks

                # Auto-claim: when idle >30s with no assigned tasks, try to
                # claim the oldest open wildcard task. This makes agents
                # self-directing instead of waiting passively for assignment.
                if _CONSECUTIVE_IDLE_SECONDS >= 30 and not _is_leader_agent():
                    claimed = _try_auto_claim_task()
                    if claimed:
                        result["auto_claimed"] = claimed
                        result["pending_tasks"] = [claimed]
                        break  # Return so agent works the claimed task

                # Update status to sleeping after threshold, but keep looping
                if _AUTO_SLEEP_THRESHOLD > 0 and _CONSECUTIVE_IDLE_SECONDS >= _AUTO_SLEEP_THRESHOLD and not _STAY_AWAKE:
                    try:
                        api_key = _get_api_key()
                        if api_key:
                            be.sb_rpc("mc_agent_set_status_by_api_key", {
                                "p_api_key": api_key,
                                "p_project_id": _PROJECT_ID,
                                "p_agent_name": AGENT_NAME,
                                "p_status": "sleeping",
                                "p_task": f"idle {_CONSECUTIVE_IDLE_SECONDS}s — still listening",
                            })
                    except Exception as e:
                        log.debug(f"auto-sleep status update failed: {e}")
                    # Do NOT return — keep looping. Status says sleeping but
                    # we are still listening for messages via realtime.
                    _set_state("sleeping", f"idle {_CONSECUTIVE_IDLE_SECONDS}s — still listening")

                # No messages, no tasks — loop back and wait again
                continue
        # ── END INTERNAL LOOP ──────────────────────────────────────

        # Track last seen timestamp for message dedup
        if result.get("got_message"):
            msgs = result.get("messages", [])
            if msgs:
                latest_ts = max((m.get("ts", "") for m in msgs), default="")
                if latest_ts:
                    _LAST_SEEN_TS = latest_ts
                    try:
                        be.sb_rpc("mc_memory_set", {
                            "p_api_key": _get_api_key(),
                            "p_agent_name": AGENT_NAME,
                            "p_key": "last_seen",
                            "p_value": {"_raw": latest_ts},
                            "p_tier": "critical",
                            "p_project_name": PROJECT_NAME,
                        })
                    except Exception as e:
                        log.debug(f"last_seen memory persist failed: {e}")
        return result
    finally:
        _IN_WAIT = False


def _mark_realtime_msgs_read_in_db(messages: List[Dict[str, Any]]) -> None:
    """Mark realtime-delivered messages as read in DB (SYNCHRONOUS).

    Must complete BEFORE returning messages to the agent. If we used a
    background thread (daemon=True), a crash between delivery and DB
    update would leave messages as read=false, causing duplicates on
    restart. Synchronous marking ensures exactly-once delivery.

    Uses batch RPC (mc_mark_messages_read_batch) when available for
    O(1) latency regardless of message count. Falls back to individual
    RPCs if batch is not deployed.
    """
    msg_ids = [m.get("id") for m in messages if m.get("id")]
    if not msg_ids:
        return
    api_key = _get_api_key()
    if not api_key:
        return

    # Try batch first (1 RPC for N messages = ~50ms total)
    try:
        result = be.sb_rpc("mc_mark_messages_read_batch", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_message_ids": msg_ids,
        })
        if result and not be.is_error(result):
            log.debug(f"batch mark_read: {result.get('marked', 0)}/{len(msg_ids)} marked")
            return
        # Batch RPC returned error — fall through to individual
        log.debug(f"batch mark_read failed: {be.get_error_message(result)}, falling back to individual")
    except Exception as e:
        log.debug(f"batch mark_read unavailable ({e}), falling back to individual")

    # Fallback: individual RPCs (N RPCs = ~N*50ms)
    for mid in msg_ids:
        try:
            be.sb_rpc("mc_mark_message_read", {
                "p_api_key": api_key,
                "p_project_id": _PROJECT_ID,
                "p_message_id": mid,
            })
        except Exception as e:
            log.debug(f"mark_read failed for msg {mid}: {e}")

    # Confirm delivery (best-effort, background) — completes the
    # delivery pipeline: sent → read → confirmed.
    try:
        be.sb_rpc("mc_confirm_delivery", {
            "p_api_key": api_key,
            "p_message_ids": msg_ids,
        })
    except Exception:
        pass  # Non-critical: messages still work without confirmation


async def _meshcode_wait_inner(actual_timeout: int, include_acks: bool) -> Dict[str, Any]:

    def _return_from_buffered(buffered: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        # Auto-decrypt encrypted payloads
        _mesh_key = None
        for msg in buffered:
            p = msg.get("payload")
            if isinstance(p, dict) and "_encrypted" in p:
                if _mesh_key is None:
                    try:
                        _mesh_key = be.get_mesh_key(_get_api_key(), _PROJECT_ID) or ""
                    except Exception:
                        _mesh_key = ""
                if _mesh_key:
                    decrypted = be.decrypt_payload(p["_encrypted"], _mesh_key)
                    if decrypted is not None:
                        msg["payload"] = decrypted
        deduped = _filter_and_mark(buffered)
        if not deduped:
            return None
        split = _split_messages(deduped)
        if not include_acks:
            split["acks"] = []
        # If the ONLY thing buffered was acks (now suppressed) AND there
        # are no real messages or done signals, treat as nothing useful.
        if not split["messages"] and not split["done_signals"] and not split["acks"]:
            return None
        # Mark realtime-delivered messages as read in DB so they don't
        # inflate pending counts on agent restart.
        _mark_realtime_msgs_read_in_db(deduped)
        out: Dict[str, Any] = {
            "got_message": True,
            **split,
        }
        done = _detect_global_done(deduped)
        if done:
            out["got_done"] = True
            out["reason"] = done["reason"]
            out["from"] = done["from"]
        return out

    # 1) Drain anything already buffered from before this call.
    if _REALTIME:
        pre = _REALTIME.drain()
        if pre:
            shaped = _return_from_buffered(pre)
            if shaped:
                return shaped

    # Determine if realtime is actually delivering events.
    _rt_live = _REALTIME and _REALTIME.is_subscribed

    if _rt_live:
        # 2a) Real async wait — zero CPU, zero Supabase calls.
        # Split into 5s sub-waits so we can detect Realtime subscription
        # drops mid-wait and fall through to DB poll immediately instead
        # of waiting the full timeout with a dead connection.
        _rt_sub_timeout = 5.0
        _rt_elapsed = 0.0
        woke = False
        while _rt_elapsed < actual_timeout:
            _this_wait = min(_rt_sub_timeout, actual_timeout - _rt_elapsed)
            try:
                woke = await asyncio.shield(
                    _REALTIME.wait_for_message(timeout=_this_wait)
                )
            except asyncio.CancelledError:
                log.debug("[meshcode] wait_for_message cancelled by ESC")
                return {"timed_out": True, "reason": "cancelled_by_client"}
            except Exception as _wait_exc:
                log.warning(f"[meshcode] wait_for_message error: {type(_wait_exc).__name__}: {_wait_exc}")
                woke = False
                break  # Fall through to DB fallback
            if woke:
                break
            _rt_elapsed += _this_wait
            # Health check: if subscription dropped, switch to DB poll
            if not (_REALTIME and _REALTIME.is_subscribed):
                log.info("[meshcode] Realtime subscription lost mid-wait — switching to DB poll")
                break
        if woke:
            buffered = _REALTIME.drain()
            if buffered:
                shaped = _return_from_buffered(buffered)
                if shaped:
                    return shaped
    else:
        # 2b) Realtime NOT subscribed — aggressive DB polling every 5s
        # so messages arrive within seconds, not after 120s timeout.
        _poll_interval = 5
        _elapsed = 0
        while _elapsed < actual_timeout:
            try:
                await asyncio.sleep(min(_poll_interval, actual_timeout - _elapsed))
            except asyncio.CancelledError:
                log.debug("[meshcode] DB poll sleep cancelled by ESC")
                return {"timed_out": True, "reason": "cancelled_by_client"}
            _elapsed += _poll_interval
            try:
                api_key = _get_api_key()
                if api_key:
                    db_pending = be.count_pending(_PROJECT_ID, AGENT_NAME, api_key=api_key)
                    if db_pending and db_pending > 0:
                        raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=True, api_key=api_key)
                        if raw:
                            msgs = [
                                {"from": m["from_agent"], "type": m.get("type", "msg"),
                                 "ts": m.get("created_at"), "payload": m.get("payload", {}),
                                 "id": m.get("id"), "parent_id": m.get("parent_msg_id")}
                                for m in raw
                            ]
                            deduped = _filter_and_mark(msgs)
                            if deduped:
                                split = _split_messages(deduped)
                                if not include_acks:
                                    split["acks"] = []
                                if split["messages"] or split["done_signals"]:
                                    return {"got_message": True, **split}
            except Exception as e:
                log.debug(f"DB poll fallback error: {e}")

    # Final fallback: one last DB check (covers realtime path missing msgs)
    try:
        api_key = _get_api_key()
        if api_key:
            db_pending = be.count_pending(_PROJECT_ID, AGENT_NAME, api_key=api_key)
            if db_pending and db_pending > 0:
                raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=True, api_key=api_key)
                if raw:
                    msgs = [
                        {"from": m["from_agent"], "type": m.get("type", "msg"),
                         "ts": m.get("created_at"), "payload": m.get("payload", {}),
                         "id": m.get("id"), "parent_id": m.get("parent_msg_id")}
                        for m in raw
                    ]
                    deduped = _filter_and_mark(msgs)
                    if deduped:
                        split = _split_messages(deduped)
                        if not include_acks:
                            split["acks"] = []
                        if split["messages"] or split["done_signals"]:
                            return {"got_message": True, **split}
    except Exception as e:
        log.debug(f"final DB fallback error: {e}")

    # Check if there's any pending work before returning timeout
    pending_tasks = _get_pending_tasks_summary()
    out: Dict[str, Any] = {"timed_out": True}
    if pending_tasks:
        out["pending_tasks"] = pending_tasks
    else:
        out["no_work"] = True
    return out


@mcp.tool()
@with_working_status
def meshcode_done(reason: str) -> Dict[str, Any]:
    """Broadcast DONE to all agents — exits everyone's wait loop.

    Args:
        reason: Why the meshwork is done.
    """
    agents = be.get_board(_PROJECT_ID)
    payload = {"reason": reason, "from": AGENT_NAME, "type": "global_done"}
    sent = 0
    for a in agents:
        name = a.get("name")
        if name and name != AGENT_NAME:
            try:
                be.send_message(_PROJECT_ID, AGENT_NAME, name, payload, msg_type="done",
                                    api_key=_get_api_key())
                sent += 1
            except Exception as e:
                log.warning(f"meshcode_done: failed to notify {name}: {e}")
    log.info(f"global done broadcast from {AGENT_NAME}: reason={reason!r} notified={sent}")
    # Immediately set sleeping — we're done, not listening anymore
    _set_state("sleeping", "sleeping")
    return {"ok": True, "global_done": True, "agents_notified": sent, "reason": reason}


@mcp.tool()
@with_working_status
def meshcode_check(include_acks: bool = False, since: Optional[str] = None, mark_read: bool = False) -> Dict[str, Any]:
    """Peek at inbox (non-destructive). Returns pending count + new messages.

    Args:
        include_acks: Include ack messages in response.
        since: ISO-8601 timestamp. Only return messages newer than this.
               Use meshcode_remember("last_seen", ts) to persist across sessions.
        mark_read: When True, consume messages (mark as read in DB) instead of
                   just peeking. Useful during boot when meshcode_wait() refuses
                   to run because of open tasks.
    """
    global _LAST_SEEN_TS
    pending = be.count_pending(_PROJECT_ID, AGENT_NAME, api_key=_get_api_key())
    # Peek at realtime buffer WITHOUT draining — check is non-destructive
    realtime_buffered = _REALTIME.peek() if _REALTIME else []
    # Don't mark as seen — meshcode_check is a peek, not a consume
    deduped = [m for m in realtime_buffered if _seen_key(m) not in _SEEN_MSG_IDS]

    # Fallback: if realtime buffer is empty but DB has pending messages,
    # fetch them from the DB. mark_read controls whether we consume or peek.
    if not deduped and pending > 0:
        raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=mark_read, api_key=_get_api_key())
        deduped = [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
                "id": m.get("id"),
                "parent_id": m.get("parent_msg_id"),
            }
            for m in raw
            if _seen_key({"id": m.get("id"), "from": m.get("from_agent"), "payload": m.get("payload", {}), "ts": m.get("created_at")}) not in _SEEN_MSG_IDS
        ]

    # Auto-apply last_seen_ts if no explicit since provided
    effective_since = since or _LAST_SEEN_TS
    if effective_since:
        deduped = [m for m in deduped if m.get("ts") and str(m["ts"]) > effective_since]

    # When mark_read=True, update tracking state so messages aren't re-processed
    if mark_read and deduped:
        for m in deduped:
            # _SEEN_MSG_IDS is a dict (key -> monotonic ts); use the helper so
            # eviction/ordering invariants are preserved. .add() was a regression
            # that crashed mark_read with: 'dict' object has no attribute 'add'.
            _mark_seen(_seen_key(m))
        latest_ts = max((str(m.get("ts", "")) for m in deduped), default=None)
        if latest_ts and (not _LAST_SEEN_TS or latest_ts > _LAST_SEEN_TS):
            _LAST_SEEN_TS = latest_ts

    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    result = {
        "pending": pending if not effective_since else len(split.get("messages", [])),
        **split,
    }
    # Auto-inject pending tasks
    pending_tasks = _get_pending_tasks_summary()
    if pending_tasks:
        result["pending_tasks"] = pending_tasks
    return result


@mcp.tool()
@with_working_status
def meshcode_status() -> Dict[str, Any]:
    """List all agents with status, role, and current task."""
    agents = be.get_board(_PROJECT_ID)
    return {
        "agents": [
            {
                "name": a["name"],
                "role": a.get("role", ""),
                "status": a.get("status", "?"),
                "task": a.get("task", ""),
                "last_heartbeat": a.get("last_heartbeat"),
            }
            for a in agents
        ],
    }


@mcp.tool()
@with_working_status
def meshcode_register(role: str = "") -> Dict[str, Any]:
    """Re-register agent (update role)."""
    return be.register_agent(PROJECT_NAME, AGENT_NAME, role or AGENT_ROLE, api_key=_get_api_key())


@mcp.tool()
def meshcode_set_status(status: str, task: str = "") -> Dict[str, Any]:
    """Update your status in the board.

    Args:
        status: One of: working, idle, standby, blocked, done, online, sleeping.
        task: Optional human-readable task description.
    """
    global _STAY_AWAKE
    # PRODUCT RULE: Cannot sleep/idle/standby with open tasks. Work first.
    if status in ("sleeping", "idle", "standby"):
        pending_tasks = _get_pending_tasks_summary()
        if pending_tasks:
            return {
                "refused": True,
                "reason": f"Cannot set status '{status}' — you have {len(pending_tasks)} open tasks. Work them first.",
                "pending_tasks": pending_tasks,
            }
    # Setting online/working = stay awake (prevent auto-sleep)
    # Setting sleeping = allow auto-sleep again
    if status in ("online", "working"):
        _STAY_AWAKE = True
    elif status == "sleeping":
        _STAY_AWAKE = False
    return be.set_status(_PROJECT_ID, AGENT_NAME, status, task, api_key=_get_api_key())


@mcp.tool()
@with_working_status
def meshcode_init(project: str, agent: str, role: str = "") -> Dict[str, Any]:
    """Switch project/agent context. Rarely needed."""
    global PROJECT_NAME, AGENT_NAME, AGENT_ROLE, _PROJECT_ID
    PROJECT_NAME = project
    AGENT_NAME = agent
    AGENT_ROLE = role
    pid = be.get_project_id(project)
    if not pid:
        return {"error": f"project '{project}' not found"}
    _PROJECT_ID = pid
    result = be.register_agent(project, agent, role or "MCP-connected agent", api_key=_get_api_key())
    return {"ok": True, "project": project, "agent": agent, "register": result}


@mcp.tool()
@with_working_status
def meshcode_task_create(title: str, description: str = "", assignee: str = "*",
                          priority: str = "normal", parent_task_id: Optional[str] = None) -> Dict[str, Any]:
    """Create task. assignee="*" for any, priority: low/normal/high/urgent."""
    if not title or not title.strip():
        return {"error": "title cannot be empty"}
    api_key = _get_api_key()
    result = be.task_create(api_key, _PROJECT_ID, AGENT_NAME, title.strip(),
                           description=description, assignee=assignee,
                           priority=priority, parent_task_id=parent_task_id)
    # Auto-notify assignee so they wake from meshcode_wait
    if isinstance(result, dict) and result.get("ok") and assignee and assignee != "*" and assignee != AGENT_NAME:
        try:
            be.send_message(_PROJECT_ID, AGENT_NAME, assignee, {
                "type": "task_assigned",
                "task_id": result.get("task_id", ""),
                "title": title,
                "priority": priority,
                "text": f"New {priority} task assigned to you: {title}",
            }, msg_type="system", api_key=_get_api_key())
        except Exception:
            pass  # best-effort notification
    return result


@mcp.tool()
@with_working_status
def meshcode_tasks(status_filter: Optional[str] = None, verbose: bool = False) -> Dict[str, Any]:
    """List tasks. Filter by status to find work.

    Args:
        status_filter: 'open' / 'in_progress' / 'done' / etc. None = all.
        verbose: When False (default), descriptions are truncated to 200 chars
            and null/empty fields are dropped to save tokens. Pass True for
            the full payload.

    Returns: {"ok": true, "tasks": [...]}
    """
    api_key = _get_api_key()
    include_done = status_filter == "done"
    result = be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter=status_filter, include_done=include_done)
    if verbose or not isinstance(result, dict) or not result.get("ok"):
        return result
    compact: List[Dict[str, Any]] = []
    for t in result.get("tasks", []):
        desc = t.get("description") or ""
        row: Dict[str, Any] = {
            "id": t.get("id"),
            "title": t.get("title"),
            "status": t.get("status"),
            "priority": t.get("priority"),
            "assignee": t.get("assignee"),
        }
        if t.get("claimed_by"):
            row["claimed_by"] = t["claimed_by"]
        if t.get("parent_task_id"):
            row["parent_task_id"] = t["parent_task_id"]
        if desc:
            if len(desc) > 200:
                row["description"] = desc[:200]
                row["_description_truncated"] = True
            else:
                row["description"] = desc
        compact.append(row)
    return {"ok": True, "tasks": compact}


@mcp.tool()
@with_working_status
def meshcode_task_claim(task_id: str) -> Dict[str, Any]:
    """Claim an open task. Fails if already claimed by someone else."""
    api_key = _get_api_key()
    return be.task_claim(api_key, _PROJECT_ID, task_id, AGENT_NAME)


@mcp.tool()
@with_working_status
def meshcode_task_complete(task_id: str, summary: str = "", force: bool = False) -> Dict[str, Any]:
    """Complete a claimed task with summary.

    Refuses if the task has open subtasks, unless force=True is passed with a
    reason in `summary`. This prevents closing a parent while lanes are still
    in flight.
    """
    api_key = _get_api_key()
    if not force:
        try:
            listing = be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter=None, include_done=False)
            if isinstance(listing, dict) and listing.get("ok"):
                open_subs = [
                    {"id": t["id"][:8], "title": t["title"][:80], "status": t["status"]}
                    for t in listing.get("tasks", [])
                    if t.get("parent_task_id") == task_id
                    and t.get("status") in ("open", "in_progress", "in_review")
                ]
                if open_subs:
                    return {
                        "refused": True,
                        "reason": f"Cannot complete — {len(open_subs)} open subtasks. Finish them or pass force=True with a reason in summary.",
                        "open_subtasks": open_subs,
                    }
        except Exception:
            pass  # Best-effort check; don't block on listing failure.
    result = be.task_complete(api_key, _PROJECT_ID, task_id, AGENT_NAME, summary=summary)
    # Task data persists in the task system — do NOT duplicate to memory.
    # Samuel: "los tasks no deben guardarse en memoria, para eso salen en tasks"
    return result


@mcp.tool()
@with_working_status
def meshcode_task_approve(task_id: str) -> Dict[str, Any]:
    """Approve a reviewed task."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_approve", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_approving_agent": AGENT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_task_reject(task_id: str, feedback: str = "") -> Dict[str, Any]:
    """Reject a task, sends back with feedback."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_reject", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_rejecting_agent": AGENT_NAME,
        "p_feedback": feedback,
    })


@mcp.tool()
@with_working_status
def meshcode_task_search(title_contains: Optional[str] = None,
                         status: Optional[str] = None,
                         assignee: Optional[str] = None,
                         limit: int = 20) -> Dict[str, Any]:
    """Search tasks by title/status/assignee. Use before task_create to dedupe."""
    return be.sb_rpc("mc_search_tasks", {
        "p_api_key": _get_api_key(),
        "p_project_id": _PROJECT_ID,
        "p_caller_agent": AGENT_NAME,
        "p_title_contains": title_contains,
        "p_status": status,
        "p_assignee": assignee,
        "p_limit": limit,
    })


@mcp.tool()
@with_working_status
def meshcode_agent_list() -> Dict[str, Any]:
    """Roster of agents in this meshwork with status + last_heartbeat."""
    return be.sb_rpc("mc_list_agents", {
        "p_api_key": _get_api_key(),
        "p_project_id": _PROJECT_ID,
    })


@mcp.tool()
@with_working_status
def meshcode_task_cancel(task_id: str, reason: str = "") -> Dict[str, Any]:
    """Cancel a task. Creator or commander only. Works on open/in_progress/in_review."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_cancel", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_cancelling_agent": AGENT_NAME,
        "p_reason": reason,
    })


@mcp.tool()
@with_working_status
def meshcode_task_reassign(task_id: str, new_assignee: str) -> Dict[str, Any]:
    """Reassign an unclaimed open task to a different agent. Creator or commander only."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_reassign", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_reassigning_agent": AGENT_NAME,
        "p_new_assignee": new_assignee,
    })


# ----------------- CROSS-MESH TASKS -----------------

@mcp.tool()
@with_working_status
def meshcode_create_cross_mesh_task(target_mesh: str, title: str,
                                     description: str = "",
                                     assignee: Optional[str] = None,
                                     priority: str = "normal") -> Dict[str, Any]:
    """Create a task in a linked meshwork (requires active mesh link).

    Args:
        target_mesh: Name of the target meshwork.
        title: Task title.
        description: Task description.
        assignee: Agent name in target mesh to assign to.
        priority: low / normal / high / urgent.
    """
    return be.sb_rpc("mc_create_cross_mesh_task", {
        "p_api_key": _get_api_key(),
        "p_target_mesh": target_mesh,
        "p_title": title,
        "p_description": description,
        "p_assignee": assignee,
        "p_priority": priority,
        "p_agent_name": AGENT_NAME,
    })


# ----------------- GOALS -----------------

@mcp.tool()
@with_working_status
def meshcode_set_goal(title: str, description: str = "",
                      priority: str = "normal", assignee: Optional[str] = None,
                      target_date: Optional[str] = None,
                      parent_id: Optional[str] = None) -> Dict[str, Any]:
    """Create a new goal for the meshwork.

    Args:
        title: Goal title.
        description: Optional detailed description.
        priority: low / normal / high / urgent.
        assignee: Agent name to assign the goal to.
        target_date: Target date (YYYY-MM-DD format).
        parent_id: UUID of parent goal for sub-goals.
    """
    return be.sb_rpc("mc_create_goal", {
        "p_api_key": _get_api_key(),
        "p_title": title,
        "p_description": description,
        "p_priority": priority,
        "p_assignee": assignee,
        "p_target_date": target_date,
        "p_parent_id": parent_id,
        "p_agent_name": AGENT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_goals() -> Dict[str, Any]:
    """List all goals for this meshwork."""
    return be.sb_rpc("mc_get_goals", {
        "p_api_key": _get_api_key(),
    })


@mcp.tool()
@with_working_status
def meshcode_update_goal(goal_id: str, status: Optional[str] = None,
                         title: Optional[str] = None,
                         description: Optional[str] = None,
                         priority: Optional[str] = None,
                         assignee: Optional[str] = None) -> Dict[str, Any]:
    """Update a goal's status or details.

    Args:
        goal_id: UUID of the goal to update.
        status: active / in_progress / achieved / abandoned.
        title: New title (optional).
        description: New description (optional).
        priority: New priority (optional).
        assignee: New assignee (optional).
    """
    return be.sb_rpc("mc_update_goal", {
        "p_api_key": _get_api_key(),
        "p_goal_id": goal_id,
        "p_status": status,
        "p_title": title,
        "p_description": description,
        "p_priority": priority,
        "p_assignee": assignee,
    })


# ----------------- MARKETPLACE -----------------

@mcp.tool()
@with_working_status
def meshcode_marketplace_search(query: Optional[str] = None,
                                 category: Optional[str] = None) -> Dict[str, Any]:
    """Search the MarketMesh marketplace for agents and meshes.

    Args:
        query: Search term (matches name, description, tags).
        category: Filter by category (Development, Content, Marketing, etc.).
    """
    return be.sb_rpc("mc_marketplace_list", {
        "p_category": category,
        "p_search": query,
        "p_status": "available",
    })


@mcp.tool()
@with_working_status
def meshcode_marketplace_install(template_slug: str,
                                  meshwork_name: str) -> Dict[str, Any]:
    """Install a marketplace item — creates a new meshwork with pre-configured agents.

    Args:
        template_slug: The slug of the marketplace item to install.
        meshwork_name: Name for the new meshwork (must be unique).
    """
    return be.sb_rpc("mc_marketplace_install_by_key", {
        "p_api_key": _get_api_key(),
        "p_template_slug": template_slug,
        "p_meshwork_name": meshwork_name,
    })


@mcp.tool()
@with_working_status
def meshcode_marketplace_list_installed() -> Dict[str, Any]:
    """List marketplace items you have installed."""
    return be.sb_rpc("mc_marketplace_installed_by_key", {
        "p_api_key": _get_api_key(),
    })


# ----------------- WEBHOOKS -----------------

@mcp.tool()
@with_working_status
def meshcode_webhook_register(url: str,
                               events: Optional[list] = None,
                               description: str = "") -> Dict[str, Any]:
    """Register a webhook URL to receive POST notifications for mesh events.

    Args:
        url: The URL to POST events to.
        events: List of event types to subscribe to.
               Options: agent_online, agent_offline, task_created, task_completed,
               message_cross_mesh, goal_updated.
               Default: all events (agent_online, agent_offline, task_created,
               task_completed, message_cross_mesh, goal_created, goal_updated).
        description: Human-readable description of this webhook.

    Returns the webhook_id and signing secret (save the secret — shown only once).
    """
    return be.sb_rpc("mc_webhook_register", {
        "p_api_key": _get_api_key(),
        "p_project_id": _PROJECT_ID,
        "p_url": url,
        "p_events": events,
        "p_description": description,
    })


@mcp.tool()
@with_working_status
def meshcode_webhook_list() -> Dict[str, Any]:
    """List all registered webhooks for this meshwork."""
    return be.sb_rpc("mc_webhook_list", {
        "p_api_key": _get_api_key(),
        "p_project_id": _PROJECT_ID,
    })


@mcp.tool()
@with_working_status
def meshcode_webhook_delete(webhook_id: str) -> Dict[str, Any]:
    """Delete a webhook by ID.

    Args:
        webhook_id: UUID of the webhook to delete.
    """
    return be.sb_rpc("mc_webhook_delete", {
        "p_api_key": _get_api_key(),
        "p_webhook_id": webhook_id,
    })


# ----------------- SCHEDULED TASKS -----------------

@mcp.tool()
@with_working_status
def meshcode_schedule(title: str, cron_expression: str, assignee: str = "*",
                      description: str = "", priority: str = "normal") -> Dict[str, Any]:
    """Create a recurring scheduled task. Fires on cron schedule.

    Args:
        title: Task title (created each time it fires).
        cron_expression: Standard cron (e.g. "0 9 * * 1-5" = 9am weekdays).
        assignee: Agent name or "*" for any.
        description: Task description template.
        priority: low/normal/high/urgent.
    """
    if not title or not title.strip():
        return {"error": "title cannot be empty"}
    if not cron_expression or not cron_expression.strip():
        return {"error": "cron_expression cannot be empty"}
    api_key = _get_api_key()
    return be.sb_rpc("mc_schedule_create", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_creator_agent": AGENT_NAME,
        "p_title": title.strip(),
        "p_cron_expression": cron_expression.strip(),
        "p_description": description,
        "p_assignee": assignee,
        "p_priority": priority,
    })


@mcp.tool()
@with_working_status
def meshcode_schedule_list() -> Dict[str, Any]:
    """List all scheduled/recurring tasks for this meshwork."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_schedule_list", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
    })


# ----------------- TEMPLATES -----------------

@mcp.tool()
@with_working_status
def meshcode_publish_template(slug: str, name: str, description: str = "",
                               category: str = "Custom", tags: Optional[List[str]] = None) -> Dict[str, Any]:
    """Publish this meshwork as a reusable template others can fork.

    Args:
        slug: URL-safe identifier (e.g. "my-saas-team"). Must be unique.
        name: Human-readable template name.
        description: What this template is for.
        category: Template category (Development, DevOps, Research, etc).
        tags: Searchable tags.
    """
    if not slug or not slug.strip():
        return {"error": "slug cannot be empty"}
    if not name or not name.strip():
        return {"error": "name cannot be empty"}
    api_key = _get_api_key()
    return be.sb_rpc("mc_template_publish", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_slug": slug.strip(),
        "p_name": name.strip(),
        "p_description": description,
        "p_category": category,
        "p_tags": tags or [],
    })


# ----------------- PROACTIVE HEALTH SCAN -----------------

@mcp.tool()
@with_working_status
def meshcode_auto_wake() -> Dict[str, Any]:
    """Scan meshwork health and suggest maintenance tasks.

    Checks: stale agents, task backlog, empty memories, unlinked meshworks.
    Returns a list of suggested tasks the commander can create.
    Call this on session start or periodically to keep the meshwork healthy.
    """
    api_key = _get_api_key()
    suggestions: List[Dict[str, str]] = []

    # 1. Check for stale agents (heartbeat >10 min, not offline/sleeping)
    agents = []  # Initialize before try so downstream checks don't NameError
    try:
        agents = be.get_board(_PROJECT_ID)
        import datetime as _dt
        now = _dt.datetime.now(_dt.timezone.utc)
        for a in agents:
            if a.get("status") in ("offline", "sleeping", "done", "needs_setup"):
                continue
            hb = a.get("last_heartbeat")
            if hb:
                try:
                    dt = _dt.datetime.fromisoformat(str(hb).replace("Z", "+00:00"))
                    age_min = (now - dt).total_seconds() / 60
                    if age_min > 10:
                        suggestions.append({
                            "title": f"Stale agent: {a['name']} ({int(age_min)}min no heartbeat)",
                            "priority": "high",
                            "assignee": "mesh-commander",
                            "description": f"Agent {a['name']} shows status '{a.get('status')}' but last heartbeat was {int(age_min)} min ago. Force disconnect or investigate.",
                        })
                except Exception:
                    pass
    except Exception:
        pass

    # 2. Check task backlog — open tasks with no assignee
    try:
        task_result = be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter="open")
        if isinstance(task_result, dict) and task_result.get("ok"):
            open_tasks = task_result.get("tasks", [])
            unassigned = [t for t in open_tasks if not t.get("assignee") or t.get("assignee") == "*"]
            if len(unassigned) > 3:
                suggestions.append({
                    "title": f"Task backlog: {len(unassigned)} unassigned open tasks",
                    "priority": "normal",
                    "assignee": "mesh-commander",
                    "description": "Review and assign or close stale tasks to keep the board clean.",
                })
    except Exception:
        pass

    # 3. Check for agents with zero memories
    try:
        for a in agents:
            mem_result = be.sb_rpc("mc_recall_all", {
                "p_api_key": api_key,
                "p_project_id": _PROJECT_ID,
                "p_agent_name": a["name"],
            })
            if isinstance(mem_result, dict) and mem_result.get("ok"):
                memories = mem_result.get("memories", [])
                if len(memories) == 0 and a.get("status") not in ("needs_setup",):
                    suggestions.append({
                        "title": f"Agent {a['name']} has zero memories",
                        "priority": "normal",
                        "assignee": a["name"],
                        "description": "Agent should save learnings, patterns, and preferences to memory for cross-session persistence.",
                    })
    except Exception:
        pass

    return {
        "ok": True,
        "suggestions": suggestions,
        "total": len(suggestions),
        "note": "Use meshcode_task_create to turn suggestions into assigned tasks.",
    }


# ----------------- MESH LINK TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_link(target_meshwork: str, source_agents: Optional[str] = None,
                  target_agents: Optional[str] = None) -> Dict[str, Any]:
    """Link to another meshwork. Target must accept."""
    api_key = _get_api_key()
    src = source_agents.split(",") if source_agents else ["*"]
    tgt = target_agents.split(",") if target_agents else ["*"]
    return be.sb_rpc("mc_create_mesh_link", {
        "p_api_key": api_key,
        "p_source_project_name": PROJECT_NAME,
        "p_target_project_name": target_meshwork,
        "p_source_agents": src,
        "p_target_agents": tgt,
    })


@mcp.tool()
@with_working_status
def meshcode_accept_link(link_id: str) -> Dict[str, Any]:
    """Accept a pending mesh link from another meshwork.

    Args:
        link_id: UUID of the pending link to accept.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_accept_mesh_link", {
        "p_api_key": api_key,
        "p_link_id": link_id,
        "p_project_name": PROJECT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_links() -> Dict[str, Any]:
    """List all mesh links (active, pending, revoked) for this meshwork."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_list_mesh_links", {
        "p_api_key": api_key,
        "p_project": PROJECT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_link_invite(source_project: str, note: str = "") -> Dict[str, Any]:
    """Generate a one-time invite token for another meshwork to link in.

    Returns {token, expires_at}. Share the token out-of-band. The recipient
    calls meshcode_link_redeem(token, their_meshwork) to auto-link
    (no separate accept step).
    """
    return be.sb_rpc("mc_create_link_invite", {
        "p_source_project": source_project,
        "p_note": note,
    })


@mcp.tool()
@with_working_status
def meshcode_link_redeem(token: str, target_meshwork: str) -> Dict[str, Any]:
    """Redeem an invite token — creates an ACTIVE mesh link in one step."""
    return be.sb_rpc("mc_redeem_link_invite", {
        "p_token": token,
        "p_target_project": target_meshwork,
    })


@mcp.tool()
@with_working_status
def meshcode_link_invites(source_project: Optional[str] = None) -> Dict[str, Any]:
    """List link invites this user has created (active/redeemed/expired/revoked)."""
    return be.sb_rpc("mc_list_my_link_invites", {
        "p_source_project": source_project,
    })


@mcp.tool()
@with_working_status
def meshcode_link_invite_revoke(token: str) -> Dict[str, Any]:
    """Revoke an outstanding (unredeemed) invite token."""
    return be.sb_rpc("mc_revoke_link_invite", {"p_token": token})


@mcp.tool()
@with_working_status
def meshcode_expand_link(link_id: str, agents: str) -> Dict[str, Any]:
    """Add agents to an active mesh link."""
    api_key = _get_api_key()
    agent_list = [a.strip() for a in agents.split(",")]
    return be.sb_rpc("mc_expand_mesh_link", {
        "p_api_key": api_key,
        "p_link_id": link_id,
        "p_src": agent_list,
        "p_tgt": agent_list,
        "p_project_name": PROJECT_NAME,
    })


# ----------------- ACCOUNT MANAGEMENT TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_create_meshwork(name: str) -> Dict[str, Any]:
    """Create a new meshwork."""
    api_key = _get_api_key()
    result = be.sb_rpc("mc_create_meshwork_by_api_key", {
        "p_api_key": api_key, "p_name": name,
    })
    if isinstance(result, dict) and result.get("ok"):
        return {**result, "next_step": f"Run: meshcode setup {name} <agent-name>"}
    return result or {"error": "failed to create meshwork"}


@mcp.tool()
@with_working_status
def meshcode_add_agent(name: str, role: str = "") -> Dict[str, Any]:
    """Add an agent to the current meshwork. Tell user to run 'meshcode setup <project> <name>' then 'meshcode run <name>'.

    Args:
        name: Agent name.
        role: Agent role description.
    """
    result = be.register_agent(PROJECT_NAME, name, role or "MCP-connected agent", api_key=_get_api_key())
    if isinstance(result, dict) and not result.get("error"):
        return {"ok": True, "agent": name, "next_step": f"Run: meshcode setup {PROJECT_NAME} {name} && meshcode run {name}"}
    return result or {"error": "failed to add agent"}


@mcp.tool()
@with_working_status
def meshcode_edit_agent(name: str, role: Optional[str] = None, launch_prompt: Optional[str] = None) -> Dict[str, Any]:
    """Update an agent's role or launch prompt. Notifies the running agent to reload.

    Args:
        name: Agent name to edit.
        role: New role description.
        launch_prompt: New launch prompt (injected into agent's system context).
    """
    result = be.sb_rpc("mc_agent_update_profile", {
        "p_project_id": _PROJECT_ID,
        "p_agent_name": name,
        "p_color": None,
        "p_display_name": None,
        "p_role_description": role,
        "p_launch_prompt": launch_prompt,
    })
    if not result:
        return {"error": "failed to update agent"}

    # Hot-swap: notify the running agent to reload its prompt
    if name != AGENT_NAME:
        try:
            be.send_message(_PROJECT_ID, AGENT_NAME, name, {
                "type": "prompt_update",
                "text": f"Your {'role' if role else 'launch prompt'} was updated by {AGENT_NAME}. Changes take effect on next boot or meshcode_check.",
                "updated_fields": {"role": role, "launch_prompt": launch_prompt is not None},
            }, msg_type="system", api_key=_get_api_key())
        except Exception:
            pass  # best-effort notification

    return result


@mcp.tool()
@with_working_status
def meshcode_edit_memory(agent_name: str, key: str, value: Any) -> Dict[str, Any]:
    """Edit another agent's memory (for commanders coordinating the team).

    Args:
        agent_name: Target agent whose memory to edit.
        key: Memory key.
        value: New value.
    """
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else {"_raw": value}
    return be.sb_rpc("mc_memory_set", {
        "p_api_key": api_key,
        "p_agent_name": agent_name,
        "p_key": key,
        "p_value": json_value,
        "p_project_name": PROJECT_NAME,
    }) or {"error": "failed to edit memory"}


# ----------------- SCRATCHPAD TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_scratchpad_set(key: str, value: Any) -> Dict[str, Any]:
    """Write to shared scratchpad (all agents in this meshwork can read/write).

    Args:
        key: Key name (e.g. "architecture_decisions", "conventions").
        value: Any JSON-serializable value.
    """
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else {"_raw": value}
    return be.sb_rpc("mc_scratchpad_set", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_key": key,
        "p_value": json_value,
        "p_tier": "reference",
    })


@mcp.tool()
@with_working_status
def meshcode_scratchpad_get(key: Optional[str] = None) -> Dict[str, Any]:
    """Read from shared scratchpad. Omit key to list all entries.

    Args:
        key: Specific key, or omit for all entries.
    """
    api_key = _get_api_key()
    if key:
        return be.sb_rpc("mc_scratchpad_get", {"p_api_key": api_key, "p_project_id": _PROJECT_ID, "p_key": key})
    else:
        return be.sb_rpc("mc_scratchpad_list", {"p_api_key": api_key, "p_project_id": _PROJECT_ID})


# ----------------- OBSIDIAN SYNC HELPER -----------------

def _sync_to_obsidian(key: str, value: Any) -> None:
    """Best-effort: push a memory to the user's Obsidian vault if configured.

    Uses the Obsidian Local REST API plugin (localhost:27124).
    Writes markdown notes with YAML frontmatter to MeshCode/<agent>/ folder.
    Failures are logged but never block the main memory write.
    """
    from datetime import datetime
    from urllib.request import Request, urlopen
    from urllib.error import URLError
    try:
        import importlib
        prefs_mod = importlib.import_module("meshcode.preferences")
        config = prefs_mod.get_obsidian_config()
        if not config:
            return

        # Build markdown note with YAML frontmatter
        timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        if isinstance(value, (dict, list)):
            body = json.dumps(value, indent=2, default=str)
        else:
            body = str(value)

        content = f"""---
agent: {AGENT_NAME}
meshwork: {PROJECT_NAME}
key: {key}
synced_at: {timestamp}
source: meshcode
---

{body}
"""
        # PUT to Obsidian REST API — creates or overwrites the note
        note_path = f"MeshCode/{AGENT_NAME}/{key}.md"
        url = f"{config['vault_url']}/vault/{note_path}"
        req = Request(
            url,
            data=content.encode("utf-8"),
            headers={
                "Authorization": f"Bearer {config['api_key']}",
                "Content-Type": "text/markdown",
            },
            method="PUT",
        )
        urlopen(req, timeout=5)
        log.debug(f"synced memory '{key}' to Obsidian vault")
    except (ImportError, URLError, OSError) as e:
        log.debug(f"obsidian sync skipped for '{key}': {e}")
    except Exception as e:
        log.warning(f"obsidian sync failed for '{key}': {e}")


# ----------------- MEMORY TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_remember(key: str, value: Any) -> Dict[str, Any]:
    """Store a persistent memory (survives restarts). Only for reusable learnings, NOT task data.

    Args:
        key: Short key (e.g. "team_conventions").
        value: Any JSON-serializable value.
    """
    if not key or not key.strip():
        return {"error": "key cannot be empty"}
    key = key.strip()
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else json.dumps(value)
    if isinstance(json_value, str):
        try:
            json_value = json.loads(json_value)
        except (json.JSONDecodeError, TypeError):
            json_value = {"_raw": value}
    result = be.sb_rpc("mc_memory_set", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_key": key,
        "p_value": json_value,
        "p_tier": "reference",
        "p_project_name": PROJECT_NAME,
    })
    # Best-effort sync to Obsidian vault (if configured)
    if isinstance(result, dict) and result.get("ok"):
        try:
            _sync_to_obsidian(key, json_value)
        except Exception:
            pass  # Obsidian sync is best-effort, never block memory writes
    return result


@mcp.tool()
@with_working_status
def meshcode_recall(key: Optional[str] = None) -> Dict[str, Any]:
    """Get persistent memories. Omit key to get all.

    Args:
        key: Specific key, or omit for all memories.
    """
    api_key = _get_api_key()
    if key:
        return be.sb_rpc("mc_memory_get", {
            "p_api_key": api_key,
            "p_agent_name": AGENT_NAME,
            "p_key": key,
        })
    else:
        # Return critical tier (full content) + counts of other tiers.
        # Episodic memories are large and should be searched on demand
        # via meshcode_recall_search(), not dumped into context.
        critical = be.sb_rpc("mc_memory_list", {
            "p_api_key": api_key,
            "p_agent_name": AGENT_NAME,
            "p_tier": "critical",
            "p_project_name": PROJECT_NAME,
        })
        # Also fetch reference tier keys (lightweight, useful context)
        reference = be.sb_rpc("mc_memory_list", {
            "p_api_key": api_key,
            "p_agent_name": AGENT_NAME,
            "p_tier": "reference",
            "p_project_name": PROJECT_NAME,
        })
        if isinstance(critical, dict) and critical.get("ok"):
            ref_keys = []
            if isinstance(reference, dict) and reference.get("ok"):
                ref_keys = [m.get("key") for m in reference.get("memories", [])]
            critical["reference_keys"] = ref_keys
            # tip removed — already in system prompt, saves ~20 tokens per call
        return critical


@mcp.tool()
@with_working_status
def meshcode_recall_keys() -> Dict[str, Any]:
    """List memory keys only (no values). Cheap token cost for deciding what to recall."""
    api_key = _get_api_key()
    result = be.sb_rpc("mc_memory_list", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_tier": "reference",
        "p_project_name": PROJECT_NAME,
    })
    if isinstance(result, dict) and result.get("ok"):
        keys = [m.get("key") for m in result.get("memories", []) if m.get("key")]
        return {"ok": True, "keys": keys, "count": len(keys)}
    return result


@mcp.tool()
@with_working_status
def meshcode_forget(key: str) -> Dict[str, Any]:
    """Delete a stored memory.

    Args:
        key: The key to delete.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_memory_delete", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_key": key,
        "p_project_name": PROJECT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_recall_search(query: str) -> Dict[str, Any]:
    """Full-text search across episodic memories. Use this when you need
    past-incident or debug-log context that wasn't preloaded at boot.

    Returns top 10 matches ranked by relevance, with snippets of the
    stored value. Episodic memories are not preloaded — search them on
    demand instead of polluting the system prompt.

    Args:
        query: Plain English search query.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_memory_search", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_query": query,
        "p_project_name": PROJECT_NAME,
    })


# ----------------- BUG REPORTING -----------------

@mcp.tool()
@with_working_status
def meshcode_report_bug(description: str) -> Dict[str, Any]:
    """Report a bug from within the mesh. Visible in admin panel.

    Args:
        description: What went wrong — include steps to reproduce if possible.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_report_bug", {
        "p_api_key": api_key,
        "p_description": description,
        "p_meshwork_name": PROJECT_NAME,
        "p_agent_name": AGENT_NAME,
    })


# ----------------- HEALTH CHECK -----------------

@mcp.tool()
def meshcode_health() -> Dict[str, Any]:
    """Check MCP server health: DB connectivity, Realtime status, circuit breaker state, uptime."""
    import time as _t
    health: Dict[str, Any] = {
        "instance_id": _INSTANCE_ID,
        "sdk_version": _SDK_VERSION,
    }

    # DB latency check
    _start = _t.monotonic()
    try:
        r = be.sb_select("mc_projects", f"id=eq.{_PROJECT_ID}", limit=1)
        health["db_latency_ms"] = round((_t.monotonic() - _start) * 1000, 1)
        health["db_status"] = "ok" if r else "empty"
    except Exception as e:
        health["db_latency_ms"] = round((_t.monotonic() - _start) * 1000, 1)
        health["db_status"] = f"error: {e}"

    # Circuit breaker state
    health["circuit_breaker"] = {
        "state": be._circuit.state,
        "failure_count": be._circuit.failure_count,
        "threshold": be._circuit.failure_threshold,
    }

    # Realtime status
    health["realtime_connected"] = _REALTIME.is_connected if _REALTIME else False
    health["realtime_subscribed"] = _REALTIME.is_subscribed if _REALTIME else False

    # Process uptime
    try:
        import psutil
        proc = psutil.Process()
        health["uptime_seconds"] = round(_t.time() - proc.create_time(), 0)
    except Exception:
        health["uptime_seconds"] = "unknown (psutil not available)"

    # Server-side system health (aggregate metrics from DB)
    try:
        sys_health = be.sb_rpc("mc_system_health", {})
        if isinstance(sys_health, dict) and sys_health.get("ok"):
            health["system"] = {
                "active_agents": sys_health.get("active_agent_count"),
                "stale_agents": sys_health.get("stale_agent_count"),
                "message_delivery_rate": sys_health.get("message_delivery_rate"),
                "messages_1h": sys_health.get("total_messages_1h"),
                "failed_rpcs_1h": sys_health.get("failed_rpc_count_1h"),
            }
    except Exception:
        pass  # mc_system_health may not be deployed yet

    # Installed-vs-PyPI version diagnostic. Running MCP servers cannot hot-reload
    # server.py edits — fixes shipped to PyPI need a Claude Code restart to take
    # effect. Surface the gap so users know to restart.
    try:
        import urllib.request as _vreq
        import json as _vjson
        with _vreq.urlopen("https://pypi.org/pypi/meshcode/json", timeout=3) as _vr:
            _latest = _vjson.loads(_vr.read()).get("info", {}).get("version")
        health["pypi"] = {
            "installed": _SDK_VERSION,
            "latest": _latest,
            "stale": _latest != _SDK_VERSION if _latest else None,
        }
        if _latest and _latest != _SDK_VERSION:
            health["pypi"]["recommendation"] = (
                f"Restart Claude Code to upgrade MeshCode {_SDK_VERSION} → {_latest}. "
                "Server.py-side fixes (sends, downloads, normalization) will not "
                "take effect until restart."
            )
    except Exception as _e:
        health["pypi"] = {"installed": _SDK_VERSION, "latest": None, "error": str(_e)[:120]}

    return health


# ----------------- RESOURCES -----------------

@mcp.tool()
def meshcode_auto_wake(enabled: bool) -> Dict[str, Any]:
    """Toggle auto-wake: when enabled, if this agent receives a mesh message
    while idle (not in meshcode_wait), the MCP server injects a nudge into
    the terminal via OS automation (AppleScript on Mac, PowerShell on Windows).

    This lets other agents wake you up remotely without burning tokens in a
    wait loop.

    Args:
        enabled: True to enable, False to disable.
    """
    global _AUTO_WAKE
    _AUTO_WAKE = enabled
    import platform
    return {
        "ok": True,
        "auto_wake": enabled,
        "platform": platform.system(),
        "note": "When idle, incoming messages will inject a nudge into your terminal." if enabled else "Auto-wake disabled. You won't be nudged when idle."
    }


def inbox_resource() -> str:
    """Current pending messages for this agent. Read-only — does NOT mark as read."""
    pending = be.sb_select(
        "mc_messages",
        f"project_id=eq.{_PROJECT_ID}&to_agent=eq.{AGENT_NAME}&read=eq.false",
        order="created_at.asc",
    )
    return json.dumps({
        "count": len(pending),
        "messages": [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
                "id": m.get("id"),
                "parent_id": m.get("parent_msg_id"),
            }
            for m in pending
        ],
    }, indent=2)


@mcp.resource("meshcode://board")
def board_resource() -> str:
    """Snapshot of the meshwork board (all agents and their status)."""
    agents = be.get_board(_PROJECT_ID)
    return json.dumps({
        "project": PROJECT_NAME,
        "agents": agents,
    }, indent=2, default=str)


@mcp.resource("meshcode://history")
def history_resource() -> str:
    """Recent message history for this meshwork (last 20 non-ack messages)."""
    history = be.get_history(_PROJECT_ID, limit=20, api_key=_get_api_key())
    return json.dumps({
        "project": PROJECT_NAME,
        "history": history,
    }, indent=2, default=str)


# ============================================================
# Entry point
# ============================================================

def _auto_update() -> None:
    """Blocking self-update: check PyPI, install if newer, re-exec.

    Ensures every agent launch always runs the latest meshcode version.
    The update is blocking (with short timeouts) so the new code is loaded
    before the MCP server starts — no "two-launch" delay.

    Disable with MESHCODE_AUTO_UPDATE=0 if needed.
    Re-exec guard: MESHCODE_UPDATED=1 prevents infinite restart loops.
    """
    if os.environ.get("MESHCODE_AUTO_UPDATE", "1").lower() in ("0", "false", "no"):
        log.debug("[meshcode] Auto-update disabled (MESHCODE_AUTO_UPDATE=0)")
        return
    if os.environ.get("MESHCODE_UPDATED") == "1":
        return

    import subprocess
    import urllib.request

    # 1. Fetch latest version from PyPI (fast, 3s timeout)
    current = "0.0.0"
    try:
        from meshcode import __version__
        current = __version__
    except Exception:
        pass

    latest = None
    try:
        req = urllib.request.Request(
            f"https://pypi.org/pypi/meshcode/json",
            headers={"User-Agent": f"meshcode/{current}"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        latest = data.get("info", {}).get("version")
    except Exception:
        log.debug("[meshcode] Auto-update: PyPI check failed (offline?), skipping")
        return

    if not latest:
        return

    # 2. Compare versions
    def _ver(v: str):
        return tuple(int(x) for x in v.split(".") if x.isdigit())

    try:
        if _ver(latest) <= _ver(current):
            log.debug(f"[meshcode] Already at latest version ({current})")
            return
    except Exception:
        return

    # 3. Install the new version (blocking, 60s timeout)
    print(f"[meshcode] Updating {current} → {latest}...", file=sys.stderr)
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade",
             "--disable-pip-version-check", "--quiet", "meshcode"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode != 0:
            log.debug(f"[meshcode] pip upgrade failed: {result.stderr}")
            return
    except subprocess.TimeoutExpired:
        log.debug("[meshcode] pip upgrade timed out (60s), skipping")
        return
    except Exception as e:
        log.debug(f"[meshcode] Auto-update failed: {e}")
        return

    # 4. In MCP mode, NEVER re-exec — it kills the stdio pipe to Claude Code.
    #    The new version will load on the next clean boot.
    if os.environ.get("MESHCODE_MCP_SERVE") == "1":
        print(f"[meshcode] Updated {current} → {latest}. Will load on next boot (MCP mode — cannot restart).", file=sys.stderr)
        return

    # CLI mode: safe to re-exec
    print(f"[meshcode] Updated to {latest}, restarting...", file=sys.stderr)
    os.environ["MESHCODE_UPDATED"] = "1"
    try:
        if sys.platform == "win32":
            import subprocess as _sp_reexec
            _sp_reexec.Popen([sys.executable] + sys.argv)
            sys.exit(0)
        else:
            os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception as e:
        log.debug(f"[meshcode] Re-exec failed: {e}, continuing with old version")


def run_server():
    """Start the MCP server on stdio (default for Claude Code)."""
    _auto_update()
    print(
        f"[meshcode-mcp] Starting server for {AGENT_NAME}@{PROJECT_NAME}",
        file=sys.stderr,
    )
    # Restore real stdout for FastMCP's JSON-RPC transport.
    # sys.stdout was redirected to stderr at module load to prevent
    # accidental stdout writes from corrupting the MCP protocol.
    sys.stdout = _REAL_STDOUT

    # Claude Code cancels tool calls on ESC via multiple side channels that
    # are destructive to the stdio subprocess. 2.10.26's SIG_IGN-on-SIGINT
    # fix was incomplete in the wild (2.10.27 field test died anyway), so we
    # widen the net: ignore every signal Claude Code is known to send on
    # cancellation and log any that arrive so we can see what actually fires.
    #
    # SIGINT  — kernel default: terminate. asyncio Runner also installs a
    #           cancel-main-task handler, but only if the current handler is
    #           default_int_handler; SIG_IGN here trips that guard.
    # SIGTERM — kernel default: terminate. Some Claude Code versions send
    #           this after SIGINT if the subprocess didn't exit fast enough.
    # SIGHUP  — kernel default: terminate. Sent when the controlling tty
    #           detaches or the parent process restructures its session.
    # SIGPIPE — kernel default: terminate. Fires when Claude Code closes its
    #           side of stdout while we're mid-write. Ignoring makes the
    #           write fail with EPIPE instead of killing us.
    #
    # SIGKILL and SIGSTOP cannot be caught — that is how the process is
    # meant to be forcibly stopped (`kill -9 <pid>` still works). stdin EOF
    # is untouched and remains the clean-shutdown signal for session end.
    import signal
    _signal_counts: Dict[int, int] = {}
    def _diag_ignore(signum, frame):  # pragma: no cover - signal handler
        try:
            name = signal.Signals(signum).name
        except Exception:
            name = f"signal-{signum}"
        _signal_counts[signum] = _signal_counts.get(signum, 0) + 1
        try:
            sys.stderr.write(f"[meshcode-mcp] received {name} ({signum}); ignored to keep MCP alive during tool cancellation\n")
            sys.stderr.flush()
        except Exception:
            pass
        # Log ESC-triggered SIGINT as an incident to mesh memory (best-effort)
        if signum == getattr(signal, "SIGINT", -1) and _signal_counts[signum] == 1:
            try:
                import threading
                def _log_esc():
                    try:
                        be.sb_rpc("mc_memory_set", {
                            "p_api_key": _get_api_key(),
                            "p_agent_name": AGENT_NAME,
                            "p_project_id": _PROJECT_ID,
                            "p_key": "last_esc_interrupt",
                            "p_value": {"signal": name, "count": 1,
                                        "ts": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())},
                        })
                    except Exception:
                        pass
                threading.Thread(target=_log_esc, daemon=True).start()
            except Exception:
                pass
    for _sig_name in ("SIGINT", "SIGTERM", "SIGHUP", "SIGPIPE"):
        _sig = getattr(signal, _sig_name, None)
        if _sig is None:
            continue
        try:
            signal.signal(_sig, _diag_ignore)
        except (ValueError, OSError):
            # Non-main thread or Windows doesn't expose the signal — harmless.
            pass

    # 2.10.29 field test proved: a bare FastMCP (naive.py / armored.py) loaded
    # via `claude mcp add` survives ESC, but meshcode does not — even after
    # moving out of the "Built-in" bucket to "Project". The remaining delta
    # between meshcode and the naked repro is our lifespan handler: it does
    # network I/O (release_lease, memory_set), blocking thread joins, and an
    # await on Realtime.stop() in its `finally`. When ESC cancels the in-flight
    # tool, CancelledError cascades into those shutdown steps, one of them
    # raises, and the event loop unwinds — process exits.
    #
    # Short of rewriting the lifespan (which we will), the pragmatic safety
    # net is to treat `mcp.run()` returning unexpectedly as an event loop
    # casualty and spin up a fresh one. FastMCP registers tools at import
    # time on the module-level `mcp` object, so the restart re-uses them;
    # only the lifespan re-runs. `SystemExit` is let through so `sys.exit`
    # from config-validation paths still works. stdin EOF returns from
    # `mcp.run()` normally, which breaks the loop.
    import time as _time_mod
    _restart_count = 0
    while True:
        try:
            mcp.run()
        except SystemExit:
            raise
        except BaseException as _e:
            _restart_count += 1
            try:
                sys.stderr.write(
                    f"[meshcode-mcp] mcp.run() raised {type(_e).__name__}: {_e} "
                    f"(restart #{_restart_count}); re-entering event loop in 0.3s\n"
                )
                sys.stderr.flush()
            except Exception:
                pass
            # If we're restarting more than a few times a second, something
            # is wrong (config error, unrecoverable import). Bail.
            if _restart_count > 20:
                try:
                    sys.stderr.write("[meshcode-mcp] too many restarts; exiting\n")
                except Exception:
                    pass
                break
            _time_mod.sleep(0.3)
            continue
        # Clean return = stdin EOF = Claude Code closed the pipe = real shutdown
        break
