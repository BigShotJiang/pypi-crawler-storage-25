"""Thin Supabase REST backend used by both the MCP server and tests.

Reuses the helpers from comms_v4.py without going through subprocess.
Zero deps beyond stdlib (urllib + http.client for connection pooling).
"""
import http.client
import json
import logging
import os
import ssl
import time as _time
import threading as _threading

log = logging.getLogger("meshcode-mcp.backend")
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen


# ── Normalised error envelope ───────────────────────────────────
# Every internal error from _request() and sb_rpc() now returns:
#   {"error": {"code": str, "message": str, "source": str}}
# where:
#   code    — HTTP status as string, "0" for network errors, "503" for circuit breaker
#   message — human-readable description
#   source  — "circuit_breaker", "http", "network", "rpc"
#
# Callers check with:  is_error(result)
# Extract message:     get_error_message(result)

def _make_error(message: str, *, code: str = "0", source: str = "unknown") -> Dict[str, Any]:
    """Build a normalised error envelope."""
    return {"error": {"code": str(code), "message": message, "source": source}}


def is_error(result: Any) -> bool:
    """Return True if *result* is a normalised error envelope."""
    return (isinstance(result, dict)
            and isinstance(result.get("error"), dict)
            and "message" in result["error"])


def get_error_message(result: Any) -> str:
    """Extract the human-readable message from an error envelope (or '')."""
    if is_error(result):
        return result["error"]["message"]
    if isinstance(result, dict) and isinstance(result.get("error"), str):
        return result["error"]
    return ""


# ── Circuit Breaker ──────────────────────────────────────────────
# Protects against cascading failures when Supabase is down.
# States: CLOSED (normal) → OPEN (reject fast) → HALF_OPEN (probe)
#
# v2 fixes (2026-04-18):
#   1. Rolling failure window — only recent failures count toward threshold
#   2. Exponential backoff — half-open probe failure doubles recovery timeout
#   3. Max open duration — force-resets after 5 min regardless of probe results
#   4. Pool flush on recovery — clears stale sockets before half-open probe
#   5. sb_rpc records ONE failure per call, not one per retry attempt
class _CircuitBreaker:
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 10.0,
                 max_recovery_timeout: float = 60.0, window_seconds: float = 60.0,
                 max_open_seconds: float = 300.0):
        self.failure_threshold = failure_threshold
        self._base_recovery_timeout = recovery_timeout
        self._max_recovery_timeout = max_recovery_timeout
        self._window_seconds = window_seconds
        self._max_open_seconds = max_open_seconds
        self.state = self.CLOSED
        self._failures: list = []
        self._current_recovery_timeout = recovery_timeout
        self._opened_at = 0.0
        self.last_failure_time = 0.0
        self._lock = _threading.Lock()
        self._pool_ref = None

    def set_pool(self, pool):
        self._pool_ref = pool

    def _prune_old_failures(self):
        cutoff = _time.monotonic() - self._window_seconds
        self._failures = [t for t in self._failures if t > cutoff]

    def _flush_pool(self):
        if self._pool_ref:
            try:
                self._pool_ref.close()
            except Exception:
                pass

    def can_execute(self) -> bool:
        with self._lock:
            if self.state == self.CLOSED:
                return True
            now = _time.monotonic()
            if self.state == self.OPEN:
                if now - self._opened_at >= self._max_open_seconds:
                    log.warning("circuit breaker: max open duration (%ds) reached — force half-open",
                                int(self._max_open_seconds))
                    self.state = self.HALF_OPEN
                    self._failures.clear()
                    self._current_recovery_timeout = self._base_recovery_timeout
                    self._flush_pool()
                    return True
                if now - self.last_failure_time >= self._current_recovery_timeout:
                    log.info("circuit breaker: recovery timeout elapsed — half-open probe")
                    self.state = self.HALF_OPEN
                    self._flush_pool()
                    return True
                return False
            return True

    def reset(self) -> None:
        """Force-reset circuit breaker to CLOSED. Called on MCP lifespan restart
        so ESC-induced failures don't permanently open the breaker."""
        with self._lock:
            prev = self.state
            self._failures.clear()
            self.state = self.CLOSED
            self._current_recovery_timeout = self._base_recovery_timeout
            self.last_failure_time = 0.0
            self._opened_at = 0.0
            if prev != self.CLOSED:
                log.info("circuit breaker: force-reset to CLOSED (lifespan restart)")

    def record_success(self) -> None:
        with self._lock:
            prev = self.state
            self._failures.clear()
            self.state = self.CLOSED
            self._current_recovery_timeout = self._base_recovery_timeout
            if prev != self.CLOSED:
                log.info("circuit breaker: recovered — back to CLOSED")

    def record_failure(self) -> None:
        if self._failures_suppressed():
            return  # ESC cancel-drain: don't amplify into CB open
        with self._lock:
            now = _time.monotonic()
            self._failures.append(now)
            self.last_failure_time = now
            self._prune_old_failures()
            if self.state == self.HALF_OPEN:
                self.state = self.OPEN
                self._opened_at = now
                self._current_recovery_timeout = min(
                    self._current_recovery_timeout * 2,
                    self._max_recovery_timeout
                )
                log.warning("circuit breaker: half-open probe failed — OPEN (next probe in %ds)",
                            int(self._current_recovery_timeout))
                self._emit_cb_telemetry("half_open_failed", len(self._failures))
            elif len(self._failures) >= self.failure_threshold:
                self.state = self.OPEN
                self._opened_at = now
                log.warning("circuit breaker: %d failures in %ds window — OPEN",
                            len(self._failures), int(self._window_seconds))
                self._emit_cb_telemetry("threshold_exceeded", len(self._failures))

    @property
    def is_open(self) -> bool:
        return self.state == self.OPEN

    @property
    def failure_count(self) -> int:
        with self._lock:
            self._prune_old_failures()
            return len(self._failures)

    # ── Cancel-mode: suppress failure recording during ESC drain ──
    # 3 rapid ESC cancellations can cause 6+ network errors (half-closed
    # sockets, timeout on retry sleep) that open the CB permanently,
    # making the agent fully deaf.  During cancel drains, failures are
    # expected and should NOT count.
    _suppress_failures = _threading.local()

    def suspend_failures(self):
        """Context manager: failures inside this block are silently ignored."""
        import contextlib as _ctx

        @_ctx.contextmanager
        def _ctx_mgr():
            self._suppress_failures.active = True
            try:
                yield
            finally:
                self._suppress_failures.active = False
        return _ctx_mgr()

    def _failures_suppressed(self) -> bool:
        return getattr(self._suppress_failures, "active", False)

    @staticmethod
    def _emit_cb_telemetry(reason: str, failure_count: int) -> None:
        """JSON telemetry for circuit breaker state changes."""
        import json as _j, sys as _sys
        try:
            record = {"event": "circuit_breaker", "reason": reason,
                      "failure_count": failure_count, "ts": _time.time()}
            _sys.stderr.write(f"[meshcode-telemetry] {_j.dumps(record)}\n")
            _sys.stderr.flush()
        except Exception:
            pass


_circuit = _CircuitBreaker(failure_threshold=5, recovery_timeout=10.0,
                           max_recovery_timeout=60.0, window_seconds=60.0,
                           max_open_seconds=300.0)

# Bake in production defaults — RLS-protected publishable key, safe to ship.
_DEFAULT_SUPABASE_URL = "https://gjinagyyjttyxnaoavnz.supabase.co"
_DEFAULT_SUPABASE_KEY = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"

def _load_env_file() -> Dict[str, str]:
    env_path = Path.home() / ".meshcode" / "env"
    if not env_path.exists():
        return {}
    out: Dict[str, str] = {}
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except Exception as e:
        log.debug(f"env file parse error ({env_path}): {e}")
    return out

_env_file = _load_env_file()
SUPABASE_URL = os.environ.get("SUPABASE_URL") or _env_file.get("SUPABASE_URL") or _DEFAULT_SUPABASE_URL
SUPABASE_KEY = os.environ.get("SUPABASE_KEY") or _env_file.get("SUPABASE_KEY") or _DEFAULT_SUPABASE_KEY
SUPABASE_SERVICE_ROLE_KEY = (
    os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    or os.environ.get("SUPABASE_SECRET_KEY")
    or _env_file.get("SUPABASE_SERVICE_ROLE_KEY")
    or _env_file.get("SUPABASE_SECRET_KEY")
    or _env_file.get("NEW_SUPABASE_SECRET")
    or ""
)
SCHEMA = "meshcode"


# ── Persistent HTTPS Connection Pool ──────────────────────────────
# Each urlopen() opens a new TCP+TLS connection (~1-2s overhead).
# This pool reuses connections, cutting typical latency from ~3s to ~100ms.
# Pool of N connections (default 3) to avoid lock contention between the
# heartbeat thread, tool call handlers, and background recording thread.
class _ConnectionPool:
    """Thread-safe HTTPS connection pool to Supabase (N connections, round-robin)."""

    def __init__(self, url: str, pool_size: int = 3, max_idle: float = 30.0):
        parsed = urlparse(url)
        self._host = parsed.hostname
        self._port = parsed.port or 443
        self._pool_size = pool_size
        self._conns: List[Optional[http.client.HTTPSConnection]] = [None] * pool_size
        self._locks = [_threading.Lock() for _ in range(pool_size)]
        self._last_used = [0.0] * pool_size
        self._max_idle = max_idle
        self._ctx = ssl.create_default_context()
        self._counter = 0
        self._counter_lock = _threading.Lock()

    def _pick_slot(self) -> int:
        """Round-robin slot selection."""
        with self._counter_lock:
            slot = self._counter % self._pool_size
            self._counter += 1
        return slot

    def _get_conn(self, slot: int) -> http.client.HTTPSConnection:
        now = _time.monotonic()
        if self._conns[slot] is not None:
            if now - self._last_used[slot] > self._max_idle:
                try:
                    self._conns[slot].close()
                except Exception:
                    pass
                self._conns[slot] = None
        if self._conns[slot] is None:
            self._conns[slot] = http.client.HTTPSConnection(
                self._host, self._port, timeout=10, context=self._ctx
            )
        return self._conns[slot]

    def request(self, method: str, path: str, body: Optional[bytes], headers: Dict[str, str]) -> tuple:
        """Returns (status, response_body_str). Thread-safe with per-slot locking."""
        slot = self._pick_slot()
        with self._locks[slot]:
            for attempt in range(2):
                conn = self._get_conn(slot)
                try:
                    conn.request(method, path, body=body, headers=headers)
                    resp = conn.getresponse()
                    data = resp.read().decode("utf-8")
                    self._last_used[slot] = _time.monotonic()
                    return resp.status, data
                except (http.client.RemoteDisconnected, BrokenPipeError,
                        ConnectionResetError, OSError) as e:
                    try:
                        self._conns[slot].close()
                    except Exception:
                        pass
                    self._conns[slot] = None
                    if attempt == 0:
                        continue
                    raise

    def close(self):
        for i in range(self._pool_size):
            with self._locks[i]:
                if self._conns[i]:
                    try:
                        self._conns[i].close()
                    except Exception:
                        pass
                    self._conns[i] = None


_pool = _ConnectionPool(SUPABASE_URL, pool_size=3)
_circuit.set_pool(_pool)


def _now_iso() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S+00:00")


def _headers(*, prefer: Optional[str] = None, content_profile: bool = True) -> Dict[str, str]:
    h = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }
    if content_profile:
        h["Accept-Profile"] = SCHEMA
        h["Content-Profile"] = SCHEMA
    if prefer:
        h["Prefer"] = prefer
    return h


def _request(method: str, path: str, *, data: Any = None, prefer: Optional[str] = None,
             _max_retries: int = 3) -> Any:
    import random as _random
    if not _circuit.can_execute():
        return _make_error("circuit breaker open — Supabase temporarily unavailable",
                           code="503", source="circuit_breaker")
    rest_path = f"/rest/v1/{path}"
    body = json.dumps(data).encode("utf-8") if data else None
    hdrs = _headers(prefer=prefer)
    last_err = None
    for attempt in range(_max_retries):
        try:
            status, raw = _pool.request(method, rest_path, body, hdrs)
            if 200 <= status < 300:
                _circuit.record_success()
                return json.loads(raw) if raw.strip() else None
            elif 400 <= status < 500:
                # Client errors are not transient — don't retry
                _circuit.record_success()
                try:
                    err_obj = json.loads(raw)
                    return _make_error(err_obj.get("message", raw[:200]),
                                       code=str(status), source="http")
                except Exception:
                    return _make_error(raw[:200], code=str(status), source="http")
            else:
                # 5xx — transient, retry
                last_err = raw[:200]
        except (KeyboardInterrupt, SystemExit):
            # ESC / Ctrl-C / process exit — NOT a Supabase failure.
            raise
        except (URLError, OSError, TimeoutError, http.client.HTTPException) as e:
            last_err = str(getattr(e, 'reason', e))
        # Retry with jitter for transient errors (5xx, network)
        if attempt < _max_retries - 1:
            delay = (2 ** attempt) + _random.uniform(0, 1)
            _time.sleep(delay)
    _circuit.record_failure()
    return _make_error(str(last_err)[:200] if last_err else "request failed after retries",
                       code="0", source="network")


def sb_select(table: str, filters: str = "", order: Optional[str] = None, limit: Optional[int] = None) -> List[Dict]:
    params = []
    if filters:
        params.append(filters)
    if order:
        params.append(f"order={order}")
    if limit:
        params.append(f"limit={limit}")
    path = f"{table}?{'&'.join(params)}" if params else table
    result = _request("GET", path)
    if is_error(result):
        return []
    return result or []


def sb_insert(table: str, row: Dict, *, upsert: bool = False, on_conflict: Optional[str] = None) -> Any:
    prefer = "return=representation"
    if upsert:
        prefer += ",resolution=merge-duplicates"
    path = table
    if on_conflict:
        path += f"?on_conflict={on_conflict}"
    return _request("POST", path, data=row, prefer=prefer)


def sb_update(table: str, filters: str, updates: Dict) -> Any:
    return _request("PATCH", f"{table}?{filters}", data=updates, prefer="return=representation")


# Session recording config — set by MCP server at boot
_recording_enabled = False
_recording_api_key = ""
_recording_project_id = ""
_recording_agent_name = ""
_recording_session_id = ""

# RPCs that should NOT be recorded (internal/heartbeat/recording itself)
_SKIP_RECORDING = {"mc_heartbeat", "mc_record_event", "mc_agent_set_status_by_api_key",
                    "mc_acquire_agent_lease", "mc_release_agent_lease",
                    "mc_update_agent", "mc_get_agents"}


def _get_api_key() -> Optional[str]:
    """Return the current agent's API key (set at boot via enable_recording)."""
    return _recording_api_key or os.environ.get("MESHCODE_API_KEY") or None


def enable_recording(api_key: str, project_id: str, agent_name: str, session_id: str):
    """Called by MCP server at boot to enable session recording."""
    global _recording_enabled, _recording_api_key, _recording_project_id
    global _recording_agent_name, _recording_session_id
    _recording_enabled = True
    _recording_api_key = api_key
    _recording_project_id = project_id
    _recording_agent_name = agent_name
    _recording_session_id = session_id


def sb_rpc(fn_name: str, params: Dict, *, _max_retries: int = 3) -> Any:
    import random as _random
    if not _circuit.can_execute():
        return _make_error("circuit breaker open — Supabase temporarily unavailable",
                           code="503", source="circuit_breaker")
    last_err = None
    rpc_path = f"/rest/v1/rpc/{fn_name}"
    body = json.dumps(params).encode("utf-8")
    hdrs = _headers(content_profile=False)
    for attempt in range(_max_retries):
        try:
            status, raw = _pool.request("POST", rpc_path, body, hdrs)
            if 200 <= status < 300:
                result = json.loads(raw) if raw.strip() else None
                _circuit.record_success()
                if _recording_enabled and fn_name not in _SKIP_RECORDING:
                    _bg_record("tool_call", {"rpc": fn_name})
                return result
            elif 400 <= status < 500:
                _circuit.record_success()
                try:
                    msg = json.loads(raw).get("message", raw[:200])
                except Exception:
                    msg = raw[:200]
                if _recording_enabled and fn_name not in _SKIP_RECORDING:
                    _bg_record("error", {"rpc": fn_name, "error": raw[:200]})
                return _make_error(msg, code=str(status), source="rpc")
            else:
                last_err = raw[:200]
        except (KeyboardInterrupt, SystemExit):
            # ESC / Ctrl-C / process exit — NOT a Supabase failure.
            # Must not count toward circuit breaker or the agent goes
            # permanently deaf after a few ESC presses.
            raise
        except (URLError, OSError, TimeoutError, http.client.HTTPException) as e:
            last_err = str(getattr(e, 'reason', e))
        # Retry with jitter for transient errors (5xx, network)
        if attempt < _max_retries - 1:
            delay = (2 ** attempt) + _random.uniform(0, 1)
            _time.sleep(delay)
    # All retries exhausted — record ONE failure for the entire call
    _circuit.record_failure()
    if _recording_enabled and fn_name not in _SKIP_RECORDING:
        _bg_record("error", {"rpc": fn_name, "error": str(last_err)[:200], "retries_exhausted": True})
    return _make_error(str(last_err)[:200] if last_err else "request failed after retries",
                       code="0", source="network")


def _bg_record(event_type: str, payload: dict):
    """Background-thread recording — never blocks the caller."""
    import threading
    def _do():
        try:
            sb_rpc_raw("mc_record_event", {
                "p_api_key": _recording_api_key,
                "p_project_id": _recording_project_id,
                "p_agent_name": _recording_agent_name,
                "p_session_id": _recording_session_id,
                "p_event_type": event_type,
                "p_payload": payload,
            })
        except Exception as e:
            log.debug(f"bg_record failed ({event_type}): {e}")
    threading.Thread(target=_do, daemon=True).start()


def sb_rpc_raw(fn_name: str, params: Dict) -> Any:
    """Raw RPC call without recording (to avoid infinite recursion)."""
    rpc_path = f"/rest/v1/rpc/{fn_name}"
    body = json.dumps(params).encode("utf-8")
    hdrs = _headers(content_profile=False)
    try:
        status, raw = _pool.request("POST", rpc_path, body, hdrs)
        if 200 <= status < 300:
            return json.loads(raw) if raw.strip() else None
        log.warning("sb_rpc_raw(%s) returned %d: %s", fn_name, status, raw[:200])
        return None
    except Exception as e:
        log.warning("sb_rpc_raw(%s) failed: %s", fn_name, e)
        return None


# ============================================================
# Project + agent helpers
# ============================================================

def get_project_id(project_name: str) -> Optional[str]:
    if not project_name:
        return None
    rows = sb_select("mc_projects", f"name=eq.{quote(project_name)}")
    if rows:
        return rows[0]["id"]
    result = sb_insert("mc_projects", {"name": project_name})
    if isinstance(result, list) and result:
        return result[0]["id"]
    return None


def register_agent(project: str, name: str, role: str = "", api_key: Optional[str] = None) -> Dict:
    project_id = get_project_id(project)
    if not project_id:
        # Fallback: many spawn paths (setup_clients.py) bake the project
        # uuid into the env so we can register even when the name lookup
        # fails (RLS, schema cache, network blip, anon-key visibility).
        env_pid = os.environ.get("MESHCODE_PROJECT_ID", "").strip()
        if env_pid:
            project_id = env_pid
    if not project_id:
        return {"error": f"Project '{project}' not found"}

    params = {
        "p_project_id": project_id,
        "p_name": name,
        "p_role": role,
        "p_status": "online",
    }
    if api_key:
        params["p_api_key"] = api_key
    result = sb_rpc("mc_register_agent", params)

    if not result or is_error(result):
        return {"error": get_error_message(result) or "Failed to register agent"}

    # Prefer SECURITY DEFINER RPC for mc_agents update
    _ak = api_key or _get_api_key()
    _agent_updated = False
    if _ak:
        _upd = sb_rpc("mc_update_agent", {
            "p_api_key": _ak,
            "p_project_id": project_id,
            "p_agent_name": name,
            "p_fields": {"task": role, "last_heartbeat": _now_iso()},
        })
        if isinstance(_upd, dict) and _upd.get("ok"):
            _agent_updated = True
    if not _agent_updated:
        # Fallback: direct PATCH (gradual rollout)
        sb_update("mc_agents",
                  f"project_id=eq.{project_id}&name=eq.{quote(name)}",
                  {"task": role, "last_heartbeat": _now_iso()})

    return {
        "registered": True,
        "project_id": project_id,
        "agent_name": name,
        "agent_id": result.get("agent_id") if isinstance(result, dict) else None,
    }


# TTL cache for resolve_agent_name — avoids N+1 queries on every send().
# Key: (project_id, name) → (resolved_name, expiry_ts).  Max 256 entries.
_AGENT_NAME_CACHE: Dict[tuple, tuple] = {}
_AGENT_NAME_CACHE_LOCK = _threading.Lock()
_AGENT_NAME_CACHE_TTL = 300  # 5 minutes
_AGENT_NAME_CACHE_MAX = 256


def _agent_name_cache_get(project_id: str, name: str) -> Optional[str]:
    key = (project_id, name)
    with _AGENT_NAME_CACHE_LOCK:
        entry = _AGENT_NAME_CACHE.get(key)
        if entry and entry[1] > _time.time():
            return entry[0]
        _AGENT_NAME_CACHE.pop(key, None)
    return None


def _agent_name_cache_set(project_id: str, name: str, resolved: str) -> None:
    key = (project_id, name)
    with _AGENT_NAME_CACHE_LOCK:
        if len(_AGENT_NAME_CACHE) >= _AGENT_NAME_CACHE_MAX:
            # Evict oldest entries
            now = _time.time()
            expired = [k for k, v in _AGENT_NAME_CACHE.items() if v[1] <= now]
            for k in expired:
                del _AGENT_NAME_CACHE[k]
            if len(_AGENT_NAME_CACHE) >= _AGENT_NAME_CACHE_MAX:
                # Still full — evict first quarter by insertion order
                to_evict = list(_AGENT_NAME_CACHE.keys())[:_AGENT_NAME_CACHE_MAX // 4]
                for k in to_evict:
                    del _AGENT_NAME_CACHE[k]
        _AGENT_NAME_CACHE[key] = (resolved, _time.time() + _AGENT_NAME_CACHE_TTL)


def resolve_agent_name(project_id: str, name: str) -> str:
    """Resolve a partial or exact agent name to the full registered name.

    Returns the exact match if found, or a unique prefix/substring match.
    Returns the original name unchanged if no match or ambiguous.
    Broadcast target '*' is passed through unchanged.
    Uses a TTL cache to avoid repeated DB lookups.
    """
    if not name or name == "*":
        return name
    cached = _agent_name_cache_get(project_id, name)
    if cached is not None:
        return cached
    # Exact match — fast path (prefer SECURITY DEFINER RPC)
    api_key = _get_api_key()
    exact = None
    if api_key:
        _res = sb_rpc("mc_get_agents", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": name,
            "p_select": None,
            "p_limit": 1,
        })
        if isinstance(_res, dict) and _res.get("ok"):
            exact = _res.get("agents", [])
    if exact is None:
        # Fallback: direct SELECT (gradual rollout)
        exact = sb_select("mc_agents",
                          f"project_id=eq.{project_id}&name=eq.{quote(name)}",
                          limit=1)
    if exact:
        _agent_name_cache_set(project_id, name, name)
        return name
    # Fuzzy: prefix or substring match among registered agents
    agents = None
    if api_key:
        _res2 = sb_rpc("mc_get_agents", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": None,
            "p_select": ["name"],
            "p_limit": None,
        })
        if isinstance(_res2, dict) and _res2.get("ok"):
            agents = _res2.get("agents", [])
    if agents is None:
        # Fallback: direct SELECT (gradual rollout)
        agents = sb_select("mc_agents", f"project_id=eq.{project_id}&select=name")
    if not agents:
        return name
    all_names = [a["name"] for a in agents]
    # Try prefix match first
    prefix_matches = [n for n in all_names if n.startswith(name)]
    if len(prefix_matches) == 1:
        _agent_name_cache_set(project_id, name, prefix_matches[0])
        return prefix_matches[0]
    # Try substring match
    sub_matches = [n for n in all_names if name in n]
    if len(sub_matches) == 1:
        _agent_name_cache_set(project_id, name, sub_matches[0])
        return sub_matches[0]
    # Ambiguous or no match — return original
    return name


def send_message(project_id: str, from_agent: str, to_agent: str, payload: Any, msg_type: str = "msg", parent_msg_id: Optional[str] = None, sensitive: bool = False, api_key: Optional[str] = None, encrypted: bool = False) -> Dict:
    import uuid as _uuid
    # Normalize partial agent names to full registered names
    to_agent = resolve_agent_name(project_id, to_agent)

    if not isinstance(payload, dict):
        payload = {"text": str(payload)}

    # Generate client-side idempotency key to prevent duplicate delivery
    # on retry. The RPC should use this to ON CONFLICT skip duplicate inserts.
    idempotency_key = str(_uuid.uuid4())

    # Encrypt payload if requested
    actual_encrypted = False
    if encrypted and api_key:
        mesh_key = get_mesh_key(api_key, project_id)
        if mesh_key:
            encrypted_data = encrypt_payload(payload, mesh_key, aad=project_id)
            payload = {"_encrypted": encrypted_data, "_aad": project_id}
            actual_encrypted = True

    # Use validated SECURITY DEFINER RPC when api_key is provided
    if api_key:
        params = {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_from_agent": from_agent,
            "p_to_agent": to_agent,
            "p_payload": payload,
            "p_type": msg_type,
            "p_idempotency_key": idempotency_key,
        }
        if parent_msg_id:
            params["p_parent_msg_id"] = parent_msg_id
        if sensitive or actual_encrypted:
            params["p_sensitive"] = True
        result = sb_rpc("mc_send_message", params)
        # If RPC succeeded, return
        if isinstance(result, dict) and result.get("ok"):
            out = {"sent": True, "msg_id": result.get("msg_id")}
            if actual_encrypted:
                out["encrypted"] = True
            return out
        # If RPC returned an error, propagate it — do NOT fall through to
        # direct insert (RLS blocks anon INSERT since migration 089).
        if is_error(result):
            return {"error": get_error_message(result)}
        # RPC may return {error,error_code} body without HTTP failure (validation
        # rejections like to_agent_not_found). Treat presence of 'error' or
        # ok=false as failure — never silently swallow as sent:true.
        if isinstance(result, dict) and (result.get("error") or result.get("ok") is False):
            return {
                "sent": False,
                "error": result.get("error", "send rejected by RPC"),
                "error_code": result.get("error_code"),
                "raw": result,
            }
        # RPC returned unexpected shape but didn't error — treat as success
        if result is not None:
            return {"sent": True}

    # Fallback: direct insert — ONLY for tests or legacy (no api_key)
    if api_key:
        # api_key was provided but RPC path didn't return — should not happen
        return {"error": "mc_send_message RPC unavailable and direct insert blocked by RLS"}
    msg = {
        "project_id": project_id,
        "from_agent": from_agent,
        "to_agent": to_agent,
        "type": msg_type,
        "payload": payload,
        "read": False,
    }
    if parent_msg_id:
        msg["parent_msg_id"] = parent_msg_id
    if sensitive:
        msg["is_sensitive"] = True
    result = sb_insert("mc_messages", msg)
    if is_error(result):
        return {"error": get_error_message(result)}
    if isinstance(result, list) and result:
        return {"sent": True, "msg_id": result[0].get("id")}
    return {"sent": True}


def read_inbox(project_id: str, agent: str, mark_read: bool = True, api_key: Optional[str] = None) -> List[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_read_inbox", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_mark_read": mark_read,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            messages = rpc_result.get("messages", [])
            if isinstance(messages, list):
                # Auto-decrypt and ACK (mark_read already handled by RPC)
                mesh_key = None
                for m in messages:
                    p = m.get("payload")
                    if isinstance(p, dict) and "_encrypted" in p:
                        if mesh_key is None:
                            mesh_key = get_mesh_key(api_key, project_id)
                        if mesh_key:
                            msg_aad = p.get("_aad", project_id)
                            decrypted = decrypt_payload(p["_encrypted"], mesh_key, aad=msg_aad)
                            if decrypted is not None:
                                m["payload"] = decrypted
                                m["_was_encrypted"] = True
                if mark_read and messages:
                    import datetime as _dt
                    now = _dt.datetime.now(_dt.timezone.utc)
                    def _is_stale_rpc(m):
                        ts = m.get("created_at")
                        if not ts:
                            return True
                        try:
                            dt = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                            return (now - dt).total_seconds() > 60
                        except Exception:
                            return True
                    ack_targets = {
                        m.get("from_agent", "")
                        for m in messages
                        if m.get("type") not in ("ack", "broadcast") and _is_stale_rpc(m)
                    }
                    for sender in ack_targets:
                        if sender:
                            send_message(project_id, agent, sender,
                                         {"text": f"{agent} read your message"},
                                         msg_type="ack", api_key=api_key)
                return messages
        # If RPC doesn't exist yet, fall through to direct query

    # Fallback: direct SELECT (tests/legacy — requires anon RLS bypass)
    # Include broadcasts (to_agent='*') — matches RPC behavior.
    messages = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=in.({quote(agent)},*)&read=eq.false",
        order="created_at.asc",
    )
    # Auto-decrypt encrypted messages
    if api_key and messages:
        mesh_key = None  # lazy-load
        for m in messages:
            p = m.get("payload")
            if isinstance(p, dict) and "_encrypted" in p:
                if mesh_key is None:
                    mesh_key = get_mesh_key(api_key, project_id)
                if mesh_key:
                    msg_aad = p.get("_aad", project_id)
                    decrypted = decrypt_payload(p["_encrypted"], mesh_key, aad=msg_aad)
                    if decrypted is not None:
                        m["payload"] = decrypted
                        m["_was_encrypted"] = True
    if mark_read and messages:
        for m in messages:
            marked = False
            if api_key:
                result = sb_rpc("mc_mark_message_read", {
                    "p_api_key": api_key,
                    "p_project_id": project_id,
                    "p_message_id": m["id"],
                })
                # If RPC succeeded, skip direct update
                if isinstance(result, dict) and result.get("ok"):
                    marked = True
            if not marked and not api_key:
                # Only attempt direct update when no api_key (tests/legacy).
                # With api_key, RLS blocks anon UPDATE since migration 089.
                sb_update("mc_messages", f"id=eq.{m['id']}", {"read": True})

        # Auto-ACK senders — but ONLY for messages older than 60s. If the
        # message was sent recently, the sender is very likely still inside
        # a meshcode_wait call that already returned the message via the
        # realtime path; an extra "you got it" ack row is pure noise that
        # spams the dashboard and the sender's inbox.
        import datetime as _dt
        now = _dt.datetime.now(_dt.timezone.utc)
        def _is_stale(m):
            ts = m.get("created_at")
            if not ts:
                return True
            try:
                dt = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                return (now - dt).total_seconds() > 60
            except Exception:
                return True
        ack_targets = {
            m["from_agent"]
            for m in messages
            if m.get("type") not in ("ack", "broadcast") and _is_stale(m)
        }
        for sender in ack_targets:
            send_message(project_id, agent, sender,
                         {"text": f"{agent} read your message"},
                         msg_type="ack", api_key=api_key)
    return messages


def count_pending(project_id: str, agent: str, api_key: Optional[str] = None) -> int:
    # Use SECURITY DEFINER RPC when api_key is available
    if api_key:
        result = sb_rpc("mc_count_pending", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
        })
        if isinstance(result, dict) and result.get("ok"):
            return result.get("count", 0)
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    # Include broadcasts (to_agent='*') — matches mc_read_inbox behavior.
    pending = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=in.({quote(agent)},*)&read=eq.false&type=neq.ack",
        limit=1000,
    )
    return len(pending)


# ============================================================
# Encryption helpers for sensitive mesh messages
# ============================================================

# TTL + max-size cache for mesh encryption keys. Previous version was unbounded.
_mesh_key_cache: Dict[str, tuple] = {}  # project_id -> (hex_key, expiry_ts)
_MESH_KEY_CACHE_TTL = 600  # 10 minutes
_MESH_KEY_CACHE_MAX = 64


def get_mesh_key(api_key: str, project_id: str) -> Optional[str]:
    """Retrieve the per-meshwork encryption key (hex-encoded AES-256 key)."""
    entry = _mesh_key_cache.get(project_id)
    if entry and entry[1] > _time.time():
        return entry[0]
    _mesh_key_cache.pop(project_id, None)
    result = sb_rpc("mc_get_mesh_key", {
        "p_api_key": api_key,
        "p_project_id": project_id,
    })
    if isinstance(result, dict) and result.get("ok"):
        key = result["key"]
        if len(_mesh_key_cache) >= _MESH_KEY_CACHE_MAX:
            # Evict expired, then oldest if still full
            now = _time.time()
            expired = [k for k, v in _mesh_key_cache.items() if v[1] <= now]
            for k in expired:
                del _mesh_key_cache[k]
            if len(_mesh_key_cache) >= _MESH_KEY_CACHE_MAX:
                oldest = min(_mesh_key_cache, key=lambda k: _mesh_key_cache[k][1])
                del _mesh_key_cache[oldest]
        _mesh_key_cache[project_id] = (key, _time.time() + _MESH_KEY_CACHE_TTL)
        return key
    return None


def encrypt_payload(payload: Dict, hex_key: str, aad: Optional[str] = None) -> str:
    """Encrypt a JSON payload using AES-256-GCM with optional AAD.

    Args:
        payload: JSON-serializable dict to encrypt.
        hex_key: Hex-encoded AES-256 key.
        aad: Additional Authenticated Data (e.g. project_id) to bind
             ciphertext to context and prevent replay/swap attacks.
    """
    import base64
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise RuntimeError("cryptography package required for encrypted messages: pip install cryptography")
    key = bytes.fromhex(hex_key)
    nonce = os.urandom(12)  # 96-bit nonce for GCM
    plaintext = json.dumps(payload).encode("utf-8")
    aad_bytes = aad.encode("utf-8") if aad else None
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, aad_bytes)
    # Format: base64(nonce + ciphertext)
    return base64.b64encode(nonce + ciphertext).decode("ascii")


def decrypt_payload(encrypted_b64: str, hex_key: str, aad: Optional[str] = None) -> Optional[Dict]:
    """Decrypt an AES-256-GCM encrypted payload. Returns None on failure.

    If AAD is provided, it is MANDATORY — the message MUST have been
    encrypted with the same AAD. No fallback to no-AAD when AAD is
    present (this prevents swap/replay attacks). Messages without AAD
    (legacy, pre-AAD era) are still decrypted with aad=None.
    """
    import base64
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        log.warning("decrypt_payload: cryptography package not installed")
        return None
    try:
        key = bytes.fromhex(hex_key)
        raw = base64.b64decode(encrypted_b64)
        nonce = raw[:12]
        ciphertext = raw[12:]
        aesgcm = AESGCM(key)
        aad_bytes = aad.encode("utf-8") if aad else None
        # AAD is mandatory when provided — no fallback to prevent replay attacks.
        # Legacy messages (aad=None) are decrypted without AAD.
        plaintext = aesgcm.decrypt(nonce, ciphertext, aad_bytes)
        return json.loads(plaintext.decode("utf-8"))
    except Exception as e:
        log.warning("decrypt_payload failed (aad=%s): %s", aad[:20] if aad else "none", e)
        return None


def get_board(project_id: str, api_key: Optional[str] = None) -> List[Dict]:
    # Prefer SECURITY DEFINER RPC
    _ak = api_key or _get_api_key()
    if _ak:
        _res = sb_rpc("mc_get_agents", {
            "p_api_key": _ak,
            "p_project_id": project_id,
            "p_agent_name": None,
            "p_select": ["name", "role", "status", "task", "last_heartbeat", "registered_at"],
            "p_limit": None,
        })
        if isinstance(_res, dict) and _res.get("ok"):
            return _res.get("agents", [])
    # Fallback: direct SELECT (gradual rollout)
    return sb_select(
        "mc_agents",
        f"project_id=eq.{project_id}&select=name,role,status,task,last_heartbeat,registered_at",
        order="registered_at.asc",
    )


def heartbeat(project_id: str, agent: str) -> Dict:
    result = sb_rpc("mc_heartbeat", {"p_project_id": project_id, "p_agent_name": agent})
    return result or {}


def set_status(project_id: str, agent: str, status: str, task: str = "", api_key: Optional[str] = None, editor: Optional[str] = None) -> Dict:
    # Use SECURITY DEFINER RPC when api_key is available (anon PATCH silently fails)
    if api_key:
        params = {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_status": status,
            "p_task": task,
        }
        if editor:
            params["p_editor"] = editor
        rpc_result = sb_rpc("mc_agent_set_status_by_api_key", params)
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return {"ok": True, "status": status}
        # Fall through to direct PATCH if RPC doesn't exist yet

    # Fallback: try mc_update_agent RPC, then direct PATCH
    _ak = api_key or _get_api_key()
    fields: Dict[str, Any] = {"status": status, "last_heartbeat": _now_iso()}
    if task:
        fields["task"] = task
    if editor:
        fields["editor"] = editor
    if _ak:
        _upd = sb_rpc("mc_update_agent", {
            "p_api_key": _ak,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_fields": fields,
        })
        if isinstance(_upd, dict) and _upd.get("ok"):
            return {"ok": True, "status": status}
    # Final fallback: direct PATCH (may silently fail with anon key if RLS blocks)
    result = sb_update("mc_agents", f"project_id=eq.{project_id}&name=eq.{quote(agent)}", fields)
    if is_error(result):
        return {"error": get_error_message(result)}
    return {"ok": True, "status": status}


def task_create(api_key, project_id, creator_agent, title, description="", assignee="*", priority="normal", parent_task_id=None):
    return sb_rpc("mc_task_create", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_creator_agent": creator_agent,
        "p_title": title,
        "p_description": description,
        "p_assignee": assignee,
        "p_priority": priority,
        "p_parent_task_id": parent_task_id,
    })


# Client-side debounce for task_list to neutralize runaway pollers without a
# server round-trip. Pairs with the planned DB-side rate limit
# (migration_task_list_rate_limit_DRAFT.sql). Two windows:
#   * MIN_INTERVAL: hard floor between identical calls. Within this window we
#     return the prior result without hitting the network.
#   * SOFT_TTL: returned-payload reuse window. After MIN_INTERVAL elapses, we
#     refresh from the network and overwrite the cache.
# Cache key includes status_filter + include_done so different views don't
# poison each other.
_TASK_LIST_CACHE: Dict[tuple, tuple] = {}
_TASK_LIST_CACHE_LOCK = _threading.Lock()
_TASK_LIST_MIN_INTERVAL = 0.5  # seconds; >= 2/sec is throttled
_TASK_LIST_CACHE_MAX = 64


def task_list(api_key, project_id, agent, status_filter=None, include_done=False):
    cache_key = (project_id, agent, status_filter, bool(include_done))
    now = _time.time()
    with _TASK_LIST_CACHE_LOCK:
        cached = _TASK_LIST_CACHE.get(cache_key)
        if cached and (now - cached[1]) < _TASK_LIST_MIN_INTERVAL:
            return cached[0]
    result = sb_rpc("mc_task_list", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_agent": agent,
        "p_status_filter": status_filter,
        "p_include_done": include_done,
    })
    with _TASK_LIST_CACHE_LOCK:
        if len(_TASK_LIST_CACHE) >= _TASK_LIST_CACHE_MAX:
            oldest_key = min(_TASK_LIST_CACHE, key=lambda k: _TASK_LIST_CACHE[k][1])
            _TASK_LIST_CACHE.pop(oldest_key, None)
        _TASK_LIST_CACHE[cache_key] = (result, now)
    return result


def task_claim(api_key, project_id, task_id, claiming_agent):
    return sb_rpc("mc_task_claim", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_claiming_agent": claiming_agent,
    })


def task_complete(api_key, project_id, task_id, completing_agent, summary=""):
    return sb_rpc("mc_task_complete", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_completing_agent": completing_agent,
        "p_summary": summary,
    })


def record_event(api_key, project_id, agent_name, session_id, event_type, payload=None):
    """Fire-and-forget event recording for session replay."""
    return sb_rpc("mc_record_event", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_agent_name": agent_name,
        "p_session_id": session_id,
        "p_event_type": event_type,
        "p_payload": payload or {},
    })


def get_history(project_id: str, limit: int = 20, agent_filter: str = "", api_key: Optional[str] = None) -> List[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_get_history", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_limit": limit,
            "p_agent_filter": agent_filter or None,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return rpc_result.get("messages", [])
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    filters = f"project_id=eq.{project_id}&type=neq.ack"
    if agent_filter:
        filters += f"&or=(from_agent.eq.{quote(agent_filter)},to_agent.eq.{quote(agent_filter)})"
    return sb_select(
        "mc_messages",
        filters,
        order="created_at.desc",
        limit=limit,
    )


def get_message_by_id(project_id: str, msg_id: str, api_key: Optional[str] = None) -> Optional[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_get_message_by_id", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_msg_id": msg_id,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return rpc_result.get("message")
        if is_error(rpc_result):
            return None
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    results = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&id=eq.{msg_id}",
        limit=1,
    )
    return results[0] if results else None


# ============================================================
# Convenience class so `from meshcode.meshcode_mcp.backend import MeshCodeBackend`
# works for users who expect a class-based API (e.g. Windows onboarding docs).
# ============================================================

class MeshCodeBackend:
    """Namespace wrapper around the backend module functions.

    All methods are static — no instance state. This exists purely so that
    ``from meshcode.meshcode_mcp.backend import MeshCodeBackend`` resolves.
    """
    get_project_id = staticmethod(get_project_id)
    resolve_agent_name = staticmethod(resolve_agent_name)
    register_agent = staticmethod(register_agent)
    send_message = staticmethod(send_message)
    read_inbox = staticmethod(read_inbox)
    count_pending = staticmethod(count_pending)
    get_board = staticmethod(get_board)
    heartbeat = staticmethod(heartbeat)
    set_status = staticmethod(set_status)
    task_create = staticmethod(task_create)
    task_list = staticmethod(task_list)
    task_claim = staticmethod(task_claim)
    task_complete = staticmethod(task_complete)
    get_history = staticmethod(get_history)
    get_message_by_id = staticmethod(get_message_by_id)
    sb_rpc = staticmethod(sb_rpc)
    sb_select = staticmethod(sb_select)
    sb_insert = staticmethod(sb_insert)
    sb_update = staticmethod(sb_update)
