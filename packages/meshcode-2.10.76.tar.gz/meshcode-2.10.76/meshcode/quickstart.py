"""MeshCode Quickstart Wizard — one command to go from zero to running agent.

Usage: meshcode quickstart

Flow:
1. Ask for API key (or detect from config)
2. Ask for project name (or create new)
3. Ask for agent name + role
4. Auto-run: register → setup → run
"""
import sys
import os
import json
from pathlib import Path


def _input_with_default(prompt: str, default: str = "") -> str:
    """Input with default value shown in brackets."""
    if default:
        raw = input(f"{prompt} [{default}]: ").strip()
        return raw if raw else default
    return input(f"{prompt}: ").strip()


def cmd_quickstart() -> int:
    """Interactive quickstart wizard."""
    print()
    print("  ╔══════════════════════════════════════╗")
    print("  ║     MeshCode Quickstart Wizard       ║")
    print("  ║  From zero to running agent in 60s   ║")
    print("  ╚══════════════════════════════════════╝")
    print()

    # Step 1: API key
    config_dir = Path.home() / ".meshcode"
    existing_key = None
    try:
        profile = config_dir / "profile_meta.json"
        if profile.exists():
            meta = json.loads(profile.read_text())
            existing_key = meta.get("api_key")
            email = meta.get("email", "unknown")
            print(f"  [+] Already logged in as {email}")
    except Exception:
        pass

    if not existing_key:
        print("  Step 1: Enter your API key")
        print("  (Get one at meshcode.io/dashboard → Settings → API Keys)")
        print()
        api_key = input("  API key: ").strip()
        if not api_key:
            print("  [!] API key required. Get one at meshcode.io/dashboard")
            return 1
        # Login
        try:
            from meshcode.meshcode_mcp import backend as be
            # Validate key
            result = be.sb_rpc("mc_validate_api_key", {"p_api_key": api_key})
            if isinstance(result, dict) and result.get("error"):
                print(f"  [x] Invalid API key: {result.get('error')}")
                return 1
            print("  [+] API key valid!")
            # Save
            config_dir.mkdir(parents=True, exist_ok=True)
            (config_dir / "profile_meta.json").write_text(json.dumps({
                "api_key": api_key,
                "email": result.get("email", "unknown"),
            }))
        except Exception as e:
            print(f"  [x] Could not validate: {e}")
            print("  Continuing anyway — key will be verified on run.")
            config_dir.mkdir(parents=True, exist_ok=True)
            (config_dir / "profile_meta.json").write_text(json.dumps({"api_key": api_key}))
    else:
        api_key = existing_key

    print()

    # Step 2: Project
    print("  Step 2: Choose your meshwork (project)")
    try:
        from meshcode.meshcode_mcp import backend as be
        projects = be.sb_rpc("mc_list_user_projects", {"p_api_key": api_key})
        if isinstance(projects, dict) and projects.get("projects"):
            proj_list = projects["projects"]
            print(f"  Your meshworks: {', '.join(p['name'] for p in proj_list[:5])}")
            project = _input_with_default("  Meshwork name", proj_list[0]["name"])
        else:
            project = _input_with_default("  New meshwork name", "my-team")
    except Exception:
        project = _input_with_default("  Meshwork name", "my-team")

    print()

    # Step 3: Agent
    print("  Step 3: Create your agent")
    agent_name = _input_with_default("  Agent name", "assistant")
    role = _input_with_default("  Agent role", "General-purpose AI assistant")

    print()
    print(f"  Creating {agent_name} in {project}...")
    print()

    # Step 4: Setup + Run
    try:
        # Register agent
        from meshcode.meshcode_mcp import backend as be
        result = be.register_agent(project, agent_name, role, api_key=api_key)
        if isinstance(result, dict) and result.get("error"):
            if "already registered" in str(result.get("error", "")).lower():
                print(f"  [+] Agent {agent_name} already exists — reusing")
            else:
                print(f"  [!] Registration: {result.get('error')}")
        else:
            print(f"  [+] Agent {agent_name} registered!")
    except Exception as e:
        print(f"  [!] Registration note: {e}")

    # Run setup
    print(f"  [+] Setting up MCP connection...")
    try:
        import subprocess
        subprocess.run(
            [sys.executable, "-m", "meshcode", "setup", "claude", project, agent_name, role],
            check=False
        )
    except Exception as e:
        print(f"  [!] Setup: {e}")

    print()
    print("  ╔══════════════════════════════════════╗")
    print(f"  ║  Agent '{agent_name}' is ready!       ")
    print("  ╚══════════════════════════════════════╝")
    print()
    print("  Next steps:")
    print(f"  1. Open Claude Code and start chatting")
    print(f"  2. Your agent will auto-connect via MCP")
    print(f"  3. Or run manually: meshcode run {project} {agent_name}")
    print()

    # Ask if they want to run now
    run_now = input("  Start agent now? [Y/n]: ").strip().lower()
    if run_now in ("", "y", "yes"):
        print(f"\n  Starting {agent_name}...")
        os.execvp(sys.executable, [sys.executable, "-m", "meshcode", "run", project, agent_name])

    return 0
