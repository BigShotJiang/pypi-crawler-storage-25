"""
OpenAI Image Provider

Modelle:
- gpt-image-1       primär, höchste Qualität, ~$0.04-0.12/Bild (token-basiert)
- gpt-image-1-mini  Budget / Massen-Generierung, ~$0.02-0.05/Bild
- dall-e-3          Legacy, URL-Response, revised_prompt
- dall-e-2          Legacy, URL-Response
"""

import base64
import time
from typing import Any

import httpx

from .base import BaseProvider
from ..schemas import IllustrationRequest, IllustrationResult

GPT_IMAGE_MODELS = {"gpt-image-1", "gpt-image-1-mini"}


class DalleProvider(BaseProvider):
    """
    OpenAI Image Generation Provider.

    Einsatzfelder je Modell:
    - gpt-image-1       Buchcover, finale Illustrationen, Produktbilder
    - gpt-image-1-mini  Thumbnails, Konzeptskizzen, Mockups, Massen-Generierung
    - dall-e-3          Legacy (revised_prompt erhalten)
    - dall-e-2          Legacy-Fallback

    api_key: OPENAI_API_KEY
    """

    API_URL = "https://api.openai.com/v1/images/generations"

    def __init__(
        self,
        api_key: str = "",
        model: str = "gpt-image-1",
        quality: str = "auto",           # auto | high | medium | low  (GPT-Image)
                                          # hd | standard               (dall-e-3)
        background: str = "opaque",      # opaque | transparent  (GPT-Image only)
        output_format: str = "png",      # png | jpeg | webp     (GPT-Image only)
        timeout: int = 60,
    ):
        self.api_key = api_key
        self.model = model
        self.quality = quality
        self.background = background
        self.output_format = output_format
        self.timeout = timeout

    @property
    def is_gpt_image(self) -> bool:
        return self.model in GPT_IMAGE_MODELS

    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        if not self.api_key:
            return IllustrationResult.error_result("OPENAI_API_KEY not set", "openai")

        size = self._map_size(request.style_spec.aspect_ratio)
        quality = self._resolve_quality()

        payload: dict = {
            "model": self.model,
            "prompt": request.prompt,
            "n": 1,
            "size": size,
        }

        if self.is_gpt_image:
            payload["quality"] = quality
            payload["background"] = self.background
            payload["output_format"] = self.output_format
        else:
            payload["quality"] = quality
            payload["response_format"] = "url"

        t0 = time.monotonic()
        try:
            response = httpx.post(
                self.API_URL,
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self.timeout,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return IllustrationResult.error_result(
                f"{exc.response.status_code}: {exc.response.text[:200]}", "openai"
            )
        except Exception as exc:
            return IllustrationResult.error_result(str(exc), "openai")

        latency = int((time.monotonic() - t0) * 1000)
        data = response.json()
        item = (data.get("data") or [{}])[0]

        if self.is_gpt_image:
            b64 = item.get("b64_json", "")
            image_bytes = base64.b64decode(b64) if b64 else b""
            usage = data.get("usage", {})
            return IllustrationResult(
                success=True,
                image_url="",
                images=[],
                image_data_b64=b64,
                prompt_used=request.prompt,
                provider="openai",
                model=self.model,
                latency_ms=latency,
                usage_tokens=usage.get("output_tokens", 0),
                metadata={
                    "background": self.background,
                    "output_format": self.output_format,
                    "quality": quality,
                    "image_bytes": len(image_bytes),
                    "usage": usage,
                },
            )
        else:
            images = [i.get("url", "") for i in data.get("data", [])]
            revised_prompt = item.get("revised_prompt", request.prompt)
            return IllustrationResult(
                success=True,
                images=images,
                image_url=images[0] if images else "",
                prompt_used=revised_prompt,
                provider="openai",
                model=self.model,
                latency_ms=latency,
            )

    async def agenerate(self, request: IllustrationRequest) -> IllustrationResult:
        """Async generate using httpx.AsyncClient."""
        if not self.api_key:
            return IllustrationResult.error_result("OPENAI_API_KEY not set", "openai")

        size = self._map_size(request.style_spec.aspect_ratio)
        quality = self._resolve_quality()

        payload: dict[str, Any] = {
            "model": self.model,
            "prompt": request.prompt,
            "n": 1,
            "size": size,
        }

        if self.is_gpt_image:
            payload["quality"] = quality
            payload["background"] = self.background
            payload["output_format"] = self.output_format
        else:
            payload["quality"] = quality
            payload["response_format"] = "url"

        t0 = time.monotonic()
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.API_URL,
                    json=payload,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=self.timeout,
                )
                response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return IllustrationResult.error_result(
                f"{exc.response.status_code}: {exc.response.text[:200]}", "openai"
            )
        except Exception as exc:
            return IllustrationResult.error_result(str(exc), "openai")

        latency = int((time.monotonic() - t0) * 1000)
        data = response.json()
        item = (data.get("data") or [{}])[0]

        if self.is_gpt_image:
            b64 = item.get("b64_json", "")
            image_bytes = base64.b64decode(b64) if b64 else b""
            usage = data.get("usage", {})
            return IllustrationResult(
                success=True,
                image_url="",
                images=[],
                image_data_b64=b64,
                prompt_used=request.prompt,
                provider="openai",
                model=self.model,
                latency_ms=latency,
                usage_tokens=usage.get("output_tokens", 0),
                metadata={
                    "background": self.background,
                    "output_format": self.output_format,
                    "quality": quality,
                    "image_bytes": len(image_bytes),
                    "usage": usage,
                },
            )
        else:
            images = [i.get("url", "") for i in data.get("data", [])]
            revised_prompt = item.get("revised_prompt", request.prompt)
            return IllustrationResult(
                success=True,
                images=images,
                image_url=images[0] if images else "",
                prompt_used=revised_prompt,
                provider="openai",
                model=self.model,
                latency_ms=latency,
            )

    def _resolve_quality(self) -> str:
        """Setzt sinnvolle Quality-Defaults je Modell, wenn 'auto' gesetzt."""
        if self.quality != "auto":
            return self.quality
        if self.model == "gpt-image-1":
            return "high"
        if self.model == "gpt-image-1-mini":
            return "medium"
        return "standard"  # dall-e-3 / dall-e-2

    def _map_size(self, aspect_ratio: str) -> str:
        if self.is_gpt_image:
            mapping = {
                "1:1": "1024x1024",
                "16:9": "1536x1024",
                "9:16": "1024x1536",
                "4:3": "1536x1024",
                "3:4": "1024x1536",
            }
        else:
            mapping = {
                "1:1": "1024x1024",
                "16:9": "1792x1024",
                "9:16": "1024x1792",
                "4:3": "1024x1024",
                "3:4": "1024x1024",
            }
        return mapping.get(aspect_ratio, "1024x1024")
