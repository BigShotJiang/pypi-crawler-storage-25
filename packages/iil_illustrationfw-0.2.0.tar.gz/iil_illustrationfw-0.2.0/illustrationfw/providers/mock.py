"""
Mock Provider -- fuer Tests
"""

import time

from .base import BaseProvider
from ..schemas import IllustrationRequest, IllustrationResult


class MockProvider(BaseProvider):
    """Mock Provider -- gibt statische Test-URLs zurueck."""

    MOCK_URL = "https://picsum.photos/1024/1024"

    def __init__(self, latency_ms: int = 10):
        self.latency_ms = latency_ms

    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        time.sleep(self.latency_ms / 1000)
        images = [f"{self.MOCK_URL}?random={i}" for i in range(request.num_images)]
        return IllustrationResult(
            success=True,
            images=images,
            image_url=images[0],
            prompt_used=request.prompt,
            provider="mock",
            model="mock-v1",
            latency_ms=self.latency_ms,
        )
