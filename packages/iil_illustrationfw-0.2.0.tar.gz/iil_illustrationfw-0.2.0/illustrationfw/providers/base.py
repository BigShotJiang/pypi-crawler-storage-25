"""
Abstract Provider Interface
"""

from abc import ABC, abstractmethod

from ..schemas import IllustrationRequest, IllustrationResult


class BaseProvider(ABC):
    """Abstract base fuer alle Illustration-Provider."""

    @abstractmethod
    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        ...

    async def agenerate(self, request: IllustrationRequest) -> IllustrationResult:
        """Async generate -- default: delegates to sync generate()."""
        return self.generate(request)

    def generate_cover(self, request: IllustrationRequest) -> IllustrationResult:
        """Default: Cover nutzt generate() mit aspect_ratio 3:4."""
        cover_request = request.model_copy(
            update={"style_spec": request.style_spec.model_copy(
                update={"aspect_ratio": "3:4"}
            )}
        )
        return self.generate(cover_request)
