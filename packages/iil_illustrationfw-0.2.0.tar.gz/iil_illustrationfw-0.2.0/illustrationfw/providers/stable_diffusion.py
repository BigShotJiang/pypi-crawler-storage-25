"""
Stable Diffusion Provider (stability.ai API oder lokale Instanz)
"""

import time

import httpx

from .base import BaseProvider
from ..schemas import IllustrationRequest, IllustrationResult


class StableDiffusionProvider(BaseProvider):
    """
    Stable Diffusion Provider.
    Unterstuetzt stability.ai v2beta oder lokale ComfyUI-Instanz.
    """

    DEFAULT_URL = "https://api.stability.ai/v2beta/stable-image/generate/core"

    def __init__(self, api_key: str = "", api_url: str = "", timeout: int = 120):
        self.api_key = api_key
        self.api_url = api_url or self.DEFAULT_URL
        self.timeout = timeout

    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        if not self.api_key:
            return IllustrationResult.error_result("STABILITY_API_KEY not set", "stable_diffusion")

        payload = {
            "prompt": request.prompt,
            "negative_prompt": request.negative_prompt,
            "aspect_ratio": request.style_spec.aspect_ratio,
            "output_format": "webp",
        }

        t0 = time.monotonic()
        try:
            response = httpx.post(
                self.api_url,
                data=payload,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Accept": "application/json",
                },
                timeout=self.timeout,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return IllustrationResult.error_result(str(exc), "stable_diffusion")
        except Exception as exc:
            return IllustrationResult.error_result(str(exc), "stable_diffusion")

        latency = int((time.monotonic() - t0) * 1000)
        data = response.json()
        image_b64 = data.get("image", "")
        image_url = f"data:image/webp;base64,{image_b64}" if image_b64 else ""

        return IllustrationResult(
            success=True,
            images=[image_url] if image_url else [],
            image_url=image_url,
            prompt_used=request.prompt,
            provider="stable_diffusion",
            model="sd-core",
            latency_ms=latency,
        )
