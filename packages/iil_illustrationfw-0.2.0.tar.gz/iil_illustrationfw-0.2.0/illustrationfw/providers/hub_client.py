"""
HubClientProvider -- Verbindet sich mit illustration-hub REST API.

Ermoeg licht bfagent/writing-hub Jobs an illustration-hub zu delegieren:
illustration-hub uebernimmt Asset-Storage, Provider-Routing, Tenant-Isolation.
"""

import time

import httpx

from .base import BaseProvider
from ..schemas import IllustrationRequest, IllustrationResult


class HubClientProvider(BaseProvider):
    """
    Remote Provider: delegiert an illustration-hub REST API.

    hub_url: z.B. 'https://illustration.iil.pet'
    api_key: Token Auth
    project_id: Optionales illustration-hub Projekt fuer Asset-Zuordnung
    """

    def __init__(
        self,
        hub_url: str,
        api_key: str = "",
        project_id: str = "",
        timeout: int = 120,
    ):
        self.hub_url = hub_url.rstrip("/")
        self.api_key = api_key
        self.project_id = project_id
        self.timeout = timeout

    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        payload: dict = {
            "prompt": request.prompt,
            "negative_prompt": request.negative_prompt,
            "aspect_ratio": request.style_spec.aspect_ratio,
            "style": request.style_spec.style,
            "quality": request.quality,
            "source_ref": request.source_ref,
        }
        if self.project_id:
            payload["project_id"] = self.project_id

        url = f"{self.hub_url}/api/v1/jobs/"
        t0 = time.monotonic()

        try:
            response = httpx.post(
                url,
                json=payload,
                headers=self._headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return IllustrationResult.error_result(str(exc), "hub")
        except Exception as exc:
            return IllustrationResult.error_result(str(exc), "hub")

        latency = int((time.monotonic() - t0) * 1000)
        data = response.json()
        images = data.get("images", [])

        return IllustrationResult(
            success=True,
            images=images,
            image_url=images[0] if images else "",
            prompt_used=data.get("prompt_used", request.prompt),
            provider="hub",
            model=data.get("model", ""),
            latency_ms=latency,
            asset_id=data.get("asset_id", ""),
            metadata=data,
        )

    def _headers(self) -> dict:
        h: dict = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Token {self.api_key}"
        return h
