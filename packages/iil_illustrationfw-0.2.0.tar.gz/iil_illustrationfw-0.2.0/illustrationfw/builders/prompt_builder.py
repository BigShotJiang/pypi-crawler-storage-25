"""
PromptBuilder -- Baut Illustration-Prompts aus Buchkontext.
Keine Django-Abhaengigkeiten -- pure Python.
"""

from ..schemas import IllustrationRequest, StyleSpec


class PromptBuilder:
    """Baut IllustrationRequest aus Buchkontext."""

    @classmethod
    def from_chapter_context(
        cls,
        chapter_title: str = "",
        setting: str = "",
        characters: list | None = None,
        mood: str = "",
        style_dna: dict | None = None,
        aspect_ratio: str = "16:9",
        quality: str = "hd",
    ) -> IllustrationRequest:
        """
        Erstellt IllustrationRequest aus Kapitel-Kontext.
        """
        parts = []

        if setting:
            parts.append(setting)
        if characters:
            char_str = ", ".join(str(c) for c in characters[:3])
            parts.append(f"featuring {char_str}")
        if mood:
            parts.append(f"{mood} atmosphere")
        if chapter_title:
            parts.append(f"scene from '{chapter_title}'")

        style = "digital painting, book illustration"
        lighting = ""
        if style_dna:
            moves = style_dna.get("signature_moves", [])
            if moves:
                parts.extend(moves[:3])
            style = style_dna.get("art_style", style)
            lighting = style_dna.get("lighting", "")

        prompt = ", ".join(filter(None, parts)) or "book illustration, high quality"

        return IllustrationRequest(
            prompt=prompt,
            style_spec=StyleSpec(
                style=style,
                aspect_ratio=aspect_ratio,  # type: ignore[arg-type]
                lighting=lighting,
            ),
            quality=quality,  # type: ignore[arg-type]
        )

    @classmethod
    def from_scene_description(
        cls,
        scene: str,
        style: str = "digital painting, book illustration",
        aspect_ratio: str = "16:9",
        quality: str = "high",
        negative_prompt: str = "",
    ) -> IllustrationRequest:
        """
        Einfacher Builder: Szene direkt als Prompt.
        Fuer Faelle wo kein voller Buchkontext noetig ist.
        """
        return IllustrationRequest(
            prompt=scene,
            negative_prompt=negative_prompt,
            style_spec=StyleSpec(
                style=style,
                aspect_ratio=aspect_ratio,  # type: ignore[arg-type]
            ),
            quality=quality,
        )

    @classmethod
    def from_cover_context(
        cls,
        book_title: str,
        genre: str = "",
        premise: str = "",
        protagonist: str = "",
        style_dna: dict | None = None,
    ) -> IllustrationRequest:
        """Erstellt Cover-spezifischen IllustrationRequest (aspect_ratio 3:4)."""
        parts = []

        if premise:
            parts.append(premise[:200])
        if protagonist:
            parts.append(f"featuring {protagonist}")
        if genre:
            parts.append(f"{genre} genre")
        parts.append(f"book cover for '{book_title}'")
        parts.append("professional book cover design, dramatic lighting")

        if style_dna:
            moves = style_dna.get("signature_moves", [])
            parts.extend(moves[:2])

        return IllustrationRequest(
            prompt=", ".join(filter(None, parts)),
            style_spec=StyleSpec(
                style="book cover illustration",
                aspect_ratio="3:4",
            ),
            quality="hd",  # type: ignore[arg-type]
        )
