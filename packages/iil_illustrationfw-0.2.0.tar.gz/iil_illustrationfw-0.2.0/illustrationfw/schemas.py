"""
Pydantic Schemas -- illustrationfw
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class StyleSpec(BaseModel):
    """Stil-Parameter fuer Bild-Generierung."""

    style: str = "digital painting"
    aspect_ratio: Literal["1:1", "4:3", "16:9", "9:16", "3:4"] = "1:1"
    color_mood: str = ""
    composition: str = ""
    lighting: str = ""
    extra_params: dict = Field(default_factory=dict)


class IllustrationRequest(BaseModel):
    """Input-Schema fuer IllustrationAgent.generate()."""

    prompt: str = Field(..., min_length=1, max_length=4000)
    negative_prompt: str = ""
    style_spec: StyleSpec = Field(default_factory=StyleSpec)
    width: int = Field(default=1024, ge=256, le=2048)
    height: int = Field(default=1024, ge=256, le=2048)
    num_images: int = Field(default=1, ge=1, le=4)
    quality: str = Field(
        default="high",
        description="gpt-image-1: high|medium|low  /  dall-e-3: hd|standard",
    )
    source_ref: str = Field(
        default="",
        description="Externe Referenz (z.B. bfagent.BookChapter.id)",
    )


class IllustrationResult(BaseModel):
    """Output-Schema von IllustrationAgent.generate()."""

    success: bool
    image_url: str = ""                 # URL (dall-e-3) oder leer bei gpt-image-1
    images: list[str] = Field(default_factory=list)
    image_data_b64: str = ""            # base64-PNG (gpt-image-1)
    prompt_used: str = ""
    provider: str = ""
    model: str = ""
    latency_ms: int = 0
    usage_tokens: int = 0               # output_tokens (gpt-image-1)
    asset_id: str = Field(
        default="",
        description="Asset-ID im illustration-hub (wenn provider='hub')",
    )
    error: str = ""
    metadata: dict = Field(default_factory=dict)

    @classmethod
    def error_result(cls, error: str, provider: str = "") -> "IllustrationResult":
        return cls(success=False, error=error, provider=provider)
