"""
IllustrationAgent -- Haupt-Entry-Point

Routet IllustrationRequest an den konfigurierten Provider.

Provider-Keys:
  openai       gpt-image-1 (primär, höchste Qualität)
  openai-mini  gpt-image-1-mini (Budget / Massen-Generierung)
  dalle3       dall-e-3 (Legacy)
  stable_diffusion
  hub          illustration-hub REST API
  mock         Test-Stub
"""

from __future__ import annotations

import asyncio
import logging
from typing import Literal

from .schemas import IllustrationRequest, IllustrationResult

logger = logging.getLogger(__name__)

ProviderType = Literal["openai", "openai-mini", "dalle3", "stable_diffusion", "hub", "mock"]


class IllustrationAgent:
    """
    Haupt-Entry-Point fuer Bild-Generierung.

    Verwendung:
        # Buchcover / finale Illustrationen
        agent = IllustrationAgent(provider="openai", api_key="...")

        # Thumbnails / Konzeptskizzen / Massen-Generierung
        agent = IllustrationAgent(provider="openai-mini", api_key="...")

        # Via illustration-hub
        agent = IllustrationAgent(
            provider="hub",
            hub_url="https://illustration.iil.pet",
            api_key="...",
        )

        # Async
        result = await agent.agenerate(request)

        # Batch (async, concurrent)
        results = await agent.abatch_generate([req1, req2, req3])
    """

    def __init__(
        self,
        provider: ProviderType = "mock",
        api_key: str = "",
        hub_url: str = "",
        **provider_kwargs,
    ):
        self.provider_name = provider
        self._provider = self._build_provider(provider, api_key, hub_url, provider_kwargs)

    def _build_provider(self, provider: str, api_key: str, hub_url: str, kwargs: dict):
        if provider in ("openai", "openai-mini", "dalle3"):
            from .providers.dalle import DalleProvider
            if provider == "openai-mini" and "model" not in kwargs:
                kwargs["model"] = "gpt-image-1-mini"
            elif provider == "dalle3" and "model" not in kwargs:
                kwargs["model"] = "dall-e-3"
                if "quality" not in kwargs:
                    kwargs["quality"] = "standard"
            return DalleProvider(api_key=api_key, **kwargs)
        if provider == "stable_diffusion":
            from .providers.stable_diffusion import StableDiffusionProvider
            return StableDiffusionProvider(api_key=api_key, **kwargs)
        if provider == "hub":
            from .providers.hub_client import HubClientProvider
            return HubClientProvider(hub_url=hub_url, api_key=api_key, **kwargs)
        if provider == "mock":
            from .providers.mock import MockProvider
            return MockProvider(**kwargs)
        raise ValueError(f"Unknown provider: {provider!r}")

    def generate(self, request: IllustrationRequest) -> IllustrationResult:
        """Generiert ein Bild ueber den konfigurierten Provider."""
        logger.info(
            "generate provider=%s prompt_len=%d",
            self.provider_name, len(request.prompt),
        )
        try:
            result = self._provider.generate(request)
            if result.success and result.images and not result.image_url:
                result.image_url = result.images[0]
            return result
        except Exception as exc:
            logger.error("generate failed provider=%s error=%s", self.provider_name, exc)
            return IllustrationResult.error_result(str(exc), self.provider_name)

    async def agenerate(self, request: IllustrationRequest) -> IllustrationResult:
        """Async generate -- nutzt Provider.agenerate() falls verfuegbar."""
        logger.info(
            "agenerate provider=%s prompt_len=%d",
            self.provider_name, len(request.prompt),
        )
        try:
            result = await self._provider.agenerate(request)
            if result.success and result.images and not result.image_url:
                result.image_url = result.images[0]
            return result
        except Exception as exc:
            logger.error("agenerate failed provider=%s error=%s", self.provider_name, exc)
            return IllustrationResult.error_result(str(exc), self.provider_name)

    async def abatch_generate(
        self,
        requests: list[IllustrationRequest],
        max_concurrent: int = 4,
    ) -> list[IllustrationResult]:
        """Async batch generate -- concurrent mit Semaphore-Limit."""
        sem = asyncio.Semaphore(max_concurrent)

        async def _limited(req: IllustrationRequest) -> IllustrationResult:
            async with sem:
                return await self.agenerate(req)

        return list(await asyncio.gather(*[_limited(r) for r in requests]))
