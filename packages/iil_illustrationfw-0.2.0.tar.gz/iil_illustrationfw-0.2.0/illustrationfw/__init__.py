"""
iil-illustrationfw -- Pure Python Illustration Framework

Provider-agnostisch: DALL-E 3, Stable Diffusion, illustration-hub REST API, Mock.

Kernklassen:
    IllustrationAgent     -- Haupt-Entry-Point
    IllustrationRequest   -- Input-Schema
    IllustrationResult    -- Output-Schema
"""

from .agent import IllustrationAgent
from .builders.prompt_builder import PromptBuilder
from .schemas import IllustrationRequest, IllustrationResult, StyleSpec

__all__ = [
    "IllustrationAgent",
    "IllustrationRequest",
    "IllustrationResult",
    "PromptBuilder",
    "StyleSpec",
]
__version__ = "0.2.0"
