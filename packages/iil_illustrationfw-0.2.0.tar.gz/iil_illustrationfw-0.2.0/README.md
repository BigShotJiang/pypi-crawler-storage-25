# illustration-fw

**iil-illustrationfw** — Pure Python illustration framework für die IIL Pipeline.

Provider-agnostisch (DALL·E 3, Stable Diffusion, Mock), Prompt-Building aus Buchkontext,
StyleDNA-Injection. Verwendet von [illustration-hub](https://github.com/achimdehnert/illustration-hub),
bfagent, writing-hub, etc.

Architektur: [ADR-084](https://github.com/achimdehnert/bfagent/blob/main/docs/adr/ADR-084-illustration-framework-pypi-package.md)
