"""
Tests fuer async generate, batch generate, und neue Builder-Methoden.
"""

import asyncio

from illustrationfw import IllustrationAgent, IllustrationRequest, PromptBuilder, StyleSpec


class TestAsyncGenerate:
    def test_agenerate_mock(self):
        async def _run():
            agent = IllustrationAgent(provider="mock")
            return await agent.agenerate(IllustrationRequest(prompt="async test"))

        result = asyncio.run(_run())
        assert result.success is True
        assert result.image_url != ""
        assert result.provider == "mock"

    def test_abatch_generate_mock(self):
        async def _run():
            agent = IllustrationAgent(provider="mock")
            requests = [
                IllustrationRequest(prompt=f"batch test {i}")
                for i in range(5)
            ]
            return await agent.abatch_generate(requests, max_concurrent=2)

        results = asyncio.run(_run())
        assert len(results) == 5
        assert all(r.success for r in results)
        assert all(r.provider == "mock" for r in results)

    def test_abatch_generate_empty(self):
        async def _run():
            agent = IllustrationAgent(provider="mock")
            return await agent.abatch_generate([])

        results = asyncio.run(_run())
        assert results == []


class TestSceneDescriptionBuilder:
    def test_from_scene_description_basic(self):
        request = PromptBuilder.from_scene_description(
            scene="A dark forest at midnight with glowing mushrooms",
        )
        assert request.prompt == "A dark forest at midnight with glowing mushrooms"
        assert request.style_spec.aspect_ratio == "16:9"
        assert request.quality == "high"

    def test_from_scene_description_custom(self):
        request = PromptBuilder.from_scene_description(
            scene="Underwater city",
            style="watercolor",
            aspect_ratio="1:1",
            quality="medium",
            negative_prompt="blurry, low quality",
        )
        assert request.prompt == "Underwater city"
        assert request.style_spec.style == "watercolor"
        assert request.style_spec.aspect_ratio == "1:1"
        assert request.quality == "medium"
        assert request.negative_prompt == "blurry, low quality"


class TestTopLevelExports:
    def test_style_spec_exported(self):
        spec = StyleSpec(style="oil painting", aspect_ratio="4:3")
        assert spec.style == "oil painting"

    def test_prompt_builder_exported(self):
        req = PromptBuilder.from_scene_description(scene="test")
        assert isinstance(req, IllustrationRequest)


class TestProviderExports:
    def test_base_provider_importable(self):
        from illustrationfw.providers import BaseProvider
        assert BaseProvider is not None

    def test_mock_provider_importable(self):
        from illustrationfw.providers import MockProvider
        assert MockProvider is not None
