"""
Tests fuer MockProvider, PromptBuilder und Schemas
"""

from illustrationfw import IllustrationAgent, IllustrationRequest
from illustrationfw.builders.prompt_builder import PromptBuilder
from illustrationfw.schemas import StyleSpec


class TestMockProvider:
    def test_generate_returns_success(self):
        agent = IllustrationAgent(provider="mock")
        result = agent.generate(IllustrationRequest(prompt="test"))
        assert result.success is True
        assert result.image_url != ""
        assert len(result.images) == 1

    def test_generate_multiple_images(self):
        agent = IllustrationAgent(provider="mock")
        result = agent.generate(IllustrationRequest(prompt="test", num_images=3))
        assert result.success is True
        assert len(result.images) == 3

    def test_provider_name_stored(self):
        agent = IllustrationAgent(provider="mock")
        assert agent.provider_name == "mock"

    def test_unknown_provider_raises(self):
        try:
            IllustrationAgent(provider="unknown")  # type: ignore[arg-type]
            assert False, "Should raise"
        except ValueError:
            pass


class TestPromptBuilder:
    def test_from_chapter_context_minimal(self):
        request = PromptBuilder.from_chapter_context()
        assert isinstance(request, IllustrationRequest)
        assert request.prompt != ""

    def test_from_chapter_context_full(self):
        request = PromptBuilder.from_chapter_context(
            chapter_title="Die letzte Nacht",
            setting="mittelalterliche Stadt bei Regen",
            characters=["Elena Voss", "Der Schatten"],
            mood="duester, spannend",
            style_dna={"signature_moves": ["starke Kontraste", "moody lighting"]},
        )
        assert "Elena Voss" in request.prompt
        assert "mittelalterliche" in request.prompt
        assert request.style_spec.aspect_ratio == "16:9"

    def test_from_cover_context(self):
        request = PromptBuilder.from_cover_context(
            book_title="Das Schweigen der Waelder",
            genre="Thriller",
            protagonist="Elena Voss",
        )
        assert request.style_spec.aspect_ratio == "3:4"
        assert request.quality == "hd"
        assert "Elena Voss" in request.prompt


class TestSchemas:
    def test_illustration_request_defaults(self):
        req = IllustrationRequest(prompt="test")
        assert req.num_images == 1
        assert req.quality == "high"
        assert req.style_spec.style == "digital painting"

    def test_style_spec_aspect_ratios(self):
        for ratio in ["1:1", "4:3", "16:9", "9:16", "3:4"]:
            spec = StyleSpec(aspect_ratio=ratio)
            assert spec.aspect_ratio == ratio

    def test_error_result(self):
        result = IllustrationRequest(prompt="test")
        err = IllustrationRequest(prompt="test")
        from illustrationfw.schemas import IllustrationResult
        err_result = IllustrationResult.error_result("something went wrong", "mock")
        assert err_result.success is False
        assert err_result.error == "something went wrong"
        assert err_result.provider == "mock"
