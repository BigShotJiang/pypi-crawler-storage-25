from dataclasses import asdict

import numpy as np
import pytest
from astropy.io import fits
from dkist_header_validator.spec_validators import spec_extras_validator
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.asdf import asdf_encoder
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.codecs.json import json_encoder
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_dlnirsp.models.tags import DlnirspTag
from dkist_processing_dlnirsp.tasks.write_dataset_extras import DlnirspWriteL1DatasetExtras
from dkist_processing_dlnirsp.tasks.write_dataset_extras import stack_pad_right
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingConstants
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingParameters


def dlnirsp_dataset_extra_testing_constants(polarimeter_mode: str, num_cs_steps: int) -> dict:
    return {
        "CAMERA_BIT_DEPTH": 16,
        "CAMERA_ID": "20:BSC-00049",
        "CAMERA_NAME": "AndorBalor.03",
        "DARK_AVERAGE_COUDE_TABLE_ANGLE": 33.421358167448965,
        "DARK_AVERAGE_LIGHT_LEVEL": 685.836364498715,
        "DARK_AVERAGE_TELESCOPE_AZIMUTH": 190.11922951102557,
        "DARK_AVERAGE_TELESCOPE_ELEVATION": 77.87248824444465,
        "DARK_DATE_BEGIN": "2024-01-01T15:05:00.000000",
        "DARK_DATE_END": "2024-01-01T15:35:27.041536",
        "DARK_GOS_LEVEL0_STATUS": "DarkShutter",
        "DARK_GOS_LEVEL3_LAMP_STATUS": "none",
        "DARK_GOS_LEVEL3_STATUS": "clear",
        "DARK_GOS_POLARIZER_ANGLE": -999,
        "DARK_GOS_POLARIZER_STATUS": "clear",
        "DARK_GOS_RETARDER_ANGLE": -999,
        "DARK_GOS_RETARDER_STATUS": "clear",
        "DARK_NUM_RAW_FRAMES_PER_FPA": {
            "34.02": [4],
            "510.384": [4],
        },
        "DARK_OBSERVING_PROGRAM_EXECUTION_IDS": [
            "eid_2_24_op-X3UG6_R002.171242.13054962",
            "eid_2_24_op30OU-k_R002.171242.13046408",
        ],
        "OBSERVE_EXPOSURE_TIMES": [136.08],
        "NON_DARK_TASK_EXPOSURE_TIMES": [136.08, 2041.536],
        "DARK_EXPOSURE_TIMES": [136.08, 2041.536],
        "DARK_READOUT_EXP_TIMES": [34.02, 510.384],
        "DARK_READOUT_TIMES_PER_DARK_EXPOSURE_TIME": {
            "136.08": [34.02],
            "2041.536": [510.384],
        },
        "HARDWARE_BINNING_X": 1,
        "HARDWARE_BINNING_Y": 1,
        "HLS_VERSION": "Pono_8.0.0",
        "LAMP_GAIN_READOUT_EXPOSURE_TIMES": [510.384],
        "LAMP_GAIN_EXPOSURE_TIMES": [2041.536],
        "POLCAL_AVERAGE_COUDE_TABLE_ANGLE": 212.32415794395922,
        "POLCAL_AVERAGE_LIGHT_LEVEL": 676.1140037869549,
        "POLCAL_AVERAGE_TELESCOPE_AZIMUTH": 147.96609040745798,
        "POLCAL_AVERAGE_TELESCOPE_ELEVATION": 76.58346179549308,
        "POLCAL_COUDE_TABLE_TRACKING_MODE": "Fixed coude table angle",
        "POLCAL_DATE_BEGIN": "2024-01-01T17:05:00.000000",
        "POLCAL_DATE_END": "2024-01-01T21:22:31.854582",
        "POLCAL_NUM_RAW_FRAMES_PER_FPA": 4,
        "POLCAL_OBSERVING_PROGRAM_EXECUTION_IDS": [
            "eid_2_24_opLzHeS4_R002.171242.13036517",
        ],
        "POLCAL_READOUT_EXPOSURE_TIMES": [34.02],
        "POLCAL_TELESCOPE_SCANNING_MODE": "HEADER_KEY_NOT_FOUND",
        "POLCAL_TELESCOPE_TRACKING_MODE": "Standard Differential Rotation Tracking",
        "POLCAL_EXPOSURE_TIMES": [136.08],
        "PROPOSAL_ID": "pid_2_24",
        "SOFTWARE_BINNING_X": 1,
        "SOFTWARE_BINNING_Y": 1,
        "SOLAR_GAIN_AVERAGE_COUDE_TABLE_ANGLE": 31.853600662668857,
        "SOLAR_GAIN_AVERAGE_LIGHT_LEVEL": 701.9119194218796,
        "SOLAR_GAIN_AVERAGE_TELESCOPE_AZIMUTH": 163.72726641760602,
        "SOLAR_GAIN_AVERAGE_TELESCOPE_ELEVATION": 78.03402647145396,
        "SOLAR_GAIN_COUDE_TABLE_TRACKING_MODE": "Fixed coude table angle",
        "SOLAR_GAIN_DATE_BEGIN": "2024-01-01T16:05:00.000000",
        "SOLAR_GAIN_DATE_END": "2024-01-01T16:05:07.136080",
        "SOLAR_GAIN_GOS_LEVEL0_STATUS": "FieldStop (2.8arcmin)",
        "SOLAR_GAIN_GOS_LEVEL3_LAMP_STATUS": "none",
        "SOLAR_GAIN_GOS_LEVEL3_STATUS": "clear",
        "SOLAR_GAIN_GOS_POLARIZER_ANGLE": -999,
        "SOLAR_GAIN_GOS_POLARIZER_STATUS": "clear",
        "SOLAR_GAIN_GOS_RETARDER_ANGLE": -999,
        "SOLAR_GAIN_GOS_RETARDER_STATUS": "clear",
        "SOLAR_GAIN_NUM_RAW_FRAMES_PER_FPA": 4,
        "SOLAR_GAIN_OBSERVING_PROGRAM_EXECUTION_IDS": [
            "eid_2_24_opa2ME90_R002.171242.13044416",
        ],
        "SOLAR_GAIN_READOUT_EXPOSURE_TIMES": [34.019999999999996],
        "SOLAR_GAIN_TELESCOPE_SCANNING_MODE": "HEADER_KEY_NOT_FOUND",
        "SOLAR_GAIN_TELESCOPE_TRACKING_MODE": "Standard Differential Rotation Tracking",
        "SOLAR_GAIN_EXPOSURE_TIMES": [136.08],
        "POLARIMETER_MODE": polarimeter_mode,
        "NUM_CS_STEPS": num_cs_steps,
    }


@pytest.fixture()
def num_cs_steps():
    return 3


@pytest.fixture(scope="function")
def write_dataset_extras_task(
    tmp_path,
    assign_input_dataset_doc_to_task,
    recipe_run_id,
    link_constants_db,
    polarimeter_mode,
    num_cs_steps,
):
    constants_db = DlnirspTestingConstants()
    constant_dict = asdict(constants_db)
    constant_dict.update(
        dlnirsp_dataset_extra_testing_constants(
            polarimeter_mode=polarimeter_mode,
            num_cs_steps=num_cs_steps,
        )
    )
    link_constants_db(recipe_run_id=recipe_run_id, constants_obj=constant_dict)
    with DlnirspWriteL1DatasetExtras(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        assign_input_dataset_doc_to_task(task, DlnirspTestingParameters())
        data = np.ones((100, 100))
        # Wavecal solution
        wavecal_solution_data = {
            "CTYPE3": "AWAV-GRA",
            "CUNIT3": "nm",
            "CRPIX3": 218,
            "CRVAL3": 854.1738582455826,
            "CDELT3": 0.0022975580183395555,
            "PV3_0": 23000.0,
            "PV3_1": 90,
            "PV3_2": 65.696,
        }
        task.write(
            data=wavecal_solution_data,
            tags=[DlnirspTag.task_wavelength_solution(), DlnirspTag.intermediate()],
            encoder=json_encoder,
        )
        # Bad pixel cube
        task.write(
            data=np.ones((100, 100, 100)),
            tags=[DlnirspTag.intermediate(), DlnirspTag.task("BAD_PIXEL_CUBE")],
            encoder=fits_array_encoder,
        )
        # Dark
        for exp_time in constant_dict["NON_DARK_TASK_EXPOSURE_TIMES"]:
            task.write(
                data=data,
                tags=DlnirspTag.intermediate_frame_dark(exposure_time=exp_time),
                encoder=fits_array_encoder,
            )
        # Solar Gain
        task.write(
            data=data,
            tags=[DlnirspTag.intermediate_frame(), DlnirspTag.task_solar_gain()],
            encoder=fits_array_encoder,
        )
        # Characteristic spectrum
        task.write(
            data=np.ones((1, 100)),
            tags=[
                DlnirspTag.frame(),
                DlnirspTag.intermediate(),
                DlnirspTag.task("SC_PAD_CHAR_SPEC"),
            ],
            encoder=fits_array_encoder,
        )
        # Spectral curvature shifts and scales
        tree = {
            "spectral_shifts": {1: [1, 2, 3, 4], 2: [1, 2, 3], 3: [1, 2, 3, 4, 5, 6]},
            "spectral_scales": {1: [1, 2, 3, 4], 2: [1, 2, 3], 3: [1, 2, 3, 4, 5, 6]},
        }
        task.write(
            data=tree,
            tags=[DlnirspTag.intermediate(), DlnirspTag.task_geometric()],
            encoder=asdf_encoder,
        )
        # Wavelength calibration input spectrum
        task.write(
            data=np.ones((1, 100)),
            tags=[
                DlnirspTag.intermediate(),
                DlnirspTag.task_wavelength_calibration_input_spectrum(),
            ],
            encoder=fits_array_encoder,
        )
        # Wavelength calibration reference spectrum
        task.write(
            data=np.ones((1, 100)),
            tags=[
                DlnirspTag.intermediate(),
                DlnirspTag.task_wavelength_calibration_reference_spectrum(),
            ],
            encoder=fits_array_encoder,
        )
        # Wavelength calibration reference wavelength vector
        task.write(
            data=np.ones((1, 100)),
            tags=[
                DlnirspTag.intermediate(),
                DlnirspTag.task_wavelength_calibration_reference_wavelength_vector(),
            ],
            encoder=fits_array_encoder,
        )
        # Demodulation matrices
        task.write(
            data=np.ones((100, 100, 4, 8)),
            tags=[DlnirspTag.intermediate_frame(), DlnirspTag.task_demodulation_matrices()],
            encoder=fits_array_encoder,
        )
        # PCAS
        if polarimeter_mode == "Full Stokes":
            for cs_step in range(num_cs_steps):
                for stokes in ["I", "Q", "U", "V"]:
                    task.write(
                        data=np.ones((100, 100)),
                        tags=[
                            DlnirspTag.task(TaskName.polcal_as_science),
                            DlnirspTag.intermediate_frame(),
                            DlnirspTag.stokes(stokes),
                            DlnirspTag.cs_step(cs_step),
                        ],
                        encoder=fits_array_encoder,
                    )

        yield task
        task._purge()


@pytest.mark.parametrize(
    "polarimeter_mode",
    [pytest.param("Full Stokes", id="polarimetric"), pytest.param("Stokes I", id="spectrographic")],
)
def test_write_dataset_extras_task(
    write_dataset_extras_task,
    mocker,
    fake_gql_client,
    polarimeter_mode,
    num_cs_steps,
):
    """
    :Given: a write dataset extras task
    :When: running the task
    :Then: no errors are raised and the expected outputs are produced
    """
    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )
    task = write_dataset_extras_task
    task()

    expected_number_of_intensity_extras = {
        "bad_pixel_map": 1,
        "dark": 1 * len(task.constants.dark_exposure_times),
        "solar_gain": 1,
        "characteristic_spectra": 1,
        "spectral_curvature_shifts": 1,
        "spectral_curvature_scales": 1,
        "wavecal_input": 1,
        "wavecal_reference": 1,
        "wavecal_wavelength": 1,
    }

    expected_number_of_polarimetric_extras = {
        "demodulation_matrices": 1,
        "polcal_as_science": 4 * num_cs_steps,
    }

    dataset_extra_files = list(task.read(tags=[Tag.extra(), Tag.output()]))
    # Ensure the correct number of dataset extra files are written
    if polarimeter_mode == "Full Stokes":
        assert len(dataset_extra_files) == sum(expected_number_of_intensity_extras.values()) + sum(
            expected_number_of_polarimetric_extras.values()
        )
    else:
        assert len(dataset_extra_files) == sum(expected_number_of_intensity_extras.values())
    for dataset_extra_file in dataset_extra_files:
        assert task.constants.instrument in dataset_extra_file.name
        assert task.constants.dataset_id in dataset_extra_file.name
        assert spec_extras_validator.validate(dataset_extra_file, extra=False)
        hdu = fits.open(dataset_extra_file)[1]
        header = hdu.header
        assert header["PROCTYPE"] == "L1_EXTRA"
        assert header["EXTNAME"] in DatasetExtraType


def test_stack_pad_right():
    """
    :Given: a list of numpy arrays of unequal length
    :When: using the stack_pad_right method
    :Then: an array is returned where the unequal length arrays have been nan-padded to the length of the longest array
    """
    values = [np.array([1, 2, 3]), np.array([1, 2, 3, 4, 5, 6]), np.array([1, 2])]
    result = stack_pad_right(values=values)
    desired = [
        np.array([1, 2, 3, np.nan, np.nan, np.nan]),
        np.array([1, 2, 3, 4, 5, 6]),
        np.array([1, 2, np.nan, np.nan, np.nan, np.nan]),
    ]
    assert result.shape == (3, 6)
    np.testing.assert_array_equal(actual=result, desired=desired)
