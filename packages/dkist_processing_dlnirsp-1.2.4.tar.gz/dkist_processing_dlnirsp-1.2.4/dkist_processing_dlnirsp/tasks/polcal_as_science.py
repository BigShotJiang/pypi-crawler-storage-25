"""Perform calibration of the polcal frames as though they were observe frames."""

from dkist_processing_common.models.constants import BudName
from dkist_processing_common.models.task_name import TaskName
from dkist_service_configuration.logging import logger

from dkist_processing_dlnirsp.models.constants import DlnirspConstants
from dkist_processing_dlnirsp.models.tags import DlnirspTag
from dkist_processing_dlnirsp.tasks import ScienceCalibration


class DlnirspPCASConstants(DlnirspConstants):
    """Constants subclass that overrides observe frame constant values for use in the PCAS task."""

    @property
    def num_mosaic_tiles_x(self) -> int:
        """Return 1 to ignore the X-tile loop."""
        return 1

    @property
    def num_mosaic_tiles_y(self) -> int:
        """Return 1 to ignore the Y-tile loop."""
        return 1

    @property
    def num_dither_steps(self) -> int:
        """Return 1 to ignore the dither step loop."""
        return 1

    @property
    def num_mosaic_repeats(self) -> int:
        """
        Return the number of CS steps by overwriting the num_mosaic_repeats property.

        This ensures that the science task correctly loops through the required axes.
        """
        return self._db_dict[BudName.num_cs_steps]


class PolcalAsScienceCalibration(ScienceCalibration):
    """
    Task class for DL-NIRSP science-like calibration of polcal input frames.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    record_provenance = False

    def run(self):
        """Only run the task if the instrument is running in Full Stokes mode."""
        if self.constants.correct_for_polarization:
            with self.telemetry_span("Processing polcal frame as science frames"):
                super().run()
        else:
            logger.info(
                "Instrument running in intensity mode - no polcal as science calibration to perform."
            )

    @property
    def constants_model_class(self):
        """Get DLNIRSP pipeline constants."""
        return DlnirspPCASConstants

    def get_input_tags(
        self, mosaic_num: int, dither_step: int, x_tile: int, y_tile: int, modstate: int
    ) -> list[str] | None:
        """Input tags to route polcal data into the task."""
        return [
            DlnirspTag.linearized_frame(),
            DlnirspTag.task_polcal(),
            DlnirspTag.cs_step(mosaic_num),
            DlnirspTag.modstate(modstate),
        ]

    def get_calibrated_tags(
        self, stokes: str, mosaic_num: int, dither_step: int, x_tile_num: int, y_tile_num: int
    ) -> list[str]:
        """Output tags to prepare output data for later use."""
        return [
            DlnirspTag.task(TaskName.polcal_as_science),
            DlnirspTag.intermediate_frame(),
            DlnirspTag.stokes(stokes),
            DlnirspTag.cs_step(mosaic_num),
        ]
