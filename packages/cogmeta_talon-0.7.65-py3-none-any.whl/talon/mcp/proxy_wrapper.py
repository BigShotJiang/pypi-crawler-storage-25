#!/usr/bin/env python3
"""Direct MCP SSE proxy — no mcp-proxy dependency.

Bridges Claude Code stdio ↔ server SSE without any external binary.
On SSE disconnect: sends error responses for pending calls (CC retries),
reconnects automatically, replays the MCP handshake, resumes forwarding.
CC sees a single always-alive MCP server regardless of server restarts.

Usage in .mcp.json:
    {
        "mcpServers": {
            "talon": {
                "command": "talon-proxy-wrapper",
                "args": ["https://api.cogmeta.ai/talon/mcp/sse"],
                "env": {"TALON_API_KEY": "your-api-key"}
            }
        }
    }
"""

from __future__ import annotations

import json
import os
import queue
import signal
import ssl
import sys
import threading
import time
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlparse, urlunparse
from urllib.request import Request, urlopen

# Project root — used for local smart_read_batch and MemoryStore
_PROJECT_ROOT = Path(os.environ.get("PWD", os.getcwd()))

from talon.mcp.session_scorer import SessionScorer

try:
    from talon.telemetry.session_reporter import SessionReporter as _SessionReporter
    from talon.telemetry.session_reporter import TraceWatcher as _TraceWatcher
except Exception:
    _SessionReporter = None  # type: ignore[assignment,misc]
    _TraceWatcher = None     # type: ignore[assignment,misc]

try:
    from talon import __version__ as _VERSION
except Exception:
    _VERSION = "0"

# Looks like a real browser/app to Cloudflare — not a bot signature
_USER_AGENT = f"Talon/{_VERSION}"

MAX_RETRIES = 50
BACKOFF_BASE = 1.0
BACKOFF_MAX = 30.0
BACKOFF_MULTIPLIER = 1.5

SSE_CONNECT_TIMEOUT = 15     # seconds to establish SSE connection
SSE_READ_TIMEOUT = 120       # seconds between SSE events before considering dead
POST_TIMEOUT = 30            # seconds for each POST message
HEALTH_CHECK_INTERVAL = 30
HEALTH_CHECK_TIMEOUT = 5
HEALTH_WAIT_TIMEOUT = 60
HEALTH_WAIT_INTERVAL = 2


_LOG_FILE = Path.home() / ".talon" / "proxy.log"


def _log(msg: str) -> None:
    import datetime
    line = f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [talon-proxy] {msg}"
    print(line, file=sys.stderr, flush=True)
    try:
        _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _LOG_FILE.open("a") as _lf:
            _lf.write(line + "\n")
    except Exception:
        pass


# ── MemoryStore — client-side file cache ───────────────────────────────────
# Built in background at startup from project files. Provides O(1) line reads
# and symbol lookups for SRB, and stays fresh after edit_batch via refresh_file().
_memory_store: object = None
_memory_store_ready = threading.Event()


def _build_memory_store() -> None:
    global _memory_store
    try:
        from talon.cache.memory_store import MemoryStore
        ms = MemoryStore()
        ms.build(_PROJECT_ROOT)
        _memory_store = ms
        _log(f"MemoryStore ready: {ms.file_count} files")
    except Exception as exc:
        _log(f"MemoryStore build failed (falling back to disk): {exc}")
    finally:
        _memory_store_ready.set()


threading.Thread(target=_build_memory_store, daemon=True, name="memory-store-build").start()


def _load_credential_key() -> str:
    try:
        p = Path.home() / ".talon" / "credentials.json"
        return json.loads(p.read_text()).get("api_key", "")
    except Exception:
        return ""


def _make_ssl_ctx() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    cert_file = os.environ.get("SSL_CERT_FILE")
    if cert_file:
        ctx.load_verify_locations(cert_file)
    return ctx


def _inject_gal_bodies(raw_data: str) -> str:
    """Extract __TALON_REFS__ from a GAL SSE response, look up bodies from MemoryStore,
    and inject them into the text content before forwarding to CC.

    Returns the original raw_data unchanged if MemoryStore is not ready, if no
    __TALON_REFS__ marker is found, or if any parse error occurs.
    """
    ms = _memory_store
    if ms is None:
        return raw_data
    try:
        resp = json.loads(raw_data)
        content_list = resp.get("result", {}).get("content", [])
        if not content_list:
            return raw_data

        for block in content_list:
            if block.get("type") != "text":
                continue
            text = block.get("text", "")
            marker = "__TALON_REFS__:"
            idx = text.rfind(marker)
            if idx == -1:
                return raw_data

            refs_line = text[idx + len(marker):].split("\n")[0].strip()
            refs = json.loads(refs_line)

            clean_text = text[:idx].rstrip()

            bodies: list[str] = []
            for ref in refs:
                f = ref.get("f", "")
                ls = ref.get("ls", 0)
                le = ref.get("le", 0)
                if not f or not ls:
                    continue
                try:
                    lines = ms.get_lines(f, ls, le)  # type: ignore[attr-defined]
                    if lines:
                        bodies.append(f"--- {f}:{ls}-{le}\n" + "\n".join(lines))
                except Exception:
                    pass

            if bodies:
                block["text"] = clean_text + "\n\n## Source Bodies\n\n" + "\n\n".join(bodies)
            else:
                block["text"] = clean_text

            return json.dumps(resp)
    except Exception:
        pass
    return raw_data


def _correct_path(path: str) -> str:
    """Suffix-match an agent-sent file path against local MemoryStore.cached_paths.

    The cloud MCP server has no MemoryStore (source never leaves the client) so
    server-side path correction always fails. Resolve prefix drift here where the
    authoritative file list lives. Returns the canonical cached path when an
    unambiguous suffix match exists, else the original path.
    """
    if not path or "/" not in path:
        return path
    ms = _memory_store
    if ms is None:
        return path
    try:
        cached = ms.cached_paths  # type: ignore[attr-defined]
    except Exception:
        return path
    if path in cached:
        return path
    needle = "/" + path
    matches = [p for p in cached if p.endswith(needle)]
    if not matches:
        stem = path.rsplit("/", 1)[-1]
        matches = [p for p in cached if p.endswith("/" + stem) or p == stem]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        matches.sort(key=len)
        return matches[0]
    return path


def _correct_tool_args(tool_name: str, args: dict) -> bool:
    """Rewrite file paths in tool-call arguments in place. Returns True if anything changed."""
    if not isinstance(args, dict):
        return False
    changed = False

    if tool_name == "graph_ask_lite":
        exp = args.get("expected_files")
        if isinstance(exp, str):
            try:
                exp = json.loads(exp)
            except Exception:
                exp = None
        if isinstance(exp, list):
            new_exp = [_correct_path(p) if isinstance(p, str) else p for p in exp]
            if new_exp != exp:
                args["expected_files"] = new_exp
                changed = True

    elif tool_name == "graph_query":
        tgt = args.get("target")
        if isinstance(tgt, str):
            new_tgt = _correct_path(tgt)
            if new_tgt != tgt:
                args["target"] = new_tgt
                changed = True

    elif tool_name == "smart_read_batch":
        targets = args.get("targets")
        if isinstance(targets, str):
            try:
                targets = json.loads(targets)
            except Exception:
                targets = None
        if isinstance(targets, list):
            for t in targets:
                if isinstance(t, dict):
                    f = t.get("file")
                    if isinstance(f, str):
                        nf = _correct_path(f)
                        if nf != f:
                            t["file"] = nf
                            changed = True
            if changed:
                args["targets"] = targets

    elif tool_name == "edit_batch":
        edits = args.get("edits")
        if isinstance(edits, str):
            try:
                edits = json.loads(edits)
            except Exception:
                edits = None
        if isinstance(edits, list):
            for e in edits:
                if isinstance(e, dict):
                    f = e.get("file_path")
                    if isinstance(f, str):
                        nf = _correct_path(f)
                        if nf != f:
                            e["file_path"] = nf
                            changed = True
            if changed:
                args["edits"] = edits

    return changed


def _srb_lookup_symbol(file_path: str, symbol: str) -> str | None:
    """Locate a symbol body from MemoryStore. Returns None if not found."""
    ms = _memory_store
    if ms is None:
        return None
    try:
        locations = ms.locate_symbol(symbol)  # type: ignore[attr-defined]
        if not locations and hasattr(ms, "locate_symbol_fuzzy"):
            locations = ms.locate_symbol_fuzzy(symbol, max_results=3)  # type: ignore[attr-defined]
        for fp, line in (locations or []):
            if file_path and file_path not in fp and fp not in file_path:
                continue
            sym_info = ms.get_symbol_at(fp, line)  # type: ignore[attr-defined]
            if sym_info:
                ls = sym_info.get("line_start", line)
                le = sym_info.get("line_end", ls + 30)
                raw = ms.get_lines(fp, ls, le)  # type: ignore[attr-defined]
                if raw:
                    return "\n".join(raw)
    except Exception:
        pass
    return None


def _srb_local(targets: list[dict]) -> str | None:
    """Handle smart_read_batch locally via MemoryStore, falling back to disk.

    Handles both line-range reads and symbol lookups. Returns None only if a
    symbol is requested and MemoryStore cannot resolve it (forward to cloud).
    """
    results = []
    for t in targets:
        file_path = t.get("file", "")
        lines_spec = t.get("lines", "")
        symbol = t.get("symbol", "")

        # Symbol lookup — use MemoryStore; if not ready or not found, forward to cloud
        if symbol and not lines_spec:
            body = _srb_lookup_symbol(file_path, symbol)
            if body is None:
                return None  # MemoryStore miss — let cloud handle it
            results.append(f"--- {file_path} ({symbol})\n{body}")
            continue

        if not file_path or not lines_spec:
            results.append(f"--- {file_path or '?'} — missing file or lines")
            continue

        try:
            parts = lines_spec.split("-")
            start_l = int(parts[0])
            end_l = int(parts[1]) if len(parts) > 1 else start_l
        except (ValueError, IndexError):
            results.append(f"--- {file_path} — invalid lines spec: {lines_spec}")
            continue

        # Line-range read — MemoryStore first, disk fallback
        chunk_out: str | None = None
        ms = _memory_store
        if ms is not None:
            try:
                raw = ms.get_lines(file_path, start_l, end_l)  # type: ignore[attr-defined]
                if raw:
                    numbered = "\n".join(f"{start_l + i}│{ln.rstrip()}" for i, ln in enumerate(raw))
                    chunk_out = f"--- {file_path} {lines_spec}\n{numbered}"
            except Exception:
                pass

        if chunk_out is None:
            fp = _PROJECT_ROOT / file_path.lstrip("/")
            if not fp.exists():
                results.append(f"--- {file_path} {lines_spec} — file not found")
                continue
            try:
                all_lines = fp.read_text(errors="replace").splitlines()
                sl = max(0, start_l - 1)
                el = min(len(all_lines), end_l)
                chunk = all_lines[sl:el]
                numbered = "\n".join(f"{sl + 1 + i}│{ln.rstrip()}" for i, ln in enumerate(chunk))
                chunk_out = f"--- {file_path} {lines_spec}\n{numbered}"
            except OSError as exc:
                results.append(f"--- {file_path} — read error: {exc}")
                continue

        results.append(chunk_out)

    return "\n\n".join(results) if results else ""


def _edit_batch_local(edits: list[dict], project_root: Path) -> tuple[str, list[str]]:
    """Apply edits locally and return (formatted_result, successfully_edited_files).

    Replicates local_server edit_batch behaviour:
    - old_string → new_string replacement (unique match required)
    - empty old_string → create new file
    - Returns [OK]/[FAIL] lines, then runs pytest if TALON_EDIT_PYTEST=1
    """
    results: list[dict] = []

    for edit in edits[:20]:
        file_path = edit.get("file_path", "")
        old_string = edit.get("old_string", "")
        new_string = edit.get("new_string", "")

        if not file_path:
            results.append({"file": "(empty)", "status": "error", "detail": "missing file_path"})
            continue

        fp = Path(file_path)
        if not fp.is_absolute():
            fp = project_root / fp

        # New file creation
        if not old_string:
            if not new_string:
                results.append({"file": file_path, "status": "error", "detail": "empty old_string and new_string"})
                continue
            if fp.exists() and fp.read_text().strip():
                results.append({"file": file_path, "status": "error", "detail": "file exists — use old_string"})
                continue
            try:
                fp.parent.mkdir(parents=True, exist_ok=True)
                fp.write_text(new_string)
                results.append({"file": file_path, "status": "created", "detail": f"new file ({len(new_string)} chars)"})
            except Exception as exc:
                results.append({"file": file_path, "status": "error", "detail": str(exc)})
            continue

        try:
            content = fp.read_text()
        except FileNotFoundError:
            results.append({"file": file_path, "status": "error", "detail": f"file not found: {fp}"})
            continue
        except Exception as exc:
            results.append({"file": file_path, "status": "error", "detail": str(exc)})
            continue

        count = content.count(old_string)
        if count == 0:
            # Find closest line for hint
            hint = ""
            first_line = next((ln.strip() for ln in old_string.splitlines() if ln.strip()), "")
            if first_line:
                for ln in content.splitlines():
                    if first_line[:20] in ln:
                        hint = f" (closest: {ln.strip()[:60]!r})"
                        break
            results.append({"file": file_path, "status": "error", "detail": f"old_string not found{hint}"})
            continue
        if count > 1:
            results.append({"file": file_path, "status": "error", "detail": f"old_string not unique ({count} matches)"})
            continue

        try:
            fp.write_text(content.replace(old_string, new_string, 1))
            results.append({"file": file_path, "status": "ok", "detail": f"applied ({len(old_string)}→{len(new_string)} chars)"})
        except Exception as exc:
            results.append({"file": file_path, "status": "error", "detail": str(exc)})

    ok = sum(1 for r in results if r["status"] in ("ok", "created"))

    # Refresh MemoryStore for successfully edited files so next SRB sees new content
    ms = _memory_store
    if ms is not None and ok > 0:
        for r in results:
            if r["status"] not in ("ok", "created"):
                continue
            fp_str = r["file"]
            try:
                fp_abs = Path(fp_str) if Path(fp_str).is_absolute() else project_root / fp_str
                new_content = fp_abs.read_text()
                # MemoryStore indexes by relative path — resolve before refresh
                try:
                    rel_str = str(fp_abs.relative_to(project_root))
                except ValueError:
                    rel_str = fp_str
                ms.refresh_file(rel_str, new_content)  # type: ignore[attr-defined]
            except Exception:
                try:
                    ms.invalidate(fp_str)  # type: ignore[attr-defined]
                except Exception:
                    pass

    lines = [f"edit_batch: {ok}/{len(results)} applied"]
    for r in results:
        icon = "OK" if r["status"] in ("ok", "created") else "FAIL"
        lines.append(f"  [{icon}] {r['file']} — {r['detail']}")

    edited_ok = [r["file"] for r in results if r["status"] in ("ok", "created")]

    # TALON_EDIT_PYTEST=1 — run pytest on test files matching edited sources
    if os.environ.get("TALON_EDIT_PYTEST", "0") == "1" and ok > 0:
        pytest_out = _run_pytest_for_edits(edited_ok, project_root)
        if pytest_out:
            lines.append("")
            lines.extend(pytest_out.splitlines())

    return "\n".join(lines), edited_ok


def _run_pytest_for_edits(edited_files: list[str], project_root: Path) -> str:
    """Discover and run pytest for files matching edited sources."""
    import subprocess

    test_targets: list[str] = []
    for ef in edited_files:
        base = Path(ef).stem
        if base.startswith("test_"):
            test_targets.append(ef)
            continue
        # Convention: foo.py → t/unit/.../test_foo.py or tests/test_foo.py
        for candidate in project_root.rglob(f"test_{base}.py"):
            test_targets.append(str(candidate.relative_to(project_root)))

    if not test_targets:
        return ""

    timeout = int(os.environ.get("TALON_EDIT_PYTEST_TIMEOUT", "30"))
    extra_args = os.environ.get("TALON_PYTEST_ARGS", "-x -q").split()
    cmd = ["python3", "-m", "pytest"] + extra_args + test_targets

    try:
        result = subprocess.run(
            cmd, cwd=str(project_root), capture_output=True, text=True, timeout=timeout
        )
        out = (result.stdout + result.stderr).strip()
        status = "PASS" if result.returncode == 0 else "FAIL"
        summary_line = next((ln for ln in reversed(out.splitlines()) if ln.strip()), "")
        return f"pytest [{status}] {summary_line}\n{out[-2000:]}" if out else f"pytest [{status}]"
    except subprocess.TimeoutExpired:
        return f"pytest [TIMEOUT] exceeded {timeout}s"
    except Exception as exc:
        return f"pytest [ERROR] {exc}"


def _derive_health_url(sse_url: str) -> str:
    p = urlparse(sse_url)
    path = p.path[:-4] + "/health" if p.path.endswith("/sse") else p.path.rstrip("/") + "/health"
    return urlunparse((p.scheme, p.netloc, path, "", "", ""))


def _derive_post_url(sse_url: str, session_id: str) -> str:
    p = urlparse(sse_url)
    path = p.path[:-4] + "/messages" if p.path.endswith("/sse") else p.path.rstrip("/") + "/messages"
    return urlunparse((p.scheme, p.netloc, path, "", f"session_id={session_id}", ""))


def _check_health(health_url: str, api_key: str) -> bool:
    try:
        req = Request(health_url, headers={
            "User-Agent": _USER_AGENT,
            "X-API-Key": api_key,
            "Authorization": f"Bearer {api_key}",
        })
        with urlopen(req, timeout=HEALTH_CHECK_TIMEOUT, context=_make_ssl_ctx()) as r:
            return r.status == 200
    except Exception:
        return False


def _wait_for_health(health_url: str, api_key: str) -> bool:
    deadline = time.monotonic() + HEALTH_WAIT_TIMEOUT
    attempts = 0
    while time.monotonic() < deadline:
        if _check_health(health_url, api_key):
            if attempts:
                _log(f"Server healthy after {attempts} checks.")
            return True
        attempts += 1
        time.sleep(HEALTH_WAIT_INTERVAL)
    _log("Timed out waiting for server health.")
    return False


# ---------------------------------------------------------------------------
# DirectSseProxy
# ---------------------------------------------------------------------------

class DirectSseProxy:
    """Stdio ↔ SSE bridge without mcp-proxy.

    - Reads JSON-RPC from CC stdin, POSTs to server
    - Reads SSE stream from server, writes JSON-RPC to CC stdout
    - On disconnect: errors pending calls, reconnects, replays handshake
    """

    def __init__(self, sse_url: str, api_key: str) -> None:
        self._sse_url = sse_url
        self._api_key = api_key
        self._health_url = _derive_health_url(sse_url)
        self._session_id: str | None = None
        self._post_url: str | None = None

        self._running = True
        self._session_ready = threading.Event()  # set when session_id known + handshake done
        self._outbound: queue.Queue[bytes] = queue.Queue()
        self._pending_calls: dict[int | str, str] = {}  # id → tool_name
        self._pending_lock = threading.Lock()
        self._synthetic_ids: set[int | str] = set()  # IDs of proxy-injected calls to discard
        self._synthetic_counter = 0

        self._init_msg: str | None = None
        self._init_id: int | str | None = None
        self._prompt_idx = 0

        self._scorer = SessionScorer()
        self._session_start = time.monotonic()
        self._reporter: _SessionReporter | None = None
        self._watcher: _TraceWatcher | None = None
        _telemetry_enabled = os.environ.get("TALON_TELEMETRY_ENABLED", "1") != "0"
        if not _telemetry_enabled:
            try:
                _cfg_path = Path.home() / ".talon" / "config.yaml"
                if _cfg_path.exists():
                    import yaml as _yaml
                    _cfg = _yaml.safe_load(_cfg_path.read_text()) or {}
                    if not _cfg.get("telemetry", {}).get("enabled", True):
                        _telemetry_enabled = False
            except Exception:
                pass

        if _SessionReporter is not None and _telemetry_enabled:
            try:
                import uuid as _uuid
                _run_id = os.environ.get("TALON_RUN_ID") or str(_uuid.uuid4())
                os.environ["TALON_RUN_ID"] = _run_id
                self._reporter = _SessionReporter(
                    api_key=api_key,
                    cloud_url=os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai"),
                    project_id=os.environ.get("TALON_PROJECT_ID", ""),
                    cwd=os.environ.get("PWD", os.getcwd()),
                    started_monotonic=self._session_start,
                    run_id=_run_id,
                )
                if _TraceWatcher is not None and api_key:
                    self._watcher = _TraceWatcher(self._reporter)
                    self._watcher.start()
            except Exception:
                pass

    # ------------------------------------------------------------------ run

    def run(self) -> int:
        # CC reader starts immediately — queues messages while SSE is connecting
        threading.Thread(target=self._cc_reader, daemon=True).start()

        retries = 0
        backoff = BACKOFF_BASE
        is_first = True

        while self._running and retries < MAX_RETRIES:
            if not is_first:
                _log("Waiting for server before reconnect…")
                if not _wait_for_health(self._health_url, self._api_key):
                    retries += 1
                    time.sleep(min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX))
                    continue

            session_id = self._connect_sse()
            if session_id is None:
                retries += 1
                time.sleep(backoff)
                backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                continue

            self._session_id = session_id
            self._post_url = _derive_post_url(self._sse_url, session_id)

            if not is_first:
                # Replay MCP initialize before unblocking the outbound writer
                if not self._replay_handshake():
                    _log("Handshake replay failed — retrying.")
                    retries += 1
                    time.sleep(backoff)
                    backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                    continue
                _log("Session recovered — forwarding resumes.")

            is_first = False
            self._session_ready.set()

            # Start outbound writer for this session
            writer = threading.Thread(target=self._outbound_writer, daemon=True)
            writer.start()

            # Block reading SSE until disconnect
            disconnect_reason = self._read_sse_forever()

            self._session_ready.clear()

            if not self._running:
                break

            # Unblock CC for any in-flight calls
            self._flush_pending_as_errors("MCP session disconnected — reconnecting automatically.")

            elapsed = time.monotonic() - self._session_start
            if elapsed > 60:
                backoff = BACKOFF_BASE
                retries = 0

            retries += 1
            _log(f"SSE disconnected ({disconnect_reason}). Reconnect {retries}/{MAX_RETRIES}…")
            time.sleep(backoff)
            backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)

        # Submit final score snapshot so all-time average includes this session
        final_snap = self._scorer.score()
        if final_snap.prompts >= 3:
            self._post_score(final_snap)
        self._submit_trace()
        return 0 if not self._running else 1

    # ------------------------------------------------------------------ SSE connection

    def _connect_sse(self) -> str | None:
        """Open SSE connection, return session_id from endpoint event or None."""
        # Re-read credentials on every connect attempt — the prompt hook may have
        # rotated the key mid-session, which revokes the old key on the server side.
        fresh_key = _load_credential_key()
        if fresh_key and fresh_key != self._api_key:
            _log("API key rotated — updating for reconnect.")
            self._api_key = fresh_key
        try:
            ctx = _make_ssl_ctx()
            _guidance_hdr: dict[str, str] = (
                {"X-Talon-Guidance": "1"}
                if os.environ.get("TALON_GUIDANCE") == "1"
                else {}
            )
            _named_cfg = os.environ.get("TALON_NAMED_CONFIG", "")
            _named_cfg_hdr: dict[str, str] = (
                {"X-Talon-Named-Config": _named_cfg} if _named_cfg else {}
            )
            req = Request(self._sse_url, headers={
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
                "User-Agent": _USER_AGENT,
                "X-API-Key": self._api_key,
                "Authorization": f"Bearer {self._api_key}",
                **_guidance_hdr,
                **_named_cfg_hdr,
            })
            self._sse_resp = urlopen(req, timeout=SSE_CONNECT_TIMEOUT, context=ctx)
            _log(f"SSE connected to {self._sse_url}")

            # Read until we get the endpoint event with session_id
            deadline = time.monotonic() + SSE_CONNECT_TIMEOUT
            event_type = ""
            for raw in self._sse_resp:
                if time.monotonic() > deadline:
                    break
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data = line[5:].strip()
                    if event_type == "endpoint":
                        # data is the POST path or full URL with ?session_id=
                        sid = self._extract_session_id(data)
                        if sid:
                            _log(f"Session ID: {sid}")
                            # Store the response object — SSE reader will use it
                            return sid
                elif line == "":
                    event_type = ""
        except Exception as exc:
            from urllib.error import HTTPError
            if isinstance(exc, HTTPError) and exc.code == 401:
                _log("SSE connect 401 Unauthorized — key rotated or revoked. Refreshing from credentials.")
                fresh = _load_credential_key()
                if fresh and fresh != self._api_key:
                    self._api_key = fresh
                    _log("Key refreshed from credentials.json.")
            else:
                _log(f"SSE connect failed: {exc}")
        return None

    def _extract_session_id(self, endpoint_data: str) -> str | None:
        """Parse session_id from endpoint event data."""
        # Could be a path like /talon/mcp/messages?session_id=abc123
        # or a full URL
        try:
            from urllib.parse import parse_qs
            parsed = urlparse(endpoint_data if "://" in endpoint_data
                              else f"http://x{endpoint_data}")
            params = parse_qs(parsed.query)
            sid = params.get("session_id", [None])[0]
            if sid:
                return sid
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------ SSE reader

    def _read_sse_forever(self) -> str:
        """Read SSE events, write JSON-RPC responses to CC stdout. Returns disconnect reason."""
        try:
            event_type = ""
            data_lines: list[str] = []
            last_event = time.monotonic()

            for raw in self._sse_resp:
                if not self._running:
                    return "shutdown"
                if time.monotonic() - last_event > SSE_READ_TIMEOUT:
                    return "read timeout"

                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")

                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].strip())
                elif line == "":
                    # Dispatch event
                    data = "\n".join(data_lines)
                    data_lines = []
                    last_event = time.monotonic()

                    if event_type in ("message", "") and data:
                        _is_gal_resp = False
                        try:
                            resp = json.loads(data)
                            resp_id = resp.get("id")
                            with self._pending_lock:
                                # Discard responses to proxy-injected sync calls
                                if resp_id is not None and resp_id in self._synthetic_ids:
                                    self._synthetic_ids.discard(resp_id)
                                    event_type = ""
                                    continue
                                if resp_id is not None and resp_id in self._pending_calls:
                                    tool_name = self._pending_calls.pop(resp_id)
                                    if tool_name == "graph_ask_lite":
                                        _is_gal_resp = True
                                    snap = self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    if snap is not None:
                                        threading.Thread(
                                            target=self._post_score, args=(snap,), daemon=True
                                        ).start()
                        except (json.JSONDecodeError, KeyError):
                            pass
                        if _is_gal_resp:
                            data = _inject_gal_bodies(data)
                        sys.stdout.buffer.write((data + "\n").encode("utf-8"))
                        sys.stdout.buffer.flush()

                    event_type = ""

        except Exception as exc:
            return str(exc)
        return "stream ended"

    # ------------------------------------------------------------------ cloud sync

    def _fire_cloud_sync(self, file_paths: list[str]) -> None:
        """Enqueue synthetic graph_query(intent=sync) calls for each edited file.

        Responses arrive from cloud via SSE; _synthetic_ids causes them to be
        discarded rather than forwarded to CC (CC didn't make these calls).
        """
        if not self._session_ready.is_set():
            return
        for fp in file_paths:
            self._synthetic_counter += 1
            syn_id = f"__sync_{self._synthetic_counter}"
            with self._pending_lock:
                self._synthetic_ids.add(syn_id)
            msg = json.dumps({
                "jsonrpc": "2.0",
                "id": syn_id,
                "method": "tools/call",
                "params": {
                    "name": "graph_query",
                    "arguments": {"intent": "sync", "target": fp, "depth": "standard"},
                },
            }) + "\n"
            self._outbound.put(msg.encode("utf-8"))

    # ------------------------------------------------------------------ CC reader

    def _cc_reader(self) -> None:
        """Read JSON-RPC from CC stdin, queue for forwarding."""
        try:
            for raw_line in sys.stdin.buffer:
                if not self._running:
                    break
                try:
                    text = raw_line.decode("utf-8", errors="replace").strip()
                    if text:
                        msg = json.loads(text)
                        if msg.get("method") == "initialize":
                            self._init_msg = text
                            self._init_id = msg.get("id")
                        elif msg.get("method") == "tools/call":
                            params = msg.get("params", {})
                            tool_name = params.get("name", "")
                            msg_id = msg.get("id")
                            # Path hygiene — agent-sent paths may omit project prefixes
                            # (e.g. "airflow/x.py" vs indexed "src/airflow/x.py"). Cloud
                            # server has no MemoryStore so correction must happen here.
                            args_for_corr = params.get("arguments", {})
                            if _correct_tool_args(tool_name, args_for_corr):
                                params["arguments"] = args_for_corr
                                raw_line = (json.dumps(msg) + "\n").encode("utf-8")
                            # Intercept edit_batch — apply locally, no cloud round-trip
                            if tool_name == "edit_batch" and msg_id is not None and os.environ.get("TALON_LOCAL_EDIT", "1") != "0":
                                args = params.get("arguments", {})
                                edits = args.get("edits", [])
                                if isinstance(edits, str):
                                    try:
                                        edits = json.loads(edits)
                                    except Exception:
                                        edits = []
                                local_result, edited_files = _edit_batch_local(edits, _PROJECT_ROOT)
                                resp = json.dumps({
                                    "jsonrpc": "2.0",
                                    "id": msg_id,
                                    "result": {
                                        "content": [{"type": "text", "text": local_result}],
                                        "isError": False,
                                    },
                                }) + "\n"
                                sys.stdout.buffer.write(resp.encode("utf-8"))
                                sys.stdout.buffer.flush()
                                self._scorer.record_call(tool_name, self._prompt_idx)
                                self._scorer.persist()
                                self._prompt_idx += 1
                                # Invalidate cloud ArangoDB response cache for edited files
                                if edited_files:
                                    self._fire_cloud_sync(edited_files)
                                continue  # don't forward to cloud
                            # Intercept smart_read_batch line-range reads — handle locally
                            if tool_name == "smart_read_batch" and msg_id is not None:
                                args = params.get("arguments", {})
                                targets = args.get("targets", [])
                                if isinstance(targets, str):
                                    try:
                                        targets = json.loads(targets)
                                    except Exception:
                                        targets = []
                                local_result = _srb_local(targets)
                                if local_result is not None:
                                    resp = json.dumps({
                                        "jsonrpc": "2.0",
                                        "id": msg_id,
                                        "result": {
                                            "content": [{"type": "text", "text": local_result}],
                                            "isError": False,
                                        },
                                    }) + "\n"
                                    sys.stdout.buffer.write(resp.encode("utf-8"))
                                    sys.stdout.buffer.flush()
                                    self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    self._prompt_idx += 1
                                    continue  # don't forward to cloud
                            if msg_id is not None and tool_name:
                                with self._pending_lock:
                                    self._pending_calls[msg_id] = tool_name
                            self._prompt_idx += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
                self._outbound.put(raw_line)
        except Exception:
            pass
        finally:
            self._running = False

    # ------------------------------------------------------------------ outbound writer

    def _outbound_writer(self) -> None:
        """Forward queued CC messages → server via POST."""
        self._session_ready.wait()
        while self._running and self._session_ready.is_set():
            try:
                raw_line = self._outbound.get(timeout=1)
            except queue.Empty:
                continue
            try:
                text = raw_line.decode("utf-8", errors="replace").strip()
                if not text:
                    continue
                self._post_message(text)
            except Exception as exc:
                _log(f"POST failed: {exc}")
                # Requeue so next session picks it up
                self._outbound.put(raw_line)
                break

    def _post_message(self, body: str) -> None:
        data = body.encode("utf-8")
        req = Request(
            self._post_url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": _USER_AGENT,
                "X-API-Key": self._api_key,
                "Authorization": f"Bearer {self._api_key}",
            },
            method="POST",
        )
        with urlopen(req, timeout=POST_TIMEOUT, context=_make_ssl_ctx()):
            pass  # 202 Accepted — response comes via SSE

    # ------------------------------------------------------------------ handshake replay

    def _replay_handshake(self) -> bool:
        if not self._init_msg:
            _log("No saved initialize — cannot replay.")
            return False
        try:
            self._post_message(self._init_msg)
            # The initialize response will come through the SSE stream naturally —
            # we don't need to intercept it; CC already processed the first one and
            # the server just needs to re-establish the session state.
            time.sleep(0.5)
            _log("Handshake replayed.")
            return True
        except Exception as exc:
            _log(f"Handshake replay error: {exc}")
            return False

    # ------------------------------------------------------------------ pending flush

    def _flush_pending_as_errors(self, message: str) -> None:
        with self._pending_lock:
            pending = dict(self._pending_calls)
            self._pending_calls.clear()
        if not pending:
            return
        for call_id, tool_name in pending.items():
            err = json.dumps({
                "jsonrpc": "2.0",
                "id": call_id,
                "error": {"code": -32000, "message": message,
                          "data": {"tool": tool_name, "recoverable": True}},
            }) + "\n"
            try:
                sys.stdout.buffer.write(err.encode("utf-8"))
                sys.stdout.buffer.flush()
            except Exception:
                pass
        _log(f"Sent error responses for {len(pending)} pending call(s). CC can retry.")

    # ------------------------------------------------------------------ trace

    def _post_score(self, snap: object) -> None:
        """POST a score snapshot to the cloud API (fire-and-forget from thread)."""
        try:
            import uuid as _uuid
            api_key = self._api_key
            if not api_key:
                return
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai").rstrip("/")
            run_id = os.environ.get("TALON_RUN_ID", "")
            project_id = os.environ.get("TALON_PROJECT_ID", "")
            payload = json.dumps({
                "session_id": run_id,
                "project_id": project_id,
                "score": snap.score,          # type: ignore[attr-defined]
                "band": snap.band,            # type: ignore[attr-defined]
                "est_reduction_pct": snap.est_reduction_pct,  # type: ignore[attr-defined]
                "spp": snap.spp,              # type: ignore[attr-defined]
                "go_pct": snap.go_pct,        # type: ignore[attr-defined]
                "cpp": snap.cpp,              # type: ignore[attr-defined]
                "sg_ratio": snap.sg_ratio,    # type: ignore[attr-defined]
                "prompts": snap.prompts,      # type: ignore[attr-defined]
                "total_steps": snap.total_steps,  # type: ignore[attr-defined]
                "total_tctx": snap.total_tctx,    # type: ignore[attr-defined]
            }).encode("utf-8")
            req = Request(
                f"{cloud_url}/cloud/v1/talon/telemetry/score",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": api_key,
                    "User-Agent": _USER_AGENT,
                },
                method="POST",
            )
            with urlopen(req, timeout=5, context=_make_ssl_ctx()):
                pass
        except Exception:
            pass

    def _submit_trace(self) -> None:
        if self._watcher is not None:
            try:
                self._watcher.stop()
            except Exception:
                pass
        if self._reporter is not None:
            try:
                self._reporter.submit()
            except Exception:
                pass

    def shutdown(self) -> None:
        self._running = False
        try:
            self._sse_resp.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# find_mcp_proxy kept for talon check backward compat — no longer used at runtime
# ---------------------------------------------------------------------------

def find_mcp_proxy() -> str | None:
    """Legacy: find mcp-proxy binary. No longer used — direct SSE mode active."""
    import shutil
    venv_candidate = str(Path(sys.executable).parent / "mcp-proxy")
    for candidate in [venv_candidate, shutil.which("mcp-proxy"),
                      os.path.expanduser("~/.local/bin/mcp-proxy"), "/usr/local/bin/mcp-proxy"]:
        if candidate and os.path.isfile(candidate):
            return candidate
    return None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: talon-proxy-wrapper <SSE_URL>", file=sys.stderr)
        sys.exit(1)

    sse_url = sys.argv[1]
    api_key = os.environ.get("TALON_API_KEY", "").strip() or _load_credential_key()

    if not api_key:
        _log("WARNING: No API key found. Set TALON_API_KEY or run 'talon auth login'.")

    proxy = DirectSseProxy(sse_url, api_key)

    def handle_signal(signum, frame):
        proxy.shutdown()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    sys.exit(proxy.run())


if __name__ == "__main__":
    main()
