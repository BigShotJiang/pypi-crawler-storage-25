### dagshund plan (v2, cli 0.296.0)

#### jobs (2)
- `~` `jobs/data_pipeline` — update
  - `+` `tasks[task_key='audit']`: {2 fields}
  - `~` `tasks[task_key='clean'].depends_on[0].task_key`: "normalize" -> "ingest"
  - `+` `tasks[task_key='clean_v2']`: {3 fields}
  - `~` `tasks[task_key='combine'].depends_on[0].task_key`: "process_a" -> "process_b"
  - `~` `tasks[task_key='combine'].depends_on[1].task_key`: "process_b" -> "process_a"
  - `~` `tasks[task_key='enrich'].depends_on`: [{task_key: "validate"}] -> [{task_key: "validate"}, {task_key: "clean"}]
  - `~` `tasks[task_key='filter'].depends_on[0].task_key`: "standby" -> "ingest"
  - `+` `tasks[task_key='monitor'].depends_on`: [{task_key: "ingest"}]
  - `-` `tasks[task_key='normalize'].depends_on`: [{task_key: "ingest"}]
  - `~` `tasks[task_key='process_a'].depends_on[1].task_key`: "filter" -> "validate"
  - `~` `tasks[task_key='process_b'].depends_on[0].task_key`: "clean" -> "ingest"
  - `~` `tasks[task_key='process_b'].depends_on[1].task_key`: "filter" -> "validate"
  - `-` `tasks[task_key='standby']`: {2 fields}
  - `~` `tasks[task_key='validate'].depends_on[0].task_key`: "clean" -> "clean_v2"
- `~` `jobs/etl_pipeline` — update
  - `-` `tasks[task_key='check_row_count']`: {3 fields}
  - `~` `tasks[task_key='full_validation'].depends_on[0].task_key`: "check_row_count" -> "load"
  - `~` `tasks[task_key='publish'].depends_on`: [2 items] -> [{task_key: "full_validation"}]
  - `-` `tasks[task_key='skip_validation']`: {3 fields}

**~2** update
