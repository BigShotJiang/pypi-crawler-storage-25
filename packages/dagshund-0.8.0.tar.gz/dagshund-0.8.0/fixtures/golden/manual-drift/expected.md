### dagshund plan (v2, cli 0.296.0)

#### jobs (1)
- `~` `jobs/drift_pipeline` — update
  - :warning: manually edited outside bundle
  - `~` `edit_mode`: "EDITABLE" -> "UI_LOCKED" (drift)
  - `=` `email_notifications`: {no_alert_for_skipped_runs: false} (remote)
  - `=` `performance_target`: "PERFORMANCE_OPTIMIZED" (remote)
  - `~` `tasks[task_key='publish'].depends_on[0].task_key`: "ingest" -> "transform" (drift)
  - `+` `tasks[task_key='transform']` (re-added)

#### schemas (2)
- `+` `schemas/drift_doomed` — create
- `~` `schemas/drift_grants` — update
  - :warning: manually edited outside bundle
  - `~` `grants.[principal='data_readers'].privileges`: ["USE_SCHEMA"] -> ["SELECT", "USE_SCHEMA"] (drift)
  - `+` `grants.[principal='data_engineers']` (re-added)

**+1** create, **~2** update

> [!WARNING]
> **Manual Edits Detected**
> - jobs/drift_pipeline was edited outside the bundle
>   - 2 fields will be overwritten
>   - 1 task will be re-added (transform)
> - schemas/drift_grants was edited outside the bundle
>   - 1 field will be overwritten
>   - 1 grant will be re-added (data_engineers)
