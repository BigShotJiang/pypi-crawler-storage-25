### dagshund plan (v2, cli 0.296.0)

No changes (5 resources unchanged)
