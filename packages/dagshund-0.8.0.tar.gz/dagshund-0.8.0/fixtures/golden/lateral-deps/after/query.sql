SELECT 1 AS result
