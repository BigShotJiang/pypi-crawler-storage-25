"""Plan parsing, change detection, and drift predicates."""

import json
from typing import TypeGuard

from dagshund.types import (
    DagshundError,
    DiffState,
    FieldChange,
    Plan,
    ResourceChanges,
    parse_resource_key,
)

DANGEROUS_ACTIONS: frozenset[str] = frozenset({"delete", "recreate"})

STATEFUL_RESOURCE_WARNINGS: dict[str, str] = {
    # Unity Catalog
    "catalogs": "all schemas, tables, and volumes in this catalog will be lost",
    "schemas": "all tables, views, and volumes in this schema will be lost",
    "volumes": "all files in this volume will be lost",
    "registered_models": "all model versions will be lost",
    "experiments": "all experiment runs and metrics will be lost",
    # PostgreSQL
    "database_instances": "all catalogs and tables on this instance will be lost",
    "postgres_projects": "all branches and endpoints in this project will be lost",
    "postgres_branches": "all data on this branch will be lost",
}

STATEFUL_RESOURCE_TYPES: frozenset[str] = frozenset(STATEFUL_RESOURCE_WARNINGS)


def action_to_diff_state(action: str) -> DiffState:
    """Map a plan action string to its diff state category.

    Action vocabulary is duplicated in two other locations:
    - format.py: ACTIONS dict (display config per action)
    - js/src/types/plan-schema.ts: knownActionTypes (Zod schema)
    """
    match action:
        case "create":
            return DiffState.ADDED
        case "delete":
            return DiffState.REMOVED
        case "update" | "recreate" | "resize" | "update_id":
            return DiffState.MODIFIED
        case "" | "skip":
            return DiffState.UNCHANGED
        case _:
            return DiffState.UNKNOWN


def is_resource_changes(value: object) -> TypeGuard[ResourceChanges]:
    """Runtime check that narrows Any to ResourceChanges for the type checker."""
    return isinstance(value, dict) and all(isinstance(v, dict) for v in value.values())


def detect_changes(resources: ResourceChanges) -> bool:
    """Check whether any resource has a non-skip action (i.e., drift detected)."""
    return any(entry.get("action") not in ("skip", "") for entry in resources.values())


def has_drifted_field(change: FieldChange) -> bool:
    """Check whether a single field change represents manual drift.

    A field has drifted when old and new are both defined and equal (the bundle
    didn't intend to change it), and remote is present with a different value
    (someone edited the server state directly).

    Assumes the caller has already narrowed the type with ``isinstance(change, dict)``.
    """
    action = str(change.get("action", ""))
    if action_to_diff_state(action) == DiffState.UNCHANGED:
        return False
    if "old" not in change or "new" not in change:
        return False
    if change["old"] != change["new"]:
        return False
    return "remote" in change and change["remote"] != change["old"]


def is_topology_drift_change(change: FieldChange) -> bool:
    """Check whether a change represents a sub-entity missing from the remote.

    Databricks encodes ``bundle has X, remote doesn't — bundle will recreate it``
    as ``action=update`` with ``old == new`` and no ``remote`` field. Operates on
    post-merge change keys (see ``merge.py``); callers live in ``format.py``.

    Direct mirror of the JS predicate at ``js/src/utils/structural-diff.ts``.
    Gated strictly on ``action=update`` — ``recreate``/``resize``/``update_id``
    never appear with this shape in observed plan.json output, and treating them
    as topology drift would render ``(re-added)`` under resources whose per-line
    action is already ``recreate``.

    Mutually exclusive with ``has_drifted_field`` by construction (that one
    requires ``"remote" in change``).
    """
    if change.get("action") != "update":
        return False
    if "old" not in change or "new" not in change:
        return False
    if "remote" in change:
        return False
    return change["old"] == change["new"]


def detect_manual_edits(resources: ResourceChanges) -> bool:
    """Check whether any resource has fields that were manually edited outside the bundle."""
    for entry in resources.values():
        changes = entry.get("changes", {})
        if not isinstance(changes, dict):
            continue
        for change in changes.values():
            if not isinstance(change, dict):
                continue
            if has_drifted_field(change):
                return True
    return False


def detect_dangerous_actions(resources: ResourceChanges) -> bool:
    """Check whether any stateful resource has a dangerous action (delete or recreate)."""
    return any(
        entry.get("action") in DANGEROUS_ACTIONS and parse_resource_key(key)[0] in STATEFUL_RESOURCE_TYPES
        for key, entry in resources.items()
    )


def parse_plan(raw: str) -> Plan:
    """Parse and validate plan JSON."""
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise DagshundError(f"invalid JSON: {exc}") from exc
    except RecursionError as exc:
        raise DagshundError("plan JSON is too deeply nested") from exc

    if not isinstance(data, dict):
        raise DagshundError("plan JSON must be an object")

    return data
