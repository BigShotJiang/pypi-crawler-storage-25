#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
独立的升级工作脚本
此脚本以独立进程运行，即使主程序退出也能继续完成升级
"""

import os
import sys
import json
import subprocess
import time
from datetime import datetime

# 升级状态文件路径
UPGRADE_STATUS_FILE = '/tmp/xgo_blockly_upgrade_status.json'

# PyPI 镜像配置（优先清华镜像，回退到官方源）
MIRRORS = [
    {
        'name': 'tsinghua',
        'index': 'https://pypi.tuna.tsinghua.edu.cn/simple/',
        'trusted_host': 'pypi.tuna.tsinghua.edu.cn'
    },
    {
        'name': 'pypi',
        'index': None,
        'trusted_host': None
    }
]


def get_current_version():
    """
    获取当前版本号，按优先级尝试多种方式：
    1. pip show（最可靠，对 metadata 损坏容错性好）
    2. importlib.metadata（快速后备）
    3. 从 xgo_blockly.__version__ 读取（开发模式）
    4. 从 pyproject.toml 读取
    """
    import re
    
    # 方式1: pip show（最可靠，对 metadata 损坏容错性好）
    try:
        pip_result = subprocess.run(
            [sys.executable, '-m', 'pip', 'show', 'xgo-blockly'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if pip_result.returncode == 0:
            for line in pip_result.stdout.splitlines():
                if line.startswith('Version:'):
                    version = line.split(':', 1)[1].strip()
                    if version:
                        return version
    except Exception:
        pass
    
    # 方式2: importlib.metadata（快速后备）
    try:
        from importlib.metadata import version as get_pkg_version
        return get_pkg_version('xgo-blockly')
    except Exception:
        pass
    
    # 方式3: 从包的 __version__ 读取
    try:
        import xgo_blockly
        if hasattr(xgo_blockly, '__version__') and xgo_blockly.__version__:
            return xgo_blockly.__version__
    except Exception:
        pass
    
    # 方式4: 从 pyproject.toml 读取
    try:
        pyproject_path = os.path.join(os.path.dirname(__file__), '..', '..', 'pyproject.toml')
        if os.path.exists(pyproject_path):
            with open(pyproject_path, 'r', encoding='utf-8') as f:
                content = f.read()
                match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                if match:
                    return match.group(1)
    except Exception:
        pass
    
    return 'unknown'


def write_status(status, **kwargs):
    """写入升级状态到文件"""
    data = {
        'status': status,
        'updated_at': datetime.now().isoformat(),
        **kwargs
    }
    
    # 读取现有状态并合并
    try:
        if os.path.exists(UPGRADE_STATUS_FILE):
            with open(UPGRADE_STATUS_FILE, 'r', encoding='utf-8') as f:
                existing = json.load(f)
                # 保留 started_at 和 from_version
                if 'started_at' not in data and 'started_at' in existing:
                    data['started_at'] = existing['started_at']
                if 'from_version' not in data and 'from_version' in existing:
                    data['from_version'] = existing['from_version']
    except Exception:
        pass
    
    with open(UPGRADE_STATUS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def run_upgrade():
    """执行升级操作"""
    from_version = get_current_version()
    
    # 写入开始状态
    write_status(
        'running',
        started_at=datetime.now().isoformat(),
        from_version=from_version,
        message='正在升级中，请勿关闭机器狗上的 AI Blockly 程序...'
    )
    
    success = False
    error_msg = None
    output = ''
    
    # 尝试各个镜像源
    for mirror in MIRRORS:
        try:
            cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade', '--no-cache-dir']
            
            if mirror['index']:
                cmd.extend(['-i', mirror['index']])
            if mirror['trusted_host']:
                cmd.extend(['--trusted-host', mirror['trusted_host']])
            
            cmd.append('xgo-blockly')
            
            write_status('running', message=f"正在使用 {mirror['name']} 源升级...")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600  # 10分钟超时
            )
            
            output = result.stdout + '\n' + result.stderr
            
            if result.returncode == 0:
                success = True
                break
            else:
                error_msg = f"{mirror['name']} 源升级失败"
                
        except subprocess.TimeoutExpired:
            error_msg = f"{mirror['name']} 源升级超时"
        except Exception as e:
            error_msg = f"{mirror['name']} 源升级异常: {str(e)}"
    
    # 获取新版本号（使用 pip show 避免缓存问题）
    to_version = get_current_version()
    if success:
        # 升级成功后，用 pip show 获取最新版本（避免 importlib.metadata 缓存）
        try:
            pip_result = subprocess.run(
                [sys.executable, '-m', 'pip', 'show', 'xgo-blockly'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if pip_result.returncode == 0:
                for line in pip_result.stdout.splitlines():
                    if line.startswith('Version:'):
                        to_version = line.split(':', 1)[1].strip()
                        break
        except Exception:
            pass
    
    if success:
        write_status(
            'success',
            finished_at=datetime.now().isoformat(),
            to_version=to_version,
            message='升级成功，重启机器狗后刷新页面生效',
            output=output[-500:] if output else ''
        )
    else:
        write_status(
            'failed',
            finished_at=datetime.now().isoformat(),
            to_version=to_version,
            error=error_msg,
            message='升级失败，请检查网络后重试',
            output=output[-500:] if output else ''
        )
    
    return success


def main():
    """主函数"""
    # 确保只有一个升级进程在运行
    lock_file = '/tmp/xgo_blockly_upgrade.lock'
    
    # 检查是否有其他升级进程
    if os.path.exists(lock_file):
        try:
            with open(lock_file, 'r') as f:
                pid = int(f.read().strip())
            # 检查进程是否还在运行
            os.kill(pid, 0)
            print(f"升级进程已在运行 (PID: {pid})")
            sys.exit(1)
        except (OSError, ValueError):
            # 进程不存在或文件无效，删除锁文件
            os.remove(lock_file)
    
    # 创建锁文件
    with open(lock_file, 'w') as f:
        f.write(str(os.getpid()))
    
    try:
        success = run_upgrade()
        sys.exit(0 if success else 1)
    finally:
        # 清理锁文件
        if os.path.exists(lock_file):
            os.remove(lock_file)


if __name__ == '__main__':
    main()
