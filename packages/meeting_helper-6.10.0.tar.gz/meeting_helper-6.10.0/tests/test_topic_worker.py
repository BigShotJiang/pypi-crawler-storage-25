"""TopicWorker — debounce, hash-skip, state updates, broadcast."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import AppState
from meeting_helper.topic_worker import TopicWorker



class FakeConfig:
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    google_api_key = ""
    deepgram_api_key = ""
    claude_model = "claude-test"
    gemini_model = "gemini-test"
    local_model = "x"
    ollama_host = "http://localhost:11434"
    max_tokens = 512
    # recordings_dir + workspace_name are read by _match_action_item. The
    # matcher's narrow except no longer swallows AttributeError, so these
    # must be present on every test FakeConfig that runs through a topic
    # cycle (even if the matcher returns None on an empty pool).
    recordings_dir = "/tmp/topic-worker-tests"
    workspace_name = ""


@pytest.mark.asyncio
async def test_topic_worker_picks_sprint_ticket_and_writes_state(monkeypatch):
    """TopicWorker now picks one ticket from the cached sprint list (LLM-
    constrained pick) and writes it as the current topic."""
    import time
    buf = SentenceBuffer(role="self")
    buf.append_final("I finished ENGT-4147 — status remapper now accepts numeric severity values.")
    buf.append_final("Today I'm working on ENGT-4212 Phase 2.")

    fake_tracker = AsyncMock()

    state = AppState()
    state.self_buffer = buf
    state.tracker = fake_tracker
    state.asyncio_loop = asyncio.get_event_loop()
    # Pre-populate sprint_tickets so refresh_sprint_tickets uses the cache
    # (agent fetch is skipped when cache is fresh).
    state.sprint_tickets = [
        {"id": "110", "title": "[ENGT-4147] Status remapper: accept numeric severity values",
         "status": "in_progress", "status_kind": "in_progress", "priority": None,
         "body_md": "body text", "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1", "url": None,
         "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
         "recent_history": [], "linked_docs": []},
        {"id": "42", "title": "[ENGT-4212] Phase 1 — Backend ClickHouse query path",
         "status": "todo", "status_kind": "todo", "priority": None,
         "body_md": "", "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1", "url": None,
         "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
         "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()

    # The picker LLM returns a JSON pointing at id "110" (Status remapper).
    fake_call = AsyncMock(return_value='{"ticket_id": "110", "topic": "Status remapper"}')
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    # State reflects the picked ticket
    assert state.current_topic["ticket_ids"] == ["110"]
    assert "Status remapper" in state.current_topic["topic"]
    assert state.current_topic_cards[0]["id"] == "110"

    # Topic broadcast went out
    assert any(p.get("type") == "topic" for p in payloads)
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["ticket_ids"] == ["110"]


@pytest.mark.asyncio
async def test_topic_worker_hash_skip_avoids_duplicate_calls(monkeypatch):
    """Same labeled text twice → second run skips on the hash check."""
    import time
    buf = SentenceBuffer(role="self")
    buf.append_final("I'm on the auth migration.")

    fake_tracker = AsyncMock()

    state = AppState()
    state.self_buffer = buf
    state.tracker = fake_tracker
    state.asyncio_loop = asyncio.get_event_loop()
    # Pre-populate sprint_tickets so refresh_sprint_tickets uses the cache.
    state.sprint_tickets = [
        {"id": "1", "title": "Auth migration", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1", "board_id": "ws1",
         "board_name": "WS1", "sprint_name": "Sp1", "url": None,
         "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
         "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()

    fake_call = AsyncMock(return_value='{"ticket_id": "1", "topic": "Auth migration"}')
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    async def fake_broadcast(payload):
        pass
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()
    await worker._run()  # same buffer text → should hash-skip

    assert fake_call.await_count == 1


@pytest.mark.asyncio
async def test_topic_worker_handles_picker_failure(monkeypatch):
    """If the picker LLM blows up, TopicWorker leaves state.current_topic
    untouched rather than crashing or blanking it."""
    import time
    buf = SentenceBuffer(role="self")
    buf.append_final("I'm working on something.")

    fake_tracker = AsyncMock()

    state = AppState()
    state.self_buffer = buf
    state.tracker = fake_tracker
    state.asyncio_loop = asyncio.get_event_loop()
    # Pre-populate sprint_tickets so refresh_sprint_tickets uses the cache.
    state.sprint_tickets = [
        {"id": "1", "title": "Something", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1", "board_id": "ws1",
         "board_name": "WS1", "sprint_name": "Sp1", "url": None,
         "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
         "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()
    # Pre-set a topic so we can verify it's preserved on failure
    state.current_topic = {
        "topic": "Previous topic",
        "ticket_ids": ["prev"],
        "search_query": "",
        "last_user_statement": "",
    }

    fake_call = AsyncMock(side_effect=RuntimeError("network down"))
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    async def fake_broadcast(payload):
        pass
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    # Previous topic preserved on failure (safer than blanking)
    assert state.current_topic["topic"] == "Previous topic"


@pytest.mark.asyncio
async def test_topic_worker_skips_empty_buffer(monkeypatch):
    buf = SentenceBuffer(role="self")
    state = AppState()
    state.self_buffer = buf
    state.asyncio_loop = asyncio.get_event_loop()

    fake_call = AsyncMock(return_value='{}')
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    fake_call.assert_not_awaited()


def test_topic_worker_lifecycle_attaches_listener():
    buf = SentenceBuffer(role="self")
    worker = TopicWorker(FakeConfig(), buf)
    assert len(buf._on_sentence) == 0
    worker.start()
    assert len(buf._on_sentence) == 1
    worker.stop()
    assert len(buf._on_sentence) == 0
