"""TopicWorker basket branch tests — Tasks 6 and 7.

The dispatcher in `_run` must short-circuit to the basket picker when
`state.pinned_topics` is non-empty; otherwise it falls through to the
existing sprint+action-item flow.
"""

from __future__ import annotations

import asyncio

import pytest

from meeting_helper.state import state as global_state, PinnedItem
from meeting_helper.topic_worker import TopicWorker


class _DummyBuffer:
    """Minimal SentenceBuffer stand-in for the dispatcher tests.

    The basket tests stub `collect_window` directly so we only need
    listener add/remove no-ops here.
    """

    def __init__(self):
        self._sentences = []
        self._lock = asyncio.Lock()

    def add_sentence_listener(self, _):
        pass

    def remove_sentence_listener(self, _):
        pass


class _FakeConfig:
    """Mirrors the shape `_match_action_item` reads off the worker's config."""
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    claude_model = "claude-test"
    max_tokens = 256
    recordings_dir = "/tmp/topic-worker-basket-tests"
    workspace_name = ""
    action_items_inject_into_copilot = True


@pytest.fixture(autouse=True)
def _clean_state():
    global_state.clear_pins()
    global_state.current_topic = {}
    global_state.current_topic_cards = []
    yield
    global_state.clear_pins()


def _stub_branches(monkeypatch):
    """Replace both `_run` branches with async no-op recorders."""
    called = {"basket": False, "auto": False}

    async def _fake_basket(self, _labeled, _text):
        called["basket"] = True

    async def _fake_auto(self, _labeled, _text):
        called["auto"] = True

    monkeypatch.setattr(TopicWorker, "_pick_from_basket", _fake_basket)
    monkeypatch.setattr(
        TopicWorker, "_pick_from_sprint_and_action_items", _fake_auto,
    )
    monkeypatch.setattr(
        TopicWorker, "collect_window",
        lambda self, ob, n: [("self", "hello there world friend mate")],
    )
    return called


@pytest.mark.asyncio
async def test_run_short_circuits_to_basket_branch_when_pinned(monkeypatch):
    called = _stub_branches(monkeypatch)
    global_state.pin_topic(PinnedItem(kind="note", id="a.note.md", title="A"))

    worker = TopicWorker(_FakeConfig(), _DummyBuffer())

    await worker._run()

    assert called["basket"] is True
    assert called["auto"] is False


@pytest.mark.asyncio
async def test_run_uses_auto_branch_when_basket_empty(monkeypatch):
    called = _stub_branches(monkeypatch)
    worker = TopicWorker(_FakeConfig(), _DummyBuffer())

    await worker._run()

    assert called["basket"] is False
    assert called["auto"] is True


@pytest.mark.asyncio
async def test_pick_from_basket_chooses_a_pinned_item(monkeypatch, tmp_path):
    """Basket leg builds candidates from pinned items, asks the LLM picker,
    writes the chosen candidate into state.current_topic + cards."""
    note = tmp_path / "design-doc.note.md"
    note.write_text("Discussion about the API contract for /pin endpoint")

    async def _fake_pick(_state, _cfg, candidates):
        # Always pick the second candidate (the note).
        return candidates[1]

    monkeypatch.setattr(
        "meeting_helper.topic_worker.pick_topic_from_candidates",
        _fake_pick,
        raising=False,
    )

    async def _fake_broadcast(_payload):
        return None

    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast",
        _fake_broadcast,
        raising=False,
    )

    global_state.pin_topic(PinnedItem(kind="ticket", id="MH-1", title="A", board_id="bd"))
    global_state.pin_topic(PinnedItem(kind="note", id="design-doc.note.md", title="Design Doc"))

    cfg = _FakeConfig()
    cfg.recordings_dir = str(tmp_path)
    cfg.workspace_name = "test"

    worker = TopicWorker(cfg, _DummyBuffer())
    await worker._pick_from_basket(
        [("self", "let me talk about the design doc")],
        "let me talk about the design doc",
    )

    assert global_state.current_topic.get("topic") == "Design Doc"
    cards = global_state.current_topic_cards or []
    assert any(c.get("kind") == "note" for c in cards)
