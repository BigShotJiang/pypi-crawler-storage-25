"""Tests for meeting_helper.ai.prompts.build_system_prompt."""
import meeting_helper.config as cfg_mod
from meeting_helper.ai.prompts import build_system_prompt


def test_build_system_prompt_injects_copilot_instructions(monkeypatch):
    class _FakeCfg:
        copilot_instructions = "USER-WORKSPACE-CONTEXT-MARKER"
    monkeypatch.setattr(cfg_mod, "get_config", lambda: _FakeCfg())
    out = build_system_prompt()
    assert "USER-WORKSPACE-CONTEXT-MARKER" in out


def test_build_system_prompt_no_instructions_no_block(monkeypatch):
    class _FakeCfg:
        copilot_instructions = ""
    monkeypatch.setattr(cfg_mod, "get_config", lambda: _FakeCfg())
    out = build_system_prompt()
    assert "Workspace context (user-written)" not in out


def test_action_items_prompt_has_strict_json_directive():
    from meeting_helper.ai.prompts import build_action_items_extraction_messages

    msgs = build_action_items_extraction_messages(
        {"id": "m1", "transcript_text": "x", "summary_text": "", "title": "T"}
    )
    assert msgs[0]["role"] == "system"
    assert "JSON" in msgs[0]["content"]
    assert "items" in msgs[0]["content"]
    assert "T" in msgs[1]["content"]
