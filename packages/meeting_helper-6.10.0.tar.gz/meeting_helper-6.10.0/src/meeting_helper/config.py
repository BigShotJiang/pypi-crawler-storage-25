"""Configuration management for Meeting Helper."""

from __future__ import annotations

import functools
import json
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

HOME = Path.home()

def _test_mode_enabled() -> bool:
    return str(os.environ.get("TEST_MODE", "")).strip().lower() in ("1", "true", "yes", "on")

_TEST_MODE = _test_mode_enabled()
_SUFFIX = "-test" if _TEST_MODE else ""
_PORT_OFFSET = int(os.environ.get("MEETING_HELPER_TEST_PORT_OFFSET", "100")) if _TEST_MODE else 0

DEFAULT_CONFIG_DIR = HOME / ".config" / f"meeting-helper{_SUFFIX}"
PROD_CONFIG_DIR = HOME / ".config" / "meeting-helper"   # always the un-suffixed one
CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"
PID_FILE = HOME / f".meeting-helper{_SUFFIX}.pid"
GUI_PID_FILE = HOME / f".meeting-helper-gui{_SUFFIX}.pid"
MENUBAR_PID_FILE = HOME / f".meeting-helper-menubar{_SUFFIX}.pid"
META_FILE = HOME / f".meeting-helper{_SUFFIX}.meta.json"
LOG_FILE = HOME / f".meeting-helper{_SUFFIX}.log"

STATE_FILE = DEFAULT_CONFIG_DIR / "state.json"
WORKSPACES_DIR = DEFAULT_CONFIG_DIR / "workspaces"
LEGACY_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"
LEGACY_BACKUP = DEFAULT_CONFIG_DIR / "config.json.pre-workspaces.bak"
WORKSPACE_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,40}$")
DEFAULT_WORKSPACE_NAME = "default"


def bootstrap_test_config_dir() -> None:
    """In TEST_MODE, if the test config dir doesn't exist yet, copy the prod
    config dir into it (so the test daemon starts from a realistic config with
    real API keys). No-op when TEST_MODE is off or the test dir already exists.
    """
    if not _TEST_MODE:
        return
    if DEFAULT_CONFIG_DIR.exists():
        return
    if PROD_CONFIG_DIR.exists():
        shutil.copytree(PROD_CONFIG_DIR, DEFAULT_CONFIG_DIR)
    else:
        (DEFAULT_CONFIG_DIR / "workspaces").mkdir(parents=True, exist_ok=True)

CLAUDE_MODELS = {
    "sonnet": "claude-sonnet-4-6",
    "opus": "claude-opus-4-6",
    "haiku": "claude-haiku-4-5-20251001",
}

GEMINI_MODELS = {
    "flash": "gemini-2.5-flash",
    "flash-lite": "gemini-2.5-flash-lite",
    "pro": "gemini-2.5-pro",
    # `flash-3` previously mapped to "gemini-3-flash-preview" / "gemini-3.0-flash"
    # — neither resolves on Google's v1beta endpoint. Removed until a GA id lands.
}


def _resolve_alias(value: str, table: dict[str, str], *, default: str) -> str:
    """Normalise a model identifier into the alias the UI expects.

    Settings forms render a dropdown keyed by alias (``"sonnet"``, ``"haiku"``).
    Disk may hold either an alias OR — from older versions / corrupted writes —
    the full model id (``"claude-haiku-4-5-20251001"``). This helper accepts
    both shapes and returns a known alias, falling back to ``default`` when
    the value matches neither.
    """
    if value in table:
        return value
    for alias, full_id in table.items():
        if full_id == value:
            return alias
    return default

DEFAULT_CONFIG: dict[str, Any] = {
    "anthropic_api_key": "",
    "google_api_key": "",
    "deepgram_api_key": "",
    "port": 7891,
    "recordings_dir": str(HOME / "meetings"),
    "repos_workspaces": [],
    "repos": [],
    "knowledge_paths": [],
    "sentence_window": 5,
    "max_history_turns": 5,
    "claude_model": "sonnet",
    "gemini_model": "flash",
    "max_tokens": 2048,
    "transcription_language": "en",
    "silence_timeout": 30,
    "hot_moment_window_minutes": 10.0,
    "setup_complete": False,
    "favorites": [],
    "proactive_answers": False,
    "ignored_repos": [],      # repo folder names to never load
    "ignored_knowledge": [],  # knowledge folder names to never load
    "preferred_provider": "",        # "" = claude (default), "gemini", "local" = ollama
    "ai_provider_order": ["anthropic", "google"],   # streaming-query providers, primary first
    "ai_failover_delay_ms": 2000,                    # 0 = launch all providers at once
    "ollama_host": "http://localhost:11434",
    "local_model": "qwen2.5-coder:3b",
    "local_todo_mcp": {
        "type": "stdio",
        "command": "npx",
        "args": ["@local-todo/mcp"],
        "env": {},
        "url": "",
        "headers": {},
    },
    "preferred_transcriber": "",     # "" = auto, "whisper", "deepgram"
    "whisper_host": "",              # "" = local whisper, "http://host:8000" = remote
    "auto_start_record": True,       # auto-detect mic and start session
    "show_menubar_icon": True,
    "menubar_icon": "MH",
    # --- Learn From Conversations ---
    "kb_artifacts": [],            # filenames in recordings_dir that the agent retrieves from
    "auto_rename_on_end": False,   # auto-rename meeting on end via AI (3-5 word title)
    "auto_summarize_on_end": False, # auto-summarize meeting on end (uses .live.txt as input)
    "auto_add_to_kb": True,         # auto-add the .summary.txt to kb_artifacts after summarize+rename
    "kb_max_results": 3,            # top-N KB cards injected per query
    # --- Speaker diarization (Deepgram) + post-meeting auto-naming ---
    # diarize_other defaults ON: meeting audio has multiple speakers worth tagging.
    # Tradeoff: Deepgram diarize adds ~200-400ms end-to-end latency; toggle off if too slow.
    "deepgram_diarize_other": True,
    "deepgram_diarize_self": False,
    "auto_name_speakers_on_end": True,
    "user_display_name": "",
    # --- Persistent agentic chat ---
    "web_search_provider": None,    # "brave" | "tavily" | None
    "web_search_api_key": None,
    "copilot_instructions": "",
    "copilot_learned_memory": [],
    # --- Internal action items (MH-32) ---
    "action_items_extract_after_meeting": False,
    "action_items_inject_into_copilot": True,
}


DEFAULT_HOME_WIDGETS: list[dict] = [
    {"id": "system-status",   "x": 0, "y": 0, "w": 6, "h": 2, "hidden": False},
    {"id": "live-session",    "x": 0, "y": 2, "w": 6, "h": 4, "hidden": False},
    {"id": "quick-actions",   "x": 6, "y": 0, "w": 6, "h": 2, "hidden": False},
    {"id": "sprint-tickets",  "x": 6, "y": 2, "w": 6, "h": 4, "hidden": False},
    {"id": "action-items",    "x": 6, "y": 6, "w": 6, "h": 3, "hidden": False},
    {"id": "recent-meetings", "x": 0, "y": 9, "w": 6, "h": 3, "hidden": False},
    {"id": "recent-notes",    "x": 6, "y": 9, "w": 6, "h": 3, "hidden": False},
    {"id": "recent-chats",    "x": 0, "y": 6, "w": 6, "h": 3, "hidden": False},
]


def validate_workspace_name(name: str) -> None:
    """Raise ValueError if `name` is not a valid workspace name."""
    if not isinstance(name, str) or not WORKSPACE_NAME_RE.match(name):
        raise ValueError(
            f"Invalid workspace name: {name!r}. "
            f"Must match {WORKSPACE_NAME_RE.pattern}."
        )


def workspace_path(name: str) -> Path:
    """Return the JSON path for workspace `name`. Validates the name."""
    validate_workspace_name(name)
    return WORKSPACES_DIR / f"{name}.json"


def load_state() -> dict:
    """Read state.json. Return safe defaults if missing or corrupt."""
    defaults = {"active_workspace": DEFAULT_WORKSPACE_NAME, "workspace_order": []}
    if not STATE_FILE.exists():
        return defaults
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return defaults
    if not isinstance(data, dict):
        return defaults
    active = data.get("active_workspace") or DEFAULT_WORKSPACE_NAME
    order = data.get("workspace_order") or []
    if not isinstance(active, str) or not isinstance(order, list):
        return defaults
    return {"active_workspace": active, "workspace_order": [str(n) for n in order]}


def save_state(state: dict) -> None:
    """Atomically write state.json."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, STATE_FILE)


def list_workspaces() -> list[str]:
    """Return workspace names in `workspace_order`, with any unlisted files
    appended alphabetically. Skips files whose stem is not a valid workspace name."""
    if not WORKSPACES_DIR.exists():
        return []
    on_disk = set()
    for p in WORKSPACES_DIR.iterdir():
        if p.suffix != ".json":
            continue
        stem = p.stem
        if not WORKSPACE_NAME_RE.match(stem):
            continue
        on_disk.add(stem)
    order = load_state()["workspace_order"]
    ordered = [n for n in order if n in on_disk]
    listed = set(ordered)
    extras = sorted(on_disk - listed)
    return ordered + extras


def migrate_legacy_config() -> None:
    """One-shot migration: legacy config.json -> workspaces/default.json + state.json.

    Idempotent. If `workspaces/` already contains at least one *.json, does nothing.
    Always writes a `.bak` of the legacy file before deleting it.
    """
    WORKSPACES_DIR.mkdir(parents=True, exist_ok=True)
    if any(WORKSPACES_DIR.glob("*.json")):
        return  # already migrated

    default_path = WORKSPACES_DIR / f"{DEFAULT_WORKSPACE_NAME}.json"

    if LEGACY_CONFIG_FILE.exists():
        backup_path = LEGACY_BACKUP
        if backup_path.exists():
            backup_path = LEGACY_BACKUP.with_name(
                LEGACY_BACKUP.name + f"-{int(time.time())}"
            )
        shutil.copy2(LEGACY_CONFIG_FILE, backup_path)
        os.replace(LEGACY_CONFIG_FILE, default_path)
    else:
        with open(default_path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)

    save_state({
        "active_workspace": DEFAULT_WORKSPACE_NAME,
        "workspace_order": [DEFAULT_WORKSPACE_NAME],
    })


def create_workspace(name: str, copy_from: str | None = None) -> None:
    """Create a new workspace JSON file. Raises ValueError if name invalid or already exists."""
    target = workspace_path(name)
    if target.exists():
        raise ValueError(f"Workspace {name!r} already exists")

    if copy_from:
        src = workspace_path(copy_from)
        if not src.exists():
            raise ValueError(f"Source workspace {copy_from!r} not found")
        shutil.copy2(src, target)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        data = dict(DEFAULT_CONFIG)
        data["recordings_dir"] = str(HOME / "meetings" / name)
        with open(target, "w") as f:
            json.dump(data, f, indent=2)

    state = load_state()
    if name not in state["workspace_order"]:
        state["workspace_order"].append(name)
        save_state(state)


def delete_workspace(name: str) -> None:
    """Delete a workspace JSON file. Refuses if active or last remaining."""
    state = load_state()
    workspaces = list_workspaces()
    if len(workspaces) <= 1:
        raise ValueError(f"Cannot delete last workspace {name!r}")
    if name == state["active_workspace"]:
        raise ValueError(f"Cannot delete active workspace {name!r}")

    target = workspace_path(name)
    if target.exists():
        target.unlink()
    state["workspace_order"] = [n for n in state["workspace_order"] if n != name]
    save_state(state)


def rename_workspace(old: str, new: str) -> None:
    """Rename a workspace. Validates `new`, refuses if target exists."""
    src = workspace_path(old)
    dst = workspace_path(new)
    if not src.exists():
        raise ValueError(f"Workspace {old!r} not found")
    if dst.exists():
        raise ValueError(f"Workspace {new!r} already exists")

    os.replace(src, dst)
    state = load_state()
    state["workspace_order"] = [
        new if n == old else n for n in state["workspace_order"]
    ]
    if state["active_workspace"] == old:
        state["active_workspace"] = new
    save_state(state)


def set_active_workspace(name: str) -> None:
    """Update state.json to mark `name` as the active workspace.

    Also clears the cached global Config so the next get_config() reloads.
    """
    if not workspace_path(name).exists():
        raise ValueError(f"Workspace {name!r} not found")
    state = load_state()
    state["active_workspace"] = name
    if name not in state["workspace_order"]:
        state["workspace_order"].append(name)
    save_state(state)
    global _config
    _config = None


class Config:
    """JSON-backed configuration manager — backed by a per-workspace file."""

    def __init__(
        self,
        config_path: Path | None = None,
        *,
        workspace: str | None = None,
    ):
        # Ensure migration has run and a workspace exists on disk
        migrate_legacy_config()
        if not any(WORKSPACES_DIR.glob("*.json")):
            # Self-heal: no workspaces -> create default
            default_path = WORKSPACES_DIR / f"{DEFAULT_WORKSPACE_NAME}.json"
            default_path.parent.mkdir(parents=True, exist_ok=True)
            with open(default_path, "w") as f:
                json.dump(DEFAULT_CONFIG, f, indent=2)
            save_state({
                "active_workspace": DEFAULT_WORKSPACE_NAME,
                "workspace_order": [DEFAULT_WORKSPACE_NAME],
            })

        if config_path is not None:
            self.config_path = config_path
        elif workspace is not None:
            self.config_path = workspace_path(workspace)
        else:
            active = load_state()["active_workspace"]
            target = workspace_path(active)
            if not target.exists():
                # Active workspace file missing -> fall back to default
                try:
                    import logging
                    logging.getLogger(__name__).warning(
                        f"Active workspace {active!r} missing; falling back to default"
                    )
                except Exception:
                    pass
                target = workspace_path(DEFAULT_WORKSPACE_NAME)
                save_state({
                    "active_workspace": DEFAULT_WORKSPACE_NAME,
                    "workspace_order": load_state()["workspace_order"] or [DEFAULT_WORKSPACE_NAME],
                })
            self.config_path = target

        self._data: dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._data = {}
        else:
            self._data = {}
        # Migrate single-value fields to lists
        if "repos_workspace" in self._data and "repos_workspaces" not in self._data:
            old = self._data.pop("repos_workspace", "")
            self._data["repos_workspaces"] = [old] if old else []
        if "knowledge_path" in self._data and "knowledge_paths" not in self._data:
            old = self._data.pop("knowledge_path", "")
            self._data["knowledge_paths"] = [old] if old else []
        # Migrate legacy flat-list MCP command to structured shape before defaults kick in
        if "local_todo_mcp" not in self._data and "local_todo_mcp_command" in self._data:
            legacy = self._data.pop("local_todo_mcp_command")
            if isinstance(legacy, list) and legacy:
                self._data["local_todo_mcp"] = {
                    "type": "stdio",
                    "command": legacy[0], "args": list(legacy[1:]), "env": {},
                    "url": "", "headers": {},
                }
            elif isinstance(legacy, str) and legacy.strip():
                parts = legacy.strip().split()
                self._data["local_todo_mcp"] = {
                    "type": "stdio",
                    "command": parts[0], "args": parts[1:], "env": {},
                    "url": "", "headers": {},
                }
        # Derive ai_provider_order from the legacy preferred_provider when absent.
        if "ai_provider_order" not in self._data:
            pref = (self._data.get("preferred_provider") or "").strip().lower()
            if pref == "gemini":
                self._data["ai_provider_order"] = ["google", "anthropic"]
            else:  # "", "local", or anything else → Claude primary
                self._data["ai_provider_order"] = ["anthropic", "google"]

        for key, value in DEFAULT_CONFIG.items():
            if key not in self._data:
                # Copy mutable defaults so per-Config writes don't mutate DEFAULT_CONFIG
                if isinstance(value, (list, dict)):
                    self._data[key] = type(value)(value)
                else:
                    self._data[key] = value

    def save(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w") as f:
            json.dump(self._data, f, indent=2)

    def get_mh_tasks(self) -> dict:
        """Return a defensive deep copy of the `mh_tasks` block, lazily
        initialized to defaults on first read. Callers mutate the copy;
        `set_mh_tasks` is the only path that updates the persisted state.

        Applies the sprint migration once per file (idempotent, guarded on
        the presence of the `sprints` key) so existing tasks land inside an
        initial active sprint and the AI Copilot's active-sprint scope
        keeps surfacing them.
        """
        import copy as _copy
        from meeting_helper.trackers.vendors.meeting_helper_types import STATUS_ORDER
        from meeting_helper.trackers.vendors.meeting_helper_store import (
            migrate_mh_tasks_for_sprints,
        )
        block = self._data.get("mh_tasks")
        if not isinstance(block, dict):
            block = {
                "next_task_id": 1,
                "next_comment_id": 1,
                "visible_statuses": list(STATUS_ORDER),
                "tasks": [],
                "next_sprint_id": 1,
                "active_sprint_id": None,
                "sprints": [],
            }
            self._data["mh_tasks"] = block
        else:
            # Persist the migration on the first read that mutates the block.
            # Without this, a crash between read and the next set_mh_tasks
            # would lose the sprint binding and re-run the migration on the
            # next launch, double-creating Sprint 1.
            had_sprints = isinstance(block.get("sprints"), list)
            migrate_mh_tasks_for_sprints(block)
            if not had_sprints:
                self.save()
        return _copy.deepcopy(block)

    def set_mh_tasks(self, value: dict) -> None:
        """Replace the `mh_tasks` block atomically and persist."""
        self._data["mh_tasks"] = value
        self.save()

    @property
    def anthropic_api_key(self) -> str:
        return (self._data.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")).strip()

    @anthropic_api_key.setter
    def anthropic_api_key(self, value: str) -> None:
        self._data["anthropic_api_key"] = value

    @property
    def google_api_key(self) -> str:
        return (self._data.get("google_api_key") or os.environ.get("GOOGLE_API_KEY", "")).strip()

    @google_api_key.setter
    def google_api_key(self, value: str) -> None:
        self._data["google_api_key"] = value

    @property
    def deepgram_api_key(self) -> str:
        return self._data.get("deepgram_api_key", "").strip()

    @deepgram_api_key.setter
    def deepgram_api_key(self, value: str) -> None:
        self._data["deepgram_api_key"] = value

    @property
    def port(self) -> int:
        """The port the daemon binds to / the GUI connects to.

        Reads the user-configured port from the workspace JSON and applies
        `_PORT_OFFSET` (non-zero only in TEST_MODE). The offset is *view-only* —
        never written back. Callers must not round-trip through the setter
        (`cfg.port = cfg.port`) because the setter expects the raw, un-offset
        value the user originally entered.
        """
        return int(self._data.get("port", 7891)) + _PORT_OFFSET

    @port.setter
    def port(self, value: int) -> None:
        """Store a raw port (no `_PORT_OFFSET`). The getter applies the offset
        at read time. Callers should pass the user's intended port (e.g. from
        the setup wizard), never the offset-applied value returned by the getter.
        """
        self._data["port"] = int(value)

    @property
    def recordings_dir(self) -> Path:
        return Path(self._data["recordings_dir"]).expanduser()

    @recordings_dir.setter
    def recordings_dir(self, value: Path | str) -> None:
        self._data["recordings_dir"] = str(value)

    def is_favorite(self, filename: str) -> bool:
        return filename in self._data.get("favorites", [])

    def add_favorite(self, filename: str) -> None:
        favs = self._data.setdefault("favorites", [])
        if filename not in favs:
            favs.append(filename)
        self.save()

    def remove_favorite(self, filename: str) -> None:
        favs = self._data.get("favorites", [])
        if filename in favs:
            favs.remove(filename)
        self.save()

    @property
    def kb_artifacts(self) -> list[str]:
        return list(self._data.get("kb_artifacts", []))

    @kb_artifacts.setter
    def kb_artifacts(self, value: list[str]) -> None:
        self._data["kb_artifacts"] = list(value)

    def is_kb(self, filename: str) -> bool:
        return filename in self._data.get("kb_artifacts", [])

    def add_kb(self, filename: str) -> None:
        items = self._data.setdefault("kb_artifacts", [])
        if filename not in items:
            items.append(filename)
        self.save()

    def remove_kb(self, filename: str) -> None:
        items = self._data.get("kb_artifacts", [])
        if filename in items:
            items.remove(filename)
        self.save()

    @property
    def auto_summarize_on_end(self) -> bool:
        return bool(self._data.get("auto_summarize_on_end", False))

    @auto_summarize_on_end.setter
    def auto_summarize_on_end(self, value: bool) -> None:
        self._data["auto_summarize_on_end"] = bool(value)

    @property
    def auto_rename_on_end(self) -> bool:
        return bool(self._data.get("auto_rename_on_end", False))

    @auto_rename_on_end.setter
    def auto_rename_on_end(self, value: bool) -> None:
        self._data["auto_rename_on_end"] = bool(value)

    @property
    def auto_add_to_kb(self) -> bool:
        return bool(self._data.get("auto_add_to_kb", True))

    @auto_add_to_kb.setter
    def auto_add_to_kb(self, value: bool) -> None:
        self._data["auto_add_to_kb"] = bool(value)

    @property
    def deepgram_diarize_other(self) -> bool:
        return bool(self._data.get("deepgram_diarize_other", True))

    @deepgram_diarize_other.setter
    def deepgram_diarize_other(self, value: bool) -> None:
        self._data["deepgram_diarize_other"] = bool(value)

    @property
    def deepgram_diarize_self(self) -> bool:
        return bool(self._data.get("deepgram_diarize_self", False))

    @deepgram_diarize_self.setter
    def deepgram_diarize_self(self, value: bool) -> None:
        self._data["deepgram_diarize_self"] = bool(value)

    @property
    def auto_name_speakers_on_end(self) -> bool:
        return bool(self._data.get("auto_name_speakers_on_end", True))

    @auto_name_speakers_on_end.setter
    def auto_name_speakers_on_end(self, value: bool) -> None:
        self._data["auto_name_speakers_on_end"] = bool(value)

    @property
    def user_display_name(self) -> str:
        return str(self._data.get("user_display_name", "") or "").strip()

    @user_display_name.setter
    def user_display_name(self, value: str) -> None:
        self._data["user_display_name"] = str(value or "").strip()

    @property
    def kb_max_results(self) -> int:
        return int(self._data.get("kb_max_results", 3))

    @kb_max_results.setter
    def kb_max_results(self, value: int) -> None:
        self._data["kb_max_results"] = int(value)

    @property
    def sentence_window(self) -> int:
        return int(self._data.get("sentence_window", 5))

    @sentence_window.setter
    def sentence_window(self, value: int) -> None:
        self._data["sentence_window"] = value

    @property
    def max_history_turns(self) -> int:
        return int(self._data.get("max_history_turns", 5))

    @max_history_turns.setter
    def max_history_turns(self, value: int) -> None:
        self._data["max_history_turns"] = value

    @property
    def claude_model(self) -> str:
        alias = self._data.get("claude_model", "sonnet")
        return CLAUDE_MODELS.get(alias, alias)

    @claude_model.setter
    def claude_model(self, value: str) -> None:
        # Disk stores the ALIAS so the model can be renamed on the table
        # above without rewriting every workspace file. If callers (older
        # versions of the UI, manual edits) hand us the full model id,
        # reverse-lookup the alias and store that.
        if value in CLAUDE_MODELS:
            self._data["claude_model"] = value
            return
        for alias, full_id in CLAUDE_MODELS.items():
            if full_id == value:
                self._data["claude_model"] = alias
                return
        # Unknown value: store as-is so the caller can debug, but the
        # `claude_model` getter will surface it verbatim (no resolution).
        self._data["claude_model"] = value

    @property
    def gemini_model(self) -> str:
        alias = self._data.get("gemini_model", "flash")
        return GEMINI_MODELS.get(alias, alias)

    @gemini_model.setter
    def gemini_model(self, value: str) -> None:
        # See `claude_model.setter` — same alias-vs-full-id normalisation.
        if value in GEMINI_MODELS:
            self._data["gemini_model"] = value
            return
        for alias, full_id in GEMINI_MODELS.items():
            if full_id == value:
                self._data["gemini_model"] = alias
                return
        self._data["gemini_model"] = value

    @property
    def max_tokens(self) -> int:
        return int(self._data.get("max_tokens", 2048))

    @max_tokens.setter
    def max_tokens(self, value: int) -> None:
        self._data["max_tokens"] = value

    @property
    def transcription_language(self) -> str:
        return self._data.get("transcription_language", "en")

    @transcription_language.setter
    def transcription_language(self, value: str) -> None:
        self._data["transcription_language"] = value

    @property
    def silence_timeout(self) -> int:
        return int(self._data.get("silence_timeout", 30))

    @silence_timeout.setter
    def silence_timeout(self, value: int) -> None:
        self._data["silence_timeout"] = value

    @property
    def hot_moment_window_minutes(self) -> float:
        return float(self._data.get("hot_moment_window_minutes", 10.0))

    @hot_moment_window_minutes.setter
    def hot_moment_window_minutes(self, value: float) -> None:
        self._data["hot_moment_window_minutes"] = float(value)

    @property
    def proactive_answers(self) -> bool:
        return bool(self._data.get("proactive_answers", False))

    @proactive_answers.setter
    def proactive_answers(self, value: bool) -> None:
        self._data["proactive_answers"] = value

    @property
    def preferred_provider(self) -> str:
        return self._data.get("preferred_provider", "").strip()

    @preferred_provider.setter
    def preferred_provider(self, value: str) -> None:
        self._data["preferred_provider"] = value

    @property
    def ai_provider_order(self) -> list[str]:
        order = self._data.get("ai_provider_order") or ["anthropic", "google"]
        # Only known providers; preserve order; drop dups.
        seen: set[str] = set()
        out: list[str] = []
        for p in order:
            p = str(p).strip().lower()
            if p in ("anthropic", "google") and p not in seen:
                seen.add(p)
                out.append(p)
        return out or ["anthropic", "google"]

    @ai_provider_order.setter
    def ai_provider_order(self, value: list[str]) -> None:
        self._data["ai_provider_order"] = [str(p).strip().lower() for p in value]

    @property
    def ai_failover_delay_ms(self) -> int:
        try:
            v = int(self._data.get("ai_failover_delay_ms", 2000))
        except (TypeError, ValueError):
            v = 2000
        return max(0, v)

    @ai_failover_delay_ms.setter
    def ai_failover_delay_ms(self, value: int) -> None:
        self._data["ai_failover_delay_ms"] = max(0, int(value))

    @property
    def ollama_host(self) -> str:
        return self._data.get("ollama_host", "http://localhost:11434").strip()

    @ollama_host.setter
    def ollama_host(self, value: str) -> None:
        self._data["ollama_host"] = value

    @property
    def local_model(self) -> str:
        return self._data.get("local_model", "qwen2.5-coder:3b").strip()

    @local_model.setter
    def local_model(self, value: str) -> None:
        self._data["local_model"] = value

    @property
    def local_todo_mcp(self) -> dict:
        """DEPRECATED. Returns the active tracker's transport if it's a
        local_todo tracker. Removed in the next release.
        """
        self._migrate_legacy_local_todo_mcp()
        active_id = self._data.get("active_tracker_id")
        for t in self._data.get("trackers") or []:
            if t.get("id") == active_id and t.get("vendor") == "local_todo":
                tx = dict(t.get("transport") or {})
                # Normalize the shape clients expect.
                return {
                    "type": tx.get("type", "stdio"),
                    "command": tx.get("command", ""),
                    "args": list(tx.get("args", []) or []),
                    "env": dict(tx.get("env", {}) or {}),
                    "url": tx.get("url", ""),
                    "headers": dict(tx.get("headers", {}) or {}),
                }
        return {"type": "stdio", "command": "", "args": [], "env": {}, "url": "", "headers": {}}

    @local_todo_mcp.setter
    def local_todo_mcp(self, value: dict) -> None:
        if not isinstance(value, dict):
            raise ValueError("local_todo_mcp must be a dict")
        kind = (value.get("type") or "stdio").strip().lower()
        if kind not in ("stdio", "http"):
            kind = "stdio"
        self._data["local_todo_mcp"] = {
            "type": kind,
            "command": str(value.get("command", "")).strip(),
            "args": list(value.get("args", []) or []),
            "env": dict(value.get("env", {}) or {}),
            "url": str(value.get("url", "")).strip(),
            "headers": dict(value.get("headers", {}) or {}),
        }
        # Drop the legacy key on first save with new shape
        self._data.pop("local_todo_mcp_command", None)

    # ---- Home widgets --------------------------------------------------

    def _migrate_home_defaults(self) -> None:
        """One-shot: ensure `home.widgets` is a list. Idempotent.

        Triggers on missing `home`, `home: null`, OR `home.widgets: null`.
        Once `home.widgets` is a list the method short-circuits — never
        overwrites a user-customized layout.
        """
        home = self._data.get("home")
        if isinstance(home, dict) and isinstance(home.get("widgets"), list):
            return
        self._data["home"] = {"widgets": [dict(w) for w in DEFAULT_HOME_WIDGETS]}

    @property
    def home(self) -> dict:
        self._migrate_home_defaults()
        return {"widgets": list(self._data["home"]["widgets"])}

    @home.setter
    def home(self, value: dict) -> None:
        if not isinstance(value, dict) or not isinstance(value.get("widgets"), list):
            raise ValueError("home must be {'widgets': list}")
        self._data["home"] = {"widgets": list(value["widgets"])}

    # ---- Trackers (vendor-agnostic) ------------------------------------

    def _migrate_legacy_local_todo_mcp(self) -> None:
        """One-shot: legacy `local_todo_mcp` → `trackers` + `active_tracker_id`.
        Idempotent — no-op if `trackers` already exists.

        LocalTodoProfile now requires HTTP+OAuth (url field). Legacy stdio
        installs cannot be auto-converted — drop them and let the user
        re-add via Settings. Legacy HTTP installs migrate with the url.
        """
        if not isinstance(self._data.get("trackers"), list):
            legacy = self._data.get("local_todo_mcp")
            if isinstance(legacy, dict):
                import uuid
                kind = (legacy.get("type") or "").strip().lower()
                if kind not in ("stdio", "http"):
                    kind = "http" if (legacy.get("url") or "").strip() else "stdio"
                if kind == "http" and (legacy.get("url") or "").strip():
                    tid = f"lt-{uuid.uuid4().hex[:8]}"
                    url = str(legacy["url"]).strip()
                    headers = dict(legacy.get("headers", {}) or {})
                    self._data["trackers"] = [{
                        "id": tid,
                        "vendor": "local_todo",
                        "label": "Local Todo",
                        "transport": {"type": "http", "url": url, "headers": headers},
                        "auth_values": {"url": url},
                        "secret_keys": [],
                    }]
                    self._data["active_tracker_id"] = tid
                else:
                    self._data["trackers"] = []
                    self._data["active_tracker_id"] = None
                self._data.pop("local_todo_mcp", None)
                self._data.pop("local_todo_mcp_command", None)

        # Phase D additions:
        #   1. Promote active_tracker_id → copilot_tracker_id (keep alias).
        #   2. Ensure every tracker entry has chat_enabled (default True;
        #      preserve explicit False).
        if isinstance(self._data.get("trackers"), list):
            if (
                self._data.get("copilot_tracker_id") in (None, "")
                and isinstance(self._data.get("active_tracker_id"), str)
            ):
                self._data["copilot_tracker_id"] = self._data["active_tracker_id"]
            for t in self._data["trackers"]:
                if "chat_enabled" not in t:
                    t["chat_enabled"] = True

    @property
    def trackers(self) -> list[dict]:
        self._migrate_legacy_local_todo_mcp()
        return list(self._data.get("trackers") or [])

    @trackers.setter
    def trackers(self, value: list[dict]) -> None:
        if not isinstance(value, list):
            raise ValueError("trackers must be a list")
        self._data["trackers"] = list(value)
        # Drop the legacy key the first time we write the new shape.
        self._data.pop("local_todo_mcp", None)
        self._data.pop("local_todo_mcp_command", None)

    @property
    def active_tracker_id(self) -> str | None:
        """Alias for copilot_tracker_id. Kept for one release so an older
        daemon reading the JSON still finds its expected key."""
        self._migrate_legacy_local_todo_mcp()
        return self._data.get("copilot_tracker_id") or self._data.get("active_tracker_id") or None

    @active_tracker_id.setter
    def active_tracker_id(self, value: str | None) -> None:
        v = value or None
        self._data["copilot_tracker_id"] = v
        self._data["active_tracker_id"] = v  # keep alias in sync

    @property
    def copilot_tracker_id(self) -> str | None:
        self._migrate_legacy_local_todo_mcp()
        return self._data.get("copilot_tracker_id") or None

    @copilot_tracker_id.setter
    def copilot_tracker_id(self, value: str | None) -> None:
        v = value or None
        self._data["copilot_tracker_id"] = v
        self._data["active_tracker_id"] = v  # keep alias in sync

    @property
    def local_todo_mcp_command(self) -> list[str]:
        """Back-compat: flat list form, only valid for stdio."""
        cfg = self.local_todo_mcp
        if cfg.get("type") != "stdio" or not cfg.get("command"):
            return []
        return [cfg["command"], *cfg["args"]]

    @property
    def preferred_transcriber(self) -> str:
        return self._data.get("preferred_transcriber", "").strip()

    @preferred_transcriber.setter
    def preferred_transcriber(self, value: str) -> None:
        self._data["preferred_transcriber"] = value

    @property
    def whisper_host(self) -> str:
        return self._data.get("whisper_host", "").strip()

    @whisper_host.setter
    def whisper_host(self, value: str) -> None:
        self._data["whisper_host"] = value

    @property
    def auto_start_record(self) -> bool:
        return bool(self._data.get("auto_start_record", True))

    @auto_start_record.setter
    def auto_start_record(self, value: bool) -> None:
        self._data["auto_start_record"] = value

    @property
    def show_menubar_icon(self) -> bool:
        return bool(self._data.get("show_menubar_icon", True))

    @show_menubar_icon.setter
    def show_menubar_icon(self, value: bool) -> None:
        self._data["show_menubar_icon"] = value

    @property
    def menubar_icon(self) -> str:
        return self._data.get("menubar_icon", "MH")

    @menubar_icon.setter
    def menubar_icon(self, value: str) -> None:
        self._data["menubar_icon"] = value

    @property
    def local_todo_configured(self) -> bool:
        """DEPRECATED — use `bool(active_tracker_id)` going forward."""
        return bool(self.active_tracker_id)

    @property
    def provider_configured(self) -> bool:
        """True iff the WORKSPACE explicitly opts into an AI provider.

        Reads `_data` directly — does NOT fall back to env vars. Env-var
        fallback in the API-key getters is intentional for the runtime
        path (so calls still work in workspaces that DO want AI but
        store keys in env), but it leaks visibility intent here:
        a workspace with empty `anthropic_api_key` but `ANTHROPIC_API_KEY`
        in the user's shell would otherwise show AI controls against the
        workspace's stated intent. Keep visibility scoped to workspace
        config.

        Claude / Gemini / Local: any one of an explicit anthropic_api_key,
        google_api_key, or `preferred_provider == "local"` counts.
        """
        if (self._data.get("anthropic_api_key") or "").strip():
            return True
        if (self._data.get("google_api_key") or "").strip():
            return True
        if (self._data.get("preferred_provider") or "").strip().lower() == "local":
            return True
        return False

    @property
    def web_search_provider(self) -> str | None:
        v = self._data.get("web_search_provider")
        return v if isinstance(v, str) and v else None

    @web_search_provider.setter
    def web_search_provider(self, value: str | None) -> None:
        self._data["web_search_provider"] = value or None

    @property
    def web_search_api_key(self) -> str | None:
        v = self._data.get("web_search_api_key")
        return v if isinstance(v, str) and v else None

    @web_search_api_key.setter
    def web_search_api_key(self, value: str | None) -> None:
        self._data["web_search_api_key"] = value or None

    @property
    def copilot_instructions(self) -> str:
        return str(self._data.get("copilot_instructions", "") or "")

    @copilot_instructions.setter
    def copilot_instructions(self, value: str) -> None:
        self._data["copilot_instructions"] = str(value or "")

    @property
    def copilot_learned_memory(self) -> list[dict]:
        v = self._data.get("copilot_learned_memory", [])
        return list(v) if isinstance(v, list) else []

    @copilot_learned_memory.setter
    def copilot_learned_memory(self, value: list[dict]) -> None:
        self._data["copilot_learned_memory"] = list(value or [])

    @property
    def action_items_extract_after_meeting(self) -> bool:
        return bool(self._data.get("action_items_extract_after_meeting", False))

    @action_items_extract_after_meeting.setter
    def action_items_extract_after_meeting(self, value: bool) -> None:
        self._data["action_items_extract_after_meeting"] = bool(value)

    @property
    def action_items_inject_into_copilot(self) -> bool:
        return bool(self._data.get("action_items_inject_into_copilot", True))

    @action_items_inject_into_copilot.setter
    def action_items_inject_into_copilot(self, value: bool) -> None:
        self._data["action_items_inject_into_copilot"] = bool(value)

    @property
    def setup_complete(self) -> bool:
        return self._data.get("setup_complete", False)

    @setup_complete.setter
    def setup_complete(self, value: bool) -> None:
        self._data["setup_complete"] = value

    @property
    def workspace_name(self) -> str:
        """The on-disk workspace filename stem (e.g. ``"Personal"`` for
        ``Personal.json``). Used as the keychain account namespace for OAuth
        secrets and as the ``oauth_workspace`` argument when the chat
        passthrough lazy-builds Tracker sessions. AppConfig also carries this
        as a plain field for the runtime snapshot; this property keeps the
        file-backed Config addressable the same way."""
        return self.config_path.stem

    def to_app_config(self) -> AppConfig:
        """Build runtime AppConfig.

        The repos/knowledge always-loaded context layer was removed in
        Phase 2 of "Learn From Conversations"; the agent now learns from
        past meeting summaries / Notes via `kb_artifacts` instead.
        """
        from meeting_helper.ai.prompts import build_system_prompt

        system_prompt = build_system_prompt("")

        return AppConfig(
            anthropic_api_key=self.anthropic_api_key,
            deepgram_api_key=self.deepgram_api_key,
            deepgram_diarize_other=self.deepgram_diarize_other,
            deepgram_diarize_self=self.deepgram_diarize_self,
            port=self.port,
            recordings_dir=self.recordings_dir,
            sentence_window=self.sentence_window,
            max_history_turns=self.max_history_turns,
            claude_model=self.claude_model,
            claude_model_alias=_resolve_alias(
                self._data.get("claude_model", "sonnet"), CLAUDE_MODELS, default="sonnet",
            ),
            gemini_model=self.gemini_model,
            gemini_model_alias=_resolve_alias(
                self._data.get("gemini_model", "flash"), GEMINI_MODELS, default="flash",
            ),
            google_api_key=self.google_api_key,
            max_tokens=self.max_tokens,
            transcription_language=self.transcription_language,
            silence_timeout=self.silence_timeout,
            hot_moment_window_minutes=self.hot_moment_window_minutes,
            proactive_answers=self.proactive_answers,
            preferred_provider=self.preferred_provider,
            ai_provider_order=self.ai_provider_order,
            ai_failover_delay_ms=self.ai_failover_delay_ms,
            ollama_host=self.ollama_host,
            local_model=self.local_model,
            preferred_transcriber=self.preferred_transcriber,
            whisper_host=self.whisper_host,
            auto_start_record=self.auto_start_record,
            system_prompt=system_prompt,
            local_todo_mcp=dict(self.local_todo_mcp),
            kb_artifacts=list(self.kb_artifacts),
            kb_max_results=self.kb_max_results,
            auto_summarize_on_end=self.auto_summarize_on_end,
            auto_rename_on_end=self.auto_rename_on_end,
            auto_add_to_kb=self.auto_add_to_kb,
            auto_name_speakers_on_end=self.auto_name_speakers_on_end,
            user_display_name=self.user_display_name,
            web_search_provider=self.web_search_provider,
            web_search_api_key=self.web_search_api_key,
            trackers=list(self.trackers),
            active_tracker_id=self.copilot_tracker_id,
            copilot_tracker_id=self.copilot_tracker_id,
            workspace_name=self.config_path.stem,
            copilot_instructions=self.copilot_instructions,
            copilot_learned_memory=list(self.copilot_learned_memory),
            action_items_extract_after_meeting=self.action_items_extract_after_meeting,
            action_items_inject_into_copilot=self.action_items_inject_into_copilot,
        )

    def __getitem__(self, key: str) -> Any:
        return self._data.get(key, DEFAULT_CONFIG.get(key))

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value


@dataclass
class AppConfig:
    """Immutable runtime config used by the daemon."""

    anthropic_api_key: str = ""
    google_api_key: str = ""
    deepgram_api_key: str = ""
    deepgram_diarize_other: bool = True
    deepgram_diarize_self: bool = False
    port: int = 7891
    recordings_dir: Path = field(default_factory=lambda: Path.home() / "meetings")
    kb_artifacts: list[str] = field(default_factory=list)
    kb_max_results: int = 3
    auto_summarize_on_end: bool = False
    auto_rename_on_end: bool = False
    auto_add_to_kb: bool = True
    auto_name_speakers_on_end: bool = True
    user_display_name: str = ""
    sentence_window: int = 5
    max_history_turns: int = 5
    claude_model: str = "claude-sonnet-4-6"
    claude_model_alias: str = "sonnet"
    gemini_model: str = "gemini-2.5-flash"
    gemini_model_alias: str = "flash"
    max_tokens: int = 2048
    transcription_language: str = "en"
    silence_timeout: int = 30
    hot_moment_window_minutes: float = 10.0
    proactive_answers: bool = False
    preferred_provider: str = ""
    ai_provider_order: list[str] = field(default_factory=lambda: ["anthropic", "google"])
    ai_failover_delay_ms: int = 2000
    ollama_host: str = "http://localhost:11434"
    local_model: str = "qwen2.5-coder:3b"
    preferred_transcriber: str = ""
    whisper_host: str = ""
    auto_start_record: bool = True
    auto_install_app: bool = True
    system_prompt: str = ""
    local_todo_mcp: dict = field(default_factory=lambda: {
        "type": "stdio", "command": "", "args": [], "env": {},
        "url": "", "headers": {},
    })
    web_search_provider: str | None = None     # "brave" | "tavily" | None
    web_search_api_key: str | None = None
    trackers: list[dict] = field(default_factory=list)
    active_tracker_id: str | None = None   # back-compat alias for copilot_tracker_id
    copilot_tracker_id: str | None = None
    workspace_name: str = ""
    copilot_instructions: str = ""
    copilot_learned_memory: list[dict] = field(default_factory=list)
    action_items_extract_after_meeting: bool = False
    action_items_inject_into_copilot: bool = True

    @property
    def local_todo_mcp_command(self) -> list[str]:
        """Back-compat: flat list form, only valid for stdio."""
        cfg = self.local_todo_mcp or {}
        if cfg.get("type", "stdio") != "stdio" or not cfg.get("command"):
            return []
        return [cfg["command"], *list(cfg.get("args", []) or [])]

    # The /provider GET handler reads these from whichever config the daemon
    # holds in `request.app["config"]` — which is an AppConfig at runtime,
    # not a Config. Keep the two surfaces in sync so the readiness flags
    # work without per-call attribute checks.
    @property
    def local_todo_configured(self) -> bool:
        """DEPRECATED alias — true iff any tracker (any vendor) is active.
        The Brief panel + topic picker still read this gate; new code should
        use `bool(self.active_tracker_id)` directly."""
        if self.active_tracker_id:
            return True
        # Pre-migration back-compat for workspaces still using legacy block.
        cfg = self.local_todo_mcp or {}
        if (cfg.get("type") or "").strip().lower() == "http":
            return bool((cfg.get("url") or "").strip())
        return bool((cfg.get("command") or "").strip())

    @property
    def provider_configured(self) -> bool:
        if (self.anthropic_api_key or "").strip():
            return True
        if (self.google_api_key or "").strip():
            return True
        if (self.preferred_provider or "").strip().lower() == "local":
            return True
        return False


# Global config instance (lazy loaded)
_config: Config | None = None


def get_config(reload: bool = False, workspace: str | None = None) -> Config:
    """Get the cached active-workspace Config, OR a fresh peek for `workspace`.

    - No `workspace` arg: returns the cached global, loading it on first call.
    - With `workspace`: ALWAYS returns a fresh Config for that workspace
      (does NOT replace the cached global). Use this for read-only peeks.
    """
    global _config
    if workspace is not None:
        return Config(workspace=workspace)
    if _config is None:
        _config = Config()
    elif reload:
        _config.load()
    return _config


def require_setup(f):
    """Decorator: ensures config directories exist."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        config = get_config()
        config.recordings_dir.mkdir(parents=True, exist_ok=True)
        return f(*args, **kwargs)
    return wrapper
