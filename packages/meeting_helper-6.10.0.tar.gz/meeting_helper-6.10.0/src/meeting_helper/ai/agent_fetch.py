"""Agent-driven 'fetch active topics' for Copilot.

Today's Copilot pre-loads a list of likely-relevant tickets ('sprint
tickets') from the active tracker before each meeting question. That list
used to come from hardcoded vendor profile methods (`active_sprint_tasks`)
which fail against real cloud MCP servers because every vendor uses
different tool names.

This module replaces those structured calls with a one-shot LLM agent
loop that:
  - introspects the active tracker's MCP tools at runtime
  - reads the user's `copilot_instructions` (free-form workspace context)
  - reads `copilot_learned_memory` (facts the agent itself has discovered)
  - calls whatever MCP tools it needs to fetch the relevant items
  - returns a normalized list[dict] in the same shape Copilot already
    consumes (`state.sprint_tickets`)
  - emits `remember` tool calls to record reusable facts (project keys,
    cloudIds, field IDs, JQL templates) so the next run is faster

Hard cap on tool cycles (~10) so a confused agent can't burn budget.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

logger = logging.getLogger(__name__)


# What the agent is expected to produce on success.
_SYSTEM_PROMPT = """You are a meeting prep assistant. Your job: fetch the user's most relevant active work items from their task tracker so they can be referenced in the upcoming meeting.

You have access to the user's tracker via `mcp.*` tools (listed in your tool surface). They wrap whatever MCP server the user is connected to (Jira, Notion, Linear, GitHub Projects, Trello, local-todo, etc.). Read each tool's schema; don't guess.

You have a `remember` tool. After you've successfully fetched items, use it to record CONCISE FACTS that will make the next run faster:
  - vendor IDs (cloudId, workspace IDs, database IDs, team IDs)
  - project keys
  - field names / IDs (e.g. "Atlassian sprint field is customfield_10020")
  - JQL / filter templates that worked
  - the user's account ID / email (if you discovered it via *userInfo)
DO NOT save:
  - secrets, tokens, full PII
  - per-ticket data (titles, descriptions, statuses — those change)
  - hypotheses or things you weren't sure about

Process (follow EXACTLY — do not vary the structure between runs):
  1. **Read memory BEFORE making any tool call.** Memory is YOUR record of what worked last run. Scan for:
       - Tool call recipes — e.g. `Open query: search_tasks(board_id=1)` or `Open items JQL: project = MH AND sprint in openSprints() ORDER BY updated DESC`
       - Resolved vendor IDs (cloudId, workspace_id, board_id, team_id, sprint id)
       - Field names (`customfield_*`, status taxonomy)

     **DECISION RULE — read this carefully:**
       - If memory has a recipe for the OPEN-items query → call that EXACT tool with those EXACT args. Don't re-list boards, don't re-look-up cloudId, don't choose a different filter. The whole point of memory is to skip discovery on every run after the first.
       - If memory has a recipe for the DONE-items query → same thing.
       - If memory is empty or doesn't have a recipe → do discovery FOR THIS RUN ONLY, then in step 4 save the EXACT tool call you ended up using (tool name + arg dict) so the next run replays it.
       - If a saved recipe failed (returned no items when you expected some, or errored) → mark it failed in memory and run a new query.

     **Consistency contract:** two consecutive runs with no instruction change MUST return the same items in the same order. If they don't, you didn't follow this rule.
  2. Fetch the user's work items. Be inclusive — the goal is to show EVERYTHING the user might reference in the meeting, not a filtered short-list:
      (a) ALL OPEN items in the current sprint / iteration / active board view. Don't filter by specific status names — different vendors use different taxonomies (Jira may have "To Do / In Progress / In Review / Blocked"; Notion may use "Not started / In progress / Waiting"; Linear uses workflow states; local-todo uses board columns). Fetch every item whose status is NOT a terminal/closed state, and let the user decide what's relevant.
      (b) RECENTLY-COMPLETED items closed within the last ~7 days. Cap ~5 items.

     **PREFER BULK QUERIES OVER INDIVIDUAL FETCHES (HARD RULE).** A single bulk query returns 20+ items in one network round-trip; N individual fetches cost N × ~500ms. Use the vendor's bulk read tool with the fields you need (title, status, priority, assignee, sprint, parent, updated):
       - Jira: `searchJiraIssuesUsingJql` with `fields=summary,status,priority,assignee,parent,sprint,updated` — fetches every matching issue at once. **Do NOT call `getJiraIssue` once per ticket** unless you've already done the bulk search and need additional fields for ONE specific issue.
       - Notion: `notion-query-data-sources` / `notion-search` with filter on status, returning the page set in one call.
       - Linear: `searchIssues` with a state filter, not per-issue lookups.
       - local-todo: `list_boards` → `search_tasks(board_id=…)` returns all tasks for that board at once.
     If you find yourself about to issue more than 2 individual-item fetches in a row, STOP and use the bulk tool instead. Subtasks/children also bulk-fetch via JQL `parent in (KEY-1, KEY-2, ...)` — one query, not N.

     If you don't know what the open vs closed statuses are for this tracker, look them up FIRST (e.g. fetch the workflow / status list / board columns) and remember them via `remember`. Then issue the read query.

     Mix both queries' results into a single `items` list. Map each item's vendor-native status to `status_kind` ∈ {todo, in_progress, done} — but DO NOT drop items based on status_kind. Caps: ~15 open + ~5 done = ~20 total. Two runs with the same instructions + memory MUST produce the same item set; pick deterministic ordering (e.g. sort by updated-desc).

  **Completeness contract (HARD RULE):** count the rows your read tool returned. Your emitted `items` array MUST contain one entry for EVERY row the tool gave you back (you may add more for subtasks). If the tool returned 7 rows and you emit 5, you are filtering — that is a bug. Re-emit the missing ones. Do NOT decide a `To Do` ticket is "stale" or "not relevant" — that is the user's call to make, not yours. Even an empty/skeleton row is better than dropping it.

  **Sanity check before emitting:** look at the items list. If the user's actual work has many `To Do` / `Backlog` items but your list only contains items you decided were "active enough", your query was too narrow OR you dropped rows — broaden the query AND emit every row.
  3. **For any parent issue / epic that has children** (Jira subtasks, Notion sub-pages, Linear sub-issues), fetch up to 5 of them via the vendor's tool (e.g. `searchJiraIssuesUsingJql` with `parent = MH-5`, or Notion's child block list) and put them in the `subtasks` field of the parent. This is REQUIRED, not optional, when children exist.
  4. Save what just worked via `remember` — write it as a directly-replayable recipe so the NEXT run can copy it verbatim. Examples of good entries:
       - `Open items JQL: project = MH AND sprint in openSprints() ORDER BY updated DESC` (use as-is on the next searchJiraIssuesUsingJql call)
       - `Done items JQL: project = MH AND status = Done AND resolved >= -7d`
       - `cloudId for victorsoares1207.atlassian.net = 7436dd9b-...`
       - `Local-todo active board = 12, sprint id = 17`
     Don't save the same fact twice (memory is shown above; check before writing).
     Don't save per-ticket data — those change between runs.
  5. Emit your FINAL MESSAGE — see format below.

# FINAL MESSAGE FORMAT — STRICT

Your final message (after all tool calls finish) MUST be a single JSON object and NOTHING ELSE. No preamble, no explanation, no markdown fences, no commentary. Just the JSON, starting with `{` and ending with `}`. The system parses your final message with `json.loads`.

The JSON shape:
```
{"items": [
  {
    "id": "<vendor-native id, e.g. MH-42 or page UUID>",
    "title": "<short title>",
    "status": "<vendor-native status text>",
    "status_kind": "todo" | "in_progress" | "done",  // "done" allowed for recently-completed items (closed ~7 days)
    "body_md": "<markdown body or short summary, <= 600 chars — keep tight, this is meeting context not a full description>",
    "workspace_id": "<board/project/db id>",
    "workspace_name": "<friendly name>",
    "sprint_name": "<sprint or iteration name, or empty>",
    "url": "<vendor URL to open the item>",
    "subtasks": [],  // populate with up to 3 child items (Jira subtasks, Notion sub-pages, Linear sub-issues) if the parent has children
    "recent_comments": []  // OMIT or leave empty unless a comment in the last 7 days names a blocker, decision, or open question; in that case include at most 2 entries
  },
  ...
]}
```

**Output budget: keep the JSON tight.** Cycle-4 emission is the single biggest cost in this whole run — every character you emit takes time. Skip fields you don't need (empty arrays are fine), trim `body_md` aggressively (don't paste the entire ticket description — summarise in one or two lines), and don't include `recent_comments` unless they materially help the meeting.

If you cannot find any active items, return exactly `{"items": []}`. Never hallucinate items.

If a tool fails or returns an error, retry once with corrected arguments. If it still fails, skip that tool — do NOT abort the whole run. Return whatever items you CAN find. An empty items list is fine; conversational prose is NOT.
"""


_NOISE_KEYS = ("title", "examples", "default", "$comment", "$id", "deprecated",
               "readOnly", "writeOnly", "format", "contentMediaType",
               "contentEncoding")


def _trim_text(text: str | None, limit: int) -> str:
    s = (text or "").strip()
    if len(s) <= limit:
        return s
    return s[: limit - 1].rstrip() + "…"


def _trim_schema(node: Any, *, depth_left: int) -> Any:
    """Recursively shrink a JSON Schema for tool-surface budget purposes.

    The MCP server's schemas often nest deep (custom_fields → string → maxLength
    → etc.) and carry long descriptions. The LLM mostly needs to know what
    arg names exist and their top-level types; the rest costs tokens without
    helping. We:
      - drop noise keys (`examples`, `default`, etc.)
      - truncate every `description` to 120 chars
      - cap recursion at `depth_left` levels — beyond that, replace nested
        objects with `{"type": "object"}` and arrays with `{"type": "array"}`
      - truncate `enum` lists to 8 entries
    """
    if isinstance(node, dict):
        if depth_left <= 0:
            t = node.get("type")
            if isinstance(t, str):
                return {"type": t}
            return {}
        out: dict[str, Any] = {}
        for k, v in node.items():
            if k in _NOISE_KEYS:
                continue
            if k == "description" and isinstance(v, str):
                out[k] = _trim_text(v, 120)
            elif k == "enum" and isinstance(v, list) and len(v) > 8:
                out[k] = v[:8] + ["…"]
            else:
                out[k] = _trim_schema(v, depth_left=depth_left - 1)
        return out
    if isinstance(node, list):
        return [_trim_schema(x, depth_left=depth_left - 1) for x in node]
    return node


def _build_user_prompt(instructions: str, memory: list[dict]) -> str:
    parts = []
    parts.append("Workspace instructions (user-written):")
    parts.append(instructions or "(none — agent must discover what's relevant)")
    parts.append("")
    parts.append("Things you've learned previously (agent memory):")
    if memory:
        for m in memory[-30:]:  # keep prompt small
            parts.append(f"- {m.get('text', '')}")
    else:
        parts.append("(no memory yet — your first run for this workspace)")
    parts.append("")
    parts.append("Fetch the user's active items now and return the JSON.")
    return "\n".join(parts)


async def fetch_active_topics(
    *,
    tracker: Any,
    config: Any,           # AppConfig with copilot_instructions
    disk: Any | None = None,   # file-backed Config for writing learned memory
    workspace_name: str = "",
) -> list[dict]:
    """Run the agent loop. Returns a list[dict] in Task-like shape.
    Falls back to empty list (logged) on any error.
    """
    if tracker is None:
        return []

    from meeting_helper.chat.providers import ClaudeProvider, GeminiProvider
    from meeting_helper.chat.agent_loop import run_agent
    from meeting_helper.chat.registry import Registry, Tool
    from meeting_helper.chat.tools.mcp_passthrough import build_mcp_passthrough_tools

    # SLIM REGISTRY — only what's needed for "find active tickets":
    #   - mcp.* passthrough tools from the active tracker, read-only ones
    #   - `remember` (added below)
    # We deliberately SKIP the chat agent's helper tools (library, memory,
    # web_search, skills). Each tool ships its JSON Schema to the LLM; for
    # local-todo's 50+ tools the chat helpers pushed the prompt past the
    # 200K-token Anthropic limit (`prompt is too long`). Trimming to the
    # minimum keeps the agent under the cap and focused.
    registry = Registry()
    mcp_tools = await build_mcp_passthrough_tools(tracker)
    # Short-circuit when the tracker explicitly signals needs_reauth.
    # Without this, the LLM agent runs for ~7s with zero MCP tools and
    # emits "I don't have access to the right tools" prose — better to
    # return empty immediately so brief_handler reads
    # `tracker_needs_reauth` and surfaces a clean error. We don't gate on
    # `not mcp_tools` alone — a tracker can legitimately expose zero tools
    # (older test stubs, vendors mid-rollout) and the agent should still
    # try with the `remember` helper.
    # Strict equality on `True`: MagicMock auto-truthifies any attribute,
    # so `if getattr(...)` would short-circuit every test that stubs the
    # tracker. The production flag is a plain bool set by `_redirect`.
    if getattr(tracker, "_needs_reauth_signaled", False) is True:
        logger.info("agent_fetch: tracker flagged needs_reauth — skipping agent run")
        return []
    candidates: list = []
    for tool in mcp_tools:
        if getattr(tool, "is_mutation", False):
            continue
        # Whitelist read/discovery tool name patterns. Local-todo + Notion
        # MCPs expose lots of read-shaped tools (list_*, get_*, query_*,
        # search_*) plus admin tools (members, invitations, custom fields).
        # The agent only needs read-shaped ones to fetch active items.
        bare = tool.name.replace("mcp.", "", 1).lower()
        if not any(bare.startswith(prefix) for prefix in (
            "list_", "get_", "search_", "query_", "find_", "read_",
            "fetch_", "describe_", "atlassianuserinfo",  # Atlassian quirks
            "getaccessible", "getjira", "searchjira",
            "getconfluence", "searchconfluence", "getpages",
            "notion-",
        )):
            continue
        # Aggressively trim every tool's schema to keep total budget low.
        slim_tool = type(tool)(
            name=tool.name,
            description=_trim_text(tool.description, 120),
            input_schema=_trim_schema(tool.input_schema, depth_left=2),
            run=tool.run,
            is_mutation=tool.is_mutation,
        )
        candidates.append(slim_tool)
    # Hard cap on tool count + per-tool byte cap. Anthropic's 200K limit
    # gets eaten fast with 40+ tool schemas. Keep the most compact first.
    candidates.sort(key=lambda t: len(json.dumps(t.input_schema or {})))
    selected: list = []
    budget = 0
    BUDGET_BYTES = 40_000  # ~10K tokens of tool surface
    for tool in candidates:
        size = len(json.dumps({
            "name": tool.name,
            "description": tool.description or "",
            "input_schema": tool.input_schema or {},
        }))
        if budget + size > BUDGET_BYTES:
            logger.info("agent_fetch: skip %s (%d bytes; budget %d/%d)",
                        tool.name, size, budget, BUDGET_BYTES)
            continue
        selected.append(tool)
        budget += size
        if len(selected) >= 25:
            break
    for tool in selected:
        registry.register(tool)
    logger.info(
        "agent_fetch: registered %d/%d tracker tools (budget %d bytes ≈ %d tokens)",
        len(selected), len(mcp_tools), budget, budget // 4,
    )

    # Add a `remember` tool that appends to the workspace's learned memory.
    # NOTE: deliberately NOT named `memory_add` — the ClaudeProvider rewrites
    # `memory.add` → `memory_add` for Anthropic's tool-name regex (no dots
    # allowed), so a sibling `memory_add` here collides with the chat-side
    # `memory.add` once both are serialized for the API. `remember` is the
    # Copilot's private workspace-memory tool and doesn't overlap with the
    # chat agent's long-term memory tools.
    learned: list[dict] = list(getattr(config, "copilot_learned_memory", []) or [])
    # Code-side dedup. The prompt asks the agent to skip already-saved facts,
    # but LLMs reliably write near-duplicates anyway ("Sprint 15 active" /
    # "Sprint 15 ('Sprint 2') active" / "Sprint 15 is active"). Memory bloats
    # to 50 mostly-identical entries within a few runs. We hash on a
    # normalised lowercase+stripped form so trivial wording variants collapse.
    def _norm(text: str) -> str:
        import re as _re
        return _re.sub(r"[\s\W]+", " ", text.lower()).strip()

    _seen_norms = {_norm(m.get("text", "")) for m in learned}

    async def _remember(args: dict, _ctx) -> dict:
        text = str(args.get("text", "")).strip()
        if not text:
            return {"status": "error", "error": "text required"}
        norm = _norm(text)
        if not norm:
            return {"status": "skipped", "reason": "empty after normalisation"}
        if norm in _seen_norms:
            return {"status": "skipped", "reason": "duplicate — already in memory"}
        # Light fuzz check — drop if ≥60% of the words overlap with anything
        # already saved. Observed in practice that an LLM re-saving the same
        # workspace fact across runs rephrases just enough to dodge an 85%
        # threshold (introductory words, punctuation, synonyms). 60% is
        # aggressive enough to catch "Grepr board_id=1, sprint 15 active" /
        # "Grepr workspace board=1, active sprint 15" while still letting a
        # genuinely new fact through.
        new_words = set(norm.split())
        for existing in _seen_norms:
            existing_words = set(existing.split())
            if not new_words or not existing_words:
                continue
            overlap = len(new_words & existing_words) / min(len(new_words), len(existing_words))
            if overlap >= 0.60:
                return {"status": "skipped", "reason": "near-duplicate of existing memory"}
        entry = {"at": time.time(), "text": text[:500], "source": "agent"}
        learned.append(entry)
        _seen_norms.add(norm)
        return {"status": "ok"}

    registry.register(Tool(
        name="remember",
        description=(
            "Save a CONCISE fact about this workspace that will make future "
            "Copilot runs faster (project keys, vendor IDs, field names, "
            "JQL templates). Max 500 chars. Don't save secrets, per-ticket "
            "data, or anything that changes day-to-day."
        ),
        input_schema={
            "type": "object",
            "properties": {"text": {"type": "string"}},
            "required": ["text"],
        },
        run=_remember,
        is_mutation=False,
    ))

    # Pick the same provider chat uses.
    preferred = (getattr(config, "preferred_provider", "") or "claude").lower()
    if preferred == "gemini" and getattr(config, "google_api_key", None):
        provider = GeminiProvider(
            api_key=config.google_api_key,
            model=getattr(config, "gemini_model", "flash"),
        )
    elif getattr(config, "anthropic_api_key", None):
        provider = ClaudeProvider(
            api_key=config.anthropic_api_key,
            model=getattr(config, "claude_model", "haiku"),
            # ~20 enriched items in JSON easily blows past the chat default
            # of 4096 tokens; the FINAL MESSAGE then arrives truncated and
            # our parser drops the whole reply. 8K gives ~6K item-payload
            # bytes which is enough for our caps (15 open + 5 done + small
            # subtask arrays). Haiku 4.5 supports up to 8192 output tokens.
            max_tokens=8192,
        )
    else:
        logger.warning("agent_fetch: no AI provider configured — returning empty")
        return []

    instructions = getattr(config, "copilot_instructions", "") or ""
    user_msg = _build_user_prompt(instructions, learned)
    # Visibility into whether memory is actually being reused run-to-run.
    # The "5 cycles every time" smell can be answered by reading this log:
    # if learned is empty or only generic entries, the agent will rediscover
    # tools every run regardless of how many times it has run before.
    if learned:
        sample = "; ".join(
            _trim_text(m.get("text", ""), 80) for m in learned[-5:]
        )
        logger.info(
            "agent_fetch: memory loaded — %d entries (last 5: %s)",
            len(learned), sample,
        )
    else:
        logger.info("agent_fetch: memory empty — full discovery this run")

    async def _on_chunk(_text): pass
    async def _on_tool_call(name, args):
        # Approve everything — this is an internal background fetch, not chat.
        return None
    async def _on_tool_result(_name, _result): pass

    import time as _time
    fetch_t0 = _time.monotonic()
    try:
        out = await asyncio.wait_for(
            run_agent(
                system=_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
                registry=registry,
                provider=provider,
                on_chunk=_on_chunk,
                on_tool_call=_on_tool_call,
                on_tool_result=_on_tool_result,
                ctx={
                    "config": config,
                    "tracker": tracker,
                    "local_todo": tracker,  # back-compat key
                },
                max_cycles=20,
            ),
            timeout=120.0,
        )
    except asyncio.TimeoutError:
        logger.warning("agent_fetch: timed out after 120s (elapsed=%dms)",
                       int((_time.monotonic() - fetch_t0) * 1000))
        return []
    except (Exception, BaseExceptionGroup) as exc:
        # BaseExceptionGroup case: an MCP tool call (not just list_tools)
        # that trips InteractiveOAuthRequired during the agent run is wrapped
        # by anyio's TaskGroup together with a GeneratorExit cleanup error.
        # Without catching BaseExceptionGroup here, the agent-run OAuth
        # failure escapes upward and brief/topics hang silently.
        logger.warning("agent_fetch: run_agent failed after %dms: %s",
                       int((_time.monotonic() - fetch_t0) * 1000), exc)
        return []

    agent_ms = int((_time.monotonic() - fetch_t0) * 1000)
    text = (out.get("text") or "").strip()
    parse_t0 = _time.monotonic()
    items = _parse_items(text)
    parse_ms = int((_time.monotonic() - parse_t0) * 1000)
    logger.info(
        "agent_fetch: TOTAL %dms (run_agent=%dms parse=%dms items=%d)",
        int((_time.monotonic() - fetch_t0) * 1000),
        agent_ms, parse_ms, len(items),
    )

    # Persist learned memory on disk (if we have a writable Config).
    if disk is not None and learned:
        try:
            new_memory = (getattr(disk, "copilot_learned_memory", []) or []) + [
                m for m in learned
                if m not in (getattr(disk, "copilot_learned_memory", []) or [])
            ]
            # Cap to last 50 entries.
            disk.copilot_learned_memory = new_memory[-50:]
            disk.save()
        except Exception as exc:
            logger.warning("agent_fetch: failed to persist learned memory: %s", exc)

    return items


def _parse_items(text: str) -> list[dict]:
    """Pull `{"items": [...]}` from the agent's final reply.

    Tolerant: tries direct JSON first, then strips markdown fences, then
    looks for the deepest `{...}` substring containing `"items"`. Chatty
    preamble is common even with strict prompts.
    """
    import re

    # 1. Direct JSON.
    try:
        obj = json.loads(text)
        if isinstance(obj, dict) and isinstance(obj.get("items"), list):
            return _flatten_subtasks([_normalize_item(i) for i in obj["items"]])
    except Exception:
        pass

    # 2. Strip markdown code fences (```json ... ``` or ``` ... ```).
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if fenced:
        try:
            obj = json.loads(fenced.group(1))
            if isinstance(obj, dict) and isinstance(obj.get("items"), list):
                return _flatten_subtasks([_normalize_item(i) for i in obj["items"]])
        except Exception:
            pass

    # 3. Find the LAST `{...}` block containing `"items"` — agents tend to
    #    narrate first and emit the answer last. Use brace-counting so we
    #    don't choke on nested objects in item bodies.
    candidates: list[str] = []
    for start in [m.start() for m in re.finditer(r"\{", text)]:
        depth = 0
        for i in range(start, len(text)):
            ch = text[i]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start:i + 1]
                    if '"items"' in candidate:
                        candidates.append(candidate)
                    break
    for candidate in reversed(candidates):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict) and isinstance(obj.get("items"), list):
                items = [_normalize_item(i) for i in obj["items"]]
                return _flatten_subtasks(items)
        except Exception:
            continue

    logger.warning("agent_fetch: could not parse items from agent reply: %r", text[:400])
    return []


def _flatten_subtasks(items: list[dict]) -> list[dict]:
    """Promote each parent's subtasks to top-level items.

    The user's instructions say "subtasks are very important, fetch them too"
    but Jira's `sprint in openSprints()` JQL only returns parents (subtasks
    inherit sprint membership through the parent and don't show up at top
    level). The agent's prompt tells it to put children inside each parent's
    `subtasks` field, which is great for context — but the Topics card,
    topic picker, and Brief backfill all read top-level items by id. If
    MH-13 only lives nested inside MH-4, the picker can't pick it, the UI
    can't list it, and Brief's "find card by id" backfill misses it (which
    is exactly what the log showed: `card_id MH-13 not in agent-fetched
    items; skipping`).

    This fix promotes each subtask to its own top-level item while keeping
    the parent's `subtasks` list intact so the Brief LLM still sees the
    hierarchy. The promoted item gains a `parent_id` / `parent_title`
    pointer so callers can render the relationship.
    """
    out: list[dict] = []
    seen_ids: set[str] = set()
    for parent in items:
        if not isinstance(parent, dict):
            continue
        pid = parent.get("id", "")
        if pid and pid not in seen_ids:
            seen_ids.add(pid)
            out.append(parent)
        for sub in parent.get("subtasks") or []:
            if not isinstance(sub, dict):
                continue
            sid = sub.get("id") or sub.get("key") or ""
            if not sid or sid in seen_ids:
                continue
            seen_ids.add(sid)
            child = _normalize_item(sub)
            child["parent_id"] = pid
            child["parent_title"] = parent.get("title", "")
            # Inherit sprint/workspace metadata from the parent when the
            # subtask record didn't carry it (often the case for nested
            # Jira responses).
            if not child.get("workspace_id"):
                child["workspace_id"] = parent.get("workspace_id", "")
                child["board_id"] = parent.get("workspace_id", "")
            if not child.get("workspace_name"):
                child["workspace_name"] = parent.get("workspace_name", "")
                child["board_name"] = parent.get("workspace_name", "")
            if not child.get("sprint_name"):
                child["sprint_name"] = parent.get("sprint_name", "")
            out.append(child)
    return out


def _normalize_item(raw: dict) -> dict:
    """Coerce an agent-emitted item into the dict shape Copilot expects."""
    if not isinstance(raw, dict):
        return {}
    sk = (raw.get("status_kind") or "todo").lower()
    if sk not in ("todo", "in_progress", "done"):
        sk = "todo"
    return {
        "id": str(raw.get("id") or ""),
        "title": str(raw.get("title") or ""),
        "status": str(raw.get("status") or ""),
        "status_kind": sk,
        "priority": raw.get("priority"),
        "body_md": str(raw.get("body_md") or "")[:1500],
        "workspace_id": str(raw.get("workspace_id") or ""),
        "workspace_name": str(raw.get("workspace_name") or ""),
        "board_id": str(raw.get("workspace_id") or ""),       # legacy back-compat
        "board_name": str(raw.get("workspace_name") or ""),   # legacy back-compat
        "sprint_name": str(raw.get("sprint_name") or ""),
        "url": raw.get("url"),
        "subtasks": list(raw.get("subtasks") or []),
        "subtasks_summary": raw.get("subtasks_summary") or {},
        "recent_comments": list(raw.get("recent_comments") or []),
        "recent_history": list(raw.get("recent_history") or []),
        "linked_docs": list(raw.get("linked_docs") or []),
    }
