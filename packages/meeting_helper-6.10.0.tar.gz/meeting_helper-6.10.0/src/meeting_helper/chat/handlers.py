"""HTTP handlers for /chat/* CRUD."""
from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from pathlib import Path
from typing import Any

from aiohttp import web

from meeting_helper.chat import (
    paths as chat_paths,
    state as chat_state,
    store as chat_store,
)
from meeting_helper.chat.registry import Registry

logger = logging.getLogger(__name__)


def _resolve_chat_disk(request: web.Request):
    """Resolve the file-backed Config for the chat tools' ctx dict.

    Mirrors `meeting_helper.server.routes._resolve_disk`: prefer the app's
    registered `disk_factory` (live workspace switch support) and fall back
    to the in-memory shim when no factory is wired (tests). Chat tools that
    need to read/write workspace JSON (like the action_items orphan file)
    pull `ctx["disk"]` and assume it has `config_path`.
    """
    factory = request.app.get("disk_factory")
    if factory is not None:
        try:
            return factory()
        except Exception:
            logger.warning(
                "_resolve_chat_disk: disk_factory raised; falling back to shim",
                exc_info=True,
            )
    from meeting_helper.trackers.shim import InMemoryDiskShim
    # Older tests stand up the chat handler without wiring `config` into the
    # aiohttp app. Fall back to the in-memory shim with a minimal app-config
    # stand-in so the chat tools that read `disk.config_path` still resolve.
    return InMemoryDiskShim(request.app.get("config"))

# Per-reference content cap. Eight thousand characters covers most summaries
# verbatim and roughly the first ~20 minutes of a verbose transcript before
# the agent has to ask for `library.get_meeting`. Truncating in the helper
# keeps a chatty user from blowing the provider's context window by dumping
# three full meetings into a single turn.
_REFERENCE_CONTENT_CAP = 8000

# `[kind:id:title]` — title may contain anything except `]`. The id is
# constrained to the characters our library uses (filename-safe + dots) so
# stray `]` in a user message doesn't accidentally match.
_REFERENCE_TOKEN_RE = re.compile(
    r"\[(meeting|note|kb):([A-Za-z0-9._\-]+):([^\]]*)\]"
)


def _truncate(text: str, cap: int = _REFERENCE_CONTENT_CAP) -> str:
    """Trim ``text`` to ``cap`` chars with a trailing ellipsis when cut."""
    if not text:
        return ""
    if len(text) <= cap:
        return text
    return text[:cap].rstrip() + "\n…"


def _load_meeting_reference(item_id: str, cfg) -> tuple[str, str] | None:
    """Return (display_title, body) for a meeting reference or ``None``.

    Body prefers the summary; falls back to the transcript; finally the
    live captions. Audio is never inlined — it's not text.
    """
    rec_dir = Path(cfg.recordings_dir).expanduser()
    summary_path = rec_dir / f"{item_id}.summary.txt"
    transcript_path = rec_dir / f"{item_id}.transcript.txt"
    live_path = rec_dir / f"{item_id}.live.txt"
    parts: list[str] = []
    title = item_id
    try:
        from meeting_helper.library_retrieval import _parse_meeting_stem
        _, parsed_title = _parse_meeting_stem(item_id)
        if parsed_title:
            title = parsed_title
    except Exception:
        pass
    if summary_path.is_file():
        try:
            parts.append("Summary:\n" + summary_path.read_text(errors="ignore"))
        except OSError:
            pass
    transcript_or_live = transcript_path if transcript_path.is_file() else (
        live_path if live_path.is_file() else None
    )
    if transcript_or_live is not None:
        try:
            label = "Transcript" if transcript_or_live == transcript_path else "Live captions"
            parts.append(f"{label}:\n" + transcript_or_live.read_text(errors="ignore"))
        except OSError:
            pass
    if not parts:
        return None
    return title, "\n\n".join(parts)


def _load_note_reference(item_id: str, cfg) -> tuple[str, str] | None:
    rec_dir = Path(cfg.recordings_dir).expanduser()
    filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
    path = rec_dir / filename
    if not path.is_file():
        return None
    try:
        body = path.read_text(errors="ignore")
    except OSError:
        return None
    title = filename[: -len(".note.md")].replace("-", " ")
    return title, body


def _load_kb_reference(item_id: str, cfg) -> tuple[str, str] | None:
    try:
        from meeting_helper.library_retrieval import load_artifacts
    except Exception:
        return None
    rec_dir = Path(cfg.recordings_dir).expanduser()
    try:
        cards = load_artifacts(recordings_dir=rec_dir, kb_filenames=[item_id])
    except Exception:
        return None
    if not cards:
        return None
    card = cards[0]
    return card.title or item_id, card.body or ""


def expand_chat_references(text: str, cfg) -> str:
    """Replace `[meeting:ID:Title]` / `[note:..]` / `[kb:..]` tokens inline.

    Each token expands to a ``[Reference: Kind "Title"] ... [/Reference]`` block
    so the model can see the referenced content alongside the user's message.
    Missing files / unparseable ids fall back to a one-line stub so the agent
    knows the user intended to reference something even when the file can't
    be loaded. Content is truncated at ``_REFERENCE_CONTENT_CAP`` chars per
    reference to keep the prompt bounded.
    """
    if not text or "[" not in text:
        return text

    def _expand(match: "re.Match[str]") -> str:
        kind = match.group(1)
        item_id = match.group(2)
        token_title = match.group(3)
        loader = {
            "meeting": _load_meeting_reference,
            "note": _load_note_reference,
            "kb": _load_kb_reference,
        }.get(kind)
        if loader is None:
            return match.group(0)
        try:
            loaded = loader(item_id, cfg)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("reference expansion failed for %s:%s — %s", kind, item_id, exc)
            loaded = None
        if loaded is None:
            return (
                f'[Reference: {kind.capitalize()} "{token_title or item_id}"]\n'
                f"(content unavailable — file missing or unreadable)\n"
                f"[/Reference]"
            )
        title, body = loaded
        display_title = token_title or title or item_id
        body = _truncate(body)
        return (
            f'[Reference: {kind.capitalize()} "{display_title}"]\n'
            f"{body}\n"
            f"[/Reference]"
        )

    return _REFERENCE_TOKEN_RE.sub(_expand, text)


def _build_registry() -> Registry:
    """Return the static tool registry — non-local-todo tools only.

    Local-todo tools are added dynamically by :func:`_build_registry_async`
    via the MCP passthrough (``mcp.*``). This sync version is kept for
    backwards compat (tests monkeypatch it) and is used as the seed by
    the async version.
    """
    from meeting_helper.chat.tools.meeting_live import (
        build_meeting_live_tool,
        build_meeting_full_transcript_tool,
    )
    from meeting_helper.chat.tools.library import (
        build_library_search_meetings,
        build_library_list_recent,
        build_library_get_meeting,
        build_library_fetch_kb,
        build_library_get_note,
    )
    from meeting_helper.chat.tools.web_search import build_web_search
    from meeting_helper.chat.tools.memory import (
        build_memory_read,
        build_memory_add,
        build_memory_update,
        build_memory_delete,
    )
    from meeting_helper.chat.tools.skills import build_skills_create
    from meeting_helper.chat.tools.action_items import (
        build_complete_action_item,
        build_create_action_item,
        build_delete_action_item,
        build_list_action_items,
        build_update_action_item,
    )
    from meeting_helper.chat.tools.topic import (
        build_topic_pin,
        build_topic_unpin,
        build_topic_clear,
    )
    from meeting_helper.chat.tools.notes import (
        build_notes_list,
        build_notes_get,
        build_notes_create,
        build_notes_update,
        build_notes_delete,
        build_notes_set_kb,
    )

    reg = Registry()
    for builder in (
        build_meeting_live_tool,
        build_meeting_full_transcript_tool,
        build_library_search_meetings,
        build_library_list_recent,
        build_library_get_meeting,
        build_library_fetch_kb,
        build_library_get_note,
        build_web_search,
        build_memory_read,
        build_memory_add,
        build_memory_update,
        build_memory_delete,
        build_skills_create,
        build_list_action_items,
        build_create_action_item,
        build_update_action_item,
        build_complete_action_item,
        build_delete_action_item,
        build_topic_pin,
        build_topic_unpin,
        build_topic_clear,
        build_notes_list,
        build_notes_get,
        build_notes_create,
        build_notes_update,
        build_notes_delete,
        build_notes_set_kb,
    ):
        reg.register(builder())
    return reg


async def _build_registry_async(app_state, cfg=None) -> Registry:
    """Build the full registry: static tools + dynamic multi-tracker MCP passthrough.

    The passthrough enumerates every chat-enabled tracker's MCP at call
    time and registers each server-side tool under ``<slug>__<tool>``, so
    the agent reaches the full surface (tickets, sprints, docs, board
    admin, custom fields, members, …) across all chat-enabled trackers.
    Mutations are marked by name prefix so the existing approval gate
    engages.

    If MCP introspection fails or the registry isn't yet built, returns
    only the static tools — the daemon stays usable.
    """
    from meeting_helper.chat.tools.mcp_passthrough import build_mcp_passthrough_tools_multi

    reg = _build_registry()
    registry = getattr(app_state, "trackers", None) if app_state is not None else None
    # Chat sees every chat-enabled tracker. cfg.workspace_name is the keychain
    # scope for OAuth session boot via ensure_session.
    extras = await build_mcp_passthrough_tools_multi(
        registry, cfg, workspace_name=getattr(cfg, "workspace_name", "") or "",
    )
    for tool in extras:
        reg.register(tool)
    return reg


def _build_provider(cfg, *, provider_override: str | None = None, model_override: str | None = None):
    """Return a streaming provider for the active config.

    ``provider_override`` / ``model_override`` let a single chat thread
    pin its own AI choice without changing the workspace defaults. Either
    can be None to inherit the workspace value.
    """
    from meeting_helper.chat.providers import (
        ClaudeProvider,
        GeminiProvider,
        NoToolsProvider,
    )
    preferred = (provider_override or getattr(cfg, "preferred_provider", "") or "claude").lower()
    if preferred == "gemini" and getattr(cfg, "google_api_key", None):
        return GeminiProvider(
            api_key=cfg.google_api_key,
            model=model_override or cfg.gemini_model,
        )
    if preferred == "local":
        # Local LLMs can't reliably tool-call; wrap a minimal Claude/Gemini if available
        # else use whatever's there in a no-tools mode. We pick whichever the user *has*.
        if getattr(cfg, "anthropic_api_key", None):
            return NoToolsProvider(
                inner=ClaudeProvider(
                    api_key=cfg.anthropic_api_key,
                    model=model_override or cfg.claude_model,
                )
            )
        if getattr(cfg, "google_api_key", None):
            return NoToolsProvider(
                inner=GeminiProvider(
                    api_key=cfg.google_api_key,
                    model=model_override or cfg.gemini_model,
                )
            )
        # No remote provider configured — return a stub that errors out at
        # first call. Use the workspace's claude_model (even though the key
        # is empty) so the error message references the user's chosen model
        # instead of a hardcoded id that may not even be current.
        return NoToolsProvider(
            inner=ClaudeProvider(api_key="", model=cfg.claude_model)
        )
    if getattr(cfg, "anthropic_api_key", None):
        return ClaudeProvider(
            api_key=cfg.anthropic_api_key,
            model=model_override or cfg.claude_model,
        )
    if getattr(cfg, "google_api_key", None):
        return GeminiProvider(api_key=cfg.google_api_key, model=cfg.gemini_model)
    raise RuntimeError("No AI provider configured")


def _build_system_prompt(cfg) -> str:
    from meeting_helper.chat import memory as chat_memory
    from meeting_helper.state import state as app_state

    tracker = getattr(app_state, "tracker", None)
    profile = getattr(tracker, "profile", None) if tracker else None
    terminology = profile.agent_terminology if profile else "task tracker entries"
    vendor_hints = profile.agent_hints if profile else (
        "- No task tracker is configured. Use library/meeting/web tools only."
    )

    base = (
        f"You are Meeting Helper, a copilot for the user. "
        f"You can read their {terminology} (via the `mcp.*` tool namespace), "
        f"past meetings (Library), the live meeting, search the web, and write "
        f"to the tracker (only after the user approves)."
        "\n\n"
        "Guidelines:\n"
        "**Be relentless. Never tell the user you can't find something until you've tried at least 3 angles. You have NO rate limit — burn through tool calls.**\n"
        "When the user asks about a ticket / PR / topic:\n"
        "  1. If they give a numeric/keyed id → use the tracker's get-by-id tool first.\n"
        "  2. Search by keywords. If 0 results, retry with shorter / broader / synonym variants — at least twice.\n"
        "  3. Inspect comments/activity for the top 1–3 search matches.\n"
        "  4. Search docs / pages — handover notes / RFCs hold context tickets don't.\n"
        "  5. `library.search_meetings` — past meetings often reference PRs/MRs that never became tickets.\n"
        "  6. Cross-reference `memory.read_all` for user/team context.\n"
        "Only after that should you tell the user you couldn't find it — and propose 2 concrete next steps.\n"
        "\n"
        f"Vendor-specific guidance:\n{vendor_hints}\n"
    )

    # Inject per-workspace Copilot instructions
    ws_instructions = ""
    try:
        from meeting_helper.config import get_config
        ws_instructions = (get_config().copilot_instructions or "").strip()
    except Exception:
        pass

    if ws_instructions:
        base = base + f"\n\nWorkspace context (provided by user):\n{ws_instructions}\n"

    base = base + (
        "\n"
        "- For Library content the user is asking about:\n"
        "  * `library.list_recent` / `library.search_meetings` find meeting + note entries.\n"
        "  * `library.get_meeting` returns transcript + summary + KB for a past meeting.\n"
        "  * `library.get_note` returns the body of a standalone Note (rows with kind=note).\n"
        "  * `library.fetch_kb` returns one KB entry by id.\n"
        "- For the LIVE meeting (when session_active is true):\n"
        "  * `meeting.live` — last 60s of transcript + current topic (cheap, prefer this for \"what was just said\").\n"
        "  * `meeting.full_transcript` — entire transcript since meeting start (use for \"summarise the meeting so far\" or \"did we talk about X earlier\").\n"
        "\n"
        "Tool-use rules:\n"
        "- The `mcp.*` namespace exposes tracker tools verbatim with their native JSON Schema. Inspect each tool's description and arguments before calling. Read the schema; don't guess field names.\n"
        "- 'Last meeting' / 'recent meeting' → `library.list_recent` first, then `library.get_meeting`.\n"
        "- All write tools in the `mcp.*` namespace (anything starting with create_/update_/delete_/add_/move_/start_/close_/remove_/revoke_/reorder_/rename_/replace_/favorite_) wait for user approval; your call is paused until they decide.\n"
        "- You have long-term memory shown above — read it, add durable facts with `memory.add`, update/delete stale ones. Don't log ephemeral chat.\n"
        "- Be concise. Prefer linking to a specific ticket/meeting over restating it in full.\n"
        "\n"
        "Linking to in-app content (markdown links navigate inside the app):\n"
        "- Past meeting → `[<title>](/library/?id=<meeting_id>&kind=meeting)`. The `id` is the `id` field on rows returned by `library.list_recent` / `library.search_meetings` / `library.get_meeting`.\n"
        "- Standalone note → `[<title>](/library/?id=<note_id>&kind=note)`. Use the same `id` field (rows with `kind: 'note'`).\n"
        "- Library tool results already include a ready-to-use `url` for each row — prefer that verbatim over building your own.\n"
        "- Use the path as shown (relative, with the leading slash); don't prepend a host or protocol.\n"
        "\n"
        "Formatting (your answer is rendered as markdown in a chat UI — use the full markdown vocabulary):\n"
        "- Use `##` for major sections, `###` for subsections. Don't write flat walls of bolded labels — promote them to headings.\n"
        "- Put a BLANK LINE between paragraphs, between headings and the text under them, and between list items if any item is more than one sentence.\n"
        "- Use bullet lists (`- `) for enumerations of three or more peers. Use numbered lists for sequences/steps.\n"
        "- Use `**bold**` for the field NAME at the start of a key/value bullet (e.g. `- **Status:** in review`). Use `` `inline code` `` for IDs, file paths, commit shas, ticket refs.\n"
        "- For long answers (≥3 topics), open with a one-sentence summary, then a `## Topics` section listing them, then one `### Topic name` block per topic with its details.\n"
        "- Don't add a closing `Would you like more details on...?` unless the user is mid-decision and you genuinely need a choice from them."
    )
    return base + chat_memory.as_prompt_block()


async def threads_list_handler(request: web.Request) -> web.Response:
    return web.json_response({"threads": chat_store.read_index()})


async def threads_create_handler(request: web.Request) -> web.Response:
    body = await request.json()
    title = (body.get("title") or "").strip() or "New conversation"
    th = chat_store.create_thread(title=title)
    return web.json_response({"id": th.id, "title": th.title, "created_at": th.created_at})


async def threads_get_handler(request: web.Request) -> web.Response:
    tid = request.match_info["thread_id"]
    try:
        th = chat_store.read_thread(tid)
    except FileNotFoundError:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response(th.to_dict())


async def threads_rename_handler(request: web.Request) -> web.Response:
    tid = request.match_info["thread_id"]
    body = await request.json()
    title = (body.get("title") or "").strip()
    if not title:
        return web.json_response({"error": "title required"}, status=400)
    try:
        chat_store.rename_thread(tid, title)
    except FileNotFoundError:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response({"ok": True})


async def threads_delete_handler(request: web.Request) -> web.Response:
    tid = request.match_info["thread_id"]
    chat_store.delete_thread(tid)
    cur = chat_state.read_state().get("active_thread_id")
    if cur == tid:
        chat_state.set_active(None)
    return web.json_response({"ok": True})


async def threads_model_handler(request: web.Request) -> web.Response:
    """POST /chat/threads/{id}/model — pin or clear the thread's AI choice.

    Body: ``{ "provider": "claude"|"gemini"|"local"|null, "model": "..."|null }``.
    Either field can be null to inherit the workspace default. The
    daemon-side message handler reads these fields when building the
    provider for each subsequent turn — older turns in the thread are
    not retroactively re-run.
    """
    tid = request.match_info["thread_id"]
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    provider = body.get("provider")
    model = body.get("model")
    if provider is not None and not isinstance(provider, str):
        return web.json_response({"error": "provider must be string or null"}, status=400)
    if model is not None and not isinstance(model, str):
        return web.json_response({"error": "model must be string or null"}, status=400)
    try:
        th = chat_store.set_thread_model(
            tid,
            provider=provider.strip() if provider else None,
            model=model.strip() if model else None,
        )
    except FileNotFoundError:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response({
        "ok": True,
        "id": th.id,
        "provider": th.provider,
        "model": th.model,
    })


async def state_get_handler(request: web.Request) -> web.Response:
    return web.json_response(chat_state.read_state())


async def state_set_handler(request: web.Request) -> web.Response:
    body = await request.json()
    chat_state.set_active(body.get("active_thread_id"))
    return web.json_response({"ok": True})


async def messages_post_handler(request: web.Request) -> web.Response:
    from meeting_helper.chat.agent_loop import run_agent
    from meeting_helper.chat.events import chat_event
    from meeting_helper.config import get_config
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state as app_state

    tid = request.match_info["thread_id"]
    body = await request.json()
    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    try:
        th = chat_store.read_thread(tid)
    except FileNotFoundError:
        return web.json_response({"error": "not_found"}, status=404)

    user_turn = chat_store.append_turn(tid, role="user", text=text)
    cfg = get_config()
    provider = _build_provider(
        cfg,
        provider_override=th.provider,
        model_override=th.model,
    )
    registry = await _build_registry_async(app_state, cfg)

    # Rebuild a provider-shaped messages list from the persisted turns
    # (just user + assistant text — tool turns are reconstructed by the loop itself).
    # User messages are expanded so any `[meeting:ID:Title]` / `[note:..]` / `[kb:..]`
    # reference tokens are replaced with inline Reference blocks before the LLM sees
    # them. The stored turn keeps the raw token so the UI chip still renders.
    msgs: list[dict[str, Any]] = []
    for t in th.turns + [user_turn]:
        if t.role == "user":
            msgs.append({
                "role": "user",
                "content": expand_chat_references(t.text or "", cfg),
            })
        elif t.role == "assistant" and t.text:
            msgs.append({"role": "assistant", "content": t.text})

    async def _run() -> None:
        assistant_turn = chat_store.append_turn(tid, role="assistant", text="")
        start = time.monotonic()
        await broadcast(chat_event(
            "chat.turn_started", thread_id=tid, turn_id=assistant_turn.id, role="assistant",
        ))

        async def on_chunk(t: str) -> None:
            await broadcast(chat_event(
                "chat.chunk", thread_id=tid, turn_id=assistant_turn.id, text=t,
            ))

        async def on_tool_call(name, args):
            tool = registry.get(name) if name in [t.name for t in registry.tools()] else None
            # Always emit `chat.tool_call` so the UI gets a chip for EVERY
            # tool invocation — including mutations. Without this, the
            # later `chat.tool_result` has no chip to attach to and the
            # user sees zero feedback for `create_task` etc.
            await broadcast(chat_event(
                "chat.tool_call",
                thread_id=tid, turn_id=assistant_turn.id,
                tool_name=name, tool_args=args,
            ))
            if tool is None or not tool.is_mutation:
                return None

            # Mutation: pause until user confirms or cancels.
            # `pending_key` MUST be unique per call. The old form
            # `f"{tid}:{turn_id}:{name}"` collided when the agent emitted
            # N consecutive calls of the same tool in a single assistant
            # turn — the frontend's auto-approve dedupe (which keys off
            # pending_key) would block calls 2..N and the daemon would
            # hang forever on the overwritten future.
            pending_key = (
                f"{tid}:{assistant_turn.id}:{name}:{uuid.uuid4().hex[:8]}"
            )
            fut = asyncio.get_running_loop().create_future()
            app_state.chat_pending_confirmations[pending_key] = fut
            await broadcast(chat_event(
                "chat.pending_confirm",
                thread_id=tid, turn_id=assistant_turn.id,
                tool_name=name, tool_args=args, pending_key=pending_key,
            ))
            try:
                decision = await fut
            finally:
                app_state.chat_pending_confirmations.pop(pending_key, None)
            return decision

        async def on_tool_result(name, result):
            await broadcast(chat_event(
                "chat.tool_result",
                thread_id=tid, turn_id=assistant_turn.id,
                tool_name=name, status=result.get("status"),
                result_summary=str(result.get("result", ""))[:200],
            ))

        try:
            out = await run_agent(
                system=_build_system_prompt(cfg),
                messages=msgs,
                registry=registry,
                provider=provider,
                on_chunk=on_chunk,
                on_tool_call=on_tool_call,
                on_tool_result=on_tool_result,
                ctx={
                    "config": cfg,
                    "disk": _resolve_chat_disk(request),
                    "app_state": app_state,
                    "tracker": getattr(app_state, "tracker", None),
                    "local_todo": getattr(app_state, "tracker", None),
                    "trackers": getattr(app_state, "trackers", None),
                    "workspace_name": getattr(cfg, "workspace_name", "") or "",
                },
            )
            error = out.get("error")
            text = out.get("text") or ""
        except Exception as exc:
            logger.exception("chat agent loop failed for thread %s", tid)
            error = str(exc)
            text = ""

        # Update the assistant turn (by id) with the final accumulated text.
        th2 = chat_store.read_thread(tid)
        for turn in th2.turns:
            if turn.id == assistant_turn.id:
                turn.text = text
                turn.latency_ms = int((time.monotonic() - start) * 1000)
                break
        chat_paths.atomic_write_json(chat_paths.thread_path(tid), th2.to_dict())
        await broadcast(chat_event(
            "chat.turn_done", thread_id=tid, turn_id=assistant_turn.id,
            latency_ms=int((time.monotonic() - start) * 1000),
            error=error,
        ))
        try:
            from meeting_helper.chat.title import maybe_generate_title
            await maybe_generate_title(tid)
        except Exception:
            pass

    asyncio.create_task(_run())
    return web.json_response({"ok": True, "user_turn_id": user_turn.id}, status=202)


async def messages_confirm_handler(request: web.Request) -> web.Response:
    from meeting_helper.state import state as app_state

    tid = request.match_info["thread_id"]
    body = await request.json()
    pending_key = body.get("pending_key")
    turn_id = body.get("turn_id")
    decision = body.get("decision")
    edited_args = body.get("edited_args")
    if decision not in ("approve", "cancel"):
        return web.json_response(
            {"error": "decision must be approve|cancel"}, status=400
        )
    if pending_key is None and turn_id:
        # Resolve by turn_id — match the first pending whose key starts with tid:turn_id.
        prefix = f"{tid}:{turn_id}:"
        candidates = [
            k for k in app_state.chat_pending_confirmations if k.startswith(prefix)
        ]
        if not candidates:
            return web.json_response(
                {"error": "no pending confirmation for that turn"}, status=404
            )
        pending_key = candidates[0]
    fut = app_state.chat_pending_confirmations.get(pending_key)
    if fut is None or fut.done():
        return web.json_response({"error": "no pending confirmation"}, status=404)
    fut.set_result({"decision": decision, "edited_args": edited_args})
    return web.json_response({"ok": True})


async def memory_list_handler(request: web.Request) -> web.Response:
    from meeting_helper.chat import memory as chat_memory
    return web.json_response({"entries": chat_memory.read_all()})


async def memory_add_handler(request: web.Request) -> web.Response:
    from meeting_helper.chat import memory as chat_memory
    body = await request.json()
    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    entry = chat_memory.add(text=text, source="user", pinned=bool(body.get("pinned", False)))
    return web.json_response(entry)


async def memory_update_handler(request: web.Request) -> web.Response:
    from meeting_helper.chat import memory as chat_memory
    mem_id = request.match_info["mem_id"]
    body = await request.json()
    entry = chat_memory.update(mem_id, text=body.get("text"), pinned=body.get("pinned"))
    if entry is None:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response(entry)


async def memory_delete_handler(request: web.Request) -> web.Response:
    from meeting_helper.chat import memory as chat_memory
    mem_id = request.match_info["mem_id"]
    ok = chat_memory.delete(mem_id)
    if not ok:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response({"ok": True})


# ---------------------------------------------------------------------------
# Skills CRUD (ticket #269) — mirrors the memory shape: list / create /
# patch / delete. Slug normalisation happens server-side so the same
# `name` typed in the Settings form and in the agent tool both end up as
# the same slash-trigger. Duplicate slugs return 409 so the UI can
# render a friendly error.
# ---------------------------------------------------------------------------

async def skills_list_handler(request: web.Request) -> web.Response:
    from meeting_helper import skills as skills_store
    return web.json_response({"entries": skills_store.list_skills()})


async def skills_create_handler(request: web.Request) -> web.Response:
    from meeting_helper import skills as skills_store
    body = await request.json()
    name = (body.get("name") or "").strip()
    desc = (body.get("description") or "").strip()
    body_text = (body.get("body") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    if not body_text:
        return web.json_response({"error": "body required"}, status=400)
    try:
        entry = skills_store.create_skill(
            name=name, description=desc, body=body_text,
        )
    except skills_store.SkillError as exc:
        return web.json_response({"error": str(exc)}, status=409)
    return web.json_response(entry)


async def skills_update_handler(request: web.Request) -> web.Response:
    from meeting_helper import skills as skills_store
    skill_id = request.match_info["skill_id"]
    body = await request.json()
    try:
        entry = skills_store.update_skill(
            skill_id,
            name=body.get("name"),
            description=body.get("description"),
            body=body.get("body"),
        )
    except skills_store.SkillError as exc:
        return web.json_response({"error": str(exc)}, status=409)
    if entry is None:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response(entry)


async def skills_delete_handler(request: web.Request) -> web.Response:
    from meeting_helper import skills as skills_store
    skill_id = request.match_info["skill_id"]
    ok = skills_store.delete_skill(skill_id)
    if not ok:
        return web.json_response({"error": "not_found"}, status=404)
    return web.json_response({"ok": True})
