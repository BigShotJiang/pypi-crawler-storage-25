"""Provider adapters — wrap Anthropic + Gemini into a unified streaming
agent-loop contract:

    async for event in provider.stream_completion(system=..., messages=..., tools=...):
        # event = {type: "chunk", text} | {type: "tool_use", id, name, input} | {type: "done"}
"""
from __future__ import annotations

from typing import Any, AsyncIterator


class ClaudeProvider:
    def __init__(self, *, api_key: str, model: str, max_tokens: int = 4096):
        from anthropic import AsyncAnthropic
        self._client = AsyncAnthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    async def stream_completion(
        self, *, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> AsyncIterator[dict[str, Any]]:
        # Anthropic enforces tool names match ^[a-zA-Z0-9_-]{1,128}$ — translate
        # dotted registry names to underscores on the wire, then map back when
        # we receive tool_use blocks so downstream consumers see the original.
        name_map_out = {t["name"]: t["name"].replace(".", "_") for t in tools}
        name_map_in = {v: k for k, v in name_map_out.items()}
        params: dict[str, Any] = {
            "model": self._model,
            "system": system,
            "messages": messages,
            "max_tokens": self._max_tokens,
        }
        if tools:
            params["tools"] = [
                {
                    "name": name_map_out[t["name"]],
                    "description": t["description"],
                    "input_schema": _to_jsonschema(t["input_schema"]),
                }
                for t in tools
            ]
        async with self._client.messages.stream(**params) as stream:
            current_tu: dict[str, Any] | None = None
            current_tu_input_acc: list[str] = []
            async for event in stream:
                etype = event.type
                if etype == "content_block_start" and event.content_block.type == "tool_use":
                    current_tu = {
                        "id": event.content_block.id,
                        "name": event.content_block.name,
                    }
                    current_tu_input_acc = []
                elif etype == "content_block_delta":
                    if event.delta.type == "text_delta":
                        yield {"type": "chunk", "text": event.delta.text}
                    elif event.delta.type == "input_json_delta" and current_tu is not None:
                        current_tu_input_acc.append(event.delta.partial_json)
                elif etype == "content_block_stop" and current_tu is not None:
                    import json as _json
                    try:
                        parsed = _json.loads("".join(current_tu_input_acc) or "{}")
                    except _json.JSONDecodeError:
                        parsed = {}
                    yield {
                        "type": "tool_use",
                        "id": current_tu["id"],
                        "name": name_map_in.get(current_tu["name"], current_tu["name"]),
                        "input": parsed,
                    }
                    current_tu = None
                    current_tu_input_acc = []
            yield {"type": "done", "stop_reason": "end_turn"}


def _to_jsonschema(schema: dict[str, Any]) -> dict[str, Any]:
    """Translate our compact schema to JSON Schema for the API.

    Compact: ``{"q": "string", "limit": "integer?"}`` → real JSON Schema
    with a `required` list. If the input is *already* a JSON Schema
    (detected by the presence of ``type == "object"`` and a ``properties``
    dict), pass it through verbatim — this is how the MCP passthrough
    tools surface their server-side schemas without round-tripping.
    """
    if isinstance(schema, dict) and schema.get("type") == "object" and isinstance(schema.get("properties"), dict):
        return schema
    properties: dict[str, Any] = {}
    required: list[str] = []
    for k, v in schema.items():
        t = v.rstrip("?")
        optional = v.endswith("?")
        properties[k] = {"type": t}
        if not optional:
            required.append(k)
    return {"type": "object", "properties": properties, "required": required}


def _sanitize_for_gemini(schema: Any) -> Any:
    """Strip JSON Schema features the Gemini SDK rejects.

    Real-world MCP tool schemas frequently use ``"type": ["string", "null"]``
    or ``["string", "number", "null"]`` for nullable / union fields (valid
    JSON Schema). Gemini's ``FunctionDeclaration`` only accepts a single
    type enum value per property, so the SDK throws a pydantic validation
    error the moment a tool with a union type is sent. We pre-walk the
    schema and:

      - collapse union types to their first non-null entry
      - drop ``oneOf`` / ``anyOf`` siblings (keep the first)
      - recurse into ``properties`` and ``items``

    Anthropic accepts the union form directly — only Gemini needs this.
    """
    if isinstance(schema, list):
        return [_sanitize_for_gemini(item) for item in schema]
    if not isinstance(schema, dict):
        return schema

    out: dict[str, Any] = {}
    for key, value in schema.items():
        if key == "type" and isinstance(value, list):
            non_null = [t for t in value if t != "null"]
            out["type"] = (non_null[0] if non_null else "string")
            continue
        if key in ("oneOf", "anyOf") and isinstance(value, list) and value:
            # Keep just the first variant. Gemini doesn't model unions.
            picked = _sanitize_for_gemini(value[0])
            if isinstance(picked, dict):
                for k2, v2 in picked.items():
                    out.setdefault(k2, v2)
            continue
        if key in ("properties", "patternProperties"):
            out[key] = {k: _sanitize_for_gemini(v) for k, v in value.items()}
            continue
        if key == "items":
            out[key] = _sanitize_for_gemini(value)
            continue
        out[key] = _sanitize_for_gemini(value) if isinstance(value, (dict, list)) else value
    return out


class GeminiProvider:
    """Streaming chat provider backed by the new ``google-genai`` SDK.

    The previous implementation imported ``google.generativeai`` (the
    deprecated legacy package, never installed by this project's
    pyproject) and the constructor blew up the moment a user picked
    Gemini in the chat picker. The rest of the codebase already uses
    ``google.genai``; this class now follows the same pattern.

    Streaming is synchronous on Gemini's side, so we shovel chunks
    through an ``asyncio.Queue`` populated by a thread-pool task —
    same trick ``ai/client.py`` uses for its non-chat Gemini path.
    """

    def __init__(self, *, api_key: str, model: str):
        # Lazy-import so the test for selection doesn't pull the SDK.
        from google import genai

        self._client = genai.Client(api_key=api_key)
        self._model_name = model

    async def stream_completion(self, *, system, messages, tools):
        import asyncio as _asyncio

        from google.genai import types as gtypes

        # Gemini's function declarations also enforce a strict name regex,
        # so translate dotted chat-registry names to underscores on the wire
        # and reverse the mapping on tool_use blocks coming back.
        name_map_out = {t["name"]: t["name"].replace(".", "_") for t in tools} if tools else {}
        name_map_in = {v: k for k, v in name_map_out.items()}
        function_declarations = [
            gtypes.FunctionDeclaration(
                name=name_map_out[t["name"]],
                description=t["description"],
                parameters=_sanitize_for_gemini(_to_jsonschema(t["input_schema"])),
            )
            for t in (tools or [])
        ]
        cfg_kwargs: dict[str, Any] = {"system_instruction": system}
        if function_declarations:
            cfg_kwargs["tools"] = [gtypes.Tool(function_declarations=function_declarations)]
        if "gemini-3" in self._model_name:
            # Mirror the legacy chat path: skip the deep "thinking" budget
            # on Gemini 3 so the first token is fast.
            cfg_kwargs["thinking_config"] = gtypes.ThinkingConfig(thinking_level="low")
        config = gtypes.GenerateContentConfig(**cfg_kwargs)

        contents = _to_gemini_contents(messages)

        loop = _asyncio.get_event_loop()
        q: _asyncio.Queue = _asyncio.Queue()
        _sentinel = object()

        def _produce() -> None:
            import time as _time
            # Gemini occasionally 503s "high demand" or 429s when the
            # project hits per-minute quota. Both are transient — a short
            # backoff almost always recovers. Retry up to 3 times before
            # surfacing.
            attempt = 0
            max_attempts = 3
            while True:
                attempt += 1
                try:
                    stream = self._client.models.generate_content_stream(
                        model=self._model_name,
                        contents=contents,
                        config=config,
                    )
                    for chunk in stream:
                        text = getattr(chunk, "text", None)
                        if text:
                            loop.call_soon_threadsafe(
                                q.put_nowait, {"type": "chunk", "text": text}
                            )
                        cands = getattr(chunk, "candidates", None) or []
                        if not cands:
                            continue
                        parts = (
                            getattr(getattr(cands[0], "content", None), "parts", None)
                            or []
                        )
                        for part in parts:
                            fc = getattr(part, "function_call", None)
                            if not fc:
                                continue
                            original = name_map_in.get(fc.name, fc.name)
                            loop.call_soon_threadsafe(
                                q.put_nowait,
                                {
                                    "type": "tool_use",
                                    "id": getattr(fc, "id", None) or fc.name,
                                    "name": original,
                                    "input": dict(fc.args or {}),
                                },
                            )
                    break  # streamed successfully
                except Exception as exc:
                    if attempt < max_attempts and _is_transient_gemini_error(exc):
                        # Exponential backoff: 1s, 2s. Caps the total wait
                        # at ~3s before we give up and surface to the user.
                        _time.sleep(2 ** (attempt - 1))
                        continue
                    loop.call_soon_threadsafe(
                        q.put_nowait, _friendly_gemini_error(exc)
                    )
                    break
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

        loop.run_in_executor(None, _produce)
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise item
            yield item
        yield {"type": "done", "stop_reason": "end_turn"}


_TRANSIENT_GEMINI_CODES = {"429", "500", "502", "503", "504"}
_TRANSIENT_GEMINI_KEYWORDS = ("unavailable", "deadline_exceeded", "internal", "rate", "overloaded")


def _is_transient_gemini_error(exc: Exception) -> bool:
    """Heuristic: should the GeminiProvider retry this call?

    The SDK surfaces a mix of ``google.genai.errors.APIError`` subclasses
    and bare exceptions depending on transport. Both expose the original
    HTTP status code in either ``code`` or the string repr. Treat 5xx and
    429 as transient; anything else (auth, validation, 404) gets surfaced
    immediately so the user can fix it.
    """
    code = str(getattr(exc, "code", "") or "")
    if code in _TRANSIENT_GEMINI_CODES:
        return True
    msg = str(exc).lower()
    if any(code_str in msg for code_str in _TRANSIENT_GEMINI_CODES):
        return True
    return any(kw in msg for kw in _TRANSIENT_GEMINI_KEYWORDS)


def _friendly_gemini_error(exc: Exception) -> Exception:
    """Replace the raw Google API exception with a user-readable one.

    The agent loop catches whatever we raise and surfaces ``str(exc)`` in
    the error bubble. Without this, the UI shows the raw response dict
    (``{'error': {'code': 503, 'message': '...', 'status': 'UNAVAILABLE'}}``)
    which is noisy and unhelpful. Pick out the meaningful bits.
    """
    msg = str(exc)
    lower = msg.lower()
    if "503" in msg or "unavailable" in lower or "overloaded" in lower:
        return RuntimeError(
            "Gemini is overloaded right now (Google's servers). Try again in a moment, "
            "or switch to Claude for this turn."
        )
    if "429" in msg or "rate" in lower or "quota" in lower:
        return RuntimeError(
            "Gemini rate limit hit. Wait a bit and retry, or switch model."
        )
    if "404" in msg or "not_found" in lower:
        return RuntimeError(
            f"Gemini model not available: {getattr(exc, 'code', '') or '404'}. "
            "Pick a different model in the picker."
        )
    if "401" in msg or "permission" in lower or "api key" in lower:
        return RuntimeError(
            "Gemini rejected the API key. Check Settings → AI Providers."
        )
    # Fall back to a trimmed version so we don't dump the whole response.
    return RuntimeError(msg[:300])


def _to_gemini_contents(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Translate Anthropic-shaped messages to Gemini parts. Coarse for v1."""
    out = []
    for m in messages:
        role = "model" if m["role"] == "assistant" else "user"
        content = m["content"]
        if isinstance(content, str):
            out.append({"role": role, "parts": [{"text": content}]})
        else:
            out.append({"role": role, "parts": [{"text": str(content)}]})
    return out


class NoToolsProvider:
    """Wraps a provider but strips the tools list so the model never tool-calls.

    Used for the local-LLM degraded mode where tool reliability is poor.
    """

    def __init__(self, *, inner):
        self._inner = inner

    async def stream_completion(self, *, system, messages, tools):
        async for ev in self._inner.stream_completion(
            system=system, messages=messages, tools=[]
        ):
            if ev["type"] == "tool_use":
                continue  # safety net — shouldn't fire
            yield ev
