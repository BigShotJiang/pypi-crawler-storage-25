"""Provider-agnostic agent loop with tool use.

The loop is generic over the *provider* and the *registry*. The caller
plugs in:
  - provider: object with `async def stream_completion(system, messages, tools)`
    yielding event dicts: {type: chunk, text} / {type: tool_use, id, name, input} / {type: done, stop_reason}
  - registry: meeting_helper.chat.registry.Registry
  - on_chunk(text): broadcast a text chunk
  - on_tool_call(name, args) -> dict | None:
       * for non-mutating tools, returns None (proceed)
       * for mutating tools, returns {decision: "approve"|"cancel", edited_args?: dict}
  - on_tool_result(name, result): broadcast the result

Hard cap on tool-use cycles to prevent runaway.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

from meeting_helper.chat.registry import Registry

logger = logging.getLogger(__name__)


OnChunk = Callable[[str], Awaitable[None]]
OnToolCall = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any] | None]]
OnToolResult = Callable[[str, dict[str, Any]], Awaitable[None]]


# Cap each tool result fed back into the conversation. ~12K chars ≈ 3K tokens.
# Enough for ~20 search hits or a hydrated ticket with comments, but stops a
# chatty `list_boards` / `searchJiraIssuesUsingJql` from eating the entire
# context budget on the next iteration.
_TOOL_RESULT_MAX_CHARS = 12_000


def _truncate_for_convo(text: str) -> str:
    """Cap a tool result's serialized text. Larger payloads get truncated
    with a clear marker so the LLM knows to narrow its query if it needs
    the rest."""
    if len(text) <= _TOOL_RESULT_MAX_CHARS:
        return text
    keep = _TOOL_RESULT_MAX_CHARS - 200
    return (
        text[:keep]
        + f"\n\n…[truncated: result was {len(text)} chars, capped at "
        + f"{_TOOL_RESULT_MAX_CHARS}. Narrow your query (smaller limit, "
        + "filter, or specific id) and call again if you need more.]"
    )


async def run_agent(
    *,
    system: str,
    messages: list[dict[str, Any]],
    registry: Registry,
    provider: Any,
    on_chunk: OnChunk,
    on_tool_call: OnToolCall,
    on_tool_result: OnToolResult,
    max_cycles: int = 30,
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any]:
    import time as _time
    ctx = ctx or {}
    text_acc: list[str] = []
    convo = list(messages)
    tools_schema = [
        {"name": t.name, "description": t.description, "input_schema": t.input_schema}
        for t in registry.tools()
    ]
    # Per-run timing — added to make the "why is Brief so slow" question
    # answerable from the log alone. Per-cycle log emits show where each
    # second goes; the final summary makes the macro picture visible too.
    run_t0 = _time.monotonic()
    total_llm_ms = 0
    total_tool_ms = 0
    total_tool_calls = 0
    for cycle in range(max_cycles + 1):
        if cycle == max_cycles:
            return {"text": "".join(text_acc), "error": "tool_cycle_limit_exceeded"}
        pending_tool_uses: list[dict[str, Any]] = []
        llm_t0 = _time.monotonic()
        chunk_chars = 0
        async for ev in provider.stream_completion(
            system=system, messages=convo, tools=tools_schema
        ):
            if ev["type"] == "chunk":
                text_acc.append(ev["text"])
                chunk_chars += len(ev["text"])
                await on_chunk(ev["text"])
            elif ev["type"] == "tool_use":
                pending_tool_uses.append(ev)
            elif ev["type"] == "done":
                break
        llm_ms = int((_time.monotonic() - llm_t0) * 1000)
        total_llm_ms += llm_ms
        if not pending_tool_uses:
            logger.info(
                "agent_loop: cycle %d — llm=%dms text=%dch (no tools, done)",
                cycle, llm_ms, chunk_chars,
            )
            logger.info(
                "agent_loop: TOTAL %dms across %d cycle(s); llm=%dms tools=%dms (%d calls)",
                int((_time.monotonic() - run_t0) * 1000), cycle + 1,
                total_llm_ms, total_tool_ms, total_tool_calls,
            )
            return {"text": "".join(text_acc), "error": None}

        tool_results = []
        registered_names = [t.name for t in registry.tools()]
        cycle_tool_ms = 0
        cycle_tool_names: list[str] = []

        # Split into mutation-and-unknown (sequential, for user-approval
        # ordering and clear inline errors) vs read-only tools (parallel via
        # asyncio.gather). The dominant agent_fetch case is 12+ getJiraIssue
        # calls in one cycle — running them concurrently cuts the wall clock
        # from sum-of-latencies to slowest-single-call, provided the
        # underlying MCP session multiplexes its JSON-RPC layer.
        async def _run_readonly(tu: dict[str, Any]) -> tuple[str, str, dict, int]:
            name, args, tu_id = tu["name"], tu["input"], tu["id"]
            tool_t0 = _time.monotonic()
            await on_tool_call(name, args)
            result = await registry.call(name, args, ctx)
            tool_ms = int((_time.monotonic() - tool_t0) * 1000)
            logger.info("agent_loop: tool %s -> %dms", name, tool_ms)
            await on_tool_result(name, result)
            return tu_id, name, result, tool_ms

        results_by_pos: dict[int, dict] = {}
        readonly_jobs: list = []
        readonly_positions: list[int] = []

        for idx, tu in enumerate(pending_tool_uses):
            name, args, tu_id = tu["name"], tu["input"], tu["id"]
            tool = registry.get(name) if name in registered_names else None
            if tool is None:
                result = {"status": "error", "error": f"unknown tool: {name}"}
                cycle_tool_names.append(f"{name}(unknown)")
                logger.info("agent_loop: tool %s -> unknown", name)
                await on_tool_result(name, result)
                results_by_pos[idx] = {"tool_use_id": tu_id, "name": name, "result": result}
            elif tool.is_mutation:
                tool_t0 = _time.monotonic()
                decision = await on_tool_call(name, args)
                if not decision or decision.get("decision") != "approve":
                    result = {"status": "cancelled"}
                else:
                    effective_args = decision.get("edited_args") or args
                    result = await registry.call(name, effective_args, ctx)
                tool_ms = int((_time.monotonic() - tool_t0) * 1000)
                cycle_tool_ms += tool_ms
                cycle_tool_names.append(f"{name}({tool_ms}ms)")
                logger.info("agent_loop: tool %s -> %dms", name, tool_ms)
                await on_tool_result(name, result)
                results_by_pos[idx] = {"tool_use_id": tu_id, "name": name, "result": result}
            else:
                readonly_jobs.append(_run_readonly(tu))
                readonly_positions.append(idx)

        if readonly_jobs:
            batch_t0 = _time.monotonic()
            completed = await asyncio.gather(*readonly_jobs)
            batch_wall_ms = int((_time.monotonic() - batch_t0) * 1000)
            batch_cpu_ms = sum(r[3] for r in completed)
            cycle_tool_ms += batch_wall_ms
            for pos, (tu_id, name, result, tool_ms) in zip(readonly_positions, completed):
                cycle_tool_names.append(f"{name}({tool_ms}ms)")
                results_by_pos[pos] = {"tool_use_id": tu_id, "name": name, "result": result}
            if len(completed) > 1 and batch_wall_ms > 0:
                logger.info(
                    "agent_loop: parallel batch — %d tools wall=%dms cpu=%dms (%.1fx)",
                    len(completed), batch_wall_ms, batch_cpu_ms,
                    batch_cpu_ms / max(1, batch_wall_ms),
                )

        # Preserve the original tool_use ordering when emitting tool_result.
        # The Anthropic API requires the assistant's tool_use blocks and the
        # user's tool_result blocks to line up by tool_use_id; the convo
        # serialization below iterates pending_tool_uses, so tool_results
        # must match that order to avoid a 400 on the next call.
        for i in range(len(pending_tool_uses)):
            tool_results.append(results_by_pos[i])
        total_tool_ms += cycle_tool_ms
        total_tool_calls += len(pending_tool_uses)
        logger.info(
            "agent_loop: cycle %d — llm=%dms text=%dch tools=%dms (%s)",
            cycle, llm_ms, chunk_chars, cycle_tool_ms, ", ".join(cycle_tool_names),
        )

        # Append the tool_use + tool_result pair to the convo for the next call.
        convo.append({
            "role": "assistant",
            "content": [
                {"type": "tool_use", "id": tu["id"], "name": tu["name"], "input": tu["input"]}
                for tu in pending_tool_uses
            ],
        })
        # Truncate fat tool results — an MCP `list_boards` or `searchJiraIssues`
        # can easily return 100K+ chars, and the entire result re-enters the
        # convo on every subsequent iteration. Anthropic counts all of it
        # against the 200K-token limit, so a single chatty tool call ends the
        # whole run with `prompt is too long`. The agent still gets enough
        # to work with for finding+filtering; deep details can be re-fetched
        # via get_task / get_issue style tools.
        convo.append({
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": r["tool_use_id"],
                    "content": _truncate_for_convo(json.dumps(r["result"])),
                }
                for r in tool_results
            ],
        })

    return {"text": "".join(text_acc), "error": None}
