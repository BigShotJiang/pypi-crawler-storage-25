CUSTOM_TABLE_FIELDS_ON_URL = """&c=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,22,78,127,128,24,25,85,26,27,28,29,30,31,32,33,34,35,36,37,
38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,57,58,59,62,63,64,65,66,67,68,69,73,74,76,77,79,80,81,82,83,84,120,130,131,132,133,134,144,145,146"""

FINVIZ_DROP_COLUMNS = ["Earnings", "52W Range", "Return% 1Y", "Index", "52W High", "52W Low"]


CUSTOM_TABLE_ALL_FIELDS_NEW = [
    'Ticker',
    'Company',
    'Sector',
    'Industry',
    'Country',
    'Market Cap',
    'P/E',
    'Forward P/E',
    'PEG',
    'P/S',
    'P/B',
    'P/C',
    'P/FCF',
    'Dividend',
    'Payout Ratio',
    'EPS',
    'EPS next Q',
    'EPS This Y',
    'EPS Next Y',
    'EPS Past 5Y',
    'EPS Next 5Y',
    'Sales Past 5Y',
    'Sales Q/Q',
    'Sales YoY TTM',
    'EPS Q/Q',
    'Sales',
    'Income',
    'EPS Surprise',
    'Revenue Surprise',
    'Outstanding',
    'Float',
    'Float %',
    'Insider Own',
    'Insider Trans',
    'Inst Own',
    'Inst Trans',
    'Short Float',
    'Short Ratio',
    'Short Interest',
    'ROA',
    'ROE',
    'ROIC',
    'Curr R',
    'Quick R',
    'LTDebt/Eq',
    'Debt/Eq',
    'Gross M',
    'Oper M',
    'Profit M',
    'Perf Week',
    'Perf Month',
    'Perf Quart',
    'Perf Half',
    'Perf Year',
    'Perf YTD',
    'Beta',
    'ATR',
    'Volatility W',
    'Volatility M',
    'SMA20',
    'SMA50',
    'SMA200',
    '52W High',
    '52W Low',
    'RSI',
    'Earnings',
    'Target Price',
    'Book/sh',
    'Cash/sh',
    'Employees',
    'Index',
    'Optionable',
    'Prev Close',
    'Shortable',
    'Recom',
    'Avg Volume',
    'Rel Volume',
    'Volume',
    'Price',
    'Change',
    'Return% 1Y',
    'Dividend TTM',
    'Dividend Ex Date',
    'EPS YoY TTM',
    '52W Range',
    'Enterprise Value',
    'EV/EBITDA',
    'EV/Sales',
]

POST_GENERATED_FIELDS = [
    '52W_NORM',
    'LTDEBT/EQ',
    'DIVIDEND_YIELD_EST',
    'DIVIDEND_YIELD_TTM',
    'IS_S&P500',
    'IS_RUSSELL',
    'IS_NASDAQ',
    'IS_AMC',
    'IS_BMO',
    'DIVIDEND_EX-DATE',
    'IS_OPTIONABLE',
    'IS_SHORTABLE',
    'VOLATILITY_RANGE',
    'IS_USA',
    'DATADATE',
]


MONEY_COLUMNS = [
    'Avg Volume', 
    'Outstanding',
    'Market Cap',
    'Enterprise Value',
    'Float',
    'Income',
    'Sales',
    'Short Interest',
    'Outstanding',
    'Float'
]

PERCENTAJE_COLUMNS = [
    'Perf Week', 
    'Perf Month', 
    'Perf Quart', 
    'Perf Year', 
    'Perf YTD', 
    'Volatility W', 
    'Volatility M', 
    'Change', 
    'Insider Own',
    'EPS Next Y',
    'EPS This Y',
    'EPS Past 5Y',
    'EPS Next 5Y',
    'Sales Past 5Y',
    'Insider Trans',
    'Inst Own',
    'Perf Quart',
    'Inst Trans',
    'Perf Half',
    'ROA',
    'ROE',
    'ROIC',
    '52W High',
    'Gross M',
    '52W Low',
    'Sales Q/Q',
    'Oper M',
    'EPS Q/Q',
    'Profit M',
    'Payout Ratio',
    'SMA20',
    'SMA50',
    'SMA200',
    'Dividend',
    'Payout Ratio',
    'EPS Surprise',
    'Revenue Surprise',
    'Float %',
    'Oper M',
    'Profit M',
    'Short Float',
    'EPS YoY TTM',
    'Sales YoY TTM',
]

NUMERIC_COLUMNS = [
    'Dividend TTM',
    'P/FCF',
    'Beta',
    'EPS YoY TTM',
    'ATR',
    'Employees',
    'Curr R',
    'Quick R',
    'RSI',
    'Debt/Eq',
    'LTDebt/Eq',
    'Recom',
    'Rel Volume',
    'Price',
    'Volume',
    'P/E',
    'Forward P/E',
    'PEG',
    'P/S',
    'Book/sh',
    'P/B',
    'Target Price',
    'Cash/sh',
    'P/C',
    'EPS next Q',
    'EPS',
    'Short Ratio',
    'Short Interest',
    'RSI',
    'Avg Volume',
    'Return% 1Y',
    'Outstanding',
    'Float',
    'ATR',
    'Prev Close',
    'EV/EBITDA',
    'EV/Sales',
]

BOOLEAN_COLUMNS = [
    'Optionable',
    'Shortable'
]

# ==============================================================
# !! WARNING: FINVIZ COLUMN RENAME MAP !!
# ==============================================================
# Finviz occasionally renames columns in their screener HTML
# without notice. When that happens:
#
#   1. Add the mapping here:  {new_finviz_name: our_internal_name}
#   2. Update CUSTOM_TABLE_ALL_FIELDS_NEW with the new Finviz name
#   3. Update the relevant processing list (NUMERIC_COLUMNS, etc.)
#      to use the new Finviz name
#
# The rename back to our internal name is applied automatically
# at the end of _process_numeric_columns() in utils.py.
# A runtime UserWarning fires if the Finviz column is all-NaN,
# which likely means Finviz renamed it AGAIN — check here first.
#
# History of renames:
#   2026-04-26: Finviz renamed "Fwd P/E" → "Forward P/E"
# ==============================================================
FINVIZ_COLUMN_RENAMES = {
    'Forward P/E': 'Fwd P/E',
}

TICKER_KEY = 'Ticker'
VALID_SCOPES_EARNING_SCOPES = [
    'last_week', 
    'this_week', 
    'next_week', 
    'today_bmo', 
    'yesterday_amc', 
    'today',
    'this_month'
]
