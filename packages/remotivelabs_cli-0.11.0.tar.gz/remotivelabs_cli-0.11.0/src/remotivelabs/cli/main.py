"""Lightweight entry point for the ``remotive`` console script.

Intercepts tab-completion requests *before* importing the full CLI
module tree.  The fast path (cache hit) uses only ``json``, so it adds
near-zero overhead on top of interpreter startup.

Handles bash, zsh, and fish by inlining the env-var parsing and output
formatting that Typer's completion classes would normally provide.

Only ``_REMOTIVE_COMPLETE=complete_<shell>`` values are served by the
fast path — that's the env var Click/Typer set when the user hits
TAB.  Any other value (e.g. ``source_bash`` emitted by
``--install-completion``) falls through to the full CLI, which Typer
handles normally.
"""

# Think before adding more imports as it will affect the completion time.
import json
import os
import sys

_COMPLETE_VAR = "_REMOTIVE_COMPLETE"

# Shells whose env-var protocol and output format are handled by the
# fast path.  Any other shell (e.g. PowerShell) must fall through to
# Typer's native completer — serving fish-formatted output to
# PowerShell would be worse than a slow response.
_SUPPORTED_SHELLS = frozenset({"bash", "zsh", "fish"})

# Bump when the on-disk cache schema changes (new/removed keys, reshaped
# nodes).  Included in the sentinel so old-format caches are rejected.
_CACHE_FORMAT_VERSION = 1


def _cache_path() -> str:
    cache_dir = os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(cache_dir, "remotivelabs", "cli", "completion_cache.json")


def _expected_sentinel() -> str:
    """
    Identity string for the installed CLI.

    Combines the package path (venv differentiation) with the package
    directory's mtime (bumped by every pip/uv install that replaces
    files inside).  Editable-install in-place edits to existing files
    do *not* bump this — run ``rm ~/.cache/remotivelabs/cli/completion_cache.json``
    after schema-changing edits during local development.
    """
    pkg_dir = os.path.dirname(__file__)
    try:
        pkg_mtime = os.stat(pkg_dir).st_mtime
    except OSError:
        pkg_mtime = 0
    return "v%d:%s:%s" % (_CACHE_FORMAT_VERSION, pkg_dir, pkg_mtime)


def load_fresh() -> dict[str, object] | None:
    """
    Read the cache and return it if the sentinel still matches, else
    ``None``.  Never raises — the fast path uses ``None`` as "fall through
    to the slow path".

    If the file exists but is unusable (corrupt JSON, wrong shape, stale
    sentinel), unlink it so the next slow-path run starts from a clean
    slate instead of re-failing the same read every tab-completion.
    """
    path = _cache_path()
    try:
        with open(path) as fh:
            tree = json.load(fh)
        if isinstance(tree, dict) and tree.get("_sentinel") == _expected_sentinel():
            return tree
    except FileNotFoundError:
        return None  # nothing to clean up
    except (ValueError, OSError):
        pass  # corrupt or unreadable — fall through to unlink

    try:
        os.remove(path)
    except OSError:
        pass
    return None


def _parse_args(shell: str) -> tuple[list[str], str]:
    """Extract (args, incomplete) from shell-set env vars.

    Bash: COMP_WORDS (space-separated) + COMP_CWORD (0-based index).
    Zsh/Fish: _TYPER_COMPLETE_ARGS (space-separated, last token is
    incomplete when string does not end with a space).
    """
    if shell == "bash":
        words = os.environ.get("COMP_WORDS", "").split()
        try:
            cword = max(0, int(os.environ.get("COMP_CWORD", "0")))
        except ValueError:
            cword = 0
        args = words[1:cword]
        incomplete = words[cword] if cword < len(words) else ""
        return args, incomplete

    # Zsh / Fish — both use _TYPER_COMPLETE_ARGS
    raw = os.environ.get("_TYPER_COMPLETE_ARGS", "")
    words = raw.split()
    args = words[1:]
    if args and not raw.endswith(" "):
        incomplete = args.pop()
    else:
        incomplete = ""
    return args, incomplete


def _complete_from_tree(tree: dict[str, object], args: list[str], incomplete: str) -> list[tuple[str, str]]:
    """Walk *tree* using *args* and return matching ``(value, help)`` pairs."""
    node: dict[str, object] = tree
    for word in args:
        child = node.get(word)
        if isinstance(child, dict):
            node = child

    if incomplete.startswith("-"):
        options = node.get("_options")
        if isinstance(options, dict):
            return [(o, h) for o, h in options.items() if o.startswith(incomplete)]
        return []

    results: list[tuple[str, str]] = []
    for n in node:
        if n.startswith("_") or not n.startswith(incomplete):
            continue
        child = node[n]
        h = child.get("_help", "") if isinstance(child, dict) else ""
        results.append((n, h))
    return results


def _format_output(shell: str, completions: list[tuple[str, str]]) -> str:
    """Format completion pairs for the target shell."""
    if shell == "bash":
        return "\n".join(v for v, _ in completions)

    if shell == "zsh":
        if not completions:
            return "_files"

        def _escape(s: str) -> str:
            return s.replace('"', '""').replace("'", "''").replace("$", "\\$").replace("`", "\\`").replace(":", r"\\:")

        items = []
        for v, h in completions:
            items.append(f'"{_escape(v)}":"{_escape(h)}"' if h else f'"{_escape(v)}"')
        return "_arguments '*: :(({}))'".format("\n".join(items))

    # Fish
    lines = []
    for v, h in completions:
        lines.append(f"{v}\t{h}" if h else v)
    return "\n".join(lines)


def _try_fast_complete(shell: str) -> tuple[int, str] | None:
    """
    Compute completions from the on-disk JSON cache.

    Returns ``(exit_code, output)`` on cache hit — the caller prints
    ``output`` (when non-empty) and exits with ``exit_code``.  Returns
    ``None`` on cache miss so the caller falls through to the slow
    path.
    """
    # Fish has a two-phase protocol: is-args (should we complete?) and
    # get-args (return completions).  Handle is-args here.
    fish_action = os.environ.get("_TYPER_COMPLETE_FISH_ACTION", "")
    if shell == "fish" and fish_action not in ("get-args", "is-args"):
        return None

    tree = load_fresh()
    if tree is None:
        return None  # missing, corrupt, or stale — fall through

    args, incomplete = _parse_args(shell)
    completions = _complete_from_tree(tree, args, incomplete)

    # is-args is a probe: exit code signals "has completions" — no output.
    if shell == "fish" and fish_action == "is-args":
        return (0 if completions else 1, "")

    return (0, _format_output(shell, completions))


def main() -> None:
    complete_var = os.environ.get(_COMPLETE_VAR)

    if complete_var is not None and complete_var.startswith("complete_"):
        shell = complete_var.rsplit("_", 1)[-1]
        if shell not in _SUPPORTED_SHELLS:
            # Unknown shell (e.g. PowerShell) — skip the fast path
            # entirely so Typer's native completer handles it.
            from remotivelabs.cli.remotive import main as _real_main

            _real_main()
            return
        result = _try_fast_complete(shell)
        if result is not None:
            exit_code, output = result
            if output:
                sys.stdout.write(output + "\n")
            sys.exit(exit_code)
        # Cache miss — fall through to full CLI.
        # Ensure the cache exists for future fast-path hits.  Any
        # failure here (broken command tree, IO error, unexpected
        # exception) must not block the user's actual command; the
        # slow path below will run regardless, so we just swallow.
        try:
            from remotivelabs.cli.completion_cache import ensure_cache

            ensure_cache()
        except Exception:  # noqa: BLE001 S110
            pass

    from remotivelabs.cli.remotive import main as _real_main

    _real_main()
