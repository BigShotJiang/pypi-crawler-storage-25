from __future__ import annotations

import importlib
from typing import Any

import typer
from click import Context
from typer.core import TyperGroup

from remotivelabs.cli.utils.console import print_generic_message


class OrderCommands(TyperGroup):
    def list_commands(self, _ctx: Context):  # type: ignore
        return list(self.commands)


class LazyTyperGroup(TyperGroup):
    """A TyperGroup that lazily imports sub-apps on first access.

    Lazy entries are registered via ``_lazy_imports``, a dict mapping
    command names to ``"module.path:attr"`` strings.  The module is only
    imported when ``get_command`` is called for that name.

    ``_sort`` controls the order returned by ``list_commands``: ``False``
    preserves insertion order (matches ``OrderCommands``), ``True`` sorts
    alphabetically (matches Click's default ``TyperGroup`` behavior and
    what ``create_typer_sorted`` advertises).
    """

    _lazy_imports: dict[str, tuple[str, str | None]]
    _sort: bool = False

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        if not hasattr(self, "_lazy_imports"):
            self._lazy_imports = {}

    def list_commands(self, ctx: Context) -> list[str]:  # type: ignore  # noqa: ARG002
        base = list(self.commands)
        base.extend(name for name in self._lazy_imports if name not in self.commands)
        return sorted(base) if self._sort else base

    def get_command(self, ctx: Context, cmd_name: str) -> Any:  # noqa: ARG002
        cmd = self.commands.get(cmd_name)
        if cmd is not None:
            return cmd
        spec = self._lazy_imports.get(cmd_name)
        if spec is None:
            return None
        import_path, help_text = spec
        module_path, attr = import_path.rsplit(":", 1)
        module = importlib.import_module(module_path)
        typer_app = getattr(module, attr)
        if help_text is not None:
            typer_app.info.help = help_text
        from typer.main import get_group

        group = get_group(typer_app)
        group.name = cmd_name
        self.commands[cmd_name] = group
        return group


def _make_lazy_cls(lazy_imports: dict[str, tuple[str, str | None]], *, sort: bool = False) -> type:
    """Build a LazyTyperGroup subclass pre-loaded with *lazy_imports*."""

    class _Cls(LazyTyperGroup):
        pass

    _Cls._lazy_imports = lazy_imports  # noqa: SLF001
    _Cls._sort = sort  # noqa: SLF001
    return _Cls


def create_typer(lazy_imports: dict[str, tuple[str, str | None]] | None = None, **kwargs: Any) -> typer.Typer:
    """Create a Typer instance with default settings.

    If *lazy_imports* is provided, subcommand modules are imported on
    demand instead of at import time.
    """
    if lazy_imports:
        cls = _make_lazy_cls(lazy_imports, sort=False)
    else:
        cls = kwargs.pop("cls", OrderCommands)
    return typer.Typer(cls=cls, no_args_is_help=True, invoke_without_command=True, **kwargs)


def create_typer_sorted(lazy_imports: dict[str, tuple[str, str | None]] | None = None, **kwargs: Any) -> typer.Typer:
    """Create a Typer instance with default settings (sorted command order)."""
    if lazy_imports:
        cls = _make_lazy_cls(lazy_imports, sort=True)
    else:
        cls = kwargs.pop("cls", TyperGroup)
    return typer.Typer(cls=cls, no_args_is_help=True, invoke_without_command=True, **kwargs)


def print_padded(label: str, right_text: str, length: int = 30) -> None:
    padded_label = label.ljust(length)  # pad to 30 characters
    print_generic_message(f"{padded_label} {right_text}")
