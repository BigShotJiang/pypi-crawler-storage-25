from __future__ import annotations

import os

import typer as _typer

from remotivelabs.cli.broker.discovery import discover as discover_cmd
from remotivelabs.cli.broker.typer import ApiKeyOption, BrokerUrlOption
from remotivelabs.cli.typer_ext import typer_utils

app = typer_utils.create_typer(
    rich_markup_mode="rich",
    lazy_imports={
        "playback": ("remotivelabs.cli.broker.recording_session:app", None),
        "record": ("remotivelabs.cli.broker.record:app", "Record data on buses"),
        "files": ("remotivelabs.cli.broker.files:app", "Upload/Download configurations and recordings"),
        "signals": ("remotivelabs.cli.broker.signals:app", "Find and subscribe to signals"),
        "restbus": ("remotivelabs.cli.broker.restbus:app", None),
        "export": ("remotivelabs.cli.broker.export:app", "Export to external formats"),
        "scripting": ("remotivelabs.cli.broker.scripting:app", "LUA scripting utilities"),
        "license": ("remotivelabs.cli.broker.licenses:app", "View and request license to broker"),
    },
)


@app.callback()
def cb(
    url: str = BrokerUrlOption,
    api_key: str = ApiKeyOption,
    ui: bool = _typer.Option(False, "--ui", help="[yellow]\\[Experimental][/yellow] Launch the interactive TUI explorer"),
) -> None:
    if url is not None:
        os.environ["REMOTIVE_BROKER_URL"] = url

    if ui:
        from remotivelabs.cli.remotive import is_featue_flag_enabled
        from remotivelabs.cli.search.sqlite.index import SQLiteSearch
        from remotivelabs.cli.topology.tui.explore_app import SignalsExplorer

        mock = is_featue_flag_enabled("REMOTIVE_MOCK_DB")
        index = SQLiteSearch(":memory:")
        index.connect()
        SignalsExplorer(broker_url=url, api_key=api_key, index=index, mock=mock).run()
        raise _typer.Exit()


# TODO: move broker commands to subcommand instead?
app.command(help="Discover brokers on this network")(discover_cmd)
