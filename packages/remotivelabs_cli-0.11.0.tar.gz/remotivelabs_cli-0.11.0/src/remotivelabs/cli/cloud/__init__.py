from remotivelabs.cli.cloud.licenses.cmd import licenses
from remotivelabs.cli.typer_ext import typer_utils

app = typer_utils.create_typer(
    lazy_imports={
        "organizations": ("remotivelabs.cli.cloud.organisations:app", "Manage organizations"),
        "projects": ("remotivelabs.cli.cloud.projects:app", "Manage projects"),
        "auth": ("remotivelabs.cli.cloud.auth.cmd:app", None),
        "brokers": ("remotivelabs.cli.cloud.brokers:app", "Manage cloud broker lifecycle"),
        "recordings": ("remotivelabs.cli.cloud.recordings:app", "Manage recordings"),
        "signal-databases": ("remotivelabs.cli.cloud.configs:app", "Manage signal databases"),
        "storage": ("remotivelabs.cli.cloud.storage.cmd:app", None),
        "service-accounts": ("remotivelabs.cli.cloud.service_accounts:app", "Manage project service account keys"),
        "samples": ("remotivelabs.cli.cloud.sample_recordings:app", "Manage sample recordings"),
    },
)

app.command(name="licenses", help="List licenses for an organization")(licenses)
