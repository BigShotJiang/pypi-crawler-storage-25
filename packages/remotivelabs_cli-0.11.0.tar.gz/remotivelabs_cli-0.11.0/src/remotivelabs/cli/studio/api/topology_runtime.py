"""FastAPI router for runtime inspection of the connected RemotiveBroker instance."""

from __future__ import annotations

import re
from pathlib import Path

import grpc
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response

from remotivelabs.broker.client import BrokerClient
from remotivelabs.broker.exceptions import BrokerConnectionError, BrokerError
from remotivelabs.cli.broker.typer import BrokerUrlOption
from remotivelabs.cli.studio.api.files import run_cmd_and_get_yaml
from remotivelabs.cli.studio.api.path_utils import join_under

# OpenAPI examples: same default broker URL as CLI (`BrokerUrlOption`).
_OPENAPI_DOCS_BROKER_URL = BrokerUrlOption.default

# Broker-supplied topology instance IDs: safe segment for cache path (defense-in-depth).
_TOPOLOGY_INSTANCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

# Path template (relative to workspace root) for cached topology instance files.
# The "cache" segment is owned by RemotiveTopology and cannot be changed here.
_INSTANCE_CACHE_PATH = ".remotive/cache/instances/{instance_id}.instance.yaml"

router = APIRouter(prefix="/api/studio/v1/runtime", tags=["runtime"])

# ---------------------------------------------------------------------------
# Shared OpenAPI error response schemas
# ---------------------------------------------------------------------------

_ERROR_404_INSTANCE_NOT_IN_WORKSPACE = {
    "description": "The broker's active topology instance is not present in this workspace.",
    "content": {"application/json": {"example": {"detail": "Current runtime service is not found in this workspace"}}},
}
_ERROR_501 = {
    "description": "Broker does not support topology instance IDs — broker version is too old or not started from a topology instance",
    "content": {
        "application/json": {
            "example": {
                "detail": "Broker returned no topologyInstanceId — broker version may be too old or not started using RemotiveTopology"
            }
        }
    },
}
_ERROR_502 = {
    "description": "Broker returned a gRPC error, or returned an invalid topology instance ID.",
    "content": {
        "application/json": {
            "examples": {
                "grpc_error": {
                    "summary": "gRPC error from broker",
                    "value": {"detail": "Broker gRPC error: <details from broker>"},
                },
                "invalid_instance_id": {
                    "summary": "Broker returned invalid topology instance ID",
                    "value": {"detail": "Broker returned invalid topologyInstanceId"},
                },
            }
        }
    },
}
_ERROR_503 = {
    "description": "Broker is unreachable.",
    "content": {"application/json": {"example": {"detail": f"Could not reach broker at {_OPENAPI_DOCS_BROKER_URL}: Connection refused"}}},
}


async def get_current_instance_id(broker_url: str) -> str:
    try:
        async with BrokerClient(url=broker_url) as client:
            raw_instance_id = await client.topology_instance_id()
    except BrokerConnectionError as e:
        raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {e.message}") from e
    except BrokerError as e:
        raise HTTPException(status_code=502, detail=f"Broker error: {e}") from e
    # Would be nice if GRPC errors was handled in broker lib so we could get proper exceptions not only for connect
    except grpc.RpcError as e:
        code_fn = getattr(e, "code", None)
        details_fn = getattr(e, "details", None)
        code = code_fn() if callable(code_fn) else None
        details = (details_fn() if callable(details_fn) else None) or str(e)
        if code == grpc.StatusCode.UNAVAILABLE:
            raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {details}") from e
        raise HTTPException(status_code=502, detail=f"Broker gRPC error: {details}") from e

    if not raw_instance_id:
        raise HTTPException(
            status_code=501,
            detail="Broker returned no topologyInstanceId — broker version may be too old or not started using RemotiveTopology",
        )
    if _TOPOLOGY_INSTANCE_ID_RE.fullmatch(raw_instance_id) is None:
        raise HTTPException(status_code=502, detail="Broker returned invalid topologyInstanceId")
    return raw_instance_id


# TODO: Perhaps check broker version once it's released to see if support exists
@router.get(
    "/instance",
    summary="Get the currently running topology instance",
    description=(
        "Resolves the active topology instance from the connected broker and returns its "
        "platform configuration as YAML. The broker is queried for its `topologyInstanceId`; "
        "the corresponding `.instance.yaml` file must exist in the current workspace."
    ),
    response_description="Platform configuration YAML for the active topology instance.",
    responses={
        404: _ERROR_404_INSTANCE_NOT_IN_WORKSPACE,
        501: _ERROR_501,
        502: _ERROR_502,
        503: _ERROR_503,
    },
)
async def current_instance(request: Request) -> Response:
    broker_url = str(request.app.state.broker_url)
    instance_id = await get_current_instance_id(broker_url)
    instance_path = _INSTANCE_CACHE_PATH.format(instance_id=instance_id)
    workspace: Path = request.app.state.topology.workspace
    resolved = join_under(workspace, Path(instance_path))
    if not resolved.is_file():
        raise HTTPException(status_code=404, detail="Current runtime service is not found in this workspace")
    return run_cmd_and_get_yaml(["show", "instance", "--full-platform"], request, instance_path)
