from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/api/studio/v1/health", tags=["health"])


class HealthResponse(BaseModel):
    status: str
    runtime_id: str


@router.get("")
def health(request: Request) -> HealthResponse:
    return HealthResponse(
        status="ok",
        runtime_id=request.app.state.runtime_id,
    )
