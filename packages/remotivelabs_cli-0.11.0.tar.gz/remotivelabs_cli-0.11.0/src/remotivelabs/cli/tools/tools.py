from remotivelabs.cli.typer_ext import typer_utils

HELP_TEXT = """
CLI tools unrelated to cloud or broker
"""

app = typer_utils.create_typer(
    help=HELP_TEXT,
    lazy_imports={
        "can": ("remotivelabs.cli.tools.can.can:app", "CAN tools"),
    },
)
