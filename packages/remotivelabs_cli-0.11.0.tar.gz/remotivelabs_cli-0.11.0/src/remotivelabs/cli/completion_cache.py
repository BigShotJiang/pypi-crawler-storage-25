"""Writer side of the completion cache.

Walks the Click command tree and serialises it as JSON to the cache
path owned by ``main``.  Runs only on cache miss — never on a fast-
path hit — so its heavy imports (``click``, ``typer``, the full CLI
app) stay deferred inside the writer functions.  The lightweight
helpers (path, sentinel, validated read) live in ``main`` so the
fast path pays zero extra import cost; this module pulls them back
lazily to avoid a circular import.
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import click
    import click.core


def _walk(cmd: click.core.Command, ctx: click.Context) -> dict[str, Any]:
    import click

    result: dict[str, Any] = {}
    if isinstance(cmd, click.Group):
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is not None and not child.hidden:
                child_ctx = click.Context(child, parent=ctx, info_name=name, resilient_parsing=True)
                result[name] = _walk(child, child_ctx)
    opts: dict[str, str] = {}
    for p in cmd.get_params(ctx):
        if isinstance(p, click.Option) and not p.hidden:
            h = p.help or ""
            for o in (*p.opts, *p.secondary_opts):
                opts[o] = h
    if opts:
        result["_options"] = dict(sorted(opts.items()))
    help_text = cmd.get_short_help_str()
    if help_text:
        result["_help"] = help_text
    return result


def _build_tree() -> tuple[click.Command, dict[str, Any]]:
    """Return the live Click root command and a freshly walked tree.

    Pure: no disk I/O, no sentinel stamping.  ``_generate_cache`` wraps
    this with the write step; tests call it directly to compare the
    cache shape against Typer's real completer without side-effects.
    """
    import click
    from typer.main import get_command

    from remotivelabs.cli.remotive import app

    # get_command (not get_group) includes Typer-added options like
    # --install-completion / --show-completion that get_group omits.
    root = get_command(app)
    ctx = click.Context(root, info_name="remotive", resilient_parsing=True)
    return root, _walk(root, ctx)


def _generate_cache() -> dict[str, Any]:
    """Walk the CLI command tree and persist the result as JSON.

    Writes to a temp file in the same directory then renames with
    ``os.replace``, so a concurrent reader never observes a partial
    cache.  The alternative (writing to ``path`` directly) would let
    reads during regeneration fail JSON parsing, causing the fast path
    to unlink the file — leading to a loop of cache churn under even
    mild concurrency.
    """
    from remotivelabs.cli.main import _cache_path, _expected_sentinel

    _, tree = _build_tree()
    tree["_sentinel"] = _expected_sentinel()

    path = _cache_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # NamedTemporaryFile in the same dir guarantees os.replace is atomic
        # (cross-device renames would fall back to copy+unlink).
        fd, tmp_path = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".completion_cache.", suffix=".json.tmp")
        try:
            with os.fdopen(fd, "w") as fh:
                json.dump(tree, fh, separators=(",", ":"))
            os.replace(tmp_path, path)
        except OSError:
            # Best-effort cleanup — if rename failed, the tmp file would
            # otherwise linger forever.
            try:
                os.remove(tmp_path)
            except OSError:
                pass
    except OSError:
        pass

    return tree


def ensure_cache() -> None:
    """Generate the completion cache if it is missing or stale."""
    from remotivelabs.cli.main import load_fresh

    if load_fresh() is None:
        _generate_cache()
