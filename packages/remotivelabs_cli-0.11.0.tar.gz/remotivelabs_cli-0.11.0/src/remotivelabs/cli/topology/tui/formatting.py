"""Pure formatting utilities and data types for the TUI explorer."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, Literal

from rich.markup import escape as rich_escape


@dataclass
class Row:
    """Base row from the search index."""

    namespace: str
    frame_name: str
    type: Literal["frame", "signal"] = "frame"
    description: str | None = None
    unit: str | None = None
    senders: str | None = None
    receivers: str | None = None

    @staticmethod
    def from_dict(d: dict[str, Any]) -> Row:
        """Convert a search result dict to a typed Row."""
        if d.get("type") == "signal":
            return SignalRow(
                type="signal",
                namespace=d.get("namespace") or "",
                frame_name=d.get("frame_name") or "",
                signal_name=d.get("signal_name") or "",
                description=d.get("description"),
                unit=d.get("unit"),
                senders=d.get("senders"),
                receivers=d.get("receivers"),
                start_bit=d.get("start_bit"),
                size=d.get("size"),
                factor=d.get("factor"),
                offset=d.get("offset"),
                min=d.get("min"),
                max=d.get("max"),
                is_signed=d.get("is_signed"),
                is_big_endian=d.get("is_big_endian"),
                is_ieee_floating_type=d.get("is_ieee_floating_type"),
                is_raw=d.get("is_raw"),
                named_values_json=d.get("named_values_json"),
                start_value=d.get("start_value"),
            )
        return FrameRow(
            type="frame",
            namespace=d.get("namespace") or "",
            frame_name=d.get("frame_name") or "",
            description=d.get("description"),
            unit=d.get("unit"),
            senders=d.get("senders"),
            receivers=d.get("receivers"),
            payload_size=d.get("payload_size"),
            cycle_time=d.get("cycle_time"),
        )

    @property
    def key(self) -> str:
        """Unique key for this row (namespace:name)."""
        if isinstance(self, SignalRow):
            return f"{self.namespace}:{self.signal_name}"
        return f"{self.namespace}:{self.frame_name}"


@dataclass
class FrameRow(Row):
    """A frame row from the search index."""

    type: Literal["frame"] = "frame"
    payload_size: int | None = None
    cycle_time: float | None = None


@dataclass
class SignalRow(Row):
    """A signal row from the search index."""

    type: Literal["signal"] = "signal"
    signal_name: str = ""
    start_bit: int | None = None
    size: int | None = None
    factor: float | None = None
    offset: float | None = None
    min: float | None = None
    max: float | None = None
    is_signed: bool | None = None
    is_big_endian: bool | None = None
    is_ieee_floating_type: bool | None = None
    is_raw: bool | None = None
    named_values_json: str | None = None
    start_value: float | None = None


def build_tree_data(rows: list[Row]) -> dict[str, dict[str, list[SignalRow]]]:
    """Group flat search rows into namespace -> frame -> [signal rows]."""
    tree: dict[str, dict[str, list[SignalRow]]] = {}

    for row in rows:
        ns = row.namespace or "(unknown)"
        if ns not in tree:
            tree[ns] = {}
        if isinstance(row, FrameRow):
            if row.frame_name not in tree[ns]:
                tree[ns][row.frame_name] = []
        elif isinstance(row, SignalRow):
            frame_name = row.frame_name or "(no frame)"
            if frame_name not in tree[ns]:
                tree[ns][frame_name] = []
            tree[ns][frame_name].append(row)

    return tree


def _is_present(value: object) -> bool:
    return value is not None and value not in ("", [])


def _escape_action_param(value: str) -> str:
    """Escape a string for safe use inside a Rich [@click] action parameter."""
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _clickable(field: str, display: str, raw_value: str | None = None) -> str:
    """Wrap a value in a Textual action link for filter creation."""
    raw = raw_value if raw_value is not None else display
    safe = _escape_action_param(raw)
    safe_display = rich_escape(display)
    return f"[@click=filter_clicked('{field}', '{safe}')][underline]{safe_display}[/underline][/]"


def _format_signal_fields(row: SignalRow, _add: Callable[..., None]) -> None:
    _add("Frame", row.frame_name, click_field="frame_name")
    _add("Start bit", row.start_bit)
    _add("Length (bits)", row.size)
    _add("Factor", row.factor)
    _add("Offset", row.offset)
    _add("Min", row.min)
    _add("Max", row.max)
    if row.is_signed is not None:
        _add("Signed", "Yes" if row.is_signed else "No")
    if row.is_big_endian is not None:
        _add("Big endian", "Yes" if row.is_big_endian else "No")
    if row.is_ieee_floating_type:
        _add("IEEE float", "Yes")
    if row.is_raw:
        _add("Raw signal", "Yes")


def _format_named_values(nv_json: str | None, lines: list[str]) -> None:
    if not nv_json:
        return
    try:
        nv = json.loads(nv_json)
        if nv:
            lines.append("[dim]Named values:[/dim]")
            for k, v in nv.items():
                lines.append(f"  [yellow]{k}[/yellow] = {v}")
    except (json.JSONDecodeError, AttributeError):
        pass


def format_detail(
    row: Row,
    line_fields: dict[int, tuple[str, str]] | None = None,
) -> str:
    """Format a signal or frame row as a Rich markup string with clickable fields.

    If *line_fields* is provided, it is populated with a mapping from rendered
    line numbers to ``(field_name, raw_value)`` tuples for right-click lookup.
    """
    kind = row.type.capitalize()
    name = row.signal_name if isinstance(row, SignalRow) else row.frame_name
    name_field = "signal_name" if isinstance(row, SignalRow) else "frame_name"
    name_link = _clickable(name_field, name)
    lines: list[str] = [f"[bold]{kind}:[/bold] [cyan]{name_link}[/cyan]", ""]
    if line_fields is not None:
        line_fields[0] = (name_field, name)

    def _add(label: str, value: object, click_field: str | None = None, raw_value: str | None = None) -> None:
        if _is_present(value):
            line_num = len(lines)
            if click_field:
                display = _clickable(click_field, str(value), raw_value)
            else:
                display = str(value)
            lines.append(f"[dim]{label:<18}[/dim] {display}")
            if click_field and line_fields is not None:
                raw = raw_value if raw_value is not None else str(value)
                line_fields[line_num] = (click_field, raw)

    _add("Namespace", row.namespace, click_field="namespace")
    _add("Description", row.description, click_field="description")
    _add("Unit", row.unit, click_field="unit")

    if isinstance(row, SignalRow):
        _format_signal_fields(row, _add)
        nv_json = row.named_values_json
    elif isinstance(row, FrameRow):
        _add("Payload size", row.payload_size)
        _add("Cycle time", row.cycle_time)
        nv_json = None
    else:
        nv_json = None

    _add("Senders", row.senders, click_field="senders")
    _add("Receivers", row.receivers, click_field="receivers")
    _format_named_values(nv_json, lines)

    return "\n".join(lines)


def extract_signal_hints(
    row: SignalRow,
) -> tuple[tuple[float | None, float | None] | None, float | None, dict[str, Any] | None]:
    """Extract hint data from a signal row."""
    min_max = (row.min, row.max) if row.min is not None or row.max is not None else None
    start_value = row.start_value

    named_values: dict[str, Any] | None = None
    if row.named_values_json:
        try:
            nv = json.loads(row.named_values_json)
            if nv:
                named_values = nv
        except (json.JSONDecodeError, AttributeError):
            pass

    return min_max, start_value, named_values


def _format_signal_hints(row: SignalRow) -> str:
    """Format hint lines matching the detail panel style."""
    min_max, start_value, named_values = extract_signal_hints(row)
    lines: list[str] = []

    def _add(label: str, value: object) -> None:
        if _is_present(value):
            lines.append(f"[dim]{label:<18}[/dim] {value}")

    if min_max is not None:
        mn, mx = min_max
        _add("Min / Max", f"{mn} / {mx}")
    _add("Start value", start_value)
    _format_named_values(row.named_values_json, lines)
    return "\n".join(lines)


def parse_hex_payload(raw: str, ns: str, name: str, payload_size: int | None) -> tuple[bytes, str | None]:
    """Parse hex string to bytes.

    Returns (payload, optional_warning_message).
    Raises ValueError on invalid input.
    """
    hex_str = raw.strip().removeprefix("0x").removeprefix("0X")
    if not hex_str:
        raise ValueError(f"{ns}:{name}: empty payload")
    if len(hex_str) % 2 != 0:
        raise ValueError(f"{ns}:{name}: odd number of hex characters")
    try:
        payload = bytes.fromhex(hex_str)
    except ValueError:
        raise ValueError(f"{ns}:{name}: invalid hex string '{raw.strip()}'")
    warning: str | None = None
    if payload_size is not None and len(payload) != payload_size:
        warning = f"{ns}:{name}: expected {payload_size} bytes, got {len(payload)}"
    return payload, warning
