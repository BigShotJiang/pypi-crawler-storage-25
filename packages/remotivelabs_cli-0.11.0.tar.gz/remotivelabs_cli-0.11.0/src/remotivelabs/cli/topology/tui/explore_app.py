"""Interactive TUI explorer for topology frames and signals."""

from __future__ import annotations

import asyncio
import logging
import re
import time

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.timer import Timer
from textual.widgets import Footer, Header, Input, Static, Tree
from textual.widgets.tree import TreeNode
from textual.worker import Worker

from remotivelabs.broker.client import BrokerClient
from remotivelabs.broker.signal import SignalValue, WriteSignal
from remotivelabs.cli.broker.typer import get_auth, parse_scalar
from remotivelabs.cli.search.base import SearchOptions
from remotivelabs.cli.search.query import ParsedQuery, Query
from remotivelabs.cli.search.sqlite.index import SQLiteSearch

from .formatting import (
    FrameRow,
    Row,
    SignalRow,
    build_tree_data,
    parse_hex_payload,
)
from .modals import FilterActionModal, FilterResult, PublishValuesModal
from .widgets import DetailPanel, LeftPane, LiveView, SidebarHandle


def _paren_depth(s: str) -> int:
    """Return net parenthesis depth (positive = unclosed opens)."""
    return sum(1 if c == "(" else -1 if c == ")" else 0 for c in s)


_SAFE_VALUE_RE = re.compile(r"^[A-Za-z0-9_.]+$")


def _quote_value(value: str) -> str:
    """Wrap in double quotes if the value contains anything the query parser would split on."""
    if _SAFE_VALUE_RE.match(value):
        return value
    return '"' + value.replace('"', '\\"') + '"'


logger = logging.getLogger(__name__)

_GRPC_SOURCE = "grpc"
_ALL_ROWS_QUERY = Query(ParsedQuery(terms=[], active_term=None))
__all__ = [
    "SignalsExplorer",
]


class SignalsExplorer(App[None]):
    """Interactive TUI explorer for topology frames and signals."""

    TITLE = "Topology Signal Explorer"
    CSS = """
    Screen {
        layout: vertical;
    }

    #search-input {
        dock: top;
        height: 3;
        margin: 0 0;
    }

    #main-area {
        layout: horizontal;
        height: 1fr;
    }

    #left-pane {
        width: 40%;
    }

    #left-pane.collapsed {
        display: none;
    }

    #right-pane {
        width: 1fr;
        layout: vertical;
        background: $surface-darken-1;
        padding: 1;
    }

    #detail-container {
        padding: 1 2;
        height: auto;
        max-height: 50%;
        background: $surface;
        margin-bottom: 1;
        display: none;
    }

    #detail-container.visible {
        display: block;
    }

    #detail-panel {
        width: 100%;
    }

    #live-view {
        height: 1fr;
        display: none;
    }

    #live-view.visible {
        display: block;
    }

    #live-view:focus {
        border: tall $primary;
    }

    #chart-view {
        height: 1fr;
        display: none;
    }

    #chart-view.visible {
        display: block;
    }

    #signal-chart {
        height: 1fr;
        background: $surface;
    }

    #subscription-view {
        height: 1fr;
        display: none;
    }

    #subscription-view.visible {
        display: block;
    }

    .frame-window {
        height: auto;
        padding: 1 2;
        background: $surface;
        background-tint: $foreground 5%;
        margin-bottom: 1;
    }

    #status-bar {
        height: 1;
        padding: 0 1;
        color: $text;
        background: $primary-darken-2;
    }
    """

    BINDINGS = [
        Binding("r", "reindex", "Re-index"),
        Binding("ctrl+b", "toggle_sidebar", "Sidebar"),
        Binding("/", "focus_search", "Search"),
        Binding("q", "close_live", "Close live view"),
        Binding("escape", "clear_search", "Clear search", show=False),
    ]

    def __init__(self, broker_url: str, api_key: str | None, index: SQLiteSearch, *, mock: bool = False) -> None:
        super().__init__()
        self._broker_url = broker_url
        self._api_key = api_key
        self._index = index
        self._mock = mock
        self._current_filter = ""
        self._frames_expanded = False
        self._expanded_frames: set[str] = set()
        self._subscribe_worker: Worker[None] | None = None
        self._broker: BrokerClient | None = None
        self._current_node: TreeNode[Row] | None = None
        self._current_row: Row | None = None
        self._marked_signals: dict[str, SignalRow] = {}
        self._marked_frames: dict[str, FrameRow] = {}

    def compose(self) -> ComposeResult:
        yield Header()
        yield Input(placeholder="/ Search frames and signals...", id="search-input")
        with Horizontal(id="main-area"):
            with LeftPane(id="left-pane"):
                yield Tree("Namespaces", id="signal-tree")
            yield SidebarHandle(id="sidebar-handle")
            with Vertical(id="right-pane"):
                with ScrollableContainer(id="detail-container", can_focus=False):
                    yield DetailPanel(id="detail-panel")
                yield LiveView(id="live-view")
        yield Static("Indexing signals from broker...", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.run_worker(self._do_index, exclusive=True, thread=True)

    def _do_index(self) -> None:
        if self._mock:
            self._set_status("Indexing mock signals...")
            try:
                from remotivelabs.cli.search.mock_index import generate_mock_index

                count = self._index.index_signals(generate_mock_index())
                self._set_status(f"Indexed {count} mock entries")
            except Exception as exc:
                self.call_from_thread(self.notify, f"Mock index error: {exc}", severity="error")
                return
        else:
            self._set_status("Indexing signals from broker...")
            try:
                count = self._index.index_grpc_signals(self._broker_url, self._api_key)
                self._set_status(f"Indexed {count} entries from {self._broker_url}")
            except Exception as exc:
                self.call_from_thread(self.notify, f"Index error: {exc}", severity="error")
                return
        self.call_from_thread(self._rebuild_tree, self._current_filter)

    def _set_status(self, message: str) -> None:
        self.call_from_thread(self._update_status_widget, message)

    def _update_status_widget(self, message: str) -> None:
        self.query_one("#status-bar", Static).update(message)

    def _signal_label(self, row: SignalRow) -> str:
        if row.key in self._marked_signals:
            return f"[bold green]* {row.signal_name}[/bold green]"
        return f"[green]{row.signal_name}[/green]"

    def _frame_label(self, row: FrameRow) -> str:
        if row.key in self._marked_frames:
            return f"[bold yellow]* {row.frame_name}[/bold yellow]"
        return f"[yellow]{row.frame_name}[/yellow]"

    def _rebuild_tree(self, filter_str: str) -> None:
        """Kick off a threaded search; the worker calls back to update the UI."""
        self.run_worker(
            lambda: self._do_search(filter_str),
            exclusive=True,
            group="search",
            thread=True,
        )

    def _do_search(self, filter_str: str) -> None:
        """Run the expensive query off the main thread."""
        opts = SearchOptions(source_filter=_GRPC_SOURCE)
        if filter_str.strip():
            query = Query.parse(filter_str)
        else:
            query = _ALL_ROWS_QUERY

        raw_rows = self._index.search(query, limit=10000, opts=opts)
        rows = [Row.from_dict(r) for r in raw_rows]
        grouped = build_tree_data(rows)

        # Schedule an async tree rebuild on the event loop so it can yield.
        self.call_from_thread(self._start_apply, filter_str, rows, grouped)

    def _start_apply(
        self,
        filter_str: str,
        rows: list[Row],
        grouped: dict[str, dict[str, list[SignalRow]]],
    ) -> None:
        """Launch the async tree rebuild as a non-threaded worker."""
        self.run_worker(
            self._apply_tree(filter_str, rows, grouped),
            exclusive=True,
            group="apply",
        )

    def _snapshot_expanded_frames(self, tree: Tree[Row]) -> None:
        """Record which frame nodes are currently expanded before rebuilding."""
        for ns_node in tree.root.children:
            for child in ns_node.children:
                if isinstance(child.data, FrameRow):
                    key = child.data.key
                    if child.is_expanded:
                        self._expanded_frames.add(key)
                    else:
                        self._expanded_frames.discard(key)

    async def _apply_tree(
        self,
        filter_str: str,
        rows: list[Row],
        grouped: dict[str, dict[str, list[SignalRow]]],
    ) -> None:
        """Update the tree widget, yielding to the event loop between namespaces."""
        if filter_str != self._current_filter:
            return
        tree = self.query_one("#signal-tree", Tree)

        self._snapshot_expanded_frames(tree)
        tree.clear()
        tree.root.expand()

        for ns in sorted(grouped):
            if filter_str != self._current_filter:
                return  # Abort: user typed more, newer search pending.
            ns_node = tree.root.add(self._ns_label(ns), expand=True)
            frames = grouped[ns]
            for frame_name in sorted(frames):
                frame_row = self._find_frame_row(rows, ns, frame_name)
                expand = self._frames_expanded or frame_row.key in self._expanded_frames
                frame_node: TreeNode[Row] = ns_node.add(
                    self._frame_label(frame_row),
                    data=frame_row,
                    expand=expand,
                )
                for sig_row in sorted(frames[frame_name], key=lambda r: r.signal_name):
                    frame_node.add_leaf(
                        self._signal_label(sig_row),
                        data=sig_row,
                    )
            # Let the event loop process pending keystrokes.
            await asyncio.sleep(0)

        total_signals = sum(len(sigs) for frames in grouped.values() for sigs in frames.values())
        total_frames = sum(len(frames) for frames in grouped.values())
        label = f"  {len(grouped)} namespace(s)  ·  {total_frames} frame(s)  ·  {total_signals} signal(s)"
        if filter_str.strip():
            label += f"  ·  filter: [italic]{filter_str}[/italic]"
        self.query_one("#status-bar", Static).update(label)

    def _find_frame_row(self, rows: list[Row], ns: str, frame_name: str) -> FrameRow:
        for row in rows:
            if isinstance(row, FrameRow) and row.namespace == ns and row.frame_name == frame_name:
                return row
        return FrameRow(namespace=ns, frame_name=frame_name)

    def _show_node_detail(self, node: TreeNode[Row]) -> None:
        row: Row | None = node.data
        panel = self.query_one("#detail-panel", DetailPanel)
        container = self.query_one("#detail-container", ScrollableContainer)
        panel.show(row)
        if row is None:
            container.remove_class("visible")
        else:
            container.add_class("visible")

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted[Row]) -> None:
        self._show_node_detail(event.node)
        self._current_node = event.node
        self._current_row = event.node.data

    def on_tree_node_selected(self, event: Tree.NodeSelected[Row]) -> None:
        self._show_node_detail(event.node)

    def on_detail_panel_filter_include(self, event: DetailPanel.FilterInclude) -> None:
        """Left-click on a detail field — directly apply AND include filter."""
        self._append_filter_term(f"{event.field}:{_quote_value(event.value)}")

    def on_detail_panel_filter_choose(self, event: DetailPanel.FilterChoose) -> None:
        """Right-click on a detail field — show include/exclude/OR popup."""
        self.push_screen(
            FilterActionModal(event.field, event.value),
            callback=self._on_filter_action,
        )

    _COMPARISON_OPS: dict[str, str] = {
        "gt": ">",
        "gte": ">=",
        "lt": "<",
        "lte": "<=",
    }

    def _on_filter_action(self, result: FilterResult | None) -> None:
        if result is None:
            return
        value = _quote_value(result.value)
        if result.action == "include":
            term = f"{result.field}:{value}"
        elif result.action == "exclude":
            term = f"-{result.field}:{value}"
        else:
            op = self._COMPARISON_OPS.get(result.action, "=")
            term = f"{result.field}:{op}{value}"
        if result.use_or:
            term = f"OR {term}"
        self._append_filter_term(term)

    def _append_filter_term(self, term: str) -> None:
        search = self.query_one("#search-input", Input)
        current = search.value.rstrip()
        # Drop leading OR when search is empty — can't OR with nothing
        if not current and term.startswith("OR "):
            term = term[3:]
        # Don't duplicate the exact same term (check with and without OR prefix).
        # Substring check handles quoted multi-word values that .split() would break.
        bare = term.removeprefix("OR ")
        if bare in current:
            return
        if not current:
            search.value = term
        elif current.endswith("("):
            search.value = current + term
        else:
            search.value = f"{current} {term}"

    _search_timer: Timer | None = None

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "search-input":
            self._current_filter = event.value
            if _paren_depth(event.value) != 0:
                return
            if self._search_timer is not None:
                self._search_timer.stop()
            self._search_timer = self.set_timer(0.15, lambda: self._rebuild_tree(self._current_filter))

    def action_reindex(self) -> None:
        self._cancel_subscription()
        self._marked_signals.clear()
        self._marked_frames.clear()
        self._current_node = None
        self._current_row = None
        self.query_one("#detail-panel", DetailPanel).show(None)
        self.query_one("#detail-container", ScrollableContainer).remove_class("visible")
        self.run_worker(self._do_index, exclusive=True, thread=True)

    def action_expand_all(self) -> None:
        self._frames_expanded = True
        tree = self.query_one("#signal-tree", Tree)
        for ns_node in tree.root.children:
            ns_node.expand()
            for frame_node in ns_node.children:
                frame_node.expand()

    def action_collapse_all(self) -> None:
        self._frames_expanded = False
        self._expanded_frames.clear()
        tree = self.query_one("#signal-tree", Tree)
        for ns_node in tree.root.children:
            for frame_node in ns_node.children:
                frame_node.collapse()
            ns_node.collapse()

    def action_focus_search(self) -> None:
        self.query_one("#search-input", Input).focus()

    def action_clear_search(self) -> None:
        search = self.query_one("#search-input", Input)
        search.clear()
        self._current_filter = ""
        self.query_one("#signal-tree", Tree).focus()

    def action_toggle_sidebar(self) -> None:
        left = self.query_one("#left-pane", LeftPane)
        handle = self.query_one("#sidebar-handle", SidebarHandle)
        left.toggle_class("collapsed")
        collapsed = left.has_class("collapsed")
        handle.update("\u25b6" if collapsed else "\u25c0")
        if collapsed:
            if self.focused is self.query_one("#signal-tree", Tree):
                self.screen.focus_next()
        else:
            self.query_one("#signal-tree", Tree).focus()

    def on_sidebar_handle_clicked(self) -> None:
        self.action_toggle_sidebar()

    @staticmethod
    def _ns_name(node: TreeNode[Row]) -> str:
        """Extract namespace name from a namespace tree node."""
        label = node.label
        plain = label.plain if isinstance(label, Text) else label
        return plain.lstrip("* ")

    def _ns_has_marks(self, ns: str) -> bool:
        """Check if a namespace has any marked frames or signals."""
        return any(k.startswith(f"{ns}:") for k in self._marked_frames) or any(k.startswith(f"{ns}:") for k in self._marked_signals)

    def _ns_label(self, ns: str) -> str:
        if self._ns_has_marks(ns):
            return f"[bold green]* {ns}[/bold green]"
        return f"[bold]{ns}[/bold]"

    def _update_ns_label(self, ns_node: TreeNode[Row]) -> None:
        """Refresh a namespace node label based on whether it has marked children."""
        ns = self._ns_name(ns_node)
        ns_node.set_label(self._ns_label(ns))

    def _mark_ns_node(self, node: TreeNode[Row], marking: bool) -> None:
        """Mark or unmark a namespace node and all its child frames."""
        for child in node.children:
            if isinstance(child.data, FrameRow):
                self._mark_frame_node(child, marking)
        self._update_ns_label(node)

    def _mark_frame_node(self, node: TreeNode[Row], marking: bool) -> None:
        """Mark or unmark a frame node and all its child signals."""
        data = node.data
        if not isinstance(data, FrameRow):
            return
        if marking:
            self._marked_frames[data.key] = data
        else:
            self._marked_frames.pop(data.key, None)
        node.set_label(self._frame_label(data))
        for child in node.children:
            if isinstance(child.data, SignalRow):
                if marking:
                    self._marked_signals[child.data.key] = child.data
                else:
                    self._marked_signals.pop(child.data.key, None)
                child.set_label(self._signal_label(child.data))

    def action_toggle_mark(self) -> None:
        node = self._current_node
        data = self._current_row
        tree = self.query_one("#signal-tree", Tree)
        if node is None:
            self.notify("Select a node to mark", severity="information")
            return

        if isinstance(data, FrameRow):
            self._mark_frame_node(node, data.key not in self._marked_frames)
            if node.parent is not None:
                self._update_ns_label(node.parent)
        elif isinstance(data, SignalRow):
            if data.key in self._marked_signals:
                del self._marked_signals[data.key]
            else:
                self._marked_signals[data.key] = data
            node.set_label(self._signal_label(data))
            if node.parent is not None and node.parent.parent is not None:
                self._update_ns_label(node.parent.parent)
        elif node is tree.root:
            # Root node — toggle all namespaces
            any_unmarked = any(not self._ns_has_marks(self._ns_name(ns_node)) for ns_node in node.children)
            for ns_node in node.children:
                self._mark_ns_node(ns_node, any_unmarked)
        elif node.children:
            # Namespace node
            ns = self._ns_name(node)
            self._mark_ns_node(node, not self._ns_has_marks(ns))
        else:
            self.notify("Select a node to mark", severity="information")
            return

    def action_clear_marks(self) -> None:
        tree = self.query_one("#signal-tree", Tree)
        self._marked_signals.clear()
        self._marked_frames.clear()
        for ns_node in tree.root.children:
            ns_node.set_label(self._ns_label(self._ns_name(ns_node)))
            for frame_node in ns_node.children:
                if isinstance(frame_node.data, FrameRow):
                    frame_node.set_label(self._frame_label(frame_node.data))
                for sig_node in frame_node.children:
                    if isinstance(sig_node.data, SignalRow):
                        sig_node.set_label(self._signal_label(sig_node.data))

    def action_publish(self) -> None:
        if self._marked_signals or self._marked_frames:
            all_rows: list[Row] = list(self._marked_signals.values()) + list(self._marked_frames.values())
        elif isinstance(self._current_row, (FrameRow, SignalRow)):
            all_rows = [self._current_row]
        else:
            self.notify("Select a signal or frame node to publish", severity="information")
            return
        self.push_screen(
            PublishValuesModal(all_rows),
            callback=self._on_publish_result,
        )

    def _on_publish_result(self, results: list[tuple[str, str, str, str, int | None]] | None) -> None:
        if not results:
            return
        self.run_worker(self._do_publish_batch(results))

    def _parse_batch_entry(
        self,
        ns: str,
        name: str,
        raw: str,
        row_type: str,
        payload_size: int | None,
    ) -> tuple[str, str, list[SignalValue]] | None:
        """Parse a single batch publish entry. Returns None on error (notified)."""
        if row_type != "frame":
            return (ns, name, [parse_scalar(v) for v in raw.split(",")])
        try:
            payload, warning = parse_hex_payload(raw, ns, name, payload_size)
        except ValueError as exc:
            self.notify(f"Publish error: {exc}", severity="error")
            return None
        if warning:
            self.notify(warning, severity="warning")
        return (ns, name, [payload])

    async def _do_publish_batch(self, entries: list[tuple[str, str, str, str, int | None]]) -> None:
        if self._mock:
            return
        broker = await self._ensure_broker()
        parsed: list[tuple[str, str, list[SignalValue]]] = []
        for ns, name, raw, row_type, payload_size in entries:
            result = self._parse_batch_entry(ns, name, raw, row_type, payload_size)
            if result is not None:
                parsed.append(result)
        if not parsed:
            return
        try:
            max_len = max(len(values) for _, _, values in parsed)
            for i in range(max_len):
                by_ns: dict[str, list[WriteSignal]] = {}
                for ns, name, values in parsed:
                    if i < len(values):
                        by_ns.setdefault(ns, []).append(WriteSignal(name=name, value=values[i]))
                await broker.publish(*by_ns.items())
        except Exception as exc:
            self.notify(f"Publish error: {exc}", severity="error")

    def _subscribe_frame_state(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
    ) -> None:
        """Start a frame-state subscription for the given signals and/or frames."""
        self._cancel_subscription()
        live = self.query_one("#live-view", LiveView)
        live.start_subscription(signals, frames)
        self._subscribe_worker = self.run_worker(self._do_subscribe_marked(live))
        self._safe_refresh_bindings()

    def action_subscribe(self) -> None:
        if self._marked_signals or self._marked_frames:
            self._subscribe_frame_state(self._marked_signals, self._marked_frames)
            return
        data = self._current_row
        if isinstance(data, FrameRow):
            node = self._current_node
            if node is None:
                return
            signals: dict[str, SignalRow] = {}
            for child in node.children:
                if isinstance(child.data, SignalRow):
                    signals[child.data.key] = child.data
            if signals:
                self._subscribe_frame_state(signals)
            else:
                # Frame without signals — subscribe to payload only
                self._subscribe_frame_state({}, {data.key: data})
            return
        if not isinstance(data, SignalRow):
            self.notify("Select a signal or frame node to subscribe", severity="information")
            return
        self._cancel_subscription()
        live = self.query_one("#live-view", LiveView)
        live.start_chart(data.namespace, data.signal_name)
        self._subscribe_worker = self.run_worker(self._do_subscribe(data))
        self._safe_refresh_bindings()

    def action_broker_version(self) -> None:
        self.run_worker(self._do_broker_version())

    async def _do_broker_version(self) -> None:
        if self._mock:
            self._update_status_widget("Broker version: mock mode")
            return
        try:
            broker = await self._ensure_broker()
            version = await broker.broker_version()
            self._update_status_widget(f"Broker version: {version}")
        except Exception as exc:
            self.notify(f"Version error: {exc}", severity="error")

    async def _ensure_broker(self) -> BrokerClient:
        if self._mock:
            raise RuntimeError("Broker operations are not available in mock mode")
        if self._broker is None:
            auth = get_auth(self._broker_url, self._api_key)
            self._broker = await BrokerClient(self._broker_url, auth=auth).connect()
        return self._broker

    async def _do_subscribe(self, row: SignalRow) -> None:
        if self._mock:
            return
        broker = await self._ensure_broker()
        live = self.query_one("#live-view", LiveView)

        # Seed chart with current value
        try:
            signals = await broker.read_signals((row.namespace, [row.signal_name]))
            for sig in signals:
                if isinstance(sig.value, (int, float)):
                    ts = int(time.time() * 1_000_000)
                    live.on_signal_value(ts, float(sig.value))
        except Exception:
            logger.debug("Failed to seed chart with current value", exc_info=True)

        stream = await broker.subscribe_frames(
            (row.namespace, [row.frame_name]),
            on_change=False,
        )

        async for frame in stream:
            value = frame.signals.get(row.signal_name)
            if isinstance(value, (int, float)):
                live.on_signal_value(frame.timestamp, float(value))

    async def _do_subscribe_marked(self, live: LiveView) -> None:
        if self._mock:
            return
        broker = await self._ensure_broker()
        signals = live.subscribed_signals
        frames = live.subscribed_frames

        # Group by namespace -> set of frame names
        by_ns_frame: dict[str, set[str]] = {}
        for sig_row in signals.values():
            by_ns_frame.setdefault(sig_row.namespace, set()).add(sig_row.frame_name)
        for frame_row in frames.values():
            by_ns_frame.setdefault(frame_row.namespace, set()).add(frame_row.frame_name)

        sub_args = [(ns, list(fnames)) for ns, fnames in by_ns_frame.items()]

        # Seed with current cached values (frame payloads + signals)
        watched_keys = set(signals.keys())
        try:
            ts = int(time.time() * 1_000_000)
            for ns, fnames in by_ns_frame.items():
                # Read frame payloads and signals in one call
                read_names: list[str] = list(fnames)
                for row in signals.values():
                    if row.namespace == ns:
                        read_names.append(row.signal_name)
                results = await broker.read_signals((ns, read_names))
                result_map = {sig.name: sig.value for sig in results if sig.value is not None}
                for fname in fnames:
                    payload = result_map.get(fname, b"")
                    sig_values = {name: val for name, val in result_map.items() if name not in fnames}
                    live.on_frame_update(
                        frame_key=f"{ns}:{fname}",
                        payload=payload,
                        timestamp=ts,
                        signals=sig_values,
                        watched_keys=watched_keys,
                    )
        except Exception:
            logger.debug("Failed to seed subscription with cached values", exc_info=True)

        stream = await broker.subscribe_frames(*sub_args, on_change=False)

        async for frame in stream:
            live.on_frame_update(
                frame_key=f"{frame.namespace}:{frame.name}",
                payload=frame.value,
                timestamp=frame.timestamp,
                signals=frame.signals,
                watched_keys=watched_keys,
            )

    def _cancel_subscription(self) -> None:
        if self._subscribe_worker is not None:
            self._subscribe_worker.cancel()
            self._subscribe_worker = None
        try:
            self.query_one("#live-view", LiveView).reset()
        except Exception:
            logger.debug("Failed to reset live view", exc_info=True)
        self._safe_refresh_bindings()

    def _safe_refresh_bindings(self) -> None:
        """Refresh footer bindings, tolerating the no-screen state during teardown."""
        try:
            self.refresh_bindings()
        except Exception:
            logger.debug("refresh_bindings skipped (no active screen)", exc_info=True)

    def action_close_live(self) -> None:
        live = self.query_one("#live-view", LiveView)
        if not live.has_subscription:
            return
        self._cancel_subscription()
        self.query_one("#signal-tree", Tree).focus()

    def check_action(self, action: str, _parameters: tuple[object, ...]) -> bool | None:
        """Hide the 'q' binding in the footer when there's no live view to close."""
        if action == "close_live":
            live = self.query_one("#live-view", LiveView)
            return True if live.has_subscription else None
        return True

    async def on_unmount(self) -> None:
        self._cancel_subscription()
        if self._broker is not None:
            await self._broker.disconnect()
