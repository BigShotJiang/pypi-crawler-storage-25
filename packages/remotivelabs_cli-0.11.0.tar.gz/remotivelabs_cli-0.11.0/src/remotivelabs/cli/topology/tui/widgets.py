"""Widget classes for the TUI explorer."""

from __future__ import annotations

import collections
from datetime import datetime
from typing import Any, Literal

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.message import Message
from textual.widgets import Static
from textual_plotext import PlotextPlot

from .formatting import FrameRow, Row, SignalRow, format_detail

_HISTORY_DEPTH = 20

_Mode = Literal["none", "chart", "subscription"]


class SignalLine(Static):
    """Clickable signal row in the frame state view."""

    DEFAULT_CSS = """
    SignalLine {
        height: auto;
    }
    SignalLine:hover {
        background: $surface-lighten-1;
    }
    """

    class Clicked(Message):
        """Posted when a signal row is clicked."""

        def __init__(self, sig_key: str) -> None:
            super().__init__()
            self.sig_key = sig_key

    def __init__(self, sig_key: str, content: str = "", **kwargs: Any) -> None:
        super().__init__(content, **kwargs)
        self.sig_key = sig_key

    def on_click(self) -> None:
        self.post_message(self.Clicked(self.sig_key))


class SubscriptionView(VerticalScroll):
    """Frame-state renderer. Internal view of LiveView — no lifecycle or focus."""

    class Updated(Message):
        """Posted when subscription data arrives with new signal values."""

        def __init__(self, updated_keys: set[str]) -> None:
            super().__init__()
            self.updated_keys = updated_keys

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._signal_history: dict[str, collections.deque[tuple[int, Any]]] = {}
        self._frame_payloads: dict[str, tuple[Any, int]] = {}
        self._subscribed_signals: dict[str, SignalRow] = {}
        self._subscribed_frames: dict[str, FrameRow] = {}
        self._expanded_history_keys: set[str] = set()
        self._history_display_depth: int = 5
        self._frame_window_ids: dict[str, str] = {}
        self._frame_window_counter: int = 0
        self._header_widgets: dict[str, Static] = {}
        self._signal_widgets: dict[str, SignalLine] = {}
        self._frame_signal_keys: dict[str, list[str]] = {}  # frame_key -> [sig_key, ...]

    @property
    def subscribed_signals(self) -> dict[str, SignalRow]:
        return self._subscribed_signals

    @property
    def subscribed_frames(self) -> dict[str, FrameRow]:
        return self._subscribed_frames

    @property
    def has_subscriptions(self) -> bool:
        return bool(self._subscribed_signals or self._subscribed_frames)

    def start(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
    ) -> None:
        """Set up a new subscription view for the given signals/frames."""
        self._signal_history.clear()
        self._frame_payloads.clear()
        self._subscribed_signals = dict(signals)
        self._subscribed_frames = dict(frames) if frames else {}
        self._expanded_history_keys.clear()

        # Group signals by frame key
        frame_groups: dict[str, list[SignalRow]] = {}
        for row in signals.values():
            fkey = f"{row.namespace}:{row.frame_name}"
            frame_groups.setdefault(fkey, []).append(row)

        all_frame_keys: set[str] = set(frame_groups)
        for fkey in frames or {}:
            all_frame_keys.add(fkey)
            if fkey not in frame_groups:
                frame_groups[fkey] = []

        # Build widget tree once — _refresh_view updates content in place
        self.remove_children()
        self._frame_window_ids.clear()
        self._header_widgets.clear()
        self._signal_widgets.clear()
        self._frame_signal_keys.clear()
        for fkey in sorted(all_frame_keys):
            wid = f"frame-win-{self._frame_window_counter}"
            self._frame_window_counter += 1
            self._frame_window_ids[fkey] = wid

            frame_sigs = sorted(frame_groups.get(fkey, []), key=lambda r: r.start_bit or 0)
            header = Static("", markup=True)
            self._header_widgets[fkey] = header
            sig_keys: list[str] = []
            children: list[Static] = [header]
            for sig_row in frame_sigs:
                sl = SignalLine(sig_row.key, "", markup=True)
                self._signal_widgets[sig_row.key] = sl
                sig_keys.append(sig_row.key)
                children.append(sl)
            self._frame_signal_keys[fkey] = sig_keys

            self.mount(Vertical(*children, id=wid, classes="frame-window"))

        self.add_class("visible")
        self._refresh_view()

    def on_frame_update(
        self,
        frame_key: str,
        payload: Any,
        timestamp: int,
        signals: dict[str, Any],
        watched_keys: set[str],
    ) -> None:
        """Called when a new frame arrives from the subscription stream."""
        self._frame_payloads[frame_key] = (payload, timestamp)

        updated_keys: set[str] = set()
        ns = frame_key.split(":", 1)[0]
        for sig_name, sig_value in signals.items():
            sig_k = f"{ns}:{sig_name}"
            if sig_k not in watched_keys:
                continue
            if sig_k not in self._signal_history:
                self._signal_history[sig_k] = collections.deque(maxlen=_HISTORY_DEPTH)
            self._signal_history[sig_k].append((timestamp, sig_value))
            updated_keys.add(sig_k)

        self._refresh_frame(frame_key)
        if updated_keys:
            self.post_message(self.Updated(updated_keys))

    def get_latest_value(self, sig_key: str) -> tuple[int, Any] | None:
        """Return the latest (timestamp, value) for a signal, or None."""
        history = self._signal_history.get(sig_key)
        if history:
            return history[-1]
        return None

    def reset(self) -> None:
        """Clear all subscription state and hide."""
        self._signal_history.clear()
        self._frame_payloads.clear()
        self._subscribed_signals.clear()
        self._subscribed_frames.clear()
        self._expanded_history_keys.clear()
        self._frame_window_ids.clear()
        self._header_widgets.clear()
        self._signal_widgets.clear()
        self._frame_signal_keys.clear()
        self.remove_children()
        self.remove_class("visible")

    def toggle_signal_history(self, key: str) -> None:
        if key in self._expanded_history_keys:
            self._expanded_history_keys.discard(key)
        else:
            self._expanded_history_keys.add(key)
        self._refresh_view()

    def action_expand_all(self) -> None:
        self._expanded_history_keys = set(self._subscribed_signals.keys())
        self._refresh_view()

    def action_collapse_all(self) -> None:
        self._expanded_history_keys.clear()
        self._refresh_view()

    def adjust_history_depth(self, delta: int) -> None:
        new_depth = self._history_display_depth + delta
        if new_depth > _HISTORY_DEPTH:
            self.notify(f"Max history depth: {_HISTORY_DEPTH}", severity="information")
            return
        self._history_display_depth = max(1, new_depth)
        self._refresh_view()

    def on_signal_line_clicked(self, event: SignalLine.Clicked) -> None:
        self.toggle_signal_history(event.sig_key)

    def _refresh_frame(self, frame_key: str) -> None:
        """Update a single frame window's header and signal widgets."""
        header = self._header_widgets.get(frame_key)
        if header is not None:
            has_signals = bool(self._frame_signal_keys.get(frame_key))
            header.update(self._render_frame_header(frame_key, has_signals))
        for sig_key in self._frame_signal_keys.get(frame_key, ()):
            widget = self._signal_widgets.get(sig_key)
            row = self._subscribed_signals.get(sig_key)
            if widget is not None and row is not None:
                widget.update(self._render_signal_line(row))

    def _refresh_view(self) -> None:
        """Update all frame window contents in place."""
        for fkey in self._header_widgets:
            self._refresh_frame(fkey)

    def _render_frame_header(self, fkey: str, has_signals: bool) -> str:
        ns, fname = fkey.split(":", 1)
        lines = [f"[bold]{ns}[/bold]  [yellow]{fname}[/yellow]"]
        payload_data = self._frame_payloads.get(fkey)
        if payload_data is not None:
            payload, ts = payload_data
            time_str = datetime.fromtimestamp(ts / 1_000_000).strftime("%H:%M:%S")
            payload_str = f"0x{payload.hex()}" if isinstance(payload, bytes) else f"{payload!r}"
            lines.append(f"[dim]Payload:[/dim] {payload_str}  [dim]{time_str}[/dim]")
        if has_signals:
            lines.append("")
            lines.append(f"  [dim]{'Signal':<30} {'Value'}[/dim]")
        return "\n".join(lines)

    def _render_signal_line(self, row: SignalRow) -> str:
        """Render a signal line. Returns formatted text."""
        sig_k = row.key
        name = row.signal_name
        bit_info = f" (bit {row.start_bit})" if row.start_bit is not None else ""
        is_expanded = sig_k in self._expanded_history_keys
        prefix = "▼" if is_expanded else "▶"
        label = f"{name}{bit_info}"

        history = self._signal_history.get(sig_k)
        val_str = f"{history[-1][1]!r}" if history else "[dim]—[/dim]"

        padding = max(0, 32 - len(f"{prefix} {label}"))
        row_text = f" [green]{prefix} {label}[/green]{' ' * padding} {val_str}"

        if is_expanded and history and len(history) > 1:
            for h_ts, h_val in list(history)[-2::-1][: self._history_display_depth]:
                h_time = datetime.fromtimestamp(h_ts / 1_000_000).strftime("%H:%M:%S")
                row_text += f"\n    [dim]│ {h_time}  {h_val!r}[/dim]"

        return row_text


class ChartView(Vertical):
    """Single-signal chart renderer. Internal view of LiveView — no lifecycle or focus."""

    _WINDOW_SECS = 30

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._values: collections.deque[tuple[int, float]] = collections.deque(maxlen=10_000)
        self._signal_name: str = ""

    def compose(self) -> ComposeResult:
        yield PlotextPlot(id="signal-chart")

    @property
    def has_subscription(self) -> bool:
        return bool(self._signal_name)

    def start(self, namespace: str, signal_name: str) -> None:
        """Prepare the chart for a new single-signal subscription."""
        self._values.clear()
        self._signal_name = signal_name
        chart = self.query_one(PlotextPlot)
        chart.plt.clear_data()
        chart.plt.clear_figure()
        chart.plt.title(f"{namespace}:{signal_name}")
        chart.plt.xlabel("Waiting for data...")
        chart.refresh()
        self.add_class("visible")

    def on_signal_value(self, timestamp: int, value: float) -> None:
        """Record a new value and refresh the chart."""
        self._values.append((timestamp, value))
        self._refresh_chart()

    def reset(self) -> None:
        """Clear all state and hide."""
        self._values.clear()
        self._signal_name = ""
        self.remove_class("visible")

    def _refresh_chart(self) -> None:
        chart = self.query_one(PlotextPlot)
        plt = chart.plt
        plt.clear_data()
        plt.clear_figure()
        all_data = list(self._values)
        if not all_data:
            return
        cutoff_us = all_data[-1][0] - self._WINDOW_SECS * 1_000_000
        data = [(ts, v) for ts, v in all_data if ts >= cutoff_us]
        times = [datetime.fromtimestamp(ts / 1_000_000).strftime("%H:%M:%S") for ts, _ in data]
        values = [v for _, v in data]
        plt.date_form("H:M:S")
        plt.plot(times, values, marker="braille", label=self._signal_name)
        plt.title(self._signal_name)
        plt.xlabel("time")
        chart.refresh()


class LiveView(Vertical, can_focus=True):
    """Live subscription host — shows either a chart (single signal) or a frame-state view.

    Owns mode switching; the app owns the close binding so it works without focusing here.
    """

    BINDINGS = [
        Binding("+", "increase", "More history"),
        Binding("-", "decrease", "Less history"),
        Binding("e", "expand_all", "Expand all"),
        Binding("c", "collapse_all", "Collapse all"),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._mode: _Mode = "none"

    def compose(self) -> ComposeResult:
        yield ChartView(id="chart-view")
        yield SubscriptionView(id="subscription-view")

    def _chart(self) -> ChartView:
        return self.query_one(ChartView)

    def _sub(self) -> SubscriptionView:
        return self.query_one(SubscriptionView)

    @property
    def mode(self) -> _Mode:
        return self._mode

    @property
    def has_subscription(self) -> bool:
        return self._mode != "none"

    @property
    def subscribed_signals(self) -> dict[str, SignalRow]:
        return self._sub().subscribed_signals

    @property
    def subscribed_frames(self) -> dict[str, FrameRow]:
        return self._sub().subscribed_frames

    def start_chart(self, namespace: str, signal_name: str) -> None:
        """Switch to chart mode for a single signal. Leaves focus where it is."""
        self._sub().reset()
        self._chart().start(namespace, signal_name)
        self._mode = "chart"
        self.add_class("visible")

    def start_subscription(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
    ) -> None:
        """Switch to subscription mode for the given signals/frames. Leaves focus where it is."""
        self._chart().reset()
        self._sub().start(signals, frames)
        self._mode = "subscription"
        self.add_class("visible")

    def on_signal_value(self, timestamp: int, value: float) -> None:
        """Forward a signal value to the chart view (chart mode only)."""
        if self._mode == "chart":
            self._chart().on_signal_value(timestamp, value)

    def on_frame_update(
        self,
        frame_key: str,
        payload: Any,
        timestamp: int,
        signals: dict[str, Any],
        watched_keys: set[str],
    ) -> None:
        """Forward a frame update to the subscription view (subscription mode only)."""
        if self._mode == "subscription":
            self._sub().on_frame_update(frame_key, payload, timestamp, signals, watched_keys)

    def reset(self) -> None:
        """Clear both views and hide."""
        self._chart().reset()
        self._sub().reset()
        self._mode = "none"
        self.remove_class("visible")

    def on_click(self) -> None:
        self.focus()

    def action_increase(self) -> None:
        if self._mode == "subscription":
            self._sub().adjust_history_depth(1)

    def action_decrease(self) -> None:
        if self._mode == "subscription":
            self._sub().adjust_history_depth(-1)

    def action_expand_all(self) -> None:
        if self._mode == "subscription":
            self._sub().action_expand_all()

    def action_collapse_all(self) -> None:
        if self._mode == "subscription":
            self._sub().action_collapse_all()


class DetailPanel(Static):
    """Displays signal/frame metadata with clickable filter fields."""

    class FilterInclude(Message):
        """Posted on left-click: immediately add an AND-include filter."""

        def __init__(self, field: str, value: str) -> None:
            super().__init__()
            self.field = field
            self.value = value

    class FilterChoose(Message):
        """Posted on right-click: open a popup to choose include/exclude/OR."""

        def __init__(self, field: str, value: str) -> None:
            super().__init__()
            self.field = field
            self.value = value

    def __init__(self, **kwargs: Any) -> None:
        super().__init__("", markup=True, **kwargs)
        self._row: Row | None = None
        self._line_fields: dict[int, tuple[str, str]] = {}
        self._last_button: int = 1

    def show(self, row: Row | None) -> None:
        self._row = row
        self._line_fields.clear()
        if row is None:
            self.update("")
        else:
            self.update(format_detail(row, line_fields=self._line_fields))

    def on_mouse_down(self, event: Any) -> None:
        self._last_button = getattr(event, "button", 1)

    def action_filter_clicked(self, field: str, value: str) -> None:
        """@click action — only apply on left-click; right-click is handled by on_click."""
        if self._last_button != 3:
            self.post_message(self.FilterInclude(field, value))

    def on_click(self, event: Any) -> None:
        """Right-click — open filter action chooser via line map."""
        button = getattr(event, "button", 1)
        if button != 3:
            return
        y = getattr(event, "y", -1)
        entry = self._line_fields.get(y)
        if entry is not None:
            field, value = entry
            self.post_message(self.FilterChoose(field, value))


class LeftPane(VerticalScroll, can_focus=False):
    """Left pane containing the signal tree. Bindings here show only when tree is focused."""

    BINDINGS = [
        Binding("e", "app.expand_all", "Expand all"),
        Binding("c", "app.collapse_all", "Collapse all"),
        Binding("s", "app.subscribe", "Subscribe"),
        Binding("p", "app.publish", "Publish"),
        Binding("m", "app.toggle_mark", "Mark"),
        Binding("M", "app.clear_marks", "Clear marks"),
        Binding("v", "app.broker_version", "Version"),
    ]


class SidebarHandle(Static):
    """Thin clickable strip shown when the sidebar is collapsed."""

    DEFAULT_CSS = """
    SidebarHandle {
        width: 3;
        height: 1fr;
        content-align: center middle;
        background: $surface;
    }
    SidebarHandle:hover {
        background: $surface-lighten-2;
    }
    """

    class Clicked(Message):
        """Posted when the handle is clicked."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__("◀", **kwargs)

    def on_click(self) -> None:
        self.post_message(self.Clicked())
