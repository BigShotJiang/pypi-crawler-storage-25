"""Modal screens for the TUI explorer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.events import Key
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Static

from .formatting import FrameRow, Row, SignalRow, _format_signal_hints

FilterAction = Literal["include", "exclude", "gt", "gte", "lt", "lte"]

# Non-FTS fields that support comparison operators
_NUMERIC_FIELDS: frozenset[str] = frozenset(
    {
        "start_bit",
        "size",
        "factor",
        "offset",
        "min",
        "max",
        "payload_size",
        "cycle_time",
    }
)


@dataclass
class FilterResult:
    action: FilterAction
    field: str
    value: str
    use_or: bool = False


class FilterActionModal(ModalScreen[FilterResult | None]):
    """Popup to choose a filter action with an OR toggle."""

    CSS = """
    FilterActionModal {
        align: center middle;
    }
    #filter-dialog {
        width: auto;
        min-width: 40;
        max-width: 70%;
        height: auto;
        padding: 1 2;
        background: $surface;
        border: thick $primary;
        layout: vertical;
    }
    #filter-dialog Button {
        width: 100%;
        margin-bottom: 1;
    }
    #or-toggle {
        margin-top: 1;
        width: 100%;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
        Binding("1", "pick_1", show=False),
        Binding("2", "pick_2", show=False),
        Binding("3", "pick_3", show=False),
        Binding("4", "pick_4", show=False),
        Binding("5", "pick_5", show=False),
        Binding("6", "pick_6", show=False),
        Binding("o", "toggle_or", "Toggle OR", show=False),
    ]

    def __init__(self, field: str, value: str) -> None:
        super().__init__()
        self._field = field
        self._value = value
        self._is_numeric = field in _NUMERIC_FIELDS
        self._use_or = False
        self._options: list[tuple[str, FilterAction]] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="filter-dialog"):
            yield Static(f"[bold]Filter[/bold]  [dim]{self._field}:[/dim] {self._value}")
            if self._is_numeric:
                self._options = [
                    (f"= {self._value}", "include"),
                    (f"!= {self._value}", "exclude"),
                    (f"> {self._value}", "gt"),
                    (f">= {self._value}", "gte"),
                    (f"< {self._value}", "lt"),
                    (f"<= {self._value}", "lte"),
                ]
            else:
                self._options = [
                    ("Include", "include"),
                    ("Exclude", "exclude"),
                ]
            for i, (label, action) in enumerate(self._options):
                variant: Literal["default", "primary", "warning"] = "primary" if i == 0 else "warning" if action == "exclude" else "default"
                yield Button(f"[{i + 1}] {label}", id=f"btn-{i}", variant=variant)
            yield Button("[o] Combine: AND", id="or-toggle", variant="default")

    def _update_or_label(self) -> None:
        mode = "OR" if self._use_or else "AND"
        self.query_one("#or-toggle", Button).label = f"[o] Combine: {mode}"

    def action_toggle_or(self) -> None:
        self._use_or = not self._use_or
        self._update_or_label()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "or-toggle":
            self.action_toggle_or()
            return
        if btn_id.startswith("btn-"):
            idx = int(btn_id.split("-")[1])
            if idx < len(self._options):
                self._dismiss_pick(idx)

    def _dismiss_pick(self, idx: int) -> None:
        if idx < len(self._options):
            self.dismiss(
                FilterResult(
                    action=self._options[idx][1],
                    field=self._field,
                    value=self._value,
                    use_or=self._use_or,
                )
            )

    def action_pick_1(self) -> None:
        self._dismiss_pick(0)

    def action_pick_2(self) -> None:
        self._dismiss_pick(1)

    def action_pick_3(self) -> None:
        self._dismiss_pick(2)

    def action_pick_4(self) -> None:
        self._dismiss_pick(3)

    def action_pick_5(self) -> None:
        self._dismiss_pick(4)

    def action_pick_6(self) -> None:
        self._dismiss_pick(5)

    def action_cancel(self) -> None:
        self.dismiss(None)


class PublishValuesModal(ModalScreen[list[tuple[str, str, str, str, int | None]] | None]):
    """Modal for entering values for a set of pre-selected signals."""

    CSS = """
    PublishValuesModal {
        align: center middle;
    }
    #values-dialog {
        width: auto;
        min-width: 60;
        max-width: 90%;
        height: auto;
        max-height: 80%;
        padding: 1 2;
        background: $surface;
        border: thick $primary;
        layout: vertical;
    }
    .value-entry {
        height: auto;
    }
    .value-row {
        layout: horizontal;
        height: auto;
        min-height: 3;
    }
    .value-row:focus-within {
        background: $surface-lighten-2;
    }
    .value-label {
        width: 1fr;
        content-align-vertical: middle;
    }
    .value-input {
        width: 1fr;
    }
    .signal-row .value-label {
        padding-left: 2;
    }
    #values-error {
        color: $error;
    }
    """

    AUTO_FOCUS = "Input"

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
        Binding("enter", "submit", "Publish", priority=True),
    ]

    def __init__(self, rows: list[Row]) -> None:
        super().__init__()
        self._rows = rows
        self._input_ids: list[str] = []

    def _group_rows(
        self,
    ) -> tuple[dict[str, dict[str, list[tuple[int, SignalRow]]]], dict[str, tuple[int, FrameRow]]]:
        by_ns_frame: dict[str, dict[str, list[tuple[int, SignalRow]]]] = {}
        frame_rows: dict[str, tuple[int, FrameRow]] = {}
        for i, row in enumerate(self._rows):
            ns = row.namespace
            fname = row.frame_name
            if isinstance(row, FrameRow):
                frame_rows[f"{ns}:{fname}"] = (i, row)
                by_ns_frame.setdefault(ns, {}).setdefault(fname, [])
            elif isinstance(row, SignalRow):
                by_ns_frame.setdefault(ns, {}).setdefault(fname, []).append((i, row))
        return by_ns_frame, frame_rows

    @staticmethod
    def _frame_label(fname: str, payload_size: int | None) -> str:
        if payload_size is not None:
            example = "FF" * payload_size
            return f"[yellow]{fname}[/yellow]  [dim]({payload_size} bytes, e.g. 0x{example})[/dim]"
        return f"[yellow]{fname}[/yellow]"

    def compose(self) -> ComposeResult:
        by_ns_frame, frame_rows = self._group_rows()

        with Vertical(id="values-dialog"):
            if len(self._rows) == 1:
                yield Static("[bold]Publish[/bold] (Enter to publish)")
            else:
                yield Static(f"[bold]Publish {len(self._rows)} item(s)[/bold] (Enter to publish)")
            with VerticalScroll():
                for ns in sorted(by_ns_frame):
                    yield Static(f"[bold]{ns}[/bold]")
                    for fname in sorted(by_ns_frame[ns]):
                        fkey = f"{ns}:{fname}"
                        if fkey in frame_rows:
                            i, frow = frame_rows[fkey]
                            yield from self._compose_value_row(i, self._frame_label(fname, frow.payload_size), "hex payload")
                        elif by_ns_frame[ns][fname]:
                            yield Static(f"[yellow]{fname}[/yellow]")
                        signals = sorted(by_ns_frame[ns][fname], key=lambda t: t[1].signal_name)
                        for i, srow in signals:
                            yield from self._compose_value_row(i, f"[green]{srow.signal_name}[/green]", "v1[,v2,...]", srow)
            yield Static("", id="values-error")

    def _compose_value_row(
        self,
        i: int,
        label: str,
        placeholder: str,
        signal: SignalRow | None = None,
    ) -> ComposeResult:
        if signal is not None:
            hints = _format_signal_hints(signal)
            if hints:
                label = f"{label}\n{hints}"
        input_id = f"val-{i}"
        self._input_ids.append(input_id)
        row_classes = "value-row signal-row" if signal is not None else "value-row"
        yield Horizontal(
            Static(label, classes="value-label"),
            Input(placeholder=placeholder, id=input_id, classes="value-input"),
            classes=row_classes,
        )

    def on_key(self, event: Key) -> None:
        if event.key not in ("up", "down") or len(self._input_ids) < 2:
            return
        focused = self.focused
        if not isinstance(focused, Input) or focused.id not in self._input_ids:
            return
        idx = self._input_ids.index(focused.id)
        if event.key == "up":
            idx = (idx - 1) % len(self._input_ids)
        else:
            idx = (idx + 1) % len(self._input_ids)
        self.query_one(f"#{self._input_ids[idx]}", Input).focus()
        event.prevent_default()

    def action_submit(self) -> None:
        results: list[tuple[str, str, str, str, int | None]] = []
        for i, row in enumerate(self._rows):
            try:
                inp = self.query_one(f"#val-{i}", Input)
                value = inp.value.strip()
                if value:
                    if isinstance(row, FrameRow):
                        results.append((row.namespace, row.frame_name, value, "frame", row.payload_size))
                    elif isinstance(row, SignalRow):
                        results.append((row.namespace, row.signal_name, value, "signal", None))
            except Exception:
                pass
        if results:
            self.dismiss(results)
        else:
            self.query_one("#values-error", Static).update("[red]Enter at least one value[/red]")

    def action_cancel(self) -> None:
        self.dismiss(None)
