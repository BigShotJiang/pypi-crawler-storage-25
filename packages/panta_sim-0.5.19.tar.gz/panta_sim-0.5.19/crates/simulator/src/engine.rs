use num_complex::Complex;
use qsim_core::complex::Real;
use qsim_core::operations::{
    apply_controlled_gate, apply_controlled_swap, apply_doubly_controlled_gate,
    apply_single_qubit_gate, apply_two_qubit_gate,
};
use qsim_core::{DensityMatrix, Gate, StateVector};
use qsim_gpu::wgpu_backend::{WgpuDensityOp, WgpuGateOp};
use qsim_gpu::GpuError;
use rand::rngs::StdRng;
use rand::Rng;
use rand::SeedableRng;

use crate::circuit::Circuit;
use crate::instruction::Instruction;
use crate::measurement;
use crate::result::{Backend, Precision, SimulationResult};

/// 회로 실행 엔진.
pub struct ExecutionEngine {
    seed: Option<u64>,
    precision: Precision,
    backend: Backend,
}

impl ExecutionEngine {
    pub fn new() -> Self {
        Self {
            seed: None,
            precision: Precision::default(),
            backend: Backend::default(),
        }
    }

    /// 재현 가능한 결과를 위한 시드 설정.
    pub fn with_seed(seed: u64) -> Self {
        Self {
            seed: Some(seed),
            precision: Precision::default(),
            backend: Backend::default(),
        }
    }

    /// 정밀도를 설정한 새 엔진 반환 (builder 패턴).
    pub fn with_precision(mut self, precision: Precision) -> Self {
        self.precision = precision;
        self
    }

    /// 백엔드를 설정한 새 엔진 반환 (v0.5.0 builder 패턴).
    pub fn with_backend(mut self, backend: Backend) -> Self {
        self.backend = backend;
        self
    }

    /// 회로를 실행하고 결과를 반환한다.  백엔드 / 정밀도에 따라 4 경로로 dispatch:
    /// (CpuStatevector, F64) / (CpuStatevector, F32) / (CpuDensity, F64) / (CpuDensity, F32).
    pub fn run(&self, circuit: &Circuit, shots: usize) -> SimulationResult {
        match (self.backend, self.precision) {
            (Backend::CpuStatevector, Precision::F64) => {
                let (counts, sv) = self.run_typed::<f64>(circuit, shots);
                SimulationResult::F64 {
                    counts,
                    statevector: sv,
                }
            }
            (Backend::CpuStatevector, Precision::F32) => {
                let (counts, sv) = self.run_typed::<f32>(circuit, shots);
                SimulationResult::F32 {
                    counts,
                    statevector: sv,
                }
            }
            (Backend::CpuDensity, Precision::F64) => {
                let (counts, rho) = self.run_typed_density::<f64>(circuit, shots);
                SimulationResult::DensityF64 {
                    counts,
                    density: rho,
                }
            }
            (Backend::CpuDensity, Precision::F32) => {
                let (counts, rho) = self.run_typed_density::<f32>(circuit, shots);
                SimulationResult::DensityF32 {
                    counts,
                    density: rho,
                }
            }
            (Backend::WgpuStatevector, _) => match self.run_wgpu_statevector(circuit, shots) {
                Ok((counts, sv)) => SimulationResult::F32 {
                    counts,
                    statevector: sv,
                },
                Err(e) => panic!("wgpu statevector backend 실패: {e}"),
            },
            (Backend::WgpuDensity, _) => match self.run_wgpu_density(circuit, shots) {
                Ok((counts, rho)) => SimulationResult::DensityF32 {
                    counts,
                    density: rho,
                },
                Err(e) => panic!("wgpu density backend 실패: {e}"),
            },
            (Backend::CudaStatevector, Precision::F32) => {
                match self.run_cuda_statevector(circuit, shots) {
                    Ok((counts, sv)) => SimulationResult::F32 {
                        counts,
                        statevector: sv,
                    },
                    Err(e) => panic!("cuda statevector backend 실패: {e}"),
                }
            }
            (Backend::CudaStatevector, Precision::F64) => {
                // v0.5.12: cuStateVec f64 (CUDA_C_64F) path.
                match self.run_cuda_statevector_f64(circuit, shots) {
                    Ok((counts, sv)) => SimulationResult::F64 {
                        counts,
                        statevector: sv,
                    },
                    Err(e) => panic!("cuda statevector f64 backend 실패: {e}"),
                }
            }
        }
    }

    /// 회로 실행 (Result 반환).  GpuError 또는 wgpu panic 모두 caller 가 처리.
    /// PyO3 binding 에서 wgpu backend 의 친화적 에러를 위해 사용.
    ///
    /// **v0.5.1 fix**: wgpu validation error 는 wgpu-core 의 default handler 로
    /// 인해 Rust panic 으로 떨어진다 (예: buffer 한계 초과, dispatch 한계 초과).
    /// `catch_unwind` 로 감싸 GpuError 로 변환 — Python 측에서 PyValueError 로
    /// 잡힘.  이전 v0.5.0 은 PyO3 가 PanicException (BaseException) 으로 노출해
    /// 사용자가 `except Exception` 으로 못 잡았음.
    pub fn run_checked(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<SimulationResult, GpuError> {
        use std::panic::AssertUnwindSafe;
        match (self.backend, self.precision) {
            (Backend::WgpuStatevector, _) => {
                let result = std::panic::catch_unwind(AssertUnwindSafe(|| {
                    self.run_wgpu_statevector(circuit, shots)
                }));
                match result {
                    Ok(Ok((counts, sv))) => Ok(SimulationResult::F32 {
                        counts,
                        statevector: sv,
                    }),
                    Ok(Err(e)) => Err(e),
                    Err(p) => Err(panic_to_gpu_error("wgpu statevector", p)),
                }
            }
            (Backend::WgpuDensity, _) => {
                let result = std::panic::catch_unwind(AssertUnwindSafe(|| {
                    self.run_wgpu_density(circuit, shots)
                }));
                match result {
                    Ok(Ok((counts, rho))) => Ok(SimulationResult::DensityF32 {
                        counts,
                        density: rho,
                    }),
                    Ok(Err(e)) => Err(e),
                    Err(p) => Err(panic_to_gpu_error("wgpu density", p)),
                }
            }
            (Backend::CudaStatevector, _) => {
                let (counts, sv) = self.run_cuda_statevector(circuit, shots)?;
                Ok(SimulationResult::F32 {
                    counts,
                    statevector: sv,
                })
            }
            _ => Ok(self.run(circuit, shots)),
        }
    }

    /// wgpu Tier-1 statevector backend 경로 (v0.5.0 Cut D.4).
    ///
    /// 회로의 ApplyGate 들을 [`WgpuGateOp`] 로 변환 후 backend.apply_circuit
    /// 으로 batch dispatch.  noise / dynamic 회로는 v0.5.x patch 로 deferred —
    /// 현재 ApplyNoise / Reset / Measure(중간) / IfEq / IfElse / WhileLoop /
    /// ForLoop / Switch 가 있으면 GpuError::Unsupported.
    ///
    /// Toffoli / Fredkin (3-qubit) 도 명시 거부 — Cut D 가 1q + 2q + controlled-1q
    /// scope.  사용자에게 transpile 권유 메시지.
    ///
    /// 측정은 statevector download 후 CPU 의 `measurement::sample` /
    /// `sample_with_cbit_map` 으로 처리 (이미 충분히 빠름).
    fn run_wgpu_statevector(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f32>), GpuError> {
        // v0.5.19: pre-flight memory warning — sv_size ≥ 4 GiB 시 stderr.
        // 사용자 환경 RAM 부족 시 OOM 발생 전에 사전 알림.
        let n_qubits = circuit.num_qubits();
        let sv_bytes: u64 = (1u64 << n_qubits).saturating_mul(8); // f32 complex = 8 byte
        let sv_gib = sv_bytes as f64 / (1u64 << 30) as f64;
        if sv_gib >= 4.0 {
            eprintln!(
                "[panta-sim] info: wgpu statevector N={n_qubits} → \
                 statevector {sv_gib:.2} GiB.  GPU/unified memory 충분한지 \
                 확인 권장 (intermediate buffer 추가 1~2 GiB 필요)."
            );
        }

        // v0.5.8: noise 회로 hybrid trajectory.
        // v0.5.9: dynamic 회로 (Reset / IfEq / IfElse / WhileLoop / ForLoop /
        // Switch / mid-circuit Measure) 도 같은 trajectory path 에서 처리.
        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));
        let has_dynamic = circuit.has_dynamic();
        if has_noise || has_dynamic {
            return self.run_wgpu_statevector_trajectory(circuit, shots);
        }

        // dynamic / noise 없는 fast path (기존 v0.5.x).
        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { .. } | Instruction::MeasureAll => {}
                Instruction::Measure { .. } => {
                    // explicit Measure 는 회로 끝의 trailing 만 허용 (cbit map).
                    // 중간 위치는 dynamic 으로 분류되므로 has_dynamic check 로 거부.
                }
                Instruction::ApplyNoise { .. } => unreachable!("noise 는 trajectory path"),
                Instruction::Reset { .. }
                | Instruction::IfEq { .. }
                | Instruction::IfElse { .. }
                | Instruction::WhileLoop { .. }
                | Instruction::ForLoop { .. }
                | Instruction::Switch { .. } => unreachable!("dynamic 은 위에서 거부됨"),
            }
        }

        // Gate → WgpuGateOp 변환.
        let mut ops: Vec<WgpuGateOp> = Vec::new();
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    convert_gate_to_wgpu_ops(gate, targets, &mut ops)?;
                }
                Instruction::Measure { qubit, cbit } => {
                    explicit_measures.push((*qubit, *cbit));
                }
                Instruction::MeasureAll => {
                    has_measure_all = true;
                }
                _ => unreachable!("dynamic instruction 은 이미 거부됨"),
            }
        }

        // Backend 가져오기 (v0.5.1: process-wide cached singleton — 첫 호출만 ~수백 ms).
        let backend = qsim_gpu::cached_wgpu_statevector_backend()?;
        let n = circuit.num_qubits();
        let dim = 1usize << n;
        let mut sv_data: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); dim];
        sv_data[0] = Complex::new(1.0, 0.0);
        backend.apply_circuit(&mut sv_data, &ops)?;

        // global_phase 적용.
        let lambda = circuit.global_phase();
        if lambda != 0.0 {
            let phase = Complex::new(lambda.cos() as f32, lambda.sin() as f32);
            for amp in &mut sv_data {
                *amp *= phase;
            }
        }

        // CPU StateVector 로 wrap.
        let mut state = StateVector::<f32>::new(n);
        state.amplitudes_mut().copy_from_slice(&sv_data);

        // RNG + sampling.
        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };
        let counts = if shots == 0 {
            std::collections::HashMap::new()
        } else if has_measure_all {
            measurement::sample(&state, shots, &mut rng)
        } else if !explicit_measures.is_empty() {
            measurement::sample_with_cbit_map(
                &state,
                shots,
                &explicit_measures,
                circuit.num_cbits(),
                &mut rng,
            )
        } else {
            std::collections::HashMap::new()
        };
        Ok((counts, state))
    }

    /// v0.5.8/v0.5.9: wgpu statevector + noise/dynamic hybrid trajectory path.
    ///
    /// 매 shot 마다 GPU 에서 |0⟩ init → consecutive gates 를 batch dispatch →
    /// `ApplyNoise` / dynamic instruction (Reset / IfEq / IfElse / WhileLoop /
    /// ForLoop / Switch / mid-circuit Measure) 만나면 batch flush + GPU →
    /// CPU download → CPU 에서 dispatch_instruction (Kraus / measure /
    /// classical control 모두 처리) → upload → 다음 batch.  회로 끝에서
    /// final download + CPU sampling.
    ///
    /// 성능: dynamic op 가 적은 큰 회로 (N≥20) 에서 GPU 가속 의미 있음.
    /// 잦으면 round-trip 비용 ↑ — 작은 N 은 `backend='cpu'` 권장.
    fn run_wgpu_statevector_trajectory(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f32>), GpuError> {
        let backend = qsim_gpu::cached_wgpu_statevector_backend()?;
        let n = circuit.num_qubits();
        let dim = 1usize << n;

        // trailing Measure (cbit map) 와 MeasureAll 수집 — 회로 마지막 위치
        // 만 대상.  중간 위치 Measure 는 has_dynamic 로 분류돼 trajectory 내부
        // dispatch_instruction 에서 처리.
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        let has_dyn = circuit.has_dynamic();
        if !has_dyn {
            // 동적 분류 안 됐으면 모든 Measure / MeasureAll 가 trailing.
            for inst in circuit.instructions() {
                match inst {
                    Instruction::Measure { qubit, cbit } => {
                        explicit_measures.push((*qubit, *cbit));
                    }
                    Instruction::MeasureAll => {
                        has_measure_all = true;
                    }
                    _ => {}
                }
            }
        }

        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };

        let lambda = circuit.global_phase();
        let phase = if lambda != 0.0 {
            Some(Complex::new(lambda.cos() as f32, lambda.sin() as f32))
        } else {
            None
        };

        let n_cbits = circuit.num_cbits();
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut last_sv: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); dim];
        let trajectories = shots.max(1);

        for _shot in 0..trajectories {
            let mut sv: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); dim];
            sv[0] = Complex::new(1.0, 0.0);
            let mut cbits: Vec<u8> = vec![0; n_cbits];

            // Gate batch 누적, dynamic / noise 만나면 flush + CPU dispatch.
            let mut pending_ops: Vec<WgpuGateOp> = Vec::new();
            for inst in circuit.instructions() {
                match inst {
                    Instruction::ApplyGate { gate, targets } => {
                        convert_gate_to_wgpu_ops(gate, targets, &mut pending_ops)?;
                    }
                    // 회로 끝의 trailing measure 는 final 단계에서 sampling.
                    Instruction::MeasureAll if !has_dyn => {}
                    Instruction::Measure { .. } if !has_dyn => {}
                    // 그 외 모두 (noise, dynamic) → flush + CPU dispatch.
                    _ => {
                        if !pending_ops.is_empty() {
                            backend.apply_circuit(&mut sv, &pending_ops)?;
                            pending_ops.clear();
                        }
                        let mut state_cpu = StateVector::<f32>::new(n);
                        state_cpu.amplitudes_mut().copy_from_slice(&sv);
                        Self::dispatch_instruction::<f32>(
                            inst,
                            &mut state_cpu,
                            &mut cbits,
                            &mut rng,
                        );
                        sv.copy_from_slice(state_cpu.amplitudes());
                    }
                }
            }
            if !pending_ops.is_empty() {
                backend.apply_circuit(&mut sv, &pending_ops)?;
            }
            if let Some(p) = phase {
                for amp in &mut sv {
                    *amp *= p;
                }
            }

            // Sample 한 trajectory.
            if shots > 0 {
                if has_dyn {
                    // dynamic 회로의 cbit register 를 LSB-first bitstring 으로.
                    if n_cbits > 0 {
                        let bits: String = (0..n_cbits)
                            .rev()
                            .map(|i| if cbits[i] != 0 { '1' } else { '0' })
                            .collect();
                        *counts.entry(bits).or_insert(0) += 1;
                    } else if has_measure_all {
                        let mut state_cpu = StateVector::<f32>::new(n);
                        state_cpu.amplitudes_mut().copy_from_slice(&sv);
                        let bits = measurement::sample_once(&state_cpu, &mut rng);
                        *counts.entry(bits).or_insert(0) += 1;
                    }
                } else {
                    let mut state_cpu = StateVector::<f32>::new(n);
                    state_cpu.amplitudes_mut().copy_from_slice(&sv);
                    if has_measure_all {
                        let bits = measurement::sample_once(&state_cpu, &mut rng);
                        *counts.entry(bits).or_insert(0) += 1;
                    } else if !explicit_measures.is_empty() {
                        let one = measurement::sample_with_cbit_map(
                            &state_cpu,
                            1,
                            &explicit_measures,
                            n_cbits,
                            &mut rng,
                        );
                        for (k, v) in one {
                            *counts.entry(k).or_insert(0) += v;
                        }
                    }
                }
            }

            last_sv = sv;
        }

        let mut final_state = StateVector::<f32>::new(n);
        final_state.amplitudes_mut().copy_from_slice(&last_sv);
        Ok((counts, final_state))
    }

    /// 정밀도 `F` 로 회로 실행. f32/f64 경로 모두 동일 코드 (monomorphized).
    ///
    /// 회로에 [`Instruction::ApplyNoise`] 또는 dynamic instruction (`Reset`/`IfEq`/
    /// 위치별 `Measure`) 이 하나라도 있으면 **trajectory 모드** 로 전환된다
    /// (각 shot 마다 회로 fresh 재실행 + cbit register + 위치별 즉시 처리).
    /// 둘 다 없으면 기존 fast path (1회 unitary evolution + N shot 샘플링).
    ///
    /// 반환되는 statevector 는 trajectory 모드일 땐 *마지막 trajectory* 의 것
    /// (디버깅 용, mixed state 를 대표하지 않음 — 사용자는 counts 를 사용).
    fn run_typed<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };

        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));

        if has_noise || circuit.has_dynamic() {
            self.run_typed_trajectory::<F>(circuit, shots, &mut rng)
        } else {
            self.run_typed_unitary::<F>(circuit, shots, &mut rng)
        }
    }

    /// Noise / dynamic 없는 경로 (fast): 1회 evolution → N shot 샘플링.
    ///
    /// **샘플러 분기 (v0.4.5.1)**:
    /// - `MeasureAll` 만 → [`measurement::sample`] (`n_qubits` 폭 비트열).
    /// - explicit `Measure { qubit, cbit }` 묶음만 → [`measurement::sample_with_cbit_map`]
    ///   (`n_cbits` 폭 + cbit 매핑 적용). v0.4.5.0 에서는 이 경로도 [`sample`] 을
    ///   썼는데 cbit 매핑이 무시돼 partial measure / cbit reorder / 동일 큐비트
    ///   두 번 측정 시 잘못된 결과를 냈음. v0.4.5.1 에서 정정.
    /// - 두 변종이 섞이면 (드문 케이스) 안전하게 [`Circuit::has_dynamic`] 가
    ///   true 를 반환하도록 빌더에서 막혀 있어 여기 도달 안 함 (실제로는 둘 다
    ///   trailing 일 수 있어 dynamic 분류 안 됨 — 이 경우 MeasureAll 우선).
    fn run_typed_unitary<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
        rng: &mut StdRng,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut state: StateVector<F> = StateVector::new(circuit.num_qubits());
        let mut has_measure_all = false;
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();

        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    apply_gate_typed(&mut state, gate, targets);
                }
                Instruction::ApplyNoise { .. } => {
                    unreachable!("run_typed_unitary called with noise instruction")
                }
                Instruction::Measure { qubit, cbit } => {
                    explicit_measures.push((*qubit, *cbit));
                }
                Instruction::MeasureAll => {
                    has_measure_all = true;
                }
                Instruction::Reset { .. }
                | Instruction::IfEq { .. }
                | Instruction::IfElse { .. }
                | Instruction::WhileLoop { .. }
                | Instruction::ForLoop { .. }
                | Instruction::Switch { .. } => {
                    unreachable!("run_typed_unitary called with dynamic instruction")
                }
            }
        }

        apply_global_phase::<F>(&mut state, circuit.global_phase());

        let counts = if shots == 0 {
            std::collections::HashMap::new()
        } else if has_measure_all {
            // MeasureAll 우선 (둘 다 trailing 인 드문 경우 포함).
            measurement::sample(&state, shots, rng)
        } else if !explicit_measures.is_empty() {
            measurement::sample_with_cbit_map(
                &state,
                shots,
                &explicit_measures,
                circuit.num_cbits(),
                rng,
            )
        } else {
            std::collections::HashMap::new()
        };

        (counts, state)
    }

    /// Noise / dynamic 경로 (trajectory): shot 마다 회로 재실행 + cbit register +
    /// 위치별 Measure 즉시 처리 + Reset / IfEq dispatch.
    ///
    /// `shots == 0` 이면 단일 trajectory 만 실행하고 counts 는 비워서 반환 (statevector
    /// 디버깅 용도). `shots > 0` 이면 각 trajectory 마다 cbit register 를 LSB-first
    /// 패킹해 outcome 문자열로 만들어 누적. 회로에 위치별 측정만 있고 `MeasureAll` 없는
    /// 경우 cbit register 그대로 outcome (creg width = `num_cbits`).  `MeasureAll` 이
    /// 끝에 있으면 trajectory 끝 상태에서 한 번 더 sampling (기존 v0.4.0 호환).
    fn run_typed_trajectory<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
        rng: &mut StdRng,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut last_state: Option<StateVector<F>> = None;

        let has_measure_all = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::MeasureAll));
        let has_explicit_measure = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::Measure { .. }));

        let n_trajectories = if shots == 0 { 1 } else { shots };
        let lambda = circuit.global_phase();
        let n_cbits = circuit.num_cbits();
        let n_qubits = circuit.num_qubits();

        for _ in 0..n_trajectories {
            let mut state: StateVector<F> = StateVector::new(n_qubits);
            let mut cbits: Vec<u8> = vec![0; n_cbits];
            for inst in circuit.instructions() {
                Self::dispatch_instruction::<F>(inst, &mut state, &mut cbits, rng);
            }
            apply_global_phase::<F>(&mut state, lambda);

            if shots > 0 {
                if has_measure_all {
                    // trajectory 끝 sampling (v0.4.0 호환 — MeasureAll 가 있으면 dynamic
                    // 회로라도 끝에서 한 번 더 측정한 것으로 간주).
                    let outcome = measurement::sample_once(&state, rng);
                    *counts.entry(outcome).or_insert(0) += 1;
                } else if has_explicit_measure {
                    // creg 의 cbits 를 LSB-first packed bit string 으로.
                    // MSB = cbits[n_cbits-1], LSB = cbits[0] — Qiskit counts 표기와 동일.
                    let mut s = String::with_capacity(n_cbits);
                    for &b in cbits.iter().rev() {
                        s.push(if b == 0 { '0' } else { '1' });
                    }
                    *counts.entry(s).or_insert(0) += 1;
                }
                // 측정도 MeasureAll 도 없으면 counts 비워둠 (statevector 디버깅 path).
            }

            last_state = Some(state);
        }

        (counts, last_state.expect("at least one trajectory"))
    }

    /// 단일 instruction 을 trajectory 상태에 dispatch.
    /// `IfEq` 의 body 재귀 적용 시에도 동일 함수 호출.
    fn dispatch_instruction<F: Real>(
        inst: &Instruction,
        state: &mut StateVector<F>,
        cbits: &mut [u8],
        rng: &mut StdRng,
    ) {
        match inst {
            Instruction::ApplyGate { gate, targets } => {
                apply_gate_typed(state, gate, targets);
            }
            Instruction::ApplyNoise { channel, target } => {
                channel.apply_to(state, *target, rng);
            }
            Instruction::Measure { qubit, cbit } => {
                let outcome = measurement::measure_qubit_inplace(state, *qubit, rng);
                if *cbit < cbits.len() {
                    cbits[*cbit] = outcome;
                }
                // *cbit >= cbits.len() 은 빌더가 자동 grow 하므로 도달 안 함.
            }
            Instruction::MeasureAll => {
                // trajectory 끝에서 별도 sampling. 여기선 no-op.
            }
            Instruction::Reset { qubit } => {
                measurement::reset_qubit(state, *qubit, rng);
            }
            Instruction::IfEq {
                cbit_indices,
                value,
                body,
            } => {
                if pack_cbits(cbit_indices, cbits) == *value {
                    Self::dispatch_instruction::<F>(body, state, cbits, rng);
                }
            }
            Instruction::IfElse {
                cbit_indices,
                value,
                then_body,
                else_body,
            } => {
                let packed = pack_cbits(cbit_indices, cbits);
                let body: Option<&[Instruction]> = if packed == *value {
                    Some(then_body.as_slice())
                } else {
                    else_body.as_deref()
                };
                if let Some(insts) = body {
                    for inst in insts {
                        Self::dispatch_instruction::<F>(inst, state, cbits, rng);
                    }
                }
            }
            Instruction::WhileLoop {
                cbit_indices,
                value,
                body,
                max_iters,
            } => {
                // cond 가 true 인 동안 body 반복. max_iters 안전 bound.
                for _ in 0..*max_iters {
                    if pack_cbits(cbit_indices, cbits) != *value {
                        break;
                    }
                    for inst in body {
                        Self::dispatch_instruction::<F>(inst, state, cbits, rng);
                    }
                }
            }
            Instruction::ForLoop { iterations, body } => {
                for _ in 0..*iterations {
                    for inst in body {
                        Self::dispatch_instruction::<F>(inst, state, cbits, rng);
                    }
                }
            }
            Instruction::Switch {
                cbit_indices,
                cases,
            } => {
                let packed = pack_cbits(cbit_indices, cbits);
                let mut chosen: Option<&Vec<Instruction>> = None;
                let mut default: Option<&Vec<Instruction>> = None;
                for (label, body) in cases {
                    match label {
                        Some(v) if *v == packed => {
                            chosen = Some(body);
                            break;
                        }
                        None => default = Some(body),
                        _ => {}
                    }
                }
                let body = chosen.or(default);
                if let Some(insts) = body {
                    for inst in insts {
                        Self::dispatch_instruction::<F>(inst, state, cbits, rng);
                    }
                }
            }
        }
    }

    /// Density matrix 백엔드 경로 (v0.5.0).
    ///
    /// 회로의 모든 instruction 을 순서대로 ρ 에 dispatch 한다.  noise 가 있어도
    /// trajectory 가 아닌 결정적 Kraus 적용 — Aer `method="density_matrix"` 와
    /// 동일 의미.  shots > 0 이고 측정이 있으면 단일 evolution 끝에서 N 회
    /// CDF 샘플링 (각 trajectory 재실행 X).
    ///
    /// dynamic 회로 (Reset / IfEq / IfElse / WhileLoop / ForLoop / Switch /
    /// 위치별 Measure) 는 측정 outcome 이 cbit 에 들어가야 다음 분기가 결정되므로
    /// shot 당 fresh ρ 진화 + 위치별 measure_collapse + cbit register.  shots=0
    /// 은 단일 trajectory 의 ρ 만 반환.
    ///
    /// counts 표기 (statevector 경로와 동일):
    /// - MeasureAll 만: `n_qubits` 폭 LSB-first 비트열.
    /// - explicit Measure 만: `n_cbits` 폭 LSB-first.
    /// - 둘 다 없음: counts 비움 (디버깅 용 ρ 만).
    fn run_typed_density<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> (std::collections::HashMap<String, usize>, DensityMatrix<F>) {
        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };
        let n_qubits = circuit.num_qubits();
        let n_cbits = circuit.num_cbits();
        let lambda = circuit.global_phase();

        let has_measure_all = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::MeasureAll));
        let has_dynamic = circuit.has_dynamic();
        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));

        // Dynamic 회로는 cbit 분기가 측정 결과에 의존 → trajectory 모드.
        // 그렇지 않으면 단일 ρ 진화 + (있다면) 끝에서 sampling.
        if has_dynamic {
            self.run_typed_density_trajectory::<F>(circuit, shots, &mut rng)
        } else {
            // Static 경로: ρ 한 번 진화 후 끝에서 sampling.
            let mut rho: DensityMatrix<F> = DensityMatrix::new(n_qubits);
            let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
            for inst in circuit.instructions() {
                match inst {
                    Instruction::ApplyGate { gate, targets } => {
                        apply_gate_typed_density(&mut rho, gate, targets);
                    }
                    Instruction::ApplyNoise { channel, target } => {
                        let kraus = channel.kraus_operators::<F>();
                        rho.apply_kraus_1q(&kraus, *target);
                    }
                    Instruction::Measure { qubit, cbit } => {
                        explicit_measures.push((*qubit, *cbit));
                    }
                    Instruction::MeasureAll => {}
                    // dynamic instruction 은 has_dynamic 분기에서 처리.
                    Instruction::Reset { .. }
                    | Instruction::IfEq { .. }
                    | Instruction::IfElse { .. }
                    | Instruction::WhileLoop { .. }
                    | Instruction::ForLoop { .. }
                    | Instruction::Switch { .. } => {
                        unreachable!("density static path with dynamic instruction")
                    }
                }
            }
            apply_global_phase_density::<F>(&mut rho, lambda);

            let counts = if shots == 0 {
                std::collections::HashMap::new()
            } else if has_measure_all {
                sample_density(&rho, shots, n_qubits, &mut rng)
            } else if !explicit_measures.is_empty() {
                sample_density_with_cbit_map(&rho, shots, &explicit_measures, n_cbits, &mut rng)
            } else {
                std::collections::HashMap::new()
            };
            // noise 없는 회로는 결정적 (RNG 사용 안함) — 빠른 path.
            // noise 있어도 ρ 는 결정적, RNG 는 sampling 에만 사용.
            let _ = has_noise; // 위 분기에서 자동 처리.
            (counts, rho)
        }
    }

    /// Density 백엔드 의 dynamic 회로 경로 (shot 당 fresh ρ).
    fn run_typed_density_trajectory<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
        rng: &mut StdRng,
    ) -> (std::collections::HashMap<String, usize>, DensityMatrix<F>) {
        let n_qubits = circuit.num_qubits();
        let n_cbits = circuit.num_cbits();
        let lambda = circuit.global_phase();
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut last_rho: Option<DensityMatrix<F>> = None;

        let has_measure_all = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::MeasureAll));
        let has_explicit_measure = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::Measure { .. }));
        let n_trajectories = if shots == 0 { 1 } else { shots };

        for _ in 0..n_trajectories {
            let mut rho: DensityMatrix<F> = DensityMatrix::new(n_qubits);
            let mut cbits: Vec<u8> = vec![0; n_cbits];
            for inst in circuit.instructions() {
                Self::dispatch_instruction_density::<F>(inst, &mut rho, &mut cbits, rng);
            }
            apply_global_phase_density::<F>(&mut rho, lambda);

            if shots > 0 {
                if has_measure_all {
                    let outcome = sample_density_once(&rho, n_qubits, rng);
                    *counts.entry(outcome).or_insert(0) += 1;
                } else if has_explicit_measure {
                    let mut s = String::with_capacity(n_cbits);
                    for &b in cbits.iter().rev() {
                        s.push(if b == 0 { '0' } else { '1' });
                    }
                    *counts.entry(s).or_insert(0) += 1;
                }
            }
            last_rho = Some(rho);
        }
        (counts, last_rho.expect("at least one trajectory"))
    }

    /// Density 백엔드 의 instruction dispatch.  statevector 의
    /// [`dispatch_instruction`](Self::dispatch_instruction) 와 평행 구조.
    fn dispatch_instruction_density<F: Real>(
        inst: &Instruction,
        rho: &mut DensityMatrix<F>,
        cbits: &mut [u8],
        rng: &mut StdRng,
    ) {
        match inst {
            Instruction::ApplyGate { gate, targets } => {
                apply_gate_typed_density(rho, gate, targets);
            }
            Instruction::ApplyNoise { channel, target } => {
                let kraus = channel.kraus_operators::<F>();
                rho.apply_kraus_1q(&kraus, *target);
            }
            Instruction::Measure { qubit, cbit } => {
                let outcome = rho.measure_collapse(*qubit, rng);
                if *cbit < cbits.len() {
                    cbits[*cbit] = outcome;
                }
            }
            Instruction::MeasureAll => {
                // trajectory 끝 sampling.  여기선 no-op.
            }
            Instruction::Reset { qubit } => {
                rho.reset_qubit(*qubit);
            }
            Instruction::IfEq {
                cbit_indices,
                value,
                body,
            } => {
                if pack_cbits(cbit_indices, cbits) == *value {
                    Self::dispatch_instruction_density::<F>(body, rho, cbits, rng);
                }
            }
            Instruction::IfElse {
                cbit_indices,
                value,
                then_body,
                else_body,
            } => {
                let packed = pack_cbits(cbit_indices, cbits);
                let body: Option<&[Instruction]> = if packed == *value {
                    Some(then_body.as_slice())
                } else {
                    else_body.as_deref()
                };
                if let Some(insts) = body {
                    for inst in insts {
                        Self::dispatch_instruction_density::<F>(inst, rho, cbits, rng);
                    }
                }
            }
            Instruction::WhileLoop {
                cbit_indices,
                value,
                body,
                max_iters,
            } => {
                for _ in 0..*max_iters {
                    if pack_cbits(cbit_indices, cbits) != *value {
                        break;
                    }
                    for inst in body {
                        Self::dispatch_instruction_density::<F>(inst, rho, cbits, rng);
                    }
                }
            }
            Instruction::ForLoop { iterations, body } => {
                for _ in 0..*iterations {
                    for inst in body {
                        Self::dispatch_instruction_density::<F>(inst, rho, cbits, rng);
                    }
                }
            }
            Instruction::Switch {
                cbit_indices,
                cases,
            } => {
                let packed = pack_cbits(cbit_indices, cbits);
                let mut chosen: Option<&Vec<Instruction>> = None;
                let mut default: Option<&Vec<Instruction>> = None;
                for (label, body) in cases {
                    match label {
                        Some(v) if *v == packed => {
                            chosen = Some(body);
                            break;
                        }
                        None => default = Some(body),
                        _ => {}
                    }
                }
                let body = chosen.or(default);
                if let Some(insts) = body {
                    for inst in insts {
                        Self::dispatch_instruction_density::<F>(inst, rho, cbits, rng);
                    }
                }
            }
        }
    }

    /// cuStateVec Tier-2 statevector backend 경로 (Cut G, feature `gpu-cuda`).
    ///
    /// `gpu-cuda` feature off 일 때 (sandbox / non-NVIDIA) 는 GpuError::Unsupported
    /// 반환 — Python 측 PyValueError 로 변환되어 사용자에게 안내.  NVIDIA + cuQuantum
    /// 환경에선 `CudaStatevectorBackend::apply_circuit` 으로 dispatch.
    #[cfg(feature = "gpu-cuda")]
    fn run_cuda_statevector(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f32>), GpuError> {
        use qsim_gpu::cuda::{CudaGateOp, CudaStatevectorBackend};

        // v0.5.12: noise / dynamic 회로는 hybrid trajectory path 진입 (wgpu
        // v0.5.8/9 패턴 복제 — cuda 호출 swap).
        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));
        let has_dynamic = circuit.has_dynamic();
        if has_noise || has_dynamic {
            return self.run_cuda_statevector_trajectory(circuit, shots);
        }

        let mut ops: Vec<CudaGateOp> = Vec::new();
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    convert_gate_to_cuda_ops(gate, targets, &mut ops)?;
                }
                Instruction::ApplyNoise { .. } => unreachable!("noise 는 trajectory path"),
                Instruction::Measure { qubit, cbit } => {
                    explicit_measures.push((*qubit, *cbit));
                }
                Instruction::MeasureAll => has_measure_all = true,
                _ => unreachable!("dynamic instruction 은 이미 거부됨"),
            }
        }

        let n = circuit.num_qubits();
        let dim = 1usize << n;
        let mut sv_data: Vec<num_complex::Complex<f32>> =
            vec![num_complex::Complex::new(0.0, 0.0); dim];
        sv_data[0] = num_complex::Complex::new(1.0, 0.0);

        let backend = CudaStatevectorBackend::new()?;
        backend.apply_circuit(&mut sv_data, &ops)?;

        let lambda = circuit.global_phase();
        if lambda != 0.0 {
            let phase = num_complex::Complex::new(lambda.cos() as f32, lambda.sin() as f32);
            for amp in &mut sv_data {
                *amp *= phase;
            }
        }

        let mut state = StateVector::<f32>::new(n);
        state.amplitudes_mut().copy_from_slice(&sv_data);

        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };
        let counts = if shots == 0 {
            std::collections::HashMap::new()
        } else if has_measure_all {
            measurement::sample(&state, shots, &mut rng)
        } else if !explicit_measures.is_empty() {
            measurement::sample_with_cbit_map(
                &state,
                shots,
                &explicit_measures,
                circuit.num_cbits(),
                &mut rng,
            )
        } else {
            std::collections::HashMap::new()
        };
        Ok((counts, state))
    }

    /// v0.5.12: cuda statevector + noise/dynamic hybrid trajectory path.
    /// wgpu trajectory (v0.5.8/9) 와 동일 패턴 — 매 trajectory 마다 GPU 에서
    /// gate batch dispatch + ApplyNoise/dynamic 만나면 download + CPU
    /// dispatch_instruction + upload.  사용자 NVIDIA PC 검증 대기.
    #[cfg(feature = "gpu-cuda")]
    fn run_cuda_statevector_trajectory(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f32>), GpuError> {
        use qsim_gpu::cuda::CudaStatevectorBackend;

        let backend = CudaStatevectorBackend::new()?;
        let n = circuit.num_qubits();
        let dim = 1usize << n;

        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        let has_dyn = circuit.has_dynamic();
        if !has_dyn {
            for inst in circuit.instructions() {
                match inst {
                    Instruction::Measure { qubit, cbit } => {
                        explicit_measures.push((*qubit, *cbit));
                    }
                    Instruction::MeasureAll => has_measure_all = true,
                    _ => {}
                }
            }
        }

        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };

        let lambda = circuit.global_phase();
        let phase = if lambda != 0.0 {
            Some(num_complex::Complex::new(
                lambda.cos() as f32,
                lambda.sin() as f32,
            ))
        } else {
            None
        };

        let n_cbits = circuit.num_cbits();
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut last_sv: Vec<num_complex::Complex<f32>> =
            vec![num_complex::Complex::new(0.0, 0.0); dim];
        let trajectories = shots.max(1);

        for _shot in 0..trajectories {
            let mut sv: Vec<num_complex::Complex<f32>> =
                vec![num_complex::Complex::new(0.0, 0.0); dim];
            sv[0] = num_complex::Complex::new(1.0, 0.0);
            let mut cbits: Vec<u8> = vec![0; n_cbits];

            let mut pending_ops: Vec<qsim_gpu::cuda::CudaGateOp> = Vec::new();
            for inst in circuit.instructions() {
                match inst {
                    Instruction::ApplyGate { gate, targets } => {
                        convert_gate_to_cuda_ops(gate, targets, &mut pending_ops)?;
                    }
                    Instruction::MeasureAll if !has_dyn => {}
                    Instruction::Measure { .. } if !has_dyn => {}
                    _ => {
                        if !pending_ops.is_empty() {
                            backend.apply_circuit(&mut sv, &pending_ops)?;
                            pending_ops.clear();
                        }
                        let mut state_cpu = StateVector::<f32>::new(n);
                        state_cpu.amplitudes_mut().copy_from_slice(&sv);
                        Self::dispatch_instruction::<f32>(
                            inst,
                            &mut state_cpu,
                            &mut cbits,
                            &mut rng,
                        );
                        sv.copy_from_slice(state_cpu.amplitudes());
                    }
                }
            }
            if !pending_ops.is_empty() {
                backend.apply_circuit(&mut sv, &pending_ops)?;
            }
            if let Some(p) = phase {
                for amp in &mut sv {
                    *amp *= p;
                }
            }

            if shots > 0 {
                if has_dyn {
                    if n_cbits > 0 {
                        let bits: String = (0..n_cbits)
                            .rev()
                            .map(|i| if cbits[i] != 0 { '1' } else { '0' })
                            .collect();
                        *counts.entry(bits).or_insert(0) += 1;
                    } else if has_measure_all {
                        let mut state_cpu = StateVector::<f32>::new(n);
                        state_cpu.amplitudes_mut().copy_from_slice(&sv);
                        let bits = measurement::sample_once(&state_cpu, &mut rng);
                        *counts.entry(bits).or_insert(0) += 1;
                    }
                } else {
                    let mut state_cpu = StateVector::<f32>::new(n);
                    state_cpu.amplitudes_mut().copy_from_slice(&sv);
                    if has_measure_all {
                        let bits = measurement::sample_once(&state_cpu, &mut rng);
                        *counts.entry(bits).or_insert(0) += 1;
                    } else if !explicit_measures.is_empty() {
                        let one = measurement::sample_with_cbit_map(
                            &state_cpu,
                            1,
                            &explicit_measures,
                            n_cbits,
                            &mut rng,
                        );
                        for (k, v) in one {
                            *counts.entry(k).or_insert(0) += v;
                        }
                    }
                }
            }

            last_sv = sv;
        }

        let mut final_state = StateVector::<f32>::new(n);
        final_state.amplitudes_mut().copy_from_slice(&last_sv);
        Ok((counts, final_state))
    }

    /// v0.5.12: cuStateVec f64 (CUDA_C_64F) statevector path.
    ///
    /// 양자 화학 / VQE 같은 정밀 계산 (norm error < 1e-12) 영역.  Apple Metal
    /// 의 wgpu 는 f64 미지원 — cuStateVec Tier-2 에서만 가용.  noise / dynamic
    /// 회로는 v0.5.x 후속 patch — 현재 거부.
    #[cfg(feature = "gpu-cuda")]
    fn run_cuda_statevector_f64(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f64>), GpuError> {
        use qsim_gpu::cuda::{CudaGateOpF64, CudaStatevectorBackend};

        if circuit.has_dynamic() {
            return Err(GpuError::Unsupported(
                "cuda statevector f64: dynamic 회로는 v0.5.x patch — \
                 backend='cpu' precision='double' 사용"
                    .into(),
            ));
        }
        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));
        if has_noise {
            return Err(GpuError::Unsupported(
                "cuda statevector f64: noise 회로는 v0.5.x patch — \
                 backend='cpu' precision='double' 사용"
                    .into(),
            ));
        }

        let mut ops: Vec<CudaGateOpF64> = Vec::new();
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    convert_gate_to_cuda_ops_f64(gate, targets, &mut ops)?;
                }
                Instruction::Measure { qubit, cbit } => {
                    explicit_measures.push((*qubit, *cbit));
                }
                Instruction::MeasureAll => has_measure_all = true,
                _ => unreachable!("noise / dynamic 은 위에서 거부됨"),
            }
        }

        let n = circuit.num_qubits();
        let dim = 1usize << n;
        let mut sv_data: Vec<num_complex::Complex<f64>> =
            vec![num_complex::Complex::new(0.0, 0.0); dim];
        sv_data[0] = num_complex::Complex::new(1.0, 0.0);

        let backend = CudaStatevectorBackend::new()?;
        backend.apply_circuit_f64(&mut sv_data, &ops)?;

        let lambda = circuit.global_phase();
        if lambda != 0.0 {
            let phase = num_complex::Complex::new(lambda.cos(), lambda.sin());
            for amp in &mut sv_data {
                *amp *= phase;
            }
        }

        let mut state = StateVector::<f64>::new(n);
        state.amplitudes_mut().copy_from_slice(&sv_data);

        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };
        let counts = if shots == 0 {
            std::collections::HashMap::new()
        } else if has_measure_all {
            measurement::sample(&state, shots, &mut rng)
        } else if !explicit_measures.is_empty() {
            measurement::sample_with_cbit_map(
                &state,
                shots,
                &explicit_measures,
                circuit.num_cbits(),
                &mut rng,
            )
        } else {
            std::collections::HashMap::new()
        };
        Ok((counts, state))
    }

    /// f64 stub (gpu-cuda feature off 시).
    #[cfg(not(feature = "gpu-cuda"))]
    fn run_cuda_statevector_f64(
        &self,
        _circuit: &Circuit,
        _shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f64>), GpuError> {
        Err(GpuError::Unsupported(
            "cuda statevector f64: panta-sim 이 'gpu-cuda' feature 없이 빌드됨".into(),
        ))
    }

    /// `gpu-cuda` feature off 시의 stub.  Python / cargo 사용자에게 친화적 에러.
    #[cfg(not(feature = "gpu-cuda"))]
    fn run_cuda_statevector(
        &self,
        _circuit: &Circuit,
        _shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, StateVector<f32>), GpuError> {
        Err(GpuError::Unsupported(
            "cuda statevector: panta-sim 이 'gpu-cuda' feature 없이 빌드됨. \
             NVIDIA + cuQuantum 환경에서 `cargo build --features gpu-cuda` 또는 \
             maturin develop --features gpu-cuda 로 다시 빌드 필요"
                .into(),
        ))
    }

    /// wgpu Tier-1 density backend 경로 (Cut E).
    ///
    /// 회로의 ApplyGate / ApplyNoise 를 WgpuDensityOp 로 변환 후
    /// `apply_circuit` 에 dispatch.  noise 는 deterministic Kraus
    /// (Aer method=density_matrix 와 동일 의미).
    ///
    /// dynamic 회로 (Reset / IfEq / Measure / IfElse / WhileLoop / ForLoop /
    /// Switch) 와 3-qubit gate (Toffoli, Fredkin) 은 거부 — v0.5.x patch.
    /// MeasureAll 은 ρ 끝의 sampling 으로 처리.
    fn run_wgpu_density(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> Result<(std::collections::HashMap<String, usize>, DensityMatrix<f32>), GpuError> {
        if circuit.has_dynamic() {
            return Err(GpuError::Unsupported(
                "wgpu density: dynamic 회로 (reset / classical control / loops) \
                 는 v0.5.x patch — backend='cpu' + method='density_matrix' 사용"
                    .into(),
            ));
        }
        let mut ops: Vec<WgpuDensityOp> = Vec::new();
        let mut explicit_measures: Vec<(usize, usize)> = Vec::new();
        let mut has_measure_all = false;
        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    convert_gate_to_density_ops(gate, targets, &mut ops)?;
                }
                Instruction::ApplyNoise { channel, target } => {
                    let kraus_f32 = channel.kraus_operators::<f32>();
                    ops.push(WgpuDensityOp::Kraus1q {
                        kraus: kraus_f32,
                        target: *target,
                    });
                }
                Instruction::Measure { qubit, cbit } => {
                    explicit_measures.push((*qubit, *cbit));
                }
                Instruction::MeasureAll => has_measure_all = true,
                _ => unreachable!("dynamic instruction 은 이미 거부됨"),
            }
        }

        let n = circuit.num_qubits();
        let dim = 1usize << n;
        let mut rho_data = vec![Complex::<f32>::new(0.0, 0.0); dim * dim];
        rho_data[0] = Complex::new(1.0, 0.0);

        // v0.5.1: process-wide cached singleton.
        let backend = qsim_gpu::cached_wgpu_density_backend()?;
        backend.apply_circuit(&mut rho_data, n, &ops)?;

        // CPU DensityMatrix wrapper 로 변환.
        let mut rho = DensityMatrix::<f32>::new(n);
        rho.data_mut().copy_from_slice(&rho_data);

        // global_phase: density 에서는 ρ → e^(iλ) ρ e^(-iλ) = ρ — no-op.
        let _ = circuit.global_phase();

        // Sampling: density 의 diagonal 분포에서 RNG.
        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };
        let counts = if shots == 0 {
            std::collections::HashMap::new()
        } else if has_measure_all {
            sample_density(&rho, shots, n, &mut rng)
        } else if !explicit_measures.is_empty() {
            sample_density_with_cbit_map(
                &rho,
                shots,
                &explicit_measures,
                circuit.num_cbits(),
                &mut rng,
            )
        } else {
            std::collections::HashMap::new()
        };
        Ok((counts, rho))
    }
}

/// panta-sim Gate → CudaGateOp 변환 (Cut G, feature `gpu-cuda`).
///
/// Toffoli / Fredkin 은 cuStateVec 의 nTargets=3 으로 가능하지만 v0.5.0 minimum
/// scope 외 — 사용자가 transpile 후 호출.
#[cfg(feature = "gpu-cuda")]
fn convert_gate_to_cuda_ops(
    gate: &Gate,
    targets: &[usize],
    ops: &mut Vec<qsim_gpu::cuda::CudaGateOp>,
) -> Result<(), GpuError> {
    use qsim_gpu::cuda::CudaGateOp;
    match gate {
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            ops.push(CudaGateOp::Single {
                matrix: gate.matrix_2x2::<f32>(),
                target: targets[0],
            });
            Ok(())
        }
        Gate::CNOT => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::X.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CZ => {
            ops.push(CudaGateOp::Two {
                matrix: Gate::cz_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::SWAP => {
            ops.push(CudaGateOp::Two {
                matrix: Gate::swap_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::CY => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::Y.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CH => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::H.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRx(theta) => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::Rx(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRy(theta) => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::Ry(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRz(theta) => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::Rz(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CP(lambda) => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::P(*lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU3(theta, phi, lambda) => {
            ops.push(CudaGateOp::Controlled1q {
                matrix: Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>();
            let phase = Complex::new(gamma.cos() as f32, gamma.sin() as f32);
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            ops.push(CudaGateOp::Controlled1q {
                matrix: m,
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::Toffoli => {
            // v0.5.10: cuStateVec native (n_controls=2 + X matrix).
            if targets.len() != 3 {
                return Err(GpuError::Unsupported(format!(
                    "Toffoli expects 3 targets, got {}",
                    targets.len()
                )));
            }
            ops.push(CudaGateOp::Toffoli {
                c0: targets[0],
                c1: targets[1],
                tgt: targets[2],
            });
            Ok(())
        }
        Gate::Fredkin => {
            // v0.5.10: cuStateVec native (n_controls=1 + SWAP matrix).
            if targets.len() != 3 {
                return Err(GpuError::Unsupported(format!(
                    "Fredkin expects 3 targets, got {}",
                    targets.len()
                )));
            }
            ops.push(CudaGateOp::Fredkin {
                ctrl: targets[0],
                t0: targets[1],
                t1: targets[2],
            });
            Ok(())
        }
    }
}

/// v0.5.12: f64 변종 convert.  동일 패턴이지만 matrix 가 f64 + CudaGateOpF64.
#[cfg(feature = "gpu-cuda")]
fn convert_gate_to_cuda_ops_f64(
    gate: &Gate,
    targets: &[usize],
    ops: &mut Vec<qsim_gpu::cuda::CudaGateOpF64>,
) -> Result<(), GpuError> {
    use qsim_gpu::cuda::CudaGateOpF64;
    match gate {
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            ops.push(CudaGateOpF64::Single {
                matrix: gate.matrix_2x2::<f64>(),
                target: targets[0],
            });
            Ok(())
        }
        Gate::CNOT => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::X.matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CZ => {
            ops.push(CudaGateOpF64::Two {
                matrix: Gate::cz_matrix::<f64>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::SWAP => {
            ops.push(CudaGateOpF64::Two {
                matrix: Gate::swap_matrix::<f64>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::CY => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::Y.matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CH => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::H.matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRx(theta) => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::Rx(*theta).matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRy(theta) => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::Ry(*theta).matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRz(theta) => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::Rz(*theta).matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CP(lambda) => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::P(*lambda).matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU3(theta, phi, lambda) => {
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: Gate::U(*theta, *phi, *lambda).matrix_2x2::<f64>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<f64>();
            let phase = Complex::new(gamma.cos(), gamma.sin());
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            ops.push(CudaGateOpF64::Controlled1q {
                matrix: m,
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::Toffoli => {
            if targets.len() != 3 {
                return Err(GpuError::Unsupported(format!(
                    "Toffoli expects 3 targets, got {}",
                    targets.len()
                )));
            }
            ops.push(CudaGateOpF64::Toffoli {
                c0: targets[0],
                c1: targets[1],
                tgt: targets[2],
            });
            Ok(())
        }
        Gate::Fredkin => {
            if targets.len() != 3 {
                return Err(GpuError::Unsupported(format!(
                    "Fredkin expects 3 targets, got {}",
                    targets.len()
                )));
            }
            ops.push(CudaGateOpF64::Fredkin {
                ctrl: targets[0],
                t0: targets[1],
                t1: targets[2],
            });
            Ok(())
        }
    }
}

/// wgpu validation error 같은 panic payload 를 사용자 친화적 GpuError 로 변환 (v0.5.1).
///
/// wgpu-core 가 validation 실패 시 default handler 로 panic 한다 — caller 가
/// `catch_unwind` 로 잡아 이 함수에 panic payload 전달.  Python 측에서 PyValueError
/// 로 떨어져 일반 `except Exception` / `except ValueError` 로 잡힘.
///
/// **v0.5.19**: OOM (Out of Memory) panic 의 친화 메시지 추가 — N / sv_size /
/// 다른 프로세스 종료 권장 등의 가이드 포함.
fn panic_to_gpu_error(context: &str, payload: Box<dyn std::any::Any + Send>) -> GpuError {
    let msg = if let Some(s) = payload.downcast_ref::<String>() {
        s.clone()
    } else if let Some(s) = payload.downcast_ref::<&'static str>() {
        (*s).to_string()
    } else {
        "(non-string panic payload)".to_string()
    };
    // 흔한 wgpu validation error 에 대해 사용자 친화 안내 추가.
    let hint = if is_oom_message(&msg) {
        " — GPU/unified memory 부족.  다른 프로세스 종료 후 재시도 또는 \
         method='statevector' (CPU 호스트 RAM) 사용 권장.  \
         사용자 환경에 따라 N 별 sv 크기는 N=28→2 GiB, N=29→4 GiB, \
         N=30→8 GiB, N=31→16 GiB, N=32→32 GiB (f32) — \
         intermediate buffer 추가 1~2 GiB 필요"
    } else if msg.contains("Buffer size") || msg.contains("max buffer size") {
        " — 회로 크기가 GPU buffer 한계 초과.  더 작은 N 으로 시도하거나 method='statevector' (CPU) 사용."
    } else if msg.contains("dispatch group size") || msg.contains("workgroups_per_dimension") {
        " — workgroup dispatch 한계 초과.  실 GPU 에선 보통 풀려있음 — driver 업데이트 시도, 또는 method='statevector' (CPU) 사용."
    } else if msg.contains("buffer_binding_size") || msg.contains("Buffer binding") {
        " — storage buffer binding 한계 초과.  더 작은 N 으로 시도하거나 method='statevector' (CPU) 사용."
    } else {
        ""
    };
    GpuError::Other(format!(
        "{context} panic: {msg}{hint}\n  (이 에러는 v0.5.1 부터 PyValueError 로 노출됨)"
    ))
}

/// v0.5.19: wgpu OOM panic message 감지.  AMD / NVIDIA / Apple Metal / lavapipe
/// 의 driver 별 OOM 메시지 형식이 약간 다름 — 가장 흔한 패턴들 모두 매칭.
fn is_oom_message(msg: &str) -> bool {
    let lower = msg.to_ascii_lowercase();
    lower.contains("out of memory")
        || lower.contains("outofmemory")
        || lower.contains("oom")
        || lower.contains("not enough memory")
        || lower.contains("memory allocation failed")
}

/// panta-sim Gate → WgpuDensityOp 변환 (Cut E).
fn convert_gate_to_density_ops(
    gate: &Gate,
    targets: &[usize],
    ops: &mut Vec<WgpuDensityOp>,
) -> Result<(), GpuError> {
    match gate {
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            ops.push(WgpuDensityOp::Single {
                matrix: gate.matrix_2x2::<f32>(),
                target: targets[0],
            });
            Ok(())
        }
        Gate::CNOT => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::X.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CZ => {
            ops.push(WgpuDensityOp::Two {
                matrix: Gate::cz_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::SWAP => {
            ops.push(WgpuDensityOp::Two {
                matrix: Gate::swap_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::CY => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::Y.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CH => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::H.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRx(theta) => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::Rx(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRy(theta) => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::Ry(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRz(theta) => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::Rz(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CP(lambda) => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::P(*lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU3(theta, phi, lambda) => {
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>();
            let phase = Complex::new(gamma.cos() as f32, gamma.sin() as f32);
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            ops.push(WgpuDensityOp::Controlled1q {
                matrix: m,
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::Toffoli | Gate::Fredkin => Err(GpuError::Unsupported(format!(
            "wgpu density: 3-qubit gate {gate:?} 는 v0.5.x — backend='cpu' 사용"
        ))),
    }
}

/// panta-sim Gate → WgpuGateOp 변환 (Cut D.4).
///
/// 1q gate → Single, controlled-1q (CNOT/CY/CH/CRx/CRy/CRz/CP/CU3/CU) →
/// Controlled1q, 2q (CZ/SWAP) → Two.  Toffoli / Fredkin 은 명시 거부 (v0.5.x).
fn convert_gate_to_wgpu_ops(
    gate: &Gate,
    targets: &[usize],
    ops: &mut Vec<WgpuGateOp>,
) -> Result<(), GpuError> {
    match gate {
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            ops.push(WgpuGateOp::Single {
                matrix: gate.matrix_2x2::<f32>(),
                target: targets[0],
            });
            Ok(())
        }
        Gate::CNOT => {
            let m = Gate::X.matrix_2x2::<f32>();
            ops.push(WgpuGateOp::Controlled1q {
                matrix: m,
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CZ => {
            ops.push(WgpuGateOp::Two {
                matrix: Gate::cz_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::SWAP => {
            ops.push(WgpuGateOp::Two {
                matrix: Gate::swap_matrix::<f32>(),
                q0: targets[0],
                q1: targets[1],
            });
            Ok(())
        }
        Gate::CY => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::Y.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CH => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::H.matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRx(theta) => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::Rx(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRy(theta) => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::Ry(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CRz(theta) => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::Rz(*theta).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CP(lambda) => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::P(*lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU3(theta, phi, lambda) => {
            ops.push(WgpuGateOp::Controlled1q {
                matrix: Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>(),
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<f32>();
            let phase = Complex::new(gamma.cos() as f32, gamma.sin() as f32);
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            ops.push(WgpuGateOp::Controlled1q {
                matrix: m,
                ctrl: targets[0],
                tgt: targets[1],
            });
            Ok(())
        }
        Gate::Toffoli | Gate::Fredkin => Err(GpuError::Unsupported(format!(
            "wgpu statevector: 3-qubit gate {gate:?} 는 v0.5.x patch — \
             qc.transpile() 으로 분해 후 backend='wgpu' 사용 또는 backend='cpu' 사용"
        ))),
    }
}

/// Density backend 의 게이트 dispatch.  [`apply_gate_typed`] 와 평행 구조,
/// 모든 게이트가 density `ρ → U ρ U†` 패턴.  3-큐비트 (Toffoli, Fredkin) 도 native.
fn apply_gate_typed_density<F: Real>(rho: &mut DensityMatrix<F>, gate: &Gate, targets: &[usize]) {
    match gate {
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            let m = gate.matrix_2x2::<F>();
            rho.apply_unitary_1q(&m, targets[0]);
        }
        Gate::CNOT => {
            let x = Gate::X.matrix_2x2::<F>();
            rho.apply_controlled_1q(&x, targets[0], targets[1]);
        }
        Gate::CZ => {
            let cz = Gate::cz_matrix::<F>();
            rho.apply_unitary_2q(&cz, targets[0], targets[1]);
        }
        Gate::SWAP => {
            let sw = Gate::swap_matrix::<F>();
            rho.apply_unitary_2q(&sw, targets[0], targets[1]);
        }
        Gate::CY => {
            let m = Gate::Y.matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CH => {
            let m = Gate::H.matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CRx(theta) => {
            let m = Gate::Rx(*theta).matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CRy(theta) => {
            let m = Gate::Ry(*theta).matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CRz(theta) => {
            let m = Gate::Rz(*theta).matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CP(lambda) => {
            let m = Gate::P(*lambda).matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CU3(theta, phi, lambda) => {
            let m = Gate::U(*theta, *phi, *lambda).matrix_2x2::<F>();
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<F>();
            let phase = qsim_core::complex::complex::<F>(gamma.cos(), gamma.sin());
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            rho.apply_controlled_1q(&m, targets[0], targets[1]);
        }
        Gate::Toffoli => {
            let x = Gate::X.matrix_2x2::<F>();
            rho.apply_doubly_controlled_1q(&x, targets[0], targets[1], targets[2]);
        }
        Gate::Fredkin => {
            rho.apply_controlled_swap(targets[0], targets[1], targets[2]);
        }
    }
}

/// Density 의 모든 amplitude 에 e^(iλ) 곱.  ρ 에는 `ρ → U ρ U†` 에서 phase 가
/// 상쇄돼 사실상 무영향이지만, statevector 경로와 의미를 통일하기 위해 동일
/// API 호출 — 실제 구현은 no-op (ρ 의 global phase 는 자명).
#[inline]
fn apply_global_phase_density<F: Real>(_rho: &mut DensityMatrix<F>, _lambda: f64) {
    // ρ → e^(iλ) ρ e^(-iλ) = ρ.  no-op.
}

/// Density 에서 measurement sampling — `n_qubits` 폭 LSB-first 비트열.
fn sample_density<F: Real, R: Rng>(
    rho: &DensityMatrix<F>,
    shots: usize,
    n_qubits: usize,
    rng: &mut R,
) -> std::collections::HashMap<String, usize> {
    let probs = rho.diagonal_probabilities();
    let cdf = build_cdf(&probs);
    let mut counts = std::collections::HashMap::new();
    for _ in 0..shots {
        let outcome = sample_from_cdf(&cdf, rng);
        let s = format_bits(outcome, n_qubits);
        *counts.entry(s).or_insert(0) += 1;
    }
    counts
}

/// Density 에서 단일 outcome sampling — trajectory 끝의 MeasureAll 용.
fn sample_density_once<F: Real, R: Rng>(
    rho: &DensityMatrix<F>,
    n_qubits: usize,
    rng: &mut R,
) -> String {
    let probs = rho.diagonal_probabilities();
    let cdf = build_cdf(&probs);
    let outcome = sample_from_cdf(&cdf, rng);
    format_bits(outcome, n_qubits)
}

/// Density 에서 explicit `Measure { qubit, cbit }` 매핑 sampling.
fn sample_density_with_cbit_map<F: Real, R: Rng>(
    rho: &DensityMatrix<F>,
    shots: usize,
    measures: &[(usize, usize)],
    n_cbits: usize,
    rng: &mut R,
) -> std::collections::HashMap<String, usize> {
    let probs = rho.diagonal_probabilities();
    let cdf = build_cdf(&probs);
    let mut counts = std::collections::HashMap::new();
    for _ in 0..shots {
        let outcome = sample_from_cdf(&cdf, rng);
        let mut cbits: Vec<u8> = vec![0; n_cbits];
        for &(q, c) in measures {
            if c < n_cbits {
                cbits[c] = ((outcome >> q) & 1) as u8;
            }
        }
        let mut s = String::with_capacity(n_cbits);
        for &b in cbits.iter().rev() {
            s.push(if b == 0 { '0' } else { '1' });
        }
        *counts.entry(s).or_insert(0) += 1;
    }
    counts
}

/// 누적 분포 빌드.  마지막 원소를 1.0 으로 강제 (floating drift 방어).
#[inline]
fn build_cdf(probs: &[f64]) -> Vec<f64> {
    let mut cdf = Vec::with_capacity(probs.len());
    let mut acc = 0.0;
    for &p in probs {
        acc += p.max(0.0);
        cdf.push(acc);
    }
    if let Some(last) = cdf.last_mut() {
        *last = 1.0;
    }
    cdf
}

#[inline]
fn sample_from_cdf<R: Rng>(cdf: &[f64], rng: &mut R) -> usize {
    let r: f64 = rng.gen();
    cdf.partition_point(|&c| c <= r).min(cdf.len() - 1)
}

#[inline]
fn format_bits(outcome: usize, n: usize) -> String {
    let mut s = String::with_capacity(n);
    for i in (0..n).rev() {
        s.push(if (outcome >> i) & 1 == 1 { '1' } else { '0' });
    }
    s
}

/// `cbit_indices` 의 cbit 들을 LSB-first packed 정수로 만든다 (v0.4.7).
///
/// `cbit_indices[0]` = LSB, `cbit_indices[k]` = bit k.  cbit register 범위
/// 밖 인덱스는 0 으로 처리 (out-of-bounds 안전).
#[inline]
fn pack_cbits(cbit_indices: &[usize], cbits: &[u8]) -> u64 {
    let mut packed: u64 = 0;
    for (bit_pos, &ci) in cbit_indices.iter().enumerate() {
        if ci < cbits.len() && cbits[ci] != 0 {
            packed |= 1u64 << bit_pos;
        }
    }
    packed
}

fn apply_global_phase<F: Real>(state: &mut StateVector<F>, lambda: f64) {
    if lambda != 0.0 {
        let phase = qsim_core::complex::complex::<F>(lambda.cos(), lambda.sin());
        for amp in state.amplitudes_mut() {
            *amp = *amp * phase;
        }
    }
}

impl Default for ExecutionEngine {
    fn default() -> Self {
        Self::new()
    }
}

/// generic 게이트 적용. f32/f64 양쪽에 monomorphize 된다.
fn apply_gate_typed<F: Real>(state: &mut StateVector<F>, gate: &Gate, targets: &[usize]) {
    match gate {
        // 단일 큐비트 게이트
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Sx
        | Gate::Sxdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::P(_)
        | Gate::U2(_, _)
        | Gate::U(_, _, _)
        | Gate::Id => {
            let matrix = gate.matrix_2x2::<F>();
            apply_single_qubit_gate(state, &matrix, targets[0]);
        }
        // 2큐비트 게이트 — 기본
        Gate::CNOT => {
            let x = Gate::X.matrix_2x2::<F>();
            apply_controlled_gate(state, &x, targets[0], targets[1]);
        }
        Gate::CZ => {
            let cz = Gate::cz_matrix::<F>();
            apply_two_qubit_gate(state, &cz, targets[0], targets[1]);
        }
        Gate::SWAP => {
            let swap = Gate::swap_matrix::<F>();
            apply_two_qubit_gate(state, &swap, targets[0], targets[1]);
        }
        // 2큐비트 controlled-1q 게이트 (v0.4.6) — apply_controlled_gate 패턴 재사용.
        // 1q matrix 를 만들어 control / target 인덱스로 그대로 위임.
        Gate::CY => {
            let m = Gate::Y.matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CH => {
            let m = Gate::H.matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CRx(theta) => {
            let m = Gate::Rx(*theta).matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CRy(theta) => {
            let m = Gate::Ry(*theta).matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CRz(theta) => {
            let m = Gate::Rz(*theta).matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CP(lambda) => {
            let m = Gate::P(*lambda).matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CU3(theta, phi, lambda) => {
            let m = Gate::U(*theta, *phi, *lambda).matrix_2x2::<F>();
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        Gate::CU(theta, phi, lambda, gamma) => {
            // Qiskit cu(θ,φ,λ,γ) 의 4×4 matrix 는 controlled-(e^(iγ) · U(θ,φ,λ)).
            // 1q matrix M = e^(iγ) · U(θ,φ,λ) 를 만들어 controlled-gate 로 적용한다.
            let u = Gate::U(*theta, *phi, *lambda).matrix_2x2::<F>();
            let phase = qsim_core::complex::complex::<F>(gamma.cos(), gamma.sin());
            let m = [
                [u[0][0] * phase, u[0][1] * phase],
                [u[1][0] * phase, u[1][1] * phase],
            ];
            apply_controlled_gate(state, &m, targets[0], targets[1]);
        }
        // 3큐비트 게이트
        Gate::Toffoli => {
            let x = Gate::X.matrix_2x2::<F>();
            apply_doubly_controlled_gate(state, &x, targets[0], targets[1], targets[2]);
        }
        Gate::Fredkin => {
            apply_controlled_swap(state, targets[0], targets[1], targets[2]);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use qsim_core::complex::approx_eq;
    use qsim_core::C64;

    #[test]
    fn test_bell_circuit_execution() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 1000);

        let counts = result.counts();
        assert!(counts.contains_key("00"));
        assert!(counts.contains_key("11"));
        assert!(!counts.contains_key("01"));
        assert!(!counts.contains_key("10"));

        let expected = C64::new(std::f64::consts::FRAC_1_SQRT_2, 0.0);
        let sv = result.statevector_f64().expect("default precision is f64");
        assert!(approx_eq(sv.amplitudes()[0], expected, 1e-10));
        assert!(approx_eq(sv.amplitudes()[3], expected, 1e-10));
    }

    #[test]
    fn test_bell_circuit_execution_f32() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42).with_precision(Precision::F32);
        let result = engine.run(&circuit, 1000);

        assert_eq!(result.precision(), Precision::F32);
        let counts = result.counts();
        assert!(counts.contains_key("00"));
        assert!(counts.contains_key("11"));

        let sv = result.statevector_f32().expect("expected f32 statevector");
        let expected = num_complex::Complex::new(std::f32::consts::FRAC_1_SQRT_2, 0.0);
        assert!(approx_eq(sv.amplitudes()[0], expected, 1e-6_f32));
        assert!(approx_eq(sv.amplitudes()[3], expected, 1e-6_f32));
    }

    #[test]
    fn test_ghz_circuit_execution() {
        let mut circuit = Circuit::new(3);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.cx(0, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(123);
        let result = engine.run(&circuit, 2000);

        let counts = result.counts();
        assert!(counts.contains_key("000"));
        assert!(counts.contains_key("111"));
        let total: usize = counts.values().sum();
        assert_eq!(total, 2000);
        for key in counts.keys() {
            assert!(key == "000" || key == "111", "unexpected outcome: {key}");
        }
    }

    #[test]
    fn test_toffoli_circuit() {
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(1);
        circuit.ccx(0, 1, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        let counts = result.counts();
        assert_eq!(counts.get("111"), Some(&100));
    }

    #[test]
    fn test_swap_circuit() {
        let mut circuit = Circuit::new(2);
        circuit.x(0);
        circuit.swap(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        assert_eq!(result.counts().get("10"), Some(&100));
    }

    #[test]
    fn test_no_measurement_empty_counts() {
        let mut circuit = Circuit::new(1);
        circuit.h(0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 100);

        assert!(result.counts().is_empty());
    }

    #[test]
    fn test_statevector_without_measurement() {
        let mut circuit = Circuit::new(1);
        circuit.x(0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 0);

        let sv = result.statevector_f64().unwrap();
        assert!(approx_eq(
            sv.amplitudes()[1],
            qsim_core::complex::ONE,
            1e-10
        ));
    }

    #[test]
    fn test_rotation_gate_circuit() {
        use std::f64::consts::PI;

        let mut circuit = Circuit::new(1);
        circuit.rx(PI, 0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 0);

        let sv = result.statevector_f64().unwrap();
        assert!((sv.probability(0)).abs() < 1e-10);
        assert!((sv.probability(1) - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_fredkin_circuit() {
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(2);
        circuit.cswap(0, 1, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        assert_eq!(result.counts().get("011"), Some(&100));
    }

    #[test]
    fn test_bell_state_statistical_distribution() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(999);
        let result = engine.run(&circuit, 10000);

        let counts = result.counts();
        let c00 = *counts.get("00").unwrap_or(&0) as f64;
        let c11 = *counts.get("11").unwrap_or(&0) as f64;
        let ratio = c00 / (c00 + c11);
        assert!(ratio > 0.45 && ratio < 0.55, "ratio was {ratio}");
    }

    #[test]
    fn test_precision_default_is_f64() {
        let engine = ExecutionEngine::new();
        let mut circuit = Circuit::new(1);
        circuit.h(0);
        let result = engine.run(&circuit, 0);
        assert_eq!(result.precision(), Precision::F64);
    }

    // ========================================================================
    // v0.4 noise integration tests
    // ========================================================================

    #[test]
    fn test_noise_p_zero_is_identity() {
        // BitFlip(p=0) 는 항상 identity → Bell 회로 결과 변동 없음.
        let mut clean = Circuit::new(2);
        clean.h(0);
        clean.cx(0, 1);
        clean.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let baseline = engine.run(&clean, 1000);

        let mut noisy = Circuit::new(2);
        noisy.h(0);
        noisy.add_noise(qsim_core::NoiseChannel::BitFlip { p: 0.0 }, 0);
        noisy.cx(0, 1);
        noisy.add_noise(qsim_core::NoiseChannel::BitFlip { p: 0.0 }, 1);
        noisy.measure_all();
        let result = engine.run(&noisy, 1000);

        let counts = result.counts();
        // p=0 이면 baseline 과 동일 분포 (ApplyNoise 가 RNG 를 한 번 더 소비하므로
        // shot RNG sequence 가 달라질 수 있어 정확 동일 비교는 안 됨 — Bell 분포만 검증).
        assert!(counts.contains_key("00") && counts.contains_key("11"));
        assert!(!counts.contains_key("01") && !counts.contains_key("10"));
        let total: usize = counts.values().sum();
        assert_eq!(total, 1000);
        let _ = baseline; // 사용. 비교는 아니지만 회로 빌드 검증.
    }

    #[test]
    fn test_noise_bit_flip_p_one_flips_state() {
        // BitFlip(p=1) on |0⟩: 항상 X 적용 → 측정 시 항상 "1".
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::BitFlip { p: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("1"), Some(&100));
    }

    #[test]
    fn test_noise_amplitude_damping_gamma_one() {
        // |1⟩ 에 AmplitudeDamping(γ=1) → |0⟩ 강제. 측정 시 항상 "0".
        let mut circuit = Circuit::new(1);
        circuit.x(0);
        circuit.add_noise(qsim_core::NoiseChannel::AmplitudeDamping { gamma: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("0"), Some(&100));
    }

    // ========================================================================
    // v0.4.6 신규 게이트 — engine 통합 테스트
    // ========================================================================

    /// Sx 게이트가 Hadamard-like 동작 (X-axis π/2 rotation up to phase).
    /// |0⟩ → (1+i)/2 |0⟩ + (1-i)/2 |1⟩, P(0) = P(1) = 1/2.
    #[test]
    fn test_sx_gate_creates_x_eigen_superposition() {
        let mut c = Circuit::new(1);
        c.sx(0);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 5000);
        let c0 = *result.counts().get("0").unwrap_or(&0) as f64;
        let ratio = c0 / 5000.0;
        assert!((ratio - 0.5).abs() < 0.03, "Sx ratio {ratio}");
    }

    /// Sx · Sx = X: |0⟩ → Sx → · → Sx → |1⟩ (결정론).
    #[test]
    fn test_sx_squared_equals_x() {
        let mut c = Circuit::new(1);
        c.sx(0);
        c.sx(0);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        assert_eq!(result.counts().get("1"), Some(&100));
    }

    /// Sxdg · Sx = I.
    #[test]
    fn test_sxdg_sx_identity() {
        let mut c = Circuit::new(1);
        c.sx(0);
        c.sxdg(0);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        assert_eq!(result.counts().get("0"), Some(&100));
    }

    /// P(π) on |+⟩ = |−⟩ (검출 H 후 X 측정 = "1").
    #[test]
    fn test_p_pi_on_plus_gives_minus() {
        let mut c = Circuit::new(1);
        c.h(0); // |+⟩
        c.p(std::f64::consts::PI, 0); // P(π) = Z, |+⟩ → |−⟩
        c.h(0); // |−⟩ → |1⟩
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        assert_eq!(result.counts().get("1"), Some(&100));
    }

    /// CY: |10⟩ (control=q1=1) → CY → |11⟩ 의 Y 적용 phase = i, 측정 시 q1=1 q0=1 → "11".
    #[test]
    fn test_cy_flips_target_with_phase() {
        let mut c = Circuit::new(2);
        c.x(1); // |10⟩
        c.cy(1, 0); // q1 control, q0 target. Y|0⟩ = i|1⟩.  state → i|11⟩.
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        assert_eq!(result.counts().get("11"), Some(&100));
    }

    /// CH: |10⟩ → CH(1, 0) → (|10⟩+|11⟩)/√2.  Q1=1 결정론, q0 marginal 50:50.
    #[test]
    fn test_ch_creates_superposition_when_control_one() {
        let mut c = Circuit::new(2);
        c.x(1);
        c.ch(1, 0);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(2024);
        let result = engine.run(&c, 5000);
        let counts = result.counts();
        let c10 = *counts.get("10").unwrap_or(&0) as f64;
        let c11 = *counts.get("11").unwrap_or(&0) as f64;
        let other: usize = counts
            .iter()
            .filter(|(k, _)| k.as_str() != "10" && k.as_str() != "11")
            .map(|(_, v)| *v)
            .sum();
        assert_eq!(other, 0);
        assert_eq!((c10 + c11) as usize, 5000);
        assert!(((c10 / 5000.0) - 0.5).abs() < 0.03);
    }

    /// CRz(π) 의 controlled-Z 동치 검증: control=1+target=1 amplitude 에 e^(-iπ/2) 추가.
    /// Bell state (|00⟩+|11⟩)/√2 에 CRz(π) 적용 → (|00⟩+e^(-iπ/2)·... wait 아니 Rz(π) on |1⟩
    /// = e^(iπ/2)|1⟩.  (|00⟩+|11⟩)/√2 의 |11⟩ 만 e^(iπ/2)|11⟩ → norm 보존. 측정 분포는
    /// 영향 없음.  여기선 CRz(0) = I 회귀 검증.
    #[test]
    fn test_crz_zero_is_identity() {
        let mut c = Circuit::new(2);
        c.h(0);
        c.cx(0, 1);
        c.crz(0.0, 0, 1);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 1000);
        let c00 = *result.counts().get("00").unwrap_or(&0);
        let c11 = *result.counts().get("11").unwrap_or(&0);
        let other: usize = result
            .counts()
            .iter()
            .filter(|(k, _)| k.as_str() != "00" && k.as_str() != "11")
            .map(|(_, v)| *v)
            .sum();
        assert_eq!(other, 0);
        assert_eq!(c00 + c11, 1000);
    }

    /// CP(π) 는 CZ 와 등가.  Bell-X = (|00⟩+|10⟩)/√2 → CP(π) → (|00⟩−|10⟩)/√2 (no measure 분포 변화)
    /// 그래도 나중 H 적용으로 detect 가능.  여기선 CP(0)=I 만 회귀.
    #[test]
    fn test_cp_zero_is_identity() {
        let mut c = Circuit::new(2);
        c.h(0);
        c.h(1);
        c.cp(0.0, 0, 1);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 1000);
        let total: usize = result.counts().values().sum();
        assert_eq!(total, 1000);
    }

    /// CU3(π, 0, π) on |10⟩ = controlled-X = CNOT.  |10⟩ → |11⟩.
    #[test]
    fn test_cu3_pi_zero_pi_equals_cnot() {
        let mut c = Circuit::new(2);
        c.x(0);
        c.cu3(std::f64::consts::PI, 0.0, std::f64::consts::PI, 0, 1);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        // q0=1 control, q1 target=X|0⟩=|1⟩.  state |11⟩.
        assert_eq!(result.counts().get("11"), Some(&100));
    }

    /// CU(π, 0, π, 0) = CNOT (γ=0).
    #[test]
    fn test_cu_zero_gamma_equals_cu3() {
        let mut c = Circuit::new(2);
        c.x(0);
        c.cu(std::f64::consts::PI, 0.0, std::f64::consts::PI, 0.0, 0, 1);
        c.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&c, 100);
        assert_eq!(result.counts().get("11"), Some(&100));
    }

    #[test]
    fn test_noise_depolarizing_statistical() {
        // Depolarizing(p=1) on |0⟩: 4 outcome {I, X, Y, Z} 균등.
        // I: |0⟩, X: |1⟩, Y: i|1⟩, Z: |0⟩ (단 |0⟩ 이므로 Z 도 |0⟩).
        // → 측정 시 "0" 50%, "1" 50%.
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::Depolarizing { p: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(2024);
        let result = engine.run(&circuit, 10_000);
        let c0 = *result.counts().get("0").unwrap_or(&0) as f64;
        let c1 = *result.counts().get("1").unwrap_or(&0) as f64;
        let ratio = c0 / (c0 + c1);
        // Each shot rebuilds state from |0⟩ then noise → I/X/Y/Z 각각 25%.
        // I, Z → "0" / X, Y → "1" → 50% 50% 기대. 3σ binomial bound ≈ 0.015.
        assert!(
            (ratio - 0.5).abs() < 0.02,
            "Depolarizing(p=1) ratio {ratio} 가 0.5 와 너무 다름"
        );
    }

    // ====================================================================
    // v0.5.0: Density matrix backend integration tests
    // ====================================================================

    #[test]
    fn density_bell_state() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        let engine = ExecutionEngine::with_seed(42).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 0);
        assert_eq!(result.backend(), Backend::CpuDensity);
        let rho = result.density_f64().expect("density f64 result");
        // ρ_Bell: ρ[0][0] = ρ[3][3] = 0.5, ρ[0][3] = ρ[3][0] = 0.5, 나머지 0.
        let half = num_complex::Complex::new(0.5_f64, 0.0);
        let expect_pairs: [(usize, usize); 4] = [(0, 0), (0, 3), (3, 0), (3, 3)];
        for i in 0..4 {
            for j in 0..4 {
                let v = rho.data()[i * 4 + j];
                if expect_pairs.contains(&(i, j)) {
                    assert!(approx_eq(v, half, 1e-12), "Bell density ({i},{j}) = {v:?}");
                } else {
                    assert!(approx_eq(v, qsim_core::complex::zero::<f64>(), 1e-12));
                }
            }
        }
    }

    #[test]
    fn density_measure_all_bell_counts() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(123).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 1000);
        let counts = result.counts();
        // Bell 분포: |00⟩, |11⟩ 각각 ~50%.
        let c00 = *counts.get("00").unwrap_or(&0) as f64;
        let c11 = *counts.get("11").unwrap_or(&0) as f64;
        let total = c00 + c11;
        assert!(total > 950.0, "Bell counts 의 |00⟩/|11⟩ 합 = {total}");
        assert!(
            (c00 / total - 0.5).abs() < 0.06,
            "|00⟩ ratio = {}",
            c00 / total
        );
    }

    #[test]
    fn density_noise_deterministic_vs_trajectory() {
        // BitFlip(p=0.3) on |0⟩: density ρ' = diag(0.7, 0.3) deterministic.
        // statevector trajectory 는 통계적이라 ±2% binomial — 비교 위해 큰 shots.
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::BitFlip { p: 0.3 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(777).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 0);
        let rho = result.density_f64().expect("density f64");
        // ρ[0][0] = 0.7, ρ[1][1] = 0.3, off-diagonal 0.
        let z = qsim_core::complex::zero::<f64>();
        assert!(approx_eq(
            rho.data()[0],
            num_complex::Complex::new(0.7_f64, 0.0),
            1e-12
        ));
        assert!(approx_eq(rho.data()[1], z, 1e-12));
        assert!(approx_eq(rho.data()[2], z, 1e-12));
        assert!(approx_eq(
            rho.data()[3],
            num_complex::Complex::new(0.3_f64, 0.0),
            1e-12
        ));
    }

    #[test]
    fn density_depolarizing_to_max_mixed() {
        // Depolarizing(p=1) on |0⟩ → ρ = I/2.
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::Depolarizing { p: 1.0 }, 0);
        let engine = ExecutionEngine::with_seed(1).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 0);
        let rho = result.density_f64().unwrap();
        let half = num_complex::Complex::new(0.5_f64, 0.0);
        assert!(approx_eq(rho.data()[0], half, 1e-12));
        assert!(approx_eq(rho.data()[3], half, 1e-12));
    }

    #[test]
    fn density_toffoli_native() {
        // |011⟩ → Toffoli (c1=q0, c2=q1, tgt=q2) → |111⟩.
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(1);
        circuit.ccx(0, 1, 2);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("111"), Some(&100));
    }

    #[test]
    fn density_fredkin_native() {
        // |101⟩ → Fredkin(ctrl=q2, t1=q0, t2=q1) → |110⟩.
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(2);
        circuit.cswap(2, 0, 1);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("110"), Some(&100));
    }

    #[test]
    fn density_reset_on_entangled() {
        // Bell + reset q=0 → q=1 marginal = I/2.
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.reset(0);
        let engine = ExecutionEngine::with_seed(99).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 0);
        let rho = result.density_f64().unwrap();
        // q=0 의 모든 row/col 이 0 인 부분만 살아남아야.  Tr_q0 (ρ) = I/2.
        let reduced = rho.partial_trace(0);
        let half = num_complex::Complex::new(0.5_f64, 0.0);
        assert!(approx_eq(reduced.data()[0], half, 1e-12));
        assert!(approx_eq(reduced.data()[3], half, 1e-12));
    }

    #[test]
    fn density_classical_control_c_if() {
        // |0⟩ → measure → c_if(c==0) X → 결과 항상 |1⟩.
        let mut circuit = Circuit::new(1);
        circuit.measure(0, 0);
        circuit.x(0);
        circuit.c_if_last(vec![0], 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42).with_backend(Backend::CpuDensity);
        let result = engine.run(&circuit, 100);
        // measure 가 cbit map 으로 바뀌면 0 측정 → c_if fires → X 적용 → measure_all → 1.
        // counts key: 1.
        assert_eq!(result.counts().get("1"), Some(&100));
    }

    #[test]
    fn density_f32_path() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        let engine = ExecutionEngine::with_seed(42)
            .with_backend(Backend::CpuDensity)
            .with_precision(Precision::F32);
        let result = engine.run(&circuit, 0);
        assert_eq!(result.precision(), Precision::F32);
        assert_eq!(result.backend(), Backend::CpuDensity);
        let rho = result.density_f32().unwrap();
        let tr = rho.trace();
        assert!((tr.re - 1.0).abs() < 1e-5);
    }

    #[test]
    fn density_matches_statevector_for_pure_circuit() {
        // Noise 없는 회로: density backend 의 ρ = |ψ⟩⟨ψ| (statevector backend 와 동치).
        let mut circuit = Circuit::new(3);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.cx(1, 2);
        circuit.rz(0.7, 0);

        let engine_sv = ExecutionEngine::with_seed(42);
        let res_sv = engine_sv.run(&circuit, 0);
        let sv = res_sv.statevector_f64().unwrap();

        let engine_dm = ExecutionEngine::with_seed(42).with_backend(Backend::CpuDensity);
        let res_dm = engine_dm.run(&circuit, 0);
        let rho = res_dm.density_f64().unwrap();

        // 비교: ρ[i][j] vs sv[i] · conj(sv[j]).
        let dim = sv.dim();
        for i in 0..dim {
            for j in 0..dim {
                let expect = sv.amplitudes()[i] * sv.amplitudes()[j].conj();
                let got = rho.data()[i * dim + j];
                assert!(
                    approx_eq(got, expect, 1e-12),
                    "density vs |ψ⟩⟨ψ| diff at ({i},{j})"
                );
            }
        }
    }

    // =====================================================================
    // v0.5.8: wgpu statevector + noise hybrid trajectory tests.
    // sandbox lavapipe / 사용자 GPU adapter 둘 다 동작해야 함.
    // adapter 없으면 NoAdapter 로 skip.
    // =====================================================================

    fn make_wgpu_engine(seed: u64) -> Option<ExecutionEngine> {
        // wgpu adapter 가용성 확인 — backend init 미리 시도.
        match qsim_gpu::cached_wgpu_statevector_backend() {
            Ok(_) => Some(
                ExecutionEngine::with_seed(seed)
                    .with_backend(crate::engine::Backend::WgpuStatevector),
            ),
            Err(_) => None, // sandbox 에 GPU 없을 때 skip.
        }
    }

    #[test]
    fn wgpu_statevector_bitflip_p1_flips_qubit() {
        // BitFlip(p=1.0) 회로: |0⟩ → |1⟩.  trajectory path 가 noise 처리하는지.
        let Some(engine) = make_wgpu_engine(42) else {
            return;
        };
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::BitFlip { p: 1.0 }, 0);
        circuit.measure_all();
        let result = engine.run(&circuit, 100);
        if let SimulationResult::F32 { counts, .. } = result {
            // BitFlip(p=1) 은 deterministic — 모든 shot 이 "1".
            assert_eq!(counts.get("1").copied().unwrap_or(0), 100);
            assert_eq!(counts.get("0").copied().unwrap_or(0), 0);
        } else {
            panic!("expected F32 statevector result");
        }
    }

    #[test]
    fn wgpu_statevector_noise_with_gates_matches_cpu() {
        // H q0 + CX(0,1) + Depolarizing(1.0) on q0 + Measure.
        // Depolarizing(p=1.0) 은 maximally mixed → 4 outcome 거의 동등.
        // 정확 분포 일치는 trajectory 분산 때문에 어려우니 totals 만 확인.
        let Some(engine) = make_wgpu_engine(123) else {
            return;
        };
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.add_noise(qsim_core::NoiseChannel::Depolarizing { p: 1.0 }, 0);
        circuit.measure_all();
        let result = engine.run(&circuit, 200);
        if let SimulationResult::F32 { counts, .. } = result {
            let total: usize = counts.values().sum();
            assert_eq!(total, 200);
            // 4 outcome 모두 적어도 한 번은 (Depolarizing(1.0) 의 fully mixed).
            assert!(counts.len() >= 2, "expected mixed counts, got {counts:?}");
        } else {
            panic!("expected F32 result");
        }
    }

    #[test]
    fn wgpu_statevector_amplitude_damping_full_decay() {
        // |1⟩ → AmplitudeDamping(γ=1.0) → |0⟩ (T1 fully relaxed).
        let Some(engine) = make_wgpu_engine(7) else {
            return;
        };
        let mut circuit = Circuit::new(1);
        circuit.x(0);
        circuit.add_noise(qsim_core::NoiseChannel::AmplitudeDamping { gamma: 1.0 }, 0);
        circuit.measure_all();
        let result = engine.run(&circuit, 100);
        if let SimulationResult::F32 { counts, .. } = result {
            assert_eq!(counts.get("0").copied().unwrap_or(0), 100);
        } else {
            panic!("expected F32 result");
        }
    }

    // =====================================================================
    // v0.5.9: wgpu statevector + dynamic (Reset / IfEq / mid-circuit Measure)
    // hybrid trajectory tests.
    // =====================================================================

    #[test]
    fn wgpu_statevector_reset_returns_to_ground() {
        // |1⟩ → Reset q0 → |0⟩.  Reset 가 GPU trajectory path 의 dynamic
        // dispatch_instruction 으로 처리되는지.
        let Some(engine) = make_wgpu_engine(11) else {
            return;
        };
        let mut circuit = Circuit::new(1);
        circuit.x(0);
        circuit.reset(0);
        circuit.measure_all();
        let result = engine.run(&circuit, 50);
        if let SimulationResult::F32 { counts, .. } = result {
            assert_eq!(counts.get("0").copied().unwrap_or(0), 50);
            assert_eq!(counts.get("1").copied().unwrap_or(0), 0);
        } else {
            panic!("expected F32 result");
        }
    }

    #[test]
    fn wgpu_statevector_mid_circuit_measure_classical_register() {
        // H q0 → measure q0 → c0.  c0 의 분포 확인 (Bernoulli 1/2).
        let Some(engine) = make_wgpu_engine(101) else {
            return;
        };
        let mut circuit = Circuit::new(1);
        circuit.h(0);
        circuit.measure(0, 0); // mid-circuit
        let result = engine.run(&circuit, 200);
        if let SimulationResult::F32 { counts, .. } = result {
            let zeros = counts.get("0").copied().unwrap_or(0);
            let ones = counts.get("1").copied().unwrap_or(0);
            assert_eq!(zeros + ones, 200);
            // 50:50 ± reasonable tolerance (분산 보정).
            assert!(zeros > 50 && zeros < 150, "zeros={zeros} ones={ones}");
        } else {
            panic!("expected F32 result");
        }
    }

    // =====================================================================
    // v0.5.19: OOM message 친화 변환 tests.
    // =====================================================================

    #[test]
    fn oom_message_detect_variants() {
        // 다양한 driver 의 OOM 메시지 형식 매칭 검증.
        assert!(super::is_oom_message("wgpu error: Out of Memory"));
        assert!(super::is_oom_message("wgpu error: out of memory"));
        assert!(super::is_oom_message("OutOfMemory"));
        assert!(super::is_oom_message("OOM during buffer allocation"));
        assert!(super::is_oom_message("not enough memory"));
        assert!(super::is_oom_message("Memory allocation failed for buffer"));

        // 비-OOM 메시지는 false.
        assert!(!super::is_oom_message(
            "Buffer binding 0 range exceeds limit"
        ));
        assert!(!super::is_oom_message("dispatch group size too large"));
        assert!(!super::is_oom_message("validation error"));
        assert!(!super::is_oom_message(""));
    }

    #[test]
    fn oom_panic_to_friendly_error() {
        // panic_to_gpu_error 가 OOM message 를 친화 hint 로 변환하는지.
        let payload: Box<dyn std::any::Any + Send> =
            Box::new(String::from("wgpu error: Out of Memory"));
        let err = super::panic_to_gpu_error("wgpu statevector", payload);
        let msg = format!("{err}");
        assert!(msg.contains("GPU/unified memory 부족"));
        assert!(msg.contains("backend='cpu'") || msg.contains("statevector"));
        // sv 크기 가이드 (N→GiB 표) 포함.
        assert!(msg.contains("N=29") || msg.contains("N=32"));
    }

    #[test]
    fn wgpu_statevector_c_if_classical_control() {
        // Bell + measure q0 → c_if (c0==1) X q1 → measure q1 → c1.
        // Bell 측정 후 |00⟩ 또는 |11⟩.
        // c0=0: X 안 적용 → q1 그대로 |0⟩ → c1=0.
        // c0=1: X 적용 → |11⟩ → |10⟩ → c1=0 (q1 = 0 after flip).
        // 결과 c1 항상 0.
        let Some(engine) = make_wgpu_engine(7) else {
            return;
        };
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure(0, 0);
        circuit.x(1);
        circuit.c_if_last(vec![0], 1);
        circuit.measure(1, 1);
        let result = engine.run(&circuit, 100);
        if let SimulationResult::F32 { counts, .. } = result {
            let total: usize = counts.values().sum();
            assert_eq!(total, 100);
            // num_cbits=2.  LSB-first reverse → c1 이 첫 자리, c0 이 둘째.
            // 모든 outcome 의 c1=0.
            for key in counts.keys() {
                assert!(
                    key.starts_with('0'),
                    "expected c1=0 in all outcomes, got {key}"
                );
            }
        } else {
            panic!("expected F32 result");
        }
    }
}
