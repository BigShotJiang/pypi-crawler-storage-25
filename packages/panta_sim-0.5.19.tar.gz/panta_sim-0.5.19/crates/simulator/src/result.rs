use qsim_core::{DensityMatrix, StateVector};
use std::collections::HashMap;

// Re-export so user crates can write `qsim_simulator::Backend::WgpuDensity`.

/// 시뮬레이션 정밀도 선택. 기본값은 `F64` (v0.2.0 호환).
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Precision {
    /// 32비트 단일 정밀도 — amplitude 8 bytes, ~50% 메모리 절감, ~1e-6 정확도.
    F32,
    /// 64비트 배 정밀도 — amplitude 16 bytes, ~1e-15 정확도 (default).
    #[default]
    F64,
}

impl Precision {
    /// 사용자 친화 문자열 표현.
    pub fn as_str(&self) -> &'static str {
        match self {
            Precision::F32 => "f32",
            Precision::F64 => "f64",
        }
    }
}

/// 시뮬레이션 백엔드 선택 (v0.5.0).
///
/// `(method, backend)` 의 cross product:
/// - method ∈ {statevector, density_matrix}
/// - backend ∈ {cpu, wgpu, cuda} (v0.5.0 cuda 는 후속 cut)
///
/// 백엔드별 의미:
/// - `CpuStatevector` (default): 기존 statevector 경로.  noise 가 있으면 자동
///   trajectory 모드.  f32 / f64.
/// - `CpuDensity`: density matrix ρ 직접 진화.  noise deterministic Kraus —
///   Aer `method="density_matrix"` 와 동일 의미.  메모리 4ⁿ → N≤14.  f32 / f64.
/// - `WgpuStatevector`: wgpu Tier-1 GPU statevector.  WGSL compute shader.
///   현재 f32 만 (wgpu 29.x 의 storage f64 제약).  noise 미지원 (statevector
///   trajectory 모드는 GPU 에서 batching 어려워 v0.5.x patch 로 deferred).
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Backend {
    /// State vector 백엔드 — CPU rayon (default).
    #[default]
    CpuStatevector,
    /// Density matrix 백엔드 — CPU.
    CpuDensity,
    /// State vector 백엔드 — wgpu GPU (Tier-1, v0.5.0).
    WgpuStatevector,
    /// Density matrix 백엔드 — wgpu GPU (Tier-1, v0.5.0 Cut E).
    WgpuDensity,
    /// State vector 백엔드 — NVIDIA cuStateVec (Tier-2, v0.5.0 Cut G).
    /// Cargo feature `gpu-cuda` 가 켜져야 동작 — NVIDIA driver + cuQuantum SDK 필요.
    /// feature off 환경에선 panic / NotImplementedError.
    CudaStatevector,
}

impl Backend {
    /// 사용자 친화 (method, backend) tuple 표현.
    pub fn method_str(&self) -> &'static str {
        match self {
            Backend::CpuStatevector | Backend::WgpuStatevector | Backend::CudaStatevector => {
                "statevector"
            }
            Backend::CpuDensity | Backend::WgpuDensity => "density_matrix",
        }
    }

    /// 사용자 친화 backend 문자열 ("cpu" / "wgpu" / "cuda").
    pub fn backend_str(&self) -> &'static str {
        match self {
            Backend::CpuStatevector | Backend::CpuDensity => "cpu",
            Backend::WgpuStatevector | Backend::WgpuDensity => "wgpu",
            Backend::CudaStatevector => "cuda",
        }
    }

    /// 호환성 alias — Python 의 `result.backend` 가 method_str 을 반환 (Cut C 호환).
    pub fn as_str(&self) -> &'static str {
        self.method_str()
    }
}

/// 시뮬레이션 실행 결과. 정밀도별로 내부 state vector 의 타입이 다르므로 enum 으로 분기한다.
#[derive(Debug, Clone)]
pub enum SimulationResult {
    /// 32비트 정밀도 statevector 결과.
    F32 {
        counts: HashMap<String, usize>,
        statevector: StateVector<f32>,
    },
    /// 64비트 정밀도 statevector 결과 (default).
    F64 {
        counts: HashMap<String, usize>,
        statevector: StateVector<f64>,
    },
    /// 32비트 정밀도 density matrix 결과 (v0.5.0).
    DensityF32 {
        counts: HashMap<String, usize>,
        density: DensityMatrix<f32>,
    },
    /// 64비트 정밀도 density matrix 결과 (v0.5.0).
    DensityF64 {
        counts: HashMap<String, usize>,
        density: DensityMatrix<f64>,
    },
}

impl SimulationResult {
    /// f64 정밀도 결과 생성자. 기존 v0.2.0 API 호환.
    pub fn new(counts: HashMap<String, usize>, statevector: StateVector<f64>) -> Self {
        SimulationResult::F64 {
            counts,
            statevector,
        }
    }

    /// f32 정밀도 결과 생성자.
    pub fn new_f32(counts: HashMap<String, usize>, statevector: StateVector<f32>) -> Self {
        SimulationResult::F32 {
            counts,
            statevector,
        }
    }

    /// f64 정밀도 density matrix 결과 생성자 (v0.5.0).
    pub fn new_density_f64(counts: HashMap<String, usize>, density: DensityMatrix<f64>) -> Self {
        SimulationResult::DensityF64 { counts, density }
    }

    /// f32 정밀도 density matrix 결과 생성자 (v0.5.0).
    pub fn new_density_f32(counts: HashMap<String, usize>, density: DensityMatrix<f32>) -> Self {
        SimulationResult::DensityF32 { counts, density }
    }

    /// 정밀도 enum 반환.
    pub fn precision(&self) -> Precision {
        match self {
            SimulationResult::F32 { .. } | SimulationResult::DensityF32 { .. } => Precision::F32,
            SimulationResult::F64 { .. } | SimulationResult::DensityF64 { .. } => Precision::F64,
        }
    }

    /// 백엔드 enum 반환 (v0.5.0).
    ///
    /// statevector 결과는 모두 `CpuStatevector` 로 보고됨 — wgpu 결과도 CPU 로
    /// 다운로드된 statevector 라 사용자 시각에서 동일.  실제 사용된 GPU 백엔드는
    /// 호출자가 알 수 있음 (run 시 backend 인자).  엄격한 구분이 필요하면
    /// 별도 metadata 추가 (v0.5.x).
    pub fn backend(&self) -> Backend {
        match self {
            SimulationResult::F32 { .. } | SimulationResult::F64 { .. } => Backend::CpuStatevector,
            SimulationResult::DensityF32 { .. } | SimulationResult::DensityF64 { .. } => {
                Backend::CpuDensity
            }
        }
    }

    /// 큐비트 수 반환.
    pub fn num_qubits(&self) -> usize {
        match self {
            SimulationResult::F32 { statevector, .. } => statevector.num_qubits(),
            SimulationResult::F64 { statevector, .. } => statevector.num_qubits(),
            SimulationResult::DensityF32 { density, .. } => density.num_qubits(),
            SimulationResult::DensityF64 { density, .. } => density.num_qubits(),
        }
    }

    /// 측정 결과 카운트를 반환한다 (정밀도 / 백엔드 무관).
    pub fn counts(&self) -> &HashMap<String, usize> {
        match self {
            SimulationResult::F32 { counts, .. }
            | SimulationResult::F64 { counts, .. }
            | SimulationResult::DensityF32 { counts, .. }
            | SimulationResult::DensityF64 { counts, .. } => counts,
        }
    }

    /// f64 statevector 참조. f32 / density 결과면 `None`.
    pub fn statevector_f64(&self) -> Option<&StateVector<f64>> {
        match self {
            SimulationResult::F64 { statevector, .. } => Some(statevector),
            _ => None,
        }
    }

    /// f32 statevector 참조. f64 / density 결과면 `None`.
    pub fn statevector_f32(&self) -> Option<&StateVector<f32>> {
        match self {
            SimulationResult::F32 { statevector, .. } => Some(statevector),
            _ => None,
        }
    }

    /// f64 density matrix 참조 (v0.5.0). statevector / f32 density 결과면 `None`.
    pub fn density_f64(&self) -> Option<&DensityMatrix<f64>> {
        match self {
            SimulationResult::DensityF64 { density, .. } => Some(density),
            _ => None,
        }
    }

    /// f32 density matrix 참조 (v0.5.0). statevector / f64 density 결과면 `None`.
    pub fn density_f32(&self) -> Option<&DensityMatrix<f32>> {
        match self {
            SimulationResult::DensityF32 { density, .. } => Some(density),
            _ => None,
        }
    }

    /// 기본 정밀도 (f64) 인 경우 `&StateVector<f64>` 를 반환. f32 / density 결과에 호출 시 panic.
    /// v0.2.0 호환용 — 새 코드는 `statevector_f64()` / `statevector_f32()` / `density_f64()` 사용 권장.
    pub fn statevector(&self) -> &StateVector<f64> {
        match self {
            SimulationResult::F64 { statevector, .. } => statevector,
            SimulationResult::F32 { .. } => {
                panic!("statevector(): f32 결과입니다. statevector_f32() 를 사용하세요")
            }
            SimulationResult::DensityF32 { .. } | SimulationResult::DensityF64 { .. } => {
                panic!("statevector(): density backend 결과입니다. density_f64() / density_f32() 를 사용하세요")
            }
        }
    }

    /// 각 basis state의 확률 벡터를 f64 로 반환한다 (정밀도 / 백엔드 통일).
    ///
    /// statevector 백엔드: `|ψ_b|²`.  density 백엔드: `ρ[b][b]` (대각선).
    pub fn probabilities(&self) -> Vec<f64> {
        match self {
            SimulationResult::F64 { statevector, .. } => statevector.probabilities(),
            SimulationResult::F32 { statevector, .. } => statevector
                .probabilities()
                .into_iter()
                .map(|p| p as f64)
                .collect(),
            SimulationResult::DensityF64 { density, .. } => density.diagonal_probabilities(),
            SimulationResult::DensityF32 { density, .. } => density.diagonal_probabilities(),
        }
    }
}
