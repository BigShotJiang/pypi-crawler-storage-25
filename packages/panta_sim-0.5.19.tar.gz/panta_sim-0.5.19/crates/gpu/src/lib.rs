//! GPU 백엔드 (v0.5.0).
//!
//! Tier-1 (wgpu) 와 Tier-2 (cudarc + cuStateVec) GPU 백엔드.  state vector +
//! density matrix 양쪽 path.  panta-sim 의 statevector 백엔드와 동일 의미
//! (qubit-wise gate update) 를 GPU compute shader 로 구현.
//!
//! 환경:
//! - **wgpu**: cross-platform (NVIDIA / AMD / Intel / Apple Metal / 소프트웨어
//!   lavapipe).  WGSL compute shader.  feature gate 없이 default 빌드.
//! - **cuStateVec** (Tier-2, v0.5.0 후반): NVIDIA 한정 추가 성능, libcustatevec.so
//!   동적 link.  feature flag `gpu-cuda`.

pub mod errors;
pub mod wgpu_backend;

#[cfg(feature = "gpu-cuda")]
pub mod cuda;

pub use errors::GpuError;
pub use wgpu_backend::{WgpuDensityBackend, WgpuDensityOp, WgpuStatevectorBackend};

#[cfg(feature = "gpu-cuda")]
pub use cuda::{CudaGateOp, CudaGateOpF64, CudaStatevectorBackend};

// ============================================================================
// Process-wide cached backends (v0.5.1)
// ============================================================================
//
// wgpu adapter / device / pipeline 초기화 비용 (~수백 ms) 을 매 `qc.run()` 호출
// 마다 지불하지 않도록 process 내 singleton.  thread-safe (`OnceLock` + `Arc`).
//
// 첫 호출에서 init, 이후 호출은 cached `Arc<Backend>` 재사용.  init 실패 시
// 에러를 cache 하지 않음 — 다음 호출에서 재시도 가능.

use std::sync::{Arc, Mutex, OnceLock};

static WGPU_STATEVECTOR_BACKEND: OnceLock<Mutex<Option<Arc<WgpuStatevectorBackend>>>> =
    OnceLock::new();
static WGPU_DENSITY_BACKEND: OnceLock<Mutex<Option<Arc<WgpuDensityBackend>>>> = OnceLock::new();

/// Process-wide cached `WgpuStatevectorBackend`.  첫 호출에서 init (수백 ms),
/// 이후 호출은 즉시 (~µs).
///
/// adapter / device 가 한번 만들어지면 process 종료 까지 유지 — 일반적인
/// wgpu 사용 패턴 (Vulkan / Metal device 는 cheap to keep alive).
pub fn cached_wgpu_statevector_backend() -> Result<Arc<WgpuStatevectorBackend>, GpuError> {
    let cell = WGPU_STATEVECTOR_BACKEND.get_or_init(|| Mutex::new(None));
    let mut guard = cell
        .lock()
        .map_err(|e| GpuError::Other(format!("statevector backend mutex poisoned: {e}")))?;
    if let Some(backend) = guard.as_ref() {
        return Ok(Arc::clone(backend));
    }
    let backend = Arc::new(WgpuStatevectorBackend::new()?);
    *guard = Some(Arc::clone(&backend));
    Ok(backend)
}

/// Process-wide cached `WgpuDensityBackend`.
pub fn cached_wgpu_density_backend() -> Result<Arc<WgpuDensityBackend>, GpuError> {
    let cell = WGPU_DENSITY_BACKEND.get_or_init(|| Mutex::new(None));
    let mut guard = cell
        .lock()
        .map_err(|e| GpuError::Other(format!("density backend mutex poisoned: {e}")))?;
    if let Some(backend) = guard.as_ref() {
        return Ok(Arc::clone(backend));
    }
    let backend = Arc::new(WgpuDensityBackend::new()?);
    *guard = Some(Arc::clone(&backend));
    Ok(backend)
}
