// Density matrix unitary 2q — column pass (Cut E).
//
// ρ' = ρ U† — column 인덱스의 q0/q1 4-pair 결합 (right multiply U†).
// uniform `udag` 는 4×4 U† row-major (CPU 에서 미리 계산).
// CPU `DensityMatrix::apply_unitary_2q` 의 Pass 2.

struct Uniforms {
    bit0: u32,
    bit1: u32,
    dim: u32,
    mask_lo: u32,
    mask_mid: u32,
    mask_hi: u32,
    n_groups: u32,
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    // 4×4 U† row-major, 8 vec4 packing (.xy = even, .zw = odd).
    udag_packed: array<vec4<f32>, 8>,
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let total = u.n_groups * u.dim;
    if (global_idx >= total) {
        return;
    }
    let i = global_idx / u.n_groups;
    let k = global_idx % u.n_groups;
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let j0 = i * u.dim + base;
    let j1 = i * u.dim + (base | u.bit0);
    let j2 = i * u.dim + (base | u.bit1);
    let j3 = i * u.dim + (base | u.bit0 | u.bit1);
    let v0 = rho[j0];
    let v1 = rho[j1];
    let v2 = rho[j2];
    let v3 = rho[j3];
    // [v0 v1 v2 v3] @ U† column-by-column:
    // result_col_c = sum_r v_r * udag[r][c] (udag row-major: idx r*4+c).
    // udag[k] = udag_packed[k/2].xy if k even, .zw if k odd.
    let u0_xy = u.udag_packed[0].xy; let u0_zw = u.udag_packed[0].zw;
    let u1_xy = u.udag_packed[1].xy; let u1_zw = u.udag_packed[1].zw;
    let u2_xy = u.udag_packed[2].xy; let u2_zw = u.udag_packed[2].zw;
    let u3_xy = u.udag_packed[3].xy; let u3_zw = u.udag_packed[3].zw;
    let u4_xy = u.udag_packed[4].xy; let u4_zw = u.udag_packed[4].zw;
    let u5_xy = u.udag_packed[5].xy; let u5_zw = u.udag_packed[5].zw;
    let u6_xy = u.udag_packed[6].xy; let u6_zw = u.udag_packed[6].zw;
    let u7_xy = u.udag_packed[7].xy; let u7_zw = u.udag_packed[7].zw;
    // udag[r*4+c] for c=0,1,2,3, r=0,1,2,3.
    // c=0: udag[0]=u0_xy, udag[4]=u2_xy, udag[8]=u4_xy, udag[12]=u6_xy
    rho[j0] = cmul(v0, u0_xy) + cmul(v1, u2_xy) + cmul(v2, u4_xy) + cmul(v3, u6_xy);
    rho[j1] = cmul(v0, u0_zw) + cmul(v1, u2_zw) + cmul(v2, u4_zw) + cmul(v3, u6_zw);
    rho[j2] = cmul(v0, u1_xy) + cmul(v1, u3_xy) + cmul(v2, u5_xy) + cmul(v3, u7_xy);
    rho[j3] = cmul(v0, u1_zw) + cmul(v1, u3_zw) + cmul(v2, u5_zw) + cmul(v3, u7_zw);
}
