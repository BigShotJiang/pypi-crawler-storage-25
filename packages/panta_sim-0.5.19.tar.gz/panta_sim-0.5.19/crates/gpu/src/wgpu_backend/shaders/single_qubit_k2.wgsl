// Single-qubit gate K=2 (2-buffer split) shader (v0.5.5).
//
// statevector |ψ⟩ 가 두 buffer 로 분할:
//   state_lo: amplitude index 의 high bit = 0 인 절반 (length = 2^(N-1))
//   state_hi: high bit = 1 인 절반 (length = 2^(N-1))
//
// Gate target qubit 이 split bit (= N-1) 인지 따라 처리 분기 (uniform branching).
//
// **same-buffer** (target < split_bit):
//   amplitude pair (i, j = i^stride) 의 high bit 같음 → 같은 buffer 안.
//   pair_idx ∈ [0, 2^(N-1)) 을 lo half (0..half_pairs) / hi half 로 분리.
//
// **cross-buffer** (target == split_bit):
//   pair (i, j) 의 high bit 가 0 / 1 → state_lo[k] ↔ state_hi[k] 짝.
//   pair_idx 가 곧 두 buffer 안 같은 offset.
//
// uniform branching: split_target 이 한 dispatch 의 모든 invocation 에 동일 →
// GPU divergence cost 0.

struct Uniforms {
    // 1 << target_qubit
    qubit_stride: u32,
    // 2^N (boundary check 용 — same-buffer path 의 pairs 총수 = n_amplitudes/2)
    n_amplitudes: u32,
    // 2^(N-1) — 각 buffer 의 length
    half_dim: u32,
    // 1 if target_qubit == split_bit (== N-1), else 0.
    split_target: u32,
    // v0.5.2 2D dispatch chunking (0 = 1D path).
    dispatches_x: u32,
    _pad1: u32, _pad2: u32, _pad3: u32,
    // 2×2 matrix (row-major).  vec2<f32> = (re, im).
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state_lo: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> state_hi: array<vec2<f32>>;
@group(0) @binding(2) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // 2D → 1D invocation index (v0.5.3 1D fallback 호환).
    let pair_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );

    if (u.split_target != 0u) {
        // Cross-buffer: target == split_bit.  pair_idx ∈ [0, half_dim).
        if (pair_idx >= u.half_dim) {
            return;
        }
        let a = state_lo[pair_idx];
        let b = state_hi[pair_idx];
        state_lo[pair_idx] = cmul(u.m00, a) + cmul(u.m01, b);
        state_hi[pair_idx] = cmul(u.m10, a) + cmul(u.m11, b);
    } else {
        // Same-buffer: target < split_bit.  total pairs = n_amplitudes/2 =
        // half_dim, split between lo (0..half_pairs) and hi (half_pairs..half_dim).
        let half_pairs = u.half_dim / 2u;
        if (pair_idx >= u.half_dim) {
            return;
        }
        let in_hi = pair_idx >= half_pairs;
        let local_pair_idx = select(pair_idx, pair_idx - half_pairs, in_hi);
        let stride = u.qubit_stride;
        let block = local_pair_idx / stride;
        let off = local_pair_idx % stride;
        let i_off = block * (stride * 2u) + off;
        let j_off = i_off + stride;
        if (in_hi) {
            let a = state_hi[i_off];
            let b = state_hi[j_off];
            state_hi[i_off] = cmul(u.m00, a) + cmul(u.m01, b);
            state_hi[j_off] = cmul(u.m10, a) + cmul(u.m11, b);
        } else {
            let a = state_lo[i_off];
            let b = state_lo[j_off];
            state_lo[i_off] = cmul(u.m00, a) + cmul(u.m01, b);
            state_lo[j_off] = cmul(u.m10, a) + cmul(u.m11, b);
        }
    }
}
