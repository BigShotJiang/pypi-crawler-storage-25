// Controlled-1q gate K=2 (2-buffer split) shader (v0.5.5).
//
// ctrl bit = 1 인 amplitude pair (i, j = i^tgt_stride) 에만 1q matrix 적용.
// split_bit = N-1 일 때:
//   ctrl == split_bit: ctrl=1 amplitude 는 모두 hi buffer.  pair 가 hi 안 same-buffer.
//   tgt == split_bit:  pair (i, j) 의 high bit 가 0/1 → cross-buffer (i in lo, j in hi).
//   둘 다 < split:     pair 는 같은 buffer (high bit 으로 lo/hi 결정).
//
// 위 3 case 모두 invocation index i (∈ [0, 2^N)) 로 dispatching:
//   각 invocation 이 amplitude index i 하나 처리.  ctrl=1, tgt bit=0 인 i 만
//   pair 처리 (그 외 early return).

struct Uniforms {
    ctrl_bit: u32,
    tgt_stride: u32,
    n_amplitudes: u32,
    half_dim: u32,        // 2^(N-1)
    split_ctrl: u32,      // 1 if ctrl == split_bit
    split_tgt: u32,       // 1 if tgt == split_bit
    dispatches_x: u32,
    _pad0: u32,
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state_lo: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> state_hi: array<vec2<f32>>;
@group(0) @binding(2) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (i >= u.n_amplitudes) {
        return;
    }
    if ((i & u.ctrl_bit) == 0u) {
        return;
    }
    if ((i & u.tgt_stride) != 0u) {
        return;
    }
    let j = i | u.tgt_stride;
    let mask = u.half_dim - 1u;
    let i_off = i & mask;
    let j_off = j & mask;

    if (u.split_tgt != 0u) {
        // tgt == split_bit: i 는 lo (tgt=0), j 는 hi (tgt=1).
        let a = state_lo[i_off];
        let b = state_hi[j_off];
        state_lo[i_off] = cmul(u.m00, a) + cmul(u.m01, b);
        state_hi[j_off] = cmul(u.m10, a) + cmul(u.m11, b);
    } else {
        // tgt < split_bit: i, j 같은 buffer.  high bit 으로 결정.
        let in_hi = i >= u.half_dim;
        if (in_hi) {
            let a = state_hi[i_off];
            let b = state_hi[j_off];
            state_hi[i_off] = cmul(u.m00, a) + cmul(u.m01, b);
            state_hi[j_off] = cmul(u.m10, a) + cmul(u.m11, b);
        } else {
            let a = state_lo[i_off];
            let b = state_lo[j_off];
            state_lo[i_off] = cmul(u.m00, a) + cmul(u.m01, b);
            state_lo[j_off] = cmul(u.m10, a) + cmul(u.m11, b);
        }
    }
}
