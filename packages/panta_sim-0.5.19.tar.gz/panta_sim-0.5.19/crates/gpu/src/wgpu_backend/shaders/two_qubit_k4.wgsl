// Two-qubit gate K=4 (4-buffer split) shader (v0.5.6).
//
// 4-amplitude block (q0, q1 자리 0/1) 의 각 amplitude 가 어느 buffer 인지
// generic 하게 계산.  target qubit 위치 무관 (split bit 또는 그 외 모두
// switch 가 처리).

struct Uniforms {
    bit0: u32,            // 1 << q0
    bit1: u32,            // 1 << q1
    n_amplitudes: u32,
    mask_lo: u32,
    mask_mid: u32,
    mask_hi: u32,
    n_groups: u32,        // n_amplitudes / 4
    offset_bits: u32,     // N - 2
    offset_mask: u32,     // (1 << (N-2)) - 1
    dispatches_x: u32,
    _pad0: u32,
    _pad1: u32,
    _pad2: u32,
    _pad3: u32,
    _pad4: u32,
    _pad5: u32,
    m00: vec2<f32>, m01: vec2<f32>, m02: vec2<f32>, m03: vec2<f32>,
    m10: vec2<f32>, m11: vec2<f32>, m12: vec2<f32>, m13: vec2<f32>,
    m20: vec2<f32>, m21: vec2<f32>, m22: vec2<f32>, m23: vec2<f32>,
    m30: vec2<f32>, m31: vec2<f32>, m32: vec2<f32>, m33: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state_b0: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> state_b1: array<vec2<f32>>;
@group(0) @binding(2) var<storage, read_write> state_b2: array<vec2<f32>>;
@group(0) @binding(3) var<storage, read_write> state_b3: array<vec2<f32>>;
@group(0) @binding(4) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

fn read_buf(idx: u32, off: u32) -> vec2<f32> {
    switch (idx) {
        case 0u: { return state_b0[off]; }
        case 1u: { return state_b1[off]; }
        case 2u: { return state_b2[off]; }
        case 3u: { return state_b3[off]; }
        default: { return vec2<f32>(0.0, 0.0); }
    }
}

fn write_buf(idx: u32, off: u32, val: vec2<f32>) {
    switch (idx) {
        case 0u: { state_b0[off] = val; }
        case 1u: { state_b1[off] = val; }
        case 2u: { state_b2[off] = val; }
        case 3u: { state_b3[off] = val; }
        default: {}
    }
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let k = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (k >= u.n_groups) {
        return;
    }
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let i00 = base;
    let i01 = base | u.bit0;
    let i10 = base | u.bit1;
    let i11 = base | u.bit0 | u.bit1;

    let b00 = i00 >> u.offset_bits;
    let o00 = i00 & u.offset_mask;
    let b01 = i01 >> u.offset_bits;
    let o01 = i01 & u.offset_mask;
    let b10 = i10 >> u.offset_bits;
    let o10 = i10 & u.offset_mask;
    let b11 = i11 >> u.offset_bits;
    let o11 = i11 & u.offset_mask;

    let v0 = read_buf(b00, o00);
    let v1 = read_buf(b01, o01);
    let v2 = read_buf(b10, o10);
    let v3 = read_buf(b11, o11);

    let n0 = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
    let n1 = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
    let n2 = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
    let n3 = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);

    write_buf(b00, o00, n0);
    write_buf(b01, o01, n1);
    write_buf(b10, o10, n2);
    write_buf(b11, o11, n3);
}
