// Single-qubit gate compute shader (v0.5.0 Tier-1 wgpu).
//
// 의미: state vector |ψ⟩ 의 amplitude pair (i, j) where i_q=0, j_q=1, j=i|stride
// 에 2×2 matrix U 를 적용한다.  statevector 의 apply_single_qubit_gate 와 동등.
//
// Workgroup: 64 invocations.  각 invocation = 한 pair (i, j).
// Total invocations = state.len() / 2 = 2^(n_qubits - 1).

struct Uniforms {
    // 1 << target_qubit (인덱스 비트 stride)
    qubit_stride: u32,
    // n_amplitudes = 2^n_qubits (boundary check 용)
    n_amplitudes: u32,
    // v0.5.2: 2D dispatch chunking — workgroup-count-per-dimension 65535 한계 해소.
    // dispatches_x = wgpu dispatch_workgroups 의 X 차원.  invocation idx 복원에 사용.
    dispatches_x: u32,
    _pad1: u32,
    // 2×2 matrix (row-major).  vec2<f32> = (re, im).
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: dispatches_x == 0 이면 1D path (gid.x 그대로), 양수면 2D chunking.
    // uniform branching 이라 GPU divergence cost 0.
    let pair_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let stride = u.qubit_stride;
    // Map pair_idx → (i, j) where i has bit q=0 and j = i | stride.
    let block = pair_idx / stride;
    let off = pair_idx % stride;
    let i = block * (stride * 2u) + off;
    let j = i + stride;
    if (j >= u.n_amplitudes) {
        return;
    }
    let a = state[i];
    let b = state[j];
    state[i] = cmul(u.m00, a) + cmul(u.m01, b);
    state[j] = cmul(u.m10, a) + cmul(u.m11, b);
}
