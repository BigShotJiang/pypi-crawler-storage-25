// Controlled single-qubit gate compute shader (v0.5.0 Cut D.2).
//
// 의미: ctrl bit = 1 인 amplitude pair (i, j = i | tgt_stride) 에 2×2 matrix
// 적용.  statevector::apply_controlled_gate 와 동등.  CNOT / CY / CH / CRx
// / CRy / CRz / CP / CU3 / CU 모두 이 path.
//
// 각 invocation 이 한 amplitude index i 를 처리.  ctrl bit=1 + tgt bit=0 일
// 때만 (i, i+tgt_stride) pair 에 적용.  total invocations = n_amplitudes.

struct Uniforms {
    ctrl_bit: u32,
    tgt_stride: u32,
    n_amplitudes: u32,
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (i >= u.n_amplitudes) {
        return;
    }
    if ((i & u.ctrl_bit) == 0u) {
        return;
    }
    if ((i & u.tgt_stride) != 0u) {
        return;
    }
    let j = i | u.tgt_stride;
    let a = state[i];
    let b = state[j];
    state[i] = cmul(u.m00, a) + cmul(u.m01, b);
    state[j] = cmul(u.m10, a) + cmul(u.m11, b);
}
