// Density matrix controlled-1q — row pass (Cut E).
//
// ρ' = (CU)_q ρ — row 인덱스의 ctrl bit=1 + tgt bit=0 인 element 의 (i, i+stride)
// pair 만 1q matrix 적용.  CPU `DensityMatrix::apply_controlled_1q` 의 Pass 1.

struct Uniforms {
    ctrl_bit: u32,
    tgt_stride: u32,
    dim: u32,
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let total = u.dim * u.dim;
    if (global_idx >= total) {
        return;
    }
    let i = global_idx / u.dim;
    let j = global_idx % u.dim;
    if ((i & u.ctrl_bit) == 0u) {
        return;
    }
    if ((i & u.tgt_stride) != 0u) {
        return;
    }
    let i0 = i * u.dim + j;
    let i1 = (i | u.tgt_stride) * u.dim + j;
    let a = rho[i0];
    let b = rho[i1];
    rho[i0] = cmul(u.m00, a) + cmul(u.m01, b);
    rho[i1] = cmul(u.m10, a) + cmul(u.m11, b);
}
