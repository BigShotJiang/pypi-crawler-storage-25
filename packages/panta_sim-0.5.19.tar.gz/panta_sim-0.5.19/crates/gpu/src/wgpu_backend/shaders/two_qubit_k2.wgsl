// Two-qubit gate K=2 (2-buffer split) shader (v0.5.5).
//
// q0 < q1 정렬 가정.  split_bit = N-1 이라 q1 ≤ split_bit 항상 만족.
// q0 == split_bit 은 불가능 (q0 < q1 ≤ split_bit).
//
// Cases:
//   q1 < split_bit  → 둘 다 same-buffer (4-amplitude block 모두 같은 buffer)
//   q1 == split_bit → q1 가 cross-buffer.  4-amplitude block 중 q1=0 두 개는
//                     lo, q1=1 두 개는 hi.  같은 4-tuple 의 amplitude 가
//                     2 buffer 에 나뉨.

struct Uniforms {
    bit0: u32,        // 1 << q0
    bit1: u32,        // 1 << q1
    n_amplitudes: u32,
    mask_lo: u32,
    mask_mid: u32,
    mask_hi: u32,
    n_groups: u32,    // n_amplitudes / 4
    half_dim: u32,    // 2^(N-1)
    split_q1: u32,    // 1 if q1 == split_bit else 0
    dispatches_x: u32,
    _pad1: u32, _pad2: u32, _pad3: u32, _pad4: u32, _pad5: u32, _pad6: u32,
    // 4×4 matrix row-major.  vec2<f32> = (re, im).
    m00: vec2<f32>, m01: vec2<f32>, m02: vec2<f32>, m03: vec2<f32>,
    m10: vec2<f32>, m11: vec2<f32>, m12: vec2<f32>, m13: vec2<f32>,
    m20: vec2<f32>, m21: vec2<f32>, m22: vec2<f32>, m23: vec2<f32>,
    m30: vec2<f32>, m31: vec2<f32>, m32: vec2<f32>, m33: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state_lo: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> state_hi: array<vec2<f32>>;
@group(0) @binding(2) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let k = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (k >= u.n_groups) {
        return;
    }
    // base index (q0, q1 자리는 0).
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let i00 = base;
    let i01 = base | u.bit0;
    let i10 = base | u.bit1;
    let i11 = base | u.bit0 | u.bit1;

    if (u.split_q1 != 0u) {
        // q1 == split_bit.  i00, i01 은 q1=0 → lo; i10, i11 은 q1=1 → hi.
        // Buffer 안 offset = index & (half_dim - 1).
        let mask = u.half_dim - 1u;
        let off00 = i00 & mask;
        let off01 = i01 & mask;
        let off10 = i10 & mask;
        let off11 = i11 & mask;
        let v0 = state_lo[off00];
        let v1 = state_lo[off01];
        let v2 = state_hi[off10];
        let v3 = state_hi[off11];
        state_lo[off00] = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
        state_lo[off01] = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
        state_hi[off10] = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
        state_hi[off11] = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);
    } else {
        // q1 < split_bit: 4 amplitude 모두 같은 buffer.  high bit 으로 lo/hi 결정.
        let in_hi = i00 >= u.half_dim;
        let mask = u.half_dim - 1u;
        let off00 = i00 & mask;
        let off01 = i01 & mask;
        let off10 = i10 & mask;
        let off11 = i11 & mask;
        if (in_hi) {
            let v0 = state_hi[off00];
            let v1 = state_hi[off01];
            let v2 = state_hi[off10];
            let v3 = state_hi[off11];
            state_hi[off00] = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
            state_hi[off01] = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
            state_hi[off10] = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
            state_hi[off11] = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);
        } else {
            let v0 = state_lo[off00];
            let v1 = state_lo[off01];
            let v2 = state_lo[off10];
            let v3 = state_lo[off11];
            state_lo[off00] = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
            state_lo[off01] = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
            state_lo[off10] = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
            state_lo[off11] = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);
        }
    }
}
