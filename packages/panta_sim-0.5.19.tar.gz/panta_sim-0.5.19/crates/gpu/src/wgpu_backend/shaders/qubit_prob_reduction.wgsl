// Per-qubit prob reduction shader (v0.5.15).
//
// statevector |ψ⟩ 의 P(qubit=0) = Σ_{i: i bit qubit == 0} |amp[i]|² 를
// GPU 에서 계산.  v0.5.13 의 norm_reduction 의 변형 — amplitude filter 추가.
//
// outcome=0 의 prob 만 반환.  outcome=1 = 1.0 - prob_zero (caller 에서 보정).
//
// workgroup_size=64 + shared memory tree-reduction (norm_reduction 와 동일 패턴).

const WORKGROUP_SIZE: u32 = 64u;

struct Uniforms {
    n_amplitudes: u32,
    target_bit: u32,         // 1 << qubit_index
    dispatches_x: u32,
    _pad0: u32,
};

@group(0) @binding(0) var<storage, read> state: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> partial: array<f32>;
@group(0) @binding(2) var<uniform> u: Uniforms;

var<workgroup> shared_sum: array<f32, 64>;

@compute @workgroup_size(64)
fn main(
    @builtin(global_invocation_id) gid: vec3<u32>,
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wgid: vec3<u32>,
    @builtin(num_workgroups) num_wg: vec3<u32>,
) {
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    var v: f32 = 0.0;
    if (i < u.n_amplitudes) {
        // outcome=0 인 amplitude (i bit qubit == 0) 만 합산.
        if ((i & u.target_bit) == 0u) {
            let a = state[i];
            v = a.x * a.x + a.y * a.y;
        }
    }
    shared_sum[lid.x] = v;
    workgroupBarrier();

    var stride: u32 = 32u;
    while (stride > 0u) {
        if (lid.x < stride) {
            shared_sum[lid.x] = shared_sum[lid.x] + shared_sum[lid.x + stride];
        }
        workgroupBarrier();
        stride = stride / 2u;
    }

    if (lid.x == 0u) {
        let wg_idx = wgid.x + wgid.y * num_wg.x;
        partial[wg_idx] = shared_sum[0];
    }
}
