// Controlled-1q gate K=16 (16-buffer split) shader (v0.5.17).

struct Uniforms {
    ctrl_bit: u32,
    tgt_stride: u32,
    n_amplitudes: u32,
    offset_bits: u32,     // N - 4
    offset_mask: u32,
    dispatches_x: u32,
    _pad0: u32,
    _pad1: u32,
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0)  var<storage, read_write> state_b0:  array<vec2<f32>>;
@group(0) @binding(1)  var<storage, read_write> state_b1:  array<vec2<f32>>;
@group(0) @binding(2)  var<storage, read_write> state_b2:  array<vec2<f32>>;
@group(0) @binding(3)  var<storage, read_write> state_b3:  array<vec2<f32>>;
@group(0) @binding(4)  var<storage, read_write> state_b4:  array<vec2<f32>>;
@group(0) @binding(5)  var<storage, read_write> state_b5:  array<vec2<f32>>;
@group(0) @binding(6)  var<storage, read_write> state_b6:  array<vec2<f32>>;
@group(0) @binding(7)  var<storage, read_write> state_b7:  array<vec2<f32>>;
@group(0) @binding(8)  var<storage, read_write> state_b8:  array<vec2<f32>>;
@group(0) @binding(9)  var<storage, read_write> state_b9:  array<vec2<f32>>;
@group(0) @binding(10) var<storage, read_write> state_b10: array<vec2<f32>>;
@group(0) @binding(11) var<storage, read_write> state_b11: array<vec2<f32>>;
@group(0) @binding(12) var<storage, read_write> state_b12: array<vec2<f32>>;
@group(0) @binding(13) var<storage, read_write> state_b13: array<vec2<f32>>;
@group(0) @binding(14) var<storage, read_write> state_b14: array<vec2<f32>>;
@group(0) @binding(15) var<storage, read_write> state_b15: array<vec2<f32>>;
@group(0) @binding(16) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

fn read_buf(idx: u32, off: u32) -> vec2<f32> {
    switch (idx) {
        case 0u:  { return state_b0[off];  }
        case 1u:  { return state_b1[off];  }
        case 2u:  { return state_b2[off];  }
        case 3u:  { return state_b3[off];  }
        case 4u:  { return state_b4[off];  }
        case 5u:  { return state_b5[off];  }
        case 6u:  { return state_b6[off];  }
        case 7u:  { return state_b7[off];  }
        case 8u:  { return state_b8[off];  }
        case 9u:  { return state_b9[off];  }
        case 10u: { return state_b10[off]; }
        case 11u: { return state_b11[off]; }
        case 12u: { return state_b12[off]; }
        case 13u: { return state_b13[off]; }
        case 14u: { return state_b14[off]; }
        case 15u: { return state_b15[off]; }
        default:  { return vec2<f32>(0.0, 0.0); }
    }
}

fn write_buf(idx: u32, off: u32, val: vec2<f32>) {
    switch (idx) {
        case 0u:  { state_b0[off]  = val; }
        case 1u:  { state_b1[off]  = val; }
        case 2u:  { state_b2[off]  = val; }
        case 3u:  { state_b3[off]  = val; }
        case 4u:  { state_b4[off]  = val; }
        case 5u:  { state_b5[off]  = val; }
        case 6u:  { state_b6[off]  = val; }
        case 7u:  { state_b7[off]  = val; }
        case 8u:  { state_b8[off]  = val; }
        case 9u:  { state_b9[off]  = val; }
        case 10u: { state_b10[off] = val; }
        case 11u: { state_b11[off] = val; }
        case 12u: { state_b12[off] = val; }
        case 13u: { state_b13[off] = val; }
        case 14u: { state_b14[off] = val; }
        case 15u: { state_b15[off] = val; }
        default:  {}
    }
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (i >= u.n_amplitudes) {
        return;
    }
    if ((i & u.ctrl_bit) == 0u) {
        return;
    }
    if ((i & u.tgt_stride) != 0u) {
        return;
    }
    let j = i | u.tgt_stride;
    let i_buf = i >> u.offset_bits;
    let i_off = i & u.offset_mask;
    let j_buf = j >> u.offset_bits;
    let j_off = j & u.offset_mask;

    let a = read_buf(i_buf, i_off);
    let b = read_buf(j_buf, j_off);
    write_buf(i_buf, i_off, cmul(u.m00, a) + cmul(u.m01, b));
    write_buf(j_buf, j_off, cmul(u.m10, a) + cmul(u.m11, b));
}
