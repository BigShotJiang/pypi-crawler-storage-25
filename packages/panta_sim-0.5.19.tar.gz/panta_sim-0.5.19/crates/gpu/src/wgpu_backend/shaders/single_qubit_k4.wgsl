// Single-qubit gate K=4 (4-buffer split) shader (v0.5.6).
//
// statevector |ψ⟩ 가 4 buffer 로 분할 — high 2 bits 가 buffer index (0..3).
//   state_b0: high 2 bits = 00
//   state_b1: high 2 bits = 01
//   state_b2: high 2 bits = 10
//   state_b3: high 2 bits = 11
//   각 buffer length = 2^(N-2)
//
// shader 가 amplitude pair (i, j = i^stride) 의 buffer index 를 generic 하게
// 계산 — same-buffer / cross-buffer 구분 없이 read_buf / write_buf switch 로
// 4-way 분기.  target qubit 위치 (split bit ∈ {N-2, N-1} or 그 외) 자동 처리.

struct Uniforms {
    qubit_stride: u32,    // 1 << target_qubit
    n_amplitudes: u32,    // 2^N
    offset_bits: u32,     // N - 2
    offset_mask: u32,     // (1 << (N-2)) - 1
    dispatches_x: u32,    // v0.5.2 2D dispatch chunking
    _pad0: u32,
    _pad1: u32,
    _pad2: u32,
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state_b0: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> state_b1: array<vec2<f32>>;
@group(0) @binding(2) var<storage, read_write> state_b2: array<vec2<f32>>;
@group(0) @binding(3) var<storage, read_write> state_b3: array<vec2<f32>>;
@group(0) @binding(4) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

fn read_buf(idx: u32, off: u32) -> vec2<f32> {
    switch (idx) {
        case 0u: { return state_b0[off]; }
        case 1u: { return state_b1[off]; }
        case 2u: { return state_b2[off]; }
        case 3u: { return state_b3[off]; }
        default: { return vec2<f32>(0.0, 0.0); }
    }
}

fn write_buf(idx: u32, off: u32, val: vec2<f32>) {
    switch (idx) {
        case 0u: { state_b0[off] = val; }
        case 1u: { state_b1[off] = val; }
        case 2u: { state_b2[off] = val; }
        case 3u: { state_b3[off] = val; }
        default: {}
    }
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let pair_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let total_pairs = u.n_amplitudes / 2u;
    if (pair_idx >= total_pairs) {
        return;
    }
    let stride = u.qubit_stride;
    let block = pair_idx / stride;
    let off_in_block = pair_idx % stride;
    let i = block * (stride * 2u) + off_in_block;
    let j = i + stride;

    let i_buf = i >> u.offset_bits;
    let i_off = i & u.offset_mask;
    let j_buf = j >> u.offset_bits;
    let j_off = j & u.offset_mask;

    let a = read_buf(i_buf, i_off);
    let b = read_buf(j_buf, j_off);
    let new_a = cmul(u.m00, a) + cmul(u.m01, b);
    let new_b = cmul(u.m10, a) + cmul(u.m11, b);
    write_buf(i_buf, i_off, new_a);
    write_buf(j_buf, j_off, new_b);
}
