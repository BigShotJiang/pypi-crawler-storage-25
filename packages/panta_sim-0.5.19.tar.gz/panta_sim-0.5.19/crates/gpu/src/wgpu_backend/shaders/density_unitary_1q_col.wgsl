// Density matrix unitary 1q — column pass (Cut E).
//
// ρ' = ρ U_q† — column 인덱스의 q-bit pair 결합 (right multiply U†).
// U† = [[conj(m00), conj(m10)], [conj(m01), conj(m11)]]
// CPU `DensityMatrix::apply_unitary_1q` 의 Pass 2 와 동일.

struct Uniforms {
    qubit_stride: u32,
    dim: u32,
    n_qubits: u32,
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    n00: vec2<f32>, // conj(m00)
    n01: vec2<f32>, // conj(m01)
    n10: vec2<f32>, // conj(m10)
    n11: vec2<f32>, // conj(m11)
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let pairs_per_row = u.dim / 2u;
    let total = pairs_per_row * u.dim;
    if (global_idx >= total) {
        return;
    }
    let i = global_idx / pairs_per_row;
    let pair_idx = global_idx % pairs_per_row;

    let stride = u.qubit_stride;
    let block = pair_idx / stride;
    let off = pair_idx % stride;
    let c0 = block * (stride * 2u) + off;
    let c1 = c0 + stride;

    let j0 = i * u.dim + c0;
    let j1 = i * u.dim + c1;
    let a = rho[j0];
    let b = rho[j1];
    // [a, b] @ U† = [a · n00 + b · n01, a · n10 + b · n11]
    rho[j0] = cmul(a, u.n00) + cmul(b, u.n01);
    rho[j1] = cmul(a, u.n10) + cmul(b, u.n11);
}
