// Density matrix unitary 2q — row pass (Cut E).
//
// ρ' = U ρ — row 인덱스의 q0/q1 4-pair 결합 (left multiply 4×4 U).
// CPU `DensityMatrix::apply_unitary_2q` 의 Pass 1.
//
// 각 invocation = (k, j) 에서 k 는 base group, j 는 col.  total = n_groups × dim.

struct Uniforms {
    bit0: u32,
    bit1: u32,
    dim: u32,
    mask_lo: u32,
    mask_mid: u32,
    mask_hi: u32,
    n_groups: u32,         // dim / 4
    dispatches_x: u32,     // v0.5.2 2D dispatch chunking
    // 4×4 matrix packed as 8 vec4 (2 complex per vec4: .xy = even, .zw = odd).
    // m_packed[i].xy = m[2i], m_packed[i].zw = m[2i+1].
    m_packed: array<vec4<f32>, 8>,
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let total = u.n_groups * u.dim;
    if (global_idx >= total) {
        return;
    }
    let k = global_idx / u.dim;
    let j = global_idx % u.dim;
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let i0 = base * u.dim + j;
    let i1 = (base | u.bit0) * u.dim + j;
    let i2 = (base | u.bit1) * u.dim + j;
    let i3 = (base | u.bit0 | u.bit1) * u.dim + j;
    let v0 = rho[i0];
    let v1 = rho[i1];
    let v2 = rho[i2];
    let v3 = rho[i3];
    // m[2k] = m_packed[k].xy, m[2k+1] = m_packed[k].zw.
    rho[i0] = cmul(u.m_packed[0].xy, v0) + cmul(u.m_packed[0].zw, v1)
            + cmul(u.m_packed[1].xy, v2) + cmul(u.m_packed[1].zw, v3);
    rho[i1] = cmul(u.m_packed[2].xy, v0) + cmul(u.m_packed[2].zw, v1)
            + cmul(u.m_packed[3].xy, v2) + cmul(u.m_packed[3].zw, v3);
    rho[i2] = cmul(u.m_packed[4].xy, v0) + cmul(u.m_packed[4].zw, v1)
            + cmul(u.m_packed[5].xy, v2) + cmul(u.m_packed[5].zw, v3);
    rho[i3] = cmul(u.m_packed[6].xy, v0) + cmul(u.m_packed[6].zw, v1)
            + cmul(u.m_packed[7].xy, v2) + cmul(u.m_packed[7].zw, v3);
}
