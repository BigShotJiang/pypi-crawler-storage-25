// Density matrix 1q Kraus channel (Cut E).
//
// ρ' = Σᵢ Kᵢ ρ Kᵢ† — 4-element block (i00 / i01 / i10 / i11) 에 in-place 적용.
// CPU `DensityMatrix::apply_kraus_1q` 와 동일.
//
// 각 invocation = 한 4-element block.  total invocations = (dim/2)² = 4^(n-1).

const MAX_KRAUS_OPS = 4u;  // BitFlip(2) / PhaseFlip(2) / Depolarizing(4) /
                           // AmpDamp(2).  최대 4.

struct KrausOp {
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

struct Uniforms {
    qubit_stride: u32,    // 1 << target
    dim: u32,             // 2ⁿ
    n_kraus: u32,         // 1..=4
    dispatches_x: u32,    // v0.5.2 2D dispatch chunking
    kraus: array<KrausOp, MAX_KRAUS_OPS>,
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

fn cconj(a: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x, -a.y);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let block_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let blocks_per_row = u.dim / 2u;
    let total = blocks_per_row * blocks_per_row;
    if (block_idx >= total) {
        return;
    }
    let r_blk = block_idx / blocks_per_row;
    let c_blk = block_idx % blocks_per_row;

    let stride = u.qubit_stride;
    let r_base_blk = r_blk / stride;
    let r_base_off = r_blk % stride;
    let r0 = r_base_blk * (stride * 2u) + r_base_off;
    let r1 = r0 + stride;

    let c_base_blk = c_blk / stride;
    let c_base_off = c_blk % stride;
    let c0 = c_base_blk * (stride * 2u) + c_base_off;
    let c1 = c0 + stride;

    let i00 = r0 * u.dim + c0;
    let i01 = r0 * u.dim + c1;
    let i10 = r1 * u.dim + c0;
    let i11 = r1 * u.dim + c1;

    let rho_00 = rho[i00];
    let rho_01 = rho[i01];
    let rho_10 = rho[i10];
    let rho_11 = rho[i11];

    var new_00 = vec2<f32>(0.0, 0.0);
    var new_01 = vec2<f32>(0.0, 0.0);
    var new_10 = vec2<f32>(0.0, 0.0);
    var new_11 = vec2<f32>(0.0, 0.0);

    for (var k: u32 = 0u; k < u.n_kraus; k = k + 1u) {
        let kop = u.kraus[k];
        // K ρ_blk
        let kp00 = cmul(kop.m00, rho_00) + cmul(kop.m01, rho_10);
        let kp01 = cmul(kop.m00, rho_01) + cmul(kop.m01, rho_11);
        let kp10 = cmul(kop.m10, rho_00) + cmul(kop.m11, rho_10);
        let kp11 = cmul(kop.m10, rho_01) + cmul(kop.m11, rho_11);
        // (K ρ_blk) K† where K† = [[conj(m00), conj(m10)], [conj(m01), conj(m11)]]
        let dk00 = cconj(kop.m00);
        let dk01 = cconj(kop.m10);
        let dk10 = cconj(kop.m01);
        let dk11 = cconj(kop.m11);
        new_00 = new_00 + cmul(kp00, dk00) + cmul(kp01, dk10);
        new_01 = new_01 + cmul(kp00, dk01) + cmul(kp01, dk11);
        new_10 = new_10 + cmul(kp10, dk00) + cmul(kp11, dk10);
        new_11 = new_11 + cmul(kp10, dk01) + cmul(kp11, dk11);
    }

    rho[i00] = new_00;
    rho[i01] = new_01;
    rho[i10] = new_10;
    rho[i11] = new_11;
}
