// Two-qubit gate K=32 (32-buffer split) shader (v0.5.18).

struct Uniforms {
    bit0: u32,
    bit1: u32,
    n_amplitudes: u32,
    mask_lo: u32,
    mask_mid: u32,
    mask_hi: u32,
    n_groups: u32,
    offset_bits: u32,
    offset_mask: u32,
    dispatches_x: u32,
    _pad0: u32,
    _pad1: u32,
    _pad2: u32,
    _pad3: u32,
    _pad4: u32,
    _pad5: u32,
    m00: vec2<f32>, m01: vec2<f32>, m02: vec2<f32>, m03: vec2<f32>,
    m10: vec2<f32>, m11: vec2<f32>, m12: vec2<f32>, m13: vec2<f32>,
    m20: vec2<f32>, m21: vec2<f32>, m22: vec2<f32>, m23: vec2<f32>,
    m30: vec2<f32>, m31: vec2<f32>, m32: vec2<f32>, m33: vec2<f32>,
};

@group(0) @binding(0)  var<storage, read_write> state_b0:  array<vec2<f32>>;
@group(0) @binding(1)  var<storage, read_write> state_b1:  array<vec2<f32>>;
@group(0) @binding(2)  var<storage, read_write> state_b2:  array<vec2<f32>>;
@group(0) @binding(3)  var<storage, read_write> state_b3:  array<vec2<f32>>;
@group(0) @binding(4)  var<storage, read_write> state_b4:  array<vec2<f32>>;
@group(0) @binding(5)  var<storage, read_write> state_b5:  array<vec2<f32>>;
@group(0) @binding(6)  var<storage, read_write> state_b6:  array<vec2<f32>>;
@group(0) @binding(7)  var<storage, read_write> state_b7:  array<vec2<f32>>;
@group(0) @binding(8)  var<storage, read_write> state_b8:  array<vec2<f32>>;
@group(0) @binding(9)  var<storage, read_write> state_b9:  array<vec2<f32>>;
@group(0) @binding(10) var<storage, read_write> state_b10: array<vec2<f32>>;
@group(0) @binding(11) var<storage, read_write> state_b11: array<vec2<f32>>;
@group(0) @binding(12) var<storage, read_write> state_b12: array<vec2<f32>>;
@group(0) @binding(13) var<storage, read_write> state_b13: array<vec2<f32>>;
@group(0) @binding(14) var<storage, read_write> state_b14: array<vec2<f32>>;
@group(0) @binding(15) var<storage, read_write> state_b15: array<vec2<f32>>;
@group(0) @binding(16) var<storage, read_write> state_b16: array<vec2<f32>>;
@group(0) @binding(17) var<storage, read_write> state_b17: array<vec2<f32>>;
@group(0) @binding(18) var<storage, read_write> state_b18: array<vec2<f32>>;
@group(0) @binding(19) var<storage, read_write> state_b19: array<vec2<f32>>;
@group(0) @binding(20) var<storage, read_write> state_b20: array<vec2<f32>>;
@group(0) @binding(21) var<storage, read_write> state_b21: array<vec2<f32>>;
@group(0) @binding(22) var<storage, read_write> state_b22: array<vec2<f32>>;
@group(0) @binding(23) var<storage, read_write> state_b23: array<vec2<f32>>;
@group(0) @binding(24) var<storage, read_write> state_b24: array<vec2<f32>>;
@group(0) @binding(25) var<storage, read_write> state_b25: array<vec2<f32>>;
@group(0) @binding(26) var<storage, read_write> state_b26: array<vec2<f32>>;
@group(0) @binding(27) var<storage, read_write> state_b27: array<vec2<f32>>;
@group(0) @binding(28) var<storage, read_write> state_b28: array<vec2<f32>>;
@group(0) @binding(29) var<storage, read_write> state_b29: array<vec2<f32>>;
@group(0) @binding(30) var<storage, read_write> state_b30: array<vec2<f32>>;
@group(0) @binding(31) var<storage, read_write> state_b31: array<vec2<f32>>;
@group(0) @binding(32) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

fn read_buf(idx: u32, off: u32) -> vec2<f32> {
    switch (idx) {
        case 0u:  { return state_b0[off];  } case 1u:  { return state_b1[off];  }
        case 2u:  { return state_b2[off];  } case 3u:  { return state_b3[off];  }
        case 4u:  { return state_b4[off];  } case 5u:  { return state_b5[off];  }
        case 6u:  { return state_b6[off];  } case 7u:  { return state_b7[off];  }
        case 8u:  { return state_b8[off];  } case 9u:  { return state_b9[off];  }
        case 10u: { return state_b10[off]; } case 11u: { return state_b11[off]; }
        case 12u: { return state_b12[off]; } case 13u: { return state_b13[off]; }
        case 14u: { return state_b14[off]; } case 15u: { return state_b15[off]; }
        case 16u: { return state_b16[off]; } case 17u: { return state_b17[off]; }
        case 18u: { return state_b18[off]; } case 19u: { return state_b19[off]; }
        case 20u: { return state_b20[off]; } case 21u: { return state_b21[off]; }
        case 22u: { return state_b22[off]; } case 23u: { return state_b23[off]; }
        case 24u: { return state_b24[off]; } case 25u: { return state_b25[off]; }
        case 26u: { return state_b26[off]; } case 27u: { return state_b27[off]; }
        case 28u: { return state_b28[off]; } case 29u: { return state_b29[off]; }
        case 30u: { return state_b30[off]; } case 31u: { return state_b31[off]; }
        default: { return vec2<f32>(0.0, 0.0); }
    }
}

fn write_buf(idx: u32, off: u32, val: vec2<f32>) {
    switch (idx) {
        case 0u:  { state_b0[off]  = val; } case 1u:  { state_b1[off]  = val; }
        case 2u:  { state_b2[off]  = val; } case 3u:  { state_b3[off]  = val; }
        case 4u:  { state_b4[off]  = val; } case 5u:  { state_b5[off]  = val; }
        case 6u:  { state_b6[off]  = val; } case 7u:  { state_b7[off]  = val; }
        case 8u:  { state_b8[off]  = val; } case 9u:  { state_b9[off]  = val; }
        case 10u: { state_b10[off] = val; } case 11u: { state_b11[off] = val; }
        case 12u: { state_b12[off] = val; } case 13u: { state_b13[off] = val; }
        case 14u: { state_b14[off] = val; } case 15u: { state_b15[off] = val; }
        case 16u: { state_b16[off] = val; } case 17u: { state_b17[off] = val; }
        case 18u: { state_b18[off] = val; } case 19u: { state_b19[off] = val; }
        case 20u: { state_b20[off] = val; } case 21u: { state_b21[off] = val; }
        case 22u: { state_b22[off] = val; } case 23u: { state_b23[off] = val; }
        case 24u: { state_b24[off] = val; } case 25u: { state_b25[off] = val; }
        case 26u: { state_b26[off] = val; } case 27u: { state_b27[off] = val; }
        case 28u: { state_b28[off] = val; } case 29u: { state_b29[off] = val; }
        case 30u: { state_b30[off] = val; } case 31u: { state_b31[off] = val; }
        default: {}
    }
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let k = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (k >= u.n_groups) {
        return;
    }
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let i00 = base;
    let i01 = base | u.bit0;
    let i10 = base | u.bit1;
    let i11 = base | u.bit0 | u.bit1;

    let b00 = i00 >> u.offset_bits;
    let o00 = i00 & u.offset_mask;
    let b01 = i01 >> u.offset_bits;
    let o01 = i01 & u.offset_mask;
    let b10 = i10 >> u.offset_bits;
    let o10 = i10 & u.offset_mask;
    let b11 = i11 >> u.offset_bits;
    let o11 = i11 & u.offset_mask;

    let v0 = read_buf(b00, o00);
    let v1 = read_buf(b01, o01);
    let v2 = read_buf(b10, o10);
    let v3 = read_buf(b11, o11);

    let n0 = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
    let n1 = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
    let n2 = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
    let n3 = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);

    write_buf(b00, o00, n0);
    write_buf(b01, o01, n1);
    write_buf(b10, o10, n2);
    write_buf(b11, o11, n3);
}
