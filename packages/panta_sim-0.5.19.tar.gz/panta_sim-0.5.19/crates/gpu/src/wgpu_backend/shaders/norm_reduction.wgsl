// Norm reduction shader (v0.5.13).
//
// statevector |ψ⟩ 의 ‖ψ‖² = Σᵢ |amp[i]|² 를 GPU 에서 계산.
//
// **Single-pass workgroup reduction**: 각 workgroup 이 자기 64 amplitude 의
// partial sum 을 shared memory tree-reduction 으로 계산해 partial[wg_index]
// 에 write.  CPU 는 partial buffer (size = num_workgroups) 만 download 하고
// final sum.  state buffer 전체 download 대비 1/64 round-trip.
//
// v0.5.14 의 normalize shader, v0.5.15 의 measure path 의 토대.

const WORKGROUP_SIZE: u32 = 64u;

struct Uniforms {
    n_amplitudes: u32,
    dispatches_x: u32,    // v0.5.2 2D dispatch chunking
    _pad0: u32,
    _pad1: u32,
};

@group(0) @binding(0) var<storage, read> state: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> partial: array<f32>;
@group(0) @binding(2) var<uniform> u: Uniforms;

var<workgroup> shared_sum: array<f32, 64>;

@compute @workgroup_size(64)
fn main(
    @builtin(global_invocation_id) gid: vec3<u32>,
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wgid: vec3<u32>,
    @builtin(num_workgroups) num_wg: vec3<u32>,
) {
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    var v: f32 = 0.0;
    if (i < u.n_amplitudes) {
        let a = state[i];
        v = a.x * a.x + a.y * a.y;
    }
    shared_sum[lid.x] = v;
    workgroupBarrier();

    // Tree reduction in shared memory: 64 → 32 → 16 → 8 → 4 → 2 → 1.
    var stride: u32 = 32u;
    while (stride > 0u) {
        if (lid.x < stride) {
            shared_sum[lid.x] = shared_sum[lid.x] + shared_sum[lid.x + stride];
        }
        workgroupBarrier();
        stride = stride / 2u;
    }

    if (lid.x == 0u) {
        let wg_idx = wgid.x + wgid.y * num_wg.x;
        partial[wg_idx] = shared_sum[0];
    }
}
