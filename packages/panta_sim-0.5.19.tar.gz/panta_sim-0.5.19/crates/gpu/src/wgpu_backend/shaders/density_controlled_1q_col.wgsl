// Density matrix controlled-1q — column pass (Cut E).
//
// ρ' = ρ (CU)†_q — column 인덱스의 ctrl bit=1 + tgt bit=0 pair 에만
// right multiply U†.  CPU 의 Pass 2.

struct Uniforms {
    ctrl_bit: u32,
    tgt_stride: u32,
    dim: u32,
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    n00: vec2<f32>, // conj(m00)
    n01: vec2<f32>, // conj(m01)
    n10: vec2<f32>, // conj(m10)
    n11: vec2<f32>, // conj(m11)
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let total = u.dim * u.dim;
    if (global_idx >= total) {
        return;
    }
    let i = global_idx / u.dim;
    let j = global_idx % u.dim;
    if ((j & u.ctrl_bit) == 0u) {
        return;
    }
    if ((j & u.tgt_stride) != 0u) {
        return;
    }
    let j0 = i * u.dim + j;
    let j1 = i * u.dim + (j | u.tgt_stride);
    let a = rho[j0];
    let b = rho[j1];
    rho[j0] = cmul(a, u.n00) + cmul(b, u.n01);
    rho[j1] = cmul(a, u.n10) + cmul(b, u.n11);
}
