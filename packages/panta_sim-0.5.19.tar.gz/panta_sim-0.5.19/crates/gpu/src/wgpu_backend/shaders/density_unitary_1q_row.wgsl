// Density matrix unitary 1q — row pass (Cut E).
//
// 의미: ρ' = U_q ρ — row 인덱스의 q-bit pair 결합 (left multiply U).
// CPU `DensityMatrix::apply_unitary_1q` 의 Pass 1 과 동일.
//
// Storage: ρ ∈ ℂ^(dim×dim) row-major, dim = 2ⁿ.
// 각 invocation = 한 (r0, j) pair 결합.  total invocations = (dim/2) × dim.

struct Uniforms {
    qubit_stride: u32,    // 1 << target
    dim: u32,             // 2ⁿ
    n_qubits: u32,
    dispatches_x: u32,    // v0.5.2 2D dispatch chunking
    m00: vec2<f32>,
    m01: vec2<f32>,
    m10: vec2<f32>,
    m11: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> rho: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기.
    let global_idx = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    let pairs_per_col = u.dim / 2u;
    let total = pairs_per_col * u.dim;
    if (global_idx >= total) {
        return;
    }
    let pair_idx = global_idx / u.dim;
    let j = global_idx % u.dim;

    let stride = u.qubit_stride;
    let block = pair_idx / stride;
    let off = pair_idx % stride;
    let r0 = block * (stride * 2u) + off;
    let r1 = r0 + stride;

    let i0 = r0 * u.dim + j;
    let i1 = r1 * u.dim + j;
    let a = rho[i0];
    let b = rho[i1];
    rho[i0] = cmul(u.m00, a) + cmul(u.m01, b);
    rho[i1] = cmul(u.m10, a) + cmul(u.m11, b);
}
