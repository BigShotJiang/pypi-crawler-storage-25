// Collapse + renormalize shader (v0.5.14).
//
// 측정 outcome 결정 후 statevector 를 collapse + renormalize.
//   amp[i] := amp[i] * inv_sqrt_prob   if (i bit qubit) == outcome
//   amp[i] := 0                         otherwise
//
// outcome ∈ {0, 1} 의 결과로 amplitude 의 절반이 0 + 나머지 절반 정규화.
//
// caller 가 prob (= P(outcome)) 를 계산해 inv_sqrt_prob = 1/√prob 전달.
// prob 계산은 v0.5.15 의 per-qubit prob shader (norm reduction 의 outcome
// filter 변형) 에서 GPU 안 통합 예정.

struct Uniforms {
    target_bit: u32,         // 1 << qubit_index
    outcome: u32,            // 0 또는 1
    n_amplitudes: u32,
    inv_sqrt_prob: f32,
    dispatches_x: u32,
    _pad0: u32,
    _pad1: u32,
    _pad2: u32,
};

@group(0) @binding(0) var<storage, read_write> state: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (i >= u.n_amplitudes) {
        return;
    }
    let i_bit_set = (i & u.target_bit) != 0u;
    let outcome_set = u.outcome != 0u;
    if (i_bit_set == outcome_set) {
        let a = state[i];
        state[i] = vec2<f32>(a.x * u.inv_sqrt_prob, a.y * u.inv_sqrt_prob);
    } else {
        state[i] = vec2<f32>(0.0, 0.0);
    }
}
