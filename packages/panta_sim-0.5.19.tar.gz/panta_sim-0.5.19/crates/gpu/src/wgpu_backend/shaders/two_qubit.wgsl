// 2-qubit gate compute shader (v0.5.0 Cut D.2).
//
// 의미: state vector 의 4-amplitude block (i00 / i01 / i10 / i11) 에 4×4
// matrix U 를 적용한다.  q0=lower (small index), q1=higher.  basis |q1 q0⟩.
// statevector::apply_two_qubit_gate 와 동등.
//
// 각 invocation = 한 group (i00=base).  base 는 (q0, q1) 자리를 0 으로 비우고
// 다른 비트들로 채워진 인덱스.  total invocations = 2^(n-2).
//
// Workgroup 64.

struct Uniforms {
    bit0: u32,        // 1 << q0
    bit1: u32,        // 1 << q1
    n_amplitudes: u32,
    mask_lo: u32,     // (1 << q_lo) - 1
    mask_mid: u32,    // ((1 << (q_hi - 1)) - 1) ^ mask_lo
    mask_hi: u32,     // !((1 << (q_hi - 1)) - 1)
    n_groups: u32,    // n_amplitudes / 4
    dispatches_x: u32, // v0.5.2 2D dispatch chunking
    // 4×4 matrix row-major.  vec2<f32> = (re, im).
    m00: vec2<f32>, m01: vec2<f32>, m02: vec2<f32>, m03: vec2<f32>,
    m10: vec2<f32>, m11: vec2<f32>, m12: vec2<f32>, m13: vec2<f32>,
    m20: vec2<f32>, m21: vec2<f32>, m22: vec2<f32>, m23: vec2<f32>,
    m30: vec2<f32>, m31: vec2<f32>, m32: vec2<f32>, m33: vec2<f32>,
};

@group(0) @binding(0) var<storage, read_write> state: array<vec2<f32>>;
@group(0) @binding(1) var<uniform> u: Uniforms;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    // v0.5.3: 1D path 자동 분기 (dispatches_x == 0).
    let k = select(
        gid.x + gid.y * u.dispatches_x * 64u,
        gid.x,
        u.dispatches_x == 0u,
    );
    if (k >= u.n_groups) {
        return;
    }
    // Expand k into base index with q0, q1 bits = 0.
    let low = k & u.mask_lo;
    let mid = (k & u.mask_mid) << 1u;
    let high = (k & u.mask_hi) << 2u;
    let base = high | mid | low;

    let i00 = base;
    let i01 = base | u.bit0;
    let i10 = base | u.bit1;
    let i11 = base | u.bit0 | u.bit1;

    let v0 = state[i00];
    let v1 = state[i01];
    let v2 = state[i10];
    let v3 = state[i11];

    state[i00] = cmul(u.m00, v0) + cmul(u.m01, v1) + cmul(u.m02, v2) + cmul(u.m03, v3);
    state[i01] = cmul(u.m10, v0) + cmul(u.m11, v1) + cmul(u.m12, v2) + cmul(u.m13, v3);
    state[i10] = cmul(u.m20, v0) + cmul(u.m21, v1) + cmul(u.m22, v2) + cmul(u.m23, v3);
    state[i11] = cmul(u.m30, v0) + cmul(u.m31, v1) + cmul(u.m32, v2) + cmul(u.m33, v3);
}
