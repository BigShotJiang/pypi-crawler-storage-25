"""Observability unit tests."""
