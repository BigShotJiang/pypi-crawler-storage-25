"""Sovyx bridge — communication layer."""
