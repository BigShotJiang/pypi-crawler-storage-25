"""Shared utilities for Arize AX operators."""

from __future__ import annotations

from typing import Any


def is_not_found(exc: Exception) -> bool:
    """Return True if *exc* represents an HTTP 404 Not Found error.

    Checks three evidence sources in order:
    1. ``exc.status == 404`` (SDK numeric status attribute)
    2. ``"404"`` appears anywhere in ``str(exc)``
    3. ``"not found"`` appears (case-insensitive) in ``str(exc)``
    """
    if getattr(exc, "status", None) == 404:
        return True
    msg = str(exc).lower()
    return "not found" in msg or "404" in msg


def is_conflict(exc: Exception) -> bool:
    """Return True if *exc* represents an HTTP 409 Conflict.

    Checks three evidence sources in order:
    1. ``exc.status == 409`` (SDK numeric status attribute)
    2. ``"409"`` appears anywhere in ``str(exc)``
    3. ``"already exists"`` appears (case-insensitive) in ``str(exc)``
    """
    if getattr(exc, "status", None) == 409:
        return True
    text = str(exc)
    if "409" in text:
        return True
    if "already exists" in text.lower():
        return True
    return False


def push_first_xcom_keys(
    context: Any,
    result: Any,
    *,
    id_field: str = "id",
    name_field: str = "name",
) -> None:
    """Push ``first_id`` and ``first_name`` XCom keys from a list response.

    Convention: every List* operator pushes the ID and name of the first
    item in its response under these named XCom keys, so DAGs can chain via
    ``{{ ti.xcom_pull(task_ids='list_x', key='first_id') }}`` without having
    to write Python intermediaries. No-ops if the result is empty or not a
    dict-shaped list response.
    """
    if not isinstance(context, dict):
        return
    ti = context.get("ti")
    if ti is None:
        return
    items = result.get("items", []) if isinstance(result, dict) else []
    if not items or not isinstance(items[0], dict):
        return
    ti.xcom_push(key="first_id", value=str(items[0].get(id_field, "")))
    ti.xcom_push(key="first_name", value=str(items[0].get(name_field, "")))


def find_resource_by_name(
    hook: Any,
    list_method: str,
    name: str,
    *,
    name_field: str = "name",
    **list_kwargs: Any,
) -> str | None:
    """Paginate a list API and return the ID of the first item matching *name*.

    Calls ``getattr(hook, list_method)(**list_kwargs, cursor=<cursor>)`` on each
    page and returns the ``id`` field of the first item whose ``name_field``
    equals *name*.  Returns ``None`` when no match is found across all pages.

    Args:
        hook: An ArizeAxHook instance.
        list_method: Name of the hook method to call (e.g. ``"list_datasets"``).
        name: The resource name to search for.
        name_field: Key to compare against *name* in each item dict.
        **list_kwargs: Extra keyword arguments forwarded to the list method
            (e.g. ``space_id="..."``).

    Returns:
        The ``str`` ID of the matching item, or ``None`` if not found.
    """
    cursor: str | None = None
    method = getattr(hook, list_method)
    while True:
        result = method(**list_kwargs, cursor=cursor)
        for item in result.get("items", []):
            if isinstance(item, dict) and item.get(name_field) == name:
                return str(item["id"])
        cursor = result.get("next_cursor")
        if not cursor:
            return None
