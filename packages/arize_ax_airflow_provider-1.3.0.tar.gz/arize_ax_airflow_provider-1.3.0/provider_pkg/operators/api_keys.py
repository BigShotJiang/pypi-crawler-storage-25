"""Arize AX API Keys operators.

Wraps the ``client.api_keys`` SDK client for listing, creating, deleting,
and refreshing API keys in Arize AX.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence

from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import is_not_found

if TYPE_CHECKING:  # pragma: no cover
    from airflow.utils.context import Context


class ArizeAxListAPIKeysOperator(BaseOperator):
    """List API keys, optionally filtered by type and status.

    Returns a structured list dict (``items``, ``next_cursor``, ``count``) via
    XCom.
    """

    template_fields: Sequence[str] = ("key_type", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        key_type: str | None = None,
        status: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.key_type = key_type
        self.status = status
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_api_keys(
            key_type=self.key_type,
            status=self.status,
            limit=self.limit,
            cursor=self.cursor,
        )


class ArizeAxCreateAPIKeyOperator(BaseOperator):
    """Create an API key in Arize AX.

    The return dict includes a ``key`` field containing the raw API key value,
    which is returned only once and cannot be retrieved again.

    SDK 8.27+ scopes keys by the caller's API token (the connection's
    ``arize_ax_default`` password), so ``key_type`` / ``space_id`` are no
    longer surfaced — they were dropped from ``client.api_keys.create``.
    """

    template_fields: Sequence[str] = ("name",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        description: str | None = None,
        expires_at: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.description = description
        self.expires_at = expires_at
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.create_api_key(
            name=self.name,
            description=self.description,
            expires_at=self.expires_at,
        )
        # Convention: Create operators return scalar str(id); full result via XCom key "result".
        ti = context.get("ti") if isinstance(context, dict) else None
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        key_id = (
            result.get("id") if isinstance(result, dict)
            else getattr(result, "id", None)
        )
        return str(key_id) if key_id is not None else ""


class ArizeAxDeleteAPIKeyOperator(BaseOperator):
    """Delete an API key by ID.

    Returns ``None`` via XCom.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("api_key_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        api_key_id: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.api_key_id = api_key_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_api_key(api_key_id=self.api_key_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "API key %r not found — skipping delete (ignore_if_missing=True).",
                    self.api_key_id,
                )
                return
            raise


class ArizeAxRefreshAPIKeyOperator(BaseOperator):
    """Refresh (rotate) an API key, optionally setting a new expiry.

    The return dict includes a ``key`` field with the new raw API key value,
    returned only once.
    """

    template_fields: Sequence[str] = ("api_key_id", "expires_at")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        api_key_id: str,
        expires_at: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.api_key_id = api_key_id
        self.expires_at = expires_at
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.refresh_api_key(
            api_key_id=self.api_key_id,
            expires_at=self.expires_at,
        )
