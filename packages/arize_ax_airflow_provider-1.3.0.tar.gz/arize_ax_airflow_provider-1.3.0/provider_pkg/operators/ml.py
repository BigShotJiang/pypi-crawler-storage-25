"""Arize AX ML (model logging / export) operators."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence

from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.spans import _load_dataframe

if TYPE_CHECKING:
    from airflow.utils.context import Context


class ArizeAxMLLogBatchOperator(BaseOperator):
    """Batch log ML predictions to Arize AX."""

    template_fields: Sequence[str] = ("space_id", "model_name", "dataframe_path")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        model_name: str,
        model_type: Any,
        environment: Any,
        dataframe: Any = None,
        dataframe_path: str | None = None,
        schema: Any,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        extra_log_kwargs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.model_name = model_name
        self.model_type = model_type
        self.environment = environment
        self.dataframe = dataframe
        self.dataframe_path = dataframe_path
        self.schema = schema
        self.arize_ax_conn_id = arize_ax_conn_id
        self.extra_log_kwargs = extra_log_kwargs or {}

    def execute(self, context: Context) -> Any:
        df = _load_dataframe(self.dataframe, self.dataframe_path)
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.log_ml_batch(
            space_id=space_id,
            model_name=self.model_name,
            model_type=self.model_type,
            environment=self.environment,
            dataframe=df,
            schema=self.schema,
            **self.extra_log_kwargs,
        )


class ArizeAxMLLogStreamOperator(BaseOperator):
    """Stream log a single ML prediction (or small batch) to Arize AX."""

    template_fields: Sequence[str] = ("space_id", "model_name")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        model_name: str,
        model_type: Any,
        environment: Any,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        log_params: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.model_name = model_name
        self.model_type = model_type
        self.environment = environment
        self.arize_ax_conn_id = arize_ax_conn_id
        self.log_params = log_params or {}

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.log_ml_stream(
            space_id=space_id,
            model_name=self.model_name,
            model_type=self.model_type,
            environment=self.environment,
            **self.log_params,
        )


class ArizeAxMLExportToDataframeOperator(BaseOperator):
    """Export ML model data to a DataFrame (returned via XCom)."""

    template_fields: Sequence[str] = ("space_id", "model_name", "start_time", "end_time", "where")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        model_name: str,
        environment: Any,
        start_time: Any,
        end_time: Any,
        where: str | None = None,
        columns: list[str] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        extra_export_kwargs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.model_name = model_name
        self.environment = environment
        self.start_time = start_time
        self.end_time = end_time
        self.where = where
        self.columns = columns
        self.arize_ax_conn_id = arize_ax_conn_id
        self.extra_export_kwargs = extra_export_kwargs or {}

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.export_ml_to_df(
            space_id=space_id,
            model_name=self.model_name,
            environment=self.environment,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
            columns=self.columns,
            **self.extra_export_kwargs,
        )


class ArizeAxMLExportToParquetOperator(BaseOperator):
    """Export ML model data to a Parquet file."""

    template_fields: Sequence[str] = ("space_id", "model_name", "start_time", "end_time", "path", "where")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        model_name: str,
        environment: Any,
        start_time: Any,
        end_time: Any,
        path: str,
        where: str | None = None,
        columns: list[str] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        extra_export_kwargs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.model_name = model_name
        self.environment = environment
        self.start_time = start_time
        self.end_time = end_time
        self.path = path
        self.where = where
        self.columns = columns
        self.arize_ax_conn_id = arize_ax_conn_id
        self.extra_export_kwargs = extra_export_kwargs or {}

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        hook.export_ml_to_parquet(
            space_id=space_id,
            model_name=self.model_name,
            environment=self.environment,
            start_time=self.start_time,
            end_time=self.end_time,
            path=self.path,
            where=self.where,
            columns=self.columns,
            **self.extra_export_kwargs,
        )
