"""Arize AX Annotation Config and Annotation Queue operators."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import is_not_found

if TYPE_CHECKING:
    from airflow.utils.context import Context


class ArizeAxCreateAnnotationConfigOperator(BaseOperator):
    """Create an annotation config (alpha).

    Params:
        name: Config name.
        space: Space name or ID (uses connection default_space if omitted).
        config_type: ``"freeform"`` (default), ``"categorical"``, or ``"continuous"``.
        minimum_score: Lower bound for continuous configs.
        maximum_score: Upper bound for continuous configs.
        values: Label list for categorical configs (list of CategoricalAnnotationValue).
        optimization_direction: ``"maximize"`` or ``"minimize"`` (optional).
    """

    ui_color = "#e4f0e8"
    template_fields = ("name", "space")

    def __init__(
        self,
        *,
        name: str,
        space: str | None = None,
        config_type: str = "freeform",
        minimum_score: float | None = None,
        maximum_score: float | None = None,
        values: list | None = None,
        optimization_direction: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.space = space
        self.config_type = config_type
        self.minimum_score = minimum_score
        self.maximum_score = maximum_score
        self.values = values
        self.optimization_direction = optimization_direction
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.create_annotation_config(
            name=self.name,
            space=self.space,
            config_type=self.config_type,
            minimum_score=self.minimum_score,
            maximum_score=self.maximum_score,
            values=self.values,
            optimization_direction=self.optimization_direction,
        )
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            return str(result.get("id", result))
        return str(result)


class ArizeAxDeleteAnnotationConfigOperator(BaseOperator):
    """Delete an annotation config by name or ID (alpha).

    Params:
        annotation_config: Config name or ID.
        space: Space name or ID (optional).
        ignore_if_missing: when ``True`` (the default), a 404 Not Found error
            is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_config", "space")

    def __init__(
        self,
        *,
        annotation_config: str,
        space: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_config = annotation_config
        self.space = space
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_annotation_config(
                annotation_config=self.annotation_config,
                space=self.space,
            )
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Annotation config %r not found — skipping delete (ignore_if_missing=True).",
                    self.annotation_config,
                )
                return
            raise


class ArizeAxListAnnotationConfigsOperator(BaseOperator):
    """List annotation configurations in Arize AX."""

    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_annotation_configs(limit=self.limit, cursor=self.cursor)


# ---------------------------------------------------------------------------
# Annotation Queues (alpha — SDK 8.11+)
# ---------------------------------------------------------------------------


class ArizeAxListAnnotationQueuesOperator(BaseOperator):
    """List annotation queues in a space (alpha).

    Params:
        space: Space name or ID (accepts either).
        limit: Max queues to return per page (default 50).
        cursor: Pagination cursor from a previous response.
        name: Optional name filter.
    """

    ui_color = "#e4f0e8"
    template_fields = ("space", "cursor", "name")

    def __init__(
        self,
        *,
        space: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        name: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space = space
        self.limit = limit
        self.cursor = cursor
        self.name = name
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_annotation_queues(
            space=self.space,
            limit=self.limit,
            cursor=self.cursor,
            name=self.name,
        )


class ArizeAxGetAnnotationQueueOperator(BaseOperator):
    """Get a single annotation queue by name or ID (alpha).

    Params:
        annotation_queue: Queue name or ID.
        space: Space name or ID.
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space")

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_annotation_queue(
            annotation_queue=self.annotation_queue,
            space=self.space,
        )


class ArizeAxCreateAnnotationQueueOperator(BaseOperator):
    """Create an annotation queue (alpha).

    Params:
        name: Queue name.
        space: Space name or ID.
        annotation_config_ids: List of annotation config IDs to attach.
        annotator_emails: Emails of annotators to assign.
        instructions: Annotation instructions shown to annotators.
        assignment_method: Record assignment strategy (e.g. "manual").
        record_sources: Initial record sources to populate the queue.
    """

    ui_color = "#e4f0e8"
    # ``annotation_config_ids``, ``annotator_emails``, and ``record_sources``
    # hold lists/dicts that may include Jinja-templated strings (config IDs,
    # emails, dataset IDs). Airflow recursively renders nested structures
    # only when the parent field name is listed here.
    template_fields = (
        "name", "space", "instructions",
        "annotation_config_ids", "annotator_emails", "record_sources",
    )

    def __init__(
        self,
        *,
        name: str,
        space: str | None = None,
        annotation_config_ids: list[str] | None = None,
        annotator_emails: list[str] | None = None,
        instructions: str | None = None,
        assignment_method: str | None = None,
        record_sources: list[Any] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.space = space
        self.annotation_config_ids = annotation_config_ids
        self.annotator_emails = annotator_emails
        self.instructions = instructions
        self.assignment_method = assignment_method
        self.record_sources = record_sources
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.create_annotation_queue(
            name=self.name,
            space=self.space,
            annotation_config_ids=self.annotation_config_ids,
            annotator_emails=self.annotator_emails,
            instructions=self.instructions,
            assignment_method=self.assignment_method,
            record_sources=self.record_sources,
        )
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            return str(result.get("id", result))
        return str(result)


class ArizeAxUpdateAnnotationQueueOperator(BaseOperator):
    """Update an existing annotation queue (alpha).

    Params:
        annotation_queue: Queue name or ID to update.
        space: Space name or ID.
        name: New name for the queue.
        instructions: Updated annotation instructions.
        annotation_config_ids: Updated list of annotation config IDs.
        annotator_emails: Updated list of annotator emails.
    """

    ui_color = "#e4f0e8"
    template_fields = (
        "annotation_queue", "space", "name", "instructions",
        "annotation_config_ids", "annotator_emails",
    )

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        name: str | None = None,
        instructions: str | None = None,
        annotation_config_ids: list[str] | None = None,
        annotator_emails: list[str] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.name = name
        self.instructions = instructions
        self.annotation_config_ids = annotation_config_ids
        self.annotator_emails = annotator_emails
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.update_annotation_queue(
            annotation_queue=self.annotation_queue,
            space=self.space,
            name=self.name,
            instructions=self.instructions,
            annotation_config_ids=self.annotation_config_ids,
            annotator_emails=self.annotator_emails,
        )


class ArizeAxDeleteAnnotationQueueOperator(BaseOperator):
    """Delete an annotation queue (alpha).

    Params:
        annotation_queue: Queue name or ID to delete.
        space: Space name or ID.
        ignore_if_missing: when ``True`` (the default), a 404 Not Found error
            is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space")

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_annotation_queue(
                annotation_queue=self.annotation_queue,
                space=self.space,
            )
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Annotation queue %r not found — skipping delete (ignore_if_missing=True).",
                    self.annotation_queue,
                )
                return
            raise


class ArizeAxListAnnotationQueueRecordsOperator(BaseOperator):
    """List records pending review in an annotation queue (alpha).

    Server cap is 500 records per page.

    Params:
        annotation_queue: Queue name or ID.
        space: Space name or ID.
        limit: Max records per page (default 100, server cap 500).
        cursor: Pagination cursor.
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space", "cursor")

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_annotation_queue_records(
            annotation_queue=self.annotation_queue,
            space=self.space,
            limit=self.limit,
            cursor=self.cursor,
        )


class ArizeAxAddAnnotationQueueRecordsOperator(BaseOperator):
    """Add record sources to an annotation queue (alpha).

    Max 2 sources, 500 records total per request.

    Params:
        annotation_queue: Queue name or ID.
        space: Space name or ID.
        record_sources: List of record source objects (max 2).
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space", "record_sources")

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        record_sources: list[Any],
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.record_sources = record_sources
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.add_annotation_queue_records(
            annotation_queue=self.annotation_queue,
            space=self.space,
            record_sources=self.record_sources,
        )


class ArizeAxAnnotateQueueRecordOperator(BaseOperator):
    """Submit annotations on a queue record (alpha).

    Params:
        annotation_queue: Queue name or ID.
        space: Space name or ID.
        record_id: Record ID to annotate.
        annotations: Annotation data (list or dict as accepted by the SDK).
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space", "record_id", "annotations")

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        record_id: str,
        annotations: list[Any] | dict[str, Any],
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.record_id = record_id
        self.annotations = annotations
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.annotate_queue_record(
            annotation_queue=self.annotation_queue,
            space=self.space,
            record_id=self.record_id,
            annotations=self.annotations,
        )


class ArizeAxDeleteAnnotationQueueRecordsOperator(BaseOperator):
    """Delete records from an annotation queue (alpha).

    Unknown record IDs are silently ignored by the API, so this operation is
    safe to retry.  1–100 record IDs per request.

    Params:
        annotation_queue: Queue name or ID.
        record_ids: List of record IDs to delete (1–100).
        space_id: Space name or ID (optional).
        ignore_if_missing: when ``True`` (the default), a 404 Not Found error
            is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    ui_color = "#e4f0e8"
    template_fields = ("annotation_queue", "space_id", "record_ids")

    def __init__(
        self,
        *,
        annotation_queue: str,
        record_ids: list[str],
        space_id: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.record_ids = record_ids
        self.space_id = space_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        if not self.record_ids:
            raise AirflowException(
                f"{type(self).__name__}: record_ids must not be empty."
            )
        if len(self.record_ids) > 100:
            raise AirflowException(
                f"{type(self).__name__}: record_ids exceeds the 100-entry limit "
                f"(got {len(self.record_ids)})."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_annotation_queue_records(
                annotation_queue=self.annotation_queue,
                record_ids=self.record_ids,
                space=self.space_id,
            )
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Annotation queue %r not found — skipping delete_records "
                    "(ignore_if_missing=True).",
                    self.annotation_queue,
                )
                return
            raise


class ArizeAxAssignQueueRecordOperator(BaseOperator):
    """Assign a queue record to one or more users (alpha).

    Params:
        annotation_queue: Queue name or ID.
        space: Space name or ID.
        record_id: Record ID to assign.
        assigned_user_emails: List of user email addresses to assign.
    """

    ui_color = "#e4f0e8"
    template_fields = (
        "annotation_queue", "space", "record_id", "assigned_user_emails",
    )

    def __init__(
        self,
        *,
        annotation_queue: str,
        space: str | None = None,
        record_id: str,
        assigned_user_emails: list[str],
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.annotation_queue = annotation_queue
        self.space = space
        self.record_id = record_id
        self.assigned_user_emails = assigned_user_emails
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.assign_queue_record(
            annotation_queue=self.annotation_queue,
            space=self.space,
            record_id=self.record_id,
            assigned_user_emails=self.assigned_user_emails,
        )
