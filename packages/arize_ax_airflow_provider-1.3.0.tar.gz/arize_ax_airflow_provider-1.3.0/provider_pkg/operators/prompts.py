"""Arize AX Prompt operators.

Uses the Arize REST API (``POST/GET/DELETE /v2/prompts``) via hook methods.
The endpoint is alpha-status -- see https://arize.com/docs/api-reference/prompts/create-a-prompt
"""

from __future__ import annotations

import logging
import statistics
from datetime import timezone
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException

try:
    from airflow.sdk.exceptions import AirflowFailException
except ImportError:
    from airflow.exceptions import AirflowFailException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import is_not_found

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


def _is_conflict(exc: BaseException) -> bool:
    """Return True if *exc* is an HTTP 409 Conflict."""
    return getattr(exc, "status", None) == 409


def _find_prompt_by_name(hook: ArizeAxHook, name: str, space_id: str | None) -> str | None:
    """Paginate ``list_prompts`` to find the ID of a prompt matching *name*."""
    cursor: str | None = None
    while True:
        result = hook.list_prompts(space_id=space_id, cursor=cursor)
        for item in result.get("items", []):
            if isinstance(item, dict) and item.get("name") == name:
                return str(item["id"])
        cursor = result.get("next_cursor")
        if not cursor:
            return None


# Placeholder content we refuse to push to Prompt Hub (e.g. when OPENAI_API_KEY was missing).
_CREATE_PROMPT_PLACEHOLDER = "Placeholder: set OPENAI_API_KEY and re-run to generate an optimized prompt."


class ArizeAxCreatePromptOperator(BaseOperator):
    """Create a prompt with an initial version in the Arize Prompt Hub.

    ``if_exists`` controls behaviour when a prompt with the same name
    already exists (HTTP 409):

    - ``"fail"`` (default): raise the conflict.
    - ``"skip"``: look up the existing prompt and return its ID without
      modifying anything.
    - ``"add_version"``: resolve the existing prompt by name, push the new
      ``messages`` as a fresh version via ``client.prompts.create_version``,
      and return the existing prompt's ID. The new version dict is pushed
      to the ``result`` XCom key (``{"id": <version_id>, ...}``) so
      downstream tasks can grab the version-specific ID when needed.

    When ``messages_task_id`` is set, messages are taken from that task's XCom
    at runtime (key ``messages_key``, default ``"messages"``). Use this to
    create a prompt from upstream output (e.g. prompt optimization DAGs).
    """

    template_fields: Sequence[str] = (
        "space_id", "name", "description", "commit_message", "model",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        name: str,
        messages: list[dict[str, Any]] | None = None,
        provider: str = "open_ai",
        input_variable_format: str = "f_string",
        model: str | None = None,
        description: str | None = None,
        commit_message: str | None = None,
        invocation_params: dict[str, Any] | None = None,
        provider_params: dict[str, Any] | None = None,
        if_exists: str = "fail",
        messages_task_id: str | None = None,
        messages_key: str = "messages",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.name = name
        self.messages = messages or []
        self.provider = provider
        self.input_variable_format = input_variable_format
        self.model = model
        self.description = description
        self.commit_message = commit_message
        self.invocation_params = invocation_params
        self.provider_params = provider_params
        self.if_exists = if_exists
        self.messages_task_id = messages_task_id
        self.messages_key = messages_key
        self.arize_ax_conn_id = arize_ax_conn_id
        if not self.messages_task_id and not self.messages:
            raise ValueError("Provide either messages or messages_task_id.")
        if self.if_exists not in ("fail", "skip", "add_version"):
            raise ValueError(
                f"if_exists must be 'fail', 'skip', or 'add_version'; got {self.if_exists!r}."
            )

    def execute(self, context: Context) -> str:
        messages = self._resolve_messages(context)
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        try:
            result = hook.create_prompt(
                space_id=space_id,
                name=self.name,
                messages=messages,
                provider=self.provider,
                input_variable_format=self.input_variable_format,
                model=self.model,
                description=self.description,
                commit_message=self.commit_message,
                invocation_params=self.invocation_params,
                provider_params=self.provider_params,
            )
            prompt_id = result.get("id") if isinstance(result, dict) else getattr(result, "id", result)
            return str(prompt_id)
        except Exception as exc:
            if not _is_conflict(exc):
                raise
            if self.if_exists == "fail":
                raise
            existing_id = _find_prompt_by_name(hook, self.name, space_id)
            if not existing_id:
                raise AirflowException(
                    f"Prompt {self.name!r} conflict (409) but could not be found via list."
                ) from exc
            if self.if_exists == "skip":
                log.info(
                    "Prompt %r already exists (if_exists='skip'), returning ID %s.",
                    self.name, existing_id,
                )
                return existing_id
            # if_exists == "add_version"
            log.info(
                "Prompt %r already exists (if_exists='add_version'), "
                "pushing new version under prompt_id=%s.",
                self.name, existing_id,
            )
            version = hook.add_prompt_version(
                prompt_id=existing_id,
                messages=messages,
                provider=self.provider,
                input_variable_format=self.input_variable_format,
                model=self.model,
                commit_message=self.commit_message,
                invocation_params=self.invocation_params,
                provider_params=self.provider_params,
            )
            ti = context.get("ti")
            if ti is not None:
                ti.xcom_push(key="result", value=version)
            return existing_id

    def _resolve_messages(self, context: Context) -> list[dict[str, Any]]:
        if self.messages_task_id:
            ti = context["ti"]
            payload = ti.xcom_pull(task_ids=self.messages_task_id) or {}
            messages = payload.get(self.messages_key, payload if isinstance(payload, list) else [])
            if not isinstance(messages, list):
                messages = [messages] if messages else []
            if not messages or (
                len(messages) == 1
                and (messages[0].get("content") or "").strip() == _CREATE_PROMPT_PLACEHOLDER
            ):
                raise AirflowFailException(
                    "Refusing to create prompt with placeholder content. "
                    "Set OPENAI_API_KEY (or fix upstream) so a real prompt is produced."
                )
            return messages
        return self.messages


class ArizeAxListPromptsOperator(BaseOperator):
    """List prompts in a space."""

    template_fields: Sequence[str] = ("space_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = self.space_id or hook.default_space
        return hook.list_prompts(space_id=space_id, limit=self.limit, cursor=self.cursor)


class ArizeAxGetPromptOperator(BaseOperator):
    """Get a prompt by ID or name, optionally resolving a specific version.

    Provide exactly one of ``prompt_id`` or ``prompt_name``. When
    ``prompt_name`` is used, the lookup is scoped to ``space_id`` (or the
    connection's default space when omitted).
    """

    template_fields: Sequence[str] = (
        "prompt_id",
        "prompt_name",
        "space_id",
        "version_id",
        "version_label",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        prompt_id: str | None = None,
        prompt_name: str | None = None,
        space_id: str | None = None,
        version_id: str | None = None,
        version_label: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.prompt_id = prompt_id
        self.prompt_name = prompt_name
        self.space_id = space_id
        self.version_id = version_id
        self.version_label = version_label
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        if bool(self.prompt_id) == bool(self.prompt_name):
            raise AirflowException(
                "ArizeAxGetPromptOperator: provide exactly one of "
                "prompt_id or prompt_name."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        if self.prompt_name:
            space_id = hook.get_space(self.space_id)
            return hook.get_prompt_by_name(space_id=space_id, name=self.prompt_name)
        return hook.get_prompt(
            prompt_id=self.prompt_id,
            version_id=self.version_id,
            version_label=self.version_label,
        )


class ArizeAxDeletePromptOperator(BaseOperator):
    """Delete a prompt by ID.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("prompt_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        prompt_id: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.prompt_id = prompt_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_prompt(prompt_id=self.prompt_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Prompt %r not found — skipping delete (ignore_if_missing=True).",
                    self.prompt_id,
                )
                return
            raise


def _resolve_callable(ref: Any) -> Any:
    """If *ref* is a dotted-path string, import and return the callable."""
    if callable(ref) or not isinstance(ref, str):
        return ref
    from importlib import import_module
    module_path, _, attr = ref.rpartition(".")
    if not module_path:
        raise ValueError(f"Cannot import callable from dotted path: {ref!r}")
    mod = import_module(module_path)
    return getattr(mod, attr)


def _extract_experiment_scores(result: Any) -> dict[str, float]:
    """Extract mean scores across all evaluation metrics from run_experiment result."""
    dataframe_records = []
    if isinstance(result, dict):
        dataframe_records = result.get("dataframe_records") or []
    scores_by_metric: dict[str, list[float]] = {}
    for row in dataframe_records:
        if not isinstance(row, dict):
            continue
        for key, val in row.items():
            if "score" in key.lower() or "eval" in key.lower():
                try:
                    fval = float(val)
                    scores_by_metric.setdefault(key, []).append(fval)
                except (TypeError, ValueError):
                    pass
    return {
        metric: statistics.mean(vals)
        for metric, vals in scores_by_metric.items()
        if vals
    }


class ArizeAxComparePromptsOperator(BaseOperator):
    """Run A/B evaluation across N prompts and return ranked results.

    For each prompt name in ``prompt_names``, the operator:
    1. Fetches the prompt from Prompt Hub (by name, within ``space_id``).
    2. Runs a separate experiment per prompt via ``hook.run_experiment``.
    3. Ranks experiments by mean eval score across all metrics.
    4. Returns ``{"rankings": [...], "winner": prompt_name}`` via XCom.

    ``task`` and ``evaluators`` accept either callables or dotted-path strings
    (same convention as ``ArizeAxRunExperimentOperator``).

    XCom return schema::

        {
            "rankings": [
                {
                    "rank": int,
                    "prompt_name": str,
                    "experiment_id": str | None,
                    "scores": {metric: float, ...},
                    "mean_score": float,
                },
                ...
            ],
            "winner": str | None,
        }
    """

    template_fields: Sequence[str] = (
        "prompt_names",
        "dataset_id",
        "experiment_name_prefix",
        "space_id",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        prompt_names: list[str],
        dataset_id: str,
        task: Any,
        evaluators: list[Any] | None = None,
        experiment_name_prefix: str = "prompt-ab",
        space_id: str | None = None,
        concurrency: int | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if not prompt_names:
            raise ValueError("prompt_names must be a non-empty list.")
        self.prompt_names = prompt_names
        self.dataset_id = dataset_id
        self.task = task
        self.evaluators = evaluators
        self.experiment_name_prefix = experiment_name_prefix
        self.space_id = space_id
        self.concurrency = concurrency
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        from datetime import datetime

        ts_nodash = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%S")
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        task_fn = _resolve_callable(self.task)
        evaluator_fns = [_resolve_callable(e) for e in (self.evaluators or [])]

        results: list[dict[str, Any]] = []
        for prompt_name in self.prompt_names:
            exp_name = f"{self.experiment_name_prefix}-{prompt_name}-{ts_nodash}"
            self.log.info(
                "Running experiment %r for prompt %r on dataset %r.",
                exp_name, prompt_name, self.dataset_id,
            )
            try:
                run_result = hook.run_experiment(
                    name=exp_name,
                    dataset_id=self.dataset_id,
                    task=task_fn,
                    evaluators=evaluator_fns or None,
                    concurrency=self.concurrency,
                )
            except Exception as exc:
                self.log.warning(
                    "Experiment for prompt %r failed: %s -- continuing with others.",
                    prompt_name, exc,
                )
                run_result = {}

            exp_obj = run_result.get("experiment") if isinstance(run_result, dict) else None
            exp_id: str | None = None
            if isinstance(exp_obj, dict):
                exp_id = str(exp_obj.get("id") or exp_obj.get("experiment_id") or "")
            scores = _extract_experiment_scores(run_result)
            mean_score = statistics.mean(scores.values()) if scores else 0.0
            results.append({
                "prompt_name": prompt_name,
                "experiment_id": exp_id or None,
                "scores": scores,
                "mean_score": mean_score,
            })

        ranked = sorted(results, key=lambda r: r["mean_score"], reverse=True)
        for i, entry in enumerate(ranked):
            entry["rank"] = i + 1

        winner = ranked[0]["prompt_name"] if ranked else None
        self.log.info(
            "Prompt A/B ranking: %s  |  winner=%r",
            [(r["rank"], r["prompt_name"], r["mean_score"]) for r in ranked],
            winner,
        )
        return {"rankings": ranked, "winner": winner}


class ArizeAxPromotePromptOperator(BaseOperator):
    """Tag a prompt version with a label in Prompt Hub.

    Applies ``promotion_label`` (e.g. ``"production"``, ``"staging"``,
    ``"archived"``) to a specific prompt version using ``prompts.set_labels``.
    If ``version_id`` is None, the latest version is resolved automatically.

    Returns ``{"prompt_id": str, "label": str}`` via XCom.
    """

    template_fields: Sequence[str] = (
        "prompt_name",
        "promotion_label",
        "version_id",
        "space_id",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        prompt_name: str,
        label: str,
        space_id: str | None = None,
        version_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.prompt_name = prompt_name
        self.promotion_label = label
        self.space_id = space_id
        self.version_id = version_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)

        prompt_data = hook.get_prompt_by_name(space_id=space_id, name=self.prompt_name)
        if prompt_data is None:
            raise AirflowException(
                f"Prompt {self.prompt_name!r} not found in space {space_id!r}. "
                "Verify the prompt name and space ID."
            )
        prompt_id = str(prompt_data.get("id") or "")
        if not prompt_id:
            raise AirflowException(
                f"Prompt {self.prompt_name!r} found but has no ID in the API response."
            )

        self.log.info(
            "Promoting prompt %r (id=%s) to label=%r (version_id=%r).",
            self.prompt_name, prompt_id, self.promotion_label, self.version_id,
        )
        hook.promote_prompt(
            space_id=space_id,
            prompt_id=prompt_id,
            label=self.promotion_label,
            version_id=self.version_id,
        )
        self.log.info("Prompt %r promoted to label=%r.", self.prompt_name, self.promotion_label)
        return {"prompt_id": prompt_id, "label": self.promotion_label}


class ArizeAxOptimizePromptOperator(BaseOperator):
    """Run meta-prompt optimization via the Arize Prompt Learning SDK.

    Wraps ``PromptLearningOptimizer.optimize`` so a DAG can improve a system
    prompt from in-production feedback (eval scores + human annotations) with
    a single task. Requires the ``prompt-learning-enhanced`` SDK (git
    source — PyPI rejects direct-URL deps, so this is installed separately
    rather than as an optional extra)::

        pip install 'arize-phoenix-evals>=2.0,<3.0' \\
                    'prompt-learning-enhanced @ git+https://github.com/Arize-ai/prompt-learning.git'

    Inputs:
        ``dataset`` is a list[dict] / pandas DataFrame with at least the
        configured ``output_column`` and one or more ``feedback_columns``.
        Alternatively, set ``dataset_task_id`` (and optionally ``dataset_key``)
        to pull the dataset from an upstream task's XCom.

    Dynamic task mapping:
        This operator is designed to be expanded via
        ``ArizeAxOptimizePromptOperator.partial(...).expand_kwargs(curate.output)``
        where ``curate`` emits a list of ``{prompt, dataset, group_key}``
        kwargs dicts (one per prompt group). The optional ``group_key`` is a
        passthrough label carried into the result for downstream tasks (e.g.
        per-agent prompt creation).

    Returns:
        A result dict with keys ``content`` (optimized prompt string),
        ``messages`` (list ready for ``ArizeAxCreatePromptOperator``),
        ``group_key``, ``raw``, ``model_choice``. Also pushes the same dict
        under the XCom key ``result`` and the prompt string under
        ``content`` for downstream tasks that only need the text.
    """

    template_fields: Sequence[str] = (
        "prompt",
        "model_choice",
        "output_column",
        "dataset_task_id",
        "dataset_key",
        "group_key",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        prompt: str,
        dataset: Any = None,
        dataset_task_id: str | None = None,
        dataset_key: str | None = None,
        output_column: str = "output",
        feedback_columns: list[str] | None = None,
        model_choice: str = "gpt-4o",
        openai_api_key: str | None = None,
        context_size_k: int = 8000,
        group_key: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.prompt = prompt
        self.dataset = dataset
        self.dataset_task_id = dataset_task_id
        self.dataset_key = dataset_key
        self.output_column = output_column
        self.feedback_columns = list(feedback_columns) if feedback_columns else ["feedback"]
        self.model_choice = model_choice
        self.openai_api_key = openai_api_key
        self.context_size_k = context_size_k
        self.group_key = group_key
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        if not self.prompt or not str(self.prompt).strip():
            raise AirflowException(
                "ArizeAxOptimizePromptOperator: 'prompt' must be a non-empty string."
            )
        if self.dataset is None and not self.dataset_task_id:
            raise AirflowException(
                "ArizeAxOptimizePromptOperator: provide either dataset or dataset_task_id."
            )

        dataset = self._resolve_dataset(context)
        df = self._to_dataframe(dataset)
        if df is None or len(df) == 0:
            raise AirflowFailException(
                "ArizeAxOptimizePromptOperator: dataset is empty — no records to optimize against."
            )
        missing = [c for c in self.feedback_columns if c not in df.columns]
        if missing:
            raise AirflowFailException(
                f"ArizeAxOptimizePromptOperator: dataset missing feedback columns: {missing}. "
                f"Got columns: {list(df.columns)}"
            )
        if self.output_column not in df.columns:
            raise AirflowFailException(
                f"ArizeAxOptimizePromptOperator: output_column {self.output_column!r} "
                f"not in dataset columns: {list(df.columns)}"
            )

        import os

        api_key = self.openai_api_key or os.environ.get("OPENAI_API_KEY")
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.optimize_prompt(
            prompt=self.prompt,
            dataset=df,
            output_column=self.output_column,
            feedback_columns=self.feedback_columns,
            model_choice=self.model_choice,
            openai_api_key=api_key,
            context_size_k=self.context_size_k,
        )
        result["group_key"] = self.group_key
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
            ti.xcom_push(key="messages", value=result["messages"])
            ti.xcom_push(key="content", value=result["content"])
        return result

    def _resolve_dataset(self, context: Context) -> Any:
        if self.dataset is not None:
            return self.dataset
        ti = context["ti"]
        payload = ti.xcom_pull(task_ids=self.dataset_task_id)
        if payload is None:
            raise AirflowFailException(
                f"ArizeAxOptimizePromptOperator: no XCom from task_id={self.dataset_task_id!r}."
            )
        if self.dataset_key and isinstance(payload, dict):
            payload = payload.get(self.dataset_key)
        if payload is None:
            raise AirflowFailException(
                f"ArizeAxOptimizePromptOperator: dataset_key={self.dataset_key!r} "
                f"missing from upstream XCom."
            )
        return payload

    @staticmethod
    def _to_dataframe(dataset: Any) -> Any:
        try:
            import pandas as pd
        except ImportError as exc:
            raise AirflowException(
                "pandas is required for ArizeAxOptimizePromptOperator."
            ) from exc
        if isinstance(dataset, pd.DataFrame):
            return dataset
        if isinstance(dataset, list):
            return pd.DataFrame(dataset)
        if isinstance(dataset, dict):
            return pd.DataFrame(dataset)
        raise AirflowFailException(
            f"ArizeAxOptimizePromptOperator: unsupported dataset type {type(dataset).__name__}; "
            "expected pandas.DataFrame, list[dict], or dict."
        )
