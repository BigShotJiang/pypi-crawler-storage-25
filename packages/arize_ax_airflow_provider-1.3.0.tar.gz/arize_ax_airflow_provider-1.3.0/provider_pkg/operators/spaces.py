"""Arize AX Space operators."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import (
    find_resource_by_name,
    is_conflict,
    is_not_found,
)

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


class ArizeAxListSpacesOperator(BaseOperator):
    """List spaces accessible to the authenticated user."""

    template_fields: Sequence[str] = ("organization_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        organization_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.organization_id = organization_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_spaces(
            organization_id=self.organization_id,
            limit=self.limit,
            cursor=self.cursor,
        )
        ti = context.get("ti")
        if ti is not None:
            items = result.get("items", []) if isinstance(result, dict) else []
            if items and isinstance(items[0], dict):
                ti.xcom_push(key="first_id", value=str(items[0].get("id", "")))
                ti.xcom_push(key="first_name", value=str(items[0].get("name", "")))
        return result


class ArizeAxGetSpaceOperator(BaseOperator):
    """Get a single space by ID or name.

    Returns the space object serialized as a dict via XCom.
    """

    template_fields: Sequence[str] = ("space",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space = space
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_space_resource(space=self.space)


class ArizeAxCreateSpaceOperator(BaseOperator):
    """Create a space in an organization.

    Set ``if_exists="skip"`` for idempotent runs: a 409 Conflict causes the
    operator to look up the existing space and return its ID so that downstream
    tasks continue to work.  Default is ``"fail"`` (raise on conflict).
    """

    template_fields: Sequence[str] = ("name", "organization_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        organization_id: str,
        description: str | None = None,
        if_exists: str = "fail",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.organization_id = organization_id
        self.description = description
        self.if_exists = if_exists
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            result = hook.create_space(
                name=self.name,
                organization_id=self.organization_id,
                description=self.description,
            )
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "Space '%s' already exists -- returning existing ID.",
                    self.name,
                )
                existing_id = find_resource_by_name(hook, "list_spaces", self.name)
                if existing_id:
                    self.log.info("Resolved existing space ID: %s", existing_id)
                    return existing_id
                raise AirflowException(
                    f"Space '{self.name}' conflicts but could not be found via list API."
                ) from exc
            raise
        if isinstance(result, dict):
            return str(result.get("id", result))
        return str(result)


class ArizeAxUpdateSpaceOperator(BaseOperator):
    """Update an existing space.

    Returns the updated space object as a dict via XCom.
    """

    template_fields: Sequence[str] = ("space", "name")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space: str,
        name: str | None = None,
        description: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space = space
        self.name = name
        self.description = description
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.update_space(
            space=self.space,
            name=self.name,
            description=self.description,
        )


class ArizeAxDeleteSpaceOperator(BaseOperator):
    """Delete a space by ID or name.

    Note: this calls an ALPHA endpoint and behaviour may change.
    Returns ``None`` via XCom.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("space",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space = space
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_space(space=self.space)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Space %r not found — skipping delete (ignore_if_missing=True).",
                    self.space,
                )
                return
            raise
