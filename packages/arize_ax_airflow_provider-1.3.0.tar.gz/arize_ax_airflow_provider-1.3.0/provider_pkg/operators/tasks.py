"""Arize AX Tasks operators.

Wraps the ``client.tasks`` SDK client for creating and querying evaluation
tasks and their runs.  Tasks connect evaluators to a project or dataset and
can run continuously or on demand.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence

from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook

if TYPE_CHECKING:  # pragma: no cover
    from airflow.utils.context import Context


class ArizeAxListTasksOperator(BaseOperator):
    """List evaluation tasks in Arize AX, optionally filtered by space, project, dataset, or type.

    Use ``eval_task_type`` to filter by task type (e.g. ``"llm"``).

    Returns a structured list dict (``items``, ``next_cursor``, ``count``) via XCom.
    """

    template_fields: Sequence[str] = ("space_id", "project_id", "dataset_id", "eval_task_type", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_id: str | None = None,
        dataset_id: str | None = None,
        eval_task_type: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.eval_task_type = eval_task_type
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = self.space_id or hook.default_space
        return hook.list_tasks(
            space_id=space_id,
            project_id=self.project_id,
            dataset_id=self.dataset_id,
            task_type=self.eval_task_type,
            limit=self.limit,
            cursor=self.cursor,
        )


class ArizeAxGetTaskOperator(BaseOperator):
    """Get a single evaluation task by ID.

    Returns the task object serialized as a dict via XCom.
    """

    # NOTE: template_fields must match the *instance attribute* names set in
    # __init__ — Airflow walks getattr(self, name). Listing "task_id" here
    # silently no-ops because the operator stores it as self.task_id_param.
    template_fields: Sequence[str] = ("task_id_param",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        task_id_param: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.task_id_param = task_id_param
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_task(task_id=self.task_id_param)


class ArizeAxCreateTaskOperator(BaseOperator):
    """Create an evaluation task connecting evaluators to a project or dataset.

    ``eval_task_type`` must be ``"template_evaluation"`` or ``"code_evaluation"``
    (SDK 8.15.0+).  The legacy value ``"llm"`` is no longer accepted.

    ``evaluators`` must be a list of dicts with an ``"evaluator_id"`` key, e.g.
    ``[{"evaluator_id": "RXZhbHVhdG9y..."}]``.  Plain string IDs and ``{"id": ...}``
    dicts are rejected by the SDK pydantic model.

    Returns the created task object serialized as a dict via XCom.
    """

    # ``evaluators`` and ``experiment_ids`` hold lists of dicts/IDs that may
    # include Jinja templated strings (e.g. ``{"evaluator_id": "{{ ... }}"}``).
    # Airflow renders nested structures when the parent field is listed here.
    template_fields: Sequence[str] = (
        "name",
        "eval_task_type",
        "evaluators",
        "project_id",
        "dataset_id",
        "experiment_ids",
        "query_filter",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        eval_task_type: str,
        evaluators: list[Any] | None = None,
        project_id: str | None = None,
        dataset_id: str | None = None,
        experiment_ids: list[str] | None = None,
        sampling_rate: float | None = None,
        is_continuous: bool | None = None,
        query_filter: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.eval_task_type = eval_task_type
        self.evaluators = evaluators
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.experiment_ids = experiment_ids
        self.sampling_rate = sampling_rate
        self.is_continuous = is_continuous
        self.query_filter = query_filter
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.create_task(
            name=self.name,
            task_type=self.eval_task_type,
            evaluators=self.evaluators,
            project_id=self.project_id,
            dataset_id=self.dataset_id,
            experiment_ids=self.experiment_ids,
            sampling_rate=self.sampling_rate,
            is_continuous=self.is_continuous,
            query_filter=self.query_filter,
        )
        ti = context.get("ti")
        if result is not None and ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            return str(result.get("id") or result.get("task_id", result))
        return str(result)


class ArizeAxListTaskRunsOperator(BaseOperator):
    """List runs for an evaluation task.

    Useful for gating deployments on eval scores from the most recent run.
    Returns a structured list dict (``items``, ``next_cursor``, ``count``) via XCom.
    """

    template_fields: Sequence[str] = ("task_id_param", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        task_id_param: str,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.task_id_param = task_id_param
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_task_runs(
            task_id=self.task_id_param,
            limit=self.limit,
            cursor=self.cursor,
        )


class ArizeAxGetTaskRunOperator(BaseOperator):
    """Get a single task run by run ID.

    Returns the task run object serialized as a dict via XCom.
    """

    template_fields: Sequence[str] = ("run_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        run_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.run_id = run_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_task_run(run_id=self.run_id)


class ArizeAxTriggerTaskRunOperator(BaseOperator):
    """Trigger an on-demand evaluation run for a task.

    Calls ``client.tasks.trigger_run`` and returns the created run dict
    (including ``id``, ``status``) via XCom.

    Two task-type modes:
    - **template_evaluation** (span-scoped): use ``data_start_time``,
      ``data_end_time``, ``max_spans`` to scope which spans get evaluated.
      ``override_evaluations=True`` re-evaluates spans that already have
      labels from prior runs.
    - **run_experiment** (dataset-scoped): use ``experiment_name``,
      ``dataset_version_id``, ``max_examples``, ``tracing_metadata``. The
      hook auto-detects this mode by the presence of any of those kwargs
      and skips the template_evaluation date defaults.
    """

    template_fields: Sequence[str] = (
        "task_id_param",
        "space_id",
        "data_start_time",
        "data_end_time",
        "experiment_name",
        "dataset_version_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        task_id_param: str,
        space_id: str | None = None,
        data_start_time: Any = None,
        data_end_time: Any = None,
        max_spans: int | None = None,
        override_evaluations: bool | None = None,
        experiment_ids: list[str] | None = None,
        experiment_name: str | None = None,
        dataset_version_id: str | None = None,
        max_examples: int | None = None,
        tracing_metadata: dict[str, Any] | None = None,
        skip_on_no_data: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.task_id_param = task_id_param
        self.space_id = space_id
        self.data_start_time = data_start_time
        self.data_end_time = data_end_time
        self.max_spans = max_spans
        self.override_evaluations = override_evaluations
        self.experiment_ids = experiment_ids
        self.experiment_name = experiment_name
        self.dataset_version_id = dataset_version_id
        self.max_examples = max_examples
        self.tracing_metadata = tracing_metadata
        self.skip_on_no_data = skip_on_no_data
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        from airflow.exceptions import AirflowException, AirflowSkipException

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            result = hook.trigger_task_run(
                task_id=self.task_id_param,
                space_id=self.space_id,
                data_start_time=self.data_start_time,
                data_end_time=self.data_end_time,
                max_spans=self.max_spans,
                override_evaluations=self.override_evaluations,
                experiment_ids=self.experiment_ids,
                experiment_name=self.experiment_name,
                dataset_version_id=self.dataset_version_id,
                max_examples=self.max_examples,
                tracing_metadata=self.tracing_metadata,
            )
        except Exception as exc:
            msg = str(exc)
            if "no data found" in msg.lower():
                if self.skip_on_no_data:
                    raise AirflowSkipException(
                        "Skipping trigger_task_run: project has no spans in the "
                        "requested window. (skip_on_no_data=True)"
                    ) from exc
                hint = (
                    "The project has no spans in the requested time window. "
                    "Either widen the window with data_start_time/data_end_time, "
                    "omit both to use all available data, or ingest spans into "
                    "the project before triggering an evaluation run. Set "
                    "skip_on_no_data=True to treat this as an Airflow skip "
                    "instead of a failure."
                )
                raise AirflowException(f"{exc}\n\n{hint}") from exc
            raise
        ti = context.get("ti")
        if result is not None and ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            run_id = result.get("id") or result.get("run_id")
            if run_id:
                return str(run_id)
        return str(result)


class ArizeAxCancelTaskRunOperator(BaseOperator):
    """Cancel a pending or running task run.

    Calls ``client.tasks.cancel_run`` and returns the updated run dict via XCom.
    """

    template_fields: Sequence[str] = ("run_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        run_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.run_id = run_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.cancel_task_run(run_id=self.run_id)


class ArizeAxCreateRunExperimentTaskOperator(BaseOperator):
    """Create a run_experiment task where Arize drives LLM calls server-side.

    Uses ``client.tasks.create_run_experiment_task`` (SDK 8.23.0+).

    ``run_configuration`` accepts an SDK ``RunConfiguration`` object or an
    equivalent dict (e.g. wrapping ``LlmGenerationRunConfig`` or
    ``TemplateEvaluationRunConfig``).

    Set ``if_exists="skip"`` to return the existing task ID on 409 Conflict
    rather than failing.  Returns the created (or existing) task ID as the
    XCom return value and pushes the full result dict to XCom key ``"result"``.
    """

    # ``run_configuration`` is templated so DAGs can pull a dict/RunConfiguration
    # from XCom via Jinja. Pair this with ``render_template_as_native_obj=True``
    # on the DAG so Jinja yields a native dict instead of its stringified form.
    template_fields: Sequence[str] = (
        "name", "dataset_id", "run_configuration", "space_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        dataset_id: str,
        run_configuration: Any,
        space_id: str | None = None,
        if_exists: str = "fail",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.dataset_id = dataset_id
        self.run_configuration = run_configuration
        self.space_id = space_id
        self.if_exists = if_exists
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        from airflow.exceptions import AirflowException
        from airflow.providers.arize_ax.operators.utils import find_resource_by_name, is_conflict

        if not self.name:
            raise AirflowException("ArizeAxCreateRunExperimentTaskOperator: 'name' is required.")
        if not self.dataset_id:
            raise AirflowException(
                "ArizeAxCreateRunExperimentTaskOperator: 'dataset_id' is required."
            )

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            result = hook.create_run_experiment_task(
                name=self.name,
                dataset_id=self.dataset_id,
                run_configuration=self.run_configuration,
                space=self.space_id,
            )
        except Exception as exc:
            if is_conflict(exc) and self.if_exists == "skip":
                existing_id = find_resource_by_name(
                    hook, "list_tasks", self.name, space_id=self.space_id
                )
                if existing_id:
                    self.log.info(
                        "Task %r already exists (if_exists='skip'), returning existing ID %r.",
                        self.name,
                        existing_id,
                    )
                    return existing_id
            raise

        ti = context.get("ti")
        if result is not None and ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            return str(result.get("id") or result.get("task_id", result))
        return str(result)


class ArizeAxUpdateTaskOperator(BaseOperator):
    """Update mutable fields of an existing evaluation task.

    Uses ``client.tasks.update`` (SDK 8.23.0+).  Only fields that are
    explicitly set (not ``None``) are forwarded to the SDK — the SDK uses a
    ``_MISSING`` sentinel pattern so unset fields are left unchanged.

    At least one mutable field (``name``, ``sampling_rate``, ``is_continuous``,
    ``query_filter`` / ``clear_query_filter``, ``evaluators``,
    ``run_configuration``) must be provided; otherwise ``AirflowException``
    is raised.

    Returns the updated task ID as the XCom return value and pushes the full
    result dict to XCom key ``"result"``.
    """

    template_fields: Sequence[str] = ("task_id_param", "name", "query_filter")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        task_id_param: str,
        name: str | None = None,
        sampling_rate: float | None = None,
        is_continuous: bool | None = None,
        query_filter: str | None = None,
        clear_query_filter: bool = False,
        evaluators: list[Any] | None = None,
        run_configuration: Any | None = None,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.task_id_param = task_id_param
        self.name = name
        self.sampling_rate = sampling_rate
        self.is_continuous = is_continuous
        self.query_filter = query_filter
        self.clear_query_filter = clear_query_filter
        self.evaluators = evaluators
        self.run_configuration = run_configuration
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        from airflow.exceptions import AirflowException

        has_update = any([
            self.name is not None,
            self.sampling_rate is not None,
            self.is_continuous is not None,
            self.query_filter is not None,
            self.clear_query_filter,
            self.evaluators is not None,
            self.run_configuration is not None,
        ])
        if not has_update:
            raise AirflowException(
                "ArizeAxUpdateTaskOperator: at least one mutable field must be provided "
                "(name, sampling_rate, is_continuous, query_filter, clear_query_filter, "
                "evaluators, or run_configuration)."
            )

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.update_task(
            task_id=self.task_id_param,
            space=self.space_id,
            name=self.name,
            sampling_rate=self.sampling_rate,
            is_continuous=self.is_continuous,
            query_filter=self.query_filter,
            clear_query_filter=self.clear_query_filter,
            evaluators=self.evaluators,
            run_configuration=self.run_configuration,
        )

        ti = context.get("ti")
        if result is not None and ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            return str(result.get("id") or result.get("task_id", result))
        return str(result)


class ArizeAxDeleteTaskOperator(BaseOperator):
    """Delete an evaluation task by ID or name.

    Uses ``client.tasks.delete`` (SDK 8.23.0+).

    Set ``ignore_if_missing=False`` to raise on 404; the default is ``True``
    (log and return without raising).  Returns ``None``.
    """

    template_fields: Sequence[str] = ("task_id_param",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        task_id_param: str,
        space_id: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.task_id_param = task_id_param
        self.space_id = space_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        from airflow.providers.arize_ax.operators.utils import is_not_found

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_task(task_id=self.task_id_param, space=self.space_id)
        except Exception as exc:
            if is_not_found(exc) and self.ignore_if_missing:
                self.log.info(
                    "Task %r not found (ignore_if_missing=True), skipping delete.",
                    self.task_id_param,
                )
                return
            raise
