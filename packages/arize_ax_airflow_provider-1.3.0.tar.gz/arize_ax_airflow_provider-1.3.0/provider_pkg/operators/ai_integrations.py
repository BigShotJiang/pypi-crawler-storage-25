"""Arize AX AI Integrations operators.

Wraps the ``client.ai_integrations`` SDK client for listing, fetching,
creating, updating, and deleting AI integrations (LLM provider connections)
configured in Arize AX.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import (
    find_resource_by_name,
    is_conflict,
    is_not_found,
)

if TYPE_CHECKING:  # pragma: no cover
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


class ArizeAxListAIIntegrationsOperator(BaseOperator):
    """List AI integrations in Arize AX, optionally scoped to a space.

    Returns a structured list dict (``items``, ``next_cursor``, ``count``) via XCom.
    """

    template_fields: Sequence[str] = ("space_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = self.space_id or hook.default_space
        result = hook.list_ai_integrations(
            space_id=space_id,
            limit=self.limit,
            cursor=self.cursor,
        )
        ti = context.get("ti")
        if ti is not None:
            items = result.get("items", []) if isinstance(result, dict) else []
            if items and isinstance(items[0], dict):
                ti.xcom_push(key="first_id", value=str(items[0].get("id", "")))
                ti.xcom_push(key="first_name", value=str(items[0].get("name", "")))
        return result


class ArizeAxGetAIIntegrationOperator(BaseOperator):
    """Get a single AI integration by ID.

    Returns the AI integration object serialized as a dict via XCom.
    """

    template_fields: Sequence[str] = ("integration_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        integration_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.integration_id = integration_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_ai_integration(integration_id=self.integration_id)


class ArizeAxCreateAIIntegrationOperator(BaseOperator):
    """Create an AI integration in Arize AX.

    Set ``if_exists="skip"`` for idempotent runs: a 409 Conflict causes the
    operator to look up the existing integration and return its ID so that
    downstream tasks continue to work.  Default is ``"fail"`` (raise on
    conflict).
    """

    template_fields: Sequence[str] = ("name", "provider", "space_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        provider: str,
        space_id: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        model_names: list[str] | None = None,
        headers: dict[str, str] | None = None,
        enable_default_models: bool | None = None,
        function_calling_enabled: bool | None = None,
        auth_type: str | None = None,
        provider_metadata: dict[str, Any] | None = None,
        scopings: list[Any] | None = None,
        if_exists: str = "fail",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.provider = provider
        self.space_id = space_id
        self.api_key = api_key
        self.base_url = base_url
        self.model_names = model_names
        self.headers = headers
        self.enable_default_models = enable_default_models
        self.function_calling_enabled = function_calling_enabled
        self.auth_type = auth_type
        self.provider_metadata = provider_metadata
        self.scopings = scopings
        self.if_exists = if_exists
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            result = hook.create_ai_integration(
                name=self.name,
                provider=self.provider,
                space=self.space_id,
                api_key=self.api_key,
                base_url=self.base_url,
                model_names=self.model_names,
                headers=self.headers,
                enable_default_models=self.enable_default_models,
                function_calling_enabled=self.function_calling_enabled,
                auth_type=self.auth_type,
                provider_metadata=self.provider_metadata,
                scopings=self.scopings,
            )
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "AI integration '%s' already exists -- returning existing ID.",
                    self.name,
                )
                existing_id = find_resource_by_name(
                    hook,
                    "list_ai_integrations",
                    self.name,
                    space_id=self.space_id,
                )
                if existing_id:
                    self.log.info("Resolved existing AI integration ID: %s", existing_id)
                    return existing_id
                raise AirflowException(
                    f"AI integration '{self.name}' conflicts but could not be found via "
                    "list API."
                ) from exc
            raise
        if isinstance(result, dict):
            return str(result.get("id", result))
        return str(result)


class ArizeAxUpdateAIIntegrationOperator(BaseOperator):
    """Update an existing AI integration in Arize AX.

    Returns the updated integration object as a dict via XCom.
    """

    template_fields: Sequence[str] = ("integration_id", "name")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        integration_id: str,
        space_id: str | None = None,
        name: str | None = None,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        model_names: list[str] | None = None,
        headers: dict[str, str] | None = None,
        enable_default_models: bool | None = None,
        function_calling_enabled: bool | None = None,
        auth_type: str | None = None,
        provider_metadata: dict[str, Any] | None = None,
        scopings: list[Any] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.integration_id = integration_id
        self.space_id = space_id
        self.name = name
        self.provider = provider
        self.api_key = api_key
        self.base_url = base_url
        self.model_names = model_names
        self.headers = headers
        self.enable_default_models = enable_default_models
        self.function_calling_enabled = function_calling_enabled
        self.auth_type = auth_type
        self.provider_metadata = provider_metadata
        self.scopings = scopings
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.update_ai_integration(
            integration=self.integration_id,
            space=self.space_id,
            name=self.name,
            provider=self.provider,
            api_key=self.api_key,
            base_url=self.base_url,
            model_names=self.model_names,
            headers=self.headers,
            enable_default_models=self.enable_default_models,
            function_calling_enabled=self.function_calling_enabled,
            auth_type=self.auth_type,
            provider_metadata=self.provider_metadata,
            scopings=self.scopings,
        )


class ArizeAxDeleteAIIntegrationOperator(BaseOperator):
    """Delete an AI integration by ID.

    Returns ``None`` via XCom.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("integration_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        integration_id: str,
        space_id: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.integration_id = integration_id
        self.space_id = space_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_ai_integration(
                integration=self.integration_id,
                space=self.space_id,
            )
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "AI integration %r not found — skipping delete (ignore_if_missing=True).",
                    self.integration_id,
                )
                return
            raise
