"""Arize AX Spans (tracing) operators."""

from __future__ import annotations

import hashlib
import json
import logging
import statistics
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


class ArizeAxListSpansOperator(BaseOperator):
    """List spans from a project with optional time range and filter.

    Provide either **project_id** (base64 ID from Arize) or **space_id** +
    **project_name**. Using a human-readable project name without space_id
    often causes 401 Unauthorized; the operator resolves name to ID when
    space_id and project_name are given.

    .. note::
        ``spans.list`` is currently in **ALPHA** in the Arize SDK v8.
    """

    template_fields: Sequence[str] = ("project_id", "space_id", "project_name", "filter", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str | None = None,
        space_id: str | None = None,
        project_name: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        filter: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.space_id = space_id
        self.project_name = project_name
        self.start_time = start_time
        self.end_time = end_time
        self.filter = filter
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = self.space_id or hook.default_space
        if not self.project_id and not self.project_name:
            raise AirflowException(
                f"{type(self).__name__} requires project_id or project_name. "
                "Set project_id as a task parameter (base64 Arize project ID), "
                "or provide space_id + project_name to resolve by name."
            )
        return hook.list_spans(
            project_id=self.project_id,
            space_id=space_id,
            project_name=self.project_name,
            start_time=self.start_time,
            end_time=self.end_time,
            filter=self.filter,
            limit=self.limit,
            cursor=self.cursor,
        )


class ArizeAxSpansLogOperator(BaseOperator):
    """Bulk log spans (and optional evals) to Arize AX."""

    template_fields: Sequence[str] = ("space_id", "project_name", "dataframe_path", "evals_dataframe_path")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        dataframe: Any = None,
        evals_dataframe: Any = None,
        dataframe_path: str | None = None,
        evals_dataframe_path: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.dataframe = dataframe
        self.evals_dataframe = evals_dataframe
        self.dataframe_path = dataframe_path
        self.evals_dataframe_path = evals_dataframe_path
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        if self.dataframe_path:
            import pandas as pd
            if self.dataframe_path.endswith(".parquet"):
                df = pd.read_parquet(self.dataframe_path)
            else:
                df = pd.read_csv(self.dataframe_path)
        else:
            df = self.dataframe
        evals_df = None
        if self.evals_dataframe_path:
            import pandas as pd
            evals_df = pd.read_parquet(self.evals_dataframe_path) if self.evals_dataframe_path.endswith(".parquet") else pd.read_csv(self.evals_dataframe_path)
        elif self.evals_dataframe is not None:
            evals_df = self.evals_dataframe
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.log_spans(
            space_id=space_id,
            project_name=self.project_name,
            dataframe=df,
            evals_dataframe=evals_df,
        )


def _load_dataframe(dataframe: Any, dataframe_path: str | None) -> Any:
    """Resolve and return a DataFrame from either a path or an in-memory object.

    Exactly one of ``dataframe`` or ``dataframe_path`` must be provided.
    Supports ``.parquet``, ``.csv``, and ``.json`` extensions for path-based loading.

    Raises:
        ValueError: When both or neither source is provided, or for unknown extensions.
    """
    if dataframe is not None and dataframe_path is not None:
        raise ValueError(
            "Provide either dataframe or dataframe_path, not both. "
            "Set one of the two parameters to None."
        )
    if dataframe is None and dataframe_path is None:
        raise ValueError(
            "Either dataframe or dataframe_path must be provided. "
            "Pass a DataFrame directly via dataframe= or a file path via dataframe_path=."
        )
    if dataframe_path is not None:
        import pandas as pd
        if dataframe_path.endswith(".parquet"):
            return pd.read_parquet(dataframe_path)
        if dataframe_path.endswith(".csv"):
            return pd.read_csv(dataframe_path)
        if dataframe_path.endswith(".json"):
            return pd.read_json(dataframe_path)
        raise ValueError(
            f"Unsupported dataframe_path extension for '{dataframe_path}'. "
            "Supported extensions are: .parquet, .csv, .json"
        )
    return dataframe


class ArizeAxSpansUpdateEvaluationsOperator(BaseOperator):
    """Update evaluations for existing spans."""

    template_fields: Sequence[str] = ("space_id", "project_name", "dataframe_path")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        dataframe: Any = None,
        dataframe_path: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.dataframe = dataframe
        self.dataframe_path = dataframe_path
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        df = _load_dataframe(self.dataframe, self.dataframe_path)
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.update_evaluations(
            space_id=space_id,
            project_name=self.project_name,
            dataframe=df,
        )


class ArizeAxSpansUpdateAnnotationsOperator(BaseOperator):
    """Update annotations for existing spans."""

    template_fields: Sequence[str] = ("space_id", "project_name", "dataframe_path")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        dataframe: Any = None,
        dataframe_path: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.dataframe = dataframe
        self.dataframe_path = dataframe_path
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        df = _load_dataframe(self.dataframe, self.dataframe_path)
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.update_annotations(
            space_id=space_id,
            project_name=self.project_name,
            dataframe=df,
        )


class ArizeAxSpansUpdateMetadataOperator(BaseOperator):
    """Update metadata for existing spans."""

    template_fields: Sequence[str] = ("space_id", "project_name", "dataframe_path")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        dataframe: Any = None,
        dataframe_path: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.dataframe = dataframe
        self.dataframe_path = dataframe_path
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        df = _load_dataframe(self.dataframe, self.dataframe_path)
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.update_metadata(
            space_id=space_id,
            project_name=self.project_name,
            dataframe=df,
        )


class ArizeAxSpansExportToDataframeOperator(BaseOperator):
    """Export spans to a DataFrame (returned via XCom).

    Use ``where`` for full filter control, or pass ``trace_id`` / ``span_id`` /
    ``session_id`` for convenience (same semantics as the arize-trace skill).
    """

    template_fields: Sequence[str] = (
        "space_id",
        "project_name",
        "start_time",
        "end_time",
        "where",
        "trace_id",
        "span_id",
        "session_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        start_time: Any,
        end_time: Any,
        where: str | None = None,
        columns: list[str] | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
        session_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.start_time = start_time
        self.end_time = end_time
        self.where = where
        self.columns = columns
        self.trace_id = trace_id
        self.span_id = span_id
        self.session_id = session_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        return hook.export_spans_to_df(
            space_id=space_id,
            project_name=self.project_name,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
            columns=self.columns,
            trace_id=self.trace_id,
            span_id=self.span_id,
            session_id=self.session_id,
        )


class ArizeAxSpansExportToParquetOperator(BaseOperator):
    """Export spans to a Parquet file.

    Use ``where`` and/or ``trace_id`` / ``span_id`` / ``session_id`` (see
    ArizeAxSpansExportToDataframeOperator).
    """

    template_fields: Sequence[str] = (
        "space_id",
        "project_name",
        "start_time",
        "end_time",
        "path",
        "where",
        "trace_id",
        "span_id",
        "session_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        project_name: str,
        start_time: Any,
        end_time: Any,
        path: str,
        where: str | None = None,
        columns: list[str] | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
        session_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.project_name = project_name
        self.start_time = start_time
        self.end_time = end_time
        self.path = path
        self.where = where
        self.columns = columns
        self.trace_id = trace_id
        self.span_id = span_id
        self.session_id = session_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str | None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        wrote = hook.export_spans_to_parquet(
            space_id=space_id,
            project_name=self.project_name,
            start_time=self.start_time,
            end_time=self.end_time,
            path=self.path,
            where=self.where,
            columns=self.columns,
            trace_id=self.trace_id,
            span_id=self.span_id,
            session_id=self.session_id,
        )
        result_path = self.path if wrote else None
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value={"path": result_path, "wrote": wrote})
        return result_path


# ---------------------------------------------------------------------------
# Fine-tuning export
# ---------------------------------------------------------------------------

class ArizeAxExportSpansToFineTuningOperator(BaseOperator):
    """Export filtered spans as a fine-tuning ready JSONL file.

    Supports two output formats:

    - ``"openai_jsonl"`` (default): Each span row becomes an OpenAI
      ChatCompletion message list
      ``{"messages": [{"role": "system", ...}, {"role": "user", ...},
      {"role": "assistant", ...}]}``.
    - ``"jsonl"``: Raw span row serialized as a JSON object per line.

    Parameters
    ----------
    project_id:
        Base64 Arize project ID.
    output_path:
        File path to write the JSONL file.
    output_format:
        ``"openai_jsonl"`` (default) or ``"jsonl"``.
    where:
        Optional SQL-like span filter (e.g. ``"evals['correctness'].score > 0.8"``).
    start_time / end_time:
        Optional time window for the export.
    input_column:
        Span attribute column to use as the user message.
    output_column:
        Span attribute column to use as the assistant message.
    system_prompt:
        Optional system prompt prepended to every OpenAI example.
    max_examples:
        Cap on the number of examples written.
    arize_ax_conn_id:
        Airflow connection ID.

    Returns via XCom: ``{"path": output_path, "count": int}``.
    """

    template_fields: Sequence[str] = (
        "project_id",
        "output_path",
        "where",
        "start_time",
        "end_time",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        output_path: str,
        output_format: str = "openai_jsonl",
        where: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        input_column: str = "input",
        output_column: str = "output",
        system_prompt: str | None = None,
        max_examples: int | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if output_format not in ("openai_jsonl", "jsonl"):
            raise ValueError(
                f"output_format must be 'openai_jsonl' or 'jsonl'; got {output_format!r}."
            )
        self.project_id = project_id
        self.output_path = output_path
        self.output_format = output_format
        self.where = where
        self.start_time = start_time
        self.end_time = end_time
        self.input_column = input_column
        self.output_column = output_column
        self.system_prompt = system_prompt
        self.max_examples = max_examples
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        if not self.project_id:
            raise AirflowException(
                f"{type(self).__name__} requires project_id. "
                "Set it as a task parameter (base64 Arize project ID), "
                "or use the Airflow Variable 'arize_ax_project_id'."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        rows = hook.export_spans_to_df_by_project_id(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
        )
        if not isinstance(rows, list):
            rows = []

        if self.max_examples is not None:
            rows = rows[: self.max_examples]

        output_path = Path(self.output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        count = 0
        with output_path.open("w", encoding="utf-8") as fh:
            for row in rows:
                if not isinstance(row, dict):
                    continue
                if self.output_format == "openai_jsonl":
                    line = self._to_openai_example(row)
                else:
                    line = row
                fh.write(json.dumps(line, ensure_ascii=False) + "\n")
                count += 1

        log.info("Wrote %d examples to %s (format=%s).", count, self.output_path, self.output_format)
        return {"path": self.output_path, "count": count}

    def _to_openai_example(self, row: dict[str, Any]) -> dict[str, Any]:
        messages: list[dict[str, str]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        user_content = str(row.get(self.input_column) or "")
        assistant_content = str(row.get(self.output_column) or "")
        messages.append({"role": "user", "content": user_content})
        messages.append({"role": "assistant", "content": assistant_content})
        return {"messages": messages}


# ---------------------------------------------------------------------------
# Span metrics aggregation
# ---------------------------------------------------------------------------

# Token column names used by Arize SDK (may vary by version).
_TOKEN_COLUMNS = (
    "llm.token_count.total",
    "attributes.llm.token_count.total",
    "token_count_total",
    "token_count",
    "total_tokens",
)

# Latency/duration column names.
_LATENCY_COLUMNS = (
    "latency_ms",
    "duration_ms",
    "latency",
    "duration",
    "elapsed_ms",
)


def _find_column(row: dict[str, Any], candidates: tuple[str, ...]) -> float | None:
    """Return float value of the first candidate column found in *row*, or None."""
    for col in candidates:
        val = row.get(col)
        if val is not None:
            try:
                return float(val)
            except (TypeError, ValueError):
                pass
    return None


class ArizeAxGetSpanMetricsOperator(BaseOperator):
    """Aggregate span metrics (latency, token usage, cost) over a time window.

    Exports spans via the hook then computes:

    - ``total_spans``
    - ``latency_p50``, ``latency_p95``, ``latency_p99`` (ms)
    - ``total_tokens``, ``avg_tokens_per_span``
    - ``estimated_cost_usd`` (``total_tokens / 1000 * llm_token_cost_per_1k``)

    If no spans are found all numeric fields are ``0`` and a warning is logged.

    Returns the metrics dict via XCom.
    """

    template_fields: Sequence[str] = (
        "project_id",
        "start_time",
        "end_time",
        "where",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        start_time: Any,
        end_time: Any,
        where: str | None = None,
        llm_token_cost_per_1k: float = 0.002,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.start_time = start_time
        self.end_time = end_time
        self.where = where
        self.llm_token_cost_per_1k = llm_token_cost_per_1k
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _to_dt(value: Any) -> datetime | None:
        """Best-effort coerce to aware datetime for pre-flight validation."""
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        if isinstance(value, str):
            try:
                dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
                return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
            except ValueError:
                pass
        return None

    def execute(self, context: Context) -> dict[str, Any]:
        if not self.project_id:
            raise AirflowException(
                f"{type(self).__name__} requires project_id. "
                "Set it as a task parameter (base64 Arize project ID), "
                "or use the Airflow Variable 'arize_ax_project_id'."
            )
        empty: dict[str, Any] = {
            "total_spans": 0,
            "latency_p50": 0.0,
            "latency_p95": 0.0,
            "latency_p99": 0.0,
            "total_tokens": 0.0,
            "avg_tokens_per_span": 0.0,
            "estimated_cost_usd": 0.0,
        }
        # Guard: manual DAG triggers produce data_interval_start == data_interval_end
        # (zero-width interval).  The SDK raises ValueError: start_time must be before
        # end_time rather than returning empty results.
        start_dt = self._to_dt(self.start_time)
        end_dt = self._to_dt(self.end_time)
        if start_dt is not None and end_dt is not None and start_dt >= end_dt:
            log.warning(
                "start_time (%s) >= end_time (%s) — zero-width or inverted window "
                "(common on manual DAG triggers). Returning empty metrics.",
                self.start_time, self.end_time,
            )
            return empty

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        rows = hook.export_spans_to_df_by_project_id(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
        )
        if not isinstance(rows, list):
            rows = []

        total_spans = len(rows)
        if total_spans == 0:
            log.warning(
                "No spans found for project_id=%r in window [%s, %s] (where=%r).",
                self.project_id, self.start_time, self.end_time, self.where,
            )
            return empty

        latencies: list[float] = []
        token_counts: list[float] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            lat = _find_column(row, _LATENCY_COLUMNS)
            if lat is not None:
                latencies.append(lat)
            tok = _find_column(row, _TOKEN_COLUMNS)
            if tok is not None:
                token_counts.append(tok)

        def _percentile(data: list[float], pct: float) -> float:
            if not data:
                return 0.0
            sorted_data = sorted(data)
            idx = (len(sorted_data) - 1) * pct / 100.0
            lower = int(idx)
            upper = lower + 1
            if upper >= len(sorted_data):
                return sorted_data[-1]
            frac = idx - lower
            return sorted_data[lower] * (1.0 - frac) + sorted_data[upper] * frac

        total_tokens = sum(token_counts)
        avg_tokens = total_tokens / len(token_counts) if token_counts else 0.0
        estimated_cost = total_tokens / 1000.0 * self.llm_token_cost_per_1k

        metrics: dict[str, Any] = {
            "total_spans": total_spans,
            "latency_p50": round(_percentile(latencies, 50), 4),
            "latency_p95": round(_percentile(latencies, 95), 4),
            "latency_p99": round(_percentile(latencies, 99), 4),
            "total_tokens": total_tokens,
            "avg_tokens_per_span": round(avg_tokens, 4),
            "estimated_cost_usd": round(estimated_cost, 6),
        }
        log.info("Span metrics for project %r: %s", self.project_id, metrics)
        return metrics


# ---------------------------------------------------------------------------
# Automated dataset curation
# ---------------------------------------------------------------------------

class ArizeAxCurateSpansToDatasetOperator(BaseOperator):
    """Filter, deduplicate, and append high-quality spans to an Arize dataset.

    This is a single-step operator for the common pattern of curating
    production spans into evaluation or fine-tuning datasets.

    Workflow:
    1. Export spans matching ``where`` within the time window.
    2. Optionally deduplicate on ``deduplicate_on`` column.
    3. Optionally cap at ``max_examples``.
    4. Transform to dataset examples and append.

    Returns via XCom::

        {
            "dataset_id": str,
            "appended_count": int,
            "deduplicated_count": int,
        }
    """

    template_fields: Sequence[str] = (
        "project_id",
        "dataset_id",
        "where",
        "start_time",
        "end_time",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        dataset_id: str,
        where: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        max_examples: int | None = None,
        deduplicate_on: str | None = None,
        input_column: str = "input",
        output_column: str = "output",
        metadata_columns: list[str] | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.where = where
        self.start_time = start_time
        self.end_time = end_time
        self.max_examples = max_examples
        self.deduplicate_on = deduplicate_on
        self.input_column = input_column
        self.output_column = output_column
        self.metadata_columns = metadata_columns or []
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        if not self.project_id:
            raise AirflowException(
                f"{type(self).__name__} requires project_id. "
                "Set it as a task parameter (base64 Arize project ID), "
                "or use the Airflow Variable 'arize_ax_project_id'."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        rows = hook.export_spans_to_df_by_project_id(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
        )
        if not isinstance(rows, list):
            rows = []

        # Deduplicate.
        before_dedup = len(rows)
        if self.deduplicate_on:
            seen: set[Any] = set()
            deduped: list[dict[str, Any]] = []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                key = row.get(self.deduplicate_on)
                if key not in seen:
                    seen.add(key)
                    deduped.append(row)
            rows = deduped
        deduplicated_count = before_dedup - len(rows)

        if self.max_examples is not None:
            rows = rows[: self.max_examples]

        if not rows:
            log.info(
                "No spans to curate after filtering/dedup for project_id=%r.",
                self.project_id,
            )
            return {
                "dataset_id": self.dataset_id,
                "appended_count": 0,
                "deduplicated_count": deduplicated_count,
            }

        examples: list[dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            example: dict[str, Any] = {
                "input": row.get(self.input_column, ""),
                "output": row.get(self.output_column, ""),
            }
            if self.metadata_columns:
                example["metadata"] = {
                    col: row.get(col) for col in self.metadata_columns
                }
            examples.append(example)

        if not examples:
            return {
                "dataset_id": self.dataset_id,
                "appended_count": 0,
                "deduplicated_count": deduplicated_count,
            }

        hook.append_dataset_examples(dataset_id=self.dataset_id, examples=examples)
        log.info(
            "Curated %d examples into dataset %r (deduplicated=%d).",
            len(examples), self.dataset_id, deduplicated_count,
        )
        return {
            "dataset_id": self.dataset_id,
            "appended_count": len(examples),
            "deduplicated_count": deduplicated_count,
        }


# ---------------------------------------------------------------------------
# Human-in-the-loop: export annotated spans
# ---------------------------------------------------------------------------

class ArizeAxExportAnnotatedSpansOperator(BaseOperator):
    """Export spans that have human annotations attached.

    Fetches spans via the hook, filters to rows that contain annotation data,
    and writes the result to ``output_path`` (.parquet or .json).

    Optional filters:
    - ``annotation_name``: keep only spans annotated under this label.
    - ``min_annotation_score``: keep only spans where the annotation score
      is >= this threshold.
    - ``where``: additional SQL-like span filter forwarded to the hook.

    Returns via XCom::

        {
            "path": output_path,
            "count": int,
            "annotation_name": annotation_name | None,
        }
    """

    template_fields: Sequence[str] = (
        "project_id",
        "output_path",
        "annotation_name",
        "where",
        "start_time",
        "end_time",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        output_path: str,
        annotation_name: str | None = None,
        min_annotation_score: float | None = None,
        where: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.output_path = output_path
        self.annotation_name = annotation_name
        self.min_annotation_score = min_annotation_score
        self.where = where
        self.start_time = start_time
        self.end_time = end_time
        self.arize_ax_conn_id = arize_ax_conn_id

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _has_annotation(row: dict[str, Any]) -> bool:
        """Return True if *row* contains any annotation-like column."""
        for key in row:
            key_lower = key.lower()
            if "annotation" in key_lower or "human_label" in key_lower:
                if row[key] is not None and row[key] != "":
                    return True
        return False

    @staticmethod
    def _annotation_score(row: dict[str, Any], annotation_name: str | None) -> float | None:
        """Return the annotation score for *row*, optionally for a specific label.

        Looks for column patterns:
        - ``annotations.<name>.score`` / ``annotation.<name>.score``
        - ``annotation_score`` (generic fallback)
        """
        # Try name-specific columns first.
        if annotation_name:
            for prefix in (f"annotations.{annotation_name}", f"annotation.{annotation_name}"):
                score_val = row.get(f"{prefix}.score")
                if score_val is not None:
                    try:
                        return float(score_val)
                    except (TypeError, ValueError):
                        pass
        # Generic fallback.
        for key in ("annotation_score", "human_score", "label_score"):
            val = row.get(key)
            if val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    pass
        return None

    def execute(self, context: Any) -> dict[str, Any]:
        if not self.project_id:
            raise AirflowException(
                f"{type(self).__name__} requires project_id. "
                "Set it as a task parameter (base64 Arize project ID), "
                "or use the Airflow Variable 'arize_ax_project_id'."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        rows = hook.export_spans_to_df_by_project_id(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
        )
        if not isinstance(rows, list):
            rows = []

        # Filter to rows with annotation data.
        annotated: list[dict[str, Any]] = [
            r for r in rows if isinstance(r, dict) and self._has_annotation(r)
        ]

        # Filter by annotation name.
        if self.annotation_name:
            name_lower = self.annotation_name.lower()
            annotated = [
                r for r in annotated
                if any(
                    name_lower in k.lower()
                    for k in r
                    if "annotation" in k.lower() or "human_label" in k.lower()
                )
            ]

        # Filter by minimum annotation score.
        if self.min_annotation_score is not None:
            threshold = float(self.min_annotation_score)
            filtered: list[dict[str, Any]] = []
            for row in annotated:
                score = self._annotation_score(row, self.annotation_name)
                if score is not None and score >= threshold:
                    filtered.append(row)
            annotated = filtered

        count = len(annotated)
        output_path = Path(self.output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if output_path.suffix == ".parquet":
            try:
                import pandas as pd
            except ImportError as exc:
                raise AirflowException(
                    "pandas is required to write .parquet output. "
                    "Install it with: pip install pandas pyarrow"
                ) from exc
            df = pd.DataFrame(annotated) if annotated else pd.DataFrame()
            df.to_parquet(str(output_path), index=False)
        elif output_path.suffix == ".json":
            with output_path.open("w", encoding="utf-8") as fh:
                json.dump(annotated, fh, ensure_ascii=False, default=str)
        else:
            raise AirflowException(
                f"Unsupported output_path extension for {self.output_path!r}. "
                "Use .parquet or .json."
            )

        log.info(
            "Exported %d annotated spans to %s (annotation_name=%r, min_score=%r).",
            count, self.output_path, self.annotation_name, self.min_annotation_score,
        )
        return {
            "path": self.output_path,
            "count": count,
            "annotation_name": self.annotation_name,
        }


# ---------------------------------------------------------------------------
# Feature 4a: Adaptive Sampling
# ---------------------------------------------------------------------------

class ArizeAxAdaptiveSamplingOperator(BaseOperator):
    """Select the highest-value spans for evaluation using uncertainty and novelty signals.

    Prioritises spans that lie near decision boundaries (mid-range eval scores),
    have anomalous output lengths, or represent novel inputs — maximising evaluation
    signal per span evaluated.

    Strategies:
    - ``"uncertainty_first"``: weight = 0.6 * low_score_signal + 0.4 * length_anomaly
    - ``"diversity_first"``: weight = 0.6 * novelty_score + 0.4 * length_anomaly
    - ``"balanced"``: equal weight across all three signals

    Writes selected spans to ``output_path`` as JSONL.

    Returns::

        {
            "selected_count": int,
            "total_candidate_count": int,
            "strategy": str,
            "selection_rate": float,
            "uncertainty_stats": {"mean_priority_score": float, "score_distribution": dict},
            "path": str,
        }
    """

    template_fields: Sequence[str] = (
        "project_id",
        "output_path",
        "start_time",
        "end_time",
        "where",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        output_path: str,
        sample_size: int = 100,
        strategy: str = "uncertainty_first",
        start_time: Any = None,
        end_time: Any = None,
        where: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.output_path = output_path
        self.sample_size = sample_size
        self.strategy = strategy
        self.start_time = start_time
        self.end_time = end_time
        self.where = where
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _extract_span_output(span: dict[str, Any]) -> str:
        for key in ("output", "attributes.output.value", "output.value", "response"):
            val = span.get(key)
            if isinstance(val, str) and val:
                return val
        return ""

    @staticmethod
    def _extract_span_input(span: dict[str, Any]) -> str:
        for key in ("input", "attributes.input.value", "input.value", "query"):
            val = span.get(key)
            if isinstance(val, str) and val:
                return val
        return ""

    @staticmethod
    def _extract_eval_score(span: dict[str, Any]) -> float | None:
        """Find any numeric eval/score field in span."""
        for key, val in span.items():
            if ("score" in key.lower() or "eval" in key.lower()) and val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    pass
        return None

    def execute(self, context: Any) -> dict[str, Any]:
        if not self.project_id:
            raise AirflowException(
                f"{type(self).__name__} requires project_id. "
                "Set it as a task parameter (base64 Arize project ID), "
                "or use the Airflow Variable 'arize_ax_project_id'."
            )
        if self.strategy not in ("uncertainty_first", "diversity_first", "balanced"):
            raise ValueError(
                f"strategy must be 'uncertainty_first', 'diversity_first', or 'balanced'; "
                f"got {self.strategy!r}."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        rows = hook.export_spans_to_df_by_project_id(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            where=self.where,
        )
        if not isinstance(rows, list):
            rows = []

        spans = [r for r in rows if isinstance(r, dict)]
        total = len(spans)
        log.info(
            "AdaptiveSampling: project %s fetched %d spans (strategy=%s, sample_size=%d).",
            self.project_id, total, self.strategy, self.sample_size,
        )

        if not spans:
            out_path = Path(self.output_path)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text("")
            return {
                "selected_count": 0,
                "total_candidate_count": 0,
                "strategy": self.strategy,
                "selection_rate": 0.0,
                "uncertainty_stats": {"mean_priority_score": 0.0, "score_distribution": {}},
                "path": self.output_path,
            }

        # Compute output lengths for anomaly scoring
        output_texts = [self._extract_span_output(s) for s in spans]
        output_lengths = [float(len(t)) for t in output_texts]
        input_texts = [self._extract_span_input(s) for s in spans]

        # z-score anomaly: how far is each output length from the median
        if len(output_lengths) >= 2:
            mean_len = statistics.mean(output_lengths)
            try:
                std_len = statistics.stdev(output_lengths)
            except statistics.StatisticsError:
                std_len = 1.0
            if std_len == 0:
                std_len = 1.0
            length_z = [abs((v - mean_len) / std_len) for v in output_lengths]
            # Normalize to [0, 1] by clamping at 3 std devs
            length_anomaly = [min(1.0, z / 3.0) for z in length_z]
        else:
            length_anomaly = [0.5] * len(spans)

        # Eval score uncertainty: spans near 0.3-0.7 are most uncertain
        eval_scores = [self._extract_eval_score(s) for s in spans]
        low_score_signal: list[float] = []
        for score in eval_scores:
            if score is None:
                low_score_signal.append(0.5)  # unknown = moderate uncertainty
            else:
                # Triangle function peaking at 0.5, 0 at 0 or 1
                low_score_signal.append(1.0 - abs(score - 0.5) * 2.0)

        # Novelty: inputs with rare (first_words, length_bucket) fingerprint
        fp_counts: dict[str, int] = {}
        for inp in input_texts:
            fp = inp[:50].lower().replace(" ", "_") + "|" + (
                "short" if len(inp) < 50 else "medium" if len(inp) < 200 else "long"
            )
            fp_counts[fp] = fp_counts.get(fp, 0) + 1

        total_spans = len(spans)
        novelty_scores: list[float] = []
        for inp in input_texts:
            fp = inp[:50].lower().replace(" ", "_") + "|" + (
                "short" if len(inp) < 50 else "medium" if len(inp) < 200 else "long"
            )
            # Rare fingerprint = higher novelty
            freq = fp_counts.get(fp, 1) / total_spans
            novelty_scores.append(1.0 - freq)

        # Composite priority score
        priority_scores: list[float] = []
        for i in range(total_spans):
            la = length_anomaly[i]
            ls = low_score_signal[i]
            ns = novelty_scores[i]
            if self.strategy == "uncertainty_first":
                score = 0.6 * ls + 0.4 * la
            elif self.strategy == "diversity_first":
                score = 0.6 * ns + 0.4 * la
            else:  # balanced
                score = (la + ls + ns) / 3.0
            priority_scores.append(score)

        # Sort by priority descending, take top sample_size
        indexed = sorted(enumerate(spans), key=lambda t: priority_scores[t[0]], reverse=True)
        selected = [span for _, span in indexed[: self.sample_size]]

        # Write to JSONL
        out_path = Path(self.output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as fh:
            for span in selected:
                fh.write(json.dumps(span, ensure_ascii=False, default=str) + "\n")

        selected_count = len(selected)
        top_priority = [priority_scores[idx] for idx, _ in indexed[: self.sample_size]]
        mean_priority = statistics.mean(top_priority) if top_priority else 0.0

        # Score distribution buckets
        all_priorities = sorted(priority_scores)
        n = len(all_priorities)
        score_dist: dict[str, float] = {}
        if n:
            score_dist = {
                "p25": all_priorities[max(0, int(n * 0.25))],
                "p50": all_priorities[max(0, int(n * 0.50))],
                "p75": all_priorities[max(0, int(n * 0.75))],
                "p90": all_priorities[max(0, int(n * 0.90))],
            }

        log.info(
            "AdaptiveSampling: selected %d/%d spans (strategy=%s, mean_priority=%.4f).",
            selected_count, total, self.strategy, mean_priority,
        )
        return {
            "selected_count": selected_count,
            "total_candidate_count": total,
            "strategy": self.strategy,
            "selection_rate": round(selected_count / total, 4) if total else 0.0,
            "uncertainty_stats": {
                "mean_priority_score": round(mean_priority, 4),
                "score_distribution": {k: round(v, 4) for k, v in score_dist.items()},
            },
            "path": self.output_path,
        }


# ---------------------------------------------------------------------------
# Self-learning agent curation: extract prompt-optimization datasets from
# OpenInference-instrumented LLM spans. Framework-agnostic — reads OpenInference
# standard fields only (llm.input_messages, llm.output_messages, row-level
# evaluations / annotations). Pairs with ArizeAxOptimizePromptOperator.
# ---------------------------------------------------------------------------


def _oi_strip_attr_prefix(key: str) -> str:
    """Strip a leading ``attributes.`` prefix that spans.list adds to every key."""
    return key[len("attributes.") :] if key.startswith("attributes.") else key


def _oi_flatten_attrs(attrs: Any) -> dict[str, Any]:
    """Return span attributes as a flat ``key.path -> value`` dict.

    ``spans.list`` already emits attributes as a flat dict keyed by
    ``attributes.<path>``. Strip that prefix so callers can look up
    ``openinference.span.kind`` directly.
    """
    if not isinstance(attrs, dict):
        return {}
    return {_oi_strip_attr_prefix(k): v for k, v in attrs.items()}


def _oi_extract_message_role_content(msg: Any) -> tuple[str | None, str | None]:
    """Return (role, content) from an OpenInference message dict.

    The OpenInference spec emits messages as flat dotted keys
    (``message.role`` / ``message.content``). Some instrumentations use the
    nested form (``{"role": "...", "content": "..."}``); both are handled.
    """
    if not isinstance(msg, dict):
        return None, None
    role = msg.get("message.role") or msg.get("role")
    content = msg.get("message.content") or msg.get("content")
    if isinstance(role, str):
        role = role.strip().lower() or None
    if content is None:
        return role, None
    if isinstance(content, (dict, list)):
        try:
            content = json.dumps(content)
        except (TypeError, ValueError):
            content = str(content)
    return role, str(content)


def _oi_messages_text(messages: Any, role_filter: str | None) -> str | None:
    """Concatenate content from OpenInference messages, optionally filtered by role."""
    if not isinstance(messages, list):
        return None
    parts: list[str] = []
    for m in messages:
        role, content = _oi_extract_message_role_content(m)
        if role_filter is not None and role != role_filter:
            continue
        if content and content.strip():
            parts.append(content.strip())
    return "\n\n".join(parts) if parts else None


def _oi_extract_feedback(row: dict[str, Any]) -> dict[str, Any]:
    """Read row-level ``evaluations`` and ``annotations`` lists into a flat feedback dict.

    Arize's spans.list emits feedback at the row level (sibling to ``attributes``)
    as lists of ``{"name", "score", "label", "explanation", ...}`` dicts.
    """
    out: dict[str, dict[str, Any]] = {}
    for source, prefix in ((row.get("evaluations"), "eval"), (row.get("annotations"), "annotation")):
        if not isinstance(source, list):
            continue
        for entry in source:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name") or entry.get("evaluator_name")
            if not name:
                continue
            out.setdefault(prefix, {})
            slot = out[prefix].setdefault(str(name), {})
            for field in ("label", "score", "explanation", "text"):
                if entry.get(field) is not None and field not in slot:
                    slot[field] = entry[field]
    return out


def _oi_feedback_to_text(feedback: dict[str, Any]) -> str:
    """Serialize the feedback dict into a single natural-language string."""
    parts: list[str] = []
    for name, data in (feedback.get("eval") or {}).items():
        if isinstance(data, dict):
            parts.append(
                f"Eval {name}: label={data.get('label')}, score={data.get('score')}; "
                f"{data.get('explanation') or ''}".strip()
            )
    for name, data in (feedback.get("annotation") or {}).items():
        if isinstance(data, dict):
            parts.append(
                f"Annotation {name}: label={data.get('label')}, score={data.get('score')}; "
                f"{data.get('text') or ''}".strip()
            )
    return " ".join(parts).strip() or json.dumps(feedback)


def _oi_group_key(attrs: dict[str, Any], system_prompt: str, group_by_metadata_key: str | None) -> str:
    """Compute a stable group key for a span.

    If ``group_by_metadata_key`` is set, look up ``metadata.<key>`` in the
    flat attributes. Otherwise, fingerprint the system prompt so spans with
    the same prompt text land in the same group.
    """
    if group_by_metadata_key:
        candidate = attrs.get(f"metadata.{group_by_metadata_key}")
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip().lower().replace(" ", "_")
    normalized = " ".join(system_prompt.split())[:500]
    return "prompt_" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]


class ArizeAxCurateFeedbackDatasetOperator(BaseOperator):
    """Curate per-prompt feedback datasets from OpenInference-instrumented LLM spans.

    Fetches LLM spans from a project, groups them by system prompt (or by a
    user-supplied metadata key), and emits a list of dataset records ready
    for ``ArizeAxOptimizePromptOperator.partial().expand_kwargs(...)``.

    Read fields (OpenInference standard, framework-agnostic):
        - ``openinference.span.kind`` to filter (server-side).
        - ``llm.input_messages`` to extract the system prompt (role=='system'
          content concatenated) and a representative user/assistant input.
        - ``llm.output_messages`` for the assistant output.
        - Row-level ``evaluations`` and ``annotations`` lists for feedback.

    Returns:
        ``list[{prompt, dataset, group_key}]`` — one item per prompt group.
        Each ``dataset`` is a ``list[{input, output, feedback}]`` ready for
        ``ArizeAxOptimizePromptOperator``. Pushed as the default XCom value
        so a downstream task can call::

            optimize = ArizeAxOptimizePromptOperator.partial(...).expand_kwargs(
                curate.output
            )

    The operator returns an empty list (and short-circuits cleanly via the
    ``ShortCircuitOperator`` convention) when no spans have feedback +
    system prompts, unless ``fail_on_empty=True`` is set.
    """

    template_fields: Sequence[str] = (
        "project_id",
        "space_id",
        "start_time",
        "end_time",
        "where",
        "group_by_metadata_key",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str | None = None,
        space_id: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        where: str | None = None,
        limit: int = 200,
        group_by_metadata_key: str | None = None,
        min_records_per_group: int = 1,
        max_groups: int | None = None,
        fail_on_empty: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.space_id = space_id
        self.start_time = start_time
        self.end_time = end_time
        self.where = where
        self.limit = limit
        self.group_by_metadata_key = group_by_metadata_key
        self.min_records_per_group = max(1, int(min_records_per_group))
        self.max_groups = max_groups
        self.fail_on_empty = fail_on_empty
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> list[dict[str, Any]]:
        if not self.project_id:
            raise AirflowException(
                "ArizeAxCurateFeedbackDatasetOperator: 'project_id' is required."
            )

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        # Default 30-day lookback when start_time isn't given so a freshly
        # configured DAG with no explicit window still finds production data.
        start_time = self.start_time if self.start_time is not None else (
            datetime.now(timezone.utc) - timedelta(days=30)
        )
        end_time = self.end_time if self.end_time is not None else datetime.now(timezone.utc)

        # Combine the user filter with the LLM-kind narrowing.
        kind_filter = "attributes.openinference.span.kind = 'LLM'"
        effective_where = (
            f"({self.where}) AND {kind_filter}" if self.where else kind_filter
        )

        result = hook.list_spans(
            project_id=self.project_id,
            space_id=self.space_id,
            start_time=start_time,
            end_time=end_time,
            filter=effective_where,
            limit=self.limit,
        )
        rows = (result or {}).get("items") or []
        log.info(
            "ArizeAxCurateFeedbackDatasetOperator: fetched %d LLM spans from project_id=%s",
            len(rows), self.project_id,
        )

        groups: dict[str, dict[str, Any]] = {}
        skipped_no_feedback = 0
        skipped_no_system = 0

        for row in rows:
            attrs = _oi_flatten_attrs(row.get("attributes") or {})

            feedback = _oi_extract_feedback(row)
            if not feedback:
                skipped_no_feedback += 1
                continue

            input_messages = attrs.get("llm.input_messages")
            system_prompt = _oi_messages_text(input_messages, role_filter="system")
            if not system_prompt:
                skipped_no_system += 1
                continue

            # User/assistant content (best-effort input record for the optimizer).
            user_input = _oi_messages_text(input_messages, role_filter="user")
            if not user_input:
                # Fallback: input.value (raw string, common for non-chat LLMs).
                iv = attrs.get("input.value")
                if isinstance(iv, str):
                    user_input = iv

            output_messages = attrs.get("llm.output_messages")
            output_text = _oi_messages_text(output_messages, role_filter=None)
            if not output_text:
                ov = attrs.get("output.value")
                if isinstance(ov, str):
                    output_text = ov

            key = _oi_group_key(attrs, system_prompt, self.group_by_metadata_key)
            bucket = groups.setdefault(key, {"prompt": system_prompt, "records": []})
            bucket["records"].append({
                "input": user_input or "",
                "output": output_text or "",
                "feedback": _oi_feedback_to_text(feedback),
            })

        # Apply min-records-per-group filter and max_groups cap.
        eligible = [
            (k, v) for k, v in groups.items()
            if len(v["records"]) >= self.min_records_per_group
        ]
        # Sort by record count desc so the biggest groups optimize first.
        eligible.sort(key=lambda kv: -len(kv[1]["records"]))
        if self.max_groups is not None and self.max_groups > 0:
            eligible = eligible[: self.max_groups]

        out: list[dict[str, Any]] = [
            {
                "prompt": v["prompt"],
                "dataset": v["records"],
                "group_key": k,
            }
            for k, v in eligible
        ]

        log.info(
            "ArizeAxCurateFeedbackDatasetOperator: %d eligible groups "
            "(skipped: no_feedback=%d, no_system_prompt=%d). Groups: %s",
            len(out), skipped_no_feedback, skipped_no_system,
            [f"{g['group_key']}({len(g['dataset'])})" for g in out],
        )

        if not out and self.fail_on_empty:
            raise AirflowException(
                "ArizeAxCurateFeedbackDatasetOperator: no prompt groups found. "
                f"Span rows={len(rows)}, skipped_no_feedback={skipped_no_feedback}, "
                f"skipped_no_system={skipped_no_system}."
            )

        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(
                key="stats",
                value={
                    "spans_total": len(rows),
                    "groups_eligible": len(out),
                    "skipped_no_feedback": skipped_no_feedback,
                    "skipped_no_system_prompt": skipped_no_system,
                },
            )
        return out
