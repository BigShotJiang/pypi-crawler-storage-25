"""Arize AX Evaluators operators.

Supports both template (LLM-as-judge) and code (managed/custom) evaluators via
SDK methods introduced in arize 8.23.0.

Evaluator ``template`` strings must use **f-string** placeholders (e.g. ``{input}``,
``{output}``), not ``{{input}}`` (the API validates this).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator

try:
    from airflow.sdk.exceptions import AirflowFailException
except ImportError:
    from airflow.exceptions import AirflowFailException
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.utils import (
    is_conflict,
    is_not_found,
    push_first_xcom_keys,
)

if TYPE_CHECKING:  # pragma: no cover
    from airflow.utils.context import Context


def _resolve_template_config_dict(
    *,
    context: Context,
    template_config: dict[str, Any] | None,
    template_config_task_id: str | None,
    template_config_key: str,
) -> dict[str, Any]:
    """Return template_config from static operator args or upstream XCom."""
    if template_config_task_id:
        ti = context["ti"]
        payload = ti.xcom_pull(task_ids=template_config_task_id) or {}
        if not isinstance(payload, dict):
            raise AirflowFailException(
                f"XCom from {template_config_task_id!r} must be a dict, got {type(payload).__name__}."
            )
        if template_config_key in payload:
            cfg = payload[template_config_key]
        else:
            cfg = payload
        if not isinstance(cfg, dict) or not cfg:
            raise AirflowFailException(
                f"Could not resolve template_config from task {template_config_task_id!r} "
                f"(expected key {template_config_key!r} or a mapping template_config)."
            )
        return cfg
    if template_config is None:
        raise AirflowFailException("template_config is required when template_config_task_id is not set.")
    return template_config


class ArizeAxListEvaluatorsOperator(BaseOperator):
    """List LLM template evaluators in Arize AX (Eval Hub), optionally scoped to a space."""

    template_fields: Sequence[str] = ("space_id", "cursor", "name_search")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        name_search: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.limit = limit
        self.cursor = cursor
        self.name_search = name_search
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = self.space_id or hook.default_space
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        result = hook.list_evaluators(
            space_id=space_id,
            limit=self.limit,
            cursor=self.cursor,
            name_search=self.name_search,
        )
        ti = context.get("ti")
        if ti is not None:
            items = result.get("items", []) if isinstance(result, dict) else []
            if items and isinstance(items[0], dict):
                ti.xcom_push(key="first_id", value=str(items[0].get("id", "")))
                ti.xcom_push(key="first_name", value=str(items[0].get("name", "")))
        return result


class ArizeAxCreateEvaluatorOperator(BaseOperator):
    """Create a template or code evaluator with an initial version in Arize AX.

    For template (LLM-as-judge) evaluators, pass ``template_config`` as a dict
    (``name``, ``template``, ``llm_config``, etc.), or set ``template_config_task_id``
    to load it from XCom (e.g. after a prompt-optimization task).

    For code evaluators (``evaluator_type="code"``), pass ``code_config`` as a
    ``CodeConfig`` instance wrapping ``ManagedCodeConfig`` or ``CustomCodeConfig``.

    Set ``if_exists="skip"`` for idempotent behaviour: if the evaluator name
    already exists (HTTP 409), the operator looks up the existing evaluator and
    returns its ID so that downstream tasks continue to work.
    Default is ``"fail"`` (raise on conflict).
    """

    template_fields: Sequence[str] = (
        "space_id",
        "name",
        "description",
        "commit_message",
        "evaluator_type",
        "if_exists",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        name: str,
        commit_message: str,
        evaluator_type: str = "template",
        template_config: dict[str, Any] | None = None,
        code_config: Any | None = None,
        description: str | None = None,
        if_exists: str = "fail",
        template_config_task_id: str | None = None,
        template_config_key: str = "template_config",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.name = name
        self.commit_message = commit_message
        self.evaluator_type = evaluator_type
        self.template_config = template_config
        self.code_config = code_config
        self.description = description
        self.if_exists = if_exists
        self.template_config_task_id = template_config_task_id
        self.template_config_key = template_config_key
        self.arize_ax_conn_id = arize_ax_conn_id
        if evaluator_type == "template" and not template_config_task_id and not template_config:
            raise ValueError("Provide either template_config or template_config_task_id.")
        if evaluator_type == "code" and code_config is None:
            raise AirflowException(
                "code_config is required when evaluator_type='code'."
            )

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        if self.evaluator_type == "template":
            cfg = _resolve_template_config_dict(
                context=context,
                template_config=self.template_config,
                template_config_task_id=self.template_config_task_id,
                template_config_key=self.template_config_key,
            )
            create_kwargs: dict[str, Any] = {
                "space_id": space_id,
                "name": self.name,
                "evaluator_type": self.evaluator_type,
                "commit_message": self.commit_message,
                "template_config": cfg,
                "description": self.description,
            }
        else:
            create_kwargs = {
                "space_id": space_id,
                "name": self.name,
                "evaluator_type": self.evaluator_type,
                "commit_message": self.commit_message,
                "code_config": self.code_config,
                "description": self.description,
            }
        try:
            result = hook.create_evaluator(**create_kwargs)
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "Evaluator '%s' already exists in space '%s' -- returning existing ID.",
                    self.name, space_id,
                )
                existing = hook.list_evaluators(
                    space_id=space_id,
                    name_search=self.name,
                )
                for item in existing.get("items", []):
                    if isinstance(item, dict) and item.get("name") == self.name:
                        existing_id = str(item["id"])
                        self.log.info("Resolved existing evaluator ID: %s", existing_id)
                        return existing_id
                raise AirflowException(
                    f"Evaluator '{self.name}' conflicts but could not be found via "
                    f"list API in space '{space_id}'."
                ) from exc
            raise
        evaluator_id = result.get("id") if isinstance(result, dict) else None
        if evaluator_id is None:
            raise AirflowFailException(
                "create_evaluator returned no id in the response."
            )
        return str(evaluator_id)


class ArizeAxUpdateEvaluatorOperator(BaseOperator):
    """Update evaluator metadata (name and/or description) via PATCH.

    This does **not** change the judge template; use
    :class:`ArizeAxAddEvaluatorVersionOperator` for a new prompt version.
    """

    template_fields: Sequence[str] = ("evaluator_id", "name", "description")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        evaluator_id: str,
        name: str | None = None,
        description: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.evaluator_id = evaluator_id
        self.name = name
        self.description = description
        self.arize_ax_conn_id = arize_ax_conn_id
        if name is None and description is None:
            raise ValueError("Provide at least one of name or description.")

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.update_evaluator(
            self.evaluator_id,
            name=self.name,
            description=self.description,
        )


class ArizeAxAddEvaluatorVersionOperator(BaseOperator):
    """Append a new version to an existing evaluator.

    Supports both template (``version_type="template"``, the default) and code
    (``version_type="code"``) versions. For template versions, pass
    ``template_config`` or set ``template_config_task_id``. For code versions,
    pass ``code_config``.
    """

    template_fields: Sequence[str] = ("evaluator_id", "commit_message", "version_type")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        evaluator_id: str,
        commit_message: str,
        version_type: str = "template",
        template_config: dict[str, Any] | None = None,
        code_config: Any | None = None,
        template_config_task_id: str | None = None,
        template_config_key: str = "template_config",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.evaluator_id = evaluator_id
        self.commit_message = commit_message
        self.version_type = version_type
        self.template_config = template_config
        self.code_config = code_config
        self.template_config_task_id = template_config_task_id
        self.template_config_key = template_config_key
        self.arize_ax_conn_id = arize_ax_conn_id
        if version_type == "template" and not template_config_task_id and not template_config:
            raise ValueError("Provide either template_config or template_config_task_id.")
        if version_type == "code" and code_config is None:
            raise AirflowException(
                "code_config is required when version_type='code'."
            )

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        if self.version_type == "template":
            cfg = _resolve_template_config_dict(
                context=context,
                template_config=self.template_config,
                template_config_task_id=self.template_config_task_id,
                template_config_key=self.template_config_key,
            )
            return hook.add_evaluator_version(
                self.evaluator_id,
                commit_message=self.commit_message,
                version_type="template",
                template_config=cfg,
            )
        else:
            return hook.add_evaluator_version(
                self.evaluator_id,
                commit_message=self.commit_message,
                version_type=self.version_type,
                code_config=self.code_config,
            )


class ArizeAxGetEvaluatorOperator(BaseOperator):
    """Get an evaluator by ID via the Arize SDK (``client.evaluators.get``).

    Returns the evaluator object serialized as a dict via XCom.
    """

    template_fields: Sequence[str] = ("evaluator_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        evaluator_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.evaluator_id = evaluator_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_evaluator(evaluator_id=self.evaluator_id)


class ArizeAxDeleteEvaluatorOperator(BaseOperator):
    """Delete an evaluator by ID via the Arize SDK (``client.evaluators.delete``).

    Returns ``None`` on success.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("evaluator_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        evaluator_id: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.evaluator_id = evaluator_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_evaluator(evaluator_id=self.evaluator_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Evaluator %r not found — skipping delete (ignore_if_missing=True).",
                    self.evaluator_id,
                )
                return
            raise


class ArizeAxListEvaluatorVersionsOperator(BaseOperator):
    """List all versions of an evaluator via the Arize SDK (``client.evaluators.list_versions``).

    Returns a structured list dict (``items``, ``next_cursor``, ``count``) via XCom.
    """

    template_fields: Sequence[str] = ("evaluator_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        evaluator_id: str,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.evaluator_id = evaluator_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_evaluator_versions(
            evaluator_id=self.evaluator_id,
            limit=self.limit,
            cursor=self.cursor,
        )
        push_first_xcom_keys(context, result)
        return result


class ArizeAxGetEvaluatorVersionOperator(BaseOperator):
    """Get a specific evaluator version by version ID via the Arize SDK
    (``client.evaluators.get_version``).

    Returns the evaluator version object serialized as a dict via XCom.
    """

    template_fields: Sequence[str] = ("version_id",)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        version_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.version_id = version_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_evaluator_version(version_id=self.version_id)
