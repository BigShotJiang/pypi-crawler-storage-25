"""Arize AX Dataset operators."""

from __future__ import annotations

import hashlib
import logging
import statistics
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.links.arize_ax import ArizeAxDatasetLink
from airflow.providers.arize_ax.operators.utils import (
    find_resource_by_name,
    is_conflict,
    is_not_found,
    push_first_xcom_keys,
)

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


class ArizeAxListDatasetsOperator(BaseOperator):
    """List datasets in a space."""

    template_fields: Sequence[str] = ("space_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        result = hook.list_datasets(space_id=space_id, limit=self.limit, cursor=self.cursor)
        ti = context.get("ti")
        if ti is not None:
            items = result.get("items", []) if isinstance(result, dict) else []
            if items and isinstance(items[0], dict):
                ti.xcom_push(key="first_id", value=str(items[0].get("id", "")))
                ti.xcom_push(key="first_name", value=str(items[0].get("name", "")))
        return result


class ArizeAxCreateDatasetOperator(BaseOperator):
    """Create a dataset with examples.

    Set ``if_exists="skip"`` for idempotent behaviour: if the dataset name
    already exists (HTTP 409), the operator looks up the existing dataset and
    returns its ID so that downstream tasks continue to work.
    Default is ``"fail"`` (raise on conflict).
    """

    template_fields: Sequence[str] = ("space_id", "name")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        name: str,
        examples: list[dict[str, Any]] | None = None,
        examples_path: str | None = None,
        if_exists: str = "fail",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.name = name
        self.examples = examples or []
        self.examples_path = examples_path
        self.if_exists = if_exists
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        import json
        if self.examples_path:
            with open(self.examples_path) as f:
                content = f.read().strip()
                if self.examples_path.endswith(".json"):
                    examples = json.loads(content)
                else:
                    import pandas as pd
                    examples = pd.read_csv(self.examples_path).to_dict(orient="records")
        else:
            examples = self.examples
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        try:
            dataset = hook.create_dataset(
                space_id=space_id, name=self.name, examples=examples,
            )
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "Dataset '%s' already exists in space '%s' -- returning existing ID.",
                    self.name, space_id,
                )
                existing_id = find_resource_by_name(
                    hook,
                    "list_datasets",
                    self.name,
                    space_id=space_id,
                )
                if existing_id:
                    self.log.info("Resolved existing dataset ID: %s", existing_id)
                    return existing_id
                raise AirflowException(
                    f"Dataset '{self.name}' conflicts but could not be found via "
                    f"list API in space '{space_id}'."
                ) from exc
            raise
        if isinstance(dataset, dict):
            return str(dataset.get("id", dataset))
        return str(getattr(dataset, "id", dataset))


class ArizeAxGetDatasetOperator(BaseOperator):
    """Get a dataset by ID."""

    template_fields: Sequence[str] = ("dataset_id",)
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_dataset(dataset_id=self.dataset_id)


class ArizeAxDeleteDatasetOperator(BaseOperator):
    """Delete a dataset by ID.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("dataset_id",)
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_dataset(dataset_id=self.dataset_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Dataset %r not found — skipping delete (ignore_if_missing=True).",
                    self.dataset_id,
                )
                return
            raise


class ArizeAxListDatasetExamplesOperator(BaseOperator):
    """List examples in a dataset, optionally targeting a specific version."""

    template_fields: Sequence[str] = ("dataset_id", "dataset_version_id")
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        limit: int = 100,
        dataset_version_id: str | None = None,
        all: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.limit = limit
        self.dataset_version_id = dataset_version_id
        self.all = all
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_dataset_examples(
            dataset_id=self.dataset_id,
            limit=self.limit,
            dataset_version_id=self.dataset_version_id,
            all=self.all,
        )
        push_first_xcom_keys(context, result)
        return result


class ArizeAxAppendDatasetExamplesOperator(BaseOperator):
    """Append examples to a dataset, optionally targeting a specific version.

    Pair with ``render_template_as_native_obj=True`` on the DAG when passing
    ``examples`` via Jinja (e.g. ``"{{ ti.xcom_pull(...) }}"``) so the
    rendered value reaches the SDK as a native list, not a string.
    """

    template_fields: Sequence[str] = ("dataset_id", "dataset_version_id", "examples")
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        examples: list[dict[str, Any]] | None = None,
        examples_path: str | None = None,
        dataset_version_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.examples = examples or []
        self.examples_path = examples_path
        self.dataset_version_id = dataset_version_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        import json
        if self.examples_path:
            with open(self.examples_path) as f:
                content = f.read().strip()
                if self.examples_path.endswith(".json"):
                    examples = json.loads(content)
                else:
                    import pandas as pd
                    examples = pd.read_csv(self.examples_path).to_dict(orient="records")
        else:
            examples = self.examples
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.append_dataset_examples(
            dataset_id=self.dataset_id,
            examples=examples,
            dataset_version_id=self.dataset_version_id,
        )


class ArizeAxExportDatasetExamplesToFileOperator(BaseOperator):
    """Export all dataset examples to a JSON file (one array of objects).

    Uses the SDK's Flight-backed all=True mode for efficient bulk export.
    """

    template_fields: Sequence[str] = ("dataset_id", "path", "dataset_version_id")
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        path: str,
        dataset_version_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.path = path
        self.dataset_version_id = dataset_version_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> int:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.export_dataset_examples_to_file(
            dataset_id=self.dataset_id,
            path=self.path,
            dataset_version_id=self.dataset_version_id,
        )


class ArizeAxAnnotateDatasetExamplesOperator(BaseOperator):
    """Batch human annotations onto dataset examples (HITL).

    Upsert semantics: submitting the same annotation config name for the same
    example overwrites the previous value, making this safe to retry.

    Params:
        dataset_id: Dataset name or ID.
        annotations: List of annotation dicts, each with ``record_id`` (example ID)
            and ``values`` (list of dicts with ``name`` and optionally ``score``,
            ``label``, ``text``).  Up to 500 entries per request.
        space_id: Space name or ID (optional).
    """

    # ``annotations`` is templated so Jinja inside nested record_id / name /
    # label strings (e.g. config names that include {{ ts_nodash }}) renders
    # before the API is called. Airflow recursively renders lists of dicts.
    template_fields: Sequence[str] = ("dataset_id", "annotations", "space_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        annotations: list[dict[str, Any]],
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.annotations = annotations
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        if not self.annotations:
            raise AirflowException(
                f"{type(self).__name__}: annotations list must not be empty."
            )
        if len(self.annotations) > 500:
            raise AirflowException(
                f"{type(self).__name__}: annotations list exceeds the 500-entry limit "
                f"(got {len(self.annotations)})."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.annotate_dataset_examples(
            dataset_id=self.dataset_id,
            annotations=self.annotations,
            space=self.space_id,
        )
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        return result


# ---------------------------------------------------------------------------
# Feature 2a: Eval Dataset Health
# ---------------------------------------------------------------------------

def _input_text(example: dict[str, Any], input_column: str = "input") -> str:
    """Extract the input text from a dataset example dict."""
    val = example.get(input_column) or example.get("query") or example.get("text") or ""
    return str(val)


def _first_words(text: str, n: int = 5) -> str:
    """Return first n words of text, lowercased."""
    return " ".join(text.lower().split()[:n])


def _length_bucket(length: int) -> str:
    if length < 50:
        return "short"
    if length < 200:
        return "medium"
    if length < 500:
        return "long"
    return "very_long"


class ArizeAxEvalDatasetHealthOperator(BaseOperator):
    """Score an evaluation dataset on freshness, diversity, and coverage.

    Compares the dataset to recent production spans to detect staleness and
    coverage gaps.  Uses only statistical heuristics (length buckets, word
    distributions) — no embedding models required.

    Returns::

        {
            "dataset_id": str,
            "example_count": int,
            "freshness_score": float,   # 0-1
            "diversity_score": float,   # 0-1
            "size_score": float,        # 0-1
            "overall_health": float,    # 0-1
            "health_grade": "healthy" | "needs_refresh" | "stale",
            "coverage_gaps": [str],
            "production_span_count": int,
            "recommendation": str,
        }
    """

    template_fields: Sequence[str] = (
        "dataset_id",
        "project_id",
        "start_time",
        "end_time",
        "arize_ax_conn_id",
    )
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        project_id: str,
        start_time: Any = None,
        end_time: Any = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.project_id = project_id
        self.start_time = start_time
        self.end_time = end_time
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Any) -> dict[str, Any]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        # Fetch dataset examples
        examples_resp = hook.list_dataset_examples(dataset_id=self.dataset_id, all=True)
        examples = examples_resp.get("items") or []
        example_count = len(examples)

        self.log.info(
            "EvalDatasetHealth: dataset %s has %d examples.", self.dataset_id, example_count,
        )

        # Fetch production spans
        prod_spans: list[dict[str, Any]] = []
        try:
            rows = hook.export_spans_to_df_by_project_id(
                project_id=self.project_id,
                start_time=self.start_time,
                end_time=self.end_time,
            )
            prod_spans = rows if isinstance(rows, list) else []
        except Exception as exc:
            self.log.warning("Could not fetch production spans: %s", exc)

        production_span_count = len(prod_spans)

        # --- Size score ---
        if example_count < 50:
            size_score = 0.3
        elif example_count < 200:
            size_score = 0.7
        else:
            size_score = 1.0

        coverage_gaps: list[str] = []

        # --- Diversity score: coefficient of variation of input lengths ---
        input_lengths = [len(_input_text(ex)) for ex in examples if isinstance(ex, dict)]
        if len(input_lengths) >= 2:
            mean_len = statistics.mean(input_lengths)
            std_len = statistics.stdev(input_lengths)
            cv = std_len / mean_len if mean_len > 0 else 0.0
            # CV > 0.5 is healthy diversity; cap at 1.0
            diversity_score = min(1.0, cv / 0.5)

            # Find under-represented length buckets
            bucket_counts: dict[str, int] = {"short": 0, "medium": 0, "long": 0, "very_long": 0}
            for ln in input_lengths:
                bucket_counts[_length_bucket(ln)] += 1
            total_ex = len(input_lengths)
            for bucket, count in bucket_counts.items():
                pct = count / total_ex
                if pct < 0.05 and total_ex >= 20:
                    gap_desc = {
                        "short": "very short inputs (<50 chars) are underrepresented",
                        "medium": "medium-length inputs (50-200 chars) are underrepresented",
                        "long": "long inputs (200-500 chars) are underrepresented",
                        "very_long": "no examples with inputs > 500 chars",
                    }[bucket]
                    coverage_gaps.append(gap_desc)
        else:
            diversity_score = 0.0
            coverage_gaps.append("dataset has fewer than 2 examples; diversity cannot be computed")

        # --- Freshness score: % of production spans NOT represented in dataset ---
        # An empty dataset cannot be considered fresh.
        freshness_score = 0.0 if not examples else 1.0
        if prod_spans and examples:
            # Build a simple novelty fingerprint set from the dataset
            dataset_fingerprints: set[str] = set()
            for ex in examples:
                if not isinstance(ex, dict):
                    continue
                text = _input_text(ex)
                fp = _first_words(text, 5) + "|" + _length_bucket(len(text))
                dataset_fingerprints.add(fp)

            novel_count = 0
            for span in prod_spans:
                if not isinstance(span, dict):
                    continue
                inp = str(span.get("input") or span.get("attributes.input.value") or span.get("input.value") or "")
                fp = _first_words(inp, 5) + "|" + _length_bucket(len(inp))
                if fp not in dataset_fingerprints:
                    novel_count += 1
            freshness_score = novel_count / production_span_count if production_span_count > 0 else 1.0

            if freshness_score < 0.2:
                coverage_gaps.append(
                    f"most production inputs ({(1-freshness_score)*100:.0f}%) are already represented "
                    "in the eval set — data is relatively fresh"
                )
        elif not prod_spans:
            coverage_gaps.append("no production spans available for freshness comparison")

        # --- Overall health: weighted average ---
        overall_health = round(
            0.4 * freshness_score + 0.3 * diversity_score + 0.3 * size_score, 4
        )

        if overall_health >= 0.7:
            health_grade = "healthy"
            recommendation = (
                f"Dataset {self.dataset_id} is healthy (score={overall_health:.3f}). "
                "No immediate refresh needed."
            )
        elif overall_health >= 0.4:
            health_grade = "needs_refresh"
            recommendation = (
                f"Dataset {self.dataset_id} needs a refresh (score={overall_health:.3f}). "
                "Consider adding diverse examples from recent production traffic."
            )
        else:
            health_grade = "stale"
            recommendation = (
                f"Dataset {self.dataset_id} is stale (score={overall_health:.3f}). "
                "Significant refresh needed — run ArizeAxSmartDatasetRefreshOperator."
            )

        if coverage_gaps:
            recommendation += " Coverage gaps: " + "; ".join(coverage_gaps) + "."

        result = {
            "dataset_id": self.dataset_id,
            "example_count": example_count,
            "freshness_score": round(freshness_score, 4),
            "diversity_score": round(diversity_score, 4),
            "size_score": round(size_score, 4),
            "overall_health": overall_health,
            "health_grade": health_grade,
            "coverage_gaps": coverage_gaps,
            "production_span_count": production_span_count,
            "recommendation": recommendation,
        }
        self.log.info(
            "EvalDatasetHealth: dataset=%s, grade=%s, overall=%.4f",
            self.dataset_id, health_grade, overall_health,
        )
        return result


# ---------------------------------------------------------------------------
# Feature 2b: Smart Dataset Refresh
# ---------------------------------------------------------------------------

class ArizeAxSmartDatasetRefreshOperator(BaseOperator):
    """Evolve an evaluation dataset by adding diverse, high-value production examples.

    Exports recent production spans, filters out examples already represented
    in the dataset (by input fingerprint), and appends up to ``max_new_examples``
    diverse, novel spans.

    Supports two diversity strategies:
    - ``"length_bucket"``: ensure coverage across short/medium/long/very_long inputs
      by sampling proportionally from each bucket.
    - ``"random"``: take the top-N novel spans without length-bucket balancing.

    Returns::

        {
            "added_count": int,
            "skipped_duplicates": int,
            "strategy": str,
            "new_total": int,
        }
    """

    template_fields: Sequence[str] = (
        "dataset_id",
        "project_id",
        "start_time",
        "end_time",
        "input_column",
        "output_column",
        "arize_ax_conn_id",
    )
    operator_extra_links = (ArizeAxDatasetLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        project_id: str,
        max_new_examples: int = 50,
        min_eval_score: float | None = None,
        diversity_strategy: str = "length_bucket",
        start_time: Any = None,
        end_time: Any = None,
        input_column: str = "input",
        output_column: str = "output",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.project_id = project_id
        self.max_new_examples = max_new_examples
        self.min_eval_score = min_eval_score
        self.diversity_strategy = diversity_strategy
        self.start_time = start_time
        self.end_time = end_time
        self.input_column = input_column
        self.output_column = output_column
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _input_hash(text: str) -> str:
        """Short stable hash for deduplication by exact input content."""
        return hashlib.md5(text.encode("utf-8", errors="replace")).hexdigest()[:12]

    @staticmethod
    def _is_too_similar(text: str, existing_fps: set[str]) -> bool:
        """Return True if text's fingerprint (first-5-words + length-bucket) is already seen."""
        fp = _first_words(text, 5) + "|" + _length_bucket(len(text))
        return fp in existing_fps

    def execute(self, context: Any) -> dict[str, Any]:
        if self.diversity_strategy not in ("length_bucket", "random"):
            raise ValueError(
                f"diversity_strategy must be 'length_bucket' or 'random'; got {self.diversity_strategy!r}."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        # Get existing dataset examples to build fingerprint set
        existing_resp = hook.list_dataset_examples(dataset_id=self.dataset_id, all=True)
        existing_examples = existing_resp.get("items") or []
        existing_fps: set[str] = set()
        existing_hashes: set[str] = set()
        for ex in existing_examples:
            if not isinstance(ex, dict):
                continue
            text = _input_text(ex, self.input_column)
            existing_fps.add(_first_words(text, 5) + "|" + _length_bucket(len(text)))
            existing_hashes.add(self._input_hash(text))

        existing_count = len(existing_examples)
        self.log.info(
            "SmartDatasetRefresh: dataset %s has %d existing examples.",
            self.dataset_id, existing_count,
        )

        # Fetch production spans
        prod_rows: list[dict[str, Any]] = []
        try:
            rows = hook.export_spans_to_df_by_project_id(
                project_id=self.project_id,
                start_time=self.start_time,
                end_time=self.end_time,
            )
            prod_rows = rows if isinstance(rows, list) else []
        except Exception as exc:
            self.log.warning("Could not fetch production spans: %s", exc)

        self.log.info("SmartDatasetRefresh: fetched %d production spans.", len(prod_rows))

        # Optionally filter by eval score
        if self.min_eval_score is not None:
            filtered: list[dict[str, Any]] = []
            for row in prod_rows:
                if not isinstance(row, dict):
                    continue
                # Look for an eval score in the span row
                eval_score: float | None = None
                for key, val in row.items():
                    if "score" in key.lower() or "eval" in key.lower():
                        try:
                            eval_score = float(val)
                            break
                        except (TypeError, ValueError):
                            pass
                if eval_score is None or eval_score >= self.min_eval_score:
                    filtered.append(row)
            prod_rows = filtered
            self.log.info(
                "SmartDatasetRefresh: %d spans after min_eval_score=%s filter.",
                len(prod_rows), self.min_eval_score,
            )

        # Filter out spans too similar to existing examples
        novel_spans: list[dict[str, Any]] = []
        skipped_duplicates = 0
        for row in prod_rows:
            if not isinstance(row, dict):
                continue
            inp = str(row.get(self.input_column) or row.get("attributes.input.value") or row.get("input.value") or "")
            h = self._input_hash(inp)
            if h in existing_hashes or self._is_too_similar(inp, existing_fps):
                skipped_duplicates += 1
                continue
            novel_spans.append(row)
            existing_hashes.add(h)  # Prevent adding same span twice

        self.log.info(
            "SmartDatasetRefresh: %d novel spans (skipped %d duplicates).",
            len(novel_spans), skipped_duplicates,
        )

        if not novel_spans:
            return {
                "added_count": 0,
                "skipped_duplicates": skipped_duplicates,
                "strategy": self.diversity_strategy,
                "new_total": existing_count,
            }

        # Apply diversity strategy
        if self.diversity_strategy == "length_bucket":
            buckets: dict[str, list[dict[str, Any]]] = {
                "short": [], "medium": [], "long": [], "very_long": []
            }
            for span in novel_spans:
                inp = str(span.get(self.input_column) or "")
                b = _length_bucket(len(inp))
                buckets[b].append(span)

            selected: list[dict[str, Any]] = []
            per_bucket = max(1, self.max_new_examples // 4)
            for b_spans in buckets.values():
                selected.extend(b_spans[:per_bucket])
            # Fill remaining budget from any bucket
            remaining = self.max_new_examples - len(selected)
            if remaining > 0:
                remaining_spans = [s for b_spans in buckets.values() for s in b_spans[per_bucket:]]
                selected.extend(remaining_spans[:remaining])
        else:
            selected = novel_spans[: self.max_new_examples]

        # Build dataset examples
        examples_to_add: list[dict[str, Any]] = []
        for span in selected:
            inp = str(span.get(self.input_column) or span.get("attributes.input.value") or span.get("input.value") or "")
            out = str(span.get(self.output_column) or span.get("attributes.output.value") or span.get("output.value") or "")
            examples_to_add.append({"input": inp, "output": out})

        if examples_to_add:
            hook.append_dataset_examples(
                dataset_id=self.dataset_id, examples=examples_to_add
            )

        added_count = len(examples_to_add)
        new_total = existing_count + added_count
        self.log.info(
            "SmartDatasetRefresh: added %d examples (strategy=%s, new_total=%d).",
            added_count, self.diversity_strategy, new_total,
        )
        return {
            "added_count": added_count,
            "skipped_duplicates": skipped_duplicates,
            "strategy": self.diversity_strategy,
            "new_total": new_total,
        }
