"""Arize AX Project operators."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.links.arize_ax import ArizeAxProjectLink
from airflow.providers.arize_ax.operators.utils import (
    find_resource_by_name,
    is_conflict,
    is_not_found,
)

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)


class ArizeAxListProjectsOperator(BaseOperator):
    """List projects in a space."""

    template_fields: Sequence[str] = ("space_id", "cursor")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.limit = limit
        self.cursor = cursor
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        result = hook.list_projects(
            space_id=space_id, limit=self.limit, cursor=self.cursor
        )
        ti = context.get("ti")
        if ti is not None:
            items = result.get("items", []) if isinstance(result, dict) else []
            if items and isinstance(items[0], dict):
                ti.xcom_push(key="first_id", value=str(items[0].get("id", "")))
                ti.xcom_push(key="first_name", value=str(items[0].get("name", "")))
        return result


class ArizeAxCreateProjectOperator(BaseOperator):
    """Create a project in a space.

    Set ``if_exists="skip"`` for idempotent behaviour: if the project name
    already exists (HTTP 409), the operator looks up the existing project and
    returns its ID so that downstream tasks continue to work.
    Default is ``"fail"`` (raise on conflict).
    """

    template_fields: Sequence[str] = ("space_id", "name")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        name: str,
        if_exists: str = "fail",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.name = name
        self.if_exists = if_exists
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)
        if not space_id:
            raise AirflowException(
                f"{type(self).__name__} requires space_id. Set it as a task parameter, "
                "or configure 'default_space' on the arize_ax_default connection, "
                "or set the Airflow Variable 'arize_ax_space_id'."
            )
        try:
            project = hook.create_project(space_id=space_id, name=self.name)
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "Project '%s' already exists in space '%s' -- returning existing ID.",
                    self.name, space_id,
                )
                existing_id = find_resource_by_name(
                    hook,
                    "list_projects",
                    self.name,
                    space_id=space_id,
                )
                if existing_id:
                    self.log.info("Resolved existing project ID: %s", existing_id)
                    return existing_id
                raise AirflowException(
                    f"Project '{self.name}' conflicts but could not be found via "
                    f"list API in space '{space_id}'."
                ) from exc
            raise
        if isinstance(project, dict):
            return str(project.get("id", project))
        return str(getattr(project, "id", project))


class ArizeAxGetProjectOperator(BaseOperator):
    """Get a project by ID."""

    template_fields: Sequence[str] = ("project_id",)
    operator_extra_links = (ArizeAxProjectLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_project(project_id=self.project_id)


class ArizeAxDeleteProjectOperator(BaseOperator):
    """Delete a project by ID.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("project_id",)
    operator_extra_links = (ArizeAxProjectLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_project(project_id=self.project_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Project %r not found — skipping delete (ignore_if_missing=True).",
                    self.project_id,
                )
                return
            raise
