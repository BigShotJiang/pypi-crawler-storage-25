"""Arize AX Experiment operators."""

from __future__ import annotations

import logging
import math
import re
import statistics
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator

try:
    from airflow.sdk.exceptions import AirflowFailException
except ImportError:
    from airflow.exceptions import AirflowFailException
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.links.arize_ax import ArizeAxExperimentLink
from airflow.providers.arize_ax.operators.utils import (
    find_resource_by_name,
    is_conflict,
    is_not_found,
    push_first_xcom_keys,
)

if TYPE_CHECKING:
    from airflow.utils.context import Context

log = logging.getLogger(__name__)

_AGGREGATIONS: dict[str, Any] = {
    "mean": statistics.mean,
    "median": statistics.median,
    "min": min,
    "max": max,
}


def _paginate_experiment_runs(hook: Any, experiment_id: str) -> list[dict[str, Any]]:
    """Fetch all experiment runs, returning a flat list of run dicts."""
    resp = hook.list_experiment_runs(experiment_id=experiment_id, all=True)
    items = resp.get("items", []) if isinstance(resp, dict) else []
    return [item for item in items if isinstance(item, dict)]


def _extract_scores_from_runs(
    runs: list[dict[str, Any]],
    metric_names: list[str] | None,
) -> dict[str, list[float]]:
    """Group numeric evaluation scores by metric name across all runs.

    Handles three serialisation shapes:
    - ``run["evaluations"]`` is a dict mapping metric name -> {"score": float, ...}
    - ``run["evaluations"]`` is a list of dicts with ``"name"`` and ``"score"`` keys
    - Flat top-level keys ``"eval.{name}.score"`` as returned by the Arize API
      when experiments are created with ``evaluator_columns``
    """
    scores: dict[str, list[float]] = {}
    for run in runs:
        evals = run.get("evaluations") or run.get("evals") or {}
        if isinstance(evals, dict):
            for name, entry in evals.items():
                if metric_names and name not in metric_names:
                    continue
                score = entry.get("score") if isinstance(entry, dict) else None
                if score is not None:
                    try:
                        scores.setdefault(name, []).append(float(score))
                    except (TypeError, ValueError):
                        pass
        elif isinstance(evals, list):
            for ev in evals:
                if not isinstance(ev, dict):
                    continue
                name = ev.get("name", "")
                if metric_names and name not in metric_names:
                    continue
                score = ev.get("score")
                if score is not None:
                    try:
                        scores.setdefault(name, []).append(float(score))
                    except (TypeError, ValueError):
                        pass

        # Flat "eval.{name}.score" keys produced by the Arize API when
        # experiments are uploaded with evaluator_columns.  These may appear
        # at the top level or nested inside "additional_properties" depending
        # on the SDK version and serialization path.
        search_dicts = [run]
        extra = run.get("additional_properties")
        if isinstance(extra, dict):
            search_dicts.append(extra)
        for d in search_dicts:
            for key, val in d.items():
                if key.startswith("eval.") and key.endswith(".score"):
                    name = key[5:-6]  # strip "eval." prefix and ".score" suffix
                    if metric_names and name not in metric_names:
                        continue
                    if val is not None:
                        try:
                            scores.setdefault(name, []).append(float(val))
                        except (TypeError, ValueError):
                            pass

    return scores


def _aggregate_scores(
    scores_by_metric: dict[str, list[float]],
    aggregation: str,
) -> dict[str, float]:
    """Apply the requested aggregation function to each metric's score list."""
    agg_fn = _AGGREGATIONS.get(aggregation)
    if agg_fn is None:
        raise AirflowFailException(
            f"Unsupported aggregation {aggregation!r}. "
            f"Supported values: {sorted(_AGGREGATIONS)!r}."
        )
    result: dict[str, float] = {}
    for name, values in scores_by_metric.items():
        if values:
            result[name] = agg_fn(values)
    return result


class ArizeAxListExperimentsOperator(BaseOperator):
    """List experiments for a dataset."""

    template_fields: Sequence[str] = ("dataset_id", "cursor", "space_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        limit: int = 50,
        cursor: str | None = None,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.limit = limit
        self.cursor = cursor
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.list_experiments(
            dataset_id=self.dataset_id,
            limit=self.limit,
            cursor=self.cursor,
            space=self.space_id,
        )


class ArizeAxCreateExperimentOperator(BaseOperator):
    """Create an experiment (log pre-computed experiment runs).

    Set ``if_exists="skip"`` for idempotent behaviour: if the experiment name
    already exists (HTTP 409), the operator looks up the existing experiment and
    returns its ID so that downstream tasks continue to work.
    Default is ``"fail"`` (raise on conflict).
    """

    template_fields: Sequence[str] = ("name", "dataset_id", "space_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        dataset_id: str,
        experiment_runs: list[dict[str, Any]] | Any,
        task_fields: Any | None = None,
        evaluator_columns: dict[str, Any] | None = None,
        experiment_runs_path: str | None = None,
        if_exists: str = "fail",
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.dataset_id = dataset_id
        self.experiment_runs = experiment_runs if experiment_runs is not None else []
        self.task_fields = task_fields
        self.evaluator_columns = evaluator_columns or {}
        self.experiment_runs_path = experiment_runs_path
        self.if_exists = if_exists
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> str:
        import json
        if self.experiment_runs_path:
            with open(self.experiment_runs_path) as f:
                content = f.read().strip()
                if self.experiment_runs_path.endswith(".json"):
                    experiment_runs = json.loads(content)
                else:
                    import pandas as pd
                    experiment_runs = pd.read_csv(self.experiment_runs_path).to_dict(orient="records")
        else:
            experiment_runs = self.experiment_runs
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            experiment = hook.create_experiment(
                name=self.name,
                dataset_id=self.dataset_id,
                experiment_runs=experiment_runs,
                task_fields=self.task_fields,
                evaluator_columns=self.evaluator_columns,
                space=self.space_id,
            )
        except Exception as exc:
            if self.if_exists == "skip" and is_conflict(exc):
                self.log.warning(
                    "Experiment '%s' already exists for dataset '%s' -- returning existing ID.",
                    self.name, self.dataset_id,
                )
                existing_id = find_resource_by_name(
                    hook,
                    "list_experiments",
                    self.name,
                    dataset_id=self.dataset_id,
                )
                if existing_id:
                    self.log.info("Resolved existing experiment ID: %s", existing_id)
                    return existing_id
                raise AirflowException(
                    f"Experiment '{self.name}' conflicts but could not be found via "
                    f"list API for dataset '{self.dataset_id}'."
                ) from exc
            raise
        if isinstance(experiment, dict):
            return str(experiment.get("id", experiment))
        return str(getattr(experiment, "id", experiment))


class ArizeAxGetExperimentOperator(BaseOperator):
    """Get an experiment by ID."""

    template_fields: Sequence[str] = ("experiment_id", "space_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.get_experiment(experiment_id=self.experiment_id, space=self.space_id)


class ArizeAxDeleteExperimentOperator(BaseOperator):
    """Delete an experiment by ID.

    ``ignore_if_missing``: when ``True`` (the default), a 404 Not Found error
    is logged and swallowed instead of raising.  Set to ``False`` to raise.
    """

    template_fields: Sequence[str] = ("experiment_id", "space_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        space_id: str | None = None,
        ignore_if_missing: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.space_id = space_id
        self.ignore_if_missing = ignore_if_missing
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> None:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        try:
            hook.delete_experiment(experiment_id=self.experiment_id, space=self.space_id)
        except Exception as exc:
            if self.ignore_if_missing and is_not_found(exc):
                self.log.info(
                    "Experiment %r not found — skipping delete (ignore_if_missing=True).",
                    self.experiment_id,
                )
                return
            raise


class ArizeAxRunExperimentOperator(BaseOperator):
    """Run an experiment end-to-end: execute a task + evaluators against a dataset.

    The ``task`` parameter must be a callable (or importable dotted path string)
    that accepts a dataset example dict and returns an output dict.  Evaluators
    follow the same convention used by the Arize SDK ``experiments.run()`` API.

    Returns a dict with ``experiment`` (serialized experiment metadata, None in
    dry-run mode) and ``dataframe_records`` (list of row dicts from the results
    DataFrame).
    """

    template_fields: Sequence[str] = ("name", "dataset_id", "space_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        name: str,
        dataset_id: str,
        task: Any,
        evaluators: list[Any] | None = None,
        concurrency: int | None = None,
        dry_run: bool = False,
        dry_run_count: int | None = None,
        exit_on_error: bool = False,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.name = name
        self.dataset_id = dataset_id
        self.task = task
        self.evaluators = evaluators
        self.concurrency = concurrency
        self.dry_run = dry_run
        self.dry_run_count = dry_run_count
        self.exit_on_error = exit_on_error
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _resolve_callable(ref: Any) -> Any:
        """If *ref* is a dotted-path string, import and return the callable."""
        if callable(ref) or not isinstance(ref, str):
            return ref
        from importlib import import_module
        module_path, _, attr = ref.rpartition(".")
        if not module_path:
            raise ValueError(f"Cannot import task from dotted path: {ref!r}")
        mod = import_module(module_path)
        return getattr(mod, attr)

    def execute(self, context: Context) -> str | None:
        task_fn = self._resolve_callable(self.task)
        evaluators = None
        if self.evaluators:
            evaluators = [self._resolve_callable(e) for e in self.evaluators]
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.run_experiment(
            name=self.name,
            dataset_id=self.dataset_id,
            task=task_fn,
            evaluators=evaluators,
            concurrency=self.concurrency,
            dry_run=self.dry_run,
            dry_run_count=self.dry_run_count,
            exit_on_error=self.exit_on_error,
            space=hook.get_space(self.space_id),
        )
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        if isinstance(result, dict):
            exp = result.get("experiment")
            if isinstance(exp, dict):
                for key in ("id", "experiment_id"):
                    if exp.get(key):
                        return str(exp[key])
            for key in ("id", "experiment_id"):
                if result.get(key):
                    return str(result[key])
        if isinstance(result, str):
            return result
        return None


class ArizeAxListExperimentRunsOperator(BaseOperator):
    """List runs for an experiment."""

    template_fields: Sequence[str] = ("experiment_id",)
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        limit: int = 100,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.limit = limit
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_experiment_runs(
            experiment_id=self.experiment_id, limit=self.limit
        )
        push_first_xcom_keys(context, result)
        return result


class ArizeAxAnnotateExperimentRunsOperator(BaseOperator):
    """Batch human annotations onto experiment runs (HITL).

    Upsert semantics: same annotation config name for the same run overwrites
    the previous value, making this safe to retry.

    Params:
        experiment_id: Experiment name or ID.
        annotations: List of annotation dicts, each with ``record_id`` (run ID)
            and ``values`` (list of dicts with ``name`` and optionally ``score``,
            ``label``, ``text``).  Up to 500 entries per request.
        dataset_id: Dataset name or ID (optional).
        space_id: Space name or ID (optional).
    """

    # ``annotations`` is templated so Jinja inside nested record_id / name /
    # label strings renders before the API is called.
    template_fields: Sequence[str] = (
        "experiment_id", "annotations", "dataset_id", "space_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        annotations: list[dict[str, Any]],
        dataset_id: str | None = None,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.annotations = annotations
        self.dataset_id = dataset_id
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> Any:
        if not self.annotations:
            raise AirflowException(
                f"{type(self).__name__}: annotations list must not be empty."
            )
        if len(self.annotations) > 500:
            raise AirflowException(
                f"{type(self).__name__}: annotations list exceeds the 500-entry limit "
                f"(got {len(self.annotations)})."
            )
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.annotate_experiment_runs(
            experiment_id=self.experiment_id,
            annotations=self.annotations,
            dataset=self.dataset_id,
            space=self.space_id,
        )
        ti = context.get("ti")
        if ti is not None:
            ti.xcom_push(key="result", value=result)
        return result


class ArizeAxExportExperimentRunsToFileOperator(BaseOperator):
    """Export all experiment runs to a JSON file (one array of run objects).

    Uses the SDK's all=True mode for bulk export.
    """

    template_fields: Sequence[str] = ("experiment_id", "path")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        path: str,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.path = path
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> int:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        return hook.export_experiment_runs_to_file(
            experiment_id=self.experiment_id,
            path=self.path,
        )


class ArizeAxGetExperimentScoreOperator(BaseOperator):
    """Extract aggregate evaluation scores from all runs of an experiment.

    Paginates through every run in the experiment, collects numeric scores for
    each evaluation metric (optionally filtered to ``metric_names``), and
    applies ``aggregation`` (one of ``"mean"``, ``"median"``, ``"min"``,
    ``"max"``).

    Returns a dict of ``{metric_name: aggregated_score}`` via XCom.  Metrics
    that have no numeric scores are omitted from the result.
    """

    template_fields: Sequence[str] = ("experiment_id", "arize_ax_conn_id")
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        metric_names: list[str] | None = None,
        aggregation: str = "mean",
        min_score: float | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if aggregation not in _AGGREGATIONS:
            raise ValueError(
                f"Unsupported aggregation {aggregation!r}. "
                f"Supported: {sorted(_AGGREGATIONS)!r}."
            )
        self.experiment_id = experiment_id
        self.metric_names = metric_names
        self.aggregation = aggregation
        self.min_score = min_score
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, float]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        runs = _paginate_experiment_runs(hook, self.experiment_id)
        self.log.info(
            "Experiment %s: fetched %d runs for scoring.", self.experiment_id, len(runs)
        )
        scores_by_metric = _extract_scores_from_runs(runs, self.metric_names)
        if not scores_by_metric:
            self.log.warning(
                "Experiment %s: no evaluation scores found (metric_names=%r).",
                self.experiment_id,
                self.metric_names,
            )
            return {}
        result = _aggregate_scores(scores_by_metric, self.aggregation)
        self.log.info(
            "Experiment %s scores (%s): %s", self.experiment_id, self.aggregation, result
        )
        if self.min_score is not None:
            for metric, score in result.items():
                if score < self.min_score:
                    raise AirflowException(
                        f"Score gate FAILED: metric {metric!r} scored {score:.4f} "
                        f"(threshold: {self.min_score})"
                    )
        return result


class ArizeAxCompareExperimentsOperator(BaseOperator):
    """Compare a candidate experiment against a baseline across evaluation metrics.

    Fetches aggregate scores for both experiments and computes per-metric
    deltas.  A metric ``"passes"`` when
    ``candidate_score >= baseline_score + pass_threshold``.

    XCom return schema::

        {
            "results": {
                "<metric>": {
                    "candidate": float,
                    "baseline": float,
                    "delta": float,
                    "passed": bool,
                },
                ...
            },
            "overall_passed": bool,   # True iff all shared metrics passed
        }

    Metrics present in only one experiment are omitted from the comparison.
    If no shared metrics exist, ``overall_passed`` is ``False``.
    """

    template_fields: Sequence[str] = (
        "candidate_experiment_id",
        "baseline_experiment_id",
        "arize_ax_conn_id",
    )
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        candidate_experiment_id: str,
        baseline_experiment_id: str,
        metric_names: list[str] | None = None,
        aggregation: str = "mean",
        pass_threshold: float = 0.0,
        fail_on_regression: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if aggregation not in _AGGREGATIONS:
            raise ValueError(
                f"Unsupported aggregation {aggregation!r}. "
                f"Supported: {sorted(_AGGREGATIONS)!r}."
            )
        self.candidate_experiment_id = candidate_experiment_id
        self.baseline_experiment_id = baseline_experiment_id
        self.metric_names = metric_names
        self.aggregation = aggregation
        self.pass_threshold = pass_threshold
        self.fail_on_regression = fail_on_regression
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Context) -> dict[str, Any]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        candidate_runs = _paginate_experiment_runs(hook, self.candidate_experiment_id)
        baseline_runs = _paginate_experiment_runs(hook, self.baseline_experiment_id)

        self.log.info(
            "Candidate %s: %d runs; Baseline %s: %d runs.",
            self.candidate_experiment_id,
            len(candidate_runs),
            self.baseline_experiment_id,
            len(baseline_runs),
        )

        candidate_scores = _aggregate_scores(
            _extract_scores_from_runs(candidate_runs, self.metric_names),
            self.aggregation,
        )
        baseline_scores = _aggregate_scores(
            _extract_scores_from_runs(baseline_runs, self.metric_names),
            self.aggregation,
        )

        shared_metrics = set(candidate_scores) & set(baseline_scores)
        if not shared_metrics:
            self.log.warning(
                "No shared metrics between candidate (%s) and baseline (%s). "
                "Candidate metrics: %r. Baseline metrics: %r.",
                self.candidate_experiment_id,
                self.baseline_experiment_id,
                sorted(candidate_scores),
                sorted(baseline_scores),
            )
            result = {"results": {}, "overall_passed": False}
            if self.fail_on_regression:
                raise AirflowException(
                    f"Experiment comparison gate FAILED: candidate did not pass "
                    f"all thresholds. Results: {result.get('results', {})}"
                )
            return result

        per_metric: dict[str, dict[str, Any]] = {}
        for metric in sorted(shared_metrics):
            c = candidate_scores[metric]
            b = baseline_scores[metric]
            delta = c - b
            passed = c >= b + self.pass_threshold
            per_metric[metric] = {
                "candidate": c,
                "baseline": b,
                "delta": delta,
                "passed": passed,
            }

        overall_passed = all(v["passed"] for v in per_metric.values())
        self.log.info(
            "Experiment comparison (%s vs %s): overall_passed=%s, per_metric=%s",
            self.candidate_experiment_id,
            self.baseline_experiment_id,
            overall_passed,
            per_metric,
        )
        result = {"results": per_metric, "overall_passed": overall_passed}
        if self.fail_on_regression and not result.get("overall_passed", True):
            raise AirflowException(
                f"Experiment comparison gate FAILED: candidate did not pass "
                f"all thresholds. Results: {result.get('results', {})}"
            )
        return result


class ArizeAxDetectEvalDriftOperator(BaseOperator):
    """Compare evaluation scores between two experiments and detect drift.

    Fetches aggregate scores for both ``current_experiment_id`` and
    ``baseline_experiment_id``, then computes per-metric deltas.  A metric is
    flagged as *drifted* when::

        delta = current_score - baseline_score < -drift_threshold

    i.e. when the current score dropped by more than ``drift_threshold``
    relative to the baseline.

    XCom return schema::

        {
            "drift_detected": bool,
            "drifted_metrics": [
                {
                    "metric": str,
                    "current": float,
                    "baseline": float,
                    "delta": float,
                },
                ...
            ],
            "stable_metrics": [
                {
                    "metric": str,
                    "current": float,
                    "baseline": float,
                    "delta": float,
                },
                ...
            ],
            "summary": str,
        }

    Metrics present in only one experiment are omitted from the comparison.
    ``drift_detected`` is ``False`` when no shared metrics exist.
    """

    template_fields: Sequence[str] = (
        "current_experiment_id",
        "baseline_experiment_id",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        current_experiment_id: str,
        baseline_experiment_id: str,
        metric_names: list[str] | None = None,
        drift_threshold: float = 0.1,
        aggregation: str = "mean",
        fail_on_drift: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if aggregation not in _AGGREGATIONS:
            raise ValueError(
                f"Unsupported aggregation {aggregation!r}. "
                f"Supported: {sorted(_AGGREGATIONS)!r}."
            )
        if drift_threshold < 0:
            raise ValueError(
                f"drift_threshold must be >= 0; got {drift_threshold!r}."
            )
        self.current_experiment_id = current_experiment_id
        self.baseline_experiment_id = baseline_experiment_id
        self.metric_names = metric_names
        self.drift_threshold = drift_threshold
        self.aggregation = aggregation
        self.fail_on_drift = fail_on_drift
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Any) -> dict[str, Any]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        current_runs = _paginate_experiment_runs(hook, self.current_experiment_id)
        baseline_runs = _paginate_experiment_runs(hook, self.baseline_experiment_id)

        self.log.info(
            "Drift detection — current %s: %d runs; baseline %s: %d runs.",
            self.current_experiment_id, len(current_runs),
            self.baseline_experiment_id, len(baseline_runs),
        )

        current_scores = _aggregate_scores(
            _extract_scores_from_runs(current_runs, self.metric_names),
            self.aggregation,
        )
        baseline_scores = _aggregate_scores(
            _extract_scores_from_runs(baseline_runs, self.metric_names),
            self.aggregation,
        )

        shared_metrics = set(current_scores) & set(baseline_scores)
        if not shared_metrics:
            self.log.warning(
                "No shared metrics between current (%s) and baseline (%s). "
                "Current metrics: %r. Baseline metrics: %r.",
                self.current_experiment_id, self.baseline_experiment_id,
                sorted(current_scores), sorted(baseline_scores),
            )
            return {
                "drift_detected": False,
                "drifted_metrics": [],
                "stable_metrics": [],
                "summary": "No shared metrics found; drift cannot be determined.",
            }

        drifted: list[dict[str, Any]] = []
        stable: list[dict[str, Any]] = []
        for metric in sorted(shared_metrics):
            current_val = current_scores[metric]
            baseline_val = baseline_scores[metric]
            delta = current_val - baseline_val
            entry = {
                "metric": metric,
                "current": current_val,
                "baseline": baseline_val,
                "delta": delta,
            }
            if delta < -self.drift_threshold:
                drifted.append(entry)
            else:
                stable.append(entry)

        drift_detected = len(drifted) > 0
        if drift_detected:
            drifted_names = [d["metric"] for d in drifted]
            summary = (
                f"Drift detected in {len(drifted)} metric(s): {drifted_names}. "
                f"Threshold: {self.drift_threshold}."
            )
        else:
            summary = (
                f"No drift detected across {len(stable)} metric(s). "
                f"Threshold: {self.drift_threshold}."
            )

        self.log.info(
            "Drift detection (%s vs %s): drift_detected=%s, drifted=%s, stable=%s",
            self.current_experiment_id, self.baseline_experiment_id,
            drift_detected, drifted, stable,
        )
        result = {
            "drift_detected": drift_detected,
            "drifted_metrics": drifted,
            "stable_metrics": stable,
            "summary": summary,
        }
        if self.fail_on_drift and drift_detected:
            raise AirflowException(
                f"Drift detected in {len(drifted)} metric(s): "
                f"{[d['metric'] for d in drifted]}. "
                f"Threshold: {self.drift_threshold}."
            )
        return result


# ---------------------------------------------------------------------------
# Helpers used by novel LLMOps operators (stdlib + statistics only)
# ---------------------------------------------------------------------------

def _spearman_correlation(xs: list[float], ys: list[float]) -> float:
    """Compute Spearman rank-order correlation coefficient using only stdlib."""
    n = len(xs)
    if n < 2:
        return 0.0

    def _rank(vals: list[float]) -> list[float]:
        sorted_vals = sorted(enumerate(vals), key=lambda t: t[1])
        ranks = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j < n - 1 and sorted_vals[j + 1][1] == sorted_vals[j][1]:
                j += 1
            avg_rank = (i + j) / 2.0 + 1
            for k in range(i, j + 1):
                ranks[sorted_vals[k][0]] = avg_rank
            i = j + 1
        return ranks

    rx = _rank(xs)
    ry = _rank(ys)
    d2 = sum((a - b) ** 2 for a, b in zip(rx, ry))
    return 1.0 - 6.0 * d2 / (n * (n * n - 1))


def _mann_whitney_u(a: list[float], b: list[float]) -> tuple[float, float]:
    """Return (U-statistic, approximate p-value) for a two-sided Mann-Whitney U test.

    Uses a normal approximation (valid for n > 20; for small samples returns 1.0).
    """
    na, nb = len(a), len(b)
    if na == 0 or nb == 0:
        return 0.0, 1.0
    combined = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    rank_sum_a = 0.0
    i = 0
    while i < len(combined):
        j = i
        while j < len(combined) - 1 and combined[j + 1][0] == combined[i][0]:
            j += 1
        avg_rank = (i + j) / 2.0 + 1
        for k in range(i, j + 1):
            if combined[k][1] == 0:
                rank_sum_a += avg_rank
        i = j + 1
    u_stat = rank_sum_a - na * (na + 1) / 2.0
    n_total = na + nb
    mean_u = na * nb / 2.0
    std_u = math.sqrt(na * nb * (n_total + 1) / 12.0)
    if std_u == 0:
        return u_stat, 1.0
    z = (u_stat - mean_u) / std_u
    # Two-sided p-value via normal CDF approximation (Abramowitz & Stegun)
    p = _norm_sf(abs(z)) * 2.0
    return u_stat, min(p, 1.0)


def _norm_sf(z: float) -> float:
    """Survival function of the standard normal (1 - CDF) via math.erfc."""
    return 0.5 * math.erfc(z / math.sqrt(2))


def _cohens_d(a: list[float], b: list[float]) -> float:
    """Compute Cohen's d effect size between two samples.

    When pooled std is zero (all values identical within each group) but the
    group means differ, return ±10.0 to signal a very large effect.
    """
    if len(a) < 2 or len(b) < 2:
        return 0.0
    mean_a = statistics.mean(a)
    mean_b = statistics.mean(b)
    var_a = statistics.variance(a)
    var_b = statistics.variance(b)
    pooled_std = math.sqrt((var_a + var_b) / 2.0)
    if pooled_std == 0:
        return 10.0 if mean_a != mean_b else 0.0
    return (mean_a - mean_b) / pooled_std


def _extract_output_text(run: dict[str, Any]) -> str:
    """Extract the output text string from a run dict (handles common shapes)."""
    output = run.get("output") or run.get("outputs") or run.get("result") or {}
    if isinstance(output, str):
        return output
    if isinstance(output, dict):
        for key in ("output", "text", "response", "content", "answer"):
            val = output.get(key)
            if isinstance(val, str) and val:
                return val
        return " ".join(str(v) for v in output.values() if v is not None)
    return str(output) if output else ""


def _count_sentences(text: str) -> int:
    """Approximate sentence count by splitting on terminal punctuation."""
    return max(1, len(re.split(r"[.!?]+", text.strip())))


_REFUSAL_PHRASES = (
    "i cannot", "i can't", "i'm unable", "i am unable",
    "i don't", "i do not", "i apologize", "i'm sorry", "i am sorry",
    "as an ai", "as an llm",
)


def _is_refusal(text: str) -> bool:
    lower = text.lower()
    return any(phrase in lower for phrase in _REFUSAL_PHRASES)


def _is_structured(text: str) -> bool:
    """Heuristic: does the text contain list markers, headers, or JSON-like structure?"""
    return bool(
        re.search(r"(^\s*[-*•]|\d+\.\s)", text, re.MULTILINE)
        or re.search(r"^#{1,3}\s", text, re.MULTILINE)
        or re.search(r"[{}\[\]]", text)
    )


# ---------------------------------------------------------------------------
# Feature 1: Evaluator Calibration
# ---------------------------------------------------------------------------

class ArizeAxEvaluatorCalibrationOperator(BaseOperator):
    """Measure how well an LLM evaluator correlates with human ground truth annotations.

    Paginates all runs in ``experiment_id``, extracts evaluator scores for
    ``metric_name``, and pairs them with human annotation scores found in run
    metadata.  Computes Spearman correlation, mean bias, MAE, and a verbosity
    bias (length-residual correlation) to produce a calibration quality report.

    Returns a structured dict via XCom::

        {
            "metric_name": str,
            "annotation_name": str,
            "sample_count": int,
            "calibrated": bool,
            "spearman_correlation": float,
            "mean_bias": float,       # positive = evaluator over-scores vs human
            "mae": float,
            "length_bias": float,     # correlation of output length with score residual
            "calibration_quality": "good" | "moderate" | "poor",
            "recommendation": str,
            "score_pairs": [{"eval": float, "human": float}],
        }
    """

    template_fields: Sequence[str] = (
        "experiment_id",
        "annotation_name",
        "metric_name",
        "min_samples",
        "arize_ax_conn_id",
    )
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        annotation_name: str,
        metric_name: str,
        min_samples: int = 10,
        fail_on_poor_calibration: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.annotation_name = annotation_name
        self.metric_name = metric_name
        self.min_samples = min_samples
        self.fail_on_poor_calibration = fail_on_poor_calibration
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _extract_annotation_score(run: dict[str, Any], annotation_name: str) -> float | None:
        """Look for a human annotation score in run metadata / input under annotation_name."""
        # Check common locations: metadata dict, top-level, annotations dict
        for container_key in ("metadata", "annotations", "labels", "input", "inputs"):
            container = run.get(container_key)
            if not isinstance(container, dict):
                continue
            # Exact match or nested
            for key in (annotation_name, f"annotations.{annotation_name}", f"annotation.{annotation_name}"):
                val = container.get(key)
                if val is not None:
                    try:
                        return float(val)
                    except (TypeError, ValueError):
                        pass
            # Fuzzy: any key that contains annotation_name
            for key, val in container.items():
                if annotation_name.lower() in key.lower() and val is not None:
                    try:
                        return float(val)
                    except (TypeError, ValueError):
                        pass
        # Top-level check — covers flat columns and dot-prefixed API keys
        for key in (
            annotation_name,
            f"human_{annotation_name}",
            f"annotation_{annotation_name}",
            f"metadata.{annotation_name}",
        ):
            val = run.get(key)
            if val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    pass
        return None

    def execute(self, context: Any) -> dict[str, Any]:
        # min_samples may arrive as a string from Jinja
        # (``"{{ params.X }}"``) on DAGs without ``render_template_as_native_obj``.
        self.min_samples = int(self.min_samples)

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        runs = _paginate_experiment_runs(hook, self.experiment_id)
        self.log.info(
            "Calibration: experiment %s has %d runs.", self.experiment_id, len(runs)
        )

        # Build paired (eval_score, human_score, output_length) triples
        pairs: list[dict[str, float]] = []
        output_lengths: list[float] = []
        for run in runs:
            evals = run.get("evaluations") or run.get("evals") or {}
            eval_score: float | None = None
            if isinstance(evals, dict):
                entry = evals.get(self.metric_name)
                if isinstance(entry, dict):
                    s = entry.get("score")
                    if s is not None:
                        try:
                            eval_score = float(s)
                        except (TypeError, ValueError):
                            pass
            elif isinstance(evals, list):
                for ev in evals:
                    if isinstance(ev, dict) and ev.get("name") == self.metric_name:
                        s = ev.get("score")
                        if s is not None:
                            try:
                                eval_score = float(s)
                            except (TypeError, ValueError):
                                pass
                            break

            if eval_score is None:
                continue

            human_score = self._extract_annotation_score(run, self.annotation_name)
            if human_score is None:
                continue

            output_text = _extract_output_text(run)
            output_lengths.append(float(len(output_text)))
            pairs.append({"eval": eval_score, "human": human_score})

        sample_count = len(pairs)
        self.log.info(
            "Calibration: found %d paired (eval, human) samples (min_samples=%d).",
            sample_count, self.min_samples,
        )

        partial_base = {
            "metric_name": self.metric_name,
            "annotation_name": self.annotation_name,
            "sample_count": sample_count,
            "calibrated": False,
        }

        if sample_count == 0:
            return {**partial_base, "reason": "no annotation data found in runs"}

        if sample_count < self.min_samples:
            self.log.warning(
                "Calibration: only %d paired samples (< min_samples=%d). Returning partial result.",
                sample_count, self.min_samples,
            )
            return {
                **partial_base,
                "reason": f"insufficient samples: {sample_count} < {self.min_samples}",
                "score_pairs": pairs,
            }

        eval_scores = [p["eval"] for p in pairs]
        human_scores = [p["human"] for p in pairs]

        spearman = _spearman_correlation(eval_scores, human_scores)
        residuals = [e - h for e, h in zip(eval_scores, human_scores)]
        mean_bias = statistics.mean(residuals)
        mae = statistics.mean(abs(r) for r in residuals)

        # Length bias: correlation between output length and residual
        length_bias = _spearman_correlation(output_lengths, residuals) if output_lengths else 0.0

        abs_sp = abs(spearman)
        if abs_sp > 0.7:
            quality = "good"
            recommendation = (
                f"Evaluator '{self.metric_name}' is well-calibrated (Spearman={spearman:.3f}). "
                "No immediate action needed."
            )
        elif abs_sp > 0.4:
            quality = "moderate"
            recommendation = (
                f"Evaluator '{self.metric_name}' shows moderate alignment (Spearman={spearman:.3f}). "
                "Consider reviewing borderline cases or adding more diverse annotations."
            )
        else:
            quality = "poor"
            recommendation = (
                f"Evaluator '{self.metric_name}' is poorly calibrated (Spearman={spearman:.3f}). "
                "Review the evaluator prompt and consider a full recalibration with more human labels."
            )

        if abs(mean_bias) > 0.1:
            direction = "over-scores" if mean_bias > 0 else "under-scores"
            recommendation += (
                f" The evaluator {direction} by {abs(mean_bias):.3f} on average vs human labels."
            )
        if abs(length_bias) > 0.3:
            recommendation += (
                f" Verbosity bias detected (length-residual Spearman={length_bias:.3f}): "
                "the evaluator may reward longer outputs independent of quality."
            )

        result = {
            "metric_name": self.metric_name,
            "annotation_name": self.annotation_name,
            "sample_count": sample_count,
            "calibrated": True,
            "spearman_correlation": round(spearman, 4),
            "mean_bias": round(mean_bias, 4),
            "mae": round(mae, 4),
            "length_bias": round(length_bias, 4),
            "calibration_quality": quality,
            "recommendation": recommendation,
            "score_pairs": pairs,
        }
        self.log.info(
            "Calibration result for %s: quality=%s, spearman=%.4f, bias=%.4f, mae=%.4f",
            self.metric_name, quality, spearman, mean_bias, mae,
        )
        if self.fail_on_poor_calibration and quality == "poor":
            raise AirflowException(
                f"Evaluator calibration gate FAILED: metric {self.metric_name!r} "
                f"has poor calibration (Spearman={spearman:.4f}). "
                f"Recommendation: {recommendation}"
            )
        return result


# ---------------------------------------------------------------------------
# Feature 3: Behavioral Regression Testing
# ---------------------------------------------------------------------------

class ArizeAxBehavioralRegressionOperator(BaseOperator):
    """Compare the behavioral distribution of two experiments beyond mean scores.

    Detects subtle regressions in output length, refusal rate, format compliance,
    and sentence count that aggregate eval scores miss.

    Uses Mann-Whitney U tests and effect sizes (Cohen's d) to compare distributions.

    Returns a structured dict via XCom with ``regression_detected`` and a full
    ``behavioral_diff`` breakdown.
    """

    template_fields: Sequence[str] = (
        "baseline_experiment_id",
        "candidate_experiment_id",
        "dataset_id",
        "significance_threshold",
        "arize_ax_conn_id",
    )
    operator_extra_links = (ArizeAxExperimentLink(),)
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        baseline_experiment_id: str,
        candidate_experiment_id: str,
        dataset_id: str | None = None,
        significance_threshold: float = 0.05,
        fail_on_regression: bool = False,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.baseline_experiment_id = baseline_experiment_id
        self.candidate_experiment_id = candidate_experiment_id
        self.dataset_id = dataset_id
        self.significance_threshold = significance_threshold
        self.fail_on_regression = fail_on_regression
        self.arize_ax_conn_id = arize_ax_conn_id

    @staticmethod
    def _extract_behavioral_features(runs: list[dict[str, Any]]) -> dict[str, Any]:
        """Extract behavioral signals from a list of runs."""
        output_lengths: list[float] = []
        refusal_flags: list[bool] = []
        format_flags: list[bool] = []
        sentence_counts: list[float] = []

        for run in runs:
            text = _extract_output_text(run)
            if not text:
                continue
            output_lengths.append(float(len(text)))
            refusal_flags.append(_is_refusal(text))
            format_flags.append(_is_structured(text))
            sentence_counts.append(float(_count_sentences(text)))

        n = len(output_lengths)
        return {
            "output_lengths": output_lengths,
            "refusal_rate": sum(refusal_flags) / n if n else 0.0,
            "format_compliance": sum(format_flags) / n if n else 0.0,
            "avg_sentences": statistics.mean(sentence_counts) if sentence_counts else 0.0,
            "n": n,
        }

    def execute(self, context: Any) -> dict[str, Any]:
        # significance_threshold may arrive as a string from Jinja
        # (``"{{ params.X }}"``) on DAGs without ``render_template_as_native_obj``.
        # Coerce defensively so downstream ``float < self.significance_threshold``
        # comparisons don't TypeError.
        self.significance_threshold = float(self.significance_threshold)

        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)

        baseline_runs = _paginate_experiment_runs(hook, self.baseline_experiment_id)
        candidate_runs = _paginate_experiment_runs(hook, self.candidate_experiment_id)

        self.log.info(
            "Behavioral regression: baseline %s (%d runs), candidate %s (%d runs).",
            self.baseline_experiment_id, len(baseline_runs),
            self.candidate_experiment_id, len(candidate_runs),
        )

        baseline_feat = self._extract_behavioral_features(baseline_runs)
        candidate_feat = self._extract_behavioral_features(candidate_runs)

        # Extract eval scores
        baseline_scores_by_metric = _extract_scores_from_runs(baseline_runs, None)
        candidate_scores_by_metric = _extract_scores_from_runs(candidate_runs, None)
        shared_metrics = set(baseline_scores_by_metric) & set(candidate_scores_by_metric)
        baseline_scores_flat = [s for m in shared_metrics for s in baseline_scores_by_metric[m]]
        candidate_scores_flat = [s for m in shared_metrics for s in candidate_scores_by_metric[m]]

        regressions: list[dict[str, Any]] = []
        stable_dimensions: list[str] = []

        def _severity(effect: float) -> str:
            ae = abs(effect)
            if ae >= 0.8:
                return "major"
            if ae >= 0.5:
                return "moderate"
            return "minor"

        # --- Output length ---
        bl_len = baseline_feat["output_lengths"]
        cd_len = candidate_feat["output_lengths"]
        len_pvalue = 1.0
        len_effect = 0.0
        if bl_len and cd_len:
            _, len_pvalue = _mann_whitney_u(bl_len, cd_len)
            len_effect = _cohens_d(cd_len, bl_len)

        bl_len_mean = statistics.mean(bl_len) if bl_len else 0.0
        cd_len_mean = statistics.mean(cd_len) if cd_len else 0.0

        if abs(len_effect) > 0.3:
            regressions.append({
                "dimension": "output_length",
                "baseline_value": round(bl_len_mean, 1),
                "candidate_value": round(cd_len_mean, 1),
                "change": round(cd_len_mean - bl_len_mean, 1),
                "severity": _severity(len_effect),
            })
        else:
            stable_dimensions.append("output_length")

        # --- Refusal rate ---
        bl_refusal = baseline_feat["refusal_rate"]
        cd_refusal = candidate_feat["refusal_rate"]
        refusal_change = cd_refusal - bl_refusal

        if abs(refusal_change) > 0.05:
            regressions.append({
                "dimension": "refusal_rate",
                "baseline_value": round(bl_refusal, 4),
                "candidate_value": round(cd_refusal, 4),
                "change": round(refusal_change, 4),
                "severity": "major" if abs(refusal_change) > 0.15 else "moderate" if abs(refusal_change) > 0.08 else "minor",
            })
        else:
            stable_dimensions.append("refusal_rate")

        # --- Format compliance ---
        bl_fmt = baseline_feat["format_compliance"]
        cd_fmt = candidate_feat["format_compliance"]
        fmt_change = cd_fmt - bl_fmt

        if abs(fmt_change) > 0.10:
            regressions.append({
                "dimension": "format_compliance",
                "baseline_value": round(bl_fmt, 4),
                "candidate_value": round(cd_fmt, 4),
                "change": round(fmt_change, 4),
                "severity": _severity(fmt_change),
            })
        else:
            stable_dimensions.append("format_compliance")

        # --- Score distribution ---
        score_pvalue = 1.0
        score_effect = 0.0
        bl_score_mean = statistics.mean(baseline_scores_flat) if baseline_scores_flat else 0.0
        cd_score_mean = statistics.mean(candidate_scores_flat) if candidate_scores_flat else 0.0
        if baseline_scores_flat and candidate_scores_flat:
            _, score_pvalue = _mann_whitney_u(candidate_scores_flat, baseline_scores_flat)
            score_effect = _cohens_d(candidate_scores_flat, baseline_scores_flat)

        if score_pvalue < self.significance_threshold and score_effect < 0:
            regressions.append({
                "dimension": "eval_score",
                "baseline_value": round(bl_score_mean, 4),
                "candidate_value": round(cd_score_mean, 4),
                "change": round(cd_score_mean - bl_score_mean, 4),
                "severity": _severity(score_effect),
            })
        else:
            stable_dimensions.append("eval_score")

        regression_detected = len(regressions) > 0

        # Build summary
        if regression_detected:
            parts = []
            for r in regressions:
                dim = r["dimension"]
                change = r["change"]
                if dim == "output_length":
                    parts.append(f"{abs(change):.0f} chars {'longer' if change > 0 else 'shorter'} outputs")
                elif dim == "refusal_rate":
                    parts.append(f"{abs(change)*100:.1f}% {'higher' if change > 0 else 'lower'} refusal rate")
                elif dim == "format_compliance":
                    parts.append(f"{abs(change)*100:.1f}% {'more' if change > 0 else 'less'} structured outputs")
                elif dim == "eval_score":
                    parts.append(f"{abs(change):.4f} {'lower' if change < 0 else 'higher'} eval scores")
            summary = "Candidate shows " + " and ".join(parts) + "."
        else:
            summary = (
                f"No behavioral regression detected across {len(stable_dimensions)} dimensions "
                f"(baseline n={len(baseline_runs)}, candidate n={len(candidate_runs)})."
            )

        result = {
            "regression_detected": regression_detected,
            "regressions": regressions,
            "stable_dimensions": stable_dimensions,
            "baseline_sample_size": len(baseline_runs),
            "candidate_sample_size": len(candidate_runs),
            "summary": summary,
            "behavioral_diff": {
                "output_length": {
                    "baseline_mean": round(bl_len_mean, 1),
                    "candidate_mean": round(cd_len_mean, 1),
                    "p_value": round(len_pvalue, 4),
                },
                "refusal_rate": {
                    "baseline": round(bl_refusal, 4),
                    "candidate": round(cd_refusal, 4),
                },
                "format_compliance": {
                    "baseline": round(bl_fmt, 4),
                    "candidate": round(cd_fmt, 4),
                },
                "score_distribution": {
                    "baseline_mean": round(bl_score_mean, 4),
                    "candidate_mean": round(cd_score_mean, 4),
                    "p_value": round(score_pvalue, 4),
                },
            },
        }
        self.log.info(
            "Behavioral regression: detected=%s, regressions=%s",
            regression_detected, [r["dimension"] for r in regressions],
        )

        # Push a pre-constructed Arize UI URL for the operator extra link.
        # Uses the optional arize_ax_org_space_url Airflow Variable when set.
        try:
            from airflow.models import Variable
            org_space_url = Variable.get("arize_ax_org_space_url", default_var="")
        except Exception:
            org_space_url = ""

        if org_space_url and self.dataset_id:
            exp_url = (
                f"{org_space_url.rstrip('/')}/datasets/{self.dataset_id}"
                f"/experiments/compare"
                f"?queryFilterA=&experimentId={self.baseline_experiment_id}"
                f"&experimentIdB={self.candidate_experiment_id}"
            )
        elif org_space_url and self.baseline_experiment_id:
            exp_url = (
                f"{org_space_url.rstrip('/')}/experiments/compare"
                f"?queryFilterA=&experimentId={self.baseline_experiment_id}"
            )
        else:
            exp_url = ""

        if exp_url:
            context["ti"].xcom_push(key="experiment_url", value=exp_url)

        if self.fail_on_regression and regression_detected:
            raise AirflowException(
                f"Behavioral regression gate FAILED: regression detected in "
                f"{len(regressions)} dimension(s): "
                f"{[r['dimension'] for r in regressions]}. "
                f"Summary: {result['summary']}"
            )
        return result


# ---------------------------------------------------------------------------
# Feature 4b: Eval Budget Allocator
# ---------------------------------------------------------------------------

class ArizeAxEvalBudgetAllocatorOperator(BaseOperator):
    """Distribute an evaluation budget across projects to maximise quality signal.

    For each project, computes allocation weights based on ``allocation_strategy``:

    - ``"risk_weighted"``: proportional to eval score variance (high variance projects
      need more evaluation to get reliable signal).
    - ``"volume_weighted"``: proportional to span count (more traffic = more budget).
    - ``"equal"``: equal split across all projects.

    If ``project_ids`` is ``None``, lists all projects in the space and considers all.

    Returns::

        {
            "total_budget": int,
            "allocations": [
                {"project_id": str, "allocated_spans": int, "weight": float, "rationale": str}
            ],
            "strategy": str,
            "summary": str,
        }
    """

    template_fields: Sequence[str] = ("space_id", "arize_ax_conn_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        total_budget_spans: int,
        project_ids: list[str] | None = None,
        allocation_strategy: str = "risk_weighted",
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if allocation_strategy not in ("risk_weighted", "volume_weighted", "equal"):
            raise ValueError(
                f"allocation_strategy must be 'risk_weighted', 'volume_weighted', or 'equal'; "
                f"got {allocation_strategy!r}."
            )
        self.space_id = space_id
        self.total_budget_spans = total_budget_spans
        self.project_ids = project_ids
        self.allocation_strategy = allocation_strategy
        self.arize_ax_conn_id = arize_ax_conn_id

    def execute(self, context: Any) -> dict[str, Any]:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        space_id = hook.get_space(self.space_id)

        # Resolve project list
        if self.project_ids:
            project_ids = list(self.project_ids)
        else:
            result = hook.list_projects(space_id=space_id, limit=100)
            project_ids = [
                str(p.get("id", "")) for p in result.get("items", [])
                if isinstance(p, dict) and p.get("id")
            ]

        if not project_ids:
            self.log.warning("No projects found for space %s.", space_id)
            return {
                "total_budget": self.total_budget_spans,
                "allocations": [],
                "strategy": self.allocation_strategy,
                "summary": "No projects found; budget not allocated.",
            }

        self.log.info(
            "Budget allocation: %d projects, strategy=%s, budget=%d.",
            len(project_ids), self.allocation_strategy, self.total_budget_spans,
        )

        # For each project, compute a metric for weighting
        project_metrics: list[tuple[str, float]] = []
        for pid in project_ids:
            if self.allocation_strategy == "risk_weighted":
                # Fetch recent experiments and compute score variance
                try:
                    datasets = hook.list_datasets(space_id=space_id, limit=5)
                    total_variance = 0.0
                    exp_count = 0
                    for ds in (datasets.get("items") or []):
                        ds_id = ds.get("id") if isinstance(ds, dict) else None
                        if not ds_id:
                            continue
                        exps = hook.list_experiments(dataset_id=ds_id, limit=3)
                        for exp in (exps.get("items") or []):
                            exp_id = exp.get("id") if isinstance(exp, dict) else None
                            if not exp_id:
                                continue
                            runs = _paginate_experiment_runs(hook, exp_id)
                            scores_by_metric = _extract_scores_from_runs(runs, None)
                            for scores in scores_by_metric.values():
                                if len(scores) >= 2:
                                    total_variance += statistics.variance(scores)
                                    exp_count += 1
                    metric = total_variance / exp_count if exp_count else 1.0
                except Exception:
                    metric = 1.0
            elif self.allocation_strategy == "volume_weighted":
                try:
                    spans = hook.list_spans(project_id=pid, limit=1)
                    metric = float(spans.get("count", 1) or 1)
                except Exception:
                    metric = 1.0
            else:  # equal
                metric = 1.0
            project_metrics.append((pid, max(metric, 1e-9)))

        total_weight = sum(m for _, m in project_metrics)
        allocations = []
        remaining = self.total_budget_spans
        for i, (pid, metric) in enumerate(project_metrics):
            weight = metric / total_weight
            if i == len(project_metrics) - 1:
                allocated = remaining
            else:
                allocated = max(1, round(self.total_budget_spans * weight))
                remaining -= allocated
            rationale = (
                f"Strategy: {self.allocation_strategy}. "
                f"Metric value: {metric:.4f} ({weight*100:.1f}% of total weight)."
            )
            allocations.append({
                "project_id": pid,
                "allocated_spans": allocated,
                "weight": round(weight, 4),
                "rationale": rationale,
            })

        summary = (
            f"Allocated {self.total_budget_spans} spans across {len(project_ids)} projects "
            f"using '{self.allocation_strategy}' strategy."
        )
        return {
            "total_budget": self.total_budget_spans,
            "allocations": allocations,
            "strategy": self.allocation_strategy,
            "summary": summary,
        }

