"""
Patch FileTaskHandler to use a fallback host when ti.hostname is empty (Docker / #42136).

When the worker never reports hostname to the execution API, log URLs become
http://:8793/... and the UI shows "No host supplied". This patch uses a configurable
fallback host when building the URL so logs can still be fetched from the scheduler.
"""

from __future__ import annotations

import os
from urllib.parse import urljoin


def _apply_log_url_fallback_patch() -> None:
    """Patch FileTaskHandler._get_log_retrieval_url to use fallback host when ti.hostname is empty."""
    try:
        from airflow.configuration import conf
        from airflow.utils.log.file_task_handler import FileTaskHandler
    except ImportError:
        return

    fallback_host = (
        os.environ.get("AIRFLOW_WORKER_LOG_SERVER_HOST", "").strip()
        or os.environ.get("AIRFLOW_WORKER_HOSTNAME", "airflow_scheduler").strip()
        or "airflow_scheduler"
    )
    if not fallback_host:
        return

    _original = FileTaskHandler._get_log_retrieval_url

    def _patched_get_log_retrieval_url(
        self,
        ti,
        log_relative_path: str,
        log_type=None,
    ):
        from airflow.utils.log.file_task_handler import LogType

        if log_type == LogType.TRIGGER:
            return _original(self, ti, log_relative_path, log_type=log_type)
        hostname = getattr(ti, "hostname", None)
        if hostname:
            return _original(self, ti, log_relative_path, log_type=log_type)
        # ti.hostname is empty – use fallback so URL is valid (apache/airflow#42136)
        port = conf.get("logging", "worker_log_server_port", fallback=8793)
        base = f"http://{fallback_host}:{port}/log/"
        return (urljoin(base, log_relative_path), log_relative_path)

    FileTaskHandler._get_log_retrieval_url = _patched_get_log_retrieval_url
