"""Build deep links to the Arize UI for traces, spans, and sessions.

Matches the URL format described in the arize-link skill:
https://github.com/Arize-ai/arize-skills/blob/main/skills/arize-link/SKILL.md
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Any
from urllib.parse import quote


def _epoch_ms(value: Any) -> int:
    """Convert datetime, int (ms), or float (sec) to epoch milliseconds."""
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        if value < 1e12:  # assume seconds
            return int(value * 1000)
        return int(value)
    if isinstance(value, datetime):
        return int(value.timestamp() * 1000)
    raise TypeError(f"start_time/end_time must be datetime, int, or float; got {type(value)}")


def build_trace_link(
    org_id: str,
    space_id: str,
    project_id: str,
    trace_id: str | None = None,
    span_id: str | None = None,
    session_id: str | None = None,
    start_time: int | float | datetime | None = None,
    end_time: int | float | datetime | None = None,
    base_url: str = "https://app.arize.com",
    time_zone: str = "America/Los_Angeles",
) -> str:
    """Build a deep link that opens a trace, span, or session in the Arize UI.

    The Arize UI requires startA and endA (epoch milliseconds) to load correctly;
    without them the UI may show "Your model doesn't have any recent data". Prefer
    passing start_time and end_time from your span data or a known window.

    Args:
        org_id: Base64-encoded organization ID (from Arize URL or connection extra).
        space_id: Base64-encoded space ID.
        project_id: Base64-encoded project/model ID.
        trace_id: Trace ID (for trace or span view).
        span_id: Optional span ID to highlight within the trace.
        session_id: Session ID; use for session view (alternative to trace_id).
        start_time: Start of time window (epoch ms, datetime, or seconds). Defaults to 90 days ago.
        end_time: End of time window. Defaults to now.
        base_url: Arize app base URL (override for on-prem).
        time_zone: Time zone for the UI (default America/Los_Angeles).

    Returns:
        Full URL string to open in the browser.

    Example:
        >>> url = build_trace_link(
        ...     org_id="QWNjb3VudE9yZ2FuaXphdGlvbjoxOmFiQzE=",
        ...     space_id="U3BhY2U6MTp4eVo5",
        ...     project_id="TW9kZWw6MTpkZUZn",
        ...     trace_id="0123456789abcdef",
        ...     start_time=1700000000000,
        ...     end_time=1700086400000,
        ... )
    """
    now_ms = int(time.time() * 1000)
    if start_time is None and end_time is None:
        start_ms = now_ms - (90 * 24 * 60 * 60 * 1000)
        end_ms = now_ms
    else:
        start_ms = _epoch_ms(start_time) if start_time is not None else (now_ms - (90 * 24 * 60 * 60 * 1000))
        end_ms = _epoch_ms(end_time) if end_time is not None else now_ms

    path = f"/organizations/{quote(org_id, safe='')}/spaces/{quote(space_id, safe='')}/projects/{quote(project_id, safe='')}"
    params: list[str] = [
        "queryFilterA=",
        "selectedTab=llmTracing",
        f"timeZoneA={quote(time_zone, safe='')}",
        f"startA={start_ms}",
        f"endA={end_ms}",
        "envA=tracing",
        "modelType=generative_llm",
    ]
    if session_id:
        params.append(f"selectedSessionId={quote(session_id, safe='')}")
    if trace_id:
        params.append(f"selectedTraceId={quote(trace_id, safe='')}")
    if span_id:
        params.append(f"selectedSpanId={quote(span_id, safe='')}")

    qs = "&".join(params)
    return f"{base_url.rstrip('/')}{path}?{qs}"
