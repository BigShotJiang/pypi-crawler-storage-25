# Utils for Arize AX Airflow provider (e.g. hostname callable for Docker).

from airflow.providers.arize_ax.utils.arize_links import build_trace_link  # noqa: PLC0415

__all__ = ["build_trace_link"]
