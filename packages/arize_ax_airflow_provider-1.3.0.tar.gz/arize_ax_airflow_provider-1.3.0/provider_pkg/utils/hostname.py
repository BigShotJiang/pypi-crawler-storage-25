"""
Hostname callable for Airflow when running in Docker Compose.

Use as AIRFLOW__CORE__HOSTNAME_CALLABLE=airflow.providers.arize_ax.utils.hostname.get_airflow_worker_hostname
and set AIRFLOW_WORKER_HOSTNAME to the scheduler service name (e.g. airflow_scheduler) so task log
URLs have a valid host and the api-server can fetch logs from the scheduler's log server.
"""

from __future__ import annotations

import os
import socket


def get_airflow_worker_hostname() -> str:
    """
    Return hostname for the worker (scheduler) so task log URLs are valid.

    Prefer AIRFLOW_WORKER_HOSTNAME env var so Docker Compose can set a known hostname
    (e.g. airflow_scheduler) that the api-server can reach. Fallback to socket.gethostname()
    then to a literal so the URL is never empty.
    """
    name = (os.environ.get("AIRFLOW_WORKER_HOSTNAME") or "").strip()
    if name:
        return name
    try:
        name = (socket.gethostname() or "").strip()
        if name:
            return name
    except OSError:
        pass
    return "airflow_scheduler"
