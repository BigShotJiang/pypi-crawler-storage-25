"""Return provider metadata for Airflow discovery."""

from .log_fallback import _apply_log_url_fallback_patch

# Apply once when provider info is loaded (e.g. api-server startup) so log URLs
# work when ti.hostname is empty (Docker / apache/airflow#42136).
_apply_log_url_fallback_patch()


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("arize-ax-airflow-provider")
    except Exception:
        return "1.0.0"


def get_provider_info() -> dict:
    return {
        "package-name": "arize-ax-airflow-provider",
        "name": "Arize AX",
        "description": "Airflow provider for Arize AX: operators, sensors, hooks, and links for datasets, experiments, projects, spans, and ML.",
        "version": _get_version(),
        "connection-types": [
            {
                "connection-type": "arize_ax",
                "hook-class-name": "airflow.providers.arize_ax.hooks.arize_ax.ArizeAxHook",
            }
        ],
        "hooks": [
            {
                "integration-name": "Arize AX",
                "python-modules": [
                    "airflow.providers.arize_ax.hooks.arize_ax",
                ],
            },
        ],
        "operators": [
            {
                "integration-name": "Arize AX",
                "python-modules": [
                    "airflow.providers.arize_ax.operators.ai_integrations",
                    "airflow.providers.arize_ax.operators.annotations",
                    "airflow.providers.arize_ax.operators.api_keys",
                    "airflow.providers.arize_ax.operators.datasets",
                    "airflow.providers.arize_ax.operators.evaluators",
                    "airflow.providers.arize_ax.operators.experiments",
                    "airflow.providers.arize_ax.operators.ml",
                    "airflow.providers.arize_ax.operators.projects",
                    "airflow.providers.arize_ax.operators.prompts",
                    "airflow.providers.arize_ax.operators.spaces",
                    "airflow.providers.arize_ax.operators.spans",
                    "airflow.providers.arize_ax.operators.tasks",
                ],
            },
        ],
        "sensors": [
            {
                "integration-name": "Arize AX",
                "python-modules": [
                    "airflow.providers.arize_ax.sensors.arize_ax",
                ],
            },
        ],
        "extra-links": [
            "airflow.providers.arize_ax.links.arize_ax.ArizeAxDatasetLink",
            "airflow.providers.arize_ax.links.arize_ax.ArizeAxExperimentLink",
            "airflow.providers.arize_ax.links.arize_ax.ArizeAxProjectLink",
        ],
        "integrations": [
            {
                "integration-name": "Arize AX",
                "external-doc-url": "https://arize.com/docs/ax/rest-reference",
            }
        ],
    }
