"""Operator extra links that open the relevant page in the Arize AX UI.

All links require the Airflow Variable ``arize_ax_org_space_url`` to be set
to the org/space prefix of your Arize workspace URL, e.g.:

    https://app.arize.com/organizations/<encoded_org>/spaces/<encoded_space>

Without it links fall back to ``https://app.arize.com`` (the Arize home page).
The Arize REST API does not expose organization or space URL components, so
this one-time Variable is the only way to construct deep links into the UI.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from airflow.models import BaseOperatorLink

if TYPE_CHECKING:
    from airflow.models import BaseOperator
    from airflow.models.taskinstancekey import TaskInstanceKey

ARIZE_UI_BASE = "https://app.arize.com"


def _org_space_url() -> str:
    """Return the org/space URL prefix from the Airflow Variable, or empty string."""
    try:
        from airflow.models import Variable
        return Variable.get("arize_ax_org_space_url", default_var="").rstrip("/")
    except Exception:
        return ""


class ArizeAxDatasetLink(BaseOperatorLink):
    """Link to a dataset in the Arize AX UI."""

    name = "Arize AX Dataset"

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        dataset_id = getattr(operator, "dataset_id", None)
        base = _org_space_url()
        if base and dataset_id:
            return f"{base}/datasets/{dataset_id}?selectedTab=examples"
        if dataset_id:
            return f"{ARIZE_UI_BASE}/datasets/{dataset_id}?selectedTab=examples"
        return base or ARIZE_UI_BASE


class ArizeAxExperimentLink(BaseOperatorLink):
    """Link to an experiment in the Arize AX UI."""

    name = "Arize AX Experiment"

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        # Prefer a pre-constructed URL pushed to XCom by the operator during execute()
        try:
            from airflow.models import XCom
            prebuilt = XCom.get_value(ti_key=ti_key, key="experiment_url")
        except Exception:
            prebuilt = None
        if prebuilt:
            return prebuilt

        experiment_id = (
            getattr(operator, "experiment_id", None)
            or getattr(operator, "baseline_experiment_id", None)
        )
        dataset_id = getattr(operator, "dataset_id", None)
        base = _org_space_url()

        if base:
            if dataset_id and experiment_id:
                return (
                    f"{base}/datasets/{dataset_id}/experiments/compare"
                    f"?queryFilterA=&experimentId={experiment_id}"
                )
            if dataset_id:
                return f"{base}/datasets/{dataset_id}?selectedTab=experiments"
            return base

        # Fallback when Variable is not set — no working deep link without org_id
        if dataset_id:
            return f"{ARIZE_UI_BASE}/datasets/{dataset_id}?selectedTab=experiments"
        return ARIZE_UI_BASE


class ArizeAxProjectLink(BaseOperatorLink):
    """Link to a project in the Arize AX UI."""

    name = "Arize AX Project"

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        project_id = getattr(operator, "project_id", None)
        base = _org_space_url()
        if base and project_id:
            return f"{base}/projects/{project_id}?selectedTab=llmTracing"
        if project_id:
            return f"{ARIZE_UI_BASE}/projects/{project_id}?selectedTab=llmTracing"
        return base or ARIZE_UI_BASE
