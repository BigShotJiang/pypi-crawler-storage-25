"""Arize AX Sensors for Airflow pipeline orchestration."""

from __future__ import annotations

import statistics
from typing import TYPE_CHECKING, Any, Sequence

from airflow.exceptions import AirflowException

try:
    from airflow.sdk.bases.sensor import BaseSensorOperator
except ImportError:
    from airflow.sensors.base import BaseSensorOperator

from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook

if TYPE_CHECKING:
    from airflow.utils.context import Context


class ArizeAxExperimentCompleteSensor(BaseSensorOperator):
    """Wait until an Arize AX experiment is complete.

    Strategy (in order):
    1. If the experiment object has a ``status`` field, check it against
       known terminal states.
    2. Otherwise fall back to ``experiments.list_runs()`` -- if at least
       ``min_runs`` runs exist the experiment is considered complete.
       The SDK ``run()`` method is synchronous, so runs are present as
       soon as the experiment finishes.
    """

    template_fields: Sequence[str] = ("experiment_id",)
    ui_color = "#e4f0e8"

    _TERMINAL_STATES = frozenset({"completed", "finished", "done", "failed", "error", "cancelled"})

    def __init__(
        self,
        *,
        experiment_id: str,
        min_runs: int = 1,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.experiment_id = experiment_id
        self.min_runs = min_runs
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        experiment = hook.get_experiment(experiment_id=self.experiment_id)

        status = ""
        if isinstance(experiment, dict):
            status = str(experiment.get("status", "")).lower()
        else:
            status = str(getattr(experiment, "status", "")).lower()

        if status and status in self._TERMINAL_STATES:
            self.log.info("Experiment %s status: %s (terminal)", self.experiment_id, status)
            return True

        runs = hook.list_experiment_runs(
            experiment_id=self.experiment_id,
            limit=max(self.min_runs, 1),
        )
        run_count = runs.get("count", 0) if isinstance(runs, dict) else 0
        self.log.info(
            "Experiment %s has %d runs (need >= %d)",
            self.experiment_id,
            run_count,
            self.min_runs,
        )
        return run_count >= self.min_runs


class ArizeAxDatasetReadySensor(BaseSensorOperator):
    """Wait until a dataset has at least ``min_examples`` examples.

    Uses ``datasets.list_examples()`` to retrieve the count. Optionally
    targets a specific ``dataset_version_id``.
    """

    template_fields: Sequence[str] = ("dataset_id", "dataset_version_id", "space_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        dataset_id: str,
        min_examples: int = 1,
        dataset_version_id: str | None = None,
        space_id: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.dataset_id = dataset_id
        self.min_examples = min_examples
        self.dataset_version_id = dataset_version_id
        self.space_id = space_id
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_dataset_examples(
            dataset_id=self.dataset_id,
            limit=1,
            dataset_version_id=self.dataset_version_id,
            all=True,
            space=self.space_id or hook.default_space,
        )
        count = result.get("count", 0) if isinstance(result, dict) else 0
        self.log.info(
            "Dataset %s has %d examples (need >= %d)",
            self.dataset_id,
            count,
            self.min_examples,
        )
        return count >= self.min_examples


class ArizeAxSpanCountSensor(BaseSensorOperator):
    """Wait until the span count in a project exceeds a threshold.

    Useful for gating experiment runs on having enough production data.

    .. note::
        **Page cap constraint**: The Arize spans API typically caps a single
        page at 500 items (SDK 8.24.0).  Setting ``min_count > 500`` would
        require multi-page aggregation which this sensor does not perform; it
        only issues a single ``list_spans`` call and inspects the ``count``
        field of that response.  Values above 500 are therefore rejected at
        ``__init__`` time to prevent silent false negatives.  If you need to
        gate on more than 500 spans, aggregate counts yourself in a
        PythonOperator and use a ShortCircuitOperator for the gate.
    """

    _MAX_MIN_COUNT = 500  # SDK 8.24.0 caps spans.list at 500 per page

    template_fields: Sequence[str] = ("project_id", "filter")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        min_count: int = 1,
        start_time: Any = None,
        end_time: Any = None,
        filter: str | None = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if min_count > self._MAX_MIN_COUNT:
            raise AirflowException(
                f"ArizeAxSpanCountSensor: min_count={min_count} exceeds the API page cap of "
                f"{self._MAX_MIN_COUNT}. The sensor issues a single list_spans call and reads "
                "the returned count; values above the cap would never be satisfied. "
                "To gate on more spans, aggregate counts in a PythonOperator and use a "
                "ShortCircuitOperator instead."
            )
        self.project_id = project_id
        self.min_count = min_count
        self.start_time = start_time
        self.end_time = end_time
        self.filter = filter
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        # NOTE: limit is clamped to at least 1 because limit=0 is invalid for
        # the API, but min_count=0 is a valid caller request (always-pass gate).
        result = hook.list_spans(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            filter=self.filter,
            limit=max(self.min_count, 1),
        )
        count = result.get("count", 0) if isinstance(result, dict) else 0
        self.log.info(
            "Project %s has %d spans (need >= %d)",
            self.project_id,
            count,
            self.min_count,
        )
        return count >= self.min_count


class ArizeAxEvaluationScoreSensor(BaseSensorOperator):
    """Wait until the average evaluation score for a metric meets a minimum threshold.

    On each poke, fetches up to 100 experiment runs via
    ``hook.list_experiment_runs()`` and computes the mean score across all runs
    that contain ``metric_name`` in their evaluation results.  Returns ``True``
    once the average is >= ``min_score``.

    .. note::
        This sensor fetches a single page of runs (up to 100).  If your
        experiment has more than 100 runs and you need a precise average across
        all of them, export the runs first with
        :class:`~airflow.providers.arize_ax.operators.experiments.ArizeAxExportExperimentRunsToFileOperator`
        and compute scores in a downstream PythonOperator.
    """

    template_fields: Sequence[str] = (
        "experiment_id",
        "metric_name",
        "min_score",
        "arize_ax_conn_id",
    )
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        metric_name: str,
        min_score: float,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if not (0.0 <= float(min_score) <= 1.0):
            raise AirflowException(
                f"ArizeAxEvaluationScoreSensor: min_score={min_score!r} must be in [0.0, 1.0]."
            )
        self.experiment_id = experiment_id
        self.metric_name = metric_name
        self.min_score = float(min_score)
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_experiment_runs(experiment_id=self.experiment_id, limit=100)
        items = result.get("items", []) if isinstance(result, dict) else []

        scores: list[float] = []
        for run in items:
            if not isinstance(run, dict):
                continue
            # Evaluation results may live under "evaluations", "evals", or
            # directly as top-level keys depending on the SDK serialisation path.
            evals = run.get("evaluations") or run.get("evals") or {}
            if isinstance(evals, dict):
                entry = evals.get(self.metric_name)
                if isinstance(entry, dict):
                    score = entry.get("score")
                    if score is not None:
                        try:
                            scores.append(float(score))
                        except (TypeError, ValueError):
                            pass
            elif isinstance(evals, list):
                for ev in evals:
                    if isinstance(ev, dict) and ev.get("name") == self.metric_name:
                        score = ev.get("score")
                        if score is not None:
                            try:
                                scores.append(float(score))
                            except (TypeError, ValueError):
                                pass

            # Flat "eval.{name}.score" keys may be nested inside
            # "additional_properties" depending on SDK version.
            for d in (run, run.get("additional_properties") or {}):
                score_key = f"eval.{self.metric_name}.score"
                if score_key in d and d[score_key] is not None:
                    try:
                        scores.append(float(d[score_key]))
                    except (TypeError, ValueError):
                        pass

        if not scores:
            self.log.info(
                "Experiment %s: no scores found for metric %r yet (0 runs with that metric).",
                self.experiment_id,
                self.metric_name,
            )
            return False

        avg = statistics.mean(scores)
        self.log.info(
            "Experiment %s metric %r: avg=%.4f over %d runs (need >= %.4f).",
            self.experiment_id,
            self.metric_name,
            avg,
            len(scores),
            self.min_score,
        )
        return avg >= self.min_score


class ArizeAxAnnotationQueueSensor(BaseSensorOperator):
    """Wait until at least ``min_count`` annotation configs exist in the space.

    Uses ``hook.list_annotation_configs()`` and counts the items returned.

    .. note::
        ``list_annotation_configs`` does not accept a ``space_id`` filter in
        the current Arize SDK — it returns configs for the authenticated
        space.  The ``space_id`` parameter is stored as metadata only and is
        included in ``template_fields`` so it can be rendered by Jinja if
        needed (e.g. for logging or future API support).
    """

    template_fields: Sequence[str] = ("space_id", "min_count", "arize_ax_conn_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        space_id: str | None = None,
        min_count: int = 1,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.space_id = space_id
        self.min_count = min_count
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_annotation_configs(limit=self.min_count + 1)
        count = result.get("count", 0) if isinstance(result, dict) else 0
        self.log.info(
            "Space %s annotation configs: %d visible (need >= %d).",
            self.space_id,
            count,
            self.min_count,
        )
        return count >= self.min_count


class ArizeAxSpanIngestionSensor(BaseSensorOperator):
    """Wait until span ingestion into a project has stabilised.

    Considers ingestion stable when the span count (from a single-page
    ``list_spans`` call) remains unchanged across ``stable_for_pokes``
    consecutive pokes.

    .. note::
        **Single-page heuristic**: each poke calls ``list_spans`` with
        ``limit=500`` (the API page cap) and reads the ``count`` field of
        that response.  If the true span count exceeds the API page cap, the
        returned ``count`` saturates at the page size, which means the sensor
        may declare stability earlier than expected for very large projects.
        For precise stabilisation on high-volume projects, consider aggregating
        counts in a PythonOperator instead.
    """

    _POLL_LIMIT = 500  # SDK 8.24.0 spans.list page cap; matches ArizeAxSpanCountSensor

    template_fields: Sequence[str] = ("project_id", "filter", "arize_ax_conn_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        project_id: str,
        stable_for_pokes: int = 2,
        filter: str | None = None,
        start_time: Any = None,
        end_time: Any = None,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if stable_for_pokes < 1:
            raise AirflowException(
                f"ArizeAxSpanIngestionSensor: stable_for_pokes={stable_for_pokes} must be >= 1."
            )
        self.project_id = project_id
        self.stable_for_pokes = stable_for_pokes
        self.filter = filter
        self.start_time = start_time
        self.end_time = end_time
        self.arize_ax_conn_id = arize_ax_conn_id
        # Mutable state across pokes (reset on each sensor instantiation).
        self._last_count: int | None = None
        self._stable_streak: int = 0

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_spans(
            project_id=self.project_id,
            start_time=self.start_time,
            end_time=self.end_time,
            filter=self.filter,
            limit=self._POLL_LIMIT,
        )
        count = result.get("count", 0) if isinstance(result, dict) else 0

        if count == self._last_count:
            self._stable_streak += 1
        else:
            self._stable_streak = 1
            self._last_count = count

        self.log.info(
            "Project %s span count: %d (stable streak %d/%d).",
            self.project_id,
            count,
            self._stable_streak,
            self.stable_for_pokes,
        )
        return self._stable_streak >= self.stable_for_pokes


class ArizeAxExperimentRunCountSensor(BaseSensorOperator):
    """Wait until an experiment has at least ``min_runs`` completed runs.

    On each poke, calls ``hook.list_experiment_runs()`` and checks whether the
    number of returned items satisfies the threshold.
    """

    template_fields: Sequence[str] = ("experiment_id", "min_runs", "arize_ax_conn_id")
    ui_color = "#e4f0e8"

    def __init__(
        self,
        *,
        experiment_id: str,
        min_runs: int,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if min_runs < 1:
            raise AirflowException(
                f"ArizeAxExperimentRunCountSensor: min_runs={min_runs} must be >= 1."
            )
        self.experiment_id = experiment_id
        self.min_runs = min_runs
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        result = hook.list_experiment_runs(
            experiment_id=self.experiment_id,
            limit=max(self.min_runs, 1),
        )
        count = result.get("count", 0) if isinstance(result, dict) else 0
        self.log.info(
            "Experiment %s has %d runs (need >= %d).",
            self.experiment_id,
            count,
            self.min_runs,
        )
        return count >= self.min_runs


class ArizeAxTaskRunSensor(BaseSensorOperator):
    """Wait until a task run reaches a terminal state.

    On each poke, fetches the run via ``hook.get_task_run(run_id)`` and
    checks its ``status`` field against known terminal states.

    Terminal states: ``completed``, ``failed``, ``cancelled``, ``error``,
    ``success``, ``done``, ``finished``.

    Set ``fail_on_error=True`` (default) to raise ``AirflowException`` when
    the run enters a failed/cancelled state instead of returning ``True``.
    This prevents downstream tasks from proceeding on a bad eval run.
    """

    template_fields: Sequence[str] = ("run_id",)
    ui_color = "#e4f0e8"

    _TERMINAL_STATES = frozenset({
        "completed", "success", "done", "finished",
        "failed", "error", "cancelled",
    })
    _FAILURE_STATES = frozenset({"failed", "error", "cancelled"})

    def __init__(
        self,
        *,
        run_id: str,
        fail_on_error: bool = True,
        arize_ax_conn_id: str = ArizeAxHook.default_conn_name,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.run_id = run_id
        self.fail_on_error = fail_on_error
        self.arize_ax_conn_id = arize_ax_conn_id

    def poke(self, context: Context) -> bool:
        hook = ArizeAxHook(arize_ax_conn_id=self.arize_ax_conn_id)
        run = hook.get_task_run(run_id=self.run_id)

        if isinstance(run, dict):
            status = str(run.get("status", "")).lower()
        else:
            status = str(getattr(run, "status", "")).lower()

        self.log.info("Task run %s status: %s", self.run_id, status or "(unknown)")

        if status not in self._TERMINAL_STATES:
            return False

        if self.fail_on_error and status in self._FAILURE_STATES:
            raise AirflowException(
                f"Task run {self.run_id!r} ended with status {status!r}."
            )
        return True
