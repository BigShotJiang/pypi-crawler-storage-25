"""Arize AX Hook: connection and ArizeClient delegation for Airflow tasks."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from airflow.exceptions import AirflowException

try:
    from airflow.sdk.bases.hook import BaseHook
except ImportError:
    from airflow.hooks.base import BaseHook

if TYPE_CHECKING:
    from arize import ArizeClient

log = logging.getLogger(__name__)


def _to_serializable(obj: Any) -> Any:
    """Convert Arize SDK / Pydantic response objects to JSON-serializable form for XCom.

    Prefers the SDK-generated ``to_dict()`` method when available (correctly
    unwraps oneOf wrappers to their inner fields per Arize-ai/arize#71729),
    falls back to ``model_dump(mode='json')`` for plain pydantic models, and
    handles primitives / dicts / iterables by recursion.
    """
    if obj is None:
        return None
    if hasattr(obj, "to_dict"):
        return obj.to_dict()
    if hasattr(obj, "model_dump"):
        try:
            return obj.model_dump(mode="json")
        except TypeError:
            return obj.model_dump()
    if hasattr(obj, "dict"):
        return obj.dict()
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serializable(x) for x in obj]
    if hasattr(obj, "__iter__") and not isinstance(obj, (str, bytes)):
        try:
            return [_to_serializable(x) for x in obj]
        except Exception:
            pass
    return str(obj)


def _ensure_utc_datetime(value: Any) -> Any:
    """Coerce value to an aware datetime.

    Handles three cases:
    - Already an aware datetime → returned as-is.
    - Naive datetime → UTC tzinfo attached.
    - ISO 8601 string (e.g. from Jinja template_fields) → parsed, then UTC attached if naive.
    """
    if isinstance(value, datetime):
        return value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)
    if isinstance(value, str):
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            return value  # not a datetime string; let the SDK surface the error
    return value


def _build_spans_where(
    where: str | None = None,
    trace_id: str | None = None,
    span_id: str | None = None,
    session_id: str | None = None,
) -> str | None:
    """Build a combined where clause for span export from optional filters.

    Uses the same column names as the Arize CLI / arize-trace skill:
    context.trace_id, context.span_id, attributes.session.id.
    """
    parts: list[str] = []
    if trace_id is not None:
        safe = str(trace_id).replace("\\", "\\\\").replace("'", "\\'")
        parts.append(f"context.trace_id = '{safe}'")
    if span_id is not None:
        safe = str(span_id).replace("\\", "\\\\").replace("'", "\\'")
        parts.append(f"context.span_id = '{safe}'")
    if session_id is not None:
        safe = str(session_id).replace("\\", "\\\\").replace("'", "\\'")
        parts.append(f"attributes.session.id = '{safe}'")
    combined = " AND ".join(parts) if parts else None
    if where and combined:
        return f"({where}) AND ({combined})"
    return where or combined


# Keys that Arize list APIs may use for the payload list (first match wins).
_LIST_RESPONSE_ITEM_KEYS = (
    "datasets",
    "experiments",
    "experiment_runs",
    "projects",
    "examples",
    "spans",
    "spaces",
    "annotation_configs",
    "annotation_queues",
    "records",
    "tasks",            # TasksList200Response
    "evaluators",         # EvaluatorsList200Response
    "evaluator_versions", # EvaluatorVersionsList200Response (was "versions" — wrong)
    "prompts",          # PromptsList200Response
    "api_keys",         # ApiKeysList200Response
    "ai_integrations",  # AiIntegrationsList200Response
    "data",
    "items",
)
_LIST_RESPONSE_CURSOR_KEYS = ("next_cursor", "cursor", "next_page_token")


def _structure_list_response(data: Any) -> dict[str, Any]:
    """
    Normalize list API responses to a consistent shape for XCom and downstream tasks.

    Returns: {"items": [...], "next_cursor": str | None, "count": int}
    """
    if not isinstance(data, dict):
        return {"items": [], "next_cursor": None, "count": 0}
    items: list[Any] = []
    for key in _LIST_RESPONSE_ITEM_KEYS:
        if key in data and isinstance(data[key], list):
            items = data[key]
            break
    next_cursor = None
    for key in _LIST_RESPONSE_CURSOR_KEYS:
        if key in data and data[key] is not None:
            val = data[key]
            next_cursor = str(val) if val is not None else None
            break
    return {
        "items": items,
        "next_cursor": next_cursor,
        "count": len(items),
    }


def _serialize_http_response(resp: Any) -> dict[str, Any]:
    """Convert an HTTP response (``requests.Response`` or similar) to an XCom-safe dict."""
    if hasattr(resp, "status_code"):
        result: dict[str, Any] = {
            "status_code": resp.status_code,
            "ok": getattr(resp, "ok", resp.status_code < 400),
        }
        if hasattr(resp, "json"):
            try:
                result["data"] = resp.json()
            except Exception:
                pass
        return result
    return _to_serializable(resp)


def _serialize_dataframe(df: Any) -> list[dict[str, Any]]:
    """Convert a DataFrame to a list of row dicts for XCom serialization."""
    if hasattr(df, "to_dict"):
        return df.to_dict(orient="records")
    return _to_serializable(df)


def _is_transient_flight_error(exc: Exception) -> bool:
    """Return True if *exc* is a transient gRPC / Arrow Flight error worth retrying."""
    msg = str(exc).lower()
    return any(
        pattern in msg
        for pattern in ("flightinternalerror", "flight returned internal error", "grpc", "502")
    )


def _is_experiment_init_flight_error(exc: Exception) -> bool:
    """Return True if *exc* is a Flight error during experiment INIT.

    The SDK calls ``_init_experiment_via_flight`` before any user task runs,
    so a failure at this phase means nothing has been persisted server-side
    yet — retry is idempotent. Failures AFTER init (during task execution or
    result upload) are NOT covered by this predicate, because retrying could
    create duplicate experiments.
    """
    msg = str(exc).lower()
    return (
        "internal error when creating experiment db entries" in msg
        or ("flight returned internal error" in msg and "experiment" in msg)
    )


def _run_experiment_with_retry(
    client: Any,
    kwargs: dict[str, Any],
    max_retries: int = 2,
) -> Any:
    """Call ``client.experiments.run(**kwargs)`` with retry on transient INIT errors.

    Only retries when the error matches the init-phase Flight signature (see
    ``_is_experiment_init_flight_error``). Any other failure — including
    Flight errors that occur after init — is re-raised immediately.
    """
    import time as _time

    last_exc: Exception | None = None
    for attempt in range(1 + max_retries):
        try:
            return client.experiments.run(**kwargs)
        except Exception as exc:
            if _is_experiment_init_flight_error(exc) and attempt < max_retries:
                wait = 2 ** attempt
                log.warning(
                    "Transient Flight init error on experiment run "
                    "(attempt %d/%d), retrying in %ds: %s",
                    attempt + 1,
                    1 + max_retries,
                    wait,
                    exc,
                )
                _time.sleep(wait)
                last_exc = exc
                continue
            raise
    raise last_exc  # type: ignore[misc]


def _export_to_df_with_retry(
    client: Any,
    kwargs: dict[str, Any],
    max_retries: int = 2,
) -> Any:
    """Call ``client.spans.export_to_df(**kwargs)`` with retry on transient errors.

    Returns the DataFrame on success, or ``None`` when the platform reports
    "no data".  Transient gRPC / Arrow Flight errors are retried up to
    *max_retries* times with a brief pause between attempts.
    """
    import time as _time

    last_exc: Exception | None = None
    for attempt in range(1 + max_retries):
        try:
            return client.spans.export_to_df(**kwargs)
        except Exception as exc:
            if "no data" in str(exc).lower():
                log.info("spans.export_to_df returned no data.")
                return None
            if _is_transient_flight_error(exc) and attempt < max_retries:
                wait = 2 ** attempt
                log.warning(
                    "Transient Flight/gRPC error (attempt %d/%d), retrying in %ds: %s",
                    attempt + 1,
                    1 + max_retries,
                    wait,
                    exc,
                )
                _time.sleep(wait)
                last_exc = exc
                continue
            raise
    raise last_exc  # type: ignore[misc]


def _raise_not_found_as_airflow(exc: Exception) -> None:
    """Re-raise SDK NotFoundError (arize.utils.resolve) as AirflowException."""
    try:
        from arize.utils.resolve import NotFoundError
        if isinstance(exc, NotFoundError):
            raise AirflowException(str(exc)) from exc
    except ImportError:
        pass
    raise exc


def _raise_with_experiment_hint(exc: Exception) -> None:
    """Re-raise experiment run errors with a clearer hint for backend/internal errors."""
    msg = str(exc).lower()
    is_flight_internal = (
        "flight returned internal error" in msg
        or "internal error when creating experiment db entries" in msg
    )
    if is_flight_internal:
        raise AirflowException(
            f"Arize experiment run failed with a backend error after retries: {exc!s}. "
            "The hook already retried the init-phase Flight call with exponential "
            "backoff. Since this persisted across attempts, it's likely a real "
            "backend issue rather than a transient blip — check Arize status or "
            "contact Arize support with this trace."
        ) from exc
    raise exc


class ArizeAxHook(BaseHook):
    """
    Hook for Arize AX: builds and caches ArizeClient from Airflow connection.

    Connection fields:
    - Password (or extra["api_key"]): API key (required).
    - Host (optional): API host override (e.g. api.arize.com).
    - Extra (JSON): optional space_id, region, api_scheme, etc.
    """

    conn_name_attr = "arize_ax_conn_id"
    default_conn_name = "arize_ax_default"
    conn_type = "arize_ax"
    hook_name = "Arize AX"

    def __init__(self, arize_ax_conn_id: str = default_conn_name, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.arize_ax_conn_id = arize_ax_conn_id
        self._client: ArizeClient | None = None

    def get_conn(self) -> ArizeClient:
        """Build and cache ArizeClient from connection. Lazy import of arize."""
        if self._client is not None:
            return self._client
        conn = self.get_connection(self.arize_ax_conn_id)
        api_key = conn.password or (conn.extra_dejson.get("api_key") if conn.extra_dejson else None)
        if not api_key:
            raise AirflowException("Arize AX connection missing API key (password or extra.api_key).")
        host = conn.host or (conn.extra_dejson.get("api_host") if conn.extra_dejson else None)
        extra = conn.extra_dejson or {}
        region = extra.get("region") or extra.get("extra__arize_ax__region")
        api_scheme = extra.get("api_scheme") or extra.get("extra__arize_ax__api_scheme")
        try:
            from arize import ArizeClient
        except ImportError as e:
            raise AirflowException(
                "Arize AX provider requires the Arize Python SDK v8 (ArizeClient). "
                "Install with: pip install 'arize>=8'. Note: arize 8 requires Python>=3.10. "
                f"Import error: {e}"
            ) from e

        max_past_years_raw = extra.get("max_past_years")
        max_past_years: int | None = int(max_past_years_raw) if max_past_years_raw is not None else None

        client_kwargs: dict[str, Any] = {"api_key": api_key}
        if host:
            client_kwargs["api_host"] = host
        if region:
            client_kwargs["region"] = region
        if api_scheme:
            client_kwargs["api_scheme"] = api_scheme
        if max_past_years is not None:
            client_kwargs["max_past_years"] = max_past_years
        self._client = ArizeClient(**client_kwargs)
        return self._client

    @property
    def default_space(self) -> str | None:
        """Space ID/name from connection extra 'default_space', if configured."""
        conn = self.get_connection(self.arize_ax_conn_id)
        return (conn.extra_dejson or {}).get("default_space")

    def get_space(self, space_id: str | None) -> str | None:
        """Resolve space: explicit value > connection default_space > None.

        Returns None when neither is configured — safe for ID-based SDK calls.
        Name-based lookups (e.g. dataset by name) will receive a clear SDK
        error if space is required but not provided.
        """
        return space_id or self.default_space or None

    @staticmethod
    def get_connection_form_widgets() -> dict[str, Any]:
        """Return custom widgets for connection form (extra fields)."""
        try:
            from flask_appbuilder.fieldwidgets import BS3TextFieldWidget
            from wtforms import StringField
        except ImportError:
            return {}
        return {
            "extra__arize_ax__space_id": StringField("Default Space ID", widget=BS3TextFieldWidget()),
            "extra__arize_ax__region": StringField("Region (e.g. US_CENTRAL_1A)", widget=BS3TextFieldWidget()),
            "extra__arize_ax__api_scheme": StringField("API Scheme (e.g. https)", widget=BS3TextFieldWidget()),
        }

    @staticmethod
    def get_ui_field_behaviour() -> dict[str, Any]:
        """Customize connection form field behaviour."""
        return {
            "hidden_fields": ["port", "schema", "extra"],
            "relabeling": {
                "host": "API host override (optional)",
                "login": "Login (unused)",
            },
            "placeholders": {
                "host": "api.arize.com or api.us-central-1a.arize.com",
            },
        }

    # --- Annotation Configs ---
    def list_annotation_configs(
        self,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.annotation_configs.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def create_annotation_config(
        self,
        name: str,
        space: str | None = None,
        config_type: str = "freeform",
        minimum_score: float | None = None,
        maximum_score: float | None = None,
        values: list | None = None,
        optimization_direction: str | None = None,
    ) -> Any:
        """Create an annotation config via ``client.annotation_configs.create`` (alpha)."""
        from arize.annotation_configs.client import AnnotationConfigType

        client = self.get_conn()
        resolved_space = self.get_space(space)
        kwargs: dict[str, Any] = {
            "name": name,
            "space": resolved_space,
            "config_type": AnnotationConfigType(config_type),
        }
        if minimum_score is not None:
            kwargs["minimum_score"] = minimum_score
        if maximum_score is not None:
            kwargs["maximum_score"] = maximum_score
        if values is not None:
            kwargs["values"] = values
        if optimization_direction is not None:
            kwargs["optimization_direction"] = optimization_direction
        out = client.annotation_configs.create(**kwargs)
        # annotation_configs.create returns a oneOf wrapper; unwrap to the actual instance
        actual = getattr(out, "actual_instance", out)
        return _to_serializable(actual)

    def delete_annotation_config(
        self,
        annotation_config: str,
        space: str | None = None,
    ) -> None:
        """Delete an annotation config via ``client.annotation_configs.delete`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"annotation_config": annotation_config}
        if space is not None:
            kwargs["space"] = space
        client.annotation_configs.delete(**kwargs)

    # --- Annotation Queues ---

    def list_annotation_queues(
        self,
        space: str | None = None,
        limit: int | None = 50,
        cursor: str | None = None,
        name: str | None = None,
    ) -> Any:
        """List annotation queues via ``client.annotation_queues.list`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if space is not None:
            kwargs["space"] = space
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        if name is not None:
            kwargs["name"] = name
        out = client.annotation_queues.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_annotation_queue(
        self,
        annotation_queue: str,
        space: str | None = None,
    ) -> Any:
        """Get a single annotation queue by name or ID (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"annotation_queue": annotation_queue}
        if space is not None:
            kwargs["space"] = space
        try:
            out = client.annotation_queues.get(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    def create_annotation_queue(
        self,
        name: str,
        space: str | None = None,
        annotation_config_ids: list[str] | None = None,
        annotator_emails: list[str] | None = None,
        instructions: str | None = None,
        assignment_method: str | None = None,
        record_sources: list[Any] | None = None,
    ) -> Any:
        """Create an annotation queue via ``client.annotation_queues.create`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"name": name}
        if space is not None:
            kwargs["space"] = space
        if annotation_config_ids is not None:
            kwargs["annotation_config_ids"] = annotation_config_ids
        # annotator_emails is required by the SDK; always pass it (empty list if not provided)
        kwargs["annotator_emails"] = annotator_emails if annotator_emails is not None else []
        if instructions is not None:
            kwargs["instructions"] = instructions
        if assignment_method is not None:
            kwargs["assignment_method"] = assignment_method
        if record_sources is not None:
            kwargs["record_sources"] = record_sources
        try:
            out = client.annotation_queues.create(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    def update_annotation_queue(
        self,
        annotation_queue: str,
        space: str | None = None,
        name: str | None = None,
        instructions: str | None = None,
        annotation_config_ids: list[str] | None = None,
        annotator_emails: list[str] | None = None,
    ) -> Any:
        """Update an annotation queue via ``client.annotation_queues.update`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"annotation_queue": annotation_queue}
        if space is not None:
            kwargs["space"] = space
        if name is not None:
            kwargs["name"] = name
        if instructions is not None:
            kwargs["instructions"] = instructions
        if annotation_config_ids is not None:
            kwargs["annotation_config_ids"] = annotation_config_ids
        if annotator_emails is not None:
            kwargs["annotator_emails"] = annotator_emails
        try:
            out = client.annotation_queues.update(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    def delete_annotation_queue(
        self,
        annotation_queue: str,
        space: str | None = None,
    ) -> None:
        """Delete an annotation queue via ``client.annotation_queues.delete`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"annotation_queue": annotation_queue}
        if space is not None:
            kwargs["space"] = space
        try:
            client.annotation_queues.delete(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)

    def list_annotation_queue_records(
        self,
        annotation_queue: str,
        space: str | None = None,
        limit: int | None = 100,
        cursor: str | None = None,
    ) -> Any:
        """List records in an annotation queue (server cap 500 per page; alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"annotation_queue": annotation_queue}
        if space is not None:
            kwargs["space"] = space
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        try:
            out = client.annotation_queues.list_records(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _structure_list_response(_to_serializable(out))

    def add_annotation_queue_records(
        self,
        annotation_queue: str,
        record_sources: list[Any],
        space: str | None = None,
    ) -> Any:
        """Add record sources to a queue (max 2 sources, 500 records total; alpha).

        Accepts either typed SDK instances (``AnnotationQueueRecordInput`` /
        ``AnnotationQueueExampleRecordInput`` / ``AnnotationQueueSpanRecordInput``)
        or plain dicts shaped as ``{"record_type": "example", "dataset_id": ...}``
        / ``{"record_type": "span", "project_id": ...}`` — dicts are forwarded
        through the SDK's ``AnnotationQueueRecordInput.from_dict`` discriminator.
        """
        from arize._generated.api_client.models.annotation_queue_record_input import (
            AnnotationQueueRecordInput,
        )

        client = self.get_conn()
        wrapped_sources = [
            rs if not isinstance(rs, dict) else AnnotationQueueRecordInput.from_dict(rs)
            for rs in record_sources
        ]
        kwargs: dict[str, Any] = {
            "annotation_queue": annotation_queue,
            "record_sources": wrapped_sources,
        }
        if space is not None:
            kwargs["space"] = space
        try:
            out = client.annotation_queues.add_records(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    def delete_annotation_queue_records(
        self,
        annotation_queue: str,
        record_ids: list[str],
        space: str | None = None,
    ) -> None:
        """Delete records from a queue by ID (1–100 per request; alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "annotation_queue": annotation_queue,
            "record_ids": record_ids,
        }
        if space is not None:
            kwargs["space"] = space
        try:
            client.annotation_queues.delete_records(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)

    def annotate_queue_record(
        self,
        annotation_queue: str,
        record_id: str,
        annotations: list[Any] | dict[str, Any],
        space: str | None = None,
    ) -> Any:
        """Submit annotations on a queue record via ``client.annotation_queues.annotate_record`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "annotation_queue": annotation_queue,
            "record_id": record_id,
            "annotations": annotations,
        }
        if space is not None:
            kwargs["space"] = space
        try:
            out = client.annotation_queues.annotate_record(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    def assign_queue_record(
        self,
        annotation_queue: str,
        record_id: str,
        assigned_user_emails: list[str],
        space: str | None = None,
    ) -> Any:
        """Assign a queue record to users via ``client.annotation_queues.assign_record`` (alpha)."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "annotation_queue": annotation_queue,
            "record_id": record_id,
            "assigned_user_emails": assigned_user_emails,
        }
        if space is not None:
            kwargs["space"] = space
        try:
            out = client.annotation_queues.assign_record(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)
        return _to_serializable(out)

    # --- Spaces ---
    def list_spaces(
        self,
        organization_id: str | None = None,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List spaces via ``client.spaces.list``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if organization_id is not None:
            kwargs["organization_id"] = organization_id
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.spaces.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_space_resource(self, space: str) -> Any:
        """Get a single space via ``client.spaces.get``."""
        client = self.get_conn()
        out = client.spaces.get(space=space)
        return _to_serializable(out)

    def create_space(
        self,
        name: str,
        organization_id: str,
        description: str | None = None,
    ) -> Any:
        """Create a space via ``client.spaces.create``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"name": name, "organization_id": organization_id}
        if description is not None:
            kwargs["description"] = description
        out = client.spaces.create(**kwargs)
        return _to_serializable(out)

    def update_space(
        self,
        space: str,
        name: str | None = None,
        description: str | None = None,
    ) -> Any:
        """Update a space via ``client.spaces.update``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"space": space}
        if name is not None:
            kwargs["name"] = name
        if description is not None:
            kwargs["description"] = description
        out = client.spaces.update(**kwargs)
        return _to_serializable(out)

    def delete_space(self, space: str) -> None:
        """Delete a space via ``client.spaces.delete``."""
        client = self.get_conn()
        try:
            client.spaces.delete(space=space)
        except Exception as e:
            _raise_not_found_as_airflow(e)

    # --- Datasets ---
    def list_datasets(
        self,
        space_id: str,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"space": space_id, "limit": limit or 50}
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.datasets.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def create_dataset(
        self,
        space_id: str,
        name: str,
        examples: list[dict[str, Any]] | Any,
    ) -> Any:
        client = self.get_conn()
        out = client.datasets.create(space=space_id, name=name, examples=examples)
        return _to_serializable(out)

    def get_dataset(self, dataset_id: str) -> Any:
        client = self.get_conn()
        out = client.datasets.get(dataset=dataset_id)
        return _to_serializable(out)

    def delete_dataset(self, dataset_id: str) -> None:
        client = self.get_conn()
        client.datasets.delete(dataset=dataset_id)

    def list_dataset_examples(
        self,
        dataset_id: str,
        limit: int | None = 100,
        dataset_version_id: str | None = None,
        all: bool = False,
        space: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "dataset": dataset_id,
            "limit": limit or 100,
        }
        if space is not None:
            kwargs["space"] = space
        if dataset_version_id is not None:
            kwargs["dataset_version_id"] = dataset_version_id
        if all:
            kwargs["all"] = True
        out = client.datasets.list_examples(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def export_dataset_examples_to_file(
        self,
        dataset_id: str,
        path: str | Path,
        *,
        dataset_version_id: str | None = None,
    ) -> int:
        """Export all dataset examples to a JSON file (one JSON array of objects).

        Uses the SDK's all=True mode which fetches all examples via Flight.

        Returns the total number of examples written.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        resp = self.list_dataset_examples(
            dataset_id=dataset_id,
            dataset_version_id=dataset_version_id,
            all=True,
        )
        items = resp.get("items") or []
        with path.open("w") as f:
            json.dump(items, f, indent=2)
        return len(items)

    def append_dataset_examples(
        self,
        dataset_id: str,
        examples: list[dict[str, Any]] | Any,
        dataset_version_id: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"dataset": dataset_id, "examples": examples}
        if dataset_version_id is not None:
            kwargs["dataset_version_id"] = dataset_version_id
        out = client.datasets.append_examples(**kwargs)
        return _to_serializable(out)

    def annotate_dataset_examples(
        self,
        dataset_id: str,
        annotations: list[Any],
        space: str | None = None,
    ) -> Any:
        """Batch-annotate dataset examples via ``client.datasets.annotate_examples``.

        Each annotation must include a ``record_id`` (example ID) and ``values``
        (list of dicts with ``name``, plus optionally ``score``, ``label``, ``text``).
        Up to 500 examples per request. Upsert semantics — same annotation config
        name for the same example overwrites previous value.
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"dataset": dataset_id, "annotations": annotations}
        if space is not None:
            kwargs["space"] = space
        out = client.datasets.annotate_examples(**kwargs)
        return _to_serializable(out)

    # --- Experiments ---
    def list_experiments(
        self,
        dataset_id: str,
        limit: int | None = 50,
        cursor: str | None = None,
        space: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"dataset": dataset_id, "limit": limit or 50}
        if cursor is not None:
            kwargs["cursor"] = cursor
        if space is not None:
            kwargs["space"] = space
        out = client.experiments.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def create_experiment(
        self,
        name: str,
        dataset_id: str,
        experiment_runs: list[dict[str, Any]] | Any,
        task_fields: Any | None = None,
        evaluator_columns: dict[str, Any] | None = None,
        space: str | None = None,
    ) -> Any:
        """Create an experiment with pre-computed runs.

        Note: ``task_fields`` is required by the Arize SDK (``ExperimentTaskFieldNames``).
        Omitting it will cause a validation error at the SDK level.
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "name": name,
            "dataset": dataset_id,
            "experiment_runs": experiment_runs,
            "task_fields": task_fields,
            "evaluator_columns": evaluator_columns,
        }
        if space is not None:
            kwargs["space"] = space
        out = client.experiments.create(**kwargs)
        return _to_serializable(out)

    def get_experiment(self, experiment_id: str, space: str | None = None) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"experiment": experiment_id}
        if space is not None:
            kwargs["space"] = space
        out = client.experiments.get(**kwargs)
        return _to_serializable(out)

    def delete_experiment(self, experiment_id: str, space: str | None = None) -> None:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"experiment": experiment_id}
        if space is not None:
            kwargs["space"] = space
        client.experiments.delete(**kwargs)

    def list_experiment_runs(
        self,
        experiment_id: str,
        limit: int | None = 100,
        all: bool = False,
    ) -> Any:
        """List runs for an experiment.

        Falls back to a raw REST call when the SDK's strict pydantic
        deserialization rejects the API response (e.g. when the server returns
        ``id=null`` for a run, which the generated ``ExperimentRun`` model
        currently rejects). The fallback tolerates null/missing fields so DAGs
        that just want to read run IDs keep working through SDK-side schema
        drift.
        """
        from pydantic import ValidationError

        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "experiment": experiment_id,
            "limit": limit or 100,
        }
        if all:
            kwargs["all"] = True
        try:
            out = client.experiments.list_runs(**kwargs)
            return _structure_list_response(_to_serializable(out))
        except ValidationError as exc:
            self.log.warning(
                "SDK validation failed deserializing experiments.list_runs "
                "for experiment %s: %s. Falling back to raw REST.",
                experiment_id,
                exc,
            )
            return self._list_experiment_runs_raw(
                experiment_id=experiment_id,
                limit=limit or 100,
                all=all,
            )

    def _list_experiment_runs_raw(
        self,
        experiment_id: str,
        limit: int,
        all: bool,
    ) -> dict[str, Any]:
        """Fallback for ``list_experiment_runs`` that bypasses the SDK's pydantic models.

        Hits ``GET /v2/experiments/{id}/runs`` directly and returns a dict shaped
        like the SDK response, tolerating null/missing fields in individual runs.
        """
        import requests

        conn = self.get_connection(self.arize_ax_conn_id)
        api_key = conn.password or (conn.extra_dejson or {}).get("api_key", "")
        extra = conn.extra_dejson or {}
        host = conn.host or extra.get("api_host", "api.arize.com")
        scheme = extra.get("api_scheme", "https")
        base_url = f"{scheme}://{host}/v2/experiments/{experiment_id}/runs"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
        }

        items: list[dict[str, Any]] = []
        next_cursor: str | None = None
        while True:
            params: dict[str, Any] = {"limit": limit}
            if next_cursor:
                params["cursor"] = next_cursor
            resp = requests.get(base_url, params=params, headers=headers, timeout=30)
            if resp.status_code != 200:
                try:
                    data = resp.json()
                    detail = data.get("detail", data.get("title", resp.text[:500]))
                except Exception:
                    detail = resp.text[:500]
                raise AirflowException(
                    f"Arize experiments.list_runs REST fallback failed "
                    f"(HTTP {resp.status_code}): {detail}"
                )
            data = resp.json()
            page = data.get("experiment_runs")
            if page is None:
                page = data.get("items") or []
            if isinstance(page, list):
                items.extend(page)
            pagination = data.get("pagination") or {}
            next_cursor = pagination.get("next_cursor")
            if not all or not next_cursor:
                break

        return {"items": items, "next_cursor": next_cursor, "count": len(items)}

    def export_experiment_runs_to_file(
        self,
        experiment_id: str,
        path: str | Path,
    ) -> int:
        """Export all experiment runs to a JSON file (one JSON array of run objects).

        Uses the SDK's all=True mode for bulk export.

        Returns the total number of runs written.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        resp = self.list_experiment_runs(experiment_id=experiment_id, all=True)
        items = resp.get("items") or []
        with path.open("w") as f:
            json.dump(items, f, indent=2)
        return len(items)

    def annotate_experiment_runs(
        self,
        experiment_id: str,
        annotations: list[Any],
        dataset: str | None = None,
        space: str | None = None,
    ) -> Any:
        """Batch-annotate experiment runs via ``client.experiments.annotate_runs``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"experiment": experiment_id, "annotations": annotations}
        if dataset is not None:
            kwargs["dataset"] = dataset
        if space is not None:
            kwargs["space"] = space
        out = client.experiments.annotate_runs(**kwargs)
        return _to_serializable(out)

    def run_experiment(
        self,
        name: str,
        dataset_id: str,
        task: Any,
        evaluators: list[Any] | None = None,
        concurrency: int | None = None,
        dry_run: bool = False,
        dry_run_count: int | None = None,
        exit_on_error: bool = False,
        space: str | None = None,
    ) -> Any:
        """Run an experiment via ``client.experiments.run()``.

        Returns a dict with ``experiment`` (serialized, None in dry-run mode)
        and ``dataframe_records`` (list of row dicts from the results DataFrame).
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "name": name,
            "dataset": dataset_id,
            "task": task,
        }
        if evaluators is not None:
            kwargs["evaluators"] = evaluators
        if concurrency is not None:
            kwargs["concurrency"] = concurrency
        if dry_run:
            kwargs["dry_run"] = True
        if dry_run_count is not None:
            kwargs["dry_run_count"] = dry_run_count
        if space is not None:
            kwargs["space"] = space
        if exit_on_error:
            kwargs["exit_on_error"] = True
        try:
            result = _run_experiment_with_retry(client, kwargs)
        except Exception as e:
            _raise_with_experiment_hint(e)
        # SDK returns (experiment, experiment_df) tuple
        if isinstance(result, tuple) and len(result) == 2:
            experiment_obj, experiment_df = result
            serialized: dict[str, Any] = {
                "experiment": _to_serializable(experiment_obj),
            }
            if experiment_df is not None and hasattr(experiment_df, "to_dict"):
                serialized["dataframe_records"] = experiment_df.to_dict(orient="records")
            return serialized
        return _to_serializable(result)

    # --- Projects ---
    def list_projects(
        self,
        space_id: str,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        client = self.get_conn()
        kwargs: dict[str, Any] = {"space": space_id, "limit": limit or 50}
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.projects.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def create_project(self, space_id: str, name: str) -> Any:
        client = self.get_conn()
        out = client.projects.create(space=space_id, name=name)
        return _to_serializable(out)

    def get_project(self, project_id: str) -> Any:
        client = self.get_conn()
        out = client.projects.get(project=project_id)
        return _to_serializable(out)

    def delete_project(self, project_id: str) -> None:
        client = self.get_conn()
        client.projects.delete(project=project_id)

    # --- Spans ---
    def list_spans(
        self,
        project_id: str | None = None,
        space_id: str | None = None,
        project_name: str | None = None,
        start_time: Any | None = None,
        end_time: Any | None = None,
        filter: str | None = None,
        limit: int | None = 100,
        cursor: str | None = None,
    ) -> Any:
        """List spans for a project. **ALPHA** -- API may change without notice.

        Provide either project_id (base64) or (space_id + project_name). Using
        project_name without resolving via space_id can cause 401 Unauthorized.
        """
        resolved_id = (project_id.strip() or None) if (project_id and isinstance(project_id, str)) else None
        if resolved_id is None and space_id and project_name:
            resolved_id = self._resolve_project_id_by_name(space_id, project_name)
            if resolved_id is None:
                raise AirflowException(
                    f"Could not resolve project_name={project_name!r} in space_id={space_id!r}. "
                    "Check that the project exists and the API key has access. "
                    "Alternatively pass project_id (base64) directly."
                )
        if resolved_id is None:
            raise AirflowException(
                "Must provide project_id or both space_id and project_name. "
                "Pass project_id (base64) directly, or supply both space_id and project_name "
                "so the hook can resolve it."
            )
        client = self.get_conn()
        kwargs: dict[str, Any] = {"project": resolved_id}
        if start_time is not None:
            kwargs["start_time"] = _ensure_utc_datetime(start_time)
        if end_time is not None:
            kwargs["end_time"] = _ensure_utc_datetime(end_time)
        if filter is not None:
            kwargs["filter"] = filter
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.spans.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def _resolve_project_id_by_name(self, space_id: str, project_name: str) -> str | None:
        """Resolve project name to base64 project_id via list_projects."""
        cursor: str | None = None
        while True:
            result = self.list_projects(space_id=space_id, limit=100, cursor=cursor)
            for item in result.get("items") or []:
                if isinstance(item, dict) and item.get("name") == project_name:
                    return str(item.get("id", ""))
            cursor = result.get("next_cursor")
            if not cursor:
                return None

    def log_spans(
        self,
        space_id: str,
        project_name: str,
        dataframe: Any,
        evals_dataframe: Any | None = None,
    ) -> Any:
        client = self.get_conn()
        resp = client.spans.log(
            space_id=space_id,
            project_name=project_name,
            dataframe=dataframe,
            evals_dataframe=evals_dataframe,
        )
        return _serialize_http_response(resp)

    def update_evaluations(
        self,
        space_id: str,
        project_name: str,
        dataframe: Any,
    ) -> Any:
        client = self.get_conn()
        out = client.spans.update_evaluations(
            space_id=space_id, project_name=project_name, dataframe=dataframe
        )
        return _to_serializable(out)

    def update_annotations(
        self,
        space_id: str,
        project_name: str,
        dataframe: Any,
    ) -> Any:
        client = self.get_conn()
        out = client.spans.update_annotations(
            space_id=space_id, project_name=project_name, dataframe=dataframe
        )
        return _to_serializable(out)

    def update_metadata(
        self,
        space_id: str,
        project_name: str,
        dataframe: Any,
    ) -> Any:
        client = self.get_conn()
        out = client.spans.update_metadata(
            space_id=space_id, project_name=project_name, dataframe=dataframe
        )
        return _to_serializable(out)

    def export_spans_to_df(
        self,
        space_id: str,
        project_name: str,
        start_time: Any,
        end_time: Any,
        where: str | None = None,
        columns: list[str] | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Export spans to a DataFrame. Use ``where`` and/or trace_id/span_id/session_id.

        Convenience params trace_id, span_id, session_id build a filter compatible
        with the arize-trace skill (context.trace_id, context.span_id,
        attributes.session.id). They are ANDed with any provided ``where``.
        """
        client = self.get_conn()
        effective_where = _build_spans_where(
            where=where, trace_id=trace_id, span_id=span_id, session_id=session_id
        )
        kwargs: dict[str, Any] = {
            "space_id": space_id,
            "project_name": project_name,
            "start_time": _ensure_utc_datetime(start_time),
            "end_time": _ensure_utc_datetime(end_time),
        }
        if effective_where is not None:
            kwargs["where"] = effective_where
        if columns is not None:
            kwargs["columns"] = columns
        df = _export_to_df_with_retry(client, kwargs)
        if df is None:
            return []
        return _serialize_dataframe(df)

    def export_spans_to_df_by_project_id(
        self,
        project_id: str,
        start_time: Any = None,
        end_time: Any = None,
        where: str | None = None,
        columns: list[str] | None = None,
    ) -> Any:
        """Export spans to a DataFrame using a base64 project_id directly.

        Resolves ``project_id`` to ``(space_id, project_name)`` via
        ``client.projects.get`` before calling ``spans.export_to_df``, which
        requires ``space_id`` + ``project_name`` (not ``project_id``).

        Returns a list of row dicts (serialized via ``_serialize_dataframe``).
        """
        client = self.get_conn()
        project = client.projects.get(project=project_id)
        if hasattr(project, "space_id") and hasattr(project, "name"):
            space_id = project.space_id
            project_name = project.name
        else:
            serialized = _to_serializable(project)
            space_id = serialized.get("space_id", "")
            project_name = serialized.get("name", "")
        # SDK 8.16.0 made start_time/end_time required for export_to_df.
        # Default to a 30-day window ending now when callers omit them.
        if start_time is None and end_time is None:
            _now = datetime.now(tz=timezone.utc)
            start_time = _now - timedelta(days=30)
            end_time = _now
        kwargs: dict[str, Any] = {
            "space_id": space_id,
            "project_name": project_name,
        }
        if start_time is not None:
            kwargs["start_time"] = _ensure_utc_datetime(start_time)
        if end_time is not None:
            kwargs["end_time"] = _ensure_utc_datetime(end_time)
        if where is not None:
            kwargs["where"] = where
        if columns is not None:
            kwargs["columns"] = columns
        df = _export_to_df_with_retry(client, kwargs)
        if df is None:
            return []
        return _serialize_dataframe(df)

    def export_spans_to_parquet(
        self,
        space_id: str,
        project_name: str,
        start_time: Any,
        end_time: Any,
        path: str,
        where: str | None = None,
        columns: list[str] | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
        session_id: str | None = None,
    ) -> bool:
        """Export spans to Parquet. Use ``where`` and/or trace_id/span_id/session_id.

        Convenience params are ANDed with any provided ``where`` (see export_spans_to_df).

        Returns ``True`` if a Parquet file was written, ``False`` if the SDK
        reported no data for the given filters/window (no file created).
        """
        client = self.get_conn()
        effective_where = _build_spans_where(
            where=where, trace_id=trace_id, span_id=span_id, session_id=session_id
        )
        kwargs: dict[str, Any] = {
            "space_id": space_id,
            "project_name": project_name,
            "start_time": _ensure_utc_datetime(start_time),
            "end_time": _ensure_utc_datetime(end_time),
            "path": path,
        }
        if effective_where is not None:
            kwargs["where"] = effective_where
        if columns is not None:
            kwargs["columns"] = columns
        try:
            client.spans.export_to_parquet(**kwargs)
        except Exception as exc:
            if "no data" in str(exc).lower():
                log.info("spans.export_to_parquet returned no data for the given filters/window.")
                return False
            raise
        # Arize SDK 8.27+ logs ``Query returns no data`` as a WARNING instead
        # of raising, so the exception branch above can be skipped while no
        # file is written. Treat a missing output file as a no-data result.
        if not Path(path).exists():
            log.info(
                "spans.export_to_parquet completed without raising, but %s "
                "was not written -- treating as no-data.",
                path,
            )
            return False
        return True

    # --- ML ---
    def log_ml_batch(
        self,
        space_id: str,
        model_name: str,
        model_type: Any,
        environment: Any,
        dataframe: Any,
        schema: Any,
        **kwargs: Any,
    ) -> Any:
        client = self.get_conn()
        resp = client.ml.log(
            space_id=space_id,
            model_name=model_name,
            model_type=model_type,
            environment=environment,
            dataframe=dataframe,
            schema=schema,
            **kwargs,
        )
        return _serialize_http_response(resp)

    def log_ml_stream(
        self,
        space_id: str,
        model_name: str,
        model_type: Any,
        environment: Any,
        **kwargs: Any,
    ) -> Any:
        client = self.get_conn()
        future = client.ml.log_stream(
            space_id=space_id,
            model_name=model_name,
            model_type=model_type,
            environment=environment,
            **kwargs,
        )
        if hasattr(future, "result"):
            return _serialize_http_response(future.result())
        return _to_serializable(future)

    def export_ml_to_df(
        self,
        space_id: str,
        model_name: str,
        environment: Any,
        start_time: Any,
        end_time: Any,
        where: str | None = None,
        columns: list[str] | None = None,
        **kwargs: Any,
    ) -> Any:
        client = self.get_conn()
        call_kwargs: dict[str, Any] = {
            "space_id": space_id,
            "model_name": model_name,
            "environment": environment,
            "start_time": _ensure_utc_datetime(start_time),
            "end_time": _ensure_utc_datetime(end_time),
        }
        if where is not None:
            call_kwargs["where"] = where
        if columns is not None:
            call_kwargs["columns"] = columns
        call_kwargs.update(kwargs)
        try:
            df = client.ml.export_to_df(**call_kwargs)
        except Exception as exc:
            if "no data" in str(exc).lower():
                log.info("ml.export_to_df returned no data for the given filters/window.")
                return []
            raise
        return _serialize_dataframe(df)

    def export_ml_to_parquet(
        self,
        space_id: str,
        model_name: str,
        environment: Any,
        start_time: Any,
        end_time: Any,
        path: str,
        where: str | None = None,
        columns: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        client = self.get_conn()
        call_kwargs: dict[str, Any] = {
            "space_id": space_id,
            "model_name": model_name,
            "environment": environment,
            "start_time": _ensure_utc_datetime(start_time),
            "end_time": _ensure_utc_datetime(end_time),
            "path": path,
        }
        if where is not None:
            call_kwargs["where"] = where
        if columns is not None:
            call_kwargs["columns"] = columns
        call_kwargs.update(kwargs)
        try:
            client.ml.export_to_parquet(**call_kwargs)
        except Exception as exc:
            if "no data" in str(exc).lower():
                log.info("ml.export_to_parquet returned no data for the given filters/window.")
                return
            raise

    # --- Prompts (SDK client.prompts CRUD) ---

    def list_prompts(
        self,
        space_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
    ) -> Any:
        """List prompts via ``client.prompts.list``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if space_id is not None:
            kwargs["space"] = space_id
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.prompts.list(**kwargs)
        data = _to_serializable(out)
        if not isinstance(data, dict):
            return {"items": [], "next_cursor": None, "count": 0}
        items = data.get("prompts", data.get("items", []))
        if not isinstance(items, list):
            items = []
        pagination = data.get("pagination") or {}
        next_cursor = pagination.get("next_cursor") if isinstance(pagination, dict) else None
        return {"items": items, "next_cursor": next_cursor, "count": len(items)}

    def create_prompt(
        self,
        space_id: str,
        name: str,
        messages: list[dict[str, Any]],
        provider: str,
        input_variable_format: str = "f_string",
        *,
        model: str | None = None,
        description: str | None = None,
        commit_message: str | None = None,
        invocation_params: dict[str, Any] | None = None,
        provider_params: dict[str, Any] | None = None,
    ) -> Any:
        """Create a prompt via ``client.prompts.create``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "space": space_id,
            "name": name,
            "messages": messages,
            "provider": provider,
            "input_variable_format": input_variable_format,
            "commit_message": commit_message or "Created by Airflow",
        }
        if model is not None:
            kwargs["model"] = model
        if description is not None:
            kwargs["description"] = description
        if invocation_params is not None:
            kwargs["invocation_params"] = invocation_params
        if provider_params is not None:
            kwargs["provider_params"] = provider_params
        out = client.prompts.create(**kwargs)
        return _to_serializable(out)

    def add_prompt_version(
        self,
        prompt_id: str,
        messages: list[dict[str, Any]],
        provider: str,
        input_variable_format: str = "f_string",
        *,
        model: str | None = None,
        commit_message: str | None = None,
        invocation_params: dict[str, Any] | None = None,
        provider_params: dict[str, Any] | None = None,
    ) -> Any:
        """Add a new version to an existing prompt via ``client.prompts.create_version``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {
            "prompt": prompt_id,
            "messages": messages,
            "provider": provider,
            "input_variable_format": input_variable_format,
            "commit_message": commit_message or "New version from Airflow",
        }
        if model is not None:
            kwargs["model"] = model
        if invocation_params is not None:
            kwargs["invocation_params"] = invocation_params
        if provider_params is not None:
            kwargs["provider_params"] = provider_params
        out = client.prompts.create_version(**kwargs)
        return _to_serializable(out)

    def get_prompt_by_name(
        self,
        space_id: str,
        name: str,
    ) -> Any:
        """Get a prompt by name via ``client.prompts.get``."""
        client = self.get_conn()
        out = client.prompts.get(prompt=name, space=space_id)
        return _to_serializable(out)

    def get_prompt(
        self,
        prompt_id: str,
        *,
        version_id: str | None = None,
        version_label: str | None = None,
    ) -> Any:
        """Get a prompt by ID via ``client.prompts.get``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"prompt": prompt_id}
        if version_id is not None:
            kwargs["version_id"] = version_id
        if version_label is not None:
            kwargs["label"] = version_label
        out = client.prompts.get(**kwargs)
        return _to_serializable(out)

    def delete_prompt(self, prompt_id: str) -> None:
        """Delete a prompt via ``client.prompts.delete``."""
        client = self.get_conn()
        client.prompts.delete(prompt=prompt_id)

    def promote_prompt(
        self,
        space_id: str,
        prompt_id: str,
        label: str,
        version_id: str | None = None,
    ) -> None:
        """Apply a label to a prompt version via the SDK ``prompts.set_labels``.

        If ``version_id`` is None, the latest version is resolved first via
        ``client.prompts.get``. Labels are set (replaced) on the target version
        using ``client.prompts.set_labels(version_id=..., labels=[label])``.
        """
        client = self.get_conn()
        if version_id is None:
            prompt = client.prompts.get(prompt=prompt_id)
            version_id = str(prompt.version.id)
        client.prompts.set_labels(version_id=version_id, labels=[label])

    def optimize_prompt(
        self,
        prompt: str,
        dataset: Any,
        *,
        output_column: str = "output",
        feedback_columns: list[str] | None = None,
        model_choice: str = "gpt-4o",
        openai_api_key: str | None = None,
        context_size_k: int = 8000,
    ) -> dict[str, Any]:
        """Run meta-prompt optimization via the Arize Prompt Learning SDK.

        Requires the ``prompt-learning-enhanced`` SDK (git source — PyPI does
        not accept direct-URL deps, so this is installed separately rather
        than as an optional extra)::

            pip install 'arize-phoenix-evals>=2.0,<3.0' \\
                        'prompt-learning-enhanced @ git+https://github.com/Arize-ai/prompt-learning.git'

        Returns a dict with:
            - ``messages``: list[{"role", "content"}] — the optimized prompt
              normalized as a single ``system`` message (always present).
            - ``content``: str — the optimized system-prompt text.
            - ``raw``: the SDK's raw return value (string or list).
            - ``model_choice``: model that produced the optimization.
        """
        try:
            from optimizer_sdk.prompt_learning_optimizer import (
                PromptLearningOptimizer,
            )
        except ImportError as exc:
            raise AirflowException(
                "Arize Prompt Learning SDK is required for optimize_prompt. "
                "Install with: pip install 'arize-phoenix-evals>=2.0,<3.0' "
                "'prompt-learning-enhanced @ git+https://github.com/Arize-ai/prompt-learning.git' "
                "(Python 3.12+ recommended). See "
                "https://github.com/Arize-ai/prompt-learning"
            ) from exc

        optimizer = PromptLearningOptimizer(
            prompt=prompt,
            model_choice=model_choice,
            openai_api_key=openai_api_key,
        )
        optimized = optimizer.optimize(
            dataset=dataset,
            output_column=output_column,
            feedback_columns=list(feedback_columns or ["feedback"]),
            context_size_k=context_size_k,
        )

        content = ""
        if isinstance(optimized, str):
            content = optimized
        elif isinstance(optimized, list):
            for m in optimized:
                if isinstance(m, dict) and (m.get("role") or "").lower() == "system":
                    content = m.get("content") or ""
                    break
            if not content and optimized:
                first = optimized[0]
                if isinstance(first, dict):
                    content = first.get("content") or ""

        content = (content or "").strip()
        if not content:
            raise AirflowException(
                "Prompt Learning SDK returned an empty optimized prompt."
            )
        return {
            "messages": [{"role": "system", "content": content}],
            "content": content,
            "raw": optimized,
            "model_choice": model_choice,
        }

    # --- Evaluators (SDK -- template and code LLM judges; alpha) ---

    def list_evaluators(
        self,
        space_id: str | None = None,
        *,
        limit: int = 50,
        cursor: str | None = None,
        name_search: str | None = None,
    ) -> Any:
        """List evaluators via ``client.evaluators.list`` (alpha).

        When ``space_id`` is set, results are limited to that space.
        """
        import requests

        conn = self.get_connection(self.arize_ax_conn_id)
        api_key = conn.password or (conn.extra_dejson or {}).get("api_key", "")
        extra = conn.extra_dejson or {}
        host = conn.host or extra.get("api_host", "api.arize.com")
        scheme = extra.get("api_scheme", "https")
        url = f"{scheme}://{host}/v2/evaluators"
        headers = {"Authorization": f"Bearer {api_key}"}
        params: dict[str, Any] = {}
        if space_id is not None:
            params["space_id"] = space_id
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if name_search is not None:
            params["name"] = name_search
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            items = data.get("evaluators", data.get("items", []))
            if not isinstance(items, list):
                items = []
            pagination = data.get("pagination", {})
            next_cursor = pagination.get("next_cursor")
            return {
                "items": items,
                "next_cursor": next_cursor,
                "count": len(items),
            }
        try:
            data = resp.json()
            detail = data.get("detail", data.get("title", resp.text[:500]))
        except Exception:
            detail = resp.text[:500]
        raise AirflowException(f"Arize Evaluators API error (HTTP {resp.status_code}): {detail}")

    def create_evaluator(
        self,
        space_id: str,
        name: str,
        evaluator_type: str = "template",
        *,
        commit_message: str,
        template_config: dict[str, Any] | None = None,
        code_config: Any | None = None,
        description: str | None = None,
    ) -> Any:
        """Create an evaluator with an initial version via the SDK.

        Migrated from REST to SDK in 8.23.0.

        Args:
            space_id: Space global ID (base64) or name.
            name: Unique evaluator name within the space.
            evaluator_type: ``"template"`` (default) for LLM-as-judge evaluators,
                or ``"code"`` for managed/custom code evaluators.
            commit_message: Version commit message.
            template_config: Required when ``evaluator_type="template"``. Dict or
                ``TemplateConfig`` object with ``name``, ``template``, ``llm_config``,
                etc. The ``template`` string must use single-brace placeholders
                (e.g. ``{input}``, ``{output}``), not doubled braces.
            code_config: Required when ``evaluator_type="code"``. A ``CodeConfig``
                instance wrapping either ``ManagedCodeConfig`` or ``CustomCodeConfig``.
            description: Optional evaluator description.

        Returns:
            Serialized evaluator-with-version dict.
        """
        if evaluator_type == "template":
            if template_config is None:
                raise ValueError("template_config is required for evaluator_type='template'")
        elif evaluator_type == "code":
            if code_config is None:
                raise ValueError("code_config is required for evaluator_type='code'")
        else:
            raise ValueError(
                f'evaluator_type must be "template" or "code"; got {evaluator_type!r}'
            )
        client = self.get_conn()
        if evaluator_type == "template":
            kwargs: dict[str, Any] = {
                "name": name,
                "space": space_id,
                "commit_message": commit_message,
                "template_config": template_config,
            }
            if description is not None:
                kwargs["description"] = description
            out = client.evaluators.create_template_evaluator(**kwargs)
        else:
            kwargs = {
                "name": name,
                "space": space_id,
                "commit_message": commit_message,
                "code_config": code_config,
            }
            if description is not None:
                kwargs["description"] = description
            out = client.evaluators.create_code_evaluator(**kwargs)
        return _to_serializable(out)

    def update_evaluator(
        self,
        evaluator_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> Any:
        """Update evaluator metadata via ``client.evaluators.update``.

        At least one of ``name`` or ``description`` must be provided. This does
        not change the evaluator template or code; use :meth:`add_evaluator_version`
        for a new version.
        """
        if name is None and description is None:
            raise ValueError("Provide at least one of name or description.")
        client = self.get_conn()
        kwargs: dict[str, Any] = {"evaluator": evaluator_id}
        if name is not None:
            kwargs["name"] = name
        if description is not None:
            kwargs["description"] = description
        out = client.evaluators.update(**kwargs)
        return _to_serializable(out)

    def add_evaluator_version(
        self,
        evaluator_id: str,
        *,
        commit_message: str,
        version_type: str = "template",
        template_config: dict[str, Any] | None = None,
        code_config: Any | None = None,
        space: str | None = None,
    ) -> Any:
        """Add a new version to an existing evaluator via the SDK.

        Migrated from REST to SDK in 8.23.0. Supports both template and code versions.

        Args:
            evaluator_id: Evaluator global ID (base64).
            commit_message: Commit message for this version.
            version_type: ``"template"`` (default) or ``"code"``.
            template_config: Required when ``version_type="template"``.
            code_config: Required when ``version_type="code"``. A ``CodeConfig``
                instance wrapping ``ManagedCodeConfig`` or ``CustomCodeConfig``.
            space: Optional space name or ID (passed to SDK when resolving by name).

        Returns:
            Serialized evaluator version dict.
        """
        if version_type == "template":
            if template_config is None:
                raise ValueError("template_config is required for version_type='template'")
        elif version_type == "code":
            if code_config is None:
                raise ValueError("code_config is required for version_type='code'")
        else:
            raise ValueError(
                f'version_type must be "template" or "code"; got {version_type!r}'
            )
        client = self.get_conn()
        kwargs: dict[str, Any] = {"evaluator": evaluator_id, "commit_message": commit_message}
        if space is not None:
            kwargs["space"] = space
        if version_type == "template":
            kwargs["template_config"] = template_config
            out = client.evaluators.create_template_version(**kwargs)
        else:
            kwargs["code_config"] = code_config
            out = client.evaluators.create_code_version(**kwargs)
        return _to_serializable(out)

    def get_evaluator(self, evaluator_id: str) -> Any:
        """Get an evaluator by ID via ``client.evaluators.get``."""
        client = self.get_conn()
        out = client.evaluators.get(evaluator=evaluator_id)
        return _to_serializable(out)

    def delete_evaluator(self, evaluator_id: str) -> None:
        """Delete an evaluator via ``client.evaluators.delete``."""
        client = self.get_conn()
        client.evaluators.delete(evaluator=evaluator_id)

    def list_evaluator_versions(
        self,
        evaluator_id: str,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List versions of an evaluator via ``client.evaluators.list_versions``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"evaluator": evaluator_id}
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.evaluators.list_versions(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_evaluator_version(self, version_id: str) -> Any:
        """Get a specific evaluator version via ``client.evaluators.get_version``."""
        client = self.get_conn()
        out = client.evaluators.get_version(version_id=version_id)
        return _to_serializable(out)

    # --- Tasks ---

    def list_tasks(
        self,
        space_id: str | None = None,
        project_id: str | None = None,
        dataset_id: str | None = None,
        task_type: str | None = None,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List evaluation tasks via ``client.tasks.list``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if space_id is not None:
            kwargs["space"] = space_id
        if project_id is not None:
            kwargs["project"] = project_id
        if dataset_id is not None:
            kwargs["dataset"] = dataset_id
        if task_type is not None:
            kwargs["task_type"] = task_type
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.tasks.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_task(self, task_id: str) -> Any:
        """Get a single evaluation task via ``client.tasks.get``."""
        client = self.get_conn()
        out = client.tasks.get(task=task_id)
        return _to_serializable(out)

    def create_task(
        self,
        name: str,
        task_type: str,
        evaluators: list[Any] | None = None,
        project_id: str | None = None,
        dataset_id: str | None = None,
        experiment_ids: list[str] | None = None,
        sampling_rate: float | None = None,
        is_continuous: bool | None = None,
        query_filter: str | None = None,
    ) -> Any:
        """Create an evaluation task via ``client.tasks.create_evaluation_task``.

        Args:
            task_type: Must be ``"template_evaluation"`` or ``"code_evaluation"``
                (SDK 8.15.0+).  The value ``"llm"`` is no longer accepted.
            evaluators: List of evaluator dicts, each with an ``"evaluator_id"`` key,
                e.g. ``[{"evaluator_id": "RXZhbHVhdG9y..."}]``.  Plain string IDs and
                ``{"id": ...}`` dicts are rejected by the SDK pydantic model
                (``BaseEvaluationTaskRequestEvaluatorsInner``).

        Note: SDK 8.23.0 split ``client.tasks.create`` into type-specific methods.
        For ``template_evaluation`` / ``code_evaluation`` task types we now call
        ``client.tasks.create_evaluation_task``. The new ``run_experiment`` task
        type has its own ``create_run_experiment_task`` method (not wrapped here).
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"name": name, "task_type": task_type}
        if evaluators is not None:
            kwargs["evaluators"] = evaluators
        if project_id is not None:
            kwargs["project"] = project_id
        if dataset_id is not None:
            kwargs["dataset"] = dataset_id
        if experiment_ids is not None:
            kwargs["experiment_ids"] = experiment_ids
        if sampling_rate is not None:
            kwargs["sampling_rate"] = sampling_rate
        if is_continuous is not None:
            kwargs["is_continuous"] = is_continuous
        if query_filter is not None:
            kwargs["query_filter"] = query_filter
        out = client.tasks.create_evaluation_task(**kwargs)
        return _to_serializable(out)

    def list_task_runs(
        self,
        task_id: str,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List runs for an evaluation task via ``client.tasks.list_runs``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"task": task_id}
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.tasks.list_runs(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_task_run(self, run_id: str) -> Any:
        """Get a single task run via ``client.tasks.get_run``."""
        client = self.get_conn()
        out = client.tasks.get_run(run_id=run_id)
        return _to_serializable(out)

    def trigger_task_run(
        self,
        task_id: str,
        space_id: str | None = None,
        data_start_time: Any = None,
        data_end_time: Any = None,
        max_spans: int | None = None,
        override_evaluations: bool | None = None,
        experiment_ids: list[str] | None = None,
        experiment_name: str | None = None,
        dataset_version_id: str | None = None,
        max_examples: int | None = None,
        tracing_metadata: dict[str, Any] | None = None,
    ) -> Any:
        """Trigger an on-demand evaluation run via ``client.tasks.trigger_run``.

        Two task-type modes share this method:
        - **template_evaluation** (span-scoped): ``data_start_time``,
          ``data_end_time``, ``max_spans`` apply.
        - **run_experiment** (dataset-scoped): ``experiment_name``,
          ``dataset_version_id``, ``max_examples``, ``tracing_metadata`` apply.
          The SDK rejects ``data_start_time`` / ``data_end_time`` for this
          task type with ``ValueError("Fields not valid for run_experiment
          tasks…")``, so we skip the default 30-day window when any
          run_experiment-only param is provided.

        Returns the created TaskRun serialized as a dict.
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"task": task_id}
        space = self.get_space(space_id)
        if space is not None:
            kwargs["space"] = space

        is_run_experiment_mode = any(
            p is not None for p in (
                experiment_name, dataset_version_id, max_examples, tracing_metadata,
            )
        )

        if is_run_experiment_mode:
            if experiment_name is not None:
                kwargs["experiment_name"] = experiment_name
            if dataset_version_id is not None:
                kwargs["dataset_version_id"] = dataset_version_id
            if max_examples is not None:
                kwargs["max_examples"] = max_examples
            if tracing_metadata is not None:
                kwargs["tracing_metadata"] = tracing_metadata
        else:
            # template_evaluation mode. The Arize SDK defaults
            # data_start_time / data_end_time to epoch 0 (1970-01-01) when
            # neither kwarg is present, which causes a 400 "No data found"
            # error. The API also enforces a 30-day maximum window.
            if data_start_time is None and data_end_time is None:
                _now = datetime.now(tz=timezone.utc)
                kwargs["data_start_time"] = _now - timedelta(days=30)
                kwargs["data_end_time"] = _now
            else:
                if data_start_time is not None:
                    kwargs["data_start_time"] = _ensure_utc_datetime(data_start_time)
                if data_end_time is not None:
                    kwargs["data_end_time"] = _ensure_utc_datetime(data_end_time)
            if max_spans is not None:
                kwargs["max_spans"] = max_spans

        if override_evaluations is not None:
            kwargs["override_evaluations"] = override_evaluations
        if experiment_ids is not None:
            kwargs["experiment_ids"] = experiment_ids
        out = client.tasks.trigger_run(**kwargs)
        return _to_serializable(out)

    def cancel_task_run(self, run_id: str) -> Any:
        """Cancel a pending or running task run via ``client.tasks.cancel_run``."""
        client = self.get_conn()
        out = client.tasks.cancel_run(run_id=run_id)
        return _to_serializable(out)

    def create_run_experiment_task(
        self,
        name: str,
        dataset_id: str,
        run_configuration: Any,
        space: str | None = None,
    ) -> Any:
        """Create a run_experiment task via ``client.tasks.create_run_experiment_task``.

        Arize drives LLM calls server-side using the supplied ``run_configuration``
        (a typed ``RunConfiguration`` SDK object or an equivalent dict — dicts
        are forwarded through the SDK's ``RunConfiguration.from_dict``
        discriminator).
        """
        from arize._generated.api_client import RunConfiguration

        client = self.get_conn()
        if isinstance(run_configuration, dict):
            run_configuration = RunConfiguration.from_dict(run_configuration)
        kwargs: dict[str, Any] = {
            "name": name,
            "dataset": dataset_id,
            "run_configuration": run_configuration,
        }
        if space is not None:
            kwargs["space"] = space
        out = client.tasks.create_run_experiment_task(**kwargs)
        return _to_serializable(out)

    def update_task(
        self,
        task_id: str,
        space: str | None = None,
        name: str | None = None,
        sampling_rate: float | None = None,
        is_continuous: bool | None = None,
        query_filter: str | None = None,
        clear_query_filter: bool = False,
        evaluators: list[Any] | None = None,
        run_configuration: Any | None = None,
    ) -> Any:
        """Update mutable task fields via ``client.tasks.update``.

        SDK uses a _MISSING sentinel pattern — fields are only updated when
        explicitly passed.  The hook converts None → omit (leave unchanged).
        Pass ``clear_query_filter=True`` to actually clear the filter (sends
        ``None`` to the SDK, which clears the server-side filter).
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"task": task_id}
        if space is not None:
            kwargs["space"] = space
        if name is not None:
            kwargs["name"] = name
        if sampling_rate is not None:
            kwargs["sampling_rate"] = sampling_rate
        if is_continuous is not None:
            kwargs["is_continuous"] = is_continuous
        if clear_query_filter:
            kwargs["query_filter"] = None
        elif query_filter is not None:
            kwargs["query_filter"] = query_filter
        if evaluators is not None:
            kwargs["evaluators"] = evaluators
        if run_configuration is not None:
            kwargs["run_configuration"] = run_configuration
        out = client.tasks.update(**kwargs)
        return _to_serializable(out)

    def delete_task(self, task_id: str, space: str | None = None) -> None:
        """Delete a task via ``client.tasks.delete``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"task": task_id}
        if space is not None:
            kwargs["space"] = space
        try:
            client.tasks.delete(**kwargs)
        except Exception as exc:
            _raise_not_found_as_airflow(exc)

    # --- AI Integrations ---

    def list_ai_integrations(
        self,
        space_id: str | None = None,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List AI integrations via ``client.ai_integrations.list``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if space_id is not None:
            kwargs["space"] = space_id
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.ai_integrations.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def get_ai_integration(self, integration_id: str) -> Any:
        """Get a single AI integration via ``client.ai_integrations.get``."""
        client = self.get_conn()
        out = client.ai_integrations.get(integration=integration_id)
        return _to_serializable(out)

    def create_ai_integration(
        self,
        name: str,
        provider: str,
        space: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        model_names: list[str] | None = None,
        headers: dict[str, str] | None = None,
        enable_default_models: bool | None = None,
        function_calling_enabled: bool | None = None,
        auth_type: str | None = None,
        provider_metadata: dict[str, Any] | None = None,
        scopings: list[Any] | None = None,
    ) -> Any:
        """Create an AI integration via ``client.ai_integrations.create``.

        Note: ``space`` is intentionally NOT forwarded to ``client.ai_integrations.create``
        because the SDK signature (as of 8.24.0) does not accept it on create;
        org/space scoping is set via the ``scopings`` field instead.
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"name": name, "provider": provider}
        if api_key is not None:
            kwargs["api_key"] = api_key
        if base_url is not None:
            kwargs["base_url"] = base_url
        if model_names is not None:
            kwargs["model_names"] = model_names
        if headers is not None:
            kwargs["headers"] = headers
        if enable_default_models is not None:
            kwargs["enable_default_models"] = enable_default_models
        if function_calling_enabled is not None:
            kwargs["function_calling_enabled"] = function_calling_enabled
        if auth_type is not None:
            kwargs["auth_type"] = auth_type
        if provider_metadata is not None:
            kwargs["provider_metadata"] = provider_metadata
        if scopings is not None:
            kwargs["scopings"] = scopings
        out = client.ai_integrations.create(**kwargs)
        return _to_serializable(out)

    def update_ai_integration(
        self,
        integration: str,
        space: str | None = None,
        name: str | None = None,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        model_names: list[str] | None = None,
        headers: dict[str, str] | None = None,
        enable_default_models: bool | None = None,
        function_calling_enabled: bool | None = None,
        auth_type: str | None = None,
        provider_metadata: dict[str, Any] | None = None,
        scopings: list[Any] | None = None,
    ) -> Any:
        """Update an AI integration via ``client.ai_integrations.update``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"integration": integration}
        if space is not None:
            kwargs["space"] = space
        if name is not None:
            kwargs["name"] = name
        if provider is not None:
            kwargs["provider"] = provider
        if api_key is not None:
            kwargs["api_key"] = api_key
        if base_url is not None:
            kwargs["base_url"] = base_url
        if model_names is not None:
            kwargs["model_names"] = model_names
        if headers is not None:
            kwargs["headers"] = headers
        if enable_default_models is not None:
            kwargs["enable_default_models"] = enable_default_models
        if function_calling_enabled is not None:
            kwargs["function_calling_enabled"] = function_calling_enabled
        if auth_type is not None:
            kwargs["auth_type"] = auth_type
        if provider_metadata is not None:
            kwargs["provider_metadata"] = provider_metadata
        if scopings is not None:
            kwargs["scopings"] = scopings
        out = client.ai_integrations.update(**kwargs)
        return _to_serializable(out)

    def delete_ai_integration(
        self,
        integration: str,
        space: str | None = None,
    ) -> None:
        """Delete an AI integration via ``client.ai_integrations.delete``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"integration": integration}
        if space is not None:
            kwargs["space"] = space
        try:
            client.ai_integrations.delete(**kwargs)
        except Exception as e:
            _raise_not_found_as_airflow(e)

    # --- API Keys ---
    def list_api_keys(
        self,
        key_type: str | None = None,
        status: str | None = None,
        limit: int | None = 50,
        cursor: str | None = None,
    ) -> Any:
        """List API keys via ``client.api_keys.list``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {}
        if key_type is not None:
            kwargs["key_type"] = key_type
        if status is not None:
            kwargs["status"] = status
        if limit is not None:
            kwargs["limit"] = limit
        if cursor is not None:
            kwargs["cursor"] = cursor
        out = client.api_keys.list(**kwargs)
        return _structure_list_response(_to_serializable(out))

    def create_api_key(
        self,
        name: str,
        description: str | None = None,
        expires_at: Any | None = None,
    ) -> Any:
        """Create an API key via ``client.api_keys.create``.

        SDK 8.27+ accepts only ``name``, ``description``, ``expires_at`` —
        ``key_type`` and ``space_id`` are no longer kwargs on the client method.
        """
        client = self.get_conn()
        kwargs: dict[str, Any] = {"name": name}
        if description is not None:
            kwargs["description"] = description
        if expires_at is not None:
            kwargs["expires_at"] = _ensure_utc_datetime(expires_at)
        out = client.api_keys.create(**kwargs)
        return _to_serializable(out)

    def delete_api_key(self, api_key_id: str) -> None:
        """Delete an API key via ``client.api_keys.delete``."""
        client = self.get_conn()
        try:
            client.api_keys.delete(api_key_id=api_key_id)
        except Exception as e:
            _raise_not_found_as_airflow(e)

    def refresh_api_key(
        self,
        api_key_id: str,
        expires_at: Any | None = None,
    ) -> Any:
        """Refresh an API key via ``client.api_keys.refresh``."""
        client = self.get_conn()
        kwargs: dict[str, Any] = {"api_key_id": api_key_id}
        if expires_at is not None:
            kwargs["expires_at"] = _ensure_utc_datetime(expires_at)
        out = client.api_keys.refresh(**kwargs)
        return _to_serializable(out)



