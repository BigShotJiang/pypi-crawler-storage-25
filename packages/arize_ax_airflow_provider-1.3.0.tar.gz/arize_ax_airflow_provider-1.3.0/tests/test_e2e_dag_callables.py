"""Unit tests for helper callables in the E2E DAG.

These callables are the "glue" that passes XCom data between operators in
``example_arize_ax_e2e_dag.py``.  Because they run inside PythonOperators,
they have zero test coverage unless tested here explicitly.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag import (
    INSPECTION_WINDOW_MINUTES,
    VERIFY_TASK_IDS,
    _echo_task,
    _exact_match_evaluator,
    _inspection_pause,
    _verify_results,
)

VERIFY_TASK_COUNT = len(VERIFY_TASK_IDS)

HOOK_MODULE = "airflow.providers.arize_ax.hooks.arize_ax"


# ---------------------------------------------------------------------------
# _echo_task
# ---------------------------------------------------------------------------
class TestEchoTask:

    def test_echoes_expected_output(self):
        result = _echo_task({"expected_output": "Paris"})
        assert result == {"output": "Paris"}

    def test_missing_expected_output_falls_back(self):
        result = _echo_task({"query": "hello"})
        assert result == {"output": "no-answer"}

    def test_empty_example(self):
        result = _echo_task({})
        assert result == {"output": "no-answer"}


# ---------------------------------------------------------------------------
# _exact_match_evaluator
# ---------------------------------------------------------------------------
class TestExactMatchEvaluator:

    def test_correct_match(self):
        result = _exact_match_evaluator(
            {"expected_output": "Paris"},
            {"output": "Paris"},
        )
        assert result.score == 1.0
        assert result.label == "correct"
        assert isinstance(result.explanation, str)

    def test_incorrect_match(self):
        result = _exact_match_evaluator(
            {"expected_output": "Paris"},
            {"output": "London"},
        )
        assert result.score == 0.0
        assert result.label == "incorrect"
        assert isinstance(result.explanation, str)

    def test_missing_output_key(self):
        result = _exact_match_evaluator(
            {"expected_output": "Paris"},
            {},
        )
        assert result.score == 0.0
        assert result.label == "incorrect"

    def test_both_missing_is_mismatch(self):
        """Missing output key yields None while missing expected defaults to '' -- no match."""
        result = _exact_match_evaluator({}, {})
        assert result.score == 0.0
        assert result.label == "incorrect"

    def test_explanation_contains_values(self):
        result = _exact_match_evaluator(
            {"expected_output": "Paris"},
            {"output": "London"},
        )
        assert "Paris" in result.explanation
        assert "London" in result.explanation


# ---------------------------------------------------------------------------
# _verify_results
# ---------------------------------------------------------------------------
class TestVerifyResults:

    def test_counts_all_non_none_xcoms(self):
        ti = MagicMock()
        # Every task in VERIFY_TASK_IDS returns a non-None value.
        ti.xcom_pull.side_effect = lambda task_ids: f"value-for-{task_ids}"
        result = _verify_results(ti=ti)
        assert result["passed"] == VERIFY_TASK_COUNT
        assert result["total"] == VERIFY_TASK_COUNT

    def test_counts_with_some_none(self):
        ti = MagicMock()
        # Only three of the expected tasks return non-None.
        non_none = set(VERIFY_TASK_IDS[:3])
        ti.xcom_pull.side_effect = lambda task_ids: (
            f"v-{task_ids}" if task_ids in non_none else None
        )
        result = _verify_results(ti=ti)
        assert result["passed"] == 3
        assert result["total"] == VERIFY_TASK_COUNT

    def test_all_none(self):
        ti = MagicMock()
        ti.xcom_pull.return_value = None
        result = _verify_results(ti=ti)
        assert result["passed"] == 0
        assert result["total"] == VERIFY_TASK_COUNT

    def test_returns_checks_dict(self):
        ti = MagicMock()
        ti.xcom_pull.return_value = None
        result = _verify_results(ti=ti)
        assert isinstance(result["checks"], dict)
        assert len(result["checks"]) == VERIFY_TASK_COUNT
        # Sanity: every VERIFY_TASK_IDS entry appears as a key.
        assert set(result["checks"].keys()) == set(VERIFY_TASK_IDS)




class TestInspectionPause:
    """Tests for _inspection_pause -- the configurable sleep before cleanup."""

    @staticmethod
    def _make_ctx(minutes: int | None = None) -> dict:
        params = {}
        if minutes is not None:
            params["inspection_minutes"] = minutes
        return {"params": params}

    @patch("airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag.time.sleep")
    def test_sleeps_for_configured_minutes(self, mock_sleep):
        ctx = self._make_ctx(minutes=5)
        _inspection_pause(**ctx)
        mock_sleep.assert_called_once_with(5 * 60)

    @patch("airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag.time.sleep")
    def test_zero_minutes_skips_sleep(self, mock_sleep):
        ctx = self._make_ctx(minutes=0)
        _inspection_pause(**ctx)
        mock_sleep.assert_not_called()

    @patch("airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag.time.sleep")
    def test_negative_clamped_to_zero(self, mock_sleep):
        ctx = self._make_ctx(minutes=-3)
        _inspection_pause(**ctx)
        mock_sleep.assert_not_called()

    @patch("airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag.time.sleep")
    def test_uses_default_when_param_missing(self, mock_sleep):
        ctx = self._make_ctx()  # no inspection_minutes param
        _inspection_pause(**ctx)
        mock_sleep.assert_called_once_with(INSPECTION_WINDOW_MINUTES * 60)

    @patch("airflow.providers.arize_ax.example_dags.example_arize_ax_e2e_dag.time.sleep")
    def test_string_param_coerced_to_int(self, mock_sleep):
        ctx = self._make_ctx(minutes="3")
        _inspection_pause(**ctx)
        mock_sleep.assert_called_once_with(3 * 60)
