"""
Layer-contract tests: verify that params accepted at one layer (operator/sensor)
are correctly forwarded to the next layer (hook -> SDK).

These tests exist to catch cross-layer forwarding gaps, e.g. a sensor accepting
space_id but silently dropping it before passing to the hook.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from airflow.providers.arize_ax.hooks.arize_ax import ArizeAxHook
from airflow.providers.arize_ax.operators.annotations import (
    ArizeAxCreateAnnotationConfigOperator,
    ArizeAxDeleteAnnotationConfigOperator,
    ArizeAxListAnnotationQueuesOperator,
)
from airflow.providers.arize_ax.operators.datasets import ArizeAxListDatasetsOperator
from airflow.providers.arize_ax.operators.experiments import (
    ArizeAxRunExperimentOperator,
)
from airflow.providers.arize_ax.sensors.arize_ax import (
    ArizeAxAnnotationQueueSensor,
    ArizeAxDatasetReadySensor,
    ArizeAxExperimentCompleteSensor,
    ArizeAxSpanCountSensor,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_arize_client():
    client = MagicMock()
    client.datasets = MagicMock()
    client.experiments = MagicMock()
    client.projects = MagicMock()
    client.spans = MagicMock()
    client.annotation_configs = MagicMock()
    client.annotation_queues = MagicMock()
    return client


@pytest.fixture
def mock_connection():
    conn = MagicMock()
    conn.conn_id = "arize_ax_default"
    conn.password = "test-api-key"
    conn.host = None
    conn.extra_dejson = {}
    return conn


# ---------------------------------------------------------------------------
# Sensor: ArizeAxExperimentCompleteSensor
# ---------------------------------------------------------------------------


class TestExperimentCompleteSensorForwarding:
    """experiment_id must reach hook.get_experiment and hook.list_experiment_runs."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_experiment_id_forwarded_to_get_experiment(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        # Return a non-terminal status so we fall through to list_runs
        mock_arize_client.experiments.get.return_value = MagicMock(status="running")
        mock_arize_client.experiments.list_runs.return_value = MagicMock()

        sensor = ArizeAxExperimentCompleteSensor(
            task_id="sensor",
            experiment_id="exp-123",
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.experiments.get.call_args[1]
        assert call_kw["experiment"] == "exp-123", (
            "experiment_id must be forwarded as kwarg 'experiment' to client.experiments.get"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_experiment_id_forwarded_to_list_runs(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        # Return an object whose status attribute is empty string so we fall through
        exp_obj = MagicMock()
        exp_obj.status = ""
        mock_arize_client.experiments.get.return_value = exp_obj
        mock_arize_client.experiments.list_runs.return_value = MagicMock()

        sensor = ArizeAxExperimentCompleteSensor(
            task_id="sensor",
            experiment_id="exp-456",
            min_runs=2,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.experiments.list_runs.call_args[1]
        assert call_kw["experiment"] == "exp-456", (
            "experiment_id must be forwarded as kwarg 'experiment' to client.experiments.list_runs"
        )


# ---------------------------------------------------------------------------
# Sensor: ArizeAxDatasetReadySensor
# ---------------------------------------------------------------------------


class TestDatasetReadySensorForwarding:
    """
    Verify that every parameter accepted by ArizeAxDatasetReadySensor
    reaches client.datasets.list_examples with the correct kwarg name.

    The original bug: space_id was accepted by the sensor but never forwarded,
    so dataset-by-name lookups silently dropped the space.
    """

    @patch.object(ArizeAxHook, "default_space", new_callable=lambda: property(lambda self: None))
    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_id_forwarded_as_dataset_kwarg(self, mock_get_conn, _mock_default_space, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        sensor = ArizeAxDatasetReadySensor(
            task_id="sensor",
            dataset_id="ds-999",
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert call_kw["dataset"] == "ds-999", (
            "dataset_id must be forwarded as kwarg 'dataset' to client.datasets.list_examples"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_id_forwarded_as_space_kwarg(self, mock_get_conn, mock_arize_client):
        """This is the regression test for the original space_id forwarding bug."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        sensor = ArizeAxDatasetReadySensor(
            task_id="sensor",
            dataset_id="ds-001",
            space_id="space-abc",
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert "space" in call_kw, (
            "space_id accepted by ArizeAxDatasetReadySensor must be forwarded as kwarg 'space' "
            "to client.datasets.list_examples — this was the original forwarding bug"
        )
        assert call_kw["space"] == "space-abc", (
            f"Expected space='space-abc', got space={call_kw.get('space')!r}"
        )

    @patch.object(ArizeAxHook, "default_space", new_callable=lambda: property(lambda self: None))
    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_version_id_forwarded_when_set(self, mock_get_conn, _mock_default_space, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        sensor = ArizeAxDatasetReadySensor(
            task_id="sensor",
            dataset_id="ds-002",
            dataset_version_id="v-007",
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert call_kw.get("dataset_version_id") == "v-007", (
            "dataset_version_id must be forwarded to client.datasets.list_examples "
            "when it is set on the sensor"
        )

    @patch.object(ArizeAxHook, "default_space", new_callable=lambda: property(lambda self: None))
    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_version_id_omitted_when_none(self, mock_get_conn, _mock_default_space, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        sensor = ArizeAxDatasetReadySensor(
            task_id="sensor",
            dataset_id="ds-003",
            dataset_version_id=None,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert "dataset_version_id" not in call_kw, (
            "dataset_version_id=None should not be forwarded to client.datasets.list_examples"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_id_none_falls_back_to_hook_default_space(
        self, mock_get_conn, mock_arize_client
    ):
        """When space_id is None, the sensor passes hook.default_space (may be None too)."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        with patch.object(ArizeAxHook, "default_space", new_callable=lambda: property(lambda self: None)):
            sensor = ArizeAxDatasetReadySensor(
                task_id="sensor",
                dataset_id="ds-004",
                space_id=None,
                poke_interval=5,
                timeout=60,
            )
            sensor.poke(context={})

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        # When both sensor.space_id and hook.default_space are None, space kwarg should be None
        assert "space" in call_kw or call_kw.get("space") is None


# ---------------------------------------------------------------------------
# Sensor: ArizeAxSpanCountSensor
# ---------------------------------------------------------------------------


class TestSpanCountSensorForwarding:
    """project_id must reach client.spans.list as kwarg 'project'."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_project_id_forwarded_as_project_kwarg(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.spans.list.return_value = MagicMock()

        sensor = ArizeAxSpanCountSensor(
            task_id="sensor",
            project_id="proj-xyz",
            min_count=1,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.spans.list.call_args[1]
        assert call_kw["project"] == "proj-xyz", (
            "project_id must be forwarded as kwarg 'project' to client.spans.list"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_filter_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.spans.list.return_value = MagicMock()

        sensor = ArizeAxSpanCountSensor(
            task_id="sensor",
            project_id="proj-abc",
            filter="latency > 100",
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.spans.list.call_args[1]
        assert call_kw.get("filter") == "latency > 100", (
            "filter param must be forwarded to client.spans.list"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_filter_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.spans.list.return_value = MagicMock()

        sensor = ArizeAxSpanCountSensor(
            task_id="sensor",
            project_id="proj-abc",
            filter=None,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.spans.list.call_args[1]
        assert "filter" not in call_kw, (
            "filter=None should not be forwarded to client.spans.list"
        )


# ---------------------------------------------------------------------------
# Sensor: ArizeAxAnnotationQueueSensor
# ---------------------------------------------------------------------------


class TestAnnotationQueueSensorForwarding:
    """Annotation queue sensor delegates to hook.list_annotation_configs (no space filter in SDK)."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_poke_calls_annotation_configs_list(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.annotation_configs.list.return_value = MagicMock()

        sensor = ArizeAxAnnotationQueueSensor(
            task_id="sensor",
            space_id="sp-1",
            min_count=2,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        mock_arize_client.annotation_configs.list.assert_called_once()

    @patch.object(ArizeAxHook, "get_conn")
    def test_min_count_plus_one_used_as_limit(self, mock_get_conn, mock_arize_client):
        """Sensor uses min_count+1 as limit so it can detect when the threshold is met."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.annotation_configs.list.return_value = MagicMock()

        sensor = ArizeAxAnnotationQueueSensor(
            task_id="sensor",
            space_id="sp-1",
            min_count=3,
            poke_interval=5,
            timeout=60,
        )
        sensor.poke(context={})

        call_kw = mock_arize_client.annotation_configs.list.call_args[1]
        assert call_kw.get("limit") == 4, (
            "ArizeAxAnnotationQueueSensor should pass limit=min_count+1 to list_annotation_configs"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK spot-checks: list_dataset_examples
# ---------------------------------------------------------------------------


class TestHookListDatasetExamplesSDKKwargs:
    """Verify kwarg names used by hook.list_dataset_examples match the SDK contract."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_id_forwarded_as_dataset(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.list_dataset_examples(dataset_id="d1", space="sp1")

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert call_kw["dataset"] == "d1"
        assert call_kw["space"] == "sp1"

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_forwarded_correctly(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.list_dataset_examples(dataset_id="d1", space="sp1")

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        assert call_kw["space"] == "sp1", (
            "space must be forwarded as kwarg 'space' to client.datasets.list_examples"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.list_examples.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.list_dataset_examples(dataset_id="d1")

        call_kw = mock_arize_client.datasets.list_examples.call_args[1]
        # space=None is the default; hook should omit the kwarg when None
        assert "space" not in call_kw, (
            "space=None should not be forwarded to client.datasets.list_examples"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK spot-checks: create_annotation_config
# ---------------------------------------------------------------------------


class TestHookCreateAnnotationConfigSDKKwargs:
    """Verify kwarg names for annotation config creation match the SDK contract."""

    @patch.object(ArizeAxHook, "get_conn")
    @patch("arize.annotation_configs.client.AnnotationConfigType")
    def test_name_space_config_type_forwarded(
        self, mock_config_type_cls, mock_get_conn, mock_arize_client
    ):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.annotation_configs.create.return_value = MagicMock(actual_instance=None)

        with patch.object(ArizeAxHook, "get_space", return_value="sp1"):
            hook = ArizeAxHook(arize_ax_conn_id="test")
            hook.create_annotation_config(name="n", space="sp1", config_type="freeform")

        call_kw = mock_arize_client.annotation_configs.create.call_args[1]
        assert call_kw["name"] == "n"
        assert call_kw["space"] == "sp1"


# ---------------------------------------------------------------------------
# Hook -> SDK spot-checks: create_annotation_queue
# ---------------------------------------------------------------------------


class TestHookCreateAnnotationQueueSDKKwargs:
    """Verify kwarg names for annotation queue creation match the SDK contract."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_and_annotator_emails_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.annotation_queues.create.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_annotation_queue(
            name="q",
            space="sp1",
            annotation_config_ids=["c1"],
            annotator_emails=[],
        )

        call_kw = mock_arize_client.annotation_queues.create.call_args[1]
        assert call_kw["space"] == "sp1", (
            "space must be forwarded as kwarg 'space' to client.annotation_queues.create"
        )
        assert call_kw["annotator_emails"] == [], (
            "annotator_emails must always be forwarded (empty list is a valid value)"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_annotation_config_ids_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.annotation_queues.create.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_annotation_queue(
            name="q",
            space="sp1",
            annotation_config_ids=["c1", "c2"],
            annotator_emails=["a@b.com"],
        )

        call_kw = mock_arize_client.annotation_queues.create.call_args[1]
        assert call_kw["annotation_config_ids"] == ["c1", "c2"]


# ---------------------------------------------------------------------------
# Hook -> SDK spot-checks: delete_annotation_config
# ---------------------------------------------------------------------------


class TestHookDeleteAnnotationConfigSDKKwargs:
    """Verify delete_annotation_config forwards the correct kwarg names."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_annotation_config_and_space_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_annotation_config("cfg1", space="sp1")

        call_kw = mock_arize_client.annotation_configs.delete.call_args[1]
        assert call_kw["annotation_config"] == "cfg1", (
            "annotation_config must be forwarded as kwarg 'annotation_config' "
            "to client.annotation_configs.delete"
        )
        assert call_kw["space"] == "sp1", (
            "space must be forwarded as kwarg 'space' to client.annotation_configs.delete"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_annotation_config("cfg1")

        call_kw = mock_arize_client.annotation_configs.delete.call_args[1]
        assert "space" not in call_kw, (
            "space=None should not be forwarded to client.annotation_configs.delete"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK spot-checks: get_space resolution
# ---------------------------------------------------------------------------


class TestHookGetSpaceResolution:
    """Verify the get_space fallback chain works correctly."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_explicit_space_id_returned(self, mock_get_conn, mock_connection):
        mock_get_conn.return_value = MagicMock()
        mock_connection.extra_dejson = {"default_space": "default-sp"}

        with patch.object(ArizeAxHook, "get_connection", return_value=mock_connection):
            hook = ArizeAxHook(arize_ax_conn_id="test")
            result = hook.get_space("explicit-sp")

        assert result == "explicit-sp", (
            "Explicit space_id must be returned as-is by get_space"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_none_falls_back_to_default_space(self, mock_get_conn, mock_connection):
        mock_get_conn.return_value = MagicMock()
        mock_connection.extra_dejson = {"default_space": "sp2"}

        with patch.object(ArizeAxHook, "get_connection", return_value=mock_connection):
            hook = ArizeAxHook(arize_ax_conn_id="test")
            result = hook.get_space(None)

        assert result == "sp2", (
            "get_space(None) must fall back to connection's default_space"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_none_with_no_default_returns_none(self, mock_get_conn, mock_connection):
        """get_space returns None (not raises) when neither space_id nor default_space is set."""
        mock_get_conn.return_value = MagicMock()
        mock_connection.extra_dejson = {}

        with patch.object(ArizeAxHook, "get_connection", return_value=mock_connection):
            hook = ArizeAxHook(arize_ax_conn_id="test")
            assert hook.get_space(None) is None


# ---------------------------------------------------------------------------
# Operator -> Hook: ArizeAxCreateAnnotationConfigOperator
# ---------------------------------------------------------------------------


class TestCreateAnnotationConfigOperatorForwarding:
    """Verify operator fields are forwarded to hook.create_annotation_config."""

    def test_name_space_config_type_reach_hook(self):
        op = ArizeAxCreateAnnotationConfigOperator(
            task_id="op",
            name="my-config",
            space="sp-op",
            config_type="categorical",
        )
        with patch(
            "airflow.providers.arize_ax.operators.annotations.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.create_annotation_config.return_value = {"id": "c1"}

            op.execute(context={"ti": MagicMock()})

        call_kw = mock_hook.create_annotation_config.call_args[1]
        assert call_kw["name"] == "my-config"
        assert call_kw["space"] == "sp-op"
        assert call_kw["config_type"] == "categorical"

    def test_optional_fields_forwarded_when_set(self):
        op = ArizeAxCreateAnnotationConfigOperator(
            task_id="op",
            name="scored-config",
            space="sp-op",
            config_type="continuous",
            minimum_score=0.0,
            maximum_score=1.0,
            optimization_direction="maximize",
        )
        with patch(
            "airflow.providers.arize_ax.operators.annotations.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.create_annotation_config.return_value = {"id": "c2"}

            op.execute(context={"ti": MagicMock()})

        call_kw = mock_hook.create_annotation_config.call_args[1]
        assert call_kw["minimum_score"] == 0.0
        assert call_kw["maximum_score"] == 1.0
        assert call_kw["optimization_direction"] == "maximize"


# ---------------------------------------------------------------------------
# Operator -> Hook: ArizeAxDeleteAnnotationConfigOperator
# ---------------------------------------------------------------------------


class TestDeleteAnnotationConfigOperatorForwarding:
    """Verify operator fields are forwarded to hook.delete_annotation_config."""

    def test_annotation_config_and_space_reach_hook(self):
        op = ArizeAxDeleteAnnotationConfigOperator(
            task_id="op",
            annotation_config="cfg-to-delete",
            space="sp-delete",
        )
        with patch(
            "airflow.providers.arize_ax.operators.annotations.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.delete_annotation_config.return_value = None

            op.execute(context={})

        call_kw = mock_hook.delete_annotation_config.call_args[1]
        assert call_kw["annotation_config"] == "cfg-to-delete", (
            "annotation_config param must reach hook.delete_annotation_config"
        )
        assert call_kw["space"] == "sp-delete", (
            "space param must reach hook.delete_annotation_config"
        )


# ---------------------------------------------------------------------------
# Operator -> Hook: ArizeAxListDatasetsOperator
# ---------------------------------------------------------------------------


class TestListDatasetsOperatorForwarding:
    """Verify space_id flows through hook.get_space before reaching hook.list_datasets."""

    def test_space_id_resolved_and_forwarded(self):
        op = ArizeAxListDatasetsOperator(
            task_id="op",
            space_id="sp-list",
            limit=25,
        )
        with patch(
            "airflow.providers.arize_ax.operators.datasets.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.get_space.return_value = "sp-list"
            mock_hook.list_datasets.return_value = {"items": [], "count": 0}

            op.execute(context={})

        mock_hook.get_space.assert_called_once_with("sp-list")
        call_kw = mock_hook.list_datasets.call_args[1]
        assert call_kw["space_id"] == "sp-list", (
            "resolved space_id must be forwarded to hook.list_datasets"
        )

    def test_none_space_id_delegates_resolution_to_hook(self):
        """When space_id=None, the operator delegates resolution to hook.get_space."""
        op = ArizeAxListDatasetsOperator(
            task_id="op",
            space_id=None,
        )
        with patch(
            "airflow.providers.arize_ax.operators.datasets.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.get_space.return_value = "resolved-from-conn"
            mock_hook.list_datasets.return_value = {"items": [], "count": 0}

            op.execute(context={})

        mock_hook.get_space.assert_called_once_with(None)
        call_kw = mock_hook.list_datasets.call_args[1]
        assert call_kw["space_id"] == "resolved-from-conn"


# ---------------------------------------------------------------------------
# Operator -> Hook: ArizeAxListAnnotationQueuesOperator
# ---------------------------------------------------------------------------


class TestListAnnotationQueuesOperatorForwarding:
    """space param must reach hook.list_annotation_queues."""

    def test_space_forwarded(self):
        op = ArizeAxListAnnotationQueuesOperator(
            task_id="op",
            space="sp-queues",
            limit=10,
        )
        with patch(
            "airflow.providers.arize_ax.operators.annotations.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.list_annotation_queues.return_value = {"items": [], "count": 0}

            op.execute(context={})

        call_kw = mock_hook.list_annotation_queues.call_args[1]
        assert call_kw["space"] == "sp-queues", (
            "space must be forwarded to hook.list_annotation_queues"
        )

    def test_name_filter_forwarded(self):
        op = ArizeAxListAnnotationQueuesOperator(
            task_id="op",
            name="review-queue",
        )
        with patch(
            "airflow.providers.arize_ax.operators.annotations.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.list_annotation_queues.return_value = {"items": [], "count": 0}

            op.execute(context={})

        call_kw = mock_hook.list_annotation_queues.call_args[1]
        assert call_kw["name"] == "review-queue", (
            "name filter must be forwarded to hook.list_annotation_queues"
        )


# ---------------------------------------------------------------------------
# Operator -> Hook: ArizeAxRunExperimentOperator space_id forwarding
# ---------------------------------------------------------------------------

_SPACE = "sp-cicd-test"


class TestRunExperimentOperatorForwarding:
    """space_id on ArizeAxRunExperimentOperator must reach hook.run_experiment as space=."""

    def test_space_id_forwarded_to_hook(self):
        def _task(example):
            return {"output": "ok"}

        op = ArizeAxRunExperimentOperator(
            task_id="run_exp",
            name="test-run",
            dataset_id="ds-1",
            task=_task,
            space_id=_SPACE,
        )
        with patch(
            "airflow.providers.arize_ax.operators.experiments.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.get_space.return_value = _SPACE
            mock_hook.run_experiment.return_value = {"experiment": None, "dataframe_records": []}

            op.execute(context={"ti": MagicMock()})

        mock_hook.get_space.assert_called_once_with(_SPACE)
        call_kw = mock_hook.run_experiment.call_args[1]
        assert call_kw.get("space") == _SPACE, (
            f"space_id={_SPACE!r} must be forwarded as space={_SPACE!r} to hook.run_experiment; "
            f"got space={call_kw.get('space')!r}"
        )

    def test_space_id_none_delegates_to_get_space(self):
        """When space_id=None, get_space(None) is still called so the connection default applies."""
        def _task(example):
            return {}

        op = ArizeAxRunExperimentOperator(
            task_id="run_exp_none",
            name="test-run-none",
            dataset_id="ds-2",
            task=_task,
            space_id=None,
        )
        with patch(
            "airflow.providers.arize_ax.operators.experiments.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.get_space.return_value = "resolved-default"
            mock_hook.run_experiment.return_value = {"experiment": None, "dataframe_records": []}

            op.execute(context={"ti": MagicMock()})

        mock_hook.get_space.assert_called_once_with(None)
        call_kw = mock_hook.run_experiment.call_args[1]
        assert call_kw.get("space") == "resolved-default", (
            "When space_id=None, hook.get_space(None) result must be forwarded as space="
        )

    def test_space_id_in_template_fields(self):
        """space_id must be listed in template_fields so Jinja can render it."""
        assert "space_id" in ArizeAxRunExperimentOperator.template_fields, (
            "space_id must be in ArizeAxRunExperimentOperator.template_fields"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: experiment methods space forwarding
# ---------------------------------------------------------------------------


class TestExperimentHookSpaceForwarding:
    """Verify space param is forwarded to client.experiments.* when provided."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_run_experiment_space_forwarded_to_sdk(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        exp_mock = MagicMock()
        df_mock = MagicMock()
        df_mock.to_dict.return_value = []
        mock_arize_client.experiments.run.return_value = (exp_mock, df_mock)

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.run_experiment(
            name="exp-run",
            dataset_id="ds-1",
            task=lambda x: x,
            space="sp1",
        )

        call_kw = mock_arize_client.experiments.run.call_args[1]
        assert call_kw.get("space") == "sp1", (
            "space must be forwarded to client.experiments.run when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_run_experiment_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        exp_mock = MagicMock()
        df_mock = MagicMock()
        df_mock.to_dict.return_value = []
        mock_arize_client.experiments.run.return_value = (exp_mock, df_mock)

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.run_experiment(
            name="exp-run-none",
            dataset_id="ds-1",
            task=lambda x: x,
            space=None,
        )

        call_kw = mock_arize_client.experiments.run.call_args[1]
        assert "space" not in call_kw, (
            "space=None must not be forwarded to client.experiments.run"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_list_experiments_space_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.list.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.list_experiments(dataset_id="ds-1", space="sp1")

        call_kw = mock_arize_client.experiments.list.call_args[1]
        assert call_kw.get("space") == "sp1", (
            "space must be forwarded to client.experiments.list when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_list_experiments_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.list.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.list_experiments(dataset_id="ds-1", space=None)

        call_kw = mock_arize_client.experiments.list.call_args[1]
        assert "space" not in call_kw, (
            "space=None must not be forwarded to client.experiments.list"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_get_experiment_space_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.get.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.get_experiment(experiment_id="exp-1", space="sp1")

        call_kw = mock_arize_client.experiments.get.call_args[1]
        assert call_kw.get("space") == "sp1", (
            "space must be forwarded to client.experiments.get when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_get_experiment_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.get.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.get_experiment(experiment_id="exp-1", space=None)

        call_kw = mock_arize_client.experiments.get.call_args[1]
        assert "space" not in call_kw, (
            "space=None must not be forwarded to client.experiments.get"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_delete_experiment_space_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_experiment(experiment_id="exp-1", space="sp1")

        call_kw = mock_arize_client.experiments.delete.call_args[1]
        assert call_kw.get("space") == "sp1", (
            "space must be forwarded to client.experiments.delete when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_delete_experiment_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_experiment(experiment_id="exp-1", space=None)

        call_kw = mock_arize_client.experiments.delete.call_args[1]
        assert "space" not in call_kw, (
            "space=None must not be forwarded to client.experiments.delete"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_create_experiment_space_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.create.return_value = MagicMock(id="exp-new")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_experiment(
            name="exp-create",
            dataset_id="ds-1",
            experiment_runs=[],
            space="sp1",
        )

        call_kw = mock_arize_client.experiments.create.call_args[1]
        assert call_kw.get("space") == "sp1", (
            "space must be forwarded to client.experiments.create when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_create_experiment_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.create.return_value = MagicMock(id="exp-new")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_experiment(
            name="exp-create-none",
            dataset_id="ds-1",
            experiment_runs=[],
            space=None,
        )

        call_kw = mock_arize_client.experiments.create.call_args[1]
        assert "space" not in call_kw, (
            "space=None must not be forwarded to client.experiments.create"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: create_run_experiment_task
# ---------------------------------------------------------------------------


class TestHookCreateRunExperimentTaskSDKKwargs:
    """Verify create_run_experiment_task forwards correct kwarg names to the SDK."""

    _MIN_DICT_CFG = {
        "experiment_type": "llm_generation",
        "ai_integration_id": "ai-1",
        "model_name": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "hi"}],
        "input_variable_format": "mustache",
    }

    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_kwarg_name(self, mock_get_conn, mock_arize_client):
        """Hook param ``dataset_id`` must reach the SDK as ``dataset=``."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.create_run_experiment_task.return_value = MagicMock(id="t-new")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_run_experiment_task(
            name="n",
            dataset_id="ds-99",
            run_configuration=self._MIN_DICT_CFG,
        )
        kw = mock_arize_client.tasks.create_run_experiment_task.call_args[1]
        assert kw["dataset"] == "ds-99", (
            "hook param dataset_id must reach SDK as kwarg 'dataset'"
        )
        assert "dataset_id" not in kw, (
            "SDK kwarg must be 'dataset', not 'dataset_id'"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_run_configuration_dict_forwarded_via_from_dict(
        self, mock_get_conn, mock_arize_client
    ):
        """A plain ``LlmGenerationRunConfig``-shaped dict must be forwarded to
        the SDK as a typed ``RunConfiguration`` (SDK 8.27+ handles the
        discriminator via ``RunConfiguration.from_dict``)."""
        from arize._generated.api_client import (
            LlmGenerationRunConfig,
            RunConfiguration,
        )

        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.create_run_experiment_task.return_value = MagicMock(id="t-new")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_run_experiment_task(name="n", dataset_id="d", run_configuration=self._MIN_DICT_CFG)
        kw = mock_arize_client.tasks.create_run_experiment_task.call_args[1]
        forwarded = kw["run_configuration"]
        assert isinstance(forwarded, RunConfiguration), (
            "run_configuration dict must reach the SDK as a typed RunConfiguration"
        )
        assert isinstance(forwarded.actual_instance, LlmGenerationRunConfig), (
            "RunConfiguration.actual_instance must be the typed LlmGenerationRunConfig"
        )
        assert forwarded.actual_instance.ai_integration_id == "ai-1"

    @patch.object(ArizeAxHook, "get_conn")
    def test_run_configuration_typed_instance_passes_through(self, mock_get_conn, mock_arize_client):
        """Already-typed ``RunConfiguration`` instances must pass through unchanged."""
        from arize._generated.api_client import LlmGenerationRunConfig, RunConfiguration

        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.create_run_experiment_task.return_value = MagicMock(id="t-new")

        typed_cfg = RunConfiguration(actual_instance=LlmGenerationRunConfig(**self._MIN_DICT_CFG))
        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_run_experiment_task(name="n", dataset_id="d", run_configuration=typed_cfg)
        kw = mock_arize_client.tasks.create_run_experiment_task.call_args[1]
        assert kw["run_configuration"] is typed_cfg

    @patch.object(ArizeAxHook, "get_conn")
    def test_run_configuration_invalid_dict_raises_from_sdk(
        self, mock_get_conn, mock_arize_client
    ):
        """A dict that can't be discriminated raises the SDK's own ValueError."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        with pytest.raises(Exception):  # SDK raises ValueError; surfaced to caller
            hook.create_run_experiment_task(name="n", dataset_id="d", run_configuration={})

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.create_run_experiment_task.return_value = MagicMock(id="t-new")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_run_experiment_task(name="n", dataset_id="d", run_configuration=self._MIN_DICT_CFG)
        kw = mock_arize_client.tasks.create_run_experiment_task.call_args[1]
        assert "space" not in kw, (
            "space=None must not be forwarded to client.tasks.create_run_experiment_task"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: update_task
# ---------------------------------------------------------------------------


class TestHookUpdateTaskSDKKwargs:
    """Verify update_task forwards correct kwarg names and omits unset fields."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_task_kwarg_name(self, mock_get_conn, mock_arize_client):
        """Hook param ``task_id`` must reach the SDK as ``task=``."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.update.return_value = MagicMock(id="t-1")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_task(task_id="t-1", name="NewName")
        kw = mock_arize_client.tasks.update.call_args[1]
        assert kw["task"] == "t-1", (
            "hook param task_id must reach SDK as kwarg 'task'"
        )
        assert "task_id" not in kw, (
            "SDK kwarg must be 'task', not 'task_id'"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_only_set_fields_forwarded(self, mock_get_conn, mock_arize_client):
        """Only explicitly set fields must appear in the SDK call_args."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.update.return_value = MagicMock(id="t-1")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_task(task_id="t-1", name="OnlyName")
        kw = mock_arize_client.tasks.update.call_args[1]
        assert "name" in kw
        assert "sampling_rate" not in kw, "sampling_rate=None must not be forwarded"
        assert "is_continuous" not in kw, "is_continuous=None must not be forwarded"
        assert "evaluators" not in kw, "evaluators=None must not be forwarded"
        assert "run_configuration" not in kw, "run_configuration=None must not be forwarded"

    @patch.object(ArizeAxHook, "get_conn")
    def test_clear_query_filter_sends_none_to_sdk(self, mock_get_conn, mock_arize_client):
        """clear_query_filter=True must send ``query_filter=None`` to the SDK."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.update.return_value = MagicMock(id="t-1")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_task(task_id="t-1", clear_query_filter=True)
        kw = mock_arize_client.tasks.update.call_args[1]
        assert "query_filter" in kw, (
            "clear_query_filter=True must add query_filter key to SDK kwargs"
        )
        assert kw["query_filter"] is None, (
            "query_filter must be None (not omitted) when clear_query_filter=True"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: delete_task
# ---------------------------------------------------------------------------


class TestHookDeleteTaskSDKKwargs:
    """Verify delete_task forwards correct kwarg names to the SDK."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_task_kwarg_name(self, mock_get_conn, mock_arize_client):
        """Hook param ``task_id`` must reach the SDK as ``task=``."""
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.delete.return_value = None

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_task(task_id="t-del")
        kw = mock_arize_client.tasks.delete.call_args[1]
        assert kw["task"] == "t-del", (
            "hook param task_id must reach SDK as kwarg 'task'"
        )
        assert "task_id" not in kw, (
            "SDK kwarg must be 'task', not 'task_id'"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.delete.return_value = None

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_task(task_id="t-del", space="sp-abc")
        kw = mock_arize_client.tasks.delete.call_args[1]
        assert kw.get("space") == "sp-abc", (
            "space must be forwarded to client.tasks.delete when provided"
        )

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.tasks = MagicMock()
        mock_arize_client.tasks.delete.return_value = None

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_task(task_id="t-del", space=None)
        kw = mock_arize_client.tasks.delete.call_args[1]
        assert "space" not in kw, (
            "space=None must not be forwarded to client.tasks.delete"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: evaluator create (template and code paths) — SDK 8.23.0
# ---------------------------------------------------------------------------

_CONTRACT_TEMPLATE_CFG = {
    "name": "relevance",
    "template": "Score: {input} / {output}",
    "include_explanations": True,
    "use_function_calling_if_available": False,
    "llm_config": {"ai_integration_id": "abc", "model_name": "gpt-4o"},
}
_CONTRACT_CODE_CFG = MagicMock(name="CodeConfig")


class TestHookEvaluatorCreateSDKKwargs:
    """Verify create_evaluator forwards correct kwargs to the right SDK method."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_template_path_uses_create_template_evaluator(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_evaluator.return_value = MagicMock(id="ev-1")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_evaluator(
            space_id="s1",
            name="relevance",
            evaluator_type="template",
            commit_message="init",
            template_config=_CONTRACT_TEMPLATE_CFG,
        )
        kw = mock_arize_client.evaluators.create_template_evaluator.call_args[1]
        assert kw["space"] == "s1", "space_id must reach SDK as 'space'"
        assert kw["name"] == "relevance"
        assert kw["commit_message"] == "init"
        assert kw["template_config"] is _CONTRACT_TEMPLATE_CFG
        mock_arize_client.evaluators.create_code_evaluator.assert_not_called()

    @patch.object(ArizeAxHook, "get_conn")
    def test_code_path_uses_create_code_evaluator(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_code_evaluator.return_value = MagicMock(id="ev-2")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_evaluator(
            space_id="s1",
            name="CodeJudge",
            evaluator_type="code",
            commit_message="init",
            code_config=_CONTRACT_CODE_CFG,
        )
        kw = mock_arize_client.evaluators.create_code_evaluator.call_args[1]
        assert kw["space"] == "s1"
        assert kw["name"] == "CodeJudge"
        assert kw["code_config"] is _CONTRACT_CODE_CFG
        mock_arize_client.evaluators.create_template_evaluator.assert_not_called()

    @patch.object(ArizeAxHook, "get_conn")
    def test_description_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_evaluator.return_value = MagicMock(id="ev-3")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_evaluator(
            space_id="s1",
            name="x",
            evaluator_type="template",
            commit_message="init",
            template_config=_CONTRACT_TEMPLATE_CFG,
            description=None,
        )
        kw = mock_arize_client.evaluators.create_template_evaluator.call_args[1]
        assert "description" not in kw, "description=None must not be forwarded to the SDK"

    @patch.object(ArizeAxHook, "get_conn")
    def test_description_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_evaluator.return_value = MagicMock(id="ev-4")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.create_evaluator(
            space_id="s1",
            name="x",
            evaluator_type="template",
            commit_message="init",
            template_config=_CONTRACT_TEMPLATE_CFG,
            description="My desc",
        )
        kw = mock_arize_client.evaluators.create_template_evaluator.call_args[1]
        assert kw["description"] == "My desc"


# ---------------------------------------------------------------------------
# Hook -> SDK: evaluator update — SDK 8.23.0
# ---------------------------------------------------------------------------


class TestHookEvaluatorUpdateSDKKwargs:
    """Verify update_evaluator forwards evaluator_id as 'evaluator=' to the SDK."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_evaluator_id_reaches_sdk_as_evaluator(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.update.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_evaluator("ev-abc", name="NewName")
        kw = mock_arize_client.evaluators.update.call_args[1]
        assert kw["evaluator"] == "ev-abc", (
            "evaluator_id must reach SDK as kwarg 'evaluator'"
        )
        assert "evaluator_id" not in kw

    @patch.object(ArizeAxHook, "get_conn")
    def test_name_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.update.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_evaluator("ev-abc", name="NewName")
        kw = mock_arize_client.evaluators.update.call_args[1]
        assert kw["name"] == "NewName"

    @patch.object(ArizeAxHook, "get_conn")
    def test_description_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.update.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_evaluator("ev-abc", description="New desc")
        kw = mock_arize_client.evaluators.update.call_args[1]
        assert kw["description"] == "New desc"
        assert "name" not in kw

    @patch.object(ArizeAxHook, "get_conn")
    def test_name_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.update.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.update_evaluator("ev-abc", description="only desc")
        kw = mock_arize_client.evaluators.update.call_args[1]
        assert "name" not in kw, "name=None must not be forwarded to the SDK"


# ---------------------------------------------------------------------------
# Hook -> SDK: evaluator version create — SDK 8.23.0
# ---------------------------------------------------------------------------


class TestHookEvaluatorVersionSDKKwargs:
    """Verify add_evaluator_version dispatches to the correct SDK method."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_template_path_uses_create_template_version(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_version.return_value = MagicMock(id="ver-1")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.add_evaluator_version(
            "ev-abc",
            commit_message="tune",
            version_type="template",
            template_config=_CONTRACT_TEMPLATE_CFG,
        )
        kw = mock_arize_client.evaluators.create_template_version.call_args[1]
        assert kw["evaluator"] == "ev-abc"
        assert kw["commit_message"] == "tune"
        assert kw["template_config"] is _CONTRACT_TEMPLATE_CFG
        mock_arize_client.evaluators.create_code_version.assert_not_called()

    @patch.object(ArizeAxHook, "get_conn")
    def test_code_path_uses_create_code_version(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_code_version.return_value = MagicMock(id="ver-2")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.add_evaluator_version(
            "ev-abc",
            commit_message="code v2",
            version_type="code",
            code_config=_CONTRACT_CODE_CFG,
        )
        kw = mock_arize_client.evaluators.create_code_version.call_args[1]
        assert kw["evaluator"] == "ev-abc"
        assert kw["commit_message"] == "code v2"
        assert kw["code_config"] is _CONTRACT_CODE_CFG
        mock_arize_client.evaluators.create_template_version.assert_not_called()

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_forwarded_when_set(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_version.return_value = MagicMock(id="ver-3")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.add_evaluator_version(
            "ev-abc",
            commit_message="tune",
            template_config=_CONTRACT_TEMPLATE_CFG,
            space="my-space",
        )
        kw = mock_arize_client.evaluators.create_template_version.call_args[1]
        assert kw["space"] == "my-space"

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.evaluators = MagicMock()
        mock_arize_client.evaluators.create_template_version.return_value = MagicMock(id="ver-4")

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.add_evaluator_version(
            "ev-abc",
            commit_message="tune",
            template_config=_CONTRACT_TEMPLATE_CFG,
            space=None,
        )
        kw = mock_arize_client.evaluators.create_template_version.call_args[1]
        assert "space" not in kw, "space=None must not be forwarded to the SDK"


# ---------------------------------------------------------------------------
# Hook -> SDK: annotate_dataset_examples (HITL — SDK 8.23+)
# ---------------------------------------------------------------------------


class TestHookAnnotateDatasetExamplesSDKKwargs:
    """Hook param ``dataset_id`` must reach SDK as ``dataset=``."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_id_forwarded_as_dataset(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.annotate_examples.return_value = MagicMock()

        anns = [{"record_id": "ex-1", "values": [{"name": "q", "score": 1.0}]}]
        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.annotate_dataset_examples(dataset_id="d1", annotations=anns, space="sp1")

        kw = mock_arize_client.datasets.annotate_examples.call_args[1]
        assert kw["dataset"] == "d1", (
            "dataset_id must be forwarded as kwarg 'dataset' to client.datasets.annotate_examples"
        )
        assert kw["annotations"] is anns, "annotations list must be forwarded as-is"
        assert kw["space"] == "sp1"

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.datasets.annotate_examples.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.annotate_dataset_examples(
            dataset_id="d1",
            annotations=[{"record_id": "ex-1", "values": []}],
        )

        kw = mock_arize_client.datasets.annotate_examples.call_args[1]
        assert "space" not in kw, (
            "space=None must not be forwarded to client.datasets.annotate_examples"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: annotate_experiment_runs (HITL — SDK 8.23+)
# ---------------------------------------------------------------------------


class TestHookAnnotateExperimentRunsSDKKwargs:
    """Hook param ``experiment_id`` must reach SDK as ``experiment=``."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_experiment_id_forwarded_as_experiment(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.annotate_runs.return_value = MagicMock()

        anns = [{"record_id": "run-1", "values": [{"name": "q", "score": 0.9}]}]
        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.annotate_experiment_runs(
            experiment_id="exp-1",
            annotations=anns,
            dataset="ds-1",
            space="sp1",
        )

        kw = mock_arize_client.experiments.annotate_runs.call_args[1]
        assert kw["experiment"] == "exp-1", (
            "experiment_id must be forwarded as kwarg 'experiment' to client.experiments.annotate_runs"
        )
        assert kw["annotations"] is anns
        assert kw["dataset"] == "ds-1"
        assert kw["space"] == "sp1"

    @patch.object(ArizeAxHook, "get_conn")
    def test_dataset_and_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client
        mock_arize_client.experiments.annotate_runs.return_value = MagicMock()

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.annotate_experiment_runs(
            experiment_id="exp-1",
            annotations=[{"record_id": "run-1", "values": []}],
        )

        kw = mock_arize_client.experiments.annotate_runs.call_args[1]
        assert "dataset" not in kw, (
            "dataset=None must not be forwarded to client.experiments.annotate_runs"
        )
        assert "space" not in kw, (
            "space=None must not be forwarded to client.experiments.annotate_runs"
        )


# ---------------------------------------------------------------------------
# Hook -> SDK: delete_annotation_queue_records (HITL — SDK 8.23+)
# ---------------------------------------------------------------------------


class TestHookDeleteAnnotationQueueRecordsSDKKwargs:
    """Verify delete_annotation_queue_records forwards kwargs correctly."""

    @patch.object(ArizeAxHook, "get_conn")
    def test_annotation_queue_and_record_ids_forwarded(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_annotation_queue_records(
            annotation_queue="q-1",
            record_ids=["r1", "r2"],
            space="sp1",
        )

        kw = mock_arize_client.annotation_queues.delete_records.call_args[1]
        assert kw["annotation_queue"] == "q-1", (
            "annotation_queue must be forwarded to client.annotation_queues.delete_records"
        )
        assert kw["record_ids"] == ["r1", "r2"], "record_ids must be forwarded as-is"
        assert kw["space"] == "sp1"

    @patch.object(ArizeAxHook, "get_conn")
    def test_space_omitted_when_none(self, mock_get_conn, mock_arize_client):
        mock_get_conn.return_value = mock_arize_client

        hook = ArizeAxHook(arize_ax_conn_id="test")
        hook.delete_annotation_queue_records(
            annotation_queue="q-1",
            record_ids=["r1"],
        )

        kw = mock_arize_client.annotation_queues.delete_records.call_args[1]
        assert "space" not in kw, (
            "space=None must not be forwarded to client.annotation_queues.delete_records"
        )


# ---------------------------------------------------------------------------
# Operator -> Hook: optimize_prompt forwarding
# ---------------------------------------------------------------------------


class TestOptimizePromptOperatorForwarding:
    """ArizeAxOptimizePromptOperator must forward all params to hook.optimize_prompt."""

    def test_all_params_forwarded(self):
        from airflow.providers.arize_ax.operators.prompts import (
            ArizeAxOptimizePromptOperator,
        )

        op = ArizeAxOptimizePromptOperator(
            task_id="opt",
            prompt="You are helpful.",
            dataset=[{"input": "q", "output": "a", "feedback": "good"}],
            output_column="output",
            feedback_columns=["feedback"],
            model_choice="gpt-4o-mini",
            openai_api_key="sk-test",
            context_size_k=4000,
        )
        with patch(
            "airflow.providers.arize_ax.operators.prompts.ArizeAxHook"
        ) as mock_hook_cls:
            mock_hook = MagicMock(spec=ArizeAxHook)
            mock_hook_cls.return_value = mock_hook
            mock_hook.optimize_prompt.return_value = {
                "messages": [{"role": "system", "content": "x"}],
                "content": "x",
                "raw": "x",
                "model_choice": "gpt-4o-mini",
            }
            op.execute(context={"ti": MagicMock()})

        call_kw = mock_hook.optimize_prompt.call_args.kwargs
        assert call_kw["prompt"] == "You are helpful."
        assert call_kw["output_column"] == "output"
        assert call_kw["feedback_columns"] == ["feedback"]
        assert call_kw["model_choice"] == "gpt-4o-mini"
        assert call_kw["openai_api_key"] == "sk-test"
        assert call_kw["context_size_k"] == 4000
        # dataset is normalized to a DataFrame before forwarding
        df = call_kw["dataset"]
        assert hasattr(df, "columns") and list(df.columns) == ["input", "output", "feedback"]

    def test_template_fields(self):
        from airflow.providers.arize_ax.operators.prompts import (
            ArizeAxOptimizePromptOperator,
        )

        for field in ("prompt", "model_choice", "output_column", "dataset_task_id", "dataset_key"):
            assert field in ArizeAxOptimizePromptOperator.template_fields, (
                f"{field!r} must be in ArizeAxOptimizePromptOperator.template_fields"
            )


# ---------------------------------------------------------------------------
# ArizeAxSpansExportToParquetOperator return value + XCom contract
# ---------------------------------------------------------------------------

class TestSpansExportToParquetOperatorReturn:
    """The Parquet export operator must return the path on success and push a
    ``result`` XCom entry with ``{"path", "wrote"}`` so downstream
    ShortCircuit/sensor tasks can tell apart "wrote a file" from "no data".
    """

    @patch("airflow.providers.arize_ax.operators.spans.ArizeAxHook")
    def test_returns_path_and_pushes_xcom_on_write(self, mock_hook_cls):
        from airflow.providers.arize_ax.operators.spans import (
            ArizeAxSpansExportToParquetOperator,
        )

        mock_hook = MagicMock(spec=ArizeAxHook)
        mock_hook.get_space.return_value = "s1"
        mock_hook.export_spans_to_parquet.return_value = True
        mock_hook_cls.return_value = mock_hook

        op = ArizeAxSpansExportToParquetOperator(
            task_id="export", project_name="p1",
            start_time="2025-01-01", end_time="2025-01-02",
            path="/tmp/out.parquet",
        )
        ti = MagicMock()
        result = op.execute(context={"ti": ti})
        assert result == "/tmp/out.parquet"
        ti.xcom_push.assert_called_once_with(
            key="result", value={"path": "/tmp/out.parquet", "wrote": True}
        )

    @patch("airflow.providers.arize_ax.operators.spans.ArizeAxHook")
    def test_returns_none_and_pushes_wrote_false_on_no_data(self, mock_hook_cls):
        from airflow.providers.arize_ax.operators.spans import (
            ArizeAxSpansExportToParquetOperator,
        )

        mock_hook = MagicMock(spec=ArizeAxHook)
        mock_hook.get_space.return_value = "s1"
        mock_hook.export_spans_to_parquet.return_value = False
        mock_hook_cls.return_value = mock_hook

        op = ArizeAxSpansExportToParquetOperator(
            task_id="export", project_name="p1",
            start_time="2025-01-01", end_time="2025-01-02",
            path="/tmp/out.parquet",
        )
        ti = MagicMock()
        result = op.execute(context={"ti": ti})
        assert result is None
        ti.xcom_push.assert_called_once_with(
            key="result", value={"path": None, "wrote": False}
        )
