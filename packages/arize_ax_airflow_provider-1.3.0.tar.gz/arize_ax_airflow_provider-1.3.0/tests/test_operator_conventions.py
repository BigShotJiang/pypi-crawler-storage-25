"""Convention tests: verify cross-cutting operator patterns in one place.

Replaces per-operator boilerplate tests (template_fields, custom_conn_id,
ignore_if_missing, xcom convenience keys) with parametrized versions.
"""
from __future__ import annotations

import importlib
import inspect
from unittest.mock import MagicMock, patch

import pytest
from airflow.models import BaseOperator

# ---------------------------------------------------------------------------
# Helpers: collect operator classes
# ---------------------------------------------------------------------------

_MODULES = [
    "airflow.providers.arize_ax.operators.ai_integrations",
    "airflow.providers.arize_ax.operators.annotations",
    "airflow.providers.arize_ax.operators.api_keys",
    "airflow.providers.arize_ax.operators.datasets",
    "airflow.providers.arize_ax.operators.evaluators",
    "airflow.providers.arize_ax.operators.experiments",
    "airflow.providers.arize_ax.operators.ml",
    "airflow.providers.arize_ax.operators.projects",
    "airflow.providers.arize_ax.operators.prompts",
    "airflow.providers.arize_ax.operators.spaces",
    "airflow.providers.arize_ax.operators.spans",
    "airflow.providers.arize_ax.operators.tasks",
]

# Reverse map: operator class name -> module path it is defined in
_CLASS_TO_MODULE: dict[str, str] = {}


def _all_operator_classes() -> list[pytest.param]:
    seen: set[str] = set()
    params: list[pytest.param] = []
    for mod_path in _MODULES:
        mod = importlib.import_module(mod_path)
        for name, obj in inspect.getmembers(mod, inspect.isclass):
            if (
                name not in seen
                and issubclass(obj, BaseOperator)
                and obj is not BaseOperator
                and name.startswith("ArizeAx")
            ):
                seen.add(name)
                _CLASS_TO_MODULE[name] = mod_path
                params.append(pytest.param(obj, id=name))
    return params


ALL_OPERATORS = _all_operator_classes()


def _delete_operator_classes() -> list[pytest.param]:
    return [p for p in ALL_OPERATORS if "Delete" in p.values[0].__name__]


def _primary_list_operator_classes() -> list[pytest.param]:
    """List operators that push first_id / first_name XCom keys.

    Excludes sub-list operators (Records, Runs, Versions, Examples) that
    operate on child resources and don't push these convenience keys.
    """
    excluded_suffixes = ("Record", "Run", "Version", "Example")
    result = []
    for p in ALL_OPERATORS:
        cls = p.values[0]
        name = cls.__name__
        if name.startswith("ArizeAxList") and not any(
            name.endswith(s) or name.endswith(s + "s") for s in excluded_suffixes
        ):
            result.append(p)
    return result


DELETE_OPERATORS = _delete_operator_classes()
LIST_OPERATORS = _primary_list_operator_classes()


# ---------------------------------------------------------------------------
# TestTemplateFields
# ---------------------------------------------------------------------------

class TestTemplateFields:
    """Every operator that declares template_fields must use a tuple/list of strings."""

    @pytest.mark.parametrize("op_cls", ALL_OPERATORS)
    def test_template_fields_is_sequence_of_strings(self, op_cls):
        fields = getattr(op_cls, "template_fields", None)
        if fields is None:
            return  # No template_fields — allowed
        assert isinstance(fields, (tuple, list)), (
            f"{op_cls.__name__}.template_fields should be tuple/list, got {type(fields)}"
        )
        for f in fields:
            assert isinstance(f, str), (
                f"{op_cls.__name__}.template_fields contains non-string: {f!r}"
            )

    @pytest.mark.parametrize("op_cls", ALL_OPERATORS)
    def test_template_fields_names_match_init_attributes(self, op_cls):
        """Every name in template_fields must correspond to an instance
        attribute set in __init__. Otherwise Airflow's getattr(self, name)
        silently no-ops and the Jinja template is sent literally to the API.

        Regression test for the 2026-05-12 GetTask bug where template_fields
        said "task_id" but the operator stored it as self.task_id_param.
        """
        import inspect
        import re

        fields = getattr(op_cls, "template_fields", None)
        if not fields:
            return
        try:
            init_src = inspect.getsource(op_cls.__init__)
        except (OSError, TypeError):
            return
        # Collect names assigned via self.X = ... in __init__.
        attrs = set(re.findall(r"self\.(\w+)\s*=", init_src))
        # Add inherited attributes too (e.g., from BaseOperator).
        for parent in op_cls.__mro__[1:]:
            try:
                parent_src = inspect.getsource(parent.__init__)
                attrs.update(re.findall(r"self\.(\w+)\s*=", parent_src))
            except (OSError, TypeError):
                continue
        for f in fields:
            assert f in attrs, (
                f"{op_cls.__name__}: template_fields lists {f!r} but no such "
                f"instance attribute is set in __init__. Airflow renders by "
                f"getattr(self, name); a missing attr means Jinja templates "
                f"go to the API as literal strings. Available attrs: "
                f"{sorted(attrs)}"
            )


# ---------------------------------------------------------------------------
# TestUiColor
# ---------------------------------------------------------------------------

class TestUiColor:
    """Every operator must declare the project-standard ui_color."""

    @pytest.mark.parametrize("op_cls", ALL_OPERATORS)
    def test_ui_color_is_brand_green(self, op_cls):
        color = getattr(op_cls, "ui_color", None)
        assert color == "#e4f0e8", (
            f"{op_cls.__name__}.ui_color should be '#e4f0e8', got {color!r}"
        )


# ---------------------------------------------------------------------------
# TestIgnoreIfMissingDefault
# ---------------------------------------------------------------------------

class TestIgnoreIfMissingDefault:
    """All Delete operators must have ignore_if_missing=True as the default."""

    @pytest.mark.parametrize("op_cls", DELETE_OPERATORS)
    def test_default_is_true(self, op_cls):
        sig = inspect.signature(op_cls.__init__)
        param = sig.parameters.get("ignore_if_missing")
        assert param is not None, (
            f"{op_cls.__name__} is missing an ignore_if_missing parameter"
        )
        assert param.default is True, (
            f"{op_cls.__name__}.ignore_if_missing default should be True, "
            f"got {param.default!r}"
        )


# ---------------------------------------------------------------------------
# TestCustomConnId
#
# Each operator patches "its own module".ArizeAxHook — the local name the
# operator module uses — rather than the hook's own module.  This matches
# the existing per-operator test pattern (MODULE = "...operators.tasks", etc.)
# ---------------------------------------------------------------------------

# Minimal required constructor kwargs per operator class name.
# Every operator that accepts arize_ax_conn_id should be listed here.
# Complex or computation-heavy operators (ComparePrompts, RunExperiment, etc.)
# are intentionally omitted — their per-file tests already cover conn_id.
_OP_MINIMAL_KWARGS: dict[str, dict] = {
    # ai_integrations
    "ArizeAxListAIIntegrationsOperator": {},
    "ArizeAxGetAIIntegrationOperator": {"integration_id": "x"},
    "ArizeAxCreateAIIntegrationOperator": {"name": "n", "provider": "openAI"},
    "ArizeAxUpdateAIIntegrationOperator": {"integration_id": "x", "name": "n"},
    "ArizeAxDeleteAIIntegrationOperator": {"integration_id": "x"},
    # annotations
    "ArizeAxListAnnotationQueuesOperator": {},
    "ArizeAxListAnnotationConfigsOperator": {},
    "ArizeAxGetAnnotationQueueOperator": {"annotation_queue": "q"},
    "ArizeAxCreateAnnotationQueueOperator": {"name": "q"},
    "ArizeAxUpdateAnnotationQueueOperator": {"annotation_queue": "q"},
    "ArizeAxDeleteAnnotationQueueOperator": {"annotation_queue": "q"},
    "ArizeAxListAnnotationQueueRecordsOperator": {"annotation_queue": "q"},
    "ArizeAxAddAnnotationQueueRecordsOperator": {"annotation_queue": "q", "record_sources": []},
    "ArizeAxAnnotateQueueRecordOperator": {
        "annotation_queue": "q", "record_id": "r", "annotations": []
    },
    "ArizeAxAssignQueueRecordOperator": {
        "annotation_queue": "q", "record_id": "r", "assigned_user_emails": []
    },
    "ArizeAxCreateAnnotationConfigOperator": {"name": "cfg"},
    "ArizeAxDeleteAnnotationConfigOperator": {"annotation_config": "cfg"},
    # api_keys
    "ArizeAxListAPIKeysOperator": {},
    "ArizeAxDeleteAPIKeyOperator": {"api_key_id": "k"},
    "ArizeAxCreateAPIKeyOperator": {"name": "k"},
    "ArizeAxRefreshAPIKeyOperator": {"api_key_id": "k"},
    # datasets
    "ArizeAxListDatasetsOperator": {"space_id": "s"},
    "ArizeAxGetDatasetOperator": {"dataset_id": "ds"},
    "ArizeAxCreateDatasetOperator": {"space_id": "s", "name": "ds", "examples": []},
    "ArizeAxDeleteDatasetOperator": {"dataset_id": "ds"},
    "ArizeAxListDatasetExamplesOperator": {"dataset_id": "ds"},
    "ArizeAxAppendDatasetExamplesOperator": {"dataset_id": "ds", "examples": []},
    "ArizeAxExportDatasetExamplesToFileOperator": {"dataset_id": "ds", "path": "/tmp/x"},
    # evaluators
    "ArizeAxListEvaluatorsOperator": {"space_id": "s"},
    "ArizeAxGetEvaluatorOperator": {"evaluator_id": "ev"},
    "ArizeAxDeleteEvaluatorOperator": {"evaluator_id": "ev"},
    "ArizeAxListEvaluatorVersionsOperator": {"evaluator_id": "ev"},
    "ArizeAxGetEvaluatorVersionOperator": {"version_id": "ver"},
    # experiments
    "ArizeAxListExperimentsOperator": {"dataset_id": "ds"},
    "ArizeAxGetExperimentOperator": {"experiment_id": "exp"},
    "ArizeAxDeleteExperimentOperator": {"experiment_id": "exp"},
    "ArizeAxListExperimentRunsOperator": {"experiment_id": "exp"},
    "ArizeAxExportExperimentRunsToFileOperator": {"experiment_id": "exp", "path": "/tmp/x"},
    # projects
    "ArizeAxListProjectsOperator": {"space_id": "s"},
    "ArizeAxGetProjectOperator": {"project_id": "p"},
    "ArizeAxDeleteProjectOperator": {"project_id": "p"},
    # prompts
    "ArizeAxListPromptsOperator": {"space_id": "s"},
    "ArizeAxGetPromptOperator": {"prompt_id": "pr"},
    "ArizeAxDeletePromptOperator": {"prompt_id": "pr"},
    # spaces
    "ArizeAxListSpacesOperator": {},
    "ArizeAxGetSpaceOperator": {"space": "s"},
    "ArizeAxUpdateSpaceOperator": {"space": "s"},
    "ArizeAxDeleteSpaceOperator": {"space": "s"},
    "ArizeAxCreateSpaceOperator": {"name": "s", "organization_id": "org"},
    # spans
    "ArizeAxListSpansOperator": {"project_id": "p"},
    "ArizeAxGetSpanMetricsOperator": {
        "project_id": "p",
        "start_time": "2025-01-01T00:00:00+00:00",
        "end_time": "2025-01-02T00:00:00+00:00",
    },
    # tasks
    "ArizeAxListTasksOperator": {},
    "ArizeAxGetTaskOperator": {"task_id_param": "t"},
    "ArizeAxListTaskRunsOperator": {"task_id_param": "t"},
    "ArizeAxGetTaskRunOperator": {"run_id": "r"},
    "ArizeAxTriggerTaskRunOperator": {"task_id_param": "t"},
    "ArizeAxCancelTaskRunOperator": {"run_id": "r"},
    "ArizeAxCreateTaskOperator": {"name": "t", "eval_task_type": "template_evaluation"},
}

# Collect the params for operators that have an entry in _OP_MINIMAL_KWARGS
_CONN_ID_OPERATORS = [
    p for p in ALL_OPERATORS if p.values[0].__name__ in _OP_MINIMAL_KWARGS
]


class TestCustomConnId:
    """Each operator must forward arize_ax_conn_id to ArizeAxHook upon construction."""

    @pytest.mark.parametrize("op_cls", _CONN_ID_OPERATORS)
    def test_conn_id_forwarded_to_hook(self, op_cls):
        name = op_cls.__name__
        extra = _OP_MINIMAL_KWARGS[name]
        mod_path = _CLASS_TO_MODULE[name]
        patch_target = f"{mod_path}.ArizeAxHook"

        with patch(patch_target) as mock_hook_cls:
            mock_hook = MagicMock()
            mock_hook_cls.return_value = mock_hook

            try:
                op = op_cls(task_id="t", arize_ax_conn_id="custom_test_conn", **extra)
                op.execute(context={})
            except Exception:
                # execute() may fail due to missing data — we only care that
                # the hook was instantiated with the correct conn_id.
                pass

            mock_hook_cls.assert_called_once_with(arize_ax_conn_id="custom_test_conn")
