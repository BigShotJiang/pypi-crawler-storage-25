"""Validate that all example DAGs parse without errors.

Uses DagBag to import each example DAG and verify:
- No import errors (syntax, missing imports, etc.)
- At least one task is present
- DAG IDs follow naming conventions

This mirrors the pattern used by apache-airflow-providers-google.
"""

from __future__ import annotations

import os

import pytest

EXAMPLE_DAGS_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "provider_pkg", "example_dags")
)
# Docker / local compose: README documents mirroring provider example DAGs here.
DOCKER_DAGS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "dags"))


def _get_example_dag_files() -> list[str]:
    """Collect all example DAG Python files."""
    if not os.path.isdir(EXAMPLE_DAGS_DIR):
        return []
    return sorted(
        f
        for f in os.listdir(EXAMPLE_DAGS_DIR)
        if f.startswith("example_") and f.endswith(".py")
    )


class TestExampleDags:
    """Validate all example DAGs load and have correct structure."""

    def test_example_dags_directory_exists(self):
        assert os.path.isdir(EXAMPLE_DAGS_DIR), f"Example DAGs dir not found: {EXAMPLE_DAGS_DIR}"

    def test_has_example_dags(self):
        files = _get_example_dag_files()
        assert len(files) >= 1, "Expected at least one example DAG file"

    def test_no_import_errors(self):
        from airflow.models import DagBag

        dag_bag = DagBag(dag_folder=EXAMPLE_DAGS_DIR, include_examples=False)
        assert dag_bag.import_errors == {}, f"DAG import errors: {dag_bag.import_errors}"

    def test_all_dags_have_tasks(self):
        from airflow.models import DagBag

        dag_bag = DagBag(dag_folder=EXAMPLE_DAGS_DIR, include_examples=False)
        for dag_id, dag in dag_bag.dags.items():
            assert len(dag.tasks) >= 1, f"DAG '{dag_id}' has no tasks"

    def test_dag_ids_follow_naming_convention(self):
        from airflow.models import DagBag

        dag_bag = DagBag(dag_folder=EXAMPLE_DAGS_DIR, include_examples=False)
        for dag_id in dag_bag.dags:
            assert "arize" in dag_id.lower(), (
                f"DAG '{dag_id}' should include 'arize' in its ID"
            )

    @pytest.mark.parametrize("dag_file", _get_example_dag_files())
    def test_individual_dag_file_loads(self, dag_file):
        from airflow.models import DagBag

        dag_path = os.path.join(EXAMPLE_DAGS_DIR, dag_file)
        dag_bag = DagBag(dag_folder=dag_path, include_examples=False)
        assert dag_bag.import_errors == {}, (
            f"Import error in {dag_file}: {dag_bag.import_errors}"
        )
        assert len(dag_bag.dags) >= 1, f"No DAGs found in {dag_file}"

    def test_docker_dags_folder_matches_provider(self):
        """``dags/example_*.py`` must match ``provider_pkg/example_dags/`` (byte-for-byte)."""
        assert os.path.isdir(DOCKER_DAGS_DIR), f"Docker dags dir missing: {DOCKER_DAGS_DIR}"
        provider_names = _get_example_dag_files()
        docker_names = sorted(
            f
            for f in os.listdir(DOCKER_DAGS_DIR)
            if f.startswith("example_") and f.endswith(".py")
        )
        assert docker_names == provider_names, (
            "dags/ example DAG set must match provider_pkg/example_dags/. "
            f"provider={provider_names!r} docker={docker_names!r}. "
            "Copy updated files from provider_pkg/example_dags/ into dags/."
        )
        for name in provider_names:
            p_path = os.path.join(EXAMPLE_DAGS_DIR, name)
            d_path = os.path.join(DOCKER_DAGS_DIR, name)
            with open(p_path, encoding="utf-8") as f:
                provider_text = f.read()
            with open(d_path, encoding="utf-8") as f:
                docker_text = f.read()
            assert provider_text == docker_text, (
                f"{name} differs between provider_pkg/example_dags/ and dags/. "
                "Sync with: cp provider_pkg/example_dags/<file> dags/"
            )
