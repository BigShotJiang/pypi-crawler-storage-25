"""Unit tests for log_fallback (FileTaskHandler hostname fallback patch)."""

from __future__ import annotations

from unittest.mock import MagicMock


def test_apply_log_url_fallback_patch_runs_without_error():
    """_apply_log_url_fallback_patch runs without error (covers main path when Airflow is available)."""
    from airflow.providers.arize_ax.log_fallback import _apply_log_url_fallback_patch

    _apply_log_url_fallback_patch()


def test_apply_log_url_fallback_patch_uses_env_fallback_host(monkeypatch):
    """When patch is applied and ti.hostname is empty, fallback host from env is used in URL."""
    from airflow.utils.log.file_task_handler import FileTaskHandler

    monkeypatch.setenv("AIRFLOW_WORKER_LOG_SERVER_HOST", "scheduler-host")
    from airflow.providers.arize_ax.log_fallback import _apply_log_url_fallback_patch

    original = FileTaskHandler._get_log_retrieval_url
    try:
        _apply_log_url_fallback_patch()
        mock_ti = MagicMock()
        mock_ti.hostname = ""
        mock_self = MagicMock()
        # Use a log_type that is not TRIGGER so the fallback-host path is used
        result = FileTaskHandler._get_log_retrieval_url(
            mock_self, mock_ti, "d/t/attempt.log", log_type=None
        )
        if isinstance(result, tuple):
            assert "scheduler-host" in result[0]
            assert "8793" in result[0] or "/log/" in result[0]
    finally:
        FileTaskHandler._get_log_retrieval_url = original


def test_apply_log_url_fallback_patch_trigger_log_type_uses_original(monkeypatch):
    """When log_type is TRIGGER, original handler is used (no fallback)."""
    from airflow.utils.log.file_task_handler import FileTaskHandler, LogType

    monkeypatch.setenv("AIRFLOW_WORKER_HOSTNAME", "worker")
    from airflow.providers.arize_ax.log_fallback import _apply_log_url_fallback_patch

    original = FileTaskHandler._get_log_retrieval_url
    mock_original = MagicMock(return_value=("http://original/url", "path"))
    try:
        FileTaskHandler._get_log_retrieval_url = mock_original
        _apply_log_url_fallback_patch()
        mock_ti = MagicMock()
        mock_ti.hostname = ""
        mock_self = MagicMock()
        result = FileTaskHandler._get_log_retrieval_url(
            mock_self, mock_ti, "d/t/attempt.log", log_type=LogType.TRIGGER
        )
        assert mock_original.called
        assert result == ("http://original/url", "path")
    finally:
        FileTaskHandler._get_log_retrieval_url = original
