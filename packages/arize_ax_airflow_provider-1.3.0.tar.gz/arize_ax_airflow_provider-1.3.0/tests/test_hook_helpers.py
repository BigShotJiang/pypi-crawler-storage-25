"""Unit tests for hook helper functions: _to_serializable and _structure_list_response.

These are the serialization primitives that every operator relies on for XCom
compatibility.  Tested in isolation to ensure edge cases are handled correctly.
"""

from __future__ import annotations

import importlib
import pkgutil
from unittest.mock import MagicMock

import pytest
from airflow.providers.arize_ax.hooks.arize_ax import (
    _LIST_RESPONSE_ITEM_KEYS,
    _structure_list_response,
    _to_serializable,
)


class TestToSerializable:
    """Test _to_serializable conversion to JSON-safe types."""

    def test_none(self):
        assert _to_serializable(None) is None

    @pytest.mark.parametrize(
        "value",
        [42, 3.14, True, False, "hello"],
        ids=["int", "float", "true", "false", "str"],
    )
    def test_primitives_pass_through(self, value):
        assert _to_serializable(value) == value

    def test_dict_recursion(self):
        result = _to_serializable({"a": 1, "b": {"c": 2}})
        assert result == {"a": 1, "b": {"c": 2}}

    def test_list_recursion(self):
        result = _to_serializable([1, [2, 3]])
        assert result == [1, [2, 3]]

    def test_tuple_converts_to_list(self):
        result = _to_serializable((1, 2, 3))
        assert result == [1, 2, 3]

    def test_pydantic_model_dump_json_mode(self):
        mock_obj = MagicMock()
        del mock_obj.to_dict
        mock_obj.model_dump.return_value = {"id": "ds-1", "name": "test"}
        result = _to_serializable(mock_obj)
        mock_obj.model_dump.assert_called_once_with(mode="json")
        assert result == {"id": "ds-1", "name": "test"}

    def test_pydantic_model_dump_fallback_no_json_mode(self):
        mock_obj = MagicMock()
        del mock_obj.to_dict
        mock_obj.model_dump.side_effect = [TypeError("no mode param"), {"id": "ds-1"}]
        result = _to_serializable(mock_obj)
        assert result == {"id": "ds-1"}
        assert mock_obj.model_dump.call_count == 2

    def test_legacy_dict_method(self):
        mock_obj = MagicMock(spec=["dict"])
        mock_obj.dict.return_value = {"id": "old-style"}
        del mock_obj.model_dump
        result = _to_serializable(mock_obj)
        assert result == {"id": "old-style"}

    def test_iterable_fallback(self):
        class CustomIter:
            def __iter__(self):
                return iter([1, 2, 3])

        result = _to_serializable(CustomIter())
        assert result == [1, 2, 3]

    def test_non_serializable_falls_back_to_str(self):
        class Opaque:
            def __str__(self):
                return "opaque-value"

        result = _to_serializable(Opaque())
        assert result == "opaque-value"

    def test_dict_with_nested_pydantic(self):
        inner = MagicMock()
        del inner.to_dict
        inner.model_dump.return_value = {"nested": True}
        result = _to_serializable({"outer": inner})
        assert result == {"outer": {"nested": True}}

    def test_prefers_to_dict_over_model_dump(self):
        """SDK 8.27+ exposes ``to_dict()`` that correctly unwraps oneOf
        wrappers (Arize-ai/arize#71729). _to_serializable must prefer it."""
        obj = MagicMock()
        obj.to_dict.return_value = {"id": "v1", "evaluator_id": "ev-1"}
        obj.model_dump.return_value = {"actual_instance": {"id": "wrong"}}
        result = _to_serializable(obj)
        assert result == {"id": "v1", "evaluator_id": "ev-1"}
        obj.model_dump.assert_not_called()


class TestStructureListResponse:
    """Test _structure_list_response normalization."""

    def test_non_dict_returns_empty(self):
        result = _structure_list_response("not a dict")
        assert result == {"items": [], "next_cursor": None, "count": 0}

    def test_non_dict_list_returns_empty(self):
        result = _structure_list_response([1, 2, 3])
        assert result == {"items": [], "next_cursor": None, "count": 0}

    @pytest.mark.parametrize(
        "key",
        [
            "datasets",
            "experiments",
            "experiment_runs",
            "projects",
            "examples",
            "spans",
            "spaces",
            "annotation_configs",
            "annotation_queues",
            "records",
            "tasks",
            "evaluators",
            "evaluator_versions",
            "prompts",
            "api_keys",
            "ai_integrations",
            "data",
            "items",
        ],
    )
    def test_extracts_items_from_known_keys(self, key):
        data = {key: [{"id": "1"}, {"id": "2"}]}
        result = _structure_list_response(data)
        assert result["items"] == [{"id": "1"}, {"id": "2"}]
        assert result["count"] == 2

    def test_extracts_evaluator_versions_key_specifically(self):
        """Regression test: SDK's EvaluatorVersionsList200Response uses
        ``evaluator_versions`` as the items key (not ``versions``). Confusing
        the two leaves the response with 0 items and silently skips downstream
        gates in DAGs."""
        data = {
            "evaluator_versions": [{"id": "v1"}, {"id": "v2"}],
            "pagination": {"next_cursor": None},
        }
        result = _structure_list_response(data)
        assert result["count"] == 2
        assert result["items"][0]["id"] == "v1"

    def test_first_matching_key_wins(self):
        data = {"datasets": [{"id": "ds"}], "items": [{"id": "item"}]}
        result = _structure_list_response(data)
        assert result["items"] == [{"id": "ds"}]

    @pytest.mark.parametrize(
        "cursor_key",
        ["next_cursor", "cursor", "next_page_token"],
    )
    def test_extracts_cursor(self, cursor_key):
        data = {"items": [], cursor_key: "abc123"}
        result = _structure_list_response(data)
        assert result["next_cursor"] == "abc123"

    def test_none_cursor_stays_none(self):
        data = {"items": [], "next_cursor": None}
        result = _structure_list_response(data)
        assert result["next_cursor"] is None

    def test_empty_dict(self):
        result = _structure_list_response({})
        assert result == {"items": [], "next_cursor": None, "count": 0}

    def test_non_list_values_ignored(self):
        data = {"datasets": "not a list", "items": [{"id": "1"}]}
        result = _structure_list_response(data)
        assert result["items"] == [{"id": "1"}]

    def test_count_matches_items_length(self):
        data = {"items": [1, 2, 3, 4, 5]}
        result = _structure_list_response(data)
        assert result["count"] == 5


def _discover_sdk_list_response_models() -> list[tuple[str, str]]:
    """Walk the SDK's generated models and return (response_class, items_field)
    for every ``*List200Response``. Used by the regression test below to assert
    every list response the SDK can emit has its items field registered in our
    ``_LIST_RESPONSE_ITEM_KEYS``."""
    pairs: list[tuple[str, str]] = []
    try:
        from arize._generated.api_client import models as m
    except ImportError:
        return pairs
    for _, modname, _ in pkgutil.walk_packages(m.__path__, prefix=m.__name__ + "."):
        if not modname.endswith("list200_response"):
            continue
        mod = importlib.import_module(modname)
        for name in dir(mod):
            cls = getattr(mod, name, None)
            if not (
                isinstance(cls, type)
                and hasattr(cls, "model_fields")
                and name.endswith("List200Response")
            ):
                continue
            fields = list(cls.model_fields.keys())
            items_keys = [f for f in fields if f != "pagination"]
            if items_keys:
                pairs.append((name, items_keys[0]))
    return pairs


# Resources the SDK exposes a ``*List200Response`` for but the hook does NOT
# wrap yet — adding a hook method for any of these requires also adding the
# items key to ``_LIST_RESPONSE_ITEM_KEYS`` and removing the entry here.
_UNWRAPPED_LIST_RESPONSE_KEYS = {
    "organizations",  # Wave-4 RBAC, not wrapped
    "prompt_versions",  # No list_prompt_versions hook method yet
    "roles",  # Wave-4 RBAC, not wrapped
    "users",  # Not wrapped
}


class TestListResponseKeysCoverSdk:
    """Regression test for the 2026-05-13 ``evaluator_versions`` bug.

    The hook's ``_structure_list_response`` walks ``_LIST_RESPONSE_ITEM_KEYS``
    to find the items list in any SDK response dict. If the tuple is missing
    the field name the SDK actually emits, items are silently dropped and the
    response surfaces as ``{"items": [], "count": 0}`` — making downstream
    XCom-presence gates skip tasks for no apparent reason.

    Asserts every SDK ``*List200Response`` model's items field is either:
      a) registered in ``_LIST_RESPONSE_ITEM_KEYS``, OR
      b) listed in ``_UNWRAPPED_LIST_RESPONSE_KEYS`` (resources we don't wrap).
    """

    @pytest.mark.parametrize(
        "response_cls,items_field", _discover_sdk_list_response_models()
    )
    def test_sdk_response_items_field_is_recognized(
        self, response_cls: str, items_field: str
    ):
        if items_field in _UNWRAPPED_LIST_RESPONSE_KEYS:
            pytest.skip(
                f"{response_cls} → {items_field!r} is in _UNWRAPPED_LIST_RESPONSE_KEYS "
                "(this hook does not wrap this resource yet)."
            )
        assert items_field in _LIST_RESPONSE_ITEM_KEYS, (
            f"SDK's {response_cls} uses items field {items_field!r}, but "
            "_LIST_RESPONSE_ITEM_KEYS in hooks/arize_ax.py does not include it. "
            "_structure_list_response will return an empty list, silently "
            "dropping every item the API returned. Either add the field name "
            "to _LIST_RESPONSE_ITEM_KEYS, or add it to "
            "_UNWRAPPED_LIST_RESPONSE_KEYS in this test if the hook does not "
            "wrap this resource."
        )
