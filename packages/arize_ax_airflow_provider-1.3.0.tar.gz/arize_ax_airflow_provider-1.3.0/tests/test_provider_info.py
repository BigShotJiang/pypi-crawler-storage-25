"""Validate provider metadata returned by get_provider_info().

These tests ensure that provider discovery works correctly when the package
is installed in an Airflow environment.  Mirrors the validation pattern used
by apache-airflow-providers-google and other first-party providers.
"""

from __future__ import annotations

import importlib

import pytest
from airflow.providers.arize_ax.get_provider_info import get_provider_info


class TestProviderInfoStructure:
    """Validate the shape and required keys of provider metadata."""

    @pytest.fixture(autouse=True)
    def _load_info(self):
        self.info = get_provider_info()

    def test_returns_dict(self):
        assert isinstance(self.info, dict)

    @pytest.mark.parametrize(
        "key",
        [
            "package-name",
            "name",
            "description",
            "version",
            "connection-types",
            "hooks",
            "operators",
            "sensors",
            "extra-links",
        ],
    )
    def test_has_required_key(self, key):
        assert key in self.info, f"Missing required key: {key}"

    def test_package_name(self):
        assert self.info["package-name"] == "arize-ax-airflow-provider"

    def test_version_is_string(self):
        assert isinstance(self.info["version"], str)
        assert len(self.info["version"]) > 0


class TestProviderInfoConnectionTypes:
    """Validate connection type registration."""

    @pytest.fixture(autouse=True)
    def _load_info(self):
        self.info = get_provider_info()

    def test_has_arize_ax_connection_type(self):
        conn_types = self.info["connection-types"]
        assert len(conn_types) >= 1
        ct = conn_types[0]
        assert ct["connection-type"] == "arize_ax"
        assert "hook-class-name" in ct

    def test_hook_class_is_importable(self):
        conn_types = self.info["connection-types"]
        hook_path = conn_types[0]["hook-class-name"]
        module_path, _, class_name = hook_path.rpartition(".")
        mod = importlib.import_module(module_path)
        assert hasattr(mod, class_name)


class TestProviderInfoOperators:
    """Validate all registered operator modules are importable."""

    @pytest.fixture(autouse=True)
    def _load_info(self):
        self.info = get_provider_info()

    def test_has_operators(self):
        assert len(self.info["operators"]) >= 1

    @pytest.mark.parametrize(
        "module_path",
        [
            entry["python-modules"]
            for entry in get_provider_info()["operators"]
            for _ in [None]  # flatten
        ][0],
    )
    def test_operator_module_importable(self, module_path):
        mod = importlib.import_module(module_path)
        assert mod is not None


class TestProviderInfoSensors:
    """Validate registered sensor modules."""

    def test_has_sensors(self):
        info = get_provider_info()
        assert len(info["sensors"]) >= 1

    def test_sensor_module_importable(self):
        info = get_provider_info()
        for sensor_group in info["sensors"]:
            for module_path in sensor_group["python-modules"]:
                mod = importlib.import_module(module_path)
                assert mod is not None


class TestProviderInfoExtraLinks:
    """Validate registered extra links are importable."""

    @pytest.mark.parametrize(
        "link_class_path",
        get_provider_info()["extra-links"],
    )
    def test_extra_link_importable(self, link_class_path):
        module_path, _, class_name = link_class_path.rpartition(".")
        mod = importlib.import_module(module_path)
        assert hasattr(mod, class_name)
        cls = getattr(mod, class_name)
        assert hasattr(cls, "get_link")
