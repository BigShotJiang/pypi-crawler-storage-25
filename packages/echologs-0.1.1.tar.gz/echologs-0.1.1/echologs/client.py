import requests

BASE_URL = "https://echologs-app.vercel.app"

class EchoLogsClient:
    def __init__(self, api_key, base_url=None):
        self.api_key  = api_key
        self.base_url = (base_url or BASE_URL).rstrip('/')

    def send(self, script_name, status, stdout=None, stderr=None, error=None, duration_ms=None):
        try:
            requests.post(
                f"{self.base_url}/api/ingest",
                json={
                    "script_name": script_name,
                    "status":      status,
                    "stdout":      stdout,
                    "stderr":      stderr,
                    "error":       error,
                    "duration_ms": duration_ms,
                },
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10,
            )
        except Exception as e:
            print(f"[EchoLogs] Warning: {e}")