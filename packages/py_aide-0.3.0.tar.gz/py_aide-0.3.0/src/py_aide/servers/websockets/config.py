"""
WebSocket Configuration - Master Container with Runtime Update Support

This file imports all module-specific configs and combines them into one master config.
It includes a configuration manager that allows runtime updates with validation,
history tracking, and rollback capabilities.

File Structure:
    config.py (this file) - Master container + ConfigManager
    engine.py - Defines EngineConfig and WebSocketEngine
    security.py - Defines SecurityConfig and WebSocketSecurityManager
    limits.py - Defines LimitsConfig and WebSocketLimitsManager
    protocol.py - Defines ProtocolConfig and WebSocketProtocolManager
    metrics.py - Defines MetricsConfig and WebSocketMetricsManager
"""

import time
import json
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List
from collections import deque
import threading

# Import configs from each module
from .engine import EngineConfig
from .security import SecurityConfig
from .limits import LimitsConfig
from .protocol import ProtocolConfig
from .metrics import MetricsConfig


# ============================================================================
# MASTER CONFIG CLASS
# ============================================================================

@dataclass
class WebSocketConfig:
    """
    Master WebSocket Configuration
    
    This is a container that holds all module-specific configurations.
    Each module is responsible for its own config class, validation, and defaults.
    The ConfigManager handles runtime updates to these settings.
    
    Example:
        >>> config = WebSocketConfig(
        ...     engine=EngineConfig(ping_interval=30),
        ...     security=SecurityConfig(require_auth_for_all_events=True)
        ... )
    """
    
    # Engine settings
    engine: EngineConfig = field(default_factory=EngineConfig)
    """
    Engine configuration.
    Controls connection lifecycle, CORS, message size limits, etc.
    """
    
    # Security settings
    security: SecurityConfig = field(default_factory=SecurityConfig)
    """
    Security configuration.
    Controls authentication requirements, token refresh, etc.
    """
    
    # Limits settings
    limits: LimitsConfig = field(default_factory=LimitsConfig)
    """
    Limits configuration.
    Controls rate limiting, quotas, backpressure, etc.
    """
    
    # Protocol settings
    protocol: ProtocolConfig = field(default_factory=ProtocolConfig)
    """
    Protocol configuration.
    Controls message format, acknowledgments, sessions, etc.
    """
    
    # Metrics settings
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    """
    Metrics configuration.
    Controls statistics collection, dashboards, alerts, etc.
    """
    
    def __post_init__(self):
        """Validate that all sub-configs are present."""
        assert self.engine is not None, "engine config cannot be None"
        assert self.security is not None, "security config cannot be None"
        assert self.limits is not None, "limits config cannot be None"
        assert self.protocol is not None, "protocol config cannot be None"
        assert self.metrics is not None, "metrics config cannot be None"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entire config to dictionary for serialization."""
        return {
            'engine': asdict(self.engine),
            'security': asdict(self.security),
            'limits': asdict(self.limits),
            'protocol': asdict(self.protocol),
            'metrics': asdict(self.metrics)
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WebSocketConfig':
        """Create config from dictionary."""
        return cls(
            engine=EngineConfig(**data.get('engine', {})),
            security=SecurityConfig(**data.get('security', {})),
            limits=LimitsConfig(**data.get('limits', {})),
            protocol=ProtocolConfig(**data.get('protocol', {})),
            metrics=MetricsConfig(**data.get('metrics', {}))
        )
    
    @classmethod
    def development(cls) -> 'WebSocketConfig':
        """Development-friendly configuration."""
        return cls(
            engine=EngineConfig(
                cors_allowed_origins=["*"],
                log_level="debug"
            ),
            security=SecurityConfig(
                reject_unauthenticated=False
            ),
            limits=LimitsConfig(
                max_messages_per_minute_per_user=1_000
            ),
            protocol=ProtocolConfig(),
            metrics=MetricsConfig(enabled=True)
        )
    
    @classmethod
    def production(cls) -> 'WebSocketConfig':
        """Production-hardened configuration."""
        return cls(
            engine=EngineConfig(
                cors_allowed_origins=[],
                log_level="warning",
                max_connections_per_ip=50,
                max_connections_per_user=3
            ),
            security=SecurityConfig(
                require_auth_for_all_events=True,
                reject_unauthorized_connections=True
            ),
            limits=LimitsConfig(
                max_messages_per_minute_per_user=30,
                max_message_size=128 * 1024
            ),
            protocol=ProtocolConfig(),
            metrics=MetricsConfig(enabled=True, stats_interval=60)
        )


# ============================================================================
# CONFIGURATION CHANGE RECORD
# ============================================================================

@dataclass
class ConfigChange:
    """Record of a single configuration change."""
    
    timestamp: float
    """When the change occurred."""
    
    module: str
    """Which module was changed (engine, security, etc.)."""
    
    setting: str
    """Which setting was changed."""
    
    old_value: Any
    """Previous value."""
    
    new_value: Any
    """New value."""
    
    success: bool
    """Whether the change was applied."""
    
    error: Optional[str] = None
    """Error message if change failed."""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'timestamp': self.timestamp,
            'datetime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.timestamp)),
            'module': self.module,
            'setting': self.setting,
            'old_value': str(self.old_value),
            'new_value': str(self.new_value),
            'success': self.success,
            'error': self.error
        }


# ============================================================================
# CONFIGURATION MANAGER (Handles Runtime Updates)
# ============================================================================

class WebSocketConfigManager:
    """
    Manages WebSocket configuration with runtime update capabilities.
    
    Features:
    - Runtime updates with module-level validation
    - Full change history
    - Rollback to previous states
    - Thread-safe operations
    - Audit trail of all changes
    
    Each module (engine, security, etc.) is responsible for:
    1. Validating changes to its own settings
    2. Applying updates at runtime
    3. Providing update methods for its settings
    
    Example:
        >>> manager = WebSocketConfigManager(initial_config)
        >>> 
        >>> # Update a setting (validated by engine module)
        >>> success = manager.update('engine', 'ping_interval', 45)
        >>> 
        >>> # Update multiple settings at once
        >>> success = manager.update_batch('engine', {
        ...     'ping_interval': 45,
        ...     'ping_timeout': 15
        ... })
        >>> 
        >>> # Rollback to previous state
        >>> manager.rollback()
        >>> 
        >>> # View change history
        >>> history = manager.get_history()
    """
    
    def __init__(self, initial_config: WebSocketConfig):
        """
        Initialize the config manager.
        
        Args:
            initial_config: Starting configuration
        """
        self._config = initial_config
        self._history: deque = deque(maxlen=1_000)  # Keep last 1000 changes
        self._snapshots: deque = deque(maxlen=50)  # Keep last 50 full snapshots
        self._lock = threading.RLock()
        
        # Store module references for updates
        self._modules = {
            'engine': initial_config.engine,
            'security': initial_config.security,
            'limits': initial_config.limits,
            'protocol': initial_config.protocol,
            'metrics': initial_config.metrics
        }
        
        # Record initial state
        self._take_snapshot()
        self._record_change(
            module='system',
            setting='initialized',
            old_value=None,
            new_value=initial_config.to_dict(),
            success=True
        )
    
    @property
    def config(self) -> WebSocketConfig:
        """Get current configuration."""
        return self._config
    
    # ========================================================================
    # UPDATE METHODS
    # ========================================================================
    
    def update(self, module: str, setting: str, value: Any) -> bool:
        """
        Update a single configuration setting at runtime.
        
        Args:
            module: Module name ('engine', 'security', 'limits', 'protocol', 'metrics')
            setting: Setting name within that module
            value: New value
            
        Returns:
            True if update successful, False otherwise
            
        Example:
            >>> manager.update('engine', 'ping_interval', 45)
        """
        with self._lock:
            # Check if module exists
            if module not in self._modules:
                self._record_change(
                    module=module,
                    setting=setting,
                    old_value=None,
                    new_value=value,
                    success=False,
                    error=f"Unknown module: {module}"
                )
                return False
            
            module_obj = self._modules[module]
            
            # Check if setting exists
            if not hasattr(module_obj, setting):
                self._record_change(
                    module=module,
                    setting=setting,
                    old_value=None,
                    new_value=value,
                    success=False,
                    error=f"Unknown setting: {module}.{setting}"
                )
                return False
            
            # Get old value
            old_value = getattr(module_obj, setting)
            
            # Try to validate and update
            try:
                # Each module is responsible for validating its own updates
                # They should raise ValueError if invalid
                self._apply_update(module_obj, setting, value)
                
                # Record successful change
                self._record_change(
                    module=module,
                    setting=setting,
                    old_value=old_value,
                    new_value=value,
                    success=True
                )
                
                # Take snapshot periodically (every 10 changes)
                if len(self._history) % 10 == 0:
                    self._take_snapshot()
                
                return True
                
            except ValueError as e:
                # Validation failed
                self._record_change(
                    module=module,
                    setting=setting,
                    old_value=old_value,
                    new_value=value,
                    success=False,
                    error=str(e)
                )
                return False
    
    def update_batch(self, module: str, updates: Dict[str, Any]) -> bool:
        """
        Update multiple settings in a module at once.
        
        All updates are validated before any are applied.
        If any validation fails, no changes are made.
        
        Args:
            module: Module name
            updates: Dictionary of {setting: value} pairs
            
        Returns:
            True if all updates successful, False otherwise
        """
        with self._lock:
            if module not in self._modules:
                return False
            
            module_obj = self._modules[module]
            
            # First, validate all changes
            old_values = {}
            for setting, value in updates.items():
                if not hasattr(module_obj, setting):
                    return False
                
                old_values[setting] = getattr(module_obj, setting)
                
                # Each module should have a validate_* method
                validator = getattr(module_obj, f"validate_{setting}", None)
                if validator:
                    try:
                        validator(value)
                    except ValueError:
                        return False
            
            # If all valid, apply all changes
            for setting, value in updates.items():
                old_value = old_values[setting]
                setattr(module_obj, setting, value)
                
                self._record_change(
                    module=module,
                    setting=setting,
                    old_value=old_value,
                    new_value=value,
                    success=True
                )
            
            self._take_snapshot()
            return True
    
    def _apply_update(self, module_obj: Any, setting: str, value: Any) -> None:
        """
        Apply an update to a module after validation.
        
        Modules can implement custom validation by providing
        a validate_<setting> method that raises ValueError if invalid.
        """
        # Check for custom validator
        validator = getattr(module_obj, f"validate_{setting}", None)
        if validator:
            validator(value)  # May raise ValueError
        
        # Apply the update
        setattr(module_obj, setting, value)
        
        # Check for post-update hook
        hook = getattr(module_obj, f"on_{setting}_updated", None)
        if hook:
            hook(value)
    
    # ========================================================================
    # ROLLBACK METHODS
    # ========================================================================
    
    def rollback(self, steps: int = 1) -> bool:
        """
        Roll back to a previous configuration snapshot.
        
        Args:
            steps: Number of snapshots to roll back (default 1)
            
        Returns:
            True if rollback successful, False otherwise
        """
        with self._lock:
            if len(self._snapshots) <= steps:
                return False
            
            # Get target snapshot
            import copy
            target_idx = len(self._snapshots) - 1 - steps
            target_config = copy.deepcopy(self._snapshots[target_idx])
            
            # Store old config for history
            old_config = self._config.to_dict()
            
            # Apply rollback
            self._config = target_config
            self._modules = {
                'engine': target_config.engine,
                'security': target_config.security,
                'limits': target_config.limits,
                'protocol': target_config.protocol,
                'metrics': target_config.metrics
            }
            
            # Record rollback
            self._record_change(
                module='system',
                setting='rollback',
                old_value=old_config,
                new_value=target_config.to_dict(),
                success=True
            )
            
            # Trim snapshots after rollback point
            while len(self._snapshots) > target_idx + 1:
                self._snapshots.pop()
            
            return True
    
    def reset_to_initial(self) -> None:
        """Reset to the initial configuration (first snapshot)."""
        with self._lock:
            if self._snapshots:
                import copy
                initial = copy.deepcopy(self._snapshots[0])
                
                old_config = self._config.to_dict()
                
                self._config = initial
                self._modules = {
                    'engine': initial.engine,
                    'security': initial.security,
                    'limits': initial.limits,
                    'protocol': initial.protocol,
                    'metrics': initial.metrics
                }
                
                self._record_change(
                    module='system',
                    setting='reset',
                    old_value=old_config,
                    new_value=initial.to_dict(),
                    success=True
                )
    
    # ========================================================================
    # HISTORY AND AUDIT
    # ========================================================================
    
    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get configuration change history."""
        with self._lock:
            return [c.to_dict() for c in list(self._history)[-limit:]]
    
    def get_recent_changes(self, minutes: int = 60) -> List[Dict[str, Any]]:
        """Get changes from the last N minutes."""
        cutoff = time.time() - (minutes * 60)
        with self._lock:
            recent = [c for c in self._history if c.timestamp >= cutoff]
            return [c.to_dict() for c in recent]
    
    def get_change_count(self) -> int:
        """Get total number of changes recorded."""
        return len(self._history)
    
    # ========================================================================
    # SNAPSHOT MANAGEMENT
    # ========================================================================
    
    def take_snapshot(self) -> None:
        """Manually trigger a configuration snapshot."""
        self._take_snapshot()
    
    def list_snapshots(self) -> List[float]:
        """Get timestamps of all snapshots."""
        with self._lock:
            return [s.timestamp for s in self._snapshots]
    
    def _take_snapshot(self):
        """Internal method to take a configuration snapshot."""
        import copy
        self._snapshots.append(copy.deepcopy(self._config))
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def _record_change(self, module: str, setting: str, old_value: Any, 
                       new_value: Any, success: bool, error: Optional[str] = None):
        """Record a configuration change."""
        change = ConfigChange(
            timestamp=time.time(),
            module=module,
            setting=setting,
            old_value=old_value,
            new_value=new_value,
            success=success,
            error=error
        )
        self._history.append(change)
    
    def export_history(self, filepath: str) -> None:
        """Export change history to a JSON file."""
        with open(filepath, 'w') as f:
            json.dump([c.to_dict() for c in self._history], f, indent=2)
    
    def get_status(self) -> Dict[str, Any]:
        """Get manager status summary."""
        return {
            'total_changes': len(self._history),
            'snapshots': len(self._snapshots),
            'last_change': self._history[-1].to_dict() if self._history else None,
            'modules': list(self._modules.keys())
        }


# ============================================================================
# CONVENIENCE FUNCTION
# ============================================================================

def create_config_manager(env: str = 'development', **overrides) -> WebSocketConfigManager:
    """
    Convenience function to create a config manager with environment defaults.
    
    Args:
        env: 'development' or 'production'
        **overrides: Individual setting overrides in dot notation
                    (e.g., engine.ping_interval=45)
    
    Returns:
        Configured WebSocketConfigManager
    
    Example:
        >>> manager = create_config_manager(
        ...     env='production',
        ...     **{'engine.ping_interval': 45}
        ... )
    """
    # Create base config
    if env == 'production':
        config = WebSocketConfig.production()
    else:
        config = WebSocketConfig.development()
    
    # Apply overrides
    for key, value in overrides.items():
        module, setting = key.split('.')
        if hasattr(config, module):
            module_obj = getattr(config, module)
            if hasattr(module_obj, setting):
                setattr(module_obj, setting, value)
    
    return WebSocketConfigManager(config)