"""SDLC add-on system — pinned, idempotent open-source extension recipes.

Public API: see :mod:`sdlc_framework.addons.cli` for the ``sdlc addons``
subcommand entry point. Modules in this package are layered:

    schema   — pure data: Recipe / Lockfile dataclasses + validation
    loader   — read recipes from scaffold + project-local YAML files
    injector — apply doc-snippet / agent-instruction (marker-based, idempotent)
    fetcher  — apply remote-fetch (git sparse-checkout, pin-verified)
    lockfile — read/write automation/addons.lock
    cli      — argparse dispatch + interactive prompts
"""
