"""Read recipe YAML files from built-in and project-local locations.

Search order (later overrides earlier on duplicate id):
  1. Built-in: ``<package>/scaffold/addons/*.yaml``
  2. Project-local: ``<project>/automation/addons/*.yaml``

A duplicate ID across the two locations is intentional — local override of a
built-in recipe is a valid extension point and is not a fatal error.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from .schema import Recipe, SchemaError, parse_recipe

BUILTIN_RELATIVE = Path("scaffold") / "addons"
PROJECT_RELATIVE = Path("automation") / "addons"


def _builtin_dir() -> Path:
    """Directory of built-in recipes shipped with the package."""
    here = Path(__file__).resolve().parent.parent  # sdlc_framework/
    return here / BUILTIN_RELATIVE


def load_all(project_root: Path) -> dict[str, Recipe]:
    """Return a ``{recipe_id: Recipe}`` map.

    Errors in any single recipe raise ``SchemaError`` mentioning the source
    file, so a typo doesn't silently shadow a working recipe.
    """
    out: dict[str, Recipe] = {}
    for src in _iter_recipe_files(project_root):
        text = src.read_text(encoding="utf-8")
        try:
            data = yaml.safe_load(text) or {}
        except yaml.YAMLError as e:
            raise SchemaError(f"{src}: invalid YAML: {e}") from e
        recipe = parse_recipe(data, source=str(src))
        if recipe.id != src.stem:
            raise SchemaError(
                f"{src}: recipe id {recipe.id!r} must match filename "
                f"{src.stem!r} (one recipe per file)"
            )
        out[recipe.id] = recipe   # later iterations override earlier
    return out


def _iter_recipe_files(project_root: Path):
    """Yield ``Path`` objects for built-in then project-local recipes."""
    builtin = _builtin_dir()
    if builtin.is_dir():
        yield from sorted(builtin.glob("*.yaml"))
    proj = project_root / PROJECT_RELATIVE
    if proj.is_dir():
        yield from sorted(proj.glob("*.yaml"))


def load_recipe(project_root: Path, recipe_id: str) -> Recipe:
    """Load a single recipe by ID. Raises ``SchemaError`` if not found."""
    all_ = load_all(project_root)
    if recipe_id not in all_:
        raise SchemaError(
            f"recipe {recipe_id!r} not found "
            f"(built-in: {_builtin_dir()}, project: "
            f"{project_root / PROJECT_RELATIVE})"
        )
    return all_[recipe_id]
