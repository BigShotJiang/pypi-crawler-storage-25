"""Marker-based snippet injection — idempotent, drift-detecting, reversible.

Every snippet is wrapped in HTML-comment markers so install/remove can
locate it unambiguously. The 4-hex content hash inside the start marker
detects user edits inside the marker block (drift).

The same module handles ``doc-snippet`` and ``agent-instruction`` since
they share the marker mechanism — the kind difference is metadata only.

**Whitespace contract** — the marker block in the file is:

    <leading-separator>            (one blank line if file already had content)
    <!-- sdlc:addon:ID#SID:start HASH -->
    <content body, exactly as in recipe, normalized to end with newline>
    <!-- sdlc:addon:ID#SID:end -->
    <trailing-newline>

Replace replaces only the marker pair + their inner content; the
leading separator and trailing newline are reused, so the surrounding
file structure is preserved exactly.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .schema import (
    AgentInstruction,
    DocSnippet,
    marker_end,
    marker_start,
    short_hash,
)

DriftAction = Literal["overwrite", "skip"]


@dataclass(frozen=True)
class InjectionResult:
    target: str
    section_id: str
    content_hash: str
    drift: bool
    action: Literal["created", "replaced", "drift-skipped", "drift-overwrote"]


@dataclass(frozen=True)
class RemovalResult:
    target: str
    section_id: str
    found: bool


def inject_snippet(
    project_root: Path,
    addon_id: str,
    inject: DocSnippet | AgentInstruction,
    *,
    drift_action: DriftAction = "skip",
) -> InjectionResult:
    """Append-or-replace a marker-wrapped snippet inside the target file."""
    path = project_root / inject.target
    if not path.exists():
        raise FileNotFoundError(f"target does not exist: {inject.target}")
    text = path.read_text(encoding="utf-8")
    canonical = _canonical(inject.content)
    new_hash = short_hash(canonical)
    span = _locate_markers(text, addon_id, inject.section_id)

    block = _format_block(addon_id, inject.section_id, canonical, new_hash)

    if span is None:
        # First install — append separated by a blank line.
        new_text = _append_with_blank(text, block)
        path.write_text(new_text, encoding="utf-8")
        return InjectionResult(
            target=inject.target,
            section_id=inject.section_id,
            content_hash=new_hash,
            drift=False,
            action="created",
        )

    s, e, advertised, inner = span
    actual_hash = short_hash(inner)
    drift = actual_hash != advertised

    # If hash unchanged AND no drift, the file is already correct — no rewrite.
    if not drift and advertised == new_hash:
        return InjectionResult(
            target=inject.target,
            section_id=inject.section_id,
            content_hash=new_hash,
            drift=False,
            action="replaced",
        )

    if drift and drift_action == "skip":
        return InjectionResult(
            target=inject.target,
            section_id=inject.section_id,
            content_hash=advertised,
            drift=True,
            action="drift-skipped",
        )

    new_text = text[:s] + block + text[e:]
    path.write_text(new_text, encoding="utf-8")
    return InjectionResult(
        target=inject.target,
        section_id=inject.section_id,
        content_hash=new_hash,
        drift=drift,
        action="drift-overwrote" if drift else "replaced",
    )


def remove_snippet(
    project_root: Path,
    addon_id: str,
    target: str,
    section_id: str,
) -> RemovalResult:
    """Remove a marker-wrapped block. Idempotent: missing block → ``found=False``."""
    path = project_root / target
    if not path.exists():
        return RemovalResult(target=target, section_id=section_id, found=False)
    text = path.read_text(encoding="utf-8")
    span = _locate_markers(text, addon_id, section_id)
    if span is None:
        return RemovalResult(target=target, section_id=section_id, found=False)
    s, e, _adv, _inner = span
    # Drop the leading blank-line separator and the trailing newline that
    # ``inject_snippet`` wrote — without these adjustments, install→remove
    # leaks two extra newlines into the file.
    new_s = s
    if new_s >= 2 and text[new_s - 2:new_s] == "\n\n":
        new_s -= 1
    new_e = e
    if new_e < len(text) and text[new_e] == "\n":
        new_e += 1
    new_text = text[:new_s] + text[new_e:]
    new_text = _collapse_runs(new_text)
    path.write_text(new_text, encoding="utf-8")
    return RemovalResult(target=target, section_id=section_id, found=True)


def content_hash(content: str) -> str:
    """Public helper: compute the canonical 4-hex hash for a snippet content.

    Lockfile and tests use this so that ``content_hash(c)`` matches the hash
    actually written to the marker, regardless of trailing-newline variation.
    """
    return short_hash(_canonical(content))


def detect_drift(
    project_root: Path,
    addon_id: str,
    target: str,
    section_id: str,
    expected_hash: str,
) -> Literal["clean", "drifted", "missing"]:
    path = project_root / target
    if not path.exists():
        return "missing"
    text = path.read_text(encoding="utf-8")
    span = _locate_markers(text, addon_id, section_id)
    if span is None:
        return "missing"
    _s, _e, advertised, inner = span
    if advertised != expected_hash or short_hash(inner) != expected_hash:
        return "drifted"
    return "clean"


# ---------------------------------------------------------------------------
# Block formatting + locating
# ---------------------------------------------------------------------------

def _canonical(content: str) -> str:
    """Force exactly one trailing newline.

    All hashing and storage uses this canonical form so that
    ``short_hash(canonical(written_content)) == short_hash(read_back_inner)``
    holds across install / re-install / drift-detect cycles.
    """
    return content.rstrip("\n") + "\n"


def _format_block(addon_id: str, section_id: str, canonical_content: str, h: str) -> str:
    """Return the EXACT bytes of the marker block.

    Caller passes already-canonicalized content (ends with a single \n).
    """
    return (
        f"{marker_start(addon_id, section_id, h)}\n"
        f"{canonical_content}"
        f"{marker_end(addon_id, section_id)}"
    )


def _append_with_blank(text: str, block: str) -> str:
    """Append ``block`` to ``text`` with exactly one blank line between."""
    if not text:
        return block + "\n"
    if text.endswith("\n\n"):
        return text + block + "\n"
    if text.endswith("\n"):
        return text + "\n" + block + "\n"
    return text + "\n\n" + block + "\n"


def _locate_markers(
    text: str, addon_id: str, section_id: str,
) -> tuple[int, int, str, str] | None:
    """Find ``(start_idx, end_idx, advertised_hash, inner_text)``.

    ``start_idx`` points at the ``<`` of the start marker.
    ``end_idx`` points just past the ``>`` of the end marker (NOT the trailing newline).
    """
    start_re = re.compile(
        r"<!--\s*sdlc:addon:" + re.escape(addon_id) + r"#"
        + re.escape(section_id) + r":start\s+([0-9a-f]{4})\s*-->"
    )
    end_re = re.compile(
        r"<!--\s*sdlc:addon:" + re.escape(addon_id) + r"#"
        + re.escape(section_id) + r":end\s*-->"
    )
    sm = start_re.search(text)
    if sm is None:
        return None
    em = end_re.search(text, sm.end())
    if em is None:
        raise ValueError(
            f"unterminated addon block: {addon_id}#{section_id} has start "
            f"marker but no matching end marker"
        )
    inner_raw = text[sm.end():em.start()]
    inner_normalized = _normalize_inner(inner_raw)
    return sm.start(), em.end(), sm.group(1), inner_normalized


def _normalize_inner(inner_raw: str) -> str:
    """Reconstruct the canonical content from the bytes between markers.

    The block was written as ``<start>\\n<canonical>\\n<end>`` so the bytes
    between start.end() and end.start() are ``\\n<canonical>``. Strip the
    one leading newline introduced by the layout, and re-canonicalize.
    """
    s = inner_raw
    if s.startswith("\n"):
        s = s[1:]
    return s.rstrip("\n") + "\n"


def _collapse_runs(text: str) -> str:
    """Replace 3+ consecutive newlines with 2 (one blank line max)."""
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")
    return text
