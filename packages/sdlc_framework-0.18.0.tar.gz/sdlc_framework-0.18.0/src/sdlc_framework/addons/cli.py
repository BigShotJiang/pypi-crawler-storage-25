"""``sdlc addons <subcmd>`` — list / info / install / remove / sync.

This module exposes :func:`cmd_addons` as the dispatch entry point. The
top-level ``cli.py`` registers it under the ``addons`` subcommand.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import lockfile as lockfile_mod
from . import loader
from .fetcher import FetchError, fetch, remove_fetched
from .injector import (
    content_hash,
    detect_drift,
    inject_snippet,
    remove_snippet,
)
from .lockfile import (
    AddonEntry,
    FetchEntry,
    SnippetEntry,
    upsert_addon,
)
from .schema import (
    AgentInstruction,
    AppliesTo,
    DocSnippet,
    Recipe,
    RemoteFetch,
    SchemaError,
)


# ---------------------------------------------------------------------------
# Top-level dispatch
# ---------------------------------------------------------------------------

def cmd_addons(argv: list[str], project_root: Path | None = None) -> int:
    """Dispatch to the ``addons`` subcommand. Returns process exit code."""
    parser = argparse.ArgumentParser(prog="sdlc addons")
    sub = parser.add_subparsers(dest="action", required=True)
    p_list = sub.add_parser("list", help="list available + installed add-ons")
    p_list.add_argument("--installed", action="store_true")
    p_list.add_argument("--phase", type=int, choices=[1, 2, 3, 4, 5])
    p_info = sub.add_parser("info", help="show recipe details")
    p_info.add_argument("id")
    p_install = sub.add_parser("install", help="install one or more add-ons")
    p_install.add_argument("ids", help="comma-separated add-on ids")
    p_install.add_argument("--yes", action="store_true",
                           help="skip interactive confirmation")
    p_install.add_argument("--offline", action="store_true",
                           help="skip remote-fetch entries (snippets only)")
    p_remove = sub.add_parser("remove", help="uninstall an add-on")
    p_remove.add_argument("id")
    p_sync = sub.add_parser("sync", help="apply addons.lock to filesystem")
    p_sync.add_argument("--yes", action="store_true")
    p_sync.add_argument("--offline", action="store_true")

    args = parser.parse_args(argv)
    root = project_root or Path.cwd()

    try:
        if args.action == "list":
            return _cmd_list(root, installed_only=args.installed, phase=args.phase)
        if args.action == "info":
            return _cmd_info(root, args.id)
        if args.action == "install":
            ids = [x.strip() for x in args.ids.split(",") if x.strip()]
            return _cmd_install(root, ids, yes=args.yes, offline=args.offline)
        if args.action == "remove":
            return _cmd_remove(root, args.id)
        if args.action == "sync":
            return _cmd_sync(root, yes=args.yes, offline=args.offline)
    except SchemaError as e:
        print(f"[sdlc addons] schema error: {e}", file=sys.stderr)
        return 2
    except FetchError as e:
        print(f"[sdlc addons] fetch error: {e}", file=sys.stderr)
        return 4

    parser.print_help()
    return 2


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def _cmd_list(root: Path, *, installed_only: bool, phase: int | None) -> int:
    recipes = loader.load_all(root)
    lock = lockfile_mod.read(root)

    rows: list[tuple[str, str, str, str, str]] = []
    for rid in sorted(recipes):
        r = recipes[rid]
        if phase is not None and not _matches_phase(r, phase):
            continue
        installed = rid in lock.addons
        if installed_only and not installed:
            continue
        track = ", ".join(_slot_label(a) for a in r.applies_to)
        status = "installed" if installed else "available"
        version = lock.addons[rid].version if installed else "—"
        rows.append((rid, _phase_repr(r), track, status, version))

    if not rows:
        print("No add-ons match the filter.")
        return 0

    headers = ("ID", "PHASE", "TRACK", "STATUS", "VERSION")
    widths = [max(len(headers[i]), max(len(r[i]) for r in rows)) for i in range(5)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    print(fmt.format(*headers))
    for r in rows:
        print(fmt.format(*r))
    return 0


def _matches_phase(r: Recipe, phase: int) -> bool:
    return any(a.phase == phase for a in r.applies_to)


def _phase_repr(r: Recipe) -> str:
    phases = sorted({a.phase for a in r.applies_to if a.phase is not None})
    if not phases:
        return "cross"
    return ",".join(str(p) for p in phases)


def _slot_label(a: AppliesTo) -> str:
    if a.phase is None:
        return "cross"
    return f"{a.phase}/{a.subtrack}"


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------

def _cmd_info(root: Path, addon_id: str) -> int:
    r = loader.load_recipe(root, addon_id)
    print(f"{r.name}  ({r.id})")
    print(f"Phase    : {_phase_repr(r)}")
    print(f"Track    : {', '.join(_slot_label(a) for a in r.applies_to)}")
    print(f"License  : {r.license}")
    print(f"Homepage : {r.homepage}")
    print(f"Description: {r.description}")
    print()
    print("Will inject:")
    for inj in r.injects:
        if isinstance(inj, DocSnippet):
            print(f"  • doc-snippet  → {inj.target}  (section: {inj.section_id})")
        elif isinstance(inj, AgentInstruction):
            print(f"  • agent-instr  → {inj.target}  (section: {inj.section_id})")
        elif isinstance(inj, RemoteFetch):
            print(f"  • remote-fetch ← {inj.from_url}  @ {inj.pin}")
            for s in inj.select:
                print(f"      {s.from_pat}  →  {s.to}")
    return 0


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------

def _cmd_install(
    root: Path, ids: list[str], *, yes: bool, offline: bool,
) -> int:
    if not ids:
        print("[sdlc addons] no ids provided", file=sys.stderr)
        return 2
    recipes = loader.load_all(root)
    missing = [rid for rid in ids if rid not in recipes]
    if missing:
        print(f"[sdlc addons] unknown add-ons: {missing}", file=sys.stderr)
        return 2

    fetch_recipes = [
        recipes[rid] for rid in ids
        if any(isinstance(i, RemoteFetch) for i in recipes[rid].injects)
    ]
    if fetch_recipes and not offline and not yes:
        print("[sdlc addons] the following add-ons will fetch remote content:")
        for r in fetch_recipes:
            for inj in r.injects:
                if isinstance(inj, RemoteFetch):
                    print(f"  • {r.id}: {inj.from_url} @ {inj.pin}")
                    print(f"      license: {r.license}    homepage: {r.homepage}")
        if not _confirm():
            print("[sdlc addons] aborted.")
            return 0

    lock = lockfile_mod.read(root)
    rc = 0
    for rid in ids:
        rc |= _install_one(root, recipes[rid], lock, offline=offline)
        lock = lockfile_mod.read(root)   # re-read after each install
    return rc


def _install_one(
    root: Path, recipe: Recipe, lock, *, offline: bool,
) -> int:
    print(f"[sdlc addons] installing {recipe.id}…")
    snippets: list[SnippetEntry] = []
    fetched: FetchEntry | None = None
    resolved_sha = "—"
    version = "—"

    for inj in recipe.injects:
        if isinstance(inj, (DocSnippet, AgentInstruction)):
            result = inject_snippet(root, recipe.id, inj)
            print(f"    {result.action}: {inj.target}#{inj.section_id}")
            snippets.append(SnippetEntry(
                target=inj.target,
                section_id=inj.section_id,
                content_hash=result.content_hash,
            ))
        elif isinstance(inj, RemoteFetch):
            if offline:
                print(f"    skipped (offline): fetch {inj.from_url}")
                continue
            res = fetch(root, inj)
            resolved_sha = res.resolved_sha
            version = inj.pin
            print(f"    fetched {len(res.files)} files → {res.to}")
            fetched = FetchEntry(to=res.to, files=list(res.files))

    if version == "—":
        # Snippet-only addon — record sdlc version as the "version" stamp.
        from sdlc_framework import __version__ as sdlc_v
        version = f"snippet-only@{sdlc_v}"
        resolved_sha = "snippet-only"

    from sdlc_framework import __version__ as sdlc_v
    entry = AddonEntry(
        version=version,
        resolved_sha=resolved_sha,
        installed_at=lockfile_mod.utc_now_iso(),
        sdlc_version=sdlc_v,
        snippets=snippets,
        fetched=fetched,
    )
    lockfile_mod.write(root, upsert_addon(lock, recipe.id, entry))
    return 0


# ---------------------------------------------------------------------------
# remove
# ---------------------------------------------------------------------------

def _cmd_remove(root: Path, addon_id: str) -> int:
    lock = lockfile_mod.read(root)
    if addon_id not in lock.addons:
        print(f"[sdlc addons] {addon_id} is not installed", file=sys.stderr)
        return 2
    entry = lock.addons[addon_id]
    print(f"[sdlc addons] removing {addon_id}…")

    for s in entry.snippets:
        result = remove_snippet(root, addon_id, s.target, s.section_id)
        status = "removed" if result.found else "already absent"
        print(f"    snippet {status}: {s.target}#{s.section_id}")

    if entry.fetched is not None:
        summary = remove_fetched(
            root, list(entry.fetched.files), to=entry.fetched.to,
        )
        print(f"    fetched files: deleted={len(summary['deleted'])}, "
              f"kept={len(summary['kept'])}")

    lockfile_mod.write(root, lockfile_mod.remove_addon(lock, addon_id))
    return 0


# ---------------------------------------------------------------------------
# sync — re-apply lockfile to filesystem (e.g. after fresh clone)
# ---------------------------------------------------------------------------

def _cmd_sync(root: Path, *, yes: bool, offline: bool) -> int:
    lock = lockfile_mod.read(root)
    if not lock.addons:
        print("[sdlc addons] addons.lock is empty — nothing to sync.")
        return 0
    recipes = loader.load_all(root)
    rc = 0
    for rid, entry in lock.addons.items():
        if rid not in recipes:
            print(f"[sdlc addons] sync: recipe for {rid} not available; "
                  "leaving as-is", file=sys.stderr)
            continue
        recipe = recipes[rid]
        # Re-inject snippets if they're missing or drifted (drift → skip)
        for inj in recipe.injects:
            if isinstance(inj, (DocSnippet, AgentInstruction)):
                expected = content_hash(inj.content)
                state = detect_drift(root, rid, inj.target, inj.section_id, expected)
                if state == "missing":
                    inject_snippet(root, rid, inj)
                    print(f"    sync: re-installed snippet {inj.target}#{inj.section_id}")
            elif isinstance(inj, RemoteFetch):
                if offline:
                    print(f"    sync: skipped fetch (offline): {inj.from_url}")
                    continue
                # Re-fetch only if files are missing
                if entry.fetched is None or not all(
                    (root / f).exists() for f in entry.fetched.files
                ):
                    if not yes and not _confirm(
                        f"re-fetch {inj.from_url} @ {inj.pin}?",
                    ):
                        print(f"    sync: skipped fetch by user request")
                        continue
                    fetch(root, inj)
                    print(f"    sync: re-fetched {inj.from_url}")
    return rc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _confirm(prompt: str = "Proceed?") -> bool:
    """Yes/no prompt. Default ``no`` if input is empty or non-tty."""
    if not sys.stdin.isatty():
        return False
    try:
        ans = input(f"{prompt} [y/N] ").strip().lower()
    except EOFError:
        return False
    return ans in ("y", "yes")
