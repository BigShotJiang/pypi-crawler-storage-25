"""Read automation/tasks/*.yaml task files and compute current stage per task.

Inject as Phase 3 Tasks sub-track items into engine state.
"""
from __future__ import annotations

import datetime as _dt
import json as _json
import subprocess
from pathlib import Path

import yaml


def _utcnow_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def resolve_active_group(
    state: dict,
    tasks: list[dict],  # noqa: ARG001 — kept for future extension
    group_done_pairs: list[tuple[str, bool]],
) -> str | None:
    """Pick or promote the active feature_id (or task.id) for Phase 3.

    ``group_done_pairs`` is a list of ``(group_id, all_tasks_done)`` in
    the order groups should be considered for promotion (yaml file-name
    order is the engine convention).

    Mutates ``state["phase3"]`` in place. Returns the active group id,
    or None when all groups are done.
    """
    state.setdefault("phase3", {"active_feature_id": None, "lock_acquired_at": None})
    p3 = state["phase3"]
    current = p3.get("active_feature_id")
    by_id = {gid: done for gid, done in group_done_pairs}
    if current and current in by_id and not by_id[current]:
        return current
    for gid, done in group_done_pairs:
        if not done:
            p3["active_feature_id"] = gid
            p3["lock_acquired_at"] = _utcnow_iso()
            return gid
    p3["active_feature_id"] = None
    p3["lock_acquired_at"] = None
    return None

VALID_STAGES = ["pending", "write-tests", "write-code", "review", "await-merge", "done"]
# Stage labels reflect the *current activity* (what is happening NOW), not
# the deliverable already produced. ``pending`` means the task is queued
# behind the Phase 3 serial lock — not currently being worked on. The
# active ladder is ``write-tests → write-code → review → await-merge →
# done``; each label names the activity in flight, not the artifact already
# committed. This was a deliberate rename in 0.16.0 — the prior scheme
# made the dashboard appear one nhịp behind real activity.
HIGH_RISK_HINTS = ["auth", "crypto", "payment", "secrets", "iam", "migration"]


def load_tasks(target: Path) -> list[dict]:
    """Load all automation/tasks/*.yaml. Returns task dicts (passes through unchanged)."""
    tasks_dir = target / "automation" / "tasks"
    if not tasks_dir.exists():
        return []
    out: list[dict] = []
    for f in sorted(tasks_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or not data.get("id"):
            continue
        out.append(data)
    return out


def _glob_paths(target: Path, pattern: str) -> set[Path]:
    """Return resolved files matching glob from target root, handling brace expansion."""
    from sdlc_framework import engine
    saved = engine.ROOT
    try:
        engine.ROOT = target
        return {p.resolve() for p in engine._glob(pattern)}
    finally:
        engine.ROOT = saved


def _glob_count(target: Path, pattern: str) -> int:
    """Count files matching glob from target root, handling brace expansion."""
    return len(_glob_paths(target, pattern))


def _pr_status_batch(branches: list[str], target: Path) -> dict[str, str]:
    """Return ``{branch: status}`` for every input branch in ONE `gh` call.

    Status is ``'open'``, ``'merged'``, or ``'none'``. Performs one
    ``gh pr list --json --state all --limit N`` instead of N separate
    ``gh pr view`` calls. Falls back to ``{}`` (caller treats as 'none')
    when ``gh`` is missing, unauthenticated, offline, or times out.

    This is the perf hot path during ``sdlc scan`` — N tasks used to
    mean N × up-to-5s subprocess calls and N × API quota burn.
    """
    out: dict[str, str] = {}
    branches = [b for b in branches if b]
    if not branches:
        return out
    # Cap at 200 — sane upper bound; exceeding this means a project has
    # accumulated too many task PRs and should archive some anyway.
    limit = max(200, len(branches) * 2)
    try:
        result = subprocess.run(
            ["gh", "pr", "list",
             "--state", "all",
             "--limit", str(limit),
             "--json", "headRefName,state"],
            capture_output=True, text=True, timeout=10, cwd=str(target),
        )
        if result.returncode != 0:
            return out
        data = _json.loads(result.stdout or "[]")
    except Exception:
        return out
    wanted = set(branches)
    # Track per-branch best status — prefer 'merged' over 'open' over 'none'
    # in case the same head branch has multiple PR records (rare but possible
    # after re-opening / closing).
    rank = {"merged": 2, "open": 1, "none": 0}
    for entry in data:
        head = entry.get("headRefName") or ""
        if head not in wanted:
            continue
        state = (entry.get("state") or "").upper()
        if state == "MERGED":
            status = "merged"
        elif state in ("OPEN", "DRAFT"):
            status = "open"
        else:
            continue
        if rank[status] > rank.get(out.get(head, "none"), 0):
            out[head] = status
    return out


def _pr_status(branch: str, target: Path) -> str:
    """Single-branch status query (legacy / fallback path).

    Prefer ``_pr_status_batch`` from a scan loop; this exists for callers
    that have only one branch on hand or for back-compat with older code.
    """
    if not branch:
        return "none"
    return _pr_status_batch([branch], target).get(branch, "none")


def _resolve_feature_branches(tasks: list[dict]) -> dict[str, str]:
    """Map ``feature_id`` → canonical PR branch shared by all siblings.

    Task yamls may opt in to feature grouping by declaring
    ``feature_id: <slug>``. All tasks sharing a feature_id then share
    one PR (instead of N PRs for one user requirement). The branch is
    resolved as:

      1. The first explicit ``pr_branch`` declared on any sibling
         (file-sort order — ``load_tasks`` returns sorted yamls).
      2. ``feature/<feature_id>`` as a deterministic fallback.

    Tasks without ``feature_id`` are not represented in the returned
    map; they retain their per-task ``pr_branch`` via the legacy path.
    """
    explicit: dict[str, str] = {}
    seen: set[str] = set()
    for t in tasks:
        fid = t.get("feature_id")
        if not fid:
            continue
        seen.add(fid)
        if fid not in explicit and t.get("pr_branch"):
            explicit[fid] = t["pr_branch"]
    return {fid: explicit.get(fid, f"feature/{fid}") for fid in seen}


def detect_stage(
    task: dict,
    target: Path,
    pr_cache: dict[str, str] | None = None,
    override_branch: str | None = None,
    *,
    is_active: bool = True,
) -> str:
    """Determine the task's current stage from filesystem + git/gh state.

    ``pr_cache`` maps branch → ``'open'|'merged'|'none'``. Pass one when
    looping over many tasks to avoid one ``gh`` subprocess per task.
    When ``None``, falls back to a per-task lookup for back-compat.

    ``override_branch`` lets a feature-grouped task share the PR state
    of its sibling tasks (resolved via ``_resolve_feature_branches``).
    When set, replaces ``task["pr_branch"]`` for the PR lookup so that
    one merged feature PR moves all siblings to ``done`` together.

    ``is_active=False`` short-circuits to ``pending`` ONLY for groups
    that have not yet completed — implements the Phase 3 serial lock so
    that inactive groups don't drift to ``write-code`` from sibling
    commits. A merged PR still reports ``done`` regardless of
    ``is_active``: a completed group must not regress to ``pending``
    when its sibling becomes active, otherwise ``find_next_pending``
    surfaces it as phantom pending work for autopilot.
    """
    pr_branch = override_branch or task.get("pr_branch") or ""

    # Resolve PR state once, BEFORE the serial-lock short-circuit, so
    # that already-merged tasks remain ``done`` after their group is
    # rotated out of the active slot.
    pr_status = "none"
    if pr_branch:
        if pr_cache is not None:
            pr_status = pr_cache.get(pr_branch, "none")
        else:
            pr_status = _pr_status(pr_branch, target)

    # Merged PR is terminal — overrides serial-lock pending.
    if pr_status == "merged":
        return "done"

    # Inactive group (serial lock) → queued, not being worked on.
    if not is_active:
        return "pending"

    code_glob = task.get("code_glob") or ""
    test_glob = task.get("test_glob") or ""
    # Bootstrapped globs are typically nested: code_glob `*.{ts,...}` is a
    # superset of test_glob `*.{test,spec}.{ts,...}`. Counting raw matches
    # would double-count test files as production code, falsely advancing
    # the stage to ``review`` while developer-agent has not written a
    # single production file. Exclude test paths from the code count so
    # ``n_code`` only reflects real production source.
    test_paths = _glob_paths(target, test_glob) if test_glob else set()
    code_paths = _glob_paths(target, code_glob) if code_glob else set()
    n_test = len(test_paths)
    n_code = len(code_paths - test_paths)

    # No deliverables yet on an active task = test-author is in the
    # write-tests activity right now.
    if n_code == 0 and n_test == 0:
        return "write-tests"
    # Code without any matching test → backfill tests first; the activity
    # is still write-tests until the test suite catches up.
    if n_test == 0 and n_code > 0:
        return "write-tests"
    # Tests exist, no code yet → developer-agent is writing code now.
    if n_test > 0 and n_code == 0:
        return "write-code"
    # Both code and tests exist. Do NOT compare counts: one test file
    # legitimately covers many implementation files, so n_test < n_code
    # does not mean "TDD violation". TDD discipline is enforced by
    # *requiring* n_test > 0 before leaving write-tests, which is already
    # guaranteed at this point.
    # PR open = code-reviewer's local job is done; awaiting human
    # (or auto-mad) merge. Distinct from `review`, which means
    # "reviewer is working locally before any PR".
    if pr_status == "open":
        return "await-merge"
    # Both files exist, no PR yet → code-reviewer is reviewing locally.
    return "review"


def stage_to_subagent(task: dict, stage: str) -> str | None:
    """Map current activity stage to the subagent performing it.

    Each stage labels the activity in flight; the agent returned here is
    the one DOING that activity. ``pending`` (inactive group) and
    ``await-merge`` / ``done`` (no agent action — human or terminal)
    return None.
    """
    label = (task.get("label") or "") + " " + (task.get("id") or "")
    is_sensitive = any(h in label.lower() for h in HIGH_RISK_HINTS)
    return {
        "pending": None,                 # inactive group, queued behind serial lock
        "write-tests": "test-author",
        "write-code": "developer-agent",
        "review": "security-reviewer" if is_sensitive else "code-reviewer",
        "await-merge": None,             # PR open, human (or auto-mad) merges
        "done": None,
    }.get(stage)


def evaluate_task_as_item(
    task: dict,
    target: Path,
    pr_cache: dict[str, str] | None = None,
    override_branch: str | None = None,
    *,
    is_active: bool = True,
) -> dict:
    """Convert a task dict into a Phase-3-compatible item dict for state.json.

    ``pr_cache`` is forwarded to :func:`detect_stage`; pass one once per
    scan to avoid a ``gh`` subprocess per task.

    ``override_branch`` lets the engine plug in a feature-shared branch
    (see ``_resolve_feature_branches``); the resolved branch becomes
    both the PR-detection target AND what ``state.json`` shows for
    ``pr_branch`` so the dashboard renders the effective branch.
    """
    stage = detect_stage(task, target, pr_cache=pr_cache,
                         override_branch=override_branch,
                         is_active=is_active)
    effective_branch = override_branch or task.get("pr_branch")
    return {
        "id": task["id"],
        "label": task.get("label") or task["id"],
        "subtrack": "tasks",
        "done": stage == "done",
        # ``drafted`` = "real evidence exists". A bare ``write-tests`` stage
        # has no committed deliverable yet (test-author is still working);
        # everything from ``write-code`` onwards is a checkpoint with a
        # tangible artifact (tests at minimum).
        "drafted": stage in ("write-code", "review", "await-merge", "done"),
        "verified": stage == "done",
        "stage": stage,
        "stages": VALID_STAGES,
        "next_subagent": stage_to_subagent(task, stage),
        "priority": task.get("priority") or "medium",
        "code_glob": task.get("code_glob"),
        "test_glob": task.get("test_glob"),
        "pr_branch": effective_branch,
        "feature_id": task.get("feature_id"),
        "story": task.get("story"),
        "checks": [{
            "rule": {"type": "task_stage"},
            "ok": stage == "done",
            "msg": f"current stage: {stage}",
        }],
    }
