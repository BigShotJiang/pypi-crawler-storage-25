import logging

from django.contrib import messages
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest
from django.shortcuts import redirect, get_object_or_404
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from pretix.base.models import OrderPayment

from .payment import GPWebPay

logger = logging.getLogger(__name__)

_RESPONSE_FIELDS = GPWebPay._RESPONSE_DIGEST_FIELDS


def _safe_order_url(order_obj) -> str:
    """Return the presale order status URL, compatible with all Pretix versions."""
    try:
        return reverse('presale:event.order', kwargs={
            'organizer': order_obj.event.organizer.slug,
            'event': order_obj.event.slug,
            'order': order_obj.code,
            'secret': order_obj.secret,
        })
    except Exception:
        return '/'


def _collect_params(request: HttpRequest) -> dict:
    params = {}
    for key in request.GET:
        params[key] = request.GET[key]
    for key in request.POST:
        params[key] = request.POST[key]
    return params


def _fix_signature(value: str) -> str:
    # URL-decoding can turn '+' into ' '; restore it for base64
    return value.replace(' ', '+') if value else value


def _get_provider(event):
    return event.get_payment_providers().get('gpwebpay')


@method_decorator(csrf_exempt, name='dispatch')
class ReturnView(View):
    """Handle user redirect back from GPWebPay gateway."""

    def get(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle(request, order, payment, order_secret)

    def post(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle(request, order, payment, order_secret)

    def _handle(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        order_obj = None
        try:
            payment_obj = get_object_or_404(
                OrderPayment,
                id=payment,
                order__code=order,
                order__secret=order_secret,
            )
            order_obj = payment_obj.order
            event = order_obj.event

            provider = _get_provider(event)
            if not provider:
                logger.error('GPWebPay provider not found for event %s', event.slug)
                messages.error(request, _('Payment provider not configured.'))
                return redirect(_safe_order_url(order_obj))

            public_key_data = provider.settings.get('public_key', '')
            merchant_number = provider.settings.get('merchant_number', '')

            all_params = _collect_params(request)
            prcode = all_params.get('PRCODE', '')
            srcode = all_params.get('SRCODE', '')
            resulttext = all_params.get('RESULTTEXT', '')
            digest1 = _fix_signature(all_params.get('DIGEST1', ''))
            digest = _fix_signature(all_params.get('DIGEST', ''))

            logger.info(
                'GPWebPay return: order=%s payment=%s PRCODE=%s SRCODE=%s state=%s',
                order, payment, prcode, srcode, payment_obj.state,
            )

            if public_key_data:
                # Build response digest from fields actually received, in spec order
                received = {f: all_params[f] for f in _RESPONSE_FIELDS if all_params.get(f)}

                if digest1:
                    response_digest = provider._build_response_digest(received, merchant_number)
                    if not provider._verify_signature(response_digest, digest1, public_key_data):
                        logger.error('GPWebPay DIGEST1 verification failed for payment %s', payment)
                        messages.error(request, _('Payment verification failed.'))
                        return redirect(_safe_order_url(order_obj))
                elif digest:
                    response_digest = '|'.join(received[f] for f in _RESPONSE_FIELDS if received.get(f))
                    if not provider._verify_signature(response_digest, digest, public_key_data):
                        logger.error('GPWebPay DIGEST verification failed for payment %s', payment)
                        messages.error(request, _('Payment verification failed.'))
                        return redirect(_safe_order_url(order_obj))
                else:
                    logger.error('GPWebPay return missing DIGEST/DIGEST1 for payment %s', payment)
                    messages.error(request, _('Payment verification failed.'))
                    return redirect(_safe_order_url(order_obj))

            if prcode == '0' and srcode == '0':
                if payment_obj.state in (
                    OrderPayment.PAYMENT_STATE_PENDING,
                    OrderPayment.PAYMENT_STATE_CREATED,
                ):
                    payment_obj.confirm()
                    logger.info('GPWebPay payment %s confirmed for order %s', payment, order)
                messages.success(request, _('Payment successful!'))
            else:
                error_msg = resulttext or str(_('Payment failed.'))
                if payment_obj.state in (
                    OrderPayment.PAYMENT_STATE_PENDING,
                    OrderPayment.PAYMENT_STATE_CREATED,
                ):
                    payment_obj.fail(info={'error': error_msg, 'prcode': prcode, 'srcode': srcode})
                logger.warning(
                    'GPWebPay payment %s failed for order %s: PRCODE=%s SRCODE=%s %s',
                    payment, order, prcode, srcode, resulttext,
                )
                messages.error(request, error_msg)

            return redirect(_safe_order_url(order_obj))

        except Exception as e:
            logger.error('Error processing GPWebPay return for payment %s: %s', payment, e, exc_info=True)
            messages.error(request, _('An error occurred while processing your payment.'))
            if order_obj is not None:
                return redirect(_safe_order_url(order_obj))
            return HttpResponseBadRequest('Error processing payment')


@method_decorator(csrf_exempt, name='dispatch')
class NotifyView(View):
    """Handle server-to-server (IPN) notification from GPWebPay."""

    def get(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle(request, order, payment, order_secret)

    def post(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle(request, order, payment, order_secret)

    def _handle(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        try:
            payment_obj = get_object_or_404(
                OrderPayment,
                id=payment,
                order__code=order,
                order__secret=order_secret,
            )
            event = payment_obj.order.event

            provider = _get_provider(event)
            if not provider:
                logger.error('GPWebPay provider not found for event %s', event.slug)
                return HttpResponseBadRequest('Provider not configured')

            public_key_data = provider.settings.get('public_key', '')
            merchant_number = provider.settings.get('merchant_number', '')

            all_params = _collect_params(request)
            prcode = all_params.get('PRCODE', '')
            srcode = all_params.get('SRCODE', '')
            resulttext = all_params.get('RESULTTEXT', '')
            digest1 = _fix_signature(all_params.get('DIGEST1', ''))
            digest = _fix_signature(all_params.get('DIGEST', ''))

            logger.info(
                'GPWebPay IPN: order=%s payment=%s PRCODE=%s SRCODE=%s state=%s',
                order, payment, prcode, srcode, payment_obj.state,
            )

            if public_key_data:
                received = {f: all_params[f] for f in _RESPONSE_FIELDS if all_params.get(f)}

                if digest1:
                    response_digest = provider._build_response_digest(received, merchant_number)
                    if not provider._verify_signature(response_digest, digest1, public_key_data):
                        logger.error('GPWebPay IPN DIGEST1 verification failed for payment %s', payment)
                        return HttpResponseBadRequest('Invalid signature')
                elif digest:
                    response_digest = '|'.join(received[f] for f in _RESPONSE_FIELDS if received.get(f))
                    if not provider._verify_signature(response_digest, digest, public_key_data):
                        logger.error('GPWebPay IPN DIGEST verification failed for payment %s', payment)
                        return HttpResponseBadRequest('Invalid signature')
                else:
                    logger.error('GPWebPay IPN missing DIGEST/DIGEST1 for payment %s', payment)
                    return HttpResponseBadRequest('Missing signature')

            if prcode == '0' and srcode == '0':
                if payment_obj.state in (
                    OrderPayment.PAYMENT_STATE_PENDING,
                    OrderPayment.PAYMENT_STATE_CREATED,
                ):
                    payment_obj.confirm()
                    logger.info('GPWebPay payment %s confirmed via IPN for order %s', payment, order)
            else:
                if payment_obj.state in (
                    OrderPayment.PAYMENT_STATE_PENDING,
                    OrderPayment.PAYMENT_STATE_CREATED,
                ):
                    payment_obj.fail(info={
                        'error': resulttext or 'Payment failed',
                        'prcode': prcode,
                        'srcode': srcode,
                    })
                logger.warning(
                    'GPWebPay payment %s failed via IPN for order %s: PRCODE=%s SRCODE=%s %s',
                    payment, order, prcode, srcode, resulttext,
                )

            # Always 200 after signature verification — prevents gateway from retrying indefinitely
            return HttpResponse('OK')

        except Exception as e:
            logger.error('Error processing GPWebPay IPN for payment %s: %s', payment, e, exc_info=True)
            return HttpResponse('ERROR', status=500)
