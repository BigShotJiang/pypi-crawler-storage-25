import binascii
import logging
import urllib.parse
import uuid
from collections import OrderedDict
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from django import forms
from django.http import HttpRequest, HttpResponse
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _
from pretix.multidomain.urlreverse import build_absolute_uri
from pretix.base.models import OrderPayment, OrderRefund
from pretix.base.payment import BasePaymentProvider, PaymentException
from pretix.control.forms import ExtFileField

logger = logging.getLogger(__name__)


class GPWebPaySettingsForm(forms.Form):
    merchant_number = forms.CharField(
        label=_('Merchant Number'),
        help_text=_('Your GPWebPay merchant number'),
        required=True,
        max_length=10,
    )
    private_key = ExtFileField(
        label=_('Private Key File'),
        help_text=_('Upload your GPWebPay private key file (.key or .pem format)'),
        required=True,
        ext_whitelist=('.key', '.pem', '.txt'),
    )
    private_key_password = forms.CharField(
        label=_('Private Key Password'),
        help_text=_('Password for your private key file (leave empty if key is not encrypted)'),
        required=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
    )
    public_key = ExtFileField(
        label=_('GPWebPay Public Key File'),
        help_text=_('Upload the GPWebPay public key file for signature verification'),
        required=True,
        ext_whitelist=('.key', '.pem', '.txt'),
    )
    gateway_url = forms.URLField(
        label=_('Gateway URL'),
        help_text=_('GPWebPay gateway URL'),
        required=True,
        initial='https://3dsecure.gpwebpay.com/pgw/order.do',
    )
    deposit_flag = forms.ChoiceField(
        label=_('Deposit flag'),
        choices=[
            ('1', _('1 — Authorize and capture immediately (recommended)')),
            ('0', _('0 — Authorize only, capture manually later')),
        ],
        initial='1',
        help_text=_('Controls whether the payment is captured immediately (1) or only authorized (0).'),
    )
    provider_code = forms.CharField(
        label=_('Provider Code'),
        help_text=_('4-digit acquirer identifier required for refunds (e.g., 0100 for Česká spořitelna). See GPWebPay documentation Annex 5.'),
        required=False,
        max_length=4,
        min_length=4,
    )
    ws_url = forms.URLField(
        label=_('WS API URL'),
        help_text=_('GPWebPay WS API URL for refunds. Default: https://3dsecure.gpwebpay.com/pay-ws/v1/PaymentService'),
        required=False,
    )
    test_mode = forms.BooleanField(
        label=_('Test mode'),
        help_text=_('Enable test mode for development'),
        required=False,
        initial=False,
    )


class GPWebPay(BasePaymentProvider):
    identifier = 'gpwebpay'
    verbose_name = _('GPWebPay')
    public_name = _('GPWebPay')
    abort_pending_allowed = True
    refunds_allowed = True

    _ZERO_DECIMAL_CURRENCIES = {'HUF', 'JPY', 'ISK', 'KRW', 'TWD'}

    # Field order per spec section 5.1 / Annex 1. Only non-empty fields are included.
    _REQUEST_DIGEST_FIELDS = [
        'MERCHANTNUMBER', 'OPERATION', 'ORDERNUMBER', 'AMOUNT', 'CURRENCY',
        'DEPOSITFLAG', 'MERORDERNUM', 'URL', 'DESCRIPTION', 'MD', 'USERPARAM1',
        'VRCODE', 'FASTPAYID', 'PAYMETHOD', 'PAYMETHODS', 'EMAIL',
        'REFERENCENUMBER', 'ADDINFO', 'PANPATTERN', 'TOKEN', 'FASTTOKEN',
    ]

    # Field order per spec section 5.2. DIGEST/DIGEST1 excluded.
    # MERCHANTNUMBER is appended last for DIGEST1 — see _build_response_digest().
    _RESPONSE_DIGEST_FIELDS = [
        'OPERATION', 'ORDERNUMBER', 'MERORDERNUM', 'MD', 'PRCODE', 'SRCODE',
        'RESULTTEXT', 'ADDINFO', 'TOKEN', 'EXPIRY', 'ACSRES', 'ACCODE',
        'PANPATTERN', 'DAYTOCAPTURE', 'TOKENREGSTATUS', 'ACRC', 'RRN', 'PAR', 'TRACEID',
    ]

    # WS API processRefund success states
    _WS_SUCCESS_STATES = {'ACCEPTED', 'APPROVED'}

    _WS_URL_DEFAULT = 'https://3dsecure.gpwebpay.com/pay-ws/v1/PaymentService'

    @property
    def settings_form_fields(self):
        fields = OrderedDict(super().settings_form_fields)
        fields.update(GPWebPaySettingsForm.base_fields)
        return fields

    def settings_form_clean(self, cleaned_data):
        # ExtFileField handles file storage automatically (saves to storage, stores 'file://path').
        # We only need to preserve the existing stored value when no new file is uploaded.
        for field_name in ('private_key', 'public_key'):
            if not cleaned_data.get(field_name):
                stored = self.settings.get(field_name)
                if stored:
                    cleaned_data[field_name] = stored
        return cleaned_data

    def settings_content_render(self, request):
        return mark_safe(
            '<p>Configure your GPWebPay payment gateway settings.</p>'
            '<ul>'
            '<li>Obtain your merchant number from GPWebPay</li>'
            '<li>Upload your private key file (used for signing requests)</li>'
            '<li>Upload GPWebPay\'s public key file (used for verifying responses)</li>'
            '<li>For refunds: enter the 4-digit Provider Code and WS API URL</li>'
            '</ul>'
        )

    def payment_form_render(self, request) -> str:
        return ''

    def checkout_confirm_render(self, request, order=None, info_data=None) -> str:
        return ''

    def payment_is_valid_session(self, request):
        return True

    def execute_payment(self, request: HttpRequest, payment: OrderPayment) -> Optional[str]:
        order = payment.order

        merchant_number = self.settings.get('merchant_number', '')
        gateway_url = self.settings.get('gateway_url', 'https://3dsecure.gpwebpay.com/pgw/order.do')
        private_key_data = self.settings.get('private_key', '')
        private_key_password = self.settings.get('private_key_password', '')
        deposit_flag = self.settings.get('deposit_flag', '1')

        if not merchant_number or not private_key_data:
            raise PaymentException(_('GPWebPay is not configured properly.'))

        params = {
            'MERCHANTNUMBER': merchant_number,
            'OPERATION': 'CREATE_ORDER',
            'ORDERNUMBER': str(payment.id),
            'AMOUNT': str(self._get_amount(payment)),
            'CURRENCY': self._get_currency_code(order.event.currency),
            'DEPOSITFLAG': deposit_flag,
            'URL': build_absolute_uri(
                order.event,
                'plugins:pretix_gpwebpay:return',
                kwargs={
                    'order': order.code,
                    'payment': payment.id,
                    'order_secret': order.secret,
                }
            ),
            'DESCRIPTION': 'Order %s' % order.code,
            'MD': str(payment.id),
        }

        try:
            digest = self._generate_digest(params)
            signature = self._sign_message(digest, private_key_data, private_key_password)
            params['DIGEST'] = signature
        except Exception as e:
            logger.error('GPWebPay signing error for payment %s: %s', payment.id, e, exc_info=True)
            raise PaymentException(_('Error preparing payment request.'))

        # Pretix's OrderPayView wraps the return value in redirect() itself,
        # so return the URL string — not HttpResponseRedirect.
        return '%s?%s' % (gateway_url, urllib.parse.urlencode(params))

    def _get_currency_code(self, currency: str) -> str:
        currency_map = {
            'CZK': '203',
            'EUR': '978',
            'USD': '840',
            'GBP': '826',
            'PLN': '985',
            'HUF': '348',
        }
        return currency_map.get(currency.upper(), '978')

    def _get_amount(self, payment: OrderPayment) -> int:
        currency = payment.order.event.currency.upper()
        multiplier = 1 if currency in self._ZERO_DECIMAL_CURRENCIES else 100
        return int(
            (payment.amount * multiplier).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
        )

    def _generate_digest(self, params: Dict[str, str]) -> str:
        return '|'.join(params[f] for f in self._REQUEST_DIGEST_FIELDS if params.get(f))

    def _build_response_digest(self, received: Dict[str, str], merchant_number: str) -> str:
        parts = [received[f] for f in self._RESPONSE_DIGEST_FIELDS if received.get(f)]
        parts.append(merchant_number)
        return '|'.join(parts)

    @staticmethod
    def _key_bytes(key_data: str) -> bytes:
        """Load key bytes from whatever format Pretix stored them in.

        Pretix ExtFileField saves files to storage and stores 'file://path'.
        Legacy storage formats (base64 or raw PEM string) are also handled.
        """
        import base64
        from django.core.files.storage import default_storage

        data = key_data.strip()

        # Pretix stores ExtFileField uploads as 'file://relative/path'
        if data.startswith('file://'):
            path = data[len('file://'):]
            with default_storage.open(path, 'rb') as f:
                return f.read()

        # Legacy: base64-encoded raw bytes (stored by old settings_form_clean)
        try:
            cleaned = ''.join(data.split())
            cleaned += '=' * (-len(cleaned) % 4)
            return base64.b64decode(cleaned, validate=True)
        except (binascii.Error, ValueError):
            # Last resort: raw UTF-8 string (e.g. manually pasted PEM)
            return data.encode('utf-8')

    @staticmethod
    def _repair_pem(pem_bytes: bytes) -> bytes:
        """Reconstruct proper PEM line breaks lost during Pretix settings storage.

        Pretix strips newlines from stored text values. This rebuilds a valid PEM
        from a header+body+footer string that has had its whitespace removed.
        """
        import re
        try:
            text = pem_bytes.decode('utf-8', errors='replace').strip()
            m = re.match(r'(-----BEGIN [^-]+-----)(.*?)(-----END [^-]+-----)', text, re.DOTALL)
            if not m:
                return pem_bytes
            header, body, footer = m.group(1), m.group(2), m.group(3)
            body = ''.join(body.split())
            wrapped = '\n'.join(body[i:i + 64] for i in range(0, len(body), 64))
            return ('%s\n%s\n%s\n' % (header, wrapped, footer)).encode('utf-8')
        except Exception:
            return pem_bytes

    def _load_private_key(self, private_key_data: str, password: Optional[str]):
        key_bytes = self._key_bytes(private_key_data)
        password_bytes = password.encode('utf-8') if password else None

        preview = key_bytes[:120].decode('utf-8', errors='replace')
        logger.error('GPWebPay KEY DIAG: stored_len=%d key_bytes_len=%d preview=%r',
                     len(private_key_data), len(key_bytes), preview)

        # 1. PEM as-is
        try:
            return serialization.load_pem_private_key(key_bytes, password=password_bytes)
        except Exception as e:
            logger.error('GPWebPay KEY DIAG: PEM failed: %s', e)

        # 2. DER
        try:
            return serialization.load_der_private_key(key_bytes, password=password_bytes)
        except Exception as e:
            logger.error('GPWebPay KEY DIAG: DER failed: %s', e)

        # 3. Repaired PEM (Pretix settings strips newlines from stored text)
        repaired = self._repair_pem(key_bytes)
        if repaired != key_bytes:
            try:
                return serialization.load_pem_private_key(repaired, password=password_bytes)
            except Exception as e:
                logger.error('GPWebPay KEY DIAG: Repaired PEM failed: %s', e)
        else:
            logger.error('GPWebPay KEY DIAG: _repair_pem returned unchanged bytes (no BEGIN header found)')

        # 4. PKCS#12 (.p12/.pfx files sometimes delivered as .key)
        try:
            from cryptography.hazmat.primitives.serialization.pkcs12 import load_key_and_certificates
            result = load_key_and_certificates(key_bytes, password_bytes)
            if result[0] is not None:
                return result[0]
        except Exception as e:
            logger.error('GPWebPay KEY DIAG: PKCS#12 failed: %s', e)

        raise ValueError('Could not load private key: tried PEM, DER, repaired PEM, and PKCS#12')

    def _load_public_key(self, public_key_data: str):
        from cryptography.x509 import load_pem_x509_certificate
        key_bytes = self._key_bytes(public_key_data)
        # 1. Try PEM as-is
        try:
            return serialization.load_pem_public_key(key_bytes)
        except Exception:
            pass
        # 2. Try DER
        try:
            return serialization.load_der_public_key(key_bytes)
        except Exception:
            pass
        # 3. Try X.509 certificate
        try:
            return load_pem_x509_certificate(key_bytes).public_key()
        except Exception:
            pass
        # 4. Repair PEM newlines
        repaired = self._repair_pem(key_bytes)
        if repaired != key_bytes:
            try:
                return serialization.load_pem_public_key(repaired)
            except Exception:
                try:
                    return load_pem_x509_certificate(repaired).public_key()
                except Exception:
                    pass
        raise ValueError('Could not load public key: tried PEM, DER, X.509, and repaired PEM')

    def _sign_message(self, message: str, private_key_data: str, password: Optional[str] = None) -> str:
        import base64
        private_key = self._load_private_key(private_key_data, password)
        # GPWebPay HTTP API requires RSA-SHA1 (PKCS1v15), not SHA256
        signature = private_key.sign(message.encode('utf-8'), padding.PKCS1v15(), hashes.SHA1())
        return base64.b64encode(signature).decode('utf-8')

    def _verify_signature(self, message: str, signature: str, public_key_data: str) -> bool:
        import base64
        try:
            public_key = self._load_public_key(public_key_data)
            public_key.verify(
                base64.b64decode(signature),
                message.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA1(),
            )
            return True
        except Exception as e:
            logger.error('GPWebPay signature verification error: %s', e, exc_info=True)
            return False

    def execute_refund(self, refund: OrderRefund):
        """Execute refund via GPWebPay WS API processRefund operation."""
        import requests as req_lib
        import xml.etree.ElementTree as ET

        payment = refund.payment
        merchant_number = self.settings.get('merchant_number', '')
        provider_code = self.settings.get('provider_code', '')
        private_key_data = self.settings.get('private_key', '')
        private_key_password = self.settings.get('private_key_password', '')
        public_key_data = self.settings.get('public_key', '')
        ws_url = self.settings.get('ws_url') or self._WS_URL_DEFAULT

        if not merchant_number or not provider_code or not private_key_data:
            raise PaymentException(_('GPWebPay refunds require provider code to be configured.'))

        message_id = uuid.uuid4().hex
        payment_number = str(payment.id)
        currency = payment.order.event.currency.upper()
        multiplier = 1 if currency in self._ZERO_DECIMAL_CURRENCIES else 100
        amount = str(int(
            (refund.amount * multiplier).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
        ))

        digest = '|'.join([message_id, provider_code, merchant_number, payment_number, amount])
        try:
            signature = self._sign_message(digest, private_key_data, private_key_password)
        except Exception as e:
            logger.error('GPWebPay refund signing error for payment %s: %s', payment.id, e, exc_info=True)
            raise PaymentException(_('Error preparing refund request.'))

        soap_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<soapenv:Envelope'
            ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
            ' xmlns:v1="http://gpe.cz/pay/pay-ws/proc/v1"'
            ' xmlns:type="http://gpe.cz/pay/pay-ws/core/type">'
            '<soapenv:Header/>'
            '<soapenv:Body>'
            '<v1:processRefund>'
            '<v1:refundRequest>'
            '<type:messageId>%s</type:messageId>'
            '<type:provider>%s</type:provider>'
            '<type:merchantNumber>%s</type:merchantNumber>'
            '<type:paymentNumber>%s</type:paymentNumber>'
            '<type:amount>%s</type:amount>'
            '<type:signature>%s</type:signature>'
            '</v1:refundRequest>'
            '</v1:processRefund>'
            '</soapenv:Body>'
            '</soapenv:Envelope>'
        ) % (message_id, provider_code, merchant_number, payment_number, amount, signature)

        try:
            http_resp = req_lib.post(
                ws_url,
                data=soap_xml.encode('utf-8'),
                headers={
                    'Content-Type': 'text/xml; charset=utf-8',
                    'SOAPAction': '""',
                },
                timeout=30,
            )
            http_resp.raise_for_status()
        except Exception as e:
            logger.error('GPWebPay WS API error for payment %s refund: %s', payment.id, e)
            raise PaymentException(_('Error communicating with payment gateway.'))

        try:
            root = ET.fromstring(http_resp.text)

            fault = root.find('.//{http://schemas.xmlsoap.org/soap/envelope/}Fault')
            if fault is not None:
                fault_string = fault.findtext('faultstring') or 'Unknown error'
                logger.error('GPWebPay WS SOAP fault for payment %s refund: %s', payment.id, fault_string)
                raise PaymentException(_('Refund was rejected by the payment gateway.'))

            resp_el = None
            for elem in root.iter():
                if elem.tag.endswith('}refundRequestResponse') or elem.tag == 'refundRequestResponse':
                    resp_el = elem
                    break

            if resp_el is None:
                logger.error('GPWebPay WS missing refundRequestResponse for payment %s', payment.id)
                raise PaymentException(_('Invalid refund response from payment gateway.'))

            def _find_text(parent, tag):
                for child in parent:
                    if child.tag.endswith('}' + tag) or child.tag == tag:
                        return child.text or ''
                return ''

            resp_msg_id = _find_text(resp_el, 'messageId')
            resp_state = _find_text(resp_el, 'state')
            resp_status = _find_text(resp_el, 'status')
            resp_substatus = _find_text(resp_el, 'subStatus')
            resp_signature = _find_text(resp_el, 'signature')

            if resp_signature and public_key_data:
                parts = [resp_msg_id, resp_state]
                if resp_status:
                    parts.append(resp_status)
                if resp_substatus:
                    parts.append(resp_substatus)
                if not self._verify_signature('|'.join(parts), resp_signature, public_key_data):
                    logger.error('GPWebPay WS response signature invalid for payment %s refund', payment.id)
                    raise PaymentException(_('Refund response verification failed.'))

            if resp_state.upper() not in self._WS_SUCCESS_STATES:
                logger.error(
                    'GPWebPay refund rejected for payment %s: state=%s status=%s subStatus=%s',
                    payment.id, resp_state, resp_status, resp_substatus,
                )
                raise PaymentException(
                    _('Refund was rejected by the payment gateway (state: %s).') % resp_state
                )

            logger.info(
                'GPWebPay refund accepted for payment %s: state=%s status=%s subStatus=%s',
                payment.id, resp_state, resp_status, resp_substatus,
            )
            refund.done()

        except PaymentException:
            raise
        except Exception as e:
            logger.error('GPWebPay WS response parse error for payment %s refund: %s', payment.id, e, exc_info=True)
            raise PaymentException(_('Error processing refund response.'))

    def payment_pending_render(self, request, payment: OrderPayment):
        return mark_safe('<p>%s</p>' % _('Your payment is being processed. Please wait.'))

    def payment_control_render(self, request, payment: OrderPayment):
        return mark_safe(
            '<dl class="dl-horizontal">'
            '<dt>%s</dt><dd>%s</dd>'
            '<dt>%s</dt><dd>%s</dd>'
            '</dl>' % (
                _('Payment ID'), payment.id,
                _('Status'), payment.state,
            )
        )
