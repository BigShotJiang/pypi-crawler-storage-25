from django.urls import path
from . import views

event_patterns = [
    path('gpwebpay/return/<str:order>/<int:payment>/<str:order_secret>/', views.ReturnView.as_view(), name='return'),
    path('gpwebpay/notify/<str:order>/<int:payment>/<str:order_secret>/', views.NotifyView.as_view(), name='notify'),
]
