from __future__ import annotations

import json
import sys
import types
import unittest
from pathlib import Path
from unittest import mock


SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from notion_access_broker.credentials import (
    StoredCredentialHandle,
    _parse_index_payload,
    delete_token,
    list_credentials,
    load_token,
    provider_diagnostics,
    store_token,
    CredentialProviderError,
)


class CredentialStoreTests(unittest.TestCase):
    def test_auto_provider_prefers_onepassword_when_cli_is_ready(self) -> None:
        with mock.patch.dict("os.environ", {}, clear=True):
            with mock.patch("notion_access_broker.credentials.shutil.which", return_value="/usr/bin/op"):
                with mock.patch(
                    "notion_access_broker.credentials.subprocess.run",
                    return_value=mock.Mock(
                        returncode=0,
                        stdout='[{"id":"vault-dev-123","name":"Development"}]',
                        stderr="",
                    ),
                ) as run_mock:
                    with mock.patch(
                        "notion_access_broker.credentials._OnePasswordProvider.store_token",
                        return_value=StoredCredentialHandle(
                            provider="1password",
                            credential_ref="vault-item-123",
                            metadata={"title": "Notion / Agent Labbook / Workspace Auto / abc123"},
                        ),
                    ) as store_mock:
                        stored = store_token(
                            integration_id="agent-labbook",
                            token_payload={
                                "access_token": "access-auto",
                                "refresh_token": "refresh-auto",
                                "workspace_id": "workspace-auto",
                                "workspace_name": "Workspace Auto",
                                "bot_id": "bot-auto",
                            },
                        )
                        diagnostics = provider_diagnostics()

        self.assertEqual(stored["provider"], "1password")
        self.assertEqual(diagnostics["resolved_provider"], "1password")
        self.assertTrue(diagnostics["providers"][0]["selected_by_default"])
        self.assertGreaterEqual(run_mock.call_count, 1)
        self.assertEqual(
            run_mock.call_args_list[0],
            mock.call(
                ["/usr/bin/op", "vault", "list", "--format", "json"],
                check=False,
                capture_output=True,
                text=True,
            ),
        )
        store_mock.assert_called_once()

    def test_keyring_provider_round_trips_tokens(self) -> None:
        memory: dict[tuple[str, str], str] = {}

        fake_keyring = types.ModuleType("keyring")
        fake_errors = types.ModuleType("keyring.errors")
        fake_errors.KeyringError = RuntimeError
        fake_errors.NoKeyringError = RuntimeError
        fake_errors.PasswordDeleteError = RuntimeError
        fake_keyring.errors = fake_errors
        fake_keyring.get_keyring = mock.Mock(return_value=mock.Mock(__class__=type("SecretServiceKeyring", (), {}), priority=5))
        fake_keyring.set_password = mock.Mock(side_effect=lambda service, username, value: memory.__setitem__((service, username), value))
        fake_keyring.get_password = mock.Mock(side_effect=lambda service, username: memory.get((service, username)))
        fake_keyring.delete_password = mock.Mock(side_effect=lambda service, username: memory.pop((service, username), None))

        with mock.patch.dict(sys.modules, {"keyring": fake_keyring, "keyring.errors": fake_errors}):
            stored = store_token(
                integration_id="agent-labbook",
                provider_name="keyring",
                token_payload={
                    "access_token": "access-1",
                    "refresh_token": "refresh-1",
                    "workspace_id": "workspace-1",
                    "workspace_name": "Workspace One",
                    "bot_id": "bot-1",
                },
            )
            loaded = load_token(
                integration_id="agent-labbook",
                credential_provider=stored["provider"],
                credential_ref=stored["credential_ref"],
            )
            listed = list_credentials(
                integration_id="agent-labbook",
                provider_name="keyring",
            )
            diagnostics = provider_diagnostics(provider_name="keyring")

        self.assertEqual(loaded["access_token"], "access-1")
        self.assertEqual(loaded["refresh_token"], "refresh-1")
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["workspace_name"], "Workspace One")
        self.assertEqual(diagnostics["resolved_provider"], "keyring")
        self.assertTrue(diagnostics["providers"][1]["available"])
        self.assertEqual(stored["metadata"]["service_name"], "Notion")
        self.assertRegex(stored["metadata"]["account_name"], r"^Agent Labbook / Workspace One / [0-9a-f]{6}$")
        self.assertIn(("Notion", stored["metadata"]["account_name"]), memory)
        self.assertIn(("Notion", "Agent Labbook / Saved Sessions"), memory)

    def test_onepassword_provider_uses_default_vault_and_human_titles(self) -> None:
        items: dict[str, dict[str, object]] = {}
        created_ids = iter(["vault-item-123", "index-item-456"])
        commands: list[list[str]] = []
        default_vault = {"id": "vault-dev-123", "name": "Development"}

        def fake_run(args, check, capture_output, text, input=None):  # noqa: ANN001
            commands.append(list(args))
            self.assertFalse(check)
            self.assertTrue(capture_output)
            self.assertTrue(text)
            if args[1:3] == ["vault", "list"]:
                return mock.Mock(returncode=0, stdout=json.dumps([default_vault]), stderr="")
            if args[1:3] == ["item", "list"]:
                tag = args[args.index("--tags") + 1]
                payload = [
                    {"id": item_id, "title": str(item.get("title") or "")}
                    for item_id, item in items.items()
                    if tag in list(item.get("tags") or [])
                ]
                return mock.Mock(returncode=0, stdout=json.dumps(payload), stderr="")
            if args[1:3] == ["item", "create"]:
                template = json.loads(input)
                item_id = next(created_ids)
                items[item_id] = {
                    "id": item_id,
                    "title": args[args.index("--title") + 1],
                    "tags": str(args[args.index("--tags") + 1]).split(","),
                    "fields": template["fields"],
                    "vault": dict(default_vault),
                }
                return mock.Mock(returncode=0, stdout=json.dumps({"id": item_id}), stderr="")
            if args[1:3] == ["item", "get"]:
                item_id = args[3]
                return mock.Mock(returncode=0, stdout=json.dumps(items[item_id]), stderr="")
            if args[1:3] == ["item", "edit"]:
                item_id = args[3]
                items[item_id] = json.loads(input)
                items[item_id]["id"] = item_id
                items[item_id]["vault"] = dict(default_vault)
                return mock.Mock(returncode=0, stdout=json.dumps(items[item_id]), stderr="")
            if args[1:3] == ["item", "delete"]:
                item_id = args[3]
                items.pop(item_id, None)
                return mock.Mock(returncode=0, stdout=json.dumps({"deleted": True}), stderr="")
            raise AssertionError(f"Unexpected command: {' '.join(args)}")

        with mock.patch("notion_access_broker.credentials.shutil.which", return_value="/usr/bin/op"):
            with mock.patch("notion_access_broker.credentials.subprocess.run", side_effect=fake_run):
                with mock.patch.dict("os.environ", {}, clear=True):
                    stored = store_token(
                        integration_id="agent-labbook",
                        provider_name="1password",
                        token_payload={
                            "access_token": "access-2",
                            "refresh_token": "refresh-2",
                            "workspace_id": "workspace-2",
                            "workspace_name": "Workspace Two",
                            "bot_id": "bot-2",
                        },
                    )
                    loaded = load_token(
                        integration_id="agent-labbook",
                        credential_provider=stored["provider"],
                        credential_ref=stored["credential_ref"],
                        metadata=stored["metadata"],
                    )
                    listed = list_credentials(
                        integration_id="agent-labbook",
                        provider_name="1password",
                    )
                    deleted = delete_token(
                        integration_id="agent-labbook",
                        credential_provider=stored["provider"],
                        credential_ref=stored["credential_ref"],
                        metadata=stored["metadata"],
                    )

        self.assertEqual(loaded["refresh_token"], "refresh-2")
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["workspace_name"], "Workspace Two")
        self.assertTrue(deleted)
        self.assertEqual(stored["metadata"]["vault"], default_vault["id"])
        self.assertEqual(stored["metadata"]["vault_name"], default_vault["name"])
        self.assertRegex(stored["metadata"]["title"], r"^Notion / Agent Labbook / Workspace Two / [0-9a-f]{6}$")
        self.assertEqual(items["index-item-456"]["title"], "Notion / Agent Labbook / Saved Sessions")
        item_commands = [command for command in commands if command[1] == "item"]
        self.assertTrue(all("--vault" in command for command in item_commands))
        self.assertTrue(
            all(command[command.index("--vault") + 1] == default_vault["id"] for command in item_commands)
        )
        self.assertTrue(all("--category" not in command for command in commands))

    def test_parse_index_payload_migrates_versionless_index(self) -> None:
        payload = _parse_index_payload(
            json.dumps(
                {
                    "integration_id": "agent-labbook",
                    "credentials": [
                        {
                            "credential_ref": "cred-1",
                            "workspace_name": "Workspace One",
                        }
                    ],
                }
            ),
            integration_id="agent-labbook",
        )

        self.assertEqual(payload["version"], 1)
        self.assertEqual(payload["credentials"][0]["credential_ref"], "cred-1")

    def test_onepassword_list_credentials_backfills_legacy_vault_metadata(self) -> None:
        default_vault = {"id": "vault-dev-123", "name": "Development"}
        items = {
            "vault-item-123": {
                "id": "vault-item-123",
                "title": "Notion / Agent Labbook / Workspace Two / abc123",
                "tags": ["notion-access-broker", "notion-access-broker/agent-labbook"],
                "vault": dict(default_vault),
                "fields": [
                    {
                        "id": "notesPlain",
                        "type": "STRING",
                        "purpose": "NOTES",
                        "label": "notesPlain",
                        "value": json.dumps(
                            {
                                "access_token": "access-2",
                                "refresh_token": "refresh-2",
                                "workspace_id": "workspace-2",
                                "workspace_name": "Workspace Two",
                                "bot_id": "bot-2",
                                "token_type": "bearer",
                            }
                        ),
                    }
                ],
            },
            "index-item-456": {
                "id": "index-item-456",
                "title": "Notion / Agent Labbook / Saved Sessions",
                "tags": ["notion-access-broker-index", "notion-access-broker-index/agent-labbook"],
                "vault": dict(default_vault),
                "fields": [
                    {
                        "id": "notesPlain",
                        "type": "STRING",
                        "purpose": "NOTES",
                        "label": "notesPlain",
                        "value": json.dumps(
                            {
                                "version": 1,
                                "integration_id": "agent-labbook",
                                "credentials": [
                                    {
                                        "credential_ref": "vault-item-123",
                                        "workspace_id": "workspace-2",
                                        "workspace_name": "Workspace Two",
                                        "bot_id": "bot-2",
                                        "authorized_at": "2026-04-05T06:44:50+00:00",
                                        "updated_at": "2026-04-05T06:44:50+00:00",
                                        "metadata": {
                                            "title": "Notion / Agent Labbook / Workspace Two / abc123"
                                        },
                                    }
                                ],
                            }
                        ),
                    }
                ],
            },
        }

        def fake_run(args, check, capture_output, text, input=None):  # noqa: ANN001
            self.assertFalse(check)
            self.assertTrue(capture_output)
            self.assertTrue(text)
            if args[1:3] == ["vault", "list"]:
                return mock.Mock(returncode=0, stdout=json.dumps([default_vault]), stderr="")
            if args[1:3] == ["item", "list"]:
                tag = args[args.index("--tags") + 1]
                payload = [
                    {"id": item_id, "title": str(item.get("title") or "")}
                    for item_id, item in items.items()
                    if tag in list(item.get("tags") or [])
                ]
                return mock.Mock(returncode=0, stdout=json.dumps(payload), stderr="")
            if args[1:3] == ["item", "get"]:
                item_id = args[3]
                return mock.Mock(returncode=0, stdout=json.dumps(items[item_id]), stderr="")
            if args[1:3] == ["item", "edit"]:
                item_id = args[3]
                items[item_id] = json.loads(input)
                items[item_id]["id"] = item_id
                items[item_id]["vault"] = dict(default_vault)
                return mock.Mock(returncode=0, stdout=json.dumps(items[item_id]), stderr="")
            raise AssertionError(f"Unexpected command: {' '.join(args)}")

        with mock.patch("notion_access_broker.credentials.shutil.which", return_value="/usr/bin/op"):
            with mock.patch("notion_access_broker.credentials.subprocess.run", side_effect=fake_run):
                with mock.patch.dict("os.environ", {}, clear=True):
                    listed = list_credentials(
                        integration_id="agent-labbook",
                        provider_name="1password",
                    )

        self.assertEqual(listed[0]["metadata"]["vault"], default_vault["id"])
        self.assertEqual(listed[0]["metadata"]["vault_name"], default_vault["name"])
        index_payload = json.loads(items["index-item-456"]["fields"][0]["value"])
        self.assertEqual(index_payload["credentials"][0]["metadata"]["vault"], default_vault["id"])
        self.assertEqual(index_payload["credentials"][0]["metadata"]["vault_name"], default_vault["name"])

    def test_parse_index_payload_rejects_future_version(self) -> None:
        with self.assertRaises(CredentialProviderError) as exc_info:
            _parse_index_payload(
                json.dumps(
                    {
                        "version": 999,
                        "integration_id": "agent-labbook",
                        "credentials": [],
                    }
                ),
                integration_id="agent-labbook",
            )

        self.assertIn("future version", str(exc_info.exception))


if __name__ == "__main__":
    unittest.main()
