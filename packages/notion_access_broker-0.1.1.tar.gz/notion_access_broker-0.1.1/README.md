# Notion Access Broker

`notion-access-broker` is a shared access-broker project for Notion public-integration flows used by multiple integrations.

It has two parts:

- a shared Cloudflare Worker for browser OAuth, handoff, token refresh, and integration-scoped credential orchestration
- a shared local Python helper module for cross-project credential storage through `keyring` or `1Password`

It centralizes:

- `start` and `callback` routes for Notion OAuth
- token refresh
- encrypted short-lived OAuth sessions for browser continuation
- encrypted handoff bundles for local MCP clients

It does not implement integration-specific UI. Each integration keeps its own browser pages and business logic, then calls this service for:

- `POST /api/create-session`
- `POST /api/resolve-session`
- `POST /api/finalize-handoff`
- `POST /api/consume-handoff`
- `POST /api/refresh`

All JSON API responses now use a stable envelope:

- success payloads include `ok: true`, `api_version: 1`, and `supported_api_versions`
- error payloads include `ok: false`, `api_version: 1`, `supported_api_versions`, and a structured `error_code`
- handoff resource selections are normalized before they leave the broker so integrations see a stable `selected_resources` shape

JSON API clients can also send `X-Notion-Access-Broker-Accept-Api-Versions` to fail fast when the broker no longer serves a compatible contract.

For the current HTTP request and response contract, see [`docs/http-api.md`](./docs/http-api.md).
For a machine-readable snapshot used by tests, see [`docs/http-api.snapshot.json`](./docs/http-api.snapshot.json).

Local MCP clients can also import `notion_access_broker.credentials` to store long-lived tokens outside project-local JSON files.

Those helpers now also keep a provider-local credential index with non-secret metadata so new projects can discover reusable saved credentials without storing token secrets in project-local files.

When an integration such as Agent Labbook exposes MCP tools, the intended split is:

- the access broker handles OAuth, refresh, signed browser continuation, and shared credential custody
- the integration MCP server exposes read-only project state through resources and explicit side-effecting steps through tools
- the integration MCP server decides when to finalize a pending browser handoff into project-local session and bindings state

## Local Credential Providers

The Python helper module supports:

- automatic `1password` preference when the local `op` CLI is installed and can access 1Password
- `keyring` as the fallback cross-platform credential provider
- `1password` through the local `op` CLI, using either a configured vault or the account's default vault
- short human-readable entry names in both 1Password and the system keyring

Environment variables:

- `NOTION_ACCESS_BROKER_CREDENTIAL_PROVIDER=keyring|1password`
- `NOTION_ACCESS_BROKER_1PASSWORD_VAULT=YOUR_VAULT` to pin 1Password to a specific vault; if unset, the default vault is used
- `NOTION_ACCESS_BROKER_KEYRING_SERVICE_NAME=Notion` to override the visible keyring service name if needed

The Python helper module also exposes provider diagnostics so integrations can report:

- which provider would be selected by default
- whether `1Password` is currently reachable
- whether the system keyring backend appears configured
- why a provider is unavailable when discovery fails

## Hosted Routes

- `https://superplanner.ai/notion/oauth/start`
- `https://superplanner.ai/notion/oauth/callback`
- `https://superplanner.ai/notion/oauth/api/create-session`
- `https://superplanner.ai/notion/oauth/api/resolve-session`
- `https://superplanner.ai/notion/oauth/api/finalize-handoff`
- `https://superplanner.ai/notion/oauth/api/consume-handoff`
- `https://superplanner.ai/notion/oauth/api/refresh`

`/health` now also reports per-integration OAuth readiness so you can see which integrations have both client secrets configured.

## Integration Registry

`INTEGRATION_REGISTRY_JSON` maps an `integration` ID to the Notion credentials and allowed browser continuation targets.

Example:

```json
{
  "agent-labbook": {
    "client_id_env": "NOTION_CLIENT_ID_AGENT_LABBOOK",
    "client_secret_env": "NOTION_CLIENT_SECRET_AGENT_LABBOOK",
    "default_continue_to": "https://superplanner.ai/notion/agent-labbook/oauth/continue",
    "allowed_continue_to_prefixes": [
      "https://superplanner.ai/notion/agent-labbook/"
    ]
  }
}
```

## Required Secrets

- `NOTION_ACCESS_BROKER_SHARED_SECRET`
- one `client_id` secret per integration
- one `client_secret` secret per integration

For example:

- `NOTION_CLIENT_ID_AGENT_LABBOOK`
- `NOTION_CLIENT_SECRET_AGENT_LABBOOK`
- `NOTION_CLIENT_ID_CALDAV_SYNC`
- `NOTION_CLIENT_SECRET_CALDAV_SYNC`

## Local Test

```bash
npm test
uv run --with pytest pytest tests/test_credentials.py
```
