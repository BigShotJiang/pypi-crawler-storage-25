from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any


DEFAULT_PROVIDER = "auto"
KEYRING_PROVIDER = "keyring"
ONEPASSWORD_PROVIDER = "1password"
KEYRING_SERVICE_NAME = "Notion"
KEYRING_INDEX_ACCOUNT_SUFFIX = "Saved Sessions"
ONEPASSWORD_TITLE_PREFIX = "Notion"
ONEPASSWORD_TAG = "notion-access-broker"
ONEPASSWORD_INDEX_TAG = "notion-access-broker-index"
INDEX_VERSION = 1
TOKEN_FIELDS = (
    "access_token",
    "refresh_token",
    "token_type",
    "bot_id",
    "workspace_id",
    "workspace_name",
    "workspace_icon",
    "duplicated_template_id",
    "owner",
)


class CredentialProviderError(RuntimeError):
    pass


@dataclass(frozen=True)
class StoredCredentialHandle:
    provider: str
    credential_ref: str
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class CredentialProviderStatus:
    provider: str
    available: bool
    selected_by_default: bool = False
    reason: str | None = None
    details: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "available": self.available,
            "selected_by_default": self.selected_by_default,
            "reason": self.reason,
            "details": self.details or None,
        }


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def store_token(
    *,
    integration_id: str,
    token_payload: dict[str, Any],
    provider_name: str | None = None,
) -> dict[str, Any]:
    provider = _provider_for_name(provider_name)
    stored = provider.store_token(integration_id=integration_id, token_payload=token_payload)
    return {
        "provider": stored.provider,
        "credential_ref": stored.credential_ref,
        "metadata": stored.metadata or None,
    }


def load_token(
    *,
    integration_id: str,
    credential_provider: str,
    credential_ref: str,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    provider = _provider_for_name(credential_provider)
    return provider.load_token(
        integration_id=integration_id,
        credential_ref=credential_ref,
        metadata=metadata or {},
    )


def delete_token(
    *,
    integration_id: str,
    credential_provider: str,
    credential_ref: str,
    metadata: dict[str, Any] | None = None,
) -> bool:
    provider = _provider_for_name(credential_provider)
    return provider.delete_token(
        integration_id=integration_id,
        credential_ref=credential_ref,
        metadata=metadata or {},
    )


def list_credentials(
    *,
    integration_id: str,
    provider_name: str | None = None,
) -> list[dict[str, Any]]:
    provider = _provider_for_name(provider_name)
    return provider.list_credentials(integration_id=integration_id)


def provider_diagnostics(provider_name: str | None = None) -> dict[str, Any]:
    requested_provider = _normalized_provider_name(provider_name)
    if requested_provider not in {"auto", KEYRING_PROVIDER, ONEPASSWORD_PROVIDER}:
        raise CredentialProviderError(
            f"Unsupported credential provider {requested_provider!r}. Use 'keyring' or '1password'."
        )

    providers = _provider_registry()
    provider_order = [ONEPASSWORD_PROVIDER, KEYRING_PROVIDER]
    resolved_provider = _auto_provider_name() if requested_provider == "auto" else requested_provider
    statuses = [
        providers[name].status(selected_by_default=name == resolved_provider)
        for name in provider_order
    ]
    return {
        "requested_provider": requested_provider,
        "resolved_provider": resolved_provider,
        "providers": [status.as_dict() for status in statuses],
    }


def _provider_for_name(provider_name: str | None):
    normalized = _normalized_provider_name(provider_name)
    if normalized in {"", "auto"}:
        normalized = _auto_provider_name()
    provider = _provider_registry().get(normalized)
    if provider is not None:
        return provider
    raise CredentialProviderError(
        f"Unsupported credential provider {normalized!r}. Use 'keyring' or '1password'."
    )


def _normalized_provider_name(provider_name: str | None) -> str:
    return str(provider_name or os.getenv("NOTION_ACCESS_BROKER_CREDENTIAL_PROVIDER") or DEFAULT_PROVIDER).strip().lower()


def _provider_registry() -> dict[str, Any]:
    return {
        KEYRING_PROVIDER: _KeyringProvider(),
        ONEPASSWORD_PROVIDER: _OnePasswordProvider(),
    }


def _auto_provider_name() -> str:
    if _onepassword_cli_is_ready():
        return ONEPASSWORD_PROVIDER
    return KEYRING_PROVIDER


def _slugify(value: str, *, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", str(value or "").casefold()).strip("-")
    return slug or fallback


def _required_token_payload(token_payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(token_payload, dict):
        raise CredentialProviderError("token_payload must be an object.")

    access_token = str(token_payload.get("access_token") or "").strip()
    refresh_token = str(token_payload.get("refresh_token") or "").strip()
    if not access_token or not refresh_token:
        raise CredentialProviderError("token_payload must include both access_token and refresh_token.")

    sanitized = {
        key: token_payload.get(key)
        for key in TOKEN_FIELDS
        if key in token_payload
    }
    sanitized["access_token"] = access_token
    sanitized["refresh_token"] = refresh_token
    sanitized["token_type"] = str(token_payload.get("token_type") or "bearer").strip() or "bearer"
    return sanitized


def _onepassword_op_binary() -> str | None:
    candidate = str(os.getenv("NOTION_ACCESS_BROKER_1PASSWORD_OP_BIN") or "op").strip() or "op"
    return shutil.which(candidate)


def _configured_onepassword_vault() -> str | None:
    vault = str(os.getenv("NOTION_ACCESS_BROKER_1PASSWORD_VAULT") or "").strip()
    return vault or None


def _accessible_onepassword_vaults(*, op_binary: str | None = None) -> list[dict[str, str]]:
    resolved_binary = op_binary or _onepassword_op_binary()
    if not resolved_binary:
        raise CredentialProviderError(
            "The 1Password CLI binary was not found. Install `op` or set NOTION_ACCESS_BROKER_1PASSWORD_OP_BIN."
        )

    completed = subprocess.run(
        [resolved_binary, "vault", "list", "--format", "json"],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip() or "The 1Password CLI could not list vaults."
        raise CredentialProviderError(detail)

    try:
        payload = json.loads(completed.stdout or "[]")
    except json.JSONDecodeError as exc:
        raise CredentialProviderError("The 1Password CLI returned invalid JSON while listing vaults.") from exc
    if not isinstance(payload, list):
        raise CredentialProviderError("The 1Password CLI returned an unexpected vault list payload.")

    vaults: list[dict[str, str]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        vault_id = str(item.get("id") or "").strip()
        vault_name = str(item.get("name") or item.get("title") or "").strip()
        if not vault_id and not vault_name:
            continue
        vaults.append({"id": vault_id, "name": vault_name})
    return vaults


def _single_accessible_onepassword_vault(*, op_binary: str | None = None) -> dict[str, str] | None:
    vaults = _accessible_onepassword_vaults(op_binary=op_binary)
    if len(vaults) != 1:
        return None
    return vaults[0]


def _onepassword_cli_is_ready() -> bool:
    return _onepassword_cli_status().available


def _onepassword_cli_status(*, selected_by_default: bool = False) -> CredentialProviderStatus:
    op_binary = _onepassword_op_binary()
    if not op_binary:
        return CredentialProviderStatus(
            provider=ONEPASSWORD_PROVIDER,
            available=False,
            selected_by_default=selected_by_default,
            reason="The 1Password CLI binary was not found in PATH.",
            details={"op_binary": None, "vault": _configured_onepassword_vault() or "default"},
        )

    try:
        vaults = _accessible_onepassword_vaults(op_binary=op_binary)
    except CredentialProviderError as exc:
        return CredentialProviderStatus(
            provider=ONEPASSWORD_PROVIDER,
            available=False,
            selected_by_default=selected_by_default,
            reason=str(exc),
            details={"op_binary": op_binary, "vault": _configured_onepassword_vault() or "default"},
        )

    configured_vault = _configured_onepassword_vault()
    if configured_vault:
        expected = configured_vault.casefold()
        for item in vaults:
            for key in ("id", "name"):
                candidate = str(item.get(key) or "").strip()
                if candidate and candidate.casefold() == expected:
                    return CredentialProviderStatus(
                        provider=ONEPASSWORD_PROVIDER,
                        available=True,
                        selected_by_default=selected_by_default,
                        details={"op_binary": op_binary, "vault": configured_vault},
                    )
        return CredentialProviderStatus(
            provider=ONEPASSWORD_PROVIDER,
            available=False,
            selected_by_default=selected_by_default,
            reason=f"The configured 1Password vault {configured_vault!r} is not accessible.",
            details={"op_binary": op_binary, "vault": configured_vault},
        )

    if not vaults:
        return CredentialProviderStatus(
            provider=ONEPASSWORD_PROVIDER,
            available=False,
            selected_by_default=selected_by_default,
            reason="The 1Password CLI could not access any vaults.",
            details={"op_binary": op_binary, "vault": "default"},
        )

    if len(vaults) == 1:
        single_vault = vaults[0]
        return CredentialProviderStatus(
            provider=ONEPASSWORD_PROVIDER,
            available=True,
            selected_by_default=selected_by_default,
            details={
                "op_binary": op_binary,
                "vault": str(single_vault.get("name") or single_vault.get("id") or "default"),
                "vault_id": str(single_vault.get("id") or "").strip() or None,
                "vault_name": str(single_vault.get("name") or "").strip() or None,
            },
        )

    return CredentialProviderStatus(
        provider=ONEPASSWORD_PROVIDER,
        available=True,
        selected_by_default=selected_by_default,
        details={
            "op_binary": op_binary,
            "vault": "default",
            "available_vault_count": len(vaults),
        },
    )


def _credential_identity(integration_id: str, token_payload: dict[str, Any]) -> tuple[str, str]:
    workspace_id = str(token_payload.get("workspace_id") or "").strip() or "unknown-workspace"
    bot_id = str(token_payload.get("bot_id") or "").strip() or "unknown-bot"
    workspace_name = str(token_payload.get("workspace_name") or "").strip()
    seed = json.dumps(
        {
            "integration_id": integration_id,
            "workspace_id": workspace_id,
            "bot_id": bot_id,
        },
        ensure_ascii=True,
        sort_keys=True,
    )
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    label = workspace_name or workspace_id or bot_id
    return digest, label


def _integration_display_name(integration_id: str) -> str:
    words = [part for part in re.split(r"[^A-Za-z0-9]+", str(integration_id or "").strip()) if part]
    if not words:
        return "Integration"
    return " ".join(word.capitalize() for word in words)


def _compact_label(value: str | None, *, fallback: str) -> str:
    compact = re.sub(r"\s+", " ", str(value or "").strip())
    if not compact:
        compact = fallback
    if len(compact) <= 48:
        return compact
    return f"{compact[:45].rstrip()}..."


def _short_credential_code(credential_ref: str) -> str:
    compact = str(credential_ref or "").strip()
    return compact[:6] or "saved"


def _credential_account_name(*, integration_id: str, label: str | None, credential_ref: str) -> str:
    return " / ".join(
        [
            _integration_display_name(integration_id),
            _compact_label(label, fallback="Workspace"),
            _short_credential_code(credential_ref),
        ]
    )


def _keyring_index_account_name(integration_id: str) -> str:
    return f"{_integration_display_name(integration_id)} / {KEYRING_INDEX_ACCOUNT_SUFFIX}"


def _service_name(integration_id: str, metadata: dict[str, Any] | None = None) -> str:
    del integration_id
    configured_name = str(
        (metadata or {}).get("service_name") or os.getenv("NOTION_ACCESS_BROKER_KEYRING_SERVICE_NAME") or KEYRING_SERVICE_NAME
    ).strip()
    return configured_name or KEYRING_SERVICE_NAME


def _onepassword_title(*, integration_id: str, label: str | None, credential_ref: str) -> str:
    return " / ".join(
        [
            ONEPASSWORD_TITLE_PREFIX,
            _credential_account_name(integration_id=integration_id, label=label, credential_ref=credential_ref),
        ]
    )


def _onepassword_index_title(integration_id: str) -> str:
    return " / ".join(
        [
            ONEPASSWORD_TITLE_PREFIX,
            _integration_display_name(integration_id),
            KEYRING_INDEX_ACCOUNT_SUFFIX,
        ]
    )


def _credential_summary(
    *,
    credential_ref: str,
    token_payload: dict[str, Any],
    metadata: dict[str, Any] | None,
    authorized_at: str | None = None,
    updated_at: str | None = None,
) -> dict[str, Any]:
    return {
        "credential_ref": str(credential_ref or "").strip(),
        "workspace_id": str(token_payload.get("workspace_id") or "").strip() or None,
        "workspace_name": str(token_payload.get("workspace_name") or "").strip() or None,
        "bot_id": str(token_payload.get("bot_id") or "").strip() or None,
        "authorized_at": str(authorized_at or "").strip() or _utc_now(),
        "updated_at": str(updated_at or "").strip() or _utc_now(),
        "metadata": metadata if isinstance(metadata, dict) else None,
    }


def _normalize_summary(entry: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(entry, dict):
        return None
    credential_ref = str(entry.get("credential_ref") or "").strip()
    if not credential_ref:
        return None
    metadata = entry.get("metadata") if isinstance(entry.get("metadata"), dict) else None
    return {
        "credential_ref": credential_ref,
        "workspace_id": str(entry.get("workspace_id") or "").strip() or None,
        "workspace_name": str(entry.get("workspace_name") or "").strip() or None,
        "bot_id": str(entry.get("bot_id") or "").strip() or None,
        "authorized_at": str(entry.get("authorized_at") or "").strip() or None,
        "updated_at": str(entry.get("updated_at") or "").strip() or None,
        "metadata": metadata,
    }


def _empty_index(integration_id: str) -> dict[str, Any]:
    return {
        "version": INDEX_VERSION,
        "integration_id": integration_id,
        "updated_at": _utc_now(),
        "credentials": [],
    }


def _parse_index_payload(raw: str, *, integration_id: str) -> dict[str, Any]:
    if not str(raw or "").strip():
        return _empty_index(integration_id)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise CredentialProviderError("The stored credential index is not valid JSON.") from exc
    if not isinstance(payload, dict):
        raise CredentialProviderError("The stored credential index is not an object.")

    version_raw = payload.get("version")
    if version_raw in (None, ""):
        version = 0
    else:
        try:
            version = int(version_raw)
        except (TypeError, ValueError) as exc:
            raise CredentialProviderError(f"The stored credential index has an invalid version: {version_raw!r}.") from exc

    if version > INDEX_VERSION:
        raise CredentialProviderError(
            f"The stored credential index uses unsupported future version {version}. Current version is {INDEX_VERSION}."
        )
    if version not in {0, INDEX_VERSION}:
        raise CredentialProviderError(
            f"The stored credential index uses unsupported version {version}. Current version is {INDEX_VERSION}."
        )

    stored_integration_id = str(payload.get("integration_id") or "").strip()
    if stored_integration_id and stored_integration_id != integration_id:
        raise CredentialProviderError("The stored credential index belongs to a different integration.")

    normalized_entries: list[dict[str, Any]] = []
    for item in list(payload.get("credentials") or []):
        normalized = _normalize_summary(item)
        if normalized is not None:
            normalized_entries.append(normalized)

    return {
        "version": INDEX_VERSION,
        "integration_id": integration_id,
        "updated_at": str(payload.get("updated_at") or "").strip() or None,
        "credentials": normalized_entries,
    }


def _serialize_index_payload(*, integration_id: str, credentials: list[dict[str, Any]]) -> str:
    normalized_entries = [
        normalized
        for item in credentials
        if (normalized := _normalize_summary(item)) is not None
    ]
    payload = {
        "version": INDEX_VERSION,
        "integration_id": integration_id,
        "updated_at": _utc_now(),
        "credentials": normalized_entries,
    }
    return json.dumps(payload, ensure_ascii=False, sort_keys=True)


def _upsert_summary(credentials: list[dict[str, Any]], summary: dict[str, Any]) -> list[dict[str, Any]]:
    credential_ref = str(summary.get("credential_ref") or "").strip()
    normalized = _normalize_summary(summary)
    if normalized is None or not credential_ref:
        raise CredentialProviderError("Cannot save a credential summary without a credential_ref.")
    remaining = [
        item
        for item in credentials
        if str(item.get("credential_ref") or "").strip() != credential_ref
    ]
    remaining.append(normalized)
    return remaining


def _remove_summary(credentials: list[dict[str, Any]], credential_ref: str) -> list[dict[str, Any]]:
    clean_ref = str(credential_ref or "").strip()
    return [
        item
        for item in credentials
        if str(item.get("credential_ref") or "").strip() != clean_ref
    ]


def _sorted_credentials(credentials: list[dict[str, Any]], *, provider_name: str) -> list[dict[str, Any]]:
    ordered = sorted(
        [_normalize_summary(item) for item in credentials],
        key=lambda item: (
            str((item or {}).get("workspace_name") or (item or {}).get("workspace_id") or (item or {}).get("bot_id") or (item or {}).get("credential_ref") or "").casefold(),
            str((item or {}).get("credential_ref") or ""),
        ),
    )
    return [
        {
            "provider": provider_name,
            **item,
        }
        for item in ordered
        if item is not None
    ]


class _KeyringProvider:
    provider_name = KEYRING_PROVIDER

    def status(self, *, selected_by_default: bool = False) -> CredentialProviderStatus:
        try:
            import keyring
        except ModuleNotFoundError:
            return CredentialProviderStatus(
                provider=self.provider_name,
                available=False,
                selected_by_default=selected_by_default,
                reason="The keyring package is not installed.",
                details=None,
            )

        get_keyring = getattr(keyring, "get_keyring", None)
        if not callable(get_keyring):
            return CredentialProviderStatus(
                provider=self.provider_name,
                available=True,
                selected_by_default=selected_by_default,
                details={"backend": None},
            )

        try:
            backend = get_keyring()
        except Exception as exc:  # noqa: BLE001
            return CredentialProviderStatus(
                provider=self.provider_name,
                available=False,
                selected_by_default=selected_by_default,
                reason=f"Could not initialize the system keyring backend: {exc}",
                details=None,
            )

        backend_name = f"{backend.__class__.__module__}.{backend.__class__.__name__}"
        priority = getattr(backend, "priority", None)
        backend_details = {"backend": backend_name, "priority": priority}
        backend_class_name = backend.__class__.__name__.casefold()
        if "failkeyring" in backend_class_name or priority == 0:
            return CredentialProviderStatus(
                provider=self.provider_name,
                available=False,
                selected_by_default=selected_by_default,
                reason="The system keyring backend is not configured.",
                details=backend_details,
            )
        return CredentialProviderStatus(
            provider=self.provider_name,
            available=True,
            selected_by_default=selected_by_default,
            details=backend_details,
        )

    def store_token(self, *, integration_id: str, token_payload: dict[str, Any]) -> StoredCredentialHandle:
        sanitized = _required_token_payload(token_payload)
        try:
            import keyring
            from keyring.errors import KeyringError, NoKeyringError, PasswordDeleteError
        except ModuleNotFoundError as exc:
            raise CredentialProviderError("The keyring package is not installed.") from exc

        credential_id, label = _credential_identity(integration_id, sanitized)
        service_name = _service_name(integration_id)
        account_name = _credential_account_name(integration_id=integration_id, label=label, credential_ref=credential_id)
        existing_index = self._read_index(integration_id=integration_id, service_name=service_name)
        existing_entry = next(
            (
                item
                for item in existing_index
                if str(item.get("credential_ref") or "").strip() == credential_id
            ),
            None,
        )
        existing_metadata = (existing_entry or {}).get("metadata") if isinstance((existing_entry or {}).get("metadata"), dict) else {}
        previous_account_name = str(existing_metadata.get("account_name") or "").strip() or (
            credential_id if existing_entry is not None else ""
        )
        try:
            keyring.set_password(service_name, account_name, json.dumps(sanitized, ensure_ascii=False, sort_keys=True))
            keyring.set_password(
                service_name,
                _keyring_index_account_name(integration_id),
                _serialize_index_payload(
                    integration_id=integration_id,
                    credentials=_upsert_summary(
                        existing_index,
                        _credential_summary(
                            credential_ref=credential_id,
                            token_payload=sanitized,
                            metadata={
                                "service_name": service_name,
                                "account_name": account_name,
                            },
                            authorized_at=str((existing_entry or {}).get("authorized_at") or "").strip() or None,
                        ),
                    ),
                ),
            )
            if previous_account_name and previous_account_name != account_name:
                try:
                    keyring.delete_password(service_name, previous_account_name)
                except PasswordDeleteError:
                    pass
                except (NoKeyringError, KeyringError) as exc:
                    raise CredentialProviderError(
                        f"Could not rename the Notion credential in the system keyring: {exc}"
                    ) from exc
        except (NoKeyringError, KeyringError) as exc:
            raise CredentialProviderError(f"Could not save the Notion credential in the system keyring: {exc}") from exc

        return StoredCredentialHandle(
            provider=self.provider_name,
            credential_ref=credential_id,
            metadata={
                "service_name": service_name,
                "account_name": account_name,
            },
        )

    def load_token(self, *, integration_id: str, credential_ref: str, metadata: dict[str, Any]) -> dict[str, Any]:
        service_name = str(metadata.get("service_name") or _service_name(integration_id, metadata)).strip()
        account_name = (
            str(metadata.get("account_name") or "").strip()
            or self._account_name_from_index(integration_id=integration_id, service_name=service_name, credential_ref=credential_ref)
            or credential_ref
        )
        try:
            import keyring
            from keyring.errors import KeyringError, NoKeyringError
        except ModuleNotFoundError as exc:
            raise CredentialProviderError("The keyring package is not installed.") from exc

        try:
            stored = keyring.get_password(service_name, account_name)
        except (NoKeyringError, KeyringError) as exc:
            raise CredentialProviderError(f"Could not read the Notion credential from the system keyring: {exc}") from exc
        if not stored:
            raise CredentialProviderError("The requested Notion credential was not found in the system keyring.")
        try:
            payload = json.loads(stored)
        except json.JSONDecodeError as exc:
            raise CredentialProviderError("The stored Notion keyring entry is not valid JSON.") from exc
        return _required_token_payload(payload)

    def list_credentials(self, *, integration_id: str) -> list[dict[str, Any]]:
        service_name = _service_name(integration_id)
        return _sorted_credentials(
            self._read_index(integration_id=integration_id, service_name=service_name),
            provider_name=self.provider_name,
        )

    def delete_token(self, *, integration_id: str, credential_ref: str, metadata: dict[str, Any]) -> bool:
        service_name = str(metadata.get("service_name") or _service_name(integration_id, metadata)).strip()
        account_name = (
            str(metadata.get("account_name") or "").strip()
            or self._account_name_from_index(integration_id=integration_id, service_name=service_name, credential_ref=credential_ref)
            or credential_ref
        )
        try:
            import keyring
            from keyring.errors import KeyringError, NoKeyringError, PasswordDeleteError
        except ModuleNotFoundError as exc:
            raise CredentialProviderError("The keyring package is not installed.") from exc
        deleted = True
        try:
            keyring.delete_password(service_name, account_name)
        except PasswordDeleteError:
            deleted = False
        except (NoKeyringError, KeyringError) as exc:
            raise CredentialProviderError(f"Could not delete the Notion credential from the system keyring: {exc}") from exc
        remaining = _remove_summary(
            self._read_index(integration_id=integration_id, service_name=service_name),
            credential_ref,
        )
        try:
            keyring.set_password(
                service_name,
                _keyring_index_account_name(integration_id),
                _serialize_index_payload(integration_id=integration_id, credentials=remaining),
            )
        except (NoKeyringError, KeyringError) as exc:
            raise CredentialProviderError(f"Could not update the Notion credential index in the system keyring: {exc}") from exc
        return deleted

    def _read_index(self, *, integration_id: str, service_name: str) -> list[dict[str, Any]]:
        try:
            import keyring
            from keyring.errors import KeyringError, NoKeyringError
        except ModuleNotFoundError as exc:
            raise CredentialProviderError("The keyring package is not installed.") from exc
        try:
            stored = keyring.get_password(service_name, _keyring_index_account_name(integration_id))
        except (NoKeyringError, KeyringError) as exc:
            raise CredentialProviderError(f"Could not read the Notion credential index from the system keyring: {exc}") from exc
        return list(_parse_index_payload(stored or "", integration_id=integration_id).get("credentials") or [])

    def _account_name_from_index(self, *, integration_id: str, service_name: str, credential_ref: str) -> str | None:
        for item in self._read_index(integration_id=integration_id, service_name=service_name):
            if str(item.get("credential_ref") or "").strip() != str(credential_ref or "").strip():
                continue
            metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
            account_name = str(metadata.get("account_name") or "").strip()
            if account_name:
                return account_name
        return None


class _OnePasswordProvider:
    provider_name = ONEPASSWORD_PROVIDER

    def status(self, *, selected_by_default: bool = False) -> CredentialProviderStatus:
        return _onepassword_cli_status(selected_by_default=selected_by_default)

    def store_token(self, *, integration_id: str, token_payload: dict[str, Any]) -> StoredCredentialHandle:
        sanitized = _required_token_payload(token_payload)
        credential_id, label = _credential_identity(integration_id, sanitized)
        vault = self._vault_name()
        title = self._title(integration_id=integration_id, label=label, credential_id=credential_id)
        tags = [ONEPASSWORD_TAG, f"{ONEPASSWORD_TAG}/{_slugify(integration_id, fallback='notion')}"]
        note_value = json.dumps(sanitized, ensure_ascii=False, sort_keys=True, indent=2)
        existing_item_id = self._find_item_id(vault=vault, title=title, tag=ONEPASSWORD_TAG)
        if existing_item_id:
            self._update_item(
                item_id=existing_item_id,
                vault=vault,
                title=title,
                tags=tags,
                note_value=note_value,
            )
            item_id = existing_item_id
        else:
            item_id = self._create_item(
                vault=vault,
                title=title,
                tags=tags,
                note_value=note_value,
            )
        resolved_metadata = self._item_metadata(item_id=item_id, vault=vault)
        resolved_vault = str(resolved_metadata.get("vault") or "").strip() or vault

        index_item_id, existing_index = self._load_index(integration_id=integration_id, vault=resolved_vault)
        existing_entry = next(
            (
                item
                for item in existing_index
                if str(item.get("credential_ref") or "").strip() == item_id
            ),
            None,
        )
        self._write_index(
            integration_id=integration_id,
            vault=resolved_vault,
            item_id=index_item_id,
            credentials=_upsert_summary(
                existing_index,
                _credential_summary(
                    credential_ref=item_id,
                    token_payload=sanitized,
                    metadata={"title": title, **resolved_metadata},
                    authorized_at=str((existing_entry or {}).get("authorized_at") or "").strip() or None,
                ),
            ),
        )

        return StoredCredentialHandle(
            provider=self.provider_name,
            credential_ref=item_id,
            metadata={"title": title, **resolved_metadata},
        )

    def load_token(self, *, integration_id: str, credential_ref: str, metadata: dict[str, Any]) -> dict[str, Any]:
        del integration_id
        item = self._get_item(item_id=credential_ref, vault=self._vault_name(metadata))
        note_value = self._note_value(item)
        try:
            payload = json.loads(note_value)
        except json.JSONDecodeError as exc:
            raise CredentialProviderError("The stored 1Password item does not contain valid JSON token data.") from exc
        return _required_token_payload(payload)

    def list_credentials(self, *, integration_id: str) -> list[dict[str, Any]]:
        vault = self._vault_name()
        item_id, credentials = self._load_index(integration_id=integration_id, vault=vault)
        hydrated_credentials, changed, resolved_vault = self._hydrate_index_credentials(
            credentials=credentials,
            vault=vault,
        )
        if changed:
            self._write_index(
                integration_id=integration_id,
                vault=resolved_vault,
                item_id=item_id,
                credentials=hydrated_credentials,
            )
        return _sorted_credentials(hydrated_credentials, provider_name=self.provider_name)

    def delete_token(self, *, integration_id: str, credential_ref: str, metadata: dict[str, Any]) -> bool:
        vault = self._vault_name(metadata)
        deleted = True
        try:
            self._run_op(["item", "delete", credential_ref, *self._vault_args(vault), "--archive=false"])
        except CredentialProviderError as exc:
            if "isn't an item" in str(exc) or "not found" in str(exc).lower():
                deleted = False
            else:
                raise
        index_item_id, credentials = self._load_index(integration_id=integration_id, vault=vault)
        self._write_index(
            integration_id=integration_id,
            vault=vault,
            item_id=index_item_id,
            credentials=_remove_summary(credentials, credential_ref),
        )
        return deleted

    def _index_title(self, integration_id: str) -> str:
        return _onepassword_index_title(integration_id)

    def _index_tags(self, integration_id: str) -> list[str]:
        return [ONEPASSWORD_INDEX_TAG, f"{ONEPASSWORD_INDEX_TAG}/{_slugify(integration_id, fallback='notion')}"]

    def _load_index(self, *, integration_id: str, vault: str | None) -> tuple[str | None, list[dict[str, Any]]]:
        item_id = self._find_item_id(vault=vault, title=self._index_title(integration_id), tag=ONEPASSWORD_INDEX_TAG)
        if not item_id:
            return None, []
        item = self._get_item(item_id=item_id, vault=vault)
        return item_id, list(_parse_index_payload(self._note_value(item), integration_id=integration_id).get("credentials") or [])

    def _write_index(
        self,
        *,
        integration_id: str,
        vault: str | None,
        item_id: str | None,
        credentials: list[dict[str, Any]],
    ) -> None:
        title = self._index_title(integration_id)
        tags = self._index_tags(integration_id)
        note_value = _serialize_index_payload(integration_id=integration_id, credentials=credentials)
        if item_id:
            self._update_item(
                item_id=item_id,
                vault=vault,
                title=title,
                tags=tags,
                note_value=note_value,
            )
            return
        self._create_item(
            vault=vault,
            title=title,
            tags=tags,
            note_value=note_value,
        )

    def _op_binary(self) -> str:
        resolved = _onepassword_op_binary()
        if not resolved:
            raise CredentialProviderError(
                "The 1Password CLI binary was not found. Install `op` or set NOTION_ACCESS_BROKER_1PASSWORD_OP_BIN."
            )
        return resolved

    def _vault_name(self, metadata: dict[str, Any] | None = None) -> str | None:
        vault = str((metadata or {}).get("vault") or _configured_onepassword_vault() or "").strip()
        if not vault:
            single_vault = _single_accessible_onepassword_vault(op_binary=self._op_binary())
            if single_vault is not None:
                vault = str(single_vault.get("id") or single_vault.get("name") or "").strip()
        return vault or None

    def _title(self, *, integration_id: str, label: str, credential_id: str) -> str:
        return _onepassword_title(integration_id=integration_id, label=label, credential_ref=credential_id)

    def _vault_args(self, vault: str | None) -> list[str]:
        if not vault:
            return []
        return ["--vault", vault]

    def _run_op(self, args: list[str], *, input_text: str | None = None) -> str:
        completed = subprocess.run(
            [self._op_binary(), *args, "--format", "json"],
            check=False,
            capture_output=True,
            text=True,
            input=input_text,
        )
        if completed.returncode != 0:
            detail = completed.stderr.strip() or completed.stdout.strip() or f"`op {' '.join(args)}` failed."
            raise CredentialProviderError(detail)
        return completed.stdout

    def _find_item_id(self, *, vault: str | None, title: str, tag: str) -> str | None:
        raw = self._run_op(["item", "list", *self._vault_args(vault), "--tags", tag])
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CredentialProviderError("1Password returned invalid JSON while listing items.") from exc
        if not isinstance(payload, list):
            raise CredentialProviderError("1Password returned an unexpected payload while listing items.")
        for item in payload:
            if not isinstance(item, dict):
                continue
            if str(item.get("title") or "").strip() == title:
                item_id = str(item.get("id") or "").strip()
                if item_id:
                    return item_id
        return None

    def _item_template(self, *, note_value: str) -> str:
        return json.dumps(
            {
                "category": "SECURE_NOTE",
                "fields": [
                    {
                        "id": "notesPlain",
                        "type": "STRING",
                        "purpose": "NOTES",
                        "label": "notesPlain",
                        "value": note_value,
                    }
                ],
            },
            ensure_ascii=False,
        )

    def _create_item(self, *, vault: str | None, title: str, tags: list[str], note_value: str) -> str:
        raw = self._run_op(
            [
                "item",
                "create",
                *self._vault_args(vault),
                "--title",
                title,
                "--tags",
                ",".join(tags),
                "-",
            ],
            input_text=self._item_template(note_value=note_value),
        )
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CredentialProviderError("1Password returned invalid JSON while creating an item.") from exc
        item_id = str(payload.get("id") or "").strip()
        if not item_id:
            raise CredentialProviderError("1Password did not return an item id after creating the credential.")
        return item_id

    def _get_item(self, *, item_id: str, vault: str | None) -> dict[str, Any]:
        raw = self._run_op(["item", "get", item_id, *self._vault_args(vault)])
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CredentialProviderError("1Password returned invalid JSON while reading an item.") from exc
        if not isinstance(payload, dict):
            raise CredentialProviderError("1Password returned an unexpected payload while reading an item.")
        return payload

    def _update_item(
        self,
        *,
        item_id: str,
        vault: str | None,
        title: str,
        tags: list[str],
        note_value: str,
    ) -> None:
        item = self._get_item(item_id=item_id, vault=vault)
        item["title"] = title
        item["tags"] = tags
        fields = item.get("fields")
        if not isinstance(fields, list):
            fields = []
            item["fields"] = fields
        note_field = None
        for field in fields:
            if not isinstance(field, dict):
                continue
            if str(field.get("id") or "").strip() == "notesPlain" or str(field.get("purpose") or "").strip() == "NOTES":
                note_field = field
                break
        if note_field is None:
            note_field = {
                "id": "notesPlain",
                "type": "STRING",
                "purpose": "NOTES",
                "label": "notesPlain",
            }
            fields.append(note_field)
        note_field["value"] = note_value
        self._run_op(["item", "edit", item_id, *self._vault_args(vault), "-"], input_text=json.dumps(item, ensure_ascii=False))

    def _item_metadata(self, *, item_id: str, vault: str | None) -> dict[str, str]:
        item = self._get_item(item_id=item_id, vault=vault)
        metadata: dict[str, str] = {}
        vault_info = item.get("vault") if isinstance(item.get("vault"), dict) else None
        vault_id = str((vault_info or {}).get("id") or "").strip()
        vault_name = str((vault_info or {}).get("name") or (vault_info or {}).get("title") or "").strip()
        if vault_id:
            metadata["vault"] = vault_id
        elif vault_name:
            metadata["vault"] = vault_name
        if vault_name:
            metadata["vault_name"] = vault_name
        return metadata

    def _hydrate_index_credentials(
        self,
        *,
        credentials: list[dict[str, Any]],
        vault: str | None,
    ) -> tuple[list[dict[str, Any]], bool, str | None]:
        hydrated: list[dict[str, Any]] = []
        changed = False
        resolved_vault = vault
        for item in credentials:
            normalized = _normalize_summary(item)
            if normalized is None:
                continue
            metadata = normalized.get("metadata") if isinstance(normalized.get("metadata"), dict) else {}
            existing_vault = str(metadata.get("vault") or "").strip()
            if existing_vault:
                resolved_vault = resolved_vault or existing_vault
                hydrated.append(normalized)
                continue
            try:
                item_metadata = self._item_metadata(
                    item_id=str(normalized.get("credential_ref") or "").strip(),
                    vault=self._vault_name(metadata),
                )
            except CredentialProviderError:
                hydrated.append(normalized)
                continue
            if item_metadata:
                merged_metadata = {**metadata, **item_metadata}
                normalized["metadata"] = merged_metadata
                resolved_vault = resolved_vault or str(item_metadata.get("vault") or "").strip() or resolved_vault
                changed = True
            hydrated.append(normalized)
        return hydrated, changed, resolved_vault

    def _note_value(self, item: dict[str, Any]) -> str:
        fields = item.get("fields")
        if not isinstance(fields, list):
            raise CredentialProviderError("The 1Password item does not contain any fields.")
        for field in fields:
            if not isinstance(field, dict):
                continue
            if str(field.get("id") or "").strip() == "notesPlain" or str(field.get("purpose") or "").strip() == "NOTES":
                value = str(field.get("value") or "").strip()
                if value:
                    return value
        raise CredentialProviderError("The 1Password item does not contain a notesPlain field.")
