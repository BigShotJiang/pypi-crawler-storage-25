"""tracegarden FastAPI integration."""
