"""
RAMJET - Distributed peer cache for ML training data

A peer-to-peer cache that sits between any ML training job and any
S3-compatible object store. Eliminates redundant S3 pulls when teams share
datasets across runs. Works with any framework that hits an S3/HTTP/local
dataset path — PyTorch, TensorFlow, JAX, HuggingFace Datasets, Ultralytics,
etc. — and any DDP launcher (torchrun, DeepSpeed, Accelerate, SLURM).

Quick Start:
    import ramjetio
    from torch.utils.data import DataLoader

    ramjetio.init()  # Connects to dashboard, starts cache server

    dataset = ramjetio.CachedDataset(your_dataset)
    loader = DataLoader(dataset, batch_size=32)

Run with:
    export RAMJET_API_KEY="your_key"
    torchrun --nproc_per_node=2 train.py

See https://docs.ramjet.io for full documentation.
"""

__version__ = "0.9.3"
__author__ = "RAMJET"
__email__ = "support@ramjet.io"

import os
import logging
import threading
import atexit
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

# Core cache functionality
from ramjetio.cache import DistributedCache
from ramjetio.consistent_hash import ConsistentHash
from ramjetio.pytorch import CachedDataset

# Universal dataset for S3/MinIO, HTTP, Local sources
from ramjetio.datasets import UniversalDataset, yolo_collate_fn

# Configuration (backend URL is hardcoded, user only needs API key)
from ramjetio.config import (
    RAMJET_BACKEND_URL,
    RAMJET_BACKEND_HOST,
    RAMJET_BACKEND_PORT,
    DEFAULT_CACHE_PORT,
    DEFAULT_CACHE_CAPACITY,
    DEFAULT_STORAGE_PATH,
    get_api_key,
    get_backend_host,
    get_backend_port,
    get_backend_url,
    get_backend_use_ssl,
    is_configured,
)

# Backend client for data source configuration
from ramjetio.backend_client import (
    BackendClient,
    get_data_source_config,
    get_cluster_nodes,
    get_backend_client,
    init_backend,
    DATA_SOURCE_TYPE_NONE,
    DATA_SOURCE_TYPE_S3,
    DATA_SOURCE_TYPE_LOCAL,
    DATA_SOURCE_TYPE_HTTP,
)


# =============================================================================
# Global State
# =============================================================================

_initialized = False
_global_cache: Optional[DistributedCache] = None
_server_process = None
_backend_client: Optional[BackendClient] = None
_node_refresh_thread: Optional[threading.Thread] = None
_refresh_running = False

# F13: cross-rank topology sync via shared file. LOCAL_RANK=0 publishes ring
# updates after backend refresh; non-zero LOCAL_RANK siblings on the same host
# watch the file and apply newer versions to their own DistributedCache.
# Prevents the 0-10s window where only rank 0 sees a node join/leave while
# ranks 1..N keep routing against a stale ring.
_TOPOLOGY_FILE = os.environ.get("RAMJET_TOPOLOGY_FILE", "/tmp/ramjet_topology.json")
_topology_watch_thread: Optional[threading.Thread] = None
_topology_watch_running = False
_topology_watch_interval: float = float(os.environ.get("RAMJET_TOPOLOGY_WATCH_INTERVAL", "2.0"))

# F-Cfg1: track the last cluster_config version applied via the topology
# watcher so we only act on genuinely newer pushes. Separate from
# ``DistributedCache.config_version`` (which counts ring mutations) because
# the backend version increments independently (e.g. replication_factor
# changes that don't move nodes).
_last_applied_cluster_config_version: int = 0
_last_applied_data_source_fingerprint: Optional[str] = None
_cluster_config_lock = threading.Lock()

# F-Shut1: track whether atexit has registered our shutdown handler so we
# don't register it twice across a re-init in the same interpreter (e.g.
# unit tests that call init() then shutdown() then init() again).
_atexit_registered: bool = False
_shutdown_in_progress: bool = False
# Grace period (seconds) for the cache server subprocess to flush state and
# unregister itself before we SIGKILL it. Override via env for slow disks.
try:
    _SHUTDOWN_GRACE_S: float = float(os.environ.get("RAMJET_SHUTDOWN_GRACE_S", "10"))
except ValueError:
    _SHUTDOWN_GRACE_S = 10.0

# A1 sticky cache for /stats heartbeat — last known good snapshot + TTL.
# Prevents metrics flicker-to-zero when a single /stats fetch times out.
_stats_sticky_cache: Dict[str, Any] = {}
_stats_sticky_ts: float = 0.0
_stats_sticky_warn_count: int = 0

# A2 DDP rank fan-in — every rank atomically writes its own
# training sample-rate/step/loss into /tmp/ramjet_rank_{RANK}.json,
# rank 0 aggregates them for the single heartbeat. Prevents the
# "only rank-0 reports" flicker when ranks drift.
_RANK_FANIN_DIR = os.environ.get("RAMJET_RANK_FANIN_DIR", "/tmp")
_RANK_FANIN_STALE_SEC = 60.0

# Training status (updated via set_training_status())
_training_status: Dict[str, Any] = {
    'is_training': False,
    'phase': 'idle',  # 'caching', 'training', 'validating', 'idle'
    'current_epoch': 0,
    'total_epochs': 0,
    'current_step': 0,
    'total_steps': 0,
    'epoch_progress': 0.0,
    'loss': 0.0,
    'task': '',
    'started_at': 0,
    'samples_per_second': 0.0,
}
_training_lock = threading.Lock()


# F8: per-rank cache-path split counters. Accumulated across the lifetime of
# the SDK process (typically one export call + training). Emitted via
# NodeMetrics.cache_hits_{local,peer,s3} on heartbeat so the backend /
# frontend can drill down by rank.
_cache_path_stats: Dict[str, int] = {
    'cache_hits_local': 0,
    'cache_hits_peer': 0,
    'cache_hits_s3': 0,
    # v0.9.2 (Phase A): cumulative bytes ingested per source. Surfaced via
    # NodeMetrics.ingress_bytes_{local,peer,s3} on heartbeat so the dashboard
    # can render a stacked Data-pipeline-rate chart.
    'ingress_bytes_local': 0,
    'ingress_bytes_peer': 0,
    'ingress_bytes_s3': 0,
}
_cache_path_lock = threading.Lock()


def _record_cache_path(source: str, nbytes: int = 0) -> None:
    """Increment the per-path counters. ``source`` is one of
    ``'cache_local' | 'cache_peer' | 's3' | 'failed'``; unknown labels are
    silently ignored to keep the critical-path call cheap.

    ``nbytes`` (optional) is the size of the payload that came through that
    path. When >0 it is added to ``ingress_bytes_<source>`` so we can later
    plot a real bandwidth breakdown rather than just hit counts.
    """
    if source == 'cache_local':
        hit_key, byte_key = 'cache_hits_local', 'ingress_bytes_local'
    elif source == 'cache_peer':
        hit_key, byte_key = 'cache_hits_peer', 'ingress_bytes_peer'
    elif source == 's3':
        hit_key, byte_key = 'cache_hits_s3', 'ingress_bytes_s3'
    else:
        return
    with _cache_path_lock:
        _cache_path_stats[hit_key] += 1
        if nbytes > 0:
            _cache_path_stats[byte_key] += int(nbytes)


def _get_cache_path_stats() -> Dict[str, int]:
    """Snapshot the cumulative per-path counters. Thread-safe."""
    with _cache_path_lock:
        return dict(_cache_path_stats)


# =============================================================================
# DDP Utilities
# =============================================================================

def _get_distributed_info() -> tuple:
    """
    Get distributed training info from environment.
    
    Supports all major distributed training launchers:
    - torchrun / torch.distributed.launch
    - DeepSpeed
    - HuggingFace Accelerate  
    - PyTorch Lightning
    - SLURM (srun)
    - OpenMPI (mpirun)
    - Horovod
    - Manual setup
    
    Returns:
        (local_rank, global_rank, world_size, is_main_local, is_main_global)
    """
    # Try different environment variable sources in priority order
    
    # 1. Standard PyTorch distributed (torchrun, DeepSpeed, Accelerate, Lightning)
    local_rank = os.environ.get("LOCAL_RANK")
    global_rank = os.environ.get("RANK")
    world_size = os.environ.get("WORLD_SIZE")
    
    # 2. SLURM
    if local_rank is None:
        local_rank = os.environ.get("SLURM_LOCALID")
    if global_rank is None:
        global_rank = os.environ.get("SLURM_PROCID")
    if world_size is None:
        world_size = os.environ.get("SLURM_NTASKS")
    
    # 3. OpenMPI (mpirun)
    if local_rank is None:
        local_rank = os.environ.get("OMPI_COMM_WORLD_LOCAL_RANK")
    if global_rank is None:
        global_rank = os.environ.get("OMPI_COMM_WORLD_RANK")
    if world_size is None:
        world_size = os.environ.get("OMPI_COMM_WORLD_SIZE")
    
    # 4. MPICH
    if local_rank is None:
        local_rank = os.environ.get("MPI_LOCALRANKID")
    if global_rank is None:
        global_rank = os.environ.get("PMI_RANK")
    if world_size is None:
        world_size = os.environ.get("PMI_SIZE")
    
    # 5. Horovod
    if local_rank is None:
        local_rank = os.environ.get("HOROVOD_LOCAL_RANK")
    if global_rank is None:
        global_rank = os.environ.get("HOROVOD_RANK")
    if world_size is None:
        world_size = os.environ.get("HOROVOD_SIZE")
    
    # 6. AWS SageMaker
    if local_rank is None:
        local_rank = os.environ.get("SM_CURRENT_INSTANCE_LOCAL_RANK", os.environ.get("SMDATAPARALLEL_LOCAL_RANK"))
    
    # Convert to int with defaults
    local_rank = int(local_rank) if local_rank is not None else 0
    global_rank = int(global_rank) if global_rank is not None else 0
    world_size = int(world_size) if world_size is not None else 1
    
    # Check if this is the main process on this machine
    # LOCAL_RANK=0 is the main process per machine
    is_main_local = (local_rank == 0)
    
    # Global main (for logging)
    is_main_global = (global_rank == 0)
    
    return local_rank, global_rank, world_size, is_main_local, is_main_global


# =============================================================================
# Main API: ramjetio.init()
# =============================================================================

def init(
    api_key: Optional[str] = None,
    cache_path: Optional[str] = None,
    cache_size: Optional[str] = None,
    port: Optional[int] = None,
    auto_start_server: bool = True,
) -> bool:
    """
    Initialize RAMJET distributed cache.
    
    This is the recommended way to start using RAMJET. It:
    1. Connects to the RAMJET dashboard
    2. Registers this node
    3. Starts a local cache server (optional)
    4. Starts heartbeat/metrics reporting
    
    DDP-Aware Behavior:
    - When using torchrun/DDP with multiple processes per machine,
      only LOCAL_RANK=0 will start the cache server and register with backend.
    - All ranks share the same cache server on that machine.
    - This prevents port conflicts and duplicate registrations.
    
    Args:
        api_key: API key (default: from RAMJET_API_KEY env var)
        cache_path: Cache directory (default: /tmp/ramjet_cache or RAMJET_CACHE_PATH)
        cache_size: Max cache size e.g. "100GB" (default: from RAMJET_CACHE_SIZE)
        port: Cache server port (default: 9000 or RAMJET_PORT)
        auto_start_server: Start local cache server automatically
        
    Returns:
        True if initialized successfully, False otherwise
        
    Example:
        # Works seamlessly with torchrun:
        # torchrun --nproc_per_node=4 train.py
        
        import ramjetio
        ramjetio.init()  # Only LOCAL_RANK=0 starts server
        
        # All ranks can use the cache
        dataset = ramjetio.CachedDataset(your_dataset)
    """
    global _initialized, _global_cache, _server_process, _backend_client
    
    if _initialized:
        logger.warning("RAMJET already initialized")
        return True
    
    # Get DDP info
    local_rank, global_rank, world_size, is_main_local, is_main_global = _get_distributed_info()
    
    if world_size > 1:
        logger.info(f"DDP detected: rank={global_rank}/{world_size}, local_rank={local_rank}")
    
    # Read config from env vars if not provided
    api_key = api_key or get_api_key()
    cache_path = cache_path or os.environ.get("RAMJET_CACHE_PATH", DEFAULT_STORAGE_PATH)
    cache_size = cache_size or os.environ.get("RAMJET_CACHE_SIZE", DEFAULT_CACHE_CAPACITY)
    port = port or int(os.environ.get("RAMJET_PORT", DEFAULT_CACHE_PORT))
    
    if not api_key and is_main_global:
        logger.warning(
            "RAMJET_API_KEY not set. Running in local mode without dashboard connection. "
            "Get your API key from https://app.ramjet.io"
        )
    
    # Step 1: Start local cache server (only on LOCAL_RANK=0)
    # This ensures one cache server per machine, shared by all local ranks
    if auto_start_server and is_main_local:
        _server_process = _start_cache_server(
            port=port,
            cache_path=cache_path,
            cache_size=cache_size,
        )
    elif auto_start_server and not is_main_local:
        # Wait for main process to start server
        logger.debug(f"Rank {local_rank}: Waiting for LOCAL_RANK=0 to start cache server...")
        _wait_for_server(port, timeout=30)
    
    # Step 2: Connect to backend (only on LOCAL_RANK=0 to avoid duplicate registrations)
    if api_key and is_main_local:
        try:
            _backend_client = BackendClient(node_port=port, api_key=api_key)
            if _backend_client.connect():
                if is_main_global:
                    logger.info(f"✓ Connected to RAMJET dashboard")
                
                # Start heartbeat in background
                _backend_client.start_heartbeat(
                    get_metrics_fn=_get_cache_metrics,
                    auto_reconnect=True,
                    on_config_changed=_on_backend_config_changed,
                )
            else:
                if is_main_global:
                    logger.warning("Could not connect to dashboard. Running in offline mode.")
        except Exception as e:
            if is_main_global:
                logger.warning(f"Backend connection failed: {e}. Running in offline mode.")
    
    # Step 3: Create global cache client (all ranks do this)
    nodes = _discover_nodes()

    # Read replication_factor from cluster config (default: 1)
    replication_factor = 1
    if _backend_client and _backend_client.cluster_config:
        replication_factor = _backend_client.cluster_config.get('replication_factor', 1)

    # F9: derive default key namespace from cluster_id so that two clusters
    # sharing the same backend cannot read each other's cache entries. Callers
    # can append a dataset fingerprint later via ``ramjetio.set_cache_namespace``.
    default_namespace: Optional[str] = None
    if _backend_client and _backend_client.cluster_id:
        default_namespace = f"cluster:{_backend_client.cluster_id}"

    # F5: this process's own cache server identity, used to classify cache
    # hits as ``local`` vs ``peer`` in :meth:`DistributedCache.get_with_source`.
    # BackendClient resolves ``hostname`` exactly the way it registers with
    # the backend, so the string is guaranteed to match one of the entries
    # in the cluster node list (when this node is part of the cluster).
    local_node: Optional[str] = None
    if _backend_client and _backend_client.hostname:
        local_node = f"{_backend_client.hostname}:{port}"
    if local_node:
        logger.info(f"[Rank {global_rank}] Cache local_node identity: {local_node!r}")

    if nodes:
        _global_cache = DistributedCache(
            nodes=nodes,
            replication_factor=replication_factor,
            key_namespace=default_namespace,
            local_node=local_node,
        )
        if is_main_global:
            logger.info(f"✓ Cache ready with {len(nodes)} node(s): {nodes}")
    else:
        # Fallback to local only
        _global_cache = DistributedCache(
            nodes=[f"localhost:{port}"],
            replication_factor=replication_factor,
            key_namespace=default_namespace,
            local_node=local_node or f"localhost:{port}",
        )
        if is_main_global:
            logger.info(f"✓ Cache ready (local mode on port {port})")

    # F2: If torch.distributed is already initialised (e.g. launched under
    # torchrun and dist.init_process_group() was called before ramjetio.init()),
    # force every rank to agree on the same node list RIGHT NOW so that the
    # consistent-hash ring cannot diverge on subsequent export calls. When
    # DDP initialises later, integrations should call ``agree_on_nodes()``
    # themselves (e.g. top of export_local) — see _export_yolo_local.
    try:
        agree_on_nodes()
    except Exception as e:
        logger.debug(f"Skipped post-init node agreement: {e}")
    
    # Step 4: Start background node ring refresh (only on LOCAL_RANK=0 with backend)
    if api_key and is_main_local and _backend_client and _backend_client.is_connected:
        _start_node_refresh()
        # F13: publish initial topology so non-zero LOCAL_RANK siblings can
        # converge on first watch tick instead of waiting for a node change.
        _publish_topology()
    elif not is_main_local:
        # F13: non-publishing ranks watch the shared file for updates
        # produced by their host's LOCAL_RANK=0 sibling.
        _start_topology_watch()

    # F-Shut1: register shutdown handler exactly once. Guarantees the cache
    # server subprocess gets terminated and the backend node is unregistered
    # even if the user forgets to call ``ramjetio.shutdown()``. ``atexit``
    # is idempotent against double-register because we gate on _atexit_done.
    global _atexit_registered
    if not _atexit_registered:
        atexit.register(_atexit_shutdown)
        _atexit_registered = True

    _initialized = True
    if is_main_global:
        logger.info("✓ RAMJET initialized successfully")
    return True


def _start_node_refresh(interval: float = 10.0) -> None:
    """Start background thread that periodically refreshes the node hash ring."""
    global _node_refresh_thread, _refresh_running
    _refresh_running = True
    _node_refresh_thread = threading.Thread(
        target=_node_refresh_loop,
        args=(interval,),
        daemon=True,
        name="ramjet-node-refresh",
    )
    _node_refresh_thread.start()
    logger.debug(f"Started node refresh thread (interval: {interval}s)")


def _node_refresh_loop(interval: float) -> None:
    """Background loop that re-discovers nodes and updates the hash ring."""
    import time
    while _refresh_running and _global_cache is not None:
        time.sleep(interval)
        if not _refresh_running:
            break
        try:
            new_nodes = _discover_nodes()
            if new_nodes is None:
                continue
            current = set(_global_cache.nodes)
            updated = set(new_nodes)
            added = updated - current
            removed = current - updated
            if added or removed:
                for node in added:
                    _global_cache.add_node(node)
                for node in removed:
                    _global_cache.remove_node(node)
                logger.info(f"Node ring updated: {len(_global_cache.nodes)} nodes "
                            f"(+{len(added)} -{len(removed)}): {_global_cache.nodes}")
                # F13: publish the new view so sibling ranks on this host
                # can converge without waiting for the next agree_on_nodes().
                _publish_topology()
        except Exception as e:
            logger.debug(f"Node refresh error: {e}")
    logger.debug("Node refresh loop ended")


# =============================================================================
# F13: Cross-rank topology sync (shared-file IPC)
# =============================================================================

def _datasource_fingerprint(ds: Optional[Dict[str, Any]]) -> Optional[str]:
    """Stable hash of a datasource dict, excluding secrets.

    The fingerprint lets non-publishing ranks detect that the data source
    changed mid-training without ever seeing the raw credentials. Secrets
    are filtered before hashing so a rotated S3 key (cosmetic to the SDK)
    does not look like a configuration change.
    """
    if not ds:
        return None
    import hashlib
    import json as _json
    redacted = {k: v for k, v in ds.items() if k not in (
        "s3_secret_key", "s3_access_key", "http_auth_header",
    )}
    blob = _json.dumps(redacted, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode()).hexdigest()[:16]


def _apply_cluster_config_update(version: int, cc: Dict[str, Any]) -> None:
    """Apply a cluster_config snapshot received via the topology file.

    Idempotent and version-monotonic. Live-updates fields that are safe to
    swap mid-training (replication_factor); logs a clear WARN if the
    data-source fingerprint changed because a mid-epoch source swap would
    silently invalidate the cache and is officially unsupported.
    """
    global _last_applied_cluster_config_version
    global _last_applied_data_source_fingerprint
    with _cluster_config_lock:
        if version <= _last_applied_cluster_config_version:
            return
        rf = cc.get("replication_factor")
        fp = cc.get("data_source_fingerprint")
        if isinstance(rf, int) and rf > 0 and _global_cache is not None:
            if rf != _global_cache.replication_factor:
                logger.info(
                    "Cluster config v%d: replication_factor %d → %d (live)",
                    version, _global_cache.replication_factor, rf,
                )
                _global_cache.replication_factor = rf
        prev_fp = _last_applied_data_source_fingerprint
        if fp is not None and prev_fp is not None and fp != prev_fp:
            logger.warning(
                "Cluster config v%d: data_source changed mid-run "
                "(fingerprint %s → %s). New samples will use the new "
                "source; already-cached entries are NOT invalidated. "
                "Restart training for a clean cutover.",
                version, prev_fp, fp,
            )
        _last_applied_data_source_fingerprint = fp
        _last_applied_cluster_config_version = version


def _on_backend_config_changed(_cfg: Dict[str, Any]) -> None:
    """Heartbeat callback (rank 0): republish topology so siblings observe.

    Runs in the heartbeat thread. Must not block. ``_publish_topology``
    is best-effort and swallows IO errors at DEBUG.
    """
    try:
        # Apply locally too so rank 0's own _last_applied_* state stays
        # in sync with what we just published.
        if _backend_client is not None and _backend_client.cluster_config:
            ver = int(getattr(_backend_client, "cluster_config_version", 0) or 0)
            cfg = _backend_client.cluster_config
            _apply_cluster_config_update(ver, {
                "replication_factor": int(cfg.get("replication_factor", 1)),
                "data_source_fingerprint": _datasource_fingerprint(cfg.get("data_source")),
            })
        _publish_topology()
    except Exception as e:
        logger.debug("_on_backend_config_changed: %s", e)


def _publish_topology() -> None:
    """Write the current ring + cluster-config snapshot to the shared file.

    Called by LOCAL_RANK=0 after every ring mutation **and** every backend
    config push. Writes a temp file in the same directory and atomically
    renames over the target so concurrent readers always see a complete
    JSON document. Errors are logged at DEBUG; publish failures must never
    crash the refresh thread.

    Payload schema (additive; older readers ignore unknown keys):
        {
          "version": int,                    # cache-ring version
          "nodes": [str, ...],
          "cluster_config_version": int,    # backend cluster.config_version
          "cluster_config": {                # public, non-sensitive fields
            "replication_factor": int,
            "data_source_fingerprint": str  # hash of full ds dict; rank>0
                                            # uses it to detect change.
          }
        }
    Credentials (s3_secret_key etc.) are **never** written to disk.
    """
    if _global_cache is None:
        return
    import json
    import tempfile
    try:
        directory = os.path.dirname(_TOPOLOGY_FILE) or "."
        os.makedirs(directory, exist_ok=True)
        payload: Dict[str, Any] = {
            "version": _global_cache.config_version,
            "nodes": list(_global_cache.nodes),
        }
        # F-Cfg1: piggy-back the latest cluster_config snapshot if rank 0
        # has a connected backend. Lets sibling ranks observe replication-
        # factor changes and warn on data-source mutations mid-training.
        if _backend_client is not None and _backend_client.cluster_config:
            cfg = _backend_client.cluster_config
            payload["cluster_config_version"] = int(
                getattr(_backend_client, "cluster_config_version", 0) or 0
            )
            payload["cluster_config"] = {
                "replication_factor": int(cfg.get("replication_factor", 1)),
                "data_source_fingerprint": _datasource_fingerprint(
                    cfg.get("data_source")
                ),
            }
        # Atomic write: temp file in same dir + rename (POSIX atomic).
        fd, tmp_path = tempfile.mkstemp(
            prefix=".ramjet_topology.", suffix=".tmp", dir=directory,
        )
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(payload, f)
            os.replace(tmp_path, _TOPOLOGY_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except Exception as e:
        logger.debug(f"Failed to publish topology to {_TOPOLOGY_FILE}: {e}")


def _read_topology_file() -> Optional[Dict[str, Any]]:
    """Read and validate the shared topology file. Returns None on any error
    (missing file, malformed JSON, bad shape). Watcher must never crash on
    a corrupt or partially-written file.
    """
    import json
    try:
        with open(_TOPOLOGY_FILE, "r") as f:
            payload = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(payload, dict):
        return None
    version = payload.get("version")
    nodes = payload.get("nodes")
    if not isinstance(version, int) or not isinstance(nodes, list):
        return None
    if not all(isinstance(n, str) for n in nodes):
        return None
    out: Dict[str, Any] = {"version": version, "nodes": nodes}
    # Optional cluster-config block (F-Cfg1). Reject malformed shape; absence
    # is fine and means "no config update available".
    cc_ver = payload.get("cluster_config_version")
    cc = payload.get("cluster_config")
    if isinstance(cc_ver, int) and isinstance(cc, dict):
        rf = cc.get("replication_factor")
        fp = cc.get("data_source_fingerprint")
        if isinstance(rf, int) and (fp is None or isinstance(fp, str)):
            out["cluster_config_version"] = cc_ver
            out["cluster_config"] = {
                "replication_factor": rf,
                "data_source_fingerprint": fp,
            }
    return out


def _start_topology_watch(interval: Optional[float] = None) -> None:
    """Start the watcher thread on non-publishing ranks (LOCAL_RANK > 0)."""
    global _topology_watch_thread, _topology_watch_running
    if _topology_watch_thread is not None and _topology_watch_thread.is_alive():
        return
    _topology_watch_running = True
    interval = interval if interval is not None else _topology_watch_interval
    _topology_watch_thread = threading.Thread(
        target=_topology_watch_loop,
        args=(interval,),
        daemon=True,
        name="ramjet-topology-watch",
    )
    _topology_watch_thread.start()
    logger.debug(f"Started topology watch thread (interval: {interval}s)")


def _topology_watch_loop(interval: float) -> None:
    """Poll the shared topology file and apply newer versions to the local ring.

    Uses :meth:`DistributedCache.replace_nodes` which is version-monotonic:
    a stale or equal-version payload is a no-op, so concurrent watchers
    cannot regress the ring and there is no thundering-herd hazard when
    multiple ranks observe the same publish event.
    """
    import time
    last_mtime: float = 0.0
    while _topology_watch_running and _global_cache is not None:
        time.sleep(interval)
        if not _topology_watch_running:
            break
        try:
            try:
                mtime = os.path.getmtime(_TOPOLOGY_FILE)
            except OSError:
                continue
            if mtime <= last_mtime:
                continue
            last_mtime = mtime
            payload = _read_topology_file()
            if payload is None:
                continue
            version = payload["version"]
            nodes = payload["nodes"]
            if version <= _global_cache.config_version:
                continue
            applied = _global_cache.replace_nodes(nodes, version)
            if applied:
                logger.info(
                    "Topology watcher applied v%d (%d nodes) on this rank",
                    version, len(nodes),
                )
            # F-Cfg1: also apply any cluster_config update embedded in the
            # payload. This is independent of the ring version: a config
            # bump may arrive without ring changes (e.g. user changes
            # replication_factor on dashboard).
            cc_ver = payload.get("cluster_config_version")
            cc = payload.get("cluster_config")
            if isinstance(cc_ver, int) and isinstance(cc, dict):
                _apply_cluster_config_update(cc_ver, cc)
        except Exception as e:
            logger.debug(f"Topology watch error: {e}")
    logger.debug("Topology watch loop ended")


def _wait_for_server(port: int, timeout: int = 30) -> bool:
    """Wait for cache server to become available."""
    import socket
    import time
    
    start = time.time()
    while time.time() - start < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            if result == 0:
                return True
        except:
            pass
        time.sleep(0.5)
    
    logger.warning(f"Timeout waiting for cache server on port {port}")
    return False


def _start_cache_server(port: int, cache_path: str, cache_size: str):
    """Start local cache server in a subprocess."""
    import subprocess
    import os
    
    # Check if server is already running on this port
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        if result == 0:
            logger.info(f"Cache server already running on port {port}")
            return None
    except:
        pass
    
    # Ensure cache directory exists
    os.makedirs(cache_path, exist_ok=True)
    
    # Start server - try ramjet-server first, fallback to python -m
    logger.info(f"Starting cache server on port {port}...")
    try:
        import shutil
        import sys
        
        # Check if ramjet-server is available in PATH
        ramjet_server_path = shutil.which("ramjet-server")
        
        if ramjet_server_path:
            cmd = [
                ramjet_server_path,
                "--host", "0.0.0.0",
                "--port", str(port),
                "--storage-path", cache_path,
                "--capacity", cache_size,
            ]
        else:
            # Fallback to python -m
            cmd = [
                sys.executable, "-m", "ramjetio.cli.server",
                "--host", "0.0.0.0",
                "--port", str(port),
                "--storage-path", cache_path,
                "--capacity", cache_size,
            ]
        
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        
        # Wait for server to start
        import time
        for _ in range(10):
            time.sleep(0.5)
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                result = sock.connect_ex(('127.0.0.1', port))
                sock.close()
                if result == 0:
                    logger.info(f"✓ Cache server started on port {port}")
                    return proc
            except:
                pass
        
        logger.warning(f"Cache server may not have started properly")
        return proc
        
    except FileNotFoundError:
        logger.warning("ramjetio-server command not found. Install with: pip install ramjetio")
        return None
    except Exception as e:
        logger.warning(f"Could not start cache server: {e}")
        return None


def _discover_nodes():
    """Discover cache nodes from backend or environment.

    F1: The returned list is sorted so that every DDP rank builds an identical
    consistent-hash ring. Without this, two ranks can route the same key to
    different owner nodes (silent cache miss + duplicate S3 fetch).
    """
    # Try to get from backend (reuse the long-lived client's stub so we
    # don't re-register the node on every refresh tick — Phase 5.1 fix).
    if _backend_client and _backend_client.is_connected:
        try:
            nodes = _backend_client.get_cluster_nodes(online_only=True)
            if nodes:
                return sorted(f"{n['hostname']}:{n['port']}" for n in nodes)
        except Exception as e:
            logger.debug(f"Could not get nodes from backend: {e}")

    # Fallback to environment variable
    nodes_env = os.environ.get("RAMJET_NODES", "")
    if nodes_env:
        nodes = []
        for node in nodes_env.split(","):
            node = node.strip()
            if ":" in node:
                nodes.append(node)
            else:
                nodes.append(f"{node}:{DEFAULT_CACHE_PORT}")
        return sorted(nodes)

    return None


def agree_on_nodes() -> Optional[list]:
    """F2: force every DDP rank to use the same cache-node list.

    When ``torch.distributed`` is initialised with world_size > 1, this
    broadcasts rank 0's (already-sorted) node list to all other ranks and
    rebuilds the local hash ring from the agreed list. This closes the
    window where two ranks discover a different node set from the backend
    and route the same key to different owners.

    Safe no-op when torch is not installed, DDP is not initialised, or
    world_size == 1. Returns the agreed node list, or ``None`` when no
    cache is active.
    """
    global _global_cache
    if _global_cache is None:
        return None

    try:
        import torch.distributed as dist
    except Exception:
        return list(_global_cache.nodes)

    if not dist.is_available() or not dist.is_initialized():
        return list(_global_cache.nodes)
    if dist.get_world_size() <= 1:
        return list(_global_cache.nodes)

    # Rank 0 is the single source of truth. Every other rank replaces its
    # local list with whatever rank 0 saw.
    payload = [sorted(_global_cache.nodes) if dist.get_rank() == 0 else None]
    try:
        dist.broadcast_object_list(payload, src=0)
    except Exception as e:
        logger.warning(f"agree_on_nodes: broadcast failed: {e}")
        return list(_global_cache.nodes)

    agreed = payload[0] or []
    if not agreed:
        return list(_global_cache.nodes)

    if list(_global_cache.nodes) != agreed:
        logger.info(
            "agree_on_nodes: rank %d rebuilding ring from %d → %d agreed nodes",
            dist.get_rank(), len(_global_cache.nodes), len(agreed),
        )
        # F-Ring1: keep deterministic order; agreed already comes sorted from
        # rank 0, but be explicit so a future change to the broadcast payload
        # cannot silently desync ranks.
        agreed_sorted = sorted(agreed)
        _global_cache.nodes = agreed_sorted
        _global_cache._node_count = len(agreed_sorted)
        _global_cache.hash_ring = ConsistentHash(nodes=agreed_sorted)

    return list(agreed)


def set_cache_namespace(namespace: Optional[str]) -> None:
    """F9: set or update the global cache key namespace.

    Downstream integrations (e.g. datasets) can append a dataset fingerprint
    to the default ``cluster:<id>`` namespace after ``ramjetio.init()`` has
    established backend connection. Calling with ``None`` removes the
    namespace (legacy behaviour — not recommended for multi-tenant setups).
    """
    if _global_cache is None:
        logger.warning("set_cache_namespace called before ramjetio.init(); ignored")
        return
    _global_cache.set_key_namespace(namespace)


def freeze_ring() -> bool:
    """F4: freeze the global cache hash ring on its current snapshot.

    After this call, all cache set/get/delete/exists operations route
    according to the snapshot. ``add_node`` / ``remove_node`` still mutate
    the live ring, but do not affect routing until ``unfreeze_ring()`` is
    called. Safe to call when the cache is not yet initialised — returns
    ``False`` in that case.
    """
    if _global_cache is None:
        logger.debug("freeze_ring called before ramjetio.init(); ignored")
        return False
    _global_cache.set_ring_snapshot(_global_cache.snapshot_ring())
    return True


def unfreeze_ring() -> None:
    """F4: release a frozen ring snapshot. No-op if nothing is frozen or
    the cache is not initialised."""
    if _global_cache is None:
        return
    _global_cache.clear_ring_snapshot()


# -----------------------------------------------------------------------------
# A2 — DDP rank fan-in helpers
# -----------------------------------------------------------------------------

def _rank_fanin_enabled() -> bool:
    return os.environ.get("RAMJET_DDP_RANK_FANIN", "1") not in ("0", "false", "False")


def _rank_fanin_path(rank: int) -> str:
    return os.path.join(_RANK_FANIN_DIR, f"ramjet_rank_{rank}.json")


def _write_rank_fanin_sample(status: Dict[str, Any]) -> None:
    """Atomically persist this rank's training counters so rank 0 can
    aggregate. Safe to call from any rank; no-op if disabled or if the
    RANK env var is missing."""
    if not _rank_fanin_enabled():
        return
    try:
        rank = int(os.environ.get("RANK", "0"))
    except (ValueError, TypeError):
        return
    import json as _json
    import time as _time
    payload = {
        "rank": rank,
        "ts": _time.time(),
        "samples_per_second": float(status.get("samples_per_second", 0.0) or 0.0),
        "current_step": int(status.get("current_step", 0) or 0),
        "current_epoch": int(status.get("current_epoch", 0) or 0),
        "loss": float(status.get("loss", 0.0) or 0.0),
        "is_training": bool(status.get("is_training", False)),
    }
    path = _rank_fanin_path(rank)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as fh:
            _json.dump(payload, fh)
        os.replace(tmp, path)
    except OSError as e:
        logger.debug("rank fan-in write failed for rank=%d: %r", rank, e)


def _read_rank_fanin_samples() -> Dict[int, Dict[str, Any]]:
    """Read all fresh per-rank samples. Skips samples older than
    ``_RANK_FANIN_STALE_SEC`` so dead ranks don't poison aggregates."""
    import glob as _glob
    import json as _json
    import time as _time

    out: Dict[int, Dict[str, Any]] = {}
    if not _rank_fanin_enabled():
        return out
    pattern = os.path.join(_RANK_FANIN_DIR, "ramjet_rank_*.json")
    now = _time.time()
    for path in _glob.glob(pattern):
        try:
            with open(path) as fh:
                payload = _json.load(fh)
            rank = int(payload.get("rank", -1))
            ts = float(payload.get("ts", 0.0))
            if rank < 0 or now - ts > _RANK_FANIN_STALE_SEC:
                continue
            out[rank] = payload
        except (OSError, ValueError) as e:
            logger.debug("rank fan-in read failed for %s: %r", path, e)
            continue
    return out


def _aggregate_rank_fanin(local_status: Dict[str, Any]) -> Dict[str, Any]:
    """Combine the local training snapshot with samples from other
    ranks. Called only on the heartbeat-emitting rank (LOCAL_RANK=0).

    Aggregation rules:
      * ``samples_per_second`` — SUM across ranks (cluster-wide throughput)
      * ``current_step`` — MAX (fastest rank defines visible progress)
      * ``current_epoch`` — MAX
      * ``loss`` — mean across ranks that reported >0
      * ``ranks_reporting`` — count of fresh samples (diagnostic)
    """
    samples = _read_rank_fanin_samples()
    if not samples:
        return dict(local_status)

    merged = dict(local_status)
    total_sps = sum(float(s.get("samples_per_second", 0.0)) for s in samples.values())
    # Fall back to the local value if no rank file reports a positive rate.
    if total_sps > 0:
        merged["samples_per_second"] = total_sps
    steps = [int(s.get("current_step", 0)) for s in samples.values()]
    if steps:
        merged["current_step"] = max(max(steps), int(local_status.get("current_step", 0) or 0))
    epochs = [int(s.get("current_epoch", 0)) for s in samples.values()]
    if epochs:
        merged["current_epoch"] = max(max(epochs), int(local_status.get("current_epoch", 0) or 0))
    losses = [float(s.get("loss", 0.0)) for s in samples.values() if float(s.get("loss", 0.0)) > 0]
    if losses:
        merged["loss"] = sum(losses) / len(losses)
    merged["ranks_reporting"] = len(samples)
    return merged


def _get_cache_metrics() -> Dict[str, Any]:
    """Get current cache metrics for heartbeat (local node only)."""
    metrics = {}
    
    # Cache stats — query LOCAL node only, not all nodes in the cluster
    # The heartbeat is per-node, so each node should report its own stats
    port = int(os.environ.get("RAMJET_PORT", DEFAULT_CACHE_PORT))
    # A1: timeout tuning + retry-once + sticky fallback.
    # RAMJET_STATS_TIMEOUT (default 5.0s) — cap for each /stats call.
    # RAMJET_STATS_STICKY_TTL (default 30s) — how long the last good
    # snapshot remains usable after failures before we give up and
    # report zeros. Tune down in tests.
    stats_timeout = float(os.environ.get("RAMJET_STATS_TIMEOUT", "5.0"))
    sticky_ttl = float(os.environ.get("RAMJET_STATS_STICKY_TTL", "30.0"))
    global _stats_sticky_cache, _stats_sticky_ts, _stats_sticky_warn_count

    local_stats: Optional[Dict[str, Any]] = None
    last_exc: Optional[BaseException] = None
    try:
        import requests as _req
        # /stats is protected by the same X-RAMJET-API-Key the
        # server enforces when RAMJET_API_KEY is set — without the header we
        # get 401 and fall through to the sticky/zeros path, which wiped
        # throughput / latency on every heartbeat.
        try:
            from .config import get_api_key as _get_api_key
            from .server import AUTH_HEADER as _AUTH_HEADER
            _api_key = _get_api_key()
        except Exception:
            _api_key = None
            _AUTH_HEADER = "X-RAMJET-API-Key"
        _headers = {_AUTH_HEADER: _api_key} if _api_key else None
        for attempt in range(2):
            try:
                resp = _req.get(
                    f"http://localhost:{port}/stats",
                    timeout=stats_timeout,
                    headers=_headers,
                )
                if resp.status_code == 200:
                    local_stats = resp.json()
                    break
            except Exception as e:
                last_exc = e
                continue
    except Exception as e:
        last_exc = e

    if local_stats is not None:
        hits = local_stats.get('hits', 0)
        misses = local_stats.get('misses', 0)
        hit_ratio = hits / (hits + misses) if (hits + misses) > 0 else 0.0
        fresh = {
            'hits': hits,
            'misses': misses,
            'cache_size_bytes': local_stats.get('cache_size', 0),
            'cache_items': local_stats.get('items', 0),
            'hit_ratio': hit_ratio,
            # forward cache I/O throughput and latency so the
            # node-table columns stop flickering "—" <-> "< 0.1 MB/s".
            'throughput_mbps': local_stats.get('throughput_mbps', 0.0),
            'avg_latency_ms': local_stats.get('avg_latency_ms', 0.0),
            'p50_latency_ms': local_stats.get('p50_latency_ms', 0.0),
            'p99_latency_ms': local_stats.get('p99_latency_ms', 0.0),
        }
        metrics.update(fresh)
        # Refresh sticky snapshot on success.
        import time as _time
        _stats_sticky_cache = dict(fresh)
        _stats_sticky_ts = _time.time()
    else:
        # Fetch failed twice — try the sticky snapshot if still fresh.
        import time as _time
        age = _time.time() - _stats_sticky_ts if _stats_sticky_ts > 0 else float('inf')
        if _stats_sticky_cache and age <= sticky_ttl:
            metrics.update(_stats_sticky_cache)
            _stats_sticky_warn_count += 1
            logger.warning(
                "ramjetio: /stats fetch failed (err=%r), using sticky "
                "snapshot aged %.1fs (fallback #%d)",
                last_exc, age, _stats_sticky_warn_count,
            )
        else:
            # No usable sticky — report zeros but log loudly.
            _stats_sticky_warn_count += 1
            logger.warning(
                "ramjetio: /stats fetch failed (err=%r) and no fresh "
                "sticky snapshot (age=%.1fs, ttl=%.1fs); cache metrics "
                "will be zero this heartbeat (#%d)",
                last_exc, age, sticky_ttl, _stats_sticky_warn_count,
            )
    
    # System metrics (RAM, Disk)
    try:
        import psutil
        
        # RAM
        mem = psutil.virtual_memory()
        metrics['ram_total'] = mem.total
        metrics['ram_used'] = mem.used
        metrics['ram_free'] = mem.available
        
        # Disk (use cache path or root)
        cache_path = os.environ.get("RAMJET_CACHE_PATH", DEFAULT_STORAGE_PATH)
        try:
            disk = psutil.disk_usage(cache_path)
        except:
            disk = psutil.disk_usage("/")
        metrics['disk_total'] = disk.total
        metrics['disk_used'] = disk.used
        metrics['disk_free'] = disk.free
        
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Failed to get system metrics: {e}")
    
    # GPU metrics — use pynvml for system-wide visibility (sees all processes' memory)
    # torch.cuda.memory_reserved() only sees the current process, which underreports in DDP
    try:
        import pynvml
        pynvml.nvmlInit()
        gpu_count = pynvml.nvmlDeviceGetCount()
        metrics['gpu_count'] = gpu_count
        
        if gpu_count > 0:
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            metrics['gpu_name'] = pynvml.nvmlDeviceGetName(handle)
            
            total_mem = 0
            used_mem = 0
            for i in range(gpu_count):
                handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                total_mem += info.total
                used_mem += info.used
            
            metrics['gpu_memory_total'] = total_mem
            metrics['gpu_memory_used'] = used_mem
            metrics['gpu_memory_free'] = total_mem - used_mem
    except ImportError:
        # Fallback to torch if pynvml not available
        try:
            import torch
            if torch.cuda.is_available():
                gpu_count = torch.cuda.device_count()
                metrics['gpu_count'] = gpu_count
                if gpu_count > 0:
                    metrics['gpu_name'] = torch.cuda.get_device_name(0)
                    total_mem = 0
                    used_mem = 0
                    for i in range(gpu_count):
                        props = torch.cuda.get_device_properties(i)
                        total_mem += props.total_memory
                        try:
                            used_mem += torch.cuda.memory_reserved(i)
                        except:
                            pass
                    metrics['gpu_memory_total'] = total_mem
                    metrics['gpu_memory_used'] = used_mem
                    metrics['gpu_memory_free'] = total_mem - used_mem
        except ImportError:
            pass
    except Exception as e:
        logger.debug(f"Failed to get GPU metrics: {e}")
    
    # Training status
    training = _get_training_status()
    # A2: if other DDP ranks have written their own samples into
    # /tmp/ramjet_rank_N.json, merge them so the single heartbeat
    # carries cluster-wide throughput instead of just rank-0.
    training = _aggregate_rank_fanin(training)
    metrics['is_training'] = training.get('is_training', False)
    metrics['training_phase'] = training.get('phase', 'idle')
    metrics['current_epoch'] = training.get('current_epoch', 0)
    metrics['total_epochs'] = training.get('total_epochs', 0)
    metrics['current_step'] = training.get('current_step', 0)
    metrics['total_steps'] = training.get('total_steps', 0)
    metrics['epoch_progress'] = training.get('epoch_progress', 0.0)
    metrics['training_loss'] = training.get('loss', 0.0)
    metrics['training_task'] = training.get('task', '')
    metrics['training_started_at'] = training.get('started_at', 0)
    metrics['samples_per_second'] = training.get('samples_per_second', 0.0)
    metrics['ranks_reporting'] = training.get('ranks_reporting', 0)
    
    # DDP info from environment (set by torchrun/torch.distributed.launch)
    try:
        world_size = int(os.environ.get('WORLD_SIZE', '0'))
        rank = int(os.environ.get('RANK', '0'))
        local_rank = int(os.environ.get('LOCAL_RANK', '0'))
        metrics['ddp_world_size'] = world_size
        metrics['ddp_rank'] = rank
        metrics['ddp_local_rank'] = local_rank
    except (ValueError, TypeError):
        metrics['ddp_world_size'] = 0
        metrics['ddp_rank'] = 0
        metrics['ddp_local_rank'] = 0

    # F8: per-path cache-hit split (accumulated by _record_cache_path).
    metrics.update(_get_cache_path_stats())

    # F8: single-flight counters from the in-process cache server (only if
    # the SDK started one on this host via init()). Attribute access is
    # deliberately best-effort — an external / standalone CLI-started server
    # already reports its own metrics via its own heartbeat, so we just
    # surface zeros here when we don't own the server locally.
    try:
        srv = globals().get('_server_process')
        cs = getattr(srv, 'server', None) if srv is not None else None
        if cs is not None:
            metrics['singleflight_leaders'] = int(getattr(cs, '_inflight_leader_count', 0))
            metrics['singleflight_waiters'] = int(getattr(cs, '_inflight_waiter_count', 0))
            metrics['singleflight_wait_hits'] = int(getattr(cs, '_inflight_wait_hits', 0))
            metrics['singleflight_wait_timeouts'] = int(getattr(cs, '_inflight_wait_timeouts', 0))
        else:
            metrics.setdefault('singleflight_leaders', 0)
            metrics.setdefault('singleflight_waiters', 0)
            metrics.setdefault('singleflight_wait_hits', 0)
            metrics.setdefault('singleflight_wait_timeouts', 0)
    except Exception:
        pass

    return metrics


def get_cache() -> Optional[DistributedCache]:
    """Get the global cache instance."""
    if not _initialized:
        logger.warning("RAMJET not initialized. Call ramjetio.init() first.")
    return _global_cache


def get_data_source() -> Optional[Dict[str, Any]]:
    """
    Get data source configuration from dashboard.
    
    Returns:
        Dict with data source config (type, endpoint, credentials, etc.)
        or None if not configured.
    """
    return get_data_source_config()


# =============================================================================
# Training Status API
# =============================================================================

def set_training_status(
    is_training: bool = True,
    phase: str = 'training',
    current_epoch: int = 0,
    total_epochs: int = 0,
    current_step: int = -1,
    total_steps: int = -1,
    loss: Optional[float] = None,
    task: str = '',
    samples_per_second: float = 0.0,
) -> None:
    """
    Update training status reported to dashboard.
    
    Call this from your training loop to show progress in the dashboard.
    
    Args:
        is_training: True if training is active
        phase: 'caching', 'training', 'validating', or 'idle'
        current_epoch: Current epoch number (1-based)
        total_epochs: Total number of epochs
        current_step: Current step within epoch
        total_steps: Total steps per epoch (0 if unknown)
        loss: Current training loss
        task: Task description (e.g., "YOLO Training")
        samples_per_second: Training throughput
        
    Example:
        # At start of training
        ramjetio.set_training_status(
            is_training=True,
            phase='training',
            task='YOLO Object Detection',
            total_epochs=100
        )
        
        # In training loop
        for epoch in range(100):
            for step, batch in enumerate(dataloader):
                loss = train_step(batch)
                ramjetio.set_training_status(
                    current_epoch=epoch + 1,
                    current_step=step + 1,
                    total_steps=len(dataloader),
                    loss=loss.item()
                )
        
        # After training
        ramjetio.set_training_status(is_training=False, phase='idle')
    """
    global _training_status
    import time
    
    with _training_lock:
        # If starting training, record start time
        if is_training and not _training_status['is_training']:
            _training_status['started_at'] = int(time.time())
        elif not is_training:
            _training_status['started_at'] = 0
        
        # reset stale progress counters on phase transitions
        # (e.g. caching→training). Without this, non-main DDP ranks that
        # never receive update_step() callbacks carry forward the last
        # caching step count (e.g. 5315/5315) forever, which the dashboard
        # then displays as "100%". Preserve current_step/total_steps ONLY
        # inside the same phase; zero them when phase changes.
        prev_phase = _training_status.get('phase', '')
        if phase and phase != prev_phase:
            _training_status['current_step'] = 0
            _training_status['total_steps'] = 0
            _training_status['epoch_progress'] = 0.0
            # loss/samples_per_second also belong to the previous phase's
            # trailing batch — clear so the next phase starts clean.
            _training_status['loss'] = 0.0
            _training_status['samples_per_second'] = 0.0

        _training_status['is_training'] = is_training
        _training_status['phase'] = phase
        
        if current_epoch > 0:
            _training_status['current_epoch'] = current_epoch
        if total_epochs > 0:
            _training_status['total_epochs'] = total_epochs
        if current_step >= 0:
            _training_status['current_step'] = current_step
        if total_steps >= 0:
            _training_status['total_steps'] = total_steps
        if loss is not None:
            _training_status['loss'] = loss
        if task:
            _training_status['task'] = task
        if samples_per_second > 0:
            _training_status['samples_per_second'] = samples_per_second
        
        # Calculate epoch progress
        if _training_status['total_steps'] > 0:
            _training_status['epoch_progress'] = (
                _training_status['current_step'] / _training_status['total_steps']
            )
        elif _training_status['current_step'] > 0:
            _training_status['epoch_progress'] = 0.5  # Unknown, show 50%
        else:
            _training_status['epoch_progress'] = 0.0  # Reset stale value

        # A2: publish this rank's snapshot for fan-in aggregation.
        _write_rank_fanin_sample(_training_status)


def start_training(task: str = '', total_epochs: int = 0) -> None:
    """
    Mark training as started. Shorthand for set_training_status().
    
    Args:
        task: Task description (e.g., "ResNet Training")
        total_epochs: Total number of epochs planned
    """
    set_training_status(
        is_training=True,
        phase='training',
        task=task,
        total_epochs=total_epochs,
        current_epoch=1,
        current_step=0,
        total_steps=0,
    )


def end_training() -> None:
    """Mark training as completed. Keeps final metrics for dashboard display."""
    with _training_lock:
        _training_status['is_training'] = False
        _training_status['phase'] = 'completed'
        # Keep started_at, loss, epoch, task etc. so dashboard can show results
    # Wait briefly so the next heartbeat picks up 'completed' before shutdown
    import time
    time.sleep(4)


def set_caching_phase(current: int = 0, total: int = 0) -> None:
    """
    Mark that we're in caching/data loading phase.
    
    Args:
        current: Number of samples cached so far
        total: Total samples to cache
    """
    set_training_status(
        is_training=True,
        phase='caching',
        current_step=current,
        total_steps=total,
    )


def update_step(
    epoch: int,
    step: int,
    total_steps: int = -1,
    loss: Optional[float] = None,
    samples_per_second: float = 0.0,
) -> None:
    """
    Update training progress. Call this each training step.
    
    Args:
        epoch: Current epoch (1-based)
        step: Current step in epoch (1-based)
        total_steps: Total steps per epoch
        loss: Current loss value
        samples_per_second: Training throughput
    """
    set_training_status(
        is_training=True,
        phase='training',
        current_epoch=epoch,
        current_step=step,
        total_steps=total_steps,
        loss=loss,
        samples_per_second=samples_per_second,
    )


def _get_training_status() -> Dict[str, Any]:
    """Get current training status (thread-safe)."""
    with _training_lock:
        return _training_status.copy()


def log_metrics(
    loss: Optional[float] = None,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
    learning_rate: Optional[float] = None,
    throughput: Optional[float] = None,
    **kwargs
) -> None:
    """
    Log training metrics to dashboard.
    
    Args:
        loss: Training loss
        epoch: Current epoch
        step: Current step/batch
        learning_rate: Current learning rate
        throughput: Samples per second
        **kwargs: Additional metrics
    """
    # TODO: Implement metrics push to backend
    pass


def cleanup_ddp() -> None:
    """
    Destroy the current DDP process group and reset environment to single-process.
    
    Call this before frameworks that manage their own DDP (e.g. ultralytics)
    to avoid conflicts with torchrun's process group.
    
    Re-initializes a single-process group so frameworks that call
    dist.get_world_size() don't crash.
    """
    try:
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()
            logger.info("Destroyed DDP process group")
    except (ImportError, RuntimeError) as e:
        logger.debug(f"DDP cleanup (process group): {e}")

    # Reset DDP env vars to single-process values
    os.environ['RANK'] = '0'
    os.environ['LOCAL_RANK'] = '0'
    os.environ['WORLD_SIZE'] = '1'
    os.environ['LOCAL_WORLD_SIZE'] = '1'
    os.environ['MASTER_ADDR'] = '127.0.0.1'
    os.environ['MASTER_PORT'] = str(_find_free_port())
    
    # Clear torchrun-specific vars
    for var in ['GROUP_RANK', 'TORCHELASTIC_RESTART_COUNT',
                'TORCHELASTIC_MAX_RESTARTS', 'TORCHELASTIC_RUN_ID']:
        os.environ.pop(var, None)
    
    # Re-init a single-process group so dist.get_world_size() works
    try:
        import torch.distributed as dist
        if not dist.is_initialized():
            dist.init_process_group(backend='gloo', world_size=1, rank=0)
            logger.info("Re-initialized single-process group for framework compatibility")
    except Exception as e:
        logger.debug(f"Could not re-init process group: {e}")
    
    logger.info("Reset DDP environment to single-process mode")


def _find_free_port() -> int:
    """Find a free TCP port."""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]


def train(model, data: str = None, epochs: int = None, **kwargs) -> object:
    """
    High-level training wrapper with automatic progress reporting.
    
    Auto-detects the framework, attaches progress callbacks, and starts training.
    Preserves the existing DDP process group so all ranks train together.
    
    Args:
        model: Model instance (e.g. ultralytics.YOLO)
        data: Path to data config (e.g. data.yaml for YOLO)
        epochs: Number of training epochs
        **kwargs: Additional args passed to the framework's train method
        
    Returns:
        Training results from the framework
        
    Example:
        import ramjetio
        from ultralytics import YOLO
        
        ramjetio.init()
        dataset = ramjetio.UniversalDataset(split='train', format='yolo')
        data_yaml = dataset.export_local('/tmp/ramjet_data')
        
        model = YOLO('yolov8n.pt')
        ramjetio.train(model, data=data_yaml, epochs=5, imgsz=640)
        ramjetio.shutdown()
    """
    from ramjetio.integrations import attach, detect_frameworks

    # Detect framework and attach hooks (only rank 0 reports to dashboard)
    attached = attach(model)
    if not attached:
        logger.warning("Could not auto-attach progress hooks. Training will proceed without dashboard updates.")

    try:
        from ultralytics import YOLO
        is_ultralytics = isinstance(model, YOLO)
    except ImportError:
        is_ultralytics = False

    if is_ultralytics:
        import torch
        # Use LOCAL_RANK for device assignment — each rank trains on its own GPU
        local_rank = int(os.environ.get('LOCAL_RANK', 0))
        gpu_count = torch.cuda.device_count() if torch.cuda.is_available() else 0
        
        if gpu_count > 0:
            device = local_rank
        else:
            device = 'cpu'
        
        logger.info(f"Training on device={device} (LOCAL_RANK={local_rank}, gpu_count={gpu_count})")

        # Build ultralytics train kwargs
        train_kwargs = {
            'data': data,
            'device': device,
        }
        if epochs is not None:
            train_kwargs['epochs'] = epochs

        # Sensible defaults
        train_kwargs.setdefault('exist_ok', True)
        train_kwargs.setdefault('project', '/tmp/ramjet_runs')
        train_kwargs.setdefault('name', 'yolo_train')

        train_kwargs.update(kwargs)

        # Explicitly set training phase before model.train() in case callbacks don't fire
        set_training_status(is_training=True, phase='training', total_epochs=epochs or 0, current_epoch=1)

        # Ultralytics unconditionally calls sampler.set_epoch() in _do_train().
        # When DDP is initialized externally (not via torchrun), Ultralytics may use
        # RandomSampler which lacks set_epoch, causing AttributeError.
        from torch.utils.data import RandomSampler
        if not hasattr(RandomSampler, 'set_epoch'):
            RandomSampler.set_epoch = lambda self, epoch: None

        results = model.train(**train_kwargs)
        return results
    else:
        # Generic fallback — just call train with what we have
        train_kwargs = {}
        if data is not None:
            train_kwargs['data'] = data
        if epochs is not None:
            train_kwargs['epochs'] = epochs
        train_kwargs.update(kwargs)
        return model.train(**train_kwargs)


def shutdown() -> None:
    """Shutdown RAMJET and cleanup resources.

    F-Shut1: orderly teardown sequence:
      1. Stop background threads (node refresh, topology watcher) — flag flip
         then short join so they don't keep poking the backend or the file.
      2. Stop ``BackendClient`` — sends a final heartbeat and ``UnregisterNode``
         so the dashboard doesn't show a ghost node for ~60s.
      3. SIGTERM the cache-server subprocess and wait up to
         ``RAMJET_SHUTDOWN_GRACE_S`` (default 10s) for it to flush, unregister,
         and exit cleanly. SIGKILL only if it overruns.
      4. Best-effort delete the published topology file (rank 0 only) so the
         next interpreter doesn't pick up stale data.
    Idempotent: safe to call multiple times and from atexit.
    """
    global _initialized, _global_cache, _server_process, _backend_client
    global _refresh_running, _topology_watch_running, _shutdown_in_progress
    global _node_refresh_thread, _topology_watch_thread

    if _shutdown_in_progress:
        return
    _shutdown_in_progress = True

    # 1. Flag background loops to exit and give them a brief chance to notice.
    _refresh_running = False
    _topology_watch_running = False
    for t in (_node_refresh_thread, _topology_watch_thread):
        if t is not None and t.is_alive():
            try:
                t.join(timeout=2.0)
            except RuntimeError:
                # Thread joining itself — possible if shutdown is invoked
                # from inside one of the loops. Skip.
                pass

    # 2. Backend client: best-effort UnregisterNode.
    if _backend_client is not None:
        try:
            _backend_client.stop()
        except Exception as e:
            logger.warning("Backend client stop failed: %s: %s", type(e).__name__, e)
        _backend_client = None

    # 3. Cache server subprocess: graceful SIGTERM with bounded wait.
    if _server_process is not None:
        proc = _server_process
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=_SHUTDOWN_GRACE_S)
                    logger.info(
                        "Cache server subprocess exited cleanly (rc=%s)",
                        proc.returncode,
                    )
                except Exception as e:
                    # ``subprocess.TimeoutExpired`` is the expected case;
                    # broader except guards weird IO errors during teardown.
                    logger.warning(
                        "Cache server did not exit within %.1fs (%s); sending SIGKILL",
                        _SHUTDOWN_GRACE_S, type(e).__name__,
                    )
                    try:
                        proc.kill()
                        proc.wait(timeout=2.0)
                    except Exception as kill_err:
                        logger.warning(
                            "SIGKILL on cache server failed: %s: %s",
                            type(kill_err).__name__, kill_err,
                        )
        finally:
            _server_process = None

    # 4. Drop the topology file so a fresh interpreter doesn't replay our
    #    last-known ring. Only the publishing rank should do this — non-zero
    #    LOCAL_RANK never wrote to the file.
    try:
        local_rank, _, _, is_main_local, _ = _get_distributed_info()
        if is_main_local and os.path.exists(_TOPOLOGY_FILE):
            os.unlink(_TOPOLOGY_FILE)
    except OSError as e:
        logger.debug("Topology file cleanup skipped: %s", e)
    except Exception as e:
        logger.debug("Topology file cleanup error: %s: %s", type(e).__name__, e)

    _global_cache = None
    _initialized = False
    _shutdown_in_progress = False
    logger.info("RAMJET shutdown complete")


def _atexit_shutdown() -> None:
    """Atexit hook — never raises so interpreter teardown is unaffected."""
    try:
        shutdown()
    except Exception as e:
        # ``logger`` may be partially torn down at interpreter exit, so use
        # a stderr fallback for absolute robustness.
        try:
            logger.warning("atexit shutdown failed: %s: %s", type(e).__name__, e)
        except Exception:
            import sys
            print(f"ramjetio atexit shutdown failed: {e}", file=sys.stderr)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Main API
    "init",
    "shutdown",
    "get_cache",
    "get_data_source",
    "log_metrics",
    "agree_on_nodes",
    "set_cache_namespace",
    "freeze_ring",
    "unfreeze_ring",
    # Training status
    "set_training_status",
    "start_training",
    "end_training",
    "set_caching_phase",
    "update_step",
    # High-level API
    "train",
    "cleanup_ddp",
    # Core
    "DistributedCache",
    "ConsistentHash", 
    "CachedDataset",
    "UniversalDataset",
    # Config
    "RAMJET_BACKEND_URL",
    "get_api_key",
    "get_backend_host",
    "get_backend_port",
    "get_backend_url",
    "get_backend_use_ssl",
    "is_configured",
    # Backend client
    "BackendClient",
    "get_data_source_config",
    "get_cluster_nodes",
    "get_backend_client",
    "init_backend",
    # Data source types
    "DATA_SOURCE_TYPE_NONE",
    "DATA_SOURCE_TYPE_S3",
    "DATA_SOURCE_TYPE_LOCAL",
    "DATA_SOURCE_TYPE_HTTP",
]


# Training helpers (optional - requires torch)
try:
    from ramjetio.helpers import (
        load_config,
        start_cache_servers,
        setup_distributed,
        create_distributed_cache,
        create_cached_dataloader,
        cleanup_distributed,
    )
    __all__.extend([
        "load_config",
        "start_cache_servers",
        "setup_distributed",
        "create_distributed_cache",
        "create_cached_dataloader",
        "cleanup_distributed",
    ])
except ImportError:
    pass
