"""
RAMJET Configuration Constants

This module contains hardcoded configuration for connecting to RAMJET backend.
Users only need to provide their API key - the backend URL is fixed.
"""

from __future__ import annotations

import os

# ============================================================================
# BACKEND CONFIGURATION
# ============================================================================

# Production backend URL - this is where ramjet-server sends metrics and heartbeats
# Format: host:port (gRPC, not HTTP)
#
# NOTE: these module-level constants snapshot the env at *import* time. They
# are kept for backward compatibility with users who imported them directly,
# but the production code path (``backend_client.py``) now reads the env
# *every time* a channel is created via ``get_backend_url()`` /
# ``get_backend_use_ssl()``. That lets self-hosted operators set
# ``RAMJET_BACKEND_HOST`` *after* ``import ramjetio`` (e.g. from a CLI flag
# parsed in ``main()``) without a fork-or-reload dance.
RAMJET_BACKEND_HOST = os.environ.get("RAMJET_BACKEND_HOST", "grpc.ramjet.io")
RAMJET_BACKEND_PORT = int(os.environ.get("RAMJET_BACKEND_PORT", "443"))
RAMJET_BACKEND_URL = f"{RAMJET_BACKEND_HOST}:{RAMJET_BACKEND_PORT}"

# Use TLS for production (AWS ALB terminates TLS)
RAMJET_BACKEND_USE_SSL = os.environ.get("RAMJET_BACKEND_USE_SSL", "true").lower() == "true"


# ---------------------------------------------------------------------------
# Live-read accessors (Phase Q.3)
# ---------------------------------------------------------------------------
# These re-read the environment on every call so that a self-hosted user can
# point ramjetio at their own coordinator by exporting RAMJET_BACKEND_HOST at
# any point before the first heartbeat fires — including from inside a
# library that wraps ramjetio and parses its own --coordinator-host flag.

def get_backend_host() -> str:
    """Return the currently-configured backend host (live env read)."""
    return os.environ.get("RAMJET_BACKEND_HOST", "grpc.ramjet.io")


def get_backend_port() -> int:
    """Return the currently-configured backend port (live env read)."""
    return int(os.environ.get("RAMJET_BACKEND_PORT", "443"))


def get_backend_url() -> str:
    """Return ``host:port`` for the gRPC backend, reading env at call time."""
    return f"{get_backend_host()}:{get_backend_port()}"


def get_backend_use_ssl() -> bool:
    """Return whether to use TLS for the backend channel (live env read)."""
    return os.environ.get("RAMJET_BACKEND_USE_SSL", "true").lower() == "true"

# ============================================================================
# USER CONFIGURATION (from environment)
# ============================================================================

def get_api_key() -> str | None:
    """
    Get RAMJET API key from environment variable.
    
    Users should set this via:
        export RAMJET_API_KEY="ramjet_xxxxx..."
    
    Returns:
        API key string or None if not configured
    """
    return os.environ.get("RAMJET_API_KEY")


def is_configured() -> bool:
    """Check if RAMJET is properly configured with an API key."""
    api_key = get_api_key()
    # Accept any non-empty API key
    return api_key is not None and len(api_key) > 10


# ============================================================================
# CACHE SERVER DEFAULTS
# ============================================================================

DEFAULT_CACHE_PORT = 9000
DEFAULT_CACHE_CAPACITY = "100GB"
DEFAULT_STORAGE_PATH = "/tmp/ramjet_cache"

# Heartbeat interval (seconds) - more frequent for better real-time updates
HEARTBEAT_INTERVAL = 3.0

# Metrics push interval (seconds)  
METRICS_PUSH_INTERVAL = 3.0

# Reconnect settings
RECONNECT_INTERVAL = 30.0  # Seconds between reconnect attempts
MAX_RECONNECT_ATTEMPTS = 0  # 0 = unlimited retries
