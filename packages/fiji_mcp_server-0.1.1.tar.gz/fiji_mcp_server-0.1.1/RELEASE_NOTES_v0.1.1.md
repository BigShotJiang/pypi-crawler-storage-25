# Release v0.1.1

**PyPI:** [`fiji-mcp-server` 0.1.1](https://pypi.org/project/fiji-mcp-server/0.1.1/) — `pip install fiji-mcp-server`

## Highlights

- Production-oriented **sdist + wheel** builds verified in CI.
- **Automated PyPI upload** when a **GitHub Release** is published (Trusted Publishing OIDC; see [`RELEASING.md`](RELEASING.md)).
- **`py.typed`** marker for type checkers; clearer package metadata and README structure.

## Upgrade

```bash
pip install -U fiji-mcp-server
```

Full history: [`CHANGELOG.md`](CHANGELOG.md).
