"""CLI helpers for Fiji MCP."""
