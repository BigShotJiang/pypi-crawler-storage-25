"""Bundled static data (macro templates, etc.)."""
