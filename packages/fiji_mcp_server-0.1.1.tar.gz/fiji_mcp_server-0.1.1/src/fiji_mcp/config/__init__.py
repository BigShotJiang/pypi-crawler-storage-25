"""Configuration helpers for Fiji MCP."""
