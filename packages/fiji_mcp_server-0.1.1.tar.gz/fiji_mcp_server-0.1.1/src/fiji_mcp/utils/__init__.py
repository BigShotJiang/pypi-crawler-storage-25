"""Shared utility modules for Fiji MCP."""
