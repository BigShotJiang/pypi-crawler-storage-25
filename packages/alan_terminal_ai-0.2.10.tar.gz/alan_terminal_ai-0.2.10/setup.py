"""
Setup script for alan-terminal-ai.
Ensures all packages are properly discovered and installed.
"""

from setuptools import find_packages, setup

setup(
    packages=find_packages(
        include=["alanterminalai", "alanterminalai.*"],
        exclude=["alanterminalai.tests", "alanterminalai.tests.*"],
    ),
)
