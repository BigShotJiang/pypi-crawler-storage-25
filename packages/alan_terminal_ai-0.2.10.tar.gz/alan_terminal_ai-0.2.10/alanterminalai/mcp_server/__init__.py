"""
MCP (Model Context Protocol) Server Integration

Expose terminal tools as MCP,compatible with Claude Desktop & any MCP client

Exposed Tools:
- run_command: Execute shell commands
- get_file_contents: Read files
- write_file: Write files
- list_directory: List directory contents
- search_files: Find files by pattern
- grep_files: Search text in files
"""

import subprocess
from pathlib import Path
from typing import Any, Dict, List


class MCPServer:
    """MCP Server for exposing terminal tools"""

    def __init__(self, os_info: Dict, max_output: int = 10000):
        """
        Initialize MCP server

        Args:
            os_info: System information (name, type, etc.)
            max_output: Max output size in characters
        """
        self.os_info = os_info
        self.max_output = max_output
        self.tools = self._define_tools()

    def _define_tools(self) -> Dict[str, Dict[str, Any]]:
        """Define available MCP tools"""
        return {
            "run_command": {
                "name": "run_command",
                "description": "Execute a shell command",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Shell command to execute",
                        },
                        "timeout": {
                            "type": "integer",
                            "description": "Timeout in seconds (default: 30)",
                            "default": 30,
                        },
                    },
                    "required": ["command"],
                },
            },
            "get_file_contents": {
                "name": "get_file_contents",
                "description": "Read file contents",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File path to read",
                        },
                    },
                    "required": ["path"],
                },
            },
            "write_file": {
                "name": "write_file",
                "description": "Write to file",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File path to write",
                        },
                        "contents": {
                            "type": "string",
                            "description": "File contents",
                        },
                    },
                    "required": ["path", "contents"],
                },
            },
            "list_directory": {
                "name": "list_directory",
                "description": "List directory contents",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Directory path",
                            "default": ".",
                        },
                    },
                },
            },
            "search_files": {
                "name": "search_files",
                "description": "Find files by pattern",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "File name pattern (glob)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Search path (default: .)",
                            "default": ".",
                        },
                    },
                    "required": ["pattern"],
                },
            },
            "grep_files": {
                "name": "grep_files",
                "description": "Search text in files",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Text pattern to search",
                        },
                        "path": {
                            "type": "string",
                            "description": "Search path (default: .)",
                            "default": ".",
                        },
                        "regex": {
                            "type": "boolean",
                            "description": "Use regex pattern (default: false)",
                            "default": False,
                        },
                    },
                    "required": ["pattern"],
                },
            },
        }

    def list_tools(self) -> List[Dict[str, Any]]:
        """List available tools"""
        return list(self.tools.values())

    def execute_tool(
        self, tool_name: str, arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a tool

        Args:
            tool_name: Name of tool to execute
            arguments: Tool arguments

        Returns:
            Result dict with 'success', 'output', 'error'
        """
        try:
            if tool_name == "run_command":
                return self._run_command(
                    arguments.get("command", ""), arguments.get("timeout", 30)
                )
            elif tool_name == "get_file_contents":
                return self._get_file_contents(arguments.get("path", ""))
            elif tool_name == "write_file":
                return self._write_file(
                    arguments.get("path", ""), arguments.get("contents", "")
                )
            elif tool_name == "list_directory":
                return self._list_directory(arguments.get("path", "."))
            elif tool_name == "search_files":
                return self._search_files(
                    arguments.get("pattern", ""), arguments.get("path", ".")
                )
            elif tool_name == "grep_files":
                return self._grep_files(
                    arguments.get("pattern", ""),
                    arguments.get("path", "."),
                    arguments.get("regex", False),
                )
            else:
                return {
                    "success": False,
                    "error": f"Unknown tool: {tool_name}",
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _run_command(self, command: str, timeout: int) -> Dict[str, Any]:
        """Execute shell command"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            output = result.stdout + result.stderr
            if len(output) > self.max_output:
                output = output[: self.max_output] + "\n... (truncated)"

            return {
                "success": result.returncode == 0,
                "output": output,
                "exit_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"Command timeout after {timeout}s",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _get_file_contents(self, path: str) -> Dict[str, Any]:
        """Read file contents"""
        try:
            file_path = Path(path).resolve()

            # Safety check
            if not file_path.exists():
                return {
                    "success": False,
                    "error": f"File not found: {path}",
                }

            if not file_path.is_file():
                return {
                    "success": False,
                    "error": f"Not a file: {path}",
                }

            with open(file_path, "r") as f:
                contents = f.read()

            if len(contents) > self.max_output:
                contents = contents[: self.max_output] + "\n... (truncated)"

            return {
                "success": True,
                "contents": contents,
                "size": len(contents),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _write_file(self, path: str, contents: str) -> Dict[str, Any]:
        """Write file contents"""
        try:
            file_path = Path(path).resolve()

            # Safety: block writing to system-critical directories
            blocked_prefixes = [
                "/etc",
                "/usr",
                "/bin",
                "/sbin",
                "/boot",
                "/sys",
                "/proc",
                "/dev",
                "/private/etc",
            ]
            resolved = str(file_path)
            for prefix in blocked_prefixes:
                if resolved.startswith(prefix):
                    return {
                        "success": False,
                        "error": f"Writing to {prefix} is not allowed for safety",
                    }

            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, "w") as f:
                f.write(contents)

            return {
                "success": True,
                "message": f"Wrote {len(contents)} bytes to {path}",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _list_directory(self, path: str) -> Dict[str, Any]:
        """List directory contents"""
        try:
            dir_path = Path(path).resolve()

            if not dir_path.exists():
                return {
                    "success": False,
                    "error": f"Directory not found: {path}",
                }

            if not dir_path.is_dir():
                return {
                    "success": False,
                    "error": f"Not a directory: {path}",
                }

            entries = []
            for item in dir_path.iterdir():
                entries.append(
                    {
                        "name": item.name,
                        "type": "dir" if item.is_dir() else "file",
                        "size": item.stat().st_size if item.is_file() else None,
                    }
                )

            return {
                "success": True,
                "entries": entries,
                "count": len(entries),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _search_files(self, pattern: str, path: str) -> Dict[str, Any]:
        """Find files by pattern"""
        try:
            search_path = Path(path).resolve()
            matches = []

            for file_path in search_path.rglob(pattern):
                if len(matches) >= 100:  # Limit results
                    break
                matches.append(str(file_path.relative_to(search_path)))

            return {
                "success": True,
                "matches": matches,
                "count": len(matches),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def _grep_files(
        self, pattern: str, path: str, regex: bool
    ) -> Dict[str, Any]:
        """Search text in files"""
        try:
            search_path = Path(path).resolve()
            args = ["grep", "-r"]
            if regex:
                args.append("-E")
            else:
                args.append("-F")
            args.extend(["--", pattern, str(search_path)])

            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=10,
            )

            output = result.stdout
            if len(output) > self.max_output:
                output = output[: self.max_output] + "\n... (truncated)"

            return {
                "success": True,
                "results": output,
                "match_count": output.count("\n"),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def get_server_info(self) -> Dict[str, Any]:
        """Get server information"""
        return {
            "name": "Alan Terminal AI MCP Server",
            "version": "0.2.0",
            "system": self.os_info,
            "tools_count": len(self.tools),
        }
