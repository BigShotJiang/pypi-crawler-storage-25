"""
Special Character Handling Module

Features:
- Unix/Windows shell escaping
- Unicode character handling
- Emoji support
- Multiline input handling
- Command normalization
- Input validation
"""

import re
import shlex


class SpecialCharacterHandler:
    """Handle special characters, escaping, and shell compatibility"""

    # Unicode normalization patterns
    UNICODE_PATTERNS = {
        "smart_quotes": (
            (""", "'"), (""", "'"),
            ('"', '"'),
            ('"', '"'),
        ),
        "dashes": (
            ("–", "-"),
            ("—", "-"),
            ("−", "-"),
            ("‐", "-"),
        ),
        "ellipsis": (("…", "..."),),
    }

    # Dangerous characters that need escaping
    SHELL_SPECIAL_CHARS_UNIX = r'[;&|`$()[\]{}!*?<>"\'\\#]'
    SHELL_SPECIAL_CHARS_WINDOWS = r'[&|()^<>"]'

    @staticmethod
    def escape_for_shell(text: str, os_type: str = "unix") -> str:
        """
        Escape text for shell execution

        Args:
            text: Text to escape
            os_type: 'unix' or 'windows'

        Returns:
            Escaped text safe for shell
        """
        if os_type.lower() == "windows":
            # Windows escaping
            if " " in text or '"' in text:
                # Use quotes - escape internal quotes by doubling them
                escaped_text = text.replace('"', '""')
                return '"' + escaped_text + '"'
            return text
        else:
            # Unix/Linux escaping
            # Try simple quoting first
            try:
                return shlex.quote(text)
            except:
                # Fallback: escape special characters
                escaped = re.sub(r'([;&|`$()[\]{}!*?<>"\'\\#])', r"\\\1", text)
                return escaped

    @staticmethod
    def escape_for_regex(text: str) -> str:
        """Escape text for use in regular expressions"""
        return re.escape(text)

    @staticmethod
    def normalize_command(command: str) -> str:
        """
        Normalize command by fixing common issues

        Args:
            command: Raw command string

        Returns:
            Normalized command
        """
        # Remove leading/trailing whitespace
        command = command.strip()

        # Fix smart quotes to regular quotes
        for smart_q, normal_q in [
            (""", "'"), (""", "'"),
            ('"', '"'),
            ('"', '"'),
        ]:
            command = command.replace(smart_q, normal_q)

        # Fix dashes
        command = command.replace("–", "-").replace("—", "-")
        command = command.replace("−", "-").replace("‐", "-")

        # Handle ellipsis
        command = command.replace("…", "...")

        # Normalize whitespace (multiple spaces to single)
        command = re.sub(r"\s+", " ", command)

        return command

    @staticmethod
    def handle_multiline(text: str, join_char: str = " ") -> str:
        """
        Handle multiline input

        Args:
            text: Multiline text
            join_char: Character to join lines with

        Returns:
            Single-line text
        """
        lines = text.strip().split("\n")
        lines = [line.strip() for line in lines if line.strip()]
        return join_char.join(lines)

    @staticmethod
    def detect_encoding(text: str) -> str:
        """
        Detect text encoding

        Returns:
            'utf-8', 'ascii', 'mixed', or 'unknown'
        """
        try:
            text.encode("ascii")
            return "ascii"
        except UnicodeEncodeError:
            try:
                text.encode("utf-8")
                return "utf-8"
            except UnicodeEncodeError:
                return "unknown"

    @staticmethod
    def is_valid_command(command: str) -> bool:
        """
        Validate command syntax

        Args:
            command: Command to validate

        Returns:
            True if command appears valid
        """
        if not command or not isinstance(command, str):
            return False

        # Basic validation
        if len(command) > 10000:
            return False

        # Check for null bytes
        if "\x00" in command:
            return False

        # Check basic shell syntax (quotes matching)
        single_quotes = command.count("'") % 2
        double_quotes = command.count('"') % 2

        if single_quotes != 0 or double_quotes != 0:
            return False

        return True

    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """
        Sanitize filename by removing/replacing unsafe characters

        Args:
            filename: Original filename

        Returns:
            Safe filename
        """
        # Remove special characters
        safe = re.sub(r'[<>:"/\\|?*]', "", filename)
        # Replace spaces with underscores
        safe = safe.replace(" ", "_")
        # Remove multiple underscores
        safe = re.sub(r"_+", "_", safe)
        # Remove leading/trailing dots
        safe = safe.strip(".")

        return safe or "unnamed"

    @staticmethod
    def extract_quoted_strings(text: str) -> list:
        """
        Extract all quoted strings from text

        Returns:
            List of quoted string contents (without quotes)
        """
        single_quoted = re.findall(r"'([^']*)'", text)
        double_quoted = re.findall(r'"([^"]*)"', text)
        return single_quoted + double_quoted

    @staticmethod
    def detect_injection_attempt(text: str) -> bool:
        """
        Detect potential command injection attempts

        Args:
            text: Text to check

        Returns:
            True if injection detected
        """
        injection_patterns = [
            r";\s*(rm|dd|mkfs|chmod|chown|cat /etc)",
            r"\|\s*(rm|dd|mkfs)",
            r"&&\s*(rm|dd|mkfs)",
            r"`(rm|dd|mkfs)",
            r"\$(rm|dd|mkfs)",
            r"\$\((rm|dd|mkfs)",
            r">\s*/dev/sda",
            r"<\s*/dev/urandom",
        ]

        for pattern in injection_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True

        return False
