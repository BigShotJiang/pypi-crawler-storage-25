"""
Session History Module

Track command history, session management, and session replay.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class SessionManager:
    """Manage session history and command tracking"""

    def __init__(self, storage_dir: Optional[str] = None):
        """
        Initialize session manager

        Args:
            storage_dir: Directory for session storage (default: ~/.alan/history/)
        """
        if storage_dir is None:
            storage_dir = str(Path.home() / ".alan" / "history")

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.current_session = None
        self.commands = []
        self.session_metadata = {}

    def start_session(self, session_name: Optional[str] = None) -> str:
        """
        Start a new session

        Args:
            session_name: Optional custom name

        Returns:
            Session ID
        """
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        if session_name:
            session_id = f"{session_name}_{session_id}"

        self.current_session = session_id
        self.commands = []
        self.session_metadata = {
            "session_id": session_id,
            "started": datetime.now().isoformat(),
            "name": session_name,
            "command_count": 0,
        }

        return session_id

    def add_command(
        self,
        command: str,
        output: str = "",
        exit_code: int = 0,
        duration: float = 0.0,
    ) -> None:
        """
        Add command to current session

        Args:
            command: Command executed
            output: Command output
            exit_code: Exit/return code
            duration: Execution time
        """
        if not self.current_session:
            self.start_session()

        entry = {
            "command": command,
            "output": output,
            "exit_code": exit_code,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
            "success": exit_code == 0,
        }

        self.commands.append(entry)
        self.session_metadata["command_count"] = len(self.commands)

    def end_session(self) -> bool:
        """Save and close current session"""
        if not self.current_session:
            return False

        # Save to disk
        session_file = self.storage_dir / f"{self.current_session}.json"

        try:
            data = {
                "metadata": self.session_metadata,
                "commands": self.commands,
            }

            self.session_metadata["ended"] = datetime.now().isoformat()

            with open(session_file, "w") as f:
                json.dump(data, f, indent=2)

            return True
        except IOError:
            return False

    def list_sessions(self, limit: int = 20) -> List[Dict[str, Any]]:
        """List recent sessions"""
        sessions = []

        # Find all session files
        session_files = sorted(
            self.storage_dir.glob("*.json"),
            reverse=True,
            key=lambda f: f.stat().st_mtime,
        )

        for session_file in session_files[:limit]:
            try:
                with open(session_file, "r") as f:
                    data = json.load(f)
                    sessions.append(data.get("metadata", {}))
            except (json.JSONDecodeError, IOError):
                continue

        return sessions

    def load_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Load session from disk"""
        session_file = self.storage_dir / f"{session_id}.json"

        if not session_file.exists():
            return None

        try:
            with open(session_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    def get_command_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent commands from all sessions"""
        all_commands = []

        # Get from all sessions
        for session_file in self.storage_dir.glob("*.json"):
            try:
                with open(session_file, "r") as f:
                    data = json.load(f)
                    all_commands.extend(data.get("commands", []))
            except (json.JSONDecodeError, IOError):
                continue

        # Sort by timestamp and return latest
        all_commands.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        return all_commands[:limit]

    def search_commands(self, query: str) -> List[Dict[str, Any]]:
        """Search commands by pattern"""
        results = []

        for cmd in self.get_command_history(limit=1000):
            if query.lower() in cmd.get("command", "").lower():
                results.append(cmd)

        return results

    def get_session_stats(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a session"""
        session = self.load_session(session_id)
        if not session:
            return None

        commands = session.get("commands", [])

        if not commands:
            return {
                "session_id": session_id,
                "total_commands": 0,
            }

        successful = sum(1 for c in commands if c.get("success", False))
        failed = len(commands) - successful
        total_duration = sum(c.get("duration", 0) for c in commands)

        return {
            "session_id": session_id,
            "started": session.get("metadata", {}).get("started"),
            "ended": session.get("metadata", {}).get("ended"),
            "total_commands": len(commands),
            "successful": successful,
            "failed": failed,
            "total_duration": total_duration,
            "average_duration": (
                total_duration / len(commands) if commands else 0
            ),
        }

    def replay_session(
        self, session_id: str, executor=None
    ) -> Optional[Dict[str, Any]]:
        """
        Replay a saved session

        Args:
            session_id: Session to replay
            executor: Optional AgenticExecutor to use for replay

        Returns:
            Results of replay
        """
        session = self.load_session(session_id)
        if not session:
            return None

        commands = session.get("commands", [])
        results = {
            "session_id": session_id,
            "total_commands": len(commands),
            "executed": 0,
            "successful": 0,
            "failed": 0,
            "commands": [],
        }

        for cmd_entry in commands:
            command = cmd_entry.get("command", "")

            if executor:
                # Execute with executor
                success, output, error = executor.execute(
                    command, auto_confirm=True, show_output=False
                )
                results["executed"] += 1
                if success:
                    results["successful"] += 1
                else:
                    results["failed"] += 1
            else:
                # Just record as replayed
                results["executed"] += 1
                if cmd_entry.get("success", False):
                    results["successful"] += 1
                else:
                    results["failed"] += 1

            results["commands"].append(
                {
                    "command": command,
                    "original_output": cmd_entry.get("output", "")[:100],
                }
            )

        return results

    def clear_old_sessions(self, days: int = 30) -> int:
        """Remove sessions older than N days"""
        import time

        cutoff_time = time.time() - (days * 24 * 60 * 60)
        deleted = 0

        for session_file in self.storage_dir.glob("*.json"):
            if session_file.stat().st_mtime < cutoff_time:
                try:
                    session_file.unlink()
                    deleted += 1
                except OSError:
                    pass

        return deleted

    def export_session(
        self, session_id: str, format: str = "json"
    ) -> Optional[str]:
        """Export session in specified format"""
        session = self.load_session(session_id)
        if not session:
            return None

        if format == "json":
            return json.dumps(session, indent=2)

        elif format == "markdown":
            lines = [
                f"# Session: {session_id}",
                f"Started: {session.get('metadata', {}).get('started')}",
                "",
                "## Commands",
                "",
            ]

            for cmd_entry in session.get("commands", []):
                lines.append(f"### {cmd_entry.get('command')}")
                lines.append(f"Exit Code: {cmd_entry.get('exit_code')}")
                output = cmd_entry.get("output", "")[:500]
                if output:
                    lines.append(f"```\n{output}\n```")
                lines.append("")

            return "\n".join(lines)

        elif format == "text":
            lines = [
                f"Session: {session_id}",
                f"Started: {session.get('metadata', {}).get('started')}",
                "",
                "Commands:",
                "",
            ]

            for cmd_entry in session.get("commands", []):
                lines.append(f"$ {cmd_entry.get('command')}")
                if cmd_entry.get("output"):
                    lines.append(cmd_entry.get("output")[:200])
                lines.append("")

            return "\n".join(lines)

        return None
