"""
Error Explainer Module

Explain error messages and stack traces in human-readable format
using LLM and domain knowledge.
"""

from datetime import datetime
from typing import Dict, List, Optional


class ErrorExplainer:
    """Explain and analyze error messages"""

    def __init__(self, llm_manager=None):
        """
        Initialize error explainer

        Args:
            llm_manager: MultiLLMManager instance for explanations
        """
        self.llm_manager = llm_manager
        self.error_database = self._load_error_database()
        self.error_history = []

    def _load_error_database(self) -> Dict[str, Dict]:
        """Load common error explanations"""
        return {
            "FileNotFoundError": {
                "category": "File System",
                "suggestion": "Check if the file path exists and is spelled correctly",
                "common_causes": [
                    "Path does not exist",
                    "Typo in filename",
                    "Wrong working directory",
                ],
            },
            "PermissionError": {
                "category": "Access Control",
                "suggestion": "Check file permissions or try running with elevated privileges",
                "common_causes": [
                    "Insufficient permissions",
                    "Read-only file system",
                    "Protected system file",
                ],
            },
            "KeyError": {
                "category": "Data Access",
                "suggestion": "Check that dictionary key exists before accessing",
                "common_causes": [
                    "Key does not exist in dict",
                    "Case sensitivity issue",
                    "Typo in key name",
                ],
            },
            "IndexError": {
                "category": "Data Access",
                "suggestion": "Ensure index is within valid range",
                "common_causes": [
                    "Index out of range",
                    "Empty sequence",
                    "Off-by-one error",
                ],
            },
            "ValueError": {
                "category": "Data Type",
                "suggestion": "Verify the value type matches expected format",
                "common_causes": [
                    "Invalid value for operation",
                    "Type conversion failure",
                    "Format mismatch",
                ],
            },
            "TypeError": {
                "category": "Data Type",
                "suggestion": "Check that variable types are compatible",
                "common_causes": [
                    "Type mismatch",
                    "Unsupported operation",
                    "Wrong argument type",
                ],
            },
            "ImportError": {
                "category": "Module",
                "suggestion": "Ensure module is installed and in Python path",
                "common_causes": [
                    "Module not installed",
                    "Wrong module name",
                    "Python path issue",
                ],
            },
            "ModuleNotFoundError": {
                "category": "Module",
                "suggestion": "Install the missing module with pip",
                "common_causes": [
                    "Module not installed",
                    "Virtual environment not activated",
                ],
            },
            "ConnectionError": {
                "category": "Network",
                "suggestion": "Check network connectivity and server availability",
                "common_causes": [
                    "Network unreachable",
                    "Server down",
                    "Firewall blocking",
                ],
            },
            "TimeoutError": {
                "category": "Network",
                "suggestion": "Increase timeout or check if service is responding",
                "common_causes": [
                    "Service too slow",
                    "Network latency",
                    "Server overloaded",
                ],
            },
        }

    def explain_error(self, error: Exception) -> Dict:
        """
        Explain an exception

        Returns:
            Dict with error_type, category, message, suggestions, etc.
        """
        error_type = type(error).__name__
        error_str = str(error)

        return self.explain_error_string(error_str, error_type)

    def explain_error_string(
        self, error_message: str, error_type: Optional[str] = None
    ) -> Dict:
        """
        Explain error from string

        Args:
            error_message: Error message text
            error_type: Optional error type (FileNotFoundError, etc.)

        Returns:
            Detailed explanation dict
        """
        result = {
            "error_message": error_message,
            "error_type": error_type or "Unknown",
            "timestamp": datetime.now().isoformat(),
            "category": "Unknown",
            "severity": self._assess_severity(error_message),
            "explanation": "",
            "suggestions": [],
            "quick_fix": None,
        }

        # Look up in database
        if error_type and error_type in self.error_database:
            db_entry = self.error_database[error_type]
            result["category"] = db_entry["category"]
            result["suggestions"] = db_entry["common_causes"]
            result["quick_fix"] = db_entry["suggestion"]

        # Analyze error message for clues
        result.update(self._analyze_error_message(error_message))

        # Store in history
        self.error_history.append(result)

        return result

    def _assess_severity(self, error_message: str) -> str:
        """Assess error severity: low, medium, high, critical"""
        critical_terms = [
            "fatal",
            "crash",
            "segmentation",
            "kernel panic",
            "system error",
            "critical",
            "emergency",
            "panic",
        ]

        high_terms = [
            "failure",
            "broken",
            "cannot",
            "abort",
            "terminate",
            "denied",
            "invalid",
            "error",
        ]

        warning_terms = ["warning", "deprecated", "notice", "info"]

        msg_lower = error_message.lower()

        if any(term in msg_lower for term in critical_terms):
            return "critical"
        elif any(term in msg_lower for term in high_terms):
            return "high"
        elif any(term in msg_lower for term in warning_terms):
            return "low"
        else:
            return "medium"

    def _analyze_error_message(self, error_message: str) -> Dict:
        """Analyze error message for patterns"""
        suggestions = []
        explanation = ""

        # Check for common patterns
        if "not found" in error_message.lower():
            suggestions.append("Check if the resource exists")
            explanation = "The requested resource could not be located"

        if "permission denied" in error_message.lower():
            suggestions.append("Check file permissions (ls -l)")
            suggestions.append("Try with elevated privileges (sudo)")
            explanation = "Access to the resource is denied"

        if "connection" in error_message.lower():
            suggestions.append("Check network connectivity")
            suggestions.append("Verify server is running")
            explanation = "There is a connectivity issue"

        if "timeout" in error_message.lower():
            suggestions.append("Increase timeout value")
            suggestions.append("Check if service is responsive")
            explanation = "Operation took too long to complete"

        if "out of memory" in error_message.lower():
            suggestions.append("Close other applications")
            suggestions.append("Increase available memory")
            explanation = "The system ran out of available memory"

        if "syntax" in error_message.lower():
            suggestions.append("Check code syntax")
            suggestions.append("Verify brackets are balanced")
            explanation = "There is a syntax error in the code"

        # Extract error context
        lines = error_message.split("\n")
        context = []
        for line in lines[:3]:  # First 3 lines
            if line.strip():
                context.append(line.strip())

        return {
            "explanation": explanation,
            "suggestions": list(set(suggestions)),  # Remove duplicates
            "context": context,
        }

    def get_common_fixes(self, error_type: str) -> List[str]:
        """Get common fixes for error type"""
        if error_type not in self.error_database:
            return []

        db_entry = self.error_database[error_type]
        return [
            db_entry["suggestion"],
            *db_entry["common_causes"],
        ]

    def get_error_statistics(self) -> Dict:
        """Get error history statistics"""
        if not self.error_history:
            return {
                "total_errors": 0,
                "unique_types": 0,
                "severity_distribution": {},
            }

        severity_dist = {}
        error_types = set()

        for error_entry in self.error_history:
            severity = error_entry.get("severity", "unknown")
            error_types.add(error_entry.get("error_type", "unknown"))

            severity_dist[severity] = severity_dist.get(severity, 0) + 1

        return {
            "total_errors": len(self.error_history),
            "unique_types": len(error_types),
            "severity_distribution": severity_dist,
            "recent_errors": [e["error_type"] for e in self.error_history[-5:]],
        }

    def clear_history(self) -> None:
        """Clear error history"""
        self.error_history = []
