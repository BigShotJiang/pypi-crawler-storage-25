#!/usr/bin/env python3
"""
CLI Entry Point for alan-terminal-ai

Usage: alan please [your request]
Example: alan please list directory files
"""

import sys

from . import __version__
from .alan_assistant import AlanAssistant


def main():
    """Main CLI entry point"""
    # Handle global help and version first (before initialization)
    help_commands = ["--help", "-h"]
    version_commands = ["--version", "-v"]

    if len(sys.argv) > 1 and sys.argv[1] in help_commands:
        print(f"alan-terminal-ai v{__version__}")
        print("\nUsage:")
        print("  alan please [your request]          - Get command suggestions")
        print(
            "  alan copy                           - Copy last command to clipboard"
        )
        print("  alan stats                          - Show command statistics")
        print("  alan --help                         - Show this help")
        print("  alan --version                      - Show version")
        print("\nExamples:")
        print("  alan please list all Python files")
        print("  alan please find files modified today")
        print("  alan please count lines in all py files")
        sys.exit(0)

    if len(sys.argv) > 1 and sys.argv[1] in version_commands:
        print(f"alan-terminal-ai v{__version__}")
        sys.exit(0)

    # Now initialize Alan
    try:
        alan = AlanAssistant()
    except Exception as e:
        print(f"❌ Error initializing Alan: {e}", file=sys.stderr)
        sys.exit(1)

    # Handle copy and stats commands
    if len(sys.argv) > 1 and sys.argv[1].lower() == "copy":
        try:
            alan.handle_copy_command()
        except AttributeError:
            print("Copy command not available")
        sys.exit(0)

    if len(sys.argv) > 1 and sys.argv[1].lower() == "stats":
        try:
            alan.show_tracking_statistics()
        except AttributeError:
            print("Stats command not available")
        sys.exit(0)

    # Main "alan please" command handling
    if len(sys.argv) < 3 or sys.argv[1].lower() != "please":
        print("Usage: alan please [your request]")
        print("Examples:")
        print("  alan please list directory files")
        print("  alan please find all csv files")
        print("\nOther commands:")
        print("  alan copy     - Copy last suggestion to clipboard")
        print("  alan stats    - Show command statistics")
        print("  alan --help   - Show detailed help")
        print("  alan --version - Show version")
        sys.exit(1)

    user_request = " ".join(sys.argv[2:])

    # Handle help within "please" context
    if user_request.strip().startswith(
        "--help"
    ) or user_request.strip().startswith("-h"):
        try:
            alan.show_help()
        except (AttributeError, Exception):
            print(f"alan-terminal-ai v{__version__}")
            print("\nUsage: alan please [your request]")
            print("Examples:")
            print("  alan please list directory files")
            print("  alan please find all Python files in documents")
            print("  alan please count total lines in all py files")
        sys.exit(0)

    if not user_request.strip():
        print("Please provide a request after 'please'")
        print("Example: alan please list directory files")
        sys.exit(1)

    print(f"📝 Request: {user_request}")

    # Show system info
    try:
        print(f"🖥️  System: {alan.os_info['name']} ({alan.os_info['type']})")
    except (AttributeError, KeyError, TypeError):
        print("🖥️  System: Unknown")

    # Process the request
    try:
        # First, check if this is a multistep operation
        if alan.handle_multistep_request(user_request):
            print(
                "💡 Tip: Use 'alan copy' to copy the operation summary to clipboard"
            )
            sys.exit(0)

        suggested_command = None

        # Try Ollama first
        try:
            suggested_command = alan.get_command_from_ollama(
                user_request, model="qwen2.5:0.5b"
            )
        except Exception:
            suggested_command = None

        # If Ollama failed, try cloud LLM providers
        if not suggested_command:
            try:
                # Check if any cloud provider is available
                backends = alan.llm_manager.get_available_backends()
                available_providers = [
                    name
                    for name, available in backends.items()
                    if available and name != "ollama"
                ]

                if available_providers:
                    print(
                        f"💡 Using {available_providers[0]}...", file=sys.stderr
                    )
                    system_prompt = f"You are a terminal assistant for {alan.os_info.get('name', 'Unknown')}. Generate ONLY the shell command, no explanations or markdown."
                    prompt = f"Generate a terminal command for: {user_request}"
                    suggested_command = alan.llm_manager.generate(
                        prompt, system_prompt
                    )
                    if not suggested_command:
                        print(
                            "❌ LLM returned empty response. Check your API key or quota.",
                            file=sys.stderr,
                        )
                else:
                    print("❌ No cloud API keys configured.", file=sys.stderr)
                    print(
                        f"ℹ️  Available backends: {backends}", file=sys.stderr
                    )
                    print(
                        "💡 Set one of: OPENROUTER_API_KEY, OPENAI_API_KEY, or ANTHROPIC_API_KEY",
                        file=sys.stderr,
                    )
                    sys.exit(1)
            except Exception as llm_error:
                print(f"❌ Cloud API error: {llm_error}", file=sys.stderr)
                import traceback

                traceback.print_exc(file=sys.stderr)
                suggested_command = None

        if suggested_command:
            print(f"\033[1;37;44m💡 Suggested: {suggested_command}\033[0m")

            # Safety check
            if not alan.is_safe_command(suggested_command):
                print(
                    "⚠️  This command appears potentially dangerous.",
                    file=sys.stderr,
                )
                print(
                    "Please review and run manually if needed.",
                    file=sys.stderr,
                )
                sys.exit(1)

            # Track the command suggestion
            tracking_id = alan.track_command_suggestion(
                user_request, suggested_command, "cloud-llm"
            )

            # Show insights if available
            insights = alan.get_command_insights(
                user_request, suggested_command
            )
            if insights.get("confidence_score", 0.5) != 0.5:
                confidence_percent = insights["confidence_score"] * 100
                if confidence_percent > 80:
                    print(f"🎯 High confidence ({confidence_percent:.0f}%)")
                elif confidence_percent < 30:
                    print(f"⚠️  Low confidence ({confidence_percent:.0f}%)")
                else:
                    print(f"📊 Confidence: {confidence_percent:.0f}%")

            # Smart learning: auto-execute previously accepted safe commands
            auto_execute = False
            has_been_accepted = alan.command_tracker.has_command_been_accepted(
                suggested_command
            )
            is_destructive = alan.command_tracker.is_destructive_command(
                suggested_command
            )
            if has_been_accepted and not is_destructive:
                print(
                    "✨ Learning: You've accepted this command before - executing without permission"
                )
                auto_execute = True
            elif is_destructive:
                print(
                    "⚠️  Destructive command detected - always requesting permission"
                )

            # Ask for user approval
            if auto_execute:
                response = "y"
            else:
                response = (
                    input("\n✋ Execute this command? (y/n): ").strip().lower()
                )

            if response == "y" or response == "yes":
                # Track user acceptance
                alan.track_user_decision(True)

                import subprocess

                try:
                    print(f"\n▶️  Executing: {suggested_command}\n")
                    result = subprocess.run(
                        suggested_command,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )

                    if result.stdout:
                        print(result.stdout.rstrip())
                    if result.stderr and result.returncode != 0:
                        print(
                            f"Error: {result.stderr.rstrip()}",
                            file=sys.stderr,
                        )

                    success = result.returncode == 0

                    # Track execution result
                    alan.track_execution_result(success, result.stdout)

                    if success:
                        print("✅ Command executed successfully")
                    else:
                        print("❌ Command execution failed")

                except KeyboardInterrupt:
                    alan.track_user_decision(
                        False, "User cancelled with Ctrl+C"
                    )
                    print("\n⏸️  Command interrupted by user")
                    sys.exit(0)
                except subprocess.TimeoutExpired:
                    print(
                        "⚠️  Command timed out after 30 seconds",
                        file=sys.stderr,
                    )
                    sys.exit(1)
                except Exception as e:
                    print(f"❌ Error executing command: {e}", file=sys.stderr)
                    sys.exit(1)
            elif response == "n" or response == "no":
                # Track user rejection
                alan.track_user_decision(False)
                print("⛔ Command rejected. Not executing.")
                sys.exit(0)
            else:
                print("❓ Invalid response. Please answer 'y' or 'n'")
                sys.exit(1)
        else:
            print("❌ Could not get a command suggestion.", file=sys.stderr)
            print(
                "📖 See https://github.com/ankit0305/alan-terminal-ai#installation for setup instructions",
                file=sys.stderr,
            )
            sys.exit(1)

    except Exception as e:
        print(f"❌ Error processing request: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
