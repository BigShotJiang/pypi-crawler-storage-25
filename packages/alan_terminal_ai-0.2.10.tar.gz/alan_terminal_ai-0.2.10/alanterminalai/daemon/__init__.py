"""
Daemon & Scheduling Module

Features:
- Schedule tasks at intervals (daily, hourly, weekly, custom)
- Background daemon process support
- Log/print/notify output modes
- Persistent task configuration
"""

import json
import os
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import schedule


class TaskScheduler:
    """Schedule and manage background tasks"""

    def __init__(self, storage_dir: Optional[str] = None):
        """
        Initialize task scheduler

        Args:
            storage_dir: Directory for task configuration (default: ~/.alan/)
        """
        if storage_dir is None:
            storage_dir = str(Path.home() / ".alan")

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.tasks_file = self.storage_dir / "scheduled_tasks.json"
        self.tasks = self._load_tasks()
        self.schedule = schedule.Scheduler()
        self.running = False
        self.thread = None

    def _load_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Load tasks from disk"""
        if self.tasks_file.exists():
            try:
                with open(self.tasks_file, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {}

    def _save_tasks(self) -> bool:
        """Save tasks to disk"""
        try:
            with open(self.tasks_file, "w") as f:
                json.dump(self.tasks, f, indent=2)
            return True
        except IOError as e:
            print(f"Error saving tasks: {e}")
            return False

    def add_task(
        self,
        task_id: str,
        command: str,
        interval: str = "daily",
        output_mode: str = "log",
    ) -> bool:
        """
        Add or update a scheduled task

        Args:
            task_id: Unique task identifier
            command: Command to execute
            interval: 'daily', 'hourly', 'weekly', 'every 6 hours', etc.
            output_mode: 'log', 'print', or 'notify'

        Returns:
            True if added successfully
        """
        self.tasks[task_id] = {
            "command": command,
            "interval": interval,
            "output_mode": output_mode,
            "created": datetime.now().isoformat(),
            "last_run": None,
            "status": "scheduled",
        }

        # Schedule the job
        self._schedule_job(task_id, command, interval, output_mode)

        return self._save_tasks()

    def _schedule_job(
        self, task_id: str, command: str, interval: str, output_mode: str
    ) -> None:
        """Schedule a job with the scheduler"""

        def job_wrapper():
            self._execute_task(task_id, command, output_mode)

        # Parse interval and schedule
        interval_lower = interval.lower()

        if interval_lower == "daily":
            self.schedule.every().day.do(job_wrapper)
        elif interval_lower == "hourly":
            self.schedule.every().hour.do(job_wrapper)
        elif interval_lower == "weekly":
            self.schedule.every().week.do(job_wrapper)
        elif "every" in interval_lower:
            # Parse "every X hours/minutes/seconds"
            parts = interval_lower.split()
            if len(parts) >= 3:
                try:
                    count = int(parts[1])
                    unit = parts[2].lower()

                    if unit.startswith("hour"):
                        self.schedule.every(count).hours.do(job_wrapper)
                    elif unit.startswith("minute"):
                        self.schedule.every(count).minutes.do(job_wrapper)
                    elif unit.startswith("second"):
                        self.schedule.every(count).seconds.do(job_wrapper)
                except (ValueError, IndexError):
                    pass

    def _execute_task(
        self, task_id: str, command: str, output_mode: str
    ) -> None:
        """Execute a scheduled task"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            output = result.stdout
            success = result.returncode == 0

            # Update task record
            if task_id in self.tasks:
                self.tasks[task_id]["last_run"] = datetime.now().isoformat()
                self.tasks[task_id]["status"] = (
                    "success" if success else "failed"
                )
                self._save_tasks()

            # Handle output
            self._handle_output(task_id, output, output_mode, success)

        except subprocess.TimeoutExpired:
            print(f"Task {task_id} timed out")
        except Exception as e:
            print(f"Task {task_id} error: {e}")

    def _handle_output(
        self, task_id: str, output: str, mode: str, success: bool
    ) -> None:
        """Handle task output based on mode"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status = "✅" if success else "❌"
        log_entry = f"[{timestamp}] {status} Task {task_id}: {output[:200]}"

        if mode == "log":
            log_file = self.storage_dir / "scheduler.log"
            try:
                with open(log_file, "a") as f:
                    f.write(log_entry + "\n")
            except IOError:
                pass

        elif mode == "print":
            print(log_entry)

        elif mode == "notify":
            # Desktop notification (platform dependent)
            try:
                if os.system("which notify-send > /dev/null 2>&1") == 0:
                    # Linux
                    os.system(f'notify-send "Alan Task" "{log_entry}"')
            except:
                print(log_entry)

    def remove_task(self, task_id: str) -> bool:
        """Remove a task"""
        if task_id in self.tasks:
            del self.tasks[task_id]
            return self._save_tasks()
        return False

    def list_tasks(self) -> List[Dict[str, Any]]:
        """List all tasks"""
        return [
            {
                **task_data,
                "task_id": task_id,
            }
            for task_id, task_data in self.tasks.items()
        ]

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get specific task"""
        if task_id in self.tasks:
            return {
                **self.tasks[task_id],
                "task_id": task_id,
            }
        return None

    def start(self) -> None:
        """Start scheduler daemon"""
        if self.running:
            return

        self.running = True
        self.thread = threading.Thread(target=self._run_scheduler, daemon=True)
        self.thread.start()

    def _run_scheduler(self) -> None:
        """Run scheduler loop"""
        while self.running:
            self.schedule.run_pending()
            time.sleep(1)

    def stop(self) -> None:
        """Stop scheduler daemon"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)

    def get_statistics(self) -> Dict[str, Any]:
        """Get scheduler statistics"""
        total_tasks = len(self.tasks)
        successful = sum(
            1 for t in self.tasks.values() if t.get("status") == "success"
        )
        failed = sum(
            1 for t in self.tasks.values() if t.get("status") == "failed"
        )

        return {
            "total_tasks": total_tasks,
            "successful_runs": successful,
            "failed_runs": failed,
            "running": self.running,
        }


class DaemonProcess:
    """Background daemon process management"""

    def __init__(self, name: str = "alan-daemon"):
        self.name = name
        self.pid_file = Path.home() / f".alan/{name}.pid"
        self.pid_file.parent.mkdir(parents=True, exist_ok=True)

    def start(self) -> bool:
        """Start daemon process"""
        try:
            # Create scheduler
            scheduler = TaskScheduler()

            # Save PID
            os.makedirs(self.pid_file.parent, exist_ok=True)
            with open(self.pid_file, "w") as f:
                f.write(str(os.getpid()))

            # Start scheduling
            scheduler.start()

            # Keep daemon running
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                scheduler.stop()
                return True

        except Exception as e:
            print(f"Daemon error: {e}")
            return False

    def stop(self) -> bool:
        """Stop daemon process"""
        try:
            if self.pid_file.exists():
                with open(self.pid_file, "r") as f:
                    pid = int(f.read().strip())

                os.kill(pid, 15)  # SIGTERM
                self.pid_file.unlink()
                return True
        except (IOError, ProcessLookupError, ValueError):
            pass

        return False

    def is_running(self) -> bool:
        """Check if daemon is running"""
        if not self.pid_file.exists():
            return False

        try:
            with open(self.pid_file, "r") as f:
                pid = int(f.read().strip())

            os.kill(pid, 0)  # Check if process exists
            return True
        except (IOError, ProcessLookupError, ValueError):
            return False
