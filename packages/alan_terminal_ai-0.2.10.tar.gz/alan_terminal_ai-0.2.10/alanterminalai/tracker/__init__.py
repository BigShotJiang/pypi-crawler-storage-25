"""
Command tracking and analytics module for Alan Terminal Assistant
Tracks command suggestions, user decisions, and learning patterns
"""

from .command_tracker import CommandTracker

__all__ = ["CommandTracker"]
