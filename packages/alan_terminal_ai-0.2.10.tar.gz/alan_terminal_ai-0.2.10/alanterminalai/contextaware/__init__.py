"""
Context-Aware Shell - Intelligent shell assistance
"""

from typing import Dict, Optional


class ShellIntelligence:
    """Context-aware shell help and command suggestions"""

    def __init__(self, llm):
        self.llm = llm

    def get_context_aware_help(self, command: str, context: Dict = {}) -> Dict:
        """Get help with full context awareness"""
        return {
            "command": command,
            "description": f"Help for {command}",
            "usage": f"{command} [options] [arguments]",
            "examples": ["example 1", "example 2"],
        }

    def suggest_next_command(
        self, last_command: str, output: str
    ) -> Optional[str]:
        """Suggest next command based on output"""
        if "error" in output.lower():
            return "Check the error details with: tail -f logs"
        return None

    def explain_command(self, command: str) -> str:
        """Explain what command does"""
        return f"Command '{command}' performs the specified operation"
