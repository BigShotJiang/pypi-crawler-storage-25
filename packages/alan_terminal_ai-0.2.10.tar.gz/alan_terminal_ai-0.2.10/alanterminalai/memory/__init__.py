"""
Session Memory Module - Persistent Conversation Memory

Features:
- Conversation history tracking
- Session persistence
- Project context awareness
- User preference storage
- Recent command tracking
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class SessionMemory:
    """Persistent session memory management for Alan Terminal AI"""

    def __init__(self, storage_dir: Optional[str] = None):
        """
        Initialize session memory

        Args:
            storage_dir: Directory for memory storage (default: ~/.alan/memory/)
        """
        if storage_dir is None:
            storage_dir = str(Path.home() / ".alan" / "memory")

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # File paths
        self.sessions_file = self.storage_dir / "sessions.json"
        self.context_file = self.storage_dir / "context.json"
        self.preferences_file = self.storage_dir / "preferences.json"

        # In-memory state
        self.current_session_id = self._generate_session_id()
        self.conversation = []
        self.commands = []
        self.context = {}
        self.preferences = self._load_preferences()

    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def _load_preferences(self) -> Dict[str, Any]:
        """Load user preferences from disk"""
        if self.preferences_file.exists():
            try:
                with open(self.preferences_file, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {
            "theme": "default",
            "auto_confirm": False,
            "show_timing": True,
            "verbose": False,
            "language": "en",
        }

    def add_to_conversation(
        self, role: str, message: str, metadata: Optional[Dict] = None
    ) -> None:
        """
        Add message to conversation history

        Args:
            role: 'user', 'assistant', or 'system'
            message: Message content
            metadata: Optional additional data
        """
        entry = {
            "role": role,
            "message": message,
            "timestamp": datetime.now().isoformat(),
        }
        if metadata:
            entry.update(metadata)

        self.conversation.append(entry)

    def add_command(
        self,
        command: str,
        output: str = "",
        success: bool = True,
        duration: float = 0.0,
    ) -> None:
        """
        Record executed command

        Args:
            command: Command executed
            output: Command output
            success: Whether command succeeded
            duration: Execution time in seconds
        """
        self.commands.append(
            {
                "command": command,
                "output": output,
                "success": success,
                "duration": duration,
                "timestamp": datetime.now().isoformat(),
            }
        )

    def get_conversation_for_prompt(self, max_entries: int = 5) -> str:
        """
        Get recent conversation as context for LLM prompt

        Args:
            max_entries: How many recent entries to include

        Returns:
            Formatted conversation string
        """
        recent = self.conversation[-max_entries:]
        formatted = ""
        for entry in recent:
            role = entry["role"].upper()
            message = entry["message"]
            formatted += f"{role}: {message}\n"
        return formatted

    def get_command_history(self, limit: int = 10) -> List[Dict]:
        """Get recent command history"""
        return self.commands[-limit:]

    def set_context(self, key: str, value: Any) -> None:
        """Set context variable"""
        self.context[key] = value

    def get_context(self, key: str, default: Any = None) -> Any:
        """Get context variable"""
        return self.context.get(key, default)

    def set_preference(self, key: str, value: Any) -> None:
        """Set user preference"""
        self.preferences[key] = value

    def get_preference(self, key: str, default: Any = None) -> Any:
        """Get user preference"""
        return self.preferences.get(key, default)

    def save_session(self) -> bool:
        """Save current session to disk"""
        try:
            # Save sessions index
            sessions_data = {}
            if self.sessions_file.exists():
                try:
                    with open(self.sessions_file, "r") as f:
                        sessions_data = json.load(f)
                except (json.JSONDecodeError, IOError):
                    sessions_data = {}

            sessions_data[self.current_session_id] = {
                "timestamp": datetime.now().isoformat(),
                "conversation_length": len(self.conversation),
                "commands_count": len(self.commands),
            }

            with open(self.sessions_file, "w") as f:
                json.dump(sessions_data, f, indent=2)

            # Save context
            with open(self.context_file, "w") as f:
                json.dump(self.context, f, indent=2)

            # Save preferences
            with open(self.preferences_file, "w") as f:
                json.dump(self.preferences, f, indent=2)

            return True
        except (IOError, json.JSONEncodeError) as e:
            print(f"Error saving session: {e}")
            return False

    def load_session(self, session_id: Optional[str] = None) -> bool:
        """
        Load session from disk

        Args:
            session_id: Session ID to load (default: latest)

        Returns:
            True if loaded successfully
        """
        try:
            # Load context
            if self.context_file.exists():
                with open(self.context_file, "r") as f:
                    self.context = json.load(f)

            # Load preferences
            self.preferences = self._load_preferences()

            return True
        except (IOError, json.JSONDecodeError) as e:
            print(f"Error loading session: {e}")
            return False

    def clear_memory(self) -> None:
        """Clear current session memory (not persistent storage)"""
        self.current_session_id = self._generate_session_id()
        self.conversation = []
        self.commands = []
        self.context = {}

    def get_statistics(self) -> Dict[str, Any]:
        """Get memory statistics"""
        return {
            "session_id": self.current_session_id,
            "conversation_messages": len(self.conversation),
            "commands_executed": len(self.commands),
            "successful_commands": sum(
                1 for c in self.commands if c.get("success", False)
            ),
            "failed_commands": sum(
                1 for c in self.commands if not c.get("success", True)
            ),
            "context_variables": len(self.context),
        }
