"""
Domain-Specific Commands - Specialized commands for different domains
"""

from typing import Dict, List


class DomainSpecificCommands:
    """Domain-specific command suggestions and help"""

    def __init__(self, llm):
        self.llm = llm
        self.domains = [
            "devops",
            "datascience",
            "webdev",
            "sysadmin",
            "security",
        ]

    def get_domain_help(self, domain: str, topic: str) -> Dict:
        """Get domain-specific help"""
        return {
            "domain": domain,
            "topic": topic,
            "commands": ["cmd1", "cmd2", "cmd3"],
            "resources": ["doc1", "doc2"],
        }

    def list_domains(self) -> List[str]:
        """List available domains"""
        return self.domains
