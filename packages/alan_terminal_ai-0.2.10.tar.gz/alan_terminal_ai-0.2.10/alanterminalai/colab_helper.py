"""
Colab-specific helper for running alan-terminal-ai in Google Colab.

In Colab, environment variables set via os.environ don't pass to shell subprocesses (! commands).
Use this helper instead, which runs in the same Python kernel where the API key is set.

Example:
    from alanterminalai.colab_helper import setup_colab, colab_alan

    # Set up once per notebook
    import os
    os.environ['OPENROUTER_API_KEY'] = 'sk-or-...'
    setup_colab()

    # Then use python functions (NOT shell commands)
    colab_alan('--version')
    colab_alan('please', 'list', 'files')
"""

import os
import sys


def setup_colab(api_provider: str = None) -> None:
    """
    Set up alan in Colab by configuring an LLM API key.

    IMPORTANT: Call this AFTER setting os.environ with your API key!

    Args:
        api_provider: 'openrouter', 'openai', 'anthropic', or None to auto-detect

    Example:
        import os
        os.environ['OPENROUTER_API_KEY'] = 'sk-or-...'
        setup_colab('openrouter')
    """
    available_keys = {
        "openrouter": "OPENROUTER_API_KEY",
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
    }

    if api_provider:
        key_env = available_keys.get(api_provider.lower())
        if not key_env:
            print(f"❌ Unknown provider: {api_provider}")
            print(f"Supported: {', '.join(available_keys.keys())}")
            return

        if not os.getenv(key_env):
            print(f"⚠️  {key_env} not set!")
            print(f"\nSet it with:")
            print(f"  import os")
            print(f"  os.environ['{key_env}'] = 'your-api-key'")
            print(f"\nThen call:")
            print(f"  setup_colab('{api_provider}')")
            return

        print(f"✅ {key_env} is configured!")
    else:
        # Check which keys are available
        configured = [
            name
            for name, env_var in available_keys.items()
            if os.getenv(env_var)
        ]

        if configured:
            print(f"✅ Alan is ready! Configured with: {', '.join(configured)}")
        else:
            print("❌ No API keys configured. Set one of:")
            for name, env_var in available_keys.items():
                print(f"\n  {name.upper()}:")
                print(f"    import os")
                print(f"    os.environ['{env_var}'] = 'your-key'")
            print("\nThen call setup_colab() again")


def colab_alan(*args: str) -> None:
    """
    Run alan CLI command from Colab.

    ⚠️  IMPORTANT: Use this function, NOT !alan shell commands
    Shell commands (! prefix) don't inherit os.environ variables!

    Args:
        *args: Command arguments (e.g., 'please', 'list', 'files')

    Example:
        colab_alan('--version')
        colab_alan('please', 'show', 'current', 'directory')
        colab_alan('please', 'find', 'all', 'python', 'files')
    """
    # Add common Colab paths to Python path
    colab_paths = [
        "/usr/local/lib/python3.10/dist-packages",
        "/usr/local/lib/python3.11/dist-packages",
        "/usr/local/lib/python3.12/dist-packages",
        "/usr/lib/python3/dist-packages",
    ]

    for path in colab_paths:
        if path not in sys.path:
            sys.path.insert(0, path)

    from .cli import main

    # Mock sys.argv for the CLI
    original_argv = sys.argv
    sys.argv = ["alan"] + list(args)

    try:
        main()
    except SystemExit:
        pass
    finally:
        sys.argv = original_argv


# Convenience aliases
def colab_version() -> None:
    """Show alan version"""
    colab_alan("--version")


def colab_help() -> None:
    """Show alan help"""
    colab_alan("--help")


def colab_command(*args: str) -> None:
    """Run an alan command. Shorthand for colab_alan()"""
    colab_alan("please", *args)
