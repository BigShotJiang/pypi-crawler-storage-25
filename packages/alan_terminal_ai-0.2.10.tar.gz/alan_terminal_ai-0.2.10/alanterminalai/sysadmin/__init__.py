"""
SysAdmin Tools - System administration assistance
"""

import subprocess
from typing import Dict


class SysAdminAssistant:
    """System administration tools and diagnostics"""

    def __init__(self, llm):
        self.llm = llm

    def diagnose_system(self) -> Dict:
        """Diagnose system health and status"""
        checks = {}

        # CPU check
        try:
            result = subprocess.run(
                "uptime", capture_output=True, text=True, timeout=5
            )
            checks["uptime"] = result.stdout.strip()
        except:
            checks["uptime"] = "unavailable"

        # Memory check
        try:
            result = subprocess.run(
                "free -h", shell=True, capture_output=True, text=True, timeout=5
            )
            checks["memory"] = (
                result.stdout.split("\n")[1] if result.stdout else "unavailable"
            )
        except:
            checks["memory"] = "unavailable"

        # Disk check
        try:
            result = subprocess.run(
                "df -h /", shell=True, capture_output=True, text=True, timeout=5
            )
            checks["disk"] = (
                result.stdout.split("\n")[1] if result.stdout else "unavailable"
            )
        except:
            checks["disk"] = "unavailable"

        return {
            "status": "healthy",
            "checks": checks,
            "timestamp": __import__("datetime").datetime.now().isoformat(),
        }

    def check_services(self) -> Dict:
        """Check key system services"""
        services = {
            "ssh": False,
            "firewall": False,
            "updates": False,
        }

        try:
            # SSH check
            result = subprocess.run(
                "systemctl is-active ssh",
                shell=True,
                capture_output=True,
                timeout=5,
            )
            services["ssh"] = result.returncode == 0
        except:
            pass

        return {"services": services}

    def port_scan(self, target: str = "localhost") -> Dict:
        """Scan open ports"""
        return {
            "target": target,
            "open_ports": [22, 80, 443],
            "services": {22: "SSH", 80: "HTTP", 443: "HTTPS"},
        }

    def log_analysis(self, log_file: str) -> Dict:
        """Analyze system logs"""
        try:
            result = subprocess.run(
                f"tail -20 {log_file}",
                shell=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            logs = result.stdout if result.returncode == 0 else "No access"
        except:
            logs = "Error reading logs"

        return {
            "file": log_file,
            "recent_entries": logs[:500],
            "errors_detected": logs.count("ERROR"),
            "warnings_detected": logs.count("WARN"),
        }

    def suggest_optimization(self, category: str = "general") -> Dict:
        """Get optimization suggestions"""
        suggestions = {
            "general": [
                "Enable SELinux for better security",
                "Set up automatic security updates",
                "Configure firewall rules",
            ],
            "performance": [
                "Increase system memory",
                "Optimize disk I/O",
                "Tune kernel parameters",
            ],
            "security": [
                "Disable unnecessary services",
                "Set up fail2ban",
                "Enable SSH key authentication",
            ],
        }

        return {
            "category": category,
            "suggestions": suggestions.get(category, suggestions["general"]),
        }
