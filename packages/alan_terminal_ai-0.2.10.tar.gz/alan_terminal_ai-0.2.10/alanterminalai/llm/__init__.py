"""
Multi-LLM Backend Module

Features:
- Multiple LLM provider support (Ollama, OpenRouter, OpenAI, Anthropic)
- Automatic backend detection
- Fallback mechanism
- Mid-session backend switching
- Configuration via environment variables
"""

import os
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

import requests


class BaseLLMProvider(ABC):
    """Base class for LLM providers"""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if provider is available"""

    @abstractmethod
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: Optional[str] = None,
    ) -> str:
        """Generate response"""

    @abstractmethod
    def list_models(self) -> List[str]:
        """List available models"""


class OllamaProvider(BaseLLMProvider):
    """Ollama local LLM provider"""

    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.api_endpoint = f"{base_url}/api/generate"

    def is_available(self) -> bool:
        """Check if Ollama is running"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            return response.status_code == 200
        except:
            return False

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: str = "mistral",
    ) -> str:
        """Generate using Ollama"""
        try:
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\n{prompt}"

            response = requests.post(
                self.api_endpoint,
                json={
                    "model": model,
                    "prompt": full_prompt,
                    "stream": False,
                },
                timeout=60,
            )

            if response.status_code == 200:
                return response.json().get("response", "")
            return ""
        except Exception as e:
            print(f"Ollama error: {e}")
            return ""

    def list_models(self) -> List[str]:
        """List available Ollama models"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            if response.status_code == 200:
                models = response.json().get("models", [])
                return [m.get("name", "") for m in models]
        except:
            pass
        return []


class OpenRouterProvider(BaseLLMProvider):
    """OpenRouter multi-model provider"""

    def __init__(self):
        self.api_key = os.getenv("OPENROUTER_API_KEY")
        self.api_endpoint = "https://openrouter.ai/api/v1/chat/completions"

    def is_available(self) -> bool:
        """Check if OpenRouter API key is configured"""
        return bool(self.api_key)

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: str = "openai/gpt-3.5-turbo",
    ) -> str:
        """Generate using OpenRouter"""
        if not self.api_key:
            return ""

        try:
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            response = requests.post(
                self.api_endpoint,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "HTTP-Referer": "https://alan-terminal-ai.dev",
                    "X-Title": "Alan Terminal AI",
                },
                json={
                    "model": model,
                    "messages": messages,
                },
                timeout=30,
            )

            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            return ""
        except Exception as e:
            print(f"OpenRouter error: {e}")
            return ""

    def list_models(self) -> List[str]:
        """List available OpenRouter models"""
        # Return popular models
        return [
            "openai/gpt-4",
            "openai/gpt-3.5-turbo",
            "anthropic/claude-3-opus",
            "anthropic/claude-3-sonnet",
            "meta-llama/llama-2-70b",
            "mistralai/mistral-7b",
        ]


class OpenAIProvider(BaseLLMProvider):
    """OpenAI API provider"""

    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.api_endpoint = "https://api.openai.com/v1/chat/completions"

    def is_available(self) -> bool:
        """Check if OpenAI API key is configured"""
        return bool(self.api_key)

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: str = "gpt-3.5-turbo",
    ) -> str:
        """Generate using OpenAI"""
        if not self.api_key:
            return ""

        try:
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            response = requests.post(
                self.api_endpoint,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": 0.7,
                },
                timeout=30,
            )

            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            return ""
        except Exception as e:
            print(f"OpenAI error: {e}")
            return ""

    def list_models(self) -> List[str]:
        """List available OpenAI models"""
        return ["gpt-4", "gpt-3.5-turbo", "gpt-4-turbo"]


class AnthropicProvider(BaseLLMProvider):
    """Anthropic Claude API provider"""

    def __init__(self):
        self.api_key = os.getenv("ANTHROPIC_API_KEY")
        self.api_endpoint = "https://api.anthropic.com/v1/messages"

    def is_available(self) -> bool:
        """Check if Anthropic API key is configured"""
        return bool(self.api_key)

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: str = "claude-3-opus-20240229",
    ) -> str:
        """Generate using Anthropic Claude"""
        if not self.api_key:
            return ""

        try:
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }

            data = {
                "model": model,
                "max_tokens": 1024,
                "messages": [{"role": "user", "content": prompt}],
            }
            if system_prompt:
                data["system"] = system_prompt

            response = requests.post(
                self.api_endpoint, headers=headers, json=data, timeout=30
            )

            if response.status_code == 200:
                return response.json()["content"][0]["text"]
            return ""
        except Exception as e:
            print(f"Anthropic error: {e}")
            return ""

    def list_models(self) -> List[str]:
        """List available Claude models"""
        return [
            "claude-3-opus-20240229",
            "claude-3-sonnet-20240229",
            "claude-3-haiku-20240307",
        ]


class MultiLLMManager:
    """Manage multiple LLM backends with fallback"""

    def __init__(self):
        """Initialize all available providers"""
        self.providers = {
            "ollama": OllamaProvider(),
            "openrouter": OpenRouterProvider(),
            "openai": OpenAIProvider(),
            "anthropic": AnthropicProvider(),
        }
        self.current_provider = None
        self._detect_available_provider()

    def _detect_available_provider(self) -> None:
        """Detect first available provider"""
        for name, provider in self.providers.items():
            if provider.is_available():
                self.current_provider = name
                break

    def get_available_backends(self) -> Dict[str, bool]:
        """Get availability of all backends"""
        return {
            name: provider.is_available()
            for name, provider in self.providers.items()
        }

    def set_provider(self, provider_name: str) -> bool:
        """Switch to specific provider"""
        if provider_name in self.providers:
            if self.providers[provider_name].is_available():
                self.current_provider = provider_name
                return True
        return False

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model: Optional[str] = None,
        fallback: bool = True,
    ) -> str:
        """
        Generate text using current provider with fallback

        Args:
            prompt: User prompt
            system_prompt: System/context prompt
            model: Specific model to use
            fallback: Try other providers if current fails

        Returns:
            Generated text or empty string
        """
        if not self.current_provider and not fallback:
            return ""

        # Try current provider first
        if self.current_provider:
            provider = self.providers[self.current_provider]
            result = provider.generate(prompt, system_prompt, model)
            if result:
                return result

        # Fallback to other providers
        if fallback:
            for name, provider in self.providers.items():
                if name != self.current_provider and provider.is_available():
                    result = provider.generate(prompt, system_prompt, model)
                    if result:
                        return result

        return ""

    def get_statistics(self) -> Dict[str, Any]:
        """Get backend statistics"""
        available = self.get_available_backends()
        return {
            "current_provider": self.current_provider,
            "available_backends": available,
            "total_backends": len(self.providers),
            "available_count": sum(available.values()),
        }
