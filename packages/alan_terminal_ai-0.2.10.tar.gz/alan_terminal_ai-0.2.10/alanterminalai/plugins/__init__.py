"""
Plugin System Module - Dynamic plugin management
"""

import importlib
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


class PluginManager:
    """Manage and load plugins dynamically"""

    def __init__(self, plugins_dir: Optional[str] = None):
        """Initialize plugin manager"""
        if plugins_dir is None:
            plugins_dir = str(Path.home() / ".alan" / "plugins")

        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self.plugins = {}
        self.plugin_metadata = {}

    def discover_plugins(self) -> List[str]:
        """Discover available plugins"""
        plugin_files = list(self.plugins_dir.glob("*.py"))
        plugins = [f.stem for f in plugin_files if f.stem != "__init__"]
        return plugins

    def load_plugin(self, plugin_name: str) -> bool:
        """Load a plugin dynamically"""
        try:
            plugin_file = self.plugins_dir / f"{plugin_name}.py"
            if not plugin_file.exists():
                return False

            # Add to sys.path
            if str(self.plugins_dir) not in sys.path:
                sys.path.insert(0, str(self.plugins_dir))

            # Import module
            module = importlib.import_module(plugin_name)
            self.plugins[plugin_name] = module

            # Load metadata if available
            if hasattr(module, "PLUGIN_INFO"):
                self.plugin_metadata[plugin_name] = module.PLUGIN_INFO

            return True
        except Exception as e:
            print(f"Error loading plugin {plugin_name}: {e}")
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """Unload a plugin"""
        if plugin_name in self.plugins:
            del self.plugins[plugin_name]
            if plugin_name in self.plugin_metadata:
                del self.plugin_metadata[plugin_name]
            return True
        return False

    def get_plugin(self, plugin_name: str) -> Optional[Any]:
        """Get loaded plugin"""
        return self.plugins.get(plugin_name)

    def list_plugins(self) -> Dict[str, Dict]:
        """List all loaded plugins with metadata"""
        result = {}
        for name, module in self.plugins.items():
            result[name] = self.plugin_metadata.get(name, {})
        return result
