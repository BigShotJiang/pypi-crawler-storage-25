"""Allow running as: python -m alanterminalai"""

from .cli import main

if __name__ == "__main__":
    main()
