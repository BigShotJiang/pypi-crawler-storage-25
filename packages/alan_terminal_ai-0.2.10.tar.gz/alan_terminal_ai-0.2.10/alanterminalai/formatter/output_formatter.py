"""
OutputFormatter - Rich terminal formatting for Alan Terminal AI

Features:
- Syntax-highlighted code blocks
- Formatted tables for structured data
- Status indicators (✅ ⚠️ ❌)
- JSON pretty-printing
- Progress indicators
- Command suggestion panels with confidence scores
"""

from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.syntax import Syntax
from rich.table import Table


class OutputFormatter:
    """Rich terminal output formatter for Alan Terminal AI"""

    def __init__(self):
        """Initialize the formatter with Rich console"""
        self.console = Console()

    def show_success(self, message: str, title: Optional[str] = None) -> None:
        """Display a success message with green checkmark"""
        if title:
            self.console.print(f"[green]✅ {title}[/green]")
        self.console.print(f"[green]{message}[/green]")

    def show_error(self, message: str, title: Optional[str] = None) -> None:
        """Display an error message with red X"""
        if title:
            self.console.print(f"[red]❌ {title}[/red]")
        self.console.print(f"[red]{message}[/red]")

    def show_warning(self, message: str, title: Optional[str] = None) -> None:
        """Display a warning message with yellow exclamation"""
        if title:
            self.console.print(f"[yellow]⚠️  {title}[/yellow]")
        self.console.print(f"[yellow]{message}[/yellow]")

    def show_info(self, message: str, title: Optional[str] = None) -> None:
        """Display an info message with blue circle"""
        if title:
            self.console.print(f"[blue]ℹ️  {title}[/blue]")
        self.console.print(f"[blue]{message}[/blue]")

    def show_command_suggestion(
        self,
        command: str,
        confidence: float = 1.0,
        explanation: Optional[str] = None,
    ) -> None:
        """Display a command suggestion with confidence score"""
        confidence_pct = f"{confidence*100:.0f}%"
        confidence_bar = "█" * int(confidence * 10) + "░" * (
            10 - int(confidence * 10)
        )

        title = f"[cyan]💡 Suggested Command[/cyan] {confidence_bar} {confidence_pct}"

        content = f"[yellow]{command}[/yellow]"
        if explanation:
            content += f"\n\n[dim]{explanation}[/dim]"

        panel = Panel(content, title=title, border_style="cyan")
        self.console.print(panel)

    def show_code_block(
        self, code: str, language: str = "python", title: Optional[str] = None
    ) -> None:
        """Display syntax-highlighted code block"""
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)

        if title:
            panel = Panel(syntax, title=title, border_style="blue")
            self.console.print(panel)
        else:
            self.console.print(syntax)

    def show_table(
        self, data: List[Dict[str, Any]], title: Optional[str] = None
    ) -> None:
        """Display formatted table from list of dictionaries"""
        if not data:
            self.show_warning("No data to display")
            return

        table = Table(title=title, show_header=True, header_style="bold cyan")

        # Get columns from first row
        columns = list(data[0].keys())
        for col in columns:
            table.add_column(col, style="dim white")

        # Add rows
        for row in data:
            values = [str(row.get(col, "")) for col in columns]
            table.add_row(*values)

        self.console.print(table)

    def show_json(
        self, data: Dict[str, Any], title: Optional[str] = None
    ) -> None:
        """Display pretty-printed JSON"""
        import json

        json_str = json.dumps(data, indent=2)
        self.show_code_block(json_str, language="json", title=title)

    def show_command_output(
        self, output: str, command: Optional[str] = None
    ) -> None:
        """Display command output in formatted panel"""
        title = (
            f"[cyan]📤 Output[/cyan]"
            if not command
            else f"[cyan]📤 {command}[/cyan]"
        )
        panel = Panel(
            f"[dim white]{output}[/dim white]", title=title, border_style="cyan"
        )
        self.console.print(panel)

    def show_status_indicators(self, statuses: Dict[str, bool]) -> None:
        """Display status indicators for multiple items"""
        for name, status in statuses.items():
            symbol = "✅" if status else "❌"
            color = "green" if status else "red"
            self.console.print(f"{symbol} [{color}]{name}[/{color}]")

    def show_progress_bar(self, title: str, total: int = 100) -> Progress:
        """Create and return a progress bar context"""
        progress = Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        )
        return progress

    def separator(self, title: Optional[str] = None) -> None:
        """Display a separator line"""
        if title:
            self.console.print(f"\n[dim]{'─' * 80}[/dim]")
            self.console.print(f"[cyan]{title}[/cyan]")
            self.console.print(f"[dim]{'─' * 80}[/dim]\n")
        else:
            self.console.print(f"[dim]{'─' * 80}[/dim]")

    def print_raw(self, text: str) -> None:
        """Print raw text without formatting"""
        self.console.print(text)
