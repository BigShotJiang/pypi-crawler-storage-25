"""
Output Formatting Module - Rich Terminal UI

Provides rich terminal formatting with syntax highlighting, tables,
progress bars, panels, and formatted output for Alan Terminal AI.
"""

from .output_formatter import OutputFormatter

__all__ = ["OutputFormatter"]
