"""
Hyper-Context Awareness - Advanced context collection
"""

import os
import subprocess
from typing import Dict, Optional


class HyperContextManager:
    """Manage deep contextual awareness"""

    def __init__(self, enable_context: bool = True):
        self.enabled = enable_context
        self.context = {}

    def collect_context(self) -> Dict:
        """Collect full context about environment"""
        if not self.enabled:
            return {}

        context = {
            "working_dir": os.getcwd(),
            "user": os.getenv("USER", "unknown"),
            "shell": os.getenv("SHELL", "unknown"),
            "git_branch": self._get_git_branch(),
            "git_status": self._get_git_status(),
            "python_version": self._get_python_version(),
            "node_version": self._get_node_version(),
        }

        self.context = context
        return context

    def _get_git_branch(self) -> Optional[str]:
        """Get current git branch"""
        try:
            result = subprocess.run(
                "git rev-parse --abbrev-ref HEAD",
                shell=True,
                capture_output=True,
                text=True,
                timeout=2,
                cwd=os.getcwd(),
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        return None

    def _get_git_status(self) -> Optional[str]:
        """Get git status (short)"""
        try:
            result = subprocess.run(
                "git status --short",
                shell=True,
                capture_output=True,
                text=True,
                timeout=2,
                cwd=os.getcwd(),
            )
            if result.returncode == 0:
                return "clean" if not result.stdout.strip() else "dirty"
        except:
            pass
        return None

    def _get_python_version(self) -> Optional[str]:
        """Get Python version if available"""
        try:
            result = subprocess.run(
                "python3 --version",
                shell=True,
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0:
                return result.stdout.strip() or result.stderr.strip()
        except:
            pass
        return None

    def _get_node_version(self) -> Optional[str]:
        """Get Node.js version if available"""
        try:
            result = subprocess.run(
                "node --version",
                shell=True,
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        return None

    def get_context(self) -> Dict:
        """Get current context"""
        return self.context
