"""
Speech-to-Text Module

Transcribe audio files to text using OpenAI's Whisper model
or local whisper installation.
"""

import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional


class SpeechToTextPipeline:
    """Speech-to-Text pipeline using Whisper"""

    def __init__(self, model: str = "base", language: Optional[str] = None):
        """
        Initialize STT pipeline

        Args:
            model: Whisper model size (tiny, base, small, medium, large)
            language: ISO 639-1 language code (e.g., 'en', 'es')
        """
        self.model = model
        self.language = language
        self.cache_dir = Path.home() / ".alan" / "stt_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.has_whisper = self._check_whisper()

    def _check_whisper(self) -> bool:
        """Check if whisper is installed"""
        try:
            result = subprocess.run(
                ["whisper", "--version"], capture_output=True, timeout=5
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def transcribe(self, audio_file: str) -> Optional[Dict[str, Any]]:
        """
        Transcribe audio file to text

        Args:
            audio_file: Path to audio file (mp3, wav, m4a, etc.)

        Returns:
            Dict with 'text', 'segments', 'language', etc., or None on error
        """
        audio_path = Path(audio_file)

        if not audio_path.exists():
            return None

        # Check cache first
        cache_result = self._get_cached_transcription(audio_file)
        if cache_result:
            return cache_result

        # Use whisper CLI
        if not self.has_whisper:
            return None

        try:
            # Build command
            cmd = [
                "whisper",
                str(audio_path),
                "--model",
                self.model,
                "--output_format",
                "json",
                "--output_dir",
                str(self.cache_dir),
            ]

            if self.language:
                cmd.extend(["--language", self.language])

            # Run transcription
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            if result.returncode != 0:
                return None

            # Parse output
            output_file = (self.cache_dir / audio_path.stem).with_suffix(
                ".json"
            )
            if output_file.exists():
                with open(output_file, "r") as f:
                    output = json.load(f)

                # Cache it
                self._cache_transcription(audio_file, output)

                return output

            return None

        except subprocess.TimeoutExpired:
            return None
        except Exception as e:
            print(f"Transcription error: {e}")
            return None

    def transcribe_stream(
        self, audio_data: bytes, format: str = "wav"
    ) -> Optional[Dict[str, Any]]:
        """
        Transcribe audio from bytes

        Args:
            audio_data: Raw audio bytes
            format: Audio format (wav, mp3, m4a)

        Returns:
            Transcription result
        """
        temp_file = self.cache_dir / f"temp_audio.{format}"

        try:
            # Write temp file
            with open(temp_file, "wb") as f:
                f.write(audio_data)

            # Transcribe
            result = self.transcribe(str(temp_file))

            return result
        finally:
            # Clean up temp file
            if temp_file.exists():
                temp_file.unlink()

    def _get_cached_transcription(self, audio_file: str) -> Optional[Dict]:
        """Check cache for transcription"""
        audio_path = Path(audio_file)
        cache_key_file = self.cache_dir / f"{audio_path.stem}_cache.json"

        if cache_key_file.exists():
            try:
                with open(cache_key_file, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass

        return None

    def _cache_transcription(self, audio_file: str, result: Dict) -> bool:
        """Cache transcription result"""
        audio_path = Path(audio_file)
        cache_key_file = self.cache_dir / f"{audio_path.stem}_cache.json"

        try:
            with open(cache_key_file, "w") as f:
                json.dump(result, f)
            return True
        except IOError:
            return False

    def get_available_models(self) -> List[str]:
        """Get available Whisper models"""
        return ["tiny", "base", "small", "medium", "large"]

    def get_supported_languages(self) -> List[Dict[str, str]]:
        """Get supported languages"""
        return [
            {"code": "en", "name": "English"},
            {"code": "es", "name": "Spanish"},
            {"code": "fr", "name": "French"},
            {"code": "de", "name": "German"},
            {"code": "it", "name": "Italian"},
            {"code": "pt", "name": "Portuguese"},
            {"code": "ru", "name": "Russian"},
            {"code": "zh", "name": "Chinese"},
            {"code": "ja", "name": "Japanese"},
            {"code": "ko", "name": "Korean"},
        ]

    def convert_to_wav(
        self, audio_file: str, output_file: Optional[str] = None
    ) -> Optional[str]:
        """Convert audio file to WAV format"""
        if output_file is None:
            output_file = str(Path(audio_file).with_suffix(".wav"))

        try:
            # Try ffmpeg first
            result = subprocess.run(
                [
                    "ffmpeg",
                    "-i",
                    audio_file,
                    "-acodec",
                    "pcm_s16le",
                    "-ar",
                    "16000",
                    output_file,
                    "-y",
                ],
                capture_output=True,
                timeout=60,
            )

            if result.returncode == 0:
                return output_file
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return None

    def get_statistics(self) -> Dict[str, Any]:
        """Get STT statistics"""
        return {
            "whisper_available": self.has_whisper,
            "model": self.model,
            "language": self.language,
            "cached_transcriptions": len(
                list(self.cache_dir.glob("*_cache.json"))
            ),
            "cache_dir": str(self.cache_dir),
        }
