from readtheyaml.exceptions.validation_error import ValidationError
from readtheyaml.fields.field import Field


class NoneField(Field):
    def __init__(self, *, when=None, **kwargs):
        super().__init__(when=when, field_type="none", **kwargs)

    def validate_and_build(self, value):
        if str(value).lower() in {"none", "null"}:
            return None

        raise ValidationError(f"Field '{self.name}': must be null/None")

    def ui_widget_type(self):
        from readtheyaml.ui.widgets import NoneFieldWidget
        return NoneFieldWidget

    @staticmethod
    def from_type_string(type_str: str, name: str, factory, **kwargs):
        if type_str in {"None", "none", "NONE"}:
            return NoneField(name=name, **kwargs)

        return None
