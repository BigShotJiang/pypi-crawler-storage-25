import ast
import copy

from readtheyaml.exceptions.format_error import FormatError
from readtheyaml.exceptions.validation_error import ValidationError
from readtheyaml.fields.field import Field
from readtheyaml.utils.type_utils import extract_types_for_composite, split_top_level


class TupleField(Field):
    def __init__(self, element_fields, *, when=None, **kwargs):
        if not element_fields or any(not isinstance(slot, Field) for slot in element_fields):
            raise FormatError("TupleField element_fields must be a non-empty list of Field instances.")
        tuple_inner = ", ".join(slot.field_type() for slot in element_fields)
        super().__init__(when=when, field_type=f"tuple({tuple_inner})", **kwargs)

        self._slots = element_fields

    def validate_and_build(self, value):
        if value is None:
            raise ValidationError(f"Field '{self.name}': None is not a valid tuple")

        if type(value) != tuple:
            if not isinstance(value, str):
                raise ValidationError(f"Field '{self.name}': Not a valid tuple")

            if not (value.startswith("(") and value.endswith(")")):
                raise ValidationError(f"Field '{self.name}': Not a valid tuple")

            try:
                value = ast.literal_eval(value)
            except (ValueError, SyntaxError):
                raise ValidationError(f"Field '{self.name}': Not a valid tuple")

            if type(value) != tuple:
                value = (value,)

        if not isinstance(value, tuple):
            raise ValidationError(f"Field '{self.name}': Expected tuple, got {type(value).__name__}")

        if len(value) != len(self._slots):
            raise ValidationError(f"Field '{self.name}': Tuple must contain exactly {len(self._slots)} elements (got {len(value)})")

        for idx, (v, field) in enumerate(zip(value, self._slots)):
            try:
                field.validate_and_build(v)
            except ValidationError as err:
                raise ValidationError(f"Field '{self.name}': Tuple element {idx} invalid: {err}")

        return value

    @staticmethod
    def from_type_string(type_str, name, factory, **kwargs):
        tuple_inner = extract_types_for_composite(type_str=type_str, type_name="tuple")
        if tuple_inner is not None:
            element_specs = split_top_level(tuple_inner, ',')

            args_copy = copy.deepcopy(kwargs)
            args_copy["ignore_post"] = True

            element_fields = []
            for element in element_specs:
                element_field = factory.create_field(element, name, **args_copy)
                element_fields.append(element_field)
            return TupleField(name=name, element_fields=element_fields, **kwargs)

        return None
