from copy import deepcopy
from functools import partial
from readtheyaml.exceptions.format_error import FormatError
from readtheyaml.exceptions.validation_error import ValidationError
from readtheyaml.conditions import parse_when


class PostInitMeta(type):
    def __call__(cls, *args, **kwargs):
        obj = super().__call__(*args, **kwargs)
        if hasattr(obj, "post_init"):
            obj.post_init()
        return obj


class Field(metaclass=PostInitMeta):
    allowed_kwargs = {"type", "when"}

    def __init__(self, name, description, required=True, default=None, *, when=None, field_type=None, additional_allowed_kwargs=None, ignore_post=False, **kwargs):
        self.name = name
        self.required = required
        self.default = default
        self.raw_default = deepcopy(default)
        self.description = description
        self.ignore_post = ignore_post
        self.when = parse_when(when, f"when for field '{self.name}'")
        self._field_type = field_type or self.__class__.__name__

        if additional_allowed_kwargs is None:
            additional_allowed_kwargs = set()

        if default is not None and required:
            raise FormatError(f"Field {self.name} you are providing default value for a required field. This is useless.")

        unknown = set(kwargs) - self.allowed_kwargs - additional_allowed_kwargs
        if unknown:
            raise FormatError(f"{self.__class__.__name__} got unknown parameters: {unknown}")

    def post_init(self):
        if not self.required and not self.ignore_post:
            try:
                self.default = self.validate_and_build(self.default)
            except ValidationError as e:
                raise FormatError(f"Field {self.name} got invalid default value: {e}") from None

    def validate_and_build(self, value):
        raise NotImplementedError(f"Field '{self.name}': Each field must implement its own validate method.")

    def constraint_specs(self):
        return {}

    def ui_widget_type(self):
        from readtheyaml.ui.widgets import StringFieldWidget
        return StringFieldWidget

    def field_type(self):
        return self._field_type

    @staticmethod
    def from_type_string(type_str: str, name: str, factory, **kwargs):
        raise NotImplementedError("Each field must implement its own from_type_string.")

    def _make_partial_field(self, field, suffix):
        if isinstance(field, partial):
            kwargs = dict(field.keywords or {})
            if "name" not in kwargs:
                kwargs["name"] = f"{self.name}_{suffix}"
            if "description" not in kwargs:
                kwargs["description"] = f"{self.description}_{suffix}"

            return field.func(*field.args, **kwargs)

        return field
