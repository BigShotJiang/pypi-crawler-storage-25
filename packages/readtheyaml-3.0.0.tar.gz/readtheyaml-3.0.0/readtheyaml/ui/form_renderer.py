from copy import deepcopy
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable, Dict, Optional

from readtheyaml.ui.form_helpers import (_normalize_path, evaluate_visibility_map, get_value_at_path, join_path, materialize_section_path, project_known_config, resolve_display_value, set_value_at_path)
from readtheyaml.ui.constants import ROOT_PATH
from readtheyaml.ui.widgets import INVALID_INPUT, StringFieldWidget


class FormRenderer(ttk.Frame):
    def __init__(self, parent: tk.Misc, introspection_model: Dict[str, Any], current_config: Dict[str, Any], strict: bool = True, on_change: Optional[Callable[[Dict[str, Any]], None]] = None):
        super().__init__(parent)
        self._introspection_model = introspection_model
        self._strict = strict
        self._on_change = on_change
        self._widgets = {}
        self._section_views: Dict[str, Dict[str, Any]] = {}
        self._initializing = True
        self._suppress_widget_events = False
        if strict:
            self._draft_config = project_known_config(current_config, introspection_model)
        else:
            self._draft_config = deepcopy(current_config)

        self.columnconfigure(0, weight=1)
        self._render_section(self, introspection_model)
        self._refresh_when_visibility()
        self._initializing = False

    def get_current_config_dict(self):
        return deepcopy(self._draft_config)

    def set_on_change(self, callback: Optional[Callable[[Dict[str, Any]], None]]):
        self._on_change = callback

    def apply_field_errors(self, field_errors: Dict[str, str]):
        for field_path, widget in self._widgets.items():
            _ = field_path
            widget.clear_invalid()
        for field_path, error_message in field_errors.items():
            target_path = self._resolve_widget_path(field_path)
            if target_path is None:
                continue
            self._reveal_ancestors(target_path)
            widget = self._widgets[target_path]
            widget.pack(fill="x", expand=True, pady=2)
            self._set_widget_enabled(widget, True)
            widget.mark_invalid(error_message)

    def set_field_value(self, field_path: str, value: Any):
        normalized = _normalize_path(field_path)
        if not normalized:
            return

        if value is None:
            self._remove_path(normalized)
        else:
            set_value_at_path(self._draft_config, normalized, value)

        widget = self._widgets.get(normalized)
        if widget is not None:
            self._suppress_widget_events = True
            try:
                widget.set_value(value)
                widget.clear_invalid()
            finally:
                self._suppress_widget_events = False

        self._refresh_when_visibility()
        self._emit_change()

    def focus_field(self, field_path: str):
        self._reveal_ancestors(field_path)
        widget = self._widgets.get(_normalize_path(field_path))
        if widget is None:
            return
        control = getattr(widget, "_input_widget", None)
        if control is not None:
            try:
                control.focus_set()
            except Exception:
                pass

    def reveal_section(self, section_path: str):
        self._reveal_ancestors(section_path)

    def _render_section(self, parent: ttk.Frame, section: Dict[str, Any]):
        section_path = section.get("path", "")
        title = section_path.split(".")[-1] if section_path else ROOT_PATH

        container = ttk.Frame(parent)
        container.pack(fill="x", expand=True, pady=4)
        container.columnconfigure(0, weight=1)

        header = ttk.Frame(container)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(2, weight=1)

        body = ttk.Frame(container)
        body.grid(row=1, column=0, sticky="ew")
        body.columnconfigure(0, weight=1)

        collapsed = tk.BooleanVar(value=False)
        toggle_text = tk.StringVar(value="[-]")

        def toggle():
            is_collapsed = not collapsed.get()
            collapsed.set(is_collapsed)
            if is_collapsed:
                toggle_text.set("[+]")
                body.grid_remove()
            else:
                toggle_text.set("[-]")
                body.grid()

        ttk.Button(header, textvariable=toggle_text, width=3, command=toggle).grid(row=0, column=0, sticky="w")
        ttk.Label(header, text=title).grid(row=0, column=1, sticky="w", padx=(4, 8))

        self._section_views[section_path] = {"container": container, "body": body, "collapsed": collapsed, "toggle_text": toggle_text}

        for field in section.get("fields", []):
            field_path = join_path(section_path, field["key"])
            widget = self._create_field_widget(body, field, field_path)
            widget.pack(fill="x", expand=True, pady=2)
            self._widgets[field_path] = widget

        for subsection in section.get("subsections", []):
            self._render_section(body, subsection)

    def _create_field_widget(self, parent: ttk.Frame, field: Dict[str, Any], field_path: str):
        field_type = field.get("field_type", field.get("type", "str"))
        label = field["key"]
        description = field.get("description", "")
        required = bool(field.get("required", True))
        widget_ctor = self._resolve_widget_type(field_type, field.get("widget_type"))
        on_change = lambda value, p=field_path: self._on_widget_change(p, value)
        widget_kwargs: Dict[str, Any] = {
            "label": label,
            "description": description,
            "required": required,
            "on_change": on_change,
        }
        constraints = field.get("constraints", {}) or {}
        if field_type.startswith("object"):
            widget_kwargs["parameters"] = list(constraints.get("object_parameters", []))
            widget_kwargs["class_path"] = constraints.get("object_class_path")
        widget = widget_ctor(parent, **widget_kwargs)
        initial = resolve_display_value(field, self._draft_config, field_path)
        widget.set_value(initial)
        return widget

    def _resolve_widget_type(self, field_type: str, widget_type: Any):
        _ = field_type
        if callable(widget_type):
            return widget_type
        return StringFieldWidget

    def _on_widget_change(self, field_path: str, value: Any):
        if self._initializing:
            return
        if self._suppress_widget_events:
            return
        if value is INVALID_INPUT:
            self._remove_path(field_path)
            self._refresh_when_visibility()
            self._emit_change()
            return
        if value is None:
            self._remove_path(field_path)
            self._refresh_when_visibility()
            self._emit_change()
            return
        set_value_at_path(self._draft_config, field_path, value)
        self._refresh_when_visibility()
        self._emit_change()

    def _remove_path(self, dotted_path: str):
        parts = dotted_path.split(".")
        current = self._draft_config
        stack = []
        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                return
            stack.append((current, part))
            current = current[part]
        if parts[-1] not in current:
            return
        del current[parts[-1]]
        while stack:
            parent, key = stack.pop()
            node = parent.get(key)
            if isinstance(node, dict) and not node:
                del parent[key]
            else:
                break

    def _emit_change(self):
        if self._on_change is not None:
            self._on_change(self.get_current_config_dict())

    def _refresh_when_visibility(self):
        visibility = evaluate_visibility_map(self._introspection_model, self._draft_config)
        for path, widget in self._widgets.items():
            is_active = visibility.get(path, True)
            if is_active:
                widget.pack(fill="x", expand=True, pady=2)
            else:
                widget.pack_forget()
            self._set_widget_enabled(widget, is_active)

        for section_path, view in self._section_views.items():
            if not section_path:
                continue
            is_active = visibility.get(section_path, True)
            container = view["container"]
            body = view["body"]
            collapsed = view["collapsed"]
            toggle_text = view["toggle_text"]

            if is_active:
                container.pack(fill="x", expand=True, pady=4)
                if collapsed.get():
                    body.grid_remove()
                    toggle_text.set("[+]")
                else:
                    body.grid()
                    toggle_text.set("[-]")
            else:
                container.pack_forget()
                body.grid_remove()
                toggle_text.set("[+]")

    @staticmethod
    def _set_widget_enabled(widget: Any, enabled: bool):
        control = getattr(widget, "_input_widget", None)
        if control is None:
            return
        try:
            if enabled:
                control.state(["!disabled"])
            else:
                control.state(["disabled"])
        except Exception:
            pass

    def _reveal_ancestors(self, path: str):
        normalized = _normalize_path(path)
        if not normalized:
            return
        parts = normalized.split(".")
        section_paths = []
        for i in range(1, len(parts) + 1):
            section_path = ".".join(parts[:i])
            if section_path in self._section_views:
                section_paths.append(section_path)

        for section_path in section_paths:
            view = self._section_views.get(section_path)
            if view is None:
                continue
            container = view["container"]
            body = view["body"]
            collapsed = view["collapsed"]
            toggle_text = view["toggle_text"]

            container.pack(fill="x", expand=True, pady=4)
            collapsed.set(False)
            toggle_text.set("[-]")
            body.grid()

    def _resolve_widget_path(self, field_path: str):
        normalized = _normalize_path(field_path)
        if normalized in self._widgets:
            return normalized
        if field_path in self._widgets:
            return field_path

        leaf = normalized.split(".")[-1] if normalized else ""
        if not leaf:
            return None
        candidates = [widget_path for widget_path in self._widgets if widget_path == leaf or widget_path.endswith(f".{leaf}")]
        if len(candidates) == 1:
            return candidates[0]
        if leaf in self._widgets:
            return leaf
        return None
