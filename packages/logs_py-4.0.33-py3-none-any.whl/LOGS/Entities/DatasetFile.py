from datetime import datetime
from typing import Optional

from LOGS.Entity.SerializableContent import SerializableContent


class DatasetFile(SerializableContent):
    _path: Optional[str] = None
    _size: Optional[int] = None
    _mtime: Optional[datetime] = None

    def __str__(self):
        return "<%s %a>" % (
            type(self).__name__,
            self._path,
        )

    @property
    def path(self) -> Optional[str]:
        return self._path

    @path.setter
    def path(self, value):
        self._path = self.checkAndConvertNullable(value, str, "path")

    @property
    def size(self) -> Optional[int]:
        return self._size

    @size.setter
    def size(self, value):
        self._size = self.checkAndConvertNullable(value, int, "size")

    @property
    def mtime(self) -> Optional[datetime]:
        return self._mtime

    @mtime.setter
    def mtime(self, value):
        if isinstance(value, (int, float)):
            value = datetime.fromtimestamp(value)

        self._mtime = self.checkAndConvertNullable(value, datetime, "mtime")
