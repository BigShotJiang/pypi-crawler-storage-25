from typing import TYPE_CHECKING, List, Optional

from LOGS.Auxiliary.MinimalModelGenerator import MinimalModelGenerator
from LOGS.Auxiliary.Tools import Tools
from LOGS.Entity.EntityWithIntId import IEntityWithIntId
from LOGS.Interfaces.IOwnedEntity import IOwnedEntity
from LOGS.Interfaces.IProjectBased import IProjectBased
from LOGS.Interfaces.ITypedEntity import ITypedEntity

if TYPE_CHECKING:
    from LOGS.Entities.DataSourceMinimal import DataSourceMinimal
    from LOGS.Entities.ProjectMinimal import ProjectMinimal


class DatasetTemplate(IEntityWithIntId, ITypedEntity, IOwnedEntity, IProjectBased):
    _id: int = 0
    _dataSources: Optional[List["DataSourceMinimal"]] = None
    _projects: Optional[List["ProjectMinimal"]] = None

    @property
    def id(self) -> int:
        return self._id

    @id.setter
    def id(self, value):
        self._id = Tools.checkAndConvert(value, int, "id")

    @property
    def dataSources(self) -> Optional[List["DataSourceMinimal"]]:
        return self._dataSources

    @dataSources.setter
    def dataSources(self, value):
        self._dataSources = MinimalModelGenerator.MinimalFromList(
            value, "DataSourceMinimal", "dataSources", connection=self._getConnection()
        )

    @property
    def projects(self) -> Optional[List["ProjectMinimal"]]:
        return self._projects

    @projects.setter
    def projects(self, value):
        self._projects = MinimalModelGenerator.MinimalFromList(
            value, "ProjectMinimal", "projects", connection=self._getConnection()
        )
