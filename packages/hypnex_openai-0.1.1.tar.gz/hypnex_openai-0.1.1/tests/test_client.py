"""Smoke tests against the live api.mor.org public surface.

Tests that don't require an API key:
  - active_models() registry fetch
  - find_model() / models_by_type()
  - /health endpoint

Tests that DO require HYPNEX_API_KEY (skipped if not set):
  - chat.completions.create
  - /billing/balance
  - /auth/me
"""

from __future__ import annotations

import os

import httpx
import pytest

from hypnex_openai import HypnexOpenAI
from hypnex_openai._constants import ACTIVE_MODELS_URL, DEFAULT_BASE_URL, DEFAULT_MODEL


def test_active_models_registry_reachable():
    r = httpx.get(ACTIVE_MODELS_URL, timeout=15.0)
    assert r.status_code == 200
    payload = r.json()
    assert "models" in payload
    assert len(payload["models"]) > 0
    sample = payload["models"][0]
    # Production uses PascalCase (Id, Name, ModelType, Fee); dev historically
    # used lowercase. Either is acceptable — the SDK normalizes both.
    has_id = "Id" in sample or "id" in sample
    has_name = "Name" in sample or "name" in sample
    has_type = "ModelType" in sample or "type" in sample
    assert has_id and has_name and has_type, f"unexpected schema: {list(sample.keys())}"


def test_health_endpoint_ok():
    health_url = DEFAULT_BASE_URL.rsplit("/api/v1", 1)[0] + "/health"
    r = httpx.get(health_url, timeout=10.0)
    assert r.status_code == 200
    body = r.json()
    assert body.get("status") == "ok"
    assert body.get("model_service", {}).get("status") == "healthy"


def test_active_models_extension_no_auth():
    client = HypnexOpenAI(api_key="dummy-for-public-calls")
    models = client.morpheus.active_models()
    assert len(models) > 0


def test_find_model_returns_known_default():
    client = HypnexOpenAI(api_key="dummy-for-public-calls")
    m = client.morpheus.find_model(DEFAULT_MODEL)
    assert m is not None, f"default model {DEFAULT_MODEL} missing from registry"
    assert m["name"] == DEFAULT_MODEL


def test_models_by_type_llm_nonempty():
    client = HypnexOpenAI(api_key="dummy-for-public-calls")
    llms = client.morpheus.models_by_type("LLM")
    assert len(llms) > 0
    assert all(str(m.get("type")).upper() == "LLM" for m in llms)


def test_models_by_type_embedding_includes_default():
    client = HypnexOpenAI(api_key="dummy-for-public-calls")
    embeds = client.morpheus.models_by_type("EMBEDDING")
    names = [m["name"] for m in embeds]
    assert "text-embedding-bge-m3" in names


def test_missing_api_key_raises():
    saved = os.environ.pop("HYPNEX_API_KEY", None)
    try:
        with pytest.raises(ValueError):
            HypnexOpenAI()
    finally:
        if saved:
            os.environ["HYPNEX_API_KEY"] = saved


def test_base_url_override_via_env(monkeypatch):
    monkeypatch.setenv("HYPNEX_BASE_URL", "https://custom.example.com/v1")
    client = HypnexOpenAI(api_key="dummy")
    assert str(client.base_url).rstrip("/") == "https://custom.example.com/v1"


@pytest.mark.skipif(
    not os.environ.get("HYPNEX_API_KEY"),
    reason="HYPNEX_API_KEY not set; live auth tests skipped",
)
def test_basic_chat_completion_live():
    client = HypnexOpenAI()
    resp = client.chat.completions.create(
        model=DEFAULT_MODEL,
        messages=[{"role": "user", "content": "Reply with exactly the word: pong"}],
        max_tokens=10,
    )
    assert resp.choices[0].message.content
