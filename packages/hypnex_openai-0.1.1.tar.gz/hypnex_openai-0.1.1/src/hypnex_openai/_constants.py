"""Morpheus inference network constants.

Verified live 2026-05-06 against api.mor.org v1.22.0.
"""

# Production API base URL — OpenAI-compatible REST endpoints under /api/v1.
DEFAULT_BASE_URL = "https://api.mor.org/api/v1"

# Public model registry (chain-of-truth, refreshed ~5 min by the API server).
ACTIVE_MODELS_URL = "https://active.mor.org/active_models.json"

# Default fallback models (sourced from production /health endpoint).
DEFAULT_MODEL = "mistral-31-24b"
DEFAULT_TTS_MODEL = "tts-kokoro"
DEFAULT_STT_MODEL = "whisper-1"
DEFAULT_EMBEDDING_MODEL = "text-embedding-bge-m3"

# Environment variable names.
ENV_API_KEY = "HYPNEX_API_KEY"
ENV_BASE_URL = "HYPNEX_BASE_URL"

# Default rate limits (production defaults, 2026-05-06).
DEFAULT_RPM = 60
DEFAULT_TPM = 100_000
