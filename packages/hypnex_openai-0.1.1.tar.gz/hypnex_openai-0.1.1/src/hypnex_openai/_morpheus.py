"""Morpheus-specific extensions: balance, billing, models, keys, wallet.

These endpoints have no OpenAI analogue. Implemented directly with httpx so
we never reach into the OpenAI SDK's private attributes.
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from ._constants import ACTIVE_MODELS_URL


# The active.mor.org registry has historically returned both PascalCase
# (`Id`, `Name`, `ModelType`, `Fee`, `IsDeleted`) and lowercase (`id`,
# `name`, `type`, `fee`) shapes depending on which environment is queried.
# Normalize to a single lowercase form so downstream callers don't care.
_FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "id": ("Id", "id"),
    "name": ("Name", "name"),
    "owner": ("Owner", "owner"),
    "type": ("ModelType", "type", "Type"),
    "fee": ("Fee", "fee"),
    "stake": ("Stake", "stake"),
    "tags": ("Tags", "tags"),
    "created_at": ("CreatedAt", "created_at"),
    "ipfs_cid": ("IpfsCID", "ipfs_cid"),
    "is_deleted": ("IsDeleted", "is_deleted"),
}


def _normalize_model(raw: dict[str, Any]) -> dict[str, Any]:
    """Convert a registry entry to the canonical lowercase shape."""
    out: dict[str, Any] = {}
    for canonical, aliases in _FIELD_ALIASES.items():
        for alias in aliases:
            if alias in raw:
                out[canonical] = raw[alias]
                break
    # Preserve any unknown fields verbatim so callers can still see them.
    for k, v in raw.items():
        if k not in {alias for aliases in _FIELD_ALIASES.values() for alias in aliases}:
            out.setdefault(k, v)
    return out


def _normalize_models(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw_list = payload.get("models", []) or []
    normalized = [_normalize_model(m) for m in raw_list]
    # Filter out tombstoned entries.
    return [m for m in normalized if not m.get("is_deleted")]


def fetch_active_models(timeout: float = 15.0) -> list[dict[str, Any]]:
    """Public, no-auth fetch of the live model registry.

    Convenience function that doesn't require constructing a client. Returns
    normalized lowercase entries with ``is_deleted`` filtered out.
    """
    with httpx.Client(timeout=timeout) as h:
        r = h.get(ACTIVE_MODELS_URL)
        r.raise_for_status()
        return _normalize_models(r.json())


class MorpheusExtensions:
    """Sync extensions accessible at ``client.morpheus``."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 30.0) -> None:
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    # --- billing -------------------------------------------------------------
    def balance(self) -> dict[str, Any]:
        """Return the current MOR balance for the authenticated account."""
        r = self._http.get("/billing/balance")
        r.raise_for_status()
        return r.json()

    def transactions(self, limit: int = 50) -> list[dict[str, Any]]:
        """List recent billing transactions."""
        r = self._http.get("/billing/transactions", params={"limit": limit})
        r.raise_for_status()
        return r.json()

    def spending(self) -> dict[str, Any]:
        """Cumulative spending summary."""
        r = self._http.get("/billing/spending")
        r.raise_for_status()
        return r.json()

    # --- auth ----------------------------------------------------------------
    def me(self) -> dict[str, Any]:
        """Return the authenticated user's profile."""
        r = self._http.get("/auth/me")
        r.raise_for_status()
        return r.json()

    # --- API keys ------------------------------------------------------------
    def list_keys(self) -> list[dict[str, Any]]:
        r = self._http.get("/auth/keys")
        r.raise_for_status()
        return r.json()

    def create_key(self, name: str) -> dict[str, Any]:
        r = self._http.post("/auth/keys", json={"name": name})
        r.raise_for_status()
        return r.json()

    def delete_key(self, key_id: str) -> None:
        r = self._http.delete(f"/auth/keys/{key_id}")
        r.raise_for_status()

    def set_default_key(self, key_id: str) -> dict[str, Any]:
        r = self._http.put(f"/auth/keys/{key_id}/default")
        r.raise_for_status()
        return r.json()

    # --- wallet --------------------------------------------------------------
    def link_wallet(self, address: str, signature: str, message: str) -> dict[str, Any]:
        """Link an Ethereum wallet via SIWE-style signed message."""
        r = self._http.post(
            "/auth/wallet/",
            json={"address": address, "signature": signature, "message": message},
        )
        r.raise_for_status()
        return r.json()

    def get_wallet(self) -> dict[str, Any]:
        r = self._http.get("/auth/wallet/")
        r.raise_for_status()
        return r.json()

    def unlink_wallet(self) -> None:
        r = self._http.delete("/auth/wallet/")
        r.raise_for_status()

    # --- public model registry (no auth required) ---------------------------
    def active_models(self) -> list[dict[str, Any]]:
        """Fetch the live model registry directly from active.mor.org.

        Returns a list of dicts normalized to lowercase keys: ``id``, ``name``,
        ``owner``, ``type`` (LLM/EMBEDDING/TTS/STT), ``fee`` (wei), ``stake``,
        ``tags``, ``created_at``, ``ipfs_cid``. Tombstoned (``is_deleted``)
        entries are filtered out.
        """
        with httpx.Client(timeout=15.0) as h:
            r = h.get(ACTIVE_MODELS_URL)
            r.raise_for_status()
            return _normalize_models(r.json())

    def find_model(self, name: str) -> Optional[dict[str, Any]]:
        """Look up a model by its human-readable name (the value of `model:`)."""
        for m in self.active_models():
            if m.get("name") == name:
                return m
        return None

    def models_by_type(self, model_type: str) -> list[dict[str, Any]]:
        """Filter the registry by type: 'LLM' | 'EMBEDDING' | 'TTS' | 'STT'."""
        t = model_type.upper()
        return [m for m in self.active_models() if str(m.get("type", "")).upper() == t]

    # --- lifecycle -----------------------------------------------------------
    def close(self) -> None:
        self._http.close()


class AsyncMorpheusExtensions:
    """Async version of MorpheusExtensions."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 30.0) -> None:
        self._http = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    async def balance(self) -> dict[str, Any]:
        r = await self._http.get("/billing/balance")
        r.raise_for_status()
        return r.json()

    async def transactions(self, limit: int = 50) -> list[dict[str, Any]]:
        r = await self._http.get("/billing/transactions", params={"limit": limit})
        r.raise_for_status()
        return r.json()

    async def spending(self) -> dict[str, Any]:
        r = await self._http.get("/billing/spending")
        r.raise_for_status()
        return r.json()

    async def me(self) -> dict[str, Any]:
        r = await self._http.get("/auth/me")
        r.raise_for_status()
        return r.json()

    async def list_keys(self) -> list[dict[str, Any]]:
        r = await self._http.get("/auth/keys")
        r.raise_for_status()
        return r.json()

    async def create_key(self, name: str) -> dict[str, Any]:
        r = await self._http.post("/auth/keys", json={"name": name})
        r.raise_for_status()
        return r.json()

    async def delete_key(self, key_id: str) -> None:
        r = await self._http.delete(f"/auth/keys/{key_id}")
        r.raise_for_status()

    async def set_default_key(self, key_id: str) -> dict[str, Any]:
        r = await self._http.put(f"/auth/keys/{key_id}/default")
        r.raise_for_status()
        return r.json()

    async def link_wallet(self, address: str, signature: str, message: str) -> dict[str, Any]:
        r = await self._http.post(
            "/auth/wallet/",
            json={"address": address, "signature": signature, "message": message},
        )
        r.raise_for_status()
        return r.json()

    async def get_wallet(self) -> dict[str, Any]:
        r = await self._http.get("/auth/wallet/")
        r.raise_for_status()
        return r.json()

    async def unlink_wallet(self) -> None:
        r = await self._http.delete("/auth/wallet/")
        r.raise_for_status()

    async def active_models(self) -> list[dict[str, Any]]:
        async with httpx.AsyncClient(timeout=15.0) as h:
            r = await h.get(ACTIVE_MODELS_URL)
            r.raise_for_status()
            return _normalize_models(r.json())

    async def find_model(self, name: str) -> Optional[dict[str, Any]]:
        for m in await self.active_models():
            if m.get("name") == name:
                return m
        return None

    async def models_by_type(self, model_type: str) -> list[dict[str, Any]]:
        t = model_type.upper()
        return [m for m in await self.active_models() if str(m.get("type", "")).upper() == t]

    async def aclose(self) -> None:
        await self._http.aclose()
