"""Hypnex — the developer toolkit for the Morpheus AI inference network.

`hypnex-openai` is the OpenAI-compatible client. It subclasses ``openai.OpenAI``
and routes every call through ``https://api.mor.org/api/v1`` (the Morpheus
inference marketplace), paid in MOR.

Quickstart:

    from hypnex_openai import HypnexOpenAI

    client = HypnexOpenAI(api_key="mor_...")  # or set HYPNEX_API_KEY env var
    r = client.chat.completions.create(
        model="mistral-31-24b",
        messages=[{"role": "user", "content": "Hello"}],
    )
    print(r.choices[0].message.content)

The class subclasses openai.OpenAI; everything that works with the OpenAI SDK
(streaming, tools, async, structured output) just works.

Morpheus-specific endpoints live under ``client.morpheus``:

    client.morpheus.balance()           # MOR balance
    client.morpheus.active_models()     # live model registry
    client.morpheus.find_model("glm-5") # registry lookup
"""

from ._constants import (
    ACTIVE_MODELS_URL,
    DEFAULT_BASE_URL,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_MODEL,
    DEFAULT_STT_MODEL,
    DEFAULT_TTS_MODEL,
)
from .client import AsyncHypnexOpenAI, HypnexOpenAI

__version__ = "0.1.0"

__all__ = [
    "HypnexOpenAI",
    "AsyncHypnexOpenAI",
    "ACTIVE_MODELS_URL",
    "DEFAULT_BASE_URL",
    "DEFAULT_MODEL",
    "DEFAULT_EMBEDDING_MODEL",
    "DEFAULT_TTS_MODEL",
    "DEFAULT_STT_MODEL",
    "__version__",
]
