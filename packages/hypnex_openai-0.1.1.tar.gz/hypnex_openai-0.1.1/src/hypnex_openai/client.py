"""HypnexOpenAI — drop-in OpenAI client routed to api.mor.org."""

from __future__ import annotations

import os
from typing import Any, Optional

from openai import AsyncOpenAI, OpenAI

from ._constants import DEFAULT_BASE_URL, ENV_API_KEY, ENV_BASE_URL
from ._morpheus import AsyncMorpheusExtensions, MorpheusExtensions


def _resolve_credentials(
    api_key: Optional[str],
    base_url: Optional[str],
) -> tuple[str, str]:
    api_key = api_key or os.environ.get(ENV_API_KEY)
    if not api_key:
        raise ValueError(
            "Morpheus API key not provided. Pass api_key=... or set the "
            f"{ENV_API_KEY} environment variable. Get a key at https://app.mor.org"
        )
    base_url = base_url or os.environ.get(ENV_BASE_URL, DEFAULT_BASE_URL)
    return api_key, base_url


class HypnexOpenAI(OpenAI):
    """Drop-in OpenAI client routed to the Morpheus decentralized inference network.

    Subclasses ``openai.OpenAI`` with a Morpheus base URL and key. Everything
    that works with the OpenAI SDK (streaming, tools, async, structured
    output, retries) just works.

    Example:

        from hypnex_openai import HypnexOpenAI

        client = HypnexOpenAI(api_key="mor_...")
        r = client.chat.completions.create(
            model="mistral-31-24b",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(r.choices[0].message.content)

    Morpheus-specific endpoints live under ``client.morpheus``:

        client.morpheus.balance()
        client.morpheus.active_models()
        client.morpheus.find_model("glm-5")
    """

    morpheus: MorpheusExtensions

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = 60.0,
        **kwargs: Any,
    ) -> None:
        api_key, base_url = _resolve_credentials(api_key, base_url)
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, **kwargs)
        # Use the same timeout for the extensions HTTP client; default 30s if None.
        ext_timeout = timeout if timeout is not None else 30.0
        self.morpheus = MorpheusExtensions(
            base_url=base_url, api_key=api_key, timeout=ext_timeout
        )


class AsyncHypnexOpenAI(AsyncOpenAI):
    """Async drop-in OpenAI client routed to the Morpheus inference network.

    Mirrors ``openai.AsyncOpenAI``.
    """

    morpheus: AsyncMorpheusExtensions

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = 60.0,
        **kwargs: Any,
    ) -> None:
        api_key, base_url = _resolve_credentials(api_key, base_url)
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, **kwargs)
        ext_timeout = timeout if timeout is not None else 30.0
        self.morpheus = AsyncMorpheusExtensions(
            base_url=base_url, api_key=api_key, timeout=ext_timeout
        )
