"""hypnex CLI: list models, check health, send a one-shot completion.

Usage:
    hypnex models
    hypnex health
    hypnex chat "Hello" --model glm-5
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import httpx

from ._constants import DEFAULT_BASE_URL, DEFAULT_MODEL, ENV_API_KEY
from ._morpheus import fetch_active_models


def _cmd_models(_: argparse.Namespace) -> int:
    models = fetch_active_models()
    print(f"{len(models)} active models on the Morpheus network:\n")
    for m in models:
        fee_mor = (m.get("fee") or 0) / 1e18
        name = m.get("name", "?")
        mtype = m.get("type", "?")
        print(f"  {name:<42} type={mtype:<10} fee={fee_mor:.4f} MOR")
    return 0


def _cmd_health(_: argparse.Namespace) -> int:
    health_url = DEFAULT_BASE_URL.rsplit("/api/v1", 1)[0] + "/health"
    r = httpx.get(health_url, timeout=10.0)
    r.raise_for_status()
    print(json.dumps(r.json(), indent=2))
    return 0


def _cmd_chat(args: argparse.Namespace) -> int:
    api_key = args.api_key or os.environ.get(ENV_API_KEY)
    if not api_key:
        print(
            f"error: set {ENV_API_KEY} env var or pass --api-key. "
            "Get one at https://app.mor.org",
            file=sys.stderr,
        )
        return 2
    from .client import HypnexOpenAI

    client = HypnexOpenAI(api_key=api_key)
    resp = client.chat.completions.create(
        model=args.model,
        messages=[{"role": "user", "content": args.prompt}],
    )
    print(resp.choices[0].message.content)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="hypnex",
        description="CLI for the Morpheus decentralized inference network",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("models", help="List active models").set_defaults(fn=_cmd_models)
    sub.add_parser("health", help="Show api.mor.org health").set_defaults(fn=_cmd_health)

    chat_p = sub.add_parser("chat", help="One-shot chat completion")
    chat_p.add_argument("prompt", help="User prompt")
    chat_p.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Model name (default: {DEFAULT_MODEL})",
    )
    chat_p.add_argument(
        "--api-key",
        default=None,
        help=f"Override {ENV_API_KEY} env var",
    )
    chat_p.set_defaults(fn=_cmd_chat)

    args = p.parse_args(argv)
    return int(args.fn(args))


if __name__ == "__main__":
    raise SystemExit(main())
