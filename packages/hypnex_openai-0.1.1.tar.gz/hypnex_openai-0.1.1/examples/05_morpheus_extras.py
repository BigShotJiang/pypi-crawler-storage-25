"""Demonstrate Morpheus-specific endpoints (no OpenAI equivalent).

Most of these require a valid HYPNEX_API_KEY:
  - balance() / transactions() / spending()
  - me() / list_keys() / create_key() / delete_key()
  - link_wallet() / get_wallet() / unlink_wallet()

These do NOT require auth (they hit the public registry):
  - active_models() / find_model() / models_by_type()

Run:  python examples/05_morpheus_extras.py
"""

import os

from hypnex_openai import HypnexOpenAI

# A dummy key works for the public registry calls. Use a real key for
# authenticated endpoints.
client = HypnexOpenAI(
    api_key=os.environ.get("HYPNEX_API_KEY", "dummy-for-public-calls")
)

print("First 10 active models:\n")
for m in client.morpheus.active_models()[:10]:
    fee_mor = (m.get("fee") or 0) / 1e18
    print(f"  {m['name']:<42} type={m['type']:<10} fee={fee_mor:.4f} MOR")

print("\nLLMs only:")
for m in client.morpheus.models_by_type("LLM"):
    print(f"  {m['name']}")

print("\nLook up a specific model:")
mistral = client.morpheus.find_model("mistral-31-24b")
print(f"  mistral-31-24b → owner {mistral['owner']}" if mistral else "  not found")

if os.environ.get("HYPNEX_API_KEY"):
    print("\nAuthenticated calls:")
    try:
        print(f"  me():      {client.morpheus.me()}")
        print(f"  balance(): {client.morpheus.balance()}")
    except Exception as e:
        print(f"  call failed (likely invalid API key): {e}")
else:
    print("\n(set HYPNEX_API_KEY to also see balance / me / keys)")
