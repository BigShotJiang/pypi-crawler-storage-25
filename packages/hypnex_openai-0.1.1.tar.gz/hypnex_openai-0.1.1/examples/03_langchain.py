"""LangChain integration — point ChatOpenAI at Morpheus.

ChatOpenAI accepts a base_url and api_key, so swapping providers is a
2-line change. Use any Morpheus model in the `model=` field.

Install:  pip install langchain langchain-openai
Run:      HYPNEX_API_KEY=mor_... python examples/03_langchain.py
"""

import os

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="qwen3-235b",
    api_key=os.environ["HYPNEX_API_KEY"],
    base_url="https://api.mor.org/api/v1",
    temperature=0.7,
)

response = llm.invoke(
    [
        SystemMessage(content="You are concise."),
        HumanMessage(content="Why is decentralized inference important?"),
    ]
)
print(response.content)
