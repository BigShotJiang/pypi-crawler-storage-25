"""Embeddings via the Morpheus network.

Run:  HYPNEX_API_KEY=mor_... python examples/08_embeddings.py
"""

import os

from hypnex_openai import HypnexOpenAI

client = HypnexOpenAI(api_key=os.environ["HYPNEX_API_KEY"])

resp = client.embeddings.create(
    model="text-embedding-bge-m3",
    input=[
        "Morpheus is a decentralized AI network.",
        "Bittensor is a decentralized ML network.",
    ],
)

for i, item in enumerate(resp.data):
    vec = item.embedding
    print(f"vector {i}: dim={len(vec)} first5={vec[:5]}")
