"""Basic chat completion against the Morpheus inference network.

Run:  HYPNEX_API_KEY=mor_... python examples/01_basic_chat.py
Get a key at https://app.mor.org.
"""

import os

from hypnex_openai import HypnexOpenAI

client = HypnexOpenAI(api_key=os.environ["HYPNEX_API_KEY"])

response = client.chat.completions.create(
    model="mistral-31-24b",
    messages=[
        {"role": "system", "content": "You are a concise assistant."},
        {"role": "user", "content": "Explain Morpheus AI in one sentence."},
    ],
)

print(response.choices[0].message.content)
