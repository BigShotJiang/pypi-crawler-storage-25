"""CrewAI integration — replace OpenAI LLM with Morpheus.

CrewAI uses a "provider/model" naming convention; "openai/<morpheus-model>"
routes through the OpenAI-compatible client at the supplied base_url.

Install:  pip install crewai
Run:      HYPNEX_API_KEY=mor_... python examples/04_crewai.py
"""

import os

from crewai import LLM, Agent, Crew, Task

morpheus_llm = LLM(
    model="openai/qwen3-coder-480b-a35b-instruct",
    api_key=os.environ["HYPNEX_API_KEY"],
    base_url="https://api.mor.org/api/v1",
)

researcher = Agent(
    role="Researcher",
    goal="Produce concise, accurate summaries.",
    backstory="A meticulous researcher who values brevity.",
    llm=morpheus_llm,
    allow_delegation=False,
)

task = Task(
    description="Summarize the four pools of the Morpheus protocol.",
    expected_output="A 3-sentence summary covering Capital, Code, Compute, Community.",
    agent=researcher,
)

crew = Crew(agents=[researcher], tasks=[task], verbose=False)
print(crew.kickoff())
