"""Tool / function calling. Works with any Morpheus model that supports tools.

Run:  HYPNEX_API_KEY=mor_... python examples/07_tools.py
"""

import json
import os

from hypnex_openai import HypnexOpenAI

client = HypnexOpenAI(api_key=os.environ["HYPNEX_API_KEY"])

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get the current weather for a city.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name"},
                    "units": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "default": "celsius",
                    },
                },
                "required": ["city"],
            },
        },
    }
]


def get_weather(city: str, units: str = "celsius") -> dict:
    return {"city": city, "temp": 22 if units == "celsius" else 72, "units": units}


messages = [{"role": "user", "content": "What's the weather in Paris?"}]

resp = client.chat.completions.create(
    model="qwen3-coder-480b-a35b-instruct",
    messages=messages,
    tools=tools,
)

msg = resp.choices[0].message

if msg.tool_calls:
    for call in msg.tool_calls:
        args = json.loads(call.function.arguments)
        result = get_weather(**args)
        messages.append(msg.model_dump())
        messages.append(
            {
                "role": "tool",
                "tool_call_id": call.id,
                "content": json.dumps(result),
            }
        )

    final = client.chat.completions.create(
        model="qwen3-coder-480b-a35b-instruct",
        messages=messages,
        tools=tools,
    )
    print(final.choices[0].message.content)
else:
    print(msg.content)
