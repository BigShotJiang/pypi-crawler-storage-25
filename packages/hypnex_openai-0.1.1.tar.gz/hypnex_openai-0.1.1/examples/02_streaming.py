"""Streaming chat completion (SSE).

Run:  HYPNEX_API_KEY=mor_... python examples/02_streaming.py
"""

import os

from hypnex_openai import HypnexOpenAI

client = HypnexOpenAI(api_key=os.environ["HYPNEX_API_KEY"])

stream = client.chat.completions.create(
    model="qwen3-235b",
    messages=[{"role": "user", "content": "Count from 1 to 10, one per line."}],
    stream=True,
)

for chunk in stream:
    delta = chunk.choices[0].delta
    if delta and delta.content:
        print(delta.content, end="", flush=True)
print()
