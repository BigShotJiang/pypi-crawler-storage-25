"""Async client example.

Run:  HYPNEX_API_KEY=mor_... python examples/06_async.py
"""

import asyncio
import os

from hypnex_openai import AsyncHypnexOpenAI


async def main() -> None:
    client = AsyncHypnexOpenAI(api_key=os.environ["HYPNEX_API_KEY"])
    try:
        # Run two requests concurrently.
        a, b = await asyncio.gather(
            client.chat.completions.create(
                model="mistral-31-24b",
                messages=[{"role": "user", "content": "Say hello in French."}],
            ),
            client.chat.completions.create(
                model="qwen3-235b",
                messages=[{"role": "user", "content": "Say hello in Japanese."}],
            ),
        )
        print("mistral:", a.choices[0].message.content)
        print("qwen:   ", b.choices[0].message.content)
    finally:
        await client.close()
        await client.morpheus.aclose()


if __name__ == "__main__":
    asyncio.run(main())
