# hypnex-openai (Python)

Drop-in OpenAI client for the Morpheus decentralized inference network ([mor.org](https://mor.org)).

```bash
pip install hypnex-openai
```

## Affiliation & monetization

This SDK is published by **Hypnex Labs**. It is a thin OpenAI-compatible client; calls go directly to `api.mor.org` and are billed by Morpheus AI to the API-key holder. **This SDK does not currently route fees to Hypnex Labs.** Hypnex's revenue comes from the sister SDK `hypnex-staking` (MRC 73 capital referral) and the `stake.hypnex.xyz` onramp. Hypnex is not affiliated with the Morpheus AI Foundation.

```python
from hypnex_openai import HypnexOpenAI

client = HypnexOpenAI(api_key="mor_...")  # get one at https://app.mor.org

response = client.chat.completions.create(
    model="mistral-31-24b",
    messages=[{"role": "user", "content": "Hello"}],
)
print(response.choices[0].message.content)
```

`HypnexOpenAI` subclasses `openai.OpenAI` and points it at `https://api.mor.org/api/v1`. Streaming, tools, async, structured output — all work unchanged.

## Models on the Morpheus network

The network exposes 60+ models via OpenAI-compatible endpoints. List them:

```bash
hypnex models
```

Or programmatically:

```python
client.morpheus.active_models()           # full registry
client.morpheus.models_by_type("LLM")     # filter
client.morpheus.find_model("glm-5")       # lookup
```

Featured LLMs: `mistral-31-24b`, `glm-5`, `qwen3-235b`, `qwen3-coder-480b-a35b-instruct`, `deepseek-r1:70b`, `minimax-m25`. Embeddings: `text-embedding-bge-m3`. TTS: `tts-kokoro`. STT: `whisper-1`.

## Drop-in for popular frameworks

Any framework that accepts a `base_url` accepts Morpheus:

```python
# LangChain
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(
    model="qwen3-235b",
    api_key=os.environ["HYPNEX_API_KEY"],
    base_url="https://api.mor.org/api/v1",
)

# CrewAI
from crewai import LLM
llm = LLM(
    model="openai/qwen3-235b",
    api_key=os.environ["HYPNEX_API_KEY"],
    base_url="https://api.mor.org/api/v1",
)

# llama-index
from llama_index.llms.openai_like import OpenAILike
llm = OpenAILike(
    model="qwen3-235b",
    api_base="https://api.mor.org/api/v1",
    api_key=os.environ["HYPNEX_API_KEY"],
    is_chat_model=True,
)

# instructor
import instructor
client = instructor.from_openai(HypnexOpenAI())
```

## Morpheus-specific endpoints

`client.morpheus.*` exposes endpoints that have no OpenAI equivalent:

| Method | What it does |
|---|---|
| `balance()` | Current MOR balance |
| `transactions(limit=50)` | Billing history |
| `spending()` | Cumulative usage |
| `me()` | User profile |
| `list_keys()` / `create_key(name)` / `delete_key(id)` / `set_default_key(id)` | API keys |
| `link_wallet(addr, sig, msg)` / `get_wallet()` / `unlink_wallet()` | Wallet binding |
| `active_models()` / `find_model(name)` / `models_by_type(type)` | Public registry |

## CLI

```bash
hypnex models                          # list
hypnex health                          # show api.mor.org health
hypnex chat "Hello" --model glm-5      # one-shot
```

## Async

```python
from hypnex_openai import AsyncHypnexOpenAI
client = AsyncHypnexOpenAI(api_key="mor_...")
r = await client.chat.completions.create(...)
```

## Environment

- `HYPNEX_API_KEY` — your API key (required)
- `HYPNEX_BASE_URL` — override base URL (default `https://api.mor.org/api/v1`)

## Tests

```bash
pip install -e ".[dev]"
pytest                                   # public smoke tests
HYPNEX_API_KEY=mor_... pytest          # also run authenticated tests
```

## License

MIT
