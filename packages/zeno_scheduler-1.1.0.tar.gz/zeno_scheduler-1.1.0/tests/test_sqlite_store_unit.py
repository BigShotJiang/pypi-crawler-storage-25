"""SQLite-specific tests for SqliteScheduleStore.

These tests exercise properties that only make sense for the SQLite adapter:
WAL mode, file permissions, persistence across instances, and migration order.
"""

from __future__ import annotations

import os
from pathlib import Path

import aiosqlite
import pytest
from zeno.scheduler.sqlite.store import SqliteScheduleStore
from zeno.scheduler.types import TriggerRow

_BASE_TS = 1_700_000_000


def _make_row(
    id: str = "01TEST0000000000000000001",
    user_id: str = "user-A",
    name: str | None = None,
    next_fire_at: int = _BASE_TS + 60,
) -> TriggerRow:
    return TriggerRow(
        id=id,
        user_id=user_id,
        thread_key=None,
        channel_ref="cli://default",
        kind="one_shot",
        name=name,
        prompt="Say hello",
        metadata={},
        spec="@once",
        next_fire_at=next_fire_at,
        fire_count=0,
        max_fires=1,
        on_missed="drop",
        status="active",
        created_at=_BASE_TS,
    )


@pytest.mark.asyncio
async def test_wal_sidecar_files_appear_with_open_connection(tmp_path: Path) -> None:
    """WAL sidecar files (*.db-wal, *.db-shm) exist while a connection is open."""
    db = tmp_path / "triggers.db"
    store = SqliteScheduleStore(db)
    # Initialize the store (creates DB + WAL mode).
    await store.count_active("__init__")

    # Open a direct connection; WAL files must be present while it's live.
    async with aiosqlite.connect(str(db)) as conn:
        await conn.execute("PRAGMA journal_mode=WAL")
        wal = Path(str(db) + "-wal")
        shm = Path(str(db) + "-shm")
        assert wal.exists() or shm.exists(), (
            f"expected at least one WAL sidecar ({wal.name} or {shm.name})"
        )


@pytest.mark.asyncio
async def test_journal_mode_is_wal(tmp_path: Path) -> None:
    """PRAGMA journal_mode reports 'wal' after initialization."""
    db = tmp_path / "triggers.db"
    store = SqliteScheduleStore(db)
    await store.count_active("__init__")  # triggers schema init

    async with aiosqlite.connect(str(db)) as conn:
        cur = await conn.execute("PRAGMA journal_mode")
        row = await cur.fetchone()
    assert row is not None
    assert row[0] == "wal"


@pytest.mark.skipif(os.name != "posix", reason="POSIX file mode bits only — Windows uses ACLs")
@pytest.mark.asyncio
async def test_new_db_file_has_0o600_permissions(tmp_path: Path) -> None:
    """A newly-created DB file must have exactly 0o600 permissions (S6)."""
    db = tmp_path / "triggers.db"
    store = SqliteScheduleStore(db)
    await store.count_active("__init__")

    mode = os.stat(str(db)).st_mode & 0o777
    assert mode == 0o600, f"expected 0o600 but got 0o{mode:o}"


@pytest.mark.asyncio
async def test_data_persists_across_instances(tmp_path: Path) -> None:
    """A row inserted via one SqliteScheduleStore instance survives reopening."""
    db = tmp_path / "triggers.db"
    row = _make_row(id="ID-PERSIST")

    store1 = SqliteScheduleStore(db)
    await store1.upsert(row)

    # Create a new instance pointing at the same file.
    store2 = SqliteScheduleStore(db)
    fetched = await store2.get("ID-PERSIST")

    assert fetched is not None
    assert fetched.id == "ID-PERSIST"


@pytest.mark.asyncio
async def test_migration_runner_applies_001_then_002(tmp_path: Path) -> None:
    """Migrations 001 (schema_version) and 002 (triggers) are applied in order."""
    db = tmp_path / "triggers.db"
    store = SqliteScheduleStore(db)
    await store.count_active("__init__")  # force migration

    async with aiosqlite.connect(str(db)) as conn:
        cur = await conn.execute("SELECT version FROM schema_version ORDER BY version ASC")
        versions = [row[0] for row in await cur.fetchall()]

    assert 1 in versions
    assert 2 in versions
    assert versions == sorted(versions)


@pytest.mark.asyncio
async def test_migration_is_idempotent(tmp_path: Path) -> None:
    """Re-opening the DB after schema is already current is a no-op."""
    db = tmp_path / "triggers.db"
    store1 = SqliteScheduleStore(db)
    await store1.count_active("__init__")

    # Second open should not raise.
    store2 = SqliteScheduleStore(db)
    await store2.count_active("__init__")

    async with aiosqlite.connect(str(db)) as conn:
        cur = await conn.execute("SELECT COUNT(*) FROM schema_version")
        row = await cur.fetchone()
    # Exactly 2 migrations recorded (001 and 002), not duplicated.
    assert row is not None
    assert row[0] == 2
