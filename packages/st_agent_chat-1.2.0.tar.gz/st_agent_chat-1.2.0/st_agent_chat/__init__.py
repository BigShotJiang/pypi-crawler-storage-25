"""
st-agent-chat — Drop-in agentic AI chat widget for Streamlit.

Usage:
    from st_agent_chat import agent_chat
    agent_chat(workspace=".", provider="anthropic")
"""
from st_agent_chat.component import agent_chat
from st_agent_chat.engine import (
    AgentEngine,
    AgentResult,
    SubagentConfig,
    UsageSummary,
    save_session,
    load_session,
    list_sessions,
)
from st_agent_chat.tools import execute_tool, TOOL_SCHEMAS, ToolResult
from st_agent_chat.llm import (
    LLMClient,
    LLMConfig,
    ALL_ANTHROPIC_MODELS,
    ALL_OPENAI_MODELS,
    ALL_GOOGLE_MODELS,
    ALL_PERPLEXITY_MODELS,
    ALL_REPLICATE_MODELS,
    ALL_OPENROUTER_MODELS,
)

__all__ = [
    "agent_chat",
    "AgentEngine",
    "AgentResult",
    "SubagentConfig",
    "UsageSummary",
    "save_session",
    "load_session",
    "list_sessions",
    "execute_tool",
    "TOOL_SCHEMAS",
    "ToolResult",
    "LLMClient",
    "LLMConfig",
    "ALL_ANTHROPIC_MODELS",
    "ALL_OPENAI_MODELS",
    "ALL_GOOGLE_MODELS",
    "ALL_PERPLEXITY_MODELS",
    "ALL_REPLICATE_MODELS",
    "ALL_OPENROUTER_MODELS",
]
__version__ = "1.2.0"
