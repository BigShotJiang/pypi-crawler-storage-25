"""Compatibility package for challenge-specific import path.

This allows:
    from mongodb_ai_widgets_challenge import MongoDBChallenge
"""

from pathlib import Path
import importlib
import sys

# Ensure sibling local package takes precedence over site-packages.
_project_root = Path(__file__).resolve().parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

# If mongodb_ai_widgets is already imported from site-packages in this kernel,
# drop it so we can import the local project package.
_loaded_pkg = sys.modules.get("mongodb_ai_widgets")
if _loaded_pkg is not None:
    _loaded_from = Path(getattr(_loaded_pkg, "__file__", "")).resolve()
    if _project_root not in _loaded_from.parents:
        del sys.modules["mongodb_ai_widgets"]

MongoDBChallenge = importlib.import_module("mongodb_ai_widgets").MongoDBChallenge  # type: ignore[attr-defined]

__all__ = [
    "MongoDBChallenge",
]
