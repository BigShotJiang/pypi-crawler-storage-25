"""Challenge-specific import path.

This allows:
    from mongodb_ai_widget_challenge import MongoDBChallenge
"""

from mongodb_ai_widgets import MongoDBChallenge

__all__ = [
    "MongoDBChallenge",
]
