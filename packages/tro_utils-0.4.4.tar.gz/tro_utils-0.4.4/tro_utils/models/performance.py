"""TrustedResearchPerformance and PerformanceAttribute models."""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Any

from ._base import TROVModel


@dataclass
class ArrangementBinding(TROVModel):
    """Maps an arrangement to a specific mount path for a particular performance.

    An intermediate RDF object (``trov:ArrangementBinding``) that associates an
    :class:`~tro_utils.models.arrangement.ArtifactArrangement` with a mount path
    scoped to one :class:`TrustedResearchPerformance`, avoiding the ambiguity that
    arises when the same arrangement is mounted at different paths in different
    performances.

    Analogous to ``trov:ArtifactLocation`` for arrangements.
    """

    binding_id: str
    arrangement_id: str
    path: str | None = None

    # ------------------------------------------------------------------
    # JSON-LD serialisation
    # ------------------------------------------------------------------

    def to_jsonld(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "@id": self.binding_id,
            "@type": "trov:ArrangementBinding",
            "trov:arrangement": {"@id": self.arrangement_id},
        }
        if self.path is not None:
            result["trov:boundTo"] = self.path
        return result

    @classmethod
    def from_jsonld(cls, data: dict[str, Any]) -> "ArrangementBinding":
        return cls(
            binding_id=data["@id"],
            arrangement_id=data["trov:arrangement"]["@id"],
            path=data.get("trov:boundTo"),
        )


@dataclass
class PerformanceAttribute(TROVModel):
    """A single attribute of a :class:`TrustedResearchPerformance`.

    Warranted by a :class:`~tro_utils.models.trs.TRSCapability`.
    """

    attribute_id: str
    attribute_type: str
    warranted_by_id: str

    # ------------------------------------------------------------------
    # JSON-LD serialisation
    # ------------------------------------------------------------------

    def to_jsonld(self) -> dict[str, Any]:
        return {
            "@id": self.attribute_id,
            "@type": self.attribute_type,
            "trov:warrantedBy": {"@id": self.warranted_by_id},
        }

    @classmethod
    def from_jsonld(cls, data: dict[str, Any]) -> "PerformanceAttribute":
        return cls(
            attribute_id=data["@id"],
            attribute_type=data["@type"],
            warranted_by_id=data["trov:warrantedBy"]["@id"],
        )


@dataclass
class TrustedResearchPerformance(TROVModel):
    """A record of a single execution run within a TRO."""

    performance_id: str
    comment: str = ""
    conducted_by_id: str = "trs"
    started_at: datetime.datetime | None = None
    ended_at: datetime.datetime | None = None
    accessed_arrangements: list[ArrangementBinding] = field(default_factory=list)
    contributed_to_arrangements: list[ArrangementBinding] = field(default_factory=list)
    attributes: list[PerformanceAttribute] = field(default_factory=list)
    extra_attributes: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # JSON-LD serialisation
    # ------------------------------------------------------------------

    def to_jsonld(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "@id": self.performance_id,
            "@type": "trov:TrustedResearchPerformance",
            "rdfs:comment": self.comment,
            "trov:wasConductedBy": {"@id": self.conducted_by_id},
            "trov:hasPerformanceAttribute": [
                attr.to_jsonld() for attr in self.attributes
            ],
        }
        if self.started_at is not None:
            result["trov:startedAtTime"] = self.started_at.isoformat()
        if self.ended_at is not None:
            result["trov:endedAtTime"] = self.ended_at.isoformat()
        if len(self.accessed_arrangements) == 1:
            result["trov:accessedArrangement"] = self.accessed_arrangements[
                0
            ].to_jsonld()
        elif len(self.accessed_arrangements) > 1:
            result["trov:accessedArrangement"] = [
                ref.to_jsonld() for ref in self.accessed_arrangements
            ]
        if len(self.contributed_to_arrangements) == 1:
            result["trov:contributedToArrangement"] = self.contributed_to_arrangements[
                0
            ].to_jsonld()
        elif len(self.contributed_to_arrangements) > 1:
            result["trov:contributedToArrangement"] = [
                ref.to_jsonld() for ref in self.contributed_to_arrangements
            ]
        if self.extra_attributes:
            result.update(self.extra_attributes)
        return result

    @classmethod
    def from_jsonld(cls, data: dict[str, Any]) -> "TrustedResearchPerformance":
        """Deserialise from a JSON-LD performance dict.

        Args:
            data: Dict with ``@id``, optional timing keys, arrangement refs, etc.

        Returns:
            :class:`TrustedResearchPerformance` instance.
        """

        def _parse_dt(value: str | None) -> datetime.datetime | None:
            if value is None:
                return None
            return datetime.datetime.fromisoformat(value)

        attributes = [
            PerformanceAttribute.from_jsonld(attr)
            for attr in data.get("trov:hasPerformanceAttribute", [])
        ]

        def _parse_refs(value: Any) -> list[ArrangementBinding]:
            if value is None:
                return []
            if isinstance(value, list):
                return [ArrangementBinding.from_jsonld(item) for item in value]
            return [ArrangementBinding.from_jsonld(value)]

        known_keys = {
            "@id",
            "@type",
            "rdfs:comment",
            "trov:wasConductedBy",
            "trov:hasPerformanceAttribute",
            "trov:startedAtTime",
            "trov:endedAtTime",
            "trov:accessedArrangement",
            "trov:contributedToArrangement",
        }
        extra = {k: v for k, v in data.items() if k not in known_keys}

        return cls(
            performance_id=data["@id"],
            comment=data.get("rdfs:comment", ""),
            conducted_by_id=data.get("trov:wasConductedBy", {}).get("@id", "trs"),
            started_at=_parse_dt(data.get("trov:startedAtTime")),
            ended_at=_parse_dt(data.get("trov:endedAtTime")),
            accessed_arrangements=_parse_refs(data.get("trov:accessedArrangement")),
            contributed_to_arrangements=_parse_refs(
                data.get("trov:contributedToArrangement")
            ),
            attributes=attributes,
            extra_attributes=extra,
        )
