"""OrderBookUpdate, TradeEvent (scaffold)."""
