"""PricePoint, Candle, HistoricalTrade (scaffold)."""
