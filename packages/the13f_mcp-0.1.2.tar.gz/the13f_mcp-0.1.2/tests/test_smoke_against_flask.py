"""Smoke test: MCP Read tools talk to the live Flask `manager_bp` endpoints.

Wires the MCP's lazy httpx client to an in-process Flask app via
httpx.WSGITransport so we can validate, without a real network:

  * each of the 9 v0.1.0 Read tools resolves to a real endpoint on
    /api/v1/managers/ or /api/v1/similarity/ or /api/v1/signals/,
  * the response shape the MCP expects matches what the Flask handler
    actually returns,
  * the disclaimer wrapper is applied to every tool result.

`utils.api_data_provider` is monkeypatched with in-memory fakes so the test
needs no parquet files on disk.

**This is a monorepo integration test, not a package unit test.** It depends
on `flask` and the project's `gui.routes` / `utils.api_data_provider` being
importable, neither of which the `the13f-mcp` PyPI package declares as
dependencies. When the whole the13f project venv is on sys.path (local `pytest
mcp_server/tests/`) it runs and validates the contract; when only the MCP
package's own `[dev]` deps are installed (CI's `cd mcp_server && pip install
-e .[dev] && pytest`), every test here skips via `pytest.importorskip`.

If this file's 11 tests all pass, we have high confidence the MCP can point
at api.the13f.com in production and the schemas line up.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# Skip the entire module in environments where flask + the repo-root
# project utilities are not importable. Matches the design intent: this
# test file is a monorepo integration check, not a package unit test.
# See the docstring above for the full rationale.
flask = pytest.importorskip("flask")
pytest.importorskip("httpx")

HERE = Path(__file__).resolve().parent
MCP_SRC = HERE.parent / "src"
REPO_ROOT = HERE.parents[2]  # .../13f/
for p in (str(MCP_SRC), str(REPO_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

# Confirm the repo-root helpers the test fixtures rely on are importable too.
# If the MCP package is installed standalone (no repo-root project on path),
# this raises ModuleNotFoundError inside importorskip and the whole module
# skips cleanly - exactly the behaviour we want on the PyPI-package CI.
pytest.importorskip("gui.routes.manager_routes")
pytest.importorskip("gui.routes.case_study_routes")
pytest.importorskip("utils.api_data_provider")


_FAKE_QUARTERS = ["q4y2025", "q3y2025", "q2y2025", "q1y2025"]
_FAKE_MANAGERS = [
    {
        "cik": "0001037389",
        "name": "Renaissance Technologies Llc",
        "latest_aum": 64_461_244_358.0,
        "available_quarters": _FAKE_QUARTERS,
        "n_private_funds": 4,
        "entity_type": "Hedge Fund Manager",
    },
    {
        "cik": "0001067983",
        "name": "Berkshire Hathaway Inc",
        "latest_aum": 300_000_000_000.0,
        "available_quarters": _FAKE_QUARTERS,
        "n_private_funds": None,
        "entity_type": "Insurance Company",
    },
]


@pytest.fixture
def app_and_client(monkeypatch, tmp_path):
    """Assemble a Flask app with manager + similarity + signal blueprints,
    monkeypatch data_provider, and route the MCP http_client at it."""
    import httpx

    monkeypatch.setenv("THE13F_DEVELOPER_DB_PATH", str(tmp_path / "dev.db"))
    monkeypatch.setenv("THE13F_API_KEY", "pf13f_smoketest_fake_key")
    monkeypatch.setenv("THE13F_API_BASE_URL", "http://testserver")

    import flask

    import utils.api_data_provider as data_provider

    monkeypatch.setattr(
        data_provider, "list_available_quarters",
        lambda newest_first=True: list(_FAKE_QUARTERS) if newest_first else list(reversed(_FAKE_QUARTERS)),
    )
    monkeypatch.setattr(
        data_provider, "search_managers",
        lambda q, limit=10: [m for m in _FAKE_MANAGERS if q.lower() in m["name"].lower()][:limit],
    )

    def fake_get_all_managers(active_only=False):
        return {
            "count": len(_FAKE_MANAGERS),
            "latest_quarter": _FAKE_QUARTERS[0],
            "total_quarters": len(_FAKE_QUARTERS),
            "managers": list(_FAKE_MANAGERS),
        }
    monkeypatch.setattr(data_provider, "get_all_managers", fake_get_all_managers)

    def fake_holdings(cik, quarter, map_tickers=True):
        return {
            "manager": {"cik": cik, "name": f"Fake Manager {cik}"},
            "quarter": quarter,
            "holdings": [
                {"ticker": "AAPL.US", "weight": 0.5, "value": 1_000_000.0, "shares": 1_000},
                {"ticker": "MSFT.US", "weight": 0.5, "value": 1_000_000.0, "shares": 1_000},
            ],
            "total_value": 2_000_000.0,
            "n_positions": 2,
        }
    monkeypatch.setattr(data_provider, "get_manager_holdings", fake_holdings)

    from gui.routes.case_study_routes import case_study_bp
    from gui.routes.manager_routes import manager_bp

    app = flask.Flask(__name__)
    app.register_blueprint(manager_bp)
    app.register_blueprint(case_study_bp)

    @app.route("/api/v1/signals/consensus")
    def _fake_consensus():
        return flask.jsonify({
            "quarter": flask.request.args.get("quarter", _FAKE_QUARTERS[0]),
            "count": 2,
            "securities": [
                {"ticker": "AAPL", "weight_pct": 10.2},
                {"ticker": "MSFT", "weight_pct": 9.1},
            ],
        })

    @app.route("/api/v1/signals/regime")
    def _fake_regime():
        return flask.jsonify({
            "quarter": flask.request.args.get("quarter", _FAKE_QUARTERS[0]),
            "iioi_composite": 62.4,
            "regime_state": "High Optimism",
            "transition": None,
        })

    @app.route("/api/v1/signals/sectors")
    def _fake_sectors():
        return flask.jsonify({
            "quarter": flask.request.args.get("quarter", _FAKE_QUARTERS[0]),
            "sectors": [
                {"gics_sector": "Information Technology", "net_capital_flow_thousands": 1_000_000, "risk_posture": "defensive"},
            ],
        })

    @app.route("/api/v1/similarity/match", methods=["POST"])
    def _fake_similarity_match():
        body = flask.request.get_json(silent=True) or {}
        return flask.jsonify({
            "quarter": body.get("quarter", _FAKE_QUARTERS[0]),
            "matches": [
                {"cik": "0001037389", "similarity_score": 0.87},
                {"cik": "0001067983", "similarity_score": 0.61},
            ],
        })

    from the13f_mcp import http_client as mcp_http
    transport = httpx.WSGITransport(app=app)
    client = httpx.Client(
        base_url="http://testserver",
        transport=transport,
        headers={"X-API-Key": "pf13f_smoketest_fake_key"},
    )
    monkeypatch.setattr(mcp_http, "_client", client)

    yield app
    client.close()


def _assert_disclaimer(result):
    assert "disclaimer" in result, f"Response missing disclaimer: {list(result.keys())}"
    assert isinstance(result["disclaimer"], str) and len(result["disclaimer"]) > 0


# ---------------------------------------------------------------------------
# 9 Read tools, one test each
# ---------------------------------------------------------------------------

def test_list_quarters(app_and_client):
    from the13f_mcp import tools
    result = tools.list_quarters()
    _assert_disclaimer(result)
    assert result["quarters"] == _FAKE_QUARTERS
    assert result["latest"] == _FAKE_QUARTERS[0]


def test_search_managers(app_and_client):
    from the13f_mcp import tools
    result = tools.search_managers("renaissance", limit=5)
    _assert_disclaimer(result)
    assert result["query"] == "renaissance"
    assert len(result["results"]) == 1
    assert result["results"][0]["cik"] == "0001037389"


def test_search_managers_min_length_returns_empty(app_and_client):
    from the13f_mcp import tools
    result = tools.search_managers("a")
    _assert_disclaimer(result)
    assert result["results"] == []


def test_get_manager_holdings(app_and_client):
    from the13f_mcp import tools
    result = tools.get_manager_holdings(cik="0001037389", quarter="q4y2025")
    _assert_disclaimer(result)
    assert result["manager"]["cik"] == "0001037389"
    assert result["quarter"] == "q4y2025"
    assert result["n_positions"] == 2
    assert result["total_value"] == 2_000_000.0
    assert len(result["holdings"]) == 2


def test_list_all_managers(app_and_client):
    from the13f_mcp import tools
    result = tools.list_all_managers(active_only=True)
    _assert_disclaimer(result)
    assert result["count"] == 2
    assert len(result["managers"]) == 2


def test_get_manager_holdings_bulk(app_and_client):
    from the13f_mcp import tools
    result = tools.get_manager_holdings_bulk(pairs=[
        {"cik": "0001037389", "quarter": "q4y2025"},
        {"cik": "0001067983", "quarter": "q4y2025"},
    ])
    _assert_disclaimer(result)
    assert result["n_requested"] == 2
    assert result["n_ok"] == 2
    assert result["n_failed"] == 0
    assert all(r["status"] == "ok" for r in result["results"])


def test_find_similar_managers(app_and_client):
    from the13f_mcp import tools
    result = tools.find_similar_managers(
        holdings=[{"ticker": "AAPL", "weight": 0.5}, {"ticker": "MSFT", "weight": 0.5}],
        quarter="q4y2025",
        top_n=5,
    )
    _assert_disclaimer(result)
    assert "matches" in result
    assert len(result["matches"]) == 2


def test_get_consensus_portfolio(app_and_client):
    from the13f_mcp import tools
    result = tools.get_consensus_portfolio(quarter="q4y2025")
    _assert_disclaimer(result)
    assert result["quarter"] == "q4y2025"
    assert len(result["securities"]) == 2


def test_get_market_regime(app_and_client):
    from the13f_mcp import tools
    result = tools.get_market_regime(quarter="q4y2025")
    _assert_disclaimer(result)
    assert result["quarter"] == "q4y2025"
    assert result["iioi_composite"] == 62.4


def test_get_sector_flows(app_and_client):
    from the13f_mcp import tools
    result = tools.get_sector_flows(quarter="q4y2025")
    _assert_disclaimer(result)
    assert result["quarter"] == "q4y2025"
    assert len(result["sectors"]) == 1


def test_free_signup_required_when_key_missing(app_and_client, monkeypatch):
    """If THE13F_API_KEY is unset, tools raise FreeSignupRequiredError with a
    Cloudflare-signup CTA URL pointing at the new /developers/ page."""
    from the13f_mcp import config, http_client, tools
    monkeypatch.delenv("THE13F_API_KEY", raising=False)
    # Clear any cached client so it re-reads the env
    monkeypatch.setattr(http_client, "_client", None)
    with pytest.raises(http_client.FreeSignupRequiredError) as exc_info:
        tools.list_quarters()
    assert config.SIGNUP_URL in str(exc_info.value)
    assert "the13f.com/developers" in config.SIGNUP_URL


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
