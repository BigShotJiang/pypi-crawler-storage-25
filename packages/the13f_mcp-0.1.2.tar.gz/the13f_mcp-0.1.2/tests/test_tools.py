"""Tests for the MCP server's tool catalog and envelope shapes.

The host LLM only sees what `_tool_definitions()` returns, so these tests
guard the contract: every tool has a non-empty description, the compliance
prefix is present, and the JSON Schema for inputs is well-formed.

v0.1.0 ships the Read tier only (9 tools). Signal (v0.2.0) and Report
(v0.3.0) tools are documented in the13f_2_0/mcp_server/ but not here.
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MCP_SRC = HERE.parent / "src"
REPO_ROOT = HERE.parents[2]  # .../13f/
for p in (str(MCP_SRC), str(REPO_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)


def test_nine_read_tier_tools_registered():
    """v0.1.0 ships exactly the 9 Read-tier tools - no signals, no reports."""
    from the13f_mcp.server import _tool_definitions
    tool_defs = _tool_definitions()
    assert len(tool_defs) == 9
    names = {t.name for t in tool_defs}
    expected = {
        "list_quarters",
        "search_managers",
        "get_manager_holdings",
        "get_manager_holdings_bulk",
        "list_all_managers",
        "find_similar_managers",
        "get_consensus_portfolio",
        "get_market_regime",
        "get_sector_flows",
    }
    assert names == expected


def test_no_signal_or_report_tools_registered():
    """Regression guard: v0.1.0 must not accidentally ship signal/report tools."""
    from the13f_mcp.server import _TOOL_FUNCTIONS, _tool_definitions
    banned = {
        "get_security_signals", "get_security_signals_bulk", "get_portfolio_signals",
        "generate_manager_report", "generate_security_report", "generate_sector_report",
        "check_report_status", "wait_and_download_report",
    }
    registered_names = {t.name for t in _tool_definitions()}
    assert not (banned & registered_names), (
        "Signal/Report tools leaked into the v0.1.0 catalog. "
        "They belong in the13f_2_0/ until v0.2.0 / v0.3.0."
    )
    assert not (banned & set(_TOOL_FUNCTIONS.keys())), (
        "Signal/Report handlers leaked into _TOOL_FUNCTIONS. "
        "Delete them from the import at the top of server.py."
    )


def test_every_tool_has_description():
    from the13f_mcp.server import _tool_definitions
    for t in _tool_definitions():
        assert t.description, f"Tool {t.name} has empty description"
        assert len(t.description) > 80, f"Tool {t.name} description too short"


def test_every_description_starts_with_compliance_prefix():
    """Load-bearing test: the LLM MUST receive the disclaimer prefix."""
    from the13f_mcp.disclaimer import TOOL_DESCRIPTION_PREFIX
    from the13f_mcp.server import _tool_definitions
    for t in _tool_definitions():
        assert t.description.startswith(TOOL_DESCRIPTION_PREFIX), (
            f"Tool {t.name} description does NOT start with the compliance prefix. "
            "This is a compliance regression."
        )


def test_input_schemas_are_well_formed_json_schema():
    from the13f_mcp.server import _tool_definitions
    for t in _tool_definitions():
        schema = t.inputSchema
        assert isinstance(schema, dict), f"Tool {t.name} inputSchema is not a dict"
        assert schema.get("type") == "object", f"Tool {t.name} inputSchema must be type:object"
        assert "properties" in schema, f"Tool {t.name} inputSchema missing properties"


def test_disclaimer_wrap_adds_field():
    from the13f_mcp.disclaimer import CANONICAL_TEXT, wrap
    out = wrap({"data": [1, 2, 3]})
    assert out["disclaimer"] == CANONICAL_TEXT
    assert out["data"] == [1, 2, 3]


def test_disclaimer_wrap_does_not_overwrite_existing_disclaimer():
    """If the upstream API already set a disclaimer field, don't overwrite."""
    from the13f_mcp.disclaimer import wrap
    out = wrap({"disclaimer": "a different disclaimer", "data": []})
    assert out["disclaimer"] == "a different disclaimer"


def test_build_server_does_not_crash():
    from the13f_mcp.server import _build_server
    server = _build_server()
    assert server.name == "the13f-mcp"
    assert server.version
