"""Tests for MCP resources + prompts (Tier 2).

Coverage:
    - resources.list_resources() returns 5 entries with correct URIs
    - resources.read_resource() returns the right body for each URI
    - resources.read_resource() raises ValueError for unknown URIs
    - resources.read_resource("the13f://catalog/quarters") falls back gracefully
      when the API can't be reached (no THE13F_API_KEY set in test)
    - prompts.list_prompts() returns 5 prompts with required arguments declared
    - prompts.get_prompt() returns a GetPromptResult with the compliance preamble
    - prompts.get_prompt() raises ValueError for unknown name
    - Prompt argument substitution puts user input into the seeded message
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MCP_SRC = HERE.parent / "src"
for p in (str(MCP_SRC), str(HERE.parents[2])):
    if p not in sys.path:
        sys.path.insert(0, p)

import pytest

from the13f_mcp import disclaimer, prompts, resources


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

def test_list_resources_count():
    rs = resources.list_resources()
    assert len(rs) == 5


def test_list_resources_uris():
    """MCP Resource.uri is a pydantic AnyUrl; compare as strings."""
    uris = {str(r.uri) for r in resources.list_resources()}
    assert uris == {
        "the13f://docs/agents",
        "the13f://docs/signal-glossary",
        "the13f://catalog/quarters",
        "the13f://catalog/sectors",
        "the13f://docs/disclaimer",
    }


def test_list_resources_have_descriptions():
    for r in resources.list_resources():
        assert r.description and len(r.description) > 20
        assert r.name and len(r.name) > 5


def test_read_disclaimer_resource():
    body = resources.read_resource("the13f://docs/disclaimer")
    assert body == disclaimer.CANONICAL_TEXT
    assert "Research data only" in body


def test_read_agents_resource():
    body = resources.read_resource("the13f://docs/agents")
    assert "the13f Platform" in body
    assert "Compliance" in body
    assert "Authentication" in body
    assert "THE13F_API_KEY" in body


def test_read_signal_glossary_resource():
    body = resources.read_resource("the13f://docs/signal-glossary")
    assert "flow_intensity" in body
    assert "net_buyer_count" in body
    assert "persistence_quarters" in body


def test_read_sectors_resource():
    import json
    body = resources.read_resource("the13f://catalog/sectors")
    parsed = json.loads(body)
    assert len(parsed["sectors"]) == 11
    assert "Information Technology" in parsed["sectors"]
    assert "Financials" in parsed["sectors"]


def test_read_quarters_resource_handles_missing_api():
    """Without THE13F_API_KEY, this should still return a valid JSON body
    (with an error key) - never raise."""
    import json
    import os
    old = os.environ.pop("THE13F_API_KEY", None)
    try:
        body = resources.read_resource("the13f://catalog/quarters")
        parsed = json.loads(body)
        # Either real quarters or a graceful error
        assert "quarters" in parsed or "error" in parsed
    finally:
        if old:
            os.environ["THE13F_API_KEY"] = old


def test_read_unknown_resource_raises():
    with pytest.raises(ValueError, match="Unknown resource URI"):
        resources.read_resource("the13f://does/not/exist")


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

def test_list_prompts_count():
    ps = prompts.list_prompts()
    assert len(ps) == 5


def test_list_prompts_names():
    names = {p.name for p in prompts.list_prompts()}
    assert names == {
        "quarterly_attribution",
        "find_my_peers",
        "sector_brief",
        "manager_change_summary",
        "family_office_quarterly",
    }


def test_each_prompt_has_required_arg():
    """Every prompt must have at least one REQUIRED argument."""
    for p in prompts.list_prompts():
        required_args = [a for a in (p.arguments or []) if a.required]
        assert len(required_args) >= 1, f"Prompt {p.name} has no required args"


def test_quarterly_attribution_uses_holdings():
    result = prompts.get_prompt("quarterly_attribution", {
        "holdings": "NVDA,AAPL,MSFT",
        "quarter": "q4y2025",
    })
    assert len(result.messages) == 1
    body = result.messages[0].content.text
    assert "NVDA,AAPL,MSFT" in body
    assert "q4y2025" in body
    # Compliance preamble present
    assert "disclaimer" in body.lower()
    assert "Research data only" in body or "research data only" in body.lower()


def test_find_my_peers_default_direction():
    """When direction is not provided, defaults to 'similar'."""
    result = prompts.get_prompt("find_my_peers", {
        "holdings": "AAPL,MSFT",
    })
    body = result.messages[0].content.text
    assert "similar" in body
    assert "AAPL,MSFT" in body


def test_sector_brief_includes_sector_and_quarter():
    result = prompts.get_prompt("sector_brief", {
        "sector_name": "Information Technology",
    })
    body = result.messages[0].content.text
    assert "Information Technology" in body
    assert "get_sector_flows" in body
    assert "get_security_signals" in body


def test_manager_change_summary_two_quarters():
    result = prompts.get_prompt("manager_change_summary", {
        "manager_name": "Renaissance",
        "quarter_to": "q4y2025",
        "quarter_from": "q3y2025",
    })
    body = result.messages[0].content.text
    assert "Renaissance" in body
    assert "q4y2025" in body
    assert "q3y2025" in body


def test_family_office_quarterly_full_workflow():
    result = prompts.get_prompt("family_office_quarterly", {
        "holdings": "AAPL,GOOGL,NVDA,BRK.B",
    })
    body = result.messages[0].content.text
    assert "AAPL,GOOGL,NVDA,BRK.B" in body
    # Workflow includes all the right tools
    assert "get_portfolio_signals" in body
    assert "find_similar_managers" in body
    assert "get_market_regime" in body
    assert "get_consensus_portfolio" in body


def test_prompt_unknown_raises():
    with pytest.raises(ValueError, match="Unknown prompt"):
        prompts.get_prompt("does_not_exist", {})


def test_prompt_with_no_args_uses_defaults():
    """quarter and direction args are optional; prompt should still build."""
    result = prompts.get_prompt("quarterly_attribution", {
        "holdings": "AAPL",
    })
    body = result.messages[0].content.text
    assert "latest available" in body  # default for quarter
    assert "AAPL" in body
