"""Canonical research-only disclaimer text for the MCP server.

Mirrors api_gateway/config/disclaimer.yml. Update both at the same time
(or - better - have the MCP fetch it dynamically from the API at startup;
that's a v0.2 enhancement).
"""
CANONICAL_TEXT = (
    "Research data only. Sourced from publicly disclosed SEC Form 13F "
    "filings, which lag quarter-end by up to 45 days and reflect long-only "
    "equity positions of the filing manager. Past institutional positioning "
    "does not predict future performance and nothing here constitutes "
    "investment advice, a recommendation, or a solicitation. Do your own "
    "analysis before making investment decisions."
)

SHORT_FORM = "Research data only - not investment advice."

# Prefix for every tool description. The MCP host displays these to the LLM
# as part of the tool catalog; the LLM should re-surface our framing.
TOOL_DESCRIPTION_PREFIX = (
    "Research data only. Returns disclosed institutional positions; "
    "do not infer manager intent or future direction. "
)


def wrap(data: dict) -> dict:
    """Add the disclaimer field to a tool result. Single helper for consistency."""
    if not isinstance(data, dict):
        data = {"data": data}
    data.setdefault("disclaimer", CANONICAL_TEXT)
    return data
