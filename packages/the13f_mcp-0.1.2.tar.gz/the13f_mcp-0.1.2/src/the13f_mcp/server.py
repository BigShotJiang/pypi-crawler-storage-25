"""MCP server for the13f (v0.1.0: Read tier).

Registers 9 Read-tier tools, 5 resources, and 5 prompts. Runs over stdio so
MCP hosts (Claude Desktop, Cursor, VS Code + Continue) can call them as
subprocesses.

Tools (9) - free tier, pf13f_ key from https://the13f.com/developers/:
    list_quarters
    search_managers
    get_manager_holdings
    get_manager_holdings_bulk
    list_all_managers
    find_similar_managers
    get_consensus_portfolio
    get_market_regime
    get_sector_flows

Deferred to later releases (source still lives in the13f_2_0/mcp_server/):
    v0.2.0 - Signal tools (get_security_signals, get_security_signals_bulk,
             get_portfolio_signals). Requires Standard tier subscription.
    v0.3.0 - Report tools (generate_{manager,security,sector}_report,
             check_report_status, wait_and_download_report). Requires
             Standard tier + stored card. Two-step confirm before charging.

Resources (5):
    the13f://docs/agents             AGENTS.md text
    the13f://docs/signal-glossary    Plain-English signal definitions
    the13f://catalog/quarters        Live list of quarters with data
    the13f://catalog/sectors         11 GICS sector names
    the13f://docs/disclaimer         Canonical compliance text

Prompts (5):
    quarterly_attribution
    find_my_peers
    sector_brief
    manager_change_summary
    family_office_quarterly

Compliance:
    Every tool description begins with the canonical "Research data only..."
    framing (see disclaimer.TOOL_DESCRIPTION_PREFIX). Every result includes
    a `disclaimer` field. Every prompt seed message includes the same
    framing as a preamble. The MCP host's LLM is responsible for surfacing
    the framing to the human user.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sys
from collections.abc import Callable
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import GetPromptResult, Prompt, Resource, TextContent, Tool

from . import config, disclaimer, http_client, prompts, resources, tools
from ._version import __version__

logger = logging.getLogger("the13f_mcp")


def _describe(fn: Callable) -> str:
    """Return the tool description shown to the LLM.

    Prepends the canonical compliance prefix (Research data only...) to the
    function's docstring so every tool description carries the framing.
    Callers MUST use this; raw __doc__ does not include the prefix.
    """
    body = (fn.__doc__ or "").strip()
    return f"{disclaimer.TOOL_DESCRIPTION_PREFIX}{body}"


def _tool_definitions() -> list[Tool]:
    """Build the MCP Tool objects for every v0.1.0 Read-tier tool.

    Each Tool needs:
        - name (snake_case, must match the Python function)
        - description (docstring + compliance prefix)
        - inputSchema (JSON Schema describing arguments)
    """
    return [
        Tool(
            name="list_quarters",
            description=_describe(tools.list_quarters),
            inputSchema={"type": "object", "properties": {}, "additionalProperties": False},
        ),
        Tool(
            name="search_managers",
            description=_describe(tools.search_managers),
            inputSchema={
                "type": "object",
                "required": ["query"],
                "properties": {
                    "query": {"type": "string", "minLength": 2, "description": "Substring of the manager's name."},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 50, "default": 10},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_manager_holdings",
            description=_describe(tools.get_manager_holdings),
            inputSchema={
                "type": "object",
                "required": ["cik", "quarter"],
                "properties": {
                    "cik": {"type": "string", "description": "Zero-padded 10-digit SEC CIK."},
                    "quarter": {"type": "string", "description": "e.g. q4y2025"},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="list_all_managers",
            description=_describe(tools.list_all_managers),
            inputSchema={
                "type": "object",
                "properties": {"active_only": {"type": "boolean", "default": True}},
                "additionalProperties": False,
            },
        ),
        Tool(
            name="find_similar_managers",
            description=_describe(tools.find_similar_managers),
            inputSchema={
                "type": "object",
                "required": ["holdings"],
                "properties": {
                    "holdings": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["ticker"],
                            "properties": {
                                "ticker": {"type": "string"},
                                "weight": {"type": "number", "minimum": 0, "maximum": 1},
                            },
                        },
                        "minItems": 1,
                    },
                    "quarter": {"type": "string"},
                    "top_n": {"type": "integer", "minimum": 1, "maximum": 50, "default": 10},
                    "direction": {"type": "string", "enum": ["similar", "unlike"], "default": "similar"},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_consensus_portfolio",
            description=_describe(tools.get_consensus_portfolio),
            inputSchema={
                "type": "object",
                "required": ["quarter"],
                "properties": {"quarter": {"type": "string"}},
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_market_regime",
            description=_describe(tools.get_market_regime),
            inputSchema={
                "type": "object",
                "required": ["quarter"],
                "properties": {"quarter": {"type": "string"}},
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_sector_flows",
            description=_describe(tools.get_sector_flows),
            inputSchema={
                "type": "object",
                "required": ["quarter"],
                "properties": {
                    "quarter": {"type": "string"},
                    "sector": {"type": "string", "description": "GICS sector name."},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_manager_holdings_bulk",
            description=_describe(tools.get_manager_holdings_bulk),
            inputSchema={
                "type": "object",
                "required": ["pairs"],
                "properties": {
                    "pairs": {
                        "type": "array",
                        "minItems": 1,
                        "maxItems": 25,
                        "items": {
                            "type": "object",
                            "required": ["cik", "quarter"],
                            "properties": {
                                "cik": {"type": "string"},
                                "quarter": {"type": "string"},
                            },
                        },
                    },
                },
                "additionalProperties": False,
            },
        ),
    ]


_TOOL_FUNCTIONS: dict[str, Callable[..., dict[str, Any]]] = {
    "list_quarters": tools.list_quarters,
    "search_managers": tools.search_managers,
    "get_manager_holdings": tools.get_manager_holdings,
    "get_manager_holdings_bulk": tools.get_manager_holdings_bulk,
    "list_all_managers": tools.list_all_managers,
    "find_similar_managers": tools.find_similar_managers,
    "get_consensus_portfolio": tools.get_consensus_portfolio,
    "get_market_regime": tools.get_market_regime,
    "get_sector_flows": tools.get_sector_flows,
}


def _build_server() -> Server:
    """Construct the MCP Server with tool, resource, and prompt registrations."""
    server: Server = Server(name="the13f-mcp", version=__version__)

    @server.list_tools()
    async def _on_list_tools() -> list[Tool]:
        return _tool_definitions()

    @server.list_resources()
    async def _on_list_resources() -> list[Resource]:
        return resources.list_resources()

    @server.read_resource()
    async def _on_read_resource(uri: Any) -> str:
        return resources.read_resource(str(uri))

    @server.list_prompts()
    async def _on_list_prompts() -> list[Prompt]:
        return prompts.list_prompts()

    @server.get_prompt()
    async def _on_get_prompt(name: str, arguments: dict[str, str] | None) -> GetPromptResult:
        return prompts.get_prompt(name, arguments)

    @server.call_tool()
    async def _on_call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        fn = _TOOL_FUNCTIONS.get(name)
        if fn is None:
            return [TextContent(type="text", text=json.dumps({
                "error": f"Unknown tool: {name}",
            }))]
        try:
            result = fn(**arguments)
        except http_client.FreeSignupRequiredError as missing:
            result = {
                "error": str(missing),
                "signup_url": config.SIGNUP_URL,
                "instruction": (
                    "Free signup required (no payment, no credit card). Visit "
                    f"{config.SIGNUP_URL}, enter your email, solve the "
                    "Cloudflare Turnstile challenge, copy your pf13f_ key, and "
                    "set THE13F_API_KEY in your MCP host config. Then restart "
                    "the host."
                ),
            }
        except http_client.TierUpgradeRequiredError as gated:
            result = {
                "error": str(gated),
                "docs_url": gated.docs_url,
                "request_id": gated.request_id,
                "instruction": (
                    "This tool is not available on the free tier. Paid tiers "
                    "arrive in v0.2.0 (signals) and v0.3.0 (report generation). "
                    "For now, use the free Read tools."
                ),
            }
        except http_client.PaymentRequiredError as pay:
            result = {
                "error": str(pay),
                "current_balance": pay.body.get("current_balance"),
                "request_id": pay.request_id,
                "instruction": (
                    "Daily quota exhausted. The free tier allows 100 calls per "
                    "UTC day. Quota resets at UTC midnight; check the "
                    "retry_after field for seconds remaining."
                ),
            }
        except http_client.The13FApiError as api_err:
            result = {
                "error": str(api_err),
                "status_code": api_err.status_code,
                "docs_url": api_err.docs_url,
                "request_id": api_err.request_id,
            }
        except Exception as call_err:
            logger.exception("Tool %s raised an unexpected exception", name)
            result = {"error": str(call_err)}

        return [TextContent(type="text", text=json.dumps(result, default=str, indent=2))]

    return server


async def _run() -> None:
    server = _build_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> int:
    logging.basicConfig(
        level=logging.WARNING,
        stream=sys.stderr,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    asyncio.run(_run())
    return 0


if __name__ == "__main__":
    sys.exit(main())
