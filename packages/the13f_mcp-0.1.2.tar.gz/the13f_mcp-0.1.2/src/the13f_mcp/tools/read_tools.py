"""Read tools - 8 tools that work with any free-tier API key.

Each function has a plain docstring describing what it does. The MCP server
(server.py) prepends the canonical "Research data only..." compliance prefix
when it builds the Tool objects exposed to the host LLM. Docstrings here
stay focused on functionality; compliance language is centralized.
"""
from __future__ import annotations

from typing import Any

from .. import disclaimer as _d
from .. import http_client


def search_managers(query: str, limit: int = 10) -> dict[str, Any]:
    """Find institutional 13F filers by name (case-insensitive substring, min 2 chars).

    Args:
        query: substring of the manager's name (e.g. "renaissance", "berkshire").
        limit: max results to return, 1-50, default 10.

    Returns:
        {
            "query": "...",
            "results": [
                {"cik": "0001037389", "name": "Renaissance Technologies Llc",
                 "latest_aum": 64461244358, "available_quarters": [...]},
                ...
            ],
            "disclaimer": "Research data only..."
        }
    """
    return _d.wrap(http_client.request("GET", "/api/v1/managers/search", params={
        "q": query,
        "limit": max(1, min(int(limit), 50)),
    }))


def get_manager_holdings(cik: str, quarter: str) -> dict[str, Any]:
    """Return all positions held by a 13F filer in a given quarter.

    Args:
        cik: zero-padded 10-digit SEC CIK (e.g. "0001037389").
        quarter: quarter code like "q4y2025".

    Returns:
        {
            "cik": "...", "quarter": "...", "n_positions": 3185,
            "total_value_thousands": 64461244358.0,
            "holdings": [{"CUSIP": ..., "TICKER": ..., "VALUE": ..., ...}, ...],
            "disclaimer": "..."
        }
    """
    return _d.wrap(http_client.request("GET", "/api/v1/case-study/holdings", params={
        "cik": cik,
        "quarter": quarter,
    }))


def list_all_managers(active_only: bool = True) -> dict[str, Any]:
    """Return the full universe of 13F filers with per-manager AUM.

    Args:
        active_only: if true (default), only managers present in the latest quarter.

    Returns:
        {
            "count": 8625, "active_only": true,
            "managers": [{"cik": "...", "name": "...", "latest_aum": ..., ...}, ...],
            "disclaimer": "..."
        }

    NOTE: response can be ~6 MB JSON; consider filtering client-side.
    """
    return _d.wrap(http_client.request("GET", "/api/v1/managers/all", params={
        "active_only": "true" if active_only else "false",
    }))


def find_similar_managers(
    holdings: list[dict[str, Any]],
    quarter: str | None = None,
    top_n: int = 10,
    direction: str = "similar",
) -> dict[str, Any]:
    """Match a portfolio against the 13F universe and return the closest (or deliberately-different) managers.

    Args:
        holdings: list of {"ticker": "AAPL", "weight": 0.05}; weight optional (equal weights default).
        quarter: defaults to latest quarter if None.
        top_n: 1-50, default 10.
        direction: "similar" (closest matches) or "unlike" (most different).

    Returns:
        {"quarter": "...", "matches": [{"cik": ..., "similarity_score": ..., ...}, ...], "disclaimer": "..."}
    """
    body: dict[str, Any] = {
        "holdings": holdings,
        "top_n": max(1, min(int(top_n), 50)),
        "direction": direction,
    }
    if quarter:
        body["quarter"] = quarter
    return _d.wrap(http_client.request("POST", "/api/v1/similarity/match", json=body))


def get_consensus_portfolio(quarter: str) -> dict[str, Any]:
    """Return the top-N consensus portfolio - securities held by the most institutional managers.

    Args:
        quarter: quarter code (e.g. "q4y2025").

    Returns:
        {"quarter": "...", "count": 50, "securities": [{"ticker": ..., "weight_pct": ..., ...}, ...]}
    """
    return _d.wrap(http_client.request("GET", "/api/v1/signals/consensus", params={"quarter": quarter}))


def get_market_regime(quarter: str) -> dict[str, Any]:
    """Return the institutional regime snapshot for a quarter (IIOI composite, regime state, transition).

    Args:
        quarter: quarter code.

    Returns:
        {"quarter": "...", "iioi_composite": 62.4, "regime_state": "High Optimism", ...}
    """
    return _d.wrap(http_client.request("GET", "/api/v1/signals/regime", params={"quarter": quarter}))


def get_sector_flows(quarter: str, sector: str | None = None) -> dict[str, Any]:
    """Return per-sector institutional capital flow intelligence for a quarter.

    Args:
        quarter: quarter code.
        sector: optional GICS sector to filter (e.g. "Information Technology").

    Returns:
        {"quarter": "...", "sectors": [{"gics_sector": ..., "net_capital_flow_thousands": ..., "risk_posture": ..., ...}, ...]}
    """
    params = {"quarter": quarter}
    if sector:
        params["sector"] = sector
    return _d.wrap(http_client.request("GET", "/api/v1/signals/sectors", params=params))


def list_quarters() -> dict[str, Any]:
    """Return all quarter codes with available data.

    Returns:
        {"quarters": ["q1y2013", ..., "q4y2025"], "latest": "q4y2025"}

    Use the latest quarter by default unless the user specifies one.
    """
    return _d.wrap(http_client.request("GET", "/api/v1/managers/quarters"))


def get_manager_holdings_bulk(pairs: list[dict[str, str]]) -> dict[str, Any]:
    """Look up holdings for many (cik, quarter) pairs in one call (Tier 3).

    More efficient than calling get_manager_holdings repeatedly: groups by
    quarter so each parquet file is read at most once. Single billing event
    regardless of how many pairs you supply (up to 25 per call).

    Args:
        pairs: list of {"cik": "...", "quarter": "..."} dicts. Min 1, max 25.

    Returns:
        {
            "results": [
                {"cik": "0001067983", "quarter": "q4y2025", "status": "ok",
                 "n_positions": 42, "total_value_thousands": ..., "holdings": [...]},
                {"cik": "0001234567", "quarter": "q4y2025", "status": "not_found",
                 "error": "..."},
                ...
            ],
            "n_requested": 5, "n_ok": 4, "n_failed": 1
        }

    Per-pair errors do NOT raise; check status field on each result.
    Use this when you need holdings for multiple managers/quarters at once
    (e.g. comparing a portfolio across periods or surveying peer institutions).
    """
    if not isinstance(pairs, list) or not pairs:
        raise ValueError("pairs must be a non-empty list of {cik, quarter} dicts")
    return _d.wrap(http_client.request("POST", "/api/v1/managers/holdings/bulk",
                                        json={"pairs": pairs}))
