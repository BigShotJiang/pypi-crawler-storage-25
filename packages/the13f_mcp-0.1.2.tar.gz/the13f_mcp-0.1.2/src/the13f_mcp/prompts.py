"""MCP prompts - named templates the user can pick from a dropdown.

Prompts differ from tools: they are workflow scaffolds that the human user
selects (in Claude Desktop's command bar, or VS Code's Continue prompt
picker), and the LLM then orchestrates by calling the appropriate tools.

We expose 5 prompts, each tuned to a real fund-manager use case:

    1. quarterly_attribution      - "What drove our outperformance in Q4?"
    2. find_my_peers              - "Which managers hold portfolios like mine?"
    3. sector_brief               - "Quick read on sector X this quarter"
    4. manager_change_summary     - "What did Sequoia change between Q3 and Q4?"
    5. family_office_quarterly    - End-of-quarter family-office briefing pack

Each prompt:
    * Has a unique name (snake_case)
    * Declares its arguments (typed, with descriptions)
    * Returns a list of PromptMessage objects (the messages to seed the chat)

The LLM follows the seeded messages and uses tools to fulfill them.
"""
from __future__ import annotations

from mcp.types import GetPromptResult, Prompt, PromptArgument, PromptMessage, TextContent

# Compliance preamble injected into every prompt's first message.
_PROMPT_PREAMBLE = (
    "You are working with the13f Platform data. Research data only - this "
    "is not investment advice. Every response includes a `disclaimer` "
    "field; you MUST surface it verbatim to the human in any output that "
    "quotes our data. Do not paraphrase the disclaimer.\n\n"
)


def list_prompts() -> list[Prompt]:
    """All 5 prompts. Called by the MCP host to populate the prompt picker."""
    return [
        Prompt(
            name="quarterly_attribution",
            description=(
                "Walk through what drove a portfolio's quarter-over-quarter "
                "value change. Pulls institutional context for each holding "
                "and identifies which positions had the strongest signals."
            ),
            arguments=[
                PromptArgument(
                    name="holdings",
                    description="Comma-separated tickers (e.g. 'NVDA,AAPL,MSFT,GOOGL')",
                    required=True,
                ),
                PromptArgument(
                    name="quarter",
                    description="Quarter to analyze, e.g. q4y2025. Defaults to latest.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="find_my_peers",
            description=(
                "Find the top institutional managers whose portfolios most "
                "resemble (or most diverge from) yours. Useful for "
                "competitor benchmarking and idea generation."
            ),
            arguments=[
                PromptArgument(
                    name="holdings",
                    description="Comma-separated tickers (no weights needed; equal-weight assumed)",
                    required=True,
                ),
                PromptArgument(
                    name="direction",
                    description="'similar' (peers) or 'unlike' (contrarians). Default: similar.",
                    required=False,
                ),
                PromptArgument(
                    name="quarter",
                    description="Quarter, e.g. q4y2025. Defaults to latest.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="sector_brief",
            description=(
                "Short institutional-positioning brief for a single GICS "
                "sector this quarter. Pulls flow numbers, top accumulators, "
                "and breadth context."
            ),
            arguments=[
                PromptArgument(
                    name="sector_name",
                    description=(
                        "One of the 11 GICS sectors. See resource "
                        "the13f://catalog/sectors for valid values."
                    ),
                    required=True,
                ),
                PromptArgument(
                    name="quarter",
                    description="Quarter, e.g. q4y2025. Defaults to latest.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="manager_change_summary",
            description=(
                "Compare a single manager's holdings between two quarters "
                "and summarize what changed: new positions, exits, "
                "concentration shifts, sector reallocations."
            ),
            arguments=[
                PromptArgument(
                    name="manager_name",
                    description="Substring of the manager's name; we'll search and pick the best match.",
                    required=True,
                ),
                PromptArgument(
                    name="quarter_to",
                    description="Most recent quarter to compare TO, e.g. q4y2025. Defaults to latest.",
                    required=False,
                ),
                PromptArgument(
                    name="quarter_from",
                    description="Earlier quarter to compare FROM. Defaults to one quarter before quarter_to.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="family_office_quarterly",
            description=(
                "End-of-quarter institutional-positioning briefing for a "
                "family-office portfolio. Combines portfolio-level signals, "
                "sector tilts, peer comparison, and consensus drift into "
                "one prose summary suitable for a quarterly partner update."
            ),
            arguments=[
                PromptArgument(
                    name="holdings",
                    description="Comma-separated tickers in the portfolio.",
                    required=True,
                ),
                PromptArgument(
                    name="quarter",
                    description="Reporting quarter, e.g. q4y2025. Defaults to latest.",
                    required=False,
                ),
            ],
        ),
    ]


def get_prompt(name: str, arguments: dict | None) -> GetPromptResult:
    """Build the seeded message list for the named prompt.

    Returns a GetPromptResult whose messages list is the conversation seed.
    The MCP host inserts these messages, then the LLM continues - calling
    the13f tools as needed to gather the data the prompt asks for.
    """
    arguments = arguments or {}

    if name == "quarterly_attribution":
        holdings = (arguments.get("holdings") or "").strip()
        quarter = (arguments.get("quarter") or "latest available").strip()
        body = (
            f"{_PROMPT_PREAMBLE}"
            f"Walk me through what drove the quarter-over-quarter value "
            f"change for this portfolio in {quarter}:\n\n"
            f"Holdings: {holdings}\n\n"
            f"Steps:\n"
            f"1. Call `get_portfolio_signals` with the holdings list.\n"
            f"2. For the top 3 positive contributors and top 3 negative, "
            f"call `get_security_signals` to get the per-security flow "
            f"intensity and net_buyer_count.\n"
            f"3. Identify the 1-2 positions where institutional flow "
            f"diverges most from price action (potential mean-reversion "
            f"or trend-following setups).\n"
            f"4. Summarize in <300 words. Lead with the finding. End with "
            f"the canonical disclaimer."
        )
        return GetPromptResult(
            description=f"Quarterly attribution walk-through for {quarter}",
            messages=[PromptMessage(role="user", content=TextContent(type="text", text=body))],
        )

    if name == "find_my_peers":
        holdings = (arguments.get("holdings") or "").strip()
        direction = (arguments.get("direction") or "similar").strip()
        quarter = (arguments.get("quarter") or "latest available").strip()
        body = (
            f"{_PROMPT_PREAMBLE}"
            f"Find institutional managers whose portfolios are most "
            f"{direction} to mine in {quarter}.\n\n"
            f"Holdings: {holdings}\n\n"
            f"Steps:\n"
            f"1. Call `find_similar_managers` with these holdings, "
            f"direction='{direction}', top_n=10.\n"
            f"2. For the top 3 results, call `get_manager_holdings` to "
            f"see what they hold that I do not (the 'differentiation' "
            f"set).\n"
            f"3. Group those differentiation positions by GICS sector to "
            f"highlight where my portfolio diverges from peers.\n"
            f"4. Output: a one-paragraph summary plus a table "
            f"(manager_name, similarity_score, top 3 holdings I'm "
            f"missing). End with the canonical disclaimer."
        )
        return GetPromptResult(
            description=f"Peer manager search ({direction}) for {quarter}",
            messages=[PromptMessage(role="user", content=TextContent(type="text", text=body))],
        )

    if name == "sector_brief":
        sector_name = (arguments.get("sector_name") or "").strip()
        quarter = (arguments.get("quarter") or "latest available").strip()
        body = (
            f"{_PROMPT_PREAMBLE}"
            f"Write a one-page institutional-positioning brief for "
            f"{sector_name} in {quarter}.\n\n"
            f"Steps:\n"
            f"1. Call `get_sector_flows` with sector='{sector_name}'.\n"
            f"2. Call `get_security_signals` filtered to that sector, "
            f"sorted by flow_intensity descending, per_page=10.\n"
            f"3. Call `get_market_regime` to frame the macro context.\n"
            f"4. Write 200-300 words structured as: (a) headline finding "
            f"for the sector this quarter, (b) top 3 securities driving "
            f"the flow, (c) breadth context (how many filers participated), "
            f"(d) one-line cautious framing. End with the canonical "
            f"disclaimer."
        )
        return GetPromptResult(
            description=f"Sector brief: {sector_name} in {quarter}",
            messages=[PromptMessage(role="user", content=TextContent(type="text", text=body))],
        )

    if name == "manager_change_summary":
        manager_name = (arguments.get("manager_name") or "").strip()
        quarter_to = (arguments.get("quarter_to") or "latest available").strip()
        quarter_from = (arguments.get("quarter_from") or "one quarter prior").strip()
        body = (
            f"{_PROMPT_PREAMBLE}"
            f"Summarize how {manager_name}'s portfolio changed from "
            f"{quarter_from} to {quarter_to}.\n\n"
            f"Steps:\n"
            f"1. Call `search_managers` with query='{manager_name}' to "
            f"resolve the CIK. Pick the best match.\n"
            f"2. Call `get_manager_holdings` for both quarters using "
            f"that CIK.\n"
            f"3. Compute: new positions (in to but not from), exited "
            f"positions (in from but not to), and the top 5 weight "
            f"increases / decreases.\n"
            f"4. Output: a 200-word paragraph plus a 4-section table "
            f"(New / Exited / Top Adds / Top Trims). End with the "
            f"canonical disclaimer."
        )
        return GetPromptResult(
            description=f"{manager_name} change summary: {quarter_from} -> {quarter_to}",
            messages=[PromptMessage(role="user", content=TextContent(type="text", text=body))],
        )

    if name == "family_office_quarterly":
        holdings = (arguments.get("holdings") or "").strip()
        quarter = (arguments.get("quarter") or "latest available").strip()
        body = (
            f"{_PROMPT_PREAMBLE}"
            f"Write a quarterly partner update for a family office whose "
            f"holdings are listed below, covering {quarter} institutional "
            f"positioning context.\n\n"
            f"Holdings: {holdings}\n\n"
            f"Steps:\n"
            f"1. Call `get_portfolio_signals` for the holdings.\n"
            f"2. Call `find_similar_managers` with direction='similar' "
            f"to identify 3 institutional peers.\n"
            f"3. Call `get_market_regime` for the macro frame.\n"
            f"4. Call `get_consensus_portfolio` for the quarter and note "
            f"3 holdings the family office holds that are NOT in the "
            f"institutional consensus (differentiated bets).\n"
            f"5. Write a 400-500 word update structured as: (a) macro "
            f"regime in one paragraph, (b) portfolio's institutional "
            f"alignment overall, (c) 3 differentiated positions and "
            f"what they reveal, (d) 3 institutional peers and how the "
            f"portfolio compares, (e) one paragraph of measured "
            f"observation (NO advice). End with the canonical "
            f"disclaimer."
        )
        return GetPromptResult(
            description=f"Family office quarterly briefing for {quarter}",
            messages=[PromptMessage(role="user", content=TextContent(type="text", text=body))],
        )

    raise ValueError(f"Unknown prompt: {name}")
