"""MCP resources - read-only context the agent can enumerate.

Resources differ from tools: they are static-ish documents the LLM can
read when it needs background context (e.g. "what does net_buyer_count
mean again?"). The MCP host typically lists them in a sidebar so the
human user can also browse.

We expose 5 resources:
    1. the13f://docs/agents             - Full AGENTS.md text
    2. the13f://docs/signal-glossary    - Plain-English signal definitions
    3. the13f://catalog/quarters        - Live list of quarters with data
    4. the13f://catalog/sectors         - 11 GICS sectors we cover
    5. the13f://docs/disclaimer         - Compliance text (also injected into every response)

Resources are cheap (no API charges, no rate-limit consumption). The
agent can call read_resource freely.
"""
from __future__ import annotations

import json

from mcp.types import Resource

from . import disclaimer, http_client


def list_resources() -> list[Resource]:
    """All 5 resources we expose. Called when the MCP host lists resources."""
    return [
        Resource(
            uri="the13f://docs/agents",
            name="AGENTS.md (the13f Platform agent guide)",
            description=(
                "Full agent-facing documentation. Covers authentication, "
                "rate limits, error handling, signal interpretation, and "
                "the compliance framing every response carries. Read this "
                "once at the start of a session."
            ),
            mimeType="text/markdown",
        ),
        Resource(
            uri="the13f://docs/signal-glossary",
            name="Signal Glossary (plain-English definitions)",
            description=(
                "What flow_intensity, net_buyer_count, persistence_quarters, "
                "DeltaV, and other terms in our API responses mean. Use "
                "this when interpreting numbers for an end user."
            ),
            mimeType="text/markdown",
        ),
        Resource(
            uri="the13f://catalog/quarters",
            name="Available Quarters (live)",
            description=(
                "JSON list of all quarter codes with usable data, plus the "
                "latest quarter. Refresh at the start of each session - "
                "new filings drop ~45 days after each quarter ends."
            ),
            mimeType="application/json",
        ),
        Resource(
            uri="the13f://catalog/sectors",
            name="GICS Sectors (11 canonical names)",
            description=(
                "The 11 GICS sector names used by every endpoint that "
                "accepts a sector parameter. Match these exactly - we "
                "reject typos at the route boundary."
            ),
            mimeType="application/json",
        ),
        Resource(
            uri="the13f://docs/disclaimer",
            name="Compliance Disclaimer (Research data only)",
            description=(
                "The canonical compliance disclaimer that accompanies "
                "every API response. Surface this verbatim when relaying "
                "any the13f data to the human user."
            ),
            mimeType="text/plain",
        ),
    ]


def read_resource(uri: str) -> str:
    """Return the body of the named resource. Raise ValueError on unknown URI."""
    if uri == "the13f://docs/agents":
        return _AGENTS_MD
    if uri == "the13f://docs/signal-glossary":
        return _SIGNAL_GLOSSARY
    if uri == "the13f://docs/disclaimer":
        return disclaimer.CANONICAL_TEXT
    if uri == "the13f://catalog/quarters":
        try:
            client = http_client.get_client()
            quarters = client.get_json("/api/v1/managers/quarters")
            return json.dumps(quarters, indent=2)
        except Exception as fetch_err:
            return json.dumps({
                "error": f"Could not fetch live quarters: {fetch_err}",
                "fallback_note": (
                    "If you're not authenticated, set THE13F_API_KEY first. "
                    "Free signup at https://platform.the13f.com/signup."
                ),
            }, indent=2)
    if uri == "the13f://catalog/sectors":
        return json.dumps({
            "sectors": [
                "Communication Services", "Consumer Discretionary",
                "Consumer Staples", "Energy", "Financials", "Health Care",
                "Industrials", "Information Technology", "Materials",
                "Real Estate", "Utilities",
            ],
            "note": "GICS Level 1. Match exactly - validation rejects typos.",
        }, indent=2)
    raise ValueError(f"Unknown resource URI: {uri}")


# ---------------------------------------------------------------------------
# Resource bodies
# ---------------------------------------------------------------------------

_AGENTS_MD = """# the13f Platform - Agent Guide (concise)

You are interacting with the13f Platform, an institutional positioning
intelligence service derived from SEC 13F filings.

## Compliance (verbatim, every response)

Every API response carries a `disclaimer` field with the exact text the
LLM must surface to the human user. The text is:

> Research data only. Not investment advice, a recommendation, an offer
> to buy or sell, or a solicitation. 13F filings are reported with a
> 45-day delay and may be incomplete. Do your own research; consult a
> licensed advisor.

Never rephrase, summarize, or omit this text.

## Authentication

Set environment variable `THE13F_API_KEY` to a key prefixed with `pf13f_`.
Get one free at https://platform.the13f.com/signup. The free tier needs
no payment information.

## Tier model

| Tier | Tools available |
|---|---|
| Free (signup, no card) | All `Read tier` tools (8 tools) |
| Standard ($99/mo) | + Signal tools (2 tools) |
| Standard + card on file | + Report tools (5 tools, charged per report) |

## Failure modes you may see

- **PaymentRequiredError**: daily quota exhausted and no credits. Surface
  the topup_url and upgrade_url in the error body to the user.
- **TierUpgradeRequiredError**: tool needs a tier the user does not have.
  Show the upgrade_url and the tier required.
- **FreeSignupRequiredError**: no API key set. Direct user to /signup.

## Numbers - what they mean

See resource `the13f://docs/signal-glossary` for all metric definitions.
The most common: `flow_intensity` (0-100, higher = stronger institutional
buying), `net_buyer_count` (filers - sellers), `persistence_quarters`
(consecutive quarters with the same direction).
"""


_SIGNAL_GLOSSARY = """# Signal Glossary

Every metric the13f Platform returns, in plain English.

## Per-security signals

**flow_intensity** (0-100)
A normalized z-score of net institutional capital flow into a security
this quarter, scaled so 50 is the cross-sectional median, 75+ is "top
quintile inflow", 25- is "top quintile outflow". Higher = stronger
institutional buying.

**net_buyer_count** (integer)
Number of distinct 13F filers who increased their position - number who
decreased. Positive = breadth of buying; negative = breadth of selling.

**persistence_quarters** (integer)
How many consecutive quarters the signal has stayed in the same
direction (positive = consecutive accumulation; negative = consecutive
distribution).

**signal** (LONG, NEUTRAL, SHORT)
Discrete summary of flow_intensity + persistence + concentration.
Useful for filtering; flow_intensity gives you the magnitude.

## Per-sector signals

**sector_capital_flow_dollars**
Sum of position-value changes across the sector this quarter, in dollars.

**sector_price_effect_dollars**
Of the above, how much is from price changes (held shares appreciating)
vs. genuine accumulation. Subtract to isolate flow.

**breadth_score** (0-100)
Fraction of filers in the sector who are net buyers, scaled.

## Manager metrics

**portfolio_concentration_hhi**
Herfindahl-Hirschman Index of position weights. 100 = single position;
0 = perfectly diversified.

**posture_score** (-100 to +100)
Aggregate aggressiveness. Negative = defensive (cash, staples); positive
= aggressive (small/mid growth, leverage).

**intent_label**
"Accumulating", "Distributing", "Holding", "Restructuring" - the
quarter's dominant action across the portfolio.

## Caveats

- 13F filings are 45 days delayed. Numbers describe the QUARTER ENDING
  date, not today.
- Long-only; short positions are NOT visible.
- Funds under $100M AUM are not required to file.
- Confidential treatment requests can defer disclosure of specific
  positions for up to 1 year.
"""
