"""Configuration loader for the MCP server.

Reads three environment variables:

    THE13F_API_KEY      - the user's pf13f_ key issued at
                          https://the13f.com/developers/signup. Optional:
                          read tools can surface a signup CTA on the first
                          call when the key is absent. THIS IS THE
                          CONVERSION GATE.

    THE13F_API_BASE_URL - defaults to https://api.the13f.com. Override for
                          local development (e.g. http://127.0.0.1:5053).

    THE13F_MCP_TIMEOUT  - HTTP timeout in seconds. Default 30.
"""
from __future__ import annotations

import os

DEFAULT_BASE_URL = "https://api.the13f.com"
DEFAULT_TIMEOUT_SECONDS = 30
SIGNUP_URL = "https://the13f.com/developers/"


def api_key() -> str | None:
    raw = os.environ.get("THE13F_API_KEY", "").strip()
    return raw or None


def base_url() -> str:
    return (os.environ.get("THE13F_API_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def timeout_seconds() -> float:
    raw = os.environ.get("THE13F_MCP_TIMEOUT", str(DEFAULT_TIMEOUT_SECONDS))
    try:
        return max(5.0, float(raw))
    except ValueError:
        return float(DEFAULT_TIMEOUT_SECONDS)
