"""the13f-mcp - Model Context Protocol server for the13f Platform.

Exposes institutional 13F intelligence as MCP tools to Claude Desktop, Cursor,
VS Code, Continue, and any MCP-compatible host. Read tools work for any signed-up
user (free tier); signal tools and PDF report generation require Standard+
subscription on platform.the13f.com.

Install:
    uvx the13f-mcp

Configure in your MCP host (e.g. ~/Library/Application Support/Claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "the13f": {
          "command": "uvx",
          "args": ["the13f-mcp"],
          "env": {"THE13F_API_KEY": "pf13f_..."}
        }
      }
    }
"""
from ._version import __version__

__all__ = ["__version__"]
