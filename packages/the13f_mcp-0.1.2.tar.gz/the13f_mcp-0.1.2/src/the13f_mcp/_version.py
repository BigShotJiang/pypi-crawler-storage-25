"""Version constant. Own module to avoid circular imports."""
__version__ = "0.1.2"
