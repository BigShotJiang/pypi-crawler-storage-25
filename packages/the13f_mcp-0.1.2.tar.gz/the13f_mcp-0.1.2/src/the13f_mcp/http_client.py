"""Shared HTTP client for the MCP server.

Wraps httpx with the platform's auth header, sane timeouts, retry-on-429
honoring Retry-After, and a small set of typed exceptions that the tool
modules surface back to the MCP host.

Importing this module is cheap; the httpx.Client is built lazily on first call.
"""
from __future__ import annotations

import time
from typing import Any

import httpx

from . import config

_client: httpx.Client | None = None


class The13FApiError(RuntimeError):
    """Base exception for any non-2xx response or transport error."""

    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body or {}
        self.request_id = self.body.get("request_id")
        self.docs_url = self.body.get("docs_url")
        self.disclaimer = self.body.get("disclaimer")


class FreeSignupRequiredError(The13FApiError):
    """Raised when no THE13F_API_KEY is set; surfaces signup CTA to the user."""


class TierUpgradeRequiredError(The13FApiError):
    """403 - the user's tier doesn't unlock this feature."""


class PaymentRequiredError(The13FApiError):
    """402 - quota exhausted + no credits OR card declined OR no card on file."""


def _client_lazy() -> httpx.Client:
    global _client
    if _client is None:
        headers: dict[str, str] = {"User-Agent": _user_agent()}
        api_key = config.api_key()
        if api_key:
            headers["X-API-Key"] = api_key
        _client = httpx.Client(
            base_url=config.base_url(),
            timeout=config.timeout_seconds(),
            headers=headers,
        )
    return _client


def _user_agent() -> str:
    from ._version import __version__
    return f"the13f-mcp/{__version__} (python-mcp; +{config.SIGNUP_URL})"


def request(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    """Perform one API call with retry on 429.

    Returns the parsed JSON dict. Raises one of the typed exceptions on
    non-2xx responses.
    """
    if not config.api_key():
        raise FreeSignupRequiredError(
            f"Free signup required. Visit {config.SIGNUP_URL}, complete the "
            "free email signup (Cloudflare Turnstile), copy the issued "
            "pf13f_ key, and set THE13F_API_KEY in your MCP host config "
            "(Claude Desktop, Cursor, or VS Code + Continue). Then restart "
            "the host.",
            status_code=401,
        )

    client = _client_lazy()
    attempts = 0
    while True:
        attempts += 1
        try:
            response = client.request(method, path, **kwargs)
        except httpx.TimeoutException as timeout_err:
            raise The13FApiError(f"Timed out talking to the13f Platform: {timeout_err}") from timeout_err
        except httpx.HTTPError as transport_err:
            raise The13FApiError(f"Transport error: {transport_err}") from transport_err

        if response.status_code == 429 and attempts < 3:
            retry_after = response.headers.get("Retry-After", "1")
            try:
                wait_s = float(retry_after)
            except ValueError:
                wait_s = 1.0
            time.sleep(min(wait_s, 30.0))
            continue
        return _interpret(response)


def _interpret(response: httpx.Response) -> dict[str, Any]:
    """Parse the response. Raise typed exceptions for non-2xx."""
    try:
        body = response.json()
    except ValueError:
        body = {"error": response.text[:500]}
    if 200 <= response.status_code < 300:
        return body if isinstance(body, dict) else {"data": body}

    message = body.get("error", f"HTTP {response.status_code}")
    if response.status_code == 401:
        raise FreeSignupRequiredError(message, status_code=401, body=body)
    if response.status_code == 402:
        raise PaymentRequiredError(message, status_code=402, body=body)
    if response.status_code == 403:
        raise TierUpgradeRequiredError(message, status_code=403, body=body)
    raise The13FApiError(message, status_code=response.status_code, body=body)
