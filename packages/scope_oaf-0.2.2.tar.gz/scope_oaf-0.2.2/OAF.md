# OAF — OpenAgentFramework

**Minimal, fast, transparent AI agent framework for Python.**

Published as [`scope-oaf`](https://pypi.org/project/scope-oaf/) on PyPI. Python 3.11+. MIT License.

Core philosophy: **zero magic.** Every prompt, tool call, and LLM decision is fully inspectable. Flat architecture over deep abstraction chains.

---

## Table of Contents

- [Architecture](#architecture)
- [How It Works](#how-it-works)
- [API Reference](#api-reference)
- [LLM Client](#llm-client)
- [Design Decisions](#design-decisions)
- [Build & Test](#build--test)
- [Release Workflow](#release-workflow)
- [Current Status & Task List](#current-status--task-list)

---

## Architecture

```
┌──────────────────────────────────────────────────┐
│                  Your Application                │
├──────────────────────────────────────────────────┤
│              OpenAgentFramework (OAF)            │
│  ┌──────────┐ ┌──────────┐ ┌───────────────┐    │
│  │  Agent   │ │  Tools   │ │    Context     │    │
│  │          │ │          │ │  + Prompts     │    │
│  └──────────┘ └──────────┘ └───────────────┘    │
├──────────────────────────────────────────────────┤
│              llmclient (built-in)                │
│          OpenAI + Anthropic providers            │
└──────────────────────────────────────────────────┘
```

### Directory Structure

```
oaf/
├── __init__.py              # Top-level exports
├── agent.py                 # Agent class — LLM call + tool execution loop
├── hooks.py                 # Async lifecycle event system (before/after hooks)
├── context/
│   ├── base.py              # BaseContext ABC (storage + prompt assembly)
│   └── ConversationalInMemory.py  # In-memory context with message/token limits
├── llmclient/               # Unified LLM client (can be used standalone)
│   ├── client.py            # LLMClient — main async API (chat, chat_stream, embed)
│   ├── sync_client.py       # SyncLLMClient — thread-safe sync wrapper
│   ├── types.py             # Message, ChatResponse, ToolCall, StreamChunk, etc.
│   ├── errors.py            # LLMError hierarchy (Auth, RateLimit, etc.)
│   ├── models.py            # Model registry with metadata (context windows, pricing)
│   ├── parser.py            # JSON response parser for tool calling
│   └── providers/
│       ├── base.py          # BaseProvider interface
│       ├── openai_provider.py
│       └── anthropic_provider.py
├── prompts/
│   └── raw.py               # Tool prompt templates + build_tool_prompt() utility
└── tools/
    ├── tool.py              # @tool decorator, Tool class, @tool_method, BaseToolGroup
    └── registry.py          # ToolRegistry — manages tool registration and lookup
```

### Supporting Files

| File | Purpose |
|------|---------|
| `chat.py` | Interactive terminal REPL (needs `OPENAI_API_KEY`) |
| `web.py` + `web_ui.html` | Browser-based chat UI (needs `aiohttp`) |
| `tests/` | Offline unit tests (82 tests, no API keys needed) |
| `oaf/llmclient/test_llmclient.py` | Integration tests (needs API keys) |
| `pyproject.toml` | Package metadata, version (single source of truth) |

### Top-Level Exports

```python
from oaf import Agent, Hooks, BaseContext, ConversationalInMemory
from oaf import Tool, tool, tool_method, BaseToolGroup, ToolRegistry
```

---

## How It Works

### Agent Loop

```
User message
    │
    ▼
┌─────────────────────────┐
│   context.build_messages │ ◄── Context assembles system prompt (with tool
│   (system + tools +     │     descriptions) + conversation history
│    conversation history) │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│   LLMClient.chat()      │ ◄── Send to OpenAI or Anthropic
└────────────┬────────────┘
             │
         ┌───┴───┐
         │       │
    text only   tool_calls (JSON parsed from LLM response)
         │       │
         ▼       ▼
      Done    ┌──────────────────┐
              │ Execute tools    │ ◄── Agent._execute_tool_call()
              └────────┬─────────┘
                       │
                       ▼
              ┌──────────────────┐
              │ Store tool turn  │ ◄── context.add_tool_turn()
              │ in context       │
              └────────┬─────────┘
                       │
                       ▼
              Loop back to build_messages()
              (until text response or max_tool_rounds)
```

### Tool System

Tools are async functions decorated with `@tool` or `@registry.register`. Type hints and docstrings are automatically converted to JSON Schema for the LLM.

```python
from oaf import ToolRegistry

registry = ToolRegistry()

@registry.register
async def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Weather in {city}: 72°F, sunny"
```

**Type inference:** `_python_type_to_json_schema()` in `tools/tool.py` converts Python types → JSON Schema. Supports: `str`, `int`, `float`, `bool`, `list`, `dict`, `Optional[T]`, `list[T]`, `dict[K,V]`, `Union`, `str | int`, `Enum` subclasses, nested generics.

**Tool groups:** Organize related tools with `BaseToolGroup` + `@tool_method`:

```python
from oaf import BaseToolGroup, tool_method, ToolRegistry

class MathTools(BaseToolGroup):
    name = "math"
    @tool_method
    async def add(self, a: int, b: int) -> str:
        return str(a + b)

registry = ToolRegistry()
registry.register_group(MathTools())
# Registers as "math.add"
```

### Context System

`BaseContext` is the **single subclass point** for custom prompt engineering. It owns:
- **Message storage** — `add_message()`, `add_tool_turn()`, `get_messages()`
- **Tool awareness** — `tools: ToolRegistry` (user-provided tools)
- **Prompt assembly** — `build_messages()` decides what the LLM sees

The agent passes its `internal_tools` (empty `ToolRegistry`, reserved for future built-in capabilities) into `build_messages(internal_tools=...)` at call time. This means **multiple agents can safely share a context** without overwriting each other's internal tools.

**Default implementation:** `ConversationalInMemory` — in-memory context with configurable `max_messages` and `max_tokens` limits. Uses tiktoken (cl100k_base) for token counting with `len//4` heuristic fallback.

**Custom contexts:** Subclass `BaseContext` to add vector DB connections, dynamic prompt sections, tool output retention policies, etc.

### Hooks System

Lifecycle events you can tap into:

| Event | When | Can Mutate? |
|-------|------|-------------|
| `before_message` | Before sending to LLM | Yes (replace message text) |
| `after_message` | After LLM responds | No |
| `before_tool_call` | Before tool execution | Yes (replace arguments) |
| `after_tool_call` | After tool returns | No |
| `on_stream_chunk` | Each streaming token | No |
| `on_error` | Any exception | No |
| `on_context_update` | Context/memory changes | No |
| `system_prompt_change` | System prompt updated | No |

Two ways to use:

```python
# 1. Subclass
class MyHooks(Hooks):
    async def before_message(self, message, role, messages):
        print(f"Sending: {message}")

# 2. Ad-hoc callbacks
hooks = Hooks()
hooks.on("on_error", my_error_handler)
```

Class method fires first, then registered callbacks. For `before_*` events, last non-None return wins.

---

## API Reference

### Agent

```python
agent = Agent(
    model="gpt-4.1-nano",           # or "claude-sonnet-4-20250514"
    system_prompt="You are helpful.",# used only if no context provided
    temperature=0.7,                 # 0.0–2.0
    max_tokens=None,                 # None = provider default
    max_tool_rounds=10,              # safety limit for tool loops
    context=ConversationalInMemory(  # context owns tools + prompt assembly
        system_prompt="You are helpful.",
        tools=registry,
        max_messages=100,
        max_tokens=8000,
    ),
    tools=registry,                  # shortcut if no context provided
    hooks=Hooks(),                   # lifecycle hooks
)

# Blocking call
response = await agent.message("Hello!", role="user")
print(response.text)

# Streaming
async for chunk in agent.message_stream("Tell me a story"):
    print(chunk.delta_text, end="")

# System prompt
await agent.change_system_prompt("New prompt")

# History
messages = agent.get_context()
agent.reset()
```

### ConversationalInMemory

```python
ctx = ConversationalInMemory(
    system_prompt="You are helpful.",
    tools=registry,          # ToolRegistry, optional
    max_messages=100,        # message count limit, optional
    max_tokens=8000,         # token budget limit, optional
)

ctx.start_turn()
ctx.add_message(Message(role="user", content="Hello"))
messages = ctx.build_messages(internal_tools=agent_internal_tools)
# → [system_msg (with tool descriptions), user_msg]
```

### ToolRegistry

```python
registry = ToolRegistry()

@registry.register
async def search(query: str) -> str:
    """Search the web."""
    return f"Results for {query}"

registry.register_group(MathTools())

tool = registry.get("search")         # Tool or None
params = registry.to_tool_params()    # list[ToolParam] for prompt injection
len(registry)                          # number of registered tools
```

---

## LLM Client

The `llmclient` subpackage is a standalone unified client for OpenAI and Anthropic. It can be used independently of the agent framework.

### Usage

```python
from oaf.llmclient import LLMClient, SyncLLMClient, Message

# Async
client = LLMClient()
response = await client.chat("gpt-4.1-nano", [Message(role="user", content="Hello")])
print(response.text)

# Sync
client = SyncLLMClient()
response = client.chat("gpt-4.1-nano", [Message(role="user", content="Hello")])

# Streaming
async for chunk in client.chat_stream("gpt-4.1-nano", messages):
    print(chunk.delta_text, end="")

# Embeddings (OpenAI only)
emb = await client.embed("text-embedding-3-small", "Hello world")
```

### Provider Auto-Detection

| Prefix | Provider |
|--------|----------|
| `gpt-*`, `o1`, `o3`, `o4`, `text-embedding-*` | OpenAI |
| `claude*` | Anthropic |

### Key Types

- **`Message`** — `role`, `content`, `tool_calls`, `tool_call_id`
- **`ChatResponse`** — `text`, `choices`, `usage`, `request_payload`, `tools_called`
- **`StreamChunk`** — `delta_text`, `finish_reason`, `usage`
- **`ToolCall`** — `id`, `name`, `arguments`, `parsed_arguments`
- **`ToolParam`** — `type`, `function` (schema definition for a tool)

### Error Hierarchy

All inherit from `LLMError`: `AuthenticationError`, `RateLimitError`, `InvalidRequestError`, `NotFoundError`, `ServerError`, `StreamError`, `TimeoutError`, `ConnectionError`.

### Model Registry

Built-in metadata for all current OpenAI and Anthropic models:

```python
from oaf.llmclient import Models, get_model, list_models

model = Models.GPT_4_1_NANO
print(model.context_window)  # 1_000_000
all_openai = list_models("openai")
```

---

## Design Decisions

| Decision | Why |
|----------|-----|
| **JSON-based tool calling** | Tools described in system prompt as JSON schema. LLM returns JSON with tool calls. Intentionally not using native OpenAI/Anthropic tool APIs — we own the format. See `parser.py` and `prompts/raw.py`. |
| **Tool results as user messages** | Tool results sent as `role="user"` JSON, not `role="tool"`. By design. |
| **Async-first** | All core APIs are async. `SyncLLMClient` wraps for sync contexts. |
| **Context owns everything** | `BaseContext` is the single subclass point — no separate PromptBuilder, no separate memory store. Override `build_messages()` and you control what the LLM sees. |
| **Internal tools via kwargs** | Agent passes `internal_tools` into `build_messages()` at call time. Multiple agents safely share a context without conflicts. |
| **No eval()** | Math uses AST-based `_safe_eval()`. |
| **Flat over deep** | If it can be a function, it's not a class. No chains, no wrappers, no shims. |

### Anti-Patterns Avoided

| Problem (see: LangChain) | OAF approach |
|---------------------------|-------------|
| 15 abstraction layers deep | Flat — Agent → LLMClient, that's it |
| Can't see the prompt | `request_payload` on every response |
| Massive dependency tree | 3 core deps: `openai`, `anthropic`, `tiktoken` |
| Opaque memory management | Explicit context with inspectable limits |
| Sequential tool execution | Async loop with hooks at every step |

---

## Build & Test

### Setup

```bash
git clone https://github.com/devincii-io/scope-oaf.git
cd scope-oaf
python -m venv .venv
.venv\Scripts\activate      # Windows
source .venv/bin/activate   # Linux/macOS
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest tests/ -v             # 82 offline unit tests (no API keys)
```

Integration tests (need `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`):

```bash
python -m oaf.llmclient.test_llmclient
```

### Examples

```bash
python chat.py               # Interactive REPL
python web.py                # Web UI at http://localhost:8080 (needs aiohttp)
```

### Dependencies

| Scope | Packages |
|-------|----------|
| Core | `openai>=2.30`, `anthropic>=0.88`, `tiktoken>=0.7` |
| Dev | `pytest`, `pytest-asyncio`, `python-dotenv` |
| Web | `aiohttp`, `python-dotenv` |

---

## Release Workflow

**Single source of truth for version:** `pyproject.toml → [project] → version`

Versioning: SemVer (`MAJOR.MINOR.PATCH`). Current: **0.2.0**.

### Steps

1. Bump version in `pyproject.toml`
2. `git commit -m "release: vX.Y.Z" && git push origin master`
3. GitHub Actions auto-publishes to PyPI via trusted publishing (OIDC)
4. Verify at https://pypi.org/project/scope-oaf/

### Branch Workflow

- **`dev`** — all development happens here. Push after every logical change.
- **`master`** — releases only. Push triggers PyPI publish.

---

## Current Status & Task List

### What's Built (working, tested)

- [x] **Agent** — async LLM call + tool execution loop with configurable max rounds
- [x] **Tool system** — `@tool` decorator, `@tool_method`, `BaseToolGroup`, `ToolRegistry`, full type inference pipeline (Python types → JSON Schema)
- [x] **Context system** — `BaseContext` ABC as single subclass point, `ConversationalInMemory` with message/token limits, atomic tool turns, tiktoken-based counting
- [x] **Prompt assembly** — context owns prompt building, `build_tool_prompt()` utility in `prompts/raw.py`, tool descriptions injected into system prompt
- [x] **Internal tools architecture** — agent-owned `ToolRegistry` passed via `build_messages(internal_tools=...)`, multi-agent safe
- [x] **Hooks** — 8 lifecycle events, class-based + ad-hoc registration, mutation support for `before_*` events
- [x] **LLM client** — unified async client for OpenAI + Anthropic, streaming, embeddings, tool calling
- [x] **Sync wrapper** — `SyncLLMClient` for non-async contexts
- [x] **Model registry** — all current OpenAI + Anthropic models with pricing metadata
- [x] **JSON parser** — extracts tool calls from LLM text responses
- [x] **Error hierarchy** — typed exceptions for all provider failure modes
- [x] **Streaming** — `message_stream()` with per-chunk hooks
- [x] **Examples** — terminal REPL (`chat.py`) + web UI (`web.py`)
- [x] **82 unit tests** — all passing, no API keys needed

### What's Planned (from DESIGN.md, not yet built)

- [ ] **Built-in agent tools** — filesystem (`read_file`, `write_file`, `list_dir`), code execution (`python_exec`, `shell_exec`), web (`web_search`, `fetch_url`), math (`calculator`), time tools. These would go into `_internal_tools`.
- [ ] **Parallel tool execution** — when LLM returns multiple tool calls, execute them concurrently with `asyncio.gather` instead of sequentially.
- [ ] **Agent-as-a-tool** — expose an agent as a callable tool for another agent (`agent.as_tool()`), enabling multi-agent orchestration.
- [ ] **Router agent** — dispatch to specialized agents based on query type.
- [ ] **Context strategies** — beyond simple sliding window: summary-based (compress old history), priority-based (score messages, drop lowest).
- [ ] **Persistent memory** — SQLite-backed key-value store with embeddings search for long-term facts.
- [ ] **Confirmation hooks** — `requires_confirmation` flag on tools for interactive approval.
- [ ] **Tool timeouts** — per-tool configurable timeout with `asyncio.wait_for`.
- [ ] **Full turn inspection** — `AgentResponse` with `turns: list[Turn]` exposing every request payload, tool call, and result per LLM round-trip.

### Architecture Improvements to Consider

- [ ] **Custom context implementations** — examples/docs for vector DB context, RAG context, multi-session context
- [ ] **Dynamic system prompt fields** — template variables in system prompt that resolve at `build_messages()` time
- [ ] **Tool output retention control** — context-level policy for how much tool output to keep vs. summarize
- [ ] **More hooks** — `before_llm_call` (after messages are assembled but before sending), `on_turn_complete`
- [ ] **Provider extensibility** — plugin system for adding new LLM providers beyond OpenAI/Anthropic
