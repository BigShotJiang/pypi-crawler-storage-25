# OAF — Project Guidelines

## What This Is

OAF (OpenAgentFramework) is a **minimal, transparent** Python framework for building AI agents with tool calling. Published as `scope-oaf` on PyPI. Python 3.11+.

**Core philosophy: zero magic.** Every prompt, tool call, and LLM decision must be inspectable. No hidden abstractions. Flat architecture over deep chains.

## Architecture

```
oaf/
├── agent.py                 # Agent class — LLM call + tool execution loop
├── hooks.py                 # Async lifecycle event system (before/after hooks)
├── context/
│   ├── base.py              # BaseContext interface (storage + prompt assembly)
│   └── ConversationalInMemory.py  # In-memory context with message/token limits
├── llmclient/               # Unified LLM client (can be used standalone)
│   ├── client.py            # LLMClient — main async API (chat, chat_stream, embed)
│   ├── sync_client.py       # SyncLLMClient — thread-safe sync wrapper
│   ├── types.py             # Message, ChatResponse, ToolCall, StreamChunk, etc.
│   ├── errors.py            # LLMError hierarchy (AuthenticationError, RateLimitError, etc.)
│   ├── models.py            # Model registry with metadata (context windows, pricing)
│   ├── parser.py            # JSON response parser for tool calling
│   └── providers/
│       ├── base.py          # BaseProvider interface
│       ├── openai_provider.py
│       └── anthropic_provider.py
├── prompts/
│   └── raw.py               # Tool prompt templates + build_tool_prompt() utility
└── tools/
    ├── tool.py              # @tool decorator, Tool class, @tool_method, BaseToolGroup
    └── registry.py          # ToolRegistry — manages tool registration and lookup
```

**Top-level exports** (from `oaf`): `Agent`, `Hooks`, `BaseContext`, `ConversationalInMemory`, `Tool`, `tool`, `tool_method`, `BaseToolGroup`, `ToolRegistry`.

### Where to Find Things

| What | Where |
|------|-------|
| Agent loop (LLM call + tool execution) | `oaf/agent.py` |
| Tool decorator, type inference, groups | `oaf/tools/tool.py` |
| Tool registration and lookup | `oaf/tools/registry.py` |
| LLM client (chat, stream, embed) | `oaf/llmclient/client.py` |
| Provider implementations | `oaf/llmclient/providers/openai_provider.py`, `anthropic_provider.py` |
| Response/tool/message types | `oaf/llmclient/types.py` |
| Error hierarchy | `oaf/llmclient/errors.py` |
| Model registry (metadata, pricing) | `oaf/llmclient/models.py` |
| JSON response parser | `oaf/llmclient/parser.py` |
| Sync wrapper | `oaf/llmclient/sync_client.py` |
| Context interface (storage + prompt assembly) | `oaf/context/base.py` |
| In-memory context (token counting, prompt assembly) | `oaf/context/ConversationalInMemory.py` |
| Lifecycle hooks | `oaf/hooks.py` |
| Tool prompt templates + builder | `oaf/prompts/raw.py` |
| Offline tests | `tests/` |
| Integration tests (API keys needed) | `oaf/llmclient/test_llmclient.py`, `test_llmclient_extras.py` |
| Example REPL | `chat.py` |
| Example Web UI | `web.py` + `web_ui.html` |
| Consolidated project docs | `OAF.md` |

## Key Design Decisions

- **JSON-based tool calling** — Tools are described in the system prompt as JSON schema. The LLM returns JSON with tool calls. This is intentional and owned by us — not using native OpenAI/Anthropic tool APIs. See `llmclient/parser.py` and `prompts/raw.py`.
- **Tool results as user messages** — Tool call results are sent back as `role="user"` JSON messages, not `role="tool"`. This is by design.
- **Async-first** — All core APIs are async. `SyncLLMClient` is a thread-safe wrapper for sync contexts.
- **Context owns prompt assembly** — `BaseContext` is the single subclass point for message storage, tool awareness, AND prompt building. No separate `PromptBuilder` — the context's `build_messages()` decides what the LLM sees, including tool descriptions. Tools live in the context (`context.tools`), and the agent passes `internal_tools` (its own `ToolRegistry`, empty for now — reserved for built-in agent capabilities) via `build_messages(internal_tools=...)` at call time. This means multiple agents can safely share a context without overwriting each other's internal tools. Use `build_tool_prompt()` from `oaf.prompts.raw` to render tool descriptions using the framework's internal format.
- **Token counting** — Uses `tiktoken` (cl100k_base) with fallback to heuristic. See `ConversationalInMemory._message_tokens()`.
- **Provider detection** — Model name prefix determines provider (claude* → Anthropic, gpt-*/o1/o3/o4 → OpenAI). See `llmclient/client.py:_detect_provider()`.

### Key Integration Points

- `LLMClient._parse_tool_response()` uses `parser.py` to extract JSON tool calls from LLM text output.
- `Agent._tool_loop()` executes tool calls and re-sends results until the LLM gives a final text response.
- `BaseContext.build_messages()` is the single point that assembles what the LLM sees — including tool descriptions. Agent calls `context.build_messages()` before every LLM request.
- `build_tool_prompt()` in `prompts/raw.py` formats ToolParams into the text block injected into the system prompt. Context implementations call this in `build_messages()`.
- `ConversationalInMemory` uses tiktoken for token counting (fallback: `len//4` heuristic).
- Hooks system (`hooks.py`): class method fires first, then registered callbacks. `before_*` events allow mutation (last non-None return wins).

### Type Inference Pipeline

`_python_type_to_json_schema()` in `tools/tool.py` converts Python type annotations to JSON Schema. Supported: `str`, `int`, `float`, `bool`, `list`, `dict`, `Optional[T]`, `list[T]`, `dict[K,V]`, `Union`, `str | int`, `Enum` subclasses, nested generics. `_build_parameters_schema()` walks function signature + type hints → produces the full JSON Schema `properties` + `required` object.

## Code Conventions

- All tool functions must be `async`. Sync functions passed to `@tool` raise `TypeError`.
- Type hints on tool parameters map to JSON Schema via `_python_type_to_json_schema()` in `tools/tool.py`. Supports: basic types, `Optional[T]`, `list[T]`, `dict[K,V]`, `Union`, `Enum`.
- Logging uses `logging.getLogger(__name__)` — no print statements in library code.
- No `eval()` anywhere — math evaluation uses AST-based `_safe_eval()`.
- Hooks fire class method first, then registered callbacks. For `before_*` events, last non-None return wins.
- Version is single-source from `pyproject.toml`, read at runtime via `importlib.metadata`.

## Build & Test

```bash
pip install -e ".[dev]"      # Install in editable mode with dev deps
pytest tests/ -v             # Run offline unit tests (no API keys needed)
python chat.py               # Interactive REPL (needs OPENAI_API_KEY)
python web.py                # Web UI (needs aiohttp: pip install -e ".[web]")
```

Integration tests (need API keys): `python -m oaf.llmclient.test_llmclient`

## Dependencies

Core: `openai>=2.30`, `anthropic>=0.88`, `tiktoken>=0.7`
Dev: `pytest`, `pytest-asyncio`, `python-dotenv`
Web: `aiohttp`, `python-dotenv`

## Workflow Rules

### Iteration Discipline

- **1–4 functions per iteration.** Never write more than 4 new/changed functions before stopping to verify they work. Smaller batches = fewer compound bugs.
- **Do NOT run tests after every single change.** Tests run once at the end of a logical unit of work, not after every file edit.
- **Git after every code change.** After completing a logical change: `git add -A && git commit -m "<concise msg>" && git push origin dev`. Always push to `dev`, never directly to `master`.

### Code Quality

- **No monkey-patching.** Modify the actual class/function. Create shared state, base classes, or utility functions instead.
- **No backward compatibility.** If a change requires rewriting multiple modules, endpoints, adapters, or providers — do it. Rip out the old code entirely. No shims, wrappers, or deprecation layers.
- **Shared code over duplication.** If two modules need the same logic, extract it. Don't copy-paste between files.
- **Keep it flat.** If it can be a function, don't make it a class.

### Don't Do These

- Don't ask permission for obvious things — just do it.
- Don't add comments explaining obvious code.
- Don't create wrapper functions for single-use operations.
- Don't add `# type: ignore` — fix the actual type issue.
- Don't leave TODO/FIXME/HACK comments — fix it now or don't touch it.
- Don't import inside functions unless there's a real circular dependency.
- Don't add defensive None checks for internal code that never produces None.
- Don't create new files unless necessary — prefer adding to existing modules.
- Don't suggest multiple options and ask which one — pick the best approach and implement it.

## Custom Agent

After completing a non-trivial iteration, ask yourself: **should we create or update a custom agent?** Create one when:
- A task keeps recurring (e.g. "add a new provider", "write integration tests for X").
- Specific rules need enforcing that don't belong in these global instructions.
- Exploring the codebase requires reading too much context — an agent with a focused module map and search tools can do it faster in isolation.

Don't create agents after simple one-off tasks. Only when a pattern emerges.

## Thinking Discipline

Think straight. For any task, ask yourself a few focused questions to decide the approach, then execute. Don't loop on the same problem — if after 2-3 questions you're still unsure, pick the most reasonable path and go. Overthinking wastes more time than a slightly imperfect first attempt that you can fix in the next iteration.

## Keeping Instructions Current

When the project structure, conventions, or design decisions change, **update these instructions to match.** Stale instructions are worse than no instructions. If you notice something in this file that no longer reflects the codebase — fix it immediately as part of the current change.
