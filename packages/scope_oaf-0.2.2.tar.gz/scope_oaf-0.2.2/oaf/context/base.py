"""BaseContext — abstract base class for all context implementations.

A context is the single object that owns message storage, tool awareness, AND prompt
assembly. Subclass this to build custom context-engineered agents with vector DB
connections, dynamic prompt sections, tool output retention policies, etc.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..llmclient import Message, ToolParam
from ..tools import ToolRegistry


class BaseContext(ABC):
    """Abstract base for context — stores messages, knows tools, builds the final prompt.

    This is the single subclass point for custom prompt engineering. Each implementation
    controls how messages are stored, which tools the agent has, and what the LLM sees.

    Attributes:
        tools: User-provided tools the agent can call. Managed by the context.

    Lifecycle per agent turn:
      1. ``start_turn()`` — mark iteration start
      2. ``add_message()`` / ``add_tool_turn()`` — record what happened
      3. ``build_messages()`` — assemble the final message list for the LLM
         (including tool descriptions from ``tools`` and any ``internal_tools`` passed via kwargs)

    To build a sophisticated agent, subclass this and override ``build_messages()``.
    Use ``build_tool_prompt()`` from ``oaf.prompts.raw`` to render tool descriptions
    into the system prompt using the framework's internal format, or roll your own.
    """

    tools: ToolRegistry

    # ── Message storage ───────────────────────────────────────────────────

    @abstractmethod
    def start_turn(self) -> None:
        """Mark the beginning of a new agent turn/iteration."""

    @abstractmethod
    def add_message(self, message: Message) -> None:
        """Record a message (user, assistant, or tool result).

        Args:
            message: The Message to store.
        """

    @abstractmethod
    def add_tool_turn(self, assistant_message: Message, tool_results_message: Message) -> None:
        """Record a tool turn as an atomic group (assistant tool-call + user tool-results).

        During truncation the two messages are dropped together, never split.
        """

    @abstractmethod
    def get_messages(self) -> list[Message]:
        """Return the stored conversation messages (excluding the system prompt).

        Implementations may truncate or summarise to stay within limits.
        """

    @abstractmethod
    def clear(self) -> None:
        """Reset all stored history."""

    @abstractmethod
    def turn_count(self) -> int:
        """Return the number of completed turns."""

    # ── Tool access ───────────────────────────────────────────────────────

    def _all_tool_params(self, internal_tools: ToolRegistry | None = None) -> list[ToolParam]:
        """Return combined ToolParams from user tools and internal tools.

        Args:
            internal_tools: Agent-owned internal tools, passed at call time.
                            Each agent owns its own — contexts never store these.

        Used by ``build_messages()`` to render tool descriptions into the prompt.
        """
        params = self.tools.to_tool_params() if len(self.tools) else []
        if internal_tools and len(internal_tools):
            params = params + internal_tools.to_tool_params()
        return params

    # ── Prompt assembly ───────────────────────────────────────────────────

    @abstractmethod
    def build_messages(self, **kwargs: Any) -> list[Message]:
        """Assemble the final message list sent to the LLM.

        This is the single point that decides what the model sees.
        Implementations should:
          1. Build the system prompt (with tool descriptions if tools exist).
          2. Append conversation messages.

        Use ``_all_tool_params(internal_tools=...)`` to get the combined tool list, and
        ``build_tool_prompt()`` from ``oaf.prompts.raw`` to format them.

        Args:
            **kwargs: Extra arguments forwarded from the agent's chat call.

        Returns:
            The complete list of Messages to send to the LLM.
        """

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the current system prompt text."""

    @abstractmethod
    def update_system_prompt(self, new_prompt: str, **kwargs: Any) -> None:
        """Replace or modify the system prompt.

        Args:
            new_prompt: The new system prompt text.
            **kwargs: Extra context for the update.
        """