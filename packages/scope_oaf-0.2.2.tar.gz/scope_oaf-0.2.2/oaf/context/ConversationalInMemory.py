"""ConversationalInMemory — an in-memory only implementation of conversational context."""

from __future__ import annotations

import logging
from typing import Any

from ..llmclient import Message
from ..tools import ToolRegistry
from ..prompts.raw import build_tool_prompt
from .base import BaseContext

logger = logging.getLogger(__name__)

try:
    import tiktoken
    _DEFAULT_ENC = tiktoken.get_encoding("cl100k_base")
except Exception:  # ImportError or download failure
    _DEFAULT_ENC = None


class ConversationalInMemory(BaseContext):
    """In-memory conversation context with message and token limits.

    Stores messages, owns the system prompt and tools, and assembles the final
    message list for the LLM. Enforces two limits:
      - max_messages: hard cap on stored messages (drops oldest first).
      - max_tokens: approximate token budget (1 token ≈ 4 chars). Drops oldest
        non-system messages when exceeded.

    Usage::

        ctx = ConversationalInMemory(
            system_prompt="You are helpful.",
            tools=registry,
        )
        ctx.start_turn()
        ctx.add_message(Message(role="user", content="Hello"))
        messages = ctx.build_messages()  # [system (with tool descriptions), user]

    Args:
        system_prompt: The system prompt text.
        tools: User-provided tool registry. Defaults to empty.
        max_messages: Maximum number of conversation messages to keep. None for unlimited.
        max_tokens: Approximate token budget for the history. None for unlimited.
    """

    def __init__(
        self,
        *,
        system_prompt: str = "You are a helpful assistant.",
        tools: ToolRegistry | None = None,
        max_messages: int | None = None,
        max_tokens: int | None = None,
    ):
        self._system_prompt = system_prompt
        self.tools = tools or ToolRegistry()
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        self._entries: list[tuple[int, list[Message]]] = []
        self._turns: int = 0

    def start_turn(self) -> None:
        """Mark the beginning of a new agent turn."""
        self._turns += 1

    def add_message(self, message: Message) -> None:
        """Store a message and enforce limits.

        Args:
            message: The Message to store (any role).
        """
        self._entries.append((self._turns, [message]))
        self._enforce_limits()

    def add_tool_turn(self, assistant_message: Message, tool_results_message: Message) -> None:
        """Store a tool turn (assistant call + user results) as an atomic group."""
        self._entries.append((self._turns, [assistant_message, tool_results_message]))
        self._enforce_limits()

    def get_messages(self) -> list[Message]:
        """Return the current message list for the LLM."""
        return [msg for _, msgs in self._entries for msg in msgs]

    def clear(self) -> None:
        """Reset all history and turn count."""
        self._entries.clear()
        self._turns = 0

    def turn_count(self) -> int:
        """Return the number of turns started so far."""
        return self._turns

    # ── Prompt assembly ───────────────────────────────────────────────────

    def build_messages(self, **kwargs: Any) -> list[Message]:
        """Prepend the system prompt (with tool descriptions) to stored messages.

        If tools are registered (user tools or agent-internal tools), their descriptions
        are injected into the system prompt using the framework's internal format.

        Args:
            **kwargs: Accepts ``internal_tools`` (ToolRegistry) — agent-owned tools
                      passed at call time. Subclasses can use additional kwargs
                      for dynamic prompt sections (e.g. vector DB query params).

        Returns:
            [system_message] + conversation messages.
        """
        system_content = self._system_prompt
        internal_tools = kwargs.get("internal_tools")
        tool_params = self._all_tool_params(internal_tools=internal_tools)
        if tool_params:
            tool_text = build_tool_prompt(tool_params)
            system_content = tool_text + "\n\n" + system_content
        system_msg = Message(role="system", content=system_content)
        return [system_msg] + self.get_messages()

    def get_system_prompt(self) -> str:
        """Return the current system prompt text."""
        return self._system_prompt

    def update_system_prompt(self, new_prompt: str, **kwargs: Any) -> None:
        """Replace the system prompt.

        Args:
            new_prompt: The new system prompt text.
            **kwargs: Ignored in default implementation.
        """
        self._system_prompt = new_prompt

    # ── internals ─────────────────────────────────────────────────────────

    def _enforce_limits(self) -> None:
        """Drop oldest non-system entries to stay within limits."""
        # Message count limit
        if self.max_messages is not None:
            while self._message_count() > self.max_messages:
                self._drop_oldest()

        # Token limit (approximate: 1 token ≈ 4 chars)
        if self.max_tokens is not None:
            while self._estimate_tokens() > self.max_tokens and len(self._entries) > 1:
                self._drop_oldest()

    def _drop_oldest(self) -> None:
        """Remove the oldest non-system entry (all messages in the group)."""
        for i, (_, msgs) in enumerate(self._entries):
            if msgs[0].role != "system":
                self._entries.pop(i)
                return

    def _message_count(self) -> int:
        """Total number of messages across all entries."""
        return sum(len(msgs) for _, msgs in self._entries)

    @staticmethod
    def _message_tokens(msg: Message) -> int:
        """Token estimate for a single message. Uses tiktoken when available."""
        text = ""
        if isinstance(msg.content, str):
            text = msg.content
        elif isinstance(msg.content, list):
            text = " ".join(p for p in msg.content if isinstance(p, str))

        if _DEFAULT_ENC is not None:
            return len(_DEFAULT_ENC.encode(text)) + 4  # +4 for role/overhead
        # fallback: ~1 token per 4 chars
        return len(text) // 4 + 4

    def _estimate_tokens(self) -> int:
        """Estimate total tokens across all stored messages."""
        return sum(self._message_tokens(m) for _, msgs in self._entries for m in msgs)