"""Raw prompt templates — all internal text blocks used by the framework.

These are the building blocks that get assembled into system prompts.
Keep them as simple format-string templates with {placeholders} where needed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..llmclient.types import ToolParam

# ── Tool system ───────────────────────────────────────────────────────────────

TOOL_HEADER = "You have access to the following tools:\n"

# Per-tool line: {name}, {signature}, {description}
TOOL_ENTRY = """\
- {name}({signature})
  {description}"""

# JSON response schema shown to the model
TOOL_JSON_SCHEMA = """\
You must respond with a JSON object with this exact structure:
{
  "tool_calls": [{"name": "tool_name", "args": {"param": "value"}}],
  "response": "your text response to the user"
}"""

# Rules appended after the schema
TOOL_RULES = """\
Rules:
- Always respond with valid JSON only. No text outside the JSON object.
- "tool_calls" is optional. Include it only when you need to call tools.
- "response" is optional. Include it when you have a message for the user.
- At least one of "tool_calls" or "response" must be present.
- You may include both "tool_calls" and "response" in the same reply. For example, saying "Checking the weather for you..." in "response" while also calling a weather tool.
- "args" must be an object matching the tool parameters described above.
- CRITICAL: When a tool exists that can fulfill the user's request, you MUST include "tool_calls" to call it. NEVER simulate, fabricate, or guess what a tool would return. If you respond without calling an available tool that is relevant, that is an error.
- When you call tools, do NOT include "response" — wait for the tool results first."""

# ── Tool groups ───────────────────────────────────────────────────────────────

# Header for a group section: {group_name}, {group_description}
TOOL_GROUP_HEADER = """\

[{group_name}] — {group_description}"""

# ── Parameter formatting ─────────────────────────────────────────────────────

# Single param inside a tool signature: {name}, {type}, {required_tag}, {default_tag}
TOOL_PARAM = "{name}: {type}{required_tag}{default_tag}"

# Tag appended to required params
TOOL_PARAM_REQUIRED_TAG = " [required]"


# ── Tool prompt builder ──────────────────────────────────────────────────────

def _format_tool(t: ToolParam) -> str:
    """Format a single ToolParam into a readable entry for the system prompt."""
    fn = t.function
    params = fn.parameters
    props = params.get("properties", {})
    required = set(params.get("required", []))

    param_parts: list[str] = []
    for pname, pdef in props.items():
        ptype = pdef.get("type", "string")
        if pname in required:
            req = TOOL_PARAM_REQUIRED_TAG
            default_tag = ""
        else:
            req = ""
            default_val = pdef.get("default")
            default_tag = f" = {default_val!r}" if default_val is not None else ""
        param_parts.append(TOOL_PARAM.format(
            name=pname, type=ptype, required_tag=req, default_tag=default_tag,
        ))

    sig = ", ".join(param_parts) if param_parts else ""
    return TOOL_ENTRY.format(name=fn.name, signature=sig, description=fn.description)


def build_tool_prompt(tools: list[ToolParam]) -> str:
    """Build a text block describing available tools and the expected JSON output format.

    This is the function that context implementations should call to render tool
    descriptions into the system prompt. The output includes:
      - Tool signatures with parameter types and defaults
      - The JSON response schema the LLM must follow
      - Rules for when/how to call tools

    The templates used (TOOL_HEADER, TOOL_ENTRY, TOOL_JSON_SCHEMA, TOOL_RULES, etc.)
    are defined in this module. To customise how tools appear in the prompt, override
    ``build_messages()`` in your BaseContext subclass and format the tool params yourself
    instead of calling this function.

    Args:
        tools: List of ToolParam objects (from ToolRegistry.to_tool_params()).

    Returns:
        A formatted string block ready to inject into the system prompt.
    """
    if not tools:
        return ""

    # Partition tools into ungrouped and grouped
    ungrouped: list[ToolParam] = []
    groups: dict[str, list[ToolParam]] = {}
    group_descs: dict[str, str] = {}

    for t in tools:
        g = t.function.group
        if g:
            groups.setdefault(g, []).append(t)
            if t.function.group_description:
                group_descs.setdefault(g, t.function.group_description)
        else:
            ungrouped.append(t)

    lines = [TOOL_HEADER]

    for t in ungrouped:
        lines.append(_format_tool(t))

    for group_name, group_tools in groups.items():
        desc = group_descs.get(group_name, "")
        lines.append(TOOL_GROUP_HEADER.format(group_name=group_name, group_description=desc))
        for t in group_tools:
            lines.append(_format_tool(t))

    lines.append("")
    lines.append(TOOL_JSON_SCHEMA)
    lines.append("")
    lines.append(TOOL_RULES)

    return "\n".join(lines)
