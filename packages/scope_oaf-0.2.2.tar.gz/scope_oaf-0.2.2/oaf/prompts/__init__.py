"""Prompt templates — raw text blocks and utility functions used by the framework."""

from .raw import build_tool_prompt

__all__ = ["build_tool_prompt"]
