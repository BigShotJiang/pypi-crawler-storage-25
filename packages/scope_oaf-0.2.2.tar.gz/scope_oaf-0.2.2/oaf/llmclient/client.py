"""
Unified LLM Client — single interface for OpenAI & Anthropic.

Uses official openai and anthropic Python libraries for reliability.
Message in → message out. JSON-based tool calling. Streaming supported.
Embeddings via OpenAI (Anthropic doesn't offer embeddings).
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, AsyncIterator

from .errors import LLMError

logger = logging.getLogger(__name__)
from .parser import ParseError, parse_response
from .providers.anthropic_provider import AnthropicProvider
from .providers.base import BaseProvider
from .providers.openai_provider import OpenAIProvider
from .types import ChatResponse, EmbeddingResponse, Message, StreamChunk, ToolCall, ToolParam

# model prefix → provider name
_ANTHROPIC_PREFIXES = ("claude",)
_OPENAI_PREFIXES = ("gpt-", "o1", "o3", "o4", "chatgpt-", "ft:gpt-", "text-embedding-")


def _detect_provider(model: str) -> str:
    lower = model.lower()
    for prefix in _ANTHROPIC_PREFIXES:
        if lower.startswith(prefix):
            return "anthropic"
    for prefix in _OPENAI_PREFIXES:
        if lower.startswith(prefix):
            return "openai"
    return "openai"


class LLMClient:
    """
    Async unified LLM client.

    Usage:
        client = LLMClient(openai_api_key="sk-...", anthropic_api_key="sk-ant-...")

        resp = await client.chat("gpt-4o", [Message(role="user", content="Hi")])
        resp = await client.chat("claude-sonnet-4-6", [Message(role="user", content="Hi")])

        async for chunk in client.chat_stream("gpt-4o", messages=[...]):
            print(chunk.delta_text, end="")

        # embeddings (OpenAI only)
        emb = await client.embed("text-embedding-3-small", "Hello world")

        await client.close()

    Context manager:
        async with LLMClient() as client:
            resp = await client.chat(...)
    """

    def __init__(
        self,
        *,
        openai_api_key: str | None = None,
        anthropic_api_key: str | None = None,
        openai_base_url: str | None = None,
        anthropic_base_url: str | None = None,
        openai_org_id: str | None = None,
        timeout: float = 120,
        max_retries: int = 2,
    ):
        self._providers: dict[str, BaseProvider] = {}

        oai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")
        if oai_key:
            self._providers["openai"] = OpenAIProvider(
                api_key=oai_key,
                base_url=openai_base_url,
                org_id=openai_org_id,
                timeout=timeout,
                max_retries=max_retries,
            )

        ant_key = anthropic_api_key or os.environ.get("ANTHROPIC_API_KEY")
        if ant_key:
            self._providers["anthropic"] = AnthropicProvider(
                api_key=ant_key,
                base_url=anthropic_base_url,
                timeout=timeout,
                max_retries=max_retries,
            )

    async def __aenter__(self) -> LLMClient:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close all persistent provider connections."""
        for p in self._providers.values():
            await p.close()

    def register_provider(self, name: str, provider: BaseProvider) -> None:
        self._providers[name] = provider

    def _get_provider(self, model: str, provider: str | None = None) -> BaseProvider:
        name = provider or _detect_provider(model)
        if name not in self._providers:
            available = list(self._providers.keys()) or ["none"]
            raise LLMError(
                f"Provider '{name}' not configured. "
                f"Available: {', '.join(available)}. "
                f"Pass the API key or register the provider.",
                provider=name,
            )
        return self._providers[name]

    # ── tool prompt injection ─────────────────────────────────────────────

    @staticmethod
    def _build_tool_prompt(tools: list[ToolParam]) -> str:
        """Build a text block describing available tools and the expected JSON output format."""
        from oaf.prompts.raw import build_tool_prompt
        return build_tool_prompt(tools)

    @staticmethod
    def _inject_tool_prompt(messages: list[Message], tool_prompt: str) -> list[Message]:
        """Prepend tool definitions to the first system message, or insert a new one."""
        messages = list(messages)  # shallow copy
        for i, m in enumerate(messages):
            if m.role == "system":
                combined = tool_prompt + "\n\n" + (m.content if isinstance(m.content, str) else "")
                messages[i] = Message(role="system", content=combined)
                return messages
        # No system message found — prepend one
        messages.insert(0, Message(role="system", content=tool_prompt))
        return messages

    @staticmethod
    def _parse_tool_response(response: ChatResponse) -> ChatResponse:
        """Parse JSON text from the response and populate tool_calls on the message."""
        text = response.text
        if not text:
            return response

        try:
            parsed = parse_response(text)
        except ParseError:
            # If parsing fails, return as-is — let the caller handle retry
            return response

        # Build ToolCall objects from parsed tool calls
        tool_calls: list[ToolCall] | None = None
        if parsed.tool_calls:
            tool_calls = [
                ToolCall(
                    name=tc.name,
                    arguments=json.dumps(tc.args),
                )
                for tc in parsed.tool_calls
            ]

        # Preserve original model output
        response.raw_text = text
        # Update the message directly
        response.message.tool_calls = tool_calls
        response.message.content = parsed.response
        if tool_calls:
            response.finish_reason = "tool_calls"

        return response

    # ── main API ──────────────────────────────────────────────────────────

    async def chat(
        self,
        model: str,
        messages: list[Message],
        *,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        tools: list[ToolParam] | None = None,
        response_format: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        p = self._get_provider(model, provider)
        logger.debug("chat request: model=%s, provider=%s, msg_count=%d, tools=%s",
                     model, type(p).__name__, len(messages), bool(tools))

        if response_format is not None:
            kwargs["response_format"] = response_format

        if tools:
            # JSON-based tool calling: inject tool definitions into the prompt
            tool_prompt = self._build_tool_prompt(tools)
            messages = self._inject_tool_prompt(messages, tool_prompt)

            # Call provider WITHOUT native tools — pure text + JSON mode
            response = await p.chat(
                messages=messages, model=model,
                temperature=temperature, max_tokens=max_tokens,
                stop=stop, top_p=top_p,
                **kwargs,
            )

            # Parse JSON text into ToolCall objects
            return self._parse_tool_response(response)

        return await p.chat(
            messages=messages, model=model,
            temperature=temperature, max_tokens=max_tokens,
            stop=stop, top_p=top_p,
            **kwargs,
        )

    async def chat_stream(
        self,
        model: str,
        messages: list[Message],
        *,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        p = self._get_provider(model, provider)
        async for chunk in p.chat_stream(
            messages=messages, model=model,
            temperature=temperature, max_tokens=max_tokens,
            stop=stop, top_p=top_p, **kwargs,
        ):
            yield chunk

    async def embed(
        self,
        model: str,
        input: str | list[str],
        *,
        provider: str | None = None,
        dimensions: int | None = None,
        **kwargs: Any,
    ) -> EmbeddingResponse:
        p = self._get_provider(model, provider)
        return await p.embed(input=input, model=model, dimensions=dimensions, **kwargs)

    # ── convenience helpers ───────────────────────────────────────────────

    async def ask(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        **kwargs: Any,
    ) -> str:
        msgs: list[Message] = []
        if system:
            msgs.append(Message(role="system", content=system))
        msgs.append(Message(role="user", content=prompt))
        resp = await self.chat(model, msgs, **kwargs)
        return resp.text

    async def ask_stream(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        msgs: list[Message] = []
        if system:
            msgs.append(Message(role="system", content=system))
        msgs.append(Message(role="user", content=prompt))
        async for chunk in self.chat_stream(model, msgs, **kwargs):
            if chunk.delta_text:
                yield chunk.delta_text
