"""Anthropic provider — uses the official anthropic Python library.

Features:
  - Automatic retries with exponential backoff (built into the library)
  - Connection pooling via httpx under the hood
  - Proper SSE streaming via the library's stream API
  - Vision (multimodal) support via content blocks
  - PDF/document support via base64 content blocks
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator

import anthropic

logger = logging.getLogger(__name__)

from ..errors import StreamError, wrap_anthropic_error
from .base import BaseProvider
from ..types import (
    ChatResponse,
    DocumentContent,
    ImageContent,
    Message,
    StreamChunk,
    ToolCall,
    ToolParam,
    Usage,
)


class AnthropicProvider(BaseProvider):
    name = "anthropic"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 120,
        max_retries: int = 2,
    ):
        kwargs: dict[str, Any] = {
            "api_key": api_key,
            "timeout": timeout,
            "max_retries": max_retries,
        }
        if base_url:
            kwargs["base_url"] = base_url
        self._client = anthropic.AsyncAnthropic(**kwargs)

    async def close(self) -> None:
        await self._client.close()

    # ── unified → Anthropic ───────────────────────────────────────────────

    @staticmethod
    def _convert_messages(messages: list[Message]) -> tuple[str | None, list[dict[str, Any]]]:
        system: str | None = None
        out: list[dict[str, Any]] = []

        for m in messages:
            if m.role == "system":
                if isinstance(m.content, str):
                    system = (system + "\n" + m.content) if system else m.content
                continue

            # Tool result message → user role with tool_result block
            if m.role == "tool":
                out.append({
                    "role": "user",
                    "content": m.content or "",
                })
                continue

            if isinstance(m.content, list):
                parts: list[dict[str, Any]] = []
                for block in m.content:
                    if isinstance(block, str):
                        parts.append({"type": "text", "text": block})
                    elif isinstance(block, ImageContent):
                        if block.base64_data:
                            parts.append({
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": block.media_type,
                                    "data": block.base64_data,
                                },
                            })
                        elif block.url:
                            parts.append({
                                "type": "image",
                                "source": {"type": "url", "url": block.url},
                            })
                    elif isinstance(block, DocumentContent):
                        parts.append({
                            "type": "document",
                            "source": {
                                "type": "base64",
                                "media_type": block.media_type,
                                "data": block.base64_data,
                            },
                        })
                out.append({"role": m.role, "content": parts})
                continue

            # Assistant message with tool calls → content blocks
            if m.role == "assistant" and m.tool_calls:
                blocks: list[dict[str, Any]] = []
                if m.content:
                    blocks.append({"type": "text", "text": m.content})
                for tc in m.tool_calls:
                    blocks.append({
                        "type": "text",
                        "text": f"Tool call: {tc.name}({tc.arguments})",
                    })
                out.append({"role": "assistant", "content": blocks})
                continue

            out.append({"role": m.role, "content": m.content or ""})

        return system, out

    # ── Anthropic response → unified ─────────────────────────────────────

    @staticmethod
    def _parse_response(response: Any) -> ChatResponse:
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                import json as _json
                tool_calls.append(ToolCall(
                    name=block.name,
                    arguments=_json.dumps(block.input) if isinstance(block.input, dict) else str(block.input),
                ))

        content = "\n".join(text_parts) if text_parts else None

        stop_reason = response.stop_reason or ""
        finish_map = {
            "end_turn": "stop",
            "stop_sequence": "stop",
            "max_tokens": "length",
            "tool_use": "tool_calls",
        }

        message = Message(
            role="assistant",
            content=content,
            tool_calls=tool_calls if tool_calls else None,
        )

        usage = Usage(
            prompt_tokens=response.usage.input_tokens,
            completion_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
        )

        return ChatResponse(
            id=response.id or "",
            model=response.model or "",
            message=message,
            finish_reason=finish_map.get(stop_reason, stop_reason),
            usage=usage,
            provider="anthropic",
            raw=response,
        )

    # ── non-streaming ─────────────────────────────────────────────────────

    async def chat(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        tools: list[ToolParam] | None = None,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        system, msgs = self._convert_messages(messages)

        params: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or 4096,
        }
        if system:
            params["system"] = system
        if temperature is not None:
            params["temperature"] = temperature
        if stop:
            params["stop_sequences"] = [stop] if isinstance(stop, str) else stop
        if top_p is not None:
            params["top_p"] = top_p
        if tools:
            params["tools"] = [
                {
                    "name": t.function.name,
                    "description": t.function.description,
                    "input_schema": t.function.parameters,
                } for t in tools
            ]
        if tool_choice is not None:
            choice_map = {"auto": {"type": "auto"}, "required": {"type": "any"}, "none": {"type": "none"}}
            params["tool_choice"] = choice_map.get(tool_choice, {"type": "auto"})
        params.update(kwargs)

        try:
            response = await self._client.messages.create(**params)
        except anthropic.APIError as e:
            raise wrap_anthropic_error(e) from e

        result = self._parse_response(response)
        result.request_payload = params
        return result

    # ── streaming ─────────────────────────────────────────────────────────

    async def chat_stream(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        system, msgs = self._convert_messages(messages)

        params: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or 4096,
            "stream": True,
        }
        if system:
            params["system"] = system
        if temperature is not None:
            params["temperature"] = temperature
        if stop:
            params["stop_sequences"] = [stop] if isinstance(stop, str) else stop
        if top_p is not None:
            params["top_p"] = top_p
        params.update(kwargs)

        try:
            stream = self._client.messages.stream(**{k: v for k, v in params.items() if k != "stream"})
        except anthropic.APIError as e:
            raise wrap_anthropic_error(e) from e

        try:
            async with stream as s:
                async for event in s:
                    if event.type == "message_start":
                        msg = event.message
                        yield StreamChunk(
                            id=msg.id,
                            model=msg.model,
                            usage=Usage(
                                prompt_tokens=msg.usage.input_tokens,
                                completion_tokens=msg.usage.output_tokens,
                                total_tokens=msg.usage.input_tokens + msg.usage.output_tokens,
                            ),
                            provider="anthropic",
                            request_payload=params,
                        )
                    elif event.type == "content_block_delta":
                        if event.delta.type == "text_delta":
                            yield StreamChunk(
                                delta_text=event.delta.text,
                                provider="anthropic",
                            )
                    elif event.type == "message_delta":
                        stop_reason = event.delta.stop_reason or ""
                        finish_map = {
                            "end_turn": "stop",
                            "stop_sequence": "stop",
                            "max_tokens": "length",
                        }
                        usage = None
                        if event.usage:
                            usage = Usage(
                                completion_tokens=event.usage.output_tokens,
                                total_tokens=event.usage.output_tokens,
                            )
                        yield StreamChunk(
                            finish_reason=finish_map.get(stop_reason, stop_reason),
                            usage=usage,
                            provider="anthropic",
                        )
        except anthropic.APIError as e:
            raise wrap_anthropic_error(e) from e
        except Exception as e:
            if not isinstance(e, StreamError):
                raise StreamError(f"[anthropic] Stream error: {e}", provider="anthropic") from e
            raise
