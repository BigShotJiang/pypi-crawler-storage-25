"""REPL — chat with an AI assistant that has tools."""

import ast
import asyncio
import operator
import random
from datetime import datetime
from dotenv import load_dotenv
from oaf.agent import Agent
from oaf.tools import ToolRegistry

load_dotenv()

registry = ToolRegistry()


@registry.register
async def get_time() -> str:
    """Get the current date and time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@registry.register
async def calculate(expression: str) -> str:
    """Evaluate a math expression. Example: '2 + 3 * 4'"""
    try:
        return str(_safe_eval(expression))
    except Exception as e:
        return f"Error: {e}"


_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}

def _safe_eval(expr: str) -> float:
    """Evaluate a math expression using the AST — no eval()."""
    tree = ast.parse(expr.strip(), mode="eval")
    def _eval(node: ast.expr) -> float:
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.operand))
        raise ValueError(f"Unsupported expression: {ast.dump(node)}")
    return _eval(tree)


@registry.register
async def roll_dice(sides: int = 6, count: int = 1) -> str:
    """Roll dice. Returns the results and total."""
    rolls = [random.randint(1, int(sides)) for _ in range(int(count))]
    return f"Rolls: {rolls}, Total: {sum(rolls)}"


@registry.register
async def flip_coin() -> str:
    """Flip a coin. Returns heads or tails."""
    return random.choice(["heads", "tails"])


agent = Agent(
    system_prompt="You are a helpful assistant with access to tools. Use them when appropriate.",
    tools=registry,
    temperature=0.7,
)


async def main():
    print("Chat — type 'quit' to exit")
    print(f"Tools: {', '.join(t.name for t in registry)}\n")
    while True:
        user = input("You: ").strip()
        if not user or user.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        response = await agent.message(user, role="user")
        print(f"Assistant: {response.text}\n")
        print(f"Usage: {response.usage}\n")
        if response.tools_called:
            print("Tools called:")
            for tr in response.tools_called:
                print(f"  - {tr.name}({tr.args}) → {tr.result}")
        print("-" * 40)


if __name__ == "__main__":
    asyncio.run(main())
