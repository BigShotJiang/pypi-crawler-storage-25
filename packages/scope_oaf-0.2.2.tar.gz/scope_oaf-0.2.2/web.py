"""Web UI — dev chat interface with full context visualization."""

import ast
import asyncio
import json
import operator
import random
from datetime import datetime
from pathlib import Path

from aiohttp import web
from dotenv import load_dotenv

from oaf.agent import Agent
from oaf.tools import ToolRegistry

load_dotenv()

# ── Tools (same as chat.py) ──────────────────────────────────────────────────

registry = ToolRegistry()


@registry.register
async def get_time() -> str:
    """Get the current date and time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@registry.register
async def calculate(expression: str) -> str:
    """Evaluate a math expression. Example: '2 + 3 * 4'"""
    try:
        return str(_safe_eval(expression))
    except Exception as e:
        return f"Error: {e}"


_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}

def _safe_eval(expr: str) -> float:
    """Evaluate a math expression using the AST — no eval()."""
    tree = ast.parse(expr.strip(), mode="eval")
    def _eval(node: ast.expr) -> float:
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.operand))
        raise ValueError(f"Unsupported expression: {ast.dump(node)}")
    return _eval(tree)


@registry.register
async def roll_dice(sides: int = 6, count: int = 1) -> str:
    """Roll dice. Returns the results and total."""
    rolls = [random.randint(1, int(sides)) for _ in range(int(count))]
    return f"Rolls: {rolls}, Total: {sum(rolls)}"


@registry.register
async def flip_coin() -> str:
    """Flip a coin. Returns heads or tails."""
    return random.choice(["heads", "tails"])


agent = Agent(
    system_prompt="You are a helpful assistant with access to tools. Use them when appropriate.",
    tools=registry,
    temperature=0.7,
)

# ── Helpers ───────────────────────────────────────────────────────────────────


def _serialize_message(msg) -> dict:
    """Convert a Message to a JSON-safe dict."""
    d = {"role": msg.role, "content": msg.content if isinstance(msg.content, str) else str(msg.content or "")}
    if msg.name:
        d["name"] = msg.name
    if msg.tool_calls:
        d["tool_calls"] = [{"name": tc.name, "args": tc.parsed_arguments} for tc in msg.tool_calls]
    return d


def _serialize_entries(context) -> list:
    """Serialize context entries preserving the grouping structure."""
    entries = []
    for turn, msgs in context._entries:
        group = [_serialize_message(m) for m in msgs]
        is_tool_turn = len(msgs) == 2 and msgs[0].role == "assistant"
        entries.append({"turn": turn, "messages": group, "is_tool_turn": is_tool_turn})
    return entries


def _serialize_tool_result(tr) -> dict:
    return {"name": tr.name, "args": tr.args, "result": tr.result}


# ── Routes ────────────────────────────────────────────────────────────────────

async def index(request: web.Request) -> web.Response:
    html = (Path(__file__).parent / "web_ui.html").read_text(encoding="utf-8")
    return web.Response(text=html, content_type="text/html")


async def api_chat(request: web.Request) -> web.Response:
    body = await request.json()
    user_msg = body.get("message", "").strip()
    if not user_msg:
        return web.json_response({"error": "empty message"}, status=400)

    response = await agent.message(user_msg, role="user")

    return web.json_response({
        "text": response.text,
        "model": response.model,
        "finish_reason": response.finish_reason,
        "usage": {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens,
        },
        "tools_called": [_serialize_tool_result(tr) for tr in response.tools_called],
        "raw_text": response.raw_text,
        "provider": response.provider,
    })


async def api_context(request: web.Request) -> web.Response:
    messages = agent.context.get_messages()
    return web.json_response({
        "messages": [_serialize_message(m) for m in messages],
        "entries": _serialize_entries(agent.context),
        "turn_count": agent.context.turn_count(),
        "message_count": len(messages),
    })


async def api_session(request: web.Request) -> web.Response:
    tools_info = []
    for t in agent.tools:
        tools_info.append({
            "name": t.name,
            "description": t.description,
            "parameters": t.parameters,
        })
    return web.json_response({
        "model": agent.model,
        "temperature": agent.temperature,
        "max_tokens": agent.max_tokens,
        "max_tool_rounds": agent.max_tool_rounds,
        "tools": tools_info,
        "turn_count": agent.context.turn_count(),
    })


async def api_reset(request: web.Request) -> web.Response:
    agent.reset()
    return web.json_response({"ok": True})


# ── App ───────────────────────────────────────────────────────────────────────

app = web.Application()
app.router.add_get("/", index)
app.router.add_post("/api/chat", api_chat)
app.router.add_get("/api/context", api_context)
app.router.add_get("/api/session", api_session)
app.router.add_post("/api/reset", api_reset)

if __name__ == "__main__":
    print("Starting web UI at http://localhost:8080")
    web.run_app(app, host="localhost", port=8080)
