"""Tests for the safe math evaluator used in chat.py and web.py."""

from __future__ import annotations

import ast
import operator
import pytest

# Replicate the _safe_eval from chat.py (it's module-level, not importable directly)
_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}

def _safe_eval(expr: str) -> float:
    tree = ast.parse(expr.strip(), mode="eval")
    def _eval(node: ast.expr) -> float:
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.operand))
        raise ValueError(f"Unsupported expression: {ast.dump(node)}")
    return _eval(tree)


# ── Arithmetic ────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("expr, expected", [
    ("2 + 3", 5),
    ("10 - 4", 6),
    ("3 * 7", 21),
    ("15 / 4", 3.75),
    ("15 // 4", 3),
    ("10 % 3", 1),
    ("2 ** 8", 256),
    ("2 + 3 * 4", 14),       # operator precedence
    ("(2 + 3) * 4", 20),     # parentheses
    ("-5", -5),               # unary neg
    ("+5", 5),                # unary pos
    ("-3 + 7", 4),
    ("0.5 * 2", 1.0),
])
def test_valid_expressions(expr, expected):
    assert _safe_eval(expr) == expected


# ── Rejects dangerous inputs ─────────────────────────────────────────────────

@pytest.mark.parametrize("expr", [
    "__import__('os').system('echo pwned')",
    "open('/etc/passwd').read()",
    "eval('1+1')",
    "(lambda: 1)()",
    "[x for x in range(10)]",
    "{'a': 1}",
])
def test_rejects_dangerous(expr):
    with pytest.raises((ValueError, SyntaxError)):
        _safe_eval(expr)


# ── Edge cases ────────────────────────────────────────────────────────────────

def test_empty_string():
    with pytest.raises(SyntaxError):
        _safe_eval("")


def test_just_a_number():
    assert _safe_eval("42") == 42
    assert _safe_eval("3.14") == 3.14
