"""Tests for tool registration, lookup, and the @tool decorator."""

from __future__ import annotations

import pytest

from oaf.tools import Tool, tool, tool_method, BaseToolGroup, ToolRegistry


# ── @tool decorator ───────────────────────────────────────────────────────────

def test_tool_decorator_basic():
    @tool
    async def greet(name: str) -> str:
        """Say hello."""
        return f"Hello {name}"

    assert isinstance(greet, Tool)
    assert greet.name == "greet"
    assert greet.description == "Say hello."
    assert "name" in greet.parameters["properties"]
    assert greet.parameters["required"] == ["name"]


def test_tool_decorator_with_args():
    @tool(name="custom_name", description="Custom desc")
    async def something(x: int) -> str:
        """Original."""
        return str(x)

    assert something.name == "custom_name"
    assert something.description == "Custom desc"


def test_tool_decorator_rejects_sync():
    with pytest.raises(TypeError, match="must be an async function"):
        @tool
        def sync_fn(x: int) -> str:
            return str(x)


def test_tool_default_description():
    @tool
    async def no_doc(x: int) -> str:
        return str(x)

    assert no_doc.description.startswith("Tool:")


# ── Tool invocation ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_tool_callable():
    @tool
    async def add(a: int, b: int) -> str:
        """Add."""
        return str(a + b)

    result = await add(a=2, b=3)
    assert result == "5"


@pytest.mark.asyncio
async def test_tool_no_fn_raises():
    t = Tool(name="ghost", description="no fn")
    with pytest.raises(RuntimeError, match="no callable"):
        await t()


# ── ToolRegistry ──────────────────────────────────────────────────────────────

def test_registry_register_decorator():
    reg = ToolRegistry()

    @reg.register
    async def my_tool(x: int) -> str:
        """Do stuff."""
        return str(x)

    assert reg.get("my_tool") is not None
    assert len(reg) == 1


def test_registry_add():
    reg = ToolRegistry()

    @tool
    async def thing(q: str) -> str:
        """Thing."""
        return q

    reg.add(thing)
    assert reg.get("thing") is thing


def test_registry_get_missing_returns_none():
    reg = ToolRegistry()
    assert reg.get("nonexistent") is None


def test_registry_to_tool_params():
    reg = ToolRegistry()

    @reg.register
    async def t1(x: str) -> str:
        """T1."""
        return x

    @reg.register
    async def t2(y: int) -> str:
        """T2."""
        return str(y)

    params = reg.to_tool_params()
    assert len(params) == 2
    names = {p.function.name for p in params}
    assert names == {"t1", "t2"}


def test_registry_iteration():
    reg = ToolRegistry()

    @reg.register
    async def a() -> str:
        """A."""
        return "a"

    @reg.register
    async def b() -> str:
        """B."""
        return "b"

    names = [t.name for t in reg]
    assert set(names) == {"a", "b"}


# ── Tool groups ───────────────────────────────────────────────────────────────

def test_tool_group():
    class MathTools(BaseToolGroup):
        name = "math"
        description = "Math operations"

        @tool_method
        async def add(self, a: int, b: int) -> str:
            """Add two numbers."""
            return str(a + b)

        @tool_method(name="subtract")
        async def sub(self, a: int, b: int) -> str:
            """Subtract b from a."""
            return str(a - b)

    group = MathTools()
    tools = group.collect_tools()

    assert len(tools) == 2
    names = {t.name for t in tools}
    assert "math.add" in names
    assert "math.subtract" in names

    for t in tools:
        assert t.group == "math"
        assert t.group_description == "Math operations"


def test_register_group():
    class Utils(BaseToolGroup):
        name = "utils"

        @tool_method
        async def ping(self) -> str:
            """Ping."""
            return "pong"

    reg = ToolRegistry()
    reg.register_group(Utils())
    assert reg.get("utils.ping") is not None
