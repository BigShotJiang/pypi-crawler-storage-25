"""Tests for the hook system — registration, triggering, mutation."""

from __future__ import annotations

import pytest

from oaf.hooks import Hooks, EVENTS


# ── Event validation ──────────────────────────────────────────────────────────

def test_on_rejects_unknown_event():
    h = Hooks()
    with pytest.raises(ValueError, match="Unknown event"):
        h.on("made_up_event", lambda: None)


def test_all_events_have_methods():
    h = Hooks()
    for event in EVENTS:
        assert hasattr(h, event), f"Hooks missing method for event {event!r}"


# ── Trigger ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_trigger_calls_callback():
    h = Hooks()
    called = []

    async def on_err(error):
        called.append(error)

    h.on("on_error", on_err)
    await h.trigger("on_error", RuntimeError("boom"))
    assert len(called) == 1
    assert str(called[0]) == "boom"


@pytest.mark.asyncio
async def test_trigger_returns_none_for_non_before():
    h = Hooks()
    result = await h.trigger("on_context_update")
    assert result is None


# ── Mutation (before_ events) ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_before_message_can_replace():
    h = Hooks()

    async def censor(message, role, messages):
        return "[REDACTED]"

    h.on("before_message", censor)
    result = await h.trigger("before_message", "secret", "user", [])
    assert result == "[REDACTED]"


@pytest.mark.asyncio
async def test_before_tool_call_can_replace_args():
    h = Hooks()

    async def override_args(tool_name, arguments):
        return {"x": 999}

    h.on("before_tool_call", override_args)
    result = await h.trigger("before_tool_call", "calc", {"x": 1})
    assert result == {"x": 999}


@pytest.mark.asyncio
async def test_last_non_none_wins():
    h = Hooks()

    async def first(message, role, messages):
        return "first"

    async def second(message, role, messages):
        return "second"

    h.on("before_message", first)
    h.on("before_message", second)
    result = await h.trigger("before_message", "original", "user", [])
    assert result == "second"


@pytest.mark.asyncio
async def test_none_return_keeps_original():
    h = Hooks()

    async def noop(message, role, messages):
        return None  # don't replace

    h.on("before_message", noop)
    result = await h.trigger("before_message", "original", "user", [])
    assert result is None  # caller sees None → keeps original


# ── Subclass overrides ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_subclass_override():
    class MyHooks(Hooks):
        async def on_error(self, error):
            return f"caught: {error}"

    h = MyHooks()
    result = await h.trigger("on_error", RuntimeError("fail"))
    assert result == "caught: fail"


@pytest.mark.asyncio
async def test_subclass_plus_callback():
    calls = []

    class MyHooks(Hooks):
        async def on_error(self, error):
            calls.append("class")

    h = MyHooks()

    async def cb(error):
        calls.append("callback")

    h.on("on_error", cb)
    await h.trigger("on_error", RuntimeError("x"))
    assert calls == ["class", "callback"]
