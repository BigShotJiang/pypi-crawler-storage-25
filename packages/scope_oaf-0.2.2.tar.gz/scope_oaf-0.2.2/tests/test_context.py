"""Tests for ConversationalInMemory — limits, token counting, atomic turns, prompt assembly, tools."""

from __future__ import annotations

import pytest

from oaf.llmclient import Message
from oaf.context import ConversationalInMemory
from oaf.tools import ToolRegistry, tool


# ── Basic operations ──────────────────────────────────────────────────────────

def test_add_and_get():
    ctx = ConversationalInMemory()
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hello"))
    msgs = ctx.get_messages()
    assert len(msgs) == 1
    assert msgs[0].content == "hello"


def test_turn_count():
    ctx = ConversationalInMemory()
    assert ctx.turn_count() == 0
    ctx.start_turn()
    assert ctx.turn_count() == 1
    ctx.start_turn()
    assert ctx.turn_count() == 2


def test_clear():
    ctx = ConversationalInMemory()
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hello"))
    ctx.clear()
    assert ctx.get_messages() == []
    assert ctx.turn_count() == 0


# ── Message limit ─────────────────────────────────────────────────────────────

def test_max_messages_drops_oldest():
    ctx = ConversationalInMemory(max_messages=3)
    ctx.start_turn()
    ctx.add_message(Message(role="system", content="sys"))
    ctx.add_message(Message(role="user", content="msg1"))
    ctx.add_message(Message(role="user", content="msg2"))
    ctx.add_message(Message(role="user", content="msg3"))

    msgs = ctx.get_messages()
    # Should keep system + the 2 newest user messages
    assert len(msgs) == 3
    assert msgs[0].role == "system"
    assert msgs[-1].content == "msg3"


def test_system_message_preserved():
    ctx = ConversationalInMemory(max_messages=2)
    ctx.start_turn()
    ctx.add_message(Message(role="system", content="sys"))
    ctx.add_message(Message(role="user", content="a"))
    ctx.add_message(Message(role="user", content="b"))

    msgs = ctx.get_messages()
    assert msgs[0].role == "system"
    assert msgs[0].content == "sys"


# ── Token limit ───────────────────────────────────────────────────────────────

def test_max_tokens_enforced():
    # Each message ~"a" * 100 → ~25 tokens + 4 overhead ≈ 29 tokens
    ctx = ConversationalInMemory(max_tokens=80)
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="a" * 100))
    ctx.add_message(Message(role="user", content="b" * 100))
    ctx.add_message(Message(role="user", content="c" * 100))

    msgs = ctx.get_messages()
    # With ~29 tokens per message and budget 80, should keep last ~2
    assert len(msgs) <= 3


# ── Atomic tool turns ────────────────────────────────────────────────────────

def test_tool_turn_atomic():
    ctx = ConversationalInMemory()
    ctx.start_turn()
    assistant = Message(role="assistant", content='{"tool_calls": []}')
    results = Message(role="user", content='{"tool_results": []}')
    ctx.add_tool_turn(assistant, results)

    msgs = ctx.get_messages()
    assert len(msgs) == 2
    assert msgs[0].role == "assistant"
    assert msgs[1].role == "user"


def test_tool_turn_dropped_as_unit():
    ctx = ConversationalInMemory(max_messages=3)
    ctx.start_turn()
    ctx.add_message(Message(role="system", content="sys"))
    ctx.add_tool_turn(
        Message(role="assistant", content="tool call"),
        Message(role="user", content="tool result"),
    )
    ctx.add_message(Message(role="user", content="final"))

    # system(1) + tool_turn(2) + final(1) = 4 messages, limit is 3
    # Should drop the tool turn as a unit → system + final = 2
    msgs = ctx.get_messages()
    assert len(msgs) <= 3


# ── Prompt assembly ───────────────────────────────────────────────────────────

def test_build_messages_prepends_system():
    ctx = ConversationalInMemory(system_prompt="Be helpful.")
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hi"))

    msgs = ctx.build_messages()
    assert len(msgs) == 2
    assert msgs[0].role == "system"
    assert msgs[0].content == "Be helpful."
    assert msgs[1].role == "user"


def test_get_system_prompt():
    ctx = ConversationalInMemory(system_prompt="You are a coder.")
    assert ctx.get_system_prompt() == "You are a coder."


def test_update_system_prompt():
    ctx = ConversationalInMemory(system_prompt="old")
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hi"))
    ctx.update_system_prompt("new")

    assert ctx.get_system_prompt() == "new"
    msgs = ctx.build_messages()
    system_msgs = [m for m in msgs if m.role == "system"]
    assert len(system_msgs) == 1
    assert system_msgs[0].content == "new"


def test_system_prompt_not_in_stored_messages():
    ctx = ConversationalInMemory(system_prompt="sys")
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hi"))

    stored = ctx.get_messages()
    assert all(m.role != "system" for m in stored)

    built = ctx.build_messages()
    assert built[0].role == "system"


# ── Token estimation uses tiktoken when available ─────────────────────────────

def test_token_estimate_reasonable():
    ctx = ConversationalInMemory()
    tokens = ctx._message_tokens(Message(role="user", content="Hello, world!"))
    # tiktoken should give ~4 tokens + 4 overhead = ~8
    # heuristic would give 13//4 + 4 = 7
    # Either way, should be in a reasonable range
    assert 4 <= tokens <= 20


# ── Tools in context ──────────────────────────────────────────────────────────

def test_context_with_tools():
    reg = ToolRegistry()

    @reg.register
    async def greet(name: str) -> str:
        """Say hello."""
        return f"Hello {name}"

    ctx = ConversationalInMemory(system_prompt="Be helpful.", tools=reg)
    assert len(ctx.tools) == 1
    assert ctx.tools.get("greet") is not None


def test_build_messages_injects_tool_prompt():
    reg = ToolRegistry()

    @reg.register
    async def search(query: str) -> str:
        """Search the web."""
        return query

    ctx = ConversationalInMemory(system_prompt="Be helpful.", tools=reg)
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="find stuff"))

    msgs = ctx.build_messages()
    system_content = msgs[0].content
    # Tool descriptions are injected before the user's system prompt
    assert "search" in system_content
    assert "Be helpful." in system_content
    assert "tool_calls" in system_content  # JSON schema present


def test_build_messages_no_tools_no_injection():
    ctx = ConversationalInMemory(system_prompt="Be helpful.")
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="hi"))

    msgs = ctx.build_messages()
    # System prompt should be clean — no tool injection
    assert msgs[0].content == "Be helpful."


def test_internal_tools_in_build_messages():
    internal_reg = ToolRegistry()

    @internal_reg.register
    async def read_file(path: str) -> str:
        """Read a file."""
        return "contents"

    ctx = ConversationalInMemory(system_prompt="Be helpful.")
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="read something"))

    msgs = ctx.build_messages(internal_tools=internal_reg)
    system_content = msgs[0].content
    assert "read_file" in system_content


def test_both_user_and_internal_tools():
    user_reg = ToolRegistry()

    @user_reg.register
    async def search(query: str) -> str:
        """Search."""
        return query

    internal_reg = ToolRegistry()

    @internal_reg.register
    async def read_file(path: str) -> str:
        """Read a file."""
        return "contents"

    ctx = ConversationalInMemory(system_prompt="Be helpful.", tools=user_reg)
    ctx.start_turn()
    ctx.add_message(Message(role="user", content="do stuff"))

    msgs = ctx.build_messages(internal_tools=internal_reg)
    system_content = msgs[0].content
    assert "search" in system_content
    assert "read_file" in system_content
