"""Tests for tool type inference — verifies _python_type_to_json_schema handles
basic types, Optional, list[T], dict[K,V], Union, and Enum."""

from __future__ import annotations

import enum

import pytest

from oaf.tools.tool import _python_type_to_json_schema, _build_parameters_schema, tool


# ── basic types ───────────────────────────────────────────────────────────────

@pytest.mark.parametrize("py_type, expected", [
    (str, {"type": "string"}),
    (int, {"type": "integer"}),
    (float, {"type": "number"}),
    (bool, {"type": "boolean"}),
    (list, {"type": "array"}),
    (dict, {"type": "object"}),
])
def test_basic_types(py_type, expected):
    assert _python_type_to_json_schema(py_type) == expected


# ── Optional ──────────────────────────────────────────────────────────────────

def test_optional_str():
    from typing import Optional
    schema = _python_type_to_json_schema(Optional[str])
    assert schema == {"type": "string"}


def test_optional_int():
    from typing import Optional
    schema = _python_type_to_json_schema(Optional[int])
    assert schema == {"type": "integer"}


# ── list[T] ───────────────────────────────────────────────────────────────────

def test_list_of_str():
    schema = _python_type_to_json_schema(list[str])
    assert schema == {"type": "array", "items": {"type": "string"}}


def test_list_of_int():
    schema = _python_type_to_json_schema(list[int])
    assert schema == {"type": "array", "items": {"type": "integer"}}


def test_bare_list():
    schema = _python_type_to_json_schema(list)
    assert schema == {"type": "array"}


# ── dict[K, V] ────────────────────────────────────────────────────────────────

def test_dict_str_int():
    schema = _python_type_to_json_schema(dict[str, int])
    assert schema == {"type": "object", "additionalProperties": {"type": "integer"}}


def test_bare_dict():
    schema = _python_type_to_json_schema(dict)
    assert schema == {"type": "object"}


# ── Union ─────────────────────────────────────────────────────────────────────

def test_union_str_int():
    from typing import Union
    schema = _python_type_to_json_schema(Union[str, int])
    assert schema == {"anyOf": [{"type": "string"}, {"type": "integer"}]}


def test_pipe_union():
    schema = _python_type_to_json_schema(str | int)
    assert schema == {"anyOf": [{"type": "string"}, {"type": "integer"}]}


# ── Enum ──────────────────────────────────────────────────────────────────────

class Color(enum.Enum):
    RED = "red"
    GREEN = "green"
    BLUE = "blue"


def test_enum():
    schema = _python_type_to_json_schema(Color)
    assert schema == {"type": "string", "enum": ["red", "green", "blue"]}


# ── nested: list[list[str]] ──────────────────────────────────────────────────

def test_nested_list():
    schema = _python_type_to_json_schema(list[list[str]])
    assert schema == {
        "type": "array",
        "items": {"type": "array", "items": {"type": "string"}},
    }


# ── _build_parameters_schema with complex types ──────────────────────────────

def test_schema_from_function():
    async def example(name: str, tags: list[str], count: int = 5) -> str:
        ...

    schema = _build_parameters_schema(example)
    assert schema["type"] == "object"
    assert schema["required"] == ["name", "tags"]
    assert schema["properties"]["name"] == {"type": "string"}
    assert schema["properties"]["tags"] == {"type": "array", "items": {"type": "string"}}
    assert schema["properties"]["count"] == {"type": "integer", "default": 5}


def test_schema_optional_param():
    async def example(query: str, limit: int | None = None) -> str:
        ...

    schema = _build_parameters_schema(example)
    assert schema["required"] == ["query"]
    assert schema["properties"]["limit"] == {"type": "integer", "default": None}


# ── @tool decorator still works with complex types ───────────────────────────

def test_tool_decorator_complex_types():
    @tool
    async def search(query: str, filters: list[str], max_results: int = 10) -> str:
        """Search for things."""
        return "results"

    assert search.name == "search"
    assert search.description == "Search for things."
    props = search.parameters["properties"]
    assert props["query"] == {"type": "string"}
    assert props["filters"] == {"type": "array", "items": {"type": "string"}}
    assert props["max_results"] == {"type": "integer", "default": 10}
    assert search.parameters["required"] == ["query", "filters"]
