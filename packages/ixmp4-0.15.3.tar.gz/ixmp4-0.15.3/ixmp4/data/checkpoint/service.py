from typing import List

from toolkit.auth.context import AuthorizationContext, PlatformProtocol
from toolkit.db.executor import SessionExecutor
from typing_extensions import Unpack

from ixmp4.base_exceptions import Forbidden
from ixmp4.data.dataframe import SerializableDataFrame
from ixmp4.data.pagination import PaginatedResult, Pagination
from ixmp4.data.run.repositories import ItemRepository as RunRepository
from ixmp4.data.services import DirectTransport, GetByIdService, Http, procedure
from ixmp4.data.versions.transaction import TransactionRepository

from .dto import Checkpoint
from .filter import CheckpointFilter
from .repositories import ItemRepository, PandasRepository


class CheckpointService(GetByIdService):
    router_prefix = "/checkpoints"
    router_tags = ["checkpoints"]

    executor: SessionExecutor
    items: ItemRepository
    pandas: PandasRepository

    def __init_direct__(self, transport: DirectTransport) -> None:
        self.executor = SessionExecutor(transport.session)
        self.items = ItemRepository(self.executor, **self.get_auth_kwargs(transport))
        self.pandas = PandasRepository(self.executor, **self.get_auth_kwargs(transport))
        self.runs = RunRepository(self.executor)
        self.transactions = TransactionRepository(self.executor)

    @procedure(Http(path="/", methods=("POST",)))
    def create(
        self, run__id: int, message: str, transaction__id: int | None = None
    ) -> Checkpoint:
        """Creates a checkpoint.

        Parameters
        ----------
        run__id : int
            Id of the run the checkpoint is connected to.
        message : str
            The checkpoints message.
        transaction__id : int, optional
            Id of the transaction the checkpoint references.

        Raises
        ------
        :class:`CheckpointNotUnique`:
            If the checkpoint with `name` is not unique.

        Returns
        -------
        :class:`Checkpoint`:
            The created checkpoint.
        """
        if transaction__id is None and self.get_dialect().name == "postgresql":
            # fill the latest transaction as default for
            # postgres dbs which support versioning
            transaction__id = self.transactions.latest().id

        result = self.items.create(
            {"run__id": run__id, "transaction__id": transaction__id, "message": message}
        )
        assert result.inserted_primary_key is not None
        return Checkpoint.model_validate(
            self.items.get_by_pk({"id": result.inserted_primary_key.id})
        )

    @create.auth_check()
    def create_auth_check(
        self,
        auth_ctx: AuthorizationContext,
        platform: PlatformProtocol,
        /,
        run__id: int,
        message: str,
        transaction__id: int | None = None,
    ) -> None:
        run = self.runs.get_by_pk({"id": run__id})
        auth_ctx.has_edit_permission(
            platform, models=[run.model.name], raise_exc=Forbidden
        )

    @procedure(Http(path="/{id:int}/", methods=("DELETE",)))
    def delete_by_id(self, id: int) -> None:
        """Deletes a checkpoint.

        Parameters
        ----------
        id : int
            The unique integer id of the checkpoint.

        Raises
        ------
        :class:`CheckpointNotFound`:
            If the checkpoint with `id` does not exist.
        """

        self.items.delete_by_pk({"id": id})

    @delete_by_id.auth_check()
    def delete_auth_check(
        self,
        auth_ctx: AuthorizationContext,
        platform: PlatformProtocol,
        id: int,
    ) -> None:
        checkpoint = self.items.get_by_pk({"id": id})
        run = self.runs.get_by_pk({"id": checkpoint.run__id})
        auth_ctx.has_edit_permission(
            platform, models=[run.model.name], raise_exc=Forbidden
        )

    @procedure(Http(path="/{id:int}/", methods=("GET",)))
    def get_by_id(self, id: int) -> Checkpoint:
        """Retrieves a checkpoint by its id.

        Parameters
        ----------
        id : int
            The integer id of the checkpoint.

        Raises
        ------
        :class:`ixmp4.data.abstract.Checkpoint.NotFound`:
            If the checkpoint with `id` does not exist.

        Returns
        -------
        :class:`ixmp4.data.base.iamc.Checkpoint`:
            The retrieved checkpoint.
        """

        return Checkpoint.model_validate(self.items.get_by_pk({"id": id}))

    @get_by_id.auth_check()
    def get_by_id_auth_check(
        self, auth_ctx: AuthorizationContext, platform: PlatformProtocol
    ) -> None:
        auth_ctx.has_view_permission(platform, raise_exc=Forbidden)

    @procedure(Http(methods=("PATCH",)))
    def list(self, **kwargs: Unpack[CheckpointFilter]) -> list[Checkpoint]:
        r"""Lists checkpoints by specified criteria.

        Parameters
        ----------
        \*\*kwargs: any
            Filter parameters as specified in :class:`CheckpointFilter`.

        Returns
        -------
        Iterable[:class:`Checkpoint`]:
            List of checkpoints.
        """

        return [
            Checkpoint.model_validate(i)
            for i in self.items.list(
                values=self.apply_filter_defaults(kwargs),
            )
        ]

    @list.auth_check()
    def list_auth_check(
        self, auth_ctx: AuthorizationContext, platform: PlatformProtocol
    ) -> None:
        auth_ctx.has_view_permission(platform, raise_exc=Forbidden)

    @list.paginated()
    def paginated_list(
        self, pagination: Pagination, **kwargs: Unpack[CheckpointFilter]
    ) -> PaginatedResult[List[Checkpoint]]:
        return PaginatedResult(
            results=[
                Checkpoint.model_validate(i)
                for i in self.items.list(
                    values=self.apply_filter_defaults(kwargs),
                    limit=pagination.limit,
                    offset=pagination.offset,
                )
            ],
            total=self.items.count(values=self.apply_filter_defaults(kwargs)),
            pagination=pagination,
        )

    @procedure(Http(methods=("PATCH",)))
    def tabulate(self, **kwargs: Unpack[CheckpointFilter]) -> SerializableDataFrame:
        r"""Tabulates checkpoints by specified criteria.

        Parameters
        ----------
        \*\*kwargs: any
            Filter parameters as specified in :class:`CheckpointFilter`.

        Returns
        -------
        :class:`pandas.DataFrame`:
            A data frame with the columns:
                - id
                - run__id
                - transcation__id
                - message
        """

        return self.pandas.tabulate(values=self.apply_filter_defaults(kwargs))

    @tabulate.auth_check()
    def tabulate_auth_check(
        self, auth_ctx: AuthorizationContext, platform: PlatformProtocol
    ) -> None:
        auth_ctx.has_view_permission(platform, raise_exc=Forbidden)

    @tabulate.paginated()
    def paginated_tabulate(
        self, pagination: Pagination, **kwargs: Unpack[CheckpointFilter]
    ) -> PaginatedResult[SerializableDataFrame]:
        return PaginatedResult[SerializableDataFrame](
            results=self.pandas.tabulate(
                values=self.apply_filter_defaults(kwargs),
                limit=pagination.limit,
                offset=pagination.offset,
            ),
            total=self.pandas.count(values=self.apply_filter_defaults(kwargs)),
            pagination=pagination,
        )
