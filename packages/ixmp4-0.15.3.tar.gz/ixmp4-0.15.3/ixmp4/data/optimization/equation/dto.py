from ixmp4.data.base.dto import BaseModel, HasCreationInfo


class Equation(BaseModel, HasCreationInfo):
    """Optimization equation model."""

    id: int
    name: str
    "Name of the equation."

    data: dict[str, list[float] | list[int] | list[str]]
    indexset_names: list[str] | None
    column_names: list[str] | None
    run__id: int

    def __str__(self) -> str:
        return f"<Equation {self.id} name={self.name}>"
