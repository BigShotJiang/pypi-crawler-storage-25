from ixmp4.data.base.dto import BaseModel, HasCreationInfo


class Table(BaseModel, HasCreationInfo):
    """Optimization table data model."""

    id: int
    name: str
    "Name of the table."
    data: dict[str, list[float] | list[int] | list[str]]
    indexset_names: list[str]
    column_names: list[str] | None
    run__id: int

    def __str__(self) -> str:
        return f"<Table {self.id} name={self.name}>"
