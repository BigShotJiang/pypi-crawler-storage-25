"""
模块：mypymssql
作者：李生
描述：Microsoft SQL Server 的 pymssql 操作
"""
import pymssql

class MyPyMSSQL:
    """Microsoft SQL Server 的 pymssql 操作"""
    def __init__(self,host,port,user,password,database,timeout=0,asDict=True,autoCommit=False,charset="cp936") -> None:
        """
        Args:
            host：服务器地址
            port：端口号
            user：用户
            password：密码
            database：数据库
            timeout：超时时间（秒）
            asDict：以字典返回数据
            autoCommit：自动提交
            charset：字符编码，默认cp936
        """
        self.host=host
        self.port=port
        self.user=user
        self.password=password
        self.database=database
        self.timeout=timeout
        self.asDict=asDict
        self.autoCommit=autoCommit
        self.charset=charset

    def connect(self) -> tuple[bool,str]:
        """
        连接数据库
        Returns:
            是否成功
            执行结果
        """
        try:
            if len(self.charset) == 0:
                self.conn=pymssql.connect(host=self.host,port=self.port,user=self.user,password=self.password,database=self.database,timeout=self.timeout)
            else:
                self.conn=pymssql.connect(host=self.host,port=self.port,user=self.user,password=self.password,database=self.database,timeout=self.timeout,charset=self.charset)
            self.conn.autocommit(self.autoCommit)
            self.cursor=self.conn.cursor(as_dict=self.asDict)
            return True,"OK"
        except Exception as e:
            return False,str(e)

    def connectWithWindowsAuth(self,server) -> tuple[bool,str]:
        """
        以Windows身份验证连接数据库
        Args:
            server：服务器地址\\实例名
        Returns:
            是否成功
            执行结果
        """
        try:
            if len(self.charset) == 0:
                self.conn=pymssql.connect(server=server,database=self.database,timeout=self.timeout)
            else:
                self.conn=pymssql.connect(server=server,database=self.database,timeout=self.timeout,charset=self.charset)
            self.conn.autocommit(self.autoCommit)
            self.cursor=self.conn.cursor(as_dict=self.asDict)
            return True,"OK"
        except Exception as e:
            return False,str(e)

    # 获取连接状态
    @property
    def Connected(self):
        """获取连接状态"""
        return self.conn is not None
        
    def setAutoCommit(self,autoCommit):
        """
        设置自动提交
        Args：
            autoCommit：是否自动提交
        """
        if not self.conn:
            return False,"连接失败"
        try:
            self.conn.autocommit(autoCommit)
            return True
        except Exception as e:
            return False
            
    @property
    def IsAutoCommit(self):
        """获取是否自动提交"""
        return self.conn.autocommit_state

    def get(self,sql):
        """
        查询数据
        Args：
            sql：SQL语句
        Returns:
            数据
        """
        if not self.conn:
            return None
        try:
            self.cursor.execute(sql)
            return self.cursor.fetchall()
        except:
            return None

    def exec(self,sql):
        """
        执行SQL
        Args：
            sql：SQL语句
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return False,"连接失败"
        try:
            self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,e)

    def execProc(self,procName,params):
        """
        执行存储过程
        Args：
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return (False,"连接失败")
        try:
            self.cursor.callproc(procName,params)
            return (True,"OK")
        except Exception as e:
            return (False,e)

    def execProcGet(self,procName,params):
        """
        执行存储过程并返回数据
        Args：
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
            数据
        """
        if not self.conn:
            return (False,"连接失败",None)
        try:
            datas=[]
            self.cursor.callproc(procName,params)
            firstData=self.cursor.fetchall()
            if firstData:
                datas.append(firstData)

            haveNext=self.cursor.nextset()
            while haveNext:
                othData=self.cursor.fetchall()
                datas.append(othData)
                haveNext=self.cursor.nextset()

            return (True,"OK",datas)
        except Exception as e:
            return (False,e,None)

    def commit(self):
        """提交事务"""
        if not self.conn:
            return
        if self.conn.autocommit_state==True:
            return
        self.conn.commit()

    def rollback(self):
        """回滚事务"""
        if not self.conn:
            return
        self.conn.rollback()

    def close(self):
        """关闭连接"""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
