## 🌺mypymssql

通过pymssql访问Microsoft SQL Server。

使用示例：

```
from pylhb-pymssql.mypymssql import MyPyMSSQL

if __name__ == "__main__":
    host="127.0.0.1"
    prot=1433
    user="sa"
    password="fpsoft@123"
    database="MyDB"
    # 实例化
    mssql=MyPyMSSQL(host,prot,user,password,database)
    mssql.connect()
    # mssql.connectWithWindowsAuth(r"localhost\sqlexpress")
    print(mssql.Connected)

    # Demo1：查询数据
    sql="SELECT TOP 2 P_CusName,P_Tel FROM Dt_Customers WITH(NOLOCK)"
    print("🌸Demot1：获取客户：")
    humans=mssql.get(sql)
    print(humans)

    # Demo2：执行无参存储过程
    (successed,msg) = mssql.execProc("Usp_TestNoArgs",())
    print("🌸Demot2：执行无参存储过程(Usp_TestNoArgs)：")
    print(successed,msg)

    # Demo3：执行带参存储过程
    (successed,msg) = mssql.execProc("Usp_TestWithArgs",("192.168.5.8","443"))
    print("🌸Demot3：执行带参存储过程(Usp_TestWithArgs)：")
    print(successed,msg)

    # Demo4：执行存储过程并返回数据
    (successed,msg,datas) = mssql.execProcGet("Usp_Test",())
    print("🌸Demot4：执行存储过程并返回数据(Usp_Test)：")
    print(successed,msg,datas)

    # 提交事务
    mssql.commit()
    # 关闭
    mssql.close()
```
