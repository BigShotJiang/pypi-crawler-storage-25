#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Any

import torch

from ax.adapter import Generators
from ax.generation_strategy.generation_strategy import GenerationStrategy
from ax.generation_strategy.generation_node import GenerationNode
from ax.generation_strategy.generator_spec import GeneratorSpec
from ax.generators.torch.botorch_modular.surrogate import SurrogateSpec, ModelConfig
from ax.generators.torch.botorch_modular.utils import fit_botorch_model
from gpytorch import ExactMarginalLogLikelihood
from torch import Tensor

from aps.ai.beamline_controller.agent.machine_learning.surrogates.bayesian_neural_network import BotorchBNNModel
from aps.ai.beamline_controller.agent.machine_learning.surrogates.dkl_feature_extractor import BotorchDKLModel, fit_dkl
from aps.ai.beamline_controller.agent.machine_learning.surrogates.facade import SurrogateAction
from aps.ai.beamline_controller.agent.machine_learning.surrogates.neural_network_surrogate import BotorchNNModel

from aps.ai.beamline_controller.agent.optimization.common.bayesian.ax.generation_strategy_factory import SobolMode, _get_sobol_node, _assemble_nodes, _get_optimizer_args

#######################################################################
# fit_botorch_model HANDLERS REGISTRATION
#######################################################################

@fit_botorch_model.register(BotorchNNModel)
def _fit_nn(model: BotorchNNModel, mll_class=None, mll_options=None, **kwargs):
    pass  # BotorchBNNModel trains itself in __init__, nothing to do here

@fit_botorch_model.register(BotorchBNNModel)
def _fit_bnn(model: BotorchBNNModel, mll_class=None, mll_options=None, **kwargs):
    pass  # BotorchBNNModel trains itself in __init__, nothing to do here

@fit_botorch_model.register(BotorchDKLModel)
def _fit_dkl(
    model: BotorchDKLModel,
    mll_class=None,
    mll_options=None,
    **kwargs,
) -> None:
   fit_dkl(model, mll_class=mll_class, mll_options=mll_options, **kwargs)

#######################################################################

def get_nn_generation_strategy(experiment_name: str,
                               add_sobol: int = SobolMode.NO_SOBOL,
                               sobol_seed: int = 42,
                               sobol_trials=6,
                               has_discrete_search_space:bool = True,
                               hidden_dim: int = 64,
                               action: int = SurrogateAction.NOTHING,
                               pre_train_X: torch.Tensor | None = None,
                               pre_train_Y: torch.Tensor | None = None,
                               n_steps: int = 1000,
                               model_directory: str = None,
                               verbose: bool = False
                               ) -> GenerationStrategy:
    return _assemble_nodes(experiment_name=experiment_name,
                           add_sobol=add_sobol,
                           sobol_seed=sobol_seed,
                           sobol_trials=sobol_trials,
                           botorch_node=_get_nn_botorch_node(has_discrete_search_space=has_discrete_search_space,
                                                             hidden_dim=hidden_dim,
                                                             action=action,
                                                             pre_train_X=pre_train_X,
                                                             pre_train_Y=pre_train_Y,
                                                             n_steps=n_steps,
                                                             model_directory=model_directory,
                                                             verbose=verbose))


def get_dkl_generation_strategy(experiment_name: str,
                                add_sobol: int = SobolMode.NO_SOBOL,
                                sobol_seed: int = 42,
                                sobol_trials=6,
                                has_discrete_search_space:bool = True,
                                feature_dim: int = 8,
                                action: int = SurrogateAction.NOTHING,
                                pre_train_X: torch.Tensor | None = None,
                                pre_train_Y: torch.Tensor | None = None,
                                n_steps: int = 300,
                                lr: float = 1e-2,
                                model_directory: str | None = None,
                                verbose: bool = False
                                ):
    return _assemble_nodes(experiment_name=experiment_name,
                           add_sobol=add_sobol,
                           sobol_seed=sobol_seed,
                           sobol_trials=sobol_trials,
                           botorch_node=_get_dkl_botorch_node(has_discrete_search_space=has_discrete_search_space,
                                                              feature_dim=feature_dim,
                                                              action=action,
                                                              pre_train_X=pre_train_X,
                                                              pre_train_Y=pre_train_Y,
                                                              n_steps=n_steps,
                                                              lr=lr,
                                                              model_directory=model_directory,
                                                              verbose=verbose))

def get_bnn_generation_strategy(experiment_name: str,
                                add_sobol: int = SobolMode.NO_SOBOL,
                                sobol_seed: int = 42,
                                sobol_trials=6,
                                has_discrete_search_space:bool = True,
                                hidden_dim: int = 64,
                                dropout_p: float = 0.1,
                                n_mc_samples: int = 64,
                                action: int = SurrogateAction.NOTHING,
                                pre_train_X: torch.Tensor | None = None,
                                pre_train_Y: torch.Tensor | None = None,
                                n_steps: int = 1000,
                                model_directory: str = None,
                                verbose: bool = False
                                ):
    return _assemble_nodes(experiment_name=experiment_name,
                           add_sobol=add_sobol,
                           sobol_seed=sobol_seed,
                           sobol_trials=sobol_trials,
                           botorch_node=_get_bnn_botorch_node(has_discrete_search_space=has_discrete_search_space,
                                                              hidden_dim=hidden_dim,
                                                              dropout_p=dropout_p,
                                                              n_mc_samples=n_mc_samples,
                                                              action=action,
                                                              pre_train_X=pre_train_X,
                                                              pre_train_Y=pre_train_Y,
                                                              n_steps=n_steps,
                                                              model_directory=model_directory,
                                                              verbose=verbose))

# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------

def _get_nn_botorch_node(has_discrete_search_space: bool,
                         hidden_dim: int,
                         action: int,
                         pre_train_X: torch.Tensor | None,
                         pre_train_Y: torch.Tensor | None,
                         n_steps: int,
                         model_directory: str | None,
                         verbose: bool
                         ) -> GenerationNode:
    return GenerationNode(
        name="NN-BoTorch",
        generator_specs=[
            GeneratorSpec(
                generator_enum=Generators.BOTORCH_MODULAR,
                generator_kwargs={
                    "surrogate_spec": SurrogateSpec(
                        model_configs=[
                            ModelConfig(
                                botorch_model_class=BotorchNNModel,
                                input_transform_classes=None,
                                mll_class=None,
                                model_options={
                                    "hidden_dim": hidden_dim,
                                    "action": action,
                                    "pre_train_X": pre_train_X,
                                    "pre_train_Y": pre_train_Y,
                                    "scalers": _get_scalers(action, pre_train_Y),
                                    "n_steps": n_steps,
                                    "model_directory": model_directory,
                                    "verbose": verbose
                                },
                            )
                        ]
                    ),
                },
                generator_gen_kwargs=_get_optimizer_args(has_discrete_search_space)
            )
        ],
    )

# ----------------------------------------------------------------------

def _get_dkl_botorch_node(has_discrete_search_space: bool,
                          feature_dim: int,
                          action: int,
                          pre_train_X: torch.Tensor | None,
                          pre_train_Y: torch.Tensor | None,
                          n_steps: int,
                          lr: float,
                          model_directory: str | None,
                          verbose: bool) -> GenerationNode:
    return GenerationNode(
        name="DKL-BoTorch",
        generator_specs=[
            GeneratorSpec(
                generator_enum=Generators.BOTORCH_MODULAR,
                generator_kwargs={
                    "surrogate_spec": SurrogateSpec(
                        model_configs=[
                            ModelConfig(
                                botorch_model_class=BotorchDKLModel,
                                input_transform_classes=None,
                                mll_class=ExactMarginalLogLikelihood, # Ax drives ExactMarginalLogLikelihood
                                mll_options={
                                    "action": action,
                                    "n_steps": n_steps,
                                    "lr": lr,
                                    "model_directory": model_directory,
                                    "verbose": verbose
                                },
                                model_options={
                                    "feature_dim": feature_dim,
                                    "action": action,
                                    "pre_train_X": pre_train_X,
                                    "pre_train_Y": pre_train_Y,
                                    "scalers": _get_scalers(action, pre_train_Y),
                                    "model_directory": model_directory,
                                    "verbose": verbose
                                },
                            )
                        ],
                        allow_batched_models=False,  # one GP per metric
                    ),
                },
                generator_gen_kwargs=_get_optimizer_args(has_discrete_search_space)
            )
        ],
    )

# ----------------------------------------------------------------------

def _get_bnn_botorch_node(has_discrete_search_space,
                          hidden_dim: int,
                          dropout_p: float,
                          n_mc_samples: int,
                          action: int,
                          pre_train_X: torch.Tensor | None,
                          pre_train_Y: torch.Tensor | None,
                          n_steps: int,
                          model_directory: str | None,
                          verbose: bool
                          ) -> GenerationNode:
    return GenerationNode(
        name="BNN-BoTorch",
        generator_specs=[
            GeneratorSpec(
                generator_enum=Generators.BOTORCH_MODULAR,
                generator_kwargs={
                    "surrogate_spec": SurrogateSpec(
                        model_configs=[
                            ModelConfig(
                                botorch_model_class=BotorchBNNModel,
                                input_transform_classes=None,
                                mll_class=None,
                                model_options={
                                    "dropout_p":    dropout_p,
                                    "n_mc_samples": n_mc_samples,
                                    "hidden_dim":   hidden_dim,
                                    "action": action,
                                    "pre_train_X": pre_train_X,
                                    "pre_train_Y": pre_train_Y,
                                    "scalers": _get_scalers(action, pre_train_Y),
                                    "n_steps": n_steps,
                                    "model_directory": model_directory,
                                    "verbose": verbose
                                },
                            )
                        ]
                    ),
                },
                generator_gen_kwargs=_get_optimizer_args(has_discrete_search_space)
            )
        ],
    )

# ----------------------------------------------------------------------

def _get_scalers(action: int, pre_train_Y: Tensor | None) -> dict[Any, dict[str, Any]]:
    if action == SurrogateAction.TRAIN_MODEL:
        scalers = {objective: {"mu": column.mean(dim=0, keepdim=True),
                               "sigma": column.std(dim=0, keepdim=True).clamp(min=1e-8)}
                   for objective, column in pre_train_Y.items()}
    else:
        scalers = {}
    return scalers