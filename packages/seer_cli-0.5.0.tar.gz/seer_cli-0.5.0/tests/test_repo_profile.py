"""Tests for seer.repo.profile (shallow path)."""

from __future__ import annotations

import subprocess
from pathlib import Path

from seer.repo.profile import profile_deep, profile_shallow


def _mk_fixture_repo(root: Path) -> Path:
    """Create a synthetic repo with every optional source populated."""
    root.mkdir()
    (root / "pyproject.toml").write_text("""
[project]
name = "demo"
version = "0.4.2"
dependencies = ["pyyaml"]

[project.scripts]
demo = "demo.cli:main"
""")
    (root / "demo").mkdir()
    (root / "demo" / "__init__.py").write_text("")
    (root / "CHANGELOG.md").write_text("""# Changelog

## [0.4.2] - 2026-05-10

### Added

- New feature.

## [0.4.1] - 2026-05-01

### Fixed

- A bug.

## [0.4.0] - 2026-04-20

### Added

- Initial.
""")
    (root / "CLAUDE.md").write_text("""# CLAUDE.md

## Project Status

Alpha. Coverage ratchet in progress.

## Architecture

Layers all the way down.
""")
    (root / "CITATION.md").write_text("""# Citations

| local | source | sha |
|---|---|---|
| src/x.py | other-repo | abc1234 |
""")
    (root / ".claude" / "skills" / "cicd").mkdir(parents=True)
    (root / "culture.yaml").write_text("agents:\n  - suffix: democult\n")
    return root


def test_profile_shallow_full_fixture(tmp_path: Path) -> None:
    """Full fixture repo exercises every optional source."""
    repo = _mk_fixture_repo(tmp_path / "demo")
    p = profile_shallow(repo)

    assert p["path"] == str(repo)
    assert p["name"] == "demo"
    assert p["version"] == "0.4.2"
    assert p["language"] == "python"
    assert p["manifest"] == "pyproject.toml"
    assert p["entry_points"] == {"demo": "demo.cli:main"}
    assert p["deps_runtime"] == ["pyyaml"]
    assert p["package_layout"] == ["demo/"]
    assert len(p["vendored_skills"]) == 1
    assert p["vendored_skills"][0]["name"] == "cicd"
    assert p["citations"] == [
        {"local": "src/x.py", "source_repo": "other-repo", "sha": "abc1234"},
    ]
    assert len(p["changelog_recent"]) == 3
    assert p["changelog_recent"][0]["version"] == "0.4.2"
    assert p["changelog_recent"][0]["date"] == "2026-05-10"
    assert "Alpha" in p["claude_md_status"]
    assert p["extra"].get("culture_nick") == "democult"


def test_profile_shallow_empty_repo(tmp_path: Path) -> None:
    """Repo with only pyproject.toml degrades silently on every optional source."""
    repo = tmp_path / "empty"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "e"\n')
    p = profile_shallow(repo)
    assert p["vendored_skills"] == []
    assert p["citations"] == []
    assert p["changelog_recent"] == []
    assert p["claude_md_status"] == ""
    assert p["extra"] == {}


def test_profile_shallow_no_manifest_repo(tmp_path: Path) -> None:
    """Repo with no pyproject.toml falls back to unknown language and dir name."""
    repo = tmp_path / "doc-only"
    (repo / ".claude" / "skills" / "x").mkdir(parents=True)
    p = profile_shallow(repo)
    assert p["language"] == "unknown"
    assert p["manifest"] is None
    assert p["name"] == "doc-only"


def test_profile_deep_adds_fields(tmp_path: Path) -> None:
    """Deep profile includes readme_intro, claude_md_sections, and commits_recent."""
    repo = _mk_fixture_repo(tmp_path / "demo")
    (repo / "README.md").write_text("""# demo

This is the intro paragraph that should be extracted verbatim, no
trailing newline trimming hassles.

## Subsection

Other stuff.
""")
    (repo / "CLAUDE.md").write_text((repo / "CLAUDE.md").read_text() + """

## Architecture

Three layers. Read top to bottom.

## Design Invariants

1. No LLM calls.
""")
    # init a git repo with one commit so commits_recent has data
    _git = ["git", "-C", str(repo)]  # noqa: S607
    subprocess.run([*_git, "init", "-q"], check=True)  # noqa: S607
    subprocess.run([*_git, "config", "user.email", "x@y"], check=True)  # noqa: S607
    subprocess.run([*_git, "config", "user.name", "x"], check=True)  # noqa: S607
    subprocess.run([*_git, "add", "-A"], check=True)  # noqa: S607
    subprocess.run([*_git, "commit", "-q", "-m", "test: seed commit"], check=True)  # noqa: S607

    p = profile_deep(repo)
    # shallow keys still present
    assert p["name"] == "demo"
    # deep additions
    assert "intro paragraph" in p["readme_intro"]
    assert "Architecture" in p["claude_md_sections"]
    assert "Three layers" in p["claude_md_sections"]
    assert "Design Invariants" in p["claude_md_sections"]
    assert "No LLM calls" in p["claude_md_sections"]
    assert p["commits_recent"] == ["test: seed commit"]


def test_profile_deep_missing_readme_and_git(tmp_path: Path) -> None:
    """Deep profile degrades gracefully when README and .git are absent."""
    repo = tmp_path / "bare"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "b"\n')
    p = profile_deep(repo)
    assert p["readme_intro"] == ""
    assert p["claude_md_sections"] == ""
    assert p["commits_recent"] == []


def test_profile_shallow_skill_sources_with_backticks(tmp_path: Path) -> None:
    """_read_skill_sources strips backticks from skill names and provenance fields."""
    repo = tmp_path / "demo"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "demo"\n')
    (repo / ".claude" / "skills" / "cicd").mkdir(parents=True)
    docs = repo / "docs"
    docs.mkdir()
    (docs / "skill-sources.md").write_text(
        "| Skill | Source | Version |\n" "|---|---|---|\n" "| `cicd` | steward | 0.11.0 |\n"
    )
    p = profile_shallow(repo)
    assert len(p["vendored_skills"]) == 1
    s = p["vendored_skills"][0]
    assert s["name"] == "cicd"
    assert s.get("source") == "steward"
    assert s.get("version") == "0.11.0"


def test_profile_shallow_citations_with_backticked_source_and_multiword_header(
    tmp_path: Path,
) -> None:
    """_read_citations recognises 'Local path' headers and strips backticks from fields."""
    repo = tmp_path / "demo"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "demo"\n')
    (repo / "CITATION.md").write_text(
        "| Local path | Source | SHA |\n"
        "|---|---|---|\n"
        "| src/x.py | `agentculture/culture` | abc1234 |\n"
    )
    p = profile_shallow(repo)
    assert p["citations"] == [
        {"local": "src/x.py", "source_repo": "agentculture/culture", "sha": "abc1234"},
    ]


def test_profile_shallow_skill_sources_preserves_inline_backtick_spans(
    tmp_path: Path,
) -> None:
    """A cell with multiple inline `…` spans must not lose any backticks.

    The agtag-shape input is a cell like
    `` `agentculture/steward` (`.claude/skills/cicd/`) `` — only a *fully*
    backtick-wrapped cell should be unwrapped; cells with internal backtick
    spans stay verbatim so the rendered markdown remains valid.
    """
    repo = tmp_path / "demo"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "demo"\n')
    (repo / ".claude" / "skills" / "cicd").mkdir(parents=True)
    docs = repo / "docs"
    docs.mkdir()
    (docs / "skill-sources.md").write_text(
        "| Skill | Source | Version |\n"
        "|---|---|---|\n"
        "| `cicd` | `agentculture/steward` (`.claude/skills/cicd/`) | adapted |\n"
    )
    p = profile_shallow(repo)
    assert len(p["vendored_skills"]) == 1
    s = p["vendored_skills"][0]
    assert s["name"] == "cicd"
    # Backticks inside the cell are preserved; the outer pair is NOT stripped
    # because the cell isn't a single wrapped span.
    assert s["source"] == "`agentculture/steward` (`.claude/skills/cicd/`)"
    # Every opening backtick has a matching closing backtick.
    assert s["source"].count("`") % 2 == 0
    assert s["version"] == "adapted"


def test_profile_shallow_src_layout_excludes_match_root(tmp_path: Path) -> None:
    """``src/`` scan honors the same dot-dir + ``_PKG_EXCLUDE`` filter as the root scan.

    Without this the src-layout exclude rules silently diverged from the root
    rules and ``tests/`` / dot-directories could leak into ``package_layout``
    and ``package_tree``.
    """
    repo = tmp_path / "demo"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "demo"\n')
    src = repo / "src"
    src.mkdir()
    # Legitimate top-level package — should appear.
    (src / "demo").mkdir()
    (src / "demo" / "__init__.py").write_text("")
    # Excluded dir name — should NOT appear even though it has __init__.py.
    (src / "tests").mkdir()
    (src / "tests" / "__init__.py").write_text("")
    # Dot-dir — should NOT appear.
    (src / ".hidden").mkdir()
    (src / ".hidden" / "__init__.py").write_text("")
    p = profile_shallow(repo)
    assert p["package_layout"] == ["src/demo/"]
    tree_names = {node["name"] for node in p["package_tree"]}
    assert tree_names == {"demo"}


def test_profile_shallow_package_tree_nested(tmp_path: Path) -> None:
    """package_tree exposes top-level subpackages and modules to ~depth 2."""
    repo = tmp_path / "demo"
    repo.mkdir()
    (repo / "pyproject.toml").write_text('[project]\nname = "demo"\n')
    (repo / "demo").mkdir()
    (repo / "demo" / "__init__.py").write_text("")
    (repo / "demo" / "nick.py").write_text("")
    (repo / "demo" / "cli").mkdir()
    (repo / "demo" / "cli" / "__init__.py").write_text("")
    (repo / "demo" / "cli" / "_errors.py").write_text("")
    (repo / "demo" / "cli" / "_commands").mkdir()
    (repo / "demo" / "cli" / "_commands" / "__init__.py").write_text("")
    (repo / "demo" / "issue").mkdir()
    (repo / "demo" / "issue" / "__init__.py").write_text("")
    (repo / "demo" / "issue" / "post.py").write_text("")
    # Excluded dirs must NOT appear in the tree.
    (repo / "tests").mkdir()
    (repo / "tests" / "__init__.py").write_text("")
    (repo / "demo" / "__pycache__").mkdir()
    p = profile_shallow(repo)
    tree = p["package_tree"]
    assert isinstance(tree, list)
    assert len(tree) == 1
    root = tree[0]
    assert root["name"] == "demo"
    assert "nick.py" in root["modules"]
    assert "__init__.py" in root["modules"]
    sub_names = {sp["name"] for sp in root["subpackages"]}
    assert sub_names == {"cli", "issue"}
    cli = next(sp for sp in root["subpackages"] if sp["name"] == "cli")
    assert "_errors.py" in cli["modules"]
    cli_sub = {sp["name"] for sp in cli["subpackages"]}
    assert cli_sub == {"_commands"}
    issue = next(sp for sp in root["subpackages"] if sp["name"] == "issue")
    assert "post.py" in issue["modules"]
    # Excluded dirs stay out.
    assert "tests" not in sub_names
    assert "__pycache__" not in {sp["name"] for sp in root["subpackages"]}
