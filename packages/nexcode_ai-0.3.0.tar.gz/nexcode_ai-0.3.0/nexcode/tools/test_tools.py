"""
test_tools.py — Utilities for running tests and gathering failure data.
"""
from pathlib import Path
from nexcode.agent_runtime.tool_registry import register_tool
from nexcode.tools.shell_tools import run_command

@register_tool("run_tests")
def run_tests(workspace: Path, framework: str = "pytest") -> str:
    """
    Run the test suite in the workspace.
    Currently defaults to pytest. Returns the output, useful for the fix loop.
    """
    if framework == "pytest":
        # Check if pytest is available
        return run_command(workspace, "pytest")
    elif framework == "npm":
        return run_command(workspace, "npm test")
    else:
        return f"Error: Unsupported test framework '{framework}'"
