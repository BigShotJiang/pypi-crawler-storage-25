"""
presentation.py - Shared Rich markup helpers for a professional CLI presentation.
"""

from __future__ import annotations

_TONE_STYLES = {
    "info": "bold cyan",
    "accent": "bold magenta",
    "success": "bold green",
    "warning": "bold yellow",
    "error": "bold red",
    "neutral": "bold white",
    "muted": "dim",
}


def _style_for(tone: str) -> str:
    return _TONE_STYLES.get((tone or "info").lower(), _TONE_STYLES["info"])


def ui_header(title: str, details: str = "") -> str:
    cleaned_title = str(title or "").strip() or "Nexcode"
    cleaned_details = str(details or "").strip()
    if cleaned_details:
        return f"[bold white]{cleaned_title}[/bold white] [dim]{cleaned_details}[/dim]"
    return f"[bold white]{cleaned_title}[/bold white]"


def ui_status(label: str, message: str, tone: str = "info", width: int = 12) -> str:
    cleaned_label = str(label or "").strip() or "Status"
    cleaned_message = str(message or "").strip()
    padded_label = cleaned_label.ljust(max(width, len(cleaned_label)))
    style = _style_for(tone)
    if cleaned_message:
        return f"[{style}]{padded_label}[/{style}] {cleaned_message}"
    return f"[{style}]{padded_label}[/{style}]"


def ui_detail(label: str, message: str, width: int = 12) -> str:
    cleaned_label = str(label or "").strip() or "Detail"
    cleaned_message = str(message or "").strip()
    padded_label = cleaned_label.ljust(max(width, len(cleaned_label)))
    if cleaned_message:
        return f"[dim]{padded_label}[/dim] {cleaned_message}"
    return f"[dim]{padded_label}[/dim]"


def ui_step(step_idx: int, total_steps: int, task: str) -> str:
    return ui_status(f"Step {step_idx}/{total_steps}", task, tone="accent", width=14)


def ui_timing(message: str) -> str:
    return ui_detail("Timing", message)
