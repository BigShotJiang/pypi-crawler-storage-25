"""
excerpts.py - Shared helpers for excerpting large files and command output.
"""
from __future__ import annotations

import re
import time
from pathlib import Path

LARGE_FILE_CHAR_LIMIT = 120000
LARGE_FILE_LINE_LIMIT = 2500
DEFAULT_FILE_CONTEXT_LINES = 30
DEFAULT_FILE_MAX_WINDOWS = 8

DEFAULT_SMALL_OUTPUT_CHARS = 20000
DEFAULT_LOG_CONTEXT_LINES = 25
DEFAULT_LOG_MAX_WINDOWS = 3
DEFAULT_LOG_TAIL_LINES = 120

DEFAULT_LOG_KEYWORDS = (
    "error",
    "exception",
    "traceback",
    "failed",
    "failure",
    "cannot",
    "can't resolve",
    "could not",
    "module not found",
    "syntaxerror",
    "failed to compile",
    "build failed",
    "err_module_not_found",
    "error ts",
)

_SYMBOL_PATTERNS = [
    re.compile(pattern)
    for pattern in (
        r"^\s*def\s+[A-Za-z_][A-Za-z0-9_]*\s*\(",
        r"^\s*async\s+def\s+[A-Za-z_][A-Za-z0-9_]*\s*\(",
        r"^\s*class\s+[A-Za-z_][A-Za-z0-9_]*\b",
        r"^\s*function\s+[A-Za-z_][A-Za-z0-9_]*\s*\(",
        r"^\s*export\s+default\s+function\b",
        r"^\s*export\s+(async\s+)?function\s+[A-Za-z_][A-Za-z0-9_]*\s*\(",
        r"^\s*export\s+(const|let|var|class|interface|type|enum)\s+[A-Za-z_][A-Za-z0-9_]*\b",
        r"^\s*(const|let|var)\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*(async\s*)?\(",
        r"^\s*(const|let|var)\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*\{",
    )
]

_STOPWORDS = {
    "about", "after", "again", "agent", "align", "allows", "already", "also", "and",
    "another", "apply", "around", "assistant", "before", "being", "between", "broad",
    "build", "bug", "change", "changes", "checked", "code", "complex", "context",
    "could", "current", "detail", "details", "exact", "execute", "failed", "failing",
    "files", "find", "first", "fix", "flow", "from", "global", "have", "here",
    "history", "into", "issue",
    "latest", "layout", "like", "make", "model", "more", "must", "need", "next",
    "only", "output", "pattern", "paths", "plan", "preview", "project", "reason",
    "recent", "report", "return", "route", "safe", "same", "search", "should",
    "simple", "step", "still", "than", "that", "their", "them", "there", "these",
    "they", "this", "tool", "tools", "turn", "update", "user", "using", "what",
    "when", "where", "which", "with", "work", "workspace", "would",
}


def _iter_strings(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set)):
        items: list[str] = []
        for item in value:
            items.extend(_iter_strings(item))
        return items
    return [str(value)]


def normalize_focus_terms(raw_terms) -> list[str]:
    terms: list[str] = []
    seen: set[str] = set()
    for raw in _iter_strings(raw_terms):
        value = str(raw or "").strip()
        if not value:
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        terms.append(value)
    return terms


def collect_focus_terms(*sources, limit: int = 18) -> list[str]:
    terms: list[str] = []
    seen: set[str] = set()

    def _push(candidate: str) -> None:
        value = candidate.strip("`'\".,:;()[]{}<>")
        if len(value) < 3:
            return
        key = value.casefold()
        if key in seen or key in _STOPWORDS:
            return
        seen.add(key)
        terms.append(value)

    for source in sources:
        for text in _iter_strings(source):
            for token in re.findall(r"[A-Za-z_][A-Za-z0-9_.:/-]{2,}", text):
                _push(token)
                if len(terms) >= limit:
                    return terms
    return terms


def _merge_ranges(ranges: list[tuple[int, int]], total_lines: int) -> list[tuple[int, int]]:
    if total_lines <= 0:
        return []
    normalized: list[tuple[int, int]] = []
    for start, end in ranges:
        start = max(1, int(start))
        end = min(total_lines, int(end))
        if start > end:
            continue
        normalized.append((start, end))
    if not normalized:
        return []
    normalized.sort()
    merged = [normalized[0]]
    for start, end in normalized[1:]:
        prev_start, prev_end = merged[-1]
        if start <= prev_end + 1:
            merged[-1] = (prev_start, max(prev_end, end))
        else:
            merged.append((start, end))
    return merged


def _find_focus_ranges(
    lines: list[str],
    focus_terms: list[str],
    context_lines: int,
    max_windows: int,
) -> list[tuple[int, int]]:
    if not lines or not focus_terms or max_windows <= 0:
        return []

    matchers: list[tuple[str, re.Pattern[str] | None]] = []
    for term in focus_terms:
        if not term:
            continue
        pattern = None
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", term):
            pattern = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(term)}(?![A-Za-z0-9_])", re.IGNORECASE)
        matchers.append((term.casefold(), pattern))
    windows: list[tuple[int, int]] = []

    for line_no, line in enumerate(lines, start=1):
        haystack = line.casefold()
        if any(pattern.search(line) if pattern else term in haystack for term, pattern in matchers):
            windows.append((line_no - context_lines, line_no + context_lines))
            if len(windows) >= max_windows * 2:
                break

    return _merge_ranges(windows, len(lines))[:max_windows]


def _find_structural_ranges(lines: list[str]) -> list[tuple[int, int]]:
    if not lines:
        return []

    total_lines = len(lines)
    ranges: list[tuple[int, int]] = [(1, min(80, total_lines))]

    symbol_hits: list[int] = []
    for line_no, line in enumerate(lines, start=1):
        if any(pattern.search(line) for pattern in _SYMBOL_PATTERNS):
            symbol_hits.append(line_no)
        if len(symbol_hits) >= 2:
            break

    for line_no in symbol_hits:
        ranges.append((line_no - 20, line_no + 35))

    if total_lines > 80:
        ranges.append((max(1, total_lines - 79), total_lines))

    return _merge_ranges(ranges, total_lines)


def format_numbered_excerpt(
    lines: list[str],
    ranges: list[tuple[int, int]],
    *,
    trailing_omission: bool = True,
) -> str:
    total_lines = len(lines)
    merged = _merge_ranges(ranges, total_lines)
    if not merged:
        return ""

    parts: list[str] = []
    previous_end = 0

    for start, end in merged:
        if start > previous_end + 1:
            omitted = start - previous_end - 1
            parts.append(f"... [{omitted} lines omitted] ...")
        parts.append(f"@@ L{start}-L{end} @@")
        for line_no in range(start, end + 1):
            parts.append(f"L{line_no}: {lines[line_no - 1]}")
        previous_end = end

    if trailing_omission and previous_end < total_lines:
        parts.append(f"... [{total_lines - previous_end} lines omitted] ...")

    return "\n".join(parts)


def build_file_excerpt(
    path: str,
    content: str,
    *,
    focus_terms=None,
    context_lines: int = DEFAULT_FILE_CONTEXT_LINES,
    max_windows: int = DEFAULT_FILE_MAX_WINDOWS,
    full_char_limit: int = LARGE_FILE_CHAR_LIMIT,
    full_line_limit: int = LARGE_FILE_LINE_LIMIT,
) -> str:
    lines = content.splitlines()
    if len(content) <= full_char_limit and len(lines) <= full_line_limit:
        return f"--- FILE: {path} ---\n{content}\n"

    normalized_terms = normalize_focus_terms(focus_terms)
    ranges = _find_focus_ranges(lines, normalized_terms, context_lines, max_windows)
    mode = "focused excerpts"
    if not ranges:
        ranges = _find_structural_ranges(lines)
        mode = "structural excerpts"

    excerpt_body = format_numbered_excerpt(lines, ranges)
    return (
        f"--- FILE: {path} ({mode} from {len(lines)} lines) ---\n"
        f"{excerpt_body}\n"
    )


def write_text_artifact(artifact_dir: Path, prefix: str, content: str, suffix: str = ".log") -> Path:
    artifact_dir.mkdir(parents=True, exist_ok=True)
    safe_prefix = re.sub(r"[^A-Za-z0-9._-]+", "_", prefix).strip("._") or "artifact"
    artifact_path = artifact_dir / f"{safe_prefix}_{time.time_ns()}{suffix}"
    artifact_path.write_text(content, encoding="utf-8")
    return artifact_path


def build_log_output_summary(
    output: str,
    *,
    failed: bool,
    artifact_dir: Path | None = None,
    artifact_path: Path | None = None,
    artifact_prefix: str = "command_output",
    small_output_chars: int = DEFAULT_SMALL_OUTPUT_CHARS,
    context_lines: int = DEFAULT_LOG_CONTEXT_LINES,
    max_windows: int = DEFAULT_LOG_MAX_WINDOWS,
    tail_lines: int = DEFAULT_LOG_TAIL_LINES,
    keywords=None,
) -> tuple[str, Path | None]:
    text = output or ""
    if not failed and len(text) <= small_output_chars:
        return (text if text.strip() else "Command executed successfully with no output."), None

    if artifact_path is None and artifact_dir is not None:
        artifact_path = write_text_artifact(artifact_dir, artifact_prefix, text)

    lines = text.splitlines()
    if not lines:
        lines = [text] if text else []

    selected_ranges: list[tuple[int, int]] = []
    keyword_ranges: list[tuple[int, int]] = []
    active_keywords = normalize_focus_terms(keywords or DEFAULT_LOG_KEYWORDS)

    if lines and active_keywords:
        lowered_keywords = [keyword.casefold() for keyword in active_keywords]
        for line_no, line in enumerate(lines, start=1):
            haystack = line.casefold()
            if any(keyword in haystack for keyword in lowered_keywords):
                keyword_ranges.append((line_no - context_lines, line_no + context_lines))
                if len(keyword_ranges) >= max_windows * 2:
                    break

    if keyword_ranges:
        selected_ranges.extend(_merge_ranges(keyword_ranges, len(lines))[:max_windows])

    if lines:
        selected_ranges.append((max(1, len(lines) - tail_lines + 1), len(lines)))

    merged_ranges = _merge_ranges(selected_ranges, len(lines))
    excerpt_body = format_numbered_excerpt(lines, merged_ranges) if lines else "(no output)"
    path_line = f"Full output saved to: {artifact_path}" if artifact_path else "Full output was not persisted."

    summary = (
        f"{path_line}\n\n"
        f"Selected excerpts from {len(lines)} lines of output:\n"
        f"{excerpt_body}"
    )
    return summary, artifact_path
