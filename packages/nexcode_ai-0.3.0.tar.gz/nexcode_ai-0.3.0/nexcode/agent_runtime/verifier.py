"""
verifier.py - Automated step verification for the coding agent.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from rich.console import Console

from nexcode.agent_runtime.excerpts import build_log_output_summary
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.project_profile import (
    ProjectProfile,
    build_build_commands,
    build_lint_commands,
    build_test_commands,
    detect_project_profile,
    find_project_root,
)
from nexcode.agent_runtime.task_scope import resolve_task_scope
from nexcode.agent_runtime.workspace import get_logs_dir, get_project_root, load_agent_state, normalize_rel_path

console = Console()

_FATAL_RUNTIME_PATTERNS = [
    "Module not found",
    "Can't resolve",
    "Cannot find module",
    "SyntaxError",
    "Failed to compile",
    "Build failed",
    "error TS",
    "ERR_MODULE_NOT_FOUND",
    "Could not resolve",
    "Unexpected token",
]

_PLACEHOLDER_PATTERNS = [
    ("TODO placeholder", r"\bTODO\b"),
    ("FIXME placeholder", r"\bFIXME\b"),
    ("lorem ipsum filler", r"lorem ipsum"),
    ("insert-here placeholder", r"\[insert[^\]]*\]"),
    ("replace-me placeholder", r"replace me"),
]

_TEXT_FILE_SUFFIXES = {
    ".css",
    ".html",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".py",
    ".sass",
    ".scss",
    ".svelte",
    ".ts",
    ".tsx",
    ".txt",
    ".vue",
    ".yaml",
    ".yml",
}

_PROJECT_WIDE_CONTROL_FILES = {
    ".eslintrc",
    ".eslintrc.cjs",
    ".eslintrc.js",
    ".eslintrc.json",
    ".eslintrc.yaml",
    ".eslintrc.yml",
    ".flake8",
    "cargo.lock",
    "cargo.toml",
    "cmakelists.txt",
    "composer.json",
    "conftest.py",
    "eslint.config.cjs",
    "eslint.config.js",
    "eslint.config.mjs",
    "eslint.config.ts",
    "gemfile",
    "go.mod",
    "go.sum",
    "jsconfig.json",
    "makefile",
    "mix.exs",
    "mypy.ini",
    "next.config.js",
    "next.config.mjs",
    "next.config.ts",
    "package-lock.json",
    "package.json",
    "pipfile",
    "poetry.lock",
    "pom.xml",
    "pyproject.toml",
    "pytest.ini",
    "requirements.txt",
    "ruff.toml",
    "setup.cfg",
    "setup.py",
    "tox.ini",
    "tsconfig.json",
    "yarn.lock",
    "pnpm-lock.yaml",
}

_FORMAT_ONLY_LINT_PATTERNS = (
    r"\bW29[123]\b",
    r"\bW39[12]\b",
    r"\bE30[1256]\b",
    r"\bE27[15]\b",
    r"\bE501\b",
    r"\bE402\b",
    r"\bI00[123]\b",
    r"\bformat(?:ted|ting)\b",
    r"\btrailing whitespace\b",
    r"\bblank line\b",
)


def _prepare_command(cmd: list[str]) -> list[str]:
    if os.name == "nt" and cmd:
        head = cmd[0].lower()
        if head in {"npm", "npx", "pnpm", "yarn", "mvnw", "mvnw.cmd", "gradlew", "gradlew.bat"} or head.endswith((".cmd", ".bat")):
            return ["cmd", "/c", *cmd]
    return cmd


def _verifier_artifact_dir(workspace: Path) -> Path:
    return get_logs_dir(workspace) / "verifier_artifacts"


def _summarize_verifier_output(workspace: Path, runner: str, output: str, *, failed: bool) -> str:
    rendered, _ = build_log_output_summary(
        output,
        failed=failed,
        artifact_dir=_verifier_artifact_dir(workspace),
        artifact_prefix=runner.replace(" ", "_"),
    )
    return rendered


def _run_cmd(workspace: Path, cmd: list[str], timeout: int = 60) -> tuple[int, str]:
    try:
        prepared = _prepare_command(cmd)
        result = subprocess.run(
            prepared,
            cwd=workspace,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
    except subprocess.TimeoutExpired:
        return 1, f"ERROR: Command timed out after {timeout}s"
    except FileNotFoundError:
        return 1, f"ERROR: Command not found: {cmd[0]}"
    except Exception as exc:
        return 1, f"ERROR: {exc}"

    output = (result.stdout or "") + (result.stderr or "")
    return result.returncode, output.strip()


def _command_exists(command: str) -> bool:
    if shutil.which(command) is not None:
        return True
    if os.name == "nt":
        return any(shutil.which(f"{command}{suffix}") is not None for suffix in (".cmd", ".bat", ".exe"))
    return False


def _find_project_root(workspace: Path) -> Path:
    return find_project_root(workspace)


def _command_available(project_root: Path, command: str) -> bool:
    local_candidates = [command]
    if os.name == "nt" and not command.lower().endswith((".cmd", ".bat", ".exe")):
        local_candidates.extend([f"{command}.cmd", f"{command}.bat", f"{command}.exe"])
    for candidate in local_candidates:
        if (project_root / candidate).exists():
            return True
    return _command_exists(command)


def _run_candidate_commands(
    workspace: Path,
    project_root: Path,
    candidates: list[tuple[str, list[str]]],
    *,
    timeout: int,
    skipped_output: str,
) -> dict:
    for label, cmd in candidates:
        if not cmd or not _command_available(project_root, cmd[0]):
            continue
        code, out = _run_cmd(project_root, cmd, timeout=timeout)
        if code != 0 and isinstance(out, str) and out.startswith("ERROR: Command not found:"):
            continue
        return {
            "runner": label,
            "passed": code == 0,
            "output": _summarize_verifier_output(workspace, label.replace(" ", "_"), out, failed=code != 0),
        }
    return {"runner": "none", "passed": True, "output": skipped_output}


def _resolve_verification_targets(
    workspace: Path,
    project_root: Path,
    *path_groups: list[str] | tuple[str, ...] | None,
) -> list[str]:
    managed_project_root = get_project_root(workspace).resolve()
    resolved: list[str] = []
    seen: set[str] = set()
    candidate_bases = [project_root.resolve()]
    if managed_project_root not in candidate_bases:
        candidate_bases.append(managed_project_root)
    workspace_root = workspace.resolve()
    if workspace_root not in candidate_bases:
        candidate_bases.append(workspace_root)

    for group in path_groups:
        for raw_path in group or []:
            normalized = normalize_rel_path(str(raw_path)).rstrip("/")
            if not normalized or normalized.startswith("scratch:"):
                continue
            relative = Path(normalized)
            for base in candidate_bases:
                candidate = (base / relative).resolve()
                if not candidate.exists() or not candidate.is_file():
                    continue
                try:
                    rel_to_project = candidate.relative_to(project_root.resolve())
                except ValueError:
                    continue
                project_relative = normalize_rel_path(str(rel_to_project).replace("\\", "/")).rstrip("/")
                if project_relative and project_relative not in seen:
                    seen.add(project_relative)
                    resolved.append(project_relative)
                break
    return resolved


def _verification_mode_for_targets(targets: list[str]) -> str:
    if not targets:
        return "project"
    for target in targets:
        path = Path(target)
        name = path.name.lower()
        if len(path.parts) == 1 and name in _PROJECT_WIDE_CONTROL_FILES:
            return "project"
    return "scoped"


def _is_format_only_lint_output(output: str) -> bool:
    text = str(output or "").strip()
    if not text:
        return False
    tokens = []
    for line in text.splitlines():
        if line.startswith("Full output saved to:") or line.startswith("Selected excerpts") or line.startswith("@@ "):
            continue
        if not line.strip():
            continue
        tokens.append(line)
    if not tokens:
        return False
    for line in tokens:
        if not any(re.search(pattern, line, re.IGNORECASE) for pattern in _FORMAT_ONLY_LINT_PATTERNS):
            return False
    return True


def _classify_verification_failure(checks: dict) -> tuple[str, str]:
    stage1_failures = [
        not checks["content_integrity"]["passed"],
        not checks["syntax"]["passed"],
        not checks["runtime_logs"]["passed"],
        not checks["ui_contract"]["passed"],
        not checks["lint"].get("passed", True),
    ]
    if any(stage1_failures):
        lint_output = str(checks["lint"].get("output") or "")
        if (
            not checks["content_integrity"]["passed"]
            or not checks["syntax"]["passed"]
            or not checks["runtime_logs"]["passed"]
            or not checks["ui_contract"]["passed"]
        ):
            return "semantic_lint", "stage1_touched_files"
        if _is_format_only_lint_output(lint_output):
            return "format_only", "stage1_touched_files"
        return "semantic_lint", "stage1_touched_files"
    if not checks["tests"].get("passed", True):
        return "broad_validation", "stage2_tests"
    if not checks["build"].get("passed", True):
        return "broad_validation", "stage3_build"
    return "none", "complete"


def _build_verifier_judgment_fallback(
    *,
    checks: dict,
    verification_mode: str,
    verification_targets: list[str],
    failure_classification: str,
    verification_stage: str,
) -> dict:
    if all(check.get("passed", True) for check in checks.values()):
        return {
            "status": "pass",
            "judgment": "pass",
            "is_blocking": False,
            "reason": "All deterministic verification checks passed.",
            "suggested_action": "none",
            "verification_stage": verification_stage,
        }

    if not checks["content_integrity"]["passed"]:
        return {
            "status": "fail",
            "judgment": "blocking",
            "is_blocking": True,
            "reason": "Content integrity checks failed.",
            "suggested_action": "repair",
            "verification_stage": verification_stage,
        }
    if not checks["syntax"]["passed"] or not checks["runtime_logs"]["passed"] or not checks["ui_contract"]["passed"]:
        return {
            "status": "fail",
            "judgment": "blocking",
            "is_blocking": True,
            "reason": "A blocking syntax, runtime, or UI contract check failed.",
            "suggested_action": "repair",
            "verification_stage": verification_stage,
        }
    if not checks["tests"].get("passed", True) or not checks["build"].get("passed", True):
        return {
            "status": "fail",
            "judgment": "blocking",
            "is_blocking": True,
            "reason": "A project validation check failed.",
            "suggested_action": "repair",
            "verification_stage": verification_stage,
        }
    if not checks["lint"].get("passed", True):
        lint_output = str(checks["lint"].get("output") or "")
        if _is_format_only_lint_output(lint_output):
            if verification_mode == "scoped" and verification_targets:
                return {
                    "status": "warn",
                    "judgment": "auto_fixable_format",
                    "is_blocking": False,
                    "reason": "Only formatter-style lint issues were found in a scoped task.",
                    "suggested_action": "auto_fix",
                    "verification_stage": verification_stage,
                }
            return {
                "status": "fail",
                "judgment": "blocking",
                "is_blocking": True,
                "reason": "Formatter-style lint issues remain in a broad validation context.",
                "suggested_action": "repair",
                "verification_stage": verification_stage,
            }
        if failure_classification == "semantic_lint":
            return {
                "status": "fail",
                "judgment": "blocking",
                "is_blocking": True,
                "reason": "Lint found a semantic or non-formatting issue.",
                "suggested_action": "repair",
                "verification_stage": verification_stage,
            }

    return {
        "status": "fail",
        "judgment": "blocking",
        "is_blocking": True,
        "reason": "Verification found unresolved issues.",
        "suggested_action": "repair",
        "verification_stage": verification_stage,
    }


def _judge_verification_result(
    workspace: Path,
    *,
    step: dict,
    checks: dict,
    verification_mode: str,
    verification_targets: list[str],
    failure_classification: str,
    verification_stage: str,
) -> dict:
    fallback = _build_verifier_judgment_fallback(
        checks=checks,
        verification_mode=verification_mode,
        verification_targets=verification_targets,
        failure_classification=failure_classification,
        verification_stage=verification_stage,
    )
    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.executor import extract_json
        from nexcode.agent_runtime.planner import _call_gateway

        access = load_access()
        if not access.get("api_key"):
            return fallback
        agent_cfg = load_agent_config(workspace)
        judge_prompt = (
            "You are the final verification judge for an autonomous coding agent.\n\n"
            "Return strict JSON only in this shape:\n"
            '{"judgment":"pass|blocking|warning_only|auto_fixable_format","is_blocking":true,"reason":"","suggested_action":"none|repair|auto_fix","status":"pass|warn|fail"}\n\n'
            "Rules:\n"
            "- Treat syntax, runtime, UI contract, placeholder, tests, and build failures as blocking.\n"
            "- Treat purely formatting lint in narrow scoped tasks as auto_fixable_format or warning_only, not blocking.\n"
            "- Do not invent new failures. Judge only the provided deterministic evidence.\n\n"
            f"Step:\n{json.dumps(step, ensure_ascii=True)}\n\n"
            f"Verification mode: {verification_mode}\n"
            f"Verification targets: {json.dumps(verification_targets, ensure_ascii=True)}\n"
            f"Failure classification: {failure_classification}\n"
            f"Verification stage: {verification_stage}\n\n"
            f"Deterministic checks:\n{json.dumps(checks, ensure_ascii=True)}"
        )
        response, _usage = _call_gateway(
            access["api_key"],
            access["endpoint"],
            agent_cfg["model"],
            "You are a strict JSON verification judge.",
            judge_prompt,
            json_mode=False,
        )
        parsed = extract_json(response)
        if not isinstance(parsed, dict):
            return fallback
        judgment = str(parsed.get("judgment") or "").strip()
        status = str(parsed.get("status") or "").strip()
        suggested_action = str(parsed.get("suggested_action") or "").strip()
        if judgment not in {"pass", "blocking", "warning_only", "auto_fixable_format"}:
            return fallback
        if status not in {"pass", "warn", "fail"}:
            return fallback
        if suggested_action not in {"none", "repair", "auto_fix"}:
            return fallback
        return {
            "judgment": judgment,
            "is_blocking": bool(parsed.get("is_blocking")),
            "reason": str(parsed.get("reason") or fallback["reason"]).strip() or fallback["reason"],
            "suggested_action": suggested_action,
            "status": status,
            "verification_stage": verification_stage,
        }
    except Exception:
        return fallback


def _check_unit_tests(
    workspace: Path,
    project_root: Path | None = None,
    profile: ProjectProfile | None = None,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> dict:
    profile = profile or detect_project_profile(workspace)
    project_root = project_root or profile.project_root
    if verification_mode == "scoped":
        return {
            "runner": "scoped-skip",
            "passed": True,
            "output": "Skipped project-wide tests for this narrow file-scoped task.",
        }
    return _run_candidate_commands(
        workspace,
        project_root,
        build_test_commands(profile, targets=targets, verification_mode=verification_mode),
        timeout=900,
        skipped_output="No test suite detected - skipped.",
    )


def _check_lint(
    workspace: Path,
    project_root: Path | None = None,
    profile: ProjectProfile | None = None,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> dict:
    profile = profile or detect_project_profile(workspace)
    project_root = project_root or profile.project_root
    return _run_candidate_commands(
        workspace,
        project_root,
        build_lint_commands(profile, targets=targets, verification_mode=verification_mode),
        timeout=120,
        skipped_output="No scoped lint command detected - skipped." if verification_mode == "scoped" else "No lint config detected - skipped.",
    )


def _check_build(
    workspace: Path,
    project_root: Path | None = None,
    profile: ProjectProfile | None = None,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> dict:
    profile = profile or detect_project_profile(workspace)
    project_root = project_root or profile.project_root
    if verification_mode == "scoped":
        return {
            "runner": "scoped-skip",
            "passed": True,
            "output": "Skipped project-wide build checks for this narrow file-scoped task.",
        }
    return _run_candidate_commands(
        workspace,
        project_root,
        build_build_commands(profile, targets=targets, verification_mode=verification_mode),
        timeout=300,
        skipped_output="No build command detected - skipped.",
    )


def _check_syntax(
    workspace: Path,
    project_root: Path | None = None,
    profile: ProjectProfile | None = None,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> dict:
    profile = profile or detect_project_profile(workspace)
    project_root = project_root or profile.project_root
    if "python" in profile.stack_ids or "python-web" in profile.stack_ids:
        python_targets = [target for target in (targets or []) if Path(target).suffix.lower() == ".py"]
        for interpreter in ("python", "python3", "py"):
            if not _command_available(project_root, interpreter):
                continue
            if verification_mode == "scoped":
                if not python_targets:
                    return {"runner": "none", "passed": True, "output": "No scoped Python syntax check required - skipped."}
                code, out = _run_cmd(project_root, [interpreter, "-m", "py_compile", *python_targets], timeout=120)
                runner = f"{interpreter} -m py_compile"
                artifact_prefix = "python_py_compile"
            else:
                code, out = _run_cmd(project_root, [interpreter, "-m", "compileall", "."], timeout=120)
                runner = f"{interpreter} -m compileall"
                artifact_prefix = "python_compileall"
            return {
                "runner": runner,
                "passed": code == 0,
                "output": _summarize_verifier_output(workspace, artifact_prefix, out, failed=code != 0),
            }
    return {"runner": "none", "passed": True, "output": "No syntax check required - skipped."}


def _check_content_integrity(workspace: Path, changed_files: list[str]) -> dict:
    violations = []
    project_root = get_project_root(workspace)
    for rel_path in changed_files or []:
        relative = Path(rel_path)
        candidates = [workspace / relative, project_root / relative]
        file_path = next((candidate for candidate in candidates if candidate.exists()), workspace / relative)
        if not file_path.exists() or not file_path.is_file():
            continue
        if file_path.suffix.lower() not in _TEXT_FILE_SUFFIXES:
            continue
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for label, pattern in _PLACEHOLDER_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                violations.append(f"{rel_path}: {label}")
                break
    return {"passed": not violations, "violations": violations}


def _check_runtime_logs(workspace: Path) -> dict:
    logs_dir = get_logs_dir(workspace) / "background"
    if not logs_dir.exists():
        return {"runner": "background logs", "passed": True, "output": "No background logs detected - skipped."}

    violations = []
    for log_file in sorted(logs_dir.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
        try:
            content = log_file.read_text(encoding="utf-8", errors="ignore")[-20000:]
        except Exception:
            continue
        for pattern in _FATAL_RUNTIME_PATTERNS:
            if pattern.lower() in content.lower():
                rendered, _ = build_log_output_summary(
                    content,
                    failed=True,
                    artifact_path=log_file,
                    artifact_prefix=log_file.stem,
                    keywords=[pattern, *_FATAL_RUNTIME_PATTERNS],
                )
                violations.append(f"{log_file.name}:\n{rendered}")
                break

    return {
        "runner": "background logs",
        "passed": not violations,
        "output": "\n".join(violations) if violations else "No fatal runtime patterns found in background logs.",
    }


def _check_ui_contract(workspace: Path, project_root: Path, step: dict, changed_files: list[str]) -> dict:
    state = load_agent_state(workspace)
    contract = state.get("ui_contract", {})
    if not isinstance(contract, dict) or not contract:
        return {"runner": "ui contract", "passed": True, "output": "No UI contract detected - skipped."}

    violations = []
    required_theme_tokens = contract.get("required_theme_tokens", [])
    globals_files = contract.get("globals_files", [])

    changed_normalized = {normalize_rel_path(path) for path in (changed_files or [])}
    globals_normalized = {normalize_rel_path(path) for path in globals_files}
    globals_were_written = bool(changed_normalized & globals_normalized)

    if globals_were_written and contract.get("requires_theme_tokens") and globals_files:
        globals_path = next(((project_root / Path(path)) for path in globals_files if (project_root / Path(path)).exists()), None)
        if globals_path is None:
            violations.append("Theme foundation missing: globals stylesheet from UI contract was not found.")
        else:
            content = globals_path.read_text(encoding="utf-8", errors="ignore")
            missing = [token for token in required_theme_tokens if token not in content]
            if missing:
                violations.append(f"{globals_path.relative_to(project_root)}: missing theme token(s): {', '.join(missing)}")

    page_paths = set()
    for path in (changed_files or []) + list(step.get("files", []) or []):
        normalized = str(Path(path).as_posix()).lstrip("./")
        if normalized.endswith("page.tsx"):
            page_paths.add(normalized)

    route_contracts = contract.get("route_contracts", {})
    for page_path in sorted(page_paths):
        route_rules = route_contracts.get(page_path, {})
        if not route_rules.get("requires_header", True):
            continue
        file_path = project_root / Path(page_path)
        if not file_path.exists():
            continue
        content = file_path.read_text(encoding="utf-8", errors="ignore")
        if "<h1" not in content and "PageHeader" not in content:
            violations.append(f"{page_path}: page is missing a visible header pattern such as `<h1>` or `PageHeader`.")

    return {
        "runner": "ui contract",
        "passed": not violations,
        "output": "\n".join(violations) if violations else "UI contract checks passed.",
    }


def _infer_relevant_stack_ids(profile: ProjectProfile, relevant_paths: list[str]) -> tuple[str, ...]:
    if not relevant_paths:
        return profile.stack_ids

    wanted: set[str] = set()
    for raw_path in relevant_paths:
        suffix = Path(str(raw_path)).suffix.lower()
        name = Path(str(raw_path)).name.lower()
        if suffix == ".py" or name in {"pyproject.toml", "requirements.txt", "pipfile", "poetry.lock", "setup.py", "pytest.ini"}:
            wanted.update({"python", "python-web"})
        elif suffix == ".go" or name in {"go.mod", "go.sum"}:
            wanted.add("go")
        elif suffix in {".js", ".jsx", ".ts", ".tsx", ".css", ".scss", ".sass", ".vue", ".svelte"} or name in {"package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock"}:
            wanted.update({"node", "react", "nextjs"})
        elif suffix == ".rs" or name == "cargo.toml":
            wanted.add("rust")
        elif suffix in {".cs", ".csproj"} or name.endswith(".sln"):
            wanted.add("dotnet")
        elif suffix in {".java", ".kt"} or name in {"pom.xml", "build.gradle", "build.gradle.kts"}:
            wanted.update({"java-maven", "java-gradle"})
        elif suffix == ".php" or name == "composer.json":
            wanted.add("php")
        elif suffix == ".rb" or name == "gemfile":
            wanted.add("ruby")
        elif suffix in {".ex", ".exs"} or name == "mix.exs":
            wanted.add("elixir")
        elif suffix == ".swift" or name == "package.swift":
            wanted.add("swift")
        elif suffix in {".c", ".cc", ".cpp", ".h", ".hpp"} or name in {"cmakelists.txt", "makefile"}:
            wanted.add("native")
    filtered = tuple(stack for stack in profile.stack_ids if stack in wanted)
    return filtered or profile.stack_ids


def _filter_profile_for_paths(profile: ProjectProfile, relevant_paths: list[str]) -> ProjectProfile:
    filtered_stack_ids = _infer_relevant_stack_ids(profile, relevant_paths)
    return ProjectProfile(
        project_root=profile.project_root,
        stack_ids=filtered_stack_ids,
        primary_stack=filtered_stack_ids[0] if filtered_stack_ids else profile.primary_stack,
        package_manager=profile.package_manager,
        package_scripts=profile.package_scripts,
        focused_roots=profile.focused_roots,
    )


def run_verification(workspace: Path, step: dict, changed_files: list[str] = None, is_final_step: bool = False) -> dict:
    if is_final_step:
        console.print(ui_status("Verifier", "Running full checks for the final step"))
    else:
        console.print(ui_status("Verifier", "Running fast checks"))

    changed_files = changed_files or []
    state = load_agent_state(workspace)
    scope = resolve_task_scope(
        workspace,
        user_message=f"{step.get('task', '')} {step.get('goal', '')}",
        checked_files=state.get("investigation_checked_files", []),
        plan_files=step.get("files", []),
        changed_files=changed_files,
    )
    relevant_paths = list(changed_files or step.get("files", []) or state.get("investigation_checked_files", []))
    project_root = scope.primary_root or _find_project_root(workspace)
    if project_root != workspace:
        console.print(ui_detail("Verifier", f"Using project root '{project_root.name}/' instead of the workspace root"))

    profile = detect_project_profile(workspace, plan_item=step, task_scope=scope)
    profile = _filter_profile_for_paths(profile, relevant_paths)
    verification_targets = _resolve_verification_targets(
        workspace,
        project_root,
        changed_files,
        step.get("files", []),
        state.get("investigation_checked_files", []),
    )
    verification_mode = _verification_mode_for_targets(verification_targets)

    checks = {
        "content_integrity": _check_content_integrity(workspace, changed_files),
        "syntax": _check_syntax(
            workspace,
            project_root,
            profile=profile,
            targets=verification_targets,
            verification_mode=verification_mode,
        ),
        "runtime_logs": _check_runtime_logs(workspace),
        "ui_contract": _check_ui_contract(workspace, project_root, step, changed_files),
    }

    if is_final_step:
        checks["lint"] = _check_lint(
            workspace,
            project_root,
            profile=profile,
            targets=verification_targets,
            verification_mode=verification_mode,
        )
        stage1_pass = all(check.get("passed", True) for check in checks.values())
        checks["tests"] = _check_unit_tests(
            workspace,
            project_root,
            profile=profile,
            targets=verification_targets,
            verification_mode=verification_mode,
        ) if stage1_pass else {"runner": "skipped", "passed": True, "output": "Skipped (a touched-file verification check failed)." }
        if stage1_pass and checks["tests"]["passed"]:
            checks["build"] = _check_build(
                workspace,
                project_root,
                profile=profile,
                targets=verification_targets,
                verification_mode=verification_mode,
            )
        else:
            checks["build"] = {"runner": "skipped", "passed": True, "output": "Skipped (an earlier verification check failed)."}
    else:
        checks["tests"] = {"runner": "deferred", "passed": True, "output": "Deferred to final step."}
        checks["lint"] = {"runner": "deferred", "passed": True, "output": "Deferred to final step."}
        checks["build"] = {"runner": "deferred", "passed": True, "output": "Deferred to final step."}

    diagnostics_parts = []
    if not checks["content_integrity"]["passed"]:
        diagnostics_parts.append("Content violations: " + "; ".join(checks["content_integrity"]["violations"]))
    if not checks["syntax"]["passed"]:
        diagnostics_parts.append(f"Syntax failed ({checks['syntax']['runner']}): " + checks["syntax"]["output"])
    if not checks["runtime_logs"]["passed"]:
        diagnostics_parts.append("Runtime logs contain fatal errors: " + checks["runtime_logs"]["output"])
    if not checks["ui_contract"]["passed"]:
        diagnostics_parts.append("UI contract failed: " + checks["ui_contract"]["output"])
    if not checks["tests"].get("passed", True):
        diagnostics_parts.append(f"Tests failed ({checks['tests']['runner']}): " + checks["tests"]["output"])
    if not checks["lint"].get("passed", True):
        diagnostics_parts.append(f"Lint failed ({checks['lint']['runner']}): " + checks["lint"]["output"])
    if not checks["build"].get("passed", True):
        diagnostics_parts.append("Build failed: " + checks["build"]["output"])

    failure_classification, verification_stage = _classify_verification_failure(checks)
    judgment = _judge_verification_result(
        workspace,
        step=step,
        checks=checks,
        verification_mode=verification_mode,
        verification_targets=verification_targets,
        failure_classification=failure_classification,
        verification_stage=verification_stage,
    )
    status = str(judgment.get("status") or "fail")
    if status == "pass":
        console.print(ui_status("Verifier", "All checks passed", tone="success"))
    elif status == "warn":
        console.print(ui_status("Verifier", "Checks completed with non-blocking warnings", tone="warning"))
    else:
        console.print(ui_status("Verifier", f"{len(diagnostics_parts)} check(s) failed", tone="error"))

    return {
        "status": status,
        "raw_checks": checks,
        "checks": checks,
        "diagnostics": "\n".join(diagnostics_parts) if diagnostics_parts else "All checks passed.",
        "failure_classification": failure_classification,
        "verification_stage": verification_stage,
        "verification_mode": verification_mode,
        "verification_targets": verification_targets,
        "judgment": str(judgment.get("judgment") or "blocking"),
        "is_blocking": bool(judgment.get("is_blocking", status == "fail")),
        "reason": str(judgment.get("reason") or "").strip(),
        "suggested_action": str(judgment.get("suggested_action") or "repair"),
    }
