"""
editor.py — The Editor Agent.

Central safety layer for all file-write operations.
Responsibilities:
  - Validates tool-call shape and allowed operations
  - Creates sha256 snapshot of target files BEFORE any write
  - Applies the underlying file-tool atomically
  - Verifies success by checking result prefix
  - Rolls back snapshot on failure
  - Writes metadata.json per snapshot (step, timestamp, files + sha256)
  - Maintains a workspace lock file (.ai_lock) to prevent concurrent runs
"""
import hashlib
import json
import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from rich.console import Console

from nexcode.agent_runtime.workspace import (
    get_lock_path,
    get_snapshots_dir,
    relativize_agent_path,
    resolve_agent_path,
)
from nexcode.agent_runtime.tool_registry import load_all_tools, get_tool

console = Console()

# Tools that involve writing to files (must go through Editor)
WRITE_TOOLS = {
    "write_file",
    "replace_in_file",
    "patch_file",
    "create_file",
    "delete_file",
    "delete_directory",
    "make_directory",
    "move_path",
    "copy_path",
}

# Maximum age in seconds before a lock file is considered stale
LOCK_TTL_SECONDS = 300  # 5 minutes


# ---------------------------------------------------------------------------
# Lock file management
# ---------------------------------------------------------------------------

def _lock_path(workspace: Path) -> Path:
    return get_lock_path(workspace)


def acquire_lock(workspace: Path) -> bool:
    """
    Acquire the workspace lock file.
    Returns True if acquired, False if another live process holds the lock.
    Stale locks (PID dead or TTL expired) are removed first.
    """
    lock = _lock_path(workspace)
    lock.parent.mkdir(parents=True, exist_ok=True)
    if lock.exists():
        try:
            data = json.loads(lock.read_text(encoding="utf-8"))
            pid = data.get("pid", 0)
            acquired_at = data.get("acquired_at", 0)
            # Stale by TTL
            if time.time() - acquired_at > LOCK_TTL_SECONDS:
                console.print(f"[yellow]Removing stale lock (TTL exceeded).[/yellow]")
                lock.unlink(missing_ok=True)
            else:
                # Check if PID is still alive
                try:
                    os.kill(pid, 0)  # signal 0 = existence check
                    # Process alive → lock is held
                    return False
                except (OSError, ProcessLookupError):
                    console.print(f"[yellow]Removing stale lock (PID {pid} dead).[/yellow]")
                    lock.unlink(missing_ok=True)
        except Exception:
            lock.unlink(missing_ok=True)

    lock_data = {
        "pid": os.getpid(),
        "acquired_at": time.time(),
        "workspace": str(workspace),
    }
    lock.write_text(json.dumps(lock_data, indent=2), encoding="utf-8")
    return True


def release_lock(workspace: Path) -> None:
    """Release the workspace lock if it belongs to this process."""
    lock = _lock_path(workspace)
    if lock.exists():
        try:
            data = json.loads(lock.read_text(encoding="utf-8"))
            if data.get("pid") == os.getpid():
                lock.unlink(missing_ok=True)
        except Exception:
            lock.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Checksum helpers
# ---------------------------------------------------------------------------

def _sha256_file(path: Path) -> str:
    """Compute sha256 hex digest of a file. Returns empty string if not found."""
    if not path.exists():
        return ""
    if not path.is_file():
        return ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha256_str(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Snapshot helpers
# ---------------------------------------------------------------------------

def _collect_target_paths(workspace: Path, tool_call: dict) -> list[Path]:
    """
    Return a list of absolute Paths that the tool_call will modify.
    Handles both single-file and potential multi-file proposals.
    """
    args = tool_call.get("args", {})
    paths_raw = []

    # Standard single-path tools use 'path'
    p = args.get("path")
    if p:
        paths_raw.append(p)

    for key in ("src", "dest"):
        extra_path = args.get(key)
        if extra_path:
            paths_raw.append(extra_path)

    # Support an optional 'paths' list for multi-file proposals
    for extra in args.get("paths", []):
        paths_raw.append(extra)

    result = []
    for raw in paths_raw:
        try:
            result.append(resolve_agent_path(workspace, raw))
        except Exception:
            pass
    return result


def _snapshot_backup_rel(agent_path: str) -> Path:
    if str(agent_path).startswith("scratch:"):
        suffix = str(agent_path).split(":", 1)[1].lstrip("/").replace("\\", "/")
        return Path("__scratch__") / Path(suffix or "root")
    return Path(agent_path)


def _create_snapshot(workspace: Path, step_idx: int, target_paths: list[Path]) -> tuple[Path, dict]:
    """
    Copy target files into a snapshot directory.
    Returns (snapshot_dir, metadata_dict).
    """
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    snap_dir = get_snapshots_dir(workspace) / f"step-{step_idx}-{ts}"
    snap_dir.mkdir(parents=True, exist_ok=True)

    files_meta = []
    for abs_path in target_paths:
        agent_rel = relativize_agent_path(workspace, abs_path)
        backup_rel = _snapshot_backup_rel(agent_rel)

        if abs_path.exists() and abs_path.is_file():
            dest = snap_dir / backup_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(abs_path, dest)
            sha = _sha256_file(abs_path)
            files_meta.append({
                "path": agent_rel,
                "backup_path": str(backup_rel).replace("\\", "/"),
                "sha256_before": sha,
            })
            continue

        if abs_path.exists() and abs_path.is_dir():
            # Directory operations: record metadata only.
            # Avoid copying large trees (e.g., node_modules) into snapshots.
            files_meta.append({
                "path": agent_rel,
                "backup_path": str(backup_rel).replace("\\", "/"),
                "sha256_before": "",
                "is_dir": True,
            })
            continue

        # File doesn't exist yet (new write) — no backup needed
        files_meta.append({
            "path": agent_rel,
            "backup_path": str(backup_rel).replace("\\", "/"),
            "sha256_before": "",
        })

    metadata = {
        "step": step_idx,
        "timestamp": ts,
        "files": files_meta,
    }
    (snap_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return snap_dir, metadata


def _rollback_snapshot(workspace: Path, snap_dir: Path, metadata: dict) -> None:
    """Restore all backed-up files from the snapshot directory."""
    for f in metadata.get("files", []):
        if f.get("is_dir"):
            # Directory snapshots are metadata-only (see _create_snapshot).
            continue
        backed_up = snap_dir / Path(f.get("backup_path") or _snapshot_backup_rel(f["path"]))
        original = resolve_agent_path(workspace, f["path"])
        if backed_up.exists():
            original.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backed_up, original)
            console.print(f"[yellow]  Rolled back: {f['path']}[/yellow]")
        elif not f.get("sha256_before"):
            # File was new (didn't exist before) — remove it on rollback
            if original.exists() and original.is_file():
                original.unlink()
                console.print(f"[yellow]  Removed new file on rollback: {f['path']}[/yellow]")


# ---------------------------------------------------------------------------
# Canonical tool signature
# ---------------------------------------------------------------------------

def canonical_tool_signature(tool_name: str, tool_args: dict) -> str:
    """
    Build a canonical signature for duplicate-detection.
    Read ops: unique per path + all args.
    Write ops: unique per operation + path.
    """
    def norm_path(p: str) -> str:
        if not p:
            return ""
        return str(Path(p).as_posix()).lstrip("./")

    if tool_name in {"read_file", "list_files", "search_file", "read_lines"}:
        args_copy = dict(tool_args)
        if "path" in args_copy:
            args_copy["path"] = norm_path(args_copy["path"])
        return f"READ:{tool_name}:{json.dumps(args_copy, sort_keys=True, separators=(',', ':'))}"
    else:
        path = norm_path(tool_args.get("path", ""))
        other = {k: tool_args[k] for k in sorted(tool_args) if k != "path"}
        return f"WRITE:{tool_name}:{path}:{json.dumps(other, sort_keys=True, separators=(',', ':'))}"


# ---------------------------------------------------------------------------
# Tool-call validation
# ---------------------------------------------------------------------------

def _validate_tool_call(workspace: Path, tool_call: dict) -> str | None:
    """
    Validate tool_call shape. Returns None if valid, or an error string.
    """
    if not isinstance(tool_call, dict):
        return "ERROR: tool_call must be a dict"
    tool = tool_call.get("tool")
    args = tool_call.get("args")
    if not tool or not isinstance(tool, str):
        return "ERROR: missing or invalid 'tool' key"
    if args is None or not isinstance(args, dict):
        return "ERROR: missing or invalid 'args' key"
    if tool not in WRITE_TOOLS:
        return f"ERROR: tool '{tool}' is not a write tool; Editor only handles {WRITE_TOOLS}"

    candidate_paths = []
    if args.get("path"):
        candidate_paths.append(args.get("path"))
    for key in ("src", "dest"):
        if args.get(key):
            candidate_paths.append(args.get(key))
    if not candidate_paths:
        return "ERROR: one of 'args.path' or 'args.src'/'args.dest' is required"

    for raw_path in candidate_paths:
        try:
            resolve_agent_path(workspace, raw_path).resolve()
        except Exception as e:
            return f"ERROR: path validation failed: {e}"

    return None


# ---------------------------------------------------------------------------
# Main apply_tool_call entry point
# ---------------------------------------------------------------------------

def apply_tool_call(workspace: Path, tool_call: dict, step_idx: int) -> dict:
    """
    Safely apply a write tool call:
      1. Validate tool_call shape
      2. Snapshot all target files (sha256 + copy)
      3. Execute underlying file tool
      4. On success: update metadata with sha256_after and return result
      5. On failure: rollback snapshot, return error

    Returns:
      {
        "status": "success" | "error",
        "operation": str,
        "details": str,        # starts with SUCCESS: or ERROR:
        "backup": str,         # snapshot dir path (or "")
        "files_changed": list[str],
        "metadata": dict,
      }
    """
    load_all_tools()

    tool_name = tool_call.get("tool", "")
    tool_args = tool_call.get("args", {})

    # 1. Validate
    err = _validate_tool_call(workspace, tool_call)
    if err:
        return {
            "status": "error",
            "operation": tool_name,
            "details": err,
            "backup": "",
            "files_changed": [],
            "metadata": {},
        }

    # 2. Snapshot
    target_paths = _collect_target_paths(workspace, tool_call)
    snap_dir, metadata = _create_snapshot(workspace, step_idx, target_paths)

    files_changed = [str(f["path"]) for f in metadata["files"]]

    # 3. Execute underlying tool
    try:
        tool_func = get_tool(tool_name)
        result = tool_func(workspace, **tool_args)
    except Exception as e:
        _rollback_snapshot(workspace, snap_dir, metadata)
        return {
            "status": "error",
            "operation": tool_name,
            "details": f"ERROR: Tool execution raised exception: {e}",
            "backup": str(snap_dir),
            "files_changed": files_changed,
            "metadata": metadata,
        }

    # 4a. Tool returned an error
    if not isinstance(result, str) or not result.startswith("SUCCESS"):
        details = result if isinstance(result, str) else f"ERROR: Unexpected result type: {type(result)}"
        if not details.startswith("ERROR"):
            details = f"ERROR: {details}"
        # Only rollback if the file was actually modified (sha256 changed).
        # replace_in_file returning "target not found" means nothing was written.
        needs_rollback = any(
            _sha256_file(resolve_agent_path(workspace, f["path"])) != f["sha256_before"]
            for f in metadata.get("files", [])
            if f.get("sha256_before")  # skip new files (no prior sha)
        )
        if needs_rollback:
            _rollback_snapshot(workspace, snap_dir, metadata)
        return {
            "status": "error",
            "operation": tool_name,
            "details": details,
            "backup": str(snap_dir),
            "files_changed": files_changed,
            "metadata": metadata,
        }

    # 4b. Success — update metadata with sha256_after
    for f in metadata["files"]:
        abs_path = resolve_agent_path(workspace, f["path"])
        f["sha256_after"] = _sha256_file(abs_path)

    # Check context drift: if sha256_before changed since snapshot (race condition guard)
    # This compares the backed-up copy sha256 vs. what snap captured before apply.
    # For normal sequential flow this is always consistent.

    # Rewrite metadata.json with sha256_after values
    (snap_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    return {
        "status": "success",
        "operation": tool_name,
        "details": result,
        "backup": str(snap_dir),
        "files_changed": files_changed,
        "metadata": metadata,
    }
