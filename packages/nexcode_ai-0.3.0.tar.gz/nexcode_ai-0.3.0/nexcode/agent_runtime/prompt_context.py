from __future__ import annotations

from pathlib import Path

from rich.console import Console
from nexcode.agent_runtime.task_scope import build_workspace_summary, resolve_task_scope
from nexcode.agent_runtime.workspace import get_project_root, safe_path

_console = Console()

_WORKSPACE_SUMMARY_CANDIDATES = (
    "README.md",
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "go.mod",
    "Cargo.toml",
)


def _dedupe_paths(paths: list[str]) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for raw_path in paths:
        normalized = str(Path(str(raw_path)).as_posix()).lstrip("./")
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return ordered


def _existing_files(project_root: Path, *sources: list[str] | tuple[str, ...] | None) -> list[str]:
    existing: list[str] = []
    seen: set[str] = set()
    for source in sources:
        for raw_path in source or []:
            normalized = str(Path(str(raw_path)).as_posix()).lstrip("./")
            if not normalized or normalized in seen:
                continue
            try:
                target = safe_path(project_root, normalized)
            except Exception:
                continue
            if not target.exists() or not target.is_file():
                continue
            seen.add(normalized)
            existing.append(normalized)
    return existing


def _simple_tokenize(query: str) -> str:
    """Fallback: extract non-trivial words from the query string."""
    import re
    stopwords = {"the", "a", "an", "is", "it", "in", "on", "at", "to", "for", "of",
                 "and", "or", "but", "not", "can", "you", "pls", "please", "just",
                 "this", "that", "we", "i", "my", "our", "have", "was", "has"}
    tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_]*", query)
    return " ".join(t for t in tokens if len(t) > 2 and t.lower() not in stopwords)


def expand_query_with_ai(
    query: str,
    image_urls: list[str] | None = None,
    index_keys: list[str] | None = None,
) -> str:
    """Use a fast LLM call to extract high-signal semantic search terms from the
    user's prompt (and any attached images). Returns a space-separated string of
    expanded terms to use as the workspace index search query.

    Falls back to simple tokenization silently if the LLM call fails.
    """
    if not query and not image_urls:
        return ""

    # Build a short index hint so the model can suggest actual filenames/dirs
    index_hint = ""
    if index_keys:
        # Show a sample of path components to help the model suggest real names
        sample_paths = index_keys[:40]
        parts: set[str] = set()
        for p in sample_paths:
            for seg in p.replace("\\", "/").split("/"):
                seg = seg.rsplit(".", 1)[0]  # strip extension
                if len(seg) > 2:
                    parts.add(seg)
        index_hint = "Known project names/paths (sample): " + ", ".join(sorted(parts)[:30])

    system_prompt = (
        "You are a search query expander for a code workspace index. "
        "Given a user's request (and optionally a screenshot/image), extract "
        "the most useful search terms to find relevant source files. "
        "Focus on: file/directory names, function/class names, framework names, "
        "error keywords, affected features, and technical concepts. "
        "Ignore filler words. Return ONLY a JSON object: "
        "{\"terms\": [\"term1\", \"term2\", ...]}"
        " with 5-20 terms, no duplicates, all lowercase."
    )

    if index_hint:
        system_prompt += f"\n\n{index_hint}"

    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.planner import _call_gateway
        from nexcode.agent_runtime.executor import extract_json as _extract_json

        acc = load_access()
        agent_cfg = load_agent_config()

        # Prefer the fastest available model; fall back to the configured model
        fast_model = agent_cfg.get("fast_model") or agent_cfg.get("model", "")

        # Build user prompt — supports vision (images)
        user_content: str | list
        if image_urls:
            user_content = [{"type": "text", "text": f"User request: {query or '(see image)'}"}]
            for url in image_urls[:3]:  # cap at 3 images
                user_content.append({"type": "image_url", "image_url": {"url": url}})
        else:
            user_content = f"User request: {query}"

        raw, _usage = _call_gateway(
            api_key=acc["api_key"],
            endpoint=acc["endpoint"],
            model=fast_model,
            system_prompt=system_prompt,
            user_prompt=user_content,
            json_mode=True,
        )

        parsed = _extract_json(raw)
        if isinstance(parsed, dict) and "terms" in parsed:
            terms = [str(t).strip().lower() for t in parsed["terms"] if t and str(t).strip()]
            if terms:
                from nexcode.agent_runtime.presentation import ui_detail as _ui_detail
                _console.print(_ui_detail(
                    "Index query",
                    " · ".join(terms[:10]) + (f"  +{len(terms)-10} more" if len(terms) > 10 else "")
                ))
                return " ".join(terms)
    except Exception:
        pass  # always degrade gracefully — never block the main flow

    # Fallback: simple tokenization
    return _simple_tokenize(query)


def build_compact_workspace_summary(
    workspace,
    *,
    query: str = "",
    preferred_files: list[str] | None = None,
    checked_files: list[str] | None = None,
    recent_files: list[str] | None = None,
    task_scope=None,
    top_k: int = 12,
    max_chars: int = 8000,
    image_urls: list[str] | None = None,
) -> tuple[str, list[str]]:
    project_root = get_project_root(workspace)
    explicit_files = _existing_files(project_root, preferred_files, checked_files, recent_files)
    recent_existing_files = _existing_files(project_root, recent_files)

    try:
        from nexcode.agent_runtime.workspace_index import (
            build_or_update_index,
            format_index_summary,
            search_index,
        )

        index = build_or_update_index(workspace)
        recent_targets = _dedupe_paths(list(recent_files or []) + list(getattr(task_scope, "focused_files", ()) or []))
        recently_edited_paths = _dedupe_paths(list(recent_files or []))

        # AI-powered query expansion: extract semantic terms from prompt + images
        # so the workspace index search uses high-signal terms rather than raw words.
        expanded_query = expand_query_with_ai(
            query=query,
            image_urls=image_urls,
            index_keys=list(index.keys()),
        )
        search_query = expanded_query or query  # expanded terms, fall back to raw

        ranked_files = search_index(
            index,
            search_query,
            top_k=max(top_k, 15),
            recent_targets=recent_targets,
            recently_edited=recently_edited_paths,
        )
        relevant_files = _dedupe_paths(explicit_files + ranked_files)
        if not relevant_files and recent_existing_files:
            relevant_files = list(recent_existing_files)
        if not relevant_files and explicit_files:
            relevant_files = list(explicit_files)
        if not relevant_files and not recent_targets:
            relevant_files = [candidate for candidate in _WORKSPACE_SUMMARY_CANDIDATES if candidate in index][:top_k]
        if not relevant_files and not recent_targets:
            relevant_files = sorted(key for key in index if not key.startswith("_"))[:top_k]
        summary = format_index_summary(index, relevant_files[:top_k], max_chars=max_chars)
        if summary.startswith("Workspace index:"):
            summary = "Focused workspace summary:" + summary[len("Workspace index:"):]
        return summary, relevant_files[:top_k]
    except Exception:
        if task_scope is None:
            task_scope = resolve_task_scope(
                workspace,
                user_message=query,
                checked_files=checked_files,
                plan_files=preferred_files,
                changed_files=recent_files,
            )
        return build_workspace_summary(workspace, task_scope, max_chars=max_chars), explicit_files[:top_k]


def _truncate_middle(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    head_len = max_chars // 2
    tail_len = max_chars - head_len - 32
    return f"{text[:head_len]}\n...[TRUNCATED]...\n{text[-tail_len:]}"


def _summarize_list_files(text: str) -> str:
    stripped = str(text).strip()
    if not stripped or stripped.startswith("ERROR") or stripped == "No files found.":
        return stripped
    lines = [line.strip() for line in stripped.splitlines() if line.strip()]
    sample = lines[:20]
    summary_lines = [f"Listed {len(lines)} files."]
    if sample:
        summary_lines.append("Sample:")
        summary_lines.extend(f"- {line}" for line in sample)
    remaining = len(lines) - len(sample)
    if remaining > 0:
        summary_lines.append(f"... [{remaining} more files omitted] ...")
    return "\n".join(summary_lines)


def _summarize_grep(text: str) -> str:
    stripped = str(text).strip()
    if not stripped or stripped.startswith("ERROR") or stripped.startswith("No matches found"):
        return stripped
    lines = [line.rstrip() for line in stripped.splitlines() if line.strip()]
    sample = lines[:12]
    summary_lines = [f"Found {len(lines)} matches."]
    if sample:
        summary_lines.append("Sample matches:")
        summary_lines.extend(sample)
    remaining = len(lines) - len(sample)
    if remaining > 0:
        summary_lines.append(f"... [{remaining} more matches omitted] ...")
    return "\n".join(summary_lines)


def summarize_tool_observation(tool_name: str, result) -> str:
    text = str(result)
    if tool_name == "list_files":
        return _truncate_middle(_summarize_list_files(text), 2000)
    if tool_name == "grep_search":
        return _truncate_middle(_summarize_grep(text), 2500)
    if tool_name in {"read_file", "read_lines", "search_file", "multi_read"}:
        return _truncate_middle(text, 5000)
    if tool_name in {"run_command", "wait_for_output"}:
        return _truncate_middle(text, 4000)
    return _truncate_middle(text, 3000)
