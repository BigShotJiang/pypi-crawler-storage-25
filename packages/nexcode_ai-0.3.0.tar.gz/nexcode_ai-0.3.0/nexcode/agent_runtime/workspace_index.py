"""
workspace_index.py - Lightweight workspace index for fast, search-first context building.

Instead of sending the full file tree to the LLM, this module:
1. Scans all source files ONCE using static analysis (no LLM calls).
2. Persists a structured index to .agent/workspace_index.json.
3. On subsequent runs, only re-scans files whose mtime changed (incremental).
4. Provides a search() function that returns the top-K most relevant files
   for a given query using keyword + path matching.

This cuts cold-start context from ~80k tokens → ~500 tokens for typical queries.
"""
from __future__ import annotations

import ast
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from nexcode.agent_runtime.task_scope import DISCOVERY_IGNORED_DIRS, DISCOVERY_IGNORED_FILE_SUFFIXES

INDEX_FILENAME = "workspace_index.json"
INDEX_VERSION = 2

# ---------------------------------------------------------------------------
# Language-specific export/import extractors
# ---------------------------------------------------------------------------

_PYTHON_IMPORT_RE = re.compile(r"^(?:import|from)\s+([\w.]+)", re.MULTILINE)
_GO_EXPORT_RE = re.compile(r"^func\s+([A-Z][A-Za-z0-9_]*)\s*\(", re.MULTILINE)
_GO_TYPE_RE = re.compile(r"^type\s+([A-Z][A-Za-z0-9_]*)\s+", re.MULTILINE)
_JS_EXPORT_RE = re.compile(
    r"^export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|var|interface|type|enum)\s+([A-Za-z_$][A-Za-z0-9_$]*)",
    re.MULTILINE,
)
_GENERIC_FUNC_RE = re.compile(
    r"^(?:def|func|function|sub|procedure)\s+([A-Za-z_][A-Za-z0-9_]*)\s*[\(:]",
    re.MULTILINE | re.IGNORECASE,
)


def _extract_python_meta(source: str) -> dict[str, Any]:
    exports: list[str] = []
    imports: list[str] = []
    summary = ""
    try:
        tree = ast.parse(source)
        # Top-level docstring as summary
        if (
            tree.body
            and isinstance(tree.body[0], ast.Expr)
            and isinstance(tree.body[0].value, ast.Constant)
            and isinstance(tree.body[0].value.value, str)
        ):
            summary = tree.body[0].value.value.strip().splitlines()[0][:120]
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if getattr(node, "col_offset", 99) == 0:  # top-level only
                    exports.append(node.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.append(node.module.split(".")[0])
    except SyntaxError:
        # Fallback: regex
        exports = _GENERIC_FUNC_RE.findall(source)
        imports = _PYTHON_IMPORT_RE.findall(source)
    return {"exports": exports[:20], "imports": list(dict.fromkeys(imports))[:15], "summary": summary}


def _extract_go_meta(source: str) -> dict[str, Any]:
    exports = _GO_EXPORT_RE.findall(source) + _GO_TYPE_RE.findall(source)
    # Package name as summary
    pkg_match = re.search(r"^package\s+(\w+)", source, re.MULTILINE)
    summary = f"Go package: {pkg_match.group(1)}" if pkg_match else ""
    # imports from import block
    imports = re.findall(r'"([^"]+)"', source[:2000])
    imports = [p.split("/")[-1] for p in imports]
    return {"exports": exports[:20], "imports": imports[:15], "summary": summary}


def _extract_js_ts_meta(source: str) -> dict[str, Any]:
    exports = _JS_EXPORT_RE.findall(source)
    if not exports:
        exports = _GENERIC_FUNC_RE.findall(source)
    imports = re.findall(r"""(?:import|require)\s*[\({]?\s*['"]([^'"]+)['"]""", source[:3000])
    imports = [p.split("/")[-1].replace("'", "").replace('"', "") for p in imports]
    # First JSDoc or comment as summary
    jsdoc = re.search(r"/\*\*\s*(.*?)\s*\*/", source[:500], re.DOTALL)
    summary = jsdoc.group(1).strip()[:120].replace("\n", " ").replace("*", "").strip() if jsdoc else ""
    return {"exports": exports[:20], "imports": list(dict.fromkeys(imports))[:15], "summary": summary}


def _extract_generic_meta(source: str) -> dict[str, Any]:
    exports = _GENERIC_FUNC_RE.findall(source)
    # First comment line as summary
    comment = re.search(r"^(?:#|//|--)\s*(.+)", source[:500], re.MULTILINE)
    summary = comment.group(1).strip()[:120] if comment else ""
    return {"exports": exports[:20], "imports": [], "summary": summary}


def _extract_file_meta(path: Path) -> dict[str, Any]:
    """Extract exports, imports, and summary from a source file without any LLM."""
    suffix = path.suffix.lower()
    try:
        raw = path.read_bytes()
        # Decode with fallbacks
        for enc in ("utf-8-sig", "utf-8", "utf-16", "latin-1"):
            try:
                source = raw.decode(enc)
                break
            except Exception:
                continue
        else:
            source = raw.decode("latin-1", errors="replace")

        if suffix == ".py":
            meta = _extract_python_meta(source)
        elif suffix == ".go":
            meta = _extract_go_meta(source)
        elif suffix in {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}:
            meta = _extract_js_ts_meta(source)
        else:
            meta = _extract_generic_meta(source)

        meta["size"] = len(raw)
        meta["lines"] = source.count("\n") + 1
        return meta

    except Exception:
        return {"exports": [], "imports": [], "summary": "", "size": 0, "lines": 0}


# ---------------------------------------------------------------------------
# Index persistence
# ---------------------------------------------------------------------------

def _index_path(workspace: Path) -> Path:
    from nexcode.agent_runtime.workspace import get_agent_dir
    return get_agent_dir(workspace) / INDEX_FILENAME


def _load_index(workspace: Path) -> dict[str, Any]:
    p = _index_path(workspace)
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data.get("_version") == INDEX_VERSION:
            return data
    except Exception:
        pass
    return {}


def _save_index(workspace: Path, index: dict[str, Any]) -> None:
    p = _index_path(workspace)
    p.parent.mkdir(parents=True, exist_ok=True)
    index["_version"] = INDEX_VERSION
    index["_built_at"] = time.time()
    p.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# File walking (reuses DISCOVERY_IGNORED_DIRS from task_scope)
# ---------------------------------------------------------------------------

_INDEXABLE_SUFFIXES = {
    ".py", ".go", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    ".java", ".kt", ".rb", ".rs", ".cs", ".cpp", ".c", ".h",
    ".swift", ".php", ".lua", ".sh", ".bash",
    ".json", ".yaml", ".yml", ".toml", ".md", ".txt", ".env.example",
}

_MAX_FILE_SIZE = 500_000  # 500 KB — skip huge files


def _should_index(path: Path) -> bool:
    suffix = path.suffix.lower()
    if suffix in DISCOVERY_IGNORED_FILE_SUFFIXES:
        return False
    if path.name.lower().startswith(".env") and suffix not in {".example", ".sample"}:
        return False
    if suffix not in _INDEXABLE_SUFFIXES and suffix != "":
        return False
    try:
        if path.stat().st_size > _MAX_FILE_SIZE:
            return False
    except OSError:
        return False
    return True


def _walk_indexable_files(root: Path) -> list[tuple[str, float]]:
    """Yield (rel_path, mtime) for all indexable files, skipping ignored dirs."""
    ignored = {d.lower() for d in DISCOVERY_IGNORED_DIRS}
    results: list[tuple[str, float]] = []

    for current_dir, dirs, filenames in os.walk(root):
        # Prune ignored directories in-place
        dirs[:] = [
            d for d in dirs
            if d.lower() not in ignored and not d.startswith(".")
        ]
        for fname in filenames:
            fpath = Path(current_dir) / fname
            if not _should_index(fpath):
                continue
            try:
                mtime = fpath.stat().st_mtime
                rel = str(fpath.relative_to(root)).replace("\\", "/")
                results.append((rel, mtime))
            except (OSError, ValueError):
                continue

    return results


# ---------------------------------------------------------------------------
# Build / update index
# ---------------------------------------------------------------------------

def build_or_update_index(workspace: Path, *, force: bool = False) -> dict[str, Any]:
    """
    Build the workspace index on first run, or update only changed files.
    This is the main entry point — called before the LLM context is assembled.

    Returns the full index dict.
    """
    from nexcode.agent_runtime.workspace import get_project_root

    project_root = get_project_root(workspace)
    index = {} if force else _load_index(workspace)

    current_files = _walk_indexable_files(project_root)
    current_map = {rel: mtime for rel, mtime in current_files}

    changed = 0
    # Remove stale entries (deleted files)
    stale = [k for k in list(index.keys()) if not k.startswith("_") and k not in current_map]
    for k in stale:
        del index[k]

    # Add or update changed files
    for rel_path, mtime in current_files:
        existing = index.get(rel_path, {})
        if not force and isinstance(existing, dict) and existing.get("mtime") == mtime:
            continue  # Not changed — skip
        abs_path = project_root / rel_path
        meta = _extract_file_meta(abs_path)
        meta["mtime"] = mtime
        index[rel_path] = meta
        changed += 1

    if changed > 0 or stale:
        _save_index(workspace, index)

    return index


def update_index_for_files(
    workspace: Path,
    changed_paths: list[str] | set[str],
) -> None:
    """
    Incrementally re-index only the specified files.

    Called by the executor after successful file writes so that later steps
    see fresh metadata for files the agent just created or modified.
    This is lightweight (~5-20ms per file) since it only re-parses the
    specified files instead of rescanning the entire workspace.
    """
    if not changed_paths:
        return

    from nexcode.agent_runtime.workspace import get_project_root

    project_root = get_project_root(workspace)
    index = _load_index(workspace)
    if not index:
        # No existing index — nothing to incrementally update.
        # A full build will happen on the next build_or_update_index() call.
        return

    updated = 0
    for raw_path in changed_paths:
        rel_path = str(raw_path).replace("\\", "/").lstrip("./")
        if not rel_path or rel_path.startswith("scratch:"):
            continue

        abs_path = project_root / rel_path
        if not abs_path.exists() or not abs_path.is_file():
            # File was deleted — remove from index
            if rel_path in index:
                del index[rel_path]
                updated += 1
            continue

        if not _should_index(abs_path):
            continue

        try:
            mtime = abs_path.stat().st_mtime
        except OSError:
            continue

        meta = _extract_file_meta(abs_path)
        meta["mtime"] = mtime
        index[rel_path] = meta
        updated += 1

    if updated > 0:
        _save_index(workspace, index)


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search_index(
    index: dict[str, Any],
    query: str,
    *,
    top_k: int = 15,
    recent_targets: list[str] | None = None,
    recently_edited: list[str] | None = None,
) -> list[str]:
    """
    Return up to top_k file paths most relevant to the query.

    Scoring breakdown:
      - Path/directory match:  2.0 pts per token
      - Filename match:        1.5 pts per token
      - Export symbol match:   1.0 pts per token
      - Import match:          0.5 pts per token
      - Summary match:         0.75 pts per token
      - Recently edited bonus: 5.0 pts (files the agent wrote this session)
      - Recent targets bonus:  3.0 pts (files in the current task scope)
      - Depth penalty:         -0.3 pts per directory level beyond 3
    """
    if not query or not index:
        return []

    tokens = set(re.findall(r"[a-z][a-z0-9_]{2,}", query.lower()))
    recent_set = {str(r).replace("\\", "/").lower() for r in (recent_targets or [])}
    edited_set = {str(r).replace("\\", "/").lower().lstrip("./") for r in (recently_edited or [])}

    scored: list[tuple[float, str]] = []
    for rel_path, meta in index.items():
        if rel_path.startswith("_"):
            continue
        if not isinstance(meta, dict):
            continue

        score = 0.0
        lpath = rel_path.lower()
        lname = Path(rel_path).name.lower().replace("_", "").replace("-", "")
        depth = len(Path(rel_path).parts)

        for tok in tokens:
            if tok in lpath:
                score += 2.0
            if tok in lname:
                score += 1.5
            for exp in meta.get("exports", []):
                if tok in exp.lower():
                    score += 1.0
                    break
            for imp in meta.get("imports", []):
                if tok in imp.lower():
                    score += 0.5
                    break
            summary = meta.get("summary", "").lower()
            if tok in summary:
                score += 0.75

        # Boost files the agent just edited (strongest signal)
        if lpath in edited_set:
            score += 5.0

        # Boost files from the current task scope
        if lpath in recent_set:
            score += 3.0

        # Mild depth penalty — prefer shallower files when scores are close
        if depth > 3:
            score -= (depth - 3) * 0.3

        if score > 0:
            scored.append((score, rel_path))

    scored.sort(key=lambda x: -x[0])
    return [path for _, path in scored[:top_k]]


# ---------------------------------------------------------------------------
# Format index as a compact workspace summary for the LLM
# ---------------------------------------------------------------------------

def format_index_summary(
    index: dict[str, Any],
    relevant_files: list[str] | None = None,
    *,
    max_chars: int = 8000,
) -> str:
    """
    Render the index as a concise workspace summary for injection into the LLM prompt.
    If relevant_files is provided, only those files are shown.
    Shows richer metadata (lines, imports) so the LLM can better judge file importance.
    """
    files_to_show = relevant_files or [k for k in index if not k.startswith("_")]

    lines = ["Workspace index:"]
    for rel_path in files_to_show:
        meta = index.get(rel_path)
        if not isinstance(meta, dict):
            continue
        summary = meta.get("summary", "")
        exports = meta.get("exports", [])
        line_count = meta.get("lines", 0)
        imports = meta.get("imports", [])

        parts = [f"- {rel_path}"]
        # Show line count for size awareness
        if line_count:
            parts.append(f"({line_count}L)")
        # Show exports (top symbols)
        if exports:
            parts.append(f"[{', '.join(exports[:6])}]")
        # Show import count for connectivity awareness
        if imports:
            parts.append(f"imports:{len(imports)}")
        # Show summary
        if summary:
            parts.append(f"— {summary}")
        lines.append(" ".join(parts))

    result = "\n".join(lines)
    return result[:max_chars]
