from dataclasses import dataclass, asdict

# Pricing per million tokens: {model: (input_$/M, output_$/M)}
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # ── xAI Grok ─────────────────────────────────────────────────────────────
    "grok-4.20-multi-agent-beta-0309":   (2.00, 6.00),
    "grok-4.20-beta-0309-reasoning":     (2.00, 6.00),
    "grok-4.20-beta-0309-non-reasoning": (2.00, 6.00),
    "grok-code-fast-1":                  (0.20, 1.50),
    "grok-4-1-fast-reasoning":           (0.20, 0.50),
    "grok-4-1-fast-non-reasoning":       (0.20, 0.50),
    # ── Google Gemini 3.x ────────────────────────────────────────────────────
    # gemini-3.1-pro-preview: $2/$12 (<=200k tokens), $4/$18 (>200k tokens)
    # Using standard tier as the cost estimate baseline
    "gemini-3.1-pro-preview":            (2.00, 12.00),
    "gemini-3.1-flash-lite-preview":     (0.25, 1.50),
    "gemini-3.1-flash-image-preview":    (0.25, 0.067),
    "gemini-3-flash-preview":            (0.50, 3.00),
    "gemini-3-pro-image-preview":        (2.00, 0.134),
    # ── Google Gemini 2.x / 1.x (legacy) ─────────────────────────────────────
    "gemini-2.5-pro-preview-06-05":      (1.25, 10.00),
    "gemini-2.0-flash":                  (0.10, 0.40),
    "gemini-1.5-pro":                    (1.25, 5.00),
    "gemini-1.5-flash":                  (0.075, 0.30),
}

def _calc_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    price = MODEL_PRICING.get(model, (0.20, 0.50))
    return (input_tokens * price[0] + output_tokens * price[1]) / 1_000_000


@dataclass
class UsageData:
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    reasoning_tokens: int = 0
    cumulative_cost: float = 0.0

    def add(self, other: 'UsageData', model: str = None):
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.total_tokens += other.total_tokens
        self.reasoning_tokens += other.reasoning_tokens
        if model:
            self.cumulative_cost += _calc_cost(model, other.input_tokens, other.output_tokens)
        else:
            self.cumulative_cost += other.cumulative_cost

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict):
        if not data:
            return cls()
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})

def estimate_tokens(text: str) -> int:
    try:
        import tiktoken
        enc = tiktoken.get_encoding("o200k_base")
        return len(enc.encode(text))
    except ImportError:
        # Fallback approximation (roughly 4 chars per token)
        return len(text) // 4
