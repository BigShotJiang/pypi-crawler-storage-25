"""
repair.py — The Repair Agent.

Activated when the Verifier fails or the Coder gets stuck.
Strategy:
  Attempt 1: Surgical fix via FIX_PLANNING_PROMPT (1-4 steps, then Coder+Editor)
  Attempt 2: Full-file rewrite of failing file(s)
  Attempt 3: Human-in-loop escalation (write HLU report and pause)

Returns a RepairResult dict indicating whether to proceed or stop.
"""
import json
from pathlib import Path
from rich.console import Console

from nexcode.config import load_access, load_agent_config
from nexcode.agent_runtime.prompt_context import build_compact_workspace_summary
from nexcode.agent_runtime.presentation import ui_status
from nexcode.agent_runtime.workspace import get_logs_dir, save_agent_state

console = Console()


def _write_hlu_report(workspace: Path, step_idx: int, coder_history: list, diagnostics: str = "") -> Path:
    """
    Write a human-readable incident report to .agent/.ai_logs/hlu_report.md.
    Called when automatic repair is exhausted.
    """
    logs_dir = get_logs_dir(workspace)
    logs_dir.mkdir(parents=True, exist_ok=True)
    report_path = logs_dir / "hlu_report.md"

    last_errors = "\n".join(
        str(h)[:300] for h in coder_history[-10:]
    )

    report = f"""# 🚨 Human-in-Loop (HLU) Report

**Step:** {step_idx}

**Automated repair exhausted.** The agent could not resolve this step automatically.

## Recent Coder History (last 10 entries)

```
{last_errors}
```

## Verifier Diagnostics

```
{diagnostics or "No diagnostics available."}
```

## Suggested Actions

1. Inspect `.agent/.snapshots/` for automatic backups of changed files.
2. Run tests locally: `pytest` or `npm run build` to see the current error.
3. Apply a manual patch to the failing file(s), then run `nexcode resume` to continue.
4. If the problem is systemic (wrong plan step), run `nexcode agent assistant <project> "<description>"`.

---
*Report generated automatically by the Repair Agent.*
"""
    report_path.write_text(report, encoding="utf-8")
    return report_path


def run_repair(
    workspace: Path,
    step: dict,
    diagnostics: str,
    coder_history: list,
    attempt: int,
    state: dict,
) -> dict:
    """
    Run the repair strategy for the given attempt number.

    Examples:
      nexcode agent build "REST API for todo app"
      nexcode agent list  (future templates)

    Args:
        workspace: Workspace root path
        step: The current plan step dict
        diagnostics: Failure output from Verifier or Coder
        coder_history: Coder message history for context
        attempt: Current repair attempt (1, 2, or 3)
        state: Agent state dict (will be mutated + saved on HLU)

    Returns:
        {
          "action": "retry" | "rewrite" | "escalate",
          "fix_plan": [...],       # populated for action="retry"
          "message": str,          # human-readable summary
        }
    """
    from nexcode.agent_runtime.planner import _build_fix_planning_prompt, _call_gateway, repair_json_plan
    acc = load_access()
    agent_cfg = load_agent_config(workspace)

    task_desc = step.get("task", "Unknown step")
    step_idx = step.get("step", 0)
    attempt_usage = {}

    if attempt == 1:
        # Attempt 1: Generate a surgical fix plan
        console.print(ui_status("Repair", "Attempt 1: generating a surgical fix plan", tone="warning"))
        fix_history = coder_history[-5:]  # last 5 entries for context

        workspace_summary, _ = build_compact_workspace_summary(
            workspace,
            query=f"{task_desc}\n{diagnostics[:1000]}",
            checked_files=list(state.get("investigation_checked_files", []) or []),
            top_k=15,
            max_chars=10000,
        )
        user_p = _build_fix_planning_prompt(
            prompt=f"Fix step: {task_desc}\n\nDiagnostics:\n{diagnostics[:1000]}",
            orig_prompt=state.get("original_prompt", ""),
            fix_history=fix_history,
            last_walkthrough=state.get("last_fix_walkthrough", "No previous walkthrough available."),
            files=workspace_summary,
            fix_metadata={
                "complexity": state.get("investigation_complexity", "simple"),
                "confidence": state.get("investigation_confidence", "medium"),
                "checked_files": state.get("investigation_checked_files", []),
            },
        )

        try:
            response, usage = _call_gateway(
                acc["api_key"], acc["endpoint"], agent_cfg["model"],
                "You are a repair planning AI.", user_p
            )
            fix_plan = repair_json_plan(response) or []
            attempt_usage = usage.to_dict() if usage else {}
        except Exception as e:
            console.print(ui_status("Repair", f"Plan generation failed: {e}", tone="error"))
            fix_plan = []
            usage = None

        if fix_plan:
            return {
                "action": "retry",
                "fix_plan": fix_plan,
                "message": f"Repair attempt 1: surgical fix plan with {len(fix_plan)} step(s).",
                "usage": attempt_usage,
            }
        else:
            # Fall through to attempt 2 if plan gen failed
            console.print(ui_status("Repair", "Attempt 1 produced no fix plan; escalating to rewrite mode", tone="warning"))
            attempt = 2

    if attempt == 2:
        # Attempt 2: Ask Coder to do a full-file rewrite
        console.print(ui_status("Repair", "Attempt 2: requesting a full-file rewrite", tone="warning"))
        coder_history.append(
            "REPAIR AGENT (Attempt 2): Surgical fix failed or wasn't possible. "
            "You MUST rewrite the entire failing file using 'write_file' with "
            "complete, correct code. No placeholders. Return a single JSON tool call."
        )
        return {
            "action": "rewrite",
            "fix_plan": [],
            "message": "Repair attempt 2: full-file rewrite mode activated.",
            "usage": attempt_usage,
        }

    # Attempt 3: Human-in-loop escalation
    console.print(ui_status("Repair", "Attempt 3: escalating to human review", tone="error"))
    report_path = _write_hlu_report(workspace, step_idx, coder_history, diagnostics)

    state["status"] = "waiting_human"
    state["hlu_report"] = str(report_path)
    save_agent_state(workspace, state)

    console.print("")
    console.print(ui_status("Repair", "Automated repair exhausted", tone="warning"))
    console.print(ui_status("Report", f"Wrote incident report to {report_path}", tone="warning"))
    console.print(ui_status("Next step", "Review the report, apply a manual fix, then run: nexcode resume", tone="warning"))

    return {
        "action": "escalate",
        "fix_plan": [],
        "message": f"Human intervention required. See {report_path}",
        "usage": {},
    }
