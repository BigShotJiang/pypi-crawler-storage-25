"""Allow `python -m nexcode` execution."""

from nexcode.cli import main

if __name__ == "__main__":
    main()
