"""
cli.py - Main entry point and command dispatcher for nexcode.

Usage:
    nexcode                                  -> help / provider status
    nexcode help                             -> help
    nexcode version                          -> version
    nexcode login [grok|gemini]              -> configure API key for a provider
    nexcode switch <grok|gemini>             -> instantly switch active provider
    nexcode config show                      -> show current config
    nexcode config model <name>              -> change model for active provider
    nexcode agent [cmd] [--verbose]          -> run the workspace agent
"""

import sys
from pathlib import Path

from nexcode.config import init_home


def main() -> None:
    """Entry point registered in pyproject.toml."""
    init_home()

    args = sys.argv[1:]

    piped_content = ""
    if not sys.stdin.isatty():
        try:
            piped_content = sys.stdin.read().strip()
        except Exception as exc:
            print(f"[WARNING] Could not read piped input: {exc}")

    if not args and not piped_content:
        from nexcode.utils import print_help

        print_help()
        return

    if args and args[0] in ("help", "--help", "-h"):
        from nexcode.utils import print_help

        print_help()
        return

    if args and args[0] in ("version", "--version", "-v"):
        from nexcode.utils import print_version

        print_version()
        return

    if args and args[0] == "login":
        from nexcode.auth import login, login_status

        if len(args) >= 2:
            login(args[1].lower())
        else:
            login_status()
        return

    if args and args[0] == "login-gemini":
        from nexcode.auth import login

        login("gemini")
        return

    if args and args[0] == "switch":
        _handle_switch(args[1:])
        return

    if args and args[0] == "config":
        _handle_config(args[1:])
        return

    if args and args[0] == "agent":
        from nexcode.agent import handle_agent_cli

        try:
            from nexcode.agent_runtime.workspace_index import build_or_update_index

            build_or_update_index(Path.cwd())
        except Exception:
            pass

        verbose = False
        if "--verbose" in args:
            verbose = True
            args.remove("--verbose")

        image_urls = []
        while "--image" in args:
            idx = args.index("--image")
            if idx + 1 < len(args):
                img_path = args[idx + 1]
                args.pop(idx)
                args.pop(idx)
                resolved = _resolve_image(img_path)
                if resolved:
                    image_urls.append(resolved)
            else:
                args.pop(idx)

        handle_agent_cli(
            args[1:],
            piped_content=piped_content,
            verbose=verbose,
            image_urls=image_urls,
        )
        return

    _print_direct_message_removed(has_piped_content=bool(piped_content))
    sys.exit(1)


def _handle_switch(args: list) -> None:
    """Handle: nexcode switch <provider>"""
    from rich.console import Console
    from nexcode.config import (
        PROVIDER_DEFAULTS,
        is_provider_configured,
        load_full_access,
        switch_provider,
    )

    console = Console()

    if not args:
        console.print("[yellow]Usage: nexcode switch <grok|gemini>[/yellow]")
        return

    provider = args[0].lower()
    valid = list(PROVIDER_DEFAULTS.keys())
    if provider not in valid:
        console.print(f"[red]Unknown provider '{provider}'. Choose from: {', '.join(valid)}[/red]")
        return

    if not is_provider_configured(provider):
        console.print(
            f"[yellow]'{provider}' is not configured yet.[/yellow] "
            f"Run [bold]nexcode login {provider}[/bold] first."
        )
        return

    switch_provider(provider)
    full = load_full_access()
    model = full.get(provider, {}).get("model", "")
    console.print()
    console.print(f"[bold green]✓ Switched to {provider.upper()}[/bold green]  model=[cyan]{model}[/cyan]")
    console.print("[dim]agent.yaml updated automatically.[/dim]")
    console.print()


def _handle_config(args: list) -> None:
    """Handle: nexcode config show | nexcode config model <name>"""
    from rich import box as rbox
    from rich.console import Console
    from rich.table import Table

    from nexcode.agent_runtime.workspace import get_local_agent_config_file
    from nexcode.config import (
        AGENT_CONFIG_FILE,
        PROVIDER_DEFAULTS,
        load_access,
        load_agent_config,
        load_full_access,
        set_provider_model,
    )

    console = Console()

    if not args or args[0] == "show":
        full = load_full_access()
        acc = load_access()
        cwd = Path.cwd()
        local_agent_cfg = get_local_agent_config_file(cwd)
        agent_cfg = load_agent_config(cwd)
        active = full.get("active", "grok")

        console.print()
        console.print(
            f"[bold white]Active Provider:[/bold white] "
            f"[bold cyan]{active.upper()}[/bold cyan]  model=[cyan]{acc['model']}[/cyan]"
        )
        console.print()

        p_table = Table(box=rbox.ROUNDED, border_style="dim", header_style="bold white")
        p_table.add_column("Provider")
        p_table.add_column("API Key")
        p_table.add_column("Model")
        p_table.add_column("Endpoint")

        for provider, meta_defaults in PROVIDER_DEFAULTS.items():
            pdata = full.get(provider, {})
            key = pdata.get("api_key", "")
            key_display = f"...{key[-6:]}" if len(key) > 8 else ("set" if key else "[red]not set[/red]")
            model = pdata.get("model", meta_defaults["model"])
            endpoint = pdata.get("endpoint", meta_defaults["endpoint"])
            marker = "● active" if provider == active else ""
            p_table.add_row(
                f"[bold]{provider}[/bold]  {marker}",
                f"[green]{key_display}[/green]" if key else "[red]not set[/red]",
                model,
                endpoint,
            )
        console.print(p_table)
        console.print()

        a_table = Table(
            box=rbox.ROUNDED,
            border_style="dim",
            header_style="bold white",
            title="[bold]Agent Config[/bold]  (agent.yaml)",
        )
        a_table.add_column("Setting")
        a_table.add_column("Value")
        for key, value in agent_cfg.items():
            a_table.add_row(key, str(value))
        console.print(a_table)
        console.print(f"  [dim]Global config: {AGENT_CONFIG_FILE}[/dim]")
        if local_agent_cfg.exists():
            console.print(f"  [dim]Local override: {local_agent_cfg}[/dim]")
        else:
            console.print(f"  [dim]Local override: {local_agent_cfg} (not present)[/dim]")
        console.print()
        console.print("[dim]Change model: [bold]nexcode config model <model-name>[/bold][/dim]")
        console.print("[dim]Switch provider: [bold]nexcode switch grok|gemini[/bold][/dim]")
        console.print()
        return

    if args[0] == "model":
        if len(args) < 2:
            console.print("[yellow]Usage: nexcode config model <model-name>[/yellow]")
            return
        model_name = args[1].strip()
        acc = load_access()
        provider = acc["provider"]
        set_provider_model(provider, model_name)
        console.print()
        console.print("[bold green]✓ Model updated[/bold green]")
        console.print(f"  Provider: [cyan]{provider}[/cyan]")
        console.print(f"  Model:    [cyan]{model_name}[/cyan]")
        console.print("  [dim]agent.yaml updated automatically.[/dim]")
        console.print()
        return

    console.print(
        f"[yellow]Unknown config command '{args[0]}'. "
        "Try: nexcode config show | nexcode config model <name>[/yellow]"
    )


def _resolve_image(img_path: str) -> str | None:
    """Resolve an image path or URL to a usable image_url string."""
    import base64
    import mimetypes
    import os

    if img_path.startswith("http://") or img_path.startswith("https://"):
        return img_path
    if os.path.exists(img_path):
        mime_type, _ = mimetypes.guess_type(img_path)
        mime_type = mime_type or "image/jpeg"
        with open(img_path, "rb") as file_handle:
            encoded = base64.b64encode(file_handle.read()).decode("utf-8")
        return f"data:{mime_type};base64,{encoded}"
    print(f"[ERROR] Image file not found: {img_path}")
    return None


def _print_direct_message_removed(has_piped_content: bool = False) -> None:
    """Tell users to use the agent namespace for prompts."""
    from rich.console import Console

    console = Console()
    console.print(
        "[red]Error:[/red] Direct messaging has been removed. "
        "Use [cyan]nexcode agent [message][/cyan] instead."
    )
    if has_piped_content:
        console.print('[dim]Example: git diff | nexcode agent "review these changes"[/dim]')
    else:
        console.print('[dim]Example: nexcode agent "hi"[/dim]')


if __name__ == "__main__":
    main()
