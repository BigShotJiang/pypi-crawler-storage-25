"""
tests/test_agent_core.py — Unit tests for the core agent components.

Tests:
  - parse_tool_call_from_text (tolerant parser)
  - canonical_tool_signature (duplicate detection)
  - Editor apply_tool_call (snapshot, rollback, lock)
  - file_tools ERROR: prefix consistency
  - replace_in_file exact matching
"""
import json
import pytest
from pathlib import Path

# ---------------------------------------------------------------------------
# Parser tests
# ---------------------------------------------------------------------------

from nexcode.agent_runtime.executor import (
    parse_tool_call_from_text,
    extract_json,
    canonical_tool_signature,
    _extract_verifier_blocking_paths,
)


class TestParseToolCallFromText:
    """Fuzz the tolerant parser with many LLM-like output patterns."""

    def _valid(self, result, tool=None, arg_key=None):
        assert isinstance(result, dict), f"Expected dict, got {type(result)}: {result}"
        assert "tool" in result, f"Missing 'tool' key: {result}"
        assert "args" in result, f"Missing 'args' key: {result}"
        if tool:
            assert result["tool"] == tool, f"Expected tool={tool}, got {result['tool']}"
        if arg_key:
            assert arg_key in result["args"], f"Expected arg '{arg_key}' in {result['args']}"

    def test_plain_json(self):
        s = '{"tool":"read_file","args":{"path":"src/App.jsx"}}'
        self._valid(parse_tool_call_from_text(s), tool="read_file", arg_key="path")

    def test_json_wrapped_in_text(self):
        s = 'Sure, here is the call: {"tool":"write_file","args":{"path":"app.py","content":"x"}} done.'
        self._valid(parse_tool_call_from_text(s), tool="write_file")

    def test_markdown_json_fence(self):
        s = '```json\n{"tool":"patch_file","args":{"path":"x.py","start_line":1,"end_line":5,"new_content":"y"}}\n```'
        self._valid(parse_tool_call_from_text(s), tool="patch_file")

    def test_markdown_plain_fence(self):
        s = '```\n{"tool":"list_files","args":{"path":"."}}\n```'
        self._valid(parse_tool_call_from_text(s), tool="list_files")

    def test_extra_text_before_and_after(self):
        s = "I will now read the file:\n\n{\"tool\":\"read_file\",\"args\":{\"path\":\"index.js\"}}\n\nThat's the call."
        self._valid(parse_tool_call_from_text(s), tool="read_file")

    def test_tool_equals_notation(self):
        s = "tool=read_file args={\"path\": \"app.py\"}"
        result = parse_tool_call_from_text(s)
        # Regex fallback — tool at minimum must be found
        assert result is not None
        assert result.get("tool") == "read_file"

    def test_invalid_no_tool_key(self):
        s = '{"action":"read","path":"app.py"}'
        result = parse_tool_call_from_text(s)
        assert result is None

    def test_empty_string(self):
        result = parse_tool_call_from_text("")
        assert result is None

    def test_nested_args_json(self):
        s = '{"tool":"replace_in_file","args":{"path":"config.py","target_text":"old","replacement_text":"new"}}'
        self._valid(parse_tool_call_from_text(s), tool="replace_in_file")


# ---------------------------------------------------------------------------
# Canonical signature tests
# ---------------------------------------------------------------------------

class TestCanonicalToolSignature:

    def test_different_read_files_have_different_signatures(self):
        sig1 = canonical_tool_signature("read_file", {"path": "src/App.jsx"})
        sig2 = canonical_tool_signature("read_file", {"path": "src/index.js"})
        assert sig1 != sig2, "Different file reads should produce different signatures"

    def test_same_read_file_same_signature(self):
        sig1 = canonical_tool_signature("read_file", {"path": "src/App.jsx"})
        sig2 = canonical_tool_signature("read_file", {"path": "src/App.jsx"})
        assert sig1 == sig2

    def test_read_sig_has_READ_prefix(self):
        sig = canonical_tool_signature("read_file", {"path": "x.py"})
        assert sig.startswith("READ:")

    def test_write_sig_has_WRITE_prefix(self):
        sig = canonical_tool_signature("write_file", {"path": "x.py", "content": "hello"})
        assert sig.startswith("WRITE:")

    def test_different_write_paths_different_sigs(self):
        sig1 = canonical_tool_signature("write_file", {"path": "a.py", "content": "x"})
        sig2 = canonical_tool_signature("write_file", {"path": "b.py", "content": "x"})
        assert sig1 != sig2

    def test_path_normalization(self):
        # Both paths should normalize to the same canonical form
        sig1 = canonical_tool_signature("read_file", {"path": "./src/App.jsx"})
        sig2 = canonical_tool_signature("read_file", {"path": "src/App.jsx"})
        assert sig1 == sig2, "Path normalization should strip leading ./"

    def test_args_order_independent(self):
        # Same args, different insertion order → same canonical sig
        sig1 = canonical_tool_signature("read_lines", {"path": "x.py", "start_line": 1, "end_line": 5})
        sig2 = canonical_tool_signature("read_lines", {"end_line": 5, "start_line": 1, "path": "x.py"})
        assert sig1 == sig2, "Arg order should not affect signature"


def test_extract_verifier_blocking_paths_finds_relative_tokens(tmp_path):
    feedback = "Automated Verifier failed:\nDUMMY\nsrc/components/sections/Hero.tsx\n  31:18  error  react/no-unescaped-entities\n"
    paths = _extract_verifier_blocking_paths(tmp_path, feedback)
    assert "src/components/sections/Hero.tsx" in paths


# ---------------------------------------------------------------------------
# Editor tests (requires tmp workspace)
# ---------------------------------------------------------------------------

from nexcode.agent_runtime.editor import apply_tool_call, acquire_lock, release_lock
from nexcode.agent_runtime.workspace import save_agent_state


class TestEditorApplyToolCall:

    @pytest.fixture
    def workspace(self, tmp_path):
        """Minimal workspace with tool registry loaded."""
        from nexcode.agent_runtime.tool_registry import load_all_tools
        load_all_tools()
        return tmp_path

    def test_write_file_success(self, workspace):
        result = apply_tool_call(
            workspace,
            {"tool": "write_file", "args": {"path": "hello.txt", "content": "Hello world"}},
            step_idx=1,
        )
        assert result["status"] == "success", f"Expected success: {result}"
        assert (workspace / "hello.txt").read_text() == "Hello world"

    def test_write_file_creates_snapshot(self, workspace):
        (workspace / "existing.txt").write_text("original content")
        result = apply_tool_call(
            workspace,
            {"tool": "write_file", "args": {"path": "existing.txt", "content": "updated"}},
            step_idx=2,
        )
        assert result["status"] == "success"
        backup_dir = Path(result["backup"])
        assert backup_dir.exists(), "Snapshot directory must be created"
        assert (backup_dir / "metadata.json").exists(), "metadata.json must exist in snapshot"
        meta = json.loads((backup_dir / "metadata.json").read_text())
        assert meta["step"] == 2
        assert len(meta["files"]) == 1
        assert "sha256_before" in meta["files"][0]

    def test_snapshot_contains_original_file(self, workspace):
        (workspace / "myfile.py").write_text("original content")
        result = apply_tool_call(
            workspace,
            {"tool": "write_file", "args": {"path": "myfile.py", "content": "new content"}},
            step_idx=3,
        )
        backup_dir = Path(result["backup"])
        backed_up = backup_dir / "myfile.py"
        assert backed_up.exists()
        assert backed_up.read_text() == "original content"

    def test_invalid_path_traversal_rejected(self, workspace):
        result = apply_tool_call(
            workspace,
            {"tool": "write_file", "args": {"path": "../../evil.txt", "content": "evil"}},
            step_idx=1,
        )
        assert result["status"] == "error"
        assert "ERROR" in result["details"]

    def test_missing_tool_key(self, workspace):
        result = apply_tool_call(workspace, {"tool": "read_file", "args": {}}, step_idx=1)
        assert result["status"] == "error"
        assert "write tool" in result["details"]

    def test_replace_in_file_success(self, workspace):
        (workspace / "app.py").write_text("def hello():\n    pass\n")
        result = apply_tool_call(
            workspace,
            {
                "tool": "replace_in_file",
                "args": {
                    "path": "app.py",
                    "target_text": "pass",
                    "replacement_text": "return 'hello'",
                },
            },
            step_idx=4,
        )
        assert result["status"] == "success"
        assert "return 'hello'" in (workspace / "app.py").read_text()

    def test_replace_in_file_not_found_triggers_error_not_rollback(self, workspace):
        (workspace / "app.py").write_text("untouched content")
        result = apply_tool_call(
            workspace,
            {
                "tool": "replace_in_file",
                "args": {
                    "path": "app.py",
                    "target_text": "nonexistent text XYZ",
                    "replacement_text": "replaced",
                },
            },
            step_idx=5,
        )
        # Should be error (target_text not found) and file should be rolled back
        assert result["status"] == "error"
        # File should remain unchanged after rollback
        assert (workspace / "app.py").read_text() == "untouched content"

    def test_delete_directory_success(self, workspace):
        (workspace / "to_delete" / "nested").mkdir(parents=True)
        (workspace / "to_delete" / "nested" / "x.txt").write_text("x", encoding="utf-8")

        result = apply_tool_call(
            workspace,
            {"tool": "delete_directory", "args": {"path": "to_delete"}},
            step_idx=6,
        )

        assert result["status"] == "success", f"Expected success: {result}"
        assert not (workspace / "to_delete").exists()

    def test_move_path_success(self, workspace):
        (workspace / "src").mkdir(parents=True)
        (workspace / "src" / "page.tsx").write_text("export default null;\n", encoding="utf-8")

        result = apply_tool_call(
            workspace,
            {"tool": "move_path", "args": {"src": "src/page.tsx", "dest": "src/(dashboard)/page.tsx"}},
            step_idx=7,
        )

        assert result["status"] == "success", f"Expected success: {result}"
        assert not (workspace / "src" / "page.tsx").exists()
        assert (workspace / "src" / "(dashboard)" / "page.tsx").exists()

    def test_write_file_supports_scratch_paths_in_managed_workspace(self, tmp_path):
        workspace = tmp_path / "demo"
        (workspace / ".agent").mkdir(parents=True)
        (workspace / "project").mkdir(parents=True)
        save_agent_state(workspace, {"original_prompt": "demo", "current_step": 3, "completed_steps": [], "plan": []})

        result = apply_tool_call(
            workspace,
            {"tool": "write_file", "args": {"path": "scratch:helpers/test.py", "content": "print('ok')\n"}},
            step_idx=3,
        )

        assert result["status"] == "success", f"Expected success: {result}"
        assert (workspace / ".agent" / ".scratch" / "step-3" / "helpers" / "test.py").exists()


# ---------------------------------------------------------------------------
# Lock file tests
# ---------------------------------------------------------------------------

class TestLockFile:

    def test_acquire_and_release(self, tmp_path):
        assert acquire_lock(tmp_path) is True
        assert (tmp_path / ".agent" / ".ai_lock").exists()
        release_lock(tmp_path)
        assert not (tmp_path / ".agent" / ".ai_lock").exists()

    def test_cannot_acquire_twice(self, tmp_path):
        assert acquire_lock(tmp_path) is True
        # Try to acquire from same process — should still work since PID matches?
        # Actually we treat same PID as locked. Let's test with a fake PID.
        lock = tmp_path / ".agent" / ".ai_lock"
        import json, os
        lock.parent.mkdir(parents=True, exist_ok=True)
        lock.write_text(json.dumps({"pid": 99999999, "acquired_at": __import__("time").time(), "workspace": str(tmp_path)}))
        # 99999999 pid likely dead so should be cleaned up
        result = acquire_lock(tmp_path)
        assert result is True  # stale lock gets removed
        release_lock(tmp_path)


# ---------------------------------------------------------------------------
# file_tools ERROR: prefix tests
# ---------------------------------------------------------------------------

class TestFileToolsErrorPrefixes:

    @pytest.fixture
    def workspace(self, tmp_path):
        from nexcode.agent_runtime.tool_registry import load_all_tools
        load_all_tools()
        return tmp_path

    def test_read_file_not_found_starts_ERROR(self, workspace):
        from nexcode.agent_runtime.tool_registry import get_tool
        result = get_tool("read_file")(workspace, "nonexistent_file.py")
        assert result.startswith("ERROR:"), f"Expected ERROR: prefix, got: {result[:50]}"

    def test_replace_in_file_not_found_starts_ERROR(self, workspace):
        from nexcode.agent_runtime.tool_registry import get_tool
        result = get_tool("replace_in_file")(workspace, "nope.py", "x", "y")
        assert result.startswith("ERROR:"), f"Expected ERROR: prefix, got: {result[:50]}"

    def test_patch_file_missing_starts_ERROR(self, workspace):
        from nexcode.agent_runtime.tool_registry import get_tool
        result = get_tool("patch_file")(workspace, "missing.py", 1, 5, "content")
        assert result.startswith("ERROR:"), f"Expected ERROR: prefix, got: {result[:50]}"

    def test_write_file_success_starts_SUCCESS(self, workspace):
        from nexcode.agent_runtime.tool_registry import get_tool
        result = get_tool("write_file")(workspace, "ok.txt", "content")
        assert result.startswith("SUCCESS:"), f"Expected SUCCESS: prefix, got: {result[:50]}"
