from nexcode.agent_runtime.token_utils import UsageData

def test_usage_data():
    u1 = UsageData(input_tokens=100, output_tokens=50, total_tokens=150, reasoning_tokens=20)
    u2 = UsageData(input_tokens=200, output_tokens=100, total_tokens=300, reasoning_tokens=40)
    
    u1.add(u2)
    assert u1.input_tokens == 300
    assert u1.output_tokens == 150
    assert u1.total_tokens == 450
    assert u1.reasoning_tokens == 60
    
    d = u1.to_dict()
    u3 = UsageData.from_dict(d)
    assert u3 == u1
    
    print("UsageData test passed!")

if __name__ == "__main__":
    test_usage_data()
