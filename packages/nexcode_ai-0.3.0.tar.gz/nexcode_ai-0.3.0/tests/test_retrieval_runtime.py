from pathlib import Path
from types import SimpleNamespace

import nexcode.agent_runtime.verifier as verifier
import nexcode.agent_runtime.planner as planner
import nexcode.agent_runtime.repair as repair
import nexcode.agent_runtime.reporter as reporter
from nexcode.agent_runtime.context import build_context
from nexcode.agent_runtime.executor import _build_coder_system_prompt
from nexcode.agent_runtime.prompt_context import summarize_tool_observation
from nexcode.agent_runtime.reporter import REPORTER_SYSTEM_PROMPT
from nexcode.agent_runtime.tool_registry import load_all_tools
from nexcode.agent_runtime.token_utils import UsageData
from nexcode.agent_runtime.workspace import get_logs_dir
from nexcode.config import DEFAULT_AGENT_CONFIG
from nexcode.tools.file_tools import multi_read
from nexcode.tools.shell_tools import run_command, run_command_interactive


def _make_workspace(tmp_path: Path) -> Path:
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    return workspace


def _write_large_file(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def test_multi_read_uses_focus_windows_for_large_files(tmp_path):
    workspace = _make_workspace(tmp_path)
    file_path = workspace / "project" / "src" / "service.py"
    lines = [f"filler_{i}" for i in range(1, 1600)]
    lines.append("BUG_MARKER = 'mid-file issue'")
    lines.extend(f"tail_{i}" for i in range(1601, 2801))
    _write_large_file(file_path, lines)

    rendered = multi_read(workspace, ["src/service.py"], focus_terms=["BUG_MARKER"])

    assert "BUG_MARKER" in rendered
    assert "@@ L1570-L1630 @@" in rendered
    assert "lines omitted" in rendered
    assert "[TRUNCATED]" not in rendered


def test_multi_read_structural_fallback_for_large_files_without_focus_terms(tmp_path):
    workspace = _make_workspace(tmp_path)
    file_path = workspace / "project" / "src" / "module.py"
    lines = [f"setup_{i}" for i in range(1, 900)]
    lines.append("def helper_alpha():")
    lines.extend(f"middle_{i}" for i in range(901, 1800))
    lines.append("class ImportantThing:")
    lines.extend(f"end_{i}" for i in range(1801, 2801))
    _write_large_file(file_path, lines)

    rendered = multi_read(workspace, ["src/module.py"])

    assert "helper_alpha" in rendered
    assert "ImportantThing" in rendered
    assert "@@ L1-L80 @@" in rendered
    assert "lines omitted" in rendered


def test_build_context_uses_targeted_late_file_excerpt(tmp_path):
    workspace = _make_workspace(tmp_path)
    file_path = workspace / "project" / "src" / "resolver.py"
    lines = [f"prefix_{i}" for i in range(1, 1800)]
    lines.append("def critical_bug_marker():")
    lines.append("    return 'needs fix'")
    lines.extend(f"suffix_{i}" for i in range(1803, 3201))
    _write_large_file(file_path, lines)
    load_all_tools()

    context = build_context(
        workspace,
        "Fix critical_bug_marker in src/resolver.py",
        plan_preview=["Step 1: Fix the resolver bug"],
        history=["Verifier failure in src/resolver.py references critical_bug_marker."],
        instruction_memory="Fix the failing resolver path",
        rationale="The fix is isolated to critical_bug_marker",
        forensics="Reporter checked src/resolver.py and found critical_bug_marker near the failure path.",
        preferred_files=["src/resolver.py"],
        report_checked_files=["src/resolver.py"],
        recent_files=["src/resolver.py"],
        verifier_feedback="NameError around critical_bug_marker in src/resolver.py",
    )

    assert "critical_bug_marker" in context
    assert "@@ L1770-L1830 @@" in context
    assert "[Truncated for length" not in context


def test_run_command_returns_small_output_without_artifact(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)

    def fake_run(*args, **kwargs):
        return SimpleNamespace(returncode=0, stdout="hello from command\n", stderr="")

    monkeypatch.setattr("nexcode.tools.shell_tools.subprocess.run", fake_run)

    result = run_command(workspace, 'python -c "print(\'hello from command\')"')

    assert result == "hello from command\n"
    assert "Full output saved to:" not in result


def test_run_command_failure_saves_artifact_and_error_excerpt(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    long_output = "\n".join(
        [f"log line {i}" for i in range(1, 220)]
        + ["Module not found: broken_dep", "Build failed because the dependency is missing."]
        + [f"tail line {i}" for i in range(220, 280)]
    )

    def fake_run(*args, **kwargs):
        return SimpleNamespace(returncode=1, stdout=long_output, stderr="")

    monkeypatch.setattr("nexcode.tools.shell_tools.subprocess.run", fake_run)

    result = run_command(workspace, 'python -c "print(\'boom\')"')
    artifacts = list((get_logs_dir(workspace) / "command_artifacts").glob("*.log"))

    assert result.startswith("Error: Command failed with exit code 1.")
    assert "Full output saved to:" in result
    assert "Module not found: broken_dep" in result
    assert artifacts


def test_run_command_interactive_streams_status_and_writes_artifact(tmp_path):
    workspace = _make_workspace(tmp_path)
    script = workspace / "project" / "live.py"
    script.write_text(
        "import time\n"
        "print('start', flush=True)\n"
        "time.sleep(0.2)\n"
        "print('middle', flush=True)\n"
        "time.sleep(0.2)\n"
        "print('done', flush=True)\n",
        encoding="utf-8",
    )
    status_updates = []
    tail_batches = []

    result = run_command_interactive(
        workspace,
        'python "live.py"',
        verbose=True,
        status_callback=lambda elapsed, latest: status_updates.append((elapsed, latest)),
        tail_callback=lambda lines, omitted: tail_batches.append((lines, omitted)),
        timeout=5,
    )

    assert result.status == "success"
    assert result.exit_code == 0
    assert Path(result.artifact_path).exists()
    assert "start" in Path(result.artifact_path).read_text(encoding="utf-8")
    assert any(latest for _, latest in status_updates)
    assert tail_batches
    assert any("done" in line for lines, _ in tail_batches for line in lines)


def test_run_command_interactive_compacts_single_line_output(tmp_path):
    workspace = _make_workspace(tmp_path)
    script = workspace / "project" / "json_out.py"
    script.write_text(
        "print('{\"data\":\"' + ('x' * 700) + '\"}', flush=True)\n",
        encoding="utf-8",
    )

    result = run_command_interactive(workspace, 'python "json_out.py"', timeout=5)

    assert result.status == "success"
    assert "truncated" in result.output_preview.lower()
    assert len(result.output_preview) < 450
    assert len(Path(result.artifact_path).read_text(encoding="utf-8")) > 700


def test_verifier_failure_uses_artifact_backed_excerpt(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "package.json").write_text(
        '{"scripts": {"test": "demo", "lint": "demo", "build": "demo"}}',
        encoding="utf-8",
    )

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        if cmd[:2] == ["npm", "test"]:
            output = "\n".join(
                [f"test line {i}" for i in range(1, 180)]
                + ["FAIL critical_suite", "Module not found: test_dep"]
                + [f"tail line {i}" for i in range(180, 260)]
            )
            return 1, output
        if cmd[:3] == ["npm", "run", "lint"]:
            return 0, "lint ok"
        if cmd[:3] == ["npm", "run", "build"]:
            return 0, "build ok"
        return 0, ""

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(workspace, step={"files": []}, changed_files=[], is_final_step=True)
    artifacts = list((get_logs_dir(workspace) / "verifier_artifacts").glob("*.log"))

    assert result["status"] == "fail"
    assert "Full output saved to:" in result["checks"]["tests"]["output"]
    assert "Module not found: test_dep" in result["checks"]["tests"]["output"]
    assert artifacts


def test_check_syntax_scoped_python_uses_py_compile_targets(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")
    commands = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        commands.append(cmd)
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_syntax(
        workspace,
        workspace / "project",
        profile=verifier.detect_project_profile(workspace),
        targets=["linked_list_cycle.py"],
        verification_mode="scoped",
    )

    assert result["runner"] == "python -m py_compile"
    assert commands == [["python", "-m", "py_compile", "linked_list_cycle.py"]]


def test_check_syntax_project_python_uses_compileall_dot(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")
    commands = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        commands.append(cmd)
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_syntax(
        workspace,
        workspace / "project",
        profile=verifier.detect_project_profile(workspace),
        verification_mode="project",
    )

    assert result["runner"] == "python -m compileall"
    assert commands == [["python", "-m", "compileall", "."]]


def test_prompts_and_defaults_reflect_range_based_retrieval(tmp_path):
    workspace = _make_workspace(tmp_path)
    prompt = _build_coder_system_prompt(workspace, {"task": "Fix the resolver bug", "files": ["src/resolver.py"]})

    assert "search_file" in REPORTER_SYSTEM_PROMPT
    assert "read_lines" in REPORTER_SYSTEM_PROMPT
    assert "search_file" in prompt
    assert "read_lines" in prompt
    assert "focus_terms" in prompt
    assert DEFAULT_AGENT_CONFIG["fix_history_summary_threshold"] == 500000


def test_build_context_returns_metadata_and_scoped_summary(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "test.py").write_text("print('hello')\n", encoding="utf-8")
    (workspace / "project" / "html").mkdir()
    for idx in range(200):
        (workspace / "project" / "html" / f"page-{idx}.html").write_text("generated\n", encoding="utf-8")
    load_all_tools()

    context, metadata = build_context(
        workspace,
        "Run test.py",
        plan_preview=["Step 1: Run test.py"],
        history=[],
        instruction_memory="Inspect the script output",
        preferred_files=["test.py"],
        return_metadata=True,
    )

    assert "Focused workspace summary" in context
    assert metadata["workspace_summary_tokens"] < 4000
    assert "page-199.html" not in context


def test_compact_workspace_summary_prefers_recent_real_files_for_generic_steps(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "merge_sort.py").write_text("print('ok')\n", encoding="utf-8")
    for idx in range(30):
        (workspace / "project" / f"extra_{idx}.py").write_text("print('extra')\n", encoding="utf-8")

    summary, relevant = planner.build_compact_workspace_summary(
        workspace,
        query="Validate the merge sort implementation",
        recent_files=["merge_sort.py"],
        top_k=12,
    )

    assert "merge_sort.py" in summary
    assert relevant == ["merge_sort.py"]
    assert "extra_29.py" not in summary


def test_build_context_does_not_expand_from_list_files_history(tmp_path):
    workspace = _make_workspace(tmp_path)
    for idx in range(120):
        (workspace / "project" / f"file_{idx}.py").write_text(f"def f_{idx}():\n    return {idx}\n", encoding="utf-8")

    context, metadata = build_context(
        workspace,
        "Delete file_1.py and file_2.py",
        plan_preview=["Step 1: delete the requested files"],
        history=["Observation from list_files:\n" + "\n".join(f"file_{idx}.py" for idx in range(120))],
        instruction_memory="Delete the requested files only",
        preferred_files=[],
        report_checked_files=[],
        recent_files=[],
        return_metadata=True,
    )

    assert len(metadata["focused_files"]) <= 10
    assert "FILE: file_119.py" not in context
    assert "file_119.py" not in metadata["focused_files"]


def test_summarize_tool_observation_compacts_list_files_and_grep_results():
    list_result = "\n".join(f"file_{idx}.py" for idx in range(30))
    grep_result = "\n".join(f"file_{idx}.py:{idx}: match_{idx}" for idx in range(25))

    summarized_list = summarize_tool_observation("list_files", list_result)
    summarized_grep = summarize_tool_observation("grep_search", grep_result)

    assert "Listed 30 files." in summarized_list
    assert "... [10 more files omitted] ..." in summarized_list
    assert "file_25.py" not in summarized_list
    assert "Found 25 matches." in summarized_grep
    assert "... [13 more matches omitted] ..." in summarized_grep
    assert "match_20" not in summarized_grep


def test_generate_plan_uses_compact_workspace_summary_for_fix_prompts(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "alpha.py").write_text("print('alpha')\n", encoding="utf-8")
    (workspace / "project" / "beta.py").write_text("print('beta')\n", encoding="utf-8")
    for idx in range(40):
        (workspace / "project" / f"extra_{idx}.py").write_text("print('extra')\n", encoding="utf-8")

    captured = {}

    monkeypatch.setattr(planner, "load_access", lambda: {"api_key": "key", "endpoint": "endpoint", "provider": "grok"})
    monkeypatch.setattr(planner, "load_agent_config", lambda workspace: {"model": "demo"})
    monkeypatch.setattr(planner, "load_agent_state", lambda workspace: {"last_fix_walkthrough": "walkthrough"})
    monkeypatch.setattr(planner, "save_agent_state", lambda workspace, state: None)

    def fake_call_gateway(api_key, endpoint, model, system_prompt, user_prompt, json_mode=True):
        captured["prompt"] = user_prompt
        return '[{"step": 1, "task": "Delete alpha.py", "files": ["alpha.py"]}]', UsageData()

    monkeypatch.setattr(planner, "_call_gateway", fake_call_gateway)

    planner.generate_plan(
        "Delete alpha.py and beta.py",
        workspace,
        is_fix=True,
        orig_prompt="demo",
        fix_history=[],
        fix_metadata={"complexity": "simple", "confidence": "high", "checked_files": ["alpha.py", "beta.py"]},
    )

    prompt_text = captured["prompt"]
    assert "Focused workspace summary:" in prompt_text
    assert "alpha.py" in prompt_text
    assert "beta.py" in prompt_text
    assert "extra_39.py" not in prompt_text


def test_run_repair_uses_compact_workspace_summary(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "alpha.py").write_text("print('alpha')\n", encoding="utf-8")
    for idx in range(40):
        (workspace / "project" / f"extra_{idx}.py").write_text("print('extra')\n", encoding="utf-8")

    captured = {}

    monkeypatch.setattr(repair, "load_access", lambda: {"api_key": "key", "endpoint": "endpoint", "provider": "grok"})
    monkeypatch.setattr(repair, "load_agent_config", lambda workspace: {"model": "demo"})

    def fake_call_gateway(api_key, endpoint, model, system_prompt, user_prompt, json_mode=True):
        captured["prompt"] = user_prompt
        return '[{"step": 1, "task": "Update alpha.py", "files": ["alpha.py"]}]', UsageData()

    monkeypatch.setattr(planner, "_call_gateway", fake_call_gateway)

    result = repair.run_repair(
        workspace,
        step={"task": "Update alpha.py", "step": 1},
        diagnostics="alpha.py failed validation",
        coder_history=["recent history"],
        attempt=1,
        state={
            "original_prompt": "demo",
            "last_fix_walkthrough": "walkthrough",
            "investigation_complexity": "simple",
            "investigation_confidence": "high",
            "investigation_checked_files": ["alpha.py"],
        },
    )

    assert result["action"] == "retry"
    assert "Focused workspace summary:" in captured["prompt"]
    assert "alpha.py" in captured["prompt"]
    assert "extra_39.py" not in captured["prompt"]


def test_reporter_normalize_submit_report_args_filters_non_paths(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "scanner" / "openapi.go").parent.mkdir(parents=True, exist_ok=True)
    (workspace / "project" / "scanner" / "openapi.go").write_text("package scanner\n", encoding="utf-8")

    normalized = reporter._normalize_submit_report_args(
        workspace,
        {
            "resolution_type": "answer_only",
            "user_instructions": "Already implemented.",
            "checked_files": [
                "Workspace summary (no Python files)",
                "scanner/openapi.go (ParseOpenAPISpec, OpenAPIEndpoint)",
                "missing/file.py",
            ],
        },
    )

    assert normalized["checked_files"] == ["scanner/openapi.go"]


def test_verifier_scopes_root_level_python_edit_away_from_nested_ui(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "go.mod").write_text("module demo\n", encoding="utf-8")
    (workspace / "project" / "test.py").write_text("print('ok')\n", encoding="utf-8")
    (workspace / "project" / "ui").mkdir()
    (workspace / "project" / "ui" / "package.json").write_text(
        '{"scripts":{"test":"demo","lint":"demo","build":"demo"}}',
        encoding="utf-8",
    )

    calls = []

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        calls.append((project_root, cmd))
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(
        workspace,
        step={"task": "Remove comments from test.py", "goal": "", "files": ["test.py"]},
        changed_files=["test.py"],
        is_final_step=True,
    )

    assert result["status"] == "pass"
    assert all(cmd[0] != "npm" for _, cmd in calls)
    assert all(cmd[:2] != ["go", "build"] for _, cmd in calls)


def test_verifier_scoped_python_task_ignores_unrelated_repo_lint_failures(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text(
        "class Solution:\n    pass\n",
        encoding="utf-8",
    )
    (workspace / "project" / "test.py").write_text("bad trailing whitespace   \n", encoding="utf-8")
    calls = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        calls.append(cmd)
        if cmd[:2] == ["python", "-m"] and cmd[2] == "py_compile":
            return 0, "syntax ok"
        if cmd and cmd[0] == "flake8":
            assert "." not in cmd
            assert "test.py" not in cmd
            assert "linked_list_cycle.py" in cmd
            return 0, "lint ok"
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(
        workspace,
        step={"task": "Create linked_list_cycle.py", "goal": "", "files": ["linked_list_cycle.py"]},
        changed_files=["linked_list_cycle.py"],
        is_final_step=True,
    )

    assert result["status"] == "pass"
    assert result["verification_mode"] == "scoped"
    assert result["verification_targets"] == ["linked_list_cycle.py"]
    assert result["checks"]["tests"]["runner"] == "scoped-skip"
    assert result["checks"]["build"]["runner"] == "scoped-skip"
    assert all(cmd[:2] != ["python", "-m"] or cmd[2] != "unittest" for cmd in calls)


def test_verifier_scoped_mode_reports_project_wide_checks_as_skipped(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)
    monkeypatch.setattr(verifier, "_run_cmd", lambda *args, **kwargs: (0, "ok"))

    result = verifier.run_verification(
        workspace,
        step={"task": "Update linked_list_cycle.py", "goal": "", "files": ["linked_list_cycle.py"]},
        changed_files=["linked_list_cycle.py"],
        is_final_step=True,
    )

    assert result["checks"]["tests"]["output"] == "Skipped project-wide tests for this narrow file-scoped task."
    assert result["checks"]["build"]["output"] == "Skipped project-wide build checks for this narrow file-scoped task."


def test_verifier_classifies_format_only_lint_failures(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        if cmd[:2] == ["python", "-m"] and cmd[2] == "py_compile":
            return 0, "syntax ok"
        if cmd and cmd[0] == "flake8":
            return 1, "linked_list_cycle.py:6:1: E302 expected 2 blank lines, found 1"
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(
        workspace,
        step={"task": "Create linked_list_cycle.py", "goal": "", "files": ["linked_list_cycle.py"]},
        changed_files=["linked_list_cycle.py"],
        is_final_step=True,
    )

    assert result["status"] == "warn"
    assert result["failure_classification"] == "format_only"
    assert result["verification_stage"] == "stage1_touched_files"
    assert result["judgment"] == "auto_fixable_format"
    assert result["is_blocking"] is False
    assert result["suggested_action"] == "auto_fix"
    assert result["raw_checks"] == result["checks"]


def test_verifier_classifies_missing_eof_newline_as_format_only(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        if cmd[:2] == ["python", "-m"] and cmd[2] == "py_compile":
            return 0, "syntax ok"
        if cmd and cmd[0] == "flake8":
            return 1, "linked_list_cycle.py:4:1: W292 no newline at end of file"
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(
        workspace,
        step={"task": "Create linked_list_cycle.py", "goal": "", "files": ["linked_list_cycle.py"]},
        changed_files=["linked_list_cycle.py"],
        is_final_step=True,
    )

    assert result["status"] == "warn"
    assert result["failure_classification"] == "format_only"
    assert result["judgment"] == "auto_fixable_format"
    assert result["is_blocking"] is False


def test_verifier_manifest_edit_uses_project_mode(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "package.json").write_text(
        '{"scripts":{"test":"demo","lint":"demo","build":"demo"}}',
        encoding="utf-8",
    )
    calls = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        calls.append(cmd)
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier.run_verification(
        workspace,
        step={"task": "Update package.json", "goal": "", "files": ["package.json"]},
        changed_files=["package.json"],
        is_final_step=True,
    )

    assert result["verification_mode"] == "project"
    assert ["npm", "test", "--", "--watchAll=false"] in calls
    assert ["npm", "run", "lint"] in calls
    assert ["npm", "run", "build"] in calls


def test_search_workspace_tool_returns_hits_for_targeted_query(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "auth.py").write_text(
        "def authenticate_user(token): pass\n", encoding="utf-8"
    )
    (workspace / "project" / "unrelated.py").write_text(
        "def compute(x): return x * 2\n", encoding="utf-8"
    )
    load_all_tools()
    from nexcode.agent_runtime.tool_registry import get_tool

    search_workspace = get_tool("search_workspace")
    result = search_workspace(workspace, "authenticate user token")

    assert "auth.py" in result
    assert "unrelated.py" not in result


def test_search_workspace_tool_returns_full_index_for_broad_query(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / "project" / "auth.py").write_text(
        "def login(): pass\n", encoding="utf-8"
    )
    (workspace / "project" / "utils.py").write_text(
        "def helper(): pass\n", encoding="utf-8"
    )
    load_all_tools()
    from nexcode.agent_runtime.tool_registry import get_tool

    search_workspace = get_tool("search_workspace")
    # Broad query with no code-specific tokens — expects full index fallback
    result = search_workspace(workspace, "explore everything review all flaws zzzunmatchable")

    # Full index fallback: both files should appear in the result
    assert "auth.py" in result
    assert "utils.py" in result
