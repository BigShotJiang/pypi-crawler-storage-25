from pathlib import Path
from types import SimpleNamespace

from nexcode.agent_runtime.designer import _derive_ui_contract
from nexcode.agent_runtime.executor import (
    _attempt_format_only_autofix,
    _auto_inspect_paths,
    _build_coder_system_prompt,
    _build_guard_recovery_note,
    _build_step_transfer_notes,
    _build_workspace_facts,
    _extract_tool_paths,
    _filter_repair_paths_to_step_roots,
    _format_usage_brief,
    _normalize_python_format_only_source,
    _bootstrap_write_guard_message,
    _is_framework_bootstrap_step,
    _project_is_initialized,
    _is_shadcn_command,
    _shadcn_postconditions_met,
    _shared_shell_write_guard_message,
    _step_scope_write_guard_message,
    _shadcn_write_guard_message,
    _is_shadcn_step,
    canonical_tool_signature,
)
from nexcode.agent_runtime.repair import run_repair
from nexcode.agent_runtime.planner import _reorder_plan_for_execution, repair_json_plan
from nexcode.agent_runtime import verifier
from nexcode.agent_runtime.token_utils import UsageData
from nexcode import config
from nexcode.agent_runtime.verifier import _check_content_integrity
from nexcode.agent_runtime.workspace import (
    get_agent_dir,
    get_project_root,
    get_step_scratch_dir,
    init_workspace,
    load_agent_state,
    relativize_agent_path,
    resolve_agent_path,
    save_agent_state,
    safe_path,
)
from nexcode.tools import shell_tools
from nexcode.tools.shell_tools import (
    BACKGROUND_PROCESSES,
    _validate_command,
    add_shadcn_components,
    run_command,
    scaffold_next_app,
    setup_shadcn,
    wait_for_output,
)


def test_wrapped_repair_plan_is_parsed():
    payload = """
    {
      "plan": [
        {
          "step": 1,
          "task": "Install required packages in app",
          "goal": "Resolve missing module errors",
          "rationale": "The imports will fail until dependencies exist",
          "files": ["app/package.json"],
          "type": "setup",
          "design_notes": ""
        }
      ]
    }
    """

    plan = repair_json_plan(payload)

    assert isinstance(plan, list)
    assert plan[0]["task"] == "Install required packages in app"


def test_run_command_blocks_unapproved_binaries(tmp_path):
    result = run_command(tmp_path, "powershell Get-ChildItem")
    assert "not allowed" in result


def test_run_command_resolves_scratch_paths(tmp_path):
    init_workspace(tmp_path)
    # Mock current step in state
    state = load_agent_state(tmp_path)
    state["current_step"] = 1
    save_agent_state(tmp_path, state)

    scratch_dir = get_step_scratch_dir(tmp_path, 1)
    scratch_dir.mkdir(parents=True, exist_ok=True)
    
    # Test the internal helper logic
    cmd = "python script.py scratch:data.csv"
    resolved = shell_tools._resolve_scratch_in_command(tmp_path, cmd)
    
    expected_path = str(scratch_dir / "data.csv")
    assert expected_path in resolved
    assert "scratch:" not in resolved


def test_extract_tool_paths_includes_run_command_workdir():
    paths = _extract_tool_paths(
        Path("."),
        "run_command",
        {"cmd": 'npm pkg set scripts.test="exit 0"', "path": "ui"},
    )

    assert "ui" in paths


def test_filter_repair_paths_to_step_roots_blocks_unrelated_nested_app(tmp_path):
    (tmp_path / "go.mod").write_text("module demo\n", encoding="utf-8")
    (tmp_path / "test.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "ui").mkdir()
    (tmp_path / "ui" / "package.json").write_text('{"name":"ui"}', encoding="utf-8")

    filtered = _filter_repair_paths_to_step_roots(
        tmp_path,
        {"task": "Remove comments from test.py", "goal": "", "files": ["test.py"]},
        {"test.py", "ui/package.json"},
    )

    assert filtered == {"test.py"}


def test_filter_repair_paths_to_step_roots_blocks_unrelated_same_root_file(tmp_path):
    (tmp_path / "go.mod").write_text("module demo\n", encoding="utf-8")
    (tmp_path / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "test.py").write_text("print('bad')\n", encoding="utf-8")

    filtered = _filter_repair_paths_to_step_roots(
        tmp_path,
        {
            "task": "Create linked_list_cycle.py",
            "goal": "Add a linked list cycle solution",
            "files": ["linked_list_cycle.py"],
        },
        {"linked_list_cycle.py", "test.py"},
        {"linked_list_cycle.py"},
    )

    assert filtered == {"linked_list_cycle.py"}


def test_validate_command_allows_quoted_node_inline_scripts():
    result = _validate_command(
        'node -e "const fs = require(\'fs\'); const value = \'a|b\'; console.log(value);"'
    )

    assert result is None


def test_validate_command_blocks_single_ampersand_command_chaining():
    result = _validate_command("npm run build & powershell Get-ChildItem")

    assert "Command 'powershell' is not allowed" in result


def test_validate_command_allows_python3_alias():
    result = _validate_command('python3 -c "print(1)"')

    assert result is None


def test_validate_command_allows_rust_commands_when_workspace_is_rust(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "Cargo.toml").write_text("[package]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8")

    result = _validate_command("cargo test", workspace=workspace, exec_dir=project_root)

    assert result is None


def test_validate_command_blocks_rust_commands_for_static_html_workspace(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "index.html").write_text("<!doctype html>\n", encoding="utf-8")

    result = _validate_command("cargo test", workspace=workspace, exec_dir=project_root)

    assert "not allowed for the detected project stack" in result


def test_run_command_allows_quoted_node_inline_scripts(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    workspace.mkdir(parents=True)

    def fake_run(*args, **kwargs):
        return SimpleNamespace(returncode=0, stdout="patched\n", stderr="")

    monkeypatch.setattr("nexcode.tools.shell_tools.subprocess.run", fake_run)

    result = run_command(
        workspace,
        'node -e "const fs = require(\'fs\'); const file = \'src/demo.ts\'; console.log(file);"',
    )

    assert result == "patched\n"


def test_content_integrity_flags_placeholder_text(tmp_path):
    app_file = tmp_path / "app.py"
    app_file.write_text("def build_app():\n    # TODO: finish me\n    return 'ok'\n", encoding="utf-8")

    result = _check_content_integrity(tmp_path, ["app.py"])

    assert result["passed"] is False
    assert "app.py: TODO placeholder" in result["violations"]


def test_init_workspace_creates_managed_layout(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    workspace = init_workspace("Job Tracker App")

    assert workspace == tmp_path / ".ai-workspace" / "job-tracker-app"
    assert get_agent_dir(workspace) == workspace / ".agent"
    assert get_project_root(workspace) == workspace / "project"
    assert (workspace / ".agent").is_dir()
    assert (workspace / "project").is_dir()


def test_managed_workspace_state_and_safe_paths(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)

    save_agent_state(workspace, {"original_prompt": "demo", "current_step": 1, "completed_steps": [], "plan": []})
    state = load_agent_state(workspace)
    target = safe_path(workspace, "src/app.tsx")

    assert (workspace / ".agent" / "agent_state.json").exists()
    assert state["original_prompt"] == "demo"
    assert target == workspace / "project" / "src" / "app.tsx"


def test_scratch_paths_resolve_to_current_step_dir(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    save_agent_state(workspace, {"original_prompt": "demo", "current_step": 4, "completed_steps": [], "plan": []})

    resolved = resolve_agent_path(workspace, "scratch:helpers/test.js")

    assert resolved == get_step_scratch_dir(workspace, 4) / "helpers" / "test.js"
    assert relativize_agent_path(workspace, resolved, step_idx=4) == "scratch:helpers/test.js"


def test_scaffold_next_app_requires_package_json(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)

    class DummyResult:
        returncode = 0
        stdout = "scaffolded"
        stderr = ""

    monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: DummyResult())

    result = scaffold_next_app(workspace, app_name="job-tracker")

    assert result.startswith("ERROR:")
    assert "package.json" in result


def test_prepare_command_wraps_npm_on_windows(monkeypatch):
    monkeypatch.setattr(verifier.os, "name", "nt")

    prepared = verifier._prepare_command(["npm", "run", "build"])

    assert prepared == ["cmd", "/c", "npm", "run", "build"]


def test_check_lint_uses_package_script_for_modern_eslint_config(tmp_path, monkeypatch):
    (tmp_path / "package.json").write_text(
        '{"scripts": {"lint": "eslint ."}, "devDependencies": {"eslint": "^9"}}',
        encoding="utf-8",
    )
    (tmp_path / "eslint.config.mjs").write_text("export default [];\n", encoding="utf-8")

    monkeypatch.setattr(verifier, "_run_cmd", lambda *args, **kwargs: (0, "ok"))

    result = verifier._check_lint(tmp_path)

    assert result["runner"] == "npm run lint"
    assert result["passed"] is True


def test_check_lint_scoped_python_uses_targeted_flake8(monkeypatch, tmp_path):
    (tmp_path / "script.py").write_text("print('ok')\n", encoding="utf-8")
    commands = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        commands.append(cmd)
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_lint(
        tmp_path,
        profile=verifier.detect_project_profile(tmp_path),
        targets=["script.py"],
        verification_mode="scoped",
    )

    assert result["runner"] == "flake8"
    assert commands == [[
        "flake8",
        "--exclude=node_modules,.venv,.env,.snapshots,__pycache__",
        "--max-line-length=120",
        "--count",
        "script.py",
    ]]


def test_check_lint_scoped_python_uses_targeted_ruff(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[tool.ruff]\nline-length = 120\n", encoding="utf-8")
    (tmp_path / "script.py").write_text("print('ok')\n", encoding="utf-8")
    commands = []

    monkeypatch.setattr(verifier, "_command_available", lambda *args, **kwargs: True)

    def fake_run_cmd(project_root: Path, cmd: list[str], timeout: int = 60):
        commands.append(cmd)
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_lint(
        tmp_path,
        profile=verifier.detect_project_profile(tmp_path),
        targets=["script.py"],
        verification_mode="scoped",
    )

    assert result["runner"] == "ruff"
    assert commands == [["ruff", "check", "script.py"]]


def test_scaffold_next_app_wraps_npx_on_windows(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    calls = []

    class DummyResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    def fake_run(command, **kwargs):
        calls.append(command)
        (kwargs["cwd"] / "package.json").write_text("{}", encoding="utf-8")
        return DummyResult()

    monkeypatch.setattr(shell_tools.os, "name", "nt")
    monkeypatch.setattr(shell_tools.subprocess, "run", fake_run)

    result = scaffold_next_app(workspace, app_name="job-tracker")

    assert result.startswith("SUCCESS:")
    assert calls[0][:3] == ["cmd", "/c", "npx"]


def test_scaffold_next_app_supports_target_subdir(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    calls = []

    class DummyResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    def fake_run(command, **kwargs):
        calls.append((command, kwargs["cwd"]))
        target_root = kwargs["cwd"] / "portfolio-site"
        target_root.mkdir(parents=True, exist_ok=True)
        (target_root / "package.json").write_text("{}", encoding="utf-8")
        return DummyResult()

    monkeypatch.setattr(shell_tools.subprocess, "run", fake_run)

    result = scaffold_next_app(workspace, app_name="portfolio", target_dir="portfolio-site")

    assert result.startswith("SUCCESS:")
    assert "portfolio-site" in calls[0][0]
    assert calls[0][1] == project_root
    assert (project_root / "portfolio-site" / "package.json").exists()


def test_bootstrap_write_guard_blocks_manual_scaffold_before_init(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    plan_item = {
        "step": 1,
        "task": "Initialize a new Next.js project in the project root with TypeScript",
        "goal": "Establish the foundational project structure",
        "type": "setup",
    }

    message = _bootstrap_write_guard_message(plan_item, workspace, "write_file")

    assert _is_framework_bootstrap_step(plan_item) is True
    assert _project_is_initialized(workspace) is False
    assert message is not None
    assert "Manual file writes are forbidden" in message


def test_bootstrap_write_guard_blocks_manual_scaffold_for_uninitialized_subdir(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "package.json").write_text("{}", encoding="utf-8")
    plan_item = {
        "step": 1,
        "task": "Initialize a new Next.js project in portfolio-site",
        "goal": "Scaffold a standalone portfolio app",
        "files": ["portfolio-site"],
        "type": "setup",
    }

    message = _bootstrap_write_guard_message(plan_item, workspace, "write_file")

    assert message is not None
    assert "portfolio-site" in message


def test_bootstrap_write_guard_allows_writes_after_init(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    (workspace / "project" / "package.json").write_text("{}", encoding="utf-8")
    plan_item = {
        "step": 1,
        "task": "Scaffold Next.js project in the project root using npx create-next-app",
        "goal": "Establish the foundational project structure",
        "type": "setup",
    }

    message = _bootstrap_write_guard_message(plan_item, workspace, "write_file")

    assert _project_is_initialized(workspace) is True
    assert message is None


def test_project_is_initialized_for_existing_html_workspace(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    (workspace / "project" / "index.html").write_text("<!doctype html>\n", encoding="utf-8")

    assert _project_is_initialized(workspace) is True


def test_bootstrap_write_guard_skips_html_step_that_only_initializes_aos(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "assets" / "js").mkdir(parents=True)
    (workspace / "project" / "index.html").write_text("<!doctype html>\n", encoding="utf-8")
    (workspace / "project" / "assets" / "js" / "main.js").write_text("", encoding="utf-8")
    plan_item = {
        "step": 29,
        "task": "Rewrite assets/js/main.js to implement smooth scrolling, scrollspy, and initialize AOS",
        "goal": "Restore landing page interactions for the existing HTML site",
        "type": "implementation",
    }

    message = _bootstrap_write_guard_message(plan_item, workspace, "patch_file")

    assert _is_framework_bootstrap_step(plan_item) is False
    assert message is None


def test_workspace_facts_reflect_src_dir_and_tailwind_v4(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "app").mkdir(parents=True)
    (workspace / "project" / "package.json").write_text(
        '{"devDependencies": {"tailwindcss": "^4.1.0"}}',
        encoding="utf-8",
    )

    facts = _build_workspace_facts(workspace)

    assert "`src/app`" in facts
    assert "`src/app/globals.css`" in facts
    assert "No Tailwind config file exists right now." in facts
    assert "Tailwind v4 may rely on" in facts


def test_shadcn_postconditions_detect_generated_assets(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "components" / "ui").mkdir(parents=True)
    (workspace / "project" / "components.json").write_text("{}", encoding="utf-8")

    assert _shadcn_postconditions_met(workspace) is True


def test_is_shadcn_step_uses_task_not_goal_only():
    package_step = {
        "task": "Run npm install framer-motion zod",
        "goal": "Install packages before shadcn setup",
    }
    shadcn_step = {
        "task": "Run npx shadcn@latest init and add button",
        "goal": "Configure shadcn/ui",
    }

    assert _is_shadcn_step(package_step) is False
    assert _is_shadcn_step(shadcn_step) is True


def test_is_shadcn_command_detects_cli_calls():
    assert _is_shadcn_command("run_command", {"cmd": "npx shadcn@latest init"}) is True
    assert _is_shadcn_command("run_command", {"cmd": "npx shadcn-ui@latest add button"}) is True
    assert _is_shadcn_command("run_command", {"cmd": "npm install zod"}) is False


def test_shadcn_write_guard_blocks_manual_files_before_init(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    plan_item = {
        "step": 3,
        "task": "Initialize shadcn/ui by running npx shadcn@latest init configuring custom theme tokens",
        "goal": "Configure shadcn/ui",
        "type": "setup",
    }

    message = _shadcn_write_guard_message(plan_item, workspace, "write_file")

    assert message is not None
    assert "Manual file writes are forbidden" in message


def test_shadcn_write_guard_allows_writes_after_real_setup(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    (project_root / "lib").mkdir(parents=True)
    project_root.mkdir(exist_ok=True)
    (project_root / "components.json").write_text("{}", encoding="utf-8")
    (project_root / "lib" / "utils.ts").write_text("export {}\n", encoding="utf-8")
    plan_item = {
        "step": 3,
        "task": "Initialize shadcn/ui by running npx shadcn@latest init configuring custom theme tokens",
        "goal": "Configure shadcn/ui",
        "type": "setup",
    }

    message = _shadcn_write_guard_message(plan_item, workspace, "replace_in_file")

    assert message is None


def test_run_repair_attempt_one_uses_fix_prompt_defaults_without_keyerror(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    captured = {}

    def fake_call_gateway(api_key, endpoint, model, system_prompt, user_prompt):
        captured["prompt"] = user_prompt
        return (
            """
            {
              "plan": [
                {
                  "step": 1,
                  "task": "Update the landing page JavaScript interactions",
                  "goal": "Restore smooth scrolling and section highlighting",
                  "rationale": "The failure is isolated to the existing front-end script",
                  "files": ["assets/js/main.js"],
                  "type": "implementation",
                  "design_notes": ""
                }
              ]
            }
            """,
            SimpleNamespace(to_dict=lambda: {"input_tokens": 1, "output_tokens": 1}),
        )

    monkeypatch.setattr("nexcode.agent_runtime.repair.load_access", lambda: {"api_key": "test", "endpoint": "http://example.test"})
    monkeypatch.setattr("nexcode.agent_runtime.repair.load_agent_config", lambda *args, **kwargs: {"model": "test-model"})
    monkeypatch.setattr("nexcode.agent_runtime.planner._call_gateway", fake_call_gateway)

    result = run_repair(
        workspace=workspace,
        step={"step": 29, "task": "Rewrite assets/js/main.js"},
        diagnostics="Bootstrap guard raised unexpectedly while editing a legacy HTML site.",
        coder_history=["Tool patch_file Error: guard blocked a valid file edit."],
        attempt=1,
        state={
            "original_prompt": "Fix the legacy HTML landing page interactions",
            "last_fix_walkthrough": "Checked the existing front-end script and the section anchors.",
            "investigation_complexity": "simple",
            "investigation_confidence": "high",
            "investigation_checked_files": ["assets/js/main.js"],
        },
    )

    assert result["action"] == "retry"
    assert "Complexity: simple" in captured["prompt"]
    assert "Confidence: high" in captured["prompt"]
    assert "- assets/js/main.js" in captured["prompt"]


def test_wait_for_output_reports_last_log_when_process_dies(tmp_path):
    BACKGROUND_PROCESSES.clear()
    log_file = tmp_path / "server.log"
    log_file.write_text("Build failed: missing module\n", encoding="utf-8")

    class FakeProcess:
        def poll(self):
            return 1

    BACKGROUND_PROCESSES[1234] = {
        "process": FakeProcess(),
        "log": log_file,
        "cmd": "npm run dev",
        "cwd": str(tmp_path),
        "start_time": 0,
    }

    result = wait_for_output(tmp_path, "localhost:3000", timeout=1, pid=1234)

    BACKGROUND_PROCESSES.clear()
    assert "terminated early" in result
    assert "Build failed: missing module" in result


def test_reorder_plan_moves_types_before_data_and_context():
    plan = [
        {"step": 1, "task": "Run npx create-next-app@latest .", "goal": "", "files": ["package.json"], "type": "setup"},
        {"step": 1, "task": "Create lib/data.ts with dummy jobs", "goal": "", "files": ["lib/data.ts"], "type": "implementation"},
        {"step": 2, "task": "Create types/job.ts with interface Job", "goal": "", "files": ["types/job.ts"], "type": "implementation"},
        {"step": 3, "task": "Create context provider", "goal": "", "files": ["contexts/JobsContext.tsx"], "type": "implementation"},
    ]

    reordered = _reorder_plan_for_execution(plan)

    assert reordered[0]["files"] == ["package.json"]
    assert reordered[1]["files"] == ["types/job.ts"]
    assert reordered[2]["files"] == ["lib/data.ts"]
    assert reordered[3]["files"] == ["contexts/JobsContext.tsx"]


def test_reorder_plan_moves_theme_foundation_before_pages_and_polish_before_validation():
    plan = [
        {"step": 1, "task": "Implement dashboard page", "goal": "", "files": ["app/dashboard/page.tsx"], "type": "implementation"},
        {"step": 2, "task": "Run npm run build and lint", "goal": "", "files": [], "type": "validation"},
        {"step": 3, "task": "Establish the global theme foundation and app shell", "goal": "", "files": ["app/globals.css", "app/layout.tsx"], "type": "implementation"},
        {"step": 4, "task": "Run a final UI polish and theme parity audit", "goal": "", "files": ["app/globals.css"], "type": "implementation"},
    ]

    reordered = _reorder_plan_for_execution(plan)

    assert reordered[0]["task"] == "Establish the global theme foundation and app shell"
    assert reordered[1]["task"] == "Implement dashboard page"
    assert reordered[2]["task"] == "Run a final UI polish and theme parity audit"
    assert reordered[3]["task"] == "Run npm run build and lint"


def test_derive_ui_contract_marks_shell_and_page_files():
    plan = [
        {"step": 1, "task": "Build shell", "files": ["app/layout.tsx", "app/globals.css", "components/layout/SidebarNav.tsx"]},
        {"step": 2, "task": "Build dashboard", "files": ["app/dashboard/page.tsx"]},
        {"step": 3, "task": "Build settings", "files": ["app/settings/page.tsx"]},
    ]

    contract = _derive_ui_contract(plan, "Theme switch behavior and placement in settings screen.")

    assert contract["requires_shared_shell"] is True
    assert "app/layout.tsx" in contract["protected_shell_files"]
    assert "app/globals.css" in contract["protected_shell_files"]
    assert "components/layout/SidebarNav.tsx" in contract["protected_shell_files"]
    assert "app/dashboard/page.tsx" in contract["page_files"]
    assert contract["requires_theme_toggle"] is True


def test_setup_shadcn_requires_support_files(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "package.json").write_text("{}", encoding="utf-8")

    class DummyResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    monkeypatch.setattr(shell_tools.subprocess, "run", lambda *args, **kwargs: DummyResult())

    result = setup_shadcn(workspace)

    assert result.startswith("ERROR:")
    assert "components.json" in result


def test_add_shadcn_components_checks_generated_file(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    (project_root / "components" / "ui").mkdir(parents=True)
    (project_root / "package.json").write_text("{}", encoding="utf-8")
    (project_root / "components.json").write_text("{}", encoding="utf-8")
    (project_root / "lib").mkdir(parents=True)
    (project_root / "lib" / "utils.ts").write_text("export {}\n", encoding="utf-8")

    class DummyResult:
        returncode = 0
        stdout = "added"
        stderr = ""

    def fake_run(*args, **kwargs):
        (project_root / "components" / "ui" / "button.tsx").write_text("export {}\n", encoding="utf-8")
        return DummyResult()

    monkeypatch.setattr(shell_tools.subprocess, "run", fake_run)

    result = add_shadcn_components(workspace, ["button"])

    assert result.startswith("SUCCESS:")
    assert "button" in result


def test_build_coder_system_prompt_is_stack_aware(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "package.json").write_text('{"dependencies": {"next": "15.0.0"}}', encoding="utf-8")

    prompt = _build_coder_system_prompt(workspace, {"task": "Implement page", "goal": ""})

    assert "Detected stack: Next.js App Router." in prompt
    assert "setup_shadcn" in prompt
    assert "theme foundation" in prompt


def test_build_coder_system_prompt_detects_rust_stack(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "Cargo.toml").write_text("[package]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8")

    prompt = _build_coder_system_prompt(workspace, {"task": "Fix parsing bug", "goal": ""})

    assert "Detected stack: Rust." in prompt
    assert "cargo test" in prompt


def test_check_unit_tests_uses_cargo_for_rust_workspace(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "Cargo.toml").write_text("[package]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8")
    seen = {}

    monkeypatch.setattr(verifier, "_command_exists", lambda command: True)

    def fake_run_cmd(cwd, cmd, timeout=60):
        seen["cmd"] = cmd
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_unit_tests(workspace, project_root)

    assert result["runner"] == "cargo test"
    assert seen["cmd"] == ["cargo", "test", "--quiet"]


def test_check_build_uses_go_build_for_go_workspace(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    (project_root / "go.mod").write_text("module demo\n\ngo 1.22\n", encoding="utf-8")
    seen = {}

    monkeypatch.setattr(verifier, "_command_exists", lambda command: True)

    def fake_run_cmd(cwd, cmd, timeout=60):
        seen["cmd"] = cmd
        return 0, "ok"

    monkeypatch.setattr(verifier, "_run_cmd", fake_run_cmd)

    result = verifier._check_build(workspace, project_root)

    assert result["runner"] == "go build"
    assert seen["cmd"] == ["go", "build", "./..."]


def test_shared_shell_write_guard_blocks_layout_edit_during_page_step(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "current_step": 2,
            "completed_steps": [],
            "plan": [],
            "ui_contract": {
                "protected_shell_files": ["app/layout.tsx", "app/globals.css"],
                "requires_shared_shell": True,
            },
        },
    )
    plan_item = {
        "step": 2,
        "task": "Implement notes page",
        "goal": "Create the notes route",
    }

    message = _shared_shell_write_guard_message(
        plan_item,
        workspace,
        "replace_in_file",
        {"app/layout.tsx"},
    )

    assert message is not None
    assert "shared shell or theme foundation files" in message


def test_ui_contract_enforces_tokens_when_globals_written(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    (project_root / "app" / "settings").mkdir(parents=True)
    (project_root / "app" / "globals.css").write_text(":root { --background: #fff; }\n", encoding="utf-8")
    (project_root / "app" / "settings" / "page.tsx").write_text(
        "export default function SettingsPage() { return <div>No header here</div>; }\n",
        encoding="utf-8",
    )
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "current_step": 4,
            "completed_steps": [],
            "plan": [],
            "ui_contract": {
                "requires_theme_tokens": True,
                "globals_files": ["app/globals.css"],
                "required_theme_tokens": ["--background", "--foreground", "--primary"],
                "route_contracts": {"app/settings/page.tsx": {"requires_header": True}},
            },
        },
    )

    # globals.css IS in changed_files -> token check fires
    result = verifier._check_ui_contract(
        workspace,
        project_root,
        {"step": 4, "files": ["app/settings/page.tsx", "app/globals.css"]},
        ["app/settings/page.tsx", "app/globals.css"],
    )

    assert result["passed"] is False
    assert "--foreground" in result["output"]
    assert "missing a visible header pattern" in result["output"]


def test_ui_contract_skips_tokens_when_globals_not_written(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    (project_root / "app" / "settings").mkdir(parents=True)
    (project_root / "app" / "globals.css").write_text(":root { --background: #fff; }\n", encoding="utf-8")
    (project_root / "app" / "settings" / "page.tsx").write_text(
        "<h1>Settings</h1>\n",
        encoding="utf-8",
    )
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "current_step": 3,
            "completed_steps": [],
            "plan": [],
            "ui_contract": {
                "requires_theme_tokens": True,
                "globals_files": ["app/globals.css"],
                "required_theme_tokens": ["--background", "--foreground", "--primary"],
            },
        },
    )

    # globals.css NOT in changed_files -> token check skipped
    result = verifier._check_ui_contract(
        workspace,
        project_root,
        {"step": 3, "files": ["app/settings/page.tsx"]},
        ["app/settings/page.tsx"],
    )

    assert result["passed"] is True
    assert "UI contract checks passed" in result["output"]


def test_extract_tool_paths_handles_multi_read():
    workspace = Path(".")
    paths = _extract_tool_paths(workspace, "multi_read", {"paths": ["./app/page.tsx", "src/app/layout.tsx"]})

    assert "app/page.tsx" in paths
    assert "src/app/layout.tsx" in paths


def test_extract_tool_paths_handles_run_command_filesystem_ops(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "app").mkdir(parents=True)

    paths = _extract_tool_paths(
        workspace,
        "run_command",
        {"cmd": 'mkdir "src/app/(dashboard)" && move src/app/page.tsx "src/app/(dashboard)/page.tsx"'},
    )

    assert "src/app/(dashboard)" in paths
    assert "src/app/page.tsx" in paths
    assert "src/app/(dashboard)/page.tsx" in paths


def test_run_command_allows_workspace_local_filesystem_commands(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "app").mkdir(parents=True)

    def fake_run(*args, **kwargs):
        return SimpleNamespace(returncode=0, stdout="ok\n", stderr="")

    monkeypatch.setattr("nexcode.tools.shell_tools.subprocess.run", fake_run)

    result = run_command(workspace, 'mkdir "src/app/(dashboard)"')

    assert result == "ok\n"


def test_run_command_blocks_path_escape_for_filesystem_commands(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)

    result = run_command(workspace, "mkdir ../outside")

    assert "escapes the resolved workspace project root or active scratch directory" in result


def test_step_scope_guard_blocks_run_command_when_step_is_too_narrow(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "app").mkdir(parents=True)
    plan_item = {
        "step": 13,
        "task": "Update root layout and create dashboard layout",
        "goal": "Separate the shell layout from the root layout",
        "files": ["src/app/layout.tsx", "src/app/(dashboard)/layout.tsx"],
    }
    targeted = _extract_tool_paths(
        workspace,
        "run_command",
        {"cmd": 'mkdir "src/app/(dashboard)" && move src/app/page.tsx "src/app/(dashboard)/page.tsx"'},
    )

    message = _step_scope_write_guard_message(plan_item, "run_command", targeted)

    assert message is not None
    assert "Step scope violation" in message


def test_step_scope_guard_allows_run_command_when_directory_is_scoped(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project" / "src" / "app").mkdir(parents=True)
    plan_item = {
        "step": 15,
        "task": "Move dashboard routes into a route group",
        "goal": "Reorganize the app routes before building the landing page",
        "files": ["src/app"],
    }
    targeted = _extract_tool_paths(
        workspace,
        "run_command",
        {"cmd": 'mkdir "src/app/(dashboard)" && move src/app/page.tsx "src/app/(dashboard)/page.tsx"'},
    )

    message = _step_scope_write_guard_message(plan_item, "run_command", targeted)

    assert message is None


def test_build_guard_recovery_note_prioritizes_pending_reads():
    note = _build_guard_recovery_note(
        {"app/page.tsx"},
        {"app/page.tsx", "components/ui/button.tsx"},
        {"app/page.tsx"},
    )

    assert "components/ui/button.tsx" in note
    assert "A previous edit target was stale" in note
    assert "app/page.tsx" in note


def test_build_step_transfer_notes_combines_summary_and_notes():
    merged = _build_step_transfer_notes(
        "We already fixed imports and build now fails on lint only.",
        "ACTIVE LINT REPAIR MODE:\nInspect app/page.tsx before editing.",
    )

    assert "STEP MEMORY SUMMARY:" in merged
    assert "build now fails on lint only" in merged
    assert "ACTIVE LINT REPAIR MODE" in merged


def test_auto_inspect_paths_reads_and_clears_flags(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    target = project_root / "app" / "page.tsx"
    target.parent.mkdir(parents=True)
    target.write_text("export default function Page() { return null; }\n", encoding="utf-8")

    inspected_files = set()
    lint_targets = {"app/page.tsx"}
    reread_targets = {"app/page.tsx"}

    result = _auto_inspect_paths(
        workspace,
        ["app/page.tsx"],
        inspected_files,
        lint_targets,
        reread_targets,
    )

    assert "FILE: app/page.tsx" in result
    assert "app/page.tsx" in inspected_files
    assert "app/page.tsx" not in lint_targets
    assert "app/page.tsx" not in reread_targets


def test_normalize_python_format_only_source_fixes_blank_lines_and_eof():
    source = (
        "class ListNode:\n"
        "    def __init__(self, x):\n"
        "        self.val = x\n"
        "        self.next = None\n"
        "\n"
        "class Solution:\n"
        "    def hasCycle(self, head):\n"
        "        return False\n"
        "    \n"
        "# Test cases\n"
        "if __name__ == '__main__':\n"
        "    print('ok')"
    )

    rewritten = _normalize_python_format_only_source(source)

    assert rewritten is not None
    assert rewritten.endswith("\n")
    assert "    \n" not in rewritten
    assert "\n\nclass Solution:" in rewritten
    assert "\n\n# Test cases\nif __name__ == '__main__':\n" in rewritten


def test_attempt_format_only_autofix_rewrites_python_targets(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    target = project_root / "algorithms" / "linked_list_cycle.py"
    target.parent.mkdir(parents=True)
    target.write_text(
        "class ListNode:\n"
        "    def __init__(self, x):\n"
        "        self.val = x\n"
        "        self.next = None\n"
        "\n"
        "class Solution:\n"
        "    def hasCycle(self, head):\n"
        "        return False\n",
        encoding="utf-8",
    )

    changed_files, notes = _attempt_format_only_autofix(
        workspace,
        1,
        {
            "failure_classification": "format_only",
            "verification_targets": ["algorithms/linked_list_cycle.py"],
            "checks": {
                "lint": {
                    "output": "algorithms/linked_list_cycle.py:6:1: E302 expected 2 blank lines, found 1\n"
                }
            },
        },
    )

    rewritten = target.read_text(encoding="utf-8")

    assert changed_files == ["algorithms/linked_list_cycle.py"]
    assert notes == ["algorithms/linked_list_cycle.py"]
    assert "\n\nclass Solution:\n" in rewritten


def test_attempt_format_only_autofix_skips_non_fixable_lint_codes(tmp_path):
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    project_root = workspace / "project"
    project_root.mkdir(parents=True)
    target = project_root / "linked_list_cycle.py"
    target.write_text("import os\n", encoding="utf-8")

    changed_files, notes = _attempt_format_only_autofix(
        workspace,
        1,
        {
            "failure_classification": "format_only",
            "verification_targets": ["linked_list_cycle.py"],
            "checks": {
                "lint": {
                    "output": "linked_list_cycle.py:1:1: F401 'os' imported but unused\n"
                }
            },
        },
    )

    assert changed_files == []
    assert notes == []
    assert target.read_text(encoding="utf-8") == "import os\n"


def test_canonical_tool_signature_distinguishes_replace_targets():
    first = canonical_tool_signature(
        "replace_in_file",
        {"path": "app/page.tsx", "target_text": "foo", "replacement_text": "bar"},
    )
    second = canonical_tool_signature(
        "replace_in_file",
        {"path": "app/page.tsx", "target_text": "baz", "replacement_text": "qux"},
    )

    assert first != second


def test_canonical_tool_signature_matches_true_duplicate_replace():
    first = canonical_tool_signature(
        "replace_in_file",
        {"path": "app/page.tsx", "target_text": "foo", "replacement_text": "bar"},
    )
    second = canonical_tool_signature(
        "replace_in_file",
        {"path": "./app/page.tsx", "target_text": "foo", "replacement_text": "zzz"},
    )

    assert first == second


def test_load_agent_config_reads_context_summary_threshold(tmp_path, monkeypatch):
    cfg_file = tmp_path / "agent.yaml"
    cfg_file.write_text(
        "model: grok-4-1-fast-reasoning\n"
        "max_steps: 50\n"
        "temperature: 0.2\n"
        "max_rejects: 5\n"
        "max_step_attempts: 20\n"
        "coder_context_summary_threshold: 250000\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(config, "AGENT_CONFIG_FILE", cfg_file)
    monkeypatch.setattr(config, "init_home", lambda: None)

    loaded = config.load_agent_config()

    assert loaded["coder_context_summary_threshold"] == 250000


def test_format_usage_brief_includes_cost_and_token_fields():
    usage = UsageData(
        input_tokens=1200,
        output_tokens=300,
        total_tokens=1500,
        reasoning_tokens=90,
        cumulative_cost=0.012345,
    )

    brief = _format_usage_brief(usage)

    assert "input=1,200" in brief
    assert "output=300" in brief
    assert "reasoning=90" in brief
    assert "cost=$0.012345" in brief


def test_history_consolidation_trigger_logic_handles_checkpoints():
    # Simulate the logic in executor.py
    from nexcode.agent_runtime.token_utils import estimate_tokens
    
    coder_context_summary_threshold = 100000
    
    class MockState(dict): pass
    class MockUsage: 
        input_tokens = 0
    
    state = MockState()
    step_usage = MockUsage()
    
    # CASE 1: step_usage is fresh, no checkpoint, but history is large (Resumption Fallback)
    massive_history = [f"Step history entry {i} with some extra padding. " for i in range(20000)]
    history_est = estimate_tokens("\n".join(massive_history))
    last_checkpoint = state.get("last_summary_checkpoint_1", 0)
    
    should_consolidate_1 = (step_usage.input_tokens - last_checkpoint) > coder_context_summary_threshold
    if last_checkpoint == 0 and history_est > (coder_context_summary_threshold * 0.9):
        should_consolidate_1 = True
    
    assert should_consolidate_1 is True

    # CASE 2: step_usage grows past threshold
    step_usage.input_tokens = 300000
    last_checkpoint = 0
    should_consolidate_2 = (step_usage.input_tokens - last_checkpoint) > coder_context_summary_threshold
    assert should_consolidate_2 is True
    
    # Simulate checkpoint update after consolidation
    state["last_summary_checkpoint_1"] = 300000
    
    # CASE 3: added more tokens but not enough to hit next threshold
    step_usage.input_tokens = 400000
    last_checkpoint = state.get("last_summary_checkpoint_1")
    should_consolidate_3 = (step_usage.input_tokens - last_checkpoint) > coder_context_summary_threshold
    assert should_consolidate_3 is False # 100k < 250k
    
    # CASE 4: hit the next threshold block
    step_usage.input_tokens = 600000
    last_checkpoint = state.get("last_summary_checkpoint_1")
    should_consolidate_4 = (step_usage.input_tokens - last_checkpoint) > coder_context_summary_threshold
    assert should_consolidate_4 is True # 300k > 250k


def test_unicode_output_handling():
    # Simulate a command that outputs non-CP1252 characters (e.g. emojis in UTF-8)
    # 0x8F (143) is the byte from the user's error report.
    import subprocess
    import sys
    from pathlib import Path
    from nexcode.agent_runtime.verifier import _run_cmd
    
    # Command that prints the offending byte directly to buffer
    cmd = [sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'Hello \\x8f World\\n'); sys.stdout.flush()"]
    
    # This should no longer crash with UnicodeDecodeError
    code, out = _run_cmd(Path("."), cmd)
    
    assert code == 0
    assert "Hello" in out
    assert "World" in out
