"""CLI interface for scrapurrr."""

from __future__ import annotations

import asyncio
import contextlib
import importlib
import logging
import sys
from pathlib import Path

import click

from scrapurrr import Scrapurrr


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--config", "-c", type=click.Path(exists=True), help="Config file path")
@click.option("--provider", "-p", type=str, help="LLM provider string")
@click.option("--api-key", type=str, help="API key for LLM provider")
@click.pass_context
def main(
    ctx: click.Context, verbose: bool, config: str | None, provider: str | None, api_key: str | None
) -> None:
    """Scrapurrr — agentic web scraper with pluggable LLM providers."""
    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    ctx.ensure_object(dict)
    ctx.obj["config_path"] = Path(config) if config else None
    ctx.obj["provider"] = provider
    ctx.obj["api_key"] = api_key


@main.command()
@click.argument("url")
@click.option(
    "--schema", "-s", required=True, help="Schema as module:Class (e.g., models.py:Product)"
)
@click.option("--output", "-o", type=click.Path(), help="Output file (json or csv)")
@click.option(
    "--format", "fmt", type=click.Choice(["json", "csv"]), default="json", help="Output format"
)
@click.pass_context
def extract(ctx: click.Context, url: str, schema: str, output: str | None, fmt: str) -> None:
    """Extract structured data from a URL."""
    schema_cls = _load_schema(schema)

    async def _run() -> None:
        scraper = Scrapurrr(
            provider=ctx.obj.get("provider"),
            api_key=ctx.obj.get("api_key"),
            config_path=ctx.obj.get("config_path"),
        )
        async with scraper:
            result: object = await scraper.extract(url, schema=schema_cls)
            _output_result(result, output, fmt)

    asyncio.run(_run())


@main.command()
@click.argument("task")
@click.option(
    "--schema", "-s", required=True, help="Schema as module:Class (e.g., models.py:Product)"
)
@click.option("--max-steps", type=int, default=20, help="Maximum agent steps")
@click.option("--output", "-o", type=click.Path(), help="Output file")
@click.option("--format", "fmt", type=click.Choice(["json", "csv"]), default="json")
@click.pass_context
def agent(
    ctx: click.Context, task: str, schema: str, max_steps: int, output: str | None, fmt: str
) -> None:
    """Run autonomous agent to accomplish a scraping task."""
    schema_cls = _load_schema(schema)

    async def _run() -> None:
        scraper = Scrapurrr(
            provider=ctx.obj.get("provider"),
            api_key=ctx.obj.get("api_key"),
            config_path=ctx.obj.get("config_path"),
        )
        async with scraper:
            result: object = await scraper.agent(task, schema=schema_cls, max_steps=max_steps)
            _output_result(result, output, fmt)

    asyncio.run(_run())


@main.command()
@click.argument("urls_file", type=click.Path(exists=True))
@click.option("--schema", "-s", required=True, help="Schema as module:Class")
@click.option("--output", "-o", type=click.Path(), help="Output file")
@click.option("--format", "fmt", type=click.Choice(["json", "csv"]), default="json")
@click.option("--concurrency", type=int, default=5, help="Max concurrent extractions")
@click.pass_context
def batch(
    ctx: click.Context, urls_file: str, schema: str, output: str | None, fmt: str, concurrency: int
) -> None:
    """Extract from multiple URLs listed in a file (one per line)."""
    schema_cls = _load_schema(schema)
    urls = Path(urls_file).read_text().strip().splitlines()
    urls = [u.strip() for u in urls if u.strip()]

    async def _run() -> None:
        scraper = Scrapurrr(
            provider=ctx.obj.get("provider"),
            api_key=ctx.obj.get("api_key"),
            config_path=ctx.obj.get("config_path"),
        )
        async with scraper:
            results: list[object] = await scraper.extract_many(
                urls, schema=schema_cls, concurrency=concurrency
            )
            _output_result(results, output, fmt)

    asyncio.run(_run())


@main.command()
def serve() -> None:
    """Start scrapurrr as an MCP server (stdio)."""
    import asyncio

    from scrapurrr.mcp_server import run_stdio_server

    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(run_stdio_server())


@main.command()
@click.pass_context
def chat(ctx: click.Context) -> None:
    """Interactive scraping session."""
    from scrapurrr.chat.renderer import ChatRenderer
    from scrapurrr.chat.session import ChatSession

    async def _run_chat() -> None:
        scraper = Scrapurrr(
            provider=ctx.obj.get("provider"),
            api_key=ctx.obj.get("api_key"),
            config_path=ctx.obj.get("config_path"),
        )
        renderer = ChatRenderer()
        session = ChatSession(scraper=scraper)

        from scrapurrr import __version__

        renderer.print_header(__version__)

        try:
            await session.start()

            while True:
                user_input = renderer.get_input()
                if user_input is None:
                    break

                if not user_input:
                    continue

                from scrapurrr.chat.commands import parse_command

                cmd = parse_command(user_input)

                if cmd is not None and cmd.action == "exit":
                    break

                if cmd is not None:
                    await renderer.start_shimmer()
                    result = await session.handle(user_input)
                    await renderer.stop_shimmer()

                    if result is None:
                        break
                    if isinstance(result, tuple):
                        response, elements = result
                        renderer.print_text(response.text)
                        if isinstance(elements, tuple):
                            sel_type, els = elements
                            if sel_type == "xpath":
                                renderer.print_text(renderer.format_xpaths(els))
                            else:
                                renderer.print_text(renderer.format_css_selectors(els))
                        else:
                            renderer.print_text(renderer.format_elements(elements))
                    else:
                        renderer.print_text(result.text)
                else:
                    # LLM response — stream it
                    await renderer.start_shimmer()
                    first_token = True
                    async for token in session.stream_respond(user_input):
                        if first_token:
                            await renderer.stop_shimmer()
                            first_token = False
                        renderer.stream_token(token)
                    if first_token:
                        await renderer.stop_shimmer()
                    renderer.end_stream()

        finally:
            await session.close()

    asyncio.run(_run_chat())


def _load_schema(schema_str: str) -> type:
    """Load a Pydantic model class from 'module:ClassName' string."""
    if ":" not in schema_str:
        raise click.BadParameter(f"Schema must be 'module:Class' format, got '{schema_str}'")

    module_path, class_name = schema_str.rsplit(":", 1)

    # Handle file paths (models.py:Product)
    if module_path.endswith(".py"):
        module_path = module_path[:-3]

    # Add current directory to path for local modules
    if "." not in sys.path:
        sys.path.insert(0, ".")

    try:
        module = importlib.import_module(module_path)
        return getattr(module, class_name)  # type: ignore[no-any-return]
    except (ImportError, AttributeError) as exc:
        raise click.BadParameter(f"Could not load {class_name} from {module_path}: {exc}") from exc


_CONFIG_PATH = Path.home() / ".scrapurrr.yaml"


def _ensure_ollama(model: str) -> None:
    """Start ollama if not running, pull model if not installed."""
    import shutil
    import subprocess
    import time
    import urllib.request

    model_name = model.replace("ollama/", "")

    if not shutil.which("ollama"):
        click.echo("\nOllama is not installed.")
        click.echo("  Install: https://ollama.ai")
        raise SystemExit(1)

    # Check if ollama API is actually reachable
    def _is_serving() -> bool:
        try:
            urllib.request.urlopen("http://localhost:11434/api/tags", timeout=3)
            return True
        except Exception:
            return False

    if not _is_serving():
        click.echo("\nStarting ollama...")
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        # Wait for server to be ready
        for _ in range(15):
            time.sleep(1)
            if _is_serving():
                break
        else:
            click.echo("Could not start ollama. Try running 'ollama serve' manually.")
            raise SystemExit(1)

    # Check if model is pulled
    result = subprocess.run(
        ["ollama", "list"],
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )
    if model_name not in result.stdout:
        click.echo(f"\nPulling {model_name}...")
        subprocess.run(
            ["ollama", "pull", model_name],
            check=False,
        )


_MODELS = [
    # Google Gemini (free tier available)
    ("gemini/gemini-2.0-flash", True),
    ("gemini/gemini-2.5-flash-preview-09-2025", True),
    ("gemini/gemini-1.5-pro-latest", True),
    # OpenAI
    ("openai/gpt-4o", True),
    ("openai/gpt-4o-mini", True),
    ("openai/gpt-4.1-mini", True),
    ("openai/o4-mini", True),
    # Anthropic
    ("anthropic/claude-sonnet-4-20250514", True),
    ("anthropic/claude-3-5-sonnet-20240620", True),
    ("anthropic/claude-3-haiku-20240307", True),
    # Groq (free tier, fast)
    ("groq/llama-3.3-70b-versatile", True),
    ("groq/meta-llama/llama-4-scout-17b-16e-instruct", True),
    ("groq/qwen/qwen3-32b", True),
    ("groq/llama-3.1-8b-instant", True),
    # DeepSeek
    ("deepseek/deepseek-chat", True),
    ("deepseek/deepseek-reasoner", True),
    # Cerebras (free tier, very fast)
    ("cerebras/llama3-70b-instruct", True),
    # Local via Ollama (no API key)
    ("ollama/llama3.2", False),
    ("ollama/llama3.1", False),
    ("ollama/qwen2.5", False),
    ("ollama/qwen3", False),
    ("ollama/gemma2", False),
    ("ollama/mistral", False),
    ("ollama/phi3", False),
    ("ollama/deepseek-r1", False),
    ("ollama/codellama", False),
    ("ollama/llava", False),
]

_SLASH_HELP = """\
/help                 Show this list
/model                Switch LLM model
/key                  Update API key
/provider <string>    Set provider directly (e.g. ollama/llama3)
/config               Show current config
/url                  Show current page URL
/history              Show conversation history
/clear                Clear conversation history
/reset                Reset session (new browser page)
/headless             Toggle headless/headed browser
/stealth <level>      Set stealth level (off, basic, full)
/mode <mode>          Set browser mode (auto, always, never)
/proxy <url>          Set proxy (or /proxy off)
/timeout <ms>         Set page load timeout
/useragent            Show current user agent
/cookies              Show browser cookies
/screenshot <file>    Save page screenshot
/html <file>          Save page HTML
/js <code>            Run JavaScript on current page
/elements             List all page elements
/xpath <tag>          Get XPaths for elements (e.g. /xpath button)
/css <tag>            Get CSS selectors for elements
/export <file>        Export conversation to file
exit, quit            End session\
"""


def _load_config() -> dict[str, object]:
    """Load full config from ~/.scrapurrr.yaml."""
    import yaml

    if not _CONFIG_PATH.exists():
        return {}
    try:
        return yaml.safe_load(_CONFIG_PATH.read_text()) or {}
    except Exception:
        return {}


def _save_config_full(data: dict[str, object]) -> None:
    """Save full config dict to ~/.scrapurrr.yaml."""
    import yaml

    _CONFIG_PATH.write_text(yaml.dump(data, default_flow_style=False))


def _get_llm_config() -> tuple[str | None, str | None]:
    """Extract provider and api_key from config."""
    config = _load_config()
    llm = config.get("llm", {})
    if not isinstance(llm, dict):
        return None, None
    return llm.get("provider"), llm.get("api_key")


def _save_llm_config(provider: str, api_key: str | None) -> None:
    """Save provider and api_key, preserving other config."""
    config = _load_config()
    llm: dict[str, str] = {"provider": provider}
    if api_key:
        llm["api_key"] = api_key
    config["llm"] = llm
    _save_config_full(config)


def _select_model() -> tuple[str, str | None]:
    """Interactive model selection with API key prompt."""
    click.echo("Select a model:\n")

    # Group by provider prefix
    current_group = ""
    for i, (model, _) in enumerate(_MODELS, 1):
        provider = model.split("/")[0]
        if provider != current_group:
            current_group = provider
            label = {
                "gemini": "Google Gemini (free tier available)",
                "openai": "OpenAI",
                "anthropic": "Anthropic",
                "groq": "Groq (free tier, fast)",
                "deepseek": "DeepSeek",
                "cerebras": "Cerebras (free tier, very fast)",
                "ollama": "Local via Ollama (no API key)",
            }.get(provider, provider)
            click.echo(f"  {label}:")
        click.echo(f"    {i}. {model}")

    click.echo("")

    while True:
        try:
            choice = input(f"Enter number (1-{len(_MODELS)}): ").strip()
        except (EOFError, KeyboardInterrupt):
            raise SystemExit(0) from None
        if choice.isdigit() and 1 <= int(choice) <= len(_MODELS):
            break
        click.echo("Invalid choice. Try again.")

    model, needs_key = _MODELS[int(choice) - 1]

    api_key = None
    if needs_key:
        click.echo(f"\n{model} requires an API key.")
        try:
            api_key = input("API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            raise SystemExit(0) from None
        if not api_key:
            click.echo("No key provided. Exiting.")
            raise SystemExit(1)
    else:
        _ensure_ollama(model)

    _save_llm_config(model, api_key)
    click.echo(f"\nSaved to {_CONFIG_PATH}\n")
    return model, api_key


async def _handle_slash(  # noqa: C901
    user_input: str,
    session: object,
    renderer: object,
) -> str | None:
    """Handle slash commands. Returns None to continue, 'break' to exit,
    'restart' to rebuild session."""
    from scrapurrr.extraction.element import extract_elements

    parts = user_input.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd == "/help":
        click.echo(_SLASH_HELP)
        return None

    if cmd == "/model":
        return "restart"

    if cmd == "/key":
        try:
            new_key = input("New API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if new_key:
            provider, _ = _get_llm_config()
            _save_llm_config(provider or "ollama/llama3", new_key)
            click.echo(f"API key updated. Saved to {_CONFIG_PATH}")
            return "restart"
        click.echo("No key entered.")
        return None

    if cmd == "/provider":
        if not arg:
            click.echo("Usage: /provider <provider/model>")
            return None
        _, api_key = _get_llm_config()
        _save_llm_config(arg, api_key)
        click.echo(f"Provider set to {arg}. Saved to {_CONFIG_PATH}")
        return "restart"

    if cmd == "/config":
        config = _load_config()
        import yaml

        click.echo(yaml.dump(config, default_flow_style=False).strip())
        return None

    if cmd == "/url":
        url = getattr(session, "_current_url", None) or "No page loaded"
        click.echo(url)
        return None

    if cmd == "/history":
        history = getattr(session, "_history", [])
        if not history:
            click.echo("No history yet.")
            return None
        for msg in history:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            click.echo(f"[{role}] {content[:200]}")
        return None

    if cmd == "/clear":
        if hasattr(session, "_history"):
            session._history.clear()  # type: ignore[union-attr]
        click.echo("History cleared.")
        return None

    if cmd == "/reset":
        return "restart"

    if cmd == "/headless":
        config = _load_config()
        browser = config.get("browser", {})
        if not isinstance(browser, dict):
            browser = {}
        current = browser.get("headless", True)
        browser["headless"] = not current
        config["browser"] = browser
        _save_config_full(config)
        state = "on" if not current else "off"
        click.echo(f"Headless {state}. Restart to apply: /reset")
        return None

    if cmd == "/stealth":
        if arg not in ("off", "basic", "full"):
            click.echo("Usage: /stealth off|basic|full")
            return None
        config = _load_config()
        browser = config.get("browser", {})
        if not isinstance(browser, dict):
            browser = {}
        browser["stealth"] = arg
        config["browser"] = browser
        _save_config_full(config)
        click.echo(f"Stealth set to {arg}. Restart to apply: /reset")
        return None

    if cmd == "/mode":
        if arg not in ("auto", "always", "never"):
            click.echo("Usage: /mode auto|always|never")
            return None
        config = _load_config()
        browser = config.get("browser", {})
        if not isinstance(browser, dict):
            browser = {}
        browser["mode"] = arg
        config["browser"] = browser
        _save_config_full(config)
        click.echo(f"Browser mode set to {arg}. Restart to apply: /reset")
        return None

    if cmd == "/proxy":
        config = _load_config()
        browser = config.get("browser", {})
        if not isinstance(browser, dict):
            browser = {}
        if arg.lower() == "off" or not arg:
            browser.pop("proxy", None)
            click.echo("Proxy cleared. Restart to apply: /reset")
        else:
            browser["proxy"] = arg
            click.echo(f"Proxy set to {arg}. Restart to apply: /reset")
        config["browser"] = browser
        _save_config_full(config)
        return None

    if cmd == "/timeout":
        if not arg.isdigit():
            click.echo("Usage: /timeout <milliseconds>")
            return None
        config = _load_config()
        browser = config.get("browser", {})
        if not isinstance(browser, dict):
            browser = {}
        browser["timeout"] = int(arg)
        config["browser"] = browser
        _save_config_full(config)
        click.echo(f"Timeout set to {arg}ms. Restart to apply: /reset")
        return None

    if cmd == "/useragent":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        ua = await page.evaluate("navigator.userAgent")
        click.echo(ua)
        return None

    if cmd == "/cookies":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        import json

        cookies = await page._page.context.cookies()
        click.echo(json.dumps(cookies, indent=2))
        return None

    if cmd == "/screenshot":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        filename = arg or "screenshot.png"
        data = await page.screenshot()
        Path(filename).write_bytes(data)
        click.echo(f"Saved to {filename}")
        return None

    if cmd == "/html":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        filename = arg or "page.html"
        html = await page.get_html()
        Path(filename).write_text(html)
        click.echo(f"Saved to {filename}")
        return None

    if cmd == "/js":
        if not arg:
            click.echo("Usage: /js <javascript code>")
            return None
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        result = await page.evaluate(arg)
        click.echo(str(result))
        return None

    if cmd == "/elements":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        elements = await extract_elements(page)
        click.echo(renderer.format_elements(elements))  # type: ignore[union-attr]
        return None

    if cmd == "/xpath":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        elements = await extract_elements(page)
        if arg:
            elements = elements.filter(tag=arg)
        click.echo(renderer.format_xpaths(elements))  # type: ignore[union-attr]
        return None

    if cmd == "/css":
        page = getattr(session, "_page", None)
        if page is None:
            click.echo("No page loaded.")
            return None
        elements = await extract_elements(page)
        if arg:
            elements = elements.filter(tag=arg)
        click.echo(renderer.format_css_selectors(elements))  # type: ignore[union-attr]
        return None

    if cmd == "/export":
        filename = arg or "chat_export.txt"
        history = getattr(session, "_history", [])
        lines = []
        for msg in history:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            lines.append(f"[{role}] {content}")
        Path(filename).write_text("\n\n".join(lines))
        click.echo(f"Exported to {filename}")
        return None

    click.echo(f"Unknown command: {cmd}. Type /help for all commands.")
    return None


def chatpurrr() -> None:
    """Interactive scraping chat. Run `chatpurrr` to start."""
    from scrapurrr import Scrapurrr
    from scrapurrr.chat.renderer import ChatRenderer
    from scrapurrr.chat.session import ChatSession

    provider, api_key = _get_llm_config()

    from scrapurrr import __version__

    click.echo(f"scrapurrr v{__version__}\n")

    if provider is None:
        click.echo("No model configured. Let's set one up.\n")
        provider, api_key = _select_model()
    elif provider.startswith("ollama/"):
        _ensure_ollama(provider)

    async def _run() -> None:
        config_path = _CONFIG_PATH if _CONFIG_PATH.exists() else None
        scraper = Scrapurrr(
            provider=provider,
            api_key=api_key,
            config_path=config_path,
        )
        renderer = ChatRenderer()
        session = ChatSession(scraper=scraper)

        try:
            await session.start()

            while True:
                user_input = renderer.get_input()
                if user_input is None:
                    break

                if not user_input:
                    continue

                if user_input.lower() in ("exit", "quit"):
                    break

                # Slash commands
                if user_input.startswith("/"):
                    result = await _handle_slash(user_input, session, renderer)
                    if result == "break":
                        break
                    if result == "restart":
                        await session.close()
                        if user_input.lower() == "/model":
                            new_provider, new_key = _select_model()
                            click.echo(f"Switched to {new_provider}\n")
                        else:
                            new_provider, new_key = _get_llm_config()
                        scraper = Scrapurrr(
                            provider=new_provider,
                            api_key=new_key,
                            config_path=config_path,
                        )
                        session = ChatSession(scraper=scraper)
                        await session.start()
                        click.echo("Session restarted.\n")
                    continue

                from scrapurrr.chat.commands import parse_command

                cmd = parse_command(user_input)

                if cmd is not None and cmd.action == "exit":
                    break

                try:
                    if cmd is not None:
                        await renderer.start_shimmer()
                        result_data = await session.handle(user_input)
                        await renderer.stop_shimmer()

                        if result_data is None:
                            break
                        if isinstance(result_data, tuple):
                            response, elements = result_data
                            renderer.print_text(response.text)
                            if isinstance(elements, tuple):
                                sel_type, els = elements
                                if sel_type == "xpath":
                                    renderer.print_text(renderer.format_xpaths(els))
                                else:
                                    renderer.print_text(renderer.format_css_selectors(els))
                            else:
                                renderer.print_text(renderer.format_elements(elements))
                        else:
                            renderer.print_text(result_data.text)
                    else:
                        await renderer.start_shimmer()
                        first_token = True
                        async for token in session.stream_respond(user_input):
                            if first_token:
                                await renderer.stop_shimmer()
                                first_token = False
                            renderer.stream_token(token)
                        if first_token:
                            await renderer.stop_shimmer()
                        renderer.end_stream()
                except Exception as exc:
                    await renderer.stop_shimmer()
                    renderer.print_text(f"\nError: {exc}\n")

        finally:
            await session.close()

    with contextlib.suppress(KeyboardInterrupt, EOFError, SystemExit):
        asyncio.run(_run())
    click.echo("\nthank you!")


def _output_result(result: object, output: str | None, fmt: str) -> None:
    """Output result to file or stdout."""
    from scrapurrr.storage.export import to_csv_str, to_json_str

    text = to_csv_str(result) if fmt == "csv" else to_json_str(result)

    if output:
        Path(output).write_text(text)
        click.echo(f"Written to {output}")
    else:
        click.echo(text)
