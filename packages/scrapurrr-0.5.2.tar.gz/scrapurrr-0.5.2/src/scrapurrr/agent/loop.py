"""ReAct agent loop — Think, Act, Observe."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, TypeVar, cast, get_args

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory
from scrapurrr.core.exceptions import AgentError, MaxStepsError, StuckError
from scrapurrr.core.schemas import SchemaHelper

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from scrapurrr.agent.tools import ToolRegistry
    from scrapurrr.core.types import LLMProvider

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class AgentStep:
    number: int
    tool: str
    params: dict[str, Any]
    result: str
    extracted_count: int


_SYSTEM_PROMPT = """\
You are an expert web scraping agent. You navigate websites to find and extract specific data.

## Available Tools
{tools}

## How to Respond
Respond with JSON: {{"tool": "<name>", "params": {{...}}}}
To finish: {{"tool": "done", "params": {{}}}}

## Strategy
1. ALWAYS start with read_page to understand page structure
2. Use inspect_elements to find exact CSS selectors and XPaths
3. For data behind pagination, follow "next" links or increment page numbers
4. For lazy-loaded content, use load_all to scroll and load content
5. Dismiss cookie/consent dialogs if they block content
6. If a selector fails, use inspect_elements to find alternatives
7. Try CSS extraction first (free, fast), fall back to LLM extraction
8. For forms, use fill_form to type into multiple fields at once

## Anti-Detection
- Scroll naturally before extracting (simulates human reading)
- Wait between rapid actions
- Don't visit the same URL more than twice

## Error Recovery
- If an element is not found, use inspect_elements to find what's actually on the page
- If a page times out, try navigating to a simpler URL
- If stuck, try a completely different approach

## Data Collection
- Extract data progressively — don't wait until you have everything
- Validate extracted data matches the schema
- If data is spread across pages, navigate and collect from each

## Rules
- One tool per step
- Always respond with valid JSON
- Report done when you have sufficient data
- Be efficient — minimize unnecessary navigation
"""

_USER_PROMPT = """\
## Goal
{goal}

## Target Schema
{schema}

## Current State
- URL: {current_url}
- Data extracted: {extracted_count} items
- Steps taken: {step_count}/{max_steps} (budget remaining: {steps_remaining})

## Page Summary (simplified DOM)
{dom_summary}

## Data Collected
{extracted_data}

## Recent Actions
{recent_actions}

## Page Knowledge
{page_knowledge}

## Failed Selectors (avoid these)
{failed_selectors}

## Suggestions
{suggestions}

Choose your next action. Respond with JSON only.
"""


class AgentLoop:
    def __init__(
        self,
        provider: LLMProvider,
        tools: ToolRegistry,
        schema: type[T],
        max_steps: int = 20,
    ) -> None:
        self._provider = provider
        self._tools = tools
        self._schema = schema
        self._max_steps = max_steps

    async def run(self, goal: str, timeout: int | None = None) -> T:
        async def _run_loop(goal: str) -> T:
            memory = AgentMemory(goal=goal, schema=self._schema)
            system = _SYSTEM_PROMPT.format(tools=self._tools.describe_tools())

            for _ in range(self._max_steps):
                if memory.step_count >= 3 and memory.is_stuck():
                    raise StuckError(
                        f"Agent is stuck after {memory.step_count} steps. "
                        f"History: {[a.tool for a in memory.recent_actions()]}"
                    )

                user_prompt = self._build_user_prompt(memory, goal)

                response = await self._provider.complete(user_prompt, system_prompt=system)

                # Parse tool call
                tool_name, tool_params = self._parse_response(response, memory)
                if tool_name is None:
                    continue

                logger.info("Agent step %d: tool=%s", memory.step_count + 1, tool_name)

                # DONE check
                if tool_name == "done":
                    if memory.extracted_data:
                        return cast("T", self._finalize(memory))
                    # Give better guidance instead of just continuing
                    memory.record_action(
                        AgentAction(
                            tool="done",
                            params={},
                            result="No data extracted yet. Try read_page or extract first,"
                            " then use inspect_elements to find data containers.",
                            timestamp=time.time(),
                            success=False,
                        )
                    )
                    continue

                # ACT — with intelligent error recovery
                result, success = await self._execute_tool(tool_name, tool_params, memory)

                # OBSERVE
                action = AgentAction(
                    tool=tool_name,
                    params=tool_params,
                    result=str(result)[:500],
                    timestamp=time.time(),
                    success=success,
                )
                memory.record_action(action)

                # Auto-record page knowledge after navigate
                if tool_name == "navigate" and success:
                    url = tool_params.get("url", "")
                    memory.record_visit(url)
                    memory.strategies_tried.append("navigate")

                # Record failures
                if not success:
                    selector = tool_params.get("selector")
                    memory.record_failure(tool_name, selector, str(result))

                # Try parsing extraction results
                if tool_name in ("extract", "smart_extract") and success:
                    self._try_parse_extraction(result, memory)
                    memory.strategies_tried.append(
                        "css_extraction" if tool_name == "extract" else "llm_extraction"
                    )
                    logger.debug("Agent extracted data: %d items", len(memory.extracted_data))

                # Retry logic: if extraction fails, suggest inspect_elements
                if (
                    tool_name in ("extract", "smart_extract")
                    and not memory.extracted_data
                    and "inspect_elements" not in [a.tool for a in memory.recent_actions(3)]
                ):
                    logger.debug("Extraction yielded no data — agent should try inspect_elements")

            raise MaxStepsError(f"Agent did not complete within {self._max_steps} steps")

        if timeout:
            try:
                async with asyncio.timeout(timeout):
                    return await _run_loop(goal)
            except TimeoutError:
                raise AgentError(f"Agent timed out after {timeout} seconds") from None
        return await _run_loop(goal)

    async def run_stream(
        self, goal: str, timeout: int | None = None
    ) -> AsyncIterator[AgentStep | T]:
        """Yield AgentStep for each action; final yield is the extracted result."""

        async def _stream_loop() -> AsyncIterator[AgentStep | T]:
            memory = AgentMemory(goal=goal, schema=self._schema)
            system = _SYSTEM_PROMPT.format(tools=self._tools.describe_tools())

            for _ in range(self._max_steps):
                if memory.step_count >= 3 and memory.is_stuck():
                    raise StuckError(
                        f"Agent is stuck after {memory.step_count} steps. "
                        f"History: {[a.tool for a in memory.recent_actions()]}"
                    )

                user_prompt = self._build_user_prompt(memory, goal)

                response = await self._provider.complete(user_prompt, system_prompt=system)

                tool_name, tool_params = self._parse_response(response, memory)
                if tool_name is None:
                    continue

                logger.info("Agent step %d: tool=%s", memory.step_count + 1, tool_name)

                if tool_name == "done":
                    if memory.extracted_data:
                        result = cast("T", self._finalize(memory))
                        yield result
                        return
                    memory.record_action(
                        AgentAction(
                            tool="done",
                            params={},
                            result="No data extracted yet. Try read_page or extract first.",
                            timestamp=time.time(),
                            success=False,
                        )
                    )
                    continue

                # ACT — with intelligent error recovery
                result_str, success = await self._execute_tool(tool_name, tool_params, memory)

                action = AgentAction(
                    tool=tool_name,
                    params=tool_params,
                    result=str(result_str)[:500],
                    timestamp=time.time(),
                    success=success,
                )
                memory.record_action(action)

                if tool_name == "navigate" and success:
                    url = tool_params.get("url", "")
                    memory.record_visit(url)

                if not success:
                    selector = tool_params.get("selector")
                    memory.record_failure(tool_name, selector, str(result_str))

                if tool_name in ("extract", "smart_extract") and success:
                    self._try_parse_extraction(result_str, memory)

                yield AgentStep(
                    number=memory.step_count,
                    tool=tool_name,
                    params=tool_params,
                    result=str(result_str)[:500],
                    extracted_count=len(memory.extracted_data),
                )

            raise MaxStepsError(f"Agent did not complete within {self._max_steps} steps")

        if timeout:
            # Wrap streaming with timeout by consuming and re-yielding
            queue: asyncio.Queue[AgentStep | T | Exception] = asyncio.Queue()

            async def _fill_queue() -> None:
                try:
                    async for item in _stream_loop():
                        await queue.put(item)
                    await queue.put(StopAsyncIteration())
                except Exception as exc:
                    await queue.put(exc)

            task = asyncio.create_task(_fill_queue())
            deadline = asyncio.get_event_loop().time() + timeout
            try:
                while True:
                    remaining = deadline - asyncio.get_event_loop().time()
                    if remaining <= 0:
                        task.cancel()
                        raise AgentError(f"Agent timed out after {timeout} seconds")
                    item = await asyncio.wait_for(queue.get(), timeout=remaining)
                    if isinstance(item, StopAsyncIteration):
                        return
                    if isinstance(item, Exception):
                        raise item
                    yield item
            except TimeoutError:
                task.cancel()
                raise AgentError(f"Agent timed out after {timeout} seconds") from None
        else:
            async for item in _stream_loop():
                yield item

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_user_prompt(self, memory: AgentMemory, goal: str) -> str:
        """Build the user prompt with full memory context."""
        # Context compaction for long runs
        if memory.step_count > 10:
            history_summary = memory.compact_history(keep_recent=5)
            recent_actions = _serialize_actions(memory.recent_actions(limit=5))
            actions_text = f"Earlier: {history_summary}\nRecent: {recent_actions}"
        else:
            actions_text = _serialize_actions(memory.recent_actions(limit=10))

        # Page knowledge summary
        page_knowledge_parts = []
        for url, pk in list(memory.page_knowledge.items())[-3:]:
            page_knowledge_parts.append(
                f"- {pk.title or url}: {pk.element_count} elements"
                f"{', has pagination' if pk.has_pagination else ''}"
                f"{f', selectors: {pk.key_selectors}' if pk.key_selectors else ''}"
            )
        page_knowledge_text = "\n".join(page_knowledge_parts) if page_knowledge_parts else "none"

        # Failed selectors
        failed_selectors_text = (
            ", ".join(list(memory.failed_selectors)[-10:]) if memory.failed_selectors else "none"
        )

        # Suggestions
        suggestions_text = memory.get_suggestions() or "none"

        return _USER_PROMPT.format(
            goal=goal,
            schema=json.dumps(SchemaHelper.to_json_schema(self._schema), indent=2),
            extracted_data=_serialize_extractions(memory.extracted_data),
            current_url=memory.current_url or "none",
            extracted_count=len(memory.extracted_data),
            step_count=memory.step_count,
            max_steps=self._max_steps,
            steps_remaining=self._max_steps - memory.step_count,
            dom_summary=memory.current_page_summary or "Navigate to a page first.",
            recent_actions=actions_text,
            page_knowledge=page_knowledge_text,
            failed_selectors=failed_selectors_text,
            suggestions=suggestions_text,
        )

    def _parse_response(
        self, response: str, memory: AgentMemory
    ) -> tuple[str | None, dict[str, Any]]:
        """Parse tool call from LLM response. Returns (tool_name, params) or (None, {})."""
        try:
            parsed = json.loads(response)
            tool_name = parsed["tool"]
            tool_params = parsed.get("params", {})
            return tool_name, tool_params
        except (json.JSONDecodeError, KeyError):
            logger.warning("Agent parse error: %s", response[:100])
            memory.record_action(
                AgentAction(
                    tool="parse_error",
                    params={},
                    result=f"Could not parse: {response[:200]}",
                    timestamp=time.time(),
                    success=False,
                )
            )
            return None, {}

    async def _execute_tool(
        self, tool_name: str, tool_params: dict[str, Any], memory: AgentMemory
    ) -> tuple[str, bool]:
        """Execute a tool and return (result, success)."""
        try:
            result = await self._tools.execute(tool_name, tool_params)
            return str(result), True
        except KeyError:
            avail = ", ".join(self._tools.tool_names())
            return f"Error: Unknown tool '{tool_name}'. Available: {avail}", False
        except Exception as exc:
            error_msg = str(exc)
            if "timeout" in error_msg.lower():
                return (
                    "Error: Page timed out. Try waiting or navigating to a simpler page.",
                    False,
                )
            if "selector" in error_msg.lower() or "not found" in error_msg.lower():
                return (
                    "Error: Element not found. Try read_page"
                    " to see current page content, then use"
                    " a different selector.",
                    False,
                )
            return f"Error: {error_msg}. Consider trying a different approach.", False

    def _finalize(self, memory: AgentMemory) -> BaseModel:
        if len(memory.extracted_data) == 1:
            return memory.extracted_data[0]

        if SchemaHelper.is_list_type(self._schema):
            return cast(
                "BaseModel",
                SchemaHelper.validate(
                    [d.model_dump() for d in memory.extracted_data],
                    self._schema,
                ),
            )

        return memory.extracted_data[-1]

    def _try_parse_extraction(self, result: str, memory: AgentMemory) -> None:
        try:
            parsed = json.loads(result)
            inner = self._get_inner_schema()
            if isinstance(parsed, list):
                for item in parsed:
                    validated = inner.model_validate(item)
                    memory.record_extraction(validated)
            else:
                validated = inner.model_validate(parsed)
                memory.record_extraction(validated)
        except Exception as exc:
            logger.warning("Extraction parse failed: %s", exc)

    def _get_inner_schema(self) -> type[BaseModel]:
        if SchemaHelper.is_list_type(self._schema):
            return cast("type[BaseModel]", get_args(self._schema)[0])
        return cast("type[BaseModel]", self._schema)


def _serialize_extractions(data: list[BaseModel]) -> str:
    if not data:
        return "none"
    return json.dumps([d.model_dump() for d in data[:10]])


def _serialize_actions(actions: list[AgentAction]) -> str:
    if not actions:
        return "none"
    return json.dumps([{"tool": a.tool, "params": a.params} for a in actions])
