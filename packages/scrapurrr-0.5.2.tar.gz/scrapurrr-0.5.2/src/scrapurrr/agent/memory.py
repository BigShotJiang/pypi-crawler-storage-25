"""Short-term memory for agent runs."""

from __future__ import annotations

import time
from collections import Counter
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel


@dataclass(frozen=True)
class AgentAction:
    tool: str
    params: dict[str, Any]
    result: str
    timestamp: float = field(default_factory=time.time)
    success: bool = True


@dataclass(frozen=True)
class PageKnowledge:
    url: str
    title: str
    element_count: int
    has_pagination: bool
    key_selectors: dict[str, str]
    content_summary: str


class AgentMemory:
    def __init__(self, goal: str, schema: type[BaseModel]) -> None:
        self.goal = goal
        self.schema = schema
        self.visited_urls: list[str] = []
        self.extracted_data: list[BaseModel] = []
        self.action_history: list[AgentAction] = []
        self.current_url: str | None = None
        self.current_page_summary: str | None = None
        self.step_count: int = 0
        self._extraction_count_at_step: dict[int, int] = {}

        # Page knowledge — what the agent has learned about each page
        self.page_knowledge: dict[str, PageKnowledge] = {}

        # Error tracking — avoid repeating mistakes
        self.failed_selectors: set[str] = set()
        self.failed_urls: set[str] = set()

        # Strategy tracking
        self.strategies_tried: list[str] = []

    def record_action(self, action: AgentAction) -> None:
        self.action_history.append(action)
        self.step_count += 1
        self._extraction_count_at_step[self.step_count] = len(self.extracted_data)

    def record_visit(self, url: str) -> None:
        self.visited_urls.append(url)
        self.current_url = url

    def record_extraction(self, data: BaseModel) -> None:
        self.extracted_data.append(data)

    def is_visited(self, url: str) -> bool:
        return url in self.visited_urls

    def is_stuck(self) -> bool:
        if self._url_visited_too_many_times():
            return True
        if self._repeated_consecutive_actions():
            return True
        return bool(self._no_progress_in_recent_steps())

    def recent_actions(self, limit: int = 10) -> list[AgentAction]:
        return self.action_history[-limit:]

    # ------------------------------------------------------------------
    # Page knowledge
    # ------------------------------------------------------------------

    def record_page_knowledge(
        self,
        url: str,
        title: str,
        element_count: int,
        has_pagination: bool,
        key_selectors: dict[str, str],
        content_summary: str = "",
    ) -> None:
        """Store what we learned about a page for later use."""
        self.page_knowledge[url] = PageKnowledge(
            url=url,
            title=title,
            element_count=element_count,
            has_pagination=has_pagination,
            key_selectors=dict(key_selectors),
            content_summary=content_summary,
        )

    def get_page_knowledge(self, url: str) -> PageKnowledge | None:
        """Retrieve knowledge about a previously visited page."""
        return self.page_knowledge.get(url)

    # ------------------------------------------------------------------
    # Failure tracking
    # ------------------------------------------------------------------

    def record_failure(self, tool: str, selector: str | None, error: str) -> None:
        """Record a failed action so we don't repeat it."""
        if selector:
            self.failed_selectors.add(selector)
        if tool == "navigate" and error:
            # Extract URL from params of the last action if available
            for action in reversed(self.action_history):
                if action.tool == "navigate":
                    url = action.params.get("url", "")
                    if url:
                        self.failed_urls.add(url)
                    break

    # ------------------------------------------------------------------
    # Suggestions
    # ------------------------------------------------------------------

    def get_suggestions(self) -> str:
        """Generate smart suggestions based on history."""
        suggestions: list[str] = []

        if self.failed_selectors:
            failed = ", ".join(list(self.failed_selectors)[-5:])
            suggestions.append(
                f"These selectors failed: {failed}. Try inspect_elements to find alternatives."
            )

        # Check if any page has pagination
        for knowledge in self.page_knowledge.values():
            if knowledge.has_pagination:
                suggestions.append(
                    f"Pagination detected on {knowledge.url}. Consider following next page links."
                )

        if self.step_count >= 5 and not self.extracted_data:
            suggestions.append(
                "No data extracted after several steps. Try a different strategy:"
                " use smart_extract with a focused query,"
                " or inspect_elements to find data containers."
            )

        if self.failed_urls:
            failed = ", ".join(list(self.failed_urls)[-3:])
            suggestions.append(f"These URLs failed: {failed}. Avoid them.")

        strategies = set(self.strategies_tried)
        if "css_extraction" in strategies and "llm_extraction" not in strategies:
            suggestions.append(
                "CSS extraction was tried. Consider using LLM extraction as fallback."
            )

        return "\n".join(suggestions) if suggestions else ""

    # ------------------------------------------------------------------
    # Stuck detection
    # ------------------------------------------------------------------

    def _url_visited_too_many_times(self) -> bool:
        counts = Counter(self.visited_urls)
        return any(count >= 3 for count in counts.values())

    def _repeated_consecutive_actions(self) -> bool:
        if len(self.action_history) < 2:
            return False
        last = self.action_history[-1]
        prev = self.action_history[-2]
        return last.tool == prev.tool and last.params == prev.params

    def _no_progress_in_recent_steps(self) -> bool:
        if self.step_count < 5:
            return False
        current_extractions = len(self.extracted_data)
        step_5_ago = self.step_count - 4
        extractions_then = self._extraction_count_at_step.get(step_5_ago, 0)
        return current_extractions == extractions_then

    # ------------------------------------------------------------------
    # Context compaction
    # ------------------------------------------------------------------

    def compact_history(self, keep_recent: int = 5) -> str:
        """Summarize old actions, keep recent ones intact.

        Returns summary string including page knowledge and failures.
        """
        if len(self.action_history) <= keep_recent:
            return ""

        old_actions = self.action_history[:-keep_recent]
        summary_parts = []

        # Group by URL visits
        urls_visited = []
        tools_used: dict[str, int] = {}
        for action in old_actions:
            if action.tool == "navigate":
                url = action.params.get("url", "unknown")
                urls_visited.append(url)
            tools_used[action.tool] = tools_used.get(action.tool, 0) + 1

        if urls_visited:
            summary_parts.append(f"Visited: {', '.join(urls_visited[-5:])}")

        tool_summary = ", ".join(f"{k}x{v}" for k, v in tools_used.items())
        summary_parts.append(f"Actions: {tool_summary}")

        # Include page knowledge
        if self.page_knowledge:
            pages = []
            for url, knowledge in list(self.page_knowledge.items())[-3:]:
                pages.append(
                    f"{knowledge.title or url} ({knowledge.element_count} elements"
                    f"{', has pagination' if knowledge.has_pagination else ''})"
                )
            summary_parts.append(f"Pages learned: {'; '.join(pages)}")

        # Include failures
        if self.failed_selectors:
            failed = ", ".join(list(self.failed_selectors)[-5:])
            summary_parts.append(f"Failed selectors: {failed}")

        if self.failed_urls:
            failed = ", ".join(list(self.failed_urls)[-3:])
            summary_parts.append(f"Failed URLs: {failed}")

        return " | ".join(summary_parts)

    # ------------------------------------------------------------------
    # Serialization for checkpointing
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "visited_urls": self.visited_urls,
            "extracted_data": [d.model_dump() for d in self.extracted_data],
            "step_count": self.step_count,
            "current_url": self.current_url,
            "failed_selectors": list(self.failed_selectors),
            "failed_urls": list(self.failed_urls),
            "strategies_tried": self.strategies_tried,
            "page_knowledge": {
                url: {
                    "url": pk.url,
                    "title": pk.title,
                    "element_count": pk.element_count,
                    "has_pagination": pk.has_pagination,
                    "key_selectors": pk.key_selectors,
                    "content_summary": pk.content_summary,
                }
                for url, pk in self.page_knowledge.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any], schema: type[BaseModel]) -> AgentMemory:
        memory = cls(goal=data["goal"], schema=schema)
        memory.visited_urls = data.get("visited_urls", [])
        memory.step_count = data.get("step_count", 0)
        memory.current_url = data.get("current_url")
        memory.failed_selectors = set(data.get("failed_selectors", []))
        memory.failed_urls = set(data.get("failed_urls", []))
        memory.strategies_tried = data.get("strategies_tried", [])
        for item_data in data.get("extracted_data", []):
            memory.extracted_data.append(schema.model_validate(item_data))
        for url, pk_data in data.get("page_knowledge", {}).items():
            memory.page_knowledge[url] = PageKnowledge(
                url=pk_data["url"],
                title=pk_data["title"],
                element_count=pk_data["element_count"],
                has_pagination=pk_data["has_pagination"],
                key_selectors=pk_data["key_selectors"],
                content_summary=pk_data.get("content_summary", ""),
            )
        return memory
