"""Deep crawler — pluggable strategies, URL filters, and streaming support."""

from __future__ import annotations

import asyncio
import fnmatch
import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeVar
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from pydantic import BaseModel

from scrapurrr.pipeline.cleaner import clean

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from scrapurrr.core.crawl_config import CrawlConfig
    from scrapurrr.core.types import FetchResult

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CrawlResult:
    url: str
    html: str
    markdown: str
    depth: int
    links: tuple[str, ...]


# ---------------------------------------------------------------------------
# Link helpers
# ---------------------------------------------------------------------------


def _extract_links(html: str, base_url: str) -> tuple[str, ...]:
    """Extract and resolve all anchor href links from HTML."""
    soup = BeautifulSoup(html, "html.parser")
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if isinstance(href, list):
            href = href[0]
        resolved = urljoin(base_url, href)
        parsed = urlparse(resolved)
        if parsed.scheme in ("http", "https"):
            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"
            links.append(clean_url)
    return tuple(dict.fromkeys(links))


def _is_same_domain(url: str, reference_url: str) -> bool:
    """Check if url belongs to the same domain as reference_url."""
    return urlparse(url).netloc == urlparse(reference_url).netloc


# ---------------------------------------------------------------------------
# Crawl strategies
# ---------------------------------------------------------------------------


class CrawlStrategy(ABC):
    """Base class for crawl strategies."""

    @abstractmethod
    async def get_next_urls(
        self,
        current_url: str,
        found_links: list[str],
        visited: set[str],
        depth: int,
    ) -> list[str]:
        """Return ordered list of URLs to crawl next."""


class BFSCrawlStrategy(CrawlStrategy):
    """Breadth-first: all links at current depth before going deeper."""

    async def get_next_urls(
        self,
        current_url: str,
        found_links: list[str],
        visited: set[str],
        depth: int,
    ) -> list[str]:
        return [link for link in found_links if link not in visited]


class DFSCrawlStrategy(CrawlStrategy):
    """Depth-first: follow first link as deep as possible, then backtrack."""

    async def get_next_urls(
        self,
        current_url: str,
        found_links: list[str],
        visited: set[str],
        depth: int,
    ) -> list[str]:
        # Reverse so first link ends up on top of the stack
        return [link for link in reversed(found_links) if link not in visited]


class BestFirstCrawlStrategy(CrawlStrategy):
    """Score-based: prioritize URLs by keyword relevance."""

    def __init__(
        self,
        keywords: list[str],
        weights: dict[str, float] | None = None,
    ) -> None:
        self._keywords = [kw.lower() for kw in keywords]
        self._weights = {k.lower(): v for k, v in (weights or {}).items()}

    def _score(self, url: str) -> float:
        url_lower = url.lower()
        score = 0.0
        for kw in self._keywords:
            if kw in url_lower:
                score += self._weights.get(kw, 1.0)
        return score

    async def get_next_urls(
        self,
        current_url: str,
        found_links: list[str],
        visited: set[str],
        depth: int,
    ) -> list[str]:
        unvisited = [link for link in found_links if link not in visited]
        return sorted(unvisited, key=self._score, reverse=True)


# ---------------------------------------------------------------------------
# URL filters
# ---------------------------------------------------------------------------


class URLFilter(ABC):
    """Base filter."""

    @abstractmethod
    def accept(self, url: str) -> bool: ...


class PatternFilter(URLFilter):
    """Wildcard/regex URL filter."""

    def __init__(self, patterns: list[str]) -> None:
        self._patterns: list[re.Pattern[str]] = []
        for p in patterns:
            # Treat patterns with * or ? as glob, otherwise as regex
            if "*" in p or "?" in p:
                self._patterns.append(re.compile(fnmatch.translate(p)))
            else:
                self._patterns.append(re.compile(p))

    def accept(self, url: str) -> bool:
        return any(pat.search(url) for pat in self._patterns)


class DomainFilter(URLFilter):
    """Allow/block specific domains."""

    def __init__(
        self,
        allowed: list[str] | None = None,
        blocked: list[str] | None = None,
    ) -> None:
        self._allowed = set(allowed) if allowed else None
        self._blocked = set(blocked) if blocked else set()

    def accept(self, url: str) -> bool:
        domain = urlparse(url).netloc
        if domain in self._blocked:
            return False
        if self._allowed is not None:
            return domain in self._allowed
        return True


class FilterChain:
    """Compose multiple filters — URL must pass ALL filters."""

    def __init__(self, filters: list[URLFilter]) -> None:
        self._filters = filters

    def accept(self, url: str) -> bool:
        return all(f.accept(url) for f in self._filters)


# ---------------------------------------------------------------------------
# DeepCrawler
# ---------------------------------------------------------------------------


class DeepCrawler:
    """Crawler that follows links using pluggable strategies and filters."""

    def __init__(
        self,
        scraper: object,
        max_depth: int = 3,
        max_pages: int = 50,
        same_domain: bool = True,
        url_pattern: str | None = None,
        config: CrawlConfig | None = None,
        strategy: CrawlStrategy | None = None,
        filters: list[URLFilter] | None = None,
    ) -> None:
        # CrawlConfig overrides take priority over explicit params
        if config is not None:
            max_depth = config.max_depth if config.max_depth > 0 else max_depth
            max_pages = config.max_pages
            same_domain = config.same_domain
            url_pattern = config.url_pattern

        self._scraper = scraper
        self._max_depth = max_depth
        self._max_pages = max_pages
        self._same_domain = same_domain
        self._url_pattern: re.Pattern[str] | None = re.compile(url_pattern) if url_pattern else None
        self._strategy = strategy or BFSCrawlStrategy()
        self._filter_chain = FilterChain(filters) if filters else None

    def _should_visit(self, url: str, start_url: str) -> bool:
        """Determine if a URL should be visited based on filters."""
        if self._same_domain and not _is_same_domain(url, start_url):
            return False
        if self._url_pattern and not self._url_pattern.search(url):
            return False
        return not (self._filter_chain and not self._filter_chain.accept(url))

    async def crawl(self, start_url: str) -> list[CrawlResult]:
        """Crawl from start_url using the configured strategy."""
        results: list[CrawlResult] = []
        async for result in self.crawl_stream(start_url):
            results.append(result)
        return results

    async def crawl_stream(self, start_url: str) -> AsyncIterator[CrawlResult]:
        """Stream crawl results as they're discovered."""
        visited: set[str] = set()
        count = 0

        if isinstance(self._strategy, DFSCrawlStrategy):
            # DFS uses a stack
            stack: list[tuple[str, int]] = [(start_url, 0)]
            while stack and count < self._max_pages:
                url, depth = stack.pop()
                if url in visited or depth > self._max_depth:
                    continue
                visited.add(url)

                result = await self._fetch_and_process(url, depth, count)
                if result is None:
                    continue
                count += 1
                yield result

                if depth < self._max_depth:
                    next_urls = await self._strategy.get_next_urls(
                        url,
                        list(result.links),
                        visited,
                        depth,
                    )
                    filtered = [u for u in next_urls if self._should_visit(u, start_url)]
                    stack.extend((u, depth + 1) for u in filtered)
        else:
            # BFS / BestFirst use a queue
            queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
            await queue.put((start_url, 0))

            while not queue.empty() and count < self._max_pages:
                url, depth = await queue.get()
                if url in visited or depth > self._max_depth:
                    continue
                visited.add(url)

                result = await self._fetch_and_process(url, depth, count)
                if result is None:
                    continue
                count += 1
                yield result

                if depth < self._max_depth:
                    next_urls = await self._strategy.get_next_urls(
                        url,
                        list(result.links),
                        visited,
                        depth,
                    )
                    filtered = [u for u in next_urls if self._should_visit(u, start_url)]
                    for u in filtered:
                        await queue.put((u, depth + 1))

        logger.info("Crawl complete: %d pages collected", count)

    async def _fetch_and_process(
        self,
        url: str,
        depth: int,
        current_count: int,
    ) -> CrawlResult | None:
        logger.info(
            "Crawling [depth=%d] %s (%d/%d)",
            depth,
            url,
            current_count + 1,
            self._max_pages,
        )
        try:
            fetch_result: FetchResult = await self._scraper._do_fetch(url)  # type: ignore[attr-defined]
        except Exception as exc:
            logger.warning("Failed to fetch %s: %s", url, exc)
            return None

        clean_result = clean(fetch_result.html)
        links = _extract_links(fetch_result.html, url)

        return CrawlResult(
            url=url,
            html=fetch_result.html,
            markdown=clean_result.markdown,
            depth=depth,
            links=links,
        )

    async def crawl_and_extract(self, start_url: str, schema: type[T]) -> list[T]:
        """Crawl and extract structured data from each page."""
        crawl_results = await self.crawl(start_url)
        extracted: list[T] = []

        extractor = self._scraper._extractor  # type: ignore[attr-defined]
        tasks = [extractor.extract(cr.html, schema) for cr in crawl_results]
        raw_results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in raw_results:
            if not isinstance(result, Exception):
                extracted.append(result)  # type: ignore[arg-type]
            else:
                logger.warning("Extraction failed for a page: %s", result)

        return extracted
