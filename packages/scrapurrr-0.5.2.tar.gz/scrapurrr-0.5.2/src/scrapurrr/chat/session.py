"""ChatSession — agentic chat with tool-calling loop."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from scrapurrr.agent.dom import simplify_dom
from scrapurrr.chat.commands import parse_command
from scrapurrr.extraction.element import extract_elements
from scrapurrr.pipeline.cleaner import clean

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from scrapurrr import Scrapurrr
    from scrapurrr.extraction.element import ElementCollection

logger = logging.getLogger(__name__)

_MAX_TOOL_STEPS = 8

_SYSTEM_PROMPT = """\
You are scrapurrr, a web scraping assistant with a live browser.
You have already navigated to a page. The page content is below.

RULES:
- Answer ONLY from the page data provided below. Do NOT make up data.
- If you cannot find the requested information in the page content, say so.
- NEVER suggest code, scripts, or tools to the user.
- NEVER mention Selenium, Playwright, BeautifulSoup, or any library.
- Be concise. No emojis.
- If asked for selectors/XPaths, use the element data below.

{context}
"""


@dataclass
class ChatResponse:
    text: str
    is_streaming: bool = False


class ChatSession:
    """Agentic chat session with tool-calling loop."""

    def __init__(self, scraper: Scrapurrr) -> None:
        self._scraper = scraper
        self._page: Any = None
        self._history: list[dict[str, str]] = []
        self._current_url: str | None = None

    @property
    def history(self) -> list[dict[str, str]]:
        return list(self._history)

    async def start(self) -> None:
        await self._scraper._ensure_launched()
        self._page = await self._scraper._get_page()

    async def close(self) -> None:
        if self._page is not None:
            await self._scraper._release_page(self._page)
        await self._scraper.close()

    # ------------------------------------------------------------------
    # Message routing
    # ------------------------------------------------------------------

    async def handle(
        self, user_input: str
    ) -> (
        ChatResponse
        | tuple[ChatResponse, ElementCollection]
        | tuple[ChatResponse, tuple[str, ElementCollection]]
        | None
    ):
        cmd = parse_command(user_input)

        if cmd is None:
            return await self._smart_respond(user_input)

        if cmd.action == "exit":
            return None

        if cmd.action == "navigate":
            url = cmd.args["url"]
            await self._page.navigate(url)
            self._current_url = url
            self._history.append({"role": "user", "content": user_input})
            return ChatResponse(text=f"Navigated to {url}")

        if cmd.action == "back":
            await self._page.go_back()
            return ChatResponse(text="Went back to previous page")

        if cmd.action == "scroll":
            direction = cmd.args["direction"]
            await self._page.scroll(direction)
            return ChatResponse(text=f"Scrolled {direction}")

        if cmd.action == "click":
            selector = cmd.args["selector"]
            await self._page.click(selector)
            return ChatResponse(text=f"Clicked {selector}")

        if cmd.action == "find":
            text = cmd.args["text"]
            collection = await extract_elements(self._page)
            filtered = collection.filter(text=text)
            return (
                ChatResponse(text=f"Found {len(filtered)} element(s) matching '{text}'"),
                filtered,
            )

        if cmd.action == "get_elements":
            collection = await extract_elements(self._page)
            return (
                ChatResponse(text=f"Found {len(collection)} element(s) on page"),
                collection,
            )

        if cmd.action == "get_selectors":
            selector_type = cmd.args["selector_type"]
            tag = cmd.args["tag"]
            collection = await extract_elements(self._page)
            filtered = collection.filter(tag=tag)
            return (
                ChatResponse(
                    text=(f"Found {len(filtered)} {selector_type} selector(s) for <{tag}>")
                ),
                (selector_type, filtered),
            )

        return await self._smart_respond(user_input)

    # ------------------------------------------------------------------
    # Smart response — navigate, scrape, then answer from real data
    # ------------------------------------------------------------------

    async def _smart_respond(self, user_input: str) -> ChatResponse:
        """Navigate if URL found, scrape page, answer from real data."""
        self._history.append({"role": "user", "content": user_input})

        # Step 1: Auto-navigate if URL in message
        url = _extract_url(user_input)
        if url and self._current_url != url:
            try:
                await self._page.navigate(url)
                self._current_url = url
            except Exception as exc:
                self._history.pop()
                return ChatResponse(text=f"Could not load {url}: {exc}")

        # Step 2: Get page content
        if self._current_url is None:
            self._history.pop()
            return ChatResponse(text="No page loaded. Use 'go to <url>' first.")

        context = await self._build_context(user_input)

        # Step 3: Ask LLM to answer from the real page data
        recent = self._history[-10:]
        prompt = "\n".join(f"{m['role'].capitalize()}: {m['content']}" for m in recent)

        try:
            response = await self._scraper._llm.complete(
                prompt,
                system_prompt=_SYSTEM_PROMPT.format(context=context),
            )
        except Exception as exc:
            self._history.pop()
            return ChatResponse(text=_friendly_error(exc))

        # Strip any JSON tool calls from response (weak models leak these)
        response = _strip_json(response)

        self._history.append({"role": "assistant", "content": response})
        return ChatResponse(text=response)

    async def _build_context(self, user_input: str) -> str:
        """Build context from actual page data."""
        html = await self._page.get_html()
        dom = simplify_dom(html, max_elements=200)
        clean_result = clean(html)
        content = clean_result.markdown[:4000]

        parts = [
            f"Current URL: {self._current_url}",
            f"\n## Page Content\n{content}",
            f"\n## Page DOM (simplified)\n{dom}",
        ]

        # Include element selectors when user asks about them
        input_lower = user_input.lower()
        if any(
            kw in input_lower
            for kw in [
                "xpath",
                "css",
                "selector",
                "element",
                "find",
                "locate",
                "inspect",
                "path",
                "outer",
                "html of",
            ]
        ):
            collection = await extract_elements(self._page, max_elements=100)
            lines = []
            for el in collection:
                lines.append(
                    f'[{el.index}] <{el.tag}> "{el.text[:50]}" css="{el.css}" xpath="{el.xpath}"'
                )
            if lines:
                parts.append("\n## Page Elements (with selectors)\n" + "\n".join(lines))

        return "\n".join(parts)

    async def stream_respond(self, user_input: str) -> AsyncIterator[str]:
        """Answer from real page data."""
        result = await self._smart_respond(user_input)
        yield result.text


def _strip_json(text: str) -> str:
    """Remove leaked JSON tool calls from LLM output."""
    # Remove lines that are just JSON objects
    lines = text.split("\n")
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("{") and stripped.endswith("}"):
            try:
                parsed = json.loads(stripped)
                if "action" in parsed:
                    continue
            except json.JSONDecodeError:
                pass
        cleaned.append(line)
    result = "\n".join(cleaned).strip()
    return result if result else text


def _friendly_error(exc: Exception) -> str:
    msg = str(exc).lower()
    if "not found" in msg and "model" in msg:
        return (
            "Model not found. Pull it first or switch to another.\n"
            "  For Ollama: ollama pull <model>\n"
            "  Or switch: /model"
        )
    if "connect" in msg and ("11434" in msg or "ollama" in msg):
        return (
            "Could not connect to Ollama. Is it running?\n"
            "  Start it: ollama serve\n"
            "  Or switch model: /model"
        )
    if "401" in msg or "auth" in msg or "api key" in msg:
        return "Authentication failed. Check your API key.\n  Update it: /key"
    if "429" in msg or "rate" in msg:
        return "Rate limited. Wait a moment and try again."
    if "timeout" in msg:
        return "Request timed out. Try again or switch model: /model"
    if "connect" in msg:
        return (
            "Connection error: could not reach the provider.\n"
            "  Check your network or switch model: /model"
        )
    return f"Error: {exc}"


def _extract_url(text: str) -> str | None:
    m = re.search(r"https?://\S+", text)
    return m.group(0).rstrip(".,;:!?)") if m else None
