"""Per-crawl configuration — controls page interaction, content processing, and crawl behavior."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CrawlConfig:
    """Single config object for controlling each crawl run.

    Similar to crawl4ai's CrawlerRunConfig — every option that affects how a page
    is fetched, processed, and returned lives here.
    """

    # Content processing
    word_count_threshold: int = 10
    css_selector: str | None = None
    excluded_tags: tuple[str, ...] = ("nav", "footer", "header")
    excluded_selector: str | None = None
    only_text: bool = False

    # Page interaction
    js_code: str | None = None
    js_code_before_wait: str | None = None
    wait_for: str | None = None
    wait_for_timeout: int = 30000
    delay_before_return: float = 0.1
    scan_full_page: bool = False
    scroll_delay: float = 0.2
    max_scroll_steps: int | None = None

    # Content cleanup
    process_iframes: bool = False
    flatten_shadow_dom: bool = False
    remove_overlay_elements: bool = False
    remove_consent_popups: bool = False

    # Media
    screenshot: bool = False
    pdf: bool = False
    exclude_external_images: bool = False

    # Links
    exclude_external_links: bool = False
    exclude_social_media_links: bool = False
    exclude_domains: tuple[str, ...] = ()

    # Cache
    cache_mode: str = "enabled"

    # Session
    session_id: str | None = None

    # Timing
    page_timeout: int = 60000
    mean_delay: float = 0.1
    max_range: float = 0.3
    semaphore_count: int = 5

    # Deep crawl
    max_depth: int = 0
    max_pages: int = 50
    same_domain: bool = True
    url_pattern: str | None = None

    # Robots
    check_robots_txt: bool = False
