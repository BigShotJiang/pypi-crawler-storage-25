"""Consent popup and overlay removal — dismiss cookie banners and modal overlays."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)

_CONSENT_SELECTORS = (
    # OneTrust
    "#onetrust-accept-btn-handler",
    ".onetrust-close-btn-handler",
    # Cookiebot
    "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll",
    # Generic patterns
    "[class*='cookie'] button[class*='accept']",
    "[class*='consent'] button[class*='accept']",
    "[id*='cookie'] button[id*='accept']",
    "button[data-testid*='accept']",
    "button:has-text('Accept All')",
    "button:has-text('Accept Cookies')",
    "button:has-text('I Agree')",
    "button:has-text('OK')",
    "button:has-text('Got it')",
    "button:has-text('Allow')",
    "button:has-text('Allow All')",
)

_OVERLAY_SELECTORS = (
    "[class*='overlay']",
    "[class*='modal']",
    "[class*='popup']",
    "[id*='overlay']",
    "[id*='modal']",
    "[id*='popup']",
)

_OVERLAY_REMOVE_SCRIPT = """
() => {
	const selectors = %s;
	let removed = 0;
	for (const sel of selectors) {
		for (const el of document.querySelectorAll(sel)) {
			const style = window.getComputedStyle(el);
			const isOverlay = (
				style.position === 'fixed' ||
				style.position === 'absolute' ||
				parseInt(style.zIndex || '0', 10) > 999
			);
			if (isOverlay) {
				el.remove();
				removed++;
			}
		}
	}
	// Also restore body scroll
	document.body.style.overflow = '';
	document.documentElement.style.overflow = '';
	return removed;
}
"""


async def remove_consent_popups(page: Any) -> bool:
    """Try to click known consent/cookie accept buttons.

    Returns True if a button was successfully clicked.
    """
    for selector in _CONSENT_SELECTORS:
        try:
            element = await page.evaluate(
                """(sel) => {
					const el = document.querySelector(sel);
					if (el && el.offsetParent !== null) {
						el.click();
						return true;
					}
					return false;
				}""",
                selector,
            )
            if element:
                logger.debug("Dismissed consent popup via %s", selector)
                await asyncio.sleep(0.3)
                return True
        except Exception:
            continue

    logger.debug("No consent popup found")
    return False


async def remove_overlays(page: Any) -> int:
    """Remove fixed/absolute overlay elements that block content.

    Returns the number of elements removed.
    """
    import json

    selectors_json = json.dumps(list(_OVERLAY_SELECTORS))
    script = _OVERLAY_REMOVE_SCRIPT % selectors_json
    try:
        removed: int = await page.evaluate(script)
        if removed > 0:
            logger.debug("Removed %d overlay elements", removed)
        return removed
    except Exception as exc:
        logger.warning("Overlay removal failed: %s", exc)
        return 0
