"""Page processor — applies CrawlConfig options to a page and returns structured results."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from scrapurrr.pipeline.cleaner import clean, clean_fit
from scrapurrr.pipeline.consent import remove_consent_popups, remove_overlays

if TYPE_CHECKING:
    from scrapurrr.core.crawl_config import CrawlConfig

logger = logging.getLogger(__name__)

_SOCIAL_DOMAINS = frozenset(
    {
        "facebook.com",
        "twitter.com",
        "x.com",
        "instagram.com",
        "linkedin.com",
        "tiktok.com",
        "pinterest.com",
        "reddit.com",
        "youtube.com",
        "snapchat.com",
        "t.co",
        "fb.me",
    }
)


@dataclass(frozen=True)
class ProcessedPage:
    """Result of processing a single page through the pipeline."""

    url: str
    html: str
    markdown: str
    fit_markdown: str
    links: tuple[str, ...]
    internal_links: tuple[str, ...]
    external_links: tuple[str, ...]
    screenshot: bytes | None
    pdf: bytes | None
    title: str | None
    metadata: dict[str, str]


async def process_page(page: Any, url: str, config: CrawlConfig) -> ProcessedPage:
    """Apply all CrawlConfig options to a page and return processed result.

    Steps:
    1. Execute js_code_before_wait
    2. Wait for condition (CSS or JS)
    3. Execute js_code
    4. Handle iframes
    5. Flatten shadow DOM
    6. Remove overlays and consent popups
    7. Auto-scroll if scan_full_page
    8. Delay before capture
    9. Capture HTML (with css_selector focus, excluded_tags removal)
    10. Take screenshot/PDF if requested
    11. Generate markdown (with content filtering)
    12. Filter links
    """
    # 1. Pre-wait JS
    if config.js_code_before_wait:
        await page.evaluate(config.js_code_before_wait)

    # 2. Wait condition
    if config.wait_for:
        await _wait_for_condition(page, config.wait_for, config.wait_for_timeout)

    # 3. Post-wait JS
    if config.js_code:
        await page.evaluate(config.js_code)

    # 4. Process iframes
    if config.process_iframes:
        await _inline_iframes(page)

    # 5. Flatten shadow DOM
    if config.flatten_shadow_dom:
        from scrapurrr.pipeline.shadow_dom import flatten_shadow_dom

        await flatten_shadow_dom(page)

    # 6. Remove consent popups and overlays
    if config.remove_consent_popups:
        await remove_consent_popups(page)
    if config.remove_overlay_elements:
        await remove_overlays(page)

    # 7. Auto-scroll
    if config.scan_full_page:
        from scrapurrr.pipeline.lazy_load import load_all_lazy_content

        await load_all_lazy_content(
            page,
            max_scrolls=config.max_scroll_steps or 10,
            scroll_delay=config.scroll_delay,
        )

    # 8. Delay before capture
    if config.delay_before_return > 0:
        await asyncio.sleep(config.delay_before_return)

    # 9. Capture HTML
    raw_html = await page.get_html()
    html = _apply_selectors(raw_html, config)

    # 10. Screenshot / PDF
    screenshot_data: bytes | None = None
    pdf_data: bytes | None = None
    if config.screenshot:
        try:
            screenshot_data = await page.screenshot()
        except Exception as exc:
            logger.warning("Screenshot failed: %s", exc)
    if config.pdf:
        try:
            pdf_data = await page._page.pdf()
        except Exception as exc:
            logger.warning("PDF generation failed: %s", exc)

    # 11. Generate markdown
    if config.only_text:
        soup = BeautifulSoup(html, "html.parser")
        markdown = soup.get_text(separator="\n", strip=True)
        fit_markdown = markdown
    else:
        clean_result = clean(html)
        fit_result = clean_fit(html)
        markdown = clean_result.markdown
        fit_markdown = fit_result.markdown

    title = _extract_title(html)
    meta = _extract_metadata(html)

    # 12. Extract and filter links
    all_links = _extract_links(html, url)
    internal, external = _split_links(all_links, url)

    filtered_links = _filter_links(
        all_links,
        url=url,
        exclude_external=config.exclude_external_links,
        exclude_social=config.exclude_social_media_links,
        exclude_domains=config.exclude_domains,
    )

    return ProcessedPage(
        url=url,
        html=html,
        markdown=markdown,
        fit_markdown=fit_markdown,
        links=tuple(filtered_links),
        internal_links=tuple(internal),
        external_links=tuple(external),
        screenshot=screenshot_data,
        pdf=pdf_data,
        title=title,
        metadata=meta,
    )


async def _wait_for_condition(page: Any, condition: str, timeout: int) -> None:
    """Wait for a CSS selector or JS expression."""
    if condition.startswith("js:"):
        js_expr = condition[3:]
        end_time = asyncio.get_event_loop().time() + timeout / 1000
        while asyncio.get_event_loop().time() < end_time:
            result = await page.evaluate(js_expr)
            if result:
                return
            await asyncio.sleep(0.1)
        logger.warning("JS wait condition timed out: %s", js_expr)
    else:
        try:
            await page.wait_for(condition, timeout=timeout)
        except Exception as exc:
            logger.warning("Wait for '%s' timed out: %s", condition, exc)


async def _inline_iframes(page: Any) -> None:
    """Inline same-origin iframe content into the main DOM.

    Reads from same-origin iframe contentDocument (browser-controlled,
    not user input) and replaces iframe elements with their body text.
    """
    try:
        await page.evaluate("""
			() => {
				for (const iframe of document.querySelectorAll('iframe')) {
					try {
						const doc = iframe.contentDocument || iframe.contentWindow?.document;
						if (doc && doc.body) {
							const wrapper = document.createElement('div');
							wrapper.setAttribute('data-iframe-src', iframe.src || '');
							wrapper.textContent = doc.body.textContent || '';
							iframe.replaceWith(wrapper);
						}
					} catch (e) { /* cross-origin, skip */ }
				}
			}
		""")
    except Exception as exc:
        logger.debug("Iframe inlining failed: %s", exc)


def _apply_selectors(html: str, config: CrawlConfig) -> str:
    """Apply css_selector focus and excluded_tags/excluded_selector removal."""
    soup = BeautifulSoup(html, "html.parser")

    # Focus on specific element
    if config.css_selector:
        target = soup.select_one(config.css_selector)
        if target:
            return str(target)
        logger.warning("css_selector '%s' not found, using full page", config.css_selector)

    # Remove excluded tags
    for tag_name in config.excluded_tags:
        for tag in list(soup.find_all(tag_name)):
            tag.decompose()

    # Remove by excluded_selector
    if config.excluded_selector:
        for el in list(soup.select(config.excluded_selector)):
            el.decompose()

    return str(soup)


def _extract_title(html: str) -> str | None:
    soup = BeautifulSoup(html, "html.parser")
    title_tag = soup.find("title")
    if title_tag:
        return title_tag.get_text(strip=True)
    return None


def _extract_metadata(html: str) -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    meta: dict[str, str] = {}
    for tag in soup.find_all("meta"):
        name = tag.get("name") or tag.get("property")
        content = tag.get("content")
        if name and content and isinstance(name, str) and isinstance(content, str):
            meta[name] = content
    return meta


def _extract_links(html: str, base_url: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if isinstance(href, list):
            href = href[0]
        resolved = urljoin(base_url, href)
        parsed = urlparse(resolved)
        if parsed.scheme in ("http", "https"):
            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"
            links.append(clean_url)
    return list(dict.fromkeys(links))


def _split_links(links: list[str], base_url: str) -> tuple[list[str], list[str]]:
    base_domain = urlparse(base_url).netloc
    internal: list[str] = []
    external: list[str] = []
    for link in links:
        if urlparse(link).netloc == base_domain:
            internal.append(link)
        else:
            external.append(link)
    return internal, external


def _filter_links(
    links: list[str],
    *,
    url: str,
    exclude_external: bool,
    exclude_social: bool,
    exclude_domains: tuple[str, ...],
) -> list[str]:
    base_domain = urlparse(url).netloc
    filtered: list[str] = []
    for link in links:
        domain = urlparse(link).netloc

        if exclude_external and domain != base_domain:
            continue

        if exclude_social and any(sd in domain for sd in _SOCIAL_DOMAINS):
            continue

        if exclude_domains and any(ed in domain for ed in exclude_domains):
            continue

        filtered.append(link)
    return filtered
