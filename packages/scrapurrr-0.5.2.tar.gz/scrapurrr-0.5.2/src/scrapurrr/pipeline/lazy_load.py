"""Handle lazy-loaded and infinite scroll content."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


async def load_all_lazy_content(
    page: Any,
    max_scrolls: int = 10,
    scroll_delay: float = 1.5,
    check_new_content: bool = True,
) -> None:
    """Scroll through the page to trigger all lazy-loaded content.

    Scrolls down incrementally, waiting for new content to load.
    Stops when no new content appears or max_scrolls reached.
    """
    previous_height = 0
    no_change_count = 0

    for i in range(max_scrolls):
        # Get current page height
        current_height = await page.evaluate("() => document.body.scrollHeight")

        if check_new_content and current_height == previous_height:
            no_change_count += 1
            if no_change_count >= 2:
                logger.debug("No new content after %d scrolls — stopping", i)
                break
        else:
            no_change_count = 0

        previous_height = current_height

        # Scroll to bottom
        await page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")

        # Wait for content to load
        await asyncio.sleep(scroll_delay)

        # Force lazy images and iframes to load
        await page.evaluate("""
			() => {
				document.querySelectorAll('img[data-src], img[loading="lazy"]').forEach(img => {
					if (img.dataset.src) img.src = img.dataset.src;
					img.loading = 'eager';
				});
				document.querySelectorAll('iframe[data-src]').forEach(iframe => {
					if (iframe.dataset.src) iframe.src = iframe.dataset.src;
				});
			}
		""")

        logger.debug("Lazy load scroll %d/%d (height: %d)", i + 1, max_scrolls, current_height)

    # Scroll back to top
    await page.evaluate("() => window.scrollTo(0, 0)")
    logger.info("Lazy content loading complete")


async def intercept_api_responses(
    page: Any,
    url_pattern: str = "api",
    timeout: float = 10.0,
) -> list[dict[str, Any]]:
    """Intercept XHR/fetch API responses from the page.

    Useful for extracting data directly from APIs instead of parsing HTML.
    """
    responses: list[dict[str, Any]] = []

    async def handle_response(response: Any) -> None:
        url = response.url
        if url_pattern in url:
            try:
                body = await response.text()
                data = json.loads(body)
                responses.append({"url": url, "data": data, "status": response.status})
                logger.debug("Intercepted API response: %s", url)
            except Exception:
                pass

    # This requires access to the underlying Playwright page
    # The page parameter should have a way to listen for responses
    try:
        page._page.on("response", handle_response)
        await asyncio.sleep(timeout)
        page._page.remove_listener("response", handle_response)
    except Exception as exc:
        logger.warning("API interception failed: %s", exc)

    return responses


async def virtual_scroll(
    page: Any,
    container_selector: str,
    scroll_count: int = 10,
    scroll_by: int | str = "container_height",
    wait_after_scroll: float = 0.5,
) -> str:
    """Handle virtualized scrolling (Twitter, Instagram style).

    Scrolls inside a container element, merging unique content across scrolls.
    Returns the combined unique inner HTML from all scroll positions.

    Args:
        page: Playwright page wrapper with `evaluate` method.
        container_selector: CSS selector for the scrollable container.
        scroll_count: Number of scroll iterations.
        scroll_by: Pixels to scroll per step, or ``"container_height"``
            to scroll by the container's visible height.
        wait_after_scroll: Seconds to wait after each scroll for content to render.
    """
    seen_ids: set[str] = set()
    collected_html: list[str] = []

    for i in range(scroll_count):
        # Grab current children, dedup by outerHTML hash
        result: dict[str, Any] = await page.evaluate(
            """(args) => {
                const container = document.querySelector(args.selector);
                if (!container) return { items: [], scrolled: false };
                const items = [];
                for (const child of container.children) {
                    items.push({
                        id: child.id || child.dataset?.key || child.outerHTML.slice(0, 200),
                        html: child.outerHTML
                    });
                }
                const scrollAmount = args.scrollBy === 'container_height'
                    ? container.clientHeight
                    : args.scrollBy;
                container.scrollTop += scrollAmount;
                return { items, scrolled: true };
            }""",
            {"selector": container_selector, "scrollBy": scroll_by},
        )

        if not result.get("scrolled"):
            logger.warning("Virtual scroll container not found: %s", container_selector)
            break

        for item in result.get("items", []):
            item_id = item["id"]
            if item_id not in seen_ids:
                seen_ids.add(item_id)
                collected_html.append(item["html"])

        await asyncio.sleep(wait_after_scroll)
        logger.debug("Virtual scroll %d/%d — %d unique items", i + 1, scroll_count, len(seen_ids))

    return "\n".join(collected_html)
