"""Tests for the page processor."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.core.crawl_config import CrawlConfig
from scrapurrr.pipeline.processor import (
    ProcessedPage,
    _apply_selectors,
    _extract_links,
    _filter_links,
    _split_links,
)


class TestApplySelectors:
    def test_css_selector_focuses_element(self) -> None:
        html = '<html><body><div id="main"><p>Hello</p></div><footer>F</footer></body></html>'
        config = CrawlConfig(css_selector="#main", excluded_tags=())
        result = _apply_selectors(html, config)
        assert "Hello" in result
        assert "footer" not in result.lower() or "F" not in result

    def test_excluded_tags_removed(self) -> None:
        html = "<html><body><nav>Nav</nav><p>Content</p><footer>Foot</footer></body></html>"
        config = CrawlConfig(excluded_tags=("nav", "footer"))
        result = _apply_selectors(html, config)
        assert "Nav" not in result
        assert "Foot" not in result
        assert "Content" in result

    def test_excluded_selector_removed(self) -> None:
        html = '<html><body><div class="ad">Ad</div><p>Content</p></body></html>'
        config = CrawlConfig(excluded_tags=(), excluded_selector=".ad")
        result = _apply_selectors(html, config)
        assert "Ad" not in result
        assert "Content" in result

    def test_css_selector_missing_falls_back(self) -> None:
        html = "<html><body><p>Content</p></body></html>"
        config = CrawlConfig(css_selector="#nonexistent", excluded_tags=())
        result = _apply_selectors(html, config)
        assert "Content" in result


class TestExtractLinks:
    def test_extracts_and_resolves(self) -> None:
        html = '<a href="/page1">P1</a><a href="https://other.com/p">P2</a>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/page1" in links
        assert "https://other.com/p" in links

    def test_deduplicates(self) -> None:
        html = '<a href="/page">A</a><a href="/page">B</a>'
        links = _extract_links(html, "https://example.com")
        assert links.count("https://example.com/page") == 1


class TestSplitLinks:
    def test_splits_internal_external(self) -> None:
        links = ["https://example.com/a", "https://other.com/b"]
        internal, external = _split_links(links, "https://example.com")
        assert internal == ["https://example.com/a"]
        assert external == ["https://other.com/b"]


class TestFilterLinks:
    def test_exclude_external(self) -> None:
        links = ["https://example.com/a", "https://other.com/b"]
        result = _filter_links(
            links,
            url="https://example.com",
            exclude_external=True,
            exclude_social=False,
            exclude_domains=(),
        )
        assert result == ["https://example.com/a"]

    def test_exclude_social(self) -> None:
        links = ["https://example.com/a", "https://twitter.com/user"]
        result = _filter_links(
            links,
            url="https://example.com",
            exclude_external=False,
            exclude_social=True,
            exclude_domains=(),
        )
        assert "https://twitter.com/user" not in result
        assert "https://example.com/a" in result

    def test_exclude_domains(self) -> None:
        links = ["https://example.com/a", "https://ads.example.com/track"]
        result = _filter_links(
            links,
            url="https://example.com",
            exclude_external=False,
            exclude_social=False,
            exclude_domains=("ads.example.com",),
        )
        assert "https://ads.example.com/track" not in result


class TestProcessedPage:
    def test_frozen(self) -> None:
        page = ProcessedPage(
            url="https://x.com",
            html="<p>hi</p>",
            markdown="hi",
            fit_markdown="hi",
            links=(),
            internal_links=(),
            external_links=(),
            screenshot=None,
            pdf=None,
            title=None,
            metadata={},
        )
        with pytest.raises(AttributeError):
            page.url = "other"  # type: ignore[misc]


class TestProcessPage:
    @pytest.mark.asyncio
    async def test_basic_processing(self) -> None:
        from scrapurrr.pipeline.processor import process_page

        page = AsyncMock()
        page.get_html = AsyncMock(
            return_value='<html><body><p>Hello World</p><a href="/about">About</a></body></html>'
        )
        page.screenshot = AsyncMock(return_value=b"png-data")

        config = CrawlConfig(
            excluded_tags=(),
            delay_before_return=0,
            screenshot=True,
        )
        result = await process_page(page, "https://example.com", config)

        assert result.url == "https://example.com"
        assert "Hello World" in result.markdown
        assert result.screenshot == b"png-data"
        assert isinstance(result.links, tuple)

    @pytest.mark.asyncio
    async def test_only_text_mode(self) -> None:
        from scrapurrr.pipeline.processor import process_page

        page = AsyncMock()
        page.get_html = AsyncMock(
            return_value="<html><body><p>Hello <b>World</b></p></body></html>"
        )

        config = CrawlConfig(only_text=True, excluded_tags=(), delay_before_return=0)
        result = await process_page(page, "https://example.com", config)
        assert "Hello" in result.markdown
        assert "<b>" not in result.markdown

    @pytest.mark.asyncio
    async def test_js_execution(self) -> None:
        from scrapurrr.pipeline.processor import process_page

        page = AsyncMock()
        page.get_html = AsyncMock(return_value="<html><body><p>Done</p></body></html>")

        config = CrawlConfig(
            js_code_before_wait="window.x = 1",
            js_code="window.y = 2",
            excluded_tags=(),
            delay_before_return=0,
        )
        await process_page(page, "https://example.com", config)

        # Verify both JS snippets were called
        calls = [str(c) for c in page.evaluate.call_args_list]
        assert any("window.x = 1" in c for c in calls)
        assert any("window.y = 2" in c for c in calls)
