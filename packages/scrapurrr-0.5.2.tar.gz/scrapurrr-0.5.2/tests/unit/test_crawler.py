"""Tests for the DeepCrawler, crawl strategies, and URL filters."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.core.crawl_config import CrawlConfig
from scrapurrr.core.types import FetchResult
from scrapurrr.crawler import (
    BestFirstCrawlStrategy,
    BFSCrawlStrategy,
    CrawlResult,
    DeepCrawler,
    DFSCrawlStrategy,
    DomainFilter,
    FilterChain,
    PatternFilter,
    _extract_links,
    _is_same_domain,
)

# ---------------------------------------------------------------------------
# Link helpers
# ---------------------------------------------------------------------------


class TestExtractLinks:
    def test_extracts_absolute_links(self) -> None:
        html = '<html><body><a href="https://example.com/page1">Page 1</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/page1" in links

    def test_resolves_relative_links(self) -> None:
        html = '<html><body><a href="/about">About</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/about" in links

    def test_strips_fragments(self) -> None:
        html = '<html><body><a href="/page#section">Link</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/page" in links
        assert any("#" in link for link in links) is False

    def test_deduplicates_links(self) -> None:
        html = '<html><body><a href="/page">Link 1</a><a href="/page">Link 2</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert links.count("https://example.com/page") == 1

    def test_skips_non_http_links(self) -> None:
        html = (
            "<html><body>"
            '<a href="mailto:test@example.com">Email</a>'
            '<a href="javascript:void(0)">JS</a>'
            '<a href="https://example.com/ok">OK</a>'
            "</body></html>"
        )
        links = _extract_links(html, "https://example.com")
        assert len(links) == 1
        assert "https://example.com/ok" in links


class TestIsSameDomain:
    def test_same_domain(self) -> None:
        assert _is_same_domain("https://example.com/page", "https://example.com") is True

    def test_different_domain(self) -> None:
        assert _is_same_domain("https://other.com/page", "https://example.com") is False

    def test_subdomain_is_different(self) -> None:
        assert _is_same_domain("https://sub.example.com", "https://example.com") is False


class TestCrawlResult:
    def test_frozen(self) -> None:
        result = CrawlResult(
            url="https://x.com", html="<p>hi</p>", markdown="hi", depth=0, links=()
        )
        with pytest.raises(AttributeError):
            result.url = "https://other.com"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------


class TestBFSStrategy:
    @pytest.mark.asyncio
    async def test_returns_unvisited_links(self) -> None:
        strategy = BFSCrawlStrategy()
        links = ["https://a.com", "https://b.com", "https://c.com"]
        visited = {"https://a.com"}
        result = await strategy.get_next_urls("https://x.com", links, visited, 0)
        assert result == ["https://b.com", "https://c.com"]


class TestDFSStrategy:
    @pytest.mark.asyncio
    async def test_returns_reversed_unvisited(self) -> None:
        strategy = DFSCrawlStrategy()
        links = ["https://a.com", "https://b.com", "https://c.com"]
        visited: set[str] = set()
        result = await strategy.get_next_urls("https://x.com", links, visited, 0)
        assert result == ["https://c.com", "https://b.com", "https://a.com"]


class TestBestFirstStrategy:
    @pytest.mark.asyncio
    async def test_scores_by_keywords(self) -> None:
        strategy = BestFirstCrawlStrategy(keywords=["blog", "article"])
        links = [
            "https://example.com/about",
            "https://example.com/blog/post1",
            "https://example.com/article/news",
        ]
        result = await strategy.get_next_urls("https://example.com", links, set(), 0)
        # blog and article links should come first
        assert result[0] in ("https://example.com/blog/post1", "https://example.com/article/news")
        assert result[-1] == "https://example.com/about"

    @pytest.mark.asyncio
    async def test_custom_weights(self) -> None:
        strategy = BestFirstCrawlStrategy(
            keywords=["blog", "docs"],
            weights={"docs": 5.0, "blog": 1.0},
        )
        links = ["https://x.com/blog/p", "https://x.com/docs/api"]
        result = await strategy.get_next_urls("https://x.com", links, set(), 0)
        assert result[0] == "https://x.com/docs/api"


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------


class TestPatternFilter:
    def test_glob_pattern(self) -> None:
        f = PatternFilter(["*/blog/*"])
        assert f.accept("https://example.com/blog/post1") is True
        assert f.accept("https://example.com/about") is False

    def test_regex_pattern(self) -> None:
        f = PatternFilter([r"/posts/\d+"])
        assert f.accept("https://example.com/posts/123") is True
        assert f.accept("https://example.com/posts/abc") is False


class TestDomainFilter:
    def test_allowed_domains(self) -> None:
        f = DomainFilter(allowed=["example.com"])
        assert f.accept("https://example.com/page") is True
        assert f.accept("https://other.com/page") is False

    def test_blocked_domains(self) -> None:
        f = DomainFilter(blocked=["ads.example.com"])
        assert f.accept("https://example.com/page") is True
        assert f.accept("https://ads.example.com/track") is False

    def test_no_constraints(self) -> None:
        f = DomainFilter()
        assert f.accept("https://anything.com") is True


class TestFilterChain:
    def test_all_must_pass(self) -> None:
        chain = FilterChain(
            [
                PatternFilter(["*/blog/*"]),
                DomainFilter(allowed=["example.com"]),
            ]
        )
        assert chain.accept("https://example.com/blog/post1") is True
        assert chain.accept("https://other.com/blog/post1") is False
        assert chain.accept("https://example.com/about") is False


# ---------------------------------------------------------------------------
# DeepCrawler
# ---------------------------------------------------------------------------


class TestDeepCrawler:
    def _make_scraper(self, pages: dict[str, str]) -> object:
        """Create a mock scraper that returns HTML from a dict."""
        scraper = AsyncMock()
        scraper._extractor = AsyncMock()

        async def _do_fetch(url: str) -> FetchResult:
            html = pages.get(url, "<html><body></body></html>")
            return FetchResult(url=url, html=html, status=200, headers={})

        scraper._do_fetch = _do_fetch
        return scraper

    @pytest.mark.asyncio
    async def test_crawl_single_page(self) -> None:
        pages = {"https://example.com": "<html><body><p>Hello</p></body></html>"}
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=0, max_pages=10)
        results = await crawler.crawl("https://example.com")
        assert len(results) == 1
        assert results[0].url == "https://example.com"
        assert results[0].depth == 0

    @pytest.mark.asyncio
    async def test_crawl_follows_links(self) -> None:
        pages = {
            "https://example.com": (
                '<html><body><a href="https://example.com/page1">P1</a></body></html>'
            ),
            "https://example.com/page1": "<html><body><p>Page 1</p></body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com" in urls
        assert "https://example.com/page1" in urls

    @pytest.mark.asyncio
    async def test_crawl_respects_max_depth(self) -> None:
        pages = {
            "https://example.com": '<html><body><a href="https://example.com/a">A</a></body></html>',
            "https://example.com/a": '<html><body><a href="https://example.com/b">B</a></body></html>',
            "https://example.com/b": "<html><body><p>Deep</p></body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com/b" not in urls

    @pytest.mark.asyncio
    async def test_crawl_respects_max_pages(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/1">1</a>'
                '<a href="https://example.com/2">2</a>'
                '<a href="https://example.com/3">3</a>'
                "</body></html>"
            ),
            "https://example.com/1": "<html><body>1</body></html>",
            "https://example.com/2": "<html><body>2</body></html>",
            "https://example.com/3": "<html><body>3</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=2, max_pages=2)
        results = await crawler.crawl("https://example.com")
        assert len(results) <= 2

    @pytest.mark.asyncio
    async def test_crawl_same_domain_filter(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/local">Local</a>'
                '<a href="https://other.com/external">External</a>'
                "</body></html>"
            ),
            "https://example.com/local": "<html><body>Local</body></html>",
            "https://other.com/external": "<html><body>External</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10, same_domain=True)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://other.com/external" not in urls

    @pytest.mark.asyncio
    async def test_crawl_url_pattern_filter(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/blog/post1">Blog</a>'
                '<a href="https://example.com/about">About</a>'
                "</body></html>"
            ),
            "https://example.com/blog/post1": "<html><body>Blog post</body></html>",
            "https://example.com/about": "<html><body>About page</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10, url_pattern=r"/blog/")
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com/about" not in urls

    @pytest.mark.asyncio
    async def test_crawl_deduplicates_urls(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/page">Link 1</a>'
                '<a href="https://example.com/page">Link 2</a>'
                "</body></html>"
            ),
            "https://example.com/page": "<html><body>Page</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        page_results = [r for r in results if r.url == "https://example.com/page"]
        assert len(page_results) == 1

    @pytest.mark.asyncio
    async def test_crawl_handles_fetch_errors(self) -> None:
        scraper = AsyncMock()

        call_count = 0

        async def _do_fetch(url: str) -> FetchResult:
            nonlocal call_count
            call_count += 1
            if "bad" in url:
                raise Exception("fetch failed")
            return FetchResult(
                url=url,
                html='<html><body><a href="https://example.com/bad">Bad</a></body></html>',
                status=200,
                headers={},
            )

        scraper._do_fetch = _do_fetch
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_crawl_with_dfs_strategy(self) -> None:
        pages = {
            "https://example.com": (
                '<html><body><a href="https://example.com/a">A</a>'
                '<a href="https://example.com/b">B</a></body></html>'
            ),
            "https://example.com/a": "<html><body>A</body></html>",
            "https://example.com/b": "<html><body>B</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10, strategy=DFSCrawlStrategy())
        results = await crawler.crawl("https://example.com")
        urls = [r.url for r in results]
        assert "https://example.com" in urls
        assert len(urls) == 3

    @pytest.mark.asyncio
    async def test_crawl_with_filters(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/blog/p1">Blog</a>'
                '<a href="https://example.com/about">About</a>'
                '<a href="https://ads.example.com/track">Ad</a>'
                "</body></html>"
            ),
            "https://example.com/blog/p1": "<html><body>Blog</body></html>",
            "https://example.com/about": "<html><body>About</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(
            scraper,
            max_depth=1,
            max_pages=10,
            same_domain=False,
            filters=[
                PatternFilter(["*/blog/*"]),
                DomainFilter(blocked=["ads.example.com"]),
            ],
        )
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com" in urls
        assert "https://example.com/blog/p1" in urls
        assert "https://example.com/about" not in urls

    @pytest.mark.asyncio
    async def test_crawl_with_config(self) -> None:
        pages = {
            "https://example.com": (
                '<html><body><a href="https://example.com/p">P</a></body></html>'
            ),
            "https://example.com/p": "<html><body>P</body></html>",
        }
        scraper = self._make_scraper(pages)
        config = CrawlConfig(max_depth=1, max_pages=5)
        crawler = DeepCrawler(scraper, config=config)
        results = await crawler.crawl("https://example.com")
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_crawl_stream(self) -> None:
        pages = {
            "https://example.com": (
                '<html><body><a href="https://example.com/p">P</a></body></html>'
            ),
            "https://example.com/p": "<html><body>P</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = []
        async for result in crawler.crawl_stream("https://example.com"):
            results.append(result)
        assert len(results) == 2
