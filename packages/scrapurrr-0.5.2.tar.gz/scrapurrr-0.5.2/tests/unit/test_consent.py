"""Tests for consent popup and overlay removal."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.pipeline.consent import remove_consent_popups, remove_overlays


class TestRemoveConsentPopups:
    @pytest.mark.asyncio
    async def test_clicks_first_matching_selector(self) -> None:
        page = AsyncMock()
        # First selector fails, second succeeds
        call_count = 0

        async def mock_evaluate(script: str, selector: str | None = None) -> bool:
            nonlocal call_count
            call_count += 1
            # Return True on the second call (simulating a found button)
            return call_count == 2

        page.evaluate = mock_evaluate
        result = await remove_consent_popups(page)
        assert result is True

    @pytest.mark.asyncio
    async def test_returns_false_when_no_popup_found(self) -> None:
        page = AsyncMock()

        async def mock_evaluate(script: str, selector: str | None = None) -> bool:
            return False

        page.evaluate = mock_evaluate
        result = await remove_consent_popups(page)
        assert result is False

    @pytest.mark.asyncio
    async def test_handles_evaluate_exception(self) -> None:
        page = AsyncMock()

        async def mock_evaluate(script: str, selector: str | None = None) -> bool:
            raise RuntimeError("page closed")

        page.evaluate = mock_evaluate
        result = await remove_consent_popups(page)
        assert result is False


class TestRemoveOverlays:
    @pytest.mark.asyncio
    async def test_returns_count_of_removed_elements(self) -> None:
        page = AsyncMock()
        page.evaluate = AsyncMock(return_value=3)
        count = await remove_overlays(page)
        assert count == 3

    @pytest.mark.asyncio
    async def test_returns_zero_on_failure(self) -> None:
        page = AsyncMock()
        page.evaluate = AsyncMock(side_effect=RuntimeError("boom"))
        count = await remove_overlays(page)
        assert count == 0
