"""Tests for CrawlConfig dataclass."""

from __future__ import annotations

from dataclasses import replace

import pytest

from scrapurrr.core.crawl_config import CrawlConfig


class TestCrawlConfigDefaults:
    def test_defaults(self) -> None:
        cfg = CrawlConfig()
        assert cfg.word_count_threshold == 10
        assert cfg.css_selector is None
        assert cfg.excluded_tags == ("nav", "footer", "header")
        assert cfg.only_text is False
        assert cfg.scan_full_page is False
        assert cfg.max_depth == 0
        assert cfg.max_pages == 50
        assert cfg.same_domain is True
        assert cfg.cache_mode == "enabled"
        assert cfg.semaphore_count == 5

    def test_frozen(self) -> None:
        cfg = CrawlConfig()
        with pytest.raises(AttributeError):
            cfg.max_depth = 5  # type: ignore[misc]

    def test_replace(self) -> None:
        cfg = CrawlConfig()
        new_cfg = replace(cfg, max_depth=3, scan_full_page=True)
        assert new_cfg.max_depth == 3
        assert new_cfg.scan_full_page is True
        assert cfg.max_depth == 0  # original unchanged

    def test_custom_values(self) -> None:
        cfg = CrawlConfig(
            css_selector="#main",
            excluded_tags=("aside",),
            js_code="console.log('hi')",
            wait_for=".loaded",
            screenshot=True,
            exclude_external_links=True,
            exclude_domains=("ads.example.com",),
            session_id="test-session",
            check_robots_txt=True,
        )
        assert cfg.css_selector == "#main"
        assert cfg.excluded_tags == ("aside",)
        assert cfg.js_code == "console.log('hi')"
        assert cfg.wait_for == ".loaded"
        assert cfg.screenshot is True
        assert cfg.exclude_external_links is True
        assert cfg.exclude_domains == ("ads.example.com",)
        assert cfg.session_id == "test-session"
        assert cfg.check_robots_txt is True
