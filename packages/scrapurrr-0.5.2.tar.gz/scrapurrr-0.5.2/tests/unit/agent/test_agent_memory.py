"""Tests for agent short-term memory."""

from __future__ import annotations

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory, PageKnowledge


class Product(BaseModel):
    name: str
    price: float


def test_memory_creation() -> None:
    memory = AgentMemory(goal="find products", schema=Product)
    assert memory.goal == "find products"
    assert memory.step_count == 0
    assert memory.visited_urls == []
    assert memory.extracted_data == []
    assert memory.action_history == []
    assert memory.page_knowledge == {}
    assert memory.failed_selectors == set()
    assert memory.failed_urls == set()
    assert memory.strategies_tried == []


def test_record_action() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="navigate", params={"url": "https://example.com"}, result="OK")
    memory.record_action(action)
    assert len(memory.action_history) == 1
    assert memory.step_count == 1


def test_record_action_with_timestamp_and_success() -> None:
    action = AgentAction(
        tool="click",
        params={"selector": ".btn"},
        result="Clicked",
        timestamp=1234567890.0,
        success=True,
    )
    assert action.timestamp == 1234567890.0
    assert action.success is True

    failed = AgentAction(
        tool="click",
        params={"selector": ".missing"},
        result="Error",
        timestamp=1234567891.0,
        success=False,
    )
    assert failed.success is False


def test_record_visit() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert "https://example.com" in memory.visited_urls


def test_record_extracted_data() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    product = Product(name="Widget", price=9.99)
    memory.record_extraction(product)
    assert len(memory.extracted_data) == 1


def test_is_url_visited() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert memory.is_visited("https://example.com") is True
    assert memory.is_visited("https://other.com") is False


def test_stuck_detection_url_visited_too_many_times() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for _ in range(3):
        memory.record_visit("https://example.com")
    assert memory.is_stuck() is True


def test_stuck_detection_repeated_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="scroll", params={"direction": "down"}, result="OK")
    memory.record_action(action)
    memory.record_action(action)
    assert memory.is_stuck() is True


def test_stuck_detection_no_progress() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    assert memory.is_stuck() is True


def test_not_stuck_with_extractions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
        memory.record_extraction(Product(name=f"P{i}", price=float(i)))
    assert memory.is_stuck() is False


def test_truncate_old_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(30):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    recent = memory.recent_actions(limit=10)
    assert len(recent) == 10


# ------------------------------------------------------------------
# Page knowledge tests
# ------------------------------------------------------------------


def test_record_and_get_page_knowledge() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_page_knowledge(
        url="https://shop.com",
        title="Shop",
        element_count=150,
        has_pagination=True,
        key_selectors={"product": ".product-card", "price": ".price"},
        content_summary="E-commerce product listing page",
    )

    knowledge = memory.get_page_knowledge("https://shop.com")
    assert knowledge is not None
    assert knowledge.title == "Shop"
    assert knowledge.element_count == 150
    assert knowledge.has_pagination is True
    assert knowledge.key_selectors == {"product": ".product-card", "price": ".price"}
    assert knowledge.content_summary == "E-commerce product listing page"


def test_get_page_knowledge_returns_none_for_unknown() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    assert memory.get_page_knowledge("https://unknown.com") is None


def test_page_knowledge_frozen() -> None:
    pk = PageKnowledge(
        url="https://example.com",
        title="Example",
        element_count=50,
        has_pagination=False,
        key_selectors={},
        content_summary="",
    )
    import dataclasses

    assert dataclasses.is_dataclass(pk)
    # frozen=True means we can't modify fields
    try:
        pk.title = "Modified"  # type: ignore[misc]
        raise AssertionError("Should have raised FrozenInstanceError")
    except dataclasses.FrozenInstanceError:
        pass


# ------------------------------------------------------------------
# Failure tracking tests
# ------------------------------------------------------------------


def test_record_failure_selector() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_failure("click", ".nonexistent", "Element not found")
    assert ".nonexistent" in memory.failed_selectors


def test_record_failure_navigate() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(
        tool="navigate", params={"url": "https://bad.com"}, result="Error: timeout"
    )
    memory.record_action(action)
    memory.record_failure("navigate", None, "timeout")
    assert "https://bad.com" in memory.failed_urls


def test_record_failure_no_selector() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_failure("extract", None, "extraction failed")
    assert len(memory.failed_selectors) == 0


# ------------------------------------------------------------------
# Suggestions tests
# ------------------------------------------------------------------


def test_suggestions_with_failed_selectors() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.failed_selectors.add(".broken")
    suggestions = memory.get_suggestions()
    assert ".broken" in suggestions
    assert "inspect_elements" in suggestions


def test_suggestions_with_pagination() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_page_knowledge(
        url="https://shop.com",
        title="Shop",
        element_count=100,
        has_pagination=True,
        key_selectors={},
    )
    suggestions = memory.get_suggestions()
    assert "Pagination" in suggestions


def test_suggestions_no_data_after_many_steps() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for _i in range(6):
        memory.record_action(AgentAction(tool="read_page", params={}, result="content"))
    suggestions = memory.get_suggestions()
    assert "No data extracted" in suggestions


def test_suggestions_empty_when_no_issues() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    assert memory.get_suggestions() == ""


def test_suggestions_css_fallback() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.strategies_tried.append("css_extraction")
    suggestions = memory.get_suggestions()
    assert "LLM extraction" in suggestions


# ------------------------------------------------------------------
# Compact history with enriched context
# ------------------------------------------------------------------


def test_compact_history_includes_page_knowledge() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for _i in range(10):
        memory.record_action(AgentAction(tool="read_page", params={}, result="content"))
    memory.record_page_knowledge(
        url="https://shop.com",
        title="Shop",
        element_count=150,
        has_pagination=True,
        key_selectors={},
    )
    summary = memory.compact_history(keep_recent=5)
    assert "Pages learned" in summary
    assert "Shop" in summary


def test_compact_history_includes_failures() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(10):
        memory.record_action(
            AgentAction(tool="click", params={"selector": f".btn{i}"}, result="OK")
        )
    memory.failed_selectors.add(".broken-selector")
    summary = memory.compact_history(keep_recent=5)
    assert "Failed selectors" in summary
    assert ".broken-selector" in summary


# ------------------------------------------------------------------
# Serialization with new fields
# ------------------------------------------------------------------


def test_to_dict_includes_new_fields() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.failed_selectors.add(".bad")
    memory.failed_urls.add("https://bad.com")
    memory.strategies_tried.append("css_extraction")
    memory.record_page_knowledge(
        url="https://shop.com",
        title="Shop",
        element_count=100,
        has_pagination=False,
        key_selectors={"item": ".item"},
    )

    data = memory.to_dict()
    assert ".bad" in data["failed_selectors"]
    assert "https://bad.com" in data["failed_urls"]
    assert "css_extraction" in data["strategies_tried"]
    assert "https://shop.com" in data["page_knowledge"]


def test_from_dict_restores_new_fields() -> None:
    data = {
        "goal": "test",
        "visited_urls": ["https://shop.com"],
        "extracted_data": [],
        "step_count": 5,
        "current_url": "https://shop.com",
        "failed_selectors": [".bad"],
        "failed_urls": ["https://bad.com"],
        "strategies_tried": ["css_extraction"],
        "page_knowledge": {
            "https://shop.com": {
                "url": "https://shop.com",
                "title": "Shop",
                "element_count": 100,
                "has_pagination": True,
                "key_selectors": {"item": ".item"},
                "content_summary": "Product listings",
            }
        },
    }

    memory = AgentMemory.from_dict(data, Product)
    assert memory.failed_selectors == {".bad"}
    assert memory.failed_urls == {"https://bad.com"}
    assert memory.strategies_tried == ["css_extraction"]
    pk = memory.get_page_knowledge("https://shop.com")
    assert pk is not None
    assert pk.title == "Shop"
    assert pk.has_pagination is True
    assert pk.content_summary == "Product listings"
