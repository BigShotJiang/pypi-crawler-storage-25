"""CLI sub-package."""
