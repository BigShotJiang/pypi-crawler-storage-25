from __future__ import annotations

import shutil
from pathlib import Path

import typer


init_skills_app = typer.Typer(add_completion=False)


@init_skills_app.command("init")
def init_skills(
    path: str = typer.Argument(
        "/home/user/workspace/.claude/",
        help="Destination directory; will copy skills/ and commands/ under it",
    ),
) -> None:
    package_root = Path(__file__).resolve().parents[1]
    src_skills = package_root / "assets" / "skills"
    src_commands = package_root / "assets" / "commands"

    if not src_skills.exists():
        raise typer.BadParameter(f"Missing {src_skills}")
    if not src_commands.exists():
        raise typer.BadParameter(f"Missing {src_commands}")

    dest_root = Path(path).expanduser().resolve()
    dest_root.mkdir(parents=True, exist_ok=True)

    shutil.copytree(src_skills, dest_root / "skills", dirs_exist_ok=True)
    shutil.copytree(src_commands, dest_root / "commands", dirs_exist_ok=True)

    typer.echo(str(dest_root))
