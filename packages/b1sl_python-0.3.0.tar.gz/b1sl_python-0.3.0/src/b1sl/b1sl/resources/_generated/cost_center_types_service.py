from __future__ import annotations
from typing import TYPE_CHECKING, Any
from b1sl.b1sl.resources.base import GenericResource

if TYPE_CHECKING:
    from ...models._generated._types import *

class CostCenterTypesService(GenericResource[Any]):
    endpoint = "CostCenterTypesService"
    
    def __init__(self, adapter):
        self.model = None
        super().__init__(adapter)

    # --- Actions ---

    def get_cost_center_type_list(self, payload: dict | None = None) -> Any:
        """POST CostCenterTypesService_GetCostCenterTypeList
        Invoke the method 'GetCostCenterTypeList' on this service.
        """
        return self._adapter.post(f"CostCenterTypesService_GetCostCenterTypeList", data=payload)
