from __future__ import annotations
from typing import TYPE_CHECKING, Any
from b1sl.b1sl.resources.base import GenericResource

if TYPE_CHECKING:
    from ...models._generated._types import *

class PurchaseCreditNotesService(GenericResource[Any]):
    endpoint = "PurchaseCreditNotesService"
    
    def __init__(self, adapter):
        self.model = None
        super().__init__(adapter)

    # --- Actions ---

    def approve_and_add(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_ApproveAndAdd
        """
        return self._adapter.post(f"PurchaseCreditNotesService_ApproveAndAdd", data=payload)

    def approve_and_update(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_ApproveAndUpdate
        """
        return self._adapter.post(f"PurchaseCreditNotesService_ApproveAndUpdate", data=payload)

    def cancel2(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_Cancel2
        Invoke the method 'Cancel2' on this service by specifying the payload 'Document' in the JSON format. This method allows you to change some properties before cancelling one document.

        Example:
        ```json
        {
            "Document": {
                "Comments": "via SL.",
                "DocEntry": 123
            }
        }
        ```
        """
        return self._adapter.post(f"PurchaseCreditNotesService_Cancel2", data=payload)

    def close_by_date(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_CloseByDate
        """
        return self._adapter.post(f"PurchaseCreditNotesService_CloseByDate", data=payload)

    def export_e_way_bill(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_ExportEWayBill
        """
        return self._adapter.post(f"PurchaseCreditNotesService_ExportEWayBill", data=payload)

    def get_approval_templates(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_GetApprovalTemplates
        Invoke the method 'GetApprovalTemplates' on this service by specifying the payload 'Document' in the JSON format.

        Example:
        ```json
        {
            "Document": {
                "CardCode": "c001",
                "DocumentLines": [
                    {
                        "ItemCode": "i001",
                        "Quantity": "100",
                        "TaxCode": "T1",
                        "UnitPrice": "30"
                    }
                ]
            }
        }
        ```
        """
        return self._adapter.post(f"PurchaseCreditNotesService_GetApprovalTemplates", data=payload)

    def handle_approval_request(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_HandleApprovalRequest
        Invoke the method 'HandleApprovalRequest' on this service.
        """
        return self._adapter.post(f"PurchaseCreditNotesService_HandleApprovalRequest", data=payload)

    def init_data(self, payload: dict | None = None) -> Any:
        """POST PurchaseCreditNotesService_InitData
        """
        return self._adapter.post(f"PurchaseCreditNotesService_InitData", data=payload)
