from __future__ import annotations
from typing import TYPE_CHECKING, Any
from b1sl.b1sl.resources.base import GenericResource

if TYPE_CHECKING:
    from ...models._generated._types import *

class CampaignResponseTypeService(GenericResource[Any]):
    endpoint = "CampaignResponseTypeService"
    
    def __init__(self, adapter):
        self.model = None
        super().__init__(adapter)

    # --- Actions ---

    def get_response_type_list(self, payload: dict | None = None) -> Any:
        """POST CampaignResponseTypeService_GetResponseTypeList
        Invoke the method 'GetResponseTypeList' on this service.
        """
        return self._adapter.post(f"CampaignResponseTypeService_GetResponseTypeList", data=payload)
