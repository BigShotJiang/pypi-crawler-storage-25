from __future__ import annotations
from typing import TYPE_CHECKING, Any
from b1sl.b1sl.resources.base import GenericResource

if TYPE_CHECKING:
    from ...models._generated._types import *

class ProfitCentersService(GenericResource[Any]):
    endpoint = "ProfitCentersService"
    
    def __init__(self, adapter):
        self.model = None
        super().__init__(adapter)

    # --- Actions ---

    def get_profit_center_list(self, payload: dict | None = None) -> Any:
        """POST ProfitCentersService_GetProfitCenterList
        Invoke the method 'GetProfitCenterList' on this service.
        """
        return self._adapter.post(f"ProfitCentersService_GetProfitCenterList", data=payload)
