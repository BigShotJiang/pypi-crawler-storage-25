from __future__ import annotations
from typing import TYPE_CHECKING, Any
from b1sl.b1sl.resources.base import GenericResource

if TYPE_CHECKING:
    from ...models._generated._types import *

class BudgetsService(GenericResource["Budget"]):
    """This entity enables you to manipulate 'Budgets' based on G/L accounts."""
    endpoint = "Budgets"
    
    def __init__(self, adapter):
        from ...models._generated._types import Budget
        self.model = Budget
        super().__init__(adapter)
