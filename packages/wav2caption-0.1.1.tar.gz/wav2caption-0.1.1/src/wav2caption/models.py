"""Model file discovery for Essentia TensorFlow graphs.

Models are **not** bundled — they are licensed separately (CC-BY-NC-SA 4.0
by MTG-Jamendo). Users download once and point ``WAV2CAPTION_MODELS_DIR`` at
the folder.

Default download source (as of 2026-04): https://essentia.upf.edu/models/
- ``discogs-effnet-bs64-1.pb`` (embedding backbone)
- ``mtg_jamendo_instrument-discogs-effnet-1.pb`` (40-class head)
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path

EFFNET_FILENAME = "discogs-effnet-bs64-1.pb"
INSTRUMENT_FILENAME = "mtg_jamendo_instrument-discogs-effnet-1.pb"

#: Expected URLs (HTTPS-only) for the two official Essentia model files.
EFFNET_URL = (
    "https://essentia.upf.edu/models/feature-extractors/discogs-effnet/"
    + EFFNET_FILENAME
)
INSTRUMENT_URL = (
    "https://essentia.upf.edu/models/classification-heads/mtg_jamendo_instrument/"
    + INSTRUMENT_FILENAME
)

#: SHA-256 digests captured on 2026-04-18 against the live
#: ``essentia.upf.edu`` downloads. Supply-chain guard: a maliciously
#: crafted TensorFlow graph can influence what runs inside Essentia, so
#: any downstream service that auto-downloads these files **should**
#: verify digests before loading. :func:`verify_digests` is provided for
#: that; CLIs may opt in via ``WAV2CAPTION_VERIFY_DIGESTS=1``.
EFFNET_SHA256 = "3ed9af50d5367c0b9c795b294b00e7599e4943244f4cbd376869f3bfc87721b1"
INSTRUMENT_SHA256 = "2e8c3003c722e098da371b6a1f7ad0ce62fac0dcfc09c7c7997d430941196c2a"

_ENV_VAR = "WAV2CAPTION_MODELS_DIR"
_VERIFY_ENV_VAR = "WAV2CAPTION_VERIFY_DIGESTS"
_DEFAULT_DIR = Path.home() / ".cache" / "wav2caption" / "models"


@dataclass(frozen=True)
class ModelPaths:
    effnet: Path
    instrument: Path

    def validate(self) -> None:
        missing = [p for p in (self.effnet, self.instrument) if not p.is_file()]
        if missing:
            listing = "\n  ".join(str(p) for p in missing)
            raise FileNotFoundError(
                "Essentia model file(s) not found:\n  "
                f"{listing}\n\n"
                f"Set {_ENV_VAR} to the directory that contains them, or place\n"
                f"them under {_DEFAULT_DIR}.\n\n"
                "Download:\n"
                f"  {EFFNET_URL}\n"
                f"  {INSTRUMENT_URL}\n"
                "Models are CC-BY-NC-SA 4.0 (non-commercial)."
            )
        if os.environ.get(_VERIFY_ENV_VAR):
            verify_digests(self)

    def verify(self) -> None:
        """Raise :class:`ValueError` if either model file's SHA-256 doesn't match."""
        verify_digests(self)


def _sha256_of(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            buf = f.read(chunk)
            if not buf:
                break
            h.update(buf)
    return h.hexdigest()


def verify_digests(paths: ModelPaths) -> None:
    """Verify the two Essentia graphs match the captured SHA-256 digests.

    Raises :class:`ValueError` on mismatch (or :class:`FileNotFoundError`
    if either file is absent). Useful from your own code, or automatic
    via the ``WAV2CAPTION_VERIFY_DIGESTS`` env var.
    """
    for path, expected in (
        (paths.effnet, EFFNET_SHA256),
        (paths.instrument, INSTRUMENT_SHA256),
    ):
        if not path.is_file():
            raise FileNotFoundError(path)
        got = _sha256_of(path)
        if got != expected:
            raise ValueError(
                f"SHA-256 mismatch for {path}:\n"
                f"  expected {expected}\n"
                f"  got      {got}\n"
                "Refuse to load potentially-compromised TensorFlow graph."
            )


def resolve_models(models_dir: str | os.PathLike[str] | None = None) -> ModelPaths:
    """Locate the two Essentia model files, honouring ``WAV2CAPTION_MODELS_DIR``."""
    if models_dir is not None:
        base = Path(models_dir).expanduser()
    else:
        env = os.environ.get(_ENV_VAR)
        base = Path(env).expanduser() if env else _DEFAULT_DIR
    return ModelPaths(
        effnet=base / EFFNET_FILENAME,
        instrument=base / INSTRUMENT_FILENAME,
    )
