"""Instrument labels and role grouping for MTG-Jamendo instrument-discogs-effnet."""

from __future__ import annotations

from typing import Final

INSTRUMENTS: Final[tuple[str, ...]] = (
    "accordion", "acousticbassguitar", "acousticguitar", "bass", "beat",
    "bell", "bongo", "brass", "cello", "clarinet", "classicalguitar",
    "computer", "doublebass", "drummachine", "drums", "electricguitar",
    "electricpiano", "flute", "guitar", "harmonica", "harp", "horn",
    "keyboard", "oboe", "orchestra", "organ", "pad", "percussion", "piano",
    "pipeorgan", "rhodes", "sampler", "saxophone", "strings", "synthesizer",
    "trombone", "trumpet", "viola", "violin", "voice",
)

ROLE_MAP: Final[dict[str, tuple[str, ...]]] = {
    "rhythm": ("drums", "drummachine", "beat", "percussion", "bongo"),
    "bass": ("bass", "acousticbassguitar", "doublebass"),
    "harmony": ("piano", "electricpiano", "keyboard", "rhodes", "organ", "pipeorgan", "accordion"),
    "lead_guitar": ("electricguitar",),
    "acoustic_guitar": ("acousticguitar", "classicalguitar", "guitar"),
    "strings": ("strings", "violin", "viola", "cello", "orchestra"),
    "brass": ("brass", "trumpet", "trombone", "horn", "saxophone"),
    "woodwind": ("flute", "clarinet", "oboe"),
    "synth": ("synthesizer", "pad", "sampler", "computer"),
    "bells": ("bell", "harp", "harmonica"),
    "vocal": ("voice",),
}

_INST_TO_ROLE: Final[dict[str, str]] = {
    inst: role for role, members in ROLE_MAP.items() for inst in members
}


def get_role(instrument: str) -> str:
    """Return the role category (e.g. 'rhythm', 'bass', 'harmony') for an instrument label.

    Unknown labels fall back to ``"other"``.
    """
    return _INST_TO_ROLE.get(instrument, "other")
