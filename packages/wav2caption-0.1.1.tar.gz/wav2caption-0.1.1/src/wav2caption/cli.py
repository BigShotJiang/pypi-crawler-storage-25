"""Command-line entry point: ``wav2caption path/to/song.wav``."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

from wav2caption import __version__
from wav2caption.analyzer import AnalysisResult, analyze, build_caption


def _json_default(obj: Any) -> Any:
    """JSON fallback that unwraps NumPy scalars to native Python numbers.

    Essentia returns ``numpy.float64`` / ``numpy.int64`` for many features.
    ``asdict`` does not recurse into NumPy types, so without this hook the
    default encoder would raise ``TypeError`` for them.
    """
    try:
        import numpy as np

        if isinstance(obj, np.generic):
            return obj.item()
    except ImportError:
        pass
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="wav2caption",
        description="Audio → instrument-aware caption for AI music generation.",
    )
    p.add_argument("audio", type=Path, help="Input audio file (WAV/MP3/FLAC)")
    p.add_argument(
        "--models-dir",
        type=Path,
        default=None,
        help="Directory with Essentia .pb files (default: $WAV2CAPTION_MODELS_DIR or ~/.cache/wav2caption/models)",
    )
    p.add_argument(
        "--section-seconds",
        type=float,
        default=10.0,
        help="Per-section window length in seconds (default: 10.0)",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Emit a single JSON object instead of human-readable output",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress logging below WARNING",
    )
    p.add_argument("--version", action="version", version=f"wav2caption {__version__}")
    return p


def _render_human(result: AnalysisResult) -> str:
    lines: list[str] = []
    dur_m, dur_s = divmod(round(result.duration_sec), 60)
    lines.append(f"=== {result.path.name} ===")
    lines.append(
        f"duration: {dur_m}:{dur_s:02d}  tempo: {result.bpm:.1f} BPM  "
        f"key: {result.key} {result.scale} (conf {result.key_confidence:.2f})  "
        f"danceability: {result.danceability:.2f}"
    )
    lines.append("")
    lines.append("[ detected instruments ]")
    for name, score in result.detected_instruments:
        bar = "#" * int(score * 40)
        lines.append(f"  {name:20s} {score:.3f}  {bar}")
    lines.append("")
    lines.append("[ role scores ]")
    for role, score in sorted(result.role_scores.items(), key=lambda x: -x[1]):
        bar = "#" * int(score * 20)
        lines.append(f"  {role:18s} {score:.3f}  {bar}")
    lines.append("")
    lines.append("[ sections ]")
    for s in result.sections:
        sm, ss = divmod(int(s.start), 60)
        em, es_ = divmod(int(s.end), 60)
        role_str = " / ".join(
            f"{r}={n}({v:.2f})"
            for r, (n, v) in sorted(s.roles.items(), key=lambda x: -x[1][1])
        )
        lines.append(
            f"  {sm}:{ss:02d}-{em}:{es_:02d}  loud={s.loudness:.0f}  "
            f"bright={s.centroid_hz:.0f}Hz  {s.key} {s.scale}"
        )
        lines.append(f"    roles: {role_str}")
        if s.features:
            lines.append(f"    features: {', '.join(s.features)}")
    lines.append("")
    lines.append("[ caption ]")
    lines.append(f"  {build_caption(result)}")
    return "\n".join(lines)


def _render_json(result: AnalysisResult) -> str:
    payload = asdict(result)
    payload["path"] = str(result.path)
    payload["caption"] = build_caption(result)
    return json.dumps(payload, ensure_ascii=False, indent=2, default=_json_default)


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.WARNING if args.quiet else logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )
    try:
        result = analyze(
            args.audio,
            section_seconds=args.section_seconds,
            models_dir=args.models_dir,
        )
    except (FileNotFoundError, ValueError, ImportError, RuntimeError) as err:
        print(f"error: {err}", file=sys.stderr)
        return 1
    out = _render_json(result) if args.json else _render_human(result)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
