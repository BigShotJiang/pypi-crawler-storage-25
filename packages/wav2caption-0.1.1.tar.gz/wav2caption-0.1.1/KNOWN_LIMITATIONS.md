# Known Limitations

## L1 — Essentia runtime is AGPL-3.0

The `[essentia]` extra installs `essentia-tensorflow`, which is licensed
under **AGPL-3.0 or a commercial license from MTG-UPF**. Applications
that call into it and are made available to users over a network may
need to release their own source under AGPL-3.0 or purchase a commercial
license. The wav2caption code itself is Apache 2.0.

## L2 — Model weights are CC-BY-NC-SA 4.0 (non-commercial)

The MTG-Jamendo pretrained `.pb` graphs are released by MTG under
**Creative Commons Attribution-NonCommercial-ShareAlike 4.0**. wav2caption
does not bundle them; users download them separately and must honour the
non-commercial restriction.

## L3 — `analyze(path)` follows symlinks

`Path(audio_path).expanduser().resolve()` silently follows symlinks. When
embedding wav2caption in a network service, validate user-supplied audio
paths against an allow-listed directory first.

## L4 — Per-section key/scale reuses the global value

To keep per-section analysis fast, each section reuses the globally
detected key and scale rather than running `KeyExtractor` per window.
Tracks with actual modulations therefore all report the global key.
Callers that care about local key should slice the audio upstream and
call `analyze()` per region.

## L5 — Caption rules are opinionated defaults

`DEFAULT_CAPTION_TAGS` was tuned on a production pipeline that captioned
reference tracks for ACE-Step Lego-mode generation. Your vocabulary will
differ — pass a custom `rules=...` tuple to `build_caption` to override.
