# Third-party notices

`wav2caption` itself is released under the [Apache License 2.0](LICENSE)
and does **not** bundle any third-party code or models. However, at run time
it depends on and interoperates with software under different licenses.
Users are responsible for complying with those licenses.

## Essentia (optional runtime dependency via `[essentia]` extra)

Distributed under the **GNU Affero General Public License v3 (AGPL-3.0)**
or a commercial license from MTG-UPF. Applications that link against
Essentia and are made available to users over a network may need to
release their own source code under AGPL-3.0.

See: https://essentia.upf.edu/licensing_information.html

## MTG-Jamendo pretrained models

`discogs-effnet-bs64-1.pb` and
`mtg_jamendo_instrument-discogs-effnet-1.pb` are released by MTG under
**Creative Commons Attribution-NonCommercial-ShareAlike 4.0
(CC-BY-NC-SA 4.0)**. They are **not** bundled with this package; users
download them separately and must honour the non-commercial restriction.

See: https://essentia.upf.edu/models/
