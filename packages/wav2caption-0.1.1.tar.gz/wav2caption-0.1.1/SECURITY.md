# Security Policy

## Supported versions

Only the latest `0.1.x` series receives security fixes.

## Reporting a vulnerability

Please report security issues **privately** via GitHub's
[Security Advisories](https://github.com/hinanohart/wav2caption/security/advisories/new).
Do **not** open a public issue.

- Acknowledgement target: **7 days**.
- Coordinated disclosure window: **90 days** by default; shorter if the
  issue is already being exploited in the wild.

## Trust model

wav2caption is a **library + CLI** and has no network-reachable attack
surface of its own. The caller supplies both the audio file and the
Essentia model `.pb` paths, so local file-handling hardening is the
responsibility of the wrapping application:

- `analyze(audio_path)` resolves symlinks with
  `Path.expanduser().resolve()`. Network services that accept an
  arbitrary path from users must validate it against an allow-listed
  directory before calling in.
- The two Essentia model files are downloaded by the user; the install
  guide in README includes SHA-256 digests so you can verify the binary
  before TensorFlow loads the graph.

## Hardenings already in place

- Input validation on audio duration, `section_seconds`, and model file
  existence (with a friendly multi-line error pointing at
  `WAV2CAPTION_MODELS_DIR`).
- Essentia `RuntimeError` (raised on corrupt / unsupported codecs) is
  wrapped in `ValueError` so the CLI surfaces a friendly error rather
  than a raw stack trace.
- NumPy-aware JSON encoder unwraps `numpy.generic` scalars so `--json`
  output cannot fall through to `str(obj)` for non-serialisable types.
