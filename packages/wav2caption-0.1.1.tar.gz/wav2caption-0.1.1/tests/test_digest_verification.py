"""SHA-256 digest verification tests (no real model download needed)."""

from __future__ import annotations

from pathlib import Path

import pytest

from wav2caption.models import (
    EFFNET_FILENAME,
    EFFNET_SHA256,
    INSTRUMENT_FILENAME,
    INSTRUMENT_SHA256,
    ModelPaths,
    verify_digests,
)


def _write(path: Path, payload: bytes) -> None:
    path.write_bytes(payload)


def test_digest_matches_when_bytes_match(tmp_path: Path) -> None:
    effnet = tmp_path / EFFNET_FILENAME
    instrument = tmp_path / INSTRUMENT_FILENAME

    # Fabricate files whose SHA-256 equals the expected digests by
    # writing known bytes and monkey-patching the constants (safer than
    # depending on a real 18 MB download in CI).
    known_bytes = b"ci-test"
    _write(effnet, known_bytes)
    _write(instrument, b"other-bytes")

    # Compute the actual hash on the fly so the test is hermetic.
    import hashlib

    import wav2caption.models as models

    mp = ModelPaths(effnet=effnet, instrument=instrument)
    monkey_expected_e = hashlib.sha256(known_bytes).hexdigest()
    monkey_expected_i = hashlib.sha256(b"other-bytes").hexdigest()

    original_e, original_i = models.EFFNET_SHA256, models.INSTRUMENT_SHA256
    models.EFFNET_SHA256 = monkey_expected_e
    models.INSTRUMENT_SHA256 = monkey_expected_i
    try:
        verify_digests(mp)  # should not raise
    finally:
        models.EFFNET_SHA256, models.INSTRUMENT_SHA256 = original_e, original_i


def test_digest_raises_on_mismatch(tmp_path: Path) -> None:
    effnet = tmp_path / EFFNET_FILENAME
    instrument = tmp_path / INSTRUMENT_FILENAME
    _write(effnet, b"garbage")
    _write(instrument, b"garbage2")

    mp = ModelPaths(effnet=effnet, instrument=instrument)
    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        verify_digests(mp)


def test_digest_constants_are_well_formed() -> None:
    assert len(EFFNET_SHA256) == 64
    assert len(INSTRUMENT_SHA256) == 64
    assert all(c in "0123456789abcdef" for c in EFFNET_SHA256)
    assert all(c in "0123456789abcdef" for c in INSTRUMENT_SHA256)


def test_digest_raises_on_missing(tmp_path: Path) -> None:
    mp = ModelPaths(
        effnet=tmp_path / EFFNET_FILENAME,
        instrument=tmp_path / INSTRUMENT_FILENAME,
    )
    with pytest.raises(FileNotFoundError):
        verify_digests(mp)
