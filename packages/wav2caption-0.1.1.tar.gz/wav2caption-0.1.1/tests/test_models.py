from __future__ import annotations

from pathlib import Path

import pytest

from wav2caption.models import (
    EFFNET_FILENAME,
    INSTRUMENT_FILENAME,
    ModelPaths,
    resolve_models,
)


def test_resolve_models_explicit_dir(tmp_path: Path) -> None:
    paths = resolve_models(tmp_path)
    assert paths.effnet == tmp_path / EFFNET_FILENAME
    assert paths.instrument == tmp_path / INSTRUMENT_FILENAME


def test_resolve_models_env_var(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("WAV2CAPTION_MODELS_DIR", str(tmp_path))
    paths = resolve_models()
    assert paths.effnet.parent == tmp_path


def test_validate_raises_when_missing(tmp_path: Path) -> None:
    paths = resolve_models(tmp_path)
    with pytest.raises(FileNotFoundError) as exc:
        paths.validate()
    # Helpful error should mention both filenames.
    assert EFFNET_FILENAME in str(exc.value)
    assert INSTRUMENT_FILENAME in str(exc.value)


def test_validate_passes_when_present(tmp_path: Path) -> None:
    (tmp_path / EFFNET_FILENAME).write_bytes(b"\x00")
    (tmp_path / INSTRUMENT_FILENAME).write_bytes(b"\x00")
    paths = ModelPaths(
        effnet=tmp_path / EFFNET_FILENAME,
        instrument=tmp_path / INSTRUMENT_FILENAME,
    )
    paths.validate()  # no exception
