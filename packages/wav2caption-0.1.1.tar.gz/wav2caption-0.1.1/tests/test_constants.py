from __future__ import annotations

from wav2caption.constants import INSTRUMENTS, ROLE_MAP, get_role


def test_instruments_match_mtg_jamendo_head() -> None:
    # The 40-label MTG-Jamendo head must stay exactly 40 classes in this order.
    assert len(INSTRUMENTS) == 40
    assert INSTRUMENTS[0] == "accordion"
    assert INSTRUMENTS[-1] == "voice"
    assert len(set(INSTRUMENTS)) == 40  # no duplicates


def test_roles_partition_instruments() -> None:
    covered = {inst for members in ROLE_MAP.values() for inst in members}
    # Every role-map entry must correspond to a real instrument label.
    assert covered.issubset(set(INSTRUMENTS))


def test_get_role_known_and_unknown() -> None:
    assert get_role("drums") == "rhythm"
    assert get_role("voice") == "vocal"
    assert get_role("trumpet") == "brass"
    assert get_role("not-a-real-instrument") == "other"


def test_no_instrument_mapped_twice() -> None:
    seen: dict[str, str] = {}
    for role, members in ROLE_MAP.items():
        for m in members:
            assert m not in seen, f"{m} is mapped to both {seen[m]} and {role}"
            seen[m] = role
