from __future__ import annotations

import subprocess
import sys

import pytest

from wav2caption.cli import _build_parser, main


def test_parser_builds_and_accepts_audio_arg() -> None:
    parser = _build_parser()
    ns = parser.parse_args(["song.wav"])
    assert str(ns.audio) == "song.wav"
    assert ns.section_seconds == 10.0
    assert ns.json is False


def test_parser_json_flag() -> None:
    ns = _build_parser().parse_args(["song.wav", "--json"])
    assert ns.json is True


def test_main_returns_1_on_missing_file(tmp_path, capsys) -> None:
    rc = main([str(tmp_path / "no.wav")])
    captured = capsys.readouterr()
    assert rc == 1
    assert "error" in captured.err.lower()


def test_console_script_help() -> None:
    # Use the module form so the test works even before `pip install -e .`
    result = subprocess.run(
        [sys.executable, "-m", "wav2caption.cli", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert "wav2caption" in result.stdout


@pytest.mark.parametrize("flag", ["--version"])
def test_version_flag(flag: str) -> None:
    result = subprocess.run(
        [sys.executable, "-m", "wav2caption.cli", flag],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert "wav2caption" in result.stdout
