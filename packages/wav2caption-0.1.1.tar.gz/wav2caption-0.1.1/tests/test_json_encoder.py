"""Cover the NumPy-aware JSON fallback without requiring Essentia."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from wav2caption.cli import _json_default


def test_json_default_unwraps_numpy_float() -> None:
    np = pytest.importorskip("numpy")
    assert _json_default(np.float64(0.5)) == 0.5
    assert _json_default(np.int64(7)) == 7


def test_json_default_stringifies_path() -> None:
    assert _json_default(Path("/tmp/x")) == "/tmp/x"


def test_json_default_raises_for_unknown() -> None:
    with pytest.raises(TypeError):
        _json_default(object())


def test_json_dumps_round_trips_with_numpy() -> None:
    np = pytest.importorskip("numpy")
    payload = {"bpm": np.float32(128.0), "frames": np.int32(440)}
    out = json.dumps(payload, default=_json_default)
    restored = json.loads(out)
    assert restored == {"bpm": 128.0, "frames": 440}
