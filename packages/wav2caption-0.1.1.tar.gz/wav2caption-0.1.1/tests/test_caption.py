"""Unit-test caption generation with synthetic AnalysisResult fixtures."""

from __future__ import annotations

from pathlib import Path

from wav2caption.analyzer import (
    AnalysisResult,
    CaptionTag,
    Section,
    build_caption,
)


def _section(start: float, loud: float, features: list[str] | None = None) -> Section:
    return Section(
        start=start,
        end=start + 10.0,
        loudness=loud,
        centroid_hz=1200.0,
        key="C",
        scale="major",
        roles={},
        top_instruments=[],
        features=features or [],
    )


def _result(
    detected: list[tuple[str, float]],
    sections: list[Section] | None = None,
) -> AnalysisResult:
    return AnalysisResult(
        path=Path("/tmp/demo.wav"),
        duration_sec=60.0,
        bpm=120.0,
        key="C",
        scale="major",
        key_confidence=0.9,
        danceability=0.5,
        detected_instruments=detected,
        role_scores={},
        sections=sections or [_section(0.0, 800.0)],
    )


def test_caption_rock_band() -> None:
    caption = build_caption(
        _result(
            detected=[
                ("drums", 0.5),
                ("electricguitar", 0.4),
                ("bass", 0.3),
                ("voice", 0.2),
            ]
        )
    )
    assert "live drums" in caption
    assert "electric guitar" in caption
    assert "bass" in caption
    assert "C major" in caption
    assert "120 BPM" in caption
    assert "4/4" in caption


def test_caption_orchestral() -> None:
    caption = build_caption(
        _result(
            detected=[
                ("strings", 0.5),
                ("violin", 0.4),
                ("cello", 0.3),
                ("trumpet", 0.2),
                ("piano", 0.15),
            ]
        )
    )
    assert "string section" in caption
    assert "brass section" in caption
    assert "piano" in caption


def test_caption_detects_dynamic_build_up() -> None:
    caption = build_caption(
        _result(
            detected=[("drums", 0.5)],
            sections=[_section(0.0, 200.0), _section(10.0, 2000.0)],
        )
    )
    assert "dynamic build-up" in caption


def test_caption_detects_breakdown_from_feature_tag() -> None:
    caption = build_caption(
        _result(
            detected=[("piano", 0.3)],
            sections=[
                _section(0.0, 900.0, features=["quiet (breakdown/interlude)"]),
            ],
        )
    )
    assert "breakdown section" in caption


def test_caption_empty_detection_still_has_key_tempo() -> None:
    caption = build_caption(_result(detected=[]))
    assert "C major" in caption
    assert "120 BPM" in caption
    assert "4/4" in caption
    # Regression guard: no detected instruments must not produce a leading
    # comma/space ("`, C major, 120 BPM, 4/4`" used to happen because an
    # empty style_words list left a bare `", ".join(style_words)`).
    assert not caption.startswith(",")
    assert not caption.startswith(" ")
    assert ",," not in caption


def test_caption_accepts_custom_rules() -> None:
    custom = (
        CaptionTag("jazz combo", 5, frozenset({"saxophone"})),
        CaptionTag("groove", 3, frozenset({"drums"}), match="substr"),
    )
    caption = build_caption(
        _result(detected=[("drums", 0.5), ("saxophone", 0.3)]),
        rules=custom,
    )
    assert "groove" in caption
    assert "jazz combo" in caption
    # Default tags must NOT leak through.
    assert "live drums" not in caption
    assert "electric guitar" not in caption


def test_caption_rule_respects_top_k() -> None:
    # "bell" would only match if we look at the top 10, so place it 5th.
    detected = [
        ("drums", 0.5),
        ("guitar", 0.4),
        ("bass", 0.3),
        ("piano", 0.2),
        ("bell", 0.1),
    ]
    caption = build_caption(
        _result(detected=detected),
        rules=(CaptionTag("bells up front", 3, frozenset({"bell"})),),
    )
    assert "bells up front" not in caption
    caption2 = build_caption(
        _result(detected=detected),
        rules=(CaptionTag("bells up front", 10, frozenset({"bell"})),),
    )
    assert "bells up front" in caption2
