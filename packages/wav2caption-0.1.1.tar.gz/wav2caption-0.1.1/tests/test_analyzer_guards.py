"""Analyzer input-validation tests that don't require essentia/TensorFlow."""

from __future__ import annotations

import pytest

from wav2caption.analyzer import analyze


def test_analyze_rejects_missing_file(tmp_path):
    missing = tmp_path / "nope.wav"
    with pytest.raises(FileNotFoundError):
        analyze(missing)


def test_analyze_rejects_bad_section_seconds(tmp_path):
    f = tmp_path / "dummy.wav"
    f.write_bytes(b"\x00")
    with pytest.raises(ValueError):
        analyze(f, section_seconds=0)
    with pytest.raises(ValueError):
        analyze(f, section_seconds=-5)
