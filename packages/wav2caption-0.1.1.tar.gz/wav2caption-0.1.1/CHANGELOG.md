# Changelog

All notable changes to this project will be documented in this file.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) · semver.

## [0.1.1] — 2026-04-18

### Changed
- **License**: switched from MIT to **Apache License 2.0** for
  consistency with the author's other OSS projects (mosaicraft, yuragi)
  and to obtain an explicit patent-grant clause — the industry standard
  for ML/AI libraries. Third-party notices moved to `NOTICE.md` so the
  `LICENSE` file is a pristine Apache-2.0 template that GitHub detects
  correctly.

### Fixed
- `build_caption` no longer returns a leading-comma string when no
  instruments are detected (would previously yield
  `", C major, 120 BPM, 4/4"`).
- `_import_essentia` error message now points at
  `pip install "wav2caption[essentia]"` so users discover the extras
  group advertised in README.
- CLI now catches Essentia's `RuntimeError` (raised on corrupt /
  unsupported codecs) and wraps it as a friendly `ValueError`; the
  decoder path also wraps the same exception upstream.

### Added
- `SECURITY.md` with private-disclosure instructions and trust model.
- `KNOWN_LIMITATIONS.md` documenting the AGPL/CC-BY-NC-SA runtime,
  symlink-following behaviour, global-only key inference, and the
  opinionated caption vocabulary.
- Dependabot config for `pip` and `github-actions`.
- GitHub Actions pinned to commit SHAs; explicit minimal `permissions`
  block on the CI workflow.
- `Literal["exact","substr"]` typing on `CaptionTag.match` so mypy can
  statically catch mis-spelled match modes.
- More SEO keywords in package metadata (audio-captioning,
  music-generation, prompt-generation, text-to-music).

## [0.1.0] — 2026-04-18

First public release.

### Added
- Per-file analysis: BPM, key/scale, danceability, 40-class instrument detection
  (MTG-Jamendo / Discogs-EffNet).
- Per-section analysis (default 10 s windows): loudness, spectral centroid,
  per-role dominant instrument, feature tags (bright highs, breakdown, brass
  accents, string harmonies, staccato stabs, …).
- Automatic ACE-Step / Suno / Udio prompt caption generation from the
  analysis result.
- Typed public API (`analyze`, `build_caption`, `AnalysisResult`, `Section`)
  and `wav2caption` CLI with `--json` output.
- Model files are user-provided (CC-BY-NC-SA 4.0); no model weights bundled.
