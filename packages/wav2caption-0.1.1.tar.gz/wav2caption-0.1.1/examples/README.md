# Examples

Drop a `song.wav` / `song.mp3` / `song.flac` in this directory (it is
`.gitignore`'d) and run:

```bash
wav2caption examples/song.wav
wav2caption examples/song.wav --json | jq '.caption'
wav2caption examples/song.wav --section-seconds 5
```

The folder is untracked on purpose — audio files are heavy, their licensing
is messy, and the CLI is the single source of truth anyway.
