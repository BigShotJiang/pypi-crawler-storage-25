# stacy

[![PyPI - Version](https://img.shields.io/pypi/v/stacy.svg)](https://pypi.org/project/stacy)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/stacy.svg)](https://pypi.org/project/stacy)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install stacy
```

## License

`stacy` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
