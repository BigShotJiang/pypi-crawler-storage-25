import re
import sys
from typing import Any, List, Optional, Union

EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')


def _prompt(message: str) -> str:
    """Display message and get user input."""
    return input(message)


def _error(message: str) -> None:
    """Display error message to stderr."""
    print(f"Error: {message}", file=sys.stderr)


class Ask:
    """Main class for handling user input with validation."""

    def text(
        self,
        prompt: str,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None,
        required: bool = True,
        empty_error: str = "Input cannot be empty. Please try again.",
        min_error: str = None,
        max_error: str = None,
        pattern_error: str = "Input does not match the required format.",
    ) -> str:
        """
        Get text input from user with optional validation.
        
        Args:
            prompt: Message to display to the user
            min_length: Minimum allowed length
            max_length: Maximum allowed length
            pattern: Regex pattern to validate against
            required: Whether input cannot be empty
            
        Returns:
            The validated text input
        """
        while True:
            value = _prompt(prompt).strip()
            
            if not value:
                if required:
                    _error(empty_error)
                    continue
                return value
            
            if min_length is not None and len(value) < min_length:
                _error(min_error or f"Input must be at least {min_length} characters long.")
                continue
            
            if max_length is not None and len(value) > max_length:
                _error(max_error or f"Input must be at most {max_length} characters long.")
                continue
            
            if pattern is not None:
                if not re.match(pattern, value):
                    _error(pattern_error)
                    continue
            
            return value

    def int(
        self,
        prompt: str,
        min_value: Optional[int] = None,
        max_value: Optional[int] = None,
        invalid_error: str = "Please enter a valid integer.",
        min_error: str = None,
        max_error: str = None,
    ) -> int:
        """
        Get integer input from user with optional range validation.
        
        Args:
            prompt: Message to display to the user
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)
            
        Returns:
            The validated integer input
        """
        while True:
            value = _prompt(prompt).strip()
            
            try:
                result = int(value)
            except ValueError:
                _error(invalid_error)
                continue
            
            if min_value is not None and result < min_value:
                _error(min_error or f"Value must be at least {min_value}.")
                continue
            
            if max_value is not None and result > max_value:
                _error(max_error or f"Value must be at most {max_value}.")
                continue
            
            return result

    def float(
        self,
        prompt: str,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None,
        invalid_error: str = "Please enter a valid number.",
        min_error: str = None,
        max_error: str = None,
    ) -> float:
        """
        Get float input from user with optional range validation.
        
        Args:
            prompt: Message to display to the user
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)
            
        Returns:
            The validated float input
        """
        while True:
            value = _prompt(prompt).strip()
            
            try:
                result = float(value)
            except ValueError:
                _error(invalid_error)
                continue
            
            if min_value is not None and result < min_value:
                _error(min_error or f"Value must be at least {min_value}.")
                continue
            
            if max_value is not None and result > max_value:
                _error(max_error or f"Value must be at most {max_value}.")
                continue
            
            return result

    def bool(
        self,
        prompt: str,
        true_values: Optional[List[str]] = None,
        false_values: Optional[List[str]] = None,
        invalid_error: Optional[str] = None,
    ) -> bool:
        """
        Get boolean input from user.
        
        Args:
            prompt: Message to display to the user
            true_values: Values considered as True (default: yes, y, true, t, 1)
            false_values: Values considered as False (default: no, n, false, f, 0)
            
        Returns:
            Boolean value based on user input
        """
        if true_values is None:
            true_values = ["yes", "y", "true", "t", "1"]
        if false_values is None:
            false_values = ["no", "n", "false", "f", "0"]
        
        while True:
            value = _prompt(prompt).strip().lower()
            
            if value in true_values:
                return True
            elif value in false_values:
                return False
            else:
                _error(invalid_error or f"Please enter: {', '.join(true_values + false_values)}")

    def email(
        self,
        prompt: str,
        empty_error: str = "Email cannot be empty. Please try again.",
        invalid_error: str = "Please enter a valid email address (e.g., user@example.com).",
    ) -> str:
        """
        Get email input from user with validation.
        
        Args:
            prompt: Message to display to the user
            
        Returns:
            The validated email address
        """
        while True:
            value = _prompt(prompt).strip()
            
            if not value:
                _error(empty_error)
                continue
            
            if not EMAIL_PATTERN.match(value):
                _error(invalid_error)
                continue
            
            return value

    def password(
        self,
        prompt: str = "Enter password: ",
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        min_error: str = None,
        max_error: str = None,
    ) -> str:
        """
        Get password input from user (hidden).
        
        Args:
            prompt: Message to display to the user
            min_length: Minimum allowed length
            max_length: Maximum allowed length
            
        Returns:
            The password input (hidden from display)
        """
        import getpass
        
        while True:
            value = getpass.getpass(prompt)
            
            if min_length is not None and len(value) < min_length:
                _error(min_error or f"Password must be at least {min_length} characters long.")
                continue
            
            if max_length is not None and len(value) > max_length:
                _error(max_error or f"Password must be at most {max_length} characters long.")
                continue
            
            return value

    def choice(
        self,
        prompt: str,
        options: List[str],
        case_sensitive: bool = False,
        invalid_error: str = None,
    ) -> str:
        """
        Get a choice from a list of options.
        
        Args:
            prompt: Message to display to the user
            options: List of valid options
            case_sensitive: Whether to match case
            
        Returns:
            The selected option
        """
        options_display = ", ".join(options)
        
        while True:
            value = _prompt(prompt).strip()
            
            if not case_sensitive:
                value = value.lower()
                options_lower = [opt.lower() for opt in options]
                if value in options_lower:
                    return options[options_lower.index(value)]
            else:
                if value in options:
                    return value
            
            _error(invalid_error or f"Please choose from: {options_display}")


ask = Ask()