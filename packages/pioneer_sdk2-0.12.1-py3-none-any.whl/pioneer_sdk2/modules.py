import socket
from enum import Enum
from .config import CONFIG

class ServoPriority(Enum):
    HIGH = 0
    MEDIUM = 1
    LOW = 2

class ServoCamera:
    """
    Класс для управления сервоприводом камеры.
    """
    def __init__(self):
        """
        Инициализирует объект ServoCamera.
        Проверяет, поддерживает ли текущий борт сервомоторы камеры.

        Raises:
            ValueError: Если борт не поддерживает сервомоторы камеры.
        """
        if CONFIG.get("servo"):
            self.__servo_socket = "/tmp/servo.sock"
        else:
            raise ValueError("Данный борт не поддерживает сервомоторы")
        
    def set_angle(self, angle: float, priority: ServoPriority = ServoPriority.LOW):
        """
        Устанавливает угол поворота сервопривода камеры.

        Args:
            angle (float): Угол в градусах, должен быть в диапазоне от -80 до 30.
            priority (ServoPriority): Приоритет команды сервопривода (HIGH, MEDIUM, LOW).

        Returns:
            bool: True, если команда успешно отправлена, иначе False.

        Raises:
            ValueError: Если угол выходит за пределы допустимого диапазона (-80 до 30 градусов).
        """
        if not (-80 <= angle <= 30):
            raise ValueError("Угол должен быть в диапазоне от -80 до 30 градусов")
        
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.connect(self.__servo_socket)
                client.sendall(f"{angle} {priority.value}\n".encode('utf-8'))
            return True
        except:
            return False