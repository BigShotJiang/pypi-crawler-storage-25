from abc import ABC, abstractmethod
import numpy as np
from enum import Enum
from ..config import CONFIG

class _CameraTypeSingleton:
    _instance = None
    _camera_type = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(_CameraTypeSingleton, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._camera_type is None:
            self._camera_type = Enum('CameraType', {key.upper(): key for key in CONFIG["cameras"] if key != "driver"})
    
    def get_camera_type(self):
        return self._camera_type


_camera_type_instance = _CameraTypeSingleton()

CameraType = _camera_type_instance.get_camera_type()

class AbstractDriver(ABC):
    @abstractmethod
    def get_cv_frame(self, timeout: float = 5.0) -> np.ndarray:
        pass

    @abstractmethod
    def stop(self):
        pass

    @abstractmethod
    def __del__(self) -> None:
        pass
