import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst, GLib
import cv2
import numpy as np
import threading
import time
import random
import string
from collections import deque
from ..config import CONFIG
from .base import AbstractDriver, CameraType

class GstreamerCamera(AbstractDriver):
    """Класс для захвата видеокадров из GStreamer и предоставления их через очередь."""
    def __init__(self, camera_type = CameraType.MAIN) -> None:
        """Инициализирует объект Camera.

        Args:
            camera_type (CameraType): Тип камеры для захвата (MAIN или OPT).
        """
        Gst.init(None)
        self.camera_type = camera_type
        self.name  = CONFIG["cameras"][camera_type.value]["name"]
        self.width = CONFIG["cameras"][camera_type.value]["width"]
        self.height = CONFIG["cameras"][camera_type.value]["height"]
        self.fps = CONFIG["cameras"][camera_type.value]["fps"]
        self.pipeline = None
        self.appsink = None
        self.running = False

        self.__frame_buffer = deque(maxlen=1)
        self.__frame_condition = threading.Condition()

        self._setup_pipeline()
        self._start()

    def _setup_pipeline(self):
        """Настраивает GStreamer-пайплайн для захвата кадров."""
        random_prefix = ''.join(random.choice(string.ascii_lowercase) for _ in range(6))

        # f"queue max-size-buffers=1 leaky=downstream ! " всегда держим только последний кадр.
        # Если камер несколько, то буфер первой инициализированной заполняется быстрее,
        # поэтому без этого шага пайплайна появляется задержка на одной из них.

        pipeline_str = (
            f"shmsrc socket-path=/tmp/{self.name} do-timestamp=true ! "
            f"queue max-size-buffers=1 leaky=downstream ! "
            f"video/x-raw,format=NV12,width={self.width},height={self.height},framerate={self.fps}/1 ! "
            f"videoconvert ! video/x-raw,format=BGR ! appsink name={self.camera_type.value}_{random_prefix} emit-signals=true sync=false"
        )
        self.pipeline = Gst.parse_launch(pipeline_str)
        self.appsink = self.pipeline.get_by_name(f"{self.camera_type.value}_{random_prefix}")
        self.appsink.set_property("max-buffers", 5)
        self.appsink.set_property("drop", True)
        self.appsink.connect("new-sample", self._on_sample)

    def _on_sample(self, sink):
        """Обрабатывает новые образцы от appsink.

        Args:
            sink (Gst.AppSink): appsink элемент, вызывающий new-sample.

        Returns:
            Gst.FlowReturn: OK при успешном захвате кадра, ERROR в случае ошибки.
        """
        sample = sink.emit("pull-sample")
        buffer = sample.get_buffer()
        
        success, map_info = buffer.map(Gst.MapFlags.READ)
        if not success:
            return Gst.FlowReturn.ERROR
        
        try:
            frame = np.frombuffer(map_info.data, dtype=np.uint8)
            frame = frame.reshape(self.height, self.width, 3)
            with self.__frame_condition:
                self.__frame_buffer.append(frame.copy())
                self.__frame_condition.notify_all()
        finally:
            buffer.unmap(map_info)
            
        return Gst.FlowReturn.OK

    def _start(self):
        """Запускает GStreamer-пайплайн и поток для GLib MainLoop."""
        self.pipeline.set_state(Gst.State.PLAYING)
        self.running = True
        self.thread = threading.Thread(target=self._gst_loop)
        self.thread.start()

    def _gst_loop(self):
        """Запускает цикл обработки сообщений GStreamer."""
        self.loop = GLib.MainLoop()
        self.loop.run()

    def get_cv_frame(self, timeout: float = 5.0) -> np.ndarray:
        """Возвращает следующий доступный кадр из очереди.

        Args:
            timeout (float): Время ожидания в секундах.

        Returns:
            np.ndarray: кадр в формате BGR.

        Raises:
            TimeoutError: Если кадр не был получен в течение указанного таймаута.
        """
        with self.__frame_condition:
            if not self.__frame_condition.wait_for(lambda: len(self.__frame_buffer) > 0, timeout=timeout):
                raise TimeoutError(f"Не удалось получить кадр в течение {timeout} секунд. Проверьте исправность камеры/media-server.")
            return self.__frame_buffer.pop()

    def stop(self):
        """Останавливает GStreamer-пайплайн и завершает поток захвата."""
        self.running = False
        self.pipeline.set_state(Gst.State.NULL)
        self.loop.quit()
        self.thread.join()

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.stop()

class ImageViewer:
    """Класс для трансляции numpy-кадров по RTSP через GStreamer."""
    def __init__(self):
        """Инициализирует GStreamer и подготовку для хранения потоков."""
        Gst.init(None)
        self.streams = {}
        self.start_time = time.time()
        self.frame_count = {}
        
    def _create_stream(self, name: str, width: int, height: int, fps: int = 30):
        """Создаёт и запускает новый RTSP-поток.

        Args:
            name (str): идентификатор потока.
            width (int): ширина кадра.
            height (int): высота кадра.
            fps (int): частота кадров.
        """
        pipeline_str = (
            f"appsrc name=source_{name} is-live=true block=true format=TIME"
            ' ! videoconvert ! video/x-raw,format=I420' + \
            ' ! mpph264enc profile=100 bps=4000000 bps-max=5000000 bps-min=3000000 rc-mode=0 header-mode=1 ' + \
            f"! rtspclientsink location=rtsp://localhost:8554/{name}"
        )
        pipeline = Gst.parse_launch(pipeline_str)
        appsrc = pipeline.get_by_name(f"source_{name}")
        appsrc.set_property("caps", Gst.Caps.from_string(
            f"video/x-raw,format=BGR,width={width},height={height},framerate={fps}/1"
        ))
        pipeline.set_state(Gst.State.PLAYING)
        self.streams[name] = (pipeline, appsrc)
        self.frame_count[name] = 0
        
    def imshow(self, name: str, frame: np.ndarray, fps: int = 30):
        """Отправляет кадр в соответствующий RTSP-поток.

        Args:
            name (str): идентификатор потока.
            frame (np.ndarray): изображение в формате BGR для трансляции.
            fps (int): кадров в секунду при передаче видео (по умолчанию 30)
        """
        if name not in self.streams:
            self._create_stream(name, frame.shape[1], frame.shape[0], fps)
            
        _, appsrc = self.streams[name]
        data = frame.tobytes()
        buffer = Gst.Buffer.new_allocate(None, len(data), None)
        buffer.fill(0, data)

        duration = Gst.util_uint64_scale_int(1, Gst.SECOND, fps)
        timestamp = self.frame_count[name] * duration

        buffer.pts = timestamp
        buffer.dts = timestamp
        buffer.duration = duration

        self.frame_count[name] += 1
        appsrc.emit("push-buffer", buffer)
        
    def close(self):
        """
        Уничтожает все gstreamer пайплайны.
        """
        for name, (pipeline, _) in self.streams.items():
            pipeline.set_state(Gst.State.NULL)
        self.streams.clear()

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.close()