from .config import CONFIG, ConfigException
from .piosdk2 import Pioneer, Event

if CONFIG is not None:
    from .camera_driver.base import CameraType
    if CONFIG['cameras']['driver'] == 'gstreamer':
        from .camera_driver.gstreamer import GstreamerCamera as Camera, ImageViewer
    elif CONFIG['cameras']['driver'] == 'rtsp':
        from .camera_driver.rtsp import RtspCamera as Camera

    if CONFIG['servo']:
        from .modules import ServoPriority, ServoCamera
else:
    raise ConfigException("Не удалось загрузить конфигурацию SDK. Проверьте, что файл board_config.json находится в директории pioneer_sdk2")