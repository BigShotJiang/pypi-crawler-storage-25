# Configuration module

# Audio constants
SR = 44100
BLOCKSIZE = 1024
CHANNELS = 2

# Physics constants
GRAVITY = 0.1
REPULSION = 0.05
CHAOS = 0.01
MOMENTUM = 0.9
TENSION = 0.02

# AI constants
MEMORY_DEPTH = 100
LEARNING_RATE = 0.01

# Network constants
OSC_PORT = 8000
OSC_TARGETS = [("localhost", 9000)]

# Performance constants
MAX_VOICES = 50
SCENE_COUNT = 10