# Mapping

class Mapping:
    def __init__(self):
        self.mappings = {}

    def map(self, input, output):
        self.mappings[input] = output