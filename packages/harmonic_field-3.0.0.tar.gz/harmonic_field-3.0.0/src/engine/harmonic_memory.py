"""
Harmonic Memory
================
Short-term memory of voice ratio states.

  memory.capture(voices)              — snapshot current ratios
  memory.recall(voices, strength)     — blend past snapshots back
                                        into present voices

`strength` ∈ [0.0, 1.0]:
  0.0 = no memory influence (pure physics)
  1.0 = voices pulled fully toward remembered mean

The recall buffer is a rolling window of the last N snapshots.
Blending uses a weighted average: recent snapshots weight more.

This creates a "ghost" of where the voices have been — useful for:
  - Reinforcing motifs that are beginning to cohere
  - Preventing complete chaos from erasing musical structure
  - Creating echo/shadow effects at high strength values
"""

import numpy as np
from collections import deque
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.engine.physics import Voice

MEMORY_DEPTH = 32   # number of snapshots retained


class HarmonicMemory:

    def __init__(self, depth: int = MEMORY_DEPTH):
        self._depth   = depth
        self._buffer: deque = deque(maxlen=depth)

    def capture(self, voices: list) -> None:
        """
        Store a snapshot of current voice ratios.
        Called every engine tick after physics, before recall.
        """
        if not voices:
            return
        snapshot = tuple(getattr(v, "ratio", float(v)) for v in voices)
        self._buffer.append(snapshot)

    def recall(self, voices: list, strength: float) -> list:
        """
        Blend remembered ratio states back into current voices.

        strength=0  → voices unchanged
        strength=1  → voices pulled to weighted mean of buffer

        Returns the same Voice objects with ratios modified in-place.
        """
        if not voices or not self._buffer or strength <= 0.0:
            return voices

        strength = float(np.clip(strength, 0.0, 1.0))
        n_voices = len(voices)

        # Build weighted mean per voice index across buffer
        # Recent snapshots get linearly higher weight
        buf_list = list(self._buffer)
        weights  = np.linspace(0.3, 1.0, len(buf_list))
        weights /= weights.sum()

        # Only use snapshots that have the same voice count
        compatible = [(w, snap) for w, snap in zip(weights, buf_list)
                      if len(snap) == n_voices]

        if not compatible:
            return voices

        w_arr  = np.array([w for w, _ in compatible])
        w_arr /= w_arr.sum()
        snaps  = np.array([list(snap) for _, snap in compatible])  # (N, voices)
        means  = np.average(snaps, axis=0, weights=w_arr)          # (voices,)

        for i, v in enumerate(voices):
            if i >= len(means):
                break
            current = getattr(v, "ratio", float(v))
            recalled = float(means[i])
            blended  = current * (1.0 - strength) + recalled * strength
            if hasattr(v, "ratio"):
                v.ratio = float(np.clip(blended, 0.5, 4.0))

        return voices

    def clear(self) -> None:
        self._buffer.clear()

    @property
    def depth(self) -> int:
        return len(self._buffer)

    @property
    def is_warm(self) -> bool:
        """True once enough history has accumulated to be musically useful."""
        return len(self._buffer) >= self._depth // 4
