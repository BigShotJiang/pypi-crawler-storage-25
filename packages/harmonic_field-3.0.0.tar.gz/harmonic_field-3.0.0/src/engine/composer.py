"""
Layer 1 top — Composition Engine (Arranger)
=============================================
Sits above the physics engine and drives it.

Structural form:
  intro → development → climax → resolution → coda  (loops if enabled)

Each section has target chaos + gravity. The composer interpolates smoothly
between them and overrides the physics engine's parameters each tick.

Also:
- Tracks motifs (ratio patterns that recur)
- Detects phrase cadences and signals resolution
- Emits a 'directive' dict consumed by main.py each tick
"""

import time
import numpy as np
from dataclasses import dataclass, field
from typing import Optional


FORM = [
    {"name": "intro",       "duration": 32,  "chaos": 0.12, "gravity": 0.025, "density": 2, "color": "#1a3a5c"},
    {"name": "development", "duration": 55,  "chaos": 0.48, "gravity": 0.012, "density": 4, "color": "#2a4a2a"},
    {"name": "climax",      "duration": 38,  "chaos": 0.85, "gravity": 0.004, "density": 6, "color": "#5c1a1a"},
    {"name": "resolution",  "duration": 30,  "chaos": 0.18, "gravity": 0.035, "density": 3, "color": "#2a2a5c"},
    {"name": "coda",        "duration": 20,  "chaos": 0.06, "gravity": 0.045, "density": 1, "color": "#2e2e2e"},
]


@dataclass
class Phrase:
    ratios:    tuple
    timestamp: float
    tension:   float
    section:   str


class CompositionEngine:

    def __init__(self):
        self._form           = [dict(s) for s in FORM]
        self._custom_form    = None
        self._section_idx    = 0
        self._start_time     = time.time()
        self._section_start  = 0.0
        self._loop           = False
        self._phrase_memory: list[Phrase] = []
        self._paused         = False
        self._pause_offset   = 0.0
        self._pause_elapsed_in_section = 0.0  # FIX B11

    # ── Properties ──────────────────────────────────────────────────────

    @property
    def form(self) -> list[dict]:
        return self._custom_form or self._form

    @property
    def elapsed(self) -> float:
        if self._paused:
            return self._pause_offset
        return time.time() - self._start_time

    @property
    def current_section(self) -> dict:
        return self.form[min(self._section_idx, len(self.form) - 1)]

    @property
    def section_progress(self) -> float:
        dur = self.current_section["duration"]
        t   = self.elapsed - self._section_start
        return float(np.clip(t / max(dur, 1), 0.0, 1.0))

    @property
    def section_name(self) -> str:
        return self.current_section["name"]

    @property
    def total_duration(self) -> float:
        return sum(s["duration"] for s in self.form)

    # ── Main tick ────────────────────────────────────────────────────────

    def tick(self, voices: list, tension: float) -> dict:
        """
        Called every engine tick. Returns directive:
        {chaos, gravity, section, section_idx, progress,
         global_progress, motif_active, cadence}
        """
        if not self._paused:
            self._advance_section()

        sec    = self.current_section
        prog   = self.section_progress
        t      = self.elapsed

        # FIX B10: smooth was computed but never applied — now used
        smooth = prog * prog * (3 - 2 * prog)   # ease-in-out [0→1]
        chaos  = sec["chaos"]
        grav   = sec["gravity"]

        # Interpolate toward next section's values if one exists
        next_idx = self._section_idx + 1
        if next_idx < len(self.form):
            nxt    = self.form[next_idx]
            chaos  = chaos + smooth * (nxt["chaos"]   - chaos)  * 0.3
            grav   = grav  + smooth * (nxt["gravity"] - grav)   * 0.3

        # Emergency resolution if tension is extreme
        cadence = False
        if tension > 0.88:
            chaos   = max(chaos * 0.4, 0.08)
            grav    = min(grav  * 4.0, 0.08)
            cadence = True

        # Record phrase
        if voices and (not self._phrase_memory or
                       t - self._phrase_memory[-1].timestamp > 4.0):
            snap = tuple(round(v.ratio, 3) for v in voices)
            self._phrase_memory.append(
                Phrase(snap, t, tension, sec["name"]))
            if len(self._phrase_memory) > 96:
                self._phrase_memory.pop(0)

        motif = self._detect_motif(voices)

        global_t    = sum(s["duration"] for s in self.form[:self._section_idx])
        global_prog = float(np.clip(
            (global_t + prog * sec["duration"]) / max(self.total_duration, 1), 0.0, 1.0))

        return {
            "chaos":           float(chaos),
            "gravity":         float(grav),
            "density":         int(sec.get("density", 4)),
            "section":         sec["name"],
            "section_idx":     self._section_idx,
            "section_color":   sec.get("color", "#333333"),
            "progress":        prog,
            "global_progress": global_prog,
            "elapsed":         t,
            "motif_active":    motif,
            "cadence":         cadence,
        }

    # ── Controls ──────────────────────────────────────────────────────

    def reset(self) -> None:
        self._start_time    = time.time()
        self._section_idx   = 0
        self._section_start = 0.0
        self._phrase_memory.clear()
        self._pause_offset  = 0.0
        self._paused        = False

    def pause(self) -> None:
        self._pause_elapsed_in_section = self.elapsed - self._section_start
        self._pause_offset = self.elapsed
        self._paused = True

    def resume(self) -> None:
        # FIX B11: restore _section_start relative to new _start_time so the
        # section timer doesn't jump forward by the paused duration.
        self._start_time    = time.time() - self._pause_offset
        self._section_start = time.time() - self._pause_elapsed_in_section
        self._paused        = False

    def jump_to_section(self, name: str) -> None:
        for i, s in enumerate(self.form):
            if s["name"] == name:
                self._section_idx   = i
                self._section_start = self.elapsed
                return

    def set_loop(self, loop: bool) -> None:
        self._loop = loop

    def set_custom_form(self, sections: list[dict]) -> None:
        self._custom_form = sections

    def get(self, t: float) -> dict:
        """
        structure.get(t) — time-indexed section lookup.
        Returns the section active at elapsed time t (in seconds),
        or the final section if t exceeds total duration.
        Compatible with the snippet: section = structure.get(t)
        """
        cursor = 0.0
        for sec in self.form:
            cursor += sec["duration"]
            if t < cursor:
                return sec
        return self.form[-1]

    def get_phrase_memory(self) -> list[Phrase]:
        return list(self._phrase_memory)

    # ── Internal ────────────────────────────────────────────────────────

    def _advance_section(self) -> None:
        sec = self.current_section
        elapsed_in = self.elapsed - self._section_start
        if elapsed_in >= sec["duration"]:
            if self._section_idx < len(self.form) - 1:
                self._section_idx  += 1
                self._section_start = self.elapsed
            elif self._loop:
                self._section_idx   = 0
                self._section_start = self.elapsed
                self._start_time    = time.time()

    def _detect_motif(self, voices: list) -> bool:
        if len(self._phrase_memory) < 5 or not voices:
            return False
        current = np.array([v.ratio for v in voices])
        for phrase in self._phrase_memory[-24:]:
            if len(phrase.ratios) == len(current):
                diff = np.mean(np.abs(np.array(phrase.ratios) - current))
                if diff < 0.04:
                    return True
        return False
