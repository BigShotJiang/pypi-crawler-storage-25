"""
Layer 3 — Musical Physics Engine
==================================
Voices are particles in log-ratio space. Each tick:

  1. Gravity    pulls each voice toward the nearest consonant ratio
  2. Repulsion  keeps voices from collapsing onto each other
  3. Chaos      injects stochastic energy
  4. Momentum   carries velocity across ticks (damped)
  5. Tension    is computed from collective dissonance

The engine is pure-Python / NumPy — no side effects, no I/O.
"""

import numpy as np
from dataclasses import dataclass, field

# Just-intonation consonant ratios, spanning two octaves
CONSONANT = np.array([
    1.0, 16/15, 9/8, 6/5, 5/4, 4/3, 45/32,
    3/2, 8/5, 5/3, 16/9, 15/8, 2.0,
    9/4, 5/2, 3.0, 4.0,
])

REPULSION_RADIUS = 0.04   # minimum distance between voices before repulsion kicks in


@dataclass
class Voice:
    ratio:     float = 1.0
    velocity:  float = 0.0
    amplitude: float = 0.85
    timbre:    float = 0.0       # 0=pure sine → 1=rich harmonics
    _history:  list  = field(default_factory=list, repr=False)

    def record(self) -> None:
        self._history.append(self.ratio)
        if len(self._history) > 64:
            self._history.pop(0)

    @property
    def trajectory(self) -> float:
        if len(self._history) < 2:
            return 0.0
        return float(np.mean(np.diff(self._history[-8:])))

    @property
    def stability(self) -> float:
        """0=volatile, 1=stable. High when recent movement is small."""
        if len(self._history) < 4:
            return 0.5
        std = float(np.std(self._history[-8:]))
        return float(np.clip(1.0 - std * 20, 0.0, 1.0))


class PhysicsEngine:

    def __init__(self, gravity: float = 0.015, chaos: float = 0.30):
        self.gravity  = float(gravity)
        self.chaos    = float(chaos)
        self._tension = 0.0

    # ── Public ──────────────────────────────────────────────────────────

    @property
    def tension(self) -> float:
        return self._tension

    def tick(self, voices: list[Voice], dt: float = 0.02) -> list[Voice]:
        self._tension = self._compute_tension(voices)

        # Resolution pressure: high tension → stronger gravity
        grav = self.gravity
        if self._tension > 0.6:
            grav *= (1.0 + self._tension * 2.5)

        for i, v in enumerate(voices):
            v.record()

            # 1. Gravity toward nearest consonant
            target = self._nearest_consonant(v.ratio)
            grav_f = (target - v.ratio) * grav

            # 2. Inter-voice repulsion
            rep = 0.0
            for j, other in enumerate(voices):
                if i == j:
                    continue
                dist = v.ratio - other.ratio
                if abs(dist) < REPULSION_RADIUS and dist != 0:
                    rep += np.sign(dist) * (REPULSION_RADIUS - abs(dist)) * 0.008

            # 3. Chaos
            noise = np.random.uniform(-self.chaos * 0.045, self.chaos * 0.045)

            # 4. Momentum
            v.velocity = v.velocity * 0.82 + grav_f + rep + noise

            # 5. Integrate
            v.ratio = float(np.clip(v.ratio + v.velocity * dt * 50, 0.5, 4.0))

            # 6. Timbre tracks tension
            v.timbre = float(np.clip(self._tension * 0.9, 0.0, 1.0))

        return voices

    def set_chaos(self, v: float)   -> None: self.chaos   = float(np.clip(v, 0.0, 1.0))
    def set_gravity(self, v: float) -> None: self.gravity = float(np.clip(v, 0.0, 0.2))

    # ── Private ─────────────────────────────────────────────────────────

    def _nearest_consonant(self, ratio: float) -> float:
        diffs = np.abs(CONSONANT - ratio)
        return float(CONSONANT[np.argmin(diffs)])

    def _compute_tension(self, voices: list[Voice]) -> float:
        if not voices:
            return 0.0
        dists = [float(np.min(np.abs(CONSONANT - v.ratio))) for v in voices]
        return float(np.clip(np.mean(dists) / 0.2, 0.0, 1.0))
