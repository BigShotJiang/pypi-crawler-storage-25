# Visuals

from PyQt6.QtWidgets import QWidget
from PyQt6.QtGui import QPainter, QColor, QPen
from PyQt6.QtCore import QTimer, Qt
import numpy as np


class VisualWidget(QWidget):
    def __init__(self, engine=None):
        super().__init__()
        self.engine = engine
        self.setMinimumSize(400, 400)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(16)  # ~60 FPS

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0))  # Black background

        if self.engine and hasattr(self.engine, 'voices'):
            for voice in self.engine.voices:
                x, y = voice.position
                # Scale positions to widget size
                scaled_x = int((x + 1) * self.width() / 2)
                scaled_y = int((y + 1) * self.height() / 2)
                color = QColor.fromHsv(int(voice.frequency * 360 / 1000) % 360, 255, 255)
                painter.setBrush(color)
                painter.setPen(QPen(color, 2))
                painter.drawEllipse(scaled_x - 5, scaled_y - 5, 10, 10)

        painter.end()
