# Timeline

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar
from PyQt6.QtCore import QTimer


class TimelineWidget(QWidget):
    def __init__(self, composer=None):
        super().__init__()
        self.composer = composer
        self.events = []

        layout = QVBoxLayout()

        self.section_label = QLabel("Current Section: Intro")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)

        layout.addWidget(self.section_label)
        layout.addWidget(self.progress_bar)

        self.setLayout(layout)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timeline)
        self.timer.start(1000)  # Update every second

    def add_event(self, time, event):
        self.events.append((time, event))

    def update_timeline(self):
        if self.composer and hasattr(self.composer, 'current_section'):
            self.section_label.setText(f"Current Section: {self.composer.current_section}")
            # Simulate progress
            value = (self.progress_bar.value() + 10) % 100
            self.progress_bar.setValue(value)
