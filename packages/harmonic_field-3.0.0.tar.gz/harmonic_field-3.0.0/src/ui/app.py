# Main app

import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout
from .visual import VisualWidget
from .timeline import TimelineWidget


class App(QApplication):
    def __init__(self):
        super().__init__(sys.argv)
        self.main_window = MainWindow()
        self.main_window.show()

    def run(self):
        sys.exit(self.exec())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Harmonic Field")
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        layout = QVBoxLayout()

        self.visual = VisualWidget()
        self.timeline = TimelineWidget()

        layout.addWidget(self.visual)
        layout.addWidget(self.timeline)

        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
