# AI memory

from typing import List
import numpy as np


class Snapshot:
    def __init__(self, voices, chaos, gravity):
        self.voices = voices.copy() if voices else []
        self.chaos = chaos
        self.gravity = gravity


class AIAdvisor:
    def __init__(self, memory_depth=100):
        self.snapshots: List[Snapshot] = []
        self.memory_depth = memory_depth

    def capture(self, voices, chaos, gravity):
        snap = Snapshot(voices, chaos, gravity)
        self.snapshots.append(snap)
        if len(self.snapshots) > self.memory_depth:
            self.snapshots.pop(0)

    def suggest(self):
        if not self.snapshots:
            return {}
        # Suggest based on recent trends
        recent = self.snapshots[-10:] if len(self.snapshots) > 10 else self.snapshots
        avg_chaos = np.mean([s.chaos for s in recent])
        avg_gravity = np.mean([s.gravity for s in recent])
        return {"chaos": avg_chaos, "gravity": avg_gravity}