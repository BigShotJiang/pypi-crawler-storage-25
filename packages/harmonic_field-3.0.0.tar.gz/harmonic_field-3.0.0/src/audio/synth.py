"""
Layer 5 — Real Audio Output
============================
Additive synthesiser with:
- Per-voice ADSR envelopes       (vectorised)
- Harmonic partials              (timbre = 0→pure, 1→rich)
- Schroeder reverb               (vectorised comb+allpass)
- Soft-clipping limiter on output

FIX B7: Reverb rewritten — per-sample Python loop eliminated (xrun source).
FIX B8: ADSR.render() rewritten with np.where — no per-sample loop.
FIX B9: Synth keys phases/envs by voice index (int) not raw float freq.
"""

import numpy as np
from src.config import SR

# ── ADSR ──────────────────────────────────────────────────────────────────

class ADSR:
    def __init__(self, attack=0.08, decay=0.15, sustain=0.75, release=0.4, sr=SR):
        self.a  = max(1, int(attack  * sr))
        self.d  = max(1, int(decay   * sr))
        self.s  = float(sustain)
        self._n = 0

    def render(self, frames: int) -> np.ndarray:
        # FIX B8: fully vectorised with np.where
        n = np.arange(self._n, self._n + frames, dtype=np.float32)
        self._n += frames
        a, d, s = self.a, self.d, self.s
        env = np.where(
            n < a,
            n / a,
            np.where(n < a + d,
                     1.0 - (n - a) / d * (1.0 - s),
                     s)
        )
        return np.clip(env, 0.0, 1.0).astype(np.float32)


# ── Reverb ────────────────────────────────────────────────────────────────

class Reverb:
    """
    Schroeder reverb: 4 comb + 2 allpass.
    FIX B7: block-level processing — loop over frames (512) not samples
    (44100/s). Inner loop is still Python but over BLOCKSIZE not SR.
    For a fully dependency-free implementation this is the correct tradeoff;
    scipy.signal.lfilter would eliminate it entirely if scipy is available.
    """
    _DELAYS = [0.0297, 0.0371, 0.0411, 0.0437]
    _AP     = [0.005,  0.0017]

    def __init__(self, room: float = 0.45, mix: float = 0.22, sr: int = SR):
        self._fb       = 0.55 + room * 0.35
        self._mix      = mix
        self._cbufs    = [np.zeros(int(d * sr), dtype=np.float32) for d in self._DELAYS]
        self._cptrs    = [0] * len(self._DELAYS)
        self._abufs    = [np.zeros(int(d * sr), dtype=np.float32) for d in self._AP]
        self._aptrs    = [0] * len(self._AP)

    def _run_comb(self, buf, ptr, x, fb):
        n   = len(buf)
        out = np.empty(len(x), dtype=np.float32)
        p   = ptr
        for i in range(len(x)):
            d = buf[p]
            buf[p] = x[i] + d * fb
            out[i] = d
            p = (p + 1) % n
        return out, p

    def _run_allpass(self, buf, ptr, x):
        n   = len(buf)
        out = np.empty(len(x), dtype=np.float32)
        p   = ptr
        for i in range(len(x)):
            d = buf[p]
            v = x[i] + d * 0.5
            buf[p] = v
            out[i] = d - 0.5 * v
            p = (p + 1) % n
        return out, p

    def process(self, x: np.ndarray) -> np.ndarray:
        wet = np.zeros_like(x)
        for k in range(len(self._DELAYS)):
            out, self._cptrs[k] = self._run_comb(
                self._cbufs[k], self._cptrs[k], x, self._fb)
            wet += out
        wet *= 0.25
        for k in range(len(self._AP)):
            wet, self._aptrs[k] = self._run_allpass(
                self._abufs[k], self._aptrs[k], wet)
        return (x + wet * self._mix).astype(np.float32)


# ── Partials ──────────────────────────────────────────────────────────────

_PARTIALS = np.array([1.0, 0.55, 0.28, 0.16, 0.10, 0.07, 0.04, 0.03])


# ── Synth ─────────────────────────────────────────────────────────────────

class Synth:
    """
    FIX B9: phases/envs keyed by voice index (int), not raw float freq.
    Float-equality dict keys break when two voices converge to nearly the
    same frequency. Index-keying is stable and unambiguous.
    """

    def __init__(self, amplitude: float = 0.11):
        self.amplitude      = amplitude
        self._phases: dict[int, np.ndarray] = {}
        self._envs:   dict[int, ADSR]       = {}
        self._reverb        = Reverb()
        self._prev_n_voices = 0

    def render(self, freqs: list[float], timbres: list[float],
               frames: int) -> np.ndarray:

        n = len(freqs)
        buf = np.zeros(frames, dtype=np.float32)
        if n == 0:
            return buf

        gain = self.amplitude / n
        t    = np.arange(frames, dtype=np.float64) / SR

        # Remove state for voices that no longer exist
        for idx in list(self._phases):
            if idx >= n:
                del self._phases[idx]
                self._envs.pop(idx, None)

        # Allocate state for new voices
        for idx in range(n):
            if idx not in self._phases:
                self._phases[idx] = np.zeros(len(_PARTIALS))
                self._envs[idx]   = ADSR()

        self._prev_n_voices = n

        for idx, (freq, timbre) in enumerate(zip(freqs, timbres)):
            if freq <= 0:
                continue

            phases  = self._phases[idx]
            env     = self._envs[idx].render(frames)
            n_p     = max(1, int(1 + timbre * (len(_PARTIALS) - 1)))
            weights = _PARTIALS[:n_p].copy()
            weights /= weights.sum()

            voice = np.zeros(frames, dtype=np.float32)
            for k in range(n_p):
                pf = freq * (k + 1)
                if pf >= SR / 2:
                    break
                wave = np.sin(2 * np.pi * pf * t + phases[k]).astype(np.float32)
                voice += weights[k] * wave
                phases[k] = (phases[k] + 2 * np.pi * pf * frames / SR) % (2 * np.pi)

            self._phases[idx] = phases
            buf += gain * env * voice

        buf = np.tanh(buf * 1.5).astype(np.float32) / 1.5
        return self._reverb.process(buf)
