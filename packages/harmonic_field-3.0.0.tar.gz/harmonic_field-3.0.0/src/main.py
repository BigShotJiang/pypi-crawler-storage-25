# Your code here
"""
Harmonic Field v3 — Signal Chain
==================================

    🎛️  Arranger (DAW-style)          ← CompositionEngine drives form
             ↓
    🧠  AI Suggestions               ← AIAdvisor reads history, emits hints
             ↓
    🧬  Engine (physics)             ← PhysicsEngine ticks voices
             ↓
    🎻  Orchestration → MIDI → DAW  ← assign_orchestra + MidiOut
             ↓
    🎧  Audio Output                 ← Synth renders to sounddevice
             ↓
    🎹  Live Control (MIDI/OSC)      ← OSCBridge receives, SceneLauncher triggers

Every layer in order, every tick.
"""

import sys
import threading
import time
import random
import numpy as np
import sounddevice as sd
from PyQt6.QtWidgets import QApplication

from src.config      import (SR, BLOCKSIZE, ROOT_FREQ, VOICE_COUNT,
                              GRAVITY_DEFAULT, CHAOS_DEFAULT)
from src.engine.physics        import PhysicsEngine, Voice
from src.engine.composer       import CompositionEngine
from src.engine.harmonic_memory import HarmonicMemory
from src.audio.synth      import Synth
from src.midi.midi_out    import MidiOut
from src.orchestration.mapping import assign_orchestra
from src.ai.memory        import AIAdvisor, Snapshot
from src.network.osc      import OSCBridge
from src.performance.scenes import SceneLauncher, Scene, MacroMap, PRESETS
from src.ui.app           import UI


# ── Shared state ─────────────────────────────────────────────────────────

lock = threading.Lock()

state: dict = {
    "voices":          [],
    "chaos":           CHAOS_DEFAULT,
    "gravity":         GRAVITY_DEFAULT,
    "tension":         0.0,
    "section":         "intro",
    "section_idx":     0,
    "section_color":   "#1a3a5c",
    "global_progress": 0.0,
    "density":         4,
    "t":               0.0,
    "motif":           False,
    "cadence":         False,
    "form":            [],
    "ai_hint":         None,
    "ai_opportunity":  None,
    "playing":         True,
    "memory_strength": 0.0,
    "midi_on":         True,
    "osc_enabled":     True,
    # FIX B13: pre-populate scene names from PRESETS so buttons show real names
    "scene_names":     [s.name for s in PRESETS],
}


# ── Engine singletons ─────────────────────────────────────────────────────

physics         = PhysicsEngine(gravity=GRAVITY_DEFAULT, chaos=CHAOS_DEFAULT)
composer        = CompositionEngine()
harmonic_memory = HarmonicMemory()
synth           = Synth()
midi            = MidiOut()
advisor         = AIAdvisor()

_prev_orch_notes: dict = {}


# ── Thread-safe flags (FIX NEW7: use threading.Event for cross-thread flags) ──

_user_adjusted_event = threading.Event()
_reset_event         = threading.Event()


# ── Audio callback ────────────────────────────────────────────────────────

def audio_callback(outdata: np.ndarray, frames: int, time_info, status) -> None:
    try:
        # FIX B3: all state reads inside lock
        with lock:
            voices  = list(state["voices"])
            playing = state["playing"]
            density = state["density"]
        if not playing or not voices:
            outdata[:] = 0
            return
        active  = voices[:density]
        freqs   = [ROOT_FREQ * v.ratio for v in active]
        timbres = [v.timbre            for v in active]
        buf = synth.render(freqs, timbres, frames)
        outdata[:, 0] = buf
        outdata[:, 1] = buf
    except Exception as exc:
        print(f"[audio] {exc}", file=sys.stderr)
        outdata[:] = np.zeros((frames, 2), dtype=np.float32)


# ── Engine loop ───────────────────────────────────────────────────────────

def engine_loop() -> None:
    global _prev_orch_notes

    dt     = 0.02
    t      = 0.0
    voices = [Voice(ratio=r) for r in [1.0, 5/4, 3/2, 2.0][:VOICE_COUNT]]

    with lock:
        state["voices"] = voices
        state["form"]   = [
            dict(s,
                 start=sum(x["duration"] for x in composer.form[:i]),
                 end=sum(x["duration"] for x in composer.form[:i + 1]))
            for i, s in enumerate(composer.form)
        ]

    while True:
        # FIX B6 + NEW7: consume reset signal
        if _reset_event.is_set():
            _reset_event.clear()
            t = 0.0

        # FIX B4 + NEW7: consume user-adjusted signal
        user_adjusted = _user_adjusted_event.is_set()
        if user_adjusted:
            _user_adjusted_event.clear()

        with lock:
            playing         = state["playing"]
            midi_on         = state["midi_on"]
            osc_on          = state["osc_enabled"]
            memory_strength = state["memory_strength"]
            voices          = list(state["voices"])
            # FIX NEW5: read user-set chaos/gravity; do NOT let directive
            # silently overwrite them every tick (was losing user input)
            user_chaos   = state["chaos"]
            user_gravity = state["gravity"]

        if not playing:
            time.sleep(dt)
            continue

        # ── 🧬  LAYER 3 first pass: get current tension for composer ──
        # FIX NEW9: physics.tension is stale from last tick but that is the
        # best available reading before this tick's physics runs. We pass it
        # to the composer and then immediately run physics so the tension
        # written to state is always from THIS tick.
        current_tension = physics.tension

        # ── 🎛️  LAYER 1: Arranger → directives ───────────────────────
        directive = composer.tick(voices, current_tension)
        section   = directive["section"]

        # ── 🧠  LAYER 2: AI snapshot ─────────────────────────────────
        mean_stab = float(np.mean([v.stability for v in voices])) if voices else 0.5
        snap = Snapshot(
            t=t, chaos=user_chaos, gravity=user_gravity,
            tension=current_tension,
            section=section,
            voice_ratios=[v.ratio for v in voices],
            motif=directive["motif_active"],
            stability=mean_stab,
            user_adjusted=user_adjusted,
        )
        ai_hint = advisor.tick(snap)

        ai_opp = ai_hint.get("opportunity") if ai_hint else None

        # ── 🧬  LAYER 3: Physics tick ─────────────────────────────────
        # Composer suggests targets; blend with user values so slider input
        # is never completely ignored (FIX NEW5).
        blend = 0.05   # how fast composer steers toward its targets
        target_chaos   = directive["chaos"]
        target_gravity = directive["gravity"]
        chaos   = user_chaos   + (target_chaos   - user_chaos)   * blend
        gravity = user_gravity + (target_gravity - user_gravity) * blend

        physics.set_chaos(chaos)
        physics.set_gravity(gravity)
        voices  = physics.tick(voices, dt)
        tension = physics.tension

        # ── Density + HarmonicMemory ──────────────────────────────────
        # FIX NEW6: use directive["density"] — same source as the section
        # the composer just ticked, guaranteed consistent.
        density = directive.get("density", len(voices))

        harmonic_memory.capture(voices)
        voices = harmonic_memory.recall(voices, memory_strength)

        active_voices = voices[:density]

        # ── 🎻  LAYER 4: Orchestration + MIDI ────────────────────────
        if midi_on:
            parts = assign_orchestra(active_voices, tension, _prev_orch_notes)
            midi.update(parts, tension)
            _prev_orch_notes = {
                inst: {n.midi_note for n in notes}
                for inst, notes in parts.items()
            }
        else:
            parts = {}

        # ── 🎹  LAYER 8: OSC broadcast ────────────────────────────────
        if osc_on:
            osc.broadcast(
                voices=active_voices,
                chaos=chaos, gravity=gravity,
                tension=tension, section=section,
                section_idx=directive["section_idx"],
                progress=directive["global_progress"],
                motif=directive["motif_active"],
                cadence=directive["cadence"],
                stability=mean_stab,
            )

        # ── Write back ────────────────────────────────────────────────
        with lock:
            state["voices"]          = voices
            state["density"]         = density
            state["tension"]         = tension
            state["section"]         = section
            state["section_idx"]     = directive["section_idx"]
            state["section_color"]   = directive["section_color"]
            state["global_progress"] = directive["global_progress"]
            state["motif"]           = directive["motif_active"]
            state["cadence"]         = directive["cadence"]
            state["t"]               = t
            state["ai_hint"]         = ai_hint
            state["ai_opportunity"]  = ai_opp
            # FIX NEW5: write the blended chaos/gravity back so sliders
            # reflect the actual engine value (blend toward composer target)
            state["chaos"]   = chaos
            state["gravity"] = gravity

        t += dt
        time.sleep(dt)


# ── Scene system ──────────────────────────────────────────────────────────

def apply_scene(scene: Scene) -> None:
    with lock:
        voices = state["voices"]
        for i, ratio in enumerate(scene.voice_ratios[:len(voices)]):
            voices[i].ratio    = float(ratio)
            voices[i].velocity = 0.0
        state["chaos"]   = scene.chaos
        state["gravity"] = scene.gravity
    physics.set_chaos(scene.chaos)
    physics.set_gravity(scene.gravity)
    if scene.section_jump:
        composer.jump_to_section(scene.section_jump)


scene_launcher = SceneLauncher(on_scene=apply_scene)


# ── UI Callbacks ──────────────────────────────────────────────────────────

def cb_set_chaos(chaos: float, user_adjusted: bool = False) -> None:
    with lock:
        state["chaos"] = float(np.clip(chaos, 0.0, 1.0))
    physics.set_chaos(chaos)
    if user_adjusted:
        _user_adjusted_event.set()   # FIX NEW7

def cb_set_gravity(gravity: float) -> None:
    with lock:
        state["gravity"] = float(np.clip(gravity, 0.0, 0.2))
    physics.set_gravity(gravity)

def cb_set_memory_strength(strength: float) -> None:
    with lock:
        state["memory_strength"] = float(np.clip(strength, 0.0, 1.0))

def cb_play_pause(playing: bool) -> None:
    with lock:
        state["playing"] = playing
    if not playing:
        midi.silence_all()
        composer.pause()
    else:
        composer.resume()

def cb_reset() -> None:
    composer.reset()
    harmonic_memory.clear()
    _reset_event.set()          # FIX B6 NEW7: signal engine loop
    with lock:
        state["t"] = 0.0

def cb_add_voice() -> None:
    with lock:
        voices = state["voices"]
        if len(voices) < 8:
            voices.append(Voice(ratio=random.uniform(1.0, 2.0)))

def cb_remove_voice() -> None:
    with lock:
        voices = state["voices"]
        if len(voices) > 1:
            voices.pop()

def cb_trigger_scene(idx: int) -> None:
    scene_launcher.trigger(idx)

def cb_capture_scene(idx: int) -> None:
    with lock:
        voices  = list(state["voices"])
        chaos   = state["chaos"]
        gravity = state["gravity"]
        section = state["section"]
    scene_launcher.capture(idx, chaos, gravity, voices, section)

def cb_toggle_midi(enabled: bool) -> None:
    with lock:
        state["midi_on"] = enabled
    midi.set_enabled(enabled)

def cb_toggle_osc_target(name: str, enabled: bool) -> None:
    osc.set_target_enabled(name, enabled)

def cb_toggle_loop(loop: bool) -> None:
    composer.set_loop(loop)

def cb_set_bpm(bpm: int) -> None:
    pass   # future: scale section durations by tempo

def cb_set_sections(sections: list) -> None:
    composer.set_custom_form(sections)

def cb_chaos_delta(delta: float) -> None:
    with lock:
        old = state["chaos"]
    cb_set_chaos(float(np.clip(old + delta, 0.0, 1.0)), user_adjusted=True)

def cb_gravity_delta(delta: float) -> None:
    with lock:
        old = state["gravity"]
    cb_set_gravity(float(np.clip(old + delta, 0.0, 0.2)))


# ── FIX NEW1: _osc_voice must be defined BEFORE OSCBridge uses it ─────────

def _osc_voice(idx: int, ratio: float) -> None:
    with lock:
        voices = state["voices"]
        if 0 <= idx < len(voices):
            voices[idx].ratio = float(np.clip(ratio, 0.5, 4.0))


# ── FIX NEW1+NEW2: OSCBridge defined AFTER _osc_voice and before MacroMap ──

osc = OSCBridge(
    on_chaos=lambda v:    cb_set_chaos(v),
    on_gravity=lambda v:  cb_set_gravity(v),
    on_voice=lambda i, r: _osc_voice(i, r),
    on_section=lambda s:  composer.jump_to_section(s),
    on_scene=lambda i:    cb_trigger_scene(i),
    on_play=lambda p:     cb_play_pause(p),
)


# ── FIX NEW2: MacroMap defined AFTER osc so lambda capture is valid ───────

macro = MacroMap(
    play_pause=lambda: cb_play_pause(not state.get("playing", True)),
    reset=cb_reset,
    toggle_loop=cb_toggle_loop,
    add_voice=cb_add_voice,
    remove_voice=cb_remove_voice,
    toggle_midi=lambda: cb_toggle_midi(not state.get("midi_on", True)),
    toggle_osc=lambda: osc.set_global_enabled(not state.get("osc_enabled", True)),
    trigger_scene=cb_trigger_scene,
    capture_scene=cb_capture_scene,
    chaos_delta=cb_chaos_delta,
    gravity_delta=cb_gravity_delta,
)


# ── Entry ─────────────────────────────────────────────────────────────────

def main() -> None:
    threading.Thread(target=engine_loop, daemon=True).start()

    app = QApplication(sys.argv)

    callbacks = {
        "set_chaos":          cb_set_chaos,
        "set_gravity":        cb_set_gravity,
        "set_memory_strength": cb_set_memory_strength,   # FIX B1/B1b
        "play_pause":         cb_play_pause,
        "reset":              cb_reset,
        "add_voice":          cb_add_voice,
        "remove_voice":       cb_remove_voice,
        "trigger_scene":      cb_trigger_scene,
        "toggle_midi":        cb_toggle_midi,
        "toggle_osc_target":  cb_toggle_osc_target,
        "toggle_loop":        cb_toggle_loop,
        "set_bpm":            cb_set_bpm,
        "set_sections":       cb_set_sections,
        "chaos_delta":        cb_chaos_delta,
        "gravity_delta":      cb_gravity_delta,
        "macro":              macro.handle,
    }

    ui = UI(state, lock, callbacks)
    ui.show()

    try:
        with sd.OutputStream(
            callback=audio_callback,
            samplerate=SR,
            blocksize=BLOCKSIZE,
            channels=2,
            dtype="float32",
        ):
            sys.exit(app.exec())
    finally:
        advisor.end_session()
        midi.close()
        osc.close()


if __name__ == "__main__":
    main()