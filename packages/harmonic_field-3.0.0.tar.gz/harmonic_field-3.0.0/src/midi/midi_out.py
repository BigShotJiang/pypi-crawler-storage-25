# MIDI output

import mido

class MidiOut:
    def __init__(self):
        self.port = None

    def send(self, msg):
        # Send MIDI message
        pass