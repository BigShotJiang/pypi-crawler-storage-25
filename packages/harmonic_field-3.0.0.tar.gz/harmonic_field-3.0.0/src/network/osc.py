"""
Layer 8 — Network Collaboration (OSC)
=======================================
Sends full engine state to ALL configured targets simultaneously:
  • Max/MSP       — port 7400  (standard Max OSC receive)
  • SuperCollider — port 57120 (scsynth default)
  • TouchDesigner — port 9000  (TD OSC In CHOP)
  • Claude agent  — port 9100  (multi-agent Harmonic Field peer)
  • Generic       — configurable

Receives on port 9001 from any source, including remote HF instances.

Address space broadcast:
  /hf/chaos          f       chaos 0–1
  /hf/gravity        f       gravity 0–0.2
  /hf/tension        f       tension 0–1
  /hf/section        s       section name
  /hf/section/idx    i       section index
  /hf/progress       f       global progress 0–1
  /hf/motif          i       1 if motif active
  /hf/cadence        i       1 if cadence triggered
  /hf/voice          i f f   idx, ratio, amplitude
  /hf/note           i i i   channel, note, velocity

SuperCollider-specific (supercollider uses /s_new etc; we send control buses):
  /hf/sc/chaos       f
  /hf/sc/tension     f
  /hf/sc/voice0..7   f       ratio per voice for SC synth control

TouchDesigner-specific (TD reads arbitrary addresses into CHOPs):
  /hf/td/r           f       tension (red)
  /hf/td/g           f       stability (green)
  /hf/td/b           f       chaos (blue)
  /hf/td/voice0..7   f       per-voice ratio

Incoming addresses (any source can control this instance):
  /hf/chaos          f
  /hf/gravity        f
  /hf/voice/set      i f     set voice i to ratio f
  /hf/section/jump   s       jump to named section
  /hf/scene          i       trigger scene index
  /hf/play           i       1=play 0=pause
"""

import threading
import sys
from typing import Callable, Optional

try:
    from pythonosc import udp_client, dispatcher, osc_server
    OSC_OK = True
except ImportError:
    OSC_OK = False
    print("[OSC] pythonosc not found — network disabled.", file=sys.stderr)

from src.config import OSC_TARGETS, OSC_RECV_PORT


class OSCBridge:

    def __init__(self,
                 on_chaos:    Optional[Callable] = None,
                 on_gravity:  Optional[Callable] = None,
                 on_voice:    Optional[Callable] = None,
                 on_section:  Optional[Callable] = None,
                 on_scene:    Optional[Callable] = None,
                 on_play:     Optional[Callable] = None):

        self._clients:    list = []
        self._client_map: dict = {}     # name → client
        self._enabled_map: dict[str, bool] = {}
        self._server  = None
        self._thread  = None

        self._on_chaos   = on_chaos
        self._on_gravity = on_gravity
        self._on_voice   = on_voice
        self._on_section = on_section
        self._on_scene   = on_scene
        self._on_play    = on_play

        if OSC_OK:
            self._init_clients()
            self._init_server()

    # ── Setup ────────────────────────────────────────────────────────────

    def _init_clients(self) -> None:
        for target in OSC_TARGETS:
            try:
                client = udp_client.SimpleUDPClient(target["host"], target["port"])
                self._clients.append((target["name"], client))
                self._client_map[target["name"]] = client
                self._enabled_map[target["name"]] = True
                print(f"[OSC] → {target['name']} {target['host']}:{target['port']}")
            except Exception as e:
                print(f"[OSC] Client '{target['name']}' error: {e}", file=sys.stderr)

    def _init_server(self) -> None:
        try:
            d = dispatcher.Dispatcher()
            d.map("/hf/chaos",        self._rx_chaos)
            d.map("/hf/gravity",      self._rx_gravity)
            d.map("/hf/voice/set",    self._rx_voice)
            d.map("/hf/section/jump", self._rx_section)
            d.map("/hf/scene",        self._rx_scene)
            d.map("/hf/play",         self._rx_play)
            d.set_default_handler(lambda *a: None)

            self._server = osc_server.ThreadingOSCUDPServer(
                ("0.0.0.0", OSC_RECV_PORT), d)
            self._thread = threading.Thread(
                target=self._server.serve_forever, daemon=True)
            self._thread.start()
            print(f"[OSC] Listening on :{OSC_RECV_PORT}")
        except Exception as e:
            print(f"[OSC] Server error: {e}", file=sys.stderr)

    # ── Receive ──────────────────────────────────────────────────────────

    def _rx_chaos(self,   addr, *a): self._on_chaos   and a and self._on_chaos(float(a[0]))
    def _rx_gravity(self, addr, *a): self._on_gravity and a and self._on_gravity(float(a[0]))
    def _rx_section(self, addr, *a): self._on_section and a and self._on_section(str(a[0]))
    def _rx_scene(self,   addr, *a): self._on_scene   and a and self._on_scene(int(a[0]))
    def _rx_play(self,    addr, *a): self._on_play    and a and self._on_play(bool(int(a[0])))
    def _rx_voice(self,   addr, *a):
        if self._on_voice and len(a) >= 2:
            self._on_voice(int(a[0]), float(a[1]))

    # ── Send ─────────────────────────────────────────────────────────────

    def _send(self, name: str, addr: str, *args) -> None:
        client = self._client_map.get(name)
        if client and self._enabled_map.get(name, True):
            try:
                client.send_message(addr, list(args) if len(args) > 1 else args[0])
            except Exception:
                pass

    def broadcast(self, voices: list, chaos: float, gravity: float,
                  tension: float, section: str, section_idx: int,
                  progress: float, motif: bool, cadence: bool,
                  stability: float) -> None:

        if not self._clients:
            return

        # ── Generic / Claude peer (all addresses) ───────────────────
        for name, client in self._clients:
            if not self._enabled_map.get(name, True):
                continue
            try:
                client.send_message("/hf/chaos",       chaos)
                client.send_message("/hf/gravity",     gravity)
                client.send_message("/hf/tension",     tension)
                client.send_message("/hf/section",     section)
                client.send_message("/hf/section/idx", section_idx)
                client.send_message("/hf/progress",    progress)
                client.send_message("/hf/motif",       int(motif))
                client.send_message("/hf/cadence",     int(cadence))
                for i, v in enumerate(voices):
                    r = getattr(v, "ratio", float(v))
                    a = getattr(v, "amplitude", 0.8)
                    client.send_message("/hf/voice", [i, float(r), float(a)])
            except Exception:
                pass

        # ── SuperCollider-specific ───────────────────────────────────
        self._send("SuperCollider", "/hf/sc/chaos",   chaos)
        self._send("SuperCollider", "/hf/sc/tension", tension)
        for i, v in enumerate(voices[:8]):
            r = getattr(v, "ratio", float(v))
            self._send("SuperCollider", f"/hf/sc/voice{i}", float(r))

        # ── TouchDesigner-specific (RGB = tension/stability/chaos) ───
        self._send("TouchDesigner", "/hf/td/r", tension)
        self._send("TouchDesigner", "/hf/td/g", stability)
        self._send("TouchDesigner", "/hf/td/b", chaos)
        for i, v in enumerate(voices[:8]):
            r = getattr(v, "ratio", float(v))
            self._send("TouchDesigner", f"/hf/td/voice{i}", float(r))

    def send_note(self, channel: int, note: int, velocity: int) -> None:
        for name, client in self._clients:
            if self._enabled_map.get(name, True):
                try:
                    client.send_message("/hf/note", [channel, note, velocity])
                except Exception:
                    pass

    # ── Control ──────────────────────────────────────────────────────────

    def set_target_enabled(self, name: str, enabled: bool) -> None:
        self._enabled_map[name] = enabled

    def set_global_enabled(self, enabled: bool) -> None:
        for k in self._enabled_map:
            self._enabled_map[k] = enabled

    def close(self) -> None:
        if self._server:
            self._server.shutdown()
