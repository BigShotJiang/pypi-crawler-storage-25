"""
Layer 7 — Live Performance System
===================================
- SceneLauncher: 8 named scenes, instant-trigger
- Built-in preset library (Drone → Chaos → Resolution etc.)
- MacroMap: keyboard shortcuts for every engine parameter
- Scene save/load as JSON
"""

import json
import time
import numpy as np
from dataclasses import dataclass, asdict
from typing import Callable, Optional
from src.config import SCENE_COUNT


@dataclass
class Scene:
    name:         str
    chaos:        float
    gravity:      float
    voice_ratios: list
    section_jump: Optional[str] = None
    color:        str = "#3a3a5c"


PRESETS: list[Scene] = [
    Scene("Drone",       0.04, 0.045, [1.0, 1.5, 2.0, 3.0],     "coda",        "#1a2a3a"),
    Scene("Development", 0.45, 0.012, [1.0, 1.25, 1.5, 1.875],  "development", "#2a4a2a"),
    Scene("Climax",      0.88, 0.003, [1.0, 1.13, 1.41, 1.78],  "climax",      "#5c1a1a"),
    Scene("Resolution",  0.10, 0.050, [1.0, 5/4,  3/2,  2.0],   "resolution",  "#2a2a5c"),
    Scene("Harmonic",    0.18, 0.030, [1.0, 4/3,  3/2,  2.0],   None,          "#2a4a4a"),
    Scene("Overtone",    0.12, 0.025, [1.0, 2.0,  3.0,  4.0],   None,          "#3a2a4a"),
    Scene("Cluster",     0.65, 0.006, [1.0, 1.06, 1.12, 1.19],  "climax",      "#4a3a1a"),
    Scene("Pentatonic",  0.22, 0.028, [1.0, 9/8,  5/4,  3/2],   None,          "#1a4a2a"),
]


class SceneLauncher:

    def __init__(self, on_scene: Callable[[Scene], None]):
        self._on_scene  = on_scene
        self.scenes: list[Scene] = list(PRESETS[:SCENE_COUNT])
        self._last_t    = 0.0

    def trigger(self, idx: int) -> None:
        if 0 <= idx < len(self.scenes):
            if time.time() - self._last_t < 0.05:
                return
            self._last_t = time.time()
            self._on_scene(self.scenes[idx])

    def save_scene(self, idx: int, scene: Scene) -> None:
        if 0 <= idx < SCENE_COUNT:
            self.scenes[idx] = scene

    def capture(self, idx: int, chaos: float, gravity: float,
                voices: list, section: str) -> None:
        """Capture current state as a new scene."""
        name = self.scenes[idx].name if idx < len(self.scenes) else f"Scene {idx+1}"
        ratios = [getattr(v, "ratio", float(v)) for v in voices]
        self.save_scene(idx, Scene(name, chaos, gravity, ratios, section))

    def export_json(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump([asdict(s) for s in self.scenes], f, indent=2)

    def import_json(self, path: str) -> None:
        with open(path) as f:
            data = json.load(f)
        for i, d in enumerate(data[:SCENE_COUNT]):
            self.scenes[i] = Scene(**d)


class MacroMap:
    """
    Keyboard → engine actions.
    Space=play/pause  R=reset  L=loop  N=add voice  D=del voice
    ↑↓=chaos  ←→=gravity  1-8=scenes  M=midi  O=osc
    Shift+1-8=capture scene
    """

    def __init__(self, **handlers):
        self._h = handlers

    def _call(self, name, *args):
        fn = self._h.get(name)
        if fn:
            fn(*args)

    def handle(self, key: str, shift: bool = False) -> bool:
        k = key.lower()
        if k == " ":            self._call("play_pause");          return True
        if k == "r":            self._call("reset");               return True
        if k == "l":            self._call("toggle_loop");         return True
        if k == "n":            self._call("add_voice");           return True
        if k == "d":            self._call("remove_voice");        return True
        if k == "m":            self._call("toggle_midi");         return True
        if k == "o":            self._call("toggle_osc");          return True
        if k == "up":           self._call("chaos_delta",  +0.05); return True
        if k == "down":         self._call("chaos_delta",  -0.05); return True
        if k == "right":        self._call("gravity_delta",+0.004);return True
        if k == "left":         self._call("gravity_delta",-0.004);return True
        if k.isdigit() and "1" <= k <= "8":
            idx = int(k) - 1
            if shift:           self._call("capture_scene", idx)
            else:               self._call("trigger_scene", idx)
            return True
        return False
