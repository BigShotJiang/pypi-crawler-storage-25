__version__ = "0.1.2"
__author__ = "Qingpo Cui"

from cvmplot.cvmplot import cvmplot
