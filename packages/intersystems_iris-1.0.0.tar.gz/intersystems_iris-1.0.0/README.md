# intersystems-iris

`intersystems-iris` is a compatibility shim for the `intersystems_iris` import name.

## The problem

The InterSystems IRIS Python client is distributed as `intersystems-irispython` but imported as `iris`. Some packages (including older versions of `iris-vector-graph`) import it as `intersystems_iris`. This package makes that work.

```python
import intersystems_iris          # same as: import iris
intersystems_iris.connect(...)    # works
intersystems_iris.createIRIS(...) # works
intersystems_iris.dbapi           # works
```

## For new code

Use `import iris` directly. This shim exists for compatibility only.

```python
import iris
conn = iris.connect("iris://_SYSTEM:SYS@localhost:1972/USER")
```

## Install

```bash
pip install intersystems-iris
```

This pulls in `intersystems-irispython` as a dependency automatically.
