from __future__ import annotations

import contextlib
import errno
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import venv
import zipfile

import pytest
import setuptools.build_meta as build_meta


@contextlib.contextmanager
def _chdir(path: Path):
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


def _copy_repo_tree(src_repo: Path, dst_repo: Path) -> None:
    shutil.copytree(
        src_repo,
        dst_repo,
        ignore=shutil.ignore_patterns(
            ".git",
            ".idea",
            ".vscode",
            ".pytest_cache",
            "__pycache__",
            "*.pyc",
            ".mypy_cache",
            ".tmp_build",
            "build",
            "dist",
        ),
    )


def _build_with_exdev_fallback(repo_dir: Path, dist_dir: Path) -> tuple[Path, Path]:
    dist_dir.mkdir(parents=True, exist_ok=True)
    original_rename = os.rename

    def _safe_rename(src: str, dst: str):
        try:
            original_rename(src, dst)
        except OSError as exc:
            if exc.errno != errno.EXDEV:
                raise
            # Handle cross-device rename failures on some mounted filesystems.
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
                shutil.rmtree(src)
            else:
                os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
                shutil.copy2(src, dst)
                os.unlink(src)

    os.rename = _safe_rename
    try:
        with _chdir(repo_dir):
            wheel_name = build_meta.build_wheel(str(dist_dir))
            sdist_name = build_meta.build_sdist(str(dist_dir))
    finally:
        os.rename = original_rename

    wheel_path = dist_dir / wheel_name
    sdist_path = dist_dir / sdist_name
    return wheel_path, sdist_path


def _python_in_venv(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def test_pennylane_q_layer_supports_torq_ansatzes_without_data_reupload():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq_bench.pennylane_backend import PennyLaneQLayer

    ansatz_names = (
        "basic_entangling",
        "single_rot_basic_ent",
        "strongly_entangling",
        "cross_mesh",
        "cross_mesh_2_rots",
        "cross_mesh_cx_rot",
        "tile",
        "no_entanglement_ansatz",
    )
    x = torch.rand(3, 2)
    for ansatz_name in ansatz_names:
        layer = PennyLaneQLayer(
            n_qubits=2,
            n_layers=1,
            ansatz_name=ansatz_name,
            basis_angle_embedding="Y",
        )
        out = layer(x)
        assert out.shape == (3, 2)
        assert torch.isfinite(out).all()


@pytest.mark.parametrize(
    ("ansatz_name", "config_kwargs"),
    (
        ("no_entanglement_ansatz", {}),
        ("single_rot_basic_ent", {"single_rotation_gate": "rz"}),
        ("tile", {"tile_rotation_params": 1, "single_rotation_gate": "ry", "tile_sublayers": 2, "tile_cyclic": True}),
    ),
)
def test_pennylane_q_layer_supports_data_reupload(ansatz_name, config_kwargs):
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.simple import CircuitConfig
    from torq_bench.pennylane_backend import PennyLaneQLayer

    n_qubits = 3
    layer = PennyLaneQLayer(
        n_qubits=n_qubits,
        n_layers=2,
        ansatz_name=ansatz_name,
        config=CircuitConfig(data_reupload_every=2, **config_kwargs),
        basis_angle_embedding="Z",
    )
    out = layer(torch.rand(4, n_qubits))
    assert out.shape == (4, n_qubits)
    assert torch.isfinite(out).all()


@pytest.mark.parametrize(
    ("ansatz_name", "config_kwargs", "n_qubits"),
    (
        ("single_rot_basic_ent", {"single_rotation_gate": "ry"}, 3),
        ("tile", {"tile_rotation_params": 3, "tile_sublayers": 2, "tile_cyclic": True}, 4),
        ("tile", {"tile_rotation_params": 1, "single_rotation_gate": "rz", "tile_sublayers": 2, "tile_cyclic": True}, 4),
        ("tile", {"tile_rotation_params": 3, "tile_sublayers": 2, "tile_cyclic": True}, 5),
    ),
)
def test_pennylane_q_layer_matches_torq_for_added_ansatzes(ansatz_name, config_kwargs, n_qubits):
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.QLayer import QLayer
    from torq.simple import CircuitConfig
    from torq_bench.pennylane_backend import PennyLaneQLayer

    torch.manual_seed(0)
    config = CircuitConfig(**config_kwargs)
    torq_layer = QLayer(
        n_qubits=n_qubits,
        n_layers=2,
        ansatz_name=ansatz_name,
        config=config,
    )
    penny_layer = PennyLaneQLayer(
        n_qubits=n_qubits,
        n_layers=2,
        ansatz_name=ansatz_name,
        config=config,
        weights=torq_layer.params.detach().clone(),
        weights_last_layer_data_re=(
            getattr(torq_layer, "params_last_layer_reupload", None).detach().clone()
            if getattr(torq_layer, "params_last_layer_reupload", None) is not None
            else None
        ),
    )

    x = torch.rand(5, n_qubits)
    y_torq = torq_layer(x)
    y_penny = penny_layer(x)
    assert y_penny.shape == y_torq.shape == (5, n_qubits)
    assert torch.allclose(y_penny, y_torq, atol=1e-5, rtol=1e-5)


def test_pennylane_q_layer_matches_torq_for_shared_local_matrix_observable():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.QLayer import QLayer
    from torq.simple import CircuitConfig
    from torq_bench.pennylane_backend import PennyLaneQLayer

    torch.manual_seed(0)
    custom_obs = torch.tensor([[0.0, 1.0], [1.0, 0.0]], dtype=torch.float32)
    config = CircuitConfig(observables=custom_obs)
    weights = torch.rand(2, 2, 3)
    x = torch.rand(5, 2)

    torq_layer = QLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )
    penny_layer = PennyLaneQLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )

    y_torq = torq_layer(x)
    y_penny = penny_layer(x)
    assert y_penny.shape == y_torq.shape == (5, 2)
    assert torch.allclose(y_penny, y_torq, atol=1e-5, rtol=1e-5)


def test_pennylane_q_layer_matches_torq_for_pauli_string_observables():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.QLayer import QLayer
    from torq.simple import CircuitConfig
    from torq_bench.pennylane_backend import PennyLaneQLayer

    torch.manual_seed(0)
    config = CircuitConfig(observables="XI_ZZ", pauli_measurement_chunk_size=1)
    weights = torch.rand(2, 2, 3)
    x = torch.rand(4, 2)

    torq_layer = QLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )
    penny_layer = PennyLaneQLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )

    y_torq = torq_layer(x)
    y_penny = penny_layer(x)
    assert y_penny.shape == y_torq.shape == (4, 2)
    assert torch.allclose(y_penny, y_torq, atol=1e-5, rtol=1e-5)


def test_pennylane_q_layer_matches_torq_for_multiple_full_system_observables():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.QLayer import QLayer
    from torq.simple import CircuitConfig
    from torq_bench.pennylane_backend import PennyLaneQLayer

    torch.manual_seed(0)
    x_gate = torch.tensor([[0.0, 1.0], [1.0, 0.0]], dtype=torch.float32)
    z_gate = torch.tensor([[1.0, 0.0], [0.0, -1.0]], dtype=torch.float32)
    observables = torch.stack(
        (
            torch.kron(x_gate, torch.eye(2, dtype=torch.float32)),
            0.5 * torch.kron(z_gate, z_gate),
            torch.diag(torch.tensor([1.0, -1.0, 0.5, 2.0], dtype=torch.float32)),
        ),
        dim=0,
    )
    config = CircuitConfig(observables=observables, pauli_measurement_chunk_size=1)
    weights = torch.rand(2, 2, 3)
    x = torch.rand(4, 2)

    torq_layer = QLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )
    penny_layer = PennyLaneQLayer(
        n_qubits=2,
        n_layers=2,
        ansatz_name="basic_entangling",
        config=config,
        weights=weights.clone(),
    )

    y_torq = torq_layer(x)
    y_penny = penny_layer(x)
    assert y_penny.shape == y_torq.shape == (4, 3)
    assert torch.allclose(y_penny, y_torq, atol=1e-5, rtol=1e-5)


def _assert_direct_measurement_matches_legacy(
    *,
    ansatz_name,
    n_qubits,
    n_layers,
    config,
    x,
):
    import torch
    import torq as tq
    from torq.QLayer import QLayer
    from torq_bench.PennyLaneComparison import PennyLaneComparison, _select_demo_circuit

    torq_layer = QLayer(
        n_qubits=n_qubits,
        n_layers=n_layers,
        ansatz_name=ansatz_name,
        config=config,
    )
    comparison = PennyLaneComparison(
        n_qubits=n_qubits,
        n_layers=n_layers,
        weights=torq_layer.params.detach().clone(),
        weights_last_layer_data_re=(
            getattr(torq_layer, "params_last_layer_reupload", None).detach().clone()
            if getattr(torq_layer, "params_last_layer_reupload", None) is not None
            else None
        ),
        data_reupload_every=getattr(config, "data_reupload_every", 0),
        observables=getattr(config, "observables", None),
        pauli_measurement_chunk_size=getattr(config, "pauli_measurement_chunk_size", 8),
        config=config,
    )

    legacy_state_circuit = _select_demo_circuit(
        comparison,
        ansatz_name,
        getattr(config, "data_reupload_every", 0),
    )
    legacy = tq.measure(
        legacy_state_circuit(x),
        getattr(config, "observables", None),
        pauli_chunk_size=getattr(config, "pauli_measurement_chunk_size", 8),
    )
    direct = comparison._format_batched_measurement_result(
        comparison.build_measurement_circuit(ansatz_name)(x)
    )

    assert direct.shape == legacy.shape
    assert torch.allclose(direct, legacy, atol=1e-5, rtol=1e-5)


def test_direct_measurement_circuit_matches_legacy_for_observable_variants():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.simple import CircuitConfig

    torch.manual_seed(0)

    x_gate = torch.tensor([[0.0, 1.0], [1.0, 0.0]], dtype=torch.float32)
    z_gate = torch.tensor([[1.0, 0.0], [0.0, -1.0]], dtype=torch.float32)
    cases = (
        CircuitConfig(),
        CircuitConfig(observables=torch.tensor([[0.0, 1.0], [1.0, 0.0]], dtype=torch.float32)),
        CircuitConfig(observables="XI_ZZ", pauli_measurement_chunk_size=1),
        CircuitConfig(
            observables=torch.stack(
                (
                    torch.kron(x_gate, torch.eye(2, dtype=torch.float32)),
                    0.5 * torch.kron(z_gate, z_gate),
                    torch.diag(torch.tensor([1.0, -1.0, 0.5, 2.0], dtype=torch.float32)),
                ),
                dim=0,
            ),
            pauli_measurement_chunk_size=1,
        ),
    )

    for config in cases:
        _assert_direct_measurement_matches_legacy(
            ansatz_name="basic_entangling",
            n_qubits=2,
            n_layers=2,
            config=config,
            x=torch.rand(5, 2),
        )


def test_direct_measurement_circuit_matches_legacy_for_data_reupload():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    import torch
    from torq.simple import CircuitConfig

    torch.manual_seed(0)
    _assert_direct_measurement_matches_legacy(
        ansatz_name="single_rot_basic_ent",
        n_qubits=3,
        n_layers=2,
        config=CircuitConfig(data_reupload_every=2, single_rotation_gate="ry"),
        x=torch.rand(4, 3),
    )


def test_pennylane_q_layer_rejects_unknown_ansatz():
    pytest.importorskip("pennylane")
    pytest.importorskip("torq")

    from torq_bench.pennylane_backend import PennyLaneQLayer

    with pytest.raises(ValueError, match="Unknown ansatz|does not support ansatz_name"):
        PennyLaneQLayer(n_qubits=2, n_layers=1, ansatz_name="not_a_real_ansatz")


def test_missing_pennylane_reports_install_hint(tmp_path: Path):
    script = tmp_path / "check_missing_pennylane.py"
    src_dir = Path(__file__).resolve().parents[1] / "src"
    script.write_text(
        """
import builtins
import sys

real_import = builtins.__import__

def blocked_import(name, *args, **kwargs):
    if name == "pennylane":
        raise ImportError("blocked by test")
    return real_import(name, *args, **kwargs)

builtins.__import__ = blocked_import

try:
    import torq_bench.PennyLaneComparison  # noqa: F401
except ImportError as exc:
    msg = str(exc)
    print(msg)
    raise SystemExit(0 if "pip install torq-bench[pennylane]" in msg else 2)

raise SystemExit(1)
""".strip(),
        encoding="utf-8",
    )

    env = os.environ.copy()
    env["PYTHONPATH"] = f"{src_dir}{os.pathsep}{env.get('PYTHONPATH', '')}"
    result = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode == 0, (
        f"returncode={result.returncode}\nstdout={result.stdout}\nstderr={result.stderr}"
    )


def test_build_smoke_produces_wheel_and_sdist(tmp_path: Path):
    repo_src = Path(__file__).resolve().parents[1]
    repo_copy = tmp_path / "repo"
    _copy_repo_tree(repo_src, repo_copy)

    dist_dir = tmp_path / "dist"
    wheel_path, sdist_path = _build_with_exdev_fallback(repo_copy, dist_dir)

    assert wheel_path.exists()
    assert sdist_path.exists()
    assert wheel_path.suffix == ".whl"
    assert sdist_path.suffix == ".gz"

    with zipfile.ZipFile(wheel_path) as zf:
        metadata_file = next(name for name in zf.namelist() if name.endswith("METADATA"))
        metadata = zf.read(metadata_file).decode("utf-8")
    assert "Requires-Dist: torq-quantum>=0.1.3" in metadata


def test_built_wheel_installs_in_clean_venv(tmp_path: Path):
    repo_src = Path(__file__).resolve().parents[1]
    repo_copy = tmp_path / "repo"
    _copy_repo_tree(repo_src, repo_copy)
    pyproject_text = (repo_copy / "pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'^\s*version\s*=\s*"([^"]+)"\s*$', pyproject_text, flags=re.MULTILINE)
    assert match is not None
    expected_version = match.group(1)

    dist_dir = tmp_path / "dist"
    wheel_path, _ = _build_with_exdev_fallback(repo_copy, dist_dir)

    venv_dir = tmp_path / "venv"
    venv.EnvBuilder(with_pip=True).create(venv_dir)
    python_exe = _python_in_venv(venv_dir)
    clean_env = os.environ.copy()
    clean_env.pop("PYTHONPATH", None)

    subprocess.run(
        [str(python_exe), "-m", "pip", "install", "--no-deps", str(wheel_path)],
        check=True,
        capture_output=True,
        text=True,
        env=clean_env,
    )

    result = subprocess.run(
        [
            str(python_exe),
            "-c",
            (
                "import importlib.metadata as im; "
                "import torq_bench; "
                "print(im.version('TorQ-bench')); "
                "print(torq_bench.__version__)"
            ),
        ],
        check=True,
        capture_output=True,
        text=True,
        env=clean_env,
    )
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    assert len(lines) == 2
    assert lines[0] == expected_version
    assert lines[1] == expected_version
