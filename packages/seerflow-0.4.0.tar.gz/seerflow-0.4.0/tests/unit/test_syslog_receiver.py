"""Tests for SyslogReceiver — parsing, severity, UDP, TCP."""

from __future__ import annotations

import asyncio
import socket

import pytest

from seerflow.receivers.base import Receiver
from seerflow.receivers.manager import ReceiverManager
from seerflow.receivers.syslog import (
    SyslogReceiver,
    _detect_rfc_version,
    _map_severity,
    _parse_priority,
    _parse_syslog,
)


class TestSyslogParsing:
    def test_parse_priority(self) -> None:
        data = b"<165>1 2026-03-20T04:00:00Z host app - - - msg"
        facility, severity, rest = _parse_priority(data)
        assert facility == 20
        assert severity == 5
        assert rest.startswith(b"1 ")

    def test_parse_priority_low(self) -> None:
        facility, severity, _rest = _parse_priority(b"<0>emergency message")
        assert facility == 0
        assert severity == 0

    def test_parse_priority_missing_returns_defaults(self) -> None:
        facility, severity, rest = _parse_priority(b"no priority here")
        assert facility == 1  # user
        assert severity == 5  # notice
        assert rest == b"no priority here"

    def test_detect_rfc5424(self) -> None:
        assert _detect_rfc_version(b"1 2026-03-20T04:00:00Z host app") == "5424"

    def test_detect_rfc3164(self) -> None:
        assert _detect_rfc_version(b"Mar 20 04:00:00 myhost sshd") == "3164"

    def test_detect_unknown_defaults_to_3164(self) -> None:
        assert _detect_rfc_version(b"random garbage") == "3164"

    def test_parse_syslog_rfc5424(self) -> None:
        data = b"<165>1 2026-03-20T04:00:00.000Z myhost myapp 1234 ID47 - Login failed"
        event = _parse_syslog(data, "192.168.1.1", "udp")
        assert event.source_type == "syslog"
        assert event.data == data
        assert event.metadata["remote_addr"] == "192.168.1.1"
        assert event.metadata["protocol"] == "udp"
        assert event.metadata["facility"] == 20
        assert event.metadata["severity"] == 5

    def test_parse_syslog_rfc3164(self) -> None:
        data = b"<34>Mar 20 04:00:00 myhost sshd[1234]: Login failed"
        event = _parse_syslog(data, "10.0.0.1", "tcp")
        assert event.source_type == "syslog"
        assert event.metadata["facility"] == 4
        assert event.metadata["severity"] == 2
        assert event.metadata["protocol"] == "tcp"


class TestSeverityMapping:
    def test_emergency(self) -> None:
        assert _map_severity(0) == 6  # FATAL

    def test_alert(self) -> None:
        assert _map_severity(1) == 5  # CRITICAL

    def test_critical(self) -> None:
        assert _map_severity(2) == 5  # CRITICAL

    def test_error(self) -> None:
        assert _map_severity(3) == 4  # ERROR

    def test_warning(self) -> None:
        assert _map_severity(4) == 3  # WARNING

    def test_notice(self) -> None:
        assert _map_severity(5) == 2  # NOTICE

    def test_info(self) -> None:
        assert _map_severity(6) == 1  # INFORMATIONAL

    def test_debug(self) -> None:
        assert _map_severity(7) == 0  # TRACE

    def test_parse_syslog_includes_seerflow_severity(self) -> None:
        data = b"<165>1 2026-03-20T04:00:00Z host app - - - msg"
        event = _parse_syslog(data, "127.0.0.1", "udp")
        assert event.metadata["seerflow_severity"] == 2  # syslog 5 -> notice -> 2


class TestSyslogReceiverUDP:
    async def test_isinstance_receiver(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test-syslog", udp_port=0, tcp_enabled=False)
        assert isinstance(receiver, Receiver)

    async def test_start_stop_lifecycle(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        assert receiver.is_healthy()
        await receiver.stop()
        assert not receiver.is_healthy()

    async def test_udp_receive_message(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        try:
            port = receiver.udp_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(
                b"<165>1 2026-03-20T04:00:00Z host app - - - test msg",
                ("127.0.0.1", port),
            )
            sock.close()
            await asyncio.sleep(0.1)
            assert mgr.queue_depth == 1
            event = await mgr.get_event()
            assert event.source_type == "syslog"
            assert event.source_id == "test"
        finally:
            await receiver.stop()

    async def test_udp_metadata(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        try:
            port = receiver.udp_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(b"<34>Mar 20 04:00:00 host sshd: test", ("127.0.0.1", port))
            sock.close()
            await asyncio.sleep(0.1)
            event = await mgr.get_event()
            assert "remote_addr" in event.metadata
            assert event.metadata["protocol"] == "udp"
        finally:
            await receiver.stop()

    async def test_udp_source_type(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="syslog-main", udp_port=0, tcp_enabled=False)
        await receiver.start()
        try:
            port = receiver.udp_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(b"<165>test", ("127.0.0.1", port))
            sock.close()
            await asyncio.sleep(0.1)
            event = await mgr.get_event()
            assert event.source_type == "syslog"
            assert event.source_id == "syslog-main"
        finally:
            await receiver.stop()


class TestSyslogReceiverTCP:
    async def test_tcp_receive_message(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"<165>1 2026-03-20T04:00:00Z host app - - - tcp msg\n")
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.1)
            assert mgr.queue_depth >= 1
            event = await mgr.get_event()
            assert event.metadata["protocol"] == "tcp"
        finally:
            await receiver.stop()

    async def test_tcp_multiple_lines(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"<165>line1\n<165>line2\n<165>line3\n")
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.2)
            assert mgr.queue_depth >= 3
        finally:
            await receiver.stop()

    async def test_tcp_client_disconnect(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.1)
        finally:
            await receiver.stop()

    async def test_tcp_metadata(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"<34>test msg\n")
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.1)
            event = await mgr.get_event()
            assert "remote_addr" in event.metadata
            assert event.metadata["protocol"] == "tcp"
        finally:
            await receiver.stop()


class TestSyslogIntegration:
    async def test_register_with_manager(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="syslog-main", udp_port=0, tcp_enabled=False)
        mgr.register("syslog-main", receiver)
        await mgr.start()
        assert receiver.is_healthy()
        await mgr.stop()

    async def test_end_to_end_udp(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="syslog-main", udp_port=0, tcp_enabled=False)
        mgr.register("syslog-main", receiver)
        await mgr.start()
        try:
            port = receiver.udp_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(
                b"<165>1 2026-03-20T04:00:00Z host app - - - e2e test",
                ("127.0.0.1", port),
            )
            sock.close()
            await asyncio.sleep(0.1)
            event = await mgr.get_event()
            assert event.source_id == "syslog-main"
            assert b"e2e test" in event.data
        finally:
            await mgr.stop()


class TestSyslogEdgeCases:
    async def test_start_is_idempotent(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        await receiver.start()  # second call should be a no-op
        assert receiver.is_healthy()
        await receiver.stop()

    async def test_stop_is_idempotent(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        await receiver.stop()
        await receiver.stop()  # second call should be a no-op
        assert not receiver.is_healthy()

    def test_detect_rfc_version_empty_bytes(self) -> None:
        assert _detect_rfc_version(b"") == "3164"

    def test_detect_rfc3164_starts_with_digit(self) -> None:
        assert _detect_rfc_version(b"10 Mar host") == "3164"

    def test_priority_out_of_range_clamped(self) -> None:
        facility, severity, _rest = _parse_priority(b"<999>test")
        assert facility == 1  # default user
        assert severity == 5  # default notice

    def test_udp_port_when_disabled(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(
            mgr,
            source_id="test",
            udp_port=514,
            udp_enabled=False,
            tcp_enabled=False,
        )
        assert receiver.udp_port == 514

    def test_tcp_port_when_disabled(self) -> None:
        mgr = ReceiverManager()
        receiver = SyslogReceiver(
            mgr,
            source_id="test",
            tcp_port=601,
            udp_enabled=False,
            tcp_enabled=False,
        )
        assert receiver.tcp_port == 601

    def test_empty_bind_addr_rejected(self) -> None:
        mgr = ReceiverManager()
        with pytest.raises(ValueError, match="bind_addr must be a non-empty string"):
            SyslogReceiver(mgr, source_id="test", bind_addr="")

    async def test_udp_oversized_datagram_dropped(self) -> None:
        """Oversized UDP datagram (>8192 bytes) is dropped (lines 107-108)."""
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        try:
            port = receiver.udp_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Send oversized datagram (> _MAX_UDP_BYTES = 8192)
            oversized = b"<165>" + b"x" * 9000
            sock.sendto(oversized, ("127.0.0.1", port))
            sock.close()
            await asyncio.sleep(0.2)
            assert mgr.queue_depth == 0  # dropped
        finally:
            await receiver.stop()

    async def test_udp_queue_full_drops_event(self) -> None:
        """When queue is full, UDP events are dropped (line 111)."""
        mgr = ReceiverManager(queue_maxsize=1)
        receiver = SyslogReceiver(mgr, source_id="test", udp_port=0, tcp_enabled=False)
        await receiver.start()
        try:
            port = receiver.udp_port
            # Fill the queue
            from seerflow.receivers.base import RawEvent

            await mgr.put_event(
                RawEvent(data=b"fill", source_type="t", source_id="t", received_ns=0, metadata={})
            )
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(b"<165>dropped", ("127.0.0.1", port))
            sock.close()
            await asyncio.sleep(0.2)
            # Queue should still have only 1 item (the pre-filled one)
            assert mgr.queue_depth == 1
        finally:
            await receiver.stop()

    async def test_udp_error_received(self) -> None:
        """error_received on UDP protocol logs warning (line 114)."""
        from seerflow.receivers.syslog import _SyslogUDPProtocol

        protocol = _SyslogUDPProtocol(ReceiverManager(), "test")
        # Should not raise — just logs
        protocol.error_received(OSError("test error"))

    async def test_tcp_empty_lines_skipped(self) -> None:
        """Empty TCP lines (just newlines) are skipped (line 212)."""
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"\n\n<165>real msg\n\n")
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.2)
            # Only the real message should be enqueued
            assert mgr.queue_depth == 1
        finally:
            await receiver.stop()

    async def test_tcp_connection_error_handled(self) -> None:
        """TCP client that sends partial data and disconnects is handled (lines 215-221)."""
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"<165>partial")  # no newline
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0.2)
            # Should not crash — client just disconnected
        finally:
            await receiver.stop()

    async def test_tcp_semaphore_null_guard(self) -> None:
        """TCP handler with None semaphore closes writer (lines 195-199)."""
        mgr = ReceiverManager()
        receiver = SyslogReceiver(mgr, source_id="test", udp_enabled=False, tcp_port=0)
        await receiver.start()
        try:
            # Force semaphore to None to test the guard
            receiver._tcp_semaphore = None
            port = receiver.tcp_port
            _reader, writer = await asyncio.open_connection("127.0.0.1", port)
            writer.write(b"<165>test\n")
            await writer.drain()
            # Give time for handler to process
            await asyncio.sleep(0.3)
            # The connection should be closed by the server
        finally:
            receiver._tcp_semaphore = asyncio.Semaphore(256)  # restore for clean stop
            await receiver.stop()


class TestSyslogExports:
    def test_import(self) -> None:
        import seerflow.receivers as mod

        assert hasattr(mod, "SyslogReceiver")

    def test_all(self) -> None:
        import seerflow.receivers as mod

        assert "SyslogReceiver" in mod.__all__
