"""Tests for EventNormalizer — RawEvent → SeerflowEvent."""

from __future__ import annotations

import time
import uuid

from seerflow.models.event import SeerflowEvent, SeverityLevel
from seerflow.parsing.drain import DrainParser
from seerflow.parsing.normalizer import EventNormalizer
from seerflow.receivers.base import RawEvent


def _make_raw(
    message: str = "test log line",
    source_type: str = "syslog",
    source_id: str = "syslog-main",
    metadata: dict[str, object] | None = None,
) -> RawEvent:
    return RawEvent(
        data=message.encode("utf-8"),
        source_type=source_type,
        source_id=source_id,
        received_ns=1_710_000_000_000_000_000,
        metadata=metadata or {},
    )


class TestNormalizerBasicFields:
    def test_returns_seerflow_event(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw())
        assert isinstance(result, SeerflowEvent)

    def test_event_id_is_uuid(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw())
        assert isinstance(result.event_id, uuid.UUID)

    def test_message_decoded(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("hello world"))
        assert result.message == "hello world"

    def test_source_type_mapped(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(source_type="file"))
        assert result.source_type == "file"

    def test_source_id_mapped(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(source_id="my-source"))
        assert result.source_id == "my-source"

    def test_encoding_errors_replaced(self) -> None:
        raw = RawEvent(
            data=b"hello \xff\xfe world",
            source_type="test",
            source_id="t",
            received_ns=0,
            metadata={},
        )
        normalizer = EventNormalizer()
        result = normalizer.normalize(raw)
        assert "hello" in result.message
        assert "\ufffd" in result.message  # replacement char

    def test_severity_from_metadata(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(metadata={"seerflow_severity": 4}))
        assert result.severity_id == SeverityLevel.ERROR

    def test_severity_default_informational(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw())
        assert result.severity_id == SeverityLevel.INFORMATIONAL

    def test_timestamp_ns_from_raw(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw())
        assert result.timestamp_ns == 1_710_000_000_000_000_000

    def test_observed_ns_captured_before_processing(self) -> None:
        normalizer = EventNormalizer()
        before = time.time_ns()
        result = normalizer.normalize(_make_raw())
        after = time.time_ns()
        assert before <= result.observed_ns <= after

    def test_severity_invalid_value_falls_back(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(metadata={"seerflow_severity": 99}))
        assert result.severity_id == SeverityLevel.INFORMATIONAL

    def test_severity_invalid_type_falls_back(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(metadata={"seerflow_severity": "high"}))
        assert result.severity_id == SeverityLevel.INFORMATIONAL

    def test_message_truncated_at_max_length(self) -> None:
        long_msg = "x" * 50_000
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw(long_msg))
        assert len(result.message) == 32_768

    def test_raw_bytes_capped_before_decode(self) -> None:
        """Content beyond byte cap must not appear in output."""
        from seerflow.parsing._constants import MAX_RAW_BYTES

        boundary = b"A" * MAX_RAW_BYTES
        smuggled = b"SMUGGLED"
        raw = RawEvent(
            data=boundary + smuggled,
            source_type="t",
            source_id="s",
            received_ns=0,
            metadata={},
        )
        normalizer = EventNormalizer()
        result = normalizer.normalize(raw)
        assert "SMUGGLED" not in result.message

    def test_normal_bytes_not_truncated(self) -> None:
        """Small raw data is preserved exactly."""
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("hello"))
        assert result.message == "hello"


class TestNormalizerDrainIntegration:
    def test_template_id_populated(self) -> None:
        normalizer = EventNormalizer()
        # Send same pattern twice to force a real cluster assignment
        normalizer.normalize(_make_raw("Login failed for user admin from 10.0.0.1"))
        result = normalizer.normalize(_make_raw("Login failed for user bob from 10.0.0.2"))
        assert result.template_id >= 1  # real Drain3 cluster ID after second message

    def test_template_str_populated(self) -> None:
        normalizer = EventNormalizer()
        # Send same pattern twice to force template generalization
        normalizer.normalize(_make_raw("Login failed for user alice from 10.0.0.1"))
        result = normalizer.normalize(_make_raw("Login failed for user bob from 10.0.0.2"))
        assert result.template_str != ""

    def test_template_params_tuple(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("test message 123"))
        assert isinstance(result.template_params, tuple)

    def test_custom_drain_parser_injected(self) -> None:
        parser = DrainParser(sim_th=0.5, depth=5)
        normalizer = EventNormalizer(drain_parser=parser)
        result = normalizer.normalize(_make_raw("custom parser test"))
        assert isinstance(result, SeerflowEvent)


class TestNormalizerEntityIntegration:
    def test_related_ips_populated(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("Login from 192.168.1.1"))
        assert "192.168.1.1" in result.related_ips

    def test_related_users_populated(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("user=admin login"))
        assert "admin" in result.related_users

    def test_related_hosts_populated(self) -> None:
        normalizer = EventNormalizer()
        result = normalizer.normalize(_make_raw("host=web-01.prod connected"))
        assert any("web-01" in h for h in result.related_hosts)

    def test_empty_message_no_entities(self) -> None:
        raw = RawEvent(data=b"", source_type="t", source_id="s", received_ns=0, metadata={})
        normalizer = EventNormalizer()
        result = normalizer.normalize(raw)
        assert result.related_ips == ()
        assert result.related_users == ()
        assert result.related_hosts == ()


class TestNormalizerExports:
    def test_importable_from_package(self) -> None:
        from seerflow.parsing import EventNormalizer as Exported

        assert Exported is EventNormalizer

    def test_in_all(self) -> None:
        import seerflow.parsing

        assert "EventNormalizer" in seerflow.parsing.__all__


class TestConstants:
    def test_constants_importable(self) -> None:
        from seerflow.parsing._constants import (
            MAX_ENTITIES_PER_TYPE,
            MAX_MESSAGE_LEN,
            MAX_RAW_BYTES,
        )

        assert isinstance(MAX_MESSAGE_LEN, int)
        assert isinstance(MAX_ENTITIES_PER_TYPE, int)
        assert isinstance(MAX_RAW_BYTES, int)

    def test_raw_bytes_derived_from_message_len(self) -> None:
        from seerflow.parsing._constants import MAX_MESSAGE_LEN, MAX_RAW_BYTES

        assert MAX_RAW_BYTES == MAX_MESSAGE_LEN * 2
