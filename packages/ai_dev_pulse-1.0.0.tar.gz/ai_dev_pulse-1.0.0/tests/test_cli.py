"""Tests for CLI commands."""

import json
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from devpulse.cli.main import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestCLIBase:
    """Test CLI base commands."""

    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output

    def test_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "DevPulse" in result.output
        assert "sync" in result.output
        assert "daily" in result.output
        assert "metrics" in result.output


class TestSyncCommand:
    """Test sync command (without actual GitHub)."""

    def test_sync_no_token(self, runner, monkeypatch):
        monkeypatch.delenv("DEVPULSE_GITHUB_TOKEN", raising=False)
        monkeypatch.setenv("DEVPULSE_GITHUB_TOKEN", "")
        from devpulse.core.config import reset_settings
        reset_settings()

        result = runner.invoke(cli, ["sync"])
        assert result.exit_code != 0 or "DEVPULSE_GITHUB_TOKEN" in result.output


class TestReportCommands:
    """Test report generation CLI commands."""

    def test_daily_report_terminal(self, runner, populated_db):
        with patch("devpulse.core.report_generator.ReportGenerator", return_value=MagicMock(
            daily_report=MagicMock(return_value={
                "date": "2026-04-01",
                "author": "all",
                "commits": 2,
                "prs_opened": 0,
                "prs_merged": 0,
                "issues_opened": 0,
                "issues_closed": 0,
                "reviews_given": 0,
                "lines_changed": 80,
                "summary": "2 commit(s)",
                "commit_details": [],
            }),
        )):
            result = runner.invoke(cli, ["daily", "--date", "2026-04-01"])
            # Should not crash (may print to console)

    def test_daily_report_json(self, runner, populated_db):
        with patch("devpulse.core.report_generator.ReportGenerator", return_value=MagicMock(
            daily_report=MagicMock(return_value={
                "date": "2026-04-01",
                "author": "all",
                "commits": 2,
                "prs_opened": 0,
                "prs_merged": 0,
                "issues_opened": 0,
                "issues_closed": 0,
                "reviews_given": 0,
                "lines_changed": 80,
                "summary": "2 commits",
                "commit_details": [],
            }),
            to_json=MagicMock(return_value='{"date": "2026-04-01"}'),
        )):
            result = runner.invoke(cli, ["daily", "--format", "json"])
            # Should output JSON

    def test_weekly_report_help(self, runner):
        result = runner.invoke(cli, ["weekly", "--help"])
        assert result.exit_code == 0
        assert "--week-start" in result.output

    def test_monthly_report_help(self, runner):
        result = runner.invoke(cli, ["monthly", "--help"])
        assert result.exit_code == 0
        assert "--year" in result.output


class TestMetricsCommand:
    """Test metrics CLI commands."""

    def test_metrics_help(self, runner):
        result = runner.invoke(cli, ["metrics", "--help"])
        assert result.exit_code == 0
        assert "--author" in result.output
        assert "--days" in result.output


class TestInsightsCommand:
    """Test insights CLI command."""

    def test_insights_help(self, runner):
        result = runner.invoke(cli, ["insights", "--help"])
        assert result.exit_code == 0
        assert "--days" in result.output


class TestHealthCommand:
    """Test health CLI command."""

    def test_health_help(self, runner):
        result = runner.invoke(cli, ["health", "--help"])
        assert result.exit_code == 0
        assert "--days" in result.output


class TestHeatmapCommand:
    """Test heatmap CLI command."""

    def test_heatmap_help(self, runner):
        result = runner.invoke(cli, ["heatmap", "--help"])
        assert result.exit_code == 0
        assert "--author" in result.output
        assert "--days" in result.output


class TestGoalsCommands:
    """Test goals CLI commands."""

    def test_goals_help(self, runner):
        result = runner.invoke(cli, ["goals", "--help"])
        assert result.exit_code == 0

    def test_goals_add_help(self, runner):
        result = runner.invoke(cli, ["goals", "add", "--help"])
        assert result.exit_code == 0
        assert "--title" in result.output

    def test_goals_list_help(self, runner):
        result = runner.invoke(cli, ["goals", "list", "--help"])
        assert result.exit_code == 0

    def test_goals_coach_help(self, runner):
        result = runner.invoke(cli, ["goals", "coach", "--help"])
        assert result.exit_code == 0


class TestSprintCommands:
    """Test sprint CLI commands."""

    def test_sprint_help(self, runner):
        result = runner.invoke(cli, ["sprint", "--help"])
        assert result.exit_code == 0

    def test_sprint_snapshot_help(self, runner):
        result = runner.invoke(cli, ["sprint", "snapshot", "--help"])
        assert result.exit_code == 0
        assert "--name" in result.output

    def test_sprint_burndown_help(self, runner):
        result = runner.invoke(cli, ["sprint", "burndown", "--help"])
        assert result.exit_code == 0

    def test_sprint_predict_help(self, runner):
        result = runner.invoke(cli, ["sprint", "predict", "--help"])
        assert result.exit_code == 0


class TestQualityCommand:
    """Test quality CLI command."""

    def test_quality_help(self, runner):
        result = runner.invoke(cli, ["quality", "--help"])
        assert result.exit_code == 0
        assert "--repo" in result.output


class TestServeCommand:
    """Test serve CLI command."""

    def test_serve_help(self, runner):
        result = runner.invoke(cli, ["serve", "--help"])
        assert result.exit_code == 0
        assert "--port" in result.output


class TestDashboardCommand:
    """Test dashboard CLI command."""

    def test_dashboard_help(self, runner):
        result = runner.invoke(cli, ["dashboard", "--help"])
        assert result.exit_code == 0
        assert "--author" in result.output
