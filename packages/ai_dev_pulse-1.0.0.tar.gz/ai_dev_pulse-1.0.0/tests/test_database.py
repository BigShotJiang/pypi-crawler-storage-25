"""Tests for the Database layer."""

import json
from datetime import datetime

import pytest

from devpulse.core.database import Database


class TestDatabaseInit:
    """Test database initialization."""

    def test_creates_tables(self, db):
        """Database should initialize with all required tables."""
        conn = db._connect()
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        table_names = {t["name"] for t in tables}
        conn.close()

        expected = {
            "commits", "pull_requests", "issues", "reviews",
            "goals", "reports", "sprint_snapshots", "code_quality",
        }
        assert expected.issubset(table_names), f"Missing tables: {expected - table_names}"

    def test_idempotent_init(self, db):
        """Running _init_db twice should not fail."""
        db._init_db()
        db._init_db()  # Should not raise


class TestCommitOperations:
    """Test commit CRUD operations."""

    def test_insert_and_retrieve_commits(self, db, sample_commits):
        count = db.upsert_commits(sample_commits)
        assert count == 4

        commits = db.get_commits()
        assert len(commits) == 4

    def test_upsert_commits_idempotent(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        # Re-upserting same data should not duplicate rows
        db.upsert_commits(sample_commits)

        commits = db.get_commits()
        assert len(commits) == 4  # No duplicates

    def test_filter_by_repo(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        commits = db.get_commits(repo="testorg/testrepo")
        assert len(commits) == 4

        commits = db.get_commits(repo="nonexistent/repo")
        assert len(commits) == 0

    def test_filter_by_author(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        alice = db.get_commits(author="Alice")
        assert len(alice) == 3

        bob = db.get_commits(author="Bob")
        assert len(bob) == 1

    def test_filter_by_date_range(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        commits = db.get_commits(since="2026-04-02", until="2026-04-02")
        assert len(commits) == 1
        assert commits[0]["author"] == "Bob"

    def test_commit_count_by_day(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        counts = db.get_commit_count_by_day(days=30)
        assert len(counts) == 3  # 3 unique dates
        # April 1 should have 2 commits
        apr1 = [c for c in counts if c["day"] == "2026-04-01"]
        assert len(apr1) == 1
        assert apr1[0]["count"] == 2

    def test_commit_limit(self, db, sample_commits):
        db.upsert_commits(sample_commits)
        commits = db.get_commits(limit=2)
        assert len(commits) == 2


class TestPullRequestOperations:
    """Test pull request CRUD operations."""

    def test_insert_and_retrieve_prs(self, db, sample_prs):
        count = db.upsert_pull_requests(sample_prs)
        assert count == 3

        prs = db.get_pull_requests()
        assert len(prs) == 3

    def test_filter_prs_by_state(self, db, sample_prs):
        db.upsert_pull_requests(sample_prs)
        merged = db.get_pull_requests(state="merged")
        assert len(merged) == 2

    def test_filter_prs_by_author(self, db, sample_prs):
        db.upsert_pull_requests(sample_prs)
        alice = db.get_pull_requests(author="Alice")
        assert len(alice) == 2


class TestIssueOperations:
    """Test issue CRUD operations."""

    def test_insert_and_retrieve_issues(self, db, sample_issues):
        count = db.upsert_issues(sample_issues)
        assert count == 3

        issues = db.get_issues()
        assert len(issues) == 3

    def test_filter_issues_by_state(self, db, sample_issues):
        db.upsert_issues(sample_issues)
        open_issues = db.get_issues(state="open")
        assert len(open_issues) == 2

        closed_issues = db.get_issues(state="closed")
        assert len(closed_issues) == 1

    def test_issue_labels_stored_as_json(self, db, sample_issues):
        db.upsert_issues(sample_issues)
        issues = db.get_issues()
        bug_issue = [i for i in issues if i["number"] == 12][0]
        labels = json.loads(bug_issue["labels"])
        assert "bug" in labels
        assert "priority:high" in labels


class TestReviewOperations:
    """Test review CRUD operations."""

    def test_insert_and_retrieve_reviews(self, db, sample_reviews):
        count = db.upsert_reviews(sample_reviews)
        assert count == 2

        reviews = db.get_reviews()
        assert len(reviews) == 2

    def test_filter_reviews_by_author(self, db, sample_reviews):
        db.upsert_reviews(sample_reviews)
        bob_reviews = db.get_reviews(author="Bob")
        assert len(bob_reviews) == 1
        assert bob_reviews[0]["state"] == "APPROVED"


class TestGoalOperations:
    """Test goal CRUD operations."""

    def test_create_and_list_goals(self, db):
        gid = db.upsert_goal({
            "title": "10 commits/day",
            "target_value": 10,
            "metric": "commits_per_day",
            "deadline": "2026-05-01",
        })
        assert isinstance(gid, int)
        assert gid > 0

        goals = db.get_goals()
        assert len(goals) == 1
        assert goals[0]["title"] == "10 commits/day"

    def test_update_goal(self, db):
        gid = db.upsert_goal({
            "title": "10 commits/day",
            "target_value": 10,
            "metric": "commits_per_day",
        })
        db.upsert_goal({
            "id": gid,
            "title": "10 commits/day",
            "target_value": 10,
            "current_value": 5,
            "metric": "commits_per_day",
        })

        goals = db.get_goals()
        assert goals[0]["current_value"] == 5

    def test_delete_goal(self, db):
        gid = db.upsert_goal({
            "title": "Test goal",
            "target_value": 5,
            "metric": "test",
        })
        assert db.delete_goal(gid) is True
        assert db.delete_goal(9999) is False  # Non-existent

    def test_filter_goals_by_status(self, db):
        db.upsert_goal({"title": "Active", "target_value": 5, "metric": "test", "status": "active"})
        db.upsert_goal({"title": "Done", "target_value": 5, "metric": "test", "status": "completed"})

        active = db.get_goals(status="active")
        assert len(active) == 1
        assert active[0]["title"] == "Active"


class TestReportCache:
    """Test report caching."""

    def test_save_and_get_report(self, db):
        db.save_report("daily", "2026-04-01", "# Daily Report\nContent here")
        content = db.get_report("daily", "2026-04-01")
        assert content is not None
        assert "Daily Report" in content

    def test_get_nonexistent_report(self, db):
        content = db.get_report("daily", "1999-01-01")
        assert content is None

    def test_overwrite_report(self, db):
        db.save_report("daily", "2026-04-01", "Version 1")
        db.save_report("daily", "2026-04-01", "Version 2")
        content = db.get_report("daily", "2026-04-01")
        assert "Version 2" in content


class TestSprintSnapshots:
    """Test sprint snapshot operations."""

    def test_save_and_get_snapshots(self, db):
        db.save_sprint_snapshot({
            "sprint_name": "Sprint 1",
            "total_points": 30,
            "completed_points": 10,
            "remaining_points": 20,
            "added_points": 0,
        })
        snapshots = db.get_sprint_snapshots("Sprint 1")
        assert len(snapshots) == 1
        assert snapshots[0]["total_points"] == 30


class TestCodeQuality:
    """Test code quality snapshot operations."""

    def test_save_and_get_quality(self, db):
        db.save_quality_snapshot({
            "repo": "testorg/testrepo",
            "test_coverage": 0.85,
            "open_bugs": 3,
            "tech_debt_score": 4.2,
        })
        snapshots = db.get_quality_snapshots(repo="testorg/testrepo")
        assert len(snapshots) == 1
        assert snapshots[0]["test_coverage"] == 0.85
