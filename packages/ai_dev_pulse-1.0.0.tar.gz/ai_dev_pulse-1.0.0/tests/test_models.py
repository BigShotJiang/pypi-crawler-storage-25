"""Tests for Pydantic models."""

import pytest

from devpulse.core.models import (
    Commit,
    PullRequest,
    Issue,
    Review,
    DeveloperMetrics,
    SprintData,
    TeamHealth,
    CodeQuality,
    Goal,
    DailyReport,
    WeeklyReport,
)


class TestCommit:
    def test_create_commit(self):
        c = Commit(sha="abc123", repo="org/repo", author="Alice", author_date="2026-04-01T10:00:00Z")
        assert c.sha == "abc123"
        assert c.additions == 0

    def test_commit_defaults(self):
        c = Commit(sha="abc", repo="r", author="a", author_date="d")
        assert c.message == ""
        assert c.url == ""


class TestPullRequest:
    def test_create_pr(self):
        pr = PullRequest(number=1, repo="org/repo")
        assert pr.state == "open"
        assert pr.merged_at is None

    def test_pr_with_merge(self):
        pr = PullRequest(number=1, repo="org/repo", state="merged", merged_at="2026-04-02")
        assert pr.state == "merged"


class TestIssue:
    def test_create_issue(self):
        issue = Issue(number=10, repo="org/repo")
        assert issue.labels == []
        assert issue.state == "open"


class TestDeveloperMetrics:
    def test_create_metrics(self):
        m = DeveloperMetrics(author="Alice")
        assert m.commits_count == 0
        assert m.avg_pr_merge_time_hours == 0.0

    def test_metrics_serialization(self):
        m = DeveloperMetrics(author="Bob", commits_count=5, active_days=3)
        d = m.model_dump()
        assert d["author"] == "Bob"
        assert d["commits_count"] == 5


class TestTeamHealth:
    def test_create_team_health(self):
        th = TeamHealth()
        assert th.overall_score == 0.0
        assert th.recommendations == []

    def test_team_health_with_burnout(self):
        th = TeamHealth(
            overall_score=75.5,
            burnout_risk={"Alice": 0.3, "Bob": 0.7},
            velocity_trend="stable",
        )
        assert th.burnout_risk["Bob"] == 0.7


class TestGoal:
    def test_create_goal(self):
        g = Goal(title="Test", target_value=10, metric="commits")
        assert g.id is None
        assert g.status == "active"

    def test_goal_with_id(self):
        g = Goal(id=1, title="Test", target_value=10, metric="commits")
        assert g.id == 1


class TestSprintData:
    def test_create_sprint(self):
        s = SprintData(name="Sprint 1")
        assert s.total_points == 0
        assert s.scope_creep_pct == 0


class TestDailyReport:
    def test_create_daily_report(self):
        r = DailyReport(date="2026-04-01", author="Alice")
        assert r.commits == 0
        assert r.summary == ""


class TestWeeklyReport:
    def test_create_weekly_report(self):
        r = WeeklyReport(week_start="2026-04-01", week_end="2026-04-07")
        assert r.total_commits == 0
        assert r.insights == []
