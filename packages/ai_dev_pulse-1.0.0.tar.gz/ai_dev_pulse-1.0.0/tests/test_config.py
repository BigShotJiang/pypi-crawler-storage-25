"""Tests for configuration management."""

import os
import pytest

from devpulse.core.config import Settings, get_settings, reset_settings


class TestSettings:
    """Test settings loading."""

    def test_default_settings(self):
        reset_settings()
        # Create Settings directly to check defaults (env vars are set by conftest)
        s = Settings(github_token="", github_username="")
        assert s.api_port == 8742
        assert s.log_level == "INFO"
        assert s.redact_sensitive is True

    def test_env_override(self, monkeypatch):
        reset_settings()
        monkeypatch.setenv("DEVPULSE_GITHUB_TOKEN", "ghp_test123")
        monkeypatch.setenv("DEVPULSE_API_PORT", "9999")
        settings = Settings()
        assert settings.github_token == "ghp_test123"
        assert settings.api_port == 9999

    def test_get_settings_caches(self):
        reset_settings()
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2

    def test_reset_settings(self):
        reset_settings()
        s1 = get_settings()
        reset_settings()
        s2 = get_settings()
        assert s1 is not s2

    def test_database_path_default(self):
        settings = Settings()
        assert "devpulse.db" in settings.database_path

    def test_burnout_threshold(self):
        settings = Settings()
        assert 0 < settings.burnout_threshold < 1
