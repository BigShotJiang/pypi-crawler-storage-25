"""Tests for the FastAPI web API."""

import json

import pytest
from httpx import AsyncClient, ASGITransport

from devpulse.api.app import app


@pytest.fixture
def client(populated_db):
    """Provide a test client with populated database."""
    # Override DB in the app to use test DB
    from devpulse.api import app as app_module

    original_get_db = app_module._get_db
    original_get_engine = app_module._get_engine
    original_get_gen = app_module._get_report_gen

    app_module._get_db = lambda: populated_db
    app_module._get_engine = lambda: __import__("devpulse.core.analytics", fromlist=["AnalyticsEngine"]).AnalyticsEngine(db=populated_db)
    app_module._get_report_gen = lambda: __import__("devpulse.core.report_generator", fromlist=["ReportGenerator"]).ReportGenerator(db=populated_db)

    transport = ASGITransport(app=app)
    yield AsyncClient(transport=transport, base_url="http://test")

    app_module._get_db = original_get_db
    app_module._get_engine = original_get_engine
    app_module._get_gen = original_get_gen


class TestHealthCheck:
    """Test API health check endpoints."""

    @pytest.mark.asyncio
    async def test_root(self, client):
        async with client as c:
            response = await c.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "DevPulse API"
        assert data["status"] == "healthy"
        assert "version" in data


class TestCommitEndpoints:
    """Test commit API endpoints."""

    @pytest.mark.asyncio
    async def test_list_commits(self, client):
        async with client as c:
            response = await c.get("/api/commits")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 4

    @pytest.mark.asyncio
    async def test_filter_commits_by_author(self, client):
        async with client as c:
            response = await c.get("/api/commits", params={"author": "Alice"})
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

    @pytest.mark.asyncio
    async def test_commit_heatmap(self, client):
        async with client as c:
            response = await c.get("/api/commits/heatmap", params={"days": 30})
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 0


class TestPullRequestEndpoints:
    """Test pull request API endpoints."""

    @pytest.mark.asyncio
    async def test_list_prs(self, client):
        async with client as c:
            response = await c.get("/api/pull-requests")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

    @pytest.mark.asyncio
    async def test_filter_prs_by_state(self, client):
        async with client as c:
            response = await c.get("/api/pull-requests", params={"state": "merged"})
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2


class TestIssueEndpoints:
    """Test issue API endpoints."""

    @pytest.mark.asyncio
    async def test_list_issues(self, client):
        async with client as c:
            response = await c.get("/api/issues")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

    @pytest.mark.asyncio
    async def test_filter_issues_by_state(self, client):
        async with client as c:
            response = await c.get("/api/issues", params={"state": "open"})
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2


class TestMetricsEndpoints:
    """Test metrics API endpoints."""

    @pytest.mark.asyncio
    async def test_developer_metrics(self, client):
        async with client as c:
            response = await c.get("/api/metrics/Alice", params={"days": 30})
        assert response.status_code == 200
        data = response.json()
        assert data["author"] == "Alice"
        assert data["commits_count"] == 3

    @pytest.mark.asyncio
    async def test_team_metrics(self, client):
        async with client as c:
            response = await c.get("/api/metrics", params={"days": 30})
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 2


class TestHealthEndpoint:
    """Test team health API endpoint."""

    @pytest.mark.asyncio
    async def test_team_health(self, client):
        async with client as c:
            response = await c.get("/api/health", params={"days": 30})
        assert response.status_code == 200
        data = response.json()
        assert "overall_score" in data
        assert "burnout_risk" in data
        assert "recommendations" in data


class TestInsightsEndpoint:
    """Test AI insights API endpoint."""

    @pytest.mark.asyncio
    async def test_get_insights(self, client):
        async with client as c:
            response = await c.get("/api/insights", params={"days": 30})
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0
        for insight in data:
            assert "message" in insight
            assert "recommendation" in insight


class TestGoalEndpoints:
    """Test goals API endpoints."""

    @pytest.mark.asyncio
    async def test_create_goal(self, client):
        async with client as c:
            response = await c.post("/api/goals", json={
                "title": "Test goal",
                "target_value": 10,
                "metric": "commits_per_day",
            })
        assert response.status_code == 201
        data = response.json()
        assert data["title"] == "Test goal"

    @pytest.mark.asyncio
    async def test_list_goals(self, client):
        async with client as c:
            # Create first
            await c.post("/api/goals", json={
                "title": "Goal 1",
                "target_value": 5,
                "metric": "test",
            })
            # Then list
            response = await c.get("/api/goals")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1

    @pytest.mark.asyncio
    async def test_delete_goal(self, client):
        async with client as c:
            create = await c.post("/api/goals", json={
                "title": "Delete me",
                "target_value": 1,
                "metric": "test",
            })
            goal_id = create.json()["id"]
            response = await c.delete(f"/api/goals/{goal_id}")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_delete_nonexistent_goal(self, client):
        async with client as c:
            response = await c.delete("/api/goals/99999")
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_goal_coaching(self, client):
        async with client as c:
            response = await c.get("/api/goals/coach")
        assert response.status_code == 200


class TestSprintEndpoints:
    """Test sprint API endpoints."""

    @pytest.mark.asyncio
    async def test_create_sprint_snapshot(self, client):
        async with client as c:
            response = await c.post("/api/sprints/snapshot", json={
                "sprint_name": "Sprint 1",
                "total_points": 30,
                "completed_points": 10,
                "added_points": 0,
            })
        assert response.status_code == 201

    @pytest.mark.asyncio
    async def test_sprint_burndown(self, client):
        async with client as c:
            # Create snapshot first
            await c.post("/api/sprints/snapshot", json={
                "sprint_name": "Sprint B",
                "total_points": 20,
                "completed_points": 5,
            })
            response = await c.get("/api/sprints/Sprint B/burndown")
        assert response.status_code == 200


class TestQualityEndpoints:
    """Test code quality API endpoints."""

    @pytest.mark.asyncio
    async def test_create_quality_snapshot(self, client):
        async with client as c:
            response = await c.post("/api/quality/snapshot", json={
                "repo": "testorg/testrepo",
                "test_coverage": 0.85,
                "open_bugs": 3,
                "tech_debt_score": 4.2,
            })
        assert response.status_code == 201

    @pytest.mark.asyncio
    async def test_quality_trends(self, client):
        async with client as c:
            response = await c.get("/api/quality", params={"days": 90})
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_quality_score(self, client):
        async with client as c:
            response = await c.get("/api/quality/score", params={"repo": "testorg/testrepo", "days": 30})
        assert response.status_code == 200
        data = response.json()
        assert data["repo"] == "testorg/testrepo"


class TestReportEndpoints:
    """Test report generation API endpoints."""

    @pytest.mark.asyncio
    async def test_daily_report_json(self, client):
        async with client as c:
            response = await c.get("/api/reports/daily", params={"date": "2026-04-01"})
        assert response.status_code == 200
        data = response.json()
        assert data["date"] == "2026-04-01"

    @pytest.mark.asyncio
    async def test_daily_report_markdown(self, client):
        async with client as c:
            response = await c.get("/api/reports/daily", params={"date": "2026-04-01", "format": "markdown"})
        assert response.status_code == 200
        data = response.json()
        assert "markdown" in data

    @pytest.mark.asyncio
    async def test_daily_report_html(self, client):
        async with client as c:
            response = await c.get("/api/reports/daily", params={"date": "2026-04-01", "format": "html"})
        assert response.status_code == 200
        assert "<!DOCTYPE html>" in response.text

    @pytest.mark.asyncio
    async def test_weekly_report(self, client):
        async with client as c:
            response = await c.get("/api/reports/weekly", params={"week_start": "2026-03-30"})
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_monthly_report(self, client):
        async with client as c:
            response = await c.get("/api/reports/monthly", params={"year": 2026, "month": 4})
        assert response.status_code == 200
