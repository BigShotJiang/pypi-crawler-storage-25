"""Tests for the ReportGenerator."""

import json
import os

import pytest

from devpulse.core.report_generator import ReportGenerator, _md_to_html


class TestDailyReport:
    """Test daily report generation."""

    def test_daily_report_basic(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.daily_report(target_date="2026-04-01")

        assert report["date"] == "2026-04-01"
        assert report["commits"] == 2  # Alice's 2 commits on April 1
        assert report["prs_opened"] >= 0
        assert "summary" in report

    def test_daily_report_with_author(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.daily_report(target_date="2026-04-01", author="Alice")

        assert report["author"] == "Alice"
        assert report["commits"] == 2

    def test_daily_report_no_activity(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.daily_report(target_date="2020-01-01")

        assert report["commits"] == 0
        assert report["summary"]  # Should still have a summary


class TestWeeklyReport:
    """Test weekly report generation."""

    def test_weekly_report_basic(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.weekly_report(week_start="2026-03-30")

        assert report["week_start"] == "2026-03-30"
        assert report["week_end"] == "2026-04-05"
        assert report["total_commits"] >= 0
        assert isinstance(report["top_contributors"], list)

    def test_weekly_report_has_insights(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.weekly_report(week_start="2026-03-30")

        assert isinstance(report["insights"], list)
        assert isinstance(report["recommendations"], list)


class TestMonthlyReport:
    """Test monthly report generation."""

    def test_monthly_report_basic(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.monthly_report(year=2026, month=4)

        assert report["period"] == "2026-04"
        assert report["total_commits"] >= 0
        assert "team_health_score" in report
        assert "velocity_trend" in report

    def test_monthly_report_default_period(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        report = gen.monthly_report()

        assert len(report["period"]) == 7  # YYYY-MM format


class TestOutputFormats:
    """Test report output format conversions."""

    def test_to_markdown_daily(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        md = gen.to_markdown(data, "daily")

        assert "# Daily Report" in md
        assert "2026-04-01" in md
        assert "## Metrics" in md

    def test_to_markdown_weekly(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.weekly_report(week_start="2026-03-30")
        md = gen.to_markdown(data, "weekly")

        assert "# Weekly Report" in md
        assert "Top Contributors" in md

    def test_to_markdown_monthly(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.monthly_report(year=2026, month=4)
        md = gen.to_markdown(data, "monthly")

        assert "# Monthly Report" in md
        assert "Team Health Score" in md

    def test_to_json(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        j = gen.to_json(data)

        parsed = json.loads(j)
        assert parsed["date"] == "2026-04-01"

    def test_to_html(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        html = gen.to_html(data, "daily")

        assert "<!DOCTYPE html>" in html
        assert "DevPulse" in html
        assert "<table>" in html or "<h1>" in html


class TestMdToHtml:
    """Test the markdown-to-HTML converter."""

    def test_headers(self):
        html = _md_to_html("# Title\n## Subtitle")
        assert "<h1>Title</h1>" in html
        assert "<h2>Subtitle</h2>" in html

    def test_list_items(self):
        html = _md_to_html("- Item 1\n- Item 2")
        assert "<ul>" in html
        assert "<li>" in html
        assert "Item 1" in html

    def test_bold_text(self):
        html = _md_to_html("- **Bold** text")
        assert "<strong>Bold</strong>" in html


class TestSaveReport:
    """Test report file saving."""

    def test_save_markdown_report(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        path = gen.save_report(data, "daily", "markdown")

        assert os.path.exists(path)
        assert path.endswith(".md")
        with open(path) as f:
            content = f.read()
        assert "Daily Report" in content

    def test_save_json_report(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        path = gen.save_report(data, "daily", "json")

        assert os.path.exists(path)
        assert path.endswith(".json")

    def test_save_html_report(self, populated_db):
        gen = ReportGenerator(db=populated_db)
        data = gen.daily_report(target_date="2026-04-01")
        path = gen.save_report(data, "daily", "html")

        assert os.path.exists(path)
        assert path.endswith(".html")
        with open(path) as f:
            content = f.read()
        assert "<!DOCTYPE html>" in content
