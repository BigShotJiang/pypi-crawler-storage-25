"""Tests for the AnalyticsEngine."""

import pytest

from devpulse.core.analytics import AnalyticsEngine, _parse_date, _days_between
from devpulse.core.models import DeveloperMetrics, TeamHealth


class TestParseDate:
    """Test date parsing utility."""

    def test_iso_with_tz(self):
        dt = _parse_date("2026-04-01T10:00:00Z")
        assert dt is not None
        assert dt.year == 2026
        assert dt.month == 4
        assert dt.day == 1

    def test_iso_without_tz(self):
        dt = _parse_date("2026-04-01T10:00:00")
        assert dt is not None

    def test_date_only(self):
        dt = _parse_date("2026-04-01")
        assert dt is not None

    def test_empty_string(self):
        assert _parse_date("") is None

    def test_none(self):
        assert _parse_date(None) is None

    def test_invalid_format(self):
        assert _parse_date("not-a-date") is None


class TestDaysBetween:
    """Test time difference computation."""

    def test_same_day(self):
        hours = _days_between("2026-04-01T10:00:00Z", "2026-04-01T14:00:00Z")
        assert hours == 4.0

    def test_24_hours(self):
        hours = _days_between("2026-04-01T00:00:00Z", "2026-04-02T00:00:00Z")
        assert hours == 24.0

    def test_empty_start(self):
        hours = _days_between("", "2026-04-01T10:00:00Z")
        assert hours == 0.0


class TestDeveloperMetrics:
    """Test developer metrics computation."""

    def test_basic_metrics(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        metrics = engine.developer_metrics(author="Alice", days=30)

        assert isinstance(metrics, DeveloperMetrics)
        assert metrics.author == "Alice"
        assert metrics.commits_count == 3
        assert metrics.prs_created == 2
        assert metrics.prs_merged == 1  # Only PR #1 is merged and authored by Alice

    def test_bob_metrics(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        metrics = engine.developer_metrics(author="Bob", days=30)

        assert metrics.author == "Bob"
        assert metrics.commits_count == 1
        assert metrics.prs_created == 1

    def test_unknown_developer(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        metrics = engine.developer_metrics(author="Nobody", days=30)

        assert metrics.commits_count == 0
        assert metrics.author == "Nobody"

    def test_active_days(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        metrics = engine.developer_metrics(author="Alice", days=30)

        assert metrics.active_days == 2  # April 1 and April 3

    def test_commits_per_day(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        metrics = engine.developer_metrics(author="Alice", days=30)

        assert metrics.commits_per_day > 0
        assert metrics.period_days == 30


class TestTeamMetrics:
    """Test team-wide metrics."""

    def test_team_metrics_list(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        team = engine.team_metrics(days=30)

        assert len(team) >= 2  # At least Alice and Bob
        authors = {m.author for m in team}
        assert "Alice" in authors
        assert "Bob" in authors

    def test_empty_team(self, db):
        engine = AnalyticsEngine(db=db)
        team = engine.team_metrics(days=30)
        assert team == []


class TestTeamHealth:
    """Test team health analysis."""

    def test_team_health_with_data(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        health = engine.team_health(days=30)

        assert isinstance(health, TeamHealth)
        assert 0 <= health.overall_score <= 100
        assert 0 <= health.workload_balance <= 1
        assert 0 <= health.collaboration_score <= 1
        assert health.velocity_trend in ("growing", "stable", "declining")
        assert len(health.recommendations) > 0

    def test_team_health_empty(self, db):
        engine = AnalyticsEngine(db=db)
        health = engine.team_health(days=30)

        assert health.overall_score == 0
        assert len(health.recommendations) > 0  # Should have "no data" recommendation


class TestSprintAnalytics:
    """Test sprint analytics."""

    def test_sprint_burndown(self, db):
        # Record multiple snapshots
        for i, completed in enumerate([0, 5, 10, 15, 18]):
            db.save_sprint_snapshot({
                "sprint_name": "Sprint 1",
                "total_points": 20,
                "completed_points": completed,
                "remaining_points": 20 - completed,
                "added_points": 0,
            })

        engine = AnalyticsEngine(db=db)
        data = engine.sprint_burndown("Sprint 1")
        assert len(data) == 5
        assert data[0]["remaining"] == 20
        assert data[-1]["remaining"] == 2

    def test_sprint_burndown_nonexistent(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        data = engine.sprint_burndown("Nonexistent Sprint")
        assert data == []

    def test_predict_sprint_completion(self, db):
        for i, completed in enumerate([0, 5, 10, 15]):
            db.save_sprint_snapshot({
                "sprint_name": "Sprint X",
                "total_points": 20,
                "completed_points": completed,
                "remaining_points": 20 - completed,
            })

        engine = AnalyticsEngine(db=db)
        result = engine.predict_sprint_completion("Sprint X", total_points=20, days_elapsed=4, total_days=10)
        assert result["prediction"] in ("on_track", "at_risk", "unknown")
        assert "message" in result

    def test_predict_nonexistent_sprint(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        result = engine.predict_sprint_completion("Ghost Sprint", 20, 5, 10)
        assert result["prediction"] == "unknown"


class TestCodeQuality:
    """Test code quality analytics."""

    def test_quality_trend(self, db):
        db.save_quality_snapshot({
            "repo": "testorg/testrepo",
            "test_coverage": 0.75,
            "open_bugs": 5,
            "tech_debt_score": 3.5,
        })
        db.save_quality_snapshot({
            "repo": "testorg/testrepo",
            "test_coverage": 0.80,
            "open_bugs": 3,
            "tech_debt_score": 3.0,
        })

        engine = AnalyticsEngine(db=db)
        trends = engine.code_quality_trend(repo="testorg/testrepo")
        assert len(trends) == 2
        assert trends[0].test_coverage == 0.75
        assert trends[1].test_coverage == 0.80

    def test_compute_quality_score(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        score = engine.compute_quality_score(repo="testorg/testrepo", days=30)

        assert score["repo"] == "testorg/testrepo"
        assert score["total_commits"] == 4
        assert score["total_prs"] == 3
        assert isinstance(score["tech_debt_score"], float)


class TestInsights:
    """Test AI insight generation."""

    def test_generate_insights_with_data(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        insights = engine.generate_insights(days=30)

        assert isinstance(insights, list)
        assert len(insights) > 0
        for insight in insights:
            assert "type" in insight
            assert "severity" in insight
            assert "message" in insight
            assert "recommendation" in insight

    def test_generate_insights_empty(self, db):
        engine = AnalyticsEngine(db=db)
        insights = engine.generate_insights(days=30)

        assert len(insights) > 0
        # Should have a "no data" or default insight

    def test_insights_include_merge_time(self, populated_db):
        engine = AnalyticsEngine(db=populated_db)
        insights = engine.generate_insights(days=30, repo="testorg/testrepo")

        messages = " ".join(i["message"] for i in insights)
        assert "merge time" in messages.lower() or "healthy" in messages.lower()


class TestGoalCoaching:
    """Test goal coaching."""

    def test_coaching_active_goals(self, db):
        db.upsert_goal({
            "title": "Commits per day",
            "target_value": 10,
            "current_value": 7,
            "metric": "commits_per_day",
        })

        engine = AnalyticsEngine(db=db)
        coaching = engine.goal_coaching()

        assert len(coaching) == 1
        assert coaching[0]["progress_pct"] == 70.0
        assert coaching[0]["status"] in ("on_track", "at_risk", "achieved")

    def test_coaching_achieved_goal(self, db):
        db.upsert_goal({
            "title": "Write code",
            "target_value": 1,
            "current_value": 5,
            "metric": "commits",
        })

        engine = AnalyticsEngine(db=db)
        coaching = engine.goal_coaching()

        assert coaching[0]["status"] == "achieved"

    def test_coaching_specific_goal(self, db):
        gid = db.upsert_goal({
            "title": "Reviews",
            "target_value": 5,
            "current_value": 1,
            "metric": "reviews",
        })

        engine = AnalyticsEngine(db=db)
        coaching = engine.goal_coaching(goal_id=gid)
        assert len(coaching) == 1
