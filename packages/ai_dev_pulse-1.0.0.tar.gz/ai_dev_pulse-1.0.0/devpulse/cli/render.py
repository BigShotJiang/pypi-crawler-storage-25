"""Rich terminal rendering helpers for DevPulse."""

from datetime import datetime, timedelta
from typing import Any

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich.text import Text


def render_heatmap(console: Console, data: list[dict[str, Any]], days: int = 365) -> None:
    """Render a GitHub-style contribution heatmap in the terminal.

    Each column represents a week, each row a day of the week (Mon-Sun).
    Cell characters indicate intensity:
      . = 0 commits
      o = 1-2
      + = 3-5
      # = 6-9
      @ = 10+
    """
    if not data:
        console.print("[yellow]No activity data to display.[/yellow]")
        return

    # Build a lookup: date_str -> count
    counts: dict[str, int] = {d["day"]: d["count"] for d in data}

    # Determine date range
    today = datetime.utcnow().date()
    start = today - timedelta(days=days)

    # Determine max for scaling
    max_count = max(d["count"] for d in data) if data else 1
    if max_count == 0:
        max_count = 1

    day_labels = ["Mon", "    ", "Wed", "    ", "Fri", "    ", "Sun"]

    # Build grid: 7 rows x N weeks
    # Each week column
    weeks: list[list[str]] = []
    current = start
    # Align to start of week (Monday)
    while current.weekday() != 0:
        current -= timedelta(days=1)

    total_commits = 0
    total_active_days = 0

    while current <= today:
        week: list[str] = []
        for dow in range(7):
            d = current
            key = d.isoformat()
            count = counts.get(key, 0)
            total_commits += count
            if count > 0:
                total_active_days += 1

            if count == 0:
                cell = "[dim].[/dim]"
            elif count <= max_count * 0.2:
                cell = f"[color(28)]o[/color(28)]"
            elif count <= max_count * 0.4:
                cell = f"[color(34)]+[/color(34)]"
            elif count <= max_count * 0.7:
                cell = f"[color(40)]#[/color(40)]"
            else:
                cell = f"[color(46)]@[/color(46)]"

            week.append(cell)
            current += timedelta(days=1)
        weeks.append(week)

    console.print(Panel("[bold]Activity Heatmap[/bold]", style="blue"))

    # Print month labels
    month_line = "     "
    last_month = ""
    for week in weeks:
        # Check the Wednesday of this week for month
        mid_date = start + timedelta(weeks=weeks.index(week), days=2)
        month_name = mid_date.strftime("%b")
        if month_name != last_month:
            month_line += f"{month_name:<4}"
            last_month = month_name
        else:
            month_line += "    "
    console.print(month_line)

    # Print each day row
    for dow in range(7):
        line = f"{day_labels[dow]}  "
        for week in weeks:
            if dow < len(week):
                line += week[dow] + " "
            else:
                line += "  "
        console.print(line)

    console.print(f"\n  Total: [bold]{total_commits}[/bold] commits across [bold]{total_active_days}[/bold] active days")
    console.print("  Legend: [dim].[/dim]=0 [color(28)]o[/color(28)]=low [color(34)]+[/color(34)]=med [color(40)]#[/color(40)]=high [color(46)]@[/color(46)]=very high")


def render_metrics_panel(console: Console, metrics: Any) -> None:
    """Render a single developer's metrics as a rich panel."""
    console.print(Panel(f"[bold]{metrics.author}[/bold]", style="cyan", expand=False))

    table = Table.grid(padding=(0, 2))
    table.add_column(justify="right", style="dim")
    table.add_column()

    table.add_row("Commits:", str(metrics.commits_count))
    table.add_row("Active Days:", str(metrics.active_days))
    table.add_row("Commits/Day:", str(metrics.commits_per_day))
    table.add_row("PRs:", f"{metrics.prs_created} created, {metrics.prs_merged} merged")
    table.add_row("Avg Merge Time:", f"{metrics.avg_pr_merge_time_hours}h")
    table.add_row("Reviews:", str(metrics.reviews_given))
    table.add_row("Lines:", f"+{metrics.lines_added} / -{metrics.lines_removed}")

    console.print(table)
    console.print()


def render_insight_card(console: Console, insight: dict[str, str], index: int) -> None:
    """Render a single insight as a styled card."""
    severity = insight.get("severity", "low")
    color = {"high": "red", "medium": "yellow", "low": "green"}.get(severity, "white")
    icon = {"high": "!!", "medium": "!", "low": "*"}.get(severity, "*")

    console.print(f"  [{color}][{icon}][/{color}] {insight['message']}")
    console.print(f"      [dim]-> {insight['recommendation']}[/dim]")


def render_burndown(console: Console, points: list[dict[str, Any]]) -> None:
    """Render an ASCII burndown chart."""
    if not points:
        console.print("[yellow]No burndown data.[/yellow]")
        return

    max_pts = max(p.get("remaining", 0) for p in points)
    if max_pts == 0:
        max_pts = 1
    width = 60

    console.print(f"\n{'Day':>4} | {'Remaining':>10} | Chart")
    console.print("-" * 80)

    for p in points:
        remaining = p.get("remaining", 0)
        ideal = p.get("ideal", 0)
        bar_len = int(remaining / max_pts * width)
        ideal_len = int(ideal / max_pts * width)

        bar = "[green]" + "#" * bar_len + "[/green]"
        ideal_marker = "[dim]|[/dim]" if ideal_len < width else ""

        line = f"{p['day']:>4} | {remaining:>10.1f} | {bar}"
        console.print(line)


def render_header(console: Console) -> None:
    """Render the DevPulse ASCII art header."""
    header = Text()
    header.append("  ____             _       ____                  _   \n", style="bold cyan")
    header.append(" |  _ \\ _   _  ___| | __  |  _ \\ __ _ _ __   ___| |__\n", style="bold cyan")
    header.append(" | | | | | | |/ __| |/ /  | |_) / _` | '_ \\ / __| '_ \\\n", style="bold cyan")
    header.append(" | |_| | |_| | (__|   <   |  __/ (_| | | | | (__| | | |\n", style="bold cyan")
    header.append(" |____/ \\__,_|\\___|_|\\_\\  |_|   \\__,_|_| |_|\\___|_| |_|\n", style="bold cyan")
    header.append("\n  AI-Powered Developer Productivity Dashboard", style="dim")
    console.print(header)
    console.print()
