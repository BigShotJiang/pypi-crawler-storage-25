"""Interactive terminal dashboard for DevPulse."""

from typing import Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.text import Text

from devpulse.core.database import Database
from devpulse.core.analytics import AnalyticsEngine
from devpulse.core.report_generator import ReportGenerator
from devpulse.cli.render import render_header, render_heatmap, render_insight_card


def dashboard_cmd(
    author: Optional[str] = None,
    days: int = 30,
    repo: Optional[str] = None,
) -> None:
    """Launch the full interactive terminal dashboard."""
    console = Console()
    db = Database()
    engine = AnalyticsEngine(db=db)
    report_gen = ReportGenerator(db=db)

    render_header(console)

    # ── Section 1: Summary ───────────────────────────────────────────
    console.rule("[bold cyan]Overview[/bold cyan]")

    daily = report_gen.daily_report(author=author, repo=repo)
    console.print(f"\n  Date: [bold]{daily['date']}[/bold]")
    console.print(f"  {daily['summary']}\n")

    # ── Section 2: Team Metrics ──────────────────────────────────────
    console.rule("[bold cyan]Team Metrics[/bold cyan]")
    console.print()

    team = engine.team_metrics(days=days, repo=repo)
    if team:
        table = Table(show_header=True, header_style="bold cyan", expand=True)
        table.add_column("Developer", style="white", min_width=15)
        table.add_column("Commits", justify="right")
        table.add_column("C/D", justify="right", style="dim")
        table.add_column("PRs", justify="right")
        table.add_column("Reviews", justify="right")
        table.add_column("Merge(h)", justify="right")
        table.add_column("+/- Lines", justify="right")

        for m in team[:10]:
            table.add_row(
                m.author,
                str(m.commits_count),
                str(m.commits_per_day),
                str(m.prs_created),
                str(m.reviews_given),
                str(m.avg_pr_merge_time_hours),
                f"+{m.lines_added}/-{m.lines_removed}",
            )
        console.print(table)
    else:
        console.print("[dim]No team data yet. Run 'devpulse sync' to fetch data.[/dim]")

    # ── Section 3: Team Health ───────────────────────────────────────
    console.rule("[bold cyan]Team Health[/bold cyan]")
    console.print()

    health = engine.team_health(days=days, repo=repo)
    score_color = "green" if health.overall_score >= 70 else "yellow" if health.overall_score >= 40 else "red"
    console.print(f"  Health Score: [{score_color}]{health.overall_score}/100[/{score_color}]")
    console.print(f"  Workload Balance: {health.workload_balance:.0%}")
    console.print(f"  Collaboration: {health.collaboration_score:.0%}")
    console.print(f"  Velocity: {health.velocity_trend}")

    if health.burnout_risk:
        console.print("\n  [bold]Burnout Risk:[/bold]")
        for name, risk in sorted(health.burnout_risk.items(), key=lambda x: x[1], reverse=True):
            color = "red" if risk >= 0.6 else "yellow" if risk >= 0.3 else "green"
            bar_len = int(risk * 20)
            bar = "#" * bar_len + "-" * (20 - bar_len)
            console.print(f"    {name:<15} [{color}]{bar}[/{color}] {risk:.0%}")

    # ── Section 4: AI Insights ───────────────────────────────────────
    console.rule("[bold cyan]AI Insights[/bold cyan]")
    console.print()

    insights = engine.generate_insights(days=days, repo=repo)
    for i, insight in enumerate(insights, 1):
        render_insight_card(console, insight, i)

    # ── Section 5: Goals ─────────────────────────────────────────────
    goals = db.get_goals(status="active")
    if goals:
        console.rule("[bold cyan]Active Goals[/bold cyan]")
        console.print()
        goal_table = Table(show_header=True, header_style="bold cyan")
        goal_table.add_column("Goal", style="white")
        goal_table.add_column("Metric")
        goal_table.add_column("Progress", justify="right")
        goal_table.add_column("Deadline")
        for g in goals:
            pct = (g["current_value"] / g["target_value"] * 100) if g["target_value"] > 0 else 0
            color = "green" if pct >= 75 else "yellow" if pct >= 25 else "red"
            goal_table.add_row(
                g["title"],
                g["metric"],
                f"[{color}]{pct:.0%}[/{color}]",
                g.get("deadline", "-"),
            )
        console.print(goal_table)

    # ── Section 6: Heatmap ───────────────────────────────────────────
    console.rule("[bold cyan]Activity Heatmap[/bold cyan]")
    console.print()

    heatmap_data = engine.activity_heatmap(author=author, days=90)
    if heatmap_data:
        render_heatmap(console, heatmap_data, days=90)
    else:
        console.print("[dim]No activity data. Run 'devpulse sync' to fetch commits.[/dim]")

    # ── Section 7: Recommendations ───────────────────────────────────
    console.rule("[bold cyan]Recommendations[/bold cyan]")
    console.print()
    for rec in health.recommendations:
        console.print(f"  -> {rec}")

    console.print()
    console.print("[dim]Run 'devpulse sync' to refresh data | 'devpulse --help' for all commands[/dim]")
