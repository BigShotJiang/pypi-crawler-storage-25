"""Main CLI entry point for DevPulse."""

import click

from devpulse.cli.dashboard import dashboard_cmd


@click.group()
@click.version_option(version="1.0.0", prog_name="devpulse")
def cli() -> None:
    """DevPulse -- AI-powered developer productivity dashboard.

    Track commits, PRs, issues, and reviews. Get AI-powered insights
    on team health, sprint velocity, and developer productivity.

    Set DEVPULSE_GITHUB_TOKEN environment variable for GitHub access.
    """
    pass


# ── Sync command ─────────────────────────────────────────────────────

@cli.command()
@click.option("--repos", "-r", multiple=True, help="Specific repos to sync (owner/name).")
@click.option("--since", "-s", default=None, help="Sync data since this date (ISO format).")
@click.option("--all", "sync_all", is_flag=True, help="Sync all accessible repos.")
def sync(repos: tuple[str, ...], since: str | None, sync_all: bool) -> None:
    """Sync data from GitHub."""
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn

    from devpulse.core.config import get_settings
    from devpulse.core.github_client import GitHubClient
    from devpulse.core.database import Database

    console = Console()
    settings = get_settings()

    if not settings.github_token:
        console.print("[red]Error: DEVPULSE_GITHUB_TOKEN not set.[/red]")
        console.print("Run: export DEVPULSE_GITHUB_TOKEN=your_token_here")
        raise SystemExit(1)

    client = GitHubClient()
    db = Database()

    repo_list = list(repos) if repos else None
    if not repo_list and not sync_all:
        if settings.github_repos:
            repo_list = settings.github_repos
        else:
            console.print("[yellow]Discovering repositories...[/yellow]")
            repo_list = client.get_repos()
            if not repo_list:
                console.print("[red]No repositories found. Use --repos or set DEVPULSE_GITHUB_ORG.[/red]")
                raise SystemExit(1)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task("Syncing GitHub data...", total=None)
        counts = client.sync_all(repos=repo_list, since=since, db=db)
        progress.update(task, completed=True)

    console.print("\n[green]Sync complete![/green]")
    console.print(f"  Commits:  {counts['commits']}")
    console.print(f"  PRs:      {counts['prs']}")
    console.print(f"  Issues:   {counts['issues']}")
    console.print(f"  Reviews:  {counts['reviews']}")


# ── Report commands ──────────────────────────────────────────────────

@cli.command()
@click.option("--date", "-d", default=None, help="Date for report (YYYY-MM-DD).")
@click.option("--author", "-a", default=None, help="Filter by author.")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
@click.option("--format", "-f", "fmt", type=click.Choice(["terminal", "markdown", "json", "html"]), default="terminal", help="Output format.")
@click.option("--save", is_flag=True, help="Save report to file.")
def daily(date: str | None, author: str | None, repo: str | None, fmt: str, save: bool) -> None:
    """Generate a daily report."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel

    from devpulse.core.report_generator import ReportGenerator

    console = Console()
    gen = ReportGenerator()
    data = gen.daily_report(target_date=date, author=author, repo=repo)

    if fmt == "terminal":
        console.print(Panel(f"[bold]Daily Report — {data['date']}[/bold]", style="blue"))
        console.print(f"[dim]Author: {data['author']}[/dim]")
        console.print(f"\n{data['summary']}\n")

        table = Table(title="Metrics", show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="white")
        table.add_column("Value", style="green", justify="right")
        for key in ["commits", "prs_opened", "prs_merged", "issues_opened", "issues_closed", "reviews_given", "lines_changed"]:
            table.add_row(key.replace("_", " ").title(), str(data.get(key, 0)))
        console.print(table)

        if data.get("commit_details"):
            console.print("\n[bold]Recent Commits[/bold]")
            for c in data["commit_details"]:
                console.print(f"  [dim][{c['sha']}][/dim] {c['message']} [dim]({c['repo']})[/dim]")
    elif fmt == "json":
        console.print(gen.to_json(data))
    elif fmt == "html":
        html = gen.to_html(data, "daily")
        if save:
            path = gen.save_report(data, "daily", "html")
            console.print(f"[green]Report saved to {path}[/green]")
        else:
            console.print(html)
    else:
        md = gen.to_markdown(data, "daily")
        if save:
            path = gen.save_report(data, "daily", "markdown")
            console.print(f"[green]Report saved to {path}[/green]")
        else:
            console.print(md)

    if save and fmt in ("terminal", "json"):
        path = gen.save_report(data, "daily", fmt if fmt != "terminal" else "markdown")
        console.print(f"[green]Report saved to {path}[/green]")


@cli.command()
@click.option("--week-start", "-w", default=None, help="Week start date (YYYY-MM-DD).")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
@click.option("--format", "-f", "fmt", type=click.Choice(["terminal", "markdown", "json", "html"]), default="terminal")
@click.option("--save", is_flag=True, help="Save report to file.")
def weekly(week_start: str | None, repo: str | None, fmt: str, save: bool) -> None:
    """Generate a weekly report."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel

    from devpulse.core.report_generator import ReportGenerator

    console = Console()
    gen = ReportGenerator()
    data = gen.weekly_report(week_start=week_start, repo=repo)

    if fmt == "terminal":
        console.print(Panel(f"[bold]Weekly Report — {data['week_start']} to {data['week_end']}[/bold]", style="blue"))

        console.print(f"\n[bold]Overview[/bold]")
        console.print(f"  Commits:      {data['total_commits']}")
        console.print(f"  PRs:          {data['total_prs']}")
        console.print(f"  Issues Closed: {data['total_issues_closed']}")
        console.print(f"  Avg Merge:    {data['avg_merge_time_hours']}h")

        if data["top_contributors"]:
            table = Table(title="Top Contributors", show_header=True, header_style="bold cyan")
            table.add_column("Author", style="white")
            table.add_column("Commits", style="green", justify="right")
            for tc in data["top_contributors"]:
                table.add_row(tc["author"], str(tc["commits"]))
            console.print(table)

        if data.get("insights"):
            console.print("\n[bold yellow]AI Insights[/bold yellow]")
            for ins in data["insights"]:
                console.print(f"  - {ins}")
        if data.get("recommendations"):
            console.print("\n[bold green]Recommendations[/bold green]")
            for rec in data["recommendations"]:
                console.print(f"  - {rec}")
    elif fmt == "json":
        console.print(gen.to_json(data))
    elif fmt == "html":
        html = gen.to_html(data, "weekly")
        if save:
            path = gen.save_report(data, "weekly", "html")
            console.print(f"[green]Saved to {path}[/green]")
        else:
            console.print(html)
    else:
        md = gen.to_markdown(data, "weekly")
        if save:
            path = gen.save_report(data, "weekly", "markdown")
            console.print(f"[green]Saved to {path}[/green]")
        else:
            console.print(md)

    if save and fmt == "terminal":
        path = gen.save_report(data, "weekly", "markdown")
        console.print(f"[green]Report saved to {path}[/green]")


@cli.command()
@click.option("--year", "-y", default=None, type=int, help="Year.")
@click.option("--month", "-m", default=None, type=int, help="Month (1-12).")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
@click.option("--format", "-f", "fmt", type=click.Choice(["terminal", "markdown", "json", "html"]), default="terminal")
@click.option("--save", is_flag=True, help="Save report to file.")
def monthly(year: int | None, month: int | None, repo: str | None, fmt: str, save: bool) -> None:
    """Generate a monthly report."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel

    from devpulse.core.report_generator import ReportGenerator

    console = Console()
    gen = ReportGenerator()
    data = gen.monthly_report(year=year, month=month, repo=repo)

    if fmt == "terminal":
        console.print(Panel(f"[bold]Monthly Report — {data['period']}[/bold]", style="blue"))

        console.print(f"\n[bold]Overview[/bold]")
        console.print(f"  Commits:       {data['total_commits']}")
        console.print(f"  PRs:           {data['total_prs']}")
        console.print(f"  Issues Closed: {data['total_issues_closed']}")
        console.print(f"  Team Health:   {data['team_health_score']}/100")
        console.print(f"  Velocity:      {data['velocity_trend']}")

        if data.get("burnout_risks"):
            console.print("\n[bold]Burnout Risk[/bold]")
            for name, risk in data["burnout_risks"].items():
                color = "red" if risk >= 0.6 else "yellow" if risk >= 0.3 else "green"
                console.print(f"  [{color}]{name}: {risk:.0%}[/{color}]")

        if data["top_contributors"]:
            table = Table(title="Top Contributors", show_header=True, header_style="bold cyan")
            table.add_column("Author", style="white")
            table.add_column("Commits", style="green", justify="right")
            for tc in data["top_contributors"]:
                table.add_row(tc["author"], str(tc["commits"]))
            console.print(table)

        if data.get("insights"):
            console.print("\n[bold yellow]AI Insights[/bold yellow]")
            for ins in data["insights"]:
                console.print(f"  - {ins}")
    elif fmt == "json":
        console.print(gen.to_json(data))
    elif fmt == "html":
        html = gen.to_html(data, "monthly")
        if save:
            path = gen.save_report(data, "monthly", "html")
            console.print(f"[green]Saved to {path}[/green]")
        else:
            console.print(html)
    else:
        md = gen.to_markdown(data, "monthly")
        if save:
            path = gen.save_report(data, "monthly", "markdown")
            console.print(f"[green]Saved to {path}[/green]")
        else:
            console.print(md)

    if save and fmt == "terminal":
        path = gen.save_report(data, "monthly", "markdown")
        console.print(f"[green]Report saved to {path}[/green]")


# ── Metrics command ──────────────────────────────────────────────────

@cli.command()
@click.option("--author", "-a", default=None, help="Developer name or 'all' for team.")
@click.option("--days", "-d", default=30, help="Number of days to analyze.")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
@click.option("--format", "-f", "fmt", type=click.Choice(["terminal", "json"]), default="terminal")
def metrics(author: str | None, days: int, repo: str | None, fmt: str) -> None:
    """View developer or team metrics."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel

    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    if author and author != "all":
        m = engine.developer_metrics(author=author, days=days, repo=repo)
        if fmt == "json":
            console.print(m.model_dump_json(indent=2))
            return
        console.print(Panel(f"[bold]Metrics: {m.author}[/bold] ({m.period_days}d)", style="blue"))

        table = Table(show_header=True, header_style="bold cyan", grid=True)
        table.add_column("Metric", style="white")
        table.add_column("Value", style="green", justify="right")
        table.add_row("Commits", str(m.commits_count))
        table.add_row("Active Days", str(m.active_days))
        table.add_row("Commits/Day", str(m.commits_per_day))
        table.add_row("PRs Created", str(m.prs_created))
        table.add_row("PRs Merged", str(m.prs_merged))
        table.add_row("Avg PR Merge Time", f"{m.avg_pr_merge_time_hours}h")
        table.add_row("Reviews Given", str(m.reviews_given))
        table.add_row("Avg Review Turnaround", f"{m.avg_review_turnaround_hours}h")
        table.add_row("Issues Opened", str(m.issues_opened))
        table.add_row("Issues Closed", str(m.issues_closed))
        table.add_row("Lines Added", f"+{m.lines_added}")
        table.add_row("Lines Removed", f"-{m.lines_removed}")
        console.print(table)
    else:
        team = engine.team_metrics(days=days, repo=repo)
        if fmt == "json":
            import json
            console.print(json.dumps([m.model_dump() for m in team], indent=2, default=str))
            return
        if not team:
            console.print("[yellow]No data. Run 'devpulse sync' first.[/yellow]")
            return
        console.print(Panel(f"[bold]Team Metrics[/bold] ({days}d)", style="blue"))
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Author", style="white")
        table.add_column("Commits", justify="right")
        table.add_column("C/D", justify="right", style="dim")
        table.add_column("PRs", justify="right")
        table.add_column("Merged", justify="right")
        table.add_column("Reviews", justify="right")
        table.add_column("Merge(h)", justify="right")
        table.add_column("Lines +/-", justify="right")
        for m in team:
            table.add_row(
                m.author,
                str(m.commits_count),
                str(m.commits_per_day),
                str(m.prs_created),
                str(m.prs_merged),
                str(m.reviews_given),
                str(m.avg_pr_merge_time_hours),
                f"+{m.lines_added}/-{m.lines_removed}",
            )
        console.print(table)


# ── Insights command ─────────────────────────────────────────────────

@cli.command()
@click.option("--days", "-d", default=30, help="Analysis window in days.")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
def insights(days: int, repo: str | None) -> None:
    """Get AI-powered insights and recommendations."""
    from rich.console import Console
    from rich.panel import Panel

    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    results = engine.generate_insights(days=days, repo=repo)

    console.print(Panel("[bold]AI-Powered Insights[/bold]", style="blue"))
    for i, insight in enumerate(results, 1):
        severity = insight["severity"]
        color = "red" if severity == "high" else "yellow" if severity == "medium" else "green"
        console.print(f"\n[{color}]  {i}. {insight['message']}[/{color}]")
        console.print(f"[dim]     Recommendation: {insight['recommendation']}[/dim]")


# ── Team Health command ──────────────────────────────────────────────

@cli.command()
@click.option("--days", "-d", default=30, help="Analysis window.")
@click.option("--repo", "-r", default=None, help="Filter by repo.")
def health(days: int, repo: str | None) -> None:
    """Analyze team health and burnout risk."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import BarColumn, Progress

    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    th = engine.team_health(days=days, repo=repo)

    console.print(Panel("[bold]Team Health Report[/bold]", style="blue"))

    score_color = "green" if th.overall_score >= 70 else "yellow" if th.overall_score >= 40 else "red"
    console.print(f"\n  Overall Score: [{score_color}]{th.overall_score}/100[/{score_color}]")
    console.print(f"  Workload Balance: {th.workload_balance:.0%}")
    console.print(f"  Collaboration: {th.collaboration_score:.0%}")
    console.print(f"  Velocity Trend: {th.velocity_trend}")

    if th.burnout_risk:
        console.print("\n[bold]Burnout Risk[/bold]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Developer", style="white")
        table.add_column("Risk", justify="right")
        for name, risk in sorted(th.burnout_risk.items(), key=lambda x: x[1], reverse=True):
            color = "red" if risk >= 0.6 else "yellow" if risk >= 0.3 else "green"
            table.add_row(name, f"[{color}]{risk:.0%}[/{color}]")
        console.print(table)

    if th.recommendations:
        console.print("\n[bold green]Recommendations[/bold green]")
        for rec in th.recommendations:
            console.print(f"  - {rec}")


# ── Goals commands ───────────────────────────────────────────────────

@cli.group()
def goals() -> None:
    """Manage goals and track progress."""
    pass


@goals.command("add")
@click.option("--title", "-t", required=True, help="Goal title.")
@click.option("--target", required=True, type=float, help="Target value.")
@click.option("--metric", "-m", required=True, help="Metric name (e.g., commits_per_day).")
@click.option("--deadline", "-d", default=None, help="Deadline (YYYY-MM-DD).")
@click.option("--description", default="", help="Goal description.")
def goals_add(title: str, target: float, metric: str, deadline: str | None, description: str) -> None:
    """Add a new goal."""
    from rich.console import Console
    from devpulse.core.database import Database

    console = Console()
    db = Database()
    gid = db.upsert_goal({
        "title": title,
        "target_value": target,
        "metric": metric,
        "deadline": deadline,
        "description": description,
    })
    console.print(f"[green]Goal created (ID: {gid}): {title}[/green]")


@goals.command("list")
def goals_list() -> None:
    """List all goals."""
    from rich.console import Console
    from rich.table import Table
    from devpulse.core.database import Database

    console = Console()
    db = Database()
    all_goals = db.get_goals()

    if not all_goals:
        console.print("[yellow]No goals found. Use 'devpulse goals add' to create one.[/yellow]")
        return

    table = Table(title="Goals", show_header=True, header_style="bold cyan")
    table.add_column("ID", justify="right")
    table.add_column("Title", style="white")
    table.add_column("Metric")
    table.add_column("Progress", justify="right")
    table.add_column("Target", justify="right")
    table.add_column("Deadline")
    table.add_column("Status")
    for g in all_goals:
        pct = (g["current_value"] / g["target_value"] * 100) if g["target_value"] > 0 else 0
        color = "green" if pct >= 75 else "yellow" if pct >= 25 else "red"
        table.add_row(
            str(g["id"]),
            g["title"],
            g["metric"],
            f"[{color}]{pct:.0%}[/{color}]",
            str(g["target_value"]),
            g.get("deadline", "-"),
            g["status"],
        )
    console.print(table)


@goals.command("coach")
@click.option("--goal-id", "-g", default=None, type=int, help="Specific goal ID.")
def goals_coach(goal_id: int | None) -> None:
    """Get AI coaching on your goals."""
    from rich.console import Console
    from rich.panel import Panel
    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()
    coaching = engine.goal_coaching(goal_id=goal_id)

    console.print(Panel("[bold]AI Goal Coaching[/bold]", style="blue"))
    for c in coaching:
        color = "green" if c["status"] == "achieved" else "yellow" if c["status"] == "on_track" else "red"
        console.print(f"\n[{color}]  {c['goal']}[/{color}]")
        console.print(f"    Progress: {c['progress_pct']:.0f}% ({c['current']}/{c['target']} {c['metric']})")
        console.print(f"    [dim]Advice: {c['advice']}[/dim]")


@goals.command("delete")
@click.argument("goal_id", type=int)
def goals_delete(goal_id: int) -> None:
    """Delete a goal."""
    from rich.console import Console
    from devpulse.core.database import Database

    console = Console()
    db = Database()
    if db.delete_goal(goal_id):
        console.print(f"[green]Goal {goal_id} deleted.[/green]")
    else:
        console.print(f"[red]Goal {goal_id} not found.[/red]")


# ── Sprint commands ──────────────────────────────────────────────────

@cli.group()
def sprint() -> None:
    """Sprint analytics and tracking."""
    pass


@sprint.command("snapshot")
@click.option("--name", "-n", required=True, help="Sprint name.")
@click.option("--total", required=True, type=float, help="Total story points.")
@click.option("--completed", required=True, type=float, help="Completed story points.")
@click.option("--added", default=0.0, type=float, help="Points added mid-sprint.")
def sprint_snapshot(name: str, total: float, completed: float, added: float) -> None:
    """Record a sprint snapshot for burndown tracking."""
    from rich.console import Console
    from devpulse.core.database import Database

    console = Console()
    db = Database()
    db.save_sprint_snapshot({
        "sprint_name": name,
        "total_points": total,
        "completed_points": completed,
        "remaining_points": total - completed,
        "added_points": added,
    })
    console.print(f"[green]Sprint snapshot recorded for '{name}'.[/green]")


@sprint.command("burndown")
@click.option("--name", "-n", required=True, help="Sprint name.")
def sprint_burndown(name: str) -> None:
    """View sprint burndown chart."""
    from rich.console import Console
    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    data = engine.sprint_burndown(name)
    if not data:
        console.print(f"[yellow]No data for sprint '{name}'.[/yellow]")
        return

    console.print(f"\n[bold]Sprint Burndown: {name}[/bold]\n")
    max_pts = max(d["remaining"] for d in data) if data else 1
    chart_width = 50

    for d in data:
        actual_bar = int(d["remaining"] / max(max_pts, 1) * chart_width)
        ideal_bar = int(d["ideal"] / max(max_pts, 1) * chart_width)
        actual_str = "[green]" + "#" * actual_bar + "[/green]"
        ideal_str = "[dim]" + "." * ideal_bar + "[/dim]"
        console.print(f"  Day {d['day']:2d} | {actual_str} {d['remaining']:.1f}")
        console.print(f"         | {ideal_str}")

    console.print(f"\n  Scale: 0{' ' * (chart_width - 8)}{max_pts:.0f} pts")


@sprint.command("predict")
@click.option("--name", "-n", required=True, help="Sprint name.")
@click.option("--total", required=True, type=float, help="Total story points.")
@click.option("--elapsed", required=True, type=int, help="Days elapsed.")
@click.option("--duration", required=True, type=int, help="Total sprint duration (days).")
def sprint_predict(name: str, total: float, elapsed: int, duration: int) -> None:
    """Predict sprint completion."""
    from rich.console import Console
    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    result = engine.predict_sprint_completion(name, total, elapsed, duration)
    color = "green" if result["prediction"] == "on_track" else "red"
    console.print(f"\n[{color}]{result['message']}[/{color}]")
    console.print(f"  Prediction: {result['prediction']} | Confidence: {result['confidence']}%")


# ── Quality command ──────────────────────────────────────────────────

@cli.command()
@click.option("--repo", "-r", default=None, help="Repository to analyze.")
@click.option("--days", "-d", default=30, type=int, help="Analysis window.")
@click.option("--format", "-f", "fmt", type=click.Choice(["terminal", "json"]), default="terminal")
def quality(repo: str | None, days: int, fmt: str) -> None:
    """View code quality trends."""
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from devpulse.core.analytics import AnalyticsEngine

    console = Console()
    engine = AnalyticsEngine()

    if repo:
        score = engine.compute_quality_score(repo=repo, days=days)
        if fmt == "json":
            import json
            console.print(json.dumps(score, indent=2))
            return
        console.print(Panel(f"[bold]Code Quality: {repo}[/bold] ({days}d)", style="blue"))
        table = Table(show_header=True, header_style="bold cyan", grid=True)
        table.add_column("Metric", style="white")
        table.add_column("Value", style="green", justify="right")
        for k, v in score.items():
            table.add_row(k.replace("_", " ").title(), str(v))
        console.print(table)
    else:
        trends = engine.code_quality_trend(days=days)
        if fmt == "json":
            import json
            console.print(json.dumps([t.model_dump() for t in trends], indent=2, default=str))
            return
        if not trends:
            console.print("[yellow]No quality data. Record snapshots with 'devpulse sprint snapshot'.[/yellow]")
            return
        console.print(Panel("[bold]Code Quality Trends[/bold]", style="blue"))
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Date")
        table.add_column("Repo")
        table.add_column("Coverage", justify="right")
        table.add_column("Bugs", justify="right")
        table.add_column("Tech Debt", justify="right")
        for t in trends[-20:]:
            table.add_row(t.date, t.repo, f"{t.test_coverage:.0%}", str(t.open_bugs), f"{t.tech_debt_score:.1f}")
        console.print(table)


# ── Heatmap command ──────────────────────────────────────────────────

@cli.command()
@click.option("--author", "-a", default=None, help="Filter by author.")
@click.option("--days", "-d", default=365, type=int, help="Number of days to show.")
def heatmap(author: str | None, days: int) -> None:
    """Show GitHub-style activity heatmap."""
    from rich.console import Console
    from devpulse.core.analytics import AnalyticsEngine
    from devpulse.cli.render import render_heatmap

    console = Console()
    engine = AnalyticsEngine()

    data = engine.activity_heatmap(author=author, days=days)
    render_heatmap(console, data, days)


# ── Dashboard command ────────────────────────────────────────────────

@cli.command()
@click.option("--author", "-a", default=None, help="Focus on specific developer.")
@click.option("--days", "-d", default=30, type=int, help="Dashboard window.")
@click.option("--repo", "-r", default=None, help="Focus repo.")
def dashboard(author: str | None, days: int, repo: str | None) -> None:
    """Launch the interactive terminal dashboard."""
    dashboard_cmd(author=author, days=days, repo=repo)


# ── Serve command ────────────────────────────────────────────────────

@cli.command()
@click.option("--host", default="127.0.0.1", help="Bind host.")
@click.option("--port", "-p", default=8742, type=int, help="Bind port.")
def serve(host: str, port: int) -> None:
    """Start the DevPulse web API server."""
    import uvicorn
    console_import_msg = "Starting DevPulse API server..."
    print(console_import_msg)
    uvicorn.run("devpulse.api.app:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    cli()
