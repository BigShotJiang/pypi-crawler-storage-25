"""Pydantic models for DevPulse data structures."""

from datetime import datetime, date
from typing import Optional

from pydantic import BaseModel, Field


class Commit(BaseModel):
    sha: str
    repo: str
    author: str
    author_date: str
    message: str = ""
    additions: int = 0
    deletions: int = 0
    url: str = ""


class PullRequest(BaseModel):
    number: int
    repo: str
    title: str = ""
    author: str = ""
    state: str = "open"
    created_at: str = ""
    merged_at: Optional[str] = None
    closed_at: Optional[str] = None
    additions: int = 0
    deletions: int = 0
    changed_files: int = 0
    review_comments: int = 0
    url: str = ""


class Issue(BaseModel):
    number: int
    repo: str
    title: str = ""
    author: str = ""
    state: str = "open"
    labels: list[str] = Field(default_factory=list)
    created_at: str = ""
    closed_at: Optional[str] = None
    url: str = ""


class Review(BaseModel):
    id: int
    repo: str
    pr_number: int
    author: str = ""
    state: str = ""
    submitted_at: str = ""
    body: str = ""


class DeveloperMetrics(BaseModel):
    author: str
    commits_count: int = 0
    prs_created: int = 0
    prs_merged: int = 0
    issues_opened: int = 0
    issues_closed: int = 0
    reviews_given: int = 0
    avg_pr_merge_time_hours: float = 0.0
    avg_review_turnaround_hours: float = 0.0
    lines_added: int = 0
    lines_removed: int = 0
    commits_per_day: float = 0.0
    active_days: int = 0
    period_days: int = 30


class SprintData(BaseModel):
    name: str
    total_points: float = 0
    completed_points: float = 0
    remaining_points: float = 0
    added_points: float = 0
    start_date: str = ""
    end_date: str = ""
    velocity: float = 0
    scope_creep_pct: float = 0


class TeamHealth(BaseModel):
    team_name: str = "team"
    overall_score: float = 0.0
    workload_balance: float = 0.0
    burnout_risk: dict[str, float] = Field(default_factory=dict)
    collaboration_score: float = 0.0
    velocity_trend: str = "stable"
    recommendations: list[str] = Field(default_factory=list)


class CodeQuality(BaseModel):
    repo: str
    date: str = ""
    test_coverage: float = 0.0
    open_bugs: int = 0
    tech_debt_score: float = 0.0
    lines_added: int = 0
    lines_removed: int = 0
    files_changed: int = 0


class Goal(BaseModel):
    id: Optional[int] = None
    title: str
    description: str = ""
    target_value: float
    current_value: float = 0
    metric: str
    deadline: Optional[str] = None
    status: str = "active"


class DailyReport(BaseModel):
    date: str
    author: str
    commits: int = 0
    prs_opened: int = 0
    prs_merged: int = 0
    issues_opened: int = 0
    issues_closed: int = 0
    reviews_given: int = 0
    lines_changed: int = 0
    summary: str = ""


class WeeklyReport(BaseModel):
    week_start: str
    week_end: str
    authors: list[str] = Field(default_factory=list)
    total_commits: int = 0
    total_prs: int = 0
    total_issues_closed: int = 0
    avg_merge_time_hours: float = 0.0
    top_contributors: list[dict[str, int]] = Field(default_factory=list)
    insights: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
