"""SQLite database layer for DevPulse."""

import sqlite3
import json
from datetime import datetime, date
from pathlib import Path
from typing import Any, Optional

from devpulse.core.config import get_settings


class Database:
    """Manages the SQLite database for DevPulse."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        if db_path is None:
            settings = get_settings()
            db_path = settings.database_path
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self) -> None:
        """Create tables if they do not exist."""
        conn = self._connect()
        try:
            conn.executescript(SCHEMA)
            conn.commit()
        finally:
            conn.close()

    # ── Commits ──────────────────────────────────────────────────────

    def upsert_commits(self, commits: list[dict[str, Any]]) -> int:
        """Insert or update commits. Returns count of new rows."""
        conn = self._connect()
        try:
            count = 0
            for c in commits:
                cur = conn.execute(
                    """INSERT INTO commits (sha, repo, author, author_date, message, additions, deletions, url)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(sha) DO UPDATE SET
                         additions=excluded.additions,
                         deletions=excluded.deletions""",
                    (
                        c["sha"],
                        c["repo"],
                        c["author"],
                        c["author_date"],
                        c["message"],
                        c.get("additions", 0),
                        c.get("deletions", 0),
                        c.get("url", ""),
                    ),
                )
                if cur.rowcount > 0:
                    count += 1
            conn.commit()
            return count
        finally:
            conn.close()

    def get_commits(
        self,
        repo: Optional[str] = None,
        author: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        """Query commits with optional filters."""
        clauses: list[str] = []
        params: list[Any] = []

        if repo:
            clauses.append("repo = ?")
            params.append(repo)
        if author:
            clauses.append("author = ?")
            params.append(author)
        if since:
            clauses.append("author_date >= ?")
            params.append(since)
        if until:
            # If until is a plain date, extend to end of day
            until_val = until if "T" in until else f"{until}T23:59:59Z"
            clauses.append("author_date <= ?")
            params.append(until_val)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)

        conn = self._connect()
        try:
            rows = conn.execute(
                f"SELECT * FROM commits {where} ORDER BY author_date DESC LIMIT ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_commit_count_by_day(
        self, author: Optional[str] = None, days: int = 365
    ) -> list[dict[str, Any]]:
        """Get daily commit counts for heatmap."""
        conn = self._connect()
        try:
            query = """
                SELECT DATE(author_date) as day, COUNT(*) as count
                FROM commits
                WHERE author_date >= date('now', ?)"""
            params: list[Any] = [f"-{days} days"]
            if author:
                query += " AND author = ?"
                params.append(author)
            query += " GROUP BY DATE(author_date) ORDER BY day"
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ── Pull Requests ────────────────────────────────────────────────

    def upsert_pull_requests(self, prs: list[dict[str, Any]]) -> int:
        """Insert or update pull requests."""
        conn = self._connect()
        try:
            count = 0
            for p in prs:
                cur = conn.execute(
                    """INSERT INTO pull_requests
                       (number, repo, title, author, state, created_at, merged_at, closed_at,
                        additions, deletions, changed_files, review_comments, url)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(repo, number) DO UPDATE SET
                         state=excluded.state,
                         merged_at=excluded.merged_at,
                         closed_at=excluded.closed_at,
                         review_comments=excluded.review_comments""",
                    (
                        p["number"],
                        p["repo"],
                        p["title"],
                        p["author"],
                        p["state"],
                        p["created_at"],
                        p.get("merged_at"),
                        p.get("closed_at"),
                        p.get("additions", 0),
                        p.get("deletions", 0),
                        p.get("changed_files", 0),
                        p.get("review_comments", 0),
                        p.get("url", ""),
                    ),
                )
                if cur.rowcount > 0:
                    count += 1
            conn.commit()
            return count
        finally:
            conn.close()

    def get_pull_requests(
        self,
        repo: Optional[str] = None,
        author: Optional[str] = None,
        state: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if repo:
            clauses.append("repo = ?")
            params.append(repo)
        if author:
            clauses.append("author = ?")
            params.append(author)
        if state:
            clauses.append("state = ?")
            params.append(state)
        if since:
            clauses.append("created_at >= ?")
            params.append(since)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        conn = self._connect()
        try:
            rows = conn.execute(
                f"SELECT * FROM pull_requests {where} ORDER BY created_at DESC LIMIT ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ── Issues ───────────────────────────────────────────────────────

    def upsert_issues(self, issues: list[dict[str, Any]]) -> int:
        conn = self._connect()
        try:
            count = 0
            for i in issues:
                cur = conn.execute(
                    """INSERT INTO issues
                       (number, repo, title, author, state, labels, created_at, closed_at, url)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(repo, number) DO UPDATE SET
                         state=excluded.state,
                         closed_at=excluded.closed_at,
                         labels=excluded.labels""",
                    (
                        i["number"],
                        i["repo"],
                        i["title"],
                        i["author"],
                        i["state"],
                        json.dumps(i.get("labels", [])),
                        i["created_at"],
                        i.get("closed_at"),
                        i.get("url", ""),
                    ),
                )
                if cur.rowcount > 0:
                    count += 1
            conn.commit()
            return count
        finally:
            conn.close()

    def get_issues(
        self,
        repo: Optional[str] = None,
        state: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if repo:
            clauses.append("repo = ?")
            params.append(repo)
        if state:
            clauses.append("state = ?")
            params.append(state)
        if since:
            clauses.append("created_at >= ?")
            params.append(since)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        conn = self._connect()
        try:
            rows = conn.execute(
                f"SELECT * FROM issues {where} ORDER BY created_at DESC LIMIT ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ── Reviews ──────────────────────────────────────────────────────

    def upsert_reviews(self, reviews: list[dict[str, Any]]) -> int:
        conn = self._connect()
        try:
            count = 0
            for r in reviews:
                cur = conn.execute(
                    """INSERT INTO reviews
                       (id, repo, pr_number, author, state, submitted_at, body)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(id) DO UPDATE SET
                         state=excluded.state""",
                    (
                        r["id"],
                        r["repo"],
                        r["pr_number"],
                        r["author"],
                        r["state"],
                        r["submitted_at"],
                        r.get("body", ""),
                    ),
                )
                if cur.rowcount > 0:
                    count += 1
            conn.commit()
            return count
        finally:
            conn.close()

    def get_reviews(
        self,
        repo: Optional[str] = None,
        author: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if repo:
            clauses.append("repo = ?")
            params.append(repo)
        if author:
            clauses.append("author = ?")
            params.append(author)
        if since:
            clauses.append("submitted_at >= ?")
            params.append(since)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        conn = self._connect()
        try:
            rows = conn.execute(
                f"SELECT * FROM reviews {where} ORDER BY submitted_at DESC LIMIT ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ── Goals ────────────────────────────────────────────────────────

    def upsert_goal(self, goal: dict[str, Any]) -> int:
        conn = self._connect()
        try:
            if goal.get("id"):
                conn.execute(
                    """UPDATE goals SET title=?, description=?, target_value=?, current_value=?,
                       metric=?, deadline=?, status=? WHERE id=?""",
                    (
                        goal["title"],
                        goal.get("description", ""),
                        goal["target_value"],
                        goal.get("current_value", 0),
                        goal["metric"],
                        goal.get("deadline"),
                        goal.get("status", "active"),
                        goal["id"],
                    ),
                )
                gid = goal["id"]
            else:
                cur = conn.execute(
                    """INSERT INTO goals (title, description, target_value, current_value, metric, deadline, status)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        goal["title"],
                        goal.get("description", ""),
                        goal["target_value"],
                        goal.get("current_value", 0),
                        goal["metric"],
                        goal.get("deadline"),
                        goal.get("status", "active"),
                    ),
                )
                gid = cur.lastrowid
            conn.commit()
            return gid  # type: ignore[return-value]
        finally:
            conn.close()

    def get_goals(self, status: Optional[str] = None) -> list[dict[str, Any]]:
        conn = self._connect()
        try:
            if status:
                rows = conn.execute(
                    "SELECT * FROM goals WHERE status = ? ORDER BY deadline", (status,)
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM goals ORDER BY deadline").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def delete_goal(self, goal_id: int) -> bool:
        conn = self._connect()
        try:
            cur = conn.execute("DELETE FROM goals WHERE id = ?", (goal_id,))
            conn.commit()
            return cur.rowcount > 0
        finally:
            conn.close()

    # ── Reports cache ────────────────────────────────────────────────

    def save_report(self, report_type: str, period: str, content: str) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO reports (report_type, period, content, generated_at)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(report_type, period) DO UPDATE SET
                     content=excluded.content,
                     generated_at=excluded.generated_at""",
                (report_type, period, content, datetime.utcnow().isoformat()),
            )
            conn.commit()
        finally:
            conn.close()

    def get_report(self, report_type: str, period: str) -> Optional[str]:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT content FROM reports WHERE report_type = ? AND period = ?",
                (report_type, period),
            ).fetchone()
            return dict(row)["content"] if row else None
        finally:
            conn.close()

    # ── Sprint snapshots ─────────────────────────────────────────────

    def save_sprint_snapshot(self, snapshot: dict[str, Any]) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO sprint_snapshots (sprint_name, snapshot_date, total_points,
                   completed_points, remaining_points, added_points)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    snapshot["sprint_name"],
                    snapshot.get("snapshot_date", date.today().isoformat()),
                    snapshot["total_points"],
                    snapshot["completed_points"],
                    snapshot["remaining_points"],
                    snapshot.get("added_points", 0),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def get_sprint_snapshots(self, sprint_name: str) -> list[dict[str, Any]]:
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM sprint_snapshots WHERE sprint_name = ? ORDER BY snapshot_date",
                (sprint_name,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ── Code quality snapshots ───────────────────────────────────────

    def save_quality_snapshot(self, snapshot: dict[str, Any]) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO code_quality (repo, snapshot_date, test_coverage, open_bugs,
                   tech_debt_score, lines_added, lines_removed, files_changed)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    snapshot["repo"],
                    snapshot.get("snapshot_date", date.today().isoformat()),
                    snapshot.get("test_coverage", 0.0),
                    snapshot.get("open_bugs", 0),
                    snapshot.get("tech_debt_score", 0.0),
                    snapshot.get("lines_added", 0),
                    snapshot.get("lines_removed", 0),
                    snapshot.get("files_changed", 0),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def get_quality_snapshots(
        self, repo: Optional[str] = None, days: int = 90
    ) -> list[dict[str, Any]]:
        conn = self._connect()
        try:
            if repo:
                rows = conn.execute(
                    """SELECT * FROM code_quality
                       WHERE repo = ? AND snapshot_date >= date('now', ?)
                       ORDER BY snapshot_date""",
                    (repo, f"-{days} days"),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM code_quality
                       WHERE snapshot_date >= date('now', ?)
                       ORDER BY snapshot_date""",
                    (f"-{days} days",),
                ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


SCHEMA = """\
CREATE TABLE IF NOT EXISTS commits (
    sha TEXT PRIMARY KEY,
    repo TEXT NOT NULL,
    author TEXT NOT NULL,
    author_date TEXT NOT NULL,
    message TEXT,
    additions INTEGER DEFAULT 0,
    deletions INTEGER DEFAULT 0,
    url TEXT DEFAULT '',
    fetched_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pull_requests (
    repo TEXT NOT NULL,
    number INTEGER NOT NULL,
    title TEXT,
    author TEXT,
    state TEXT,
    created_at TEXT,
    merged_at TEXT,
    closed_at TEXT,
    additions INTEGER DEFAULT 0,
    deletions INTEGER DEFAULT 0,
    changed_files INTEGER DEFAULT 0,
    review_comments INTEGER DEFAULT 0,
    url TEXT DEFAULT '',
    fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (repo, number)
);

CREATE TABLE IF NOT EXISTS issues (
    repo TEXT NOT NULL,
    number INTEGER NOT NULL,
    title TEXT,
    author TEXT,
    state TEXT,
    labels TEXT DEFAULT '[]',
    created_at TEXT,
    closed_at TEXT,
    url TEXT DEFAULT '',
    fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (repo, number)
);

CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY,
    repo TEXT NOT NULL,
    pr_number INTEGER NOT NULL,
    author TEXT,
    state TEXT,
    submitted_at TEXT,
    body TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    target_value REAL NOT NULL,
    current_value REAL DEFAULT 0,
    metric TEXT NOT NULL,
    deadline TEXT,
    status TEXT DEFAULT 'active',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    report_type TEXT NOT NULL,
    period TEXT NOT NULL,
    content TEXT NOT NULL,
    generated_at TEXT,
    PRIMARY KEY (report_type, period)
);

CREATE TABLE IF NOT EXISTS sprint_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sprint_name TEXT NOT NULL,
    snapshot_date TEXT NOT NULL,
    total_points REAL DEFAULT 0,
    completed_points REAL DEFAULT 0,
    remaining_points REAL DEFAULT 0,
    added_points REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS code_quality (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo TEXT NOT NULL,
    snapshot_date TEXT NOT NULL,
    test_coverage REAL DEFAULT 0.0,
    open_bugs INTEGER DEFAULT 0,
    tech_debt_score REAL DEFAULT 0.0,
    lines_added INTEGER DEFAULT 0,
    lines_removed INTEGER DEFAULT 0,
    files_changed INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_commits_repo ON commits(repo);
CREATE INDEX IF NOT EXISTS idx_commits_author ON commits(author);
CREATE INDEX IF NOT EXISTS idx_commits_date ON commits(author_date);
CREATE INDEX IF NOT EXISTS idx_prs_repo ON pull_requests(repo);
CREATE INDEX IF NOT EXISTS idx_prs_author ON pull_requests(author);
CREATE INDEX IF NOT EXISTS idx_issues_repo ON issues(repo);
CREATE INDEX IF NOT EXISTS idx_issues_state ON issues(state);
CREATE INDEX IF NOT EXISTS idx_reviews_repo ON reviews(repo);
CREATE INDEX IF NOT EXISTS idx_reviews_author ON reviews(author);
CREATE INDEX IF NOT EXISTS idx_goals_status ON goals(status);
CREATE INDEX IF NOT EXISTS idx_sprint_name ON sprint_snapshots(sprint_name);
CREATE INDEX IF NOT EXISTS idx_quality_repo ON code_quality(repo);
"""
