"""Configuration management for DevPulse."""

import os
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # GitHub
    github_token: str = ""
    github_username: str = ""
    github_org: Optional[str] = None
    github_api_url: str = "https://api.github.com"
    github_repos: list[str] = []

    # Database
    database_path: str = ""

    # API Server
    api_host: str = "127.0.0.1"
    api_port: int = 8742
    api_workers: int = 1

    # Rate limiting
    github_rate_limit_rpm: int = 40
    github_cache_ttl_seconds: int = 300

    # Reports
    reports_dir: str = ""
    export_dir: str = ""

    # AI insights (local heuristic engine)
    insight_lookback_days: int = 30
    burnout_threshold: float = 0.75
    sprint_velocity_window: int = 4

    # Logging
    log_level: str = "INFO"
    redact_sensitive: bool = True

    model_config = {
        "env_prefix": "DEVPULSE_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
    }

    def model_post_init(self, __context: object) -> None:
        """Set defaults that depend on runtime state."""
        base = Path(os.getcwd()) / "devpulse_data"
        if not self.database_path:
            self.database_path = str(base / "devpulse.db")
        if not self.reports_dir:
            self.reports_dir = str(base / "reports")
        if not self.export_dir:
            self.export_dir = str(base / "exports")


_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Return cached settings instance."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reset_settings() -> None:
    """Reset cached settings (useful for testing)."""
    global _settings
    _settings = None
