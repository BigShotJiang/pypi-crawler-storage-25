"""DevPulse - AI-powered developer productivity dashboard."""

__version__ = "1.0.0"
__author__ = "DevPulse Contributors"
