from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ReverseJournalEntryRequest")


@_attrs_define
class ReverseJournalEntryRequest:
  """Reverse a posted journal entry.

  Creates a new entry whose line items flip the originals
  (debits → credits, credits → debits), sets `reversal_of` on the new
  entry to the original's id, marks the original as
  `status='reversed'`, and posts the reversing entry immediately.

  This is how accountants correct posted entries — the original stays
  in the audit trail, the reversal cancels its effect, and a
  corrected entry can be created separately.

      Attributes:
          entry_id (str):
          posting_date (datetime.date | None | Unset):
          memo (None | str | Unset):
  """

  entry_id: str
  posting_date: datetime.date | None | Unset = UNSET
  memo: None | str | Unset = UNSET
  additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

  def to_dict(self) -> dict[str, Any]:
    entry_id = self.entry_id

    posting_date: None | str | Unset
    if isinstance(self.posting_date, Unset):
      posting_date = UNSET
    elif isinstance(self.posting_date, datetime.date):
      posting_date = self.posting_date.isoformat()
    else:
      posting_date = self.posting_date

    memo: None | str | Unset
    if isinstance(self.memo, Unset):
      memo = UNSET
    else:
      memo = self.memo

    field_dict: dict[str, Any] = {}
    field_dict.update(self.additional_properties)
    field_dict.update(
      {
        "entry_id": entry_id,
      }
    )
    if posting_date is not UNSET:
      field_dict["posting_date"] = posting_date
    if memo is not UNSET:
      field_dict["memo"] = memo

    return field_dict

  @classmethod
  def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
    d = dict(src_dict)
    entry_id = d.pop("entry_id")

    def _parse_posting_date(data: object) -> datetime.date | None | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      try:
        if not isinstance(data, str):
          raise TypeError()
        posting_date_type_0 = isoparse(data).date()

        return posting_date_type_0
      except (TypeError, ValueError, AttributeError, KeyError):
        pass
      return cast(datetime.date | None | Unset, data)

    posting_date = _parse_posting_date(d.pop("posting_date", UNSET))

    def _parse_memo(data: object) -> None | str | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(None | str | Unset, data)

    memo = _parse_memo(d.pop("memo", UNSET))

    reverse_journal_entry_request = cls(
      entry_id=entry_id,
      posting_date=posting_date,
      memo=memo,
    )

    reverse_journal_entry_request.additional_properties = d
    return reverse_journal_entry_request

  @property
  def additional_keys(self) -> list[str]:
    return list(self.additional_properties.keys())

  def __getitem__(self, key: str) -> Any:
    return self.additional_properties[key]

  def __setitem__(self, key: str, value: Any) -> None:
    self.additional_properties[key] = value

  def __delitem__(self, key: str) -> None:
    del self.additional_properties[key]

  def __contains__(self, key: str) -> bool:
    return key in self.additional_properties
