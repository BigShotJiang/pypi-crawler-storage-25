from enum import Enum


class CreateStructureRequestStructureType(str, Enum):
  BALANCE_SHEET = "balance_sheet"
  CHART_OF_ACCOUNTS = "chart_of_accounts"
  COA_MAPPING = "coa_mapping"
  CUSTOM = "custom"
  EQUITY_STATEMENT = "equity_statement"
  INCOME_STATEMENT = "income_statement"
  SCHEDULE = "schedule"

  def __str__(self) -> str:
    return str(self.value)
