"""RoboSystems Client Extensions for Python

Enhanced clients with SSE support for the RoboSystems API.
Provides seamless integration with streaming operations, queue management,
and advanced query capabilities.
"""

from .sse_client import SSEClient, EventType, SSEEvent, SSEConfig
from .query_client import (
  QueryClient,
  QueryResult,
  QueuedQueryResponse,
  QueryRequest,
  QueryOptions,
  QueuedQueryError,
)
from .agent_client import (
  AgentClient,
  AgentResult,
  QueuedAgentResponse,
  AgentQueryRequest,
  AgentOptions,
  QueuedAgentError,
)
from .operation_client import (
  OperationClient,
  OperationStatus,
  OperationProgress,
  OperationResult,
)
from .file_client import (
  FileClient,
  FileUploadOptions,
  FileUploadResult,
  FileInfo,
)
from .table_client import (
  TableClient,
  TableInfo,
  QueryResult as TableQueryResult,
)
from .graph_client import (
  GraphClient,
  MaterializationOptions,
  MaterializationResult,
  GraphMetadata,
  InitialEntityData,
  GraphInfo,
)
from .investor_client import InvestorClient
from .ledger_client import LedgerClient
from .facade import (
  RoboSystemsClients,
  RoboSystemsClientConfig,
  AsyncRoboSystemsClients,
)
from .utils import (
  QueryBuilder,
  ResultProcessor,
  CacheManager,
  ProgressTracker,
  DataBatcher,
  QueryStats,
  ConnectionInfo,
  estimate_query_cost,
  format_duration,
  validate_cypher_query,
)
from .auth_integration import (
  AuthenticatedClients,
  CookieAuthClients,
  TokenClients,
  create_clients,
  create_production_clients,
  create_development_clients,
)

# JWT Token utilities
from .token_utils import (
  validate_jwt_format,
  extract_jwt_from_header,
  decode_jwt_payload,
  is_jwt_expired,
  get_jwt_claims,
  get_jwt_expiration,
  extract_token_from_environment,
  extract_token_from_cookie,
  find_valid_token,
  TokenManager,
  TokenSource,
)

# DataFrame utilities (optional - requires pandas)
try:
  from .dataframe_utils import (
    query_result_to_dataframe,
    DataFrameQueryClient,
    HAS_PANDAS,
  )

  # Re-export the imported functions for module API
  from .dataframe_utils import (
    parse_datetime_columns,
    stream_to_dataframe as _stream_to_dataframe,
    dataframe_to_cypher_params,
    export_query_to_csv,
    compare_dataframes,
  )
except ImportError:
  HAS_PANDAS = False
  DataFrameQueryClient = None
  # Set placeholders for optional functions
  query_result_to_dataframe = None
  parse_datetime_columns = None
  _stream_to_dataframe = None
  dataframe_to_cypher_params = None
  export_query_to_csv = None
  compare_dataframes = None

__all__ = [
  # Core extension classes
  "RoboSystemsClients",
  "RoboSystemsClientConfig",
  "AsyncRoboSystemsClients",
  # SSE Client
  "SSEClient",
  "EventType",
  "SSEEvent",
  "SSEConfig",
  # Query Client
  "QueryClient",
  "QueryResult",
  "QueuedQueryResponse",
  "QueryRequest",
  "QueryOptions",
  "QueuedQueryError",
  # Agent Client
  "AgentClient",
  "AgentResult",
  "QueuedAgentResponse",
  "AgentQueryRequest",
  "AgentOptions",
  "QueuedAgentError",
  # Operation Client
  "OperationClient",
  "OperationStatus",
  "OperationProgress",
  "OperationResult",
  # File Client
  "FileClient",
  "FileUploadOptions",
  "FileUploadResult",
  "FileInfo",
  # Table Client
  "TableClient",
  "TableInfo",
  "TableQueryResult",
  # Graph Client
  "GraphClient",
  "GraphMetadata",
  "InitialEntityData",
  "GraphInfo",
  "MaterializationOptions",
  "MaterializationResult",
  # Ledger Client
  "LedgerClient",
  # Investor Client
  "InvestorClient",
  # Report Client
  # Utilities
  "QueryBuilder",
  "ResultProcessor",
  "CacheManager",
  "ProgressTracker",
  "DataBatcher",
  "QueryStats",
  "ConnectionInfo",
  "estimate_query_cost",
  "format_duration",
  "validate_cypher_query",
  # Authentication Integration
  "AuthenticatedClients",
  "CookieAuthClients",
  "TokenClients",
  "create_clients",
  "create_production_clients",
  "create_development_clients",
  # JWT Token utilities
  "validate_jwt_format",
  "extract_jwt_from_header",
  "decode_jwt_payload",
  "is_jwt_expired",
  "get_jwt_claims",
  "get_jwt_expiration",
  "extract_token_from_environment",
  "extract_token_from_cookie",
  "find_valid_token",
  "TokenManager",
  "TokenSource",
  # DataFrame utilities (optional)
  "HAS_PANDAS",
  "DataFrameQueryClient",
]

# Create a default clients instance
clients = RoboSystemsClients()


# Export convenience functions
def monitor_operation(operation_id: str, on_progress=None):
  """Monitor an operation using the default clients instance"""
  return clients.monitor_operation(operation_id, on_progress)


def execute_query(graph_id: str, query: str, parameters=None):
  """Execute a query using the default clients instance"""
  return clients.query.query(graph_id, query, parameters)


def stream_query(graph_id: str, query: str, parameters=None, chunk_size=None):
  """Stream a query using the default clients instance"""
  return clients.query.stream_query(graph_id, query, parameters, chunk_size)


def agent_query(graph_id: str, message: str, context=None):
  """Execute an agent query using the default clients instance"""
  return clients.agent.query(graph_id, message, context)


def analyze_financials(graph_id: str, message: str, on_progress=None):
  """Execute financial agent using the default clients instance"""
  return clients.agent.analyze_financials(graph_id, message, on_progress)


# DataFrame convenience functions (if pandas is available)
if (
  HAS_PANDAS
  and query_result_to_dataframe is not None
  and _stream_to_dataframe is not None
):

  def query_to_dataframe(graph_id: str, query: str, parameters=None, **kwargs):
    """Execute query and return results as pandas DataFrame"""
    assert query_result_to_dataframe is not None
    result = execute_query(graph_id, query, parameters)
    return query_result_to_dataframe(result, **kwargs)

  def stream_to_dataframe(graph_id: str, query: str, parameters=None, chunk_size=10000):
    """Stream query results and return as pandas DataFrame"""
    assert _stream_to_dataframe is not None
    stream = stream_query(graph_id, query, parameters, chunk_size)
    return _stream_to_dataframe(stream, chunk_size)
