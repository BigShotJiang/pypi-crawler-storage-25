"""Ledger Client for RoboSystems API.

High-level facade for everything the RoboLedger domain exposes: entity,
chart of accounts, transactions, taxonomy + mappings, fiscal calendar,
schedules, and period close.

**Transport split:**
- **Reads** go through GraphQL at `/extensions/{graph_id}/graphql`
  (via the local `GraphQLClient` wrapping httpx). The graph is in the
  URL, not in the query.
- **Writes** go through named command operations at
  `/extensions/roboledger/{graph_id}/operations/{operation_name}`
  (via the OpenAPI-generated `op_*` functions in
  `robosystems_client/api/extensions_robo_ledger/`). Each command
  returns an `OperationEnvelope`; the facade unwraps
  `envelope.result` and returns either a dict or, for async dispatches
  (e.g. auto-map, create-report), a small ack dict.

Reports, statements, and publish lists are included on this client —
same backend surface as the ledger operations.
"""

from __future__ import annotations

import datetime
from http import HTTPStatus
from typing import Any

from ..api.extensions_robo_ledger.op_auto_map_elements import (
  sync_detailed as op_auto_map_elements,
)
from ..api.extensions_robo_ledger.op_build_fact_grid import (
  sync_detailed as op_build_fact_grid,
)
from ..api.extensions_robo_ledger.op_close_period import (
  sync_detailed as op_close_period,
)
from ..api.extensions_robo_ledger.op_create_closing_entry import (
  sync_detailed as op_create_closing_entry,
)
from ..api.extensions_robo_ledger.op_create_manual_closing_entry import (
  sync_detailed as op_create_manual_closing_entry,
)
from ..api.extensions_robo_ledger.op_create_mapping_association import (
  sync_detailed as op_create_mapping_association,
)
from ..api.extensions_robo_ledger.op_create_schedule import (
  sync_detailed as op_create_schedule,
)
from ..api.extensions_robo_ledger.op_create_structure import (
  sync_detailed as op_create_structure,
)
from ..api.extensions_robo_ledger.op_create_taxonomy import (
  sync_detailed as op_create_taxonomy,
)
from ..api.extensions_robo_ledger.op_delete_mapping_association import (
  sync_detailed as op_delete_mapping_association,
)
from ..api.extensions_robo_ledger.op_initialize_ledger import (
  sync_detailed as op_initialize_ledger,
)
from ..api.extensions_robo_ledger.op_reopen_period import (
  sync_detailed as op_reopen_period,
)
from ..api.extensions_robo_ledger.op_set_close_target import (
  sync_detailed as op_set_close_target,
)
from ..api.extensions_robo_ledger.op_truncate_schedule import (
  sync_detailed as op_truncate_schedule,
)
from ..api.extensions_robo_ledger.op_update_association import (
  sync_detailed as op_update_association,
)
from ..api.extensions_robo_ledger.op_update_element import (
  sync_detailed as op_update_element,
)
from ..api.extensions_robo_ledger.op_update_entity import (
  sync_detailed as op_update_entity,
)
from ..api.extensions_robo_ledger.op_update_schedule import (
  sync_detailed as op_update_schedule,
)
from ..api.extensions_robo_ledger.op_update_structure import (
  sync_detailed as op_update_structure,
)
from ..api.extensions_robo_ledger.op_update_taxonomy import (
  sync_detailed as op_update_taxonomy,
)
from ..api.extensions_robo_ledger.op_add_publish_list_members import (
  sync_detailed as op_add_publish_list_members,
)
from ..api.extensions_robo_ledger.op_create_publish_list import (
  sync_detailed as op_create_publish_list,
)
from ..api.extensions_robo_ledger.op_create_report import (
  sync_detailed as op_create_report,
)
from ..api.extensions_robo_ledger.op_delete_publish_list import (
  sync_detailed as op_delete_publish_list,
)
from ..api.extensions_robo_ledger.op_delete_report import (
  sync_detailed as op_delete_report,
)
from ..api.extensions_robo_ledger.op_regenerate_report import (
  sync_detailed as op_regenerate_report,
)
from ..api.extensions_robo_ledger.op_remove_publish_list_member import (
  sync_detailed as op_remove_publish_list_member,
)
from ..api.extensions_robo_ledger.op_share_report import (
  sync_detailed as op_share_report,
)
from ..api.extensions_robo_ledger.op_update_publish_list import (
  sync_detailed as op_update_publish_list,
)
from ..api.extensions_robo_ledger.op_create_associations import (
  sync_detailed as op_create_associations,
)
from ..api.extensions_robo_ledger.op_create_element import (
  sync_detailed as op_create_element,
)
from ..api.extensions_robo_ledger.op_create_journal_entry import (
  sync_detailed as op_create_journal_entry,
)
from ..api.extensions_robo_ledger.op_link_entity_taxonomy import (
  sync_detailed as op_link_entity_taxonomy,
)
from ..api.extensions_robo_ledger.op_delete_association import (
  sync_detailed as op_delete_association,
)
from ..api.extensions_robo_ledger.op_delete_element import (
  sync_detailed as op_delete_element,
)
from ..api.extensions_robo_ledger.op_delete_journal_entry import (
  sync_detailed as op_delete_journal_entry,
)
from ..api.extensions_robo_ledger.op_delete_schedule import (
  sync_detailed as op_delete_schedule,
)
from ..api.extensions_robo_ledger.op_delete_structure import (
  sync_detailed as op_delete_structure,
)
from ..api.extensions_robo_ledger.op_delete_taxonomy import (
  sync_detailed as op_delete_taxonomy,
)
from ..api.extensions_robo_ledger.op_reverse_journal_entry import (
  sync_detailed as op_reverse_journal_entry,
)
from ..api.extensions_robo_ledger.op_update_journal_entry import (
  sync_detailed as op_update_journal_entry,
)
from ..client import AuthenticatedClient
from ..graphql.client import GraphQLClient, strip_none_vars
from ..graphql.queries.ledger import (
  GET_ACCOUNT_ROLLUPS_QUERY,
  GET_ACCOUNT_TREE_QUERY,
  GET_CLOSING_BOOK_STRUCTURES_QUERY,
  GET_ENTITY_QUERY,
  GET_FISCAL_CALENDAR_QUERY,
  GET_MAPPED_TRIAL_BALANCE_QUERY,
  GET_MAPPING_COVERAGE_QUERY,
  GET_MAPPING_QUERY,
  GET_PERIOD_CLOSE_STATUS_QUERY,
  GET_PERIOD_DRAFTS_QUERY,
  GET_REPORTING_TAXONOMY_QUERY,
  GET_SCHEDULE_FACTS_QUERY,
  GET_SUMMARY_QUERY,
  GET_TRANSACTION_QUERY,
  GET_TRIAL_BALANCE_QUERY,
  LIST_ACCOUNTS_QUERY,
  LIST_ELEMENTS_QUERY,
  LIST_ENTITIES_QUERY,
  LIST_MAPPINGS_QUERY,
  LIST_SCHEDULES_QUERY,
  LIST_STRUCTURES_QUERY,
  LIST_TAXONOMIES_QUERY,
  LIST_TRANSACTIONS_QUERY,
  LIST_UNMAPPED_ELEMENTS_QUERY,
  parse_account_rollups,
  parse_account_tree,
  parse_accounts,
  parse_closing_book_structures,
  parse_elements,
  parse_entities,
  parse_entity,
  parse_fiscal_calendar,
  parse_mapped_trial_balance,
  parse_mapping,
  parse_mapping_coverage,
  parse_mappings,
  parse_period_close_status,
  parse_period_drafts,
  parse_reporting_taxonomy,
  parse_schedule_facts,
  parse_schedules,
  parse_structures,
  parse_summary,
  parse_taxonomies,
  parse_transaction,
  parse_transactions,
  parse_trial_balance,
  parse_unmapped_elements,
)
from ..graphql.queries.ledger import (
  GET_PUBLISH_LIST_QUERY,
  GET_REPORT_QUERY,
  GET_STATEMENT_QUERY,
  LIST_PUBLISH_LISTS_QUERY,
  LIST_REPORTS_QUERY,
  parse_publish_list,
  parse_publish_lists,
  parse_report,
  parse_reports,
  parse_statement,
)
from ..models.add_publish_list_members_operation import AddPublishListMembersOperation
from ..models.auto_map_elements_operation import AutoMapElementsOperation
from ..models.bulk_association_item import BulkAssociationItem
from ..models.bulk_create_associations_request import BulkCreateAssociationsRequest
from ..models.create_element_request import CreateElementRequest
from ..models.create_journal_entry_request import CreateJournalEntryRequest
from ..models.delete_association_request import DeleteAssociationRequest
from ..models.delete_element_request import DeleteElementRequest
from ..models.delete_journal_entry_request import DeleteJournalEntryRequest
from ..models.delete_schedule_request import DeleteScheduleRequest
from ..models.delete_structure_request import DeleteStructureRequest
from ..models.delete_taxonomy_request import DeleteTaxonomyRequest
from ..models.link_entity_taxonomy_request import LinkEntityTaxonomyRequest
from ..models.reverse_journal_entry_request import ReverseJournalEntryRequest
from ..models.update_association_request import UpdateAssociationRequest
from ..models.update_element_request import UpdateElementRequest
from ..models.update_journal_entry_request import UpdateJournalEntryRequest
from ..models.update_schedule_request import UpdateScheduleRequest
from ..models.update_structure_request import UpdateStructureRequest
from ..models.update_taxonomy_request import UpdateTaxonomyRequest
from ..models.close_period_operation import ClosePeriodOperation
from ..models.create_closing_entry_operation import CreateClosingEntryOperation
from ..models.create_view_request import CreateViewRequest
from ..models.create_manual_closing_entry_request import CreateManualClosingEntryRequest
from ..models.create_manual_closing_entry_request_entry_type import (
  CreateManualClosingEntryRequestEntryType,
)
from ..models.create_mapping_association_operation import (
  CreateMappingAssociationOperation,
)
from ..models.create_schedule_request import CreateScheduleRequest
from ..models.create_structure_request import CreateStructureRequest
from ..models.create_structure_request_structure_type import (
  CreateStructureRequestStructureType,
)
from ..models.create_taxonomy_request import CreateTaxonomyRequest
from ..models.delete_mapping_association_operation import (
  DeleteMappingAssociationOperation,
)
from ..models.initialize_ledger_request import InitializeLedgerRequest
from ..models.manual_line_item_request import ManualLineItemRequest
from ..models.create_publish_list_request import CreatePublishListRequest
from ..models.create_report_request import CreateReportRequest
from ..models.delete_publish_list_operation import DeletePublishListOperation
from ..models.delete_report_operation import DeleteReportOperation
from ..models.operation_envelope import OperationEnvelope
from ..models.regenerate_report_operation import RegenerateReportOperation
from ..models.remove_publish_list_member_operation import (
  RemovePublishListMemberOperation,
)
from ..models.share_report_operation import ShareReportOperation
from ..models.update_publish_list_operation import UpdatePublishListOperation
from ..models.reopen_period_operation import ReopenPeriodOperation
from ..models.set_close_target_operation import SetCloseTargetOperation
from ..models.truncate_schedule_operation import TruncateScheduleOperation
from ..models.update_entity_request import UpdateEntityRequest
from ..types import UNSET


class LedgerClient:
  """High-level facade for the RoboLedger domain.

  Reads go through GraphQL at `/extensions/{graph_id}/graphql`;
  writes go through REST operation endpoints at
  `/extensions/roboledger/{graph_id}/operations/{operation_name}`.

  Every method takes `graph_id` as the first argument — the facade
  builds the per-graph GraphQL URL on each read, and passes it to the
  generated REST SDK on each write.
  """

  def __init__(self, config: dict[str, Any]):
    self.config = config
    self.base_url = config["base_url"]
    self.headers = config.get("headers", {})
    self.token = config.get("token")
    self.timeout = config.get("timeout", 60)

  def _get_client(self) -> AuthenticatedClient:
    if not self.token:
      raise RuntimeError("No API key provided. Set X-API-Key in headers.")
    return AuthenticatedClient(
      base_url=self.base_url,
      token=self.token,
      prefix="",
      auth_header_name="X-API-Key",
      headers=self.headers,
    )

  def _get_graphql_client(self) -> GraphQLClient:
    """Construct a fresh GraphQL client per call.

    Same shape as `_get_client()` — no long-lived connections; auth
    comes from the same config fields the REST path uses. `graph_id`
    is passed to `execute()`, not the constructor, because it shapes
    the URL.
    """
    if not self.token:
      raise RuntimeError("No API key provided. Set X-API-Key in headers.")
    return GraphQLClient(
      base_url=self.base_url,
      token=self.token,
      headers=self.headers,
      timeout=self.timeout,
    )

  # ── Helpers ─────────────────────────────────────────────────────────

  def _query(
    self,
    graph_id: str,
    query: str,
    variables: dict[str, Any] | None = None,
  ) -> dict[str, Any]:
    """Execute a read against the per-graph GraphQL endpoint.

    ``None`` values in ``variables`` are stripped before sending — the
    facade takes ``None`` to mean "not provided", and some Strawberry
    resolvers treat an explicit ``null`` differently from an unset arg.
    See ``strip_none_vars`` in ``graphql/client.py``.
    """
    cleaned = strip_none_vars(variables) if variables else None
    return self._get_graphql_client().execute(graph_id, query, cleaned)

  def _unwrap(self, label: str, envelope: OperationEnvelope | Any) -> Any:
    """Unwrap an operation envelope and return `result` (None on failure)."""
    if not isinstance(envelope, OperationEnvelope):
      raise RuntimeError(f"{label} failed: {envelope!r}")
    # envelope.result is untyped dict / list / None in the generated model
    return envelope.result

  def _call_op(self, label: str, response: Any) -> OperationEnvelope:
    """Common error handling for every generated op_* REST call."""
    if response.status_code not in (HTTPStatus.OK, HTTPStatus.ACCEPTED):
      raise RuntimeError(
        f"{label} failed: {response.status_code}: {response.content!r}"
      )
    envelope = response.parsed
    if not isinstance(envelope, OperationEnvelope):
      raise RuntimeError(f"{label} failed: unexpected response shape: {envelope!r}")
    # Normalize result to a plain dict — the generated SDK sometimes
    # wraps it in an OperationEnvelopeResultType0 attrs class instead
    # of a dict, depending on the response shape.
    if envelope.result is not None and hasattr(envelope.result, "to_dict"):
      envelope.result = envelope.result.to_dict()
    return envelope

  # ── Entity ──────────────────────────────────────────────────────────

  def get_entity(self, graph_id: str) -> dict[str, Any] | None:
    """Get the entity (company/organization) for this graph.

    Returns None when the ledger has no entity yet.
    """
    data = self._query(graph_id, GET_ENTITY_QUERY)
    return parse_entity(data)

  def list_entities(
    self, graph_id: str, source: str | None = None
  ) -> list[dict[str, Any]]:
    """List all entities for this graph, optionally filtered by source system."""
    data = self._query(graph_id, LIST_ENTITIES_QUERY, {"source": source})
    return parse_entities(data)

  def update_entity(self, graph_id: str, updates: dict[str, Any]) -> dict[str, Any]:
    """Update the entity for this graph. Only provided fields are applied."""
    body = UpdateEntityRequest.from_dict(updates)
    response = op_update_entity(graph_id=graph_id, body=body, client=self._get_client())
    envelope = self._call_op("Update entity", response)
    return envelope.result or {}

  # ── Summary ────────────────────────────────────────────────────────

  def get_summary(self, graph_id: str) -> dict[str, Any] | None:
    """Ledger rollup counts + QB sync metadata."""
    data = self._query(graph_id, GET_SUMMARY_QUERY)
    return parse_summary(data)

  # ── Accounts ────────────────────────────────────────────────────────

  def list_accounts(
    self,
    graph_id: str,
    classification: str | None = None,
    is_active: bool | None = None,
    limit: int = 100,
    offset: int = 0,
  ) -> dict[str, Any] | None:
    """List CoA accounts with optional filters and pagination."""
    data = self._query(
      graph_id,
      LIST_ACCOUNTS_QUERY,
      {
        "classification": classification,
        "isActive": is_active,
        "limit": limit,
        "offset": offset,
      },
    )
    return parse_accounts(data)

  def get_account_tree(self, graph_id: str) -> dict[str, Any] | None:
    """Hierarchical Chart of Accounts (up to 4 levels deep)."""
    data = self._query(graph_id, GET_ACCOUNT_TREE_QUERY)
    return parse_account_tree(data)

  def get_account_rollups(
    self,
    graph_id: str,
    mapping_id: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
  ) -> dict[str, Any] | None:
    """Accounts rolled up to reporting concepts via a mapping structure."""
    data = self._query(
      graph_id,
      GET_ACCOUNT_ROLLUPS_QUERY,
      {"mappingId": mapping_id, "startDate": start_date, "endDate": end_date},
    )
    return parse_account_rollups(data)

  # ── Transactions ────────────────────────────────────────────────────

  def list_transactions(
    self,
    graph_id: str,
    type: str | None = None,  # noqa: A002 — matches backend arg name
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int = 100,
    offset: int = 0,
  ) -> dict[str, Any] | None:
    """List transactions with optional type + date filters and pagination."""
    data = self._query(
      graph_id,
      LIST_TRANSACTIONS_QUERY,
      {
        "type": type,
        "startDate": start_date,
        "endDate": end_date,
        "limit": limit,
        "offset": offset,
      },
    )
    return parse_transactions(data)

  def get_transaction(
    self, graph_id: str, transaction_id: str
  ) -> dict[str, Any] | None:
    """Get transaction detail with entries + line items."""
    data = self._query(
      graph_id, GET_TRANSACTION_QUERY, {"transactionId": transaction_id}
    )
    return parse_transaction(data)

  # ── Trial balance ──────────────────────────────────────────────────

  def get_trial_balance(
    self,
    graph_id: str,
    start_date: str | None = None,
    end_date: str | None = None,
  ) -> dict[str, Any] | None:
    """Trial balance by raw CoA account."""
    data = self._query(
      graph_id,
      GET_TRIAL_BALANCE_QUERY,
      {"startDate": start_date, "endDate": end_date},
    )
    return parse_trial_balance(data)

  def get_mapped_trial_balance(
    self,
    graph_id: str,
    mapping_id: str,
    start_date: str | None = None,
    end_date: str | None = None,
  ) -> dict[str, Any] | None:
    """Trial balance rolled up to GAAP reporting concepts via a mapping."""
    data = self._query(
      graph_id,
      GET_MAPPED_TRIAL_BALANCE_QUERY,
      {"mappingId": mapping_id, "startDate": start_date, "endDate": end_date},
    )
    return parse_mapped_trial_balance(data)

  # ── Taxonomy ────────────────────────────────────────────────────────

  def get_reporting_taxonomy(self, graph_id: str) -> dict[str, Any] | None:
    """The locked US GAAP reporting taxonomy for this graph."""
    data = self._query(graph_id, GET_REPORTING_TAXONOMY_QUERY)
    return parse_reporting_taxonomy(data)

  def list_taxonomies(
    self, graph_id: str, taxonomy_type: str | None = None
  ) -> list[dict[str, Any]]:
    """List active taxonomies with optional type filter."""
    data = self._query(graph_id, LIST_TAXONOMIES_QUERY, {"taxonomyType": taxonomy_type})
    return parse_taxonomies(data)

  def create_taxonomy(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a new taxonomy (used for CoA + mapping taxonomies)."""
    request = CreateTaxonomyRequest.from_dict(body)
    response = op_create_taxonomy(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Create taxonomy", response)
    return envelope.result or {}

  def update_taxonomy(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update mutable fields on a taxonomy. taxonomy_type is immutable."""
    request = UpdateTaxonomyRequest.from_dict(body)
    response = op_update_taxonomy(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update taxonomy", response)
    return envelope.result or {}

  def delete_taxonomy(self, graph_id: str, taxonomy_id: str) -> dict[str, Any]:
    """Soft-delete a taxonomy (is_active=false)."""
    body = DeleteTaxonomyRequest(taxonomy_id=taxonomy_id)
    response = op_delete_taxonomy(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete taxonomy", response)
    return envelope.result or {}

  def link_entity_taxonomy(
    self,
    graph_id: str,
    taxonomy_id: str,
    basis: str = "chart_of_accounts",
    is_primary: bool = True,
    adoption_context: str | None = "voluntary",
  ) -> dict[str, Any]:
    """Link the graph's entity to a taxonomy (ENTITY_HAS_TAXONOMY edge).

    Idempotent — returns existing linkage if already present.
    """
    body = LinkEntityTaxonomyRequest.from_dict(
      {
        "taxonomy_id": taxonomy_id,
        "basis": basis,
        "is_primary": is_primary,
        "adoption_context": adoption_context,
      }
    )
    response = op_link_entity_taxonomy(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Link entity taxonomy", response)
    return envelope.result or {}

  def list_elements(
    self,
    graph_id: str,
    taxonomy_id: str | None = None,
    source: str | None = None,
    classification: str | None = None,
    is_abstract: bool | None = None,
    limit: int = 100,
    offset: int = 0,
  ) -> dict[str, Any] | None:
    """List elements (CoA accounts, GAAP concepts, etc.) with filters."""
    data = self._query(
      graph_id,
      LIST_ELEMENTS_QUERY,
      {
        "taxonomyId": taxonomy_id,
        "source": source,
        "classification": classification,
        "isAbstract": is_abstract,
        "limit": limit,
        "offset": offset,
      },
    )
    return parse_elements(data)

  def list_unmapped_elements(
    self, graph_id: str, mapping_id: str | None = None
  ) -> list[dict[str, Any]]:
    """CoA elements not yet mapped to a reporting concept."""
    data = self._query(
      graph_id, LIST_UNMAPPED_ELEMENTS_QUERY, {"mappingId": mapping_id}
    )
    return parse_unmapped_elements(data)

  def create_element(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a new element within a taxonomy (native CoA account, etc.)."""
    request = CreateElementRequest.from_dict(body)
    response = op_create_element(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Create element", response)
    return envelope.result or {}

  def update_element(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update mutable fields on an element. taxonomy_id and source are immutable."""
    request = UpdateElementRequest.from_dict(body)
    response = op_update_element(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update element", response)
    return envelope.result or {}

  def delete_element(self, graph_id: str, element_id: str) -> dict[str, Any]:
    """Soft-delete an element (is_active=false)."""
    body = DeleteElementRequest(element_id=element_id)
    response = op_delete_element(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete element", response)
    return envelope.result or {}

  # ── Structures / mappings ──────────────────────────────────────────

  def list_structures(
    self,
    graph_id: str,
    taxonomy_id: str | None = None,
    structure_type: str | None = None,
  ) -> list[dict[str, Any]]:
    """List reporting structures (IS, BS, CF, schedules) with optional filters."""
    data = self._query(
      graph_id,
      LIST_STRUCTURES_QUERY,
      {"taxonomyId": taxonomy_id, "structureType": structure_type},
    )
    return parse_structures(data)

  def create_structure(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a new structure (mapping, statement, schedule)."""
    request = CreateStructureRequest.from_dict(body)
    response = op_create_structure(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Create structure", response)
    return envelope.result or {}

  def update_structure(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update mutable fields on a structure. structure_type is immutable."""
    request = UpdateStructureRequest.from_dict(body)
    response = op_update_structure(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update structure", response)
    return envelope.result or {}

  def delete_structure(self, graph_id: str, structure_id: str) -> dict[str, Any]:
    """Soft-delete a structure (is_active=false)."""
    body = DeleteStructureRequest(structure_id=structure_id)
    response = op_delete_structure(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete structure", response)
    return envelope.result or {}

  def create_mapping_structure(
    self,
    graph_id: str,
    name: str = "CoA to Reporting",
    description: str | None = "Map Chart of Accounts to US GAAP reporting concepts",
    taxonomy_id: str = "tax_usgaap_reporting",
  ) -> dict[str, Any]:
    """Convenience wrapper — create a CoA→GAAP mapping structure."""
    body = CreateStructureRequest(
      name=name,
      structure_type=CreateStructureRequestStructureType.COA_MAPPING,
      taxonomy_id=taxonomy_id,
      description=description if description is not None else UNSET,
    )
    response = op_create_structure(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create mapping structure", response)
    return envelope.result or {}

  def list_mappings(self, graph_id: str) -> list[dict[str, Any]]:
    """List active CoA→reporting mapping structures."""
    data = self._query(graph_id, LIST_MAPPINGS_QUERY)
    return parse_mappings(data)

  def get_mapping(self, graph_id: str, mapping_id: str) -> dict[str, Any] | None:
    """Get a mapping structure with all its associations."""
    data = self._query(graph_id, GET_MAPPING_QUERY, {"mappingId": mapping_id})
    return parse_mapping(data)

  def get_mapping_coverage(
    self, graph_id: str, mapping_id: str
  ) -> dict[str, Any] | None:
    """Mapping coverage stats — how many CoA elements are mapped."""
    data = self._query(graph_id, GET_MAPPING_COVERAGE_QUERY, {"mappingId": mapping_id})
    return parse_mapping_coverage(data)

  def create_mapping_association(
    self,
    graph_id: str,
    mapping_id: str,
    from_element_id: str,
    to_element_id: str,
    confidence: float = 1.0,
  ) -> dict[str, Any]:
    """Create a manual mapping association between two elements."""
    body = CreateMappingAssociationOperation(
      mapping_id=mapping_id,
      from_element_id=from_element_id,
      to_element_id=to_element_id,
      confidence=confidence,
    )
    response = op_create_mapping_association(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create mapping association", response)
    return envelope.result or {}

  def delete_mapping_association(
    self, graph_id: str, mapping_id: str, association_id: str
  ) -> dict[str, Any]:
    """Delete a mapping association."""
    body = DeleteMappingAssociationOperation(
      mapping_id=mapping_id, association_id=association_id
    )
    response = op_delete_mapping_association(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete mapping association", response)
    return envelope.result if envelope.result is not None else {"deleted": True}

  def auto_map_elements(self, graph_id: str, mapping_id: str) -> dict[str, Any]:
    """Trigger the AI MappingAgent (async). Returns an operation ack."""
    body = AutoMapElementsOperation(mapping_id=mapping_id)
    response = op_auto_map_elements(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Auto-map elements", response)
    return {"operation_id": envelope.operation_id, "status": envelope.status}

  def create_associations(
    self,
    graph_id: str,
    structure_id: str,
    associations: list[dict[str, Any]],
  ) -> dict[str, Any]:
    """Bulk create associations within a single structure, atomically."""
    items = [BulkAssociationItem.from_dict(a) for a in associations]
    body = BulkCreateAssociationsRequest(structure_id=structure_id, associations=items)
    response = op_create_associations(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create associations", response)
    return envelope.result or {}

  def update_association(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update mutable fields on an association (order, weight, confidence)."""
    request = UpdateAssociationRequest.from_dict(body)
    response = op_update_association(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update association", response)
    return envelope.result or {}

  def delete_association(self, graph_id: str, association_id: str) -> dict[str, Any]:
    """Hard-delete an association (any type: presentation, calculation, mapping)."""
    body = DeleteAssociationRequest(association_id=association_id)
    response = op_delete_association(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete association", response)
    return envelope.result if envelope.result is not None else {"deleted": True}

  # ── Schedules ──────────────────────────────────────────────────────

  def list_schedules(self, graph_id: str) -> list[dict[str, Any]]:
    """List all schedule structures with metadata."""
    data = self._query(graph_id, LIST_SCHEDULES_QUERY)
    return parse_schedules(data)

  def get_schedule_facts(
    self,
    graph_id: str,
    structure_id: str,
    period_start: str | None = None,
    period_end: str | None = None,
  ) -> list[dict[str, Any]]:
    """Schedule facts optionally filtered by period window."""
    data = self._query(
      graph_id,
      GET_SCHEDULE_FACTS_QUERY,
      {
        "structureId": structure_id,
        "periodStart": period_start,
        "periodEnd": period_end,
      },
    )
    parsed = parse_schedule_facts(data)
    if parsed is None:
      return []
    return parsed.get("facts", [])

  def create_schedule(
    self,
    graph_id: str,
    *,
    name: str,
    element_ids: list[str],
    period_start: str,
    period_end: str,
    monthly_amount: int,
    debit_element_id: str,
    credit_element_id: str,
    entry_type: str = "closing",
    memo_template: str = "",
    taxonomy_id: str | None = None,
    method: str | None = None,
    original_amount: int | None = None,
    residual_value: int | None = None,
    useful_life_months: int | None = None,
    asset_element_id: str | None = None,
    auto_reverse: bool = False,
  ) -> dict[str, Any]:
    """Create a new schedule with pre-generated monthly facts."""
    body_dict: dict[str, Any] = {
      "name": name,
      "element_ids": element_ids,
      "period_start": period_start,
      "period_end": period_end,
      "monthly_amount": monthly_amount,
      "entry_template": {
        "debit_element_id": debit_element_id,
        "credit_element_id": credit_element_id,
        "entry_type": entry_type,
        "memo_template": memo_template,
        "auto_reverse": auto_reverse,
      },
    }
    if taxonomy_id:
      body_dict["taxonomy_id"] = taxonomy_id
    schedule_metadata: dict[str, Any] = {}
    if method:
      schedule_metadata["method"] = method
    if original_amount is not None:
      schedule_metadata["original_amount"] = original_amount
    if residual_value is not None:
      schedule_metadata["residual_value"] = residual_value
    if useful_life_months is not None:
      schedule_metadata["useful_life_months"] = useful_life_months
    if asset_element_id:
      schedule_metadata["asset_element_id"] = asset_element_id
    if schedule_metadata:
      body_dict["schedule_metadata"] = schedule_metadata

    body = CreateScheduleRequest.from_dict(body_dict)
    response = op_create_schedule(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create schedule", response)
    return envelope.result or {}

  def truncate_schedule(
    self,
    graph_id: str,
    structure_id: str,
    new_end_date: str,
    reason: str,
  ) -> dict[str, Any]:
    """Truncate a schedule — end it early at `new_end_date`."""
    body = TruncateScheduleOperation(
      structure_id=structure_id,
      new_end_date=datetime.date.fromisoformat(new_end_date),
      reason=reason,
    )
    response = op_truncate_schedule(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Truncate schedule", response)
    return envelope.result or {}

  def update_schedule(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update mutable fields on a schedule (name, entry_template, metadata)."""
    request = UpdateScheduleRequest.from_dict(body)
    response = op_update_schedule(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update schedule", response)
    return envelope.result or {}

  def delete_schedule(self, graph_id: str, structure_id: str) -> dict[str, Any]:
    """Permanently delete a schedule (cascades through facts + associations)."""
    body = DeleteScheduleRequest(structure_id=structure_id)
    response = op_delete_schedule(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete schedule", response)
    return envelope.result if envelope.result is not None else {"deleted": True}

  # ── Period close ────────────────────────────────────────────────────

  def get_period_close_status(
    self,
    graph_id: str,
    period_start: str,
    period_end: str,
  ) -> dict[str, Any] | None:
    """Close status for all schedules in a fiscal period."""
    data = self._query(
      graph_id,
      GET_PERIOD_CLOSE_STATUS_QUERY,
      {"periodStart": period_start, "periodEnd": period_end},
    )
    return parse_period_close_status(data)

  def list_period_drafts(self, graph_id: str, period: str) -> dict[str, Any] | None:
    """All draft entries in a period, fully expanded for review pre-close."""
    data = self._query(graph_id, GET_PERIOD_DRAFTS_QUERY, {"period": period})
    return parse_period_drafts(data)

  def create_closing_entry(
    self,
    graph_id: str,
    structure_id: str,
    posting_date: str,
    period_start: str,
    period_end: str,
    memo: str | None = None,
  ) -> dict[str, Any]:
    """Idempotently create (or refresh) a draft closing entry from a schedule."""
    body = CreateClosingEntryOperation(
      structure_id=structure_id,
      posting_date=datetime.date.fromisoformat(posting_date),
      period_start=datetime.date.fromisoformat(period_start),
      period_end=datetime.date.fromisoformat(period_end),
      memo=memo if memo is not None else UNSET,
    )
    response = op_create_closing_entry(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create closing entry", response)
    return envelope.result or {}

  def create_manual_closing_entry(
    self,
    graph_id: str,
    *,
    posting_date: str,
    memo: str,
    line_items: list[dict[str, Any]],
    entry_type: str | None = None,
  ) -> dict[str, Any]:
    """Create a manual balanced closing entry (not tied to a schedule)."""
    items = [
      ManualLineItemRequest(
        element_id=li["element_id"],
        debit_amount=li.get("debit_amount", 0),
        credit_amount=li.get("credit_amount", 0),
        description=(
          li.get("description") if li.get("description") is not None else UNSET
        ),
      )
      for li in line_items
    ]
    body = CreateManualClosingEntryRequest(
      posting_date=datetime.date.fromisoformat(posting_date),
      memo=memo,
      line_items=items,
      entry_type=(
        CreateManualClosingEntryRequestEntryType(entry_type)
        if entry_type is not None
        else UNSET
      ),
    )
    response = op_create_manual_closing_entry(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create manual closing entry", response)
    return envelope.result or {}

  # ── Journal entries (native accounting writes) ──────────────────────

  def create_journal_entry(
    self,
    graph_id: str,
    *,
    posting_date: str,
    memo: str,
    line_items: list[dict[str, Any]],
    type: str = "standard",  # noqa: A002
    status: str = "draft",
    transaction_id: str | None = None,
    idempotency_key: str | None = None,
  ) -> dict[str, Any]:
    """Create a journal entry with balanced line items (DR=CR enforced).

    Defaults to ``status='draft'`` for ongoing writes. Pass
    ``status='posted'`` for historical data import where entries
    represent already-happened business events.

    Supply ``idempotency_key`` to make the call safe to retry — replays
    within 24 hours return the same envelope. Reusing the key with a
    different body returns HTTP 409.
    """
    body_dict: dict[str, Any] = {
      "posting_date": posting_date,
      "memo": memo,
      "line_items": line_items,
      "type": type,
      "status": status,
    }
    if transaction_id is not None:
      body_dict["transaction_id"] = transaction_id
    body = CreateJournalEntryRequest.from_dict(body_dict)
    response = op_create_journal_entry(
      graph_id=graph_id,
      body=body,
      client=self._get_client(),
      idempotency_key=idempotency_key,
    )
    envelope = self._call_op("Create journal entry", response)
    return envelope.result or {}

  def update_journal_entry(self, graph_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Update a draft journal entry. Posted entries are immutable."""
    request = UpdateJournalEntryRequest.from_dict(body)
    response = op_update_journal_entry(
      graph_id=graph_id, body=request, client=self._get_client()
    )
    envelope = self._call_op("Update journal entry", response)
    return envelope.result or {}

  def delete_journal_entry(self, graph_id: str, entry_id: str) -> dict[str, Any]:
    """Hard-delete a draft journal entry. Posted entries must be reversed."""
    body = DeleteJournalEntryRequest(entry_id=entry_id)
    response = op_delete_journal_entry(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Delete journal entry", response)
    return envelope.result if envelope.result is not None else {"deleted": True}

  def reverse_journal_entry(
    self,
    graph_id: str,
    entry_id: str,
    posting_date: str | None = None,
    memo: str | None = None,
  ) -> dict[str, Any]:
    """Reverse a posted journal entry (creates offsetting entry, marks original as reversed)."""
    body = ReverseJournalEntryRequest(
      entry_id=entry_id,
      posting_date=(
        datetime.date.fromisoformat(posting_date) if posting_date else UNSET
      ),
      memo=memo if memo is not None else UNSET,
    )
    response = op_reverse_journal_entry(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Reverse journal entry", response)
    return envelope.result or {}

  # ── Fact grid (graph-backed analytical query) ─────────────────────

  def build_fact_grid(self, graph_id: str, request: dict[str, Any]) -> dict[str, Any]:
    """Build a multi-dimensional fact grid against the graph schema.

    This is a graph-database *read* dispatched through the operation
    surface — it runs against LadybugDB (not the extensions OLTP
    database) and returns a deduplicated pivot table of XBRL facts.
    The same operation works for roboledger tenant graphs (after
    materialization) and for the SEC shared repository, which uses the
    same hypercube schema.

    ``request`` accepts any fields of
    ``robosystems_client.models.create_view_request.CreateViewRequest``:
    ``elements`` (qnames), ``canonical_concepts``, ``periods``,
    ``entities``, ``form``, ``fiscal_year``, ``fiscal_period``,
    ``period_type``, ``include_summary``, ``view_config``. The legacy
    model name ``CreateViewRequest`` is a holdover from when fact grids
    were exposed under a ``/views`` route; the shape is unchanged.
    """
    body = CreateViewRequest.from_dict(request)
    response = op_build_fact_grid(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Build fact grid", response)
    return envelope.result or {}

  # ── Closing book ───────────────────────────────────────────────────

  def get_closing_book_structures(self, graph_id: str) -> dict[str, Any] | None:
    """Grouped closing book structures for the close-screen sidebar."""
    data = self._query(graph_id, GET_CLOSING_BOOK_STRUCTURES_QUERY)
    return parse_closing_book_structures(data)

  # ── Fiscal Calendar ────────────────────────────────────────────────

  def get_fiscal_calendar(self, graph_id: str) -> dict[str, Any] | None:
    """Current fiscal calendar state — pointers, gap, closeable status."""
    data = self._query(graph_id, GET_FISCAL_CALENDAR_QUERY)
    return parse_fiscal_calendar(data)

  def initialize_ledger(
    self,
    graph_id: str,
    *,
    closed_through: str | None = None,
    fiscal_year_start_month: int | None = None,
    earliest_data_period: str | None = None,
    auto_seed_schedules: bool | None = None,
    note: str | None = None,
  ) -> dict[str, Any]:
    """One-time ledger initialization — seed fiscal calendar + periods."""
    body = InitializeLedgerRequest(
      closed_through=closed_through if closed_through is not None else UNSET,
      fiscal_year_start_month=(
        fiscal_year_start_month if fiscal_year_start_month is not None else UNSET
      ),
      earliest_data_period=(
        earliest_data_period if earliest_data_period is not None else UNSET
      ),
      auto_seed_schedules=(
        auto_seed_schedules if auto_seed_schedules is not None else UNSET
      ),
      note=note if note is not None else UNSET,
    )
    response = op_initialize_ledger(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Initialize ledger", response)
    return envelope.result or {}

  def set_close_target(
    self,
    graph_id: str,
    period: str,
    note: str | None = None,
  ) -> dict[str, Any]:
    """Set the user-controlled close target (YYYY-MM)."""
    body = SetCloseTargetOperation(
      period=period,
      note=note if note is not None else UNSET,
    )
    response = op_set_close_target(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Set close target", response)
    return envelope.result or {}

  def close_period(
    self,
    graph_id: str,
    period: str,
    note: str | None = None,
    allow_stale_sync: bool | None = None,
  ) -> dict[str, Any]:
    """Close a fiscal period — the final commit action."""
    body = ClosePeriodOperation(
      period=period,
      note=note if note is not None else UNSET,
      allow_stale_sync=(allow_stale_sync if allow_stale_sync is not None else UNSET),
    )
    response = op_close_period(graph_id=graph_id, body=body, client=self._get_client())
    envelope = self._call_op("Close period", response)
    return envelope.result or {}

  def reopen_period(
    self,
    graph_id: str,
    period: str,
    reason: str,
    note: str | None = None,
  ) -> dict[str, Any]:
    """Reopen a closed fiscal period. Requires a reason for the audit log."""
    body = ReopenPeriodOperation(
      period=period,
      reason=reason,
      note=note if note is not None else UNSET,
    )
    response = op_reopen_period(graph_id=graph_id, body=body, client=self._get_client())
    envelope = self._call_op("Reopen period", response)
    return envelope.result or {}

  # ── Reports ─────────────────────────────────────────────────────────

  def create_report(
    self,
    graph_id: str,
    name: str,
    mapping_id: str,
    period_start: str,
    period_end: str,
    taxonomy_id: str = "tax_usgaap_reporting",
    period_type: str = "quarterly",
    comparative: bool = True,
  ) -> dict[str, Any]:
    """Kick off report creation (async). Returns an operation ack."""
    body = CreateReportRequest(
      name=name,
      mapping_id=mapping_id,
      period_start=period_start,
      period_end=period_end,
      taxonomy_id=taxonomy_id,
      period_type=period_type,
      comparative=comparative,
    )
    response = op_create_report(graph_id=graph_id, body=body, client=self._get_client())
    envelope = self._call_op("Create report", response)
    return {"operation_id": envelope.operation_id, "status": envelope.status}

  def list_reports(self, graph_id: str) -> list[dict[str, Any]]:
    """List all reports for a graph (includes received shared reports)."""
    data = self._query(graph_id, LIST_REPORTS_QUERY)
    return parse_reports(data)

  def get_report(self, graph_id: str, report_id: str) -> dict[str, Any] | None:
    """Get a single report with its period list + available structures."""
    data = self._query(graph_id, GET_REPORT_QUERY, {"reportId": report_id})
    return parse_report(data)

  def get_statement(
    self, graph_id: str, report_id: str, structure_type: str
  ) -> dict[str, Any] | None:
    """Render a financial statement — facts viewed through a structure.

    `structure_type`: income_statement, balance_sheet, cash_flow_statement, ...
    """
    data = self._query(
      graph_id,
      GET_STATEMENT_QUERY,
      {"reportId": report_id, "structureType": structure_type},
    )
    return parse_statement(data)

  def regenerate_report(
    self,
    graph_id: str,
    report_id: str,
    period_start: str | None = None,
    period_end: str | None = None,
  ) -> dict[str, Any]:
    """Regenerate an existing report (async). Returns an operation ack."""
    body = RegenerateReportOperation(
      report_id=report_id,
      period_start=period_start if period_start is not None else UNSET,
      period_end=period_end if period_end is not None else UNSET,
    )
    response = op_regenerate_report(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Regenerate report", response)
    return {"operation_id": envelope.operation_id, "status": envelope.status}

  def delete_report(self, graph_id: str, report_id: str) -> None:
    """Delete a report and its generated facts."""
    body = DeleteReportOperation(report_id=report_id)
    response = op_delete_report(graph_id=graph_id, body=body, client=self._get_client())
    self._call_op("Delete report", response)

  def share_report(
    self, graph_id: str, report_id: str, publish_list_id: str
  ) -> dict[str, Any]:
    """Share a published report to every member of a publish list (async)."""
    body = ShareReportOperation(report_id=report_id, publish_list_id=publish_list_id)
    response = op_share_report(graph_id=graph_id, body=body, client=self._get_client())
    envelope = self._call_op("Share report", response)
    return {"operation_id": envelope.operation_id, "status": envelope.status}

  def is_shared_report(self, report: dict[str, Any] | Any) -> bool:
    """Check if a report was received via sharing (vs locally created)."""
    if isinstance(report, dict):
      return report.get("source_graph_id") is not None
    return getattr(report, "source_graph_id", None) is not None

  # ── Publish Lists ────────────────────────────────────────────────────

  def list_publish_lists(
    self, graph_id: str, limit: int = 100, offset: int = 0
  ) -> dict[str, Any] | None:
    """List publish lists with pagination."""
    data = self._query(
      graph_id, LIST_PUBLISH_LISTS_QUERY, {"limit": limit, "offset": offset}
    )
    return parse_publish_lists(data)

  def get_publish_list(self, graph_id: str, list_id: str) -> dict[str, Any] | None:
    """Get a single publish list with its full member list."""
    data = self._query(graph_id, GET_PUBLISH_LIST_QUERY, {"listId": list_id})
    return parse_publish_list(data)

  def create_publish_list(
    self, graph_id: str, name: str, description: str | None = None
  ) -> dict[str, Any]:
    """Create a new publish list."""
    body = CreatePublishListRequest(
      name=name,
      description=description if description is not None else UNSET,
    )
    response = op_create_publish_list(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Create publish list", response)
    return envelope.result or {}

  def update_publish_list(
    self,
    graph_id: str,
    list_id: str,
    name: str | None = None,
    description: str | None = None,
  ) -> dict[str, Any]:
    """Update a publish list's name or description."""
    body = UpdatePublishListOperation(
      list_id=list_id,
      name=name if name is not None else UNSET,
      description=description if description is not None else UNSET,
    )
    response = op_update_publish_list(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Update publish list", response)
    return envelope.result or {}

  def delete_publish_list(self, graph_id: str, list_id: str) -> None:
    """Delete a publish list."""
    body = DeletePublishListOperation(list_id=list_id)
    response = op_delete_publish_list(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    self._call_op("Delete publish list", response)

  def add_publish_list_members(
    self, graph_id: str, list_id: str, target_graph_ids: list[str]
  ) -> dict[str, Any]:
    """Add target graphs as members of a publish list."""
    body = AddPublishListMembersOperation(
      list_id=list_id, target_graph_ids=target_graph_ids
    )
    response = op_add_publish_list_members(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Add publish list members", response)
    return envelope.result or {}

  def remove_publish_list_member(
    self, graph_id: str, list_id: str, member_id: str
  ) -> dict[str, Any]:
    """Remove a single member from a publish list."""
    body = RemovePublishListMemberOperation(list_id=list_id, member_id=member_id)
    response = op_remove_publish_list_member(
      graph_id=graph_id, body=body, client=self._get_client()
    )
    envelope = self._call_op("Remove publish list member", response)
    return envelope.result if envelope.result is not None else {"deleted": True}
