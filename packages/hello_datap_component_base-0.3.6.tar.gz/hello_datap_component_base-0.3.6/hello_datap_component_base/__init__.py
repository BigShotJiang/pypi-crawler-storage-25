"""
数据处理平台组件基类 - 统一的服务管理框架

提供标准化的数据处理组件开发框架，统一用户代码的入参和出参以及程序执行入口。
"""

# 检查 MNS SDK 冲突：aliyun-mns（旧）和 aliyun-mns-sdk（新）共用 mns 命名空间，
# 同时安装时旧包会覆盖新包，导致 FIFO 队列等功能不可用
def _check_mns_conflict():
    try:
        import importlib.metadata as metadata
    except ImportError:
        return
    installed = {d.metadata["Name"].lower() for d in metadata.distributions()}
    if "aliyun-mns" in installed and "aliyun-mns-sdk" in installed:
        import warnings
        warnings.warn(
            "检测到同时安装了 aliyun-mns 和 aliyun-mns-sdk，两者共用 mns 命名空间会冲突。"
            "请卸载旧版: pip uninstall aliyun-mns",
            stacklevel=2,
        )

_check_mns_conflict()
del _check_mns_conflict

from .base import BaseService, ServiceConfig
from .runner import ServiceRunner
from .config import ServerConfig, RuntimeEnv
from .logger import setup_logging, get_service_logger
from .discover import find_service_classes, get_single_service_class

# 导入 logger 实例
from .logger import logger

# 导入数据跟踪模块
from . import track

# 导入工具模块
from . import tools

__version__ = "0.3.6"
__author__ = "Data Processing Team"

__all__ = [
    "BaseService",
    "ServiceConfig",
    "ServerConfig",
    "RuntimeEnv",
    "ServiceRunner",
    "setup_logging",
    "get_service_logger",
    "logger",
    "track",
    "tools",
    "find_service_classes",
    "get_single_service_class",
]