"""
工具函数模块

提供环境变量提取、bag 路径解析等通用工具方法。

使用方法：
    from hello_datap_component_base import tools

    env_vars = tools.extract_specific_env_vars()
    vehicle_id = tools.get_vehicle_id_from_bag("oss://bucket/.../1_002_20260119-151708_0.db3")
    date = tools.get_date_from_bag("oss://bucket/.../1_002_20260119-151708_0.db3")
    package = tools.get_package_name_from_bag("oss://bucket/.../1_002_20260119-151708/1_002_20260119-151708_0.db3")
"""

import os
import re
import base64
import logging
from pathlib import Path, PurePosixPath
from typing import Dict, Optional

import requests
import yaml

logger = logging.getLogger(__name__)

# AES 解密密钥的环境变量名
AES_KEY_ENV_VAR = "ENV_AES_KEY"


def _try_aes_decrypt(value: str, aes_key: bytes) -> Optional[str]:
    """
    尝试用 AES-CBC 解密 base64 编码的密文。

    密文格式：base64(IV + ciphertext)，其中 IV 为前 16 字节，PKCS7 填充。

    Args:
        value: base64 编码的密文字符串
        aes_key: AES 密钥（16/24/32 字节）

    Returns:
        解密后的明文字符串，解密失败返回 None
    """
    try:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import unpad

        raw = base64.b64decode(value)
        if len(raw) < 17:  # 至少 16 字节 IV + 1 字节密文
            return None

        iv = raw[:16]
        ciphertext = raw[16:]
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        plaintext = unpad(cipher.decrypt(ciphertext), AES.block_size)
        return plaintext.decode("utf-8")
    except Exception:
        return None


def decrypt_env_value(value: str) -> str:
    """
    智能解密环境变量值。

    逻辑：
    1. 如果未配置 ENV_AES_KEY，直接返回原值（认为是明文）。
    2. 如果配置了 ENV_AES_KEY，尝试 AES-CBC 解密：
       - 解密成功 → 返回明文
       - 解密失败 → 返回原值（认为本身就是明文）

    Args:
        value: 环境变量原始值

    Returns:
        解密后的值或原值
    """
    if not value:
        return value

    aes_key_str = os.environ.get(AES_KEY_ENV_VAR, "")
    if not aes_key_str:
        return value

    # 支持 base64 编码的密钥和原始字符串密钥
    try:
        aes_key = base64.b64decode(aes_key_str)
        if len(aes_key) not in (16, 24, 32):
            # 不是合法的 base64 密钥，当作 UTF-8 字符串
            aes_key = aes_key_str.encode("utf-8")
    except Exception:
        aes_key = aes_key_str.encode("utf-8")

    if len(aes_key) not in (16, 24, 32):
        logger.warning(
            f"{AES_KEY_ENV_VAR} 长度不合法（需要 16/24/32 字节，当前 {len(aes_key)} 字节），"
            "跳过解密，直接使用原值"
        )
        return value

    decrypted = _try_aes_decrypt(value, aes_key)
    if decrypted is not None:
        logger.debug("环境变量值已成功解密")
        return decrypted

    # 解密失败，认为是明文
    return value


def extract_specific_env_vars() -> Dict[str, str]:
    """
    从 os.environ 中提取框架相关的环境变量

    Returns:
        包含指定环境变量的字典
    """
    env_vars = {}

    # MNS 相关配置
    env_vars["MNS_ENDPOINT"] = os.environ.get("MNS_ENDPOINT", "")
    env_vars["MNS_ACCESS_KEY_ID"] = os.environ.get("MNS_ACCESS_KEY_ID", "")
    env_vars["MNS_ACCESS_KEY_SECRET"] = os.environ.get("MNS_ACCESS_KEY_SECRET", "")
    env_vars["MNS_QUEUE_NAME"] = os.environ.get("MNS_QUEUE_NAME", "")

    # OSS 日志配置
    oss_endpoint = os.environ.get("OSS_ENDPOINT_FOR_LOG", "")
    if not oss_endpoint and (oss_endpoint_raw := os.environ.get("OSS_ENDPOINT")):
        oss_endpoint = f"https://{oss_endpoint_raw}"
    env_vars["OSS_ENDPOINT_FOR_LOG"] = oss_endpoint

    env_vars["OSS_BUCKET_NAME_FOR_LOG"] = os.environ.get("OSS_BUCKET_NAME_FOR_LOG", "")
    env_vars["OSS_LOG_PATH_PREFIX"] = os.environ.get("OSS_LOG_PATH_PREFIX", "")
    env_vars["RESULT_OSS_BUCKET"] = os.environ.get("RESULT_OSS_BUCKET", "").strip() or "infra-hads-artifacts"

    oss_access_key_id = os.environ.get("OSS_ACCESS_KEY_ID_FOR_LOG")
    oss_access_key_secret = os.environ.get("OSS_ACCESS_KEY_SECRET_FOR_LOG")
    if oss_access_key_id and oss_access_key_id.strip():
        env_vars["OSS_ACCESS_KEY_ID_FOR_LOG"] = oss_access_key_id.strip()
    if oss_access_key_secret and oss_access_key_secret.strip():
        env_vars["OSS_ACCESS_KEY_SECRET_FOR_LOG"] = oss_access_key_secret.strip()

    # 数据跟踪环境变量
    env_vars["DATA_TRACK_MNS_QUEUE_NAME"] = os.environ.get("DATA_TRACK_MNS_QUEUE_NAME", "")
    env_vars["DATA_TRACK_PIPELINE_ID"] = os.environ.get("DATA_TRACK_PIPELINE_ID", "")
    env_vars["DATA_TRACK_PIPELINE_INSTANCE_ID"] = os.environ.get("DATA_TRACK_PIPELINE_INSTANCE_ID", "")
    env_vars["DATA_TRACK_COMPONENT_VERSION"] = os.environ.get("DATA_TRACK_COMPONENT_VERSION", "")
    env_vars["DATA_TRACK_PRIORITY"] = os.environ.get("DATA_TRACK_PRIORITY", "")
    env_vars["DATA_TRACK_EXECUTOR"] = os.environ.get("DATA_TRACK_EXECUTOR", "")
    env_vars["DATA_TRACK_RUN_TYPE"] = os.environ.get("DATA_TRACK_RUN_TYPE", "")
    env_vars["DATA_TRACK_NODE_ID"] = os.environ.get("DATA_TRACK_NODE_ID", "")
    env_vars["DATA_TRACK_NODE_TASK_ID"] = os.environ.get("DATA_TRACK_NODE_TASK_ID", "")

    # 数据平台接口
    env_vars["BAG_DATA_APP_KEY"] = os.environ.get("BAG_DATA_APP_KEY", "")
    env_vars["BAG_DATA_API_URL"] = os.environ.get("BAG_DATA_API_URL", "")
    env_vars["DATA_PROCESS_API_URL"] = os.environ.get("DATA_PROCESS_API_URL", "")

    return env_vars

def load_yaml_from_url(url, timeout=10):
    """
    从URL直接加载YAML到内存，不保存本地文件
    :return: 解析后的Python字典
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    try:
        # 1. 获取YAML内容（仅在内存中）
        response = requests.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()
        response.encoding = "utf-8"

        # 2. 直接在内存解析YAML，不写入磁盘
        yaml_data = yaml.safe_load(response.text)

        logger.info("✅ 成功：YAML已加载到内存并解析")
        return yaml_data

    except Exception as e:
        logger.error(f"❌ 失败：{str(e)}")
        return None


def load_json_from_url(url, timeout=10):
    """
    从URL直接加载JSON到内存，不保存本地
    :return: 解析后的Python字典/列表
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    try:
        # 发送请求
        response = requests.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()

        # 直接在内存解析成JSON（字典/列表）
        json_data = response.json()

        return json_data

    except Exception as e:
        logger.error(f"加载失败: {e}")
        return None


def get_vehicle_id_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取 vehicle_id

    支持的路径格式：
    - oss://bucket/path/1_002/1_002_20260119-151708/1_002_20260119-151708_0.db3
    - s3://bucket/path/1_002/1_002_20260119-151708/1_002_20260119-151708_0.db3
    - /local/path/1_002_20260119-151708_0.db3

    提取规则：
    1. 从文件名提取：1_002_20260119-151708_0.db3 -> 1_002
    2. 文件名格式：{vehicle_id}_{date}-{time}_{index}.db3

    Returns:
        vehicle_id 字符串，如 "1_002"，提取失败返回空字符串
    """
    try:
        filename = Path(bag_path).stem

        # 匹配 vehicle_id：数字_数字（如 1_002, 1_022）
        match = re.match(r'^(\d+_\d+)_', filename)
        if match:
            return match.group(1)

        # 回退：从路径目录中查找独立的 vehicle_id 段
        parts = bag_path.replace("\\", "/").split("/")
        for part in parts:
            if re.match(r'^\d+_\d+$', part):
                return part

        return ""
    except Exception as e:
        logger.error(f"提取 vehicle_id 失败: {bag_path}, 错误: {e}")
        return ""


def get_date_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取日期（YYYYMMDD）

    文件名格式：1_002_20251219-164135_0.db3 -> 20251219

    Returns:
        日期字符串 "YYYYMMDD"，提取失败返回空字符串
    """
    try:
        stem = Path(bag_path).stem
        match = re.match(r"^\d+_\d+_(\d{8})", stem)
        if match:
            return match.group(1)
        return ""
    except Exception as e:
        logger.error(f"提取日期失败: {bag_path}, 错误: {e}")
        return ""


def get_package_name_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取 package 名称（文件的上一级目录名）

    示例：
    - bag_path: oss://bucket/.../1_063_20260120-100608/1_063_20260120-100608_0.db3
    - package: 1_063_20260120-100608

    Returns:
        package 名称，如 "1_063_20260120-100608"，提取失败返回空字符串
    """
    try:
        parent_dir = Path(bag_path).parent.name
        return parent_dir
    except Exception as e:
        logger.error(f"提取 package 名称失败: {bag_path}, 错误: {e}")
        return ""


def extract_filename(file_path: str) -> str:
    """
    从路径中提取文件名（不含扩展名）

    支持 oss://、s3:// 等远程路径和本地路径。

    Args:
        file_path: 完整文件路径

    Returns:
        文件名（不含扩展名）
    """
    return PurePosixPath(file_path).stem
