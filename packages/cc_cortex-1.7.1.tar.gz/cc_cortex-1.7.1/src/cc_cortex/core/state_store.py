"""cc_cortex.core.state_store — Unified JSON state management.

@module state_store
@responsibility Namespace-aware JSON state with atomic I/O and
    auto-pruning
@dependencies cc_cortex.core.atomic
@exports StateStore
"""

from __future__ import annotations

import logging
import os
from typing import Any

from .atomic import acquire_file_lock, read_json, release_file_lock, write_atomic

logger = logging.getLogger("cc_cortex.state_store")


class StateStore:
    """Namespace-aware JSON state manager with auto-pruning.

    Args:
        base_dir: Root directory for state files.
            Files are stored as ``{base_dir}/{namespace}/{session_prefix}.json``.
    """

    def __init__(self, base_dir: str) -> None:
        self._base_dir = base_dir

    def _path(self, namespace: str, session_id: str) -> str:
        prefix = session_id[:8] if session_id else "unknown"
        return os.path.join(self._base_dir, namespace, f"{prefix}.json")

    def read(
        self,
        namespace: str,
        session_id: str,
        *,
        default: Any = None,
    ) -> Any:
        """Read state for a namespace + session.

        Args:
            namespace: Logical group (e.g. "sentinel", "read_log", "cooldown").
            session_id: Session identifier (first 8 chars used as filename).
            default: Returned when file doesn't exist or is corrupt.

        Returns:
            Parsed JSON data, or *default*.
        """
        if default is None:
            default = {}
        path = self._path(namespace, session_id)
        result = read_json(path, default=default)
        return result

    def write(
        self,
        namespace: str,
        session_id: str,
        data: Any,
    ) -> None:
        """Write state atomically.

        Args:
            namespace: Logical group.
            session_id: Session identifier.
            data: JSON-serializable data.
        """
        path = self._path(namespace, session_id)
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            write_atomic(path, data)
        except Exception as exc:
            logger.debug("state_store write failed: %s %s — %s", namespace, session_id[:8], exc)

    def read_modify_write(
        self,
        namespace: str,
        session_id: str,
        fn: Any,
        *,
        default: Any = None,
    ) -> Any:
        """Atomic read-modify-write with file lock.

        Acquires a file lock, reads current state, applies *fn*, writes back.
        Prevents concurrent-session data loss.

        Args:
            namespace: Logical group.
            session_id: Session identifier.
            fn: ``fn(data) -> new_data`` transformation callable.
            default: Fallback value when file doesn't exist.

        Returns:
            The new state after applying *fn*.

        Raises:
            RuntimeError: If the file lock cannot be acquired.
        """
        if default is None:
            default = {}
        path = self._path(namespace, session_id)
        # Ensure the namespace directory exists before attempting to
        # create the lock file — acquire_file_lock uses O_EXCL which
        # fails with FileNotFoundError on a missing parent directory.
        os.makedirs(os.path.dirname(path), exist_ok=True)
        lock_path = path + ".lock"
        if not acquire_file_lock(lock_path):
            msg = f"state_store: failed to acquire lock {lock_path}"
            raise RuntimeError(msg)
        try:
            data = self.read(namespace, session_id, default=default)
            data = fn(data)
            self.write(namespace, session_id, data)
            return data
        finally:
            release_file_lock(lock_path)

    def prune_list(
        self,
        namespace: str,
        session_id: str,
        *,
        key: str,
        max_items: int,
    ) -> None:
        """Keep only the last *max_items* entries for a list key.

        Args:
            namespace: Logical group.
            session_id: Session identifier.
            key: Dict key whose value is a list.
            max_items: Maximum items to retain (from end).
        """
        state = self.read(namespace, session_id, default={})
        items = state.get(key)
        if isinstance(items, list) and len(items) > max_items:
            state[key] = items[-max_items:]
            self.write(namespace, session_id, state)

    def read_flat(self, namespace: str, filename: str, *, default: Any = None) -> Any:
        """Read a non-session-scoped state file (e.g. shared cache).

        Args:
            namespace: Logical group.
            filename: Exact filename (not session-derived).
            default: Fallback value.
        """
        if default is None:
            default = {}
        path = os.path.join(self._base_dir, namespace, filename)
        return read_json(path, default=default)

    def write_flat(self, namespace: str, filename: str, data: Any) -> None:
        """Write a non-session-scoped state file atomically."""
        path = os.path.join(self._base_dir, namespace, filename)
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            write_atomic(path, data)
        except Exception as exc:
            logger.debug("state_store write_flat failed: %s/%s — %s", namespace, filename, exc)

    def prune_dict(
        self,
        namespace: str,
        filename: str,
        *,
        max_items: int,
        keep_last: int,
    ) -> None:
        """Keep only the last *keep_last* items in a flat dict (e.g. SHA cache).

        Args:
            namespace: Logical group.
            filename: Exact filename.
            max_items: Threshold that triggers pruning.
            keep_last: How many items to retain after pruning.
        """
        data = self.read_flat(namespace, filename, default={})
        if isinstance(data, dict) and len(data) > max_items:
            keys = list(data.keys())
            pruned = {k: data[k] for k in keys[-keep_last:]}
            self.write_flat(namespace, filename, pruned)
