"""cc_cortex.ziq_retrieval — EMA adaptive retrieval for Cognitive RAG.

@module ziq_retrieval
@responsibility Learn which knowledge sources (corrections, rules, skills,
    handoffs) are actually useful per-query, using EMA online learning.
    Replaces flat ChromaDB ranking with adaptive multi-source fusion.
@dependencies cc_cortex.core.state_store
@exports ZIQRetrieval, rerank_results, record_feedback

This is ZIQ-Find technology feeding back into CCC:
  - ZIQ-Score uses FTRL to learn retriever weights (search domain)
  - Here we use the same FTRL to learn knowledge-source weights (RAG domain)
  - PTME mapping: P=source stability, T=query pattern change,
    M=FTRL weights, E=fusion decision

Design:
  RAG returns N results from ChromaDB. Each result has a source type
  (correction, rule, skill, handoff). FTRL learns per-source-type weights
  from implicit feedback (was the correction actually used? did the agent
  read the linked skill?).

  The FTRL weights adjust over time:
  - Source type that keeps getting used → weight goes UP
  - Source type that gets ignored → weight goes DOWN
  - New session resets nothing (weights persist cross-session)

  This is the ZIQ "教練面" (coach) for RAG — it doesn't change the
  retriever (ChromaDB embeddings), it changes which results to trust.

PTME SOP for RAG:
  P (勢): source_type hit rate stability (are corrections consistently useful?)
  T (張): query pattern shift (new domain → reset confidence)
  M (記): FTRL cumulative weights per source_type
  E (決): final score = chromadb_score * ftrl_weight[source_type]
"""

from __future__ import annotations

from dataclasses import dataclass

from cc_cortex.core.state_store import StateStore

_NS = "ziq_retrieval"

# Source types for RAG knowledge
SOURCE_TYPES = (
    "correction",  # Past mistakes / learnings
    "rule",        # L0/L1/L2 rules
    "skill",       # KB skills
    "handoff",     # Handoff summaries
    "memory",      # Memory files
)

# EMA learning rate (how fast weights adapt)
DEFAULT_LR = 0.15
# Weight bounds
WEIGHT_MIN = 0.1
WEIGHT_MAX = 5.0


@dataclass
class SourceState:
    """Per-source-type adaptive state."""

    weight: float = 1.0  # Current weight (EMA)
    hits: int = 0     # Total times this source appeared in results
    used: int = 0     # Total times result from this source was used


def _ema_update(
    state: SourceState,
    reward: float,
    lr: float = DEFAULT_LR,
) -> SourceState:
    """EMA weight update. Positive reward = source was useful.

    Args:
        state: Current state for one source type.
        reward: +1.0 if used, -0.1 if ignored (asymmetric).
        lr: Learning rate (0-1).

    Returns:
        Updated SourceState.
    """
    # EMA: weight = (1-lr)*weight + lr*target
    # target = weight * (1 + reward) — multiplicative update
    target = state.weight * (1.0 + reward)
    state.weight = (1.0 - lr) * state.weight + lr * target

    # Clamp
    state.weight = max(WEIGHT_MIN, min(WEIGHT_MAX, state.weight))

    return state


class ZIQRetrieval:
    """EMA adaptive retrieval layer for CCC RAG.

    Wraps RAG search results with learned source-type weights.

    Usage::

        ziq = ZIQRetrieval(cache_dir="/path/to/cache")

        # After RAG search returns results
        reranked = ziq.rerank(results)

        # After observing which results were actually used
        ziq.feedback(used_files=["corrections/fix_123.md"])
    """

    def __init__(self, cache_dir: str):
        self._store = StateStore(cache_dir)

    def _load_states(self) -> dict[str, SourceState]:
        """Load source states from persistent store."""
        raw = self._store.read(_NS, "source_states", default={})
        states = {}
        for stype in SOURCE_TYPES:
            data = raw.get(stype, {})
            states[stype] = SourceState(
                weight=data.get("weight", 1.0),
                hits=data.get("hits", 0),
                used=data.get("used", 0),
            )
        return states

    def _save_states(self, states: dict[str, SourceState]) -> None:
        """Persist source states."""
        raw = {}
        for stype, state in states.items():
            raw[stype] = {
                "weight": state.weight,
                "hits": state.hits,
                "used": state.used,
            }
        self._store.write(_NS, "source_states", raw)

    def _classify_source(self, file_path: str) -> str:
        """Classify a file path into source type."""
        fp = file_path.lower().replace("\\", "/")
        if "correction" in fp or "learning" in fp:
            return "correction"
        if "rule" in fp or "00-l0" in fp or "l1/" in fp:
            return "rule"
        if "skill" in fp or "kb_" in fp:
            return "skill"
        if "handoff" in fp or "交接" in fp:
            return "handoff"
        if "memory" in fp:
            return "memory"
        return "correction"  # Default

    def get_weights(self) -> dict[str, float]:
        """Get current source-type weights (for debugging/display)."""
        states = self._load_states()
        return {stype: round(state.weight, 3) for stype, state in states.items()}

    def rerank(self, results: list[dict]) -> list[dict]:
        """Rerank RAG results using FTRL-learned source weights.

        Args:
            results: List of RAG result dicts with keys: text, file, score.

        Returns:
            Same results with adjusted scores, re-sorted.
        """
        if not results:
            return results

        # Shallow-copy each dict to avoid mutating caller's data
        results = [dict(r) for r in results]

        states = self._load_states()

        # Apply FTRL weights to scores
        for r in results:
            source_type = self._classify_source(r.get("file", ""))
            weight = states[source_type].weight
            original_score = r.get("score", 0.5)
            r["ziq_score"] = round(original_score * weight, 4)
            r["source_type"] = source_type
            # Track hit
            states[source_type].hits += 1

        self._save_states(states)

        # R1 fix: store this round's results for causal feedback
        self._last_rerank_results = list(results)

        # Sort by ZIQ-adjusted score (descending)
        results.sort(key=lambda x: x.get("ziq_score", 0), reverse=True)
        return results

    def feedback(self, used_files: list[str]) -> None:
        """Record which results were actually used (implicit feedback).

        Call this when the agent reads a file that was in RAG results.
        Positive gradient for used source types, negative for unused.

        Args:
            used_files: File paths that were actually read/used.
        """
        states = self._load_states()

        used_types = set()
        for fp in used_files:
            stype = self._classify_source(fp)
            used_types.add(stype)
            states[stype].used += 1

        # R1 fix: only penalize source types that appeared THIS round
        # (not all historically active types)
        this_round = {
            self._classify_source(r.get("file", ""))
            for r in self._last_rerank_results
        } if hasattr(self, "_last_rerank_results") else set()

        for stype in SOURCE_TYPES:
            if stype not in this_round and stype not in used_types:
                continue  # Skip types not involved this round
            reward = 0.3 if stype in used_types else -0.1
            states[stype] = _ema_update(states[stype], reward)
            # Weight decay every 20 feedback rounds: regress toward 1.0
            total = states[stype].hits
            if total > 0 and total % 20 == 0:
                states[stype].weight = (
                    0.95 * states[stype].weight + 0.05 * 1.0
                )

        self._save_states(states)

    def route_query(self, query: str, confidence: float) -> list[str]:
        """Decide which namespaces to search based on ZIQ confidence.

        Maps confidence (alpha_t) to search breadth:
        - confidence < 0.3  -> high confidence, search 1 best namespace (fast)
        - confidence 0.3-0.6 -> partial knowledge, search 2-3 namespaces + fusion
        - confidence > 0.6  -> low confidence, search all 5 + reranker

        Args:
            query: The search query text.
            confidence: ZIQ alpha_t uncertainty score (0=certain, 1=unknown).

        Returns:
            List of namespace keys to search.
        """
        all_ns = ["knowledge", "memory", "cognition", "skills", "context"]

        if confidence > 0.6:
            # High uncertainty — search everything
            return all_ns

        # Use query keywords to pick best namespaces
        q = query.lower()
        ranked: list[tuple[str, int]] = []
        keyword_map = {
            "memory": ["correction", "feedback", "handoff", "mistake", "learning"],
            "cognition": ["rule", "cbua", "plan", "decision", "iron"],
            "skills": ["skill", "kb_", "sop", "template", "how to"],
            "knowledge": ["doc", "api", "spec", "reference", "external"],
            "context": ["session", "current", "recent", "just now"],
        }
        for ns, keywords in keyword_map.items():
            score = sum(1 for kw in keywords if kw in q)
            ranked.append((ns, score))
        ranked.sort(key=lambda x: x[1], reverse=True)

        if confidence < 0.3:
            # High confidence — just the best match (or default to memory)
            best = ranked[0][0] if ranked[0][1] > 0 else "memory"
            return [best]

        # Medium confidence — top 2-3
        selected = [ns for ns, s in ranked if s > 0]
        if len(selected) < 2:
            selected = [ranked[0][0], ranked[1][0]]
        return selected[:3]

    def stats(self) -> dict:
        """Return stats for debugging/telemetry."""
        states = self._load_states()
        return {
            stype: {
                "weight": round(s.weight, 3),
                "hits": s.hits,
                "used": s.used,
                "use_rate": round(s.used / max(s.hits, 1), 2),
            }
            for stype, s in states.items()
        }


def rerank_results(
    cache_dir: str, results: list[dict],
) -> list[dict]:
    """Convenience: rerank RAG results with ZIQ adaptive weights."""
    return ZIQRetrieval(cache_dir).rerank(results)


def record_feedback(
    cache_dir: str, used_files: list[str],
) -> None:
    """Convenience: record feedback for ZIQ weight learning."""
    ZIQRetrieval(cache_dir).feedback(used_files)
