"""cc_cortex.agent — Agent management subsystem facade.

Re-exports from top-level modules for ``from cc_cortex.agent import …`` usage.
"""

from cc_cortex.agent_artifact_guard import AgentArtifactGuard
from cc_cortex.agent_gate import (
    AgentGateGuard,
    check,
    gate_agent_cap,
    is_research_agent,
)
from cc_cortex.agent_supervisor import (
    AgentSupervisor,
    SupervisedTask,
    VerificationResult,
    verify_task,
)

__all__ = [
    "AgentArtifactGuard",
    "AgentGateGuard",
    "AgentSupervisor",
    "SupervisedTask",
    "VerificationResult",
    "check",
    "gate_agent_cap",
    "is_research_agent",
    "verify_task",
]
