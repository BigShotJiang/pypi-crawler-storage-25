"""cc_cortex.hooks.on_prompt_submit — CCC-side prompt submit handler.

@module on_prompt_submit
@responsibility Combine clarity gate + multi-question injection + insight engine
    into a single CCC handler. CC hook stays thin (stdin parse + output).
@dependencies cc_cortex.prompt_guard, cc_cortex.insight_engine
@exports handle_prompt_submit
"""

from __future__ import annotations


def _ftrl_learning_injection(
    cache_dir: str = "",
    max_items: int = 3,
    ftrl_threshold: float = 3.0,
) -> str | None:
    """Inject top FTRL-weighted learnings as session reminders.

    Thin adapter — delegates to :class:`cc_cortex.prompt_engine.PromptEngine`
    so FTRL learnings flow through the shared dynamic-slot pipeline (budget
    aware, priority-ordered). ``cache_dir`` is retained for ABI stability
    but currently unused: learnings live at
    ``~/.claude/cognitive/learnings.json``.

    Args:
        cache_dir: Kept for backwards compatibility; ignored.
        max_items: Maximum learnings to inject.
        ftrl_threshold: Minimum FTRL weight to include.

    Returns:
        Formatted string of top learnings, or None.
    """
    try:
        from cc_cortex.prompt_engine import PromptEngine

        return PromptEngine().build_ftrl_context(
            max_items=max_items,
            ftrl_threshold=ftrl_threshold,
        )
    except Exception:
        return None


def _first_keyword_pos(text: str, keywords: list[str]) -> int:
    """Return position of the first matching keyword in *text*, or -1."""
    for kw in keywords:
        pos = text.find(kw.lower())
        if pos >= 0:
            return pos
    return -1


def rule_injection(
    user_prompt: str,
    *,
    trigger_map: dict[str, list[str]] | None = None,
    rules_dir: str = "",
    max_files: int = 2,
) -> str | None:
    """Keyword-triggered L1 rule injection for three-layer rule architecture.

    Scans user prompt for trigger keywords (multi-language via i18n.patterns)
    and injects matching rule files as additionalContext. This enables:
    L0 (always loaded, minimal) → L1 (keyword-triggered) → L2 (manual).

    Args:
        user_prompt: The user's input.
        trigger_map: Maps rule file basenames to i18n pattern keys.
            e.g. {"handoff.md": "rule_trigger.handoff"}
            If a pattern key is not found in i18n, the value list is used
            as literal keywords (fallback for custom setups).
        rules_dir: Base directory for rule files.
        max_files: Maximum number of rule files to inject (default 2).

    Returns:
        Combined content of matched rule files, or None.
    """
    import os

    from cc_cortex.i18n import patterns as i18n_patterns

    if not trigger_map or not user_prompt:
        return None

    prompt_lower = user_prompt.lower()
    matched: list[tuple[int, str, str]] = []  # (position, basename, content)

    for rule_file, kw_source in trigger_map.items():
        # Try i18n patterns first (multi-language), fallback to literal list
        keywords = (
            i18n_patterns(kw_source) or [kw_source]
            if isinstance(kw_source, str)
            else list(kw_source)
        )
        pos = _first_keyword_pos(prompt_lower, keywords)
        if pos < 0:
            continue
        full_path = (
            os.path.join(rules_dir, rule_file) if rules_dir else rule_file
        )
        if not os.path.isfile(full_path):
            continue
        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read(4096)  # Cap at 4KB per file
        except OSError:
            continue
        matched.append((pos, os.path.basename(rule_file), content))

    if not matched:
        return None

    # Sort by position in prompt (earliest mention = most relevant), cap
    matched.sort(key=lambda x: x[0])
    matched = matched[:max_files]

    parts = [f"📋 {name}:\n{content}" for _, name, content in matched]
    header = "📋 L1 rules auto-loaded (keyword trigger):"
    return header + "\n\n" + "\n\n---\n\n".join(parts)


def _auto_capture_goal(
    user_prompt: str,
    cache_dir: str,
    session_id: str,
    max_len: int = 80,
) -> None:
    """Seed TaskOrchestrator with the first user prompt as the session goal.

    Pure side-effect, failure-safe. Behavior:
      - No-op when cache_dir / session_id missing.
      - No-op when a goal is already set (don't clobber explicit goals).
      - No-op when prompt is empty after strip / trivially short.
      - Truncates long prompts to *max_len* chars so the goal line stays
        readable in ``cc aegis status``.

    This makes every fresh session automatically trackable via the
    existing aegis CLI without requiring the user to call ``cc aegis goal``
    manually.
    """
    if not cache_dir or not session_id:
        return
    text = (user_prompt or "").strip()
    if len(text) < 3:
        return
    try:
        from cc_cortex.task_orchestrator import TaskOrchestrator

        orch = TaskOrchestrator(
            cache_dir=cache_dir,
            session_id=session_id,
        )
        if orch.progress().get("goal"):
            return  # Already set — don't clobber
        goal = text[:max_len]
        if len(text) > max_len:
            goal = goal.rstrip() + "..."
        orch.set_goal(goal)
    except Exception:
        # Auto-capture must never break prompt submission
        pass


def handle_prompt_submit(
    user_prompt: str,
    *,
    prefs_path: str = "",
    cache_dir: str = "",
    session_id: str = "",
    trigger_map: dict[str, list[str]] | None = None,
    rules_dir: str = "",
) -> dict:
    """Run CCC prompt-submit pipeline.

    Returns:
        dict with optional keys:
        - "deny": hook deny dict (if clarity gate rejects)
        - "contexts": list[str] of additionalContext fragments
    """
    from cc_cortex.insight_engine import check_insight
    from cc_cortex.prompt_guard import (
        multi_question_injection,
        run_clarity_gate,
    )

    # 1. TADS-3 clarity gate
    deny = run_clarity_gate(user_prompt, prefs_path=prefs_path)
    if deny:
        return {"deny": deny}

    contexts: list[str] = []

    # 2. Multi-question checklist injection
    mq = multi_question_injection(user_prompt)
    if mq:
        contexts.append(mq)

    # 3. Proactive Insight Engine
    insight = check_insight(
        user_prompt,
        cache_dir=cache_dir,
        session_id=session_id,
    )
    if insight:
        contexts.append(insight)

    # 4. FTRL-weighted learning injection (top corrections by recency × count)
    ftrl_ctx = _ftrl_learning_injection(cache_dir=cache_dir)
    if ftrl_ctx:
        contexts.append(ftrl_ctx)

    # 5. L1 Rule injection (three-layer architecture)
    if trigger_map:
        rule_ctx = rule_injection(
            user_prompt,
            trigger_map=trigger_map,
            rules_dir=rules_dir,
        )
        if rule_ctx:
            contexts.append(rule_ctx)

    # 6. Auto-capture session goal from first prompt (side-effect only)
    _auto_capture_goal(user_prompt, cache_dir, session_id)

    return {"contexts": contexts}
