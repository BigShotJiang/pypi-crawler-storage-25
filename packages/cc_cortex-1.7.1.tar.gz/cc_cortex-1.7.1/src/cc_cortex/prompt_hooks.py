"""cc_cortex.prompt_hooks — LLM-as-Judge via Claude Code prompt hooks.

@module prompt_hooks
@responsibility Curated judge prompts + settings.json installer for
    Claude Code's ``type: "prompt"`` hook runtime. CCC never calls an
    LLM directly (core is zero-dep and L3 forbids hook-side LLM calls);
    instead this module emits ``hooks`` config that the CC runtime
    executes with its own Haiku-class evaluator.
@dependencies stdlib only (``json``, ``pathlib``, ``dataclasses``)
@exports PromptJudge, HALLUCINATION_JUDGE, EXCUSE_SCANNER_JUDGE,
    CODE_QUALITY_JUDGE, ALL_JUDGES, build_hook_config,
    install_prompt_hooks, uninstall_prompt_hooks

Rationale (1.4.0 C6 — H1 reopen):
  H1 ``LLM-as-Judge`` was killed in 1.3.0 because CCC's core cannot
  import an LLM SDK (zero runtime deps + L3 hook-side LLM ban). The
  2026-04 Claude Code release shipped an official ``type: "prompt"``
  hook that runs a short single-turn evaluation against a fast model
  inside the CC runtime itself — the KILL premise no longer holds.

  CCC's role is narrow on purpose: ship *well-written judge prompts*
  as module constants plus a settings.json installer. The user's CC
  runtime does the actual evaluation. Judges and installer are fully
  tested; integration with the live runtime is the user's choice.

Design constraints:
  - Pure stdlib, no runtime deps.
  - Settings writes are atomic (temp file + replace) so a crash mid-
    write does not corrupt the user's config.
  - Installer is idempotent: each judge is tagged with a marker token
    in ``statusMessage`` and the prompt header, so running ``install``
    twice leaves the file unchanged and ``uninstall`` is unambiguous.
  - Never touches hook specs the user (or another tool) added — we
    only append, match, and remove by marker.
  - No personal paths; the caller passes the settings.json location.
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

MARKER_PREFIX = "[cc-cortex:"
"""Marker token embedded at the start of CCC-owned prompts / statusMessage.

Downstream detection reads this prefix to tell CCC-owned hook specs
apart from specs the user wrote by hand. Changing this value is a
breaking change for existing installations — bump the module contract
and provide a migration shim if it ever happens.
"""

DEFAULT_MODEL = "claude-haiku-4-5-20251001"
"""Default evaluation model.

Haiku 4.5 is the 2026-04 fast-path default: strong enough for
single-turn yes/no evaluation, cheap enough to run on every tool call
without budget anxiety. Callers can override per judge via
``PromptJudge.model``.
"""

DEFAULT_TIMEOUT = 30
"""Default prompt-hook timeout in seconds, matching CC docs."""


# ── PromptJudge dataclass ──────────────────────────────────


@dataclass(frozen=True)
class PromptJudge:
    """A single judge prompt + the hook event it attaches to.

    Every judge is identified by ``name``; CCC tags ownership using
    ``[cc-cortex:<name>]`` in both the rendered prompt and the
    ``statusMessage`` so install / uninstall can find the right spec
    without guessing.

    Attributes:
        name: unique identifier (snake_case). Used in the marker.
        event: Claude Code hook event (``PostToolUse``, ``Stop``, ...).
        matcher: tool matcher regex string. Empty string means no
            matcher — the CC runtime treats that as "all tools" for
            tool events. Non-tool events (``Stop``, ``UserPromptSubmit``)
            should leave this empty.
        prompt_body: the actual judge prompt. ``build_spec`` prepends
            the marker header and appends the ``$ARGUMENTS`` slot if
            the body does not already include one.
        description: short human description used in documentation.
        model: evaluation model. Defaults to Haiku.
        timeout: seconds before CC cancels the evaluation.
        status_message: spinner label shown while the hook runs; the
            installer prepends the marker automatically.
    """

    name: str
    event: str
    matcher: str
    prompt_body: str
    description: str
    model: str = DEFAULT_MODEL
    timeout: int = DEFAULT_TIMEOUT
    status_message: str = ""

    def marker(self) -> str:
        """Return the ownership marker token for this judge."""
        return f"{MARKER_PREFIX}{self.name}]"

    def rendered_prompt(self) -> str:
        """Return the full prompt string the hook spec should carry."""
        header = f"{self.marker()} CCC judge prompt — do not edit inline.\n\n"
        body = self.prompt_body
        # Ensure the body tells the runtime where to splice the hook
        # JSON input. CC replaces $ARGUMENTS before dispatch.
        if "$ARGUMENTS" not in body:
            body = body.rstrip() + "\n\nHook input JSON:\n$ARGUMENTS\n"
        return header + body

    def rendered_status_message(self) -> str:
        """Return the spinner label, always tagged with the marker."""
        if self.status_message:
            return f"{self.marker()} {self.status_message}"
        return f"{self.marker()} running…"

    def build_spec(self) -> dict[str, Any]:
        """Return the hook spec dict CC expects inside ``hooks: [...]``."""
        spec: dict[str, Any] = {
            "type": "prompt",
            "prompt": self.rendered_prompt(),
            "model": self.model,
            "timeout": self.timeout,
            "statusMessage": self.rendered_status_message(),
        }
        return spec


# ── Judge prompt constants ─────────────────────────────────


_HALLUCINATION_BODY = """You are HallucinationJudge, a terse reviewer that inspects the last
written artifact for unsourced factual claims.

A claim is unsourced when the writer states something as fact
(specific numbers, historical events, API behavior, library
versions, research results) without citing a source the reader
can verify — code path, commit, file, URL, or explicit "I inferred".

For each unsourced claim, note it. If the artifact is pure code,
prose that only describes the diff, or references only files that
exist in the repo, return allow.

Return a JSON object:
  {"decision": "block", "reason": "<one sentence>"}  if any
    unsourced factual claim appears;
  {}  (empty object) otherwise.

Block sparingly. Style preferences, opinions, and TODO notes are
not hallucinations. Only block when a future reader would reach
the wrong conclusion because the writer invented a fact."""


_EXCUSE_SCANNER_BODY = """You are ExcuseScannerJudge. You read the final assistant message of
this session and flag hedging language that masks unfinished work.

Examples of excuses to flag:
  - "should work" / "probably works" / "theoretically" without a test
  - "will fix later" / "leaving as TODO" in a shipped deliverable
  - "good enough" when the task explicitly required verification
  - claiming success while the diff shows only partial implementation
  - saying "I verified" when no verification artifact (screenshot,
    test output, command transcript) was produced

Return a JSON object:
  {"decision": "block", "reason": "<one sentence quoting the
    hedging phrase>"}  if an excuse is present;
  {}  otherwise.

Do not block normal caveats ("on Linux this may differ", "needs
review before merge"). Only block when the assistant is declaring
done on work that is demonstrably not done."""


_CODE_QUALITY_BODY = """You are CodeQualityJudge, a staff-engineer reviewer. You inspect a
single Write or Edit tool call and look for the four cardinal sins:

  1. Dead code — functions / vars defined and never called.
  2. Silently-swallowed errors — bare except, ignored Result/Err.
  3. Over-engineering — abstractions, flags, or config for
     scenarios the diff does not exercise.
  4. Backdoor defaults — dangerous fallbacks like "if missing, use
     admin", "if parse fails, allow", "if timeout, proceed".

You do NOT flag style, naming, or import order. You do NOT ask for
tests unless the diff deletes an existing test.

Return a JSON object:
  {"decision": "block", "reason": "<cardinal sin + location>"}  if
    any of the four is present;
  {}  otherwise."""


HALLUCINATION_JUDGE: PromptJudge = PromptJudge(
    name="hallucination_judge",
    event="PostToolUse",
    matcher="Write|Edit",
    prompt_body=_HALLUCINATION_BODY,
    description="Flag unsourced factual claims in Write/Edit output.",
    status_message="hallucination check",
)


EXCUSE_SCANNER_JUDGE: PromptJudge = PromptJudge(
    name="excuse_scanner_judge",
    event="Stop",
    matcher="",
    prompt_body=_EXCUSE_SCANNER_BODY,
    description="Flag hedging language when declaring a task done.",
    status_message="excuse scan",
)


CODE_QUALITY_JUDGE: PromptJudge = PromptJudge(
    name="code_quality_judge",
    event="PostToolUse",
    matcher="Write|Edit",
    prompt_body=_CODE_QUALITY_BODY,
    description="Flag the four cardinal code sins in Write/Edit diffs.",
    status_message="code quality check",
)


ALL_JUDGES: tuple[PromptJudge, ...] = (
    HALLUCINATION_JUDGE,
    EXCUSE_SCANNER_JUDGE,
    CODE_QUALITY_JUDGE,
)


# ── Hook config builder ────────────────────────────────────


def build_hook_config(
    judges: Sequence[PromptJudge] = ALL_JUDGES,
) -> dict[str, list[dict[str, Any]]]:
    """Return a ``hooks`` sub-dict suitable for settings.json merge.

    The shape matches CC's expectation::

        {
          "PostToolUse": [
            {"matcher": "Write|Edit", "hooks": [<spec>, ...]},
            ...
          ],
          "Stop": [
            {"hooks": [<spec>, ...]}
          ]
        }

    Judges with the same (event, matcher) pair are grouped into the
    same matcher entry so CC dispatches them together.
    """
    out: dict[str, list[dict[str, Any]]] = {}
    # (event, matcher) → list of specs, preserving judge order
    buckets: dict[tuple[str, str], list[dict[str, Any]]] = {}
    order: list[tuple[str, str]] = []

    for j in judges:
        key = (j.event, j.matcher)
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(j.build_spec())

    for event, matcher in order:
        entry: dict[str, Any] = {}
        if matcher:
            entry["matcher"] = matcher
        entry["hooks"] = buckets[(event, matcher)]
        out.setdefault(event, []).append(entry)

    return out


# ── Settings file helpers ──────────────────────────────────


def _load_settings(path: Path) -> dict[str, Any]:
    """Load settings.json. Missing file → empty dict. Invalid → raise."""
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        msg = (
            f"{path} is not valid JSON: {exc}. Refusing to write over "
            "a corrupt settings file; fix it by hand first."
        )
        raise ValueError(msg) from exc
    if not isinstance(data, dict):
        msg = (
            f"{path} top level must be a JSON object; got "
            f"{type(data).__name__}."
        )
        raise ValueError(msg)
    return data


def _atomic_write(path: Path, data: dict[str, Any]) -> None:
    """Write JSON atomically. Creates parent dirs if missing."""
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    # NamedTemporaryFile on Windows cannot be re-opened while the
    # handle is open, so we close first then os.replace.
    fd, tmp = tempfile.mkstemp(
        prefix=".settings.json.",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _is_ccc_owned(spec: dict[str, Any]) -> bool:
    """Return True if a hook spec is one of ours (marker-based)."""
    if spec.get("type") != "prompt":
        return False
    prompt = spec.get("prompt", "")
    status = spec.get("statusMessage", "")
    if not isinstance(prompt, str) or not isinstance(status, str):
        return False
    return prompt.startswith(MARKER_PREFIX) or status.startswith(
        MARKER_PREFIX,
    )


def _judge_matches_spec(judge: PromptJudge, spec: dict[str, Any]) -> bool:
    """True if ``spec`` looks like the CCC install of ``judge``."""
    if not _is_ccc_owned(spec):
        return False
    marker = judge.marker()
    prompt = spec.get("prompt", "")
    if isinstance(prompt, str) and prompt.startswith(marker):
        return True
    status = spec.get("statusMessage", "")
    return isinstance(status, str) and status.startswith(marker)


def _merge_judge_into_hooks(
    hooks_root: dict[str, Any],
    judge: PromptJudge,
) -> None:
    """Insert one judge into ``hooks_root`` in place. Idempotent."""
    event_list = hooks_root.setdefault(judge.event, [])
    if not isinstance(event_list, list):
        msg = (
            f"hooks.{judge.event} must be a list in settings.json; "
            f"got {type(event_list).__name__}."
        )
        raise ValueError(msg)

    # Find the matcher entry we should attach to.
    target_entry: dict[str, Any] | None = None
    for entry in event_list:
        if not isinstance(entry, dict):
            continue
        entry_matcher = entry.get("matcher", "")
        if entry_matcher == judge.matcher:
            target_entry = entry
            break

    if target_entry is None:
        target_entry = {}
        if judge.matcher:
            target_entry["matcher"] = judge.matcher
        target_entry["hooks"] = []
        event_list.append(target_entry)

    spec_list = target_entry.setdefault("hooks", [])
    if not isinstance(spec_list, list):
        msg = (
            f"hooks.{judge.event}[...].hooks must be a list; got "
            f"{type(spec_list).__name__}."
        )
        raise ValueError(msg)

    new_spec = judge.build_spec()
    # Replace an existing CCC spec for this judge; otherwise append.
    for i, existing in enumerate(spec_list):
        if isinstance(existing, dict) and _judge_matches_spec(judge, existing):
            spec_list[i] = new_spec
            return
    spec_list.append(new_spec)


def _remove_judge_from_hooks(
    hooks_root: dict[str, Any],
    judge: PromptJudge,
) -> bool:
    """Remove CCC-owned spec for ``judge`` from ``hooks_root``.

    Returns True if something was removed. Cleans up empty matcher
    entries and empty event lists so uninstall is a full reversal.
    """
    event_list = hooks_root.get(judge.event)
    if not isinstance(event_list, list):
        return False

    removed = False
    pruned_entries: list[dict[str, Any]] = []
    for entry in event_list:
        if not isinstance(entry, dict):
            pruned_entries.append(entry)
            continue
        entry_matcher = entry.get("matcher", "")
        spec_list = entry.get("hooks", [])
        if entry_matcher != judge.matcher or not isinstance(spec_list, list):
            pruned_entries.append(entry)
            continue

        new_specs: list[Any] = []
        for spec in spec_list:
            if isinstance(spec, dict) and _judge_matches_spec(judge, spec):
                removed = True
                continue
            new_specs.append(spec)

        if new_specs:
            new_entry = dict(entry)
            new_entry["hooks"] = new_specs
            pruned_entries.append(new_entry)
        # Otherwise drop the empty entry entirely.

    if pruned_entries:
        hooks_root[judge.event] = pruned_entries
    else:
        hooks_root.pop(judge.event, None)
    return removed


# ── Public installer API ───────────────────────────────────


def install_prompt_hooks(
    settings_path: str | os.PathLike[str],
    *,
    judges: Sequence[PromptJudge] = ALL_JUDGES,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Install ``judges`` into ``settings_path``.

    Idempotent: running twice with the same judges is a no-op beyond
    refreshing the stored prompt to the current module version (which
    is what you want — bumping CCC bumps the judge prompt). Other
    hooks already in the file are preserved byte-for-byte.

    Args:
        settings_path: absolute path to the target settings.json. The
            caller owns path selection (CCC never touches
            ``$HOME/.claude/settings.json`` unless asked to).
        judges: which judges to install. Default installs all three.
        dry_run: when True, returns the new settings dict without
            touching disk.

    Returns:
        The resulting settings.json content as a dict.

    Raises:
        ValueError: if the existing file is not valid JSON or does
            not have a dict at the top level.
    """
    path = Path(settings_path)
    data = _load_settings(path)
    hooks_root = data.setdefault("hooks", {})
    if not isinstance(hooks_root, dict):
        msg = (
            f"{path} has a non-dict `hooks` section "
            f"({type(hooks_root).__name__}); refusing to overwrite."
        )
        raise ValueError(msg)

    for judge in judges:
        _merge_judge_into_hooks(hooks_root, judge)

    if not dry_run:
        _atomic_write(path, data)
    return data


def uninstall_prompt_hooks(
    settings_path: str | os.PathLike[str],
    *,
    judges: Sequence[PromptJudge] = ALL_JUDGES,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Remove CCC-owned judge hooks from ``settings_path``.

    Uses marker matching so we never touch specs the user wrote or
    modified by hand (modifying the prompt header breaks marker
    ownership and the spec becomes "user-owned" — uninstall leaves
    it alone by design).

    Args:
        settings_path: target settings.json.
        judges: which judges to remove. Default removes all three.
        dry_run: when True, returns the new dict without writing.

    Returns:
        The resulting settings.json content as a dict.
    """
    path = Path(settings_path)
    if not path.exists():
        return {}
    data = _load_settings(path)
    hooks_root = data.get("hooks")
    if not isinstance(hooks_root, dict):
        return data

    for judge in judges:
        _remove_judge_from_hooks(hooks_root, judge)

    if not hooks_root:
        data.pop("hooks", None)

    if not dry_run:
        _atomic_write(path, data)
    return data


def list_installed_judges(
    settings_path: str | os.PathLike[str],
) -> list[str]:
    """Return the names of CCC-owned judges currently in settings.json.

    Scans every hook spec under ``hooks.*[*].hooks`` and reports any
    that carry our marker prefix. Non-prompt hooks and non-CCC specs
    are ignored.
    """
    path = Path(settings_path)
    if not path.exists():
        return []
    data = _load_settings(path)
    hooks_root = data.get("hooks")
    if not isinstance(hooks_root, dict):
        return []

    found: list[str] = []
    for event_list in hooks_root.values():
        if not isinstance(event_list, list):
            continue
        for entry in event_list:
            if not isinstance(entry, dict):
                continue
            spec_list = entry.get("hooks", [])
            if not isinstance(spec_list, list):
                continue
            for spec in spec_list:
                if not isinstance(spec, dict) or not _is_ccc_owned(spec):
                    continue
                prompt = spec.get("prompt", "")
                if not isinstance(prompt, str):
                    continue
                # Marker format: [cc-cortex:<name>] ...
                if prompt.startswith(MARKER_PREFIX):
                    end = prompt.find("]")
                    if end > len(MARKER_PREFIX):
                        found.append(prompt[len(MARKER_PREFIX):end])
    return found


__all__ = [
    "MARKER_PREFIX",
    "DEFAULT_MODEL",
    "DEFAULT_TIMEOUT",
    "PromptJudge",
    "HALLUCINATION_JUDGE",
    "EXCUSE_SCANNER_JUDGE",
    "CODE_QUALITY_JUDGE",
    "ALL_JUDGES",
    "build_hook_config",
    "install_prompt_hooks",
    "uninstall_prompt_hooks",
    "list_installed_judges",
]


# Suppress unused warnings for dataclass field helper (kept in case a
# future judge needs per-instance mutable defaults).
_ = field
