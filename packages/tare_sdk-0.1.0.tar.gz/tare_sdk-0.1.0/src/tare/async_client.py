from __future__ import annotations

import os
from typing import Optional

import httpx

from .exceptions import TareLimitError, TareConnectionError

try:
    from openai import AsyncOpenAI
except ImportError:
    AsyncOpenAI = None

try:
    from anthropic import AsyncAnthropic
except ImportError:
    AsyncAnthropic = None


class TareAsyncHTTPClient(httpx.AsyncClient):
    def __init__(self, *args, **kwargs):
        self._tare_url = kwargs.pop("tare_url", "")
        super().__init__(*args, **kwargs)

    def _handle_429(self, response):
        if response.status_code == 429:
            try:
                data = response.json()
                if data.get("error") == "limit_reached":
                    request_id = response.headers.get("X-Tare-Request-ID", "")
                    raise TareLimitError(
                        limit=data.get("limit", "unknown"),
                        message=data.get("message", "Limit reached"),
                        docs=data.get("docs"),
                        tare_request_id=request_id,
                    )
            except Exception:
                pass  # If we can't parse, just return the response
        return response

    async def request(self, *args, **kwargs):
        try:
            resp = await super().request(*args, **kwargs)
            return self._handle_429(resp)
        except httpx.ConnectError as e:
            raise TareConnectionError(self._tare_url) from e

    async def send(self, *args, **kwargs):
        try:
            resp = await super().send(*args, **kwargs)
            return self._handle_429(resp)
        except httpx.ConnectError as e:
            raise TareConnectionError(self._tare_url) from e


class AsyncTareClient:
    def __init__(
        self,
        tare_api_key: str,
        tare_url: str = "http://localhost:8000",
        feature: Optional[str] = None,
        user_id: Optional[str] = None,
        project: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        anthropic_api_key: Optional[str] = None,
    ):
        self.tare_api_key = tare_api_key
        self.tare_url = tare_url.rstrip("/")
        self.feature = feature
        self.user_id = user_id
        self.project = project

        self.default_headers = {
            "Authorization": f"Bearer {self.tare_api_key}",
        }
        if self.feature:
            self.default_headers["X-Tare-Feature"] = self.feature
        if self.user_id:
            self.default_headers["X-Tare-User"] = self.user_id
        if self.project:
            self.default_headers["X-Tare-Project"] = self.project

        self._openai = None
        self._anthropic = None
        self._openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY", "missing-key")
        self._anthropic_api_key = anthropic_api_key or os.getenv("ANTHROPIC_API_KEY", "missing-key")

    @property
    def openai(self):
        if self._openai is None:
            if AsyncOpenAI is None:
                raise ImportError("openai package is not installed")

            http_client = TareAsyncHTTPClient(tare_url=self.tare_url)
            self._openai = AsyncOpenAI(
                api_key=self._openai_api_key,
                base_url=f"{self.tare_url}/v1",
                default_headers=self.default_headers,
                http_client=http_client,
            )
        return self._openai

    @property
    def anthropic(self):
        if self._anthropic is None:
            if AsyncAnthropic is None:
                raise ImportError("anthropic package is not installed")

            http_client = TareAsyncHTTPClient(tare_url=self.tare_url)
            self._anthropic = AsyncAnthropic(
                api_key=self._anthropic_api_key,
                base_url=self.tare_url,
                default_headers=self.default_headers,
                http_client=http_client,
            )
        return self._anthropic
