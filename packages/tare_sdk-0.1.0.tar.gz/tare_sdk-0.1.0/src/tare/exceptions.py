class TareError(Exception):
    def __init__(self, message: str, tare_request_id: str = None):
        super().__init__(message)
        self.tare_request_id = tare_request_id


class TareLimitError(TareError):
    def __init__(self, limit: str, message: str, docs: str = None, tare_request_id: str = None):
        super().__init__(message, tare_request_id)
        self.limit = limit
        self.message = message
        self.docs = docs or "https://tare.dev/docs/limits"

    def __str__(self):
        return f"TareLimitError({self.limit}): {self.message}"


class TareConnectionError(TareError):
    def __init__(self, url: str, tare_request_id: str = None):
        msg = f"Tare proxy at {url} is unreachable. Verify the proxy is running and TARE_URL is correct."
        super().__init__(msg, tare_request_id)
        self.url = url

    def __str__(self):
        return f"TareConnectionError: Tare proxy at {self.url} is unreachable."