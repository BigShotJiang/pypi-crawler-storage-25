"""
tests/test_sdk.py
─────────────────
Integration test for the Tare SDK.

Strategy
────────
We *don't* call the real OpenAI API — that would require a paid key and
add network flakiness.  Instead we:

1. Unit-test that tare.client() returns an openai.OpenAI instance wired to
   the proxy with the correct base_url and header.

2. Integration-test that a call recorded via the proxy (using the
   /internal/seed endpoint so no upstream key is needed) shows up in
   /api/calls with a non-zero cost.

Prerequisites
─────────────
The Tare proxy must be running on localhost:8000:

    cd proxy && .venv/Scripts/uvicorn main:app --reload --port 8000

Run the tests:

    cd sdk
    pip install -e ".[dev]"
    pytest -v
"""

from __future__ import annotations

import time
import uuid

import httpx
import pytest
import tare
from openai import OpenAI

PROXY_BASE = "http://localhost:8000"


# ── helpers ───────────────────────────────────────────────────────────────────


def proxy_is_up() -> bool:
    try:
        r = httpx.get(f"{PROXY_BASE}/health", timeout=3.0)
        return r.status_code == 200
    except Exception:
        return False


requires_proxy = pytest.mark.skipif(
    not proxy_is_up(),
    reason="Tare proxy not running on localhost:8000 — start it with: "
           "cd proxy && .venv/Scripts/uvicorn main:app --reload",
)


# ── unit tests ────────────────────────────────────────────────────────────────


class TestClientFactory:
    """tare.client() must return a properly configured OpenAI instance."""

    def test_returns_openai_instance(self):
        llm = tare.client(api_key="sk-test-key", feature="test")
        assert isinstance(llm, OpenAI)

    def test_base_url_ends_with_v1(self):
        llm = tare.client(api_key="sk-test-key", feature="test")
        # base_url is a httpx URL object; str() gives the full URL
        assert str(llm.base_url).rstrip("/").endswith("/v1"), (
            f"Expected base_url to end in /v1, got: {llm.base_url}"
        )

    def test_feature_header_is_injected(self):
        feature = "my-feature"
        llm = tare.client(api_key="sk-test-key", feature=feature)
        assert llm.default_headers.get("X-Tare-Feature") == feature, (
            "X-Tare-Feature header was not set on the client"
        )

    def test_custom_proxy_url(self):
        llm = tare.client(
            api_key="sk-test-key",
            feature="test",
            proxy_url="http://custom-proxy:9000",
        )
        assert "custom-proxy:9000" in str(llm.base_url)

    def test_v1_not_doubled_when_provided(self):
        """If someone passes a proxy_url that already has /v1, don't double it."""
        llm = tare.client(
            api_key="sk-test-key",
            feature="test",
            proxy_url="http://localhost:8000/v1",
        )
        url = str(llm.base_url).rstrip("/")
        assert not url.endswith("/v1/v1"), f"Double /v1 detected: {url}"

    def test_extra_kwargs_forwarded(self):
        """max_retries should be passed through to OpenAI without error."""
        llm = tare.client(api_key="sk-test-key", feature="test", max_retries=0)
        assert llm.max_retries == 0


# ── integration tests ─────────────────────────────────────────────────────────


@requires_proxy
class TestCostRecording:
    """
    Verifies the full loop: a call reaches the proxy → cost is recorded → 
    the dashboard API returns the record.

    Uses /internal/seed so no real OpenAI API key is required.
    """

    def _seed_one(self, feature: str, model: str = "gpt-4o-mini") -> dict:
        """Insert one synthetic call record via the proxy seed endpoint."""
        payload = {
            "feature_name": feature,
            "model": model,
            "prompt_tokens": 100,
            "completion_tokens": 50,
            "latency_ms": 300,
        }
        resp = httpx.post(f"{PROXY_BASE}/internal/seed", json=payload, timeout=5.0)
        resp.raise_for_status()
        return resp.json()

    def _latest_calls(self, limit: int = 10) -> list[dict]:
        resp = httpx.get(f"{PROXY_BASE}/api/calls", params={"limit": limit}, timeout=5.0)
        resp.raise_for_status()
        return resp.json()

    # ── tests ─────────────────────────────────────────────────────────────────

    def test_seed_returns_ok(self):
        result = self._seed_one("sdk-test")
        assert result.get("ok") is True
        assert "id" in result

    def test_cost_is_nonzero_for_known_model(self):
        """gpt-4o-mini has a known price — cost must be > 0."""
        result = self._seed_one("sdk-test", model="gpt-4o-mini")
        cost = result.get("total_cost_usd", 0)
        assert cost > 0, (
            f"Expected non-zero cost for gpt-4o-mini, got {cost!r}. "
            "Check pricing_manifest.json."
        )

    def test_record_appears_in_api_calls(self):
        """After seeding, the call must appear in /api/calls."""
        # Use a unique feature so we can find it without date filtering
        feature = f"sdk-test-{uuid.uuid4().hex[:8]}"
        seed_result = self._seed_one(feature)
        inserted_id = seed_result["id"]

        calls = self._latest_calls(limit=100)
        ids = {c["id"] for c in calls}
        assert inserted_id in ids, (
            f"Seeded record {inserted_id!r} not found in /api/calls response. "
            f"Got IDs: {list(ids)[:5]}..."
        )

    def test_feature_name_is_recorded_correctly(self):
        """The feature_name stored in the DB must match what was sent."""
        feature = f"sdk-test-{uuid.uuid4().hex[:8]}"
        seed_result = self._seed_one(feature)
        inserted_id = seed_result["id"]

        calls = self._latest_calls(limit=100)
        match = next((c for c in calls if c["id"] == inserted_id), None)

        assert match is not None, "Record not found in /api/calls"
        assert match["feature_name"] == feature, (
            f"Expected feature_name={feature!r}, got {match['feature_name']!r}"
        )

    def test_cost_is_recorded_in_db(self):
        """The primary assertion: cost > 0 must be persisted in the DB record."""
        feature = f"sdk-test-{uuid.uuid4().hex[:8]}"
        seed_result = self._seed_one(feature, model="gpt-4o-mini")
        inserted_id = seed_result["id"]

        calls = self._latest_calls(limit=100)
        match = next((c for c in calls if c["id"] == inserted_id), None)

        assert match is not None, "Record not found in /api/calls"
        assert match["total_cost_usd"] > 0, (
            f"Expected total_cost_usd > 0 for gpt-4o-mini, "
            f"got {match['total_cost_usd']!r}"
        )

    def test_token_counts_are_stored(self):
        """prompt_tokens=100 and completion_tokens=50 must round-trip correctly."""
        feature = f"sdk-test-{uuid.uuid4().hex[:8]}"
        seed_result = self._seed_one(feature)
        inserted_id = seed_result["id"]

        calls = self._latest_calls(limit=100)
        match = next((c for c in calls if c["id"] == inserted_id), None)

        assert match is not None
        assert match["prompt_tokens"] == 100
        assert match["completion_tokens"] == 50
        assert match["total_tokens"] == 150

    def test_health_endpoint(self):
        """Sanity check that the proxy is reachable."""
        resp = httpx.get(f"{PROXY_BASE}/health", timeout=3.0)
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
