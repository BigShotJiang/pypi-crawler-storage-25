# Tare SDK

Drop-in replacement for `openai.OpenAI` that routes every call through the
Tare proxy and attributes cost to the product feature that made it.

## 5-line integration

```python
import tare

llm = tare.client(api_key="sk-...", feature="chat")
resp = llm.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Summarise this in one sentence."}],
)
print(resp.choices[0].message.content)
```

That's it — every call is now tracked in the Tare dashboard, broken down by
the `feature` label you pass.

## Installation

```bash
# From the monorepo root (local dev)
pip install -e ./sdk

# Future PyPI release
pip install tare
```

## Configuration

| Env var | Default | Description |
|---|---|---|
| `TARE_PROXY_URL` | `http://localhost:8000` | Running Tare proxy base URL |

The `/v1` path suffix is appended automatically, so you never need to add it.

```python
# Override at call time — useful in staging / prod
llm = tare.client(
    api_key="sk-...",
    feature="summarizer",
    proxy_url="https://tare.internal",
)
```

## How it works

`tare.client()` returns a standard `openai.OpenAI` instance configured with:

- `base_url` → `<proxy_url>/v1`
- `default_headers` → `{"X-Tare-Feature": "<feature>"}`

The proxy forwards the request to OpenAI unchanged, records token usage, cost,
and latency against the feature label, then returns the original response.
Zero behaviour change for the caller.

## Running the test suite

```bash
# Requires the proxy running on localhost:8000
cd sdk
pip install -e ".[dev]"
pytest
```

> **Reminder:** Add a LICENSE file before publishing to PyPI.
