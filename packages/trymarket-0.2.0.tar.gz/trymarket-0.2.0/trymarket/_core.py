from __future__ import annotations

import httpx
from dataclasses import dataclass, field
from typing import Any, Optional

API_BASE = "https://try.market"


class TryMarketError(Exception):
    """Error returned by the try.market API."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


@dataclass
class TryMarketSession:
    """Validated try.market session."""

    user_id: str
    email: str
    handle: str
    product: str
    balance: int
    token: str


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _api_call(method: str, path: str, *, body: Optional[dict[str, Any]] = None, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Synchronous API call to try.market."""
    url = f"{API_BASE}{path}"
    with httpx.Client(timeout=15) as client:
        if method == "GET":
            resp = client.get(url, params=params)
        else:
            resp = client.post(url, json=body)
    data = resp.json()
    if resp.status_code >= 400:
        raise TryMarketError(
            code=data.get("code", "UNKNOWN"),
            message=data.get("message", resp.text),
        )
    return data


async def _async_api_call(method: str, path: str, *, body: Optional[dict[str, Any]] = None, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Asynchronous API call to try.market."""
    url = f"{API_BASE}{path}"
    async with httpx.AsyncClient(timeout=15) as client:
        if method == "GET":
            resp = await client.get(url, params=params)
        else:
            resp = await client.post(url, json=body)
    data = resp.json()
    if resp.status_code >= 400:
        raise TryMarketError(
            code=data.get("code", "UNKNOWN"),
            message=data.get("message", resp.text),
        )
    return data


# ---------------------------------------------------------------------------
# Public sync API
# ---------------------------------------------------------------------------

def validate_token(token: str) -> TryMarketSession:
    """Validate a try.market session token (sync)."""
    data = _api_call("POST", "/api/sdk/session/validate", body={"token": token})
    return TryMarketSession(
        user_id=data["userId"],
        email=data["email"],
        handle=data["handle"],
        product=data["product"],
        balance=data["balance"],
        token=token,
    )


def charge(session: TryMarketSession, amount: int, action: Optional[str] = None) -> int:
    """Charge the user's balance (sync). Returns new balance."""
    body: dict[str, Any] = {"token": session.token, "amount": amount}
    if action is not None:
        body["action"] = action
    data = _api_call("POST", "/api/sdk/session/charge", body=body)
    session.balance = data["balance"]
    return data["balance"]



# ---------------------------------------------------------------------------
# Public async API
# ---------------------------------------------------------------------------

async def async_validate_token(token: str) -> TryMarketSession:
    """Validate a try.market session token (async)."""
    data = await _async_api_call("POST", "/api/sdk/session/validate", body={"token": token})
    return TryMarketSession(
        user_id=data["userId"],
        email=data["email"],
        handle=data["handle"],
        product=data["product"],
        balance=data["balance"],
        token=token,
    )


async def async_charge(session: TryMarketSession, amount: int, action: Optional[str] = None) -> int:
    """Charge the user's balance (async). Returns new balance."""
    body: dict[str, Any] = {"token": session.token, "amount": amount}
    if action is not None:
        body["action"] = action
    data = await _async_api_call("POST", "/api/sdk/session/charge", body=body)
    session.balance = data["balance"]
    return data["balance"]


