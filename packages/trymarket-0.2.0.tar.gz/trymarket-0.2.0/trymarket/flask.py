"""Flask integration for try.market SDK."""
from __future__ import annotations

import functools
from typing import Any, Callable, Optional

import flask
from flask import Flask, Response, abort, g, request

from trymarket._core import (
    TryMarketError,
    TryMarketSession,
    charge as _charge,
    validate_token,
)


# ---------------------------------------------------------------------------
# Gate HTML
# ---------------------------------------------------------------------------

def _gate_html(code: str, message: str = "") -> str:
    display_message = message or "This app requires a valid try.market session."
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Access Denied</title>
<style>
  body {{ font-family: system-ui, sans-serif; display: flex; align-items: center;
         justify-content: center; min-height: 100vh; margin: 0; background: #fafafa; }}
  .gate {{ text-align: center; max-width: 420px; padding: 2rem; }}
  .gate h1 {{ font-size: 1.25rem; margin-bottom: 0.5rem; }}
  .gate p {{ color: #666; font-size: 0.95rem; }}
  .gate code {{ background: #eee; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
</style>
</head>
<body>
  <div class="gate">
    <h1>Access Denied</h1>
    <p>{display_message}</p>
    <p><code>{code}</code></p>
  </div>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Extension
# ---------------------------------------------------------------------------

class TryMarket:
    """Flask extension for try.market session management.

    Usage::

        app = Flask(__name__)
        tm = TryMarket(app)

    Or with the factory pattern::

        tm = TryMarket()
        tm.init_app(app)
    """

    def __init__(self, app: Optional[Flask] = None, gate_all: bool = True) -> None:
        self.gate_all = gate_all
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask) -> None:
        """Register the before_request hook on the Flask app."""
        app.before_request(self._before_request)

    def _before_request(self) -> Optional[Response]:
        """Validate the _tm token before each request."""
        # Read token from header, cookie, or query param
        token = (
            request.headers.get("X-TM-Token")
            or request.cookies.get("_tm_token")
            or request.args.get("_tm")
        )

        if not token:
            if self.gate_all:
                html = _gate_html("NO_TOKEN", "Missing session token. Open this app from try.market.")
                return Response(html, status=403, mimetype="text/html")
            g.trymarket = None
            return None

        try:
            session = validate_token(token)
        except TryMarketError as exc:
            html = _gate_html(exc.code, exc.message)
            return Response(html, status=403, mimetype="text/html")

        g.trymarket = session
        return None

    # -----------------------------------------------------------------------
    # Public helpers
    # -----------------------------------------------------------------------

    @staticmethod
    def session() -> TryMarketSession:
        """Get the current TryMarketSession from ``flask.g``.

        Aborts with 403 if no session is present.
        """
        sess: TryMarketSession | None = getattr(g, "trymarket", None)
        if sess is None:
            abort(403, description="No try.market session.")
        return sess

    @staticmethod
    def charge(amount: int, action: Optional[str] = None) -> Callable:
        """Decorator that charges the user before executing the view.

        Usage::

            @app.route("/generate")
            @tm.charge(10, action="generate")
            def generate():
                ...
        """
        def decorator(view_func: Callable) -> Callable:
            @functools.wraps(view_func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                sess: TryMarketSession | None = getattr(g, "trymarket", None)
                if sess is None:
                    abort(403, description="No try.market session.")
                try:
                    _charge(sess, amount, action)
                except TryMarketError as exc:
                    html = _gate_html(exc.code, exc.message)
                    return Response(html, status=402, mimetype="text/html")
                return view_func(*args, **kwargs)
            return wrapper
        return decorator

