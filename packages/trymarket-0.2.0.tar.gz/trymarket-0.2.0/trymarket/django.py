"""Django integration for try.market SDK."""
from __future__ import annotations

import functools
from typing import Any, Callable, Optional

from django.core.exceptions import PermissionDenied
from django.http import HttpRequest, HttpResponse

from trymarket._core import (
    TryMarketError,
    TryMarketSession,
    charge as _charge,
    validate_token,
)


# ---------------------------------------------------------------------------
# Gate HTML
# ---------------------------------------------------------------------------

def _gate_html(code: str, message: str = "") -> str:
    display_message = message or "This app requires a valid try.market session."
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Access Denied</title>
<style>
  body {{ font-family: system-ui, sans-serif; display: flex; align-items: center;
         justify-content: center; min-height: 100vh; margin: 0; background: #fafafa; }}
  .gate {{ text-align: center; max-width: 420px; padding: 2rem; }}
  .gate h1 {{ font-size: 1.25rem; margin-bottom: 0.5rem; }}
  .gate p {{ color: #666; font-size: 0.95rem; }}
  .gate code {{ background: #eee; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
</style>
</head>
<body>
  <div class="gate">
    <h1>Access Denied</h1>
    <p>{display_message}</p>
    <p><code>{code}</code></p>
  </div>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class TryMarketMiddleware:
    """Django middleware that validates the ``_tm`` query parameter.

    On success, sets ``request.trymarket`` to a ``TryMarketSession``.
    On failure, returns a gate HTML response.
    """

    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]) -> None:
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        # Read token from header, cookie, or query param
        token = (
            request.META.get("HTTP_X_TM_TOKEN")
            or request.COOKIES.get("_tm_token")
            or request.GET.get("_tm")
        )
        if not token:
            html = _gate_html("NO_TOKEN", "Missing session token. Open this app from try.market.")
            return HttpResponse(html, status=403, content_type="text/html")

        try:
            session = validate_token(token)
        except TryMarketError as exc:
            html = _gate_html(exc.code, exc.message)
            return HttpResponse(html, status=403, content_type="text/html")

        request.trymarket = session  # type: ignore[attr-defined]
        return self.get_response(request)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_trymarket_session(request: HttpRequest) -> TryMarketSession:
    """Get the validated TryMarketSession from a Django request.

    Raises ``PermissionDenied`` if no session is present.
    """
    session: TryMarketSession | None = getattr(request, "trymarket", None)
    if session is None:
        raise PermissionDenied("No try.market session. Is TryMarketMiddleware installed?")
    return session


def tm_charge(amount: int, action: Optional[str] = None) -> Callable:
    """Decorator factory that charges the user before executing the view.

    Usage::

        @tm_charge(10, action="generate")
        def my_view(request):
            ...
    """
    def decorator(view_func: Callable) -> Callable:
        @functools.wraps(view_func)
        def wrapper(request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse:
            session = get_trymarket_session(request)
            try:
                _charge(session, amount, action)
            except TryMarketError as exc:
                html = _gate_html(exc.code, exc.message)
                return HttpResponse(html, status=402, content_type="text/html")
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


def tm_required(view_func: Callable) -> Callable:
    """Decorator that ensures a valid try.market session exists on the request.

    Usage::

        @tm_required
        def my_view(request):
            session = get_trymarket_session(request)
            ...
    """
    @functools.wraps(view_func)
    def wrapper(request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse:
        session: TryMarketSession | None = getattr(request, "trymarket", None)
        if session is None:
            raise PermissionDenied("No try.market session.")
        return view_func(request, *args, **kwargs)
    return wrapper


