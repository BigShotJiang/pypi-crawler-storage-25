"""FastAPI integration for try.market SDK."""
from __future__ import annotations

from typing import Annotated, Optional

from fastapi import Depends, HTTPException, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from trymarket._core import (
    TryMarketError,
    TryMarketSession,
    async_charge as _async_charge,
    async_validate_token,
)


# ---------------------------------------------------------------------------
# Gate HTML
# ---------------------------------------------------------------------------

def _gate_html(code: str, message: str = "") -> str:
    """Simple HTML gate page shown when session validation fails."""
    display_message = message or "This app requires a valid try.market session."
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Access Denied</title>
<style>
  body {{ font-family: system-ui, sans-serif; display: flex; align-items: center;
         justify-content: center; min-height: 100vh; margin: 0; background: #fafafa; }}
  .gate {{ text-align: center; max-width: 420px; padding: 2rem; }}
  .gate h1 {{ font-size: 1.25rem; margin-bottom: 0.5rem; }}
  .gate p {{ color: #666; font-size: 0.95rem; }}
  .gate code {{ background: #eee; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
</style>
</head>
<body>
  <div class="gate">
    <h1>Access Denied</h1>
    <p>{display_message}</p>
    <p><code>{code}</code></p>
  </div>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class TryMarketMiddleware(BaseHTTPMiddleware):
    """Validates the _tm query parameter on every request.

    On success, sets ``request.state.trymarket`` to a ``TryMarketSession``.
    On failure, returns a gate HTML page.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Read token from header, cookie, or query param
        token = (
            request.headers.get("x-tm-token")
            or request.cookies.get("_tm_token")
            or request.query_params.get("_tm")
        )
        if not token:
            html = _gate_html("NO_TOKEN", "Missing session token. Open this app from try.market.")
            return Response(content=html, status_code=403, media_type="text/html")

        try:
            session = await async_validate_token(token)
        except TryMarketError as exc:
            html = _gate_html(exc.code, exc.message)
            return Response(content=html, status_code=403, media_type="text/html")

        request.state.trymarket = session
        return await call_next(request)


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------

async def tm_session(request: Request) -> TryMarketSession:
    """FastAPI dependency that returns the validated TryMarketSession.

    Requires ``TryMarketMiddleware`` to be installed.
    """
    session: TryMarketSession | None = getattr(request.state, "trymarket", None)
    if session is None:
        raise HTTPException(status_code=403, detail="No try.market session. Is TryMarketMiddleware installed?")
    return session


TmSession = Annotated[TryMarketSession, Depends(tm_session)]
"""Convenience type alias: ``session: TmSession`` in route signatures."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def charge(session: TryMarketSession, amount: int, action: Optional[str] = None) -> int:
    """Charge the user's balance. Raises HTTPException(402) on insufficient funds."""
    try:
        return await _async_charge(session, amount, action)
    except TryMarketError as exc:
        raise HTTPException(status_code=402, detail=exc.message) from exc
