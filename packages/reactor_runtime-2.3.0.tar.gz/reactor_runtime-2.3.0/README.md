# Reactor Runtime

A Python framework for building real-time, interactive video models. Write your ML code — Reactor handles networking, media transport, and client connections.

## Installation

```bash
pip install reactor-runtime
```

## Quick Example

```python
from dataclasses import dataclass
from reactor_runtime.interface import Output, Video, ReactorPipeline, InputState, InputField

@dataclass
class MyOutput(Output):
    video: Video

@dataclass
class MyState(InputState):
    prompt: str = InputField(default="a sunny meadow")

class MyModel(ReactorPipeline):
    state: MyState

    def load(self, config):
        self.pipe = load_my_model(config["checkpoint"])

    def inference(self):
        while True:
            frame = self.pipe.forward(prompt=self.state.prompt)
            yield MyOutput(video=frame)
```

Implement `inference()` as a generator that yields frames. Clients can update `self.state` mid-generation — no restart, no re-queue.

## Key Features

- **Real-time streaming** — frames delivered over WebRTC as they're generated
- **Live interaction** — clients change inputs mid-generation via typed, validated state
- **No transport code** — no WebRTC, WebSocket, or video encoding to manage
- **Scaffold & run** — `reactor init` creates a project; `reactor run` starts it locally
