"""
OTLP backend for profiler - exports timing data as histograms via OpenTelemetry.

Supports per-section histogram bucket boundaries via the OTEL advisory API.
When a section specifies ``bucket_boundaries``, a dedicated histogram is
created for that key with ``explicit_bucket_boundaries_advisory``, giving
fine-grained resolution where it matters without global Views.
"""

import threading
from typing import Dict, Optional, Sequence

from opentelemetry import metrics

from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class OTLPProfilerBackend(ProfilerBackend):
    """
    Profiler backend that exports timing data to OTLP as histograms.

    Uses the existing ReactorMachineMetrics infrastructure for OTLP configuration.
    Creates histogram metrics for section durations with attributes for filtering.

    Sections that provide ``bucket_boundaries`` get a dedicated histogram
    (``reactor_profiler_custom_{key}_ms``) with advisory bucket boundaries.
    All other sections share the default ``reactor_profiler_section_ms``
    histogram.
    """

    def __init__(self) -> None:
        """
        Initialize the OTLP profiler backend.

        Uses the global meter provider that should already be configured
        by ReactorMachineMetrics.
        """
        self._enabled = False
        self._meter: Optional[metrics.Meter] = None
        self._histogram: Optional[metrics.Histogram] = None
        self._custom_histograms: Dict[str, metrics.Histogram] = {}
        self._custom_boundaries: Dict[str, tuple] = {}
        self._histograms_lock = threading.Lock()
        self._machine_id: Optional[str] = None
        self._model_name: Optional[str] = None
        self._machine_info_refresh_attempted = False

        self._setup()

    def _setup(self) -> None:
        """Set up the OTLP histogram metric."""
        try:
            self._meter = metrics.get_meter(__name__)

            self._histogram = self._meter.create_histogram(
                name="reactor_profiler_section_ms",
                description="Duration of profiled code sections in milliseconds",
                unit="ms",
            )

            try:
                from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                    ReactorMachineMetrics,
                )

                self._machine_id = ReactorMachineMetrics.machine_id
                self._model_name = ReactorMachineMetrics.model_name
            except (ImportError, AttributeError):
                pass

            self._enabled = True
            logger.debug("OTLP profiler backend initialized")

        except Exception as e:
            logger.warning("Failed to set up OTLP profiler backend", error=e)
            self._enabled = False

    def _get_or_create_histogram(
        self, key: str, bucket_boundaries: Sequence[float]
    ) -> metrics.Histogram:
        """Return (or lazily create) a histogram for *key* with advisory boundaries.

        The histogram is created on first call for a given *key* and
        cached for subsequent calls.  If the same *key* is later passed
        with different *bucket_boundaries*, a one-shot warning is logged
        and the originally created histogram is reused — OTEL instruments
        are identified by name, so only the first advisory takes effect.

        Uses double-checked locking: the fast path (after first creation)
        is a lock-free dict lookup, so there is no contention overhead on
        the per-frame recording hot path.

        If ``self._meter`` is None (setup failed), falls back to the
        default histogram.
        """
        # Fast path: already created — no lock needed.
        # dict.__getitem__ is atomic under CPython's GIL.
        histogram = self._custom_histograms.get(key)
        if histogram is not None:
            return histogram

        # Slow path: first call for this key — acquire lock and create.
        meter = self._meter
        if meter is None:
            return self._histogram  # type: ignore[return-value]
        incoming = tuple(bucket_boundaries)
        with self._histograms_lock:
            # Re-check under lock (another thread may have created it).
            if key not in self._custom_histograms:
                self._custom_histograms[key] = meter.create_histogram(
                    name=f"reactor_profiler_custom_{key}_ms",
                    description=f"Duration of '{key}' profiled section in milliseconds",
                    unit="ms",
                    explicit_bucket_boundaries_advisory=list(bucket_boundaries),
                )
                self._custom_boundaries[key] = incoming
                logger.debug(
                    "Created custom histogram",
                    key=key,
                    boundaries=list(bucket_boundaries),
                )
            elif self._custom_boundaries.get(key) != incoming:
                logger.warning(
                    "bucket_boundaries mismatch for key '%s': "
                    "using originally registered boundaries, ignoring new ones",
                    key,
                    registered=list(self._custom_boundaries[key]),
                    requested=list(incoming),
                )
                self._custom_boundaries[key] = incoming  # suppress further warnings
            return self._custom_histograms[key]

    def _resource_attrs(self) -> dict:
        """Return resource attributes for metrics."""
        return {
            "machine_id": self._machine_id or "unknown",
            "model_name": self._model_name or "unknown",
        }

    def record(
        self,
        key: str,
        parent_path: str,
        full_path: str,
        duration: float,
        bucket_boundaries: Optional[Sequence[float]] = None,
    ) -> None:
        """
        Record a timing measurement to the OTLP histogram.

        Args:
            key: The section key (e.g., "vae_decode").
            parent_path: The path of parent sections (e.g., "inference/diffusion").
            full_path: The complete path including this section.
            duration: The duration in seconds (converted to milliseconds for export).
            bucket_boundaries: Optional bucket boundaries in ms. When
                provided, the measurement is routed to a dedicated
                histogram for *key* with these advisory boundaries.
        """
        if not self._enabled or self._histogram is None:
            return

        if self._machine_id is None and not self._machine_info_refresh_attempted:
            self._machine_info_refresh_attempted = True
            try:
                from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                    ReactorMachineMetrics,
                )

                self._machine_id = ReactorMachineMetrics.machine_id
                self._model_name = ReactorMachineMetrics.model_name
            except (ImportError, AttributeError):
                pass

        histogram_attributes = {
            "section_key": key,
            "parent_path": parent_path or "",
            "full_path": full_path,
            **self._resource_attrs(),
        }

        duration_ms = duration * 1000.0

        if bucket_boundaries is not None and self._meter is not None:
            histogram = self._get_or_create_histogram(key, bucket_boundaries)
            histogram.record(duration_ms, attributes=histogram_attributes)
        else:
            self._histogram.record(duration_ms, attributes=histogram_attributes)
