"""
Base protocol/interface for profiler backends.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Sequence


class ProfilerBackend(ABC):
    """
    Abstract base class for profiler backends.

    Backends are responsible for recording timing data and optionally
    flushing accumulated data to persistent storage.
    """

    @abstractmethod
    def record(
        self,
        key: str,
        parent_path: str,
        full_path: str,
        duration: float,
        bucket_boundaries: Optional[Sequence[float]] = None,
    ) -> None:
        """
        Record a timing measurement for a profiled section.

        Args:
            key: The section key (e.g., "vae_decode").
            parent_path: The path of parent sections (e.g., "inference/diffusion").
            full_path: The complete path including this section (e.g., "inference/diffusion/vae_decode").
            duration: The duration in seconds.
            bucket_boundaries: Optional histogram bucket boundaries in
                milliseconds. When provided, the OTLP backend creates a
                dedicated histogram for this key using
                ``explicit_bucket_boundaries_advisory``. Ignored by
                backends that store raw samples (e.g. file backend).
        """
        pass

    def flush(self, output_path: Optional[Path] = None) -> None:
        """
        Flush accumulated data to persistent storage.

        This is called at the end of a session. Not all backends need to implement this;
        the default implementation does nothing.

        Args:
            output_path: Optional path to write output to. Backend-specific.
        """
        pass

    def shutdown(self) -> None:
        """
        Shutdown the backend and release any resources.

        This is called when the runtime is shutting down. The default implementation
        does nothing.
        """
        pass
