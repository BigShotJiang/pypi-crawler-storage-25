# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Process-level profiler singleton.

The runtime calls :func:`set_profiler` once during startup to install
either a real :class:`Profiler` (with an OTLP or file backend) or a
:class:`NoOpProfiler`.  Model code and helper utilities retrieve it
with :func:`get_profiler`.

Before ``set_profiler`` is called, ``get_profiler()`` returns a
``NoOpProfiler`` so that instrumentation added at import-time is safe
and zero-cost.
"""

from __future__ import annotations

from reactor_runtime.profiling.profiler import NoOpProfiler, ProfilerType

_profiler: ProfilerType = NoOpProfiler()


def get_profiler() -> ProfilerType:
    """Return the process-level profiler instance.

    Always safe to call — returns a :class:`NoOpProfiler` if the
    runtime has not yet configured profiling.
    """
    return _profiler


def set_profiler(profiler: ProfilerType) -> None:
    """Install a profiler instance for the process.

    Called once by the runtime during initialisation.  Not intended
    for use by model authors.
    """
    global _profiler
    _profiler = profiler
