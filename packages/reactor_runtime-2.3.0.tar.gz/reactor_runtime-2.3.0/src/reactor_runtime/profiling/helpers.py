"""
Optional helper functions for easier profiling usage.

The primary API is ``get_profiler().section()``; these helpers are optional
sugar that delegate to it and do not change semantics.
"""

from functools import wraps
from typing import Callable, TypeVar

from reactor_runtime.profiling.profiler import CudaTimingMode
from reactor_runtime.profiling.singleton import get_profiler

T = TypeVar("T")


def profile_fn(
    section_name: str, cuda_timing: CudaTimingMode = CudaTimingMode.NONE
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator that wraps a function call in a profiler section.

    Uses the process-level profiler singleton from
    :func:`reactor_runtime.get_profiler`.  When profiling is disabled
    the singleton is a :class:`NoOpProfiler` and the overhead is
    negligible.
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            with get_profiler().section(section_name, cuda_timing=cuda_timing):
                return func(*args, **kwargs)

        return wrapper

    return decorator
