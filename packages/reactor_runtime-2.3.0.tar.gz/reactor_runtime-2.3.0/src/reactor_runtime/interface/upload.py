# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""File upload types for the model interface."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class UploadedFile:
    """Metadata and content of a file uploaded by the client.

    Delivered to the model's ``@file_uploaded`` handler by the runtime.
    """

    name: str
    """Original filename, e.g. ``"reference.jpg"``."""

    mime_type: str
    """MIME type, e.g. ``"image/jpeg"``."""

    size: int
    """File size in bytes."""

    data: bytes
    """Raw file content."""
