# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Handler collection and dispatch table construction.

Scans a model class's MRO for ``@connected``, ``@disconnected``,
``@file_uploaded``, and ``@event`` decorated methods and builds a
dispatch table used by :class:`ReactorModel`.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Tuple, Type

from reactor_runtime.interface.events.event import Event
from reactor_runtime.interface.model.decorators import (
    _CONNECTED_ATTR,
    _DISCONNECTED_ATTR,
    _EVENT_HANDLER_ATTR,
    _FILE_UPLOADED_ATTR,
    _IS_ASYNC_ATTR,
)


class EventEntry:
    """A single @event handler and its generated Event class."""

    __slots__ = ("handler", "event_cls", "name", "description", "is_async")

    def __init__(
        self,
        handler: Callable,
        event_cls: Type[Event],
        name: str,
        description: str,
        is_async: bool,
    ) -> None:
        self.handler = handler
        self.event_cls = event_cls
        self.name = name
        self.description = description
        self.is_async = is_async


class Handlers:
    """Resolved handler table for a concrete model subclass."""

    __slots__ = (
        "connected",
        "connected_is_async",
        "disconnected",
        "disconnected_is_async",
        "file_uploaded",
        "file_uploaded_is_async",
        "events",
    )

    def __init__(self) -> None:
        self.connected: Optional[Callable] = None
        self.connected_is_async: bool = False
        self.disconnected: Optional[Callable] = None
        self.disconnected_is_async: bool = False
        self.file_uploaded: Optional[Callable] = None
        self.file_uploaded_is_async: bool = False
        self.events: Dict[str, EventEntry] = {}


def collect_handlers(cls: type, skip_classes: tuple = ()) -> Handlers:
    """Scan the MRO (child-first) for decorated methods.

    Args:
        cls: The concrete model class to scan.
        skip_classes: Base classes to skip during the MRO walk
            (``object`` is always skipped).
    """
    skip = (object,) + skip_classes

    handlers = Handlers()
    seen_events: set[str] = set()

    for klass in cls.__mro__:
        if klass in skip:
            continue

        connected_in_class: List[Callable] = []
        disconnected_in_class: List[Callable] = []
        file_uploaded_in_class: List[Callable] = []

        for _attr_name, attr_value in vars(klass).items():
            if not callable(attr_value):
                continue

            if getattr(attr_value, _CONNECTED_ATTR, False):
                connected_in_class.append(attr_value)

            if getattr(attr_value, _DISCONNECTED_ATTR, False):
                disconnected_in_class.append(attr_value)

            if getattr(attr_value, _FILE_UPLOADED_ATTR, False):
                file_uploaded_in_class.append(attr_value)

            meta = getattr(attr_value, _EVENT_HANDLER_ATTR, None)
            if meta is not None and meta["name"] not in seen_events:
                handlers.events[meta["name"]] = EventEntry(
                    handler=attr_value,
                    event_cls=meta["event_cls"],
                    name=meta["name"],
                    description=meta["description"],
                    is_async=meta.get(
                        "is_async",
                        getattr(
                            attr_value,
                            _IS_ASYNC_ATTR,
                            False,
                        ),
                    ),
                )
                seen_events.add(meta["name"])

        if len(connected_in_class) > 1:
            raise TypeError(
                f"Multiple @connected handlers in {klass.__qualname__}: "
                f"{[f.__qualname__ for f in connected_in_class]}"
            )
        if len(disconnected_in_class) > 1:
            raise TypeError(
                f"Multiple @disconnected handlers in {klass.__qualname__}: "
                f"{[f.__qualname__ for f in disconnected_in_class]}"
            )
        if len(file_uploaded_in_class) > 1:
            raise TypeError(
                f"Multiple @file_uploaded handlers in {klass.__qualname__}: "
                f"{[f.__qualname__ for f in file_uploaded_in_class]}"
            )

        if connected_in_class and handlers.connected is None:
            handlers.connected = connected_in_class[0]
            handlers.connected_is_async = getattr(
                connected_in_class[0],
                _IS_ASYNC_ATTR,
                False,
            )
        if disconnected_in_class and handlers.disconnected is None:
            handlers.disconnected = disconnected_in_class[0]
            handlers.disconnected_is_async = getattr(
                disconnected_in_class[0],
                _IS_ASYNC_ATTR,
                False,
            )
        if file_uploaded_in_class and handlers.file_uploaded is None:
            handlers.file_uploaded = file_uploaded_in_class[0]
            handlers.file_uploaded_is_async = getattr(
                file_uploaded_in_class[0],
                _IS_ASYNC_ATTR,
                False,
            )

    return handlers


def build_dispatch_table(
    handlers: Handlers,
) -> List[Tuple[Type[Event], Callable, bool]]:
    """Build the (event_cls, handler, is_async) dispatch list from handlers."""
    return [
        (entry.event_cls, entry.handler, entry.is_async)
        for entry in handlers.events.values()
    ]
