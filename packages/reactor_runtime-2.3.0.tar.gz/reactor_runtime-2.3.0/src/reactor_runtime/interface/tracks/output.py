# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Output track schema — :class:`Output`.

Subclass :class:`Output` and annotate fields with :class:`Video` /
:class:`Audio` to declare the media tracks your model emits::

    @dataclass
    class GameOutput(Output):
        video: Video
        audio: Audio

    await self.emit(GameOutput(video=frame, audio=samples))
"""

from __future__ import annotations

import dataclasses
from typing import Any, ClassVar, Dict, Type

from reactor_runtime.interface.tracks.descriptors import (
    TRACK_MARKERS,
    resolve_annotations,
)

OUTPUT_REGISTRY: Dict[str, Type["Output"]] = {}


class Output:
    """Base class for output track bundles.

    Subclass and annotate fields with :class:`Video` or :class:`Audio`
    to define the media tracks your model sends to clients.  Construct
    instances with keyword arguments holding the media data
    (``np.ndarray``) and pass them to :meth:`emit`::

        @dataclass
        class GameOutput(Output):
            video: Video
            audio: Audio

        await self.emit(GameOutput(video=frame, audio=samples))
    """

    _tracks: ClassVar[Dict[str, type]]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        hints = resolve_annotations(cls)
        cls._tracks = {name: ann for name, ann in hints.items() if ann in TRACK_MARKERS}
        if cls._tracks:
            OUTPUT_REGISTRY[cls.__name__] = cls
            dataclasses.dataclass(cls)


def all_output_tracks() -> Dict[str, type]:
    """Union of all tracks across all registered Output subclasses."""
    result: Dict[str, type] = {}
    for cls in OUTPUT_REGISTRY.values():
        for name, marker in cls._tracks.items():
            result[name] = marker
    return result
