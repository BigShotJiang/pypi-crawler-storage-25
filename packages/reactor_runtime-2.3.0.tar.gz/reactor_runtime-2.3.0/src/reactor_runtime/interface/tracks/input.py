# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Input track schema — :class:`Input`.

Subclass :class:`Input` and annotate fields with :class:`Video` /
:class:`Audio` to declare the media tracks your model receives from
clients.  Annotate any attribute on your model with the subclass and
access buffers through that attribute::

    @dataclass
    class GameInput(Input):
        camera: Video

    class MyModel(ReactorPipeline):
        input: GameInput          # attribute name is your choice
        ...

        async def inference(self):
            [frame] = await self.input.camera.read(1)
"""

from __future__ import annotations

from typing import Any, ClassVar, Dict, Type

from reactor_runtime.interface.tracks.descriptors import (
    TRACK_MARKERS,
    resolve_annotations,
)

INPUT_REGISTRY: Dict[str, Type["Input"]] = {}


class Input:
    """Base class for input track schemas.

    Subclass and annotate fields with :class:`Video` or :class:`Audio`
    to define the media tracks your model receives from clients.
    Annotate any attribute on your model with the subclass — the
    runtime auto-detects it and populates it with live buffers::

        @dataclass
        class GameInput(Input):
            camera: Video

        class MyModel(ReactorPipeline):
            input: GameInput      # any name works

            async def inference(self):
                [frame] = await self.input.camera.read(1)
                frame   = self.input.camera.try_read()

    Each track buffer provides:

    - ``await read(n)`` — block until *n* frames are available.
    - ``try_read()`` — return the most recent frame without blocking.
    """

    _tracks: ClassVar[Dict[str, type]]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        hints = resolve_annotations(cls)
        cls._tracks = {name: ann for name, ann in hints.items() if ann in TRACK_MARKERS}
        if cls._tracks:
            INPUT_REGISTRY[cls.__name__] = cls


def all_input_tracks() -> Dict[str, type]:
    """Union of all tracks across all registered Input subclasses."""
    result: Dict[str, type] = {}
    for cls in INPUT_REGISTRY.values():
        for name, marker in cls._tracks.items():
            result[name] = marker
    return result
