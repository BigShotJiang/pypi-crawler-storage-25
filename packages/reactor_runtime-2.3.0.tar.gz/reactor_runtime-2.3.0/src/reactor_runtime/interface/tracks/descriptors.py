# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Track marker types — :class:`Video` and :class:`Audio`.

Use these as type annotations on :class:`Output` and :class:`Input`
subclasses to declare media tracks::

    @dataclass
    class GameOutput(Output):
        video: Video
        audio: Audio

    @dataclass
    class GameInput(Input):
        camera: Video

On :class:`Input` subclasses, each annotated field becomes a readable
track buffer with :meth:`read` and :meth:`try_read` methods.  Annotate
any attribute on the model with the ``Input`` subclass and access
buffers through it::

    [frame] = await self.input.camera.read(1)
"""

from __future__ import annotations

import typing
from typing import Any, Dict, Set, Type

from reactor_runtime.interface.internal.input_buffer import InputBuffer

TRACK_MARKERS: Set[Type] = set()


def resolve_annotations(cls: type) -> Dict[str, Any]:
    """Resolve annotations to real types, handling PEP 563 strings."""
    try:
        return typing.get_type_hints(cls)
    except Exception:
        return getattr(cls, "__annotations__", {})


class Video(InputBuffer):
    """Declares a video track.

    Use as a type annotation on :class:`Output` or :class:`Input`
    subclasses.  On input tracks, provides :meth:`read` and
    :meth:`try_read` for reading frames (``np.ndarray``, HWC, uint8).
    """

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        TRACK_MARKERS.add(cls)


class Audio(InputBuffer):
    """Declares an audio track.

    Use as a type annotation on :class:`Output` or :class:`Input`
    subclasses.  On input tracks, provides :meth:`read` and
    :meth:`try_read` for reading audio samples (``np.ndarray``).

    Attributes:
        sample_rate: Sample rate in Hz (default 48000).  Subclass
            to override (e.g. ``class Audio16k(Audio): sample_rate = 16_000``).
    """

    sample_rate: int = 48_000

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        TRACK_MARKERS.add(cls)


TRACK_MARKERS.update({Video, Audio})
