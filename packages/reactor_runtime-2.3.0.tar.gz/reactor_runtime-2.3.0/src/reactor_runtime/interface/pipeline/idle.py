# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
:data:`Idle` sentinel for the generator pipeline.

Yield ``Idle`` (or ``None``) from ``inference()`` to skip a frame::

    def inference(self):
        while True:
            if not self.ready:
                yield Idle
                continue
            yield MyOutput(video=self.pipe.forward())
"""

from __future__ import annotations


class _IdleType:
    """Type of the :data:`Idle` sentinel.  Do not instantiate directly."""

    _instance: _IdleType | None = None

    def __new__(cls) -> _IdleType:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "Idle"

    def __bool__(self) -> bool:
        return False


Idle: _IdleType = _IdleType()
