# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""StepResult — return type of ``next(PipelineExecutor)``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Union

from reactor_runtime.interface.events.messages import ModelMessage
from reactor_runtime.interface.pipeline.idle import _IdleType
from reactor_runtime.interface.tracks.output import Output


@dataclass
class StepResult:
    """Result of a single inference step.

    Attributes:
        output: The resolved :class:`Output` instance that the
            generator yielded, or :data:`Idle` when it yielded
            ``Idle`` or ``None``.
        compute_time: Wall-clock seconds spent inside the generator
            for this step (excludes transport and emission overhead).
        messages: :class:`ModelMessage` instances the model sent via
            ``self.send()`` during this step.
    """

    output: Union[Output, _IdleType]
    compute_time: float
    messages: List[ModelMessage] = field(default_factory=list)
