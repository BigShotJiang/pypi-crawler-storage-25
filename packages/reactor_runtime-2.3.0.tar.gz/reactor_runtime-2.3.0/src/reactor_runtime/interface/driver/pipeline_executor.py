# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""PipelineExecutor — programmatic step-by-step control of a ReactorPipeline."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Dict, Iterator, List, Optional, Type

from reactor_runtime.interface.driver.step_result import StepResult
from reactor_runtime.interface.events.messages import ModelMessage
from reactor_runtime.interface.model.handlers import Handlers, build_dispatch_table
from reactor_runtime.interface.defaults import validate_field
from reactor_runtime.interface.pipeline.idle import Idle
from reactor_runtime.interface.pipeline.reactor_pipeline import (
    GeneratorEnded,
    ReactorPipeline,
)


class PipelineExecutor(Iterator[StepResult]):
    """Execute a :class:`ReactorPipeline` step-by-step from synchronous code.

    Wraps any ``ReactorPipeline`` subclass and exposes a clean
    sequential API: ``connect()``, iteration via ``next()`` / ``for``,
    ``send_event()``, ``push_media()``, ``disconnect()``.
    No server, no transport, no background threads.

    Implements ``Iterator[StepResult]`` — each call to ``next(exe)``
    advances the inference generator by one ``yield``.  Iteration
    stops with ``StopIteration`` when no session is active.

    Each action returns the :class:`ModelMessage` instances the model
    sent via ``self.send()`` during that action, enabling deterministic
    assertions in tests and structured output capture in scripts.

    Example::

        with PipelineExecutor(EchoPipeline) as exe:
            exe.connect()
            exe.push_media("webcam", frame)
            for r in exe:
                if r.output is not Idle:
                    break
            msgs = exe.send_event("set_effect", effect="sepia")
            exe.disconnect()
    """

    def __init__(
        self,
        pipeline_cls: Type[ReactorPipeline],
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        # Instantiate the pipeline and run its one-time load().
        self._model: ReactorPipeline = pipeline_cls()
        self._model.load(config or {})

        # Build the handler dispatch table from @event / @connected /
        # @disconnected decorators discovered on the pipeline class.
        self._handlers: Handlers = self._model._get_handlers()
        self._dispatch_table = build_dispatch_table(self._handlers)

        # Private event loop — _advance() and some handlers are async,
        # so we need a loop.  Everything still runs on the caller's
        # thread; there are no background threads.
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._loop.run_until_complete(self._init())

        # Track whether inference() is sync or async so _advance()
        # uses the right iteration protocol (next vs __anext__).
        self._gen = None
        self._is_async_gen: bool = inspect.isasyncgenfunction(self._model.inference)
        self._model._async_inference = self._is_async_gen

        # Message capture — override send() to collect ModelMessage
        # instances instead of serializing them over transport.
        # _run() clears this list before every action so that
        # messages are scoped to the action that produced them.
        self._captured: List[ModelMessage] = []

        async def _capturing_send(message: ModelMessage) -> None:
            self._captured.append(message)

        self._model.send = _capturing_send  # type: ignore[assignment]

    async def _init(self) -> None:
        self._model._init_async()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def connect(self) -> List[ModelMessage]:
        """Begin a session.

        Creates a fresh :class:`InputState`, starts the ``inference()``
        generator, sets the ``connected`` signal, and fires the
        ``@connected`` handler if defined.

        Returns:
            Messages the model sent during the ``@connected`` handler.
        """
        if self._gen is not None:
            raise RuntimeError(
                "connect() called on an already-connected executor. "
                "Call disconnect() first."
            )
        return self._run(self._connect())

    def __iter__(self) -> Iterator[StepResult]:
        """Return self — PipelineExecutor is its own iterator."""
        return self

    def __next__(self) -> StepResult:
        """Advance the inference generator by one ``yield``.

        Returns:
            A :class:`StepResult` with the output, compute time, and
            any messages sent during this step.

        Raises:
            StopIteration: No active session (before ``connect()``
                or after ``disconnect()``).
        """
        if self._gen is None:
            raise StopIteration
        return self._run(self._step())

    def send_event(self, name: str, **kwargs: Any) -> List[ModelMessage]:
        """Deliver a named event to the model.

        Validates strictly before calling the handler:

        1. ``ValueError`` if the event name is unknown.
        2. ``TypeError`` if the kwargs don't match the event dataclass.
        3. ``ValueError`` if an ``InputField`` constraint is violated.

        Returns:
            Messages the model sent during the event handler.
        """
        entry = self._handlers.events.get(name)
        if entry is None:
            available = sorted(self._handlers.events.keys())
            raise ValueError(f"Unknown event {name!r}. Available events: {available}")

        try:
            entry.event_cls(**kwargs)
        except TypeError as exc:
            raise TypeError(f"Invalid arguments for event {name!r}: {exc}") from None

        field_infos: Dict = getattr(entry.event_cls, "_field_infos", {})
        for field_name, info in field_infos.items():
            if field_name in kwargs:
                ok, reason = validate_field(field_name, kwargs[field_name], info)
                if not ok:
                    raise ValueError(f"Validation failed for event {name!r}: {reason}")

        return self._run(self._send_event(entry, **kwargs))

    def push_media(self, track_name: str, data: Any) -> None:
        """Push a media frame into an input buffer.

        The frame becomes available to the model on the next
        iteration when ``inference()`` calls ``try_read()`` or
        ``read()``.
        """
        self._model._push_media(track_name, data)

    def disconnect(self) -> List[ModelMessage]:
        """End the current session.

        Clears the ``connected`` signal, fires the ``@disconnected``
        handler, closes the generator, and resets state and buffers.

        Returns:
            Messages the model sent during the ``@disconnected`` handler.
        """
        if self._gen is None:
            raise RuntimeError(
                "disconnect() called without an active session. Call connect() first."
            )
        return self._run(self._disconnect())

    @property
    def state(self):
        """The current session state, or ``None`` if no session is active."""
        return self._model.state

    def close(self) -> None:
        """Shut down the executor.

        Disconnects if a session is active and closes the event loop.
        """
        try:
            if self._gen is not None:
                self._run(self._disconnect())
        finally:
            if not self._loop.is_closed():
                self._loop.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Async implementations
    #
    # Each method below is the async core of a public API method.
    # The public wrappers delegate to these via _run(), which clears
    # captured messages and runs the coroutine synchronously with
    # run_until_complete().
    # ------------------------------------------------------------------

    async def _connect(self) -> List[ModelMessage]:
        """Create a fresh InputState, start inference(), fire @connected."""
        self._model.state = self._model._state_cls()
        self._gen = self._model.inference()
        self._model.connected.set()
        await self._fire_handler(
            self._handlers.connected,
            self._handlers.connected_is_async,
        )
        return list(self._captured)

    async def _step(self) -> StepResult:
        """Advance the inference generator by one ``yield``.

        On ``GeneratorEnded`` the generator is restarted automatically
        (same behavior as the production run-loop) and ``Idle`` is
        returned for that tick.
        """
        try:
            output, compute_time = await self._model._advance(
                self._gen, self._is_async_gen
            )
        except GeneratorEnded:
            self._gen = self._model.inference()
            return StepResult(
                output=Idle, compute_time=0.0, messages=list(self._captured)
            )
        return StepResult(
            output=output,
            compute_time=compute_time,
            messages=list(self._captured),
        )

    async def _send_event(self, entry: Any, **kwargs: Any) -> List[ModelMessage]:
        """Dispatch a validated event to its handler function."""
        await self._fire_handler(entry.handler, entry.is_async, **kwargs)
        return list(self._captured)

    async def _disconnect(self) -> List[ModelMessage]:
        """Clear connected, fire @disconnected, close generator, reset state."""
        self._model.connected.clear()
        await self._fire_handler(
            self._handlers.disconnected,
            self._handlers.disconnected_is_async,
        )
        if self._gen is not None:
            if self._is_async_gen:
                await self._gen.aclose()
            else:
                self._gen.close()
            self._gen = None
        self._model.state = None
        for buf in self._model._input_buffers.values():
            buf.reset()
        return list(self._captured)

    # ------------------------------------------------------------------
    # Infrastructure
    # ------------------------------------------------------------------

    async def _fire_handler(
        self,
        handler: Any,
        is_async: bool,
        **kwargs: Any,
    ) -> None:
        """Call a lifecycle or event handler, dispatching sync/async."""
        if handler is None:
            return
        if is_async:
            await handler(self._model, **kwargs)
        else:
            handler(self._model, **kwargs)

    def _run(self, coro: Any) -> Any:
        """Clear captured messages then run *coro* synchronously.

        The clear-before-run pattern scopes messages: each public
        action sees only the messages produced during that action.
        """
        self._captured.clear()
        return self._loop.run_until_complete(coro)
