# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Field metadata and default-value validation primitives.

Single home for the types and helpers that both :class:`Event` /
:class:`ModelMessage` base classes and their user-facing surfaces
(:func:`~reactor_runtime.interface.model.decorators.event`,
:class:`~reactor_runtime.interface.pipeline.input_state.InputState`,
:class:`~reactor_runtime.interface.events.messages.MessageField`)
share to validate user-supplied defaults.

Exports :class:`FieldInfo`, :func:`InputField`, :func:`validate_field`,
:func:`raise_if_default_invalid`, :func:`raise_if_default_not_static`,
and :func:`field_info_to_json_schema`. Re-exported from
``reactor_runtime.interface`` and ``reactor_runtime`` as part of the
public API.

Lives one level above ``interface.model`` so the base classes in
``interface.events`` can consume it without cycling back through
``interface.model.__init__``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

_NO_DEFAULT = object()

_MUTABLE_DEFAULT_TYPES = (list, dict, set)


# ---------------------------------------------------------------------
# FieldInfo + InputField — the user-facing declaration of a field's
# default value and validation constraints.
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class FieldInfo:
    """Validation constraints for a single input field.

    Create instances via :func:`InputField` rather than directly.
    When no default is provided, ``default`` is :data:`_NO_DEFAULT`.
    """

    default: Any = _NO_DEFAULT
    description: Optional[str] = None
    ge: Optional[Union[int, float]] = None
    le: Optional[Union[int, float]] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    choices: Optional[List[Any]] = None


def InputField(
    default: Any = _NO_DEFAULT,
    *,
    default_factory: Any = None,
    description: Optional[str] = None,
    ge: Optional[Union[int, float]] = None,
    le: Optional[Union[int, float]] = None,
    min_length: Optional[int] = None,
    max_length: Optional[int] = None,
    choices: Optional[List[Any]] = None,
) -> Any:
    """Declare a default value and validation constraints for a field.

    Use as the default value for ``@event`` handler parameters or
    :class:`~reactor_runtime.interface.pipeline.input_state.InputState`
    fields.  Values that violate constraints are rejected before
    reaching the handler (logged at debug level, the event is dropped).

    Args:
        default: Default value for the field.
        default_factory: Not supported; raises ``TypeError``. Defaults
            must be statically representable — use a literal ``default=...``.
        description: Human-readable description (exposed in capabilities).
        ge: Minimum allowed value (inclusive).
        le: Maximum allowed value (inclusive).
        min_length: Minimum length for string/sequence values.
        max_length: Maximum length for string/sequence values.
        choices: Exhaustive list of allowed values.
    """
    if default_factory is not None:
        raise TypeError(
            "InputField(default_factory=...) is not supported. "
            "Defaults must be statically representable — use a literal `default=...`."
        )
    return FieldInfo(
        default=default,
        description=description,
        ge=ge,
        le=le,
        min_length=min_length,
        max_length=max_length,
        choices=choices,
    )


# ---------------------------------------------------------------------
# Static-default check — rejects mutable containers, the one guardrail
# every entry point funnels through.
# ---------------------------------------------------------------------


def raise_if_default_not_static(owner: str, field_name: str, default: Any) -> None:
    """Raise ``TypeError`` when *default* is a mutable container.

    Defaults must be statically representable. Mutable containers
    (``list`` / ``dict`` / ``set``) would be shared across every
    instance and produce surprising cross-session state leaks — the
    same reason Python's ``dataclasses`` forbids ``field(default=[])``.
    Users who need a per-instance container should use ``default=None``
    and initialise inside the handler, or an immutable alternative like
    ``tuple`` / ``frozenset``.

    ``None`` is the canonical "unset" sentinel for Optional fields and
    is always allowed.
    """
    if default is None:
        return
    if isinstance(default, _MUTABLE_DEFAULT_TYPES):
        raise TypeError(
            f"{owner}: default for '{field_name}' is a mutable "
            f"{type(default).__name__} which can't be used as a static default. "
            "Defaults must be statically representable — use `default=None` and "
            "initialise inside the handler, or an immutable alternative "
            "(tuple, frozenset)."
        )


# ---------------------------------------------------------------------
# FieldInfo-aware validation — constraints + static-default check.
# ---------------------------------------------------------------------


def validate_field(name: str, value: Any, info: FieldInfo) -> Tuple[bool, str]:
    """Validate *value* against its :class:`FieldInfo` constraints.

    Returns ``(True, "")`` if valid, ``(False, reason)`` if not.
    """
    if info.choices is not None and value not in info.choices:
        return False, f"{name}: {value!r} not in choices {info.choices}"

    if info.ge is not None:
        try:
            if value < info.ge:
                return False, f"{name}: {value} < ge({info.ge})"
        except TypeError:
            return False, f"{name}: {value!r} is not comparable to ge({info.ge})"

    if info.le is not None:
        try:
            if value > info.le:
                return False, f"{name}: {value} > le({info.le})"
        except TypeError:
            return False, f"{name}: {value!r} is not comparable to le({info.le})"

    if info.min_length is not None:
        try:
            if len(value) < info.min_length:
                return (
                    False,
                    f"{name}: length {len(value)} < min_length({info.min_length})",
                )
        except TypeError:
            return (
                False,
                f"{name}: {value!r} has no length for min_length({info.min_length})",
            )

    if info.max_length is not None:
        try:
            if len(value) > info.max_length:
                return (
                    False,
                    f"{name}: length {len(value)} > max_length({info.max_length})",
                )
        except TypeError:
            return (
                False,
                f"{name}: {value!r} has no length for max_length({info.max_length})",
            )

    return True, ""


def raise_if_default_invalid(
    owner: str, field_name: str, default: Any, info: FieldInfo
) -> None:
    """Raise ``TypeError`` when *default* is unusable for *field_name*.

    Single source of truth for decoration-time / class-creation-time
    checks on ``InputField`` defaults. Runs two checks in order:

    1. The default must be statically representable (no mutable
       containers) — delegated to :func:`raise_if_default_not_static`.
    2. The default must satisfy its own ``info`` constraints
       (``choices`` / ``ge`` / ``le`` / ``min_length`` / ``max_length``).

    Bypasses both checks for the ``_NO_DEFAULT`` sentinel and for
    explicit ``None`` (the "unset" value for Optional fields).
    """
    if default is _NO_DEFAULT or default is None:
        return
    raise_if_default_not_static(owner, field_name, default)
    ok, reason = validate_field(field_name, default, info)
    if not ok:
        raise TypeError(
            f"{owner}: default value for '{field_name}' violates "
            f"its own InputField constraints ({reason})."
        )


def field_info_to_json_schema(schema: Dict[str, Any], info: FieldInfo) -> None:
    """Merge :class:`FieldInfo` constraints into a JSON Schema dict."""
    if info.description:
        schema["description"] = info.description
    if info.ge is not None:
        schema["minimum"] = info.ge
    if info.le is not None:
        schema["maximum"] = info.le
    if info.min_length is not None:
        schema["minLength"] = info.min_length
    if info.max_length is not None:
        schema["maxLength"] = info.max_length
    if info.choices is not None:
        schema["enum"] = info.choices
