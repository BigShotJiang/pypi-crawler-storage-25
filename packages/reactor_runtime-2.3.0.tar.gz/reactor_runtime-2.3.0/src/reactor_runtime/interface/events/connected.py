# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Built-in lifecycle events — :class:`Connected` and :class:`Disconnected`."""

from __future__ import annotations

from dataclasses import dataclass

from reactor_runtime.interface.events.event import Event


@dataclass
class Connected(Event, internal=True):  # type: ignore[call-arg]
    """Fired when a client connects to the session.

    Handle with the ``@connected`` decorator on your model method.
    This is a lifecycle event pushed by the runtime — clients cannot
    trigger it via the data channel.
    """


@dataclass
class Disconnected(Event, internal=True):  # type: ignore[call-arg]
    """Fired when a client disconnects from the session.

    Handle with the ``@disconnected`` decorator on your model method.
    This is a lifecycle event pushed by the runtime — clients cannot
    trigger it via the data channel.
    """
