# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Typed outbound messages — :class:`ModelMessage`.

Subclass :class:`ModelMessage` to define typed messages your model
sends to the client via :meth:`send`::

    @dataclass
    class CurrentMode(ModelMessage):
        mode: str

    await self.send(CurrentMode(mode="turbo"))

The client receives::

    {"type": "current_mode", "data": {"mode": "turbo"}}

Use :func:`MessageField` to add descriptions to fields::

    @dataclass
    class Progress(ModelMessage):
        step: int = MessageField(description="Current step number")
        total: int = MessageField(description="Total steps")
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, Optional, Type

from reactor_runtime.interface.defaults import raise_if_default_not_static
from reactor_runtime.interface.events.event import _pascal_to_snake

MESSAGE_REGISTRY: Dict[str, Type["ModelMessage"]] = {}

_NO_DEFAULT = object()


@dataclass(frozen=True)
class MessageFieldInfo:
    """Metadata for a single outbound message field.

    Create instances via :func:`MessageField` rather than directly.
    """

    default: Any = _NO_DEFAULT
    description: Optional[str] = None


def MessageField(
    default: Any = _NO_DEFAULT,
    *,
    default_factory: Any = None,
    description: Optional[str] = None,
) -> Any:
    """Declare a default value and description for a message field.

    Use as the default value for :class:`ModelMessage` fields.
    The ``description`` is included in the OpenAPI webhook schema.

    Args:
        default: Default value for the field.
        default_factory: Not supported; raises ``TypeError``. Defaults
            must be statically representable — use a literal ``default=...``.
        description: Human-readable description (exposed in the schema).
    """
    if default_factory is not None:
        raise TypeError(
            "MessageField(default_factory=...) is not supported. "
            "Defaults must be statically representable — use a literal `default=...`."
        )
    return MessageFieldInfo(default=default, description=description)


class ModelMessage:
    """Base class for typed outbound messages from model to client.

    Subclass with dataclass fields to define a message type.  Send
    instances via ``await self.send(MyMessage(...))``.  The message
    is delivered to the client as JSON with ``type`` and ``data``
    keys.

    Example::

        @dataclass
        class Progress(ModelMessage):
            step: int = MessageField(description="Current step number")
            total: int = MessageField(description="Total steps")

        await self.send(Progress(step=42, total=100))
    """

    name: ClassVar[str]
    _field_descriptions: ClassVar[Dict[str, str]]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)

        descriptions: Dict[str, str] = {}
        has_default: list[str] = []
        no_default: list[str] = []

        for attr_name in list(getattr(cls, "__annotations__", {})):
            raw = cls.__dict__.get(attr_name, _NO_DEFAULT)
            if isinstance(raw, dataclasses.Field):
                raise TypeError(
                    f"{cls.__qualname__}.{attr_name}: "
                    f"`dataclasses.field(...)` is not supported on "
                    f"ModelMessage subclasses — use "
                    f"`MessageField(default=..., description=...)`. "
                    f"Message defaults must be static."
                )
            if isinstance(raw, MessageFieldInfo):
                if raw.description:
                    descriptions[attr_name] = raw.description
                if raw.default is not _NO_DEFAULT:
                    raise_if_default_not_static(
                        cls.__qualname__, attr_name, raw.default
                    )
                    setattr(cls, attr_name, raw.default)
                    has_default.append(attr_name)
                else:
                    if hasattr(cls, attr_name):
                        delattr(cls, attr_name)
                    no_default.append(attr_name)
            elif raw is _NO_DEFAULT:
                no_default.append(attr_name)
            else:
                raise_if_default_not_static(cls.__qualname__, attr_name, raw)
                has_default.append(attr_name)

        annotations = cls.__annotations__
        reordered = {k: annotations[k] for k in no_default + has_default}
        cls.__annotations__ = reordered
        cls._field_descriptions = descriptions

        if not dataclasses.is_dataclass(cls):
            dataclasses.dataclass(cls)
        msg_name = cls._message_name()
        MESSAGE_REGISTRY[msg_name] = cls
        if "name" not in cls.__dict__:
            cls.name = msg_name

    @classmethod
    def _message_name(cls) -> str:
        return _pascal_to_snake(cls.__name__)

    def to_wire_format(self) -> Dict[str, Any]:
        """Serialise into the ``{"type": "<name>", "data": {...}}`` wire envelope."""
        data: Dict[str, Any] = {}
        if dataclasses.is_dataclass(self):
            for f in dataclasses.fields(self):
                data[f.name] = getattr(self, f.name)
        return {"type": self.name, "data": data}
