# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Event base class — :class:`Event`.

Subclass :class:`Event` to define typed events that clients can send
to your model.  Each subclass is automatically registered under its
``snake_case`` name (e.g. ``SetBrightness`` → ``"set_brightness"``).

Every pathway that creates an Event subclass — direct
``@dataclass class Foo(Event)`` declarations as well as the
:func:`~reactor_runtime.interface.model.decorators.event` decorator
(which synthesises a subclass from a method signature via
``make_dataclass``) — converges on :meth:`Event.__init_subclass__`.
All field-level validation lives there: supported-type checks, static
default checks, :class:`~reactor_runtime.interface.defaults.FieldInfo`
unwrapping, and :class:`~reactor_runtime.interface.upload.UploadedFile`
detection.  The decorator stays deliberately thin.
"""

from __future__ import annotations

import dataclasses
import enum
import re
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Set,
    Type,
    get_args,
    get_origin,
    get_type_hints,
)

from reactor_runtime.interface.defaults import (
    _NO_DEFAULT,
    FieldInfo,
    raise_if_default_invalid,
    raise_if_default_not_static,
)
from reactor_runtime.interface.upload import UploadedFile
from reactor_runtime.utils.typing import unwrap_optional

EVENT_REGISTRY: Dict[str, Type["Event"]] = {}

_PASCAL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")

_PRIMITIVE_TYPES = (int, float, str, bool)


def _pascal_to_snake(name: str) -> str:
    return _PASCAL_RE.sub("_", name).lower()


def _snake_to_pascal(name: str) -> str:
    return "".join(word.capitalize() for word in name.split("_"))


# ---------------------------------------------------------------------
# Type-support predicate + UploadedFile detector.
# Shared between the Event base class (validation) and the @event
# decorator (re-exported for existing tests and callers).
# ---------------------------------------------------------------------


def _is_supported_event_type(raw_type: Any) -> bool:
    """Return True if *raw_type* is an accepted Event field type.

    Supported: ``int``, ``float``, ``str``, ``bool``, ``Literal[...]``,
    ``Optional[T]`` (where ``T`` is supported), ``List[T]``,
    ``Dict[K,V]``, :class:`enum.Enum` subclasses, dataclasses, and
    :class:`~reactor_runtime.interface.upload.UploadedFile`.
    """
    inner = unwrap_optional(raw_type)
    if inner is not None:
        return _is_supported_event_type(inner)

    origin = get_origin(raw_type)

    if origin is Literal:
        return True

    if origin is list or origin is List:
        args = get_args(raw_type)
        if args:
            return _is_supported_event_type(args[0])
        return True

    if origin is dict or origin is Dict:
        args = get_args(raw_type)
        if args and len(args) == 2:
            return _is_supported_event_type(args[1])
        return True

    if isinstance(raw_type, type):
        if raw_type in _PRIMITIVE_TYPES:
            return True
        if raw_type is list or raw_type is dict:
            return True
        if raw_type is UploadedFile:
            return True
        if issubclass(raw_type, enum.Enum):
            return True
        if dataclasses.is_dataclass(raw_type):
            return True

    return False


def _is_uploaded_file(raw_type: Any) -> bool:
    """Return ``True`` if *raw_type* is ``UploadedFile`` or ``Optional[UploadedFile]``."""
    if raw_type is UploadedFile:
        return True
    inner = unwrap_optional(raw_type)
    return inner is UploadedFile


def _is_classvar(raw_type: Any) -> bool:
    """Return True if *raw_type* is ``typing.ClassVar[...]`` (or the bare alias)."""
    return get_origin(raw_type) is ClassVar or raw_type is ClassVar


# ---------------------------------------------------------------------
# Class-creation-time validation walk.
# Runs before ``dataclasses.dataclass(cls)`` is applied so we can
# (a) emit clean errors for mutable defaults / unsupported types
# before Python's own dataclass machinery trips, and
# (b) unwrap FieldInfo defaults so ``@dataclass`` never sees them.
# ---------------------------------------------------------------------


def _process_event_class(cls: type) -> None:
    """Validate annotations / defaults and stamp Event metadata.

    Runs once per Event subclass from :meth:`Event.__init_subclass__`.
    After this returns, ``cls`` is ready for
    ``dataclasses.dataclass(cls)``: every public annotated attribute
    holds a raw default (or is missing, for required fields), all
    :class:`FieldInfo` wrappers have been lifted onto
    ``cls._field_infos``, and
    :class:`~reactor_runtime.interface.upload.UploadedFile` fields are
    recorded in ``cls._upload_fields``.
    """
    annotations: Dict[str, Any] = getattr(cls, "__annotations__", {})
    if not annotations:
        return

    try:
        hints = get_type_hints(cls)
    except Exception:
        hints = {}

    field_infos: Dict[str, FieldInfo] = {}
    upload_fields: Set[str] = set()
    owner = cls.__qualname__

    has_default: List[str] = []
    no_default: List[str] = []

    for name in list(annotations):
        ann = hints.get(name, annotations[name])

        if _is_classvar(ann):
            continue

        if ann is not Any and not _is_supported_event_type(ann):
            raise TypeError(
                f"{owner}: field '{name}' has unsupported type {ann!r}. "
                f"Supported: int, float, str, bool, Literal[...], Optional[T], "
                f"List[T], Dict[K,V], Enum, dataclass, UploadedFile."
            )

        if _is_uploaded_file(ann):
            upload_fields.add(name)

        raw = cls.__dict__.get(name, _NO_DEFAULT)

        if isinstance(raw, dataclasses.Field):
            raise TypeError(
                f"{owner}.{name}: `dataclasses.field(...)` is not supported on "
                "Event subclasses — use `InputField(default=..., ...)`. "
                "Event defaults must be static."
            )

        if isinstance(raw, FieldInfo):
            field_infos[name] = raw
            raise_if_default_invalid(owner, name, raw.default, raw)
            if raw.default is _NO_DEFAULT:
                if hasattr(cls, name):
                    delattr(cls, name)
                no_default.append(name)
            else:
                setattr(cls, name, raw.default)
                has_default.append(name)
        elif raw is _NO_DEFAULT:
            no_default.append(name)
        else:
            raise_if_default_not_static(owner, name, raw)
            has_default.append(name)

    # Reorder annotations so fields without defaults come first —
    # ``@dataclass`` otherwise refuses classes that mix the two.
    if no_default and has_default:
        cls.__annotations__ = {k: annotations[k] for k in no_default + has_default}

    if field_infos:
        cls._field_infos = field_infos  # type: ignore[attr-defined]
    if upload_fields:
        cls._upload_fields = upload_fields  # type: ignore[attr-defined]


class Event:
    """Base class for all inbound events from client to model.

    Subclass to define a typed event.  The event is registered under
    its ``snake_case`` name (e.g. ``SetBrightness`` →
    ``"set_brightness"``), which is the string the client sends as
    the event ``type``.

    In most cases you don't subclass ``Event`` directly — use the
    ``@event`` decorator on a handler method instead, which creates
    the event class from the method signature automatically.
    """

    name: ClassVar[str]

    def __init_subclass__(cls, *, internal: bool = False, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if not internal:
            _process_event_class(cls)
        if not dataclasses.is_dataclass(cls):
            dataclasses.dataclass(cls)
        if internal:
            return
        event_name = cls._event_name()
        EVENT_REGISTRY[event_name] = cls
        if "name" not in cls.__dict__:
            cls.name = event_name

    @classmethod
    def _event_name(cls) -> str:
        return _pascal_to_snake(cls.__name__)
