# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Built-in file upload lifecycle event — :class:`FileUploaded`."""

from __future__ import annotations

from dataclasses import dataclass

from reactor_runtime.interface.events.event import Event
from reactor_runtime.interface.upload import UploadedFile


@dataclass
class FileUploaded(Event, internal=True):  # type: ignore[call-arg]
    """Fired when an uploaded file has been downloaded and is ready.

    Handle with the ``@file_uploaded`` decorator on your model method.
    This is a lifecycle event pushed by the runtime — clients cannot
    trigger it via the data channel.
    """

    file: UploadedFile
