# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Internal — :class:`InputBuffer` backing each inbound media track.

Model authors interact with input buffers through the :class:`Input`
track handles (e.g. ``await GameInput.camera.read(1)``), not by
using this class directly.

Threading model::

    Runtime thread               Model thread
    ──────────────               ────────────
    _push(data)  ──────────────► read() / try_read()
                                 close()  → BufferClosed raised
                                 reset()  (between sessions)

All methods are thread-safe (guarded by a shared
:class:`threading.Condition`).
"""

from __future__ import annotations

import asyncio
import threading
from collections import deque
from enum import Enum, auto
from typing import List, Optional

import numpy as np


class ReadMode(Enum):
    """Controls which frames are returned when reading from an input buffer.

    - ``FIFO``: oldest *n* frames (consumed in arrival order).
    - ``LATEST``: newest *n* frames (older backlog is discarded).
    """

    FIFO = auto()
    LATEST = auto()


class BufferClosed(Exception):
    """Raised when reading from an input track after the client disconnects.

    In :class:`ReactorPipeline`, this is caught automatically — the
    generator exits cleanly.  In :class:`ReactorModel`, you may catch
    it in your ``run()`` loop to handle disconnection.

    Raised by :meth:`InputBuffer.read` and :meth:`InputBuffer.try_read`.
    """


DEFAULT_BUFFER_CAPACITY: int = 128
"""Default maximum number of frames an :class:`InputBuffer` can hold."""


class InputBuffer:
    """Thread-safe ring buffer for a single inbound media track.

    "Input" is from the **model's point of view**: data flows
    *from the client into the model*.

    Accessed via :class:`Input` track handles — model authors never
    instantiate this class directly.

    Read API:

    - :meth:`read` — async, blocks until *n* frames are available.
    - :meth:`try_read` — sync, returns immediately (latest frame or
      ``None``).

    Lifecycle:

    - :meth:`close` — signal end-of-input (raises :class:`BufferClosed`
      in blocked readers).
    - :meth:`reset` — re-open for a new session.

    The buffer is a bounded :class:`~collections.deque`.  When full,
    the oldest frame is silently evicted — the model always sees the
    most recent data.

    Args:
        maxlen: Maximum number of frames the buffer can hold.
            Older frames are evicted when this limit is reached.
    """

    def __init__(self, maxlen: int = DEFAULT_BUFFER_CAPACITY) -> None:
        # _condition wraps _lock — they are the SAME underlying mutex.
        # `with self._lock` for simple acquire/release (try_read, properties).
        # `with self._condition` when we also need wait/notify (_read, _push, close).
        # Only one lock exists, so no lock-ordering deadlocks are possible.
        self._lock = threading.Lock()
        self._condition = threading.Condition(self._lock)

        self._buffer: deque[np.ndarray] = deque(maxlen=maxlen)
        self._total_received: int = 0
        self._closed: bool = False

    # ------------------------------------------------------------------
    # Read API (model thread)
    # ------------------------------------------------------------------

    async def read(
        self,
        n: int = 1,
        timeout: Optional[float] = None,
        mode: ReadMode = ReadMode.LATEST,
    ) -> List[np.ndarray]:
        """Return *n* frames, waiting if necessary.

        Blocks the calling coroutine (via ``asyncio.to_thread``) until
        at least *n* frames are present in the buffer, then returns
        exactly *n* according to *mode*.  While blocked, the model's
        event loop remains responsive — ``@event`` handlers and the
        dispatcher continue to run.

        Typical usage::

            frames = await self.input.camera.read(4)               # newest 4
            frames = await self.input.camera.read(4, mode=ReadMode.FIFO)  # oldest 4

        Args:
            n: Number of frames to return.
            timeout: Maximum seconds to wait.  ``None`` waits
                indefinitely.
            mode: :attr:`ReadMode.LATEST` (default) returns the *n*
                newest frames and discards any older backlog.
                :attr:`ReadMode.FIFO` returns the *n* oldest frames,
                leaving newer frames in the buffer.

        Returns:
            A list of *n* ``np.ndarray`` frames (HWC, uint8).

        Raises:
            BufferClosed: The client disconnected while waiting.
            TimeoutError: *timeout* expired before *n* frames arrived.
            ValueError: *n* exceeds the buffer capacity (``maxlen``).
        """
        return await asyncio.to_thread(self._read, n, timeout, mode)

    def _read(
        self,
        n: int,
        timeout: Optional[float],
        mode: ReadMode = ReadMode.LATEST,
    ) -> List[np.ndarray]:
        if self._buffer.maxlen is not None and n > self._buffer.maxlen:
            raise ValueError(
                f"Requested {n} frames but buffer capacity is {self._buffer.maxlen}. "
                "Pass a larger maxlen to InputBuffer."
            )
        with self._condition:
            if not self._condition.wait_for(
                lambda: len(self._buffer) >= n or self._closed,
                timeout=timeout,
            ):
                raise TimeoutError(
                    f"Timed out waiting for {n} frame(s) after {timeout}s"
                )
            if self._closed and len(self._buffer) < n:
                raise BufferClosed("Buffer closed")

            if mode == ReadMode.LATEST:
                return self._read_latest(n)
            return self._read_fifo(n)

    def _read_latest(self, n: int) -> List[np.ndarray]:
        """Return the *n* newest frames and discard the rest.  Caller holds the lock."""
        buf_len = len(self._buffer)
        start = buf_len - n
        result = [self._buffer[start + i] for i in range(n)]
        self._buffer.clear()
        return result

    def _read_fifo(self, n: int) -> List[np.ndarray]:
        """Pop the *n* oldest frames.  Caller holds the lock."""
        return [self._buffer.popleft() for _ in range(n)]

    def try_read(
        self,
        n: int = 1,
        mode: ReadMode = ReadMode.LATEST,
    ) -> Optional[List[np.ndarray]]:
        """Try to read *n* frames without blocking.

        Returns ``None`` when fewer than *n* frames are available —
        the buffer is left untouched so nothing is lost.

        Args:
            n: Number of frames to return.
            mode: :attr:`ReadMode.LATEST` (default) returns the *n*
                newest frames and discards any older backlog.
                :attr:`ReadMode.FIFO` pops the *n* oldest frames,
                leaving newer frames in the buffer.

        Returns:
            A list of *n* ``np.ndarray`` frames, or ``None`` if
            fewer than *n* are available.

        Raises:
            BufferClosed: The client has disconnected.
        """
        with self._lock:
            if self._closed:
                raise BufferClosed("Buffer closed")
            if len(self._buffer) < n:
                return None
            if mode == ReadMode.LATEST:
                return self._read_latest(n)
            return self._read_fifo(n)

    @property
    def available(self) -> int:
        """Number of frames currently in the buffer."""
        with self._lock:
            return len(self._buffer)

    @property
    def total_received(self) -> int:
        """Total number of frames received since the last reset."""
        with self._lock:
            return self._total_received

    @property
    def closed(self) -> bool:
        """Whether the buffer has been closed (client disconnected)."""
        with self._lock:
            return self._closed

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """Drop all buffered frames without closing the buffer."""
        with self._lock:
            self._buffer.clear()

    def close(self) -> None:
        """Signal end-of-input for the current session.

        Wakes any coroutine blocked in :meth:`read`, causing it to
        raise :class:`BufferClosed`.  Further incoming frames are
        silently dropped until :meth:`reset` is called.
        """
        with self._condition:
            self._closed = True
            # Wake _read() if it's sleeping in wait_for().  It will
            # re-acquire the lock, see _closed=True, raise BufferClosed.
            self._condition.notify_all()

    def reset(self) -> None:
        """Re-open the buffer for a new session.

        Clears all frames, resets counters, and unsets the closed
        flag so that :meth:`read` works again.

        :class:`ReactorPipeline` calls this automatically between
        connections.  :class:`ReactorModel` users should call it in
        their ``@disconnected`` handler.
        """
        # No notify_all needed: no thread should be blocked in wait_for()
        # at this point — the session is over and _read() already exited
        # via BufferClosed after close() was called.
        with self._condition:
            self._closed = False
            self._buffer.clear()
            self._total_received = 0

    # ------------------------------------------------------------------
    # Write API (runtime thread — not part of the model-author surface)
    # ------------------------------------------------------------------
    #
    # Call chain:
    #   WebRTC transport (on_track / on_frame callback)
    #     → ReactorCore._push_media(track_name, data)
    #       → InputBuffer._push(data)
    #
    # Thread-safe: the model thread may be blocked in read()
    # concurrently — notify_all wakes it.

    def _push(self, data: np.ndarray) -> None:
        """Append a media frame (called by the runtime, not model code).

        Silently drops the frame if the buffer has been closed.
        When full, the oldest frame is evicted (bounded deque).
        """
        with self._condition:
            if self._closed:
                return
            self._buffer.append(data)
            self._total_received += 1
            # Wake _read() if it's sleeping in wait_for() — it will
            # re-acquire the lock and re-check len(buffer) >= n.
            self._condition.notify_all()
