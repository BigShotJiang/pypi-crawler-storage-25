# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Schema-driven validation for inbound event messages.

:class:`SchemaValidator` pre-compiles a JSON Schema validator for each
event in an OpenAPI 3.1 document and provides a single :meth:`validate`
entry point that validates incoming payloads against the event's request
body schema.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Set, Tuple

import jsonschema

logger = logging.getLogger(__name__)


class SchemaValidator:
    """Pre-compiled JSON Schema validators for a model's events.

    Accepts a raw OpenAPI 3.1 document (a plain dict).  The document
    can come from runtime introspection, a static file, or a registry
    — this class does not depend on how the schema was produced.

    Instantiate once per session (or model load), then call
    :meth:`validate` for each inbound message.
    """

    def __init__(self, openapi: Dict[str, Any]) -> None:
        self._validators: Dict[str, jsonschema.Draft202012Validator] = {}
        self._schemas: Dict[str, Dict[str, Any]] = {}
        self._upload_fields: Dict[str, Set[str]] = {}

        paths = openapi.get("paths", {})

        for path, path_item in paths.items():
            event_name = path.removeprefix("/events/")
            post = path_item.get("post", {})
            body_content = post.get("requestBody", {}).get("content", {})
            json_content = body_content.get("application/json", {})
            body_schema = json_content.get("schema", {})

            upload_fields: Set[str] = set()
            for field_name, field_schema in body_schema.get("properties", {}).items():
                if _is_upload_reference(field_schema):
                    upload_fields.add(field_name)
            self._upload_fields[event_name] = upload_fields

            resolved = _inline_refs(
                body_schema,
                openapi.get("components", {}).get("schemas", {}),
            )
            self._schemas[event_name] = resolved
            self._validators[event_name] = jsonschema.Draft202012Validator(resolved)

    def validate(
        self, event_name: str, data: Dict[str, Any]
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        """Validate *data* against the schema for *event_name*.

        Returns ``(data, None)`` on success, or
        ``(None, error_message)`` on failure.
        """
        validator = self._validators.get(event_name)
        if validator is None:
            return None, f"Unknown event: {event_name}"

        errors = list(validator.iter_errors(data))
        if errors:
            messages = "; ".join(e.message for e in errors[:3])
            return None, f"Validation failed for {event_name}: {messages}"

        return data, None

    def get_upload_fields(self, event_name: str) -> Set[str]:
        """Return field names with ``format: reactor-upload-reference``."""
        return self._upload_fields.get(event_name, set())


def _is_upload_reference(field_schema: Dict[str, Any]) -> bool:
    """Check if a field schema references ReactorUploadReference.

    Handles both direct ``$ref`` and ``Optional[UploadedFile]`` which
    wraps the ``$ref`` inside an ``anyOf``.
    """
    ref = field_schema.get("$ref", "")
    if "ReactorUploadReference" in ref:
        return True
    for sub in field_schema.get("anyOf", []):
        if "ReactorUploadReference" in sub.get("$ref", ""):
            return True
    return False


def _inline_refs(
    schema: Dict[str, Any], component_schemas: Dict[str, Any]
) -> Dict[str, Any]:
    """Recursively resolve ``$ref`` pointers against component schemas."""
    if "$ref" in schema:
        ref_path = schema["$ref"]
        ref_name = ref_path.rsplit("/", 1)[-1]
        resolved = component_schemas.get(ref_name)
        if resolved is None:
            raise ValueError(f"$ref '{ref_path}' not found in component schemas")
        return _inline_refs(resolved, component_schemas)

    result = dict(schema)
    if "properties" in result:
        result["properties"] = {
            k: _inline_refs(v, component_schemas)
            for k, v in result["properties"].items()
        }
    if "items" in result and isinstance(result["items"], dict):
        result["items"] = _inline_refs(result["items"], component_schemas)
    for keyword in ("anyOf", "allOf", "oneOf"):
        if keyword in result:
            result[keyword] = [
                _inline_refs(v, component_schemas) for v in result[keyword]
            ]

    return result
