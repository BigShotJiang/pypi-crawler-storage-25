# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Model loading utilities.

Loads a model class from a ``module:ClassName`` spec, instantiates it,
loads the model-specific config (if any), and calls :meth:`load`.
"""

import importlib
import inspect
import logging
import sys
from typing import Any, Tuple

from omegaconf import OmegaConf

from reactor_runtime.config import ReactorConfig
from reactor_runtime.interface.internal.reactor_core import ReactorCore

logger = logging.getLogger(__name__)


def parse_spec(spec: str) -> Tuple[str, str]:
    """Parse a ``module:ClassName`` string into ``(module, class_name)``."""
    if not spec or ":" not in spec:
        raise ValueError(f"Invalid spec '{spec}'. Expected 'module:ClassName'.")
    module, class_name = spec.split(":", 1)
    module = module.strip()
    class_name = class_name.strip()
    if not module or not class_name:
        raise ValueError(f"Invalid spec '{spec}'. Expected 'module:ClassName'.")
    return module, class_name


def resolve_class(spec: str) -> type:
    """Resolve a ``module:ClassName`` spec to a class object.

    Note: The caller is responsible for adding the model directory to sys.path
    before calling this function (typically done via launch.py's add_import_paths).
    """
    module_name, class_name = parse_spec(spec)

    try:
        module = importlib.import_module(module_name)
    except ModuleNotFoundError as e:
        if (
            e.name
            and e.name != module_name
            and not e.name.startswith(module_name + ".")
        ):
            raise ModuleNotFoundError(
                f"Module '{module_name}' failed to import: "
                f"missing dependency '{e.name}'. "
                f"Install it or ensure it is available in your environment."
            ) from e
        raise ModuleNotFoundError(
            f"Module '{module_name}' not found. "
            f"Ensure the model directory is in sys.path (current: {sys.path[:3]}...)"
        ) from e

    try:
        cls = getattr(module, class_name)
    except AttributeError:
        raise ImportError(f"Class '{class_name}' not found in module '{module_name}'")
    if not inspect.isclass(cls):
        raise TypeError(f"'{class_name}' in module '{module_name}' is not a class")
    return cls


def _load_model_config(reactor_config: ReactorConfig) -> dict[str, Any]:
    """Load and return the model-specific config from ``reactor_config.config``.

    Applies ``reactor_config.config_overrides`` on top of the loaded file.
    Returns an empty dict when no config path is set.
    """
    if not reactor_config.config:
        return {}

    cfg = OmegaConf.load(reactor_config.config)
    if reactor_config.config_overrides:
        cli_cfg = OmegaConf.from_dotlist(reactor_config.config_overrides)
        cfg = OmegaConf.merge(cfg, cli_cfg)
    return OmegaConf.to_container(cfg, resolve=True)  # type: ignore[return-value]


def build_model(reactor_config: ReactorConfig) -> ReactorCore:
    """Instantiate and load a model from a :class:`ReactorConfig`.

    1. Resolves the model class from ``reactor_config.model``.
    2. Instantiates it (``fps`` and ``buffer_size`` come from class attributes).
    3. Loads the model-specific config from ``reactor_config.config``
       (with ``config_overrides`` merged), and calls ``model.load()``.

    Args:
        reactor_config: Parsed ``reactor.yaml``.  The ``config`` path
            must already be resolved to an absolute path if it was
            originally relative.

    Returns:
        A fully loaded :class:`ReactorCore` subclass instance.
    """
    cls = resolve_class(reactor_config.model)

    if not issubclass(cls, ReactorCore):
        raise TypeError(f"'{cls.__name__}' is not a subclass of ReactorCore")

    instance = cls()

    model_config = _load_model_config(reactor_config)
    instance.load(model_config)

    return instance
