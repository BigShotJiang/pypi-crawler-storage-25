# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Shared type-annotation helpers used across the runtime."""

from __future__ import annotations

import types
from typing import Any, Optional, Union, get_args, get_origin


def unwrap_optional(raw_type: Any) -> Optional[Any]:
    """If *raw_type* is ``Optional[X]`` (``Union[X, None]``), return ``X``.

    Supports both ``typing.Union`` and Python 3.10+ ``X | None`` syntax.
    Returns ``None`` when *raw_type* is not an Optional.
    """
    origin = get_origin(raw_type)
    if origin is not Union and origin is not types.UnionType:
        return None
    args = [a for a in get_args(raw_type) if a is not type(None)]
    if len(args) == 1:
        return args[0]
    return None
