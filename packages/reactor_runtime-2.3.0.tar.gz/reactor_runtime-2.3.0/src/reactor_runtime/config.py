# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Typed configuration parsed from ``reactor.yaml``.

:class:`ReactorConfig` is the runtime-level configuration that identifies
the model entry point and name.  Track topology is inferred from the
model class via the ``OUTPUT_REGISTRY`` / ``INPUT_REGISTRY``.

Emission settings (``fps``, ``buffer_size``) are declared as class
attributes on the model class, not in YAML.  Model-specific parameters
(latent dims, learning rate, etc.) live in a separate config file
pointed to by ``ReactorConfig.config``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ReactorConfig:
    """Parsed ``reactor.yaml``.

    Example YAML::

        model: my_module:MyModel
        name: my-world-model
        config: config.yml

    The ``config`` path should be resolved to an absolute path by the
    caller before passing to :func:`build_model`.  ``config_overrides``
    carries CLI dotlist overrides (e.g. ``["lr=0.001", "batch=4"]``)
    that are merged on top of the loaded config file.
    """

    model: str
    name: str = ""
    config: Optional[str] = None
    config_overrides: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "ReactorConfig":
        """Parse a raw YAML dict into a :class:`ReactorConfig`."""
        return cls(
            model=raw["model"],
            name=raw.get("name", ""),
            config=raw.get("config"),
        )
