# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
HTTP Runtime for Reactor

An HTTP-based runtime that exposes REST endpoints for session management
and WebRTC for real-time video/audio/data streaming.

Used by the JS SDK's ``LocalCoordinatorClient`` for local development.

Session endpoints:
    POST   /start_session                               - Start session (returns capabilities)
    POST   /stop_session                                - Stop session

Transport endpoints:
    GET    /sessions/{id}/transport/webrtc/ice_servers   - ICE server config
    POST   /sessions/{id}/transport/webrtc/sdp_params    - Send SDP offer (async, 202)
    GET    /sessions/{id}/transport/webrtc/sdp_params    - Poll for SDP answer
    PUT    /sessions/{id}/transport/webrtc/sdp_params    - Reconnect (new SDP offer)

Other:
    GET    /health                                       - Health check
"""

import asyncio
import os
import uuid
from typing import Any, Dict, Optional
import numpy as np
from fastapi import FastAPI, HTTPException, Request
from importlib.metadata import version as _pkg_version, PackageNotFoundError

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from reactor_runtime.schema import ModelSchema
from reactor_runtime.config import ReactorConfig
from reactor_runtime.model_state import ModelEvent, ModelState
import uvicorn

from reactor_runtime.runtime_api import Runtime
from reactor_runtime.transports.media import (
    MediaBundle,
    TrackMapping,
)
from reactor_runtime.utils.log import get_logger
from reactor_runtime.transports import (
    WebRTCTransport,
    WebRTCSupersededError,
    EventType,
    MessageEvent,
    DisconnectedEvent,
    VideoFrameEvent,
    PingTimeoutEvent,
)
from reactor_runtime.transports.config import (
    resolve_default_transport,
    validate_transport_available,
)
from reactor_runtime.transports.types import (
    IceTransportPolicy,
    TransportConfig,
    WebRTCSignalingState,
)
from reactor_runtime.runtimes.http.config import HttpRuntimeConfig
from reactor_runtime.runtimes.http.types import (
    CreateUploadRequest,
    SdpOfferRequest,
)

logger = get_logger(__name__)

try:
    _runtime_version = _pkg_version("reactor_runtime")
except PackageNotFoundError:
    _runtime_version = "0.0.0"

SESSION_ID = "local"


def _validate_session_id(session_id: str) -> None:
    if session_id != SESSION_ID:
        raise HTTPException(status_code=404, detail="Session not found")


# =============================================================================
# HttpRuntime
# =============================================================================


class HttpRuntime(Runtime):
    """HTTP runtime with decoupled session/transport signaling.

    Implements the REST protocol matching the JS SDK v3
    (``LocalCoordinatorClient`` + ``WebRTCTransportClient``).
    """

    config: HttpRuntimeConfig

    def __init__(self, config: HttpRuntimeConfig) -> None:
        """Initialize the HTTP runtime.

        Args:
            config: HttpRuntimeConfig containing model and runtime-specific settings.
        """
        # WebRTC transport - single connection at a time
        # Protected by _client_lock for thread-safe access
        self._webrtc_client: Optional[WebRTCTransport] = None
        self._client_lock = asyncio.Lock()
        self._server: Optional[uvicorn.Server] = None

        # Local file upload store: upload_id -> {name, mime_type, size, data?}
        self._upload_store: Dict[str, Dict[str, Any]] = {}

        # FastAPI app
        self.app = FastAPI(title="Reactor HTTP Runtime")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self._setup_routes()

        super().__init__(config)

    # ===============================
    # Route Setup
    # ===============================

    def _setup_routes(self) -> None:
        """Setup FastAPI routes for the local runtime protocol."""

        # -----------------------------------------------------------
        # Session endpoints
        # -----------------------------------------------------------

        @self.app.post("/start_session")
        async def start_session():
            """Start a session and return full capabilities immediately."""
            if self.current_state != ModelState.READY:
                raise HTTPException(
                    status_code=400,
                    detail=f"Cannot start session in state {self.current_state.value}",
                )

            model_schema = ModelSchema.from_config(
                self.config.reactor_config,
                model_cls=type(self.model) if self.model else None,
            )

            success = self.send(ModelEvent.START_SESSION)
            if not success:
                raise HTTPException(
                    status_code=400,
                    detail="Failed to start session",
                )

            return {
                "session_id": SESSION_ID,
                "cluster": "local",
                "server_info": {"server_version": _runtime_version},
                "selected_transport": {"protocol": "webrtc", "version": "1.0"},
                "model": {"name": self.config.reactor_config.name},
                "capabilities": model_schema.to_legacy_tracks_only(),
                "schema": model_schema.to_openapi(),
                "state": self.current_state.value,
            }

        @self.app.post("/stop_session")
        async def stop_session():
            """Stop the current session."""
            success = self.send(ModelEvent.STOP_SESSION)
            if not success:
                if self.current_state in (
                    ModelState.READY,
                    ModelState.CREATED,
                    ModelState.TERMINATED,
                ):
                    return JSONResponse(status_code=200, content=None)
                raise HTTPException(
                    status_code=409,
                    detail=f"Cannot stop session in state {self.current_state.value}",
                )

            return JSONResponse(status_code=200, content=None)

        # -----------------------------------------------------------
        # Transport endpoints
        # -----------------------------------------------------------

        @self.app.get("/sessions/{session_id}/transport/webrtc/ice_servers")
        async def ice_servers(session_id: str):
            """Return ICE server configuration for WebRTC peer connection."""
            _validate_session_id(session_id)
            return {"ice_servers": self.config.ice_servers_json}

        @self.app.post("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def post_sdp_params(session_id: str, request: SdpOfferRequest):
            """Accept an SDP offer and start WebRTC connection setup in the background.

            Returns 202 immediately.  The client polls
            ``GET .../sdp_params`` for the answer.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            await self._clear_existing_transport()

            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.put("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def put_sdp_params(session_id: str, request: SdpOfferRequest):
            """Reconnect with a new SDP offer.

            Same logic as POST — stops existing transport and creates a new one.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            await self._clear_existing_transport()

            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.get("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def get_sdp_params(session_id: str):
            """Poll for the SDP answer.

            Returns:
                200 with ``{ "sdp_answer": "..." }`` if the transport is ready.
                202 if the transport is still being created.
                404 if no session is active.
            """
            _validate_session_id(session_id)

            client = self._webrtc_client
            if client is not None:
                signaling = client.get_signaling()
                if not isinstance(signaling, WebRTCSignalingState):
                    raise HTTPException(
                        status_code=500,
                        detail=f"Unexpected signaling type: {type(signaling).__name__}",
                    )
                if signaling.sdp_answer is not None:
                    return {
                        "sdp_answer": signaling.sdp_answer.sdp,
                    }

            if self.current_state in (ModelState.WAITING, ModelState.ORPHANED):
                return JSONResponse(status_code=202, content=None)

            raise HTTPException(status_code=404, detail="No pending SDP offer")

        # -----------------------------------------------------------
        # Upload endpoints (local file store)
        # -----------------------------------------------------------

        @self.app.post("/sessions/{session_id}/uploads")
        async def create_upload(session_id: str, req: CreateUploadRequest):
            """Allocate a local upload slot (mirrors Coordinator endpoint)."""
            _validate_session_id(session_id)
            if not req.name:
                raise HTTPException(status_code=400, detail="name is required")
            if not req.mime_type:
                raise HTTPException(status_code=400, detail="mime_type is required")
            if req.size <= 0:
                raise HTTPException(status_code=400, detail="size must be > 0")

            upload_id = str(uuid.uuid4())
            self._upload_store[upload_id] = {
                "name": req.name,
                "mime_type": req.mime_type,
                "size": req.size,
            }
            port = self.config.port
            upload_url = f"http://localhost:{port}/uploads/{upload_id}"
            path = f"sessions/{session_id}/uploads/{upload_id}/{req.name}"
            logger.info(
                "Upload slot created",
                upload_id=upload_id,
                name=req.name,
            )
            return JSONResponse(
                status_code=201,
                content={
                    "presigned_id": upload_id,
                    "presigned_url": upload_url,
                    "path": path,
                },
            )

        @self.app.put("/uploads/{upload_id}")
        async def put_upload(upload_id: str, request: Request):
            """Receive file bytes for a previously allocated upload slot."""
            if upload_id not in self._upload_store:
                raise HTTPException(status_code=404, detail="Upload not found")
            entry = self._upload_store[upload_id]
            if "data" in entry:
                raise HTTPException(status_code=409, detail="Upload already completed")
            body = await request.body()
            expected_size = entry.get("size", 0)
            if expected_size and len(body) != expected_size:
                raise HTTPException(
                    status_code=400,
                    detail=f"Content-Length mismatch: expected {expected_size}, got {len(body)}",
                )
            entry["data"] = body
            logger.info(
                "Upload received",
                upload_id=upload_id,
                size=len(body),
            )
            return JSONResponse(status_code=200, content=None)

        # -----------------------------------------------------------
        # Health check
        # -----------------------------------------------------------

        @self.app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "model": self.config.reactor_config.name,
                "state": self.current_state.value,
            }

    # ===============================
    # WebRTC Connection Management
    # ===============================

    async def _clear_existing_transport(self) -> None:
        """Stop and null the current WebRTC client, clearing stale signaling state.

        Fires ``CLIENT_DISCONNECTED`` if a transport was active so the
        state machine transitions correctly (e.g. ``STREAMING`` →
        ``ORPHANED``).

        Called by the POST/PUT ``sdp_params`` endpoints *before*
        spawning ``_create_transport_background``, so the teardown
        happens synchronously in the request handler while the creation
        runs as a fire-and-forget background task.
        """
        async with self._client_lock:
            if self._webrtc_client is not None:
                logger.info("Stopping existing WebRTC client")
                self._webrtc_client.stop()
                self._webrtc_client = None
                self.send(ModelEvent.CLIENT_DISCONNECTED)

    async def _create_transport_background(
        self, sdp_offer: str, track_mapping: TrackMapping
    ) -> None:
        """Background task: create a WebRTC transport and install it.

        **Concurrency model — why a post-creation lock check is needed:**

        Teardown and creation are split across two steps:

        1. *Teardown* (in the request handler): the POST/PUT endpoint
           calls ``_clear_existing_transport`` synchronously before
           spawning this background task.
        2. *Creation* (this method, fire-and-forget):
           ``WebRTCTransport.create()`` is async and yields to the event
           loop (SDP exchange, ICE gathering).  During this window the
           client can send another POST/PUT which tears down again and
           spawns a second background task.  Two tasks now race to
           install their transport.

        When installation re-acquires ``_client_lock``, two guards
        prevent stale transports from being installed:

        - ``_webrtc_client is not None``: the other background task
          already won the race and installed its transport.  Ours is
          stale — stop it and return.
        - ``send(CLIENT_CONNECTED)`` returns ``False``: the session was
          stopped or timed out while we were creating the transport, so
          the state machine rejects the transition.  The transport is
          no longer needed — stop it.

        ``WebRTCSupersededError`` can also be raised from *inside*
        ``WebRTCTransport.create()`` if the transport backend detects
        its stop event was set during setup (e.g. runtime shutdown).
        This is a benign abort — the transport was no longer needed.

        On any failure the error is logged but not re-raised; the orphan
        timeout (managed by ``runtime_api.py``) will eventually clean up
        the session.

        Args:
            sdp_offer: The SDP offer string.
            track_mapping: Track mapping from the client.
        """
        try:
            logger.info("Creating new WebRTC connection (background)")
            transport = await WebRTCTransport.create(
                self.config.transport_type,
                sdp_offer=sdp_offer,
                track_mapping=track_mapping,
                config=TransportConfig(
                    ice_servers=self.config.ice_servers,
                    port_range=self.config.webrtc_port_range,
                    transport_policy=self.config.ice_transport_policy,
                ),
            )

            async with self._client_lock:
                if self._webrtc_client is not None:
                    transport.stop()
                    logger.warning("Connection superseded by concurrent request")
                    return

                success = self.send(ModelEvent.CLIENT_CONNECTED, client=transport)
                if not success:
                    transport.stop()
                    logger.warning(
                        "Session expired while waiting for client connection",
                        state=self.current_state.value,
                    )
                    return

        except WebRTCSupersededError:
            logger.warning("WebRTC connection was superseded during creation")
        except Exception as e:
            logger.exception("Failed to create WebRTC transport (background)", error=e)

    def _setup_webrtc_handlers(self, client: WebRTCTransport) -> None:
        """Setup event handlers for a WebRTC client."""

        def on_message(event: MessageEvent):
            """Handle incoming data channel message."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_data_channel_message(event.data), self.loop
                )

        def on_disconnect(event: DisconnectedEvent):
            if not self.loop.is_closed():
                logger.info("WebRTC disconnected", reason=event.reason)
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        def on_video_frame(event: VideoFrameEvent):
            self._on_incoming_video_frame(event.frame, event.track_name)

        def on_ping_timeout(event: PingTimeoutEvent):
            if not self.loop.is_closed():
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        client.on(EventType.MESSAGE, on_message)
        client.on(EventType.DISCONNECTED, on_disconnect)
        client.on(EventType.VIDEO_FRAME, on_video_frame)
        client.on(EventType.PING_TIMEOUT, on_ping_timeout)

    async def _stop_webrtc_client(self) -> None:
        """Stop and clear the current WebRTC client."""
        async with self._client_lock:
            if self._webrtc_client is not None:
                self._webrtc_client.stop()
                self._webrtc_client = None

    async def _on_data_channel_message(self, message: str) -> None:
        """Handle incoming data channel message.
        Delegates to the common handler in the abstract Runtime class.
        """
        await self._handle_incoming_data_channel_message(message)

    async def _download_uploaded_file(self, upload_id: str) -> bytes:
        """Read an uploaded file from the local in-memory store.

        The data is retained so the same upload can be read multiple times
        within a session.  The entire store is cleared on session cleanup.
        """
        entry = self._upload_store.get(upload_id)
        if entry is None or "data" not in entry:
            raise FileNotFoundError(f"Upload {upload_id} not found in local store")
        return entry["data"]

    def _on_ping_received(self) -> None:
        """Forward client ping to the WebRTC client's watchdog."""
        if self._webrtc_client:
            self._webrtc_client.notify_ping()

    def _on_incoming_video_frame(
        self, frame: np.ndarray, track_name: str = "video"
    ) -> None:
        """Handle incoming video frame from WebRTC.

        Pushes the raw frame directly into the model's InputBuffer
        for the named track.

        Args:
            frame: NumPy array in RGB format with shape (H, W, 3).
            track_name: The MID-derived track name.
        """
        if self.model is not None:
            self.model._push_media(track_name, frame)

    # -----------------------------------------------------------------
    # Transport abstract method implementations
    # -----------------------------------------------------------------

    async def send_out_app_message(self, data: dict) -> None:
        """Send an application message via the WebRTC data channel."""
        client = self._webrtc_client
        if client is not None:
            client.send_message(data)

    async def send_out_runtime_message(self, data: dict) -> None:
        """Send a runtime message via the WebRTC data channel."""
        client = self._webrtc_client
        if client is not None:
            client.send_message(data)

    async def send_out_app_bundle(
        self, media_bundle: MediaBundle, duplicate: bool
    ) -> None:
        """Send a multi-track media bundle via the WebRTC transport.

        Silently skips if no WebRTC connection is active.
        """
        client = self._webrtc_client
        if client is not None:
            client.send_media(media_bundle)

    # -----------------------------------------------------------------
    # State machine hooks
    # -----------------------------------------------------------------

    def on_before_stop_session(self, **kwargs) -> None:
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_client_connected(self, **kwargs) -> None:
        """Handler called before the client connected event is sent.
        Installs the client setting up event handlers.
        """
        client = kwargs.get("client")
        assert client is not None, "Client must be provided"
        self._setup_webrtc_handlers(client)
        self._webrtc_client = client
        client.start_ping_watchdog()

    def on_before_client_disconnected(self, **kwargs) -> None:
        """Cleanup called after the WebRTC client is disconnected.
        This frees the resource used by the WebRTC client thread.
        """
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_cleanup_complete(self, **kwargs) -> None:
        self._upload_store.clear()

    # -----------------------------------------------------------------
    # State-machine hooks
    # -----------------------------------------------------------------

    def on_enter_TERMINATED(self, previous_state: ModelState) -> None:
        super().on_enter_TERMINATED(previous_state)
        if self._server is not None:
            self._server.should_exit = True

    # -----------------------------------------------------------------
    # State hooks
    # -----------------------------------------------------------------

    def on_before_initialization_success(self, **kwargs) -> None:
        aqua, reset = "\033[96m", "\033[0m"
        url = f"http://{self.config.host}:{self.config.port}"
        logger.info("Started runtime process", pid=os.getpid())
        logger.info(f"Reactor runtime running on {aqua}{url}{reset}")

    # -----------------------------------------------------------------
    # run()
    # -----------------------------------------------------------------

    async def run(self) -> None:
        """Main entry point to run the HTTP runtime.
        Starts the FastAPI server with uvicorn.
        """
        uvicorn_config = uvicorn.Config(
            app=self.app,
            host=self.config.host,
            port=self.config.port,
            log_level="warning",
            access_log=False,
        )
        self._server = uvicorn.Server(uvicorn_config)

        try:
            await self._server.serve()
        except KeyboardInterrupt:
            logger.info("HTTP runtime interrupted")
        finally:
            self._server = None
            await self._stop_webrtc_client()
            await self.shutdown()


# ---------------------------------------------------------------------------
# serve() entry point (called by the CLI)
# ---------------------------------------------------------------------------


async def serve(
    reactor_config: ReactorConfig,
    **kwargs,
) -> None:
    """Entry point for running the HTTP runtime from a CLI.

    Args:
        reactor_config: Parsed reactor.yaml configuration (with ``config``
            resolved to an absolute path and ``config_overrides`` populated).
        **kwargs: Runtime-specific arguments from HttpRuntimeConfig.parser()
            - host: Host to bind to (default: "0.0.0.0")
            - port: Port to bind to (default: 8080)
            - orphan_timeout: Seconds to wait before stopping orphaned session (default: 30.0)
            - max_session_duration: Maximum session duration in seconds (default: None, disabled)
            - webrtc_port_range: WebRTC ICE UDP port range as tuple (min, max) (default: None)
            - stun_servers: List of STUN server URLs (default: None, uses Google STUN)
            - turn_servers: List of TURN servers in format "username;credential;url" (default: None)
            - transport_type: WebRTC transport backend (default: None -> auto-detect)
    """
    transport_type = kwargs.get("transport_type")
    if transport_type is not None:
        try:
            validate_transport_available(transport_type)
        except ImportError as e:
            raise RuntimeError(
                f"Transport '{transport_type.name}' not available: {e}"
            ) from e
    else:
        transport_type = resolve_default_transport()

    config = HttpRuntimeConfig(
        reactor_config=reactor_config,
        host=kwargs.get("host", "0.0.0.0"),
        port=kwargs.get("port", 8080),
        orphan_timeout=kwargs.get("orphan_timeout", 30.0),
        max_session_duration=kwargs.get("max_session_duration"),
        webrtc_port_range=kwargs.get("webrtc_port_range"),
        stun_servers=kwargs.get("stun_servers"),
        turn_servers=kwargs.get("turn_servers"),
        ice_transport_policy=kwargs.get("ice_transport_policy", IceTransportPolicy.ALL),
        transport_type=transport_type,
        profiling_output_dir=kwargs.get("profiling_output_dir"),
    )

    runtime = HttpRuntime(config)
    asyncio.create_task(runtime.load())
    await runtime.run()
