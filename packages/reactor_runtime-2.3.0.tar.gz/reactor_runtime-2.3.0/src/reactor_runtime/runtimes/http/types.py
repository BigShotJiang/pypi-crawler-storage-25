# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Pydantic request/response models for the HTTP Runtime REST API.

These models define the wire format for the decoupled session/transport
protocol matching the JS SDK v3 (``LocalCoordinatorClient`` +
``WebRTCTransportClient``).
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel

# =============================================================================
# Session API models
# =============================================================================


class CreateSessionRequest(BaseModel):
    """POST /sessions request body."""

    model: Dict[str, str]
    client_info: Optional[Dict[str, str]] = None
    supported_transports: Optional[List[Dict[str, str]]] = None
    extra_args: Optional[Dict[str, Any]] = None


class TerminateSessionRequest(BaseModel):
    """DELETE /sessions/{id} optional request body."""

    reason: Optional[str] = None


# =============================================================================
# Transport API models
# =============================================================================


class TrackMappingEntry(BaseModel):
    """A single entry in the track_mapping array.

    Mirrors the proto ``Track`` message.  Maps a browser-assigned MID
    (``id``) to a named track with its kind and direction from the
    **client's** perspective.

    ``mid`` is the MID string per RFC 5888 (``a=mid:<token>``).
    """

    mid: str
    name: str
    kind: str
    direction: str


class SdpOfferRequest(BaseModel):
    """POST /sessions/{id}/transport/webrtc/sdp_params request body."""

    sdp_offer: str
    client_info: Optional[Dict[str, str]] = None
    track_mapping: List[TrackMappingEntry] = []


# =============================================================================
# Upload API models
# =============================================================================


class CreateUploadRequest(BaseModel):
    """POST /sessions/{id}/uploads request body."""

    name: str
    size: int
    mime_type: str
