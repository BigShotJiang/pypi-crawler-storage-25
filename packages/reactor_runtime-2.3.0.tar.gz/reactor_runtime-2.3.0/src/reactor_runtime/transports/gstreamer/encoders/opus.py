# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Opus audio encoder bin: sink -> opusenc -> rtpopuspay -> src.

Designed for WebRTC RTP pipelines. Opus is the standard audio codec
for WebRTC (Chrome, Firefox, Safari).

SDP fmtp parameters (RFC 7587) are honored when passed via format:
  - minptime: minimum RTP packet time in ms; encoder frame size is chosen >= minptime.
  - useinbandfec=1: enable in-band FEC in opusenc.
"""

from typing import Dict, Optional

from reactor_runtime.transports.gstreamer.gst_helpers import (
    make_element,
    try_set_property,
)
from .base import BaseEncoderBin

# opusenc frame-size enum values (ms); must be >= SDP minptime
_OPUS_FRAME_SIZES_MS = (2.5, 5, 10, 20, 40, 60)


def _frame_size_from_minptime(minptime_ms: Optional[int]) -> float:
    """Choose smallest opusenc frame size >= minptime, or default 20 ms."""
    if minptime_ms is None or minptime_ms <= 0:
        return 20.0
    for size in _OPUS_FRAME_SIZES_MS:
        if size >= minptime_ms:
            return size
    return 60.0


def _parse_useinbandfec(format_params: Dict[str, Optional[str]]) -> bool:
    """True if useinbandfec=1 in SDP fmtp."""
    val = format_params.get("useinbandfec")
    if val is None:
        return True  # default for WebRTC
    return str(val).strip() == "1"


class OpusEncoderBin(BaseEncoderBin):
    """
    Encoder bin implementing:

        sink -> opusenc -> rtpopuspay(pt=...) -> src

    Accepts raw audio (e.g. from audioconvert/audiorate); produces RTP Opus.
    """

    def __init__(
        self,
        pt: int,
        name: str = "opus_encoder_bin",
        initial_bitrate_bps: int = 64_000,
        bitrate_type: str = "constrained-vbr",
        frame_size_ms: Optional[float] = None,
        inband_fec: Optional[bool] = None,
        dtx: bool = False,
        ssrc: Optional[int] = None,
        format: Optional[Dict[str, Optional[str]]] = None,
    ):
        """
        Args:
            pt:
                RTP payload type negotiated via SDP.

            initial_bitrate_bps:
                Target bitrate in bits per second (e.g. 64000 for 64 kbps).

            bitrate_type:
                "cbr", "vbr", or "constrained-vbr" (default for WebRTC).

            frame_size_ms:
                Frame duration in ms (2.5, 5, 10, 20, 40, 60). If None, derived
                from format minptime (SDP fmtp) or default 20.

            inband_fec:
                Enable in-band FEC. If None, derived from format useinbandfec or True.

            dtx:
                Discontinuous transmission (silence suppression).

            ssrc:
                Optional RTP SSRC for the payloader.

            format:
                SDP fmtp parameters (e.g. minptime=10;useinbandfec=1). Used to set
                frame_size >= minptime and useinbandfec.
        """
        super().__init__(name=name)

        self._pt = int(pt)
        format_params = format or {}

        # SDP minptime: minimum RTP packet time in ms; we use frame size >= minptime
        minptime_val = format_params.get("minptime")
        minptime_ms: Optional[int] = None
        if minptime_val is not None and str(minptime_val).strip().isdigit():
            minptime_ms = int(minptime_val)

        if frame_size_ms is not None:
            frame_size = float(frame_size_ms)
        else:
            frame_size = _frame_size_from_minptime(minptime_ms)

        if inband_fec is not None:
            fec = inband_fec
        else:
            fec = _parse_useinbandfec(format_params)

        self._enc = make_element("opusenc", "opusenc")
        self._pay = make_element("rtpopuspay", "rtpopuspay")

        self.set_bitrate_property(self._enc, initial_bitrate_bps)

        try_set_property(self._enc, "bitrate-type", bitrate_type)
        try_set_property(self._enc, "frame-size", frame_size)
        try_set_property(self._enc, "inband-fec", fec)
        try_set_property(self._enc, "dtx", dtx)

        self._pay.set_property("pt", self._pt)
        if ssrc is not None:
            try_set_property(self._pay, "ssrc", ssrc)

        self.add(self._enc)
        self.add(self._pay)

        if not self._enc.link(self._pay):
            raise RuntimeError("Failed to link opusenc -> rtpopuspay")

        enc_sink = self._enc.get_static_pad("sink")
        pay_src = self._pay.get_static_pad("src")

        if not enc_sink or not pay_src:
            raise RuntimeError("Failed to fetch sink/src pads")

        self._create_ghost_pads(enc_sink, pay_src)
