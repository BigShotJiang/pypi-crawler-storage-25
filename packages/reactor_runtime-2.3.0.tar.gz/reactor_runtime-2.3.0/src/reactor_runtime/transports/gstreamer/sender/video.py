# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Video sender bin: raw frames in, RTP out (through BWE or identity); RTX lives on the transport.
"""

from typing import List, NamedTuple, Optional

import numpy as np

from reactor_runtime.transports.gstreamer.encoders import EncoderFactory
from reactor_runtime.transports.gstreamer.settings import (
    VIDEO_BWE_MAX_BITRATE_KBPS,
    VIDEO_BWE_MIN_BITRATE_KBPS,
    VIDEO_BWE_TARGET_BITRATE_KBPS,
)
from reactor_runtime.transports.gstreamer.sdp.codec import CodecEntry
from reactor_runtime.transports.gstreamer.sdp.extmap import SdpExtmap
from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_many,
    link_pads,
    make_element,
)
from reactor_runtime.utils.log import get_logger

from .base import _SenderStreamBase

logger = get_logger(__name__)

# WebRTC stream/track identification (matches SDP a=msid and stream-id)
_DEFAULT_STREAM_ID = "default"


class RtpRtxSenderIds(NamedTuple):
    """Primary and RTX RTP identifiers for ``rtprtxsend`` map structures."""

    pt: int
    ssrc: Optional[int]
    rtx_pt: Optional[int]
    rtx_ssrc: Optional[int]


def _gst_caps_for_rtp_header_extensions(extmaps: List[SdpExtmap]) -> Gst.Caps:
    """
    Build ``application/x-rtp`` caps with ``extmap-<id>=(string)"<uri>"`` fields
    so downstream (e.g. rtpgccbwe) matches negotiated SDP ``a=extmap`` lines.
    """
    if not extmaps:
        raise ValueError("extmaps must be non-empty")
    seen_ids: set[int] = set()
    fields = ["application/x-rtp"]
    for em in extmaps:
        if em.id in seen_ids:
            raise ValueError(f"duplicate RTP header extension id: {em.id}")
        seen_ids.add(em.id)
        if em.id <= 0:
            raise ValueError(f"extmap id must be > 0, got {em.id}")
        uri = em.uri.strip()
        if not uri:
            raise ValueError("extmap uri must be non-empty")
        # Gst caps string: escape backslashes and double-quotes in the URI token.
        safe_uri = uri.replace("\\", "\\\\").replace('"', '\\"')
        fields.append(f'extmap-{em.id}=(string)"{safe_uri}"')
    return Gst.Caps.from_string(", ".join(fields))


class VideoSender(_SenderStreamBase):
    """
    ``Gst.Bin`` that turns raw frames into RTP for ``webrtcbin``:

        appsrc ! videoconvert ! queue ! encoder ! capsfilter (RTP header extensions) !
        (rtpgccbwe | identity)

    The last element is ``rtpgccbwe`` when that plugin exists, otherwise a no-op
    ``identity``. The ghost ``src`` pad is the RTP source of that element.

    Retransmission is **not** wired here. The WebRTC transport responds to
    ``webrtcbin``'s ``request-aux-sender`` with ``rtprtxsend`` and fills
    ``ssrc-map`` / ``payload-type-map`` from :meth:`get_rtprtx_sender_ids` and the
    ``pt``, ``ssrc``, ``rtx_pt``, and ``rtx_ssrc`` attributes so RTX matches SDP.

    The capsfilter after the payloader can set ``stream-id`` / ``msid`` on
    ``application/x-rtp`` caps so bundled sendonly tracks stay distinguishable.

    ``rtp_header_extensions`` lists negotiated ``SdpExtmap`` entries for this mid;
    pass ``[]`` or omit when none apply.
    """

    def __init__(
        self,
        codec_entry: CodecEntry,
        name: str = "video_sender",
        min_bitrate_kbps: int = VIDEO_BWE_MIN_BITRATE_KBPS,
        max_bitrate_kbps: int = VIDEO_BWE_MAX_BITRATE_KBPS,
        ssrc: Optional[int] = None,
        rtx_ssrc: Optional[int] = None,
        rtx_payload_type: Optional[int] = None,
        rtp_header_extensions: Optional[List[SdpExtmap]] = None,
    ):
        """
        Args:
            rtx_ssrc: RTX SSRC paired with ``ssrc`` for SDP FID and the transport's
                ``rtprtxsend`` ``ssrc-map``.
            rtx_payload_type: Negotiated RTX payload type (``apt=`` primary PT); used for
                the transport's ``rtprtxsend`` ``payload-type-map``.
        """
        super().__init__(name=name)

        encoding_name = codec_entry.get("codec")
        pt = codec_entry.get("payload_type")
        if not encoding_name or pt is None:
            raise ValueError("codec_entry must contain 'codec' and 'payload_type'")
        format_params = codec_entry.get("parameters") or {}

        self._pt = int(pt)
        self._ssrc = ssrc
        self._rtx_pt = int(rtx_payload_type) if rtx_payload_type is not None else None
        self._rtx_ssrc = int(rtx_ssrc) if rtx_ssrc is not None else None

        self._appsrc = make_element("appsrc", "appsrc")
        self._appsrc.set_property("format", Gst.Format.TIME)
        self._appsrc.set_property("is-live", True)
        self._appsrc.set_property("do-timestamp", True)
        self._appsrc.set_property("block", True)

        videoconvert = make_element("videoconvert", "videoconvert")
        queue_el = make_element("queue", "queue")
        queue_el.set_property("max-size-buffers", 1)
        queue_el.set_property("leaky", "downstream")

        self._encoder = EncoderFactory.create(
            encoding_name, pt, format_params, ssrc=ssrc
        )
        self._current_bitrate_kbps = VIDEO_BWE_TARGET_BITRATE_KBPS
        self._min_bitrate_kbps = min_bitrate_kbps
        self._max_bitrate_kbps = max_bitrate_kbps

        # Negotiated RTP header extensions (e.g. TWCC for rtpgccbwe); ids must match SDP per mid.
        exts = list(rtp_header_extensions) if rtp_header_extensions is not None else []
        self._rtp_hdr_ext_capsfilter = make_element(
            "capsfilter", "rtp_hdr_ext_capsfilter"
        )
        if exts:
            self._rtp_hdr_ext_capsfilter.set_property(
                "caps", _gst_caps_for_rtp_header_extensions(exts)
            )

        if Gst.ElementFactory.find("rtpgccbwe") is not None:
            bwe = make_element("rtpgccbwe", "bwe")
            bwe.set_property("min-bitrate", min_bitrate_kbps * 1000)
            bwe.set_property("max-bitrate", max_bitrate_kbps * 1000)
            bwe.connect(
                "notify::estimated-bitrate",
                self._on_bitrate_estimate,
            )
        else:
            bwe = make_element("identity", "identity")
            bwe.set_property("signal-handoffs", False)

        add_many(
            self,
            self._appsrc,
            videoconvert,
            queue_el,
            self._encoder,
            self._rtp_hdr_ext_capsfilter,
            bwe,
            sync_with_parent=True,
        )
        link_many(self._appsrc, videoconvert, queue_el)
        link_pads(queue_el.get_static_pad("src"), self._encoder.pad_sink())
        link_pads(
            self._encoder.pad_src(), self._rtp_hdr_ext_capsfilter.get_static_pad("sink")
        )
        link_pads(
            self._rtp_hdr_ext_capsfilter.get_static_pad("src"),
            bwe.get_static_pad("sink"),
        )

        pad_src = bwe.get_static_pad("src")
        if not pad_src:
            raise RuntimeError("element has no src pad")
        ghost_src = Gst.GhostPad.new("src", pad_src)
        if not ghost_src or not self.add_pad(ghost_src):
            raise RuntimeError("Failed to add ghost src pad to VideoSender")
        self._ghost_src: Gst.GhostPad = ghost_src

        # Per-sender caps and PTS (must be used only on GLib thread)
        self._outgoing_width = 0
        self._outgoing_height = 0

    @property
    def pt(self) -> int:
        """Negotiated RTP payload type for the primary (non-RTX) video codec."""
        return self._pt

    @property
    def ssrc(self) -> Optional[int]:
        """RTP SSRC for outgoing media (passed to the encoder / payloader)."""
        return self._ssrc

    @property
    def rtx_pt(self) -> Optional[int]:
        """Negotiated RTX payload type (``apt=`` primary PT), if retransmission is used."""
        return self._rtx_pt

    @property
    def rtx_ssrc(self) -> Optional[int]:
        """RTX SSRC paired with :attr:`ssrc` for FID / ``rtprtxsend`` ``ssrc-map``."""
        return self._rtx_ssrc

    def get_rtprtx_sender_ids(self) -> RtpRtxSenderIds:
        """Return stored RTP/RTX identifiers for building ``rtprtxsend`` maps."""
        return RtpRtxSenderIds(
            pt=self._pt,
            ssrc=self._ssrc,
            rtx_pt=self._rtx_pt,
            rtx_ssrc=self._rtx_ssrc,
        )

    def push_buffer(self, frame: np.ndarray) -> bool:
        """
        Extract dimensions and bytes from the frame (e.g. numpy array with .shape and .tobytes()),
        set appsrc caps if needed, create a Gst.Buffer, set PTS/duration, and push to the appsrc.
        Must be called from the thread that runs the GStreamer main loop.

        Returns:
            True if the buffer was pushed successfully (Gst.FlowReturn.OK), False otherwise
            or if frame has no .shape/.tobytes().
        """
        try:
            height, width = frame.shape[:2]
            data = frame.tobytes()
        except Exception:
            return False

        if width != self._outgoing_width or height != self._outgoing_height:
            caps = Gst.Caps.from_string(
                f"video/x-raw,format=RGB,width={width},height={height},framerate=30/1"
            )
            self._appsrc.set_property("caps", caps)
            self._outgoing_width = width
            self._outgoing_height = height

        buf = Gst.Buffer.new_wrapped(data)
        ret = self._appsrc.emit("push-buffer", buf)
        return ret == Gst.FlowReturn.OK

    def _on_bitrate_estimate(self, element: Gst.Element, pspec: object) -> None:
        """Handle bitrate estimate from rtpgccbwe (Google Congestion Control)."""
        estimated = element.get_property("estimated-bitrate")
        new_bitrate_kbps = estimated // 1000  # Convert to kbps

        logger.debug(
            f"GCC bitrate estimate: {estimated} bps -> {new_bitrate_kbps} kbps"
        )

        # Only update if change is significant (>5%)
        if abs(new_bitrate_kbps - self._current_bitrate_kbps) > (
            self._current_bitrate_kbps * 0.05
        ):
            old_bitrate = self._current_bitrate_kbps
            new_bitrate_kbps = max(
                self._min_bitrate_kbps,
                min(self._max_bitrate_kbps, new_bitrate_kbps),
            )
            self._current_bitrate_kbps = new_bitrate_kbps

            self._encoder.set_target_bitrate(new_bitrate_kbps * 1000)
            direction = "↑" if new_bitrate_kbps > old_bitrate else "↓"
            logger.debug(
                f"GCC bitrate {direction} {old_bitrate} → {new_bitrate_kbps} kbps"
            )
