# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
My first Reactor model — ReactorModel version.

Same model as pipeline.py, but using the lower-level ReactorModel base
class where you manage the run loop, events, and session lifecycle
explicitly.

Run with:  reactor run  (after updating reactor.yaml to point here)
"""

from typing import Any


from reactor_runtime.interface import (
    InputField,
    ReactorModel,
    connected,
    disconnected,
    event,
)

from pipeline import MyOutput, render_batch


# -- Model ---------------------------------------------------------------------


class MyModel(ReactorModel):
    fps = 30
    buffer_size = 8

    def load(self, config: dict[str, Any]) -> None:
        self.width = config.get("width", 640)
        self.height = config.get("height", 480)
        self.chunk_size = config.get("chunk_size", 4)
        self.brightness = 1.0

    @connected
    def on_connect(self):
        self.brightness = 1.0

    @disconnected
    def on_disconnect(self):
        self.output_buffer.flush()

    @event(name="set_brightness", description="Brightness multiplier")
    def set_brightness(
        self,
        brightness: float = InputField(default=1.0, ge=0.0, le=2.0),
    ):
        self.brightness = brightness

    async def run(self) -> None:
        while True:
            await self.connected.wait()
            frame_idx = 0

            while self.connected.is_set():
                # Sync work is fine here — events dispatch at await points
                batch, frame_idx = render_batch(
                    self.width,
                    self.height,
                    self.chunk_size,
                    frame_idx,
                    self.brightness,
                )
                await self.emit(MyOutput(main_video=batch))
