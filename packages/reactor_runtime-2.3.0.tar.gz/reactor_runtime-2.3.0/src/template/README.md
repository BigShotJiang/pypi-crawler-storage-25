# My Reactor Model

A real-time video model built with Reactor Runtime.

## Setup and run

```bash
pip install -r requirements.txt
reactor run
```

This starts the model locally. Connect with a WebRTC client at the URL printed by the runtime.

## Project structure

| File | Purpose |
|------|---------|
| `pipeline.py` | **ReactorPipeline** — generator pattern with auto state management (default) |
| `model.py` | **ReactorModel** — manual run loop with explicit events and lifecycle |
| `reactor.yaml` | Tells the runtime where to find your model class |
| `config.yml` | Model configuration (passed to `load()` as a dict) |
| `requirements.txt` | Extra Python dependencies |

## How it works

- **`MyOutput`** declares the video track the model sends to clients.
- **`MyState`** declares parameters clients can change in real-time. Each field auto-generates a `set_<field>` event — no handler code needed.
- **`inference()`** is a generator that yields frames in batches. Read `self.state` to pick up the latest client values.
- **`load()`** runs once at startup — put weight loading here.

## Switching to the ReactorModel version

Edit `reactor.yaml` and change the model entry:

```yaml
model: model:MyModel
```

Then run again. The ReactorModel version gives you full control over the run loop, events, and session lifecycle.

## Next steps

- Add `Input` tracks to receive webcam video from the client
- Add `@event` handlers for custom logic (e.g. encoding a prompt)
- Add `ModelMessage` subclasses to send structured data back to the client
