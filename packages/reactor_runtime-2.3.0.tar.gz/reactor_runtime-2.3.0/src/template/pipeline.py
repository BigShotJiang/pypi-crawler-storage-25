# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
My first Reactor model — ReactorPipeline version.

Generates animated gradient frames with a client-controllable brightness
multiplier. Frames are produced in configurable chunks to demonstrate
batch yielding.

Run with:  reactor run
"""

from dataclasses import dataclass
from typing import Any
import time

import numpy as np
from PIL import Image, ImageDraw

from reactor_runtime.interface import (
    InputField,
    InputState,
    Output,
    ReactorPipeline,
    Video,
)


# -- Tracks --------------------------------------------------------------------


@dataclass
class MyOutput(Output):
    main_video: Video


# -- State ---------------------------------------------------------------------


@dataclass
class MyState(InputState):
    brightness: float = InputField(
        default=1.0, ge=0.0, le=2.0, description="Brightness multiplier"
    )


# -- Model ---------------------------------------------------------------------


class MyModel(ReactorPipeline):
    state: MyState
    buffer_size = 8

    def load(self, config: dict[str, Any]) -> None:
        self.width = config.get("width", 640)
        self.height = config.get("height", 480)
        self.chunk_size = config.get("chunk_size", 4)

    def inference(self):
        frame_idx = 0
        while True:
            batch, frame_idx = render_batch(
                self.width,
                self.height,
                self.chunk_size,
                frame_idx,
                self.state.brightness,
            )
            yield MyOutput(main_video=batch)


# -- Rendering -----------------------------------------------------------------


_FRAME_BUDGET = 1 / 30


def render_batch(
    width: int,
    height: int,
    chunk_size: int,
    start_idx: int,
    brightness: float,
) -> tuple[np.ndarray, int]:
    """Generate a batch of animated gradient frames with brightness applied.

    Returns the batch as ``(N, H, W, 3)`` uint8 and the next frame index.
    """
    frames = []
    for i in range(chunk_size):
        idx = start_idx + i
        t0 = time.perf_counter()

        img = np.zeros((height, width, 3), dtype=np.float32)
        ys = np.linspace(0, 1, height, dtype=np.float32)[:, None]
        img[:, :, 0] = ys * 128
        img[:, :, 2] = (1 - ys) * 128

        bar_x = (idx * 4) % width
        bar_w = max(1, width // 20)
        img[:, bar_x : min(width, bar_x + bar_w), 1] = 128

        img = np.clip(img * brightness, 0, 255).astype(np.uint8)
        img = draw_text(img, f"Frame {idx}  |  Brightness {brightness:.1f}")
        frames.append(img)

        remaining = _FRAME_BUDGET - (time.perf_counter() - t0)
        if remaining > 0:
            time.sleep(remaining)

    return np.stack(frames), start_idx + chunk_size


def draw_text(
    frame: np.ndarray,
    text: str,
    position: tuple = (16, 30),
) -> np.ndarray:
    """Draw white text with a dark outline onto a frame."""
    img = Image.fromarray(frame)
    draw = ImageDraw.Draw(img)
    x, y = position
    for dx, dy in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
        draw.text((x + dx, y + dy), text, fill=(0, 0, 0))
    draw.text((x, y), text, fill=(255, 255, 255))
    return np.array(img)
