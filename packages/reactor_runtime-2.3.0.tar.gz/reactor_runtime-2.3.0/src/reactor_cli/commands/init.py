# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Init command — scaffolds a new Reactor model workspace."""

import pathlib
import importlib.resources


_TEMPLATE_FILES = {
    "pipeline.py": "pipeline.py",
    "model.py": "model.py",
    "reactor.yaml": "reactor.yaml",
    "config.yml": "config.yml",
    "requirements.txt": "requirements.txt",
    "README.md": "README.md",
}


class InitCommand:
    @staticmethod
    def register_subcommand(subparsers):
        """Register init command"""
        init_parser = subparsers.add_parser(
            "init", help="Initialize a new reactor model workspace"
        )
        init_parser.add_argument(
            "name", help="Name of the model (will create directory with this name)"
        )
        init_parser.set_defaults(func=InitCommand)

    def __init__(self, args):
        self.args = args

    def run(self):
        """Initialize a new reactor model workspace in a directory with the given name."""
        model_name = self.args.name
        target_dir = pathlib.Path.cwd() / model_name

        # Check if directory already exists
        if target_dir.exists():
            print(f"Error: Directory '{model_name}' already exists")
            print("Please choose a different name or remove the existing directory")
            return

        # Create the model directory
        try:
            target_dir.mkdir()
        except Exception as e:
            print(f"Error creating directory '{model_name}': {e}")
            return

        # Load the template package (ships with reactor_runtime)
        try:
            import template as template_package
        except ImportError:
            print(
                "Error: template package not found. "
                "Make sure reactor_runtime is properly installed."
            )
            target_dir.rmdir()
            return

        # Copy template files from the installed package into the new directory
        created = []
        for dest_name, src_name in _TEMPLATE_FILES.items():
            dest_path = target_dir / dest_name
            try:
                # Read from package resources so this works for both editable
                # installs and proper wheel installs
                content = (
                    importlib.resources.files(template_package)
                    .joinpath(src_name)
                    .read_text(encoding="utf-8")
                )
                dest_path.write_text(content)
                created.append(dest_name)
            except FileNotFoundError:
                print(f"Warning: template file {src_name} not found, skipping")

        if not created:
            print("Error: no template files were created")
            target_dir.rmdir()
            return

        for name in created:
            print(f"  {name}")

        print(f"\nReactor workspace '{model_name}' created.")
        print(f"\n  cd {model_name}")
        print("  pip install -r requirements.txt")
        print("  reactor run\n")
