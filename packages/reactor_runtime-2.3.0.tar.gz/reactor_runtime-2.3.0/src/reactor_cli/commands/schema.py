# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Schema command — prints or writes the model's OpenAPI 3.1 schema."""

import json
import re
import sys
from pathlib import Path

from omegaconf import OmegaConf

from reactor_runtime.schema import ModelSchema
from reactor_runtime.config import ReactorConfig
from reactor_runtime.utils.loader import resolve_class
from reactor_runtime.utils.launch import add_import_paths

_REACTOR_YAML = "reactor.yaml"

_VERSION_PATTERN = re.compile(r"^v?\d+\.\d+\.\d+(-g[0-9a-f]+)?$")
# Describes valid --version input. Reused by both the --version argparse
# help text and the error message on pattern mismatch. Starts with a
# capitalised "Format:" so it reads naturally both standalone and after
# "Error: invalid --version 'bad': ".
_VERSION_FORMAT_HINT = (
    "Format: 'X.Y.Z' or 'X.Y.Z-g<hex>', optionally with a 'v' prefix "
    "(e.g. '2.2.1', 'v2.2.1', '2.2.1-gac767ec', 'v2.2.1-gac767ec'). "
    "The 'v' prefix is optional on input — the emitted schema always "
    "carries it."
)


class SchemaCommand:
    @staticmethod
    def register_subcommand(subparsers):
        """Register schema command."""
        run_parser = subparsers.add_parser(
            "schema", help="Print or write the model's OpenAPI schema."
        )
        run_parser.add_argument(
            "--path",
            "-p",
            type=str,
            default=None,
            help="Path to model directory (default: current directory)",
        )
        run_parser.add_argument(
            "--version",
            "-v",
            type=str,
            default=None,
            help=(
                "Override the schema version emitted in info.version. "
                f"{_VERSION_FORMAT_HINT} Default: v0.0.0."
            ),
        )
        run_parser.add_argument(
            "--out",
            "-o",
            type=str,
            default=None,
            help=(
                "Write the schema JSON to this path instead of printing to "
                "stdout. Parent directories are created if missing."
            ),
        )
        run_parser.set_defaults(func=SchemaCommand)

    def __init__(self, args):
        """Initialize with parsed arguments."""
        self.args = args

    def run(self):
        """Emit the OpenAPI schema of a Reactor model.

        Loads the model class (triggering auto-registration of tracks,
        events, and messages in the global registries), builds the
        schema from those registries, optionally overrides the version,
        and either prints the JSON to stdout or writes it to ``--out``.
        """
        if self.args.version is not None and not _VERSION_PATTERN.match(
            self.args.version
        ):
            print(
                f"Error: invalid --version {self.args.version!r}: "
                f"{_VERSION_FORMAT_HINT}",
                file=sys.stderr,
            )
            sys.exit(1)

        model_path = Path(self.args.path).resolve() if self.args.path else Path.cwd()

        reactor_yaml_path = model_path / _REACTOR_YAML
        if not reactor_yaml_path.exists():
            print(f"Error: {_REACTOR_YAML} not found in {model_path}", file=sys.stderr)
            sys.exit(1)

        raw_yaml = OmegaConf.to_container(
            OmegaConf.load(str(reactor_yaml_path)), resolve=True
        )
        if not isinstance(raw_yaml, dict) or "model" not in raw_yaml:
            print(
                f"Error: {_REACTOR_YAML} must contain a 'model' field",
                file=sys.stderr,
            )
            sys.exit(1)

        reactor_config = ReactorConfig.from_dict(raw_yaml)

        add_import_paths([str(model_path)])

        try:
            model_cls = resolve_class(reactor_config.model)
        except Exception as e:
            print(f"Error loading model class: {e}", file=sys.stderr)
            sys.exit(1)

        try:
            schema = ModelSchema.from_config(reactor_config, model_cls=model_cls)
        except Exception as e:
            print(f"Error extracting schema: {e}", file=sys.stderr)
            sys.exit(1)

        if self.args.version is not None:
            # Honour the ModelSchema.version invariant: the internal value
            # always carries a 'v' prefix, matching the release-tag format
            # stored in the Coordinator's schema registry. to_openapi()
            # emits it as-is; to_legacy_tracks_only() is the only place
            # that strips it for the legacy wire protocol_version field.
            # See ModelSchema's class docstring.
            v = self.args.version
            schema.version = v if v.startswith("v") else f"v{v}"

        openapi_doc = schema.to_openapi()
        model_name = reactor_config.name or reactor_config.model

        if self.args.out is not None:
            out_path = Path(self.args.out).expanduser().resolve()
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps(openapi_doc, indent=4))
            emitted_version = openapi_doc["info"]["version"]
            print(
                f"Model: {model_name} — schema ({emitted_version}) written to "
                f"{out_path}"
            )
        else:
            print(f"Model: {model_name}")
            print(json.dumps(openapi_doc, indent=4))
