"""
core.py - MCP input security validation logic for mcp-marshal.
"""

from __future__ import annotations

from typing import Any, Dict, List


# Patterns considered risky in MCP payloads
_RISKY_PATTERNS: List[Dict[str, str]] = [
    {"pattern": "DROP TABLE",  "severity": "critical"},
    {"pattern": "DELETE FROM", "severity": "critical"},
    {"pattern": "--",          "severity": "medium"},
    {"pattern": ";--",         "severity": "high"},
    {"pattern": "' OR '1'='1", "severity": "critical"},
    {"pattern": "UNION SELECT", "severity": "critical"},
    {"pattern": "<script>",    "severity": "high"},
    {"pattern": "javascript:", "severity": "high"},
]


class Warden:
    """
    Warden inspects MCP tool-call payloads for risky patterns before
    they are forwarded to a model or executed by a tool handler.

    Usage::

        from mcpwarden import Warden

        warden = Warden()
        result = warden.validate_input({"query": "SELECT * FROM users; DROP TABLE users;--"})
        if not result["valid"]:
            for issue in result["issues"]:
                print(issue)
    """

    def __init__(self, extra_patterns: List[Dict[str, str]] | None = None) -> None:
        """
        Initialise Warden with the built-in pattern set.

        :param extra_patterns: Optional list of additional pattern dicts.
            Each dict must have ``pattern`` (str) and ``severity``
            (``"low"`` | ``"medium"`` | ``"high"`` | ``"critical"``) keys.
        """
        self._patterns = list(_RISKY_PATTERNS)
        if extra_patterns:
            self._patterns.extend(extra_patterns)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate_input(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Scan all string values in *payload* for risky patterns.

        :param payload: A flat or nested dict representing an MCP tool-call
            input (e.g. ``{"query": "...", "context": "..."}``.
        :returns: A result dict::

            {
                "valid": bool,          # True if no issues were found
                "issues": [             # Empty list when valid=True
                    {
                        "field":    str,   # dot-path to the offending field
                        "pattern":  str,   # matched risky pattern
                        "severity": str,   # low / medium / high / critical
                    },
                    ...
                ]
            }
        """
        if not isinstance(payload, dict):
            raise TypeError(f"validate_input expects a dict, got {type(payload).__name__!r}")

        issues: List[Dict[str, str]] = []
        self._scan(payload, prefix="", issues=issues)

        return {"valid": len(issues) == 0, "issues": issues}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _scan(
        self,
        obj: Any,
        prefix: str,
        issues: List[Dict[str, str]],
    ) -> None:
        """Recursively walk *obj* and collect pattern matches."""
        if isinstance(obj, dict):
            for key, value in obj.items():
                path = f"{prefix}.{key}" if prefix else key
                self._scan(value, path, issues)
        elif isinstance(obj, (list, tuple)):
            for idx, item in enumerate(obj):
                path = f"{prefix}[{idx}]"
                self._scan(item, path, issues)
        elif isinstance(obj, str):
            self._check_string(obj, prefix, issues)

    def _check_string(
        self,
        value: str,
        field: str,
        issues: List[Dict[str, str]],
    ) -> None:
        """Check a single string value against all risky patterns."""
        upper = value.upper()
        for entry in self._patterns:
            if entry["pattern"].upper() in upper:
                issues.append(
                    {
                        "field":    field,
                        "pattern":  entry["pattern"],
                        "severity": entry["severity"],
                    }
                )
