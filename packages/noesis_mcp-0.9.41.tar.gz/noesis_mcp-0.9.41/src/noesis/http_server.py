"""OpenAI-compatible HTTP server for MCP Brain.

Serves POST /v1/chat/completions - proxies requests through the adaptive
cognitive pipeline and streams SSE responses back in OpenAI format.

Usage:
    mcp-brain-http                    # default 0.0.0.0:8080
    mcp-brain-http --port 9000       # custom port
    mcp-brain-http --help            # see all options
"""

import os
import sys
import json
import re
import time
import uuid
import asyncio
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

import fastapi
from fastapi import Request, Response
from fastapi.responses import StreamingResponse
import uvicorn

# Add src to path for editable installs
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from noesis.mcp_core import MCP
from noesis.tools import TOOL_REGISTRY
from noesis.minimax_client import METRICS, MiniMaxClient
from noesis.logging_config import new_correlation_id, configure_logging, log

# Configure structured logging at import time
configure_logging()

APP = fastapi.FastAPI(
    title="MCP Brain",
    description="OpenAI-compatible API for the adaptive multi-agent cognitive pipeline",
    version="0.9.41",
)

_START_TIME = time.monotonic()
_START_UTC = datetime.now(timezone.utc).isoformat()

# ── API key retrieval ─────────────────────────────────────────────────────────


def get_api_key() -> Optional[str]:
    """Check environment variable and config file for API key on each call.

    Checks (1) environment variable and (2) ~/.mcp/config.json.
    No caching - always re-checked on every request to pick up changes.
    """
    return os.environ.get("MINIMAX_API_KEY") or _load_config_key()


def _load_config_key() -> Optional[str]:
    try:
        path = Path("~/.mcp/config.json").expanduser()
        if path.exists():
            return json.loads(path.read_text()).get("api_key")
    except Exception:
        pass
    return None

# ── Shared MiniMaxClient (connection pool reuse) ─────────────────────────────
_shared_client: Optional[MiniMaxClient] = None
_shared_client_lock = asyncio.Lock()


async def get_shared_client(api_key: str) -> MiniMaxClient:
    """Get or create the shared MiniMax client for connection pooling."""
    global _shared_client
    async with _shared_client_lock:
        if _shared_client is None:
            _shared_client = MiniMaxClient(api_key=api_key)
        return _shared_client


# ── Correlation ID + CORS middleware ─────────────────────────────────────────

@APP.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    """Extract or generate a correlation ID for request tracing; add CORS headers to all responses."""
    cid = request.headers.get("x-correlation-id") or new_correlation_id()
    request.state.correlation_id = cid
    response = await call_next(request)
    response.headers["x-correlation-id"] = cid
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type, X-API-Key, X-Correlation-ID"
    response.headers["Access-Control-Max-Age"] = "86400"
    return response


# ── Health Check Endpoint ─────────────────────────────────────────────────────


@APP.get("/health")
async def health_check():
    """Health check endpoint that validates MiniMax API credentials and reports connectivity status.

    Returns:
        JSON with overall status, API key presence, and MiniMax API connectivity.
    """
    result = {
        "status": "unknown",
        "uptime_seconds": round(time.monotonic() - _START_TIME, 2),
        "started_at": _START_UTC,
        "version": "0.9.39",
        "api_key": {
            "configured": False,
            "source": None,
            "valid": None,
        },
        "minimax_api": {
            "reachable": None,
            "latency_ms": None,
            "error": None,
            "models_available": None,
        },
        "mcp_configured": False,
    }

    # Check API key presence
    env_key = os.environ.get("MINIMAX_API_KEY")
    config_key = _load_config_key()

    if env_key:
        result["api_key"]["configured"] = True
        result["api_key"]["source"] = "environment"
        api_key = env_key
    elif config_key:
        result["api_key"]["configured"] = True
        result["api_key"]["source"] = "config_file"
        api_key = config_key
    else:
        result["api_key"]["configured"] = False
        result["api_key"]["source"] = None
        result["status"] = "degraded"
        return result

    # Check MCP configuration
    try:
        mcp = MCP(skip_api_key_check=True)
        result["mcp_configured"] = mcp.is_setup()
    except Exception:
        result["mcp_configured"] = False

    # Validate API key by calling MiniMax API
    if result["api_key"]["configured"] and api_key:
        client = MiniMaxClient(api_key=api_key)
        start = time.monotonic()
        try:
            models = await client.list_models()
            result["minimax_api"]["reachable"] = True
            result["minimax_api"]["latency_ms"] = round((time.monotonic() - start) * 1000, 2)
            result["minimax_api"]["models_available"] = len(models) if models else 0
            result["api_key"]["valid"] = True
        except Exception as e:
            result["minimax_api"]["reachable"] = False
            result["minimax_api"]["latency_ms"] = round((time.monotonic() - start) * 1000, 2)
            result["minimax_api"]["error"] = str(e)
            result["api_key"]["valid"] = False
            result["status"] = "unhealthy"
            return result

    # All checks passed
    result["status"] = "healthy" if result["minimax_api"]["reachable"] else "unhealthy"
    return result


@APP.head("/health")
async def health_check_head():
    """HEAD version of health check for load balancer probes."""
    return Response(status_code=200)


# ── Metrics Endpoint (Prometheus format) ─────────────────────────────────────


@APP.get("/metrics")
async def metrics():
    """Expose metrics in Prometheus exposition format for production observability.

    Returns all in-process counters and gauges from the METRICS registry in
    Prometheus text format. Suitable for Prometheus scraping and alerting.

    Note: METRICS values are exported as gauges by default. Applications
    should use counters for monotonically increasing values (request counts,
    token totals) and histograms for latency distributions.
    """
    lines = [
        "# HELP noesis_uptime_seconds Time since server start in seconds",
        "# TYPE noesis_uptime_seconds gauge",
        f"noesis_uptime_seconds {round(time.monotonic() - _START_TIME, 2)}",
        "",
        "# HELP noesis_info Server version and build information",
        "# TYPE noesis_info gauge",
        f'noesis_info{{version="{APP.version}"}} 1',
        "",
    ]

    # Safely iterate METRICS with error handling
    try:
        if METRICS and isinstance(METRICS, dict):
            for key, value in METRICS.items():
                try:
                    # Convert value to float for Prometheus compatibility
                    numeric_value = float(value) if value is not None else 0
                    # Sanitize metric name for use as label value
                    safe_name = _sanitize_metric_name(str(key))
                    # Use counter type for metrics with "count", "total", "requests" in name
                    # Use gauge type for all others
                    metric_type = "counter" if any(x in safe_name.lower() for x in ("count", "total", "requests", "tokens")) else "gauge"
                    lines.append(f"# HELP noesis_metric_{safe_name} Metric exported from METRICS registry")
                    lines.append(f"# TYPE noesis_metric_{safe_name} {metric_type}")
                    lines.append(f"noesis_metric_{safe_name}{{name=\"{safe_name}\"}} {numeric_value}")
                except (ValueError, TypeError, OverflowError):
                    # Skip metrics with non-numeric values
                    continue
            lines.append("")
    except Exception:
        # If METRICS iteration fails, log and return basic server metrics
        lines.append("# HELP noesis_metrics_error Error accessing METRICS registry")
        lines.append("# TYPE noesis_metrics_error gauge")
        lines.append("noesis_metrics_error{error=\"registry_access_failed\"} 1")
        lines.append("")

    return Response(content="".join(lines), media_type="text/plain; version=0.0.4; charset=utf-8")


def _sanitize_metric_name(name: str) -> str:
    """Sanitize a metric name for Prometheus label/value compatibility.

    Replaces non-alphanumeric characters with underscores and ensures
    uniqueness by appending a numeric suffix if collisions occur.
    """
    # Replace any character that's not alphanumeric or underscore with underscore
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', str(name))
    # Ensure the result starts with a letter
    if sanitized and sanitized[0].isdigit():
        sanitized = '_' + sanitized
    return sanitized


@APP.head("/metrics")
async def metrics_head():
    """HEAD version of metrics endpoint for load balancer probes."""
    return Response(status_code=200)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _resolve_model(model: str) -> str:
    """Map user-facing model names to MiniMax API model names."""
    if model in ("mcp-brain", "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"):
        return "MiniMax-M2.7"
    return model


def _build_token_chunk(content: str, model: str = "mcp-brain") -> dict:
    """Build an OpenAI chat completion chunk for a text token."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [{
            "index": 0,
            "delta": {"content": content},
            "finish_reason": None,
        }],
    }


def _build_done_chunk(usage: dict) -> dict:
    """Build the final [DONE] chunk with usage stats."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": "mcp-brain",
        "choices": [{
            "index": 0,
            "delta": {},
            "finish_reason": "stop",
        }],
        "usage": usage,
    }


# ── Think-tag / reasoning filter ─────────────────────────────────────────────

# Think tag open/close patterns - `` ... `` blocks
_THINK_OPEN = re.compile(r"``")
_THINK_CLOSE = re.compile(r"``")

# Alternative think tag patterns -  /  /  /  /  /  blocks
_THINK_OPEN_ALT = re.compile(r"<(?:think|THINK)")
_THINK_CLOSE_ALT = re.compile(r"/>")

# MiniMax reasoning format - [COMPLEXITY: X], [REASON: ...], [TOOL_CALL], [OUTPUT], [NOTES], [NEXT_PLAN]
# The colon is optional - [TOOL_CALL] has no colon, while others do: [COMPLEXITY: X]
_MINIMAX_OPEN = re.compile(r"\[(COMPLEXITY|REASON|TOOL_CALL|OUTPUT|NOTES|NEXT_PLAN):?")
_MINIMAX_CLOSE = re.compile(r"\]")
_MINIMAX_SEP = re.compile(r"^\s*---\s*$", re.MULTILINE)  # Horizontal rule separators


def _make_think_filter():
    """Create a fresh state machine instance for filtering think/reasoning tags.

    Filters three formats:
    1. `` ... ``
    2.  /  /  /  /  /  blocks
    3. --- separators between reasoning sections
    """
    in_think = False
    in_minimax = False

    def _process_token(content: str) -> Optional[str]:
        nonlocal in_think, in_minimax
        if not content:
            return None
        result_parts = []
        remaining = content

        while remaining:
            # Handle MiniMax [LABEL: ...] blocks
            if in_minimax:
                m = _MINIMAX_CLOSE.search(remaining)
                if m:
                    in_minimax = False
                    remaining = remaining[m.end():]
                else:
                    # No closing tag in this chunk - suppress output and
                    # preserve state so next chunk continues from here
                    return None
                continue

            if in_think:
                m = _THINK_CLOSE.search(remaining) or _THINK_CLOSE_ALT.search(remaining)
                if m:
                    in_think = False
                    remaining = remaining[m.end():]
                else:
                    # No closing tag in this chunk - suppress output and
                    # preserve state so next chunk continues from here
                    return None
                continue

            # Try standard think tags (only if not already in a block)
            m = _THINK_OPEN.search(remaining) or _THINK_OPEN_ALT.search(remaining)
            if m:
                before = remaining[:m.start()]
                if before:
                    result_parts.append(before)
                in_think = True
                remaining = remaining[m.end():]
                continue

            # Stray closing tag with no opening - treat as plain text, not tag
            m = _THINK_CLOSE.search(remaining) or _THINK_CLOSE_ALT.search(remaining)
            if m:
                before = remaining[:m.start()]
                result_parts.append(before)
                remaining = remaining[m.end():]
                continue

            # Try MiniMax reasoning tags
            m = _MINIMAX_OPEN.search(remaining)
            if m:
                before = remaining[:m.start()]
                if before:
                    result_parts.append(before)
                in_minimax = True
                remaining = remaining[m.end():]
                continue

            # Try --- separator (drop it)
            m = _MINIMAX_SEP.match(remaining)
            if m:
                remaining = remaining[m.end():]
                continue

            # No more tags - append rest and done
            result_parts.append(remaining)
            break

        out = "".join(result_parts)
        return out if out else None

    return _process_token


def _filter_think_tags(content: str) -> str:
    """Strip all think/reasoning tags from content.

    Processes the full string in one pass so state (in_think/in_minimax)
    persists across newlines - fixes multi-line `` blocks that would
    otherwise leak through with per-line processing.
    """
    if not content:
        return ""
    filter_fn = _make_think_filter()
    # Process whole content at once - state persists across newlines
    result = filter_fn(content)
    return (result or "").strip()


# ── Passthrough mode ─────────────────────────────────────────────────────────

async def _stream_passthrough(messages: List[dict], model: str, max_tokens: int, tools: Optional[List[dict]], api_key: str):
    """Forward messages + tools directly to MiniMax, bypassing the cognitive pipeline."""
    client = await get_shared_client(api_key)
    actual_model = _resolve_model(model)
    think_filter = _make_think_filter()

    try:
        async for event in client.generate_stream_from_messages(
            messages=messages,
            model=actual_model,
            max_tokens=max_tokens,
            tools=tools if tools else None,
        ):
            if isinstance(event, dict):
                if event.get("type") == "token":
                    filtered = think_filter(event.get("content", ""))
                    if filtered is not None:
                        chunk = _build_token_chunk(filtered, actual_model)
                        yield f"data: {json.dumps(chunk)}\n\n"
                elif event.get("type") == "tool_call":
                    chunk = {
                        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                        "object": "chat.completion.chunk",
                        "created": int(time.time()),
                        "model": model or "mcp-brain",
                        "choices": [{
                            "index": 0,
                            "delta": {
                                "content": None,
                                "tool_calls": [{
                                    "index": event.get("index", 0),
                                    "id": f"call_{uuid.uuid4().hex[:8]}",
                                    "type": "function",
                                    "function": {
                                        "name": event.get("name", ""),
                                        "arguments": event.get("arguments", ""),
                                    },
                                }],
                            },
                            "finish_reason": "tool_calls",
                        }],
                    }
                    yield f"data: {json.dumps(chunk)}\n\n"
                    yield "data: [DONE]\n\n"
                    return
            else:
                filtered = think_filter(event)
                if filtered is not None:
                    chunk = _build_token_chunk(filtered, actual_model)
                    yield f"data: {json.dumps(chunk)}\n\n"
    except Exception as e:
        log.error("passthrough_stream_error", error=str(e))
        error_chunk = {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": actual_model,
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "error",
                "error": {
                    "message": f"Stream interrupted: {str(e)}",
                    "type": "internal_server_error",
                    "code": "stream_error",
                },
            }],
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"
        yield "data: [DONE]\n\n"
        return

    # Final done chunk
    done = _build_done_chunk({"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1})
    yield f"data: {json.dumps(done)}\n\n"
    yield "data: [DONE]\n\n"


# ── Pipeline mode ─────────────────────────────────────────────────────────────


async def _stream_pipeline(mcp: MCP, task: str, model: Optional[str], functions: Optional[List[dict]]):
    """Drain the cognitive pipeline and yield OpenAI-compatible SSE tokens."""
    think_filter = _make_think_filter()
    actual_model = model or "mcp-brain"
    _sent_done = False  # Guard against double [DONE] on re-entry

    try:
        async for event in mcp.process_task_stream_async(task, functions):
            etype = event.get("type")

            if etype == "function_call":
                chunk = {
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": model or "mcp-brain",
                    "choices": [{
                        "index": 0,
                        "delta": {
                            "content": None,
                            "tool_calls": [{
                                "index": 0,
                                "id": f"call_{uuid.uuid4().hex[:8]}",
                                "type": "function",
                                "function": {
                                    "name": event["name"],
                                    "arguments": event["arguments"],
                                },
                            }],
                        },
                        "finish_reason": "tool_calls",
                    }],
                }
                yield f"data: {json.dumps(chunk)}\n\n"
                done_chunk = _build_done_chunk({"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1})
                yield f"data: {json.dumps(done_chunk)}\n\n"
                yield "data: [DONE]\n\n"
                _sent_done = True
                return

            elif etype == "token":
                content = event.get("content", "")
                filtered = think_filter(content)
                if filtered is not None:
                    chunk = _build_token_chunk(filtered, actual_model)
                    yield f"data: {json.dumps(chunk)}\n\n"

            elif etype == "done":
                usage = event.get("usage", {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1})
                done = _build_done_chunk(usage)
                yield f"data: {json.dumps(done)}\n\n"
                yield "data: [DONE]\n\n"
                _sent_done = True
                return

            elif etype == "error":
                error_msg = event.get("error", "Unknown pipeline error")
                log.error("pipeline_stream_error", error=error_msg)
                error_chunk = {
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": actual_model,
                    "choices": [{
                        "index": 0,
                        "delta": {},
                        "finish_reason": "error",
                        "error": {
                            "message": error_msg,
                            "type": "internal_server_error",
                            "code": "pipeline_error",
                        },
                    }],
                }
                yield f"data: {json.dumps(error_chunk)}\n\n"
                yield "data: [DONE]\n\n"
                _sent_done = True
                return

    except Exception as e:
        log.error("pipeline_stream_exception", error=str(e))
        if not _sent_done:
            error_chunk = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": actual_model,
                "choices": [{
                    "index": 0,
                    "delta": {},
                    "finish_reason": "error",
                    "error": {
                        "message": f"Pipeline exception: {str(e)}",
                        "type": "internal_server_error",
                        "code": "pipeline_exception",
                    },
                }],
            }
            yield f"data: {json.dumps(error_chunk)}\n\n"
            yield "data: [DONE]\n\n"


# ── Chat Completions Endpoint ─────────────────────────────────────────────────


@APP.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """OpenAI-compatible chat completions endpoint with cognitive pipeline support.

    Accepts standard OpenAI chat completion requests. Uses the adaptive cognitive
    pipeline when no tools are specified, otherwise delegates to MiniMax with
    passthrough mode. Supports streaming SSE responses.
    """
    try:
        body = await request.json()
    except Exception:
        return Response(content=json.dumps({"error": "Invalid JSON body"}), media_type="application/json", status_code=400)

    # Extract standard OpenAI fields
    messages = body.get("messages", [])
    model = body.get("model", "mcp-brain")
    max_tokens = body.get("max_tokens", 4096)
    stream = body.get("stream", False)
    functions = body.get("functions")
    tools = body.get("tools")
    # Support OpenAI-style functions or Anthropic-style tools
    if functions and not tools:
        tools = [{"type": "function", "function": f} for f in functions]

    if not messages:
        return Response(content=json.dumps({"error": "messages is required"}), media_type="application/json", status_code=400)

    # Resolve API key
    api_key = get_api_key()
    if not api_key:
        return Response(
            content=json.dumps({"error": {"message": "MiniMax API key not configured", "type": "authentication_error", "code": "api_key_missing"}}),
            media_type="application/json",
            status_code=401,
        )

    # Build the task string from messages (system + conversation)
    task_parts = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if content:
            task_parts.append(f"[{role}] {content}")
    task = "\n".join(task_parts)

    # Use pipeline mode (cognitive processing) when no tools specified, otherwise passthrough
    use_pipeline = not tools and not functions

    if stream:
        if use_pipeline:
            return StreamingResponse(
                _stream_pipeline(MCP(skip_api_key_check=True), task, model, None),
                media_type="text/event-stream",
                headers={"x-correlation-id": new_correlation_id()},
            )
        else:
            return StreamingResponse(
                _stream_passthrough(messages, model, max_tokens, tools, api_key),
                media_type="text/event-stream",
                headers={"x-correlation-id": new_correlation_id()},
            )
    else:
        # Non-streaming: accumulate full response
        if use_pipeline:
            mcp = MCP(skip_api_key_check=True)
            chunks = []
            async for event in mcp.process_task_stream_async(task, None):
                etype = event.get("type")
                if etype == "token":
                    content = event.get("content", "")
                    filtered = _filter_think_tags(content)
                    if filtered:
                        chunks.append(filtered)
                elif etype == "function_call":
                    # In non-streaming mode, return function call as final delta
                    chunks.append(f"\n[tool call: {event['name']}]\n")
                elif etype == "done":
                    break
            content = "".join(chunks)
            return Response(
                content=json.dumps({
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion",
                    "created": int(time.time()),
                    "model": model or "mcp-brain",
                    "choices": [{
                        "index": 0,
                        "message": {"role": "assistant", "content": content},
                        "finish_reason": "stop",
                    }],
                    "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
                }),
                media_type="application/json",
            )
        else:
            # Passthrough non-streaming
            client = await get_shared_client(api_key)
            response = await client.generate_from_messages(
                messages=messages,
                model=_resolve_model(model),
                max_tokens=max_tokens,
                tools=tools,
            )
            return Response(
                content=json.dumps({
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion",
                    "created": int(time.time()),
                    "model": model or "mcp-brain",
                    "choices": [{
                        "index": 0,
                        "message": {"role": "assistant", "content": response},
                        "finish_reason": "stop",
                    }],
                    "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
                }),
                media_type="application/json",
            )


@APP.get("/v1/models")
async def list_models():
    """List available models in OpenAI-compatible format."""
    api_key = get_api_key()
    if not api_key:
        return Response(content=json.dumps({"error": "Not authenticated"}), media_type="application/json", status_code=401)
    try:
        client = MiniMaxClient(api_key=api_key)
        models = await client.list_models()
        return Response(
            content=json.dumps({
                "object": "list",
                "data": [
                    {
                        "id": m["id"],
                        "object": "model",
                        "created": int(time.time()),
                        "owned_by": "minimax",
                    }
                    for m in models
                ],
            }),
            media_type="application/json",
        )
    except Exception as e:
        return Response(content=json.dumps({"error": str(e)}), media_type="application/json", status_code=500)


# ── Discovery endpoint ───────────────────────────────────────────────────────


@APP.get("/.well-known/openapi.yaml")
async def openapi_yaml():
    """Serve the OpenAPI spec as YAML for client tooling."""
    from fastapi.openapi.utils import get_openapi
    spec = get_openapi(title=APP.title, version=APP.version, routes=APP.routes)
    import yaml
    return Response(content=yaml.dump(spec), media_type="text/yaml")


# ── Server bootstrap ─────────────────────────────────────────────────────────


def run():
    parser = argparse.ArgumentParser(description="MCP Brain HTTP Server")
    parser.add_argument("--host", default=os.environ.get("MCP_HOST", "0.0.0.0"), help="Bind host")
    parser.add_argument("--port", type=int, default=int(os.environ.get("MCP_PORT", "8080")), help="Bind port")
    parser.add_argument("--workers", type=int, default=1, help="Number of worker processes")
    args = parser.parse_args()

    log.info("Starting MCP Brain HTTP server", host=args.host, port=args.port)
    uvicorn.run(APP, host=args.host, port=args.port, workers=args.workers, log_level="info")


if __name__ == "__main__":
    run()