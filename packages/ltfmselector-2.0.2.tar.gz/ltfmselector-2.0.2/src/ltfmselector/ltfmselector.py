import shap
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter

import os, sys
import random
import pickle
import shutil
import tarfile
import numpy as np
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt
from collections import defaultdict
from joblib import Parallel, delayed

from .env import Environment
from .utils import rename_features
from .utils import ReplayMemory, DQN, Transition, balance_classDistribution_patient

from itertools import count

from sklearn.svm import SVR, SVC
from sklearn.linear_model import Ridge
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

from sklearn.model_selection._search import BaseSearchCV

# Functions to clip predicted regression values
capUpperValues = lambda x: 3.0 if x > 3.0 else x
capLowerValues = lambda x: 0.0 if x < 0.0 else x

def load_model(filename, default_policy_net=True, nOptSteps=None):
    '''
    Load a previously saved model. The list of prediction models will be
    returned. User should manually load it, see example. This design
    decision was made to account for users who might work with PyTorch and
    TensorFlow models which should not be pickled whole.

    Parameter
    ---------
    filename : str or Path.pathlib

    default_policy_net : bool
        If True, user used the default policy network during training

    nOptSteps : int or None
        If None, the policy network that has been trained on all initialized
        environments will be used or else the user-specified policy network
        that was saved intermediately

    Returns
    -------
    pModels : list(tuple)
        List of prediction models provided by user during training
    '''
    with tarfile.open(filename, 'r') as tar:
        with tar.extractfile('selector.pkl_ltfmselector') as f:
            selector = pickle.load(f)
        with tar.extractfile('pModels.pkl_list') as f:
            pModels = pickle.load(f)
        with tar.extractfile('policy_network_checkpoints.pkl_dict') as f:
            policy_network_dict = pickle.load(f)

    # Load policy network
    if default_policy_net:
        if nOptSteps is None:
            nE = -1
        else:
            # Extract intermediately saved intervals
            nEOptions = list(policy_network_dict.keys())
            nEOptions = [i for i in nEOptions if isinstance(i, int)]
            if not nOptSteps in nEOptions:
                raise ValueError(f"Available options of nOptSteps: {nEOptions}")
            else:
                nE = nOptSteps

        policy_network = DQN(
            selector.state_length, selector.actions_length,
            policy_network_dict["n1"], policy_network_dict["n2"]
        )
        policy_network.load_state_dict(policy_network_dict[nE])

    selector.policy_net = policy_network

    # Set pModels to None to ENSURE that user, manually sets the prediction
    # models used earlier.
    selector.pModels = None

    return selector, pModels

class LTFMSelector:
    def __init__(
            self, episodes, buffer_size=10000, batch_size=512,
            epochs=10, tau=0.0005,
            eps_start=0.9, eps_end=0.05, eps_decay=125,
            fQueryCost=0.01, fQueryFunction=None,
            fThreshold=None, fCap=None, fRate=None,
            fRepeatQueryCost=1.0, p_wNoFCost=5.0, errorCost=1.0,
            pType="regression", regression_tol=0.5,
            regression_error_rounding=1,
            pModels=None,
            gamma=0.99, max_timesteps=None,
            checkpoint_interval=None, device="cpu"
    ):
        '''
        Locally-Tailored Feature and Model Selector, implemented according
        to the method described in https://doi.org/10.17185/duepublico/82941.

        Parameters
        ----------
        episodes : int
            Number of episodes agent is trained

        buffer_size : int (default: 10000)
            Number of transitions to store in the replay memory

        batch_size : int
            Batch size to train the policy network with

        epochs : int
            Number of epochs in updating the policy network at each update
            step

        tau : float
            Update rate of the target network

        eps_start : float
            Start value of epsilon

        eps_end : float
            Final value of epsilon

        eps_decay : float
            Rate of exponential decay

        fQueryCost : float
            Cost of querying a feature.

        fQueryFunction : None or {'step', 'linear', 'quadratic'}
            User can also decide to progressively increase the cost of
            querying features in the following manner:
            'step' :
                Every additional feature adds a fixed constant, determined
                by user.
            'linear' :
                Cost of every additional feature linearly increases according
                to user-defined gradient
            'quadratic' :
                Cost of every additional feature increases quadratically,
                according to a user-defined rate

        fThreshold : None or int
            If `fQueryFunction == {'step', 'linear', 'quadratic', 'exponential'}`
            Threshold of number of features, before cost of recruiting
            increases

        fCap : None or float
            If `fQueryFunction == {'step', 'linear', 'quadratic'}`, upper
            limit of penalty

        fRate : None or float
            If `fQueryFunction == {'linear', 'quadratic'}`, rate of
            individual cost functions

        fRepeatQueryCost : float
            Cost of querying a feature already previously selected

        p_wNoFCost : float
            Cost of making a prediction without any recruited features

        errorCost : float
            Cost of making a wrong prediction

            If pType == 'regression', then
            Agent is punished -errorCost*abs(``prediction`` - ``target``)

            If pType == 'classification', then
            Agent is punished -errorCost

        pType : {'regression' or 'classification'}
            Type of prediction to make

        regression_tol : float
            Only applicable for regression models, punish agent if prediction
            error is bigger than regression_tol

        regression_error_rounding : int (default = 1)
            Only applicable for regression models. The error between the
            prediction and true value is rounded to the input decimal place.

        pModels : None or ``list of prediction models``
            Options of prediction models that the agent can choose from

            If None, the default options will include for classification:
            1. Support Vector Machine
            2. Random Forest
            3. Gaussian Naive Bayes

            For regression:
            1. Support Vector Machine
            2. Random Forest
            3. Ridge Regression

            If it is intended for the agent to only dynamically select features
            and use only the prescribed prediction model, simply enter a list
            with one instance of a prediction model.

        gamma : float
            Discount factor, must be in :math:`]0, 1]`. The higher the discount
            factor, the higher the influence of rewards from future states.

            In other words, the more emphasis is placed on maximizing rewards
            with a long-term perspective. A discount factor of zero would result
            in an agent that only seeks to maximize immediate rewards.

        max_timesteps : int or None
            Maximum number of time-steps per episode. Agent will be forced to
            make a prediction with the selected features and prediction model,
            if max_timesteps is reached.

            If None, max_timesteps will be set to 3 x number_of_features

        checkpoint_interval : int or None
            Save the policy network intermediately over a user-defined number
            of optimization steps.
        '''
        self.device = device

        self.batch_size = batch_size
        self.epochs = epochs
        self.tau = tau
        self.eps_start = eps_start
        self.eps_end = eps_end
        self.eps_decay = eps_decay
        self.gamma = gamma
        self.episodes = episodes
        self.max_timesteps = max_timesteps
        self.checkpoint_interval = checkpoint_interval
        self.policy_net = None
        self.policy_network_checkpoints = dict()

        if not pType in ["regression", "classification"]:
            raise ValueError("Either 'regression' or 'classification' only!")
        else:
            self.pType = pType

        # Reward function
        self.fQueryCost = fQueryCost
        self.fQueryFunction = fQueryFunction
        self.fThreshold = fThreshold
        self.fCap = fCap
        self.fRate = fRate

        # Options for progressive cost functions
        if isinstance(self.fQueryFunction, str):
            fQueryFunctions = ['step', 'linear', 'quadratic']
            if not self.fQueryFunction in fQueryFunctions:
                raise ValueError(
                    f"{self.fQueryFunction} is not a valid option. Available " +
                    f"options are {fQueryFunctions}"
                )
            else:
                if not isinstance(fThreshold, int):
                    raise ValueError("Parameter fThreshold must be an integer!")

                if self.fQueryFunction == "step":
                    if not (isinstance(fCap, float) or isinstance(fCap, int)):
                        raise ValueError("Parameter fCap must be an int or float!")
                    else:
                        self.fCap = float(fCap)
                else:
                    if self.fQueryFunction in ["linear", "quadratic"]:
                        if not (isinstance(fRate, float) or isinstance(fRate, int)):
                            raise ValueError("Parameter fRate must be an int or float!")
                        else:
                            self.fRate = float(fRate)

        self.fRepeatQueryCost = fRepeatQueryCost
        self.p_wNoFCost = p_wNoFCost
        self.errorCost = errorCost
        self.regression_tol = regression_tol
        self.regression_error_rounding = regression_error_rounding

        # Available option of prediction models the agent can select
        if (pModels is None) and (self.pType == "regression"):
            self.pModels = [
                SVR(),
                RandomForestRegressor(n_jobs=-1),
                Ridge()
            ]
        elif (pModels is None) and (self.pType == "classification"):
            self.pModels = [
                SVC(),
                RandomForestClassifier(n_jobs=-1),
                GaussianNB()
            ]
        else:
            if isinstance(pModels, list):
                self.pModels = pModels
            else:
                raise ValueError("`pModels` must be type `list`")

        # Initializing the ReplayMemory
        print(
            "Initializing the replay buffer to store the last " +
            f"{buffer_size} transitions ... "
        )
        self.ReplayMemory = ReplayMemory(buffer_size)

        # Initialize counter to track total actions already taken
        self.total_actions = 0

    def fit(
            self, X, y, n=10000, loss_function='mse', sample_weight=None,
            agent_neuralnetwork=None, lr=1e-5, monitor=False,
            log_actions=False, log_dir=None, background_dataset=None, **kwargs
    ):
        '''
        Initializes the environment and agent, then trains the agent to select
        optimal combinations of features and prediction models locally, i.e.
        specific for a given sample.

        Parameters
        ----------
        X : pd.DataFrame
            Pandas dataframe with the shape: (n_samples, n_features)

        y : pd.Series
            Class/Target vector

        n : int
            Number of trees in the random forest ensemble, which will be used
            to estimate the relative importance of features. Based on these
            importances will the features be sampled as 'initial features'

        loss_function : {'mse', 'smoothl1'} or custom function
            Choice of loss function. Default is 'mse'. User may also pass
            own customized loss function, based on PyTorch.

        sample_weight : list or array or None
            Per-sample weights

        agent_neuralnetwork : torch.nn.Module or (int, int) or None
            Neural network to represent the policy network of the agent.

            User may pass user-defined PyTorch neural network or a tuple of two
            integer elements (n1, n2). n1 and n2 pertains to the number of units
            in the first and second layer of a multilayer-perceptron,
            implemented in PyTorch.

            If None, a default multilayer-perceptron of two hidden layers, each
            with 1024 units is used.

        lr : float
            Learning rate of the default AdamW optimizer to optimize parameters
            of the policy network

        monitor : bool
            Monitor training process using a TensorBoard.

            Run `tensorboard --logdir=runs` in the terminal to monitor the
            progression of the action-value function.

        background_dataset : None or pd.DataFrame
            If None, numerical features will be assumed when computing the
            background dataset.

            The background dataset defines the feature values when a feature
            is not selected.

        log_actions : bool
            If `True`, the progression of selected actions will be saved in
            `self.ActionsLog` which is a np.array of size
            (self.episodes, self.max_timesteps).

            Because not every episode has the length defined in
            `self.max_timesteps`, remaining time-steps not "filled" will
            assume values of -2.

        log_dir : str or None
            Directory to store all logged metrics if `monitor=True`.
        '''
        ### Special-tailored implementation ###
        if "smsproject" in list(kwargs.keys()):
            self.smsproject = True
        else:
            self.smsproject = False

        # Training dataset
        if isinstance(X, np.ndarray):
            self.X = pd.DataFrame(X)
        else:
            self.X = X

        if isinstance(y, np.ndarray):
            self.y = pd.Series(y)
        else:
            self.y = y

        # Compute background dataset if needed
        if background_dataset is None:
            # Computing background dataset (assuming numerical features)
            self.background_dataset = pd.DataFrame(
                data=np.zeros(self.X.shape), index=self.X.index,
                columns=self.X.columns
            )
            for i in self.background_dataset.index:
                self.background_dataset.loc[i] = self.X.drop(i).mean(axis=0)

            self.background_dataset.loc["Total", :] = self.X.mean(axis=0)
        else:
            self.background_dataset = background_dataset

        self.sample_weight = sample_weight

        # If user wants to monitor progression of terms in the loss function
        if monitor:
            writer = SummaryWriter(log_dir=f'runs/{log_dir}')

        # If user wants to log actions
        if log_actions:
            self.ActionsLog = np.ones((self.episodes, self.max_timesteps))*(-2)

        # Getting background predictions here to generate multiple environments
        # in parallel
        self.y_pred_bg = self.get_bgPrediction(**kwargs)

        # Initialize probability of each feature sampled as the initial feature
        self.InitialFeatureP = self.get_probInitialFeature(self.X, self.y, n)

        # Initializing the environments in parallel
        envs = [
            Environment(
                self.X, self.y, self.background_dataset, self.y_pred_bg,
                self.fQueryCost, self.fQueryFunction,
                self.fThreshold, self.fCap, self.fRate,
                self.fRepeatQueryCost, self.p_wNoFCost, self.errorCost,
                self.pType, self.InitialFeatureP,
                self.regression_tol, self.regression_error_rounding,
                self.pModels, self.device, sample_weight=self.sample_weight, **kwargs
            ) for i in tqdm(range(self.episodes), desc=f"Creating {self.episodes} environments")
        ]
        if log_actions:
            IDX = [i for i in range(self.episodes)]

        # Take an environment and reset it simply for metadata initialization
        _intenv = Environment(
            self.X, self.y, self.background_dataset, self.y_pred_bg,
            self.fQueryCost, self.fQueryFunction,
            self.fThreshold, self.fCap, self.fRate,
            self.fRepeatQueryCost, self.p_wNoFCost, self.errorCost,
            self.pType, self.InitialFeatureP,
            self.regression_tol, self.regression_error_rounding,
            self.pModels, self.device, sample_weight=self.sample_weight
        ); _intenv.reset()
        self.state_length   = len(_intenv.state)
        self.actions_length = len(_intenv.actions)

        # Initializing the policy and target networks
        if isinstance(agent_neuralnetwork, nn.Module):
            self.policy_net = agent_neuralnetwork
            self.target_net = agent_neuralnetwork
        else:
            if agent_neuralnetwork is None:
                nLayer1 = 1024
                nLayer2 = 1024

            elif isinstance(agent_neuralnetwork, tuple) and len(agent_neuralnetwork) == 2:
                nLayer1 = agent_neuralnetwork[0]
                nLayer2 = agent_neuralnetwork[1]

            self.policy_net = DQN(
                len(_intenv.state), len(_intenv.actions), nLayer1, nLayer2
            ).to(self.device)

            self.target_net = DQN(
                len(_intenv.state), len(_intenv.actions), nLayer1, nLayer2
            ).to(self.device)

        self.target_net.load_state_dict(self.policy_net.state_dict())

        # Initializing the optimizer
        optimizer = optim.AdamW(
            self.policy_net.parameters(), lr=lr, amsgrad=True
        )

        # Training the agent over self.episodes
        if self.max_timesteps is None:
            self.max_timesteps = _intenv.nFeatures * 3

        # Reset all environments
        states = torch.tensor(
            np.array([env.reset() for env in envs]),
            dtype=torch.float32, device=self.device
        )
        # >> Tensor(nEpisodes, |State|)

        # Counter of number of steps
        self.steps = 0

        # Counter of number of optimization steps
        self.opt_steps = 0

        for t in count():
            actions = self.select_action(states, envs, t, train=True)
            # >> Tensor(nEpisodes, 1) - Action selected for each environment

            # Log actions if desired
            if log_actions:
                self.ActionsLog[IDX, t] = actions.squeeze(1).numpy()

            # If maximum time_steps is reached, pick a prediction action based
            # on the one with highest Q-value
            if t+1 == self.max_timesteps:
                actions = self.select_PM(states, envs, t)

            # Agent carries out action in each environment and returns:
            # - Observations :: list(nEpisodes)
            # >> Every element is the next state or None (termination)
            # - Rewards      :: list(nEpisodes)
            # - Terminations :: list(nEpisodes of boolean value)
            envTransition = []
            for envIdx, env in enumerate(tqdm(envs)):
                envTransition.append(env.step(actions[envIdx, 0].item()))

            self.steps += 1

            observations, rewards, terminations = zip(*envTransition)
            observations = list(observations)
            rewards = torch.tensor(
                list(rewards), device=self.device
            ).view(len(envs), 1)
            terminations = list(terminations)

            # Get next states
            # - None if the next state is a termination state
            # - Otherwise, simply the next state according to the transition function
            get_nextState = lambda x, o: None if x else torch.tensor(
                o, dtype=torch.float32, device=self.device
            ).unsqueeze(0)
            nextStates = [
                get_nextState(t, o) for t, o in zip(terminations, observations)
            ]

            # Push to replay buffer
            for s, a, sp, r in zip(
                    torch.unbind(states, dim=0),
                    torch.unbind(actions, dim=0),
                    nextStates,
                    rewards
            ):
                self.ReplayMemory.push(s.unsqueeze(0), a.unsqueeze(0), sp, r)


            # Update next state
            # - Kick out environments that have ended from `envs` and `states`
            nextStates_onGoing = []
            envIdxToRemove     = []
            for i, sp in enumerate(nextStates):
                if not sp is None:
                    nextStates_onGoing.append(sp)
                else:
                    envIdxToRemove.append(i)

            for i in reversed(envIdxToRemove):
                del envs[i]
                if log_actions:
                    del IDX[i]
            # All environments have terminated
            if len(nextStates_onGoing) == 0:
                break

            states = torch.tensor(
                np.array(nextStates_onGoing), dtype=torch.float32, device=self.device
            ).squeeze(1)

            # Optimize the model over user-desired number of epochs
            for _ in range(self.epochs):
                _res = self.optimize_model(optimizer, loss_function, monitor)
                self.opt_steps += 1

                if monitor:
                    writer.add_scalar("Metrics/Average_QValue", _res[0], self.opt_steps)
                    writer.add_scalar("Metrics/Average_Reward", _res[1], self.opt_steps)
                    writer.add_scalar("Metrics/Average_Target", _res[2], self.opt_steps)

                # Saving trained policy network intermediately
                if not self.checkpoint_interval is None:
                    if (self.opt_steps) % self.checkpoint_interval == 0:
                        self.policy_network_checkpoints[self.opt_steps] =\
                            self.policy_net.state_dict()

            # Apply soft update to target network's weights
            targetParameters = self.target_net.state_dict()
            policyParameters = self.policy_net.state_dict()

            for key in policyParameters:
                targetParameters[key] = policyParameters[key]*self.tau + \
                    targetParameters[key]*(1 - self.tau)

            self.target_net.load_state_dict(targetParameters)

        # Save trained weights after all episodes
        self.policy_network_checkpoints[-1] = self.policy_net.state_dict()

        if monitor:
            writer.flush()
            writer.close()
    def predict(self, X_test, log=False, **kwargs):
        '''
        Use trained agent to select features and a suitable prediction model
        to predict the target/class, given X_test.

        Parameters
        ----------
        X_test : pd.DataFrame
            Test samples

        log : bool
            Log each predicted sample into self.doc_test

        Returns
        -------
        y_pred : pd.Series
            Target/Class predicted for X_test
        '''
        # Initializing the environments in parallel for each test sample
        envs = [
            Environment(
                self.X, self.y, self.background_dataset, self.y_pred_bg,
                self.fQueryCost, self.fQueryFunction,
                self.fThreshold, self.fCap, self.fRate,
                self.fRepeatQueryCost, self.p_wNoFCost, self.errorCost,
                self.pType, self.InitialFeatureP,
                self.regression_tol, self.regression_error_rounding,
                self.pModels, self.device, sample_weight=self.sample_weight, **kwargs
            ) for i in tqdm(
                range(X_test.shape[0]),
                desc=f"Creating {X_test.shape[0]} environments for each test sample"
            )
        ]
        if isinstance(X_test, pd.DataFrame):
            IDX = list(X_test.index)
        else:
            raise ValueError("X_test must be a pandas DataFrame!")

        # Create dictionary to save information per episode
        if log:
            self.doc_test = defaultdict(dict)

        # Array to store predictions
        y_pred = pd.Series(np.zeros(X_test.shape[0]), index=X_test.index)

        # Reset all environments
        states = torch.tensor(
            np.array([env.reset(sample=X_test.iloc[[i]]) for i, env in enumerate(envs)]),
            dtype=torch.float32, device=self.device
        )

        for t in count():
            actions = self.select_action(states, envs, t, train=False)

            if t+1 == self.max_timesteps:
                actions = self.select_PM(states, envs, t)

            envTransition = []
            for envIdx, env in enumerate(tqdm(envs)):
                envTransition.append(env.step(actions[envIdx, 0].item()))

            observations, rewards, terminations = zip(*envTransition)
            observations = list(observations)
            rewards = torch.tensor(
                list(rewards), device=self.device
            ).view(len(envs), 1)
            terminations = list(terminations)

            get_nextState = lambda x, o: None if x else torch.tensor(
                o, dtype=torch.float32, device=self.device
            ).unsqueeze(0)
            nextStates = [
                get_nextState(t, o) for t, o in zip(terminations, observations)
            ]

            # Update next state
            # - Kick out environments that have ended from `envs` and `states`
            nextStates_onGoing = []
            envIdxToRemove     = []
            for i, sp in enumerate(nextStates):
                if not sp is None:
                    nextStates_onGoing.append(sp)
                else:
                    envIdxToRemove.append(i)
                    y_pred.at[IDX[i]] = envs[i].y_pred

                    if log:
                        doc_episode = {
                            "SampleID": IDX[i],
                            "PredModel": envs[i].PM,
                            "Iterations": t+1,
                            "Mask": envs[i].get_feature_mask()
                        }
                        self.doc_test[IDX[i]] = doc_episode

            for i in reversed(envIdxToRemove):
                del envs[i]
                del IDX[i]

            # All environments have terminated
            if len(nextStates_onGoing) == 0:
                break

            states = torch.tensor(
                np.array(nextStates_onGoing), dtype=torch.float32, device=self.device
            ).squeeze(1)

        return y_pred

    def select_action(self, states, envs, t, train=True):
        '''
        Select an action based on the given states. For exploration an
        epsilon-greedy strategy is implemented - the agent will for an
        epsilon probability choose a random action, instead of using the
        policy network.

        Parameters
        ----------
        states : torch.Tensor
            State of environments generated in parallel

        envs : torch.Tensor
            Environments agent interacts with

        t : int
            Time-step

        train : bool
            If `true` employ epsilon-greedy strategy
        '''
        # Probability of choosing random actions, instead of best action
        # - Probability decreases exponentially over time
        if train:
            eps_threshold = self.eps_end + (self.eps_start - self.eps_end) * \
                np.exp(-1. * t / self.eps_decay)

        else:
            eps_threshold = -1

        # Perform random action
        print(f"Eps: {eps_threshold}")
        if eps_threshold > random.random():
            print(f"Step {t+1}:: Random")
            return torch.tensor(
                [env.get_random_action() for env in envs],
                device=self.device, dtype=torch.long
            ).view(states.shape[0], 1)

        # Perform maximizing action
        else:
            print(f"Step {t+1}:: Policy-based")
            with torch.no_grad():
                QValues = self.policy_net(states)
                # >> Tensor(nEpisodes, |Actions (#Features + #PM)|)
                return QValues.max(1)[1].view(states.shape[0], 1)

    def select_PM(self, states, envs, t):
        '''
        Select PM with highest Q-value based on given states.

        Parameters
        ----------
        states : torch.Tensor
            State of environments generated in parallel

        envs : torch.Tensor
            Environments agent interacts with

        t : int
            Time-step
        '''
        print(f"Step {t+1}:: Policy-based (Final)")
        with torch.no_grad():
            QValuesPM = self.policy_net(states)[:, -(len(self.pModels)):]
            return (QValuesPM.max(1)[1] + self.X.shape[1]).view(states.shape[0], 1)

    def optimize_model(self, optimizer, loss_function, monitor):
        '''
        Optimize the policy network.

        Parameters
        ----------
        loss_function : {'mse', 'smoothl1'} or custom function
            Choice of loss function. Default is 'mse'. User may also pass
            own customized loss function, based on PyTorch.
        '''
        # Regarding notations used in comments:
        # s  : current state
        # a  : action
        # s' : future state
        # Q  : action-value function (quality)
        #      (estimate of the cumulative reward, R)

        if len(self.ReplayMemory) < self.batch_size:
            if monitor:
                _res = (0., 0., 0.)
            else:
                _res = None

            return _res

        # Step 1 ---
        # Draw a random batch of experiences
        experiences = self.ReplayMemory.sample(self.batch_size)
        # [
        #    Experience #1: (state, action, next_state, reward),
        #    Experience #2: (state, action, next_state, reward),
        #    ...
        # ]

        # Step 2 ---
        # Convert the experiences into batches, per "item"
        batch = Transition(*zip(*experiences))
        # [
        #    s  : (#1, #2, ..., #BATCH_SIZE),
        #    a  : (#1, #2, ..., #BATCH_SIZE),
        #    s' : (#1, #2, ..., #BATCH_SIZE),
        #    r  : (#1, #2, ..., #BATCH_SIZE)
        # ]
        state_batch  = torch.cat(batch.state)
        action_batch = torch.cat(batch.action)
        reward_batch = torch.cat(batch.reward)

        # Step 3 ---
        # Get a boolean mask of non-final states (iterations)
        # - s' is None if environment terminates
        non_final_mask = torch.tensor(
            tuple(
                map(lambda s: s is not None, batch.next_state)
            ), device=self.device, dtype=torch.bool
        )
        # Example of map()
        # >> A = [6, 53, 3, 9, 12]
        # >> B = tuple(map(lambda s: s < 10, A))
        # (True False True True False)

        # Step 4 ---
        # Get a batch of non-final next_states of tensor dimensions:
        # - (<#BATCH_SIZE (except final states), (#features * 2)+1)
        non_final_next_states = torch.cat(
            [s for s in batch.next_state if s is not None]
        )

        # Step 5 ---
        # Compute Q(s, a) of each sampled state-action pair from with the
        # policy network
        state_action_values = self.policy_net(state_batch).gather(
            1, action_batch
        ).float()

        # Step 6 ---
        # Double Deep Q-Learning, where Q' denotes the target network, compute
        # r + GAMMA * Q'(s', argmax_{a'} Q(s', a'))

        # Q'(s', a') computed based on "older" target network, but actions a'
        # selected by policy network

        # This is merged, per non_final_mask, such that we'll have either:
        #  1. r + GAMMA * Q'(s', argmax_{a'} Q(s', a')) >> non-final
        #  2. r                                         >> final
        next_state_values = torch.zeros(
            self.batch_size, device=self.device, dtype=torch.float32
        )
        with torch.no_grad():
            # Get maximizing action from policy_net, action space:
            # [0, 1, 2, ..., D+1, D+2, ..., D+G]
            maxActionsIdx = self.policy_net(
                non_final_next_states
            ).max(1)[1].unsqueeze(-1)

            next_state_values[non_final_mask] = self.target_net(
                non_final_next_states
            ).gather(1, maxActionsIdx).squeeze(-1)

        expected_state_action_values = (
            reward_batch + (next_state_values * self.gamma)
        ).float()

        # Clip target values at a maximum of zero, since we only have penalties!
        expected_state_action_values = torch.clamp(
            expected_state_action_values, max=0.0
        )

        # Step 7 ---
        # Compute loss
        if isinstance(loss_function, str):
            if loss_function == 'mse':
                criterion = nn.MSELoss()
            elif loss_function == 'smoothl1':
                criterion = nn.SmoothL1Loss()
        else:
            criterion = loss_function

        loss = criterion(
            state_action_values, expected_state_action_values.unsqueeze(1)
        )
        optimizer.zero_grad()

        # Compute gradient via backpropagation
        loss.backward()
        # In-place gradient clipping
        torch.nn.utils.clip_grad_value_(self.policy_net.parameters(), 1)
        # Optimize the model (policy network)
        optimizer.step()

        if monitor:
            Q_avr = state_action_values.detach().numpy().mean()
            r_avr = reward_batch.unsqueeze(1).numpy().mean()
            V_avr = expected_state_action_values.unsqueeze(1).numpy().mean()
            res = (Q_avr, r_avr, V_avr)
        else:
            res = None

        return res

    def save_model(self, filename):
        '''
        Save the model. The LTFMSelector object will be pickled, but the
        prediction models (pModels) and the policy network (policy_net),
        will be saved separately.

        Parameters
        ----------
        filename : str
        '''
        # 1. Save the LTFMSelector object
        with open('selector.pkl_ltfmselector', 'wb') as f:
            pickle.dump(self, f)

        # 2. Save the prediction models
        with open('pModels.pkl_list', 'wb') as f:
            pModels_to_save = []
            for model in self.pModels:
                if isinstance(model, nn.Module):
                    pModels_to_save.append("pytorch", model.state_dict())
                else:
                    pModels_to_save.append((type(model), model))

            pickle.dump(pModels_to_save, f)

        # 3. Save the weights of the policy network
        with open('policy_network_checkpoints.pkl_dict', 'wb') as f:
            self.policy_network_checkpoints["n1"] = self.policy_net.n1
            self.policy_network_checkpoints["n2"] = self.policy_net.n2
            pickle.dump(self.policy_network_checkpoints, f)

        # 4. Save all in a tarball
        with tarfile.open(f"{filename}.tar", 'w') as tar:
            tar.add('selector.pkl_ltfmselector')
            tar.add('pModels.pkl_list')
            tar.add('policy_network_checkpoints.pkl_dict')

        # Only delete if the archive actually exists and has size
        if os.path.getsize(f"{filename}.tar") > 0:
            os.remove('selector.pkl_ltfmselector')
            os.remove('pModels.pkl_list')
            os.remove('policy_network_checkpoints.pkl_dict')

    def __getstate__(self):
        state = self.__dict__.copy()

        del state["pModels"]
        del state["policy_net"]
        del state["target_net"]
        del state["ReplayMemory"]
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)

    def get_bgPrediction(self, **kwargs):
        '''
        Get prediction based on average targets/classes when the agent decides
        to make a prediction without any recruited features.
        '''
        if isinstance(self.y, pd.Series):
            _y = (self.y.values).copy()
        else:
            _y = self.y.copy()

        if self.smsproject:
            X_wTarget = self.X.iloc[:,0:2].copy()
            X_wTarget["Target"] = _y
            X_wTarget = X_wTarget.rename(
                index=lambda x: x[0:5] if x.startswith('ES') else x[0:8]
            )
            X_wTarget_patLevel = X_wTarget.groupby("StridePairID").mean()
            _y = X_wTarget_patLevel["Target"]

        return _y.mean()

    def get_probInitialFeature(self, X, y, n):
        '''
        Trains a Random Forest ensemble of n trees, calculates feature
        importance, and returns the probability of sampling a feature, based
        on its total relative relevance.

        Parameters
        ----------
        X : pd.DataFrame
            Training dataset, pandas dataframe with the shape:
            (n_samples, n_features)

        y : pd.Series
            Class/Target vector

        n : int
            Number of trees

        Returns
        -------
        probs : numpy.ndarray
         - Probabily of sampling feature based on their relevance
        '''
        print(
            "Initializing the probability of a feature being selected as " +
            "an initial feature, based on the feature's importance in a " +
            f"random forest ensemble of {n} trees ..."
        )
        if self.pType == "regression":
            rf = RandomForestRegressor(
                n_estimators=n, n_jobs=-1, random_state=42
            )
        elif self.pType == "classification":
            rf = RandomForestClassifier(
                n_estimators=n, n_jobs=-1, random_state=42
            )
        else:
            raise ValueError("'pType' must be 'regression' or 'classification'")

        rf.fit(X, y)

        # Get feature importance
        # > scikit-learn's feature_importances_ sum to 1.0 by default
        probs = rf.feature_importances_

        return probs

    def explain_wSHAP(
            self, test_id, test_pkldict, X_test, bgDataset=None, plot=False,
            max_display=4, features_names=None
    ):
        '''
        Explains the prediction model of the given test sample.

        Parameters
        ----------
        test_id : int or str
            The ID (index) of the prediction to explain

        test_pkldict : Python pickle
            The output Python pickled binary file from running predict

        X_test : pd.DataFrame
            Test samples

        bgDataset : pd.DataFrame or None
            "Background dataset" for conditioning out on feature values when
            deriving SHAP values

        plot : bool
            Plot waterfall diagram

        max_display : int
            Maximum number of features displayed in waterfall plot if
            `plot=True`

        features_names : list or None
            Feature names for waterfall plot

        Returns
        -------
        explanations : shap._explanation.Explanation
            Feature attribution values

        fig : matplotlib.figure.Figure
            Only if `plot=True`

        ax : matplotlib.axes._axes.Axes
            Only if `plot=True`
        '''
        # Load metainformation from earlier prediction
        with open(test_pkldict, 'rb') as handle:
            testDict = pickle.load(handle)

        # Get PM and features used by agent when making a prediction for
        # given sample
        test_idDict = testDict[test_id]

        pModel = self.pModels[test_idDict["PredModel"]][1]
        featuresMask = test_idDict["Mask"]

        # Get trimmed datasets
        trimmedTrainDF = self.X.iloc[:, np.where(featuresMask==1.)[0].tolist()]
        trimmedTestDF  = X_test.iloc[:, np.where(featuresMask==1.)[0].tolist()]

        if bgDataset is None:
            bgDataset = shap.maskers.Independent(self.X)

        trimmedbgDataset = bgDataset.iloc[:, np.where(featuresMask==1.)[0].tolist()]

        # Retrain PM
        # Force to run on 1 thread to avoid 'bugs'
        if hasattr(pModel, 'n_jobs'):
            pModel.n_jobs = 1

        if self.smsproject:
            _X_train_wLabel = trimmedTrainDF.copy()
            _X_train_wLabel["Target"] = self.y.loc[_X_train_wLabel.index]

            _weights = balance_classDistribution_patient(
                _X_train_wLabel, "Target"
            ).to_numpy(dtype=np.float32)[:,0]
        else:
            _weights = self.sample_weight

        pModel.fit(trimmedTrainDF, self.y, sample_weight=_weights)

        # Get sample
        testX = (trimmedTestDF.loc[test_id].values).reshape(1, trimmedTestDF.shape[1])

        # Initializing a SHAP explanation model

        # First handle scikit model selectors
        if isinstance(pModel, BaseSearchCV):
            # Get best estimator
            pModel = pModel.best_estimator_

        max_evals = (50 * trimmedbgDataset.shape[1]*2) + 50

        if self.smsproject:
            features_names = [
                rename_features(col) for col in list(trimmedTestDF.columns)
            ]
        else:
            features_names = features_names

        explainer = shap.Explainer(
            pModel.predict,
            masker=trimmedbgDataset,
            algorithm="permutation",
            max_evals=max_evals, seed=0,
            feature_names=features_names
        )
        explanations = explainer(testX, max_evals=max_evals)

        # Plot waterfall
        if plot:
            fig, ax = plt.subplots(1, 1)
            wfplot = shap.plots.waterfall(
                explanations[0], show=False, max_display=max_display
            )
            fig.tight_layout()
            return explanations, fig, ax
        else:
            return explanations
