import{b as r}from"./graph-CF1QPhtf.js";var e=4;function a(o){return r(o,e)}export{a as c};
