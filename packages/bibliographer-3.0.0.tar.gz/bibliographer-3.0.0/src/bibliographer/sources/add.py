from typing import Optional

from bibliographer.cardcatalog import (
    CardCatalog,
    CatalogArticle,
    CatalogBook,
    CatalogPodcastEpisode,
    CatalogVideo,
)
from bibliographer.util.isbnutil import normalize_isbn
from bibliographer.util.slugify import generate_slug_for_work


def add_book(
    catalog: CardCatalog,
    title: Optional[str],
    authors: Optional[list[str]],
    isbn: Optional[str],
    purchase_date: Optional[str],
    read_date: Optional[str],
    slug: Optional[str],
):
    """Add a new book entry to the combined library."""

    if not title and not isbn:
        raise Exception("Must specify at least --title or --isbn")

    if isbn:
        isbn = normalize_isbn(isbn)

    book = CatalogBook(
        title=title,
        authors=authors or [],
        isbn=isbn,
        purchase_date=purchase_date,
        consumed_date=read_date,
    )

    # Use provided slug, or generate from title, or fall back to ISBN-based slug
    if not slug:
        if title:
            slug = generate_slug_for_work(book)
        else:
            slug = f"book-{isbn}"

    if slug in catalog.combinedlib.contents:
        raise ValueError(f"Slug {slug} already exists, edit that entry or choose a different slug")

    book.slug = slug
    catalog.combinedlib.contents[slug] = book
    print(f"Added book {slug}")


def add_article(
    catalog: CardCatalog,
    title: Optional[str],
    authors: Optional[list[str]],
    url: Optional[str],
    publication: Optional[str],
    purchase_date: Optional[str],
    consumed_date: Optional[str],
    slug: Optional[str],
):
    """Add a new article entry to the combined library."""

    if not title and not url:
        raise Exception("Must specify at least --title or --url")

    article = CatalogArticle(
        title=title,
        authors=authors or [],
        url=url,
        publication=publication,
        purchase_date=purchase_date,
        consumed_date=consumed_date,
    )

    if not slug:
        slug = generate_slug_for_work(article)

    if slug in catalog.combinedlib.contents:
        raise ValueError(f"Slug {slug} already exists, edit that entry or choose a different slug")

    article.slug = slug
    catalog.combinedlib.contents[slug] = article
    print(f"Added article {slug}")


def add_podcast(
    catalog: CardCatalog,
    title: Optional[str],
    authors: Optional[list[str]],
    url: Optional[str],
    podcast_name: Optional[str],
    episode_number: Optional[int],
    purchase_date: Optional[str],
    consumed_date: Optional[str],
    slug: Optional[str],
):
    """Add a new podcast episode entry to the combined library."""

    if not title and not url:
        raise Exception("Must specify at least --title or --url")

    podcast = CatalogPodcastEpisode(
        title=title,
        authors=authors or [],
        url=url,
        podcast_name=podcast_name,
        episode_number=episode_number,
        purchase_date=purchase_date,
        consumed_date=consumed_date,
    )

    if not slug:
        slug = generate_slug_for_work(podcast)

    if slug in catalog.combinedlib.contents:
        raise ValueError(f"Slug {slug} already exists, edit that entry or choose a different slug")

    podcast.slug = slug
    catalog.combinedlib.contents[slug] = podcast
    print(f"Added podcast episode {slug}")


def add_video(
    catalog: CardCatalog,
    title: Optional[str],
    authors: Optional[list[str]],
    url: Optional[str],
    purchase_date: Optional[str],
    consumed_date: Optional[str],
    slug: Optional[str],
):
    """Add a new video entry to the combined library."""

    if not title and not url:
        raise Exception("Must specify at least --title or --url")

    video = CatalogVideo(
        title=title,
        authors=authors or [],
        url=url,
        purchase_date=purchase_date,
        consumed_date=consumed_date,
    )

    if not slug:
        slug = generate_slug_for_work(video)

    if slug in catalog.combinedlib.contents:
        raise ValueError(f"Slug {slug} already exists, edit that entry or choose a different slug")

    video.slug = slug
    catalog.combinedlib.contents[slug] = video
    print(f"Added video {slug}")
