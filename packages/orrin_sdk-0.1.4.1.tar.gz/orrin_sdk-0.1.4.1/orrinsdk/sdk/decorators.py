import ast
from enum import Enum
import inspect
from json import dumps, loads
import pathlib
from typing import Dict, List
import requests
import sys
import yaml

API_BASE = "https://stellr-company.com"

class ProcessSource:
    def __init__(self):
        self.source_file = None
        self.source_content = ''

        self.allowed_imports = [
            'openai',
            'requests',
            'json',
            'datetime',
            'math',
            'numpy',
            'pandas',
            'beautifulsoup',
            'pydantic',
            'pillow',
            'nltk',
            'tiktoken',
            'anthropic',
            'google.generativeai',
            'orrinsdk'
        ]
    
    def assign_source_file(self, fn):
        try:
            self.source_file = pathlib.Path(inspect.getfile(fn))
        except Exception as e:
            print(f'Failed to obtain source file: {e}')
            sys.exit(1)

    def get_source(self):
        self.source_content = self.source_file.read_text()

    def validate_imports(self):
        tree = ast.parse(self.source_content)

        used_imports = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top_level = alias.name.split('.')[0]
                    used_imports.add(top_level)

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top_level = node.module.split('.')[0]
                    used_imports.add(top_level)

        disallowed = used_imports - set(self.allowed_imports)

        if disallowed:
            raise ValueError(
                "\033[1;31m[orrin-sdk] DISALLOWED IMPORTS\033[0m\n\n"
                "\033[31mThe following imports are not permitted:\033[0m\n"
                "\t\033[1;37m" + ", ".join(sorted(disallowed)) + "\033[0m\n\n"
                "\033[32mAllowed imports:\033[0m\n"
                "\t\033[36m" + "\n\t".join(self.allowed_imports) + "\033[0m\n\n"
                "\033[90mPlease remove or replace the disallowed imports and try again.\033[0m"
            )
    
    def strip_with_ast(self) -> str:
        """
        Use AST to parse and remove OrrinSDK-related nodes, then unparse back to source.
        Handles various styles: aliases, multiline, etc.
        """
        tree = ast.parse(self.source_content)

        class OrrinRemover(ast.NodeTransformer):
            def visit_Import(self, node):
                # Remove imports like 'import orrinsdk' or aliases
                if any(alias.name == 'orrinsdk' for alias in node.names):
                    return None
                return node

            def visit_ImportFrom(self, node):
                # Remove 'from sdk import OrrinSDK' or 'from orrinsdk import OrrinSDK' (handle module variations)
                if node.module in {'sdk', 'orrinsdk'} and any(alias.name == 'OrrinAppsSDK' or alias.name == 'OrrinToolsSDK' for alias in node.names):
                    return None
                return node

            def visit_Assign(self, node):
                # Remove assignments like 'orrin_sdk = OrrinToolsSDK(...)' or 'orrin_sdk = OrrinAppsSDK(...)'
                if (isinstance(node.value, ast.Call) and 
                    isinstance(node.value.func, ast.Name) and 
                    node.value.func.id in {'OrrinAppsSDK', 'OrrinToolsSDK'}):
                    return None
                return node

            def visit_Expr(self, node):
                # Remove standalone calls like 'orrin_sdk.finalize()'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'finalize':
                    return None
                return node

            def visit_FunctionDef(self, node):
                # Remove decorators like '@orrin_sdk.action(...)'
                new_decorators = []
                for dec in node.decorator_list:
                    if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr == 'action' or dec.func.attr == 'plugin_entry' or dec.func.attr == 'plugin_action'):
                        new_decorators.append(dec)
                node.decorator_list = new_decorators
                return self.generic_visit(node)

        remover = OrrinRemover()
        cleaned_tree = remover.visit(tree)
        ast.fix_missing_locations(cleaned_tree)
        return ast.unparse(cleaned_tree).strip()

    def strip_with_lines(self) -> str:
        """
        Fallback: Original line-based stripping, but improved to handle 'from sdk' and case-insensitivity.
        """
        lines = self.source_content.splitlines()
        filtered = []
        for l in lines:
            stripped_l = l.strip().lower()
            if (stripped_l.startswith("from sdk") or stripped_l.startswith("from orrinsdk") or
                stripped_l.startswith("import sdk") or stripped_l.startswith("import orrinsdk")):
                continue
            if 'orrinsdk' in stripped_l or '.action' in stripped_l or '.finalize' in stripped_l:
                continue
            filtered.append(l)
        return '\n'.join(filtered).strip()
        
    def exists(self):
        return self.source_file.exists()

from .OrrinToolsSDK import OrrinToolsSDK

class OrrinAppsSDK:
    def __init__(self, developer_api_key: str, app_name: str, desc: str):
        self.developer_api_key = developer_api_key
        self._registered_actions = []  # store action metadata
        self._source_file = None  # the file we will read later
        self.app_name = app_name
        self.description = desc
        self.allowed_imports = [
            'openai',
            'requests',
            'json',
            'datetime',
            'math',
            'numpy',
            'pandas',
            'beautifulsoup',
            'pydantic',
            'pillow',
            'nltk',
            'tiktoken',
            'anthropic',
            'google.generativeai',
            'orrinsdk'
        ]

    def action(self, name: str, required_payload: list = [], extra_metadata: dict = {}):
        """
        Decorator to mark a function as a platform action.
        Stores metadata but does not upload yet.
        """
        def decorator(fn):
            # Track the source file (once)
            if self._source_file is None:
                try:
                    self._source_file = pathlib.Path(inspect.getfile(fn))
                except Exception:
                    pass
            # Save action metadata
            action_data = {
                "action_name": name,
                "entrypoint": fn.__name__,
                "required_payload": required_payload,
                "runtime": "python",
                "extra_metadata": extra_metadata or None
            }
            self._registered_actions.append(action_data)
            return fn
        return decorator

    def finalize(self):
        """
        Read the full source file, strip Orrin-related code using AST (or fallback to line-based),
        and send all registered actions in one request to the backend.
        """
        if not self._registered_actions:
            print("[orrin-sdk] No actions registered, skipping upload.")
            return
        if not self._source_file or not self._source_file.exists():
            print("[orrin-sdk] Could not find source file.")
            return
        
        try:
            full_source = self._source_file.read_text()

            # 🔐 Validate imports BEFORE stripping
            self._validate_imports(full_source)

            stripped_source = self._strip_with_ast(full_source)

        except ValueError as e:
            print(f"{e}")
            return

        except Exception as e:
            print(f"[orrin-sdk] AST stripping failed ({e}), falling back to line-based.")
            stripped_source = self._strip_with_lines(full_source)

        if not stripped_source:
            print("[orrin-sdk] Stripped source is empty, aborting.")
            return

        payload = {
            'app_name': self.app_name,
            'desc': self.description,
            'source_code': stripped_source,
            'actions': self._registered_actions
        }

        try:
            response = requests.post(
                f"{API_BASE}/actions/register",
                json=payload,
                headers={
                    "Authorization": self.developer_api_key,
                    "fsdk": "yes"
                },
                timeout=10
            )
            if response.status_code == 200:
                print(
                    "\033[1;32m[orrin-sdk] SUCCESS\033[0m\n\n"
                    "\033[32mActions registered successfully!\033[0m\n\n"
                    "Approval Status: \033[1;33mPENDING\033[0m\n\n"
                    "App ID (save this — you will need it in your Next.js code):\n"
                    f"\t\033[1;36m{response.json()['AppID']}\033[0m\n\n"
                    "\033[90mAll changes or new apps must be approved after submission.\n"
                    "This process typically takes 1–3 days.\033[0m"
                )

            else:
                try:
                    data = response.json()

                    if data['ErrorCode'] == 0x60:
                        print(
                            "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            "\033[31mFailed to register actions.\033[0m\n\n"
                            f"The app \033[1;33m\"{self.app_name}\"\033[0m has recently been \033[1;31marchived\033[0m and is\n"
                            "not authorized for release.\n\n"
                            "If you believe this was an error, please contact Stellr:\n"
                            "\033[4;34mhttps://stellr-company.com/contact\033[0m\n\n"
                            "\033[90mPlease wait 3–7 days for the app to be completely wiped from our servers\n"
                            "before attempting to re-upload.\033[0m"
                        )

                    else:
                        print(
                            "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            f"\033[31mFailed to register actions\033[0m\n\n"
                            f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                            f"Message: \033[1;37m{response.json()['Message']}\033[0m"
                        )

                except:
                    print(
                        "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mFailed to register actions\033[0m\n\n"
                        f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                        f"Message: \033[1;37m{response.json()['Message']}\033[0m"
                    )
        except Exception as e:
            print(f"[orrin-sdk] Exception when sending actions: {e}")
    
    def _validate_imports(self, source: str):
        tree = ast.parse(source)

        used_imports = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top_level = alias.name.split('.')[0]
                    used_imports.add(top_level)

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top_level = node.module.split('.')[0]
                    used_imports.add(top_level)

        disallowed = used_imports - set(self.allowed_imports)

        if disallowed:
            raise ValueError(
                "\033[1;31m[orrin-sdk] DISALLOWED IMPORTS\033[0m\n\n"
                "\033[31mThe following imports are not permitted:\033[0m\n"
                "\t\033[1;37m" + ", ".join(sorted(disallowed)) + "\033[0m\n\n"
                "\033[32mAllowed imports:\033[0m\n"
                "\t\033[36m" + "\n\t".join(self.allowed_imports) + "\033[0m\n\n"
                "\033[90mPlease remove or replace the disallowed imports and try again.\033[0m"
            )


    def _strip_with_ast(self, source: str) -> str:
        """
        Use AST to parse and remove OrrinSDK-related nodes, then unparse back to source.
        Handles various styles: aliases, multiline, etc.
        """
        tree = ast.parse(source)

        class OrrinRemover(ast.NodeTransformer):
            def visit_Import(self, node):
                # Remove imports like 'import orrinsdk' or aliases
                if any(alias.name == 'orrinsdk' for alias in node.names):
                    return None
                return node

            def visit_ImportFrom(self, node):
                # Remove 'from sdk import OrrinSDK' or 'from orrinsdk import OrrinSDK' (handle module variations)
                if node.module in {'sdk', 'orrinsdk'} and any(alias.name == 'OrrinSDK' for alias in node.names):
                    return None
                return node

            def visit_Assign(self, node):
                # Remove assignments like 'orrin_sdk = OrrinSDK(...)'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'OrrinSDK':
                    return None
                # Handle if assigned to different var names? For now, assume standard 'OrrinSDK' class name.
                return node

            def visit_Expr(self, node):
                # Remove standalone calls like 'orrin_sdk.finalize()'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'finalize':
                    return None
                return node

            def visit_FunctionDef(self, node):
                # Remove decorators like '@orrin_sdk.action(...)'
                new_decorators = []
                for dec in node.decorator_list:
                    if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr == 'action'):
                        new_decorators.append(dec)
                node.decorator_list = new_decorators
                return self.generic_visit(node)

        remover = OrrinRemover()
        cleaned_tree = remover.visit(tree)
        ast.fix_missing_locations(cleaned_tree)
        return ast.unparse(cleaned_tree).strip()

    def _strip_with_lines(self, source: str) -> str:
        """
        Fallback: Original line-based stripping, but improved to handle 'from sdk' and case-insensitivity.
        """
        lines = source.splitlines()
        filtered = []
        for l in lines:
            stripped_l = l.strip().lower()
            if (stripped_l.startswith("from sdk") or stripped_l.startswith("from orrinsdk") or
                stripped_l.startswith("import sdk") or stripped_l.startswith("import orrinsdk")):
                continue
            if 'orrinsdk' in stripped_l or '.action' in stripped_l or '.finalize' in stripped_l:
                continue
            filtered.append(l)
        return '\n'.join(filtered).strip()

class Models(list, Enum):
    # Grok Models
    GROK_4_2_FNR =              ["grok", "grok-4.20-0309-non-reasoning"]
    GROK_4_2_FR =               ["grok", "grok-4.20-0309-reasoning"]
    GROK_4_1_FNR =              ["grok", "grok-4-1-fast-non-reasoning"]
    GROK_4_1_FR =               ["grok", "grok-4-1-fast-reasoning"]

    # OpenAI Models
    GPT_5_4 =                   ["gpt", "gpt-5.4"]
    GPT_5_4_MINI =              ["gpt", "gpt-5.4-mini"]
    GPT_5_4_NANO =              ["gpt", "gpt-5.4-nano"]
    GPT_5 =                     ["gpt", "gpt-5"]
    GPT_5_MINI =                ["gpt", "gpt-5-mini"]
    GPT_5_NANO =                ["gpt", "gpt-5-nano"]
    GPT_O3_DEEP_RESEARCH =      ["gpt", "o3-deep-research"]
    GPT_O4_MINI_DEEP_RESEARCH = ["gpt", "o4-mini-deep-research"]

    # Claude
    CLAUDE_OPUS_4_6 =           ["claude", "claude-opus-4-6"]
    CLAUDE_SONNET_4_6 =         ["claude", "claude-sonnet-4-6"]

from xai_sdk import Client
from xai_sdk.chat import user, system, image
from xai_sdk.tools import web_search, x_search, code_execution
from openai import OpenAI
from anthropic import Anthropic

class OrrinAISDK:
    def __init__(self, api_key: str, model: Models):
        self.api_key = api_key
        self.brand = model.value[0]
        self.model = model.value[1]
    
    def chat(
        self,
        messages: list,
        tools: List[Dict[str, str]] = []
    ):
        all_messages = []

        match self.brand:
            case 'grok':
                client = Client(api_key=self.api_key)
                tools_config = []
                chats = []

                for tool in tools:
                    match tool['type']:
                        case 'schema':
                            try:
                                tool_id = tool['tool_id']
                                resp = requests.get('http://172.20.10.2:8081/v1/tool_schematic', headers={
                                    'tool-id': tool_id
                                })

                                if resp.ok:
                                    resp = resp.json()

                                    chats.append(system(
                                        f"You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:"
                                        f"{resp['schematic']}"
                                        "If you believe this tool should be used, or any of its actions, respond with `USE TOOL:`, followed by the metadata needed for that tool to be used."
                                    ))
                            except: pass
                        case 'web_search':
                            tools_config.append(web_search(enable_image_understanding=True))
                        case 'x_search':
                            tools_config.append(x_search())
                        case 'code_execution':
                            tools_config.append(code_execution())
                        case _:
                            break
                
                for message in messages:
                    if message['role'] == 'system':
                        chats.append(system(message['content']))
                        continue

                    if message['role'] == 'user':
                        chats.append(user(message['content']))
                        continue
                
                chat = client.chat.create(
                    model=self.model,  # reasoning model
                    tools=tools_config
                )
                is_thinking = True
                content = ''

                for response, chunk in chat.stream():
                    if chunk.content and is_thinking:
                        is_thinking = False

                    if chunk.content and not is_thinking:
                        content += chunk.content
                
                return content
            case 'gpt':
                client = OpenAI(api_key=self.api_key)

                tools_config = []
                tool_id = ''
                chats = []

                for tool in tools:
                    if tool['type'] == 'schema':
                        try:
                            tool_id = tool['tool_id']
                            resp = requests.get('http://172.20.10.2:8081/v1/tool_schematic', headers={
                                'tool-id': tool_id
                            })

                            if resp.ok:
                                resp = resp.json()

                                chats.append({
                                    'role': 'system',
                                    'content': f'''You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:
                                    {resp['schematic']}

                                    If you believe this tool should be used, or any of its actions, respond with `USE TOOL:`, followed
                                    by the metadata needed for that tool to be used on the same line (no newlines).

                                    An example of the metadata needed for the tool will be:
                                    {{"actionID": <actionID>, "payload": <payload_needed>}}
                                    '''
                                })
                        except: pass

                        continue

                    tools_config.append(tool)
                
                for message in messages:
                    chats.append(message)

                resp = client.responses.create(
                    model=self.model,
                    input=chats
                )

                if 'USE TOOL:' in resp.output_text:
                    resp = resp.output_text.replace('USE TOOL:', '').rstrip()
                    resp = loads(resp)
                    
                    action = resp["actionID"]
                    payload = resp["payload"]

                    r = requests.post('http://172.20.10.2:8081/v1/tools', headers={
                        'authorization': '922785tyu33er93se111093kloi'
                    }, json={
                        'toolId': tool_id,
                        'action': action,
                        'payload': payload
                    })

                    if r.ok:
                        r = r.json()
                        return dumps(r, indent=2)
                    else:
                        try:
                            return dumps({
                                'status': '500',
                                'message': 'something went wrong',
                                'result': r.json()
                            })
                        except:
                            return dumps({
                                'status': '500',
                                'message': 'something went wrong'
                            })
                return resp.output_text
            case 'claude':
                client = Anthropic(api_key=self.api_key)

                chats = []

                for tool in tools:
                    if tool['type'] == 'schema':
                        try:
                            tool_id = tool['tool_id']
                            resp = requests.get('http://172.20.10.2:8081/v1/tool_schematic', headers={
                                'tool-id': tool_id
                            })

                            if resp.ok:
                                resp = resp.json()

                                chats.append({
                                    'role': 'system',
                                    'content': f'''You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:
                                    {resp['schematic']}'''
                                })
                        except: pass

                        continue
                
                for message in messages:
                    chats.append(message)

                resp = client.messages.create(
                    model=self.model,
                    messages=chats
                )

                return resp.content