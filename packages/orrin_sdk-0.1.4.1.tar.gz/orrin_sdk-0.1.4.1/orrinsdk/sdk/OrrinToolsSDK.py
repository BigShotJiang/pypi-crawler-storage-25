from json import dumps
from .decorators import ProcessSource
import yaml, sys

class OrrinToolsSDK:
    def __init__(
            self,
            developer_api_key: str,
            tool_name: str,
            desc: str,
            nuances={},
            plugin_metadata: str = '',
            metadata={}
        ):
        self.developer_api_key = developer_api_key
        self.tool_name = tool_name
        self.process_source = ProcessSource()
        self.desc = desc
        self.nuances = nuances

        # Process the metadata
        self.plugins = {}
        self.plugin_actions = []
        self.plugin_entries = {}

        if not plugin_metadata == '':
            with open(plugin_metadata, 'r') as file:
                plugins = yaml.safe_load(file)
                file.close()
            
            for plugin in plugins['plugins']:
                if not all(k in plugin for k in ("type", "for", "display_name", "actions")):
                    print(
                        "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mPlugin for {plugin['for']} is missing some data.\033[0m\n\n"
                        f"Ensure you have: `type`, `for`, `name`, `display_name`, and `actions` in the data.\n\n"
                        "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                        "\033[0m\n"
                    )

                    sys.exit(1)

                if not isinstance(plugin['actions'], list):
                    print(
                        "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mActions must be an array, not {type(plugin['actions'])}\033[0m\n\n"
                        "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                        "\033[0m\n"
                    )

                    sys.exit(1)

                if plugin['for'] in self.plugins:
                    print(
                        "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mPlugin for {plugin['for']} alreadye exists.\033[0m\n\n"
                        f"Ensure you have all actions for the plugin in `actions` array. Cannot have multiple similar plugins.\n\n"
                        "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                        "\033[0m\n"
                    )

                    sys.exit(1)

                self.plugins[plugin['for']] = {
                    'type': plugin['type'],
                    'name': plugin['name'],
                    'display_name': plugin['display_name'],
                    'actions': plugin['actions']
                }
        
            print(dumps(self.plugins, indent=2))
        self.metadata = metadata
        self.tool_actions = []

    def action(
        self,
        name: str,
        payload_schema: str,
        desc: str,
        dependencies: dict = [],
        extra_metadata: dict = {}
    ):
        """
        Decorator to mark a function as a platform action.
        Stores metadata but does not upload yet.
        """
        def decorator(fn):
            # Track the source file (once)
            if self.process_source.source_file is None:
                try:
                    self.process_source.assign_source_file(fn)
                except Exception:
                    pass

            # Save action metadata
            tool_data = {
                "action_name": name,
                "entrypoint": fn.__name__,
                "payload_schema": payload_schema,
                "desc": desc,
                "dependencies": dependencies,
                "runtime": "python",
                "extra_metadata": extra_metadata or None
            }
            self.tool_actions.append(tool_data)
            return fn
        return decorator

    def plugin_entry(self, plugin: str):
        """
        Decorator to mark a function as a platform action.
        Stores metadata but does not upload yet.
        """
        def decorator(fn):
            if not plugin in self.plugins:
                print(
                    "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                    f"\033[31mThere is no plugin metadata for {plugin}. Ensure you add the plugin metadata in `metadata` dictionary for `OrrinToolsSDK`.\033[0m\n\n"
                    "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                    "\033[0m\n"
                )

                sys.exit(1)
                
            # Track the source file (once)
            if self.process_source.source_file is None:
                try:
                    self.process_source.assign_source_file(fn)
                except Exception:
                    pass

            # Save action metadata
            self.plugin_entries[plugin] = {
                'entrypoint': fn.__name__
            }

            return fn
        return decorator
    
    def plugin_action(self, plugin: str, name: str, extra_metadata: dict = {}):
        """
        Decorator to mark a function as a platform action.
        Stores metadata but does not upload yet.
        """
        def decorator(fn):
            if not plugin in self.plugins:
                print(
                    "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                    f"\033[31mThere is no plugin metadata for {plugin}. Ensure you add the plugin metadata in `metadata` dictionary for `OrrinToolsSDK`.\033[0m\n\n"
                    "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                    "\033[0m\n"
                )

                sys.exit(1)
            
            action_found = False
            for action in self.plugins[plugin]['actions']:
                if action['type'] == 'function' and action['function'] == name:
                    action_found = True
            
            if not action_found:
                print(
                    "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                    f"\033[31mThere is no action `{name}` found for the plugin {plugin}.\033[0m\n\n"
                    "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                    "\033[0m\n"
                )

                sys.exit(1)
                
            # Track the source file (once)
            if self.process_source.source_file is None:
                try:
                    self.process_source.assign_source_file(fn)
                except Exception:
                    pass

            # Save action metadata
            self.plugin_actions.append({
                'action_name': name,
                'entrypoint': fn.__name__,
                'extra_metadata': extra_metadata or None
            })
            return fn
        return decorator

    def finalize(self):
        """
        Read the full source file, strip Orrin-related code using AST (or fallback to line-based),
        and send all registered tool actions in one request to the backend.
        """
        if not self.tool_actions:
            print("\n[orrin-sdk] No actions registered, skipping upload.\n")
            return
        if not self.process_source.exists():
            print("\n[orrin-sdk] Could not find source file.\n")
            return
        
        try:
            self.process_source.get_source() #self._source_file.read_text()

            # Iterate through plugins, look for `type` of `function`
            if not self.plugins == {}:
                for plugin in self.plugins:
                    plugin_actions = self.plugins[plugin]['actions']
                    for plugin_action in plugin_actions:
                        if plugin_action['type'] == 'function' and not f'def {plugin_action["function"]}' in self.process_source.source_content:
                            print(
                                "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                                f"\033[31mThe source code is missing `{plugin_action['function']}` function for plugin action {plugin_action['action']}\033[0m\n\n"
                                "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                                "\033[0m\n"
                            )

                            sys.exit(1)

            # 🔐 Validate imports BEFORE stripping
            self.process_source.validate_imports()

            stripped_source = self.process_source.strip_with_ast()

        except ValueError as e:
            print(f"{e}")
            return

        except Exception as e:
            print(f"\n[orrin-sdk] AST stripping failed ({e}), falling back to line-based.\n")
            stripped_source = self.process_source.strip_with_lines()

        if not stripped_source:
            print("\n[orrin-sdk] Stripped source is empty, aborting.\n")
            return

        payload = {
            'tool_name': self.tool_name,
            'desc': self.desc,
            'nuances': self.nuances,
            'source_code': stripped_source,
            'tool_actions': self.tool_actions,
            'metadata': self.metadata
        }

        if not self.plugins == {}:
            payload['plugins'] = {}
            for plugin in self.plugins:
                payload['plugins'][plugin] = {}

                plugin_data = self.plugins[plugin]
                payload['plugins'][plugin]['plugin_name'] = plugin_data['name']
                payload['plugins'][plugin]['plugin_display_name'] = plugin_data['display_name']
                payload['plugins'][plugin]['plugin_entry'] = self.plugin_entries[plugin]['entrypoint']
                payload['plugins'][plugin]['actions'] = plugin_data['actions']

        try:
            response = requests.post(
                f"{API_BASE}/tools/actions/register",
                json=payload,
                headers={
                    "Authorization": self.developer_api_key,
                    "fsdk": "yes"
                },
                timeout=10
            )

            if response.status_code == 200:
                print(
                    "\n\033[1;32m[orrin-sdk] SUCCESS\033[0m\n\n"
                    "\033[32mTool Actions registered successfully!\033[0m\n\n"
                    "Approval Status: \033[1;33mPENDING\033[0m\n\n"
                    "\033[90mAll changes or new tools must be approved after submission.\n"
                    "This process typically takes 1–3 days.\033[0m\n"
                )

            else:
                try:
                    data = response.json()

                    if data['ErrorCode'] == 0x60:
                        print(
                            "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            "\033[31mFailed to register tool actions.\033[0m\n\n"
                            f"The tool \033[1;33m\"{self.tool_name}\"\033[0m has recently been \033[1;31marchived\033[0m and is\n"
                            "not authorized for release.\n\n"
                            "If you believe this was an error, please contact Stellr:\n"
                            "\033[4;34mhttps://stellr-company.com/contact\033[0m\n\n"
                            "\033[90mPlease wait 3–7 days for the tool to be completely wiped from our servers\n"
                            "before attempting to re-upload.\033[0m\n"
                        )

                    else:
                        print(
                            "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            f"\033[31mFailed to register tool actions\033[0m\n\n"
                            f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                            f"Message: \033[1;37m{response.json()['Message']}\033[0m\n"
                        )

                except:
                    print(
                        "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mFailed to register tool actions\033[0m\n\n"
                        f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                        f"Message: \033[1;37m{response.json()['Message']}\033[0m\n"
                    )
        except Exception as e:
            print(f"\n[orrin-sdk] Exception when sending actions: {e}\n")