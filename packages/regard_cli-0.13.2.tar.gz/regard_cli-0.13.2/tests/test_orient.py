"""Tests for orient commands — status, balance, positions, orders."""

import json
from unittest.mock import patch

from regard.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestStatus:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "status"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_fields(self, runner, patched):
        result = runner.invoke(app, ["--fields", "account_value,withdrawable", "hl", "status"])
        assert result.exit_code == 0
        d = data(result)
        assert set(d.keys()) == {"account_value", "withdrawable"}


class TestBalance:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "balance"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_spot_balances_present(self, runner, patched):
        result = runner.invoke(app, ["hl", "balance"])
        assert result.exit_code == 0
        d = data(result)
        assert d["account_mode"] == "default"
        assert len(d["spot_balances"]) == 2
        tokens = {b["token"] for b in d["spot_balances"]}
        assert tokens == {"USDC", "HYPE"}

    def test_empty_spot(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.orient.get_spot_balances", return_value=[]):
            result = runner.invoke(app, ["hl", "balance"])
            assert result.exit_code == 0
            d = data(result)
            assert d["spot_balances"] == []

    def test_unified_mode(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.orient.get_account_mode", return_value="unifiedAccount"):
            result = runner.invoke(app, ["hl", "status"])
            assert result.exit_code == 0
            assert data(result)["account_mode"] == "unifiedAccount"


class TestPositions:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "positions", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_empty(self, runner, patched):
        patched["info"].user_state.return_value = {
            "crossMarginSummary": {"accountValue": "100.00"},
            "withdrawable": "100.00",
            "assetPositions": [],
        }
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == []


class TestSpotBalances:
    def test_basic(self, runner, patched):
        result = runner.invoke(app, ["hl", "spot-balances"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 2
        tokens = {b["token"] for b in d}
        assert tokens == {"USDC", "HYPE"}

    def test_empty(self, runner, patched):
        from unittest.mock import patch as mp
        with mp("regard.venues.hyperliquid.commands.orient.get_spot_balances", return_value=[]):
            result = runner.invoke(app, ["hl", "spot-balances"])
            assert result.exit_code == 0
            assert data(result) == []


class TestOrders:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "orders", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_trigger_order_tif_none(self, runner, patched):
        """Regression: trigger orders (TP/SL) return tif=None from API."""
        patched["info"].frontend_open_orders.return_value = [
            {
                "coin": "BTC",
                "oid": 100003,
                "side": "A",
                "limitPx": "80000.0",
                "sz": "0.001",
                "orderType": "Take Profit Market",
                "tif": None,
                "reduceOnly": True,
                "timestamp": 1773000000000,
            }
        ]
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        d = data(result)
        assert d[0]["tif"] is None
        assert d[0]["type"] == "take profit market"
