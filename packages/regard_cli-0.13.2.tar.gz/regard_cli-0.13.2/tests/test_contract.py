"""Contract tests — every command produces valid JSON, no tracebacks, no ANSI.

The meta-test: invoke every command (success + error cases) and assert
the output is always valid JSON with the correct envelope shape.
This single file would have caught all 10 bugs from the 2026-03-31 test run.
"""

import json
import re

import pytest

from regard.main import app

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_stdout(result) -> dict:
    """Parse CLI result stdout as JSON. Fails with clear message if non-JSON."""
    stdout = result.stdout.strip() if result.stdout else ""
    assert "Traceback" not in stdout, f"Traceback in stdout: {stdout[:300]}"
    assert not re.search(r"\x1b\[[0-9;]*[a-zA-Z]", stdout), "ANSI codes in stdout"
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Non-JSON stdout (exit={result.exit_code}): {stdout!r}")


def assert_envelope(data: dict):
    """Assert the output follows the envelope contract."""
    assert isinstance(data, dict)
    assert "ok" in data
    if data["ok"]:
        assert "data" in data
        assert "meta" in data
    else:
        assert "error" in data


# ---------------------------------------------------------------------------
# HL commands — success paths (with mocked SDK)
# ---------------------------------------------------------------------------

HL_SUCCESS_COMMANDS = [
    ["hl", "status"],
    ["hl", "balance"],
    ["hl", "positions"],
    ["hl", "orders"],
    ["hl", "assets"],
    ["hl", "assets", "BTC"],
    ["hl", "prices"],
    ["hl", "prices", "BTC"],
    ["hl", "book", "BTC"],
    ["hl", "funding"],
    ["hl", "funding", "BTC"],
    ["hl", "funding", "BTC", "--history", "--limit", "3"],
    ["hl", "candles", "BTC", "1h", "--limit", "2"],
    ["hl", "trades"],
    ["hl", "trades", "BTC"],
    ["hl", "preflight", "BTC", "buy", "0.01"],
    ["hl", "order", "BTC", "buy", "0.01", "65000"],
    ["hl", "order", "BTC", "sell", "0.01", "--market"],
    ["hl", "cancel", "BTC", "100001"],
    ["hl", "cancel-all"],
    ["hl", "leverage", "BTC", "10"],
]


@pytest.mark.parametrize("args", HL_SUCCESS_COMMANDS, ids=lambda a: " ".join(a))
def test_hl_command_produces_valid_json(runner, patched, args):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is True, f"Expected ok=True for {args}: {data}"


# ---------------------------------------------------------------------------
# HL commands — error paths (should STILL produce valid JSON)
# ---------------------------------------------------------------------------

HL_ERROR_COMMANDS = [
    # Unknown asset
    (["hl", "prices", "FAKECOIN123"], "UNKNOWN_ASSET"),
    # Invalid side
    (["hl", "order", "BTC", "invalidside", "1", "65000"], "INVALID_SIDE"),
    # Invalid TIF
    (["hl", "order", "BTC", "buy", "1", "65000", "--tif", "badvalue"], "INVALID_TIF"),
    # Missing required args (Click/Typer parse error → JSON via monkey-patch)
    (["hl", "order"], "USAGE_ERROR"),
    (["hl", "book"], "USAGE_ERROR"),
    (["hl", "candles"], "USAGE_ERROR"),
    (["hl", "leverage", "BTC"], "USAGE_ERROR"),
    (["hl", "preflight", "BTC"], "USAGE_ERROR"),
    # Unknown option
    (["hl", "status", "--nonexistent"], "USAGE_ERROR"),
]


@pytest.mark.parametrize("args,expected_code", HL_ERROR_COMMANDS,
                         ids=lambda a: " ".join(a) if isinstance(a, list) else a)
def test_hl_error_produces_json(runner, patched, args, expected_code):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is False
    assert data["error"]["code"] == expected_code


# ---------------------------------------------------------------------------
# Global flags
# ---------------------------------------------------------------------------

def test_version_flag(runner):
    result = runner.invoke(app, ["--version"])
    # Version output is plain text (not JSON) — that's OK, it's a special case
    assert result.exit_code == 0


def test_fields_projection(runner, patched):
    result = runner.invoke(app, ["--fields", "account_value", "hl", "status"])
    data = parse_stdout(result)
    assert data["ok"] is True
    assert "account_value" in data["data"]


def test_no_args_help(runner):
    result = runner.invoke(app, [])
    # no_args_is_help exits 0 or 2 depending on Typer version — help text, not JSON (acceptable)
    assert result.exit_code in (0, 2)
