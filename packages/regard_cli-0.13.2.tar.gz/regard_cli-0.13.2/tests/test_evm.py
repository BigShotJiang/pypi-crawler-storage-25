"""Tests for EVM transaction safety — gas ceiling and simulation."""

import json
from unittest.mock import MagicMock, PropertyMock, patch

import pytest

from regard.core.evm import get_safe_gas_price, simulate_and_send


# ---------------------------------------------------------------------------
# Gas ceiling tests
# ---------------------------------------------------------------------------

def _make_w3(gas_price_gwei: float, median_effective_gwei: float, fee_history_fails: bool = False, tip_gwei: float = 0):
    """Create a mock Web3 with configurable gas price and fee history.

    median_effective_gwei: the total effective gas price (base + tip) per block.
    tip_gwei: priority fee portion (subtracted from effective to get base fee).
    """
    w3 = MagicMock()
    w3.eth.gas_price = int(gas_price_gwei * 10**9)

    if fee_history_fails:
        w3.eth.fee_history.side_effect = Exception("method not found")
    else:
        base_wei = int((median_effective_gwei - tip_gwei) * 10**9)
        tip_wei = int(tip_gwei * 10**9)
        # 21 base fee entries (N+1), 20 reward entries (N)
        base_fees = [base_wei] * 21
        rewards = [[tip_wei]] * 20
        w3.eth.fee_history.return_value = {"baseFeePerGas": base_fees, "reward": rewards}

    return w3


class TestGasCeiling:
    def test_normal_gas_passes(self):
        """Gas within 10x of median effective price passes."""
        w3 = _make_w3(gas_price_gwei=50, median_effective_gwei=30)
        price = get_safe_gas_price(w3)
        assert price == int(50 * 10**9)

    def test_gas_at_boundary_passes(self):
        """Gas at exactly 10x passes (not strictly greater)."""
        w3 = _make_w3(gas_price_gwei=300, median_effective_gwei=30)
        price = get_safe_gas_price(w3)
        assert price == int(300 * 10**9)

    def test_gas_spike_rejected(self):
        """Gas above 10x median is rejected."""
        w3 = _make_w3(gas_price_gwei=500, median_effective_gwei=30)
        with pytest.raises(SystemExit) as exc_info:
            get_safe_gas_price(w3)
        assert exc_info.value.code == 4

    def test_gas_spike_error_message(self, capsys):
        """Rejection error has human-readable message."""
        w3 = _make_w3(gas_price_gwei=600, median_effective_gwei=30)
        with pytest.raises(SystemExit):
            get_safe_gas_price(w3)
        output = json.loads(capsys.readouterr().out)
        assert output["ok"] is False
        assert output["error"]["code"] == "GAS_CEILING_EXCEEDED"
        assert "20x" in output["error"]["message"]  # 600/30 = 20x
        assert output["error"]["retryable"] is True
        assert output["error"]["execution_state"] == "not_executed"

    def test_fee_history_unavailable_passes(self):
        """If fee history RPC fails, gas price passes (fallback)."""
        w3 = _make_w3(gas_price_gwei=9999, median_effective_gwei=0, fee_history_fails=True)
        price = get_safe_gas_price(w3)
        assert price == int(9999 * 10**9)

    def test_zero_median_passes(self):
        """Zero median (edge case) doesn't cause division by zero."""
        w3 = _make_w3(gas_price_gwei=50, median_effective_gwei=0)
        # Override fee history to return zeros for both base and tip
        w3.eth.fee_history.return_value = {"baseFeePerGas": [0] * 21, "reward": [[0]] * 20}
        price = get_safe_gas_price(w3)
        assert price == int(50 * 10**9)

    def test_polygon_tip_offset_no_false_reject(self):
        """Polygon-like scenario: low base fee + high tip doesn't false-reject.

        Base fee 5 gwei, tip 30 gwei → effective 35 gwei.
        gas_price = 35 gwei. Ratio = 35/35 = 1x. Should pass.
        Without the fix, comparison was 35/5 = 7x (close to the 10x limit).
        """
        w3 = _make_w3(gas_price_gwei=35, median_effective_gwei=35, tip_gwei=30)
        price = get_safe_gas_price(w3)
        assert price == int(35 * 10**9)


# ---------------------------------------------------------------------------
# Simulation tests
# ---------------------------------------------------------------------------

def _make_tx():
    """Build a minimal unsigned tx dict."""
    return {
        "from": "0xSender",
        "to": "0xContract",
        "value": 0,
        "data": b"\x01\x02",
        "gas": 100_000,
        "gasPrice": 30 * 10**9,
        "nonce": 5,
        "chainId": 137,
    }


class TestSimulateAndSend:
    def test_success(self):
        """Simulation passes → signs and sends."""
        w3 = MagicMock()
        w3.eth.call.return_value = b""
        account = MagicMock()
        account.sign_transaction.return_value = MagicMock(raw_transaction=b"\xab\xcd")
        w3.eth.send_raw_transaction.return_value = b"\x00" * 32

        tx = _make_tx()
        tx_hash = simulate_and_send(w3, tx, account)

        # eth_call was called with simulation-only fields
        sim_call = w3.eth.call.call_args[0][0]
        assert "from" in sim_call
        assert "to" in sim_call
        assert "nonce" not in sim_call  # stripped for simulation
        assert "chainId" not in sim_call

        # Transaction was signed and sent
        account.sign_transaction.assert_called_once_with(tx)
        assert tx_hash == b"\x00" * 32

    def test_revert_dies(self):
        """Simulation revert → dies with SIMULATION_REVERTED."""
        w3 = MagicMock()
        w3.eth.call.side_effect = Exception("execution reverted: ERC20: insufficient allowance")
        account = MagicMock()

        tx = _make_tx()
        with pytest.raises(SystemExit) as exc_info:
            simulate_and_send(w3, tx, account)
        assert exc_info.value.code == 4

        # Transaction was NOT signed or sent
        account.sign_transaction.assert_not_called()
        w3.eth.send_raw_transaction.assert_not_called()

    def test_revert_error_message(self, capsys):
        """Revert error includes the revert reason."""
        w3 = MagicMock()
        w3.eth.call.side_effect = Exception("execution reverted: not owner")
        account = MagicMock()

        with pytest.raises(SystemExit):
            simulate_and_send(w3, _make_tx(), account)
        output = json.loads(capsys.readouterr().out)
        assert output["error"]["code"] == "SIMULATION_REVERTED"
        assert "not owner" in output["error"]["message"]
        assert output["error"]["execution_state"] == "not_executed"

    def test_native_transfer_no_data(self):
        """Native value transfer (no data field) simulates and sends correctly."""
        w3 = MagicMock()
        w3.eth.call.return_value = b""
        account = MagicMock()
        account.sign_transaction.return_value = MagicMock(raw_transaction=b"\xef")
        w3.eth.send_raw_transaction.return_value = b"\x01" * 32

        tx = {
            "from": "0xSender",
            "to": "0xDest",
            "value": 10**18,
            "gas": 21000,
            "gasPrice": 30 * 10**9,
            "nonce": 0,
            "chainId": 137,
        }
        tx_hash = simulate_and_send(w3, tx, account)

        sim_call = w3.eth.call.call_args[0][0]
        assert "data" not in sim_call
        assert sim_call["value"] == 10**18
        assert tx_hash == b"\x01" * 32
