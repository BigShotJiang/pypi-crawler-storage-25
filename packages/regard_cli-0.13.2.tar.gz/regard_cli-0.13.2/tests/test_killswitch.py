"""Tests for regard killswitch command."""

import json
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


def _parse_json(result):
    """Extract JSON from runner output, skipping any stderr progress lines."""
    # Typer's CliRunner mixes stderr into output. Find the JSON line.
    for line in reversed(result.output.strip().splitlines()):
        line = line.strip()
        if line.startswith("{"):
            return json.loads(line)
    raise AssertionError(f"No JSON found in output: {result.output!r}")

# Patch paths — _kill_hl imports from these modules at call time
_C = "regard.venues.hyperliquid.client"
_R = "regard.venues.hyperliquid.resolver"
_K = "regard.commands.killswitch"


def test_killswitch_no_address():
    """killswitch dies with clear error when no KILLSWITCH_ADDRESS configured."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 2
        data = _parse_json(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "NO_KILLSWITCH_ADDRESS"
        assert "config" in data["error"]["hint"]


def test_killswitch_with_address_hl_no_positions():
    """killswitch succeeds with no positions/orders to close."""
    with patch(f"{_K}._get_killswitch_address", return_value="0x1234567890abcdef1234567890abcdef12345678"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["destination"] == "0x1234567890abcdef1234567890abcdef12345678"
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["hl"]["closed_positions"] == []
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_hl_error_does_not_crash():
    """HL errors are caught and reported, poly still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", side_effect=Exception("connection failed")), \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["error"] == "connection failed"
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_poly_error_does_not_crash():
    """Poly errors are caught and reported, HL still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly", side_effect=Exception("geo-blocked")):

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
            "key_mode": "agent",
        }

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["poly"]["error"] == "geo-blocked"


def test_killswitch_reports_key_mode():
    """killswitch output includes key_mode so user knows agent key limitations."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 2,
            "closed_positions": [{"asset": "BTC", "side": "sell", "size": 0.1}],
            "transferred": [{"source": "perp", "token": "USDC", "amount": 500.0}],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        data = _parse_json(result)
        assert data["data"]["hl"]["key_mode"] == "agent"


def test_killswitch_reports_stranded_dex_balances():
    """killswitch with agent key reports HIP-3 dex balances as stranded."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [
                {"source": "perp", "token": "USDC", "amount": 100.0},
                {"source": "dex:flx", "amount": 50.0,
                 "error": "agent key cannot transfer HIP-3 dex funds — use master key or withdraw via Hyperliquid UI"},
            ],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        data = _parse_json(result)
        transfers = data["data"]["hl"]["transferred"]
        assert len(transfers) == 2
        assert transfers[0]["source"] == "perp"
        stranded = transfers[1]
        assert stranded["source"] == "dex:flx"
        assert "agent key" in stranded["error"]


def test_is_agent_key_detection(tmp_path, monkeypatch):
    """_is_agent_key correctly detects agent vs master key."""
    from regard.commands.killswitch import _is_agent_key

    monkeypatch.delenv("HYPERLIQUID_AGENT_KEY", raising=False)
    monkeypatch.delenv("HYPERLIQUID_PRIVATE_KEY", raising=False)

    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)

    settings.write_text(json.dumps({"env": {"HYPERLIQUID_AGENT_KEY": "0xabc"}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    assert _is_agent_key() is True

    settings.write_text(json.dumps({"env": {"HYPERLIQUID_PRIVATE_KEY": "0xabc"}}))
    assert _is_agent_key() is False

    monkeypatch.setenv("HYPERLIQUID_AGENT_KEY", "0xabc")
    assert _is_agent_key() is True


# ---------------------------------------------------------------------------
# Close logic tests — test _kill_hl internals with mocked SDK
# ---------------------------------------------------------------------------

def _mock_kill_hl(positions, close_response, orders=None):
    """Run _kill_hl with mocked SDK. Returns the result dict."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.return_value = close_response

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=positions), \
         patch(f"{_C}.get_all_orders", return_value=orders or []), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True):

        from regard.commands.killswitch import _kill_hl
        return _kill_hl("0xdest")


def test_close_filled():
    """Position close that fills reports avg_price and status."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "-0.1"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"filled": {"totalSz": "0.1", "avgPx": "95100.5", "oid": 123}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["status"] == "filled"
    assert closed["avg_price"] == "95100.5"
    assert closed["side"] == "buy"


def test_close_error_from_exchange():
    """Exchange returns error status."""
    result = _mock_kill_hl(
        positions=[{"coin": "ETH", "szi": "1.0"}],
        close_response={"status": "err", "response": "Insufficient margin"},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "Insufficient margin" in closed["error"]


def test_close_ioc_expired():
    """IOC order expires without filling — resting instead of filled."""
    result = _mock_kill_hl(
        positions=[{"coin": "SOL", "szi": "-10.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"resting": {"oid": 456}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "no fill" in closed["error"]


def test_close_order_error_in_status():
    """Exchange returns error inside statuses array."""
    result = _mock_kill_hl(
        positions=[{"coin": "xyz:NATGAS", "szi": "-12.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"error": "reduce only order would increase position"}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["error"] == "reduce only order would increase position"


def test_close_market_close_returns_none():
    """market_close returns None when position not found by SDK."""
    result = _mock_kill_hl(
        positions=[{"coin": "UNKNOWN", "szi": "5.0"}],
        close_response=None,
    )
    closed = result["closed_positions"][0]
    assert "not found" in closed["error"]


def test_close_zero_position_skipped():
    """Positions with szi=0 are skipped."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "0.0"}],
        close_response=None,
    )
    assert result["closed_positions"] == []


def test_close_exception_caught():
    """SDK exception during market_close is caught and reported."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.side_effect = Exception("connection reset")

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")

    closed = result["closed_positions"][0]
    assert closed["error"] == "connection reset"
    assert closed["side"] == "sell"


# ---------------------------------------------------------------------------
# Transfer logic tests — unified and legacy accounts
# ---------------------------------------------------------------------------

SPOT_META = {
    "tokens": [
        {"name": "USDC", "index": 0, "tokenId": "0xabc", "isCanonical": True, "weiDecimals": 8, "szDecimals": 2},
        {"name": "USDH", "index": 360, "tokenId": "0x54e00a", "isCanonical": False, "weiDecimals": 8, "szDecimals": 2},
        {"name": "USDE", "index": 235, "tokenId": "0x2e6d84", "isCanonical": False, "weiDecimals": 8, "szDecimals": 2},
        {"name": "USDT0", "index": 400, "tokenId": "0x3d1a00", "isCanonical": False, "weiDecimals": 8, "szDecimals": 2},
    ],
}


COLLATERAL_MAP = {
    "": ("USDC", 0),
    "xyz": ("USDC", 0),
    "para": ("USDC", 0),
    "flx": ("USDH", 360),
    "vntl": ("USDH", 360),
    "km": ("USDH", 360),
    "hyna": ("USDE", 235),
    "cash": ("USDT0", 400),
}


def _make_transfer_mocks(account_mode="unifiedAccount", spot_balances=None, dex_balances=None, withdrawable="0"):
    """Create mocks for transfer logic tests."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": withdrawable}
    mock_info.spot_meta.return_value = SPOT_META
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.return_value = None  # no positions to close
    mock_exchange.send_asset.return_value = {"status": "ok", "response": {"type": "default"}}
    mock_exchange.usd_transfer.return_value = {"status": "ok"}
    mock_exchange.spot_transfer.return_value = {"status": "ok"}

    return mock_info, mock_exchange, [
        patch(f"{_C}.get_exchange", return_value=mock_exchange),
        patch(f"{_C}.get_address", return_value="0xaddr"),
        patch(f"{_C}.get_all_positions", return_value=[]),
        patch(f"{_C}.get_all_orders", return_value=[]),
        patch(f"{_C}.get_spot_balances", return_value=spot_balances or []),
        patch(f"{_C}.get_dex_balances", return_value=dex_balances or []),
        patch(f"{_C}.get_account_mode", return_value=account_mode),
        patch(f"{_C}.get_collateral_map", return_value=dict(COLLATERAL_MAP)),
        patch(f"{_R}.get_resolver", return_value=MagicMock()),
        patch(f"{_K}._is_agent_key", return_value=account_mode != "unifiedAccount"),
    ]


def test_unified_transfer_uses_send_asset():
    """Unified account uses send_asset(dest, 'spot', 'spot', ...) for transfers."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[
            {"token": "USDC", "balance": "25.00", "token_index": 0},
            {"token": "USDH", "balance": "15.00", "token_index": 360},
        ],
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    assert len(result["transferred"]) == 2
    # USDC uses plain name (canonical)
    mock_exchange.send_asset.assert_any_call("0xdest", "spot", "spot", "USDC", 24.99)
    # USDH uses TOKEN:tokenId format (non-canonical)
    mock_exchange.send_asset.assert_any_call("0xdest", "spot", "spot", "USDH:0x54e00a", 14.99)
    # spot_transfer should NOT be called on unified accounts
    mock_exchange.spot_transfer.assert_not_called()
    mock_exchange.usd_transfer.assert_not_called()


def test_unified_transfer_dust_buffer():
    """Large balances get dust buffer deducted, small ones sent as-is."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[
            {"token": "USDC", "balance": "50.00", "token_index": 0},  # > 0.02 → dust buffer applied
            {"token": "USDH", "balance": "0.005", "token_index": 360},  # ≤ 0.02 → sent as-is
        ],
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    transfers = result["transferred"]
    # USDC: 50.00 - 0.01 dust = 49.99
    assert transfers[0]["amount"] == 49.99
    # USDH: 0.005 sent as-is (below 0.02 threshold)
    assert transfers[1]["amount"] == 0.005


def test_unified_transfer_send_asset_error():
    """send_asset error on unified account is reported, doesn't crash."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[{"token": "USDC", "balance": "10.00", "token_index": 0}],
    )
    mock_exchange.send_asset.return_value = {"status": "err", "response": "Insufficient balance"}
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    assert result["transferred"][0]["error"] == "Insufficient balance"


def test_legacy_transfer_uses_usd_and_spot_transfer():
    """Legacy account uses usd_transfer for perp USDC and spot_transfer for spot tokens."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        spot_balances=[{"token": "USDH", "balance": "5.00", "token_index": 360}],
        withdrawable="100.50",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    mock_exchange.usd_transfer.assert_called_once_with(100.50, "0xdest")
    # spot_transfer uses NAME:tokenId for non-canonical tokens + dust buffer
    mock_exchange.spot_transfer.assert_called_once_with(4.99, "0xdest", "USDH:0x54e00a")
    mock_exchange.send_asset.assert_not_called()


def test_legacy_hip3_dex_stranded_on_agent_key():
    """Agent key reports HIP-3 dex balances as stranded."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "50.0", "positions": 0},
        ],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    stranded = [t for t in result["transferred"] if "agent key" in t.get("error", "")]
    assert len(stranded) == 1
    assert stranded[0]["source"] == "dex:flx"


def test_legacy_hip3_dex_consolidated_on_master_key():
    """Master key consolidates HIP-3 dex balances via send_asset."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "xyz", "account_value": "20.0", "positions": 0},
        ],
        withdrawable="0",
    )
    # Override is_agent_key to False (master key)
    patches[-1] = patch(f"{_K}._is_agent_key", return_value=False)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["source"] == "dex:xyz"
    # send_asset routes to "spot", not default perp
    mock_exchange.send_asset.assert_called_once()
    call_args = mock_exchange.send_asset.call_args[0]
    assert call_args[1] == "xyz"    # source dex
    assert call_args[2] == "spot"   # destination


def test_legacy_hip3_non_usdc_consolidation():
    """Non-USDC HIP-3 dex (flx→USDH) consolidates to spot with correct token format."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "75.0", "positions": 0},
        ],
        withdrawable="0",
    )
    patches[-1] = patch(f"{_K}._is_agent_key", return_value=False)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["source"] == "dex:flx"
    assert consolidated[0]["token"] == "USDH"
    # send_asset must use NAME:tokenId format and route to "spot"
    mock_exchange.send_asset.assert_called_once()
    call_args = mock_exchange.send_asset.call_args[0]
    assert call_args[1] == "flx"
    assert call_args[2] == "spot"
    assert call_args[3] == "USDH:0x54e00a"


def test_legacy_hip3_mixed_dex_collateral():
    """Multiple HIP-3 dexes with different collateral types consolidate correctly."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "xyz", "account_value": "30.0", "positions": 0},
            {"dex": "flx", "account_value": "50.0", "positions": 0},
        ],
        spot_balances=[{"token": "USDC", "balance": "10.00", "token_index": 0}],
        withdrawable="0",
    )
    patches[-1] = patch(f"{_K}._is_agent_key", return_value=False)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 2
    dexes = {c["source"] for c in consolidated}
    assert "dex:xyz" in dexes
    assert "dex:flx" in dexes

    # Both send to "spot"
    for call in mock_exchange.send_asset.call_args_list:
        assert call[0][2] == "spot"

    # Spot sweep runs after consolidation
    spot_transfers = [t for t in result["transferred"] if t.get("source") == "spot"]
    assert len(spot_transfers) >= 1  # at least the pre-existing USDC


def test_legacy_hip3_all_non_usdc_collateral_types():
    """All non-USDC collateral types (USDH, USDE, USDT0) consolidate with correct token format."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "40.0", "positions": 0},   # USDH
            {"dex": "hyna", "account_value": "30.0", "positions": 0},  # USDE
            {"dex": "cash", "account_value": "20.0", "positions": 0},  # USDT0
        ],
        withdrawable="0",
    )
    patches[-1] = patch(f"{_K}._is_agent_key", return_value=False)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 3

    # Verify each dex used the right collateral token
    by_source = {c["source"]: c for c in consolidated}
    assert by_source["dex:flx"]["token"] == "USDH"
    assert by_source["dex:hyna"]["token"] == "USDE"
    assert by_source["dex:cash"]["token"] == "USDT0"

    # Verify send_asset used NAME:tokenId format for all
    assert mock_exchange.send_asset.call_count == 3
    token_args = {call[0][3] for call in mock_exchange.send_asset.call_args_list}
    assert "USDH:0x54e00a" in token_args
    assert "USDE:0x2e6d84" in token_args
    assert "USDT0:0x3d1a00" in token_args

    # All routed to "spot"
    for call in mock_exchange.send_asset.call_args_list:
        assert call[0][2] == "spot"


def test_legacy_hip3_dry_run():
    """Dry run reports consolidation without executing."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "25.0", "positions": 0},
        ],
        withdrawable="0",
    )
    patches[-1] = patch(f"{_K}._is_agent_key", return_value=False)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest", dry_run=True)
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["status"] == "dry_run"
    # No actual API calls
    mock_exchange.send_asset.assert_not_called()
    mock_exchange.spot_transfer.assert_not_called()


def test_cancel_orders_flow():
    """Cancel orders calls bulk_cancel with correct format."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_info.spot_meta.return_value = SPOT_META
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.bulk_cancel.return_value = {"status": "ok"}

    orders = [
        {"coin": "BTC", "oid": 123},
        {"coin": "ETH", "oid": 456},
        {"coin": "xyz:TSLA", "oid": 789},
    ]

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[]), \
         patch(f"{_C}.get_all_orders", return_value=orders), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_C}.get_account_mode", return_value="default"), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")

    assert result["cancelled_orders"] == 3
    mock_exchange.bulk_cancel.assert_called_once()
    cancel_args = mock_exchange.bulk_cancel.call_args[0][0]
    assert len(cancel_args) == 3
    assert cancel_args[0] == {"coin": "BTC", "oid": 123}


def test_slippage_config_read():
    """_get_killswitch_slippage reads from settings."""
    from regard.commands.killswitch import _get_killswitch_slippage

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "0.15"}):
        assert _get_killswitch_slippage() == 0.15

    with patch(f"{_C}._load_settings_env", return_value={}):
        assert _get_killswitch_slippage() == 0.10  # default

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "garbage"}):
        assert _get_killswitch_slippage() == 0.10  # fallback on bad value


# ---------------------------------------------------------------------------
# Dry run tests
# ---------------------------------------------------------------------------

def test_dry_run_does_not_execute():
    """--dry-run reports what would happen without calling exchange methods."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 2,
            "closed_positions": [{"asset": "BTC", "side": "sell", "size": 0.1, "status": "dry_run"}],
            "transferred": [{"source": "spot", "token": "USDC", "amount": 100, "status": "dry_run"}],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch", "--dry-run"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["data"]["dry_run"] is True
        # Verify _kill_hl was called with dry_run=True
        mock_hl.assert_called_once_with("0xdead", dry_run=True)


def test_dry_run_close_logic():
    """Dry run skips market_close and reports dry_run status."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "-0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[{"coin": "BTC", "oid": 123}]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True), \
         patch(f"{_C}.get_account_mode", return_value="default"):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest", dry_run=True)

    # Orders counted but not cancelled
    assert result["cancelled_orders"] == 1
    mock_exchange.bulk_cancel.assert_not_called()

    # Position reported but not closed
    assert result["closed_positions"][0]["status"] == "dry_run"
    mock_exchange.market_close.assert_not_called()


# ---------------------------------------------------------------------------
# Contract tests — envelope shape, no tracebacks
# ---------------------------------------------------------------------------

def test_killswitch_no_address_envelope():
    """killswitch error produces valid JSON envelope with correct shape."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert "ok" in data
        assert data["ok"] is False
        assert "error" in data
        assert "type" in data["error"]
        assert "code" in data["error"]
        assert "message" in data["error"]


def test_killswitch_success_envelope():
    """killswitch success produces valid JSON envelope with meta."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", return_value={"cancelled_orders": 0, "closed_positions": [], "transferred": [], "key_mode": "agent"}), \
         patch(f"{_K}._kill_poly", return_value={"skipped": "not configured"}):

        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert data["ok"] is True
        assert "data" in data
        assert "meta" in data
        assert "timestamp" in data["meta"]


def test_killswitch_unknown_option_produces_json():
    """Unknown flags produce JSON error, not Rich/Click text."""
    result = runner.invoke(app, ["killswitch", "--nonexistent"])
    assert "Traceback" not in result.output
    data = _parse_json(result)
    assert data["ok"] is False


# ---------------------------------------------------------------------------
# Config integration tests
# ---------------------------------------------------------------------------

def test_config_show_includes_killswitch_address(tmp_path, monkeypatch):
    """config show surfaces killswitch_address field."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"KILLSWITCH_ADDRESS": "0xdead"}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["current"] == "0xdead"
    assert ks["configured"] is True


def test_config_show_killswitch_not_configured(tmp_path, monkeypatch):
    """config show shows killswitch_address as null when not set."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["configured"] is False
