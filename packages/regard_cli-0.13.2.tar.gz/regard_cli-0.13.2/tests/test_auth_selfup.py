"""Auth + selfup command tests.

Tests auth check, auth sync, selfup version comparison.
Auth hl/poly are interactive (getpass) — tested via key validation only.
"""

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from typer.testing import CliRunner

from regard.main import app
from regard.commands.auth import _validate_hex_key
from regard.commands.update import _parse_version, _get_pypi_latest

runner = CliRunner()


# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

class TestValidateHexKey:
    def test_valid_with_prefix(self):
        key = "0x" + "a" * 64
        assert _validate_hex_key(key) == "0x" + "a" * 64

    def test_valid_without_prefix(self):
        key = "b" * 64
        assert _validate_hex_key(key) == "0x" + "b" * 64

    def test_too_short(self):
        assert _validate_hex_key("0xabc") == ""

    def test_too_long(self):
        assert _validate_hex_key("0x" + "a" * 65) == ""

    def test_non_hex(self):
        assert _validate_hex_key("0x" + "g" * 64) == ""

    def test_empty(self):
        assert _validate_hex_key("") == ""

    def test_whitespace_stripped(self):
        key = "  0x" + "c" * 64 + "  "
        assert _validate_hex_key(key) == "0x" + "c" * 64


# ---------------------------------------------------------------------------
# Auth check
# ---------------------------------------------------------------------------

class TestAuthCheck:
    def test_no_credentials(self):
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.venues.hyperliquid.client._load_settings_env", return_value={}):
                result = runner.invoke(app, ["auth", "check"])
                d = json.loads(result.stdout)
                assert d["ok"] is True
                hl = d["data"]["venues"]["hyperliquid"]
                assert hl["configured"] is False
                poly = d["data"]["venues"]["polymarket"]
                assert poly["configured"] is False

    def test_with_hl_key(self):
        fake_key = "0x" + "a" * 64
        env = {"HYPERLIQUID_AGENT_KEY": fake_key}
        mock_account = MagicMock(address="0xTEST")
        mock_info = MagicMock()
        mock_info.post.return_value = {"role": "agent", "data": {"user": "0xMASTER"}}
        with patch.dict(os.environ, env):
            with patch("eth_account.Account.from_key", return_value=mock_account):
                with patch("hyperliquid.info.Info", return_value=mock_info):
                    result = runner.invoke(app, ["auth", "check"])
                    d = json.loads(result.stdout)
                    assert d["ok"] is True
                    hl = d["data"]["venues"]["hyperliquid"]
                    assert hl["configured"] is True
                    assert hl["mode"] == "agent"

    def test_with_poly_key(self):
        fake_key = "0x" + "b" * 64
        env = {"POLYMARKET_PRIVATE_KEY": fake_key}
        mock_account = MagicMock(address="0xPOLY")
        with patch.dict(os.environ, env):
            with patch("eth_account.Account.from_key", return_value=mock_account):
                result = runner.invoke(app, ["auth", "check"])
                d = json.loads(result.stdout)
                poly = d["data"]["venues"]["polymarket"]
                assert poly["configured"] is True
                assert poly["address"] == "0xPOLY"


# ---------------------------------------------------------------------------
# Auth sync
# ---------------------------------------------------------------------------

class TestAuthSync:
    def test_no_global_settings(self, tmp_path):
        with patch("regard.commands.auth.Path.home", return_value=tmp_path):
            result = runner.invoke(app, ["auth", "sync"])
            d = json.loads(result.stdout)
            assert d["ok"] is False

    def test_export_blocked_non_tty(self):
        """--export MUST refuse when stdin is not a TTY (agent context)."""
        with patch("regard.commands.auth._stdin_is_tty", return_value=False):
            result = runner.invoke(app, ["auth", "sync", "--export"])
            d = json.loads(result.stdout)
            assert d["ok"] is False
            assert d["error"]["code"] == "EXPORT_REQUIRES_TERMINAL"
            assert result.exit_code == 3

    def test_export_no_settings(self, tmp_path):
        with patch("regard.commands.auth._stdin_is_tty", return_value=True):
            with patch("regard.commands.auth.Path.home", return_value=tmp_path):
                result = runner.invoke(app, ["auth", "sync", "--export"])
                # Export mode outputs shell commands, not JSON
                assert "false" in result.stdout or result.exit_code != 0

    def test_export_allowed_tty(self, tmp_path):
        """--export works when stdin IS a TTY (human in terminal)."""
        global_dir = tmp_path / ".claude"
        global_dir.mkdir()
        settings = {"env": {"HYPERLIQUID_AGENT_KEY": "0x" + "a" * 64}}
        (global_dir / "settings.local.json").write_text(json.dumps(settings))

        with patch("regard.commands.auth._stdin_is_tty", return_value=True):
            with patch("regard.commands.auth.Path.home", return_value=tmp_path):
                result = runner.invoke(app, ["auth", "sync", "--export"])
                assert "export HYPERLIQUID_AGENT_KEY=" in result.stdout

    def test_sync_with_credentials(self, tmp_path):
        # Create global settings with credentials
        global_dir = tmp_path / ".claude"
        global_dir.mkdir()
        settings = {"env": {"HYPERLIQUID_AGENT_KEY": "0x" + "a" * 64}}
        (global_dir / "settings.local.json").write_text(json.dumps(settings))

        with patch("regard.commands.auth.Path.home", return_value=tmp_path):
            result = runner.invoke(app, ["auth", "sync"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["synced"] == 1


# ---------------------------------------------------------------------------
# Selfup
# ---------------------------------------------------------------------------

class TestSelfup:
    def test_no_update(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="0.6.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False

    def test_update_available(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="99.0.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is True
            assert "command" in d["data"]

    def test_pypi_unreachable(self):
        with patch("regard.commands.update._get_pypi_latest", return_value=None):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False
            assert d["data"]["latest"] is None


class TestParseVersion:
    def test_basic(self):
        assert _parse_version("0.10.6") == (0, 10, 6)

    def test_comparison(self):
        assert _parse_version("0.10.6") > _parse_version("0.10.5")
        assert _parse_version("0.11.0") > _parse_version("0.10.99")
        assert _parse_version("1.0.0") > _parse_version("0.99.99")

    def test_invalid(self):
        assert _parse_version("") == (0,)
        assert _parse_version(None) == (0,)
