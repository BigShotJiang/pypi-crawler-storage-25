"""Portfolio (regard port) tests — cross-venue aggregate view.

Mocks both HL and Poly clients to test JSON output shape, schema
consistency, partial-failure rollback, and edge cases.
"""

import json
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


def parse(result) -> dict:
    stdout = result.stdout.strip()
    assert "Traceback" not in stdout, f"Traceback leaked: {stdout[:300]}"
    return json.loads(stdout)


# ---------------------------------------------------------------------------
# Mock data
# ---------------------------------------------------------------------------

MOCK_DEX_BALANCES = [
    {"dex": "", "account_value": "1500.00", "positions": 1},
    {"dex": "xyz", "account_value": "200.00", "positions": 0},
]

MOCK_HL_POSITIONS = [
    {
        "coin": "BTC",
        "szi": "0.05",
        "unrealizedPnl": "12.50",
        "entryPx": "68000.00",
        "leverage": {"type": "cross", "value": 5},
    },
]

MOCK_MIDS = {"BTC": "68250.0", "ETH": "3400.0"}

MOCK_WALLET = {"usdc_e": "50.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": True}
MOCK_CLOB_BALANCE = {"balance": "100.00"}
MOCK_POLY_POSITIONS = [
    {
        "market": "Will BTC hit $100k?",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "size": 200,
        "avg_price": 0.55,
        "cur_price": 0.60,
        "pnl": 10.0,
    },
]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_HL = "regard.venues.hyperliquid.client"
_POLY = "regard.venues.polymarket.client"


def _patch_hl(positions=None, dex_balances=None, mids=None, fail=False):
    """Return patch context managers for HL client imports."""
    if fail:
        return [patch(f"{_HL}.get_info", side_effect=Exception("HL down"))]

    info = MagicMock()
    return [
        patch(f"{_HL}.get_info", return_value=info),
        patch(f"{_HL}.get_address", return_value="0xabc"),
        patch(f"{_HL}.get_dex_balances", return_value=dex_balances if dex_balances is not None else MOCK_DEX_BALANCES),
        patch(f"{_HL}.get_all_positions", return_value=positions if positions is not None else MOCK_HL_POSITIONS),
        patch(f"{_HL}.get_all_mids", return_value=mids if mids is not None else MOCK_MIDS),
    ]


def _patch_poly(positions=None, wallet=None, balance=None, fail=False):
    """Return patch context managers for Poly client imports."""
    if fail:
        return [patch(f"{_POLY}.get_clob_client", side_effect=Exception("Poly down"))]

    clob = MagicMock()
    clob.get_balance_allowance.return_value = balance or MOCK_CLOB_BALANCE
    clob.get_positions.return_value = positions if positions is not None else MOCK_POLY_POSITIONS
    return [
        patch(f"{_POLY}.get_clob_client", return_value=clob),
        patch(f"{_POLY}.get_wallet_balances", return_value=wallet or MOCK_WALLET),
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPortfolioHappyPath:
    """Both venues return data — verify JSON shape and values."""

    def test_both_venues(self):
        """Full portfolio with HL + Poly positions."""
        hl_patches = _patch_hl()
        poly_patches = _patch_poly()
        for p in hl_patches + poly_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)

            assert d["ok"] is True
            data = d["data"]

            # Totals
            assert float(data["total_equity"]) > 0
            assert data["position_count"] == 2

            # Venues
            assert len(data["venues"]) == 2
            hl_venue = next(v for v in data["venues"] if v["venue"] == "hyperliquid")
            poly_venue = next(v for v in data["venues"] if v["venue"] == "polymarket")
            assert "error" not in hl_venue
            assert "error" not in poly_venue
            assert hl_venue["positions"] == 1
            assert poly_venue["positions"] == 1

            # Position schema consistency — all positions have the same keys
            positions = data["positions"]
            assert len(positions) == 2
            expected_keys = {"venue", "asset", "side", "size", "entry_price", "mark_price", "unrealized_pnl", "leverage"}
            for p in positions:
                assert set(p.keys()) == expected_keys

            # All values are strings or None (not int/float)
            for p in positions:
                for k, v in p.items():
                    assert isinstance(v, (str, type(None))), f"Position field {k}={v!r} is {type(v).__name__}, expected str or None"
        finally:
            for p in hl_patches + poly_patches:
                p.stop()


class TestPortfolioSchemaConsistency:
    """Poly positions include leverage=None, all values are strings."""

    def test_poly_has_leverage_null(self):
        """Poly positions must have leverage key (set to None)."""
        hl_patches = _patch_hl(positions=[])  # no HL positions
        poly_patches = _patch_poly()
        for p in hl_patches + poly_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            positions = d["data"]["positions"]
            assert len(positions) == 1
            assert positions[0]["venue"] == "polymarket"
            assert "leverage" in positions[0]
            assert positions[0]["leverage"] is None
        finally:
            for p in hl_patches + poly_patches:
                p.stop()

    def test_poly_values_are_strings(self):
        """Poly position size/price/pnl must be strings, not raw ints/floats."""
        hl_patches = _patch_hl(positions=[])
        poly_patches = _patch_poly(positions=[{
            "market": "test",
            "side": "BUY",
            "size": 100,
            "avg_price": 0.42,
            "cur_price": 0.60,
            "pnl": 18.0,
        }])
        for p in hl_patches + poly_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            pos = d["data"]["positions"][0]
            assert isinstance(pos["size"], str)
            assert isinstance(pos["entry_price"], str)
            assert isinstance(pos["mark_price"], str)
            assert isinstance(pos["unrealized_pnl"], str)
        finally:
            for p in hl_patches + poly_patches:
                p.stop()


class TestPortfolioZeroSzi:
    """Zero-size positions must be filtered out."""

    def test_szi_zero_skipped(self):
        positions = [
            {"coin": "BTC", "szi": "0", "unrealizedPnl": "0", "entryPx": "100", "leverage": 5},
            {"coin": "ETH", "szi": "0.5", "unrealizedPnl": "3.00", "entryPx": "3000", "leverage": 3},
        ]
        hl_patches = _patch_hl(positions=positions)
        poly_patches = _patch_poly(positions=[])
        for p in hl_patches + poly_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            assert d["data"]["position_count"] == 1
            assert d["data"]["positions"][0]["asset"] == "ETH"
        finally:
            for p in hl_patches + poly_patches:
                p.stop()


class TestPortfolioPartialFailure:
    """When one venue fails, aggregates must not include leaked partial state."""

    def test_hl_fails_poly_ok(self):
        """HL throws — total_equity should only include Poly, no HL positions leaked."""
        all_patches = _patch_hl(fail=True) + _patch_poly()
        for p in all_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            data = d["data"]

            # HL shows error
            hl_venue = next(v for v in data["venues"] if v["venue"] == "hyperliquid")
            assert hl_venue["error"] == "unavailable"

            # Poly still works
            poly_venue = next(v for v in data["venues"] if v["venue"] == "polymarket")
            assert "error" not in poly_venue

            # Total equity = Poly only (100 CLOB + 50 USDC.e + 5 USDC = 155)
            assert float(data["total_equity"]) == 155.0

            # No HL positions leaked
            for p in data["positions"]:
                assert p["venue"] != "hyperliquid"
        finally:
            for p in all_patches:
                p.stop()

    def test_poly_fails_hl_ok(self):
        """Poly throws — total_equity should only include HL, no Poly positions leaked."""
        all_patches = _patch_hl() + _patch_poly(fail=True)
        for p in all_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            data = d["data"]

            # Poly shows error
            poly_venue = next(v for v in data["venues"] if v["venue"] == "polymarket")
            assert poly_venue["error"] == "unavailable"

            # HL still works
            hl_venue = next(v for v in data["venues"] if v["venue"] == "hyperliquid")
            assert "error" not in hl_venue

            # Total equity = HL only (1500 + 200 = 1700)
            assert float(data["total_equity"]) == 1700.0

            # No Poly positions leaked
            for p in data["positions"]:
                assert p["venue"] != "polymarket"
        finally:
            for p in all_patches:
                p.stop()

    def test_both_fail(self):
        """Both venues fail — empty but valid JSON."""
        all_patches = _patch_hl(fail=True) + _patch_poly(fail=True)
        for p in all_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            data = d["data"]
            assert float(data["total_equity"]) == 0.0
            assert data["position_count"] == 0
            assert len(data["positions"]) == 0
            assert len(data["venues"]) == 2
            assert all("error" in v for v in data["venues"])
        finally:
            for p in all_patches:
                p.stop()


class TestPortfolioContract:
    """Output envelope and JSON validity."""

    def test_valid_json_envelope(self):
        hl_patches = _patch_hl()
        poly_patches = _patch_poly()
        for p in hl_patches + poly_patches:
            p.start()
        try:
            result = runner.invoke(app, ["port"])
            d = parse(result)
            assert "ok" in d
            assert "data" in d or "error" in d
        finally:
            for p in hl_patches + poly_patches:
                p.stop()
