"""SDK client factory — creates Info and Exchange instances."""

import json
import os
from pathlib import Path

import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.info import Info
from hyperliquid.utils.constants import MAINNET_API_URL

from regard.core.output import die

TESTNET_API_URL = "https://api.hyperliquid-testnet.xyz"


def _base_url(testnet: bool) -> str:
    return TESTNET_API_URL if testnet else MAINNET_API_URL


def _load_settings_env() -> dict:
    """Load env vars from ~/.claude/settings.local.json as fallback.

    Claude Code injects these into the shell for new sessions, but after
    /clear or context compaction the env vars are lost. Reading the file
    directly means credentials always resolve without eval tricks.
    """
    try:
        settings_path = Path.home() / ".claude" / "settings.local.json"
        if settings_path.exists():
            return json.loads(settings_path.read_text()).get("env", {})
    except Exception:
        pass
    return {}


def _get_key():
    key = os.environ.get("HYPERLIQUID_AGENT_KEY") or os.environ.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        # Fallback: read from settings file directly
        settings_env = _load_settings_env()
        key = settings_env.get("HYPERLIQUID_AGENT_KEY") or settings_env.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        die(
            "auth_error", "NO_KEY",
            "No trading key set",
            hint="Run 'regard auth hl' in a separate terminal to set up credentials",
            exit_code=3,
        )
    return key


def _resolve_master_address(info: Info, agent_address: str) -> str:
    """Look up the master account for an agent wallet via userRole API."""
    try:
        result = info.post("/info", {"type": "userRole", "user": agent_address})
        role = result.get("role")
        if role == "agent":
            return result["data"]["user"]
        if role == "user":
            return agent_address  # key IS the master key
    except Exception:
        pass
    return agent_address  # fallback: assume key is master


def get_address(explicit: str = None, testnet: bool = False) -> str:
    """Get account address for queries.

    Priority: explicit arg > HYPERLIQUID_ACCOUNT_ADDRESS > auto-resolve via userRole API > derived from key.
    """
    if explicit:
        return explicit
    addr = os.environ.get("HYPERLIQUID_ACCOUNT_ADDRESS")
    if addr:
        return addr
    key = os.environ.get("HYPERLIQUID_AGENT_KEY") or os.environ.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        settings_env = _load_settings_env()
        key = settings_env.get("HYPERLIQUID_AGENT_KEY") or settings_env.get("HYPERLIQUID_PRIVATE_KEY")
    if key:
        agent_address = eth_account.Account.from_key(key).address
        is_agent = os.environ.get("HYPERLIQUID_AGENT_KEY") or _load_settings_env().get("HYPERLIQUID_AGENT_KEY")
        if is_agent:
            info = Info(_base_url(testnet), skip_ws=True)
            return _resolve_master_address(info, agent_address)
        return agent_address
    die(
        "auth_error", "NO_ADDRESS",
        "No address available",
        hint="Run 'regard auth hl' in a separate terminal, or use --address for read-only",
        exit_code=3,
    )


def get_info(testnet: bool = False) -> Info:
    """Create Info client (default perps only, dexes loaded lazily by resolver)."""
    return Info(_base_url(testnet), skip_ws=True)


def get_exchange(testnet: bool = False) -> Exchange:
    """Create Exchange client.

    Supports two modes:
    - Agent mode: HYPERLIQUID_AGENT_KEY (signs) + HYPERLIQUID_ACCOUNT_ADDRESS (queries master account)
    - Direct mode: HYPERLIQUID_PRIVATE_KEY (signs and queries same account)
    """
    key = _get_key()
    wallet = eth_account.Account.from_key(key)
    account_address = get_address()
    return Exchange(wallet, _base_url(testnet), account_address=account_address)


def get_all_mids(info: Info) -> dict:
    """Get all mid prices including HIP-3 deployer assets."""
    mids = info.all_mids()
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            dex_mids = info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
            mids.update(dex_mids)
    except Exception:
        pass
    return mids


def get_account_mode(info: Info, address: str) -> str:
    """Get account abstraction mode: default, unifiedAccount, portfolioMargin."""
    try:
        return info.query_user_abstraction_state(address) or "default"
    except Exception:
        return "default"


def get_spot_balances(info: Info, address: str) -> list:
    """Get spot token balances with human-readable amounts.

    Handles both legacy format (holds/withdrawn in wei) and unified account
    format (total as human-readable float string).
    Returns [] for accounts with no spot holdings or on error.
    """
    try:
        spot_state = info.spot_user_state(address)
        raw_balances = spot_state.get("balances", [])
        if not raw_balances:
            return []

        # Build token index lookup
        meta = info.spot_meta()
        tokens_by_index = {t["index"]: t for t in meta["tokens"]}

        result = []
        for bal in raw_balances:
            token_idx = bal["token"]
            token_info = tokens_by_index.get(token_idx)
            if not token_info:
                continue

            # Unified accounts use "total" as human-readable float string
            if "total" in bal:
                net = float(bal["total"])
            else:
                # Legacy: holds/withdrawn in wei
                holds = int(bal.get("holds", "0"))
                withdrawn = int(bal.get("withdrawn", "0"))
                net_wei = holds - withdrawn
                wei_decimals = token_info.get("weiDecimals", 18)
                net = net_wei / (10 ** wei_decimals)

            if net <= 0:
                continue

            sz_decimals = token_info.get("szDecimals", 2)
            result.append({
                "token": token_info["name"],
                "balance": f"{net:.{sz_decimals}f}",
                "token_index": token_idx,
            })

        return result
    except Exception:
        return []


def get_all_perp_metas(info: Info) -> list:
    """All perp dex metas in one call (replaces perpDexs for dex discovery).

    Returns raw list from allPerpMetas API. Index 0 is the default dex,
    the rest are HIP-3 deployers. Each item has: universe, marginTables,
    collateralToken. Dex name is extracted from universe asset names
    (e.g. "xyz:TSLA" → "xyz", "BTC" → "").
    """
    try:
        return info.post("/info", {"type": "allPerpMetas"})
    except Exception:
        return []


def get_perp_annotations(info: Info) -> dict:
    """Asset categories from perpConciseAnnotations API.

    Returns {asset_name: category} where category is "crypto", "stocks",
    "commodities", "indices", etc. Only HIP-3 assets appear; default perps
    are all crypto by definition.
    """
    try:
        data = info.post("/info", {"type": "perpConciseAnnotations"})
        return {item[0]: item[1].get("category", "") for item in data}
    except Exception:
        return {}


def get_collateral_map(info: Info) -> dict:
    """Build {dex_name: (token_name, token_index)} from allPerpMetas + spot meta.

    Resolves collateral token index to human-readable name via spot tokens list.
    Default dex key is "".
    """
    try:
        all_metas = info.post("/info", {"type": "allPerpMetas"})
        dex_list = info.post("/info", {"type": "perpDexs"})
        spot_meta = info.spot_meta()
        tokens = spot_meta["tokens"]

        result = {}
        for dex_info, meta in zip(dex_list, all_metas):
            name = dex_info.get("name", "")
            idx = meta.get("collateralToken", 0)
            token_name = tokens[idx]["name"] if idx < len(tokens) else "USDC"
            result[name] = (token_name, idx)
        return result
    except Exception:
        return {"": ("USDC", 0)}


def dex_name_from_universe(universe: list) -> str:
    """Extract dex name from allPerpMetas universe asset names.

    "xyz:TSLA" → "xyz", "BTC" → "" (default dex).
    """
    if not universe:
        return ""
    name = universe[0].get("name", "")
    return name.split(":")[0] if ":" in name else ""


def get_dex_for_coin(coin: str) -> str:
    """Extract dex name from coin. 'xyz:CL' → 'xyz', 'BTC' → '' (default)."""
    return coin.split(":")[0] if ":" in coin else ""


def get_active_asset_data(info: Info, address: str, coin: str) -> dict | None:
    """Preflight check: max trade size, available margin, leverage for a specific asset.

    Returns None on error. Fields: coin, leverage, max_trade_szs, available_to_trade, mark_px.
    """
    try:
        return info.post("/info", {"type": "activeAssetData", "user": address, "coin": coin})
    except Exception:
        return None


def get_all_orders(info: Info, address: str) -> list:
    """Get open orders across all perp dexes (default + HIP-3), including trigger orders.

    Uses frontendOpenOrders which returns full trigger metadata (triggerPx, isTrigger, etc.).
    """
    orders = []
    try:
        # Default perps
        for o in info.frontend_open_orders(address):
            orders.append(o)

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_orders = info.post("/info", {"type": "frontendOpenOrders", "user": address, "dex": name})
                for o in dex_orders:
                    orders.append(o)
            except Exception:
                continue
    except Exception:
        pass
    return orders


def get_all_positions(info: Info, address: str) -> list:
    """Get positions across all perp dexes (default + HIP-3).

    Returns list of raw position dicts from the API, each with an added
    "dex" field ("" for default, "xyz" etc for HIP-3).
    """
    positions = []
    try:
        # Default perps
        state = info.user_state(address)
        for p in state.get("assetPositions", []):
            pos = p["position"]
            if float(pos["szi"]) != 0:
                pos["_dex"] = ""
                positions.append(pos)

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_state = info.post("/info", {"type": "clearinghouseState", "user": address, "dex": name})
                for p in dex_state.get("assetPositions", []):
                    pos = p["position"]
                    if float(pos["szi"]) != 0:
                        pos["_dex"] = name
                        positions.append(pos)
            except Exception:
                continue
    except Exception:
        pass
    return positions


def get_dex_balances(info: Info, address: str) -> list:
    """Get account balances across all perp dexes.

    Returns [{dex, account_value, positions}] for dexes with non-zero balance or positions.
    For unified accounts, includes a "spot" entry with the total spot equity.
    """
    result = []
    is_unified = get_account_mode(info, address) == "unifiedAccount"
    try:
        # Default perps
        state = info.user_state(address)
        margin = state.get("marginSummary", state.get("crossMarginSummary", {}))
        val = margin.get("accountValue", "0")
        n_pos = len([p for p in state.get("assetPositions", []) if float(p["position"]["szi"]) != 0])
        result.append({"dex": "default", "account_value": val, "positions": n_pos})

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_state = info.post("/info", {"type": "clearinghouseState", "user": address, "dex": name})
                dex_margin = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {}))
                dex_val = dex_margin.get("accountValue", "0")
                dex_pos = len([p for p in dex_state.get("assetPositions", []) if float(p["position"]["szi"]) != 0])
                if float(dex_val) > 0 or dex_pos > 0:
                    result.append({"dex": name, "account_value": dex_val, "positions": dex_pos})
            except Exception:
                continue

        # Unified accounts hold equity in spot — include spot balances
        if is_unified:
            spot_bals = get_spot_balances(info, address)
            spot_total = sum(float(s["balance"]) for s in spot_bals)
            if spot_total > 0:
                result.append({"dex": "spot", "account_value": f"{spot_total:.6f}", "positions": 0})
    except Exception:
        pass
    return result
