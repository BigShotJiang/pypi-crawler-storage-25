"""Act commands — approve, order, cancel, cancel-all."""

from typing import Annotated, Optional

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor
from regard.venues.polymarket.client import (
    CONTRACTS,
    CTF_ABI,
    ERC20_ABI,
    check_geo_block,
    get_clob_client,
    get_collateral_token,
    get_gamma_client,
    get_web3,
)
from regard.venues.polymarket.main import poly_app
from regard.venues.polymarket.market import resolve_market

SIDE_MAP = {"buy": "BUY", "sell": "SELL"}
MAX_UINT256 = 2**256 - 1


def _validate_poly_precision(size: float, price: float | None, tick_size: float):
    """Reject orders with excess precision. Constitution Article II.

    Polymarket shares are whole numbers. Prices must be multiples of tick_size.
    Silent rounding is a correctness violation — reject instead.
    """
    from decimal import Decimal

    if size % 1 != 0:
        die("validation_error", "PRECISION_EXCEEDED",
            f"Size must be a whole number of shares, got {size}",
            param="size", exit_code=2)

    if price is not None:
        d_price = Decimal(str(price))
        d_tick = Decimal(str(tick_size))
        if d_tick > 0 and d_price % d_tick != 0:
            die("validation_error", "PRECISION_EXCEEDED",
                f"Price {price} is not a multiple of tick size {tick_size}",
                param="price", exit_code=2)


@poly_app.command()
def approve(ctx: typer.Context):
    """Approve USDC and CTF tokens for Polymarket contracts. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    params = {}
    proposal = create_proposal("poly", "approve", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_approve(params: dict) -> dict:
    """Execute on-chain Polymarket approvals from proposal params."""
    from regard.venues.polymarket.client import _get_key, get_address

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = get_address()

    w3 = get_web3()
    try:
        w3.eth.block_number  # verify connectivity (is_connected uses web3_clientVersion which eRPC blocks)
    except Exception:
        die("network_error", "RPC_UNREACHABLE", "Cannot connect to Polygon RPC",
            hint="Set POLYGON_RPC env var to a working RPC URL", exit_code=6)

    account = w3.eth.account.from_key(key)
    checksummed = w3.to_checksum_address(address)

    collateral = get_collateral_token(w3)
    collateral_addr = collateral["address"]
    collateral_name = collateral["name"]

    usdc = w3.eth.contract(address=w3.to_checksum_address(collateral_addr), abi=ERC20_ABI)
    ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_ABI)

    erc20_approvals = [
        (f"{collateral_name}→CTF", CONTRACTS["CTF"]),
        (f"{collateral_name}→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]
    ctf_approvals = [
        ("CTF→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        ("CTF→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        ("CTF→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]

    pending = []
    for label, spender in erc20_approvals:
        try:
            allowance = usdc.functions.allowance(checksummed, w3.to_checksum_address(spender)).call()
            if allowance < 10**18:
                pending.append((label, usdc, "approve", spender, MAX_UINT256))
        except Exception:
            pending.append((label, usdc, "approve", spender, MAX_UINT256))

    for label, spender in ctf_approvals:
        try:
            approved = ctf.functions.isApprovedForAll(checksummed, w3.to_checksum_address(spender)).call()
            if not approved:
                pending.append((label, ctf, "setApprovalForAll", spender, True))
        except Exception:
            pending.append((label, ctf, "setApprovalForAll", spender, True))

    if not pending:
        return {"approvals": [], "count": 0, "message": "All approvals already set"}

    tx_hashes = []
    nonce = w3.eth.get_transaction_count(checksummed, "pending")

    from regard.core.evm import get_safe_gas_price, simulate_and_send
    import time
    for label, contract, method, spender, value in pending:
        try:
            gas_price = get_safe_gas_price(w3)
            fn = getattr(contract.functions, method)
            tx = fn(w3.to_checksum_address(spender), value).build_transaction({
                "from": checksummed,
                "nonce": nonce,
                "gas": 100_000,
                "gasPrice": gas_price,
                "chainId": 137,
            })
            tx_hash = simulate_and_send(w3, tx, account)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

            if receipt["status"] != 1:
                die("venue_error", "APPROVAL_FAILED", f"{label} tx reverted: {tx_hash.hex()}", exit_code=4)

            tx_hashes.append({"label": label, "tx_hash": tx_hash.hex()})
            nonce += 1
            time.sleep(5)
        except SystemExit:
            raise
        except Exception as e:
            die("venue_error", "APPROVAL_FAILED", f"{label}: {e}", exit_code=4)

    return {"approvals": tx_hashes, "count": len(tx_hashes)}


register_executor("poly", "approve", execute_poly_approve)


@poly_app.command()
def order(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID, condition ID, or slug")],
    outcome: Annotated[str, typer.Argument(help="yes or no")],
    side: Annotated[str, typer.Argument(help="buy or sell")],
    size: Annotated[float, typer.Argument(help="Number of shares")],
    price: Annotated[Optional[float], typer.Argument(help="Limit price (probability 0.01-0.99)")] = None,
    market_order: Annotated[bool, typer.Option("--market", help="Market order (fill or kill)")] = False,
):
    """Place an order on a prediction market outcome. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    outcome_lower = outcome.lower()
    if outcome_lower not in ("yes", "no"):
        die("validation_error", "INVALID_OUTCOME", f"Outcome must be 'yes' or 'no', got '{outcome}'", exit_code=2)

    side_upper = SIDE_MAP.get(side.lower())
    if not side_upper:
        die("validation_error", "INVALID_SIDE", f"Side must be 'buy' or 'sell', got '{side}'", exit_code=2)

    if not market_order and price is None:
        die("validation_error", "MISSING_PRICE", "Specify a price or use --market", exit_code=2)

    if price is not None and (price < 0.01 or price > 0.99):
        die("validation_error", "INVALID_PRICE", f"Price must be between 0.01 and 0.99, got {price}", exit_code=2)

    check_geo_block()

    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)
    if not m["accepting_orders"]:
        die("venue_error", "MARKET_CLOSED", f"Market is not accepting orders: {m['question']}", exit_code=4)

    token_id = m["yes_token_id"] if outcome_lower == "yes" else m["no_token_id"]
    if not token_id:
        die("validation_error", "NO_TOKEN", f"No {outcome} token found", exit_code=2)

    # Validate precision before creating proposal
    _validate_poly_precision(size, price, m["tick_size"])

    # Capture current market probability as mark price (not user's limit price)
    current_prob = m["yes_price"] if outcome_lower == "yes" else m["no_price"]
    checks = {}
    if current_prob > 0:
        checks["mark_price"] = str(current_prob)

    params = {
        "token_id": token_id,
        "market_question": m["question"],
        "market_slug": m["slug"],
        "outcome": outcome_lower,
        "side": side_upper,
        "size": str(size),
        "price": str(price) if price is not None else None,
        "market_order": market_order,
        "tick_size": m["tick_size"],
    }

    warnings = []
    proposal = create_proposal("poly", "order", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_poly_order(params: dict) -> dict:
    """Execute a Polymarket order from proposal params."""
    check_geo_block()
    clob = get_clob_client()

    token_id = params["token_id"]
    side_upper = params["side"]
    size = float(params["size"])
    is_market = params["market_order"]

    # Validate precision at approve time too (defense in depth —
    # pre-upgrade proposals or tampered pending files could bypass propose-time check)
    price_val = float(params["price"]) if params.get("price") else None
    tick = params.get("tick_size", 0.01)
    _validate_poly_precision(size, price_val, tick)

    # Proactive balance check — catch insufficient funds before submission
    if side_upper == "BUY":
        try:
            from py_clob_client.clob_types import AssetType, BalanceAllowanceParams
            bal = clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))
            available = float(bal.get("balance", 0))
            estimated_cost = size * (price_val if price_val else 1.0)
            if available < estimated_cost:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"Available balance ({available:.2f}) is less than estimated order cost ({estimated_cost:.2f})",
                    hint="Deposit more USDC.e or reduce order size. Check balance with: regard poly balance",
                    extra={"execution_state": "not_executed"},
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass  # balance check is best-effort; CLOB will reject if insufficient

    try:
        from py_clob_client.clob_types import MarketOrderArgs, OrderArgs, OrderType

        if is_market:
            order_args = MarketOrderArgs(
                token_id=token_id,
                amount=size,
                side=side_upper,
                fee_rate_bps=0,
            )
            signed = clob.create_market_order(order_args)
            resp = clob.post_order(signed, OrderType.FOK)
        else:
            price = float(params["price"])

            order_args = OrderArgs(
                price=price,
                size=size,
                side=side_upper,
                token_id=token_id,
            )
            signed = clob.create_order(order_args)
            resp = clob.post_order(signed, OrderType.GTC)

    except Exception as e:
        err_str = str(e)
        if "not enough balance" in err_str.lower():
            die("venue_error", "INSUFFICIENT_BALANCE", err_str,
                hint="Check balance with: regard poly balance", exit_code=4)
        if "restricted" in err_str.lower() or "403" in err_str:
            die("geo_error", "GEO_BLOCKED", err_str,
                hint="Polymarket trading requires a non-US/non-SG IP (e.g. Ireland VPN)", exit_code=4)
        die("venue_error", "ORDER_REJECTED", err_str, exit_code=4)

    order_id = ""
    if isinstance(resp, dict):
        order_id = resp.get("orderID", resp.get("id", ""))

    return {
        "order_id": order_id,
        "market": params["market_question"],
        "outcome": params["outcome"],
        "side": side_upper,
        "size": params["size"],
        "price": params["price"] if params.get("price") else "market",
        "type": "FOK" if is_market else "GTC",
        "response": resp,
    }


register_executor("poly", "order", execute_poly_order)


@poly_app.command()
def cancel(
    ctx: typer.Context,
    order_id: Annotated[str, typer.Argument(help="Order ID to cancel")],
):
    """Cancel an open order. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    check_geo_block()

    params = {"order_id": order_id}
    proposal = create_proposal("poly", "cancel", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_cancel(params: dict) -> dict:
    """Execute a Polymarket cancel from proposal params."""
    check_geo_block()
    clob = get_clob_client()

    try:
        resp = clob.cancel(params["order_id"])
    except Exception as e:
        die("venue_error", "CANCEL_FAILED", str(e), exit_code=4)

    return {"order_id": params["order_id"], "response": resp}


register_executor("poly", "cancel", execute_poly_cancel)


@poly_app.command(name="cancel-all")
def cancel_all(ctx: typer.Context):
    """Cancel all open orders. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    check_geo_block()

    params = {}
    proposal = create_proposal("poly", "cancel-all", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_cancel_all(params: dict) -> dict:
    """Execute a Polymarket cancel-all from proposal params."""
    check_geo_block()
    clob = get_clob_client()

    try:
        resp = clob.cancel_all()
    except Exception as e:
        die("venue_error", "CANCEL_FAILED", str(e), exit_code=4)

    return {"response": resp}


register_executor("poly", "cancel-all", execute_poly_cancel_all)
