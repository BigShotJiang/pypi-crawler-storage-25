"""Review commands — trades."""

from typing import Annotated

import typer

from regard.core.output import output
from regard.venues.polymarket.client import get_clob_client
from regard.venues.polymarket.main import poly_app


@poly_app.command()
def trades(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 20,
):
    """Recent trade history."""
    opts = ctx.obj
    clob = get_clob_client()

    try:
        resp = clob.get_trades()
        trade_list = resp if isinstance(resp, list) else []
    except Exception:
        trade_list = []

    result = []
    for t in trade_list[:limit]:
        result.append({
            "trade_id": t.get("id", ""),
            "market": t.get("market", ""),
            "asset_id": t.get("asset_id", ""),
            "side": t.get("side", ""),
            "price": t.get("price", ""),
            "size": t.get("size", ""),
            "fee": t.get("fee", ""),
            "created_at": t.get("created_at", ""),
        })

    output(result, opts["fields"])
