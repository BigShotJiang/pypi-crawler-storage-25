"""Research commands — markets, market, book, prices."""

from typing import Annotated, Optional

import typer

from regard.core.output import die, output
from regard.venues.polymarket.client import get_clob_client, get_gamma_client
from regard.venues.polymarket.main import poly_app
from regard.venues.polymarket.market import resolve_market


@poly_app.command()
def markets(
    ctx: typer.Context,
    query: Annotated[Optional[str], typer.Argument(help="Search query")] = None,
    tag: Annotated[Optional[str], typer.Option("--tag", help="Filter by tag")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 20,
    active: Annotated[bool, typer.Option("--active/--all", help="Active only")] = True,
):
    """Search and list markets."""
    opts = ctx.obj
    gamma = get_gamma_client()

    # Fetch more than needed when filtering by query (client-side text search)
    fetch_limit = limit * 5 if query else limit
    params = {"limit": fetch_limit, "order": "volume24hr", "ascending": "false"}
    if active:
        params["active"] = "true"
        params["closed"] = "false"
    if tag:
        params["tag"] = tag

    try:
        resp = gamma.get("/markets", params=params)
        resp.raise_for_status()
        raw = resp.json()
    except Exception as e:
        die("venue_error", "FETCH_FAILED", f"Gamma API error: {e}", exit_code=4)

    # Client-side text filter (Gamma API search is unreliable)
    if query:
        q = query.lower()
        raw = [m for m in raw if q in m.get("question", "").lower()][:limit]

    result = []
    for m in raw:
        import json
        raw_clob = m.get("clobTokenIds", "[]")
        clob_ids = json.loads(raw_clob) if isinstance(raw_clob, str) else (raw_clob or [])
        raw_prices = m.get("outcomePrices", "[]")
        outcome_prices = json.loads(raw_prices) if isinstance(raw_prices, str) else (raw_prices or [])
        result.append({
            "market_id": m.get("id", ""),
            "question": m.get("question", ""),
            "yes_price": outcome_prices[0] if outcome_prices else "",
            "no_price": outcome_prices[1] if len(outcome_prices) > 1 else "",
            "volume_24h": m.get("volume24hr", ""),
            "liquidity": m.get("liquidityNum", ""),
            "end_date": m.get("endDateIso", ""),
            "active": m.get("active", False),
            "yes_token_id": clob_ids[0] if clob_ids else "",
        })

    output(result, opts["fields"])


@poly_app.command()
def market(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID, condition ID, slug, or search query")],
):
    """Get detailed market info."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)
    output(m, opts["fields"])


@poly_app.command()
def book(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID or condition ID")],
    outcome: Annotated[str, typer.Option("--outcome", help="yes or no")] = "yes",
    depth: Annotated[int, typer.Option("--depth", help="Levels per side")] = 10,
):
    """Order book for a market outcome."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)

    token_id = m["yes_token_id"] if outcome.lower() == "yes" else m["no_token_id"]
    if not token_id:
        die("validation_error", "NO_TOKEN", f"No {outcome} token found for this market", exit_code=2)

    clob = get_clob_client()
    ob = clob.get_order_book(token_id)

    bids = [{"price": str(b.price), "size": str(b.size)} for b in ob.bids[:depth]]
    asks = [{"price": str(a.price), "size": str(a.size)} for a in ob.asks[:depth]]

    output({
        "question": m["question"],
        "outcome": outcome,
        "token_id": token_id,
        "bids": bids,
        "asks": asks,
    }, opts["fields"])


@poly_app.command()
def event(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Event ID, slug, or search query")],
):
    """List all markets within an event — natural hedge pairs."""
    opts = ctx.obj
    gamma = get_gamma_client()

    # Try by event ID
    event_data = None
    if identifier.isdigit():
        try:
            resp = gamma.get(f"/events/{identifier}")
            if resp.status_code == 200:
                event_data = resp.json()
        except Exception:
            pass

    # Try by slug
    if not event_data:
        try:
            resp = gamma.get("/events", params={"slug": identifier, "limit": 1})
            events = resp.json()
            if events:
                event_data = events[0]
        except Exception:
            pass

    # Fallback: search by title across top events by volume
    if not event_data:
        try:
            resp = gamma.get("/events", params={
                "limit": 100, "active": "true", "closed": "false",
                "order": "volume24hr", "ascending": "false",
            })
            events = resp.json()
        except Exception as e:
            die("venue_error", "FETCH_FAILED", f"Gamma API error: {e}", exit_code=4)
        q = identifier.lower()
        for e in events:
            if q in e.get("title", "").lower():
                event_data = e
                break

    if not event_data:
        die("validation_error", "UNKNOWN_EVENT", f"No event found for '{identifier}'", exit_code=2)

    import json as json_mod
    event_markets = event_data.get("markets", [])
    result_markets = []
    for m in event_markets:
        clob_ids = json_mod.loads(m.get("clobTokenIds", "[]")) if isinstance(m.get("clobTokenIds"), str) else m.get("clobTokenIds", [])
        outcome_prices = json_mod.loads(m.get("outcomePrices", "[]")) if isinstance(m.get("outcomePrices"), str) else m.get("outcomePrices", [])
        result_markets.append({
            "market_id": m.get("id", ""),
            "question": m.get("question", ""),
            "yes_price": outcome_prices[0] if outcome_prices else "",
            "no_price": outcome_prices[1] if len(outcome_prices) > 1 else "",
            "volume_24h": m.get("volume24hr", ""),
            "active": m.get("active", False),
            "accepting_orders": m.get("acceptingOrders", False),
            "yes_token_id": clob_ids[0] if clob_ids else "",
        })

    # Sort by volume
    result_markets.sort(key=lambda x: float(x["volume_24h"] or "0"), reverse=True)

    output({
        "event_id": event_data.get("id", ""),
        "title": event_data.get("title", ""),
        "slug": event_data.get("slug", ""),
        "markets": result_markets,
        "market_count": len(result_markets),
    }, opts["fields"])


@poly_app.command()
def prices(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID or condition ID")],
):
    """Current prices for a market."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)

    output({
        "question": m["question"],
        "yes_price": m["yes_price"],
        "no_price": m["no_price"],
        "best_bid": m["best_bid"],
        "best_ask": m["best_ask"],
        "volume_24h": m["volume_24h"],
        "liquidity": m["liquidity"],
    }, opts["fields"])
