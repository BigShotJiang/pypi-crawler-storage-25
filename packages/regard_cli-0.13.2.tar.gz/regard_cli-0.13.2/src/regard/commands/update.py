"""Update check — compare installed CLI version against PyPI latest."""

import json
from importlib.metadata import version as pkg_version

import typer

from regard.core.output import output

update_app = typer.Typer(
    name="selfup",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Check for CLI updates.",
)


def _get_pypi_latest():
    """Fetch latest version from PyPI. Returns version string or None."""
    try:
        from urllib.request import urlopen, Request
        req = Request(
            "https://pypi.org/pypi/regard-cli/json",
            headers={"Accept": "application/json"},
        )
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("info", {}).get("version")
    except Exception:
        return None


def _parse_version(v):
    """Parse version string into tuple for comparison."""
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


@update_app.callback(invoke_without_command=True)
def check(ctx: typer.Context):
    """Check if a newer CLI version is available on PyPI."""
    current = pkg_version("regard-cli")
    latest = _get_pypi_latest()

    result = {
        "current": current,
        "latest": latest,
        "update_available": False,
    }

    if latest and _parse_version(latest) > _parse_version(current):
        result["update_available"] = True
        result["command"] = "uv tool upgrade regard-cli"

    opts = ctx.ensure_object(dict)
    output(result, opts.get("fields"))
