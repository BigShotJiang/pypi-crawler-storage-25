"""Config — surface and inspect CLI configuration."""

import typer

from regard.core.output import output

config_app = typer.Typer(
    name="config",
    no_args_is_help=True,
    help="View CLI configuration.",
)

DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"
DEFAULT_KILLSWITCH_SLIPPAGE = 0.10


@config_app.command()
def show():
    """Show current configuration."""
    from regard.venues.hyperliquid.client import _load_settings_env

    settings = _load_settings_env()
    custom_rpc = settings.get("POLYGON_RPC")

    killswitch_addr = settings.get("KILLSWITCH_ADDRESS")
    custom_slippage = settings.get("KILLSWITCH_SLIPPAGE")

    result = {
        "polygon_rpc": {
            "current": custom_rpc or DEFAULT_POLYGON_RPC,
            "source": "settings" if custom_rpc else "default",
            "default": DEFAULT_POLYGON_RPC,
        },
        "killswitch_address": {
            "current": killswitch_addr or None,
            "configured": killswitch_addr is not None,
        },
        "killswitch_slippage": {
            "current": float(custom_slippage) if custom_slippage else DEFAULT_KILLSWITCH_SLIPPAGE,
            "source": "settings" if custom_slippage else "default",
            "default": DEFAULT_KILLSWITCH_SLIPPAGE,
        },
    }
    output(result, None)
