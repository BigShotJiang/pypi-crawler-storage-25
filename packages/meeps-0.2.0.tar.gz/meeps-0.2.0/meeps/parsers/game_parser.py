from concurrent.futures.thread import ThreadPoolExecutor
from typing import List, Optional

from lol_dto.classes.game import LolGame
from lol_dto.classes.game.lol_game import LolPickBan

from meeps.site.leaguepedia import leaguepedia
from meeps.transmuters.field_names import (
    game_fields,
    tournaments_fields,
    game_players_fields,
)
from meeps.transmuters.game import transmute_game
from meeps.transmuters.game_players import add_players
from meeps.transmuters.picks_bans import (
    picks_bans_fields,
    transmute_picks_bans,
)
from meeps.transmuters.tournament import (
    transmute_tournament,
    LeaguepediaTournament,
)
from meeps.parsers.query_builder import QueryBuilder


def get_regions() -> List[str]:
    """Returns a list of all regions that appear in the Tournaments table.

    Returns:
        The list of all region names, simply strings.
    """
    regions_dicts_list = leaguepedia.query(
        tables="Tournaments", fields="Region", group_by="Region"
    )

    return [row["Region"] for row in regions_dicts_list]


def get_tournaments(
    region: str = None,
    year: int = None,
    tournament_level: str = "Primary",
    is_playoffs: bool = None,
    order_by: str = None,
    limit: int = None,
) -> List[LeaguepediaTournament]:
    """Returns a list of tournaments.

    Typical usage example:
        get_tournaments('China', 2020)

    Args:
        region: Recommended to get it from get_tournament_regions().
        year: Year to filter on. Defaults to None.
        tournament_level: Primary, Secondary, Major, Secondary, Showmatch. Defaults to Primary.
        is_playoffs: Can be used to filter between playoffs and regular season tournaments.
        order_by: SQL ORDER BY clause (e.g., "Tournaments.DateStart DESC").
        limit: Maximum number of tournaments to return.

    Returns:
        A list of LeaguepediaTournament objects.
    """
    # We need to cast is_playoffs as an integer for the cargoquery
    if is_playoffs is not None:
        is_playoffs = 1 if is_playoffs else 0

    # Build WHERE clause using QueryBuilder
    where = QueryBuilder.build_where(
        "Tournaments",
        {
            "Region": region,
            "Year": year,
            "TournamentLevel": tournament_level,
            "IsPlayoffs": is_playoffs,
        }
    )

    query_kwargs = {}
    if order_by:
        query_kwargs["order_by"] = order_by
    if limit:
        query_kwargs["limit"] = limit

    result = leaguepedia.query(
        tables="Tournaments, Leagues",
        join_on="Tournaments.League = Leagues.League",
        fields=f"Leagues.League_Short, {', '.join(f'Tournaments.{field}' for field in tournaments_fields)}",
        where=where,
        **query_kwargs,
    )

    return [transmute_tournament(tournament) for tournament in result]


def get_games(
    tournament_overview_page: str = None,
    limit: int = None,
) -> List[LolGame]:
    """Returns the list of games played in a tournament.

    Returns basic information about all games played in a tournament.

    Args:
        tournament_overview_page: Tournament overview page, acquired from get_tournaments().
        limit: Maximum number of games to return.

    Returns:
        A list of LolGame with basic game information.
    """
    query_kwargs = {}
    if limit:
        query_kwargs["limit"] = limit

    games = leaguepedia.query(
        tables="ScoreboardGames",
        fields=", ".join(game_fields),
        where=QueryBuilder.build_where("ScoreboardGames", {"OverviewPage": tournament_overview_page}),
        order_by="ScoreboardGames.DateTime_UTC",
        **query_kwargs,
    )

    return [transmute_game(game) for game in games]


def get_game_details(game: LolGame, add_page_id=False) -> LolGame:
    """Gets most game information available on Leaguepedia.

    Note: For detailed scoreboard statistics (KDA, damage, CS, etc.), use
    get_game_scoreboard(game_id) from scoreboard_players_parser instead.
    This separation allows for efficient queries when only basic game info is needed.

    Args:
        game: A LolGame with Leaguepedia IDs in its 'sources' dict.
        add_page_id: whether or not to link the player page ID to their object. Mostly for debugging.

    Returns:
        The LolGame with all information available on Leaguepedia.
    """
    try:
        assert game.sources.leaguepedia.gameId
    except AssertionError:
        raise ValueError(
            f"Leaguepedia GameId not present in the input object, joins cannot be performed to get details"
        )

    with ThreadPoolExecutor() as executor:
        picks_bans_future = executor.submit(_get_picks_bans, game)
        game_future = executor.submit(_add_game_players, game, add_page_id)

    game = game_future.result()
    game.picksBans = picks_bans_future.result()

    return game


def _get_picks_bans(game: LolGame) -> Optional[List[LolPickBan]]:
    """Returns the picks and bans for the game."""
    # Double join as required by Leaguepedia
    picks_bans = leaguepedia.query(
        tables="PicksAndBansS7, ScoreboardGames",
        join_on="PicksAndBansS7.GameId = ScoreboardGames.GameId",
        fields=", ".join(picks_bans_fields),
        where=QueryBuilder.build_where("ScoreboardGames", {"GameId": game.sources.leaguepedia.gameId}),
    )

    if not picks_bans:
        return None

    return transmute_picks_bans(picks_bans[0])


def _add_game_players(game: LolGame, add_page_id: bool) -> LolGame:
    """Joins on PlayersRedirect to get all players information."""

    players = leaguepedia.query(
        tables=f"ScoreboardGames, ScoreboardPlayers, PlayerRedirects, Players",
        join_on="ScoreboardGames.GameId = ScoreboardPlayers.GameId, "
        "ScoreboardPlayers.Link = PlayerRedirects.AllName, "
        "PlayerRedirects.OverviewPage = Players.OverviewPage",
        fields=", ".join(game_players_fields) + ", Players._pageID=pageId",
        where=QueryBuilder.build_where("ScoreboardGames", {"GameId": game.sources.leaguepedia.gameId}),
    )

    return add_players(game, players, add_page_id=add_page_id)
