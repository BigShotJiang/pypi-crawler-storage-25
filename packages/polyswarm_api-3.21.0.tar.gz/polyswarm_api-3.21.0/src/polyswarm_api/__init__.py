# https://www.python.org/dev/peps/pep-0008/#module-level-dunder-names
__version__ = '3.21.0'
__release_url__ = 'https://api.github.com/repos/polyswarm/polyswarm-api/releases/latest'

from . import api
from . import exceptions

try:
    from .aio import PolySwarmAsyncAPI
except ImportError:
    pass  # httpx not installed; install polyswarm_api[async] to enable
