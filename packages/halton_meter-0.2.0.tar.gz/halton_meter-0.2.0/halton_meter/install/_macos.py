"""OS-level supervisor install/uninstall for the halton-meter daemon.

Layer 1 of the three-layer connectivity-on-crash fix (see ADR
``decisions.md`` 2026-04-29 — "Three-layer connectivity-on-crash fix").

The in-process atexit/signal handlers in :mod:`halton_meter.system_proxy`
catch clean exits and SIGINT/SIGTERM but cannot intercept SIGKILL,
segfault, OOM, or power loss. This module installs an OS-level
supervisor (launchd KeepAlive on macOS, systemd ``Restart=always`` on
Linux) so the daemon revives within ~1s of any exit. ``uninstall`` also
unconditionally resets the macOS system proxy — that is the load-bearing
recovery line: even if everything else fails, ``halton-meter uninstall``
restores the user's network connectivity.

Pure-function-first: the file-content generators (``build_macos_plist``,
``build_systemd_unit``) are stdlib-only and trivially testable; the
side-effecting orchestrators (``install``, ``uninstall``) call out to
``launchctl``/``systemctl``/``networksetup``.
"""

from __future__ import annotations

import datetime
import os
import plistlib
import shutil
import subprocess
import sys
from pathlib import Path

import structlog

from halton_meter import system_proxy

_log = structlog.get_logger()

_LABEL = "com.haltonlabs.meter"
_MACOS_PLIST_NAME = f"{_LABEL}.plist"
_WATCHDOG_LABEL = "com.haltonlabs.meter.watchdog"
_WATCHDOG_PLIST_NAME = f"{_WATCHDOG_LABEL}.plist"
_EDGE_LABEL = "com.haltonlabs.meter.edge"
_EDGE_PLIST_NAME = f"{_EDGE_LABEL}.plist"
_USERENV_LABEL = "com.haltonlabs.meter.userenv"
_USERENV_PLIST_NAME = f"{_USERENV_LABEL}.plist"
_LINUX_UNIT_NAME = "halton-meter.service"
_LINUX_WATCHDOG_UNIT_NAME = "halton-meter-watchdog.service"
# v0.1.23 Blocker 1: edge systemd unit mirrors the macOS edge launchd
# plist — port-keeping sidecar that owns the user-facing port across
# daemon transitions.
_LINUX_EDGE_UNIT_NAME = "halton-meter-edge.service"
_PROXY_MANAGED_SENTINEL_NAME = "proxy-managed"

# macOS Transparency, Consent and Control (TCC) blocks LaunchAgent-spawned
# processes from reading files under these home-relative directories unless
# the user has explicitly granted Full Disk Access to the interpreter. A
# plist whose ProgramArguments points into one of these will write+load
# successfully but every spawn dies with PermissionError on pyvenv.cfg /
# site-packages, leaving the agent looping in launchd's retry-then-throttle
# pit and the user with no signal anything is wrong.
_TCC_PROTECTED_DIRS = ("Documents", "Desktop", "Downloads")


# --------------------------------------------------------------------------- #
# Pure builders (no side effects)                                              #
# --------------------------------------------------------------------------- #


def build_macos_plist(halton_path: Path, log_dir: Path, working_dir: Path) -> bytes:
    """Return the bytes of a launchd plist file for the daemon.

    Uses :mod:`plistlib` from the stdlib; no string templating. The
    returned bytes are XML plist 1.0 ready to be written to
    ``~/Library/LaunchAgents/com.haltonlabs.meter.plist``.

    v0.1.21.1 (2026-05-05): NO ``KeepAlive`` key at all. From
    ``man launchd.plist`` under ``KeepAlive`` -> ``SuccessfulExit``:
    "This key implies that 'RunAtLoad' is set to true, since the job
    needs to run at least once before we can get an exit status." Our
    previous shape (``KeepAlive={"SuccessfulExit": False}`` with an
    explicit ``RunAtLoad=False``) was therefore a no-op for the v0.1.21
    manual-start architecture: launchd silently promoted ``RunAtLoad``
    back to true and the daemon kept loading at every login. Confirmed
    by Vikrant's reboot soak on 2026-05-05. Drop the key entirely.
    Trade-off: we lose in-session auto-restart for the daemon. If it
    crashes mid-day the user runs ``halton-meter start`` again.
    Fail-open is preserved: the watchdog detects unhealthy ``/health``
    and disables the system proxy; the edge keeps shuttling traffic
    direct to upstream during the gap. See ``decisions.md`` 2026-05-05
    -- "v0.1.21.1 KeepAlive removal".

    ``ThrottleInterval=1`` keeps launchd from hammering the binary if
    it crashes immediately on a manual ``launchctl bootstrap``.
    """
    payload: dict[str, object] = {
        "Label": _LABEL,
        "ProgramArguments": [str(halton_path), "daemon"],
        # v0.1.21 (2026-05-05): manual-start architecture. ``RunAtLoad``
        # used to be ``True`` so the daemon came up at every login —
        # but the cold-boot zombie (process spawns, never binds :8090
        # / :8765) survived v0.1.20.1's signal-handler / squatter /
        # sentinel fixes across two reboot soaks. Decision: stop
        # auto-loading the daemon at login. The user runs
        # ``halton-meter start`` when they sit down to work. Edge +
        # userenv plists STAY ``RunAtLoad=True`` so the fail-open
        # pass-through path (HTTPS_PROXY -> edge -> upstream) is
        # always alive — zero workflow disruption is preserved.
        #
        # v0.1.21.1 (2026-05-05): also DROP ``KeepAlive`` entirely.
        # ``KeepAlive={"SuccessfulExit": False}`` IMPLIES
        # ``RunAtLoad=True`` per ``man launchd.plist`` — silently
        # overriding our explicit False above. With no KeepAlive, the
        # daemon loads only on ``halton-meter start`` (launchctl
        # bootstrap) and stays dead after any exit until the user
        # starts it again. See this function's docstring + decisions.md.
        "RunAtLoad": False,
        "ThrottleInterval": 1,
        # Q1 layer-4 (2B.10): give the in-process SIGTERM handler in
        # system_proxy.install_proxy_cleanup up to 30 seconds to finish
        # the networksetup loop before launchd escalates to SIGKILL. The
        # default is 5s, which is sometimes not enough on a busy system.
        "ExitTimeOut": 30,
        "StandardOutPath": str(log_dir / "daemon.out.log"),
        "StandardErrorPath": str(log_dir / "daemon.err.log"),
        "WorkingDirectory": str(working_dir),
        "EnvironmentVariables": {
            "PATH": "/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        },
        "ProcessType": "Background",
        # P0.1 (v0.1.16, Bug 4): macOS default per-process FD soft limit
        # is 256, which evaporated the moment system-proxy mode routed
        # every app on the machine through the daemon (`[Errno 24] Too
        # many open files`). 10,240 matches the limit other long-running
        # proxies (kubectl, terraform) request and is well below the
        # kernel ceiling. Soft + hard set identically so child sockets
        # never hit a soft cap that's lower than the hard cap.
        "SoftResourceLimits": {"NumberOfFiles": 10240},
        "HardResourceLimits": {"NumberOfFiles": 10240},
    }
    return plistlib.dumps(payload)


def build_systemd_unit(halton_path: Path, log_dir: Path) -> str:
    """Return the contents of a systemd user unit for the daemon."""
    # Q1 layer-4 (2B.10): ExecStop runs on `systemctl --user stop` AND on
    # system shutdown. Belt-and-braces with the in-process signal handler
    # — gives us a separate process to do the reset even if the main
    # daemon is hung and gets SIGKILLed.
    return f"""[Unit]
Description=Halton Meter daemon
After=network.target

[Service]
Type=simple
ExecStart={halton_path} daemon
ExecStop={halton_path} reset-proxy
Restart=always
RestartSec=1
StandardOutput=append:{log_dir}/daemon.out.log
StandardError=append:{log_dir}/daemon.err.log

[Install]
WantedBy=default.target
"""


def build_watchdog_plist(halton_path: Path, log_dir: Path, working_dir: Path) -> bytes:
    """Return the bytes of a launchd plist for the watchdog companion process.

    Same shape as :func:`build_macos_plist` but pointed at ``halton-meter
    watchdog``.

    v0.1.21.1 (2026-05-05): NO ``KeepAlive`` key. Same reasoning as
    :func:`build_macos_plist`: any ``KeepAlive`` flavour (bool True,
    or ``{"SuccessfulExit": False}``) implies ``RunAtLoad=True`` per
    ``man launchd.plist``, which silently overrode our explicit
    ``RunAtLoad=False`` and kept loading the watchdog at every login
    in v0.1.21. Drop it. The watchdog now starts only when
    ``halton-meter start`` calls ``launchctl bootstrap`` on this
    plist, and stays down after any exit until the user starts again.

    Trade-off (deliberate): the v0.1.6 layer-2 design relied on
    ``KeepAlive=True`` to revive the watchdog whenever ``run_watchdog``
    exits clean on the "no interfaces snapshot" path. Without KeepAlive
    that revival no longer happens: a single clean exit takes the
    layer-2 monitor down for the rest of the session. Acceptable for
    v0.1.21.1 because (a) manual-start means the user is present when
    the daemon starts, and (b) the empty-snapshot exit only fires on
    cold boot before networksetup has populated interfaces — not a
    path the manual-start flow hits. We accept the gap to fix the
    cold-boot auto-load regression, which is the bigger correctness
    bug. See ``decisions.md`` 2026-05-05 -- "v0.1.21.1 KeepAlive
    removal".
    """
    payload: dict[str, object] = {
        "Label": _WATCHDOG_LABEL,
        "ProgramArguments": [str(halton_path), "watchdog"],
        # v0.1.21 (2026-05-05): manual-start architecture. Watchdog
        # follows the daemon's lifecycle — there is no point watching
        # a daemon the user has not asked to start. ``halton-meter
        # start`` loads both plists; reboot leaves both unloaded.
        #
        # v0.1.21.1: also DROP ``KeepAlive`` entirely (was ``True``).
        # Any KeepAlive value implies ``RunAtLoad=True`` per
        # ``man launchd.plist`` — that override silently kept the
        # watchdog auto-loading at login despite our False above. See
        # docstring + decisions.md for the trade-off rationale (we
        # lose layer-2 revival on the empty-snapshot exit path).
        "RunAtLoad": False,
        "ThrottleInterval": 1,
        # Q1 layer-4 (2B.10): match the daemon plist's grace window so
        # the watchdog has time to finish its own cleanup on shutdown.
        "ExitTimeOut": 30,
        "StandardOutPath": str(log_dir / "watchdog.out.log"),
        "StandardErrorPath": str(log_dir / "watchdog.err.log"),
        "WorkingDirectory": str(working_dir),
        "EnvironmentVariables": {
            "PATH": "/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        },
        "ProcessType": "Background",
        # P0.1 (v0.1.16, Bug 4): bumped for consistency with the daemon
        # plist. The watchdog itself is a low-FD process, but matching
        # the daemon limit means a future watchdog feature that opens
        # more sockets won't surprise us with a 256-FD cliff.
        "SoftResourceLimits": {"NumberOfFiles": 10240},
        "HardResourceLimits": {"NumberOfFiles": 10240},
    }
    return plistlib.dumps(payload)


def build_macos_plist_edge(
    halton_path: Path, log_dir: Path, working_dir: Path
) -> bytes:
    """Return the bytes of a launchd plist file for the edge proxy (2C.2).

    The edge proxy owns the user-facing port (``HTTPS_PROXY``). Apps
    inherit that port at spawn time and cannot have it mutated mid-
    process — so the edge MUST keep the port bound through every
    daemon transition (stop, crash, upgrade). ``KeepAlive=True``
    (unconditional, NOT ``{SuccessfulExit: False}``) means launchd
    respawns the edge on any exit including clean ones; the only way
    it stays down is ``launchctl unload -w`` from uninstall.

    No SQLite to flush, no in-process system-proxy cleanup — so
    ``ExitTimeOut=5`` is plenty (vs the daemon's 30s).
    """
    payload: dict[str, object] = {
        "Label": _EDGE_LABEL,
        "ProgramArguments": [str(halton_path), "edge"],
        "RunAtLoad": True,
        # Unconditional respawn. The edge is the load-bearing port-keeper;
        # any exit at all should be replaced immediately. Clean exits
        # only happen on uninstall via `launchctl unload -w`.
        "KeepAlive": True,
        "ThrottleInterval": 1,
        # No SQLite flush, no system-proxy reset — the edge is a pure
        # byte-shuttle. 5s is more than enough.
        "ExitTimeOut": 5,
        "StandardOutPath": str(log_dir / "edge.out.log"),
        "StandardErrorPath": str(log_dir / "edge.err.log"),
        "WorkingDirectory": str(working_dir),
        "EnvironmentVariables": {
            "PATH": "/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        },
        "ProcessType": "Background",
        # P0.1 (v0.1.16, Bug 4): the edge owns the user-facing port and
        # holds one socket per in-flight CONNECT — under system-proxy
        # mode that's every TLS-speaking app on the machine. The 256
        # default produced `[Errno 24] Too many open files` immediately
        # on Vikrant's daily-driver. 10,240 gives us roughly two orders
        # of magnitude headroom while still being inside macOS's
        # per-process kernel ceiling.
        "SoftResourceLimits": {"NumberOfFiles": 10240},
        "HardResourceLimits": {"NumberOfFiles": 10240},
    }
    return plistlib.dumps(payload)


def build_macos_plist_userenv(
    halton_path: Path, log_dir: Path, working_dir: Path
) -> bytes:
    """Return the bytes of a launchd plist that re-applies user-domain env at login.

    v0.1.19 Task 0.1: ``launchctl setenv`` (the mechanism ``init --apps``
    uses to feed ``HTTPS_PROXY`` into GUI apps spawned from the Dock) does
    NOT survive logout/reboot — the launchd user-domain env is wiped on
    every session start. Without intervention, Windsurf / Cursor / VS Code
    launched from the Dock after reboot bypass the proxy entirely.

    This plist is a one-shot login agent: ``RunAtLoad=True`` plus
    ``KeepAlive=False`` (note: NOT ``{SuccessfulExit: False}`` — we want
    a literal one-shot, not "respawn on crash"). It runs the hidden
    ``halton-meter _apply-user-env`` subcommand at every login, which
    re-applies :func:`system_proxy.setenv_user_domain` with the canonical
    proxy + cert env vars. If the apply fails the agent does NOT respawn-
    loop — ``halton-meter doctor`` is the surfacing channel for that
    (Task 0.3).

    No SQLite, no port-keeping, no socket inheritance — so no
    ``ResourceLimits`` and a short ``ExitTimeOut=5`` matches the edge
    plist's "pure-shuttle" shape.
    """
    payload: dict[str, object] = {
        "Label": _USERENV_LABEL,
        "ProgramArguments": [str(halton_path), "_apply-user-env"],
        "RunAtLoad": True,
        # One-shot at login. NOT {SuccessfulExit: False}: a per-key
        # launchctl setenv failure is logged and surfaced via doctor;
        # we never want this agent in a respawn loop.
        "KeepAlive": False,
        "ThrottleInterval": 1,
        # Short timeout — there's nothing to flush.
        "ExitTimeOut": 5,
        "StandardOutPath": str(log_dir / "userenv.out.log"),
        "StandardErrorPath": str(log_dir / "userenv.err.log"),
        "WorkingDirectory": str(working_dir),
        "EnvironmentVariables": {
            "PATH": "/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        },
        "ProcessType": "Background",
    }
    return plistlib.dumps(payload)


def build_systemd_edge_unit(halton_path: Path, log_dir: Path) -> str:
    """Return the contents of a systemd user unit for the edge proxy.

    v0.1.23 Blocker 1: the edge owns the user-facing port (the value of
    ``HTTPS_PROXY`` that apps inherit at spawn time). It must keep the
    port bound through every daemon transition (stop, crash, upgrade) —
    so ``Restart=always`` + ``RestartSec=1`` mirrors the launchd
    ``KeepAlive=True`` semantics on macOS.

    ``TimeoutStopSec=10`` + ``KillSignal=SIGTERM`` give the edge a
    graceful window to drain in-flight CONNECTs before systemd escalates
    to SIGKILL. ``LimitNOFILE=10240`` mirrors the launchd plist's
    SoftResourceLimits.NumberOfFiles — under system-proxy mode the edge
    holds one socket per in-flight CONNECT and the 1024 default would
    cap out immediately on a busy daily-driver. The edge is a pure
    byte-shuttle (no SQLite, no system-proxy reset on exit), so no
    ExecStop is wired up — the daemon unit's ExecStop handles
    connectivity restoration.
    """
    return f"""[Unit]
Description=Halton Meter edge proxy
After=network.target

[Service]
Type=simple
ExecStart={halton_path} edge
Restart=always
RestartSec=1
TimeoutStopSec=10
KillSignal=SIGTERM
LimitNOFILE=10240
StandardOutput=append:{log_dir}/edge.out.log
StandardError=append:{log_dir}/edge.err.log

[Install]
WantedBy=default.target
"""


def build_systemd_watchdog_unit(halton_path: Path, log_dir: Path) -> str:
    """Return the contents of a systemd user unit for the watchdog."""
    # Q1 layer-4 (2B.10): ExecStop on the watchdog too — belt-and-braces
    # with the daemon unit. Either ExecStop reaching reset-proxy is enough
    # to leave the user's connectivity in a good state on shutdown.
    return f"""[Unit]
Description=Halton Meter watchdog
After=network.target

[Service]
Type=simple
ExecStart={halton_path} watchdog
ExecStop={halton_path} reset-proxy
Restart=always
RestartSec=1
StandardOutput=append:{log_dir}/watchdog.out.log
StandardError=append:{log_dir}/watchdog.err.log

[Install]
WantedBy=default.target
"""


# --------------------------------------------------------------------------- #
# Helpers                                                                      #
# --------------------------------------------------------------------------- #


def _resolve_halton_path() -> Path | None:
    """Locate the ``halton-meter`` executable for the supervisor entry."""
    which = shutil.which("halton-meter")
    if which:
        return Path(which)
    argv0 = sys.argv[0] if sys.argv else ""
    if argv0:
        candidate = Path(argv0).resolve()
        # ``-c`` invocations and pytest leave argv[0] pointing at things
        # that are not the halton-meter binary; require it to exist as
        # a file before accepting it.
        if candidate.is_file():
            return candidate
    return None


# v0.1.20.dev2: ``halton-meter init`` wraps the install hot path in a
# Rich progress UI. The legacy ``[halton-meter] ...`` lines (plist
# unchanged / writing / launchctl unload+load / final "installed" line)
# are diagnostic noise during the normal happy path — they're load-bearing
# only when something goes wrong. ``set_quiet(True)`` suppresses them on
# the TTY path (init's progress task descriptions cover the user-facing
# story); ``set_quiet(False)`` restores the legacy behaviour for callers
# that invoke ``install.install()`` directly (e.g. ``halton-meter
# install`` CLI, tests, repair flows).
_QUIET: bool = False

# v0.1.22.16: install-event capture for the branded display layer. When
# ``_CAPTURE_BUFFER`` is not None, every ``_print`` call appends the raw
# message (without the ``[halton-meter]`` prefix) to it; the branded
# display in ``init.py`` / CLI ``uninstall`` consumes the buffer to render
# the editorial section layout. Independent of ``_QUIET`` — capture and
# stderr emission are orthogonal so direct callers (tests, repair flows)
# keep seeing the legacy stderr line stream regardless of capture state.
_CAPTURE_BUFFER: list[str] | None = None


def set_quiet(value: bool) -> None:
    """Toggle suppression of the ``[halton-meter] ...`` diagnostic prints."""
    global _QUIET
    _QUIET = value


def start_capture() -> list[str]:
    """Begin capturing ``_print`` events into an in-memory buffer.

    Returns the buffer so the caller can inspect it after
    :func:`stop_capture`. Safe to call when capture is already active —
    the existing buffer is replaced.
    """
    global _CAPTURE_BUFFER
    _CAPTURE_BUFFER = []
    return _CAPTURE_BUFFER


def stop_capture() -> list[str]:
    """End capture and return the collected events.

    Returns an empty list if capture was not active.
    """
    global _CAPTURE_BUFFER
    buf = _CAPTURE_BUFFER or []
    _CAPTURE_BUFFER = None
    return buf


def _print(msg: str) -> None:
    # v0.1.22.16: route every install-event through structlog at INFO so
    # forensic debugging survives the visual-layer collapse. Capture into
    # the branded-display buffer when active.
    try:
        _log.info("install.event", message=msg)
    except Exception:
        pass
    if _CAPTURE_BUFFER is not None:
        _CAPTURE_BUFFER.append(msg)
    if _QUIET:
        return
    print(f"[halton-meter] {msg}", file=sys.stderr, flush=True)


# v0.1.21.5: persist launchctl install errors to a dedicated post-mortem
# log so the init wrapper panel can surface the actual stderr inline.
# The wrapper's ``supervisor install exited with code N`` panel used to
# advise "See messages above." but the wrapping subprocess capture
# sometimes obscured the stderr lines, leaving the user with no way to
# diagnose. Append-only, ISO-8601 timestamped, last-N-lines readable by
# ``init.py``.
_INSTALL_ERR_LOG = Path.home() / ".halton-meter" / "install.err.log"


def _record_install_error(
    label: str,
    kind: str,
    rc: int,
    err: str,
    plist: Path | None = None,
) -> None:
    """Append a structured failure entry to ``~/.halton-meter/install.err.log``.

    Best-effort — never raise. ``kind`` is e.g. ``"bootstrap"`` or
    ``"kickstart"``; ``rc`` is the launchctl exit code; ``err`` is the
    captured stderr.
    """
    try:
        _INSTALL_ERR_LOG.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.datetime.now(datetime.UTC).isoformat()
        with _INSTALL_ERR_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"{ts} launchctl {kind} failed for {label} (rc={rc})\n")
            fh.write(f"  stderr: {err or '<empty>'}\n")
            if plist is not None:
                fh.write(f"  plist:  {plist}\n")
    except OSError:
        # Diagnostics must never break the install path.
        pass


def _is_tcc_protected(path: Path) -> str | None:
    """Return the protected-dir name if ``path`` lies under it, else ``None``.

    macOS TCC blocks LaunchAgent-spawned processes from reading files in
    ``~/Documents``, ``~/Desktop``, ``~/Downloads`` (and a few others)
    unless the user has granted Full Disk Access. A plist whose
    ProgramArguments points into one of these will silently fail to spawn.
    """
    try:
        resolved = path.resolve()
    except OSError:
        return None
    home = Path.home().resolve()
    for protected in _TCC_PROTECTED_DIRS:
        candidate = home / protected
        try:
            resolved.relative_to(candidate)
            return protected
        except ValueError:
            continue
    return None


def _read_shebang_interpreter(binary: Path) -> str | None:
    """Best-effort: read the interpreter path from a script's shebang line."""
    try:
        with binary.open("rb") as fh:
            first = fh.readline(512)
    except OSError:
        return None
    if not first.startswith(b"#!"):
        return None
    try:
        decoded = first[2:].decode("utf-8", errors="replace").strip()
    except Exception:
        return None
    if not decoded:
        return None
    # Shebangs may include args (e.g. `/usr/bin/env python3`); take the
    # first whitespace-separated token, which is the interpreter path.
    return decoded.split()[0]


def _resolve_daemon_listener() -> tuple[str, int]:
    """Return ``(listen_host, edge_port)`` from config, with safe defaults.

    Used by uninstall's snapshot-restore self-guard: if the captured
    ``host:port`` matches the user-facing proxy listener, we DISABLE
    the service rather than restore it. Falls back to the documented
    v0.1.6 defaults ``127.0.0.1:8081`` if config can't be loaded —
    that's the value a fresh install would point the system proxy at,
    so the self-guard still fires for the common case.

    v0.1.6 (2C.2): the listener port is now ``edge_port`` (previously
    ``listen_port``); the variable name is kept for caller stability.
    """
    try:
        from halton_meter.config import load_config

        cfg = load_config()
        return cfg.daemon.listen_host, int(cfg.daemon.edge_port)
    except Exception:
        return "127.0.0.1", 8081


def _macos_paths() -> tuple[Path, Path, Path]:
    home = Path.home()
    plist_path = home / "Library" / "LaunchAgents" / _MACOS_PLIST_NAME
    halton_dir = home / ".halton-meter"
    return plist_path, halton_dir, halton_dir


def _macos_watchdog_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / _WATCHDOG_PLIST_NAME


def _macos_edge_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / _EDGE_PLIST_NAME


def _macos_userenv_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / _USERENV_PLIST_NAME


def _proxy_managed_sentinel_path() -> Path:
    return Path.home() / ".halton-meter" / _PROXY_MANAGED_SENTINEL_NAME


def _linux_unit_path() -> Path:
    return Path.home() / ".config" / "systemd" / "user" / _LINUX_UNIT_NAME


def _linux_watchdog_unit_path() -> Path:
    return Path.home() / ".config" / "systemd" / "user" / _LINUX_WATCHDOG_UNIT_NAME


def _linux_edge_unit_path() -> Path:
    return Path.home() / ".config" / "systemd" / "user" / _LINUX_EDGE_UNIT_NAME


# --------------------------------------------------------------------------- #
# Platform installers                                                          #
# --------------------------------------------------------------------------- #


def _install_macos() -> int:
    halton_path = _resolve_halton_path()
    if halton_path is None:
        _print(
            "error: could not locate halton-meter binary; install via "
            "'pipx install halton-meter' first"
        )
        return 1

    protected = _is_tcc_protected(halton_path)
    if protected is not None:
        _print(f"error: halton-meter binary at {halton_path}")
        _print(
            f"  lies under ~/{protected}, which macOS LaunchAgents cannot"
        )
        _print("  read by default (TCC sandbox). The daemon will fail to spawn.")
        _print("")
        _print("Fix: install via a tool that places the binary outside protected")
        _print("  directories. For example:")
        _print("    uv tool install --editable <repo>/daemon       # uv-native")
        _print("    pipx install --editable <repo>/daemon          # pipx")
        _print("  Both put halton-meter under ~/.local/bin/.")
        interpreter = _read_shebang_interpreter(halton_path)
        if interpreter:
            _print("")
            _print(f"Alternative: grant Full Disk Access to {interpreter} in")
            _print("  System Settings -> Privacy & Security -> Full Disk Access.")
            _print("  This is fragile across venv recreations; prefer the install")
            _print("  route above.")
        return 1

    plist_path, log_dir, working_dir = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()
    edge_plist_path = _macos_edge_plist_path()
    userenv_plist_path = _macos_userenv_plist_path()
    log_dir.mkdir(parents=True, exist_ok=True)
    plist_path.parent.mkdir(parents=True, exist_ok=True)

    plist_bytes = build_macos_plist(halton_path, log_dir, working_dir)
    # P0-2 idempotency: byte-compare existing plist; skip the write when the
    # content is identical. The launchctl unload/load cycle below is itself
    # idempotent, so we still register the agent — we just avoid touching the
    # file on disk (no mtime churn, no unnecessary fs operations).
    if plist_path.exists() and plist_path.read_bytes() == plist_bytes:
        _print(f"plist unchanged: {plist_path}")
    else:
        _print(f"writing {plist_path}")
        plist_path.write_bytes(plist_bytes)

    watchdog_bytes = build_watchdog_plist(halton_path, log_dir, working_dir)
    if watchdog_plist_path.exists() and watchdog_plist_path.read_bytes() == watchdog_bytes:
        _print(f"plist unchanged: {watchdog_plist_path}")
    else:
        _print(f"writing {watchdog_plist_path}")
        watchdog_plist_path.write_bytes(watchdog_bytes)

    edge_bytes = build_macos_plist_edge(halton_path, log_dir, working_dir)
    if edge_plist_path.exists() and edge_plist_path.read_bytes() == edge_bytes:
        _print(f"plist unchanged: {edge_plist_path}")
    else:
        _print(f"writing {edge_plist_path}")
        edge_plist_path.write_bytes(edge_bytes)

    # v0.1.19 Task 0.1: userenv login agent. Re-applies launchctl
    # user-domain env vars at every login so --apps/--full survives
    # reboot. Mode-agnostic install — _reconcile_to_mode sweeps it
    # back out in env-only mode.
    userenv_bytes = build_macos_plist_userenv(halton_path, log_dir, working_dir)
    if userenv_plist_path.exists() and userenv_plist_path.read_bytes() == userenv_bytes:
        _print(f"plist unchanged: {userenv_plist_path}")
    else:
        _print(f"writing {userenv_plist_path}")
        userenv_plist_path.write_bytes(userenv_bytes)

    # v0.1.21.3: bootout-then-bootstrap via ``_launchctl_reload``.
    # Bootstrap returns rc=5 EIO when the label is already in the
    # user-domain registry — common after a reboot, since user-domain
    # LaunchAgents are auto-registered at login. v0.1.21.2 tried to
    # detect this via stderr substring matching ("already" / "loaded")
    # but the actual macOS message is bare "Input/output error" with
    # neither token, so init false-failed with exit code 5. Always
    # clear-and-re-register: bootout is no-op-safe; if bootstrap then
    # returns non-zero, that's a real failure. ``kickstart -k`` forces
    # start regardless of ``RunAtLoad``. RunAtLoad=True plists (edge,
    # userenv) start on bootstrap alone — kickstart is restricted to
    # labels that need it.
    # v0.1.22: clear the graceful-shutdown sentinel before kickstart.
    # ``_uninstall_macos`` (and ``_stop_macos``) write the sentinel so the
    # daemon stays down across reboot when the user explicitly stopped
    # metering. ``init`` is a fresh start: the user's intent has flipped
    # back to "start metering". Without this clear, the rapid
    # ``uninstall && init --apps`` retry path falls inside the 30s
    # suppression window — the daemon spawns, sees the sentinel,
    # logs ``daemon.graceful_shutdown_active``, exits, and init's
    # self-test times out on /health. See ``decisions.md`` 2026-05-06 —
    # "v0.1.22 graceful-shutdown sentinel blocks rapid init/start retry".
    from halton_meter.graceful_shutdown import clear_graceful_shutdown_sentinel
    from halton_meter.lifecycle import _launchctl_kickstart, _launchctl_reload

    clear_graceful_shutdown_sentinel()

    needs_kickstart = {_LABEL, _WATCHDOG_LABEL}
    for label, path in (
        (_LABEL, plist_path),
        (_WATCHDOG_LABEL, watchdog_plist_path),
        (_EDGE_LABEL, edge_plist_path),
        (_USERENV_LABEL, userenv_plist_path),
    ):
        _print(f"launchctl bootout {label}; bootstrap gui/<uid> {path}")
        rc, err = _launchctl_reload(path, label)
        if rc != 0:
            _print(
                f"error: launchctl bootstrap failed for {label} "
                f"(exit {rc}): {err}"
            )
            _record_install_error(label, "bootstrap", rc, err, plist=path)
            return rc
        if label in needs_kickstart:
            _print(f"launchctl kickstart -k gui/<uid>/{label}")
            ks_rc, ks_err = _launchctl_kickstart(label, kill_existing=True)
            if ks_rc != 0:
                _print(
                    f"error: launchctl kickstart failed for {label} "
                    f"(exit {ks_rc}): {ks_err}"
                )
                _record_install_error(label, "kickstart", ks_rc, ks_err, plist=path)
                return ks_rc

    _print(
        "daemon + watchdog + edge + userenv installed; launchd will keep "
        "the supervisors running across crashes and re-apply user env at login"
    )
    return 0


def _uninstall_macos(*, graceful: bool = False) -> int:
    """Tear down the macOS launchd entries and restore the system proxy.

    ``graceful=True`` (v0.1.9 Gap 11): leave the running edge process
    alive in pure-passthrough mode. Mechanism: skip ``launchctl unload``
    on the edge label and remove the edge plist file from disk only.
    The in-memory launchd job stays referenced (so KeepAlive will still
    respawn the edge if it crashes during the grace window), but at next
    user-domain reload (logout / reboot) the plist is gone and the edge
    will not come back. Daemon + watchdog are torn down normally — once
    the daemon is gone the edge falls through to direct passthrough on
    every CONNECT and apps with HTTPS_PROXY=http://127.0.0.1:<edge_port>
    keep working transparently.

    ``graceful=False`` (default): full teardown — all three labels
    unloaded + plist files removed. Apps lose connectivity until they
    are restarted (the warning block at the end documents this).
    """
    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()
    edge_plist_path = _macos_edge_plist_path()
    userenv_plist_path = _macos_userenv_plist_path()
    sentinel_path = _proxy_managed_sentinel_path()

    # v0.1.3 P0-3 / v0.1.5 (2B.16): read install-mode sentinel so we know
    # which side effects need reversing. ``None`` means "older install /
    # unknown" — treat as full to be defensive (better to issue a no-op
    # unsetenv than leave stale env vars in launchd's user domain).
    # In apps mode the system proxy was never enabled but launchctl env
    # + shell-rc were — so apps and full both need the env-var sweep.
    from halton_meter.init import (
        MODE_APPS,
        MODE_FULL,
        detect_shell_rc,
        read_install_mode,
        remove_coverage_block_from_rc,
        remove_install_mode,
    )

    install_mode = read_install_mode()
    treat_as_env_writer = (install_mode is None) or (
        install_mode in (MODE_APPS, MODE_FULL)
    )

    # Step 0 (Layer 2): remove the managed-proxy sentinel BEFORE the
    # system-proxy reset. After uninstall the user is no longer in
    # managed mode; the next ``halton-meter daemon`` invocation must NOT
    # re-enable the system proxy. We catch any error here and continue —
    # the unconditional system-proxy reset below remains the load-bearing
    # recovery line.
    try:
        sentinel_path.unlink()
        _print(f"removed {sentinel_path}")
    except FileNotFoundError:
        pass
    except OSError as exc:
        _print(f"warning: could not remove {sentinel_path}: {exc}")

    # v0.1.20.1: apps-managed sentinel (parallel mode marker for
    # ``init --apps`` installs). Remove unconditionally — uninstall
    # exits both modes.
    from halton_meter.setup import APPS_MANAGED_SENTINEL as _APPS_MGMT
    try:
        _APPS_MGMT.unlink()
        _print(f"removed {_APPS_MGMT}")
    except FileNotFoundError:
        pass
    except OSError as exc:
        _print(f"warning: could not remove {_APPS_MGMT}: {exc}")

    # v0.1.3 P0-3 / v0.1.5 (2B.16): in --apps / --full mode (or unknown
    # / older install), unsetenv the launchd user-domain env vars and
    # remove the shell-rc block. env-only mode never wrote either.
    if treat_as_env_writer:
        from halton_meter.system_proxy import (
            GUI_LAUNCHCTL_ENV_KEYS,
            unsetenv_user_domain,
        )

        rcs = unsetenv_user_domain(GUI_LAUNCHCTL_ENV_KEYS)
        if rcs:
            _print(
                f"launchctl unsetenv: {', '.join(GUI_LAUNCHCTL_ENV_KEYS)}"
            )
        rc_path = detect_shell_rc()
        if rc_path is not None and remove_coverage_block_from_rc(rc_path):
            _print(f"removed halton-meter env block from {rc_path}")

    # Always remove the install-mode sentinel + runtime.toml as part of
    # uninstall. The runtime.toml is recomputed on next daemon startup
    # from a fresh probe; persisting it across uninstall would lock in a
    # port choice the user may not want any more.
    remove_install_mode()
    from halton_meter.port_alloc import (
        remove_edge_state_toml,
        remove_effective_ports,
        remove_runtime_toml,
    )

    remove_runtime_toml()
    # v0.1.7 Gap 0: edge sidecar tracks the running edge's chain target.
    # Clean it up so a stale file from a previous run doesn't mislead the
    # next install's doctor.
    remove_edge_state_toml()
    # v0.1.19.dev1: shared effective-ports source of truth. Stale state
    # across uninstall would publish a wrong HTTPS_PROXY at the next
    # login; remove it so the next daemon write is the only source.
    remove_effective_ports()

    # Steps 1+2 are best-effort. The system-proxy reset (step 3) MUST
    # run regardless; it's the load-bearing recovery line. Three plists
    # are unloaded + removed in a specific order:
    #   1. Daemon (com.haltonlabs.meter)
    #   2. Watchdog (com.haltonlabs.meter.watchdog)
    #   3. Edge (com.haltonlabs.meter.edge) — LAST.
    # The edge keeps the user-facing port bound through the daemon's
    # teardown so any in-flight connection from a still-running app
    # gets passthrough'd cleanly until the very last moment. Once the
    # edge unloads the port goes dead — apps with HTTPS_PROXY pointing
    # at it will fail until restarted; the warning block below makes
    # that explicit.
    # v0.1.9 Gap 11: in graceful mode, skip ``launchctl unload`` for the
    # edge label so the running edge process stays alive in pure-
    # passthrough mode through the grace window. We still remove the
    # edge plist file from disk — at next user-domain reload (logout /
    # reboot) the plist is gone and the edge will not come back. Daemon
    # + watchdog are torn down normally (graceful mode is about app
    # connectivity, not about leaving metering enabled — once the daemon
    # is gone the edge cannot chain anywhere and silently falls through
    # to direct passthrough on every CONNECT).
    edge_pid_pre_uninstall: int | None = None
    if graceful:
        try:
            from halton_meter.lifecycle import _launchctl_label_pid

            edge_pid_pre_uninstall = _launchctl_label_pid(_EDGE_LABEL)
        except Exception:
            edge_pid_pre_uninstall = None

    for label, path in (
        (_LABEL, plist_path),
        (_WATCHDOG_LABEL, watchdog_plist_path),
        (_EDGE_LABEL, edge_plist_path),
        # v0.1.19 Task 0.1: userenv login agent. Unloaded + removed
        # in both regular and graceful uninstall — graceful only
        # spares the edge (port-keeper); userenv has no
        # connectivity-keeping role.
        (_USERENV_LABEL, userenv_plist_path),
    ):
        skip_unload = graceful and label == _EDGE_LABEL
        if not skip_unload:
            try:
                _print(f"launchctl unload {path}")
                subprocess.run(
                    ["launchctl", "unload", str(path)],
                    capture_output=True,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                _print(f"warning: launchctl unload {label} raised: {exc}")
        else:
            _print(
                f"graceful: skipping launchctl unload for {label} "
                "(edge stays running)"
            )

        try:
            path.unlink()
            _print(f"removed {path}")
        except FileNotFoundError:
            pass
        except OSError as exc:
            _print(f"warning: could not remove {path}: {exc}")

    # 2B.11: prefer snapshot/restore over unconditional disable. If
    # ``~/.halton-meter/system_state.json`` exists from ``halton-meter
    # init`` we re-apply the captured pre-install state per service —
    # except where the captured ``host:port`` matches our own daemon
    # listener, in which case we DISABLE that service (self-guard against
    # re-pointing the user at a dead proxy). When no snapshot exists
    # (older installs / users who never ran ``init``), fall back to the
    # original unconditional disable loop — that is still the load-bearing
    # recovery line. Interfaces are enumerated dynamically via
    # ``networksetup -listallnetworkservices`` (see decisions.md
    # 2026-04-30 — "2B.7.2 enumerate macOS network services dynamically").
    our_host, our_port = _resolve_daemon_listener()
    restored = system_proxy.restore_system_proxy(our_host, our_port)
    if restored:
        _print("system proxy restored from snapshot")
    else:
        for iface in system_proxy._macos_interfaces():
            for variant in ("-setsecurewebproxystate", "-setwebproxystate"):
                try:
                    subprocess.run(
                        ["networksetup", variant, iface, "off"],
                        capture_output=True,
                        check=False,
                    )
                except (OSError, subprocess.SubprocessError):
                    pass
            _print(f"system proxy reset on {iface}")

    # 2C.2 v0.1.6 — final warning block. Once the edge plist is unloaded
    # the user-facing port goes dead. macOS does not allow mutating a
    # running process's environ, so any app that was started with
    # HTTPS_PROXY=http://127.0.0.1:<edge_port> still has that value in
    # its process environment and will fail every outbound HTTPS call
    # with ConnectionRefused until it is restarted. We cannot fix this
    # from the outside — the warning is the fix.
    if graceful:
        pid_str = (
            f"PID {edge_pid_pre_uninstall}"
            if edge_pid_pre_uninstall is not None
            else "PID unknown"
        )
        _print(
            f"graceful uninstall: edge proxy ({pid_str}) left running in "
            "pure-passthrough mode."
        )
        _print(
            f"  Apps with HTTPS_PROXY=http://{our_host}:{our_port} baked "
            "into their environment will keep working transparently."
        )
        _print(
            "  At next reboot the edge will NOT restart — relaunch any "
            "apps that need direct connectivity afterwards."
        )
        _print(
            "  To kill the edge sooner: `pkill -f 'halton-meter edge'`."
        )
    else:
        _print("removed edge proxy")
        _print(
            f"WARNING: any application currently running with "
            f"HTTPS_PROXY=http://{our_host}:{our_port} in its environment"
        )
        _print(
            "  will lose connectivity until restarted. Quit and reopen any "
            "IDE / terminal / browser"
        )
        _print("  that was using halton-meter before this uninstall.")
    return 0


def _install_linux() -> int:
    halton_path = _resolve_halton_path()
    if halton_path is None:
        _print(
            "error: could not locate halton-meter binary; install via "
            "'pipx install halton-meter' first"
        )
        return 1

    unit_path = _linux_unit_path()
    watchdog_unit_path = _linux_watchdog_unit_path()
    edge_unit_path = _linux_edge_unit_path()
    log_dir = Path.home() / ".halton-meter"
    log_dir.mkdir(parents=True, exist_ok=True)
    unit_path.parent.mkdir(parents=True, exist_ok=True)

    unit_text = build_systemd_unit(halton_path, log_dir)
    # P0-2 idempotency: byte-compare existing unit file; skip the write when
    # the content matches. systemctl daemon-reload below is itself idempotent.
    if unit_path.exists() and unit_path.read_text() == unit_text:
        _print(f"unit unchanged: {unit_path}")
    else:
        _print(f"writing {unit_path}")
        unit_path.write_text(unit_text)

    # v0.1.23 Blocker 1: edge systemd unit (port-keeper sidecar). Mirrors
    # the macOS launchd edge plist — KeepAlive semantics via
    # Restart=always + RestartSec=1.
    edge_unit_text = build_systemd_edge_unit(halton_path, log_dir)
    if edge_unit_path.exists() and edge_unit_path.read_text() == edge_unit_text:
        _print(f"unit unchanged: {edge_unit_path}")
    else:
        _print(f"writing {edge_unit_path}")
        edge_unit_path.write_text(edge_unit_text)

    # v0.1.23 Blocker 2: do NOT install the watchdog unit on Linux. The
    # watchdog is a macOS-`networksetup` poller with no Linux job; it exits
    # 0 every tick, systemd Restart=always triggers, StartLimitBurst hits,
    # and the unit enters permanent failed state ~7s after install. Skip
    # the write entirely. If a stale unit from an older version is on disk,
    # remove it so the user's `systemctl --user list-unit-files` is clean.
    if watchdog_unit_path.exists():
        try:
            watchdog_unit_path.unlink()
            _print(f"removed stale {watchdog_unit_path}")
        except OSError as exc:
            _print(f"warning: could not remove stale {watchdog_unit_path}: {exc}")

    _print("systemctl --user daemon-reload")
    reload = subprocess.run(
        ["systemctl", "--user", "daemon-reload"],
        capture_output=True,
        text=True,
        check=False,
    )
    if reload.returncode != 0:
        _print(
            "user systemd unavailable; manual install: run "
            "'systemctl --user enable --now halton-meter.service' "
            "once user systemd is available"
        )
        return 0

    # v0.1.23 Blocker 1: enable the daemon + edge units (no watchdog on
    # Linux per Blocker 2). Daemon first so the API socket is up before
    # the edge starts attempting to chain into it.
    for unit_name in (_LINUX_UNIT_NAME, _LINUX_EDGE_UNIT_NAME):
        _print(f"systemctl --user enable --now {unit_name}")
        enable = subprocess.run(
            ["systemctl", "--user", "enable", "--now", unit_name],
            capture_output=True,
            text=True,
            check=False,
        )
        if enable.returncode != 0:
            _print(
                f"user systemd unavailable; manual install: run "
                f"'systemctl --user enable --now {unit_name}' "
                "once user systemd is available"
            )
            return 0

    _print("daemon installed; systemd will keep it running across crashes")
    return 0


def _uninstall_linux(*, graceful: bool = False) -> int:
    """Tear down the Linux systemd user units (v0.1.10 Gap 17 adds graceful).

    ``graceful=False`` (default): full teardown — both units
    ``disable --now`` (SIGTERM the process + remove enable symlinks),
    unit files removed, daemon-reload.

    ``graceful=True`` (v0.1.10 Gap 17): the running daemon + watchdog
    processes are LEFT ALIVE so apps holding ``HTTPS_PROXY`` keep
    working AND keep being metered until the next reboot / logout. At
    next boot the units are gone (disabled + unit file removed), so
    nothing comes back. Mechanism:

    1. ``systemctl --user disable <unit>`` — *bare* disable, NOT
       ``disable --now``. Per ``systemctl(1)``: "This command does not
       implicitly stop the units that are being disabled. If this is
       desired, an additional --now switch should be added." Bare
       disable only removes the symlinks from ``*.wants/`` so the
       unit will not be brought up automatically next boot. The
       running unit's processes are untouched. (Verified against
       upstream systemd documentation; assertion in
       ``test_uninstall_linux_graceful_does_not_pass_now``.)
    2. Remove the unit files from ``~/.config/systemd/user/``.
    3. ``systemctl --user daemon-reload`` to drop the cached unit
       definitions.
    4. ``systemctl --user reset-failed <unit>`` to clear any auto-
       restart counters that would otherwise prevent the units from
       being re-installed cleanly later.

    Note that on Linux, the daemon owns the user-facing port directly
    (no edge process — the macOS edge unit has no Linux equivalent),
    so graceful on Linux gives MORE than macOS graceful: full metering
    continues until reboot, not just pure passthrough. Documented in
    the public ``uninstall`` docstring.
    """
    unit_path = _linux_unit_path()
    watchdog_unit_path = _linux_watchdog_unit_path()
    edge_unit_path = _linux_edge_unit_path()

    # v0.1.23 Blocker 4: sentinel + install-mode cleanup must run on
    # Linux too. Mirrors the macOS uninstall (proxy-managed +
    # apps-managed sentinels, install-mode state, runtime.toml +
    # edge-state.toml + effective-ports state). All best-effort; the
    # systemd teardown below remains the load-bearing recovery line.
    if not graceful:
        from halton_meter.setup import APPS_MANAGED_SENTINEL, PROXY_MANAGED_SENTINEL
        for sentinel in (PROXY_MANAGED_SENTINEL, APPS_MANAGED_SENTINEL):
            try:
                sentinel.unlink()
                _print(f"removed {sentinel}")
            except FileNotFoundError:
                pass
            except OSError as exc:
                _print(f"warning: could not remove {sentinel}: {exc}")

        try:
            from halton_meter.init import remove_install_mode
            from halton_meter.port_alloc import (
                remove_edge_state_toml,
                remove_effective_ports,
                remove_runtime_toml,
            )

            remove_install_mode()
            remove_runtime_toml()
            remove_edge_state_toml()
            remove_effective_ports()
        except Exception as exc:  # defensive: never block the systemd teardown
            _print(f"warning: install-mode cleanup raised: {exc}")

    if graceful:
        # v0.1.10 Gap 17: bare ``disable`` (no ``--now``) so the running
        # processes keep going. Watchdog first to mirror the destructive
        # ordering (stop the supervisor before the supervised), even
        # though here neither is actually stopped.
        for unit_name in (_LINUX_WATCHDOG_UNIT_NAME, _LINUX_EDGE_UNIT_NAME, _LINUX_UNIT_NAME):
            try:
                _print(f"systemctl --user disable {unit_name}  # graceful: no --now")
                subprocess.run(
                    ["systemctl", "--user", "disable", unit_name],
                    capture_output=True,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                _print(f"warning: systemctl disable {unit_name} raised: {exc}")
    else:
        for unit_name in (_LINUX_WATCHDOG_UNIT_NAME, _LINUX_EDGE_UNIT_NAME, _LINUX_UNIT_NAME):
            try:
                _print(f"systemctl --user disable --now {unit_name}")
                subprocess.run(
                    ["systemctl", "--user", "disable", "--now", unit_name],
                    capture_output=True,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                _print(f"warning: systemctl disable {unit_name} raised: {exc}")

    for path in (watchdog_unit_path, edge_unit_path, unit_path):
        try:
            path.unlink()
            _print(f"removed {path}")
        except FileNotFoundError:
            pass
        except OSError as exc:
            _print(f"warning: could not remove {path}: {exc}")

    # v0.1.23 Blocker 4: non-graceful uninstall must also run
    # daemon-reload + reset-failed so a subsequent ``halton-meter init``
    # starts from a clean systemd state. Previously only the graceful
    # branch did this; the regular path left tainted RestartCounter
    # state behind.
    if not graceful:
        try:
            _print("systemctl --user daemon-reload")
            subprocess.run(
                ["systemctl", "--user", "daemon-reload"],
                capture_output=True,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _print(f"warning: systemctl daemon-reload raised: {exc}")
        for unit_name in (_LINUX_WATCHDOG_UNIT_NAME, _LINUX_EDGE_UNIT_NAME, _LINUX_UNIT_NAME):
            try:
                _print(f"systemctl --user reset-failed {unit_name}")
                subprocess.run(
                    ["systemctl", "--user", "reset-failed", unit_name],
                    capture_output=True,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                _print(
                    f"warning: systemctl reset-failed {unit_name} raised: {exc}"
                )

        # v0.1.23 Blocker 4: strip the halton-meter block from the
        # certifi bundle. Cross-platform — `revert_certifi_patch` is in
        # `setup/_common.py`. Best-effort: never raises.
        try:
            from halton_meter.setup._common import revert_certifi_patch
            from halton_meter.setup._macos import _certifi_bundle_path
            bundle = _certifi_bundle_path()
            if revert_certifi_patch(bundle):
                _print(f"reverted certifi patch in {bundle}")
        except Exception as exc:
            _print(f"warning: could not revert certifi patch: {exc}")

    if graceful:
        # daemon-reload drops the in-memory cached unit definitions so
        # the now-removed files don't keep reappearing in `systemctl
        # status`. reset-failed clears any RestartCounter so a future
        # `halton-meter init` does not inherit a tainted state.
        try:
            _print("systemctl --user daemon-reload")
            subprocess.run(
                ["systemctl", "--user", "daemon-reload"],
                capture_output=True,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _print(f"warning: systemctl daemon-reload raised: {exc}")
        for unit_name in (_LINUX_WATCHDOG_UNIT_NAME, _LINUX_EDGE_UNIT_NAME, _LINUX_UNIT_NAME):
            try:
                _print(f"systemctl --user reset-failed {unit_name}")
                subprocess.run(
                    ["systemctl", "--user", "reset-failed", unit_name],
                    capture_output=True,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                _print(
                    f"warning: systemctl reset-failed {unit_name} raised: {exc}"
                )
        _print(
            "graceful uninstall: daemon + edge left running until next "
            "reboot. Metering continues until then; nothing comes back at boot."
        )

    return 0


def _windows_unsupported() -> int:
    _print(
        "halton-meter install/uninstall is not yet supported on Windows; "
        "tracked for Phase 2.x. The daemon still runs via 'halton-meter "
        "daemon' in a foreground terminal."
    )
    return 0


# --------------------------------------------------------------------------- #
# Public orchestrators                                                         #
# --------------------------------------------------------------------------- #


def install() -> int:
    """Install the OS-level supervisor entry for the daemon."""
    platform = sys.platform
    if platform == "darwin":
        return _install_macos()
    if platform.startswith("linux"):
        return _install_linux()
    if platform == "win32" or os.name == "nt":
        return _windows_unsupported()
    _print(f"unsupported platform: {platform}")
    return 1


def uninstall(
    *,
    purge: bool = False,
    include_logs: bool = False,
    graceful: bool = False,
) -> int:
    """Remove the OS-level supervisor entry and restore the system proxy.

    ``purge`` and ``include_logs`` control three-tier data removal (2B.11):

    * default (``purge=False``): supervisor + sentinel + system-proxy
      restore only; ``~/.halton-meter/`` is preserved (config + logs +
      runtime state).
    * ``purge=True``: also delete ``~/.halton-meter/`` EXCEPT
      ``db.sqlite`` and its WAL siblings (preserved as a unit). A legacy
      ``logs.db`` is preserved for users mid-migration.
    * ``purge=True, include_logs=True``: also delete the SQLite database
      (``db.sqlite`` + WAL siblings + legacy ``logs.db`` if present).

    ``graceful=True`` (v0.1.9 Gap 11 macOS, v0.1.10 Gap 17 Linux):

    * macOS: leave the running edge process alive in pure-passthrough
      mode through the next reboot so apps with
      ``HTTPS_PROXY=http://127.0.0.1:<edge_port>`` baked into their
      environment keep working. Daemon + watchdog are still torn down.
      No metering during the grace window.
    * Linux: leave the running daemon + watchdog processes alive
      through the next reboot. Because Linux has no edge unit (the
      daemon owns the user-facing port directly), graceful on Linux
      keeps METERING ACTIVE until reboot — stronger than macOS
      graceful. Mechanism is bare ``systemctl --user disable`` (no
      ``--now``), which removes the enable symlinks without stopping
      the running unit, plus a daemon-reload + reset-failed cleanup.

    Caller (the CLI) is responsible for any interactive confirmation
    prompts. This function does not prompt — it performs the operation
    indicated by its arguments.
    """
    from halton_meter.graceful_shutdown import write_graceful_shutdown_sentinel

    # v0.1.16 Issue #1: write graceful shutdown sentinel so the daemon doesn't
    # auto-restart on reboot (respecting the user's explicit uninstall request).
    write_graceful_shutdown_sentinel()

    platform = sys.platform
    if platform == "darwin":
        rc = _uninstall_macos(graceful=graceful)
    elif platform.startswith("linux"):
        rc = _uninstall_linux(graceful=graceful)
    elif platform == "win32" or os.name == "nt":
        return _windows_unsupported()
    else:
        _print(f"unsupported platform: {platform}")
        return 1

    if purge:
        _purge_data_dir(include_logs=include_logs)
    return rc


# --------------------------------------------------------------------------- #
# Three-tier purge (2B.11)                                                     #
# --------------------------------------------------------------------------- #

# Files that count as "the SQLite database" — preserved across the
# default ``--purge`` and removed only with ``--include-logs``. WAL +
# shared-memory siblings are part of the database; they MUST move/restore
# as a unit or SQLite reports corruption on next open.
_DB_FILENAMES = ("db.sqlite", "db.sqlite-wal", "db.sqlite-shm")
# Legacy filename from earlier development. A user mid-migration may have
# either ``db.sqlite`` or ``logs.db``; we preserve both defensively under
# ``--purge`` and remove both under ``--purge --include-logs``.
_LEGACY_DB_FILENAMES = ("logs.db", "logs.db-wal", "logs.db-shm")


def _data_dir() -> Path:
    return Path.home() / ".halton-meter"


def _purge_data_dir(*, include_logs: bool) -> None:
    """Execute the data-dir removal pass.

    With ``include_logs=False`` we move the SQLite db (canonical +
    legacy) aside, ``rm -rf`` the entire ``~/.halton-meter/``, then
    restore the db files. WAL siblings are moved/restored together — a
    half-moved set would corrupt the database on next open.

    With ``include_logs=True`` we ``rm -rf`` everything including the db.
    """
    import shutil as _shutil
    import tempfile

    data = _data_dir()
    if not data.exists():
        _print(f"{data} does not exist; nothing to purge")
        return

    if include_logs:
        try:
            _shutil.rmtree(data)
            _print(f"removed {data} (including database)")
        except OSError as exc:
            _print(f"warning: could not remove {data}: {exc}")
        return

    # Preserve the database. Move it aside as a unit, wipe, restore.
    preserved: list[tuple[Path, Path]] = []
    tmp_root = Path(tempfile.mkdtemp(prefix="halton-meter-purge-"))
    try:
        for name in (*_DB_FILENAMES, *_LEGACY_DB_FILENAMES):
            src = data / name
            if not src.exists():
                continue
            dst = tmp_root / name
            try:
                src.rename(dst)
                preserved.append((dst, src))
            except OSError as exc:
                _print(f"warning: could not move {src} aside: {exc}")
        try:
            _shutil.rmtree(data)
            _print(f"removed {data} (database preserved)")
        except OSError as exc:
            _print(f"warning: could not remove {data}: {exc}")
        # Recreate the data dir before restoring so the parent exists.
        data.mkdir(parents=True, exist_ok=True)
        for tmp_path, original in preserved:
            try:
                tmp_path.rename(original)
            except OSError as exc:
                _print(
                    f"warning: could not restore {original} from {tmp_path}: {exc}"
                )
    finally:
        # Clean the staging dir if anything is still in it.
        try:
            _shutil.rmtree(tmp_root, ignore_errors=True)
        except OSError:
            pass


def count_request_records(db_path: Path) -> tuple[int, int]:
    """Return ``(records, distinct_projects)`` for the SQLite db at ``db_path``.

    Opens read-only via ``file:...?mode=ro`` URI so an accidentally-running
    daemon isn't disturbed. Returns ``(0, 0)`` if the file does not exist
    or cannot be read (corrupt db, locked beyond timeout, schema missing).
    """
    if not db_path.exists():
        return (0, 0)
    import sqlite3

    uri = f"file:{db_path}?mode=ro"
    try:
        conn = sqlite3.connect(uri, uri=True, timeout=2.0)
    except sqlite3.Error:
        return (0, 0)
    try:
        cur = conn.cursor()
        try:
            cur.execute("SELECT COUNT(*) FROM requests")
            (records,) = cur.fetchone()
            cur.execute("SELECT COUNT(DISTINCT project_id) FROM requests")
            (projects,) = cur.fetchone()
        except sqlite3.Error:
            return (0, 0)
        return (int(records), int(projects))
    finally:
        conn.close()
