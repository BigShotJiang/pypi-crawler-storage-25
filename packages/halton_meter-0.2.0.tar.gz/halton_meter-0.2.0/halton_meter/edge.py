"""
Edge proxy (Phase 2C.2 / v0.1.6).

A tiny, stdlib-only asyncio TCP CONNECT proxy that owns the user-facing
proxy port (the one that lives in apps' ``HTTPS_PROXY`` env var). For
each incoming connection it decides — based on a cached daemon-health
signal — whether to chain the request through the metering daemon
(full TLS interception + cost attribution) or open a direct
passthrough tunnel to the upstream host (no decryption, no metering,
the user's request just works).

The point of this component is to decouple the apps' connectivity
contract from the metering daemon's lifecycle. Apps can stay running
across a daemon stop / crash / upgrade because the edge port stays
bound by this process the whole time.

See ``memory/plans/2026-04-30-edge-proxy-decoupling.md`` for the full
design. The cardinal rule (CLAUDE.md): observation must never break
the developer's workflow. This module is the architectural answer.

Stdlib only: ``asyncio`` + ``socket``. No mitmproxy, no httpx, no
Pydantic. The edge does not decrypt; it shuttles bytes.
"""

from __future__ import annotations

import asyncio
import os
import time
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

import structlog

from halton_meter.providers.hosts import host_should_intercept

log = structlog.get_logger(__name__)


# --------------------------------------------------------------------------- #
# Tunables                                                                    #
# --------------------------------------------------------------------------- #

# Health-cache TTLs. Asymmetric (see plan §4 / §12.3):
#   - Healthy state is the steady state. Re-probing every 500ms during
#     normal metering wastes CPU. 1000ms is short enough that a freshly
#     crashed daemon is detected quickly; long enough that sustained
#     traffic doesn't generate probe noise.
#   - Unhealthy state should converge fast on recovery. 200ms is
#     sub-perceptible (< two human reaction times).
#   - Chain-failure invalidation closes the stale-positive race: if the
#     cached "healthy" answer is stale because the daemon crashed
#     between probe and request, the chain TCP connect raises
#     ConnectionRefusedError; we invalidate and fall through to
#     passthrough on that very request — no TTL wait.
DEFAULT_HEALTHY_TTL_SECONDS = 1.0
DEFAULT_UNHEALTHY_TTL_SECONDS = 0.2
DEFAULT_PROBE_TIMEOUT_SECONDS = 0.1

# Per-request limits.
_MAX_REQUEST_LINE_BYTES = 8192  # 8 KiB
_MAX_HEADER_BYTES = 16 * 1024  # 16 KiB
_SHUTTLE_CHUNK_BYTES = 65536


# --------------------------------------------------------------------------- #
# Health cache                                                                #
# --------------------------------------------------------------------------- #


@dataclass
class DaemonHealthCache:
    """Asymmetric-TTL cache for the metering daemon's ``/health`` state.

    Probe a daemon's HTTP ``/health`` endpoint and cache the result.
    The cached value's freshness window depends on the value:

    * ``healthy_ttl_s`` — how long a True answer stays cached.
    * ``unhealthy_ttl_s`` — how long a False answer stays cached.
    * :meth:`invalidate` clears the cache immediately, used when a
      real chain attempt observes ``ConnectionRefusedError`` despite
      a cached "healthy" answer.

    The probe runs as an asyncio task; concurrent callers de-duplicate
    onto a single in-flight probe via ``_probe_lock``. Time is taken
    from a monotonic clock so wall-clock changes don't affect us.

    Port semantics (v0.1.7 Gap 5 — ship-blocker fix):

    * ``internal_port`` is the **chain target** — the mitmproxy CONNECT
      proxy port that ``EdgeProxy._try_chain`` opens TCP to for actual
      data flow. mitmproxy is a CONNECT proxy and does NOT serve
      ``/health``; probing it always returns nothing → cache stuck
      False → all CONNECTs fall through to passthrough → zero captures.
    * ``probe_port`` is the **HTTP API port** where FastAPI/uvicorn
      serves ``/health``. This is what the probe must hit. Defaults to
      8765 (matches ``DaemonConfig.api_port``).
    """

    internal_host: str = "127.0.0.1"
    internal_port: int = 8090
    probe_port: int = 8765
    healthy_ttl_s: float = DEFAULT_HEALTHY_TTL_SECONDS
    unhealthy_ttl_s: float = DEFAULT_UNHEALTHY_TTL_SECONDS
    probe_timeout_s: float = DEFAULT_PROBE_TIMEOUT_SECONDS
    # Test seam: pluggable monotonic clock.
    clock: callable = field(default=time.monotonic)
    _last_check_at: float = 0.0
    _last_result: bool = False
    _has_result: bool = False
    _probe_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def is_healthy(self) -> bool:
        """Return cached or freshly-probed daemon health.

        On a hot cache (``now - last_check_at < ttl``) the cached value
        is returned without a network call. On a cold cache the probe
        runs under ``_probe_lock`` so concurrent callers share one
        in-flight probe.
        """
        now = self.clock()
        if self._has_result:
            ttl = self.healthy_ttl_s if self._last_result else self.unhealthy_ttl_s
            if (now - self._last_check_at) < ttl:
                return self._last_result

        async with self._probe_lock:
            # Re-check inside the lock — another caller may have just
            # populated the cache while we were waiting.
            now = self.clock()
            if self._has_result:
                ttl = (
                    self.healthy_ttl_s
                    if self._last_result
                    else self.unhealthy_ttl_s
                )
                if (now - self._last_check_at) < ttl:
                    return self._last_result
            result = await self._probe()
            self._last_result = result
            self._last_check_at = self.clock()
            self._has_result = True
            return result

    def invalidate(self) -> None:
        """Forget the cached answer. Next ``is_healthy()`` re-probes."""
        self._has_result = False
        self._last_result = False
        self._last_check_at = 0.0

    async def _probe(self) -> bool:
        """Issue ``GET /health`` to the metering daemon.

        Returns True iff the daemon answers with 200 OK within
        ``probe_timeout_s``. Any error (timeout, ConnectionRefused,
        non-200, malformed response) returns False — fail-closed.

        Stdlib raw HTTP/1.0 over a single TCP connection. We don't need
        keep-alive, redirects, TLS, or chunked transfer; the daemon's
        ``/health`` endpoint returns a small JSON dict.
        """
        try:
            return await asyncio.wait_for(
                self._probe_inner(), timeout=self.probe_timeout_s
            )
        except TimeoutError:
            return False
        except Exception:  # pragma: no cover - defensive
            return False

    async def _probe_inner(self) -> bool:
        try:
            reader, writer = await asyncio.open_connection(
                self.internal_host, self.probe_port
            )
        except (ConnectionRefusedError, OSError):
            return False
        try:
            request = (
                b"GET /health HTTP/1.0\r\n"
                b"Host: " + self.internal_host.encode("ascii") + b"\r\n"
                b"Connection: close\r\n"
                b"\r\n"
            )
            writer.write(request)
            await writer.drain()
            # Read just enough to parse the status line.
            status_line = await reader.readline()
            if not status_line:
                return False
            try:
                parts = status_line.decode("ascii", errors="replace").split()
            except Exception:
                return False
            return len(parts) >= 2 and parts[1] == "200"
        except (ConnectionResetError, BrokenPipeError, OSError):
            return False
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            except RuntimeError:
                # See note on the up_writer.wait_closed sites below
                # (v0.1.19.dev1 Python 3.14 coroutine-reuse defence).
                pass


# --------------------------------------------------------------------------- #
# Request-line parsing                                                        #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class ParsedRequest:
    """Parsed HTTP-proxy request first line + raw header block.

    The raw header block (``raw_head``) is replayed verbatim when
    chaining or passthrough'ing — we never decode/re-encode the
    headers; that would be an unwarranted source of subtle bugs. Only
    the request-line method + target is parsed for routing.
    """

    method: str
    target: str  # e.g. "host:port" for CONNECT, "http://example.com/x" for HTTP
    version: str  # e.g. "HTTP/1.1"
    raw_head: bytes  # request line + headers + terminating CRLF CRLF


def parse_connect_target(target: str) -> tuple[str, int] | None:
    """Parse ``host:port`` from a CONNECT request target.

    Returns ``(host, port)`` or ``None`` if the target is malformed.
    Bracketed IPv6 literals are supported (``[::1]:443``).
    """
    target = target.strip()
    if not target:
        return None
    if target.startswith("["):
        end = target.find("]")
        if end == -1:
            return None
        host = target[1:end]
        rest = target[end + 1:]
        if not rest.startswith(":"):
            return None
        port_str = rest[1:]
    else:
        if ":" not in target:
            return None
        host, _, port_str = target.rpartition(":")
    if not host or not port_str:
        return None
    try:
        port = int(port_str)
    except ValueError:
        return None
    if not (0 < port < 65536):
        return None
    return host, port


async def read_request_head(reader: asyncio.StreamReader) -> ParsedRequest | None:
    """Read the request line + header block from ``reader``.

    Returns ``None`` if the request line is malformed, the head is
    larger than the limit, or the connection closes before the head
    completes. The raw bytes (request line + every header line +
    terminating CRLF CRLF) are returned in :attr:`ParsedRequest.raw_head`
    so the caller can replay them verbatim downstream.
    """
    try:
        request_line = await reader.readline()
    except (ConnectionResetError, BrokenPipeError, OSError):
        return None
    if not request_line or len(request_line) > _MAX_REQUEST_LINE_BYTES:
        return None
    try:
        decoded = request_line.decode("iso-8859-1").rstrip("\r\n")
    except Exception:
        return None
    parts = decoded.split(" ", 2)
    if len(parts) != 3:
        return None
    method, target, version = parts
    if not method or not target or not version.startswith("HTTP/"):
        return None

    # Read header block until blank line.
    head_bytes = bytearray(request_line)
    while True:
        if len(head_bytes) > _MAX_HEADER_BYTES:
            return None
        try:
            line = await reader.readline()
        except (ConnectionResetError, BrokenPipeError, OSError):
            return None
        if not line:
            # Connection closed before headers terminated.
            return None
        head_bytes.extend(line)
        if line in (b"\r\n", b"\n"):
            break
    return ParsedRequest(
        method=method,
        target=target,
        version=version,
        raw_head=bytes(head_bytes),
    )


# --------------------------------------------------------------------------- #
# Bidirectional byte shuttle                                                  #
# --------------------------------------------------------------------------- #


async def _shuttle_one_way(
    src: asyncio.StreamReader,
    dst: asyncio.StreamWriter,
) -> None:
    """Copy bytes from ``src`` to ``dst`` until EOF on ``src``.

    Closes the write side of ``dst`` on completion so the peer's
    counterpart shuttle observes EOF and unblocks. Errors are
    swallowed: this function exists inside a try/finally where the
    caller closes both streams unconditionally; logging an
    OSError per side per close is noise.
    """
    try:
        while True:
            chunk = await src.read(_SHUTTLE_CHUNK_BYTES)
            if not chunk:
                break
            dst.write(chunk)
            await dst.drain()
    except asyncio.CancelledError:
        # v0.1.22.18 Fix 1: legitimate shutdown signal from
        # ``EdgeProxy.cancel_inflight()`` (or any caller cancelling the
        # parent task). Treat as a clean exit so the runtime doesn't
        # surface a "Task was destroyed but it is pending" warning. The
        # outer ``finally`` still runs to write_eof on the destination.
        return
    except (ConnectionResetError, BrokenPipeError, OSError):
        return
    finally:
        try:
            if dst.can_write_eof():
                dst.write_eof()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass


async def shuttle_bidirectional(
    a_reader: asyncio.StreamReader,
    a_writer: asyncio.StreamWriter,
    b_reader: asyncio.StreamReader,
    b_writer: asyncio.StreamWriter,
) -> None:
    """Bidirectionally pipe bytes between two stream pairs.

    Returns when either direction finishes. The caller is responsible
    for closing both writers in their finally block.
    """
    a_to_b = asyncio.create_task(_shuttle_one_way(a_reader, b_writer))
    b_to_a = asyncio.create_task(_shuttle_one_way(b_reader, a_writer))
    try:
        await asyncio.gather(a_to_b, b_to_a)
    except (ConnectionResetError, BrokenPipeError, OSError):
        return


# --------------------------------------------------------------------------- #
# The edge proxy itself                                                       #
# --------------------------------------------------------------------------- #


@dataclass
class EdgeConfig:
    """Runtime config for the edge proxy.

    Decoupled from :class:`halton_meter.config.HaltonConfig` on purpose
    — the edge has a stripped-down concern surface. The
    :meth:`from_halton_config` classmethod (added in W2) reads
    ``cfg.daemon.edge_port`` / ``internal_port`` / ``edge_health_ttl_ms``
    so the production entry point and tests share one wiring.
    """

    edge_host: str = "127.0.0.1"
    edge_port: int = 8081
    internal_host: str = "127.0.0.1"
    internal_port: int = 8090
    # v0.1.7 Gap 5: HTTP API port where the daemon serves ``/health``.
    # The probe MUST hit this, not ``internal_port`` (mitmproxy CONNECT,
    # speaks no HTTP). Default matches ``DaemonConfig.api_port``.
    probe_port: int = 8765
    healthy_ttl_s: float = DEFAULT_HEALTHY_TTL_SECONDS
    unhealthy_ttl_s: float = DEFAULT_UNHEALTHY_TTL_SECONDS
    probe_timeout_s: float = DEFAULT_PROBE_TIMEOUT_SECONDS
    # v0.1.7 Gap 0: paths for the runtime.toml re-resolve and the edge
    # sidecar. Both default to None so existing tests (which construct
    # EdgeConfig with literal ports) keep their previous behaviour —
    # re-resolution and sidecar writes are no-ops unless a path is set.
    # Production wiring via ``from_halton_config`` populates both with
    # the canonical paths from port_alloc.
    runtime_path: Path | None = None
    state_path: Path | None = None
    # v0.1.21.2: shared effective-ports.json source-of-truth path. The
    # daemon writes this BEFORE its bind in cli._daemon, so the edge
    # can read the authoritative chain target from a single place
    # rather than waiting for runtime.toml to be rewritten by the next
    # port-fallback cycle. Falls back to ``runtime_path`` reading when
    # this file is missing (older installs / tests). Default None
    # mirrors the other path fields; ``from_halton_config`` populates
    # it from port_alloc.EFFECTIVE_PORTS_JSON_PATH.
    effective_ports_path: Path | None = None
    # 2026-05-01 fix: SQLite-backed attribution. The edge writes the
    # resolution into the shared ``~/.halton-meter/db.sqlite`` file
    # under ``BEGIN IMMEDIATE`` BEFORE forwarding the CONNECT, replacing
    # the v0.1.13 HTTP POST that was racing the daemon's ``request()``
    # hook in production. Defaults to None so unit tests that construct
    # EdgeConfig directly without a SQLite path don't crash; the
    # production entry point fills this from ``cfg.storage.db_path``
    # and calls ``attribution_store.set_db_path`` so the write goes
    # through the module singleton. Both fields can coexist during
    # the rolling-upgrade window: the field on EdgeConfig drives the
    # singleton wiring (see ``halton_meter.edge_main``), and tests
    # that construct EdgeConfig directly also call ``set_db_path``
    # to mirror the production wiring.
    attribution_db_path: Path | None = None

    @classmethod
    def from_halton_config(cls, cfg: object) -> EdgeConfig:
        """Map a :class:`halton_meter.config.HaltonConfig` into an
        :class:`EdgeConfig`. Imports lazily so this module stays
        stdlib-only at import time (the rest of the file deliberately
        does not depend on Pydantic or the rest of the daemon).
        """
        # ``cfg`` is typed as ``object`` to avoid a hard import-time
        # dependency on halton_meter.config; we duck-type it here.
        daemon = cfg.daemon  # type: ignore[attr-defined]
        ttl_ms = int(getattr(daemon, "edge_health_ttl_ms", 1000))
        # Lazy import keeps edge.py importable without port_alloc when
        # callers construct EdgeConfig directly.
        from halton_meter.port_alloc import (
            EDGE_STATE_TOML_PATH,
            EFFECTIVE_PORTS_JSON_PATH,
            RUNTIME_TOML_PATH,
        )
        api_port = int(getattr(daemon, "api_port", 8765))
        # 2026-05-01 fix: resolve the SQLite attribution path from the
        # daemon's storage config so the edge and daemon share state
        # via the same file. ``Path.expanduser`` is critical — the
        # config defaults to ``~/.halton-meter/db.sqlite``.
        storage = getattr(cfg, "storage", None)  # type: ignore[attr-defined]
        db_path: Path | None = None
        if storage is not None:
            raw_path = getattr(storage, "db_path", None)
            if raw_path:
                db_path = Path(str(raw_path)).expanduser()
        return cls(
            edge_host=str(daemon.listen_host),
            edge_port=int(daemon.edge_port),
            internal_host=str(daemon.listen_host),
            internal_port=int(daemon.internal_port),
            probe_port=api_port,
            healthy_ttl_s=max(ttl_ms, 0) / 1000.0,
            unhealthy_ttl_s=DEFAULT_UNHEALTHY_TTL_SECONDS,
            probe_timeout_s=DEFAULT_PROBE_TIMEOUT_SECONDS,
            runtime_path=RUNTIME_TOML_PATH,
            state_path=EDGE_STATE_TOML_PATH,
            effective_ports_path=EFFECTIVE_PORTS_JSON_PATH,
            attribution_db_path=db_path,
        )


class EdgeProxy:
    """Asyncio TCP CONNECT/HTTP-via-proxy server.

    Lifecycle:

    * :meth:`start` binds the listener and returns the bound port.
    * :meth:`serve_forever` runs the accept loop until cancelled.
    * :meth:`stop` cleanly drains and closes.

    Per-connection flow:

    1. Read the request head (request line + headers).
    2. If method == ``CONNECT``: parse host:port; decide chain vs
       passthrough; either connect to daemon and replay the head, or
       connect direct and answer ``200 Connection Established``;
       shuttle bytes both ways.
    3. Else (HTTP-via-proxy): open the same kind of upstream
       connection; replay the head verbatim; shuttle bytes both ways.
    4. On any error: log structured + close both sockets. Never raise
       out of the per-connection task.
    """

    def __init__(
        self,
        config: EdgeConfig,
        *,
        health_cache: DaemonHealthCache | None = None,
    ) -> None:
        self._config = config
        self._cache = health_cache or DaemonHealthCache(
            internal_host=config.internal_host,
            internal_port=config.internal_port,
            probe_port=config.probe_port,
            healthy_ttl_s=config.healthy_ttl_s,
            unhealthy_ttl_s=config.unhealthy_ttl_s,
            probe_timeout_s=config.probe_timeout_s,
        )
        self._server: asyncio.base_events.Server | None = None
        # v0.1.13: the actually-bound listener port. Differs from
        # ``self._config.edge_port`` only when the caller asked for
        # port=0 (kernel-assigned, common in tests). The attribution
        # path needs the bound value because psutil matches against
        # the client process's connection table where ``raddr.port``
        # is the real port the client connected to.
        self._bound_edge_port: int = int(config.edge_port)
        # v0.1.21.2: 1-second TTL cache on the authoritative port read.
        # Per-CONNECT FS reads are cheap but not free; capping at 1s
        # makes drift impossible (any change in effective-ports.json
        # is picked up within a second) without measurable overhead
        # under a hot-path with hundreds of CONNECTs/sec.
        self._auth_port_cached: int | None = None
        self._auth_port_cache_expires_at: float = 0.0
        # v0.1.22.18 Fix 1: track in-flight per-connection handler tasks
        # so the edge can cancel them cleanly on shutdown. Without this
        # the asyncio runtime warns "Task was destroyed but it is
        # pending" for every active CONNECT tunnel when SIGTERM lands
        # (legitimate ``halton-meter uninstall`` / shutdown path). The
        # set is mutated only from the event loop, so no lock needed.
        self._active_handler_tasks: set[asyncio.Task[None]] = set()

    @property
    def health_cache(self) -> DaemonHealthCache:
        return self._cache

    def _read_runtime_internal_port(self) -> int | None:
        """Read ``daemon.internal_port`` out of ``runtime.toml``.

        Stdlib-only on purpose — the edge module deliberately doesn't
        import port_alloc to keep the hot path free of Pydantic /
        config-layer imports. Returns ``None`` if no runtime path is
        configured, the file is missing, or the value is malformed.
        """
        path = self._config.runtime_path
        if path is None:
            return None
        try:
            if not path.exists():
                return None
            with path.open("rb") as fh:
                raw = tomllib.load(fh)
        except (tomllib.TOMLDecodeError, OSError):
            return None
        daemon_tbl = raw.get("daemon", {}) or {}
        val = daemon_tbl.get("internal_port")
        if isinstance(val, int) and 0 < val < 65536:
            return val
        return None

    def _read_effective_internal_port(self) -> int | None:
        """Read ``internal_port`` out of ``effective-ports.json``.

        v0.1.21.2: this file is the daemon's authoritative source of
        truth, written atomically BEFORE the daemon binds. Preferred
        over ``runtime.toml`` because the daemon writes both files but
        only effective-ports.json is guaranteed to reflect the
        currently-bound tuple (runtime.toml is rewritten only on
        port-fallback). Stdlib-only JSON; never raises.
        """
        path = self._config.effective_ports_path
        if path is None:
            return None
        import json as _json

        try:
            if not path.exists():
                return None
            with path.open("rb") as fh:
                raw = _json.load(fh)
        except (_json.JSONDecodeError, OSError, UnicodeDecodeError):
            return None
        if not isinstance(raw, dict):
            return None
        val = raw.get("internal_port")
        if isinstance(val, int) and 0 < val < 65536:
            return val
        return None

    def _read_authoritative_internal_port(self) -> int | None:
        """Return the daemon's authoritative ``internal_port`` with a 1s TTL cache.

        v0.1.21.2: prefers ``effective-ports.json`` (kernel-confirmed
        post-bind tuple) over ``runtime.toml`` (rewritten only on
        port-fallback). Both reads are cheap but every CONNECT calling
        this would still add up; a 1-second cache makes drift
        impossible (changes propagate within a second) without hot-path
        cost. ``None`` on any read failure — caller falls back to the
        cached config value.
        """
        now = time.monotonic()
        if (
            self._auth_port_cached is not None
            and now < self._auth_port_cache_expires_at
        ):
            return self._auth_port_cached
        port = self._read_effective_internal_port()
        if port is None:
            port = self._read_runtime_internal_port()
        self._auth_port_cached = port
        # 1.0s TTL — short enough that any port-fallback propagates
        # within a single second; long enough that hundreds of
        # CONNECTs/sec don't FS-thrash effective-ports.json.
        self._auth_port_cache_expires_at = now + 1.0
        return port

    def _write_state_sidecar(self) -> None:
        """Persist the current chain target to the edge sidecar.

        Best-effort; sidecar write failures must never break the hot
        path. Skips when no state_path is configured (test mode).
        """
        path = self._config.state_path
        if path is None:
            return
        try:
            from halton_meter.port_alloc import write_edge_state_toml

            write_edge_state_toml(
                path,
                edge_port=int(self._config.edge_port),
                chain_port=int(self._config.internal_port),
                pid=os.getpid(),
            )
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.state_sidecar_write_failed", error=str(exc))

    def write_initial_state(self, *, bound_edge_port: int | None = None) -> None:
        """Public entry point for ``halton-meter edge`` to persist the
        initial sidecar after binding.

        ``bound_edge_port`` lets the caller pass the kernel-assigned
        port (when the config asked for ``edge_port=0``) so the sidecar
        carries the actually-bound value, not the placeholder zero.
        """
        if bound_edge_port is not None:
            self._config.edge_port = int(bound_edge_port)
        self._write_state_sidecar()

    def _maybe_reresolve_chain_target(self) -> bool:
        """Re-read ``runtime.toml`` and rebind the chain target if it changed.

        Returns True iff the chain target was changed. Called on
        ``ConnectionRefusedError`` from a chain attempt — the daemon
        may have fallen back to a different ``internal_port`` since
        this process started, in which case the cached target is stale
        and every subsequent chain would also fail. Re-resolution is
        what stops the edge from locking into passthrough forever
        (memory/plans/2026-05-01-edge-passthrough-lockin-bug.md).
        """
        # v0.1.21.2: prefer effective-ports.json (authoritative post-bind
        # tuple) over runtime.toml. Cached at 1s TTL so per-CONNECT calls
        # are effectively free.
        new_port = self._read_authoritative_internal_port()
        if new_port is None:
            return False
        old_port = self._config.internal_port
        if new_port == old_port:
            return False
        self._config.internal_port = new_port
        self._cache.internal_port = new_port
        # Invalidate the auth-port cache so the very next call re-reads
        # the file rather than serving the just-applied stale value.
        self._auth_port_cache_expires_at = 0.0
        # New target: cached health answer is meaningless — force a
        # re-probe on the next request.
        self._cache.invalidate()
        log.warning(
            "edge.chain_target_changed",
            old_port=old_port,
            new_port=new_port,
        )
        self._write_state_sidecar()
        return True

    async def start(self) -> int:
        """Bind the listener; return the bound port.

        ``edge_port == 0`` is honoured for tests (kernel-assigned port).
        Updates ``self._bound_edge_port`` so the attribution path can
        do its dual-port psutil match against the actually-bound
        value (the client's ``raddr.port`` is whatever the kernel
        assigned, not the configured 0).
        """
        self._server = await asyncio.start_server(
            self._handle_connection,
            host=self._config.edge_host,
            port=self._config.edge_port,
        )
        # Capture the actual bound port (relevant when caller passed 0).
        sock = self._server.sockets[0] if self._server.sockets else None
        if sock is None:
            return self._config.edge_port
        bound = sock.getsockname()[1]
        self._bound_edge_port = int(bound)
        return bound

    async def watch_runtime_toml(self, *, poll_interval_s: float = 1.0) -> None:
        """Poll ``runtime.toml`` and re-resolve the chain target on change.

        v0.1.8 Gap 10. Pre-fix, the edge only re-resolved its
        ``internal_port`` AFTER a chain attempt observed
        ``ConnectionRefusedError`` (the v0.1.7 Gap 0 fallback). That
        works but means **one CONNECT must fail** before correction.
        With this watcher running, the moment the daemon writes a new
        ``runtime.toml`` the edge re-resolves — zero failed CONNECTs.

        Stdlib-only on purpose. Polling on file mtime + size is portable
        across macOS / Linux without pulling in ``watchdog`` (the
        plan's hard constraint: no new third-party deps).

        Fail-open: every iteration is wrapped. Any exception is logged
        and the loop continues; the watcher is observation
        infrastructure and must never break the edge serving loop.
        Cancellation propagates via :exc:`asyncio.CancelledError`.

        No-op when ``runtime_path`` is unset (test mode).
        """
        path = self._config.runtime_path
        if path is None:
            return

        # Signature includes mtime_ns + size + inode. Inode is the
        # decisive bit when the daemon rewrites runtime.toml via
        # os.replace within the same mtime tick: the destination inode
        # changes so we always notice. mtime_ns gives nanosecond
        # resolution (mtime alone has 1s granularity on some FS).
        def _sig() -> tuple[int, int, int] | None:
            try:
                st = path.stat()
            except (FileNotFoundError, OSError):
                return None
            return (st.st_mtime_ns, st.st_size, st.st_ino)

        # Initial reconciliation: the daemon may have rewritten
        # runtime.toml between EdgeConfig construction and now (e.g.
        # daemon restart racing edge startup). Re-resolve once on entry
        # so we don't wait for a file change that already happened.
        try:
            self._maybe_reresolve_chain_target()
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.runtime_watch_initial_reresolve_failed", error=str(exc))

        last_signature = _sig()

        while True:
            try:
                await asyncio.sleep(poll_interval_s)
                signature = _sig()
                if signature is None:
                    last_signature = None
                    continue
                if signature == last_signature:
                    continue
                last_signature = signature
                try:
                    changed = self._maybe_reresolve_chain_target()
                except Exception as exc:  # pragma: no cover - defensive
                    log.warning("edge.runtime_watch_reresolve_failed", error=str(exc))
                    continue
                if changed:
                    log.info(
                        "edge.runtime_watch_reresolved",
                        path=str(path),
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("edge.runtime_watch_iteration_failed", error=str(exc))

    async def serve_forever(self) -> None:
        if self._server is None:
            raise RuntimeError("EdgeProxy.start() must be called before serve_forever()")
        async with self._server:
            await self._server.serve_forever()

    async def stop(self) -> None:
        if self._server is None:
            return
        self._server.close()
        try:
            await self._server.wait_closed()
        except Exception:  # pragma: no cover - defensive
            pass
        self._server = None

    async def cancel_inflight(self) -> None:
        """Cancel all in-flight per-connection handler tasks and wait.

        v0.1.22.18 Fix 1. ``stop()`` closes the listener and refuses new
        accepts but does NOT touch handler tasks already running for
        existing connections. On legitimate SIGTERM (e.g. the edge's
        own launchd plist sending SIGTERM during ``halton-meter
        uninstall`` / system shutdown) the asyncio event loop closes
        with these tasks still pending, surfacing the
        ``Task was destroyed but it is pending`` runtime warning into
        edge.err.log.

        This method snapshots the current set, requests cancellation
        on each, and awaits all to completion via
        ``asyncio.gather(..., return_exceptions=True)`` so a per-task
        error doesn't abort the drain. Idempotent: a second call on an
        already-empty set is a no-op.

        B4 stop semantics (decisions.md 2026-05-07 v0.1.22.3): this
        helper runs in the EDGE process's own shutdown path. The
        daemon's ``halton-meter stop`` lifecycle does NOT signal the
        edge — that contract is unchanged. Cancellation here only
        fires when the edge itself is being torn down.
        """
        # Snapshot first: cancellation drives finally blocks that
        # mutate ``_active_handler_tasks`` via discard().
        tasks = [t for t in self._active_handler_tasks if not t.done()]
        if not tasks:
            return
        for task in tasks:
            task.cancel()
        # ``return_exceptions=True`` so CancelledError doesn't propagate
        # out of gather and a single-task failure doesn't abort the
        # drain of the rest.
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _handle_connection(
        self,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        """Per-connection handler. Never raises."""
        # v0.1.22.18 Fix 1: register the running task so
        # ``cancel_inflight`` can drain it on shutdown. ``current_task``
        # returns the task asyncio.start_server spawned to invoke this
        # callback. Discard on exit so the set doesn't leak across
        # millions of connections in long-lived edge processes.
        _self_task = asyncio.current_task()
        if _self_task is not None:
            self._active_handler_tasks.add(_self_task)
        peer = client_writer.get_extra_info("peername")
        # v0.1.13: client port is the unique identifier for the client
        # process — psutil can find the owner of (laddr.port=client_port,
        # raddr.port=edge_port) in O(processes) without racing the
        # connection table. Captured at accept-time and threaded all
        # the way down to _try_chain so the daemon registration uses
        # the same port the addon will see in flow.client_conn.peername.
        client_port: int | None = None
        if isinstance(peer, tuple) and len(peer) >= 2:
            try:
                client_port = int(peer[1])
            except (TypeError, ValueError):
                client_port = None
        try:
            parsed = await read_request_head(client_reader)
            if parsed is None:
                log.info("edge.bad_request", peer=str(peer))
                self._safe_write(
                    client_writer,
                    b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
                )
                return
            if parsed.method.upper() == "CONNECT":
                await self._handle_connect(
                    parsed, client_reader, client_writer, client_port
                )
            else:
                await self._handle_http(
                    parsed, client_reader, client_writer, client_port
                )
        except asyncio.CancelledError:
            # v0.1.22.18 Fix 1: shutdown cancellation (cancel_inflight).
            # Treat as clean exit — the finally block still closes the
            # client writer. Re-raise so the parent task properly
            # surfaces the cancellation to ``asyncio.gather``.
            raise
        except Exception as exc:
            # Cardinal rule: log and let the connection die. Never let
            # an edge-proxy bug bring the listener down.
            log.error(
                "edge.connection_failed",
                peer=str(peer),
                error=str(exc),
                exc_info=True,
            )
        finally:
            # v0.1.22.18 Fix 1: deregister from the inflight set so
            # idle/long-lived edges don't accumulate task references.
            if _self_task is not None:
                self._active_handler_tasks.discard(_self_task)
            # 2026-05-01 (0.1.13.dev2): we used to ``await
            # client_writer.wait_closed()`` here. Under Python 3.14 the
            # asyncio shutdown path was racing this await: the same
            # close-waiter future was being reached twice (once on the
            # normal-path return, once when the loop cancelled the
            # task at interpreter shutdown), and 3.14's stricter
            # coroutine-reuse check raised
            # ``RuntimeError: cannot reuse already awaited coroutine``
            # — polluting edge.err.log on every clean shutdown.
            #
            # We don't actually need to block on the kernel TCP-close
            # here: the client is the one that disconnected, the
            # asyncio.Server already released the slot at handler
            # return, and the transport will reach connection_lost
            # asynchronously. Calling ``close()`` and letting the
            # transport tear itself down is correct AND quiet.
            try:
                if not client_writer.is_closing():
                    client_writer.close()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass

    async def _handle_connect(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        client_port: int | None = None,
    ) -> None:
        host_port = parse_connect_target(parsed.target)
        if host_port is None:
            log.info("edge.connect.bad_target", target=parsed.target)
            self._safe_write(
                client_writer,
                b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
            )
            return

        # v0.1.22.24: host-allowlist gate. Only LLM provider hosts are
        # candidates for chaining into mitmproxy. Non-LLM CONNECTs
        # (github.com, registry.npmjs.org, sentry.io, etc.) go directly
        # to passthrough and never touch the internal mitm port. This
        # restores the cardinal-rule contract: even when the daemon is
        # healthy, the edge does not interfere with traffic it has no
        # business decrypting.
        host_only, _ = host_port
        if host_should_intercept(host_only):
            chained = await self._try_chain(
                parsed, client_reader, client_writer, client_port
            )
            if chained:
                return
        # Fall through to direct passthrough.
        await self._do_passthrough_connect(host_port, client_reader, client_writer)

    async def _try_chain(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        client_port: int | None = None,
    ) -> bool:
        """Attempt to chain the request through the metering daemon.

        Returns True if the chain was attempted (regardless of whether
        it succeeded internally — once we hand off to the daemon the
        edge is just shuttling bytes). Returns False if we never
        attempted the chain (cache says daemon down) OR if the TCP
        connect to the daemon raised ConnectionRefusedError, in which
        case the cache is invalidated and the caller can fall through
        to passthrough.

        2026-05-01: between ``open_connection`` and ``up_writer.write``
        we register the project attribution decision into a shared
        SQLite table (``attribution_log``) via
        ``attribution_store.write``. The order matters — the
        registration must complete before the daemon's mitmproxy
        ``request()`` hook reads the row. The write is synchronous
        Python (no ``await`` between it and the forward), so the
        ordering is guaranteed by control flow, not by transport
        latency. Both branches respect the cardinal rule: registration
        failure is logged and chained traffic still flows; the request
        lands as ``unattributed`` in that case.
        """
        # v0.1.21.2: re-resolve chain target BEFORE every chain attempt
        # against effective-ports.json (1s TTL cache → cheap). Closes
        # the silent-metering-loss window where the runtime.toml watcher
        # hasn't ticked yet but the daemon has rebound to a new
        # internal_port. The previous design relied on
        # ConnectionRefusedError to trigger re-resolution; that fails
        # when the OLD port is held by an unrelated listener (no
        # refused — bytes shuttle nowhere meaningful).
        try:
            self._maybe_reresolve_chain_target()
        except Exception as exc:  # pragma: no cover — defensive
            log.warning("edge.chain.preflight_reresolve_failed", error=str(exc))
        if not await self._cache.is_healthy():
            return False
        try:
            up_reader, up_writer = await asyncio.open_connection(
                self._config.internal_host, self._config.internal_port
            )
        except ConnectionRefusedError:
            # Stale-positive race: cache said healthy but daemon died
            # between probe and chain. Invalidate so next request re-
            # probes; fall through to passthrough on this one.
            self._cache.invalidate()
            log.info(
                "edge.chain.refused_invalidating",
                internal=f"{self._config.internal_host}:{self._config.internal_port}",
            )
            # v0.1.7 Gap 0: the daemon may have moved to a different
            # internal_port since this edge process started (port-fallback
            # race). Re-read runtime.toml so the next chain attempt uses
            # the new target instead of looping refused → passthrough.
            self._maybe_reresolve_chain_target()
            return False
        except OSError as exc:
            self._cache.invalidate()
            log.warning("edge.chain.connect_failed", error=str(exc))
            self._maybe_reresolve_chain_target()
            return False
        try:
            # 2026-05-01: register attribution BEFORE forwarding the
            # request line. The SQLite write inside
            # ``_register_attribution_for_connection`` is plain
            # synchronous Python — the ``await`` here returns only
            # after the row is committed, so by the time we call
            # ``up_writer.write(parsed.raw_head)`` the daemon's
            # ``request()`` hook is guaranteed to find the row.
            await self._register_attribution_for_connection(
                up_writer, client_port
            )

            up_writer.write(parsed.raw_head)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            except RuntimeError:
                # v0.1.19.dev1 (Phase 2): under Python 3.14 + asyncio
                # shutdown, the close-waiter future can be reached
                # twice (handler return + loop cancellation), raising
                # ``RuntimeError: cannot reuse already awaited coroutine``.
                # Same root cause as the 2026-05-01 fix in
                # ``_handle_connection``; cleanup is best-effort, so
                # we swallow and let the transport tear itself down.
                pass
        return True

    async def _register_attribution_for_connection(
        self,
        up_writer: asyncio.StreamWriter,
        client_port: int | None,
    ) -> None:
        """Resolve and register the project attribution for one chain hop.

        ``up_writer`` is the writer for the edge→daemon TCP socket;
        its ``sockname`` is the edge's outbound source port — exactly
        the port the daemon sees in ``flow.client_conn.peername[1]``.

        2026-05-01 fix — the registration writes **synchronously** to
        a shared SQLite attribution table via the
        ``attribution_store`` module singleton instead of POSTing to
        the daemon's HTTP API. The structural change eliminates the
        HTTP/uvicorn-dispatch race that was landing every production
        row as ``unattributed``. SQLite WAL with ``BEGIN IMMEDIATE``
        handles the cross-process write durably in well under a
        millisecond, inside the daemon's TCP-accept window. The
        cardinal invariant — write completes BEFORE
        ``up_writer.write(parsed.raw_head)`` — holds because the
        write here is plain synchronous Python (no ``await``)
        between this call and the forward in ``_try_chain``.

        Skips registration when:

        * ``client_port`` is ``None`` (the accept didn't yield a
          peer port — happens for unix-domain sockets and certain
          test transports).
        * ``attribution_db_path`` on the EdgeConfig is unset AND the
          ``attribution_store`` singleton has no path wired (test
          mode constructed an ``EdgeConfig`` directly without
          calling ``set_db_path``).

        We log the resolved ``edge_src_port`` here too — operator's
        ask for ongoing observability so daemon-side store lookups
        can be correlated with edge-side resolutions in a logfile.
        """
        if client_port is None:
            return
        sockname = up_writer.get_extra_info("sockname")
        if not (isinstance(sockname, tuple) and len(sockname) >= 2):
            return
        try:
            edge_src_port = int(sockname[1])
        except (TypeError, ValueError):
            return

        # Lazy imports keep edge.py stdlib-only at import time.
        from halton_meter import attribution_store
        from halton_meter.edge_attribution import resolve_client_project

        # If the EdgeConfig carries a path but the singleton hasn't
        # been wired yet (e.g. tests that build EdgeConfig directly),
        # wire it on first use. Idempotent — set_db_path is a no-op
        # on a same-path re-set.
        cfg_path = self._config.attribution_db_path
        if cfg_path is not None and attribution_store.get_db_path() is None:
            attribution_store.set_db_path(cfg_path)
        if attribution_store.get_db_path() is None:
            return

        project, body_capture_enabled = await resolve_client_project(
            client_port=client_port,
            edge_port=self._bound_edge_port,
        )
        # Synchronous SQLite write. MUST complete before the caller
        # forwards the CONNECT to the daemon (see _try_chain for the
        # full ordering rationale). Never raises.
        # ``body_capture_enabled`` (B1, 2026-05-02) carries the
        # rcfile-side ``body_capture`` flag so B2's BodyCaptureCache
        # fallback can honour it without a project_settings row.
        attribution_store.write(edge_src_port, project, body_capture_enabled)
        # Operator-requested observability: log both the client port
        # AND the edge src port on every registration so daemon-side
        # store lookups can be correlated.
        log.info(
            "edge.attribution.registered",
            client_port=client_port,
            edge_src_port=edge_src_port,
            project=project,
            body_capture_enabled=body_capture_enabled,
        )

    async def _do_passthrough_connect(
        self,
        host_port: tuple[str, int],
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        host, port = host_port
        try:
            up_reader, up_writer = await asyncio.open_connection(host, port)
        except (TimeoutError, OSError) as exc:
            log.info(
                "edge.passthrough.connect_failed",
                host=host,
                port=port,
                error=str(exc),
            )
            self._safe_write(
                client_writer,
                b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n",
            )
            return
        try:
            self._safe_write(
                client_writer,
                b"HTTP/1.1 200 Connection Established\r\n\r\n",
            )
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            except RuntimeError:
                # v0.1.19.dev1 (Phase 2): under Python 3.14 + asyncio
                # shutdown, the close-waiter future can be reached
                # twice (handler return + loop cancellation), raising
                # ``RuntimeError: cannot reuse already awaited coroutine``.
                # Same root cause as the 2026-05-01 fix in
                # ``_handle_connection``; cleanup is best-effort, so
                # we swallow and let the transport tear itself down.
                pass

    async def _handle_http(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        client_port: int | None = None,
    ) -> None:
        """Handle plain (non-CONNECT) HTTP-via-proxy requests.

        Two upstream choices, same as CONNECT:

        * **Chain.** Replay the head to the metering daemon's proxy
          listener verbatim — mitmproxy speaks the absolute-URL HTTP-
          proxy form so the request line passes through unchanged.
        * **Passthrough.** Parse host:port out of the absolute URL,
          rewrite the request line to its origin form, replay
          headers, shuttle bytes.

        Edge case: a plain HTTP request to a proxy with a non-absolute
        target (i.e. someone sent us a regular HTTP request as if we
        were the origin server). Rare in practice and outside our
        contract. Reply 400 and move on.
        """
        chained = await self._try_chain_http(
            parsed, client_reader, client_writer, client_port
        )
        if chained:
            return
        # Passthrough branch — parse upstream out of the absolute URL.
        upstream = _parse_http_absolute_url(parsed.target)
        if upstream is None:
            log.info("edge.http.bad_target", target=parsed.target)
            self._safe_write(
                client_writer,
                b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
            )
            return
        await self._do_passthrough_http(
            parsed, upstream, client_reader, client_writer
        )

    async def _try_chain_http(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        client_port: int | None = None,
    ) -> bool:
        # v0.1.21.2: same per-request reresolve as ``_try_chain``.
        try:
            self._maybe_reresolve_chain_target()
        except Exception as exc:  # pragma: no cover — defensive
            log.warning("edge.chain_http.preflight_reresolve_failed", error=str(exc))
        if not await self._cache.is_healthy():
            return False
        try:
            up_reader, up_writer = await asyncio.open_connection(
                self._config.internal_host, self._config.internal_port
            )
        except ConnectionRefusedError:
            self._cache.invalidate()
            # v0.1.7 Gap 0: same re-resolve trigger as the CONNECT path —
            # see _try_chain for the full rationale.
            self._maybe_reresolve_chain_target()
            return False
        except OSError:
            self._cache.invalidate()
            self._maybe_reresolve_chain_target()
            return False
        try:
            # Same attribution-before-forward order as _try_chain.
            # See that method for the rationale.
            await self._register_attribution_for_connection(
                up_writer, client_port
            )
            up_writer.write(parsed.raw_head)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            except RuntimeError:
                # v0.1.19.dev1 (Phase 2): under Python 3.14 + asyncio
                # shutdown, the close-waiter future can be reached
                # twice (handler return + loop cancellation), raising
                # ``RuntimeError: cannot reuse already awaited coroutine``.
                # Same root cause as the 2026-05-01 fix in
                # ``_handle_connection``; cleanup is best-effort, so
                # we swallow and let the transport tear itself down.
                pass
        return True

    async def _do_passthrough_http(
        self,
        parsed: ParsedRequest,
        upstream: tuple[str, int, str],
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        host, port, origin_path = upstream
        try:
            up_reader, up_writer = await asyncio.open_connection(host, port)
        except (TimeoutError, OSError) as exc:
            log.info(
                "edge.passthrough.http.connect_failed",
                host=host,
                port=port,
                error=str(exc),
            )
            self._safe_write(
                client_writer,
                b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n",
            )
            return
        try:
            # Rewrite request line: absolute-URL → origin-form.
            new_request_line = (
                f"{parsed.method} {origin_path} {parsed.version}\r\n"
            ).encode("iso-8859-1")
            # Append the original header block (everything after the
            # first line of raw_head).
            _, _, header_tail = parsed.raw_head.partition(b"\r\n")
            up_writer.write(new_request_line + header_tail)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
            except RuntimeError:
                # v0.1.19.dev1 (Phase 2): under Python 3.14 + asyncio
                # shutdown, the close-waiter future can be reached
                # twice (handler return + loop cancellation), raising
                # ``RuntimeError: cannot reuse already awaited coroutine``.
                # Same root cause as the 2026-05-01 fix in
                # ``_handle_connection``; cleanup is best-effort, so
                # we swallow and let the transport tear itself down.
                pass

    @staticmethod
    def _safe_write(writer: asyncio.StreamWriter, data: bytes) -> None:
        try:
            writer.write(data)
        except (ConnectionResetError, BrokenPipeError, OSError):
            return


def _parse_http_absolute_url(target: str) -> tuple[str, int, str] | None:
    """Parse ``http://host[:port]/path`` from an HTTP-proxy request line.

    Returns ``(host, port, origin_path)`` or ``None`` if the target is
    not in absolute-URL form. Default port is 80 for ``http://``,
    443 for ``https://`` (though https-via-proxy is normally CONNECT,
    not absolute-URL).
    """
    target = target.strip()
    for scheme, default_port in (("http://", 80), ("https://", 443)):
        if target.lower().startswith(scheme):
            rest = target[len(scheme):]
            slash = rest.find("/")
            if slash == -1:
                authority = rest
                origin_path = "/"
            else:
                authority = rest[:slash]
                origin_path = rest[slash:]
            if not authority:
                return None
            if ":" in authority:
                host, _, port_str = authority.rpartition(":")
                try:
                    port = int(port_str)
                except ValueError:
                    return None
            else:
                host = authority
                port = default_port
            if not host or not (0 < port < 65536):
                return None
            return host, port, origin_path
    return None
