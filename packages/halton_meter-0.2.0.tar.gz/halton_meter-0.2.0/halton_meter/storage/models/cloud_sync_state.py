"""CloudSyncState model — cursor for the metadata cloud-sync worker.

One row per cloud ``endpoint``. The worker reads from ``requests`` ordered by
``(recorded_at, id)`` and advances this cursor only after the cloud has
acknowledged the batch.

See:
  * memory/plans/phase2-wire-contract.md §3 (pinned to SHA e8f252a)
  * memory/plans/phase2-daemon-changes.md §1b
  * memory/plans/phase2-cloud-sync.md §3c (rationale for the cursor key)

Single-row in practice: Wave-1 daemons talk to exactly one cloud endpoint.
The schema is keyed by endpoint so a future multi-endpoint world (paranoid
multi-cloud, staging vs prod) is a row-add, not a migration.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


class CloudSyncState(Base):
    __tablename__ = "cloud_sync_state"

    # Endpoint URL is the natural primary key — single-row today, future-proof
    # for multi-endpoint installs without a migration.
    endpoint: Mapped[str] = mapped_column(String(512), primary_key=True)

    # Cursor anchor: ``(last_synced_request_recorded_at, last_synced_request_id)``.
    # The worker selects ``WHERE (recorded_at, id) > (cursor_at, cursor_id)``
    # ordered by the same pair, so streaming responses (which can write much
    # later than their ``requested_at``) cannot leak past the cursor.
    last_synced_request_recorded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_synced_request_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True
    )

    # Crash-recovery breadcrumbs. Updated inside the same transaction as the
    # cursor advance so a half-applied batch is impossible.
    last_batch_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    last_batch_attempted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_batch_succeeded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Health surface. ``consecutive_failures`` resets to 0 on a successful
    # advance; ``last_error`` carries a token-redacted human string.
    consecutive_failures: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # 'paused_unauthorised' (cloud 401/403), 'paused_manual' (operator),
    # 'paused_schema_mismatch', or NULL. Worker checks this before each tick.
    paused_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
