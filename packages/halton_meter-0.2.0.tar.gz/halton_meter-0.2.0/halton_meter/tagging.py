"""
Project tagging for Halton Meter daemon.

Resolves a project name for a given mitmproxy flow using the following
precedence (first match wins):

  0. **Edge attribution store** (``halton_meter.attribution_store``) —
     populated by the edge process at TCP-accept time, keyed by the
     edge's outbound source port. SQLite-backed since the 2026-05-01
     race fix that replaced the in-memory HTTP cache. This is the
     **authoritative** answer when the request flowed through the
     edge, which is the production path.
  1. HALTON_PROJECT environment variable on the daemon process (legacy
     fallback for direct mitmproxy mode without an edge in front).
  2. .haltonrc walk from the originating process's cwd (legacy fallback).
  4. Git repo basename (PR2 2026-05-02; Option A locked).
  6. Linux/Kubernetes container detection (PR2 2026-05-02).
  6.5. macOS sandbox bundle id (PR2 2026-05-02; Brief D).
  7. Originating process's working directory basename (legacy fallback).
  8. Literal string "unattributed".

Decision reference: memory/decisions.md 2026-05-01 — "Move project
attribution to the edge". v0.1.13 made the cache the primary path; the
psutil-based fallback below is preserved for direct mitmproxy
connections (e.g. mitmproxy testing, future deployments without the
edge in front) but is no longer the production hot path.

The edge attribution store (Step 0):

The edge owns the user-facing :8081 port. When it accepts a client
TCP connection, it does a synchronous psutil lookup for the process
owning that local client port (with a hard time budget) and applies
the same precedence (env > rcfile > cwd basename) to that process.
The result is written into the shared SQLite ``attribution_log``
table keyed by the edge's outbound source port — exactly the value
the daemon sees in ``flow.client_conn.peername[1]``. Step 0 below
reads that table; if it hits, we are done.

Why the daemon-side psutil walk was removed from the hot path:

The pre-v0.1.13 design (``_get_process_cwd`` + two-hop traversal)
worked when the connection table was stable, but psutil's
``net_connections()`` on macOS frequently returns incomplete data
under permissions / kernel-state edge cases. By the time the daemon's
tagger runs, the edge→daemon TCP connection has been established for
milliseconds and the ephemeral port may already be reused by an
unrelated socket; the daemon is too far removed from the original
client connection to reliably introspect it. Decision log entry
2026-05-01 captures the full rationale.

The legacy two-hop helpers (``_get_process_cwd``,
``_find_client_port_via_edge``, ``_cwd_for_port``) are retained as a
fallback for non-edge deployments — they still work in direct
mitmproxy mode where a single hop (no edge) puts the client port in
``flow.client_conn.peername`` directly. They are NOT on the
production hot path; do not redesign them without flagging the
operator first.

Project names are post-processed to refuse a leading dot: a leading
dot is stripped; if the result is empty the name becomes
``"unattributed"``. This keeps system-directory basenames out of the
report column.

This function is intentionally synchronous — it runs in the mitmproxy
proxy hot path and must be fast. All I/O is filesystem-only (no network,
no DB writes).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import NamedTuple

import structlog

from halton_meter import attribution_store
from halton_meter.attribution import layers as _layers
from halton_meter.config import HaltonConfig

log = structlog.get_logger()

# Constants kept as module-level aliases for back-compat with any
# external import; the canonical home is now
# :mod:`halton_meter.attribution.layers`.
_RCFILE_NAME = _layers.RCFILE_NAME
_ENV_VAR = _layers.ENV_VAR
_UNATTRIBUTED = _layers.UNATTRIBUTED


class ResolvedProject(NamedTuple):
    """Structured result from :func:`resolve_project_with_meta`.

    ``project`` — the resolved project slug (always set; falls back to
    ``"unattributed"`` when no layer fires).

    ``method`` — the attribution layer that won. One of: ``edge_store``,
    ``env``, ``rcfile``, ``git``, ``container``, ``mac_sandbox``,
    ``workdir``, ``unattributed``. The set matches the ``method=...``
    values already emitted by the ``tagging.resolved`` log calls.
    The edge-side resolver also produces ``ide_sniff``; the daemon-side
    bypass path here cannot reach Step 3 (cmdline sniff requires
    psutil) so it never emits that value.

    ``source_workdir`` — the cwd that was used as input to the
    layer that won. ``None`` for ``edge_store`` (cache hit — the
    original method's source_workdir was recorded ONCE at edge time and
    isn't re-surfaced today; see follow-up note in
    ``memory/progress.md``) and for ``env`` (no cwd consulted).
    """

    project: str
    method: str
    source_workdir: str | None


def _proc_net_connections(proc: object) -> list:  # type: ignore[type-arg]
    """Return a process's network connections, handling psutil API versions."""
    try:
        return proc.net_connections()  # type: ignore[attr-defined]  # psutil >= 6.0
    except AttributeError:
        return proc.connections()  # type: ignore[attr-defined]  # psutil < 6.0


def _get_process_cwd(flow: object, edge_port: int | None = None) -> str | None:
    """
    LEGACY FALLBACK — direct-mitmproxy mode only (NOT production hot path).

    v0.1.13: ``resolve_project`` checks the edge attribution store
    first (Step 0). The production deployment always has the edge in
    front, so this function is only reached when:

    * Tests construct a flow directly without an edge.
    * A future deployment runs mitmproxy without an edge.
    * The store somehow misses on a flow that *did* come via the edge
      (edge crashed mid-write, etc.) — in which case falling through
      to "unattributed" is the right answer per the cardinal rule.

    Do NOT redesign this without flagging the operator: the v0.1.12
    two-hop logic remains useful for non-edge deployments and the
    operator must approve changes to the cross-cutting attribution
    contract.

    Original v0.1.12 description follows.

    Attempt to resolve the working directory of the process that opened
    the connection represented by the given flow.

    Uses psutil to look up the client PID from the flow's client connection.
    Returns ``None`` on any failure (no flow, non-HTTPFlow, no peername,
    PID not found, psutil unavailable, etc.). The caller is expected to
    fall back to ``"unattributed"`` rather than ``os.getcwd()``: the
    daemon's own cwd under launchd is ``~/.halton-meter`` and using
    that as a project name produces the ``.halton-meter`` mis-attribution
    fixed in v0.1.8 Gap 6.

    When ``edge_port`` is provided (the port the edge proxy listens on,
    typically 8081), a two-hop traversal is attempted: if the process
    found via ``EDGE_SRC_PORT`` looks like the edge proxy (it has an
    accepted connection on ``edge_port`` with a live remote address),
    we extract the original ``CLIENT_PORT`` from that connection's
    ``raddr.port`` and look up the process that owns it. This corrects
    the mis-attribution introduced by the edge→daemon two-hop
    architecture (v0.1.12 fix).
    """
    try:
        import psutil  # type: ignore[import-untyped]
        from mitmproxy import http  # type: ignore[import-untyped]

        if not isinstance(flow, http.HTTPFlow):
            return None

        client_conn = flow.client_conn
        # client_conn.peername is (host, port) for the connecting client.
        # In the two-hop setup this is the edge's ephemeral source port
        # (EDGE_SRC_PORT), not the original client's port.
        client_port: int | None = None
        if client_conn.peername:
            client_port = client_conn.peername[1]

        if client_port is None:
            return None

        # Walk all connections to find the process owning this port.
        for proc in psutil.process_iter(["pid"]):
            try:
                conns = _proc_net_connections(proc)
                for conn in conns:
                    if hasattr(conn, "laddr") and conn.laddr and conn.laddr.port == client_port:
                        # Found the process that owns EDGE_SRC_PORT (or
                        # CLIENT_PORT in a direct one-hop setup).
                        if edge_port is not None:
                            # Check whether this looks like the edge proxy.
                            # The edge process will have an accepted connection
                            # on laddr.port == edge_port with a live raddr —
                            # that raddr.port is the real CLIENT_PORT.
                            real_client_port = _find_client_port_via_edge(
                                conns, edge_port
                            )
                            if real_client_port is not None:
                                log.debug(
                                    "tagging.two_hop_traversal",
                                    edge_src_port=client_port,
                                    edge_port=edge_port,
                                    real_client_port=real_client_port,
                                )
                                return _cwd_for_port(
                                    psutil,
                                    real_client_port,
                                    edge_port=edge_port,
                                    exclude_pid=proc.pid,
                                )
                            # edge_port not found on this process — not the
                            # edge proxy, treat as a direct client.
                        return proc.cwd()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

    except Exception as exc:
        log.debug("tagging.cwd_lookup_failed", error=str(exc))

    return None


def _find_client_port_via_edge(
    edge_conns: list,  # type: ignore[type-arg]
    edge_port: int,
) -> int | None:
    """Given the connections of the suspected edge process and the known
    ``edge_port``, find the CLIENT_PORT.

    When a client connects to the edge on ``edge_port``, the edge process
    has an accepted TCP connection:
        laddr = (127.0.0.1, edge_port)   ← the listener address
        raddr = (127.0.0.1, CLIENT_PORT) ← the client's ephemeral port

    We find the first such connection with a live ``raddr`` and return
    ``raddr.port`` as the real CLIENT_PORT.

    Returns ``None`` if no matching connection is found (meaning the
    process is not the edge, or there are no current clients — fall
    through to treating it as a direct client).
    """
    for conn in edge_conns:
        if (
            hasattr(conn, "laddr")
            and conn.laddr
            and conn.laddr.port == edge_port
            and hasattr(conn, "raddr")
            and conn.raddr
            and conn.raddr.port  # non-zero → a live connection, not a listener
        ):
            return int(conn.raddr.port)
    return None


def _cwd_for_port(
    psutil: object,
    port: int,
    edge_port: int | None = None,
    exclude_pid: int | None = None,
) -> str | None:
    """Find the cwd of the process that has ``laddr.port == port``.

    When ``edge_port`` is provided, the connection is additionally matched
    on ``raddr.port == edge_port`` to uniquely identify the client's
    connection (laddr is the client's ephemeral port, raddr is the edge proxy).
    This prevents mis-matching a system process with an ephemeral port
    coincidentally equal to ``port`` (macOS has many such processes).

    ``exclude_pid`` is the PID of the edge process — we skip it so we
    don't accidentally re-select the edge if port reuse causes a collision.
    Returns ``None`` if no matching process is found or cwd is unreadable.
    """
    try:
        for proc in psutil.process_iter(["pid"]):  # type: ignore[attr-defined]
            if exclude_pid is not None and proc.pid == exclude_pid:
                continue
            try:
                conns = _proc_net_connections(proc)
                for conn in conns:
                    if (
                        hasattr(conn, "laddr")
                        and conn.laddr
                        and conn.laddr.port == port
                    ):
                        # If edge_port is specified, additionally match on raddr
                        # to uniquely identify the client's connection.
                        if edge_port is not None:
                            if not (
                                hasattr(conn, "raddr")
                                and conn.raddr
                                and conn.raddr.port == edge_port
                            ):
                                continue
                        return proc.cwd()
            except (
                psutil.NoSuchProcess,  # type: ignore[attr-defined]
                psutil.AccessDenied,  # type: ignore[attr-defined]
                psutil.ZombieProcess,  # type: ignore[attr-defined]
            ):
                continue
    except Exception as exc:
        log.debug("tagging.cwd_for_port_failed", port=port, error=str(exc))
    return None


# Back-compat shims — the canonical implementations live in
# :mod:`halton_meter.attribution.layers`. Tests reach for these private
# names; preserve them so the PR1 refactor is bit-for-bit behavioural.
_sanitize_project_name = _layers.normalise_project_slug


def _read_haltonrc(start_dir: str) -> str | None:
    """Daemon-side projection: project field only.

    The shared layer returns ``(project, body_capture)``; the daemon
    bypass path has no use for the body_capture flag (body capture is
    gated at the edge), so we project to the project string. Tests
    asserting ``isinstance(result, str) or result is None`` keep
    passing.
    """
    return _layers.resolve_via_haltonrc_project_only(start_dir)


def _normalize_process_name(name: str) -> str:
    """Normalize process name for matching: lowercase, strip path, remove extension.

    Examples:
      /usr/bin/python3 → python3
      /Applications/Cursor.app/Contents/MacOS/Cursor → cursor
      Code → code
    """
    import os
    # Extract basename (strip full path)
    basename = os.path.basename(name)
    # Lowercase for case-insensitive matching
    normalized = basename.lower()
    return normalized


def _get_process_name(flow: object, edge_port: int | None = None) -> str | None:
    """Extract the executable name (basename) from the originating process.

    Uses psutil to get the process information from the flow's client connection.
    Returns normalized (lowercase, path-stripped) process name, or ``None`` if
    the process cannot be determined. This is a fallback helper for process-based
    heuristics (e.g. mapping 'python' -> 'dev' project).
    """
    try:
        import psutil  # type: ignore[import-untyped]
        from mitmproxy import http  # type: ignore[import-untyped]

        if not isinstance(flow, http.HTTPFlow) or not flow.client_conn.peername:
            return None

        client_port = flow.client_conn.peername[1]
        proc = psutil.Process(psutil.net_connections()[0].pid)  # type: ignore[index]

        # Try to find the process by port
        for proc in psutil.process_iter(["pid", "name"]):  # type: ignore[attr-defined]
            try:
                conns = _proc_net_connections(proc)  # type: ignore[arg-type]
                for conn in conns:
                    if (
                        hasattr(conn, "laddr")
                        and conn.laddr
                        and conn.laddr.port == client_port
                    ):
                        # Found the process; normalize and return
                        raw_name = proc.info.get("name")  # type: ignore[union-attr]
                        if raw_name:
                            normalized = _normalize_process_name(raw_name)
                            log.debug(
                                "tagging.process_name_detected",
                                raw_name=raw_name,
                                normalized=normalized,
                                client_port=client_port,
                            )
                            return normalized
                        return None
            except (
                psutil.NoSuchProcess,  # type: ignore[attr-defined]
                psutil.AccessDenied,  # type: ignore[attr-defined]
                psutil.ZombieProcess,  # type: ignore[attr-defined]
            ):
                continue
    except Exception as exc:
        log.debug("tagging.process_name_lookup_failed", error=str(exc))

    return None


def resolve_project(
    flow: object,
    edge_port: int | None = None,
) -> str:
    """Back-compat string-only wrapper around :func:`resolve_project_with_meta`.

    The proxy hot path calls :func:`resolve_project_with_meta` directly so
    it can populate the ``attribution_method`` and ``source_workdir``
    columns on the ``requests`` row. Tests and any other callers that
    only need the project slug keep the original signature.
    """
    return resolve_project_with_meta(flow, edge_port=edge_port).project


def resolve_project_with_meta(
    flow: object,
    edge_port: int | None = None,
    config: HaltonConfig | None = None,
) -> ResolvedProject:
    """
    Resolve the project name for a given mitmproxy HTTPFlow.

    Precedence (Smart Attribution v0.3, 2026-05-02; v0.1.17 + process heuristics):
      0. Edge attribution store lookup (production path; SQLite-backed
         since the 2026-05-01 race fix). When the request came through
         the edge, the ``attribution_log`` table contains the
         authoritative answer keyed by ``flow.client_conn.peername[1]``.
         The lookup uses the module-level ``attribution_store``
         singleton; the daemon's CLI wires its DB path at startup. If
         the singleton is unwired (test mode without an edge), the
         lookup returns ``None`` and we fall through.

      The remaining steps are the daemon-side bypass path (no edge in
      the picture — direct mitmproxy mode, tests, or future
      integrations). The edge resolver in ``edge_attribution.py``
      walks the same precedence against the matched process:

      1. HALTON_PROJECT environment variable.
      2. .haltonrc walked upward from cwd.
         (Edge also: 3. IDE workspace sniff via cmdline args.)
      4. Git repo basename (Option A — branch info dropped).
      6. Container detection (k8s / Docker, gated on real container
         signals — never fires on a developer laptop).
      6.5. macOS sandbox bundle id (``mac:<bundle-id>`` — unwraps
         ``~/Library/Containers/<bundle>/Data`` cwds so apps like
         Perplexity stop collapsing to project ``Data``).
      7. Workdir basename.
      7.5. Process-based heuristics (v0.1.17, Issue #3). When enabled via
         config, detect the originating process name and check against
         process_mappings (e.g. 'claude' -> 'dev'). Reduces unattributed
         traffic from known tools.
      8. Smart default or "unattributed" (config: tagging.default_project).

      First match wins. Layer 5 (monorepo) is intentionally parked
      per the v0.3 plan — see ``memory/plans/2026-05-02-smart-attribution-v0.3.md``.

      The ``config`` parameter supplies tagging.default_project and
      tagging.process_mappings. If None, defaults are used (process
      heuristics enabled, default_project='misc').

    Example (Windsurf session inside a git repo with a .haltonrc):
      A request lands from a Windsurf renderer whose cwd is
      ``~/code/halton-meter-cloud`` and the repo contains a
      ``.haltonrc`` with ``project: halton-meter-cloud``. The edge
      resolver runs precedence 1 → no env override → 2 hits the
      rcfile → emits ``halton-meter-cloud`` and writes that into
      ``attribution_log``. The daemon's hot path then sees the row
      via Step 0 (cache hit) on every subsequent request from the
      same TCP connection, never re-running the walk.

    ``edge_port`` is the port the edge proxy listens on (default 8081).
    When provided AND the store step misses, ``_get_process_cwd`` falls
    back to the v0.1.12 two-hop traversal — kept for direct-mitmproxy
    mode but not exercised on the production path.

    The attribution method is logged on every resolution so debugging
    is possible. A ``tagging.cache_miss`` debug event fires when Step
    0 is consulted but returns None — operator-requested observability
    hook for production store-effectiveness analysis.
    """
    # Step 0 — edge attribution store (production hot path).
    try:
        from mitmproxy import http  # type: ignore[import-untyped]

        if isinstance(flow, http.HTTPFlow) and flow.client_conn.peername:
            edge_src_port = flow.client_conn.peername[1]
            cached = attribution_store.lookup(edge_src_port)
            if cached is not None:
                log.info(
                    "tagging.resolved",
                    method="edge_store",
                    project=cached,
                    edge_src_port=edge_src_port,
                )
                # source_workdir is None for cache hits — recording the
                # original layer's cwd would require an attribution_log
                # schema migration. Tracked as a follow-up.
                return ResolvedProject(cached, "edge_store", None)
            # Operator-requested: emit a structured cache-miss event
            # so production observability can quantify the
            # fall-through rate.
            log.debug(
                "tagging.cache_miss",
                edge_src_port=edge_src_port,
            )
    except Exception as exc:  # pragma: no cover — defensive
        # Store lookup must never break the hot path.
        log.debug("tagging.edge_store_lookup_failed", error=str(exc))

    # Step 1 — HALTON_PROJECT env var (delegated to attribution.layers).
    sanitized_env = _layers.resolve_via_env(os.environ)
    if sanitized_env is not None:
        log.debug("tagging.resolved", method="env", project=sanitized_env)
        # env-var hit consults no cwd; source_workdir is None.
        return ResolvedProject(sanitized_env, "env", None)

    # Determine the originating process's working directory.
    #
    # If the lookup fails (psutil can't peer into the source process
    # — common for ``claude`` and other Mach-O binaries) we MUST NOT
    # fall back to ``os.getcwd()``. The daemon's own cwd under
    # launchd is ``~/.halton-meter``; using its basename produces
    # the bogus ``.halton-meter`` project name. Preserve cwd=None
    # for fallthrough to Step 7.5 (process heuristics). (v0.1.8 Gap 6.)
    try:
        cwd = _get_process_cwd(flow, edge_port=edge_port)
    except Exception as exc:
        log.debug("tagging.cwd_error", error=str(exc))
        cwd = None

    # Step 2 — .haltonrc walk (delegated to attribution.layers).
    # Only attempt if we have a valid cwd.
    if cwd is not None:
        rc_project = _read_haltonrc(cwd)
        if rc_project:
            sanitized = _sanitize_project_name(rc_project)
            log.debug("tagging.resolved", method="rcfile", project=sanitized, cwd=cwd)
            return ResolvedProject(sanitized, "rcfile", cwd)

    # Step 3 (IDE-args sniff) is edge-only — it needs ``proc.cmdline()``
    # which the daemon-side bypass path can't get to. Fall through.

    # Step 4 — git repo basename (PR2 2026-05-02; Option A locked,
    # never concatenates branch info). Only if we have a valid cwd.
    if cwd is not None:
        git_project = _layers.resolve_via_git(cwd)
        if git_project:
            log.debug("tagging.resolved", method="git", project=git_project, cwd=cwd)
            return ResolvedProject(git_project, "git", cwd)

    # Step 6 — Linux/Kubernetes container detection (PR2 2026-05-02;
    # gated on real container signals, never fires on a dev laptop).
    container_project = _layers.resolve_via_container(os.environ)
    if container_project:
        log.debug(
            "tagging.resolved",
            method="container",
            project=container_project,
            cwd=cwd,
        )
        return ResolvedProject(container_project, "container", cwd)

    # Step 6.5 — macOS sandbox bundle id (PR2 2026-05-02; pre-empts
    # the Layer 7 ``Data`` collapse for sandboxed Mac apps). Only if
    # we have a valid cwd.
    if cwd is not None:
        mac_project = _layers.resolve_via_mac_sandbox(cwd)
        if mac_project:
            log.debug(
                "tagging.resolved",
                method="mac_sandbox",
                project=mac_project,
                cwd=cwd,
            )
            return ResolvedProject(mac_project, "mac_sandbox", cwd)

    # Step 7 — workdir basename. Mirrors the original guard: emit the
    # ``method="workdir"`` log whenever the raw basename is truthy,
    # even if the sanitised value collapses to ``"unattributed"`` (a
    # cwd basename of ``"..."`` etc.). The slug normaliser lives in
    # :mod:`halton_meter.attribution.layers`. Only if we have a valid cwd.
    if cwd is not None:
        basename = Path(cwd).name
        if basename:
            sanitized = _sanitize_project_name(basename)
            log.debug("tagging.resolved", method="workdir", project=sanitized, cwd=cwd)
            return ResolvedProject(sanitized, "workdir", cwd)

    # Step 7.5 — process-based heuristics (v0.1.17, Issue #3). When
    # enabled via config, detect the originating process name and check
    # against process_mappings (e.g. 'claude' -> 'dev'). Reduces
    # unattributed traffic from known tools.
    if config is not None and config.tagging.enable_process_heuristics:
        proc_name = _get_process_name(flow, edge_port=edge_port)
        if proc_name and proc_name in config.tagging.process_mappings:
            mapped_project = config.tagging.process_mappings[proc_name]
            log.debug(
                "tagging.resolved",
                method="process_heuristics",
                project=mapped_project,
                process_name=proc_name,
                cwd=cwd,
            )
            return ResolvedProject(mapped_project, "process_heuristics", cwd)

    # Step 8 — smart default or unattributed. Use config's
    # default_project if provided, otherwise fall back to "misc".
    default = (config.tagging.default_project if config else None) or "misc"
    log.debug("tagging.resolved", method="smart_default", project=default, cwd=cwd)
    return ResolvedProject(default, "smart_default", cwd)
