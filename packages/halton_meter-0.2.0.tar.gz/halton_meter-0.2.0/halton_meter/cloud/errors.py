"""Typed exceptions for cloud sync.

The cloud worker's retry/pause logic dispatches on these types. Catching a
typed exception is the only sanctioned way to learn *why* a cloud call
failed — never inspect ``httpx.Response`` from outside ``client.py``.

Pause semantics (see ``client.CloudClient`` for the source of truth):

- :class:`CloudUnauthorised` (HTTP 401) → worker writes
  ``cloud_sync_state.paused_reason = 'paused_unauthorised'`` and stops.
  No automatic recovery; user must re-run ``halton-meter cloud connect``.
- :class:`CloudRateLimited` (HTTP 429) → caller honours
  :attr:`CloudRateLimited.retry_after_seconds` then retries.
- :class:`CloudTransport` (5xx, connect/read timeout, transport error) →
  caller applies exponential backoff capped at 5 minutes.
- :class:`CloudSchemaMismatch` (4xx other than 401/429) → caller surfaces
  to the user; usually means the daemon outran the cloud's wire-version
  acceptance (forward-compat rule violation). Not retried.
"""

from __future__ import annotations


class CloudError(Exception):
    """Base for all cloud-client typed exceptions."""


class CloudUnauthorised(CloudError):
    """HTTP 401 — token is invalid, revoked, or for a different endpoint.

    The worker MUST NOT retry. It MUST persist
    ``paused_reason='paused_unauthorised'`` to ``cloud_sync_state`` and
    stop the loop until the user re-pairs.
    """


class CloudRateLimited(CloudError):
    """HTTP 429 — caller must respect ``Retry-After`` then retry.

    Attributes:
        retry_after_seconds: Parsed ``Retry-After`` header (seconds). ``None``
            if the server omitted it; caller should fall back to its
            exponential backoff schedule capped at 5 minutes.
    """

    def __init__(self, message: str, retry_after_seconds: float | None = None) -> None:
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


class CloudTransport(CloudError):
    """Network / 5xx — retry with exponential backoff capped at 5 minutes.

    Wraps connect errors, read timeouts, and any 5xx status. The cloud is
    explicitly allowed to be transiently unreachable; the daemon proxy
    hot path is untouched while we wait.
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class CloudSchemaMismatch(CloudError):
    """4xx other than 401/429 — usually a wire-format / contract drift.

    Not retried automatically. Surface to the user via
    ``halton-meter cloud status`` so they can pin daemon/cloud versions.
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
