"""Cloud-config adapter — reads ``[cloud]`` keys from the existing config.

The Wave 1A.iii PR does **not** ship the ``[cloud]`` Pydantic submodel
(that's Wave 1A.i / 1A.ii territory). Until ``HaltonConfig.cloud`` lands
as a first-class nested model, this adapter reads the same keys via the
TOML file directly, with safe defaults.

Keys consumed (mirror of ``phase2-daemon-changes.md`` § 4):

- ``cloud.enabled``               — bool, default ``False``.
- ``cloud.base_url``              — str, default ``""``. Empty disables.
- ``cloud.continuous``            — bool, default ``True``.
- ``cloud.sync_interval_seconds`` — int, default ``30``.

Any other ``[cloud]`` keys (``token``, ``batch_size``, etc.) are out of
scope for the 1A.iii client surface and are read by other modules when
those waves land.

Wave 1A.i added a ``cloud_state`` table whose ``enabled`` column is the
runtime master switch. We treat the TOML file as the canonical source
for ``base_url``, ``continuous``, and ``sync_interval_seconds`` (operator
intent), but fall back to ``cloud_state.enabled`` when the TOML omits
``cloud.enabled`` so the CLI's ``cloud pause`` / ``cloud resume`` can
take effect without rewriting config.toml. The TOML value, when
explicitly set, still wins — operator intent overrides DB drift.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from halton_meter.cloud.privacy import (
    GATEABLE_FIELDS,
    ProjectRule,
    UploadPolicy,
    UploadPreset,
)
from halton_meter.config import HaltonConfig

_DEFAULT_CONFIG_PATH = Path("~/.halton-meter/config.toml").expanduser()


@dataclass(frozen=True)
class CloudClientConfig:
    """Subset of ``[cloud]`` the 1A.iii surface needs.

    Designed so future waves can extend this dataclass additively
    without touching client/worker code — every consumer treats unknown
    fields as opaque.
    """

    enabled: bool
    base_url: str
    continuous: bool
    sync_interval_seconds: int

    @property
    def is_active(self) -> bool:
        """True iff cloud sync should actually run.

        Both the master switch and a non-empty base URL must agree.
        Kept as a property so callers can write the intention
        (``if cfg.is_active``) rather than spell out the conjunction
        at every check site.
        """
        return self.enabled and bool(self.base_url)


def load_cloud_config(
    config: HaltonConfig | None = None,
    *,
    config_path: Path | None = None,
) -> CloudClientConfig:
    """Read the ``[cloud]`` block from the daemon config.

    Args:
        config: Reserved for the post-1A.i world where the cloud submodel
            lives on ``HaltonConfig`` directly. Currently unused — passed
            through so callers don't need to change when 1A.i lands.
        config_path: Override the TOML path. Defaults to
            ``~/.halton-meter/config.toml``. Tests pass an explicit path.

    Returns:
        A frozen :class:`CloudClientConfig` with defaults applied. Never
        raises for missing keys or a missing file — disabled is the safe
        default.
    """
    del config  # nested cloud submodel not yet on HaltonConfig
    raw = _read_cloud_block(config_path or _DEFAULT_CONFIG_PATH)
    base_url = _str(raw.get("base_url"), default="")

    # ``enabled`` resolution: TOML explicit value wins; if missing, look
    # up ``cloud_state.enabled`` for this endpoint. The DB read is
    # synchronous + fail-open: a locked / missing DB just falls through
    # to ``default=False``.
    if "enabled" in raw:
        enabled = _bool(raw.get("enabled"), default=False)
    else:
        enabled = _enabled_from_cloud_state(base_url)

    return CloudClientConfig(
        enabled=enabled,
        base_url=base_url,
        continuous=_bool(raw.get("continuous"), default=True),
        sync_interval_seconds=_int(raw.get("sync_interval_seconds"), default=30),
    )


def _enabled_from_cloud_state(endpoint: str) -> bool:
    """Read ``cloud_state.enabled`` for ``endpoint``. Fail-open False.

    Synchronous wrapper around the async ``StorageManager`` API — used
    only from the config-load path which is sync. Any failure (no DB,
    locked, row missing) returns ``False``: the safe default for a
    master switch is "off".
    """
    if not endpoint:
        return False
    try:
        import asyncio

        from halton_meter.config import load_config as _load_config
        from halton_meter.storage import StorageManager

        cfg = _load_config()

        async def _read() -> bool:
            async with StorageManager(cfg.storage.db_path) as storage:
                state = await storage.cloud_get_state(endpoint)
                return bool(state and state.enabled)

        try:
            return asyncio.run(_read())
        except RuntimeError:
            # Already inside an event loop — config-glue should not be
            # called from async code (it's a CLI startup path), so this
            # is a misuse rather than a real fallback; return False.
            return False
    except Exception:
        return False


def _read_cloud_block(path: Path) -> dict[str, Any]:
    """Best-effort TOML read of the ``[cloud]`` table.

    Returns an empty dict if the file or the ``[cloud]`` table is
    missing. Read errors (permission denied, broken TOML) propagate —
    those are not "cloud is disabled", those are "something is wrong
    with the user's box" and the daemon should surface them.
    """
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        data = tomllib.load(fh)
    block = data.get("cloud", {})
    return block if isinstance(block, dict) else {}


def _bool(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def _str(value: Any, *, default: str) -> str:
    if value is None:
        return default
    return str(value)


def _int(value: Any, *, default: int) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


# ─── Upload-privacy policy ──────────────────────────────────────────────────


def load_upload_policy(
    *, config_path: Path | None = None
) -> UploadPolicy:
    """Read the ``[cloud.upload]`` block and resolve into an :class:`UploadPolicy`.

    Returns the v0.2.0 default policy if the file or the block is absent,
    or if any value is malformed beyond recovery. Privacy-by-default means
    erring toward the more-redacting choice on ambiguity.
    """
    block = _read_upload_block(config_path or _DEFAULT_CONFIG_PATH)
    if not block:
        return UploadPolicy.default()

    preset = _parse_preset(block.get("preset"))

    field_overrides: dict[str, bool] = {}
    fields_raw = block.get("fields")
    if isinstance(fields_raw, dict):
        for name, value in fields_raw.items():
            if name in GATEABLE_FIELDS:
                field_overrides[name] = _bool(value, default=False)

    per_project: dict[str, ProjectRule] = {}
    pp_raw = block.get("per_project")
    if isinstance(pp_raw, dict):
        for project_name, project_block in pp_raw.items():
            if not isinstance(project_block, dict):
                continue
            upload = _bool(project_block.get("upload"), default=True)
            rule_fields: dict[str, bool] = {}
            rf_raw = project_block.get("fields")
            if isinstance(rf_raw, dict):
                for name, value in rf_raw.items():
                    if name in GATEABLE_FIELDS:
                        rule_fields[name] = _bool(value, default=False)
            per_project[str(project_name)] = ProjectRule(
                upload=upload, fields=rule_fields
            )

    return UploadPolicy(
        preset=preset,
        field_overrides=field_overrides,
        per_project=per_project,
    )


def _parse_preset(value: Any) -> UploadPreset:
    """Resolve preset name → enum. Unknown values fall back to ``standard``."""
    if isinstance(value, str):
        try:
            return UploadPreset(value.strip().lower())
        except ValueError:
            return UploadPreset.standard
    return UploadPreset.standard


def _read_upload_block(path: Path) -> dict[str, Any]:
    """Best-effort TOML read of ``[cloud.upload]``. Empty dict on absence."""
    if not path.exists():
        return {}
    try:
        with path.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        # Privacy-by-default: a broken TOML returns "no overrides" which
        # collapses to the standard preset — the safer default than
        # surfacing a parse error and proceeding with whatever the caller
        # had cached.
        return {}
    cloud_block = data.get("cloud", {})
    if not isinstance(cloud_block, dict):
        return {}
    upload_block = cloud_block.get("upload", {})
    return upload_block if isinstance(upload_block, dict) else {}
