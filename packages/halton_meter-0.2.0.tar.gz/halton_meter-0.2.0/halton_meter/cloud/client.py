"""Async HTTP client for the halton-meter-cloud SaaS (Wave 1A.iii).

Single-process ``httpx.AsyncClient`` with its **own connection pool** —
separate from anything mitmproxy / the edge / fastapi touch. The cloud
endpoint can be slow, broken, or unreachable for hours and the proxy
hot path must not feel it.

Contract pinned to ``memory/plans/phase2-wire-contract.md`` SHA
``e8f252a``.

Retry policy (matches phase2-daemon-changes.md § 2a + § 2b):

- Transport errors (connect failures, read timeouts, ``httpx.HTTPError``
  outside response status) → exponential backoff capped at 300 seconds.
- 5xx → same exponential backoff schedule. Status preserved on the
  exception.
- 429 → honour ``Retry-After`` if present, else fall through to
  exponential backoff capped at 300 seconds.
- 401 → :class:`~halton_meter.cloud.errors.CloudUnauthorised`. **No
  retry.** Caller is expected to set
  ``cloud_state.paused_reason = 'paused_unauthorised'`` and stop the
  worker; recovery requires the user re-running ``cloud connect``.
- 4xx (other) → :class:`~halton_meter.cloud.errors.CloudSchemaMismatch`.
  Not retried.

Auth: bearer token. The token is **fetched lazily per request** from
the supplied ``token_provider`` callable. Tokens are stored encrypted
at rest in ``cloud_state`` (Wave 1A.i). Until that PR merges we use a
TODO-stubbed reader; ``token_provider`` accepts any callable returning
``str | None`` so tests inject directly without touching state.
"""

from __future__ import annotations

import asyncio
import logging
import random
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

import httpx

from halton_meter.cloud.errors import (
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)

logger = logging.getLogger(__name__)

# Retry schedule envelope. Per-call retries hit the cap quickly; the
# worker loop is the long-running retry surface and its own scheduling
# layers another envelope on top. These constants are intentionally
# module-level so tests can monkeypatch them to zero for fast runs.
INITIAL_BACKOFF_SECONDS = 1.0
BACKOFF_MULTIPLIER = 2.0
MAX_BACKOFF_SECONDS = 300.0  # 5 minutes — cardinal cap from spec.
MAX_RETRIES = 8  # 1, 2, 4, 8, 16, 32, 64, 128 → capped at 300.

# Default timeouts. Connect short, read longer to accommodate large
# batch round-trips. Numbers chosen in plan doc § 2a.
DEFAULT_CONNECT_TIMEOUT = 30.0
DEFAULT_READ_TIMEOUT = 60.0


TokenProvider = Callable[[], str | None]


def _stub_token_provider() -> str | None:
    """Default token reader.

    Resolution order (wire contract § 6):

    1. ``~/.halton-meter/cloud-credentials.json`` (chmod 0600). This is
       the **primary** store — kept first for backwards-compat with
       bootstrap scripts that wrote the file directly.
    2. ``cloud_state.api_key_ciphertext`` — defence-in-depth mirror,
       Fernet-encrypted at rest. Decrypted lazily via
       :mod:`halton_meter.storage.cloud_crypto`.

    Any failure (file missing, DB locked, ciphertext corrupt) returns
    ``None`` rather than raising — the CloudClient surfaces a clean
    ``CloudUnauthorised`` so the worker pauses gracefully.
    """
    # 1. Primary: the 0600 file.
    try:
        import json as _json
        from pathlib import Path as _Path

        cred_path = _Path("~/.halton-meter/cloud-credentials.json").expanduser()
        if cred_path.exists():
            payload = _json.loads(cred_path.read_text())
            api_key = payload.get("api_key")
            if api_key:
                return str(api_key)
    except Exception as exc:
        logger.debug("cloud.credentials_file_read_failed: %s", exc)

    # 2. Fallback: the encrypted cloud_state row.
    try:
        import asyncio as _asyncio

        from halton_meter.config import load_config
        from halton_meter.storage import StorageManager
        from halton_meter.storage.cloud_crypto import decrypt_api_key

        cfg = load_config()

        async def _read() -> str | None:
            async with StorageManager(cfg.storage.db_path) as storage:
                # Iterate every endpoint and return the first one with a
                # ciphertext. Today there's exactly one row in practice;
                # this stays correct for a future multi-endpoint world.
                async with storage._sessionmaker() as session:  # type: ignore[union-attr]
                    from sqlalchemy import select as _select

                    from halton_meter.storage.models import CloudState

                    result = await session.execute(_select(CloudState))
                    for row in result.scalars():
                        if row.api_key_ciphertext:
                            try:
                                return decrypt_api_key(row.api_key_ciphertext)
                            except Exception:
                                continue
            return None

        try:
            return _asyncio.run(_read())
        except RuntimeError:
            # Already inside an event loop — caller (e.g. CloudClient
            # used from async code) should pass an explicit
            # token_provider. Falling through to None matches the
            # documented stub contract.
            return None
    except Exception as exc:
        logger.debug("cloud.state_token_read_failed: %s", exc)
        return None


class CloudClient:
    """Async HTTP client for the cloud endpoints.

    A single instance is constructed by the daemon (or by tests with a
    ``MockTransport``). Instances are async-context-managed; ``async
    with CloudClient(...) as c:`` is the only sanctioned lifetime.
    """

    def __init__(
        self,
        base_url: str,
        *,
        token_provider: TokenProvider | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout: httpx.Timeout | None = None,
        user_agent: str = "halton-meter-daemon",
    ) -> None:
        """Construct the client. No I/O happens here.

        Args:
            base_url: Cloud root URL, e.g. ``https://meter.haltonlabs.io``.
                Trailing slash tolerated.
            token_provider: Zero-arg callable returning the bearer token
                string, or ``None`` if no token is configured.
                Defaulted to the 1A.i stub.
            transport: Optional ``httpx.AsyncBaseTransport`` — primary
                use is ``httpx.MockTransport`` in tests. Production
                callers leave this ``None``.
            timeout: Optional override; defaults to (30s connect, 60s
                read) per the plan doc.
            user_agent: Header value. Lets the cloud distinguish daemon
                versions when investigating issues.
        """
        self._base_url = base_url.rstrip("/")
        self._token_provider = token_provider or _stub_token_provider
        self._timeout = timeout or httpx.Timeout(
            connect=DEFAULT_CONNECT_TIMEOUT,
            read=DEFAULT_READ_TIMEOUT,
            write=DEFAULT_READ_TIMEOUT,
            pool=DEFAULT_CONNECT_TIMEOUT,
        )
        self._transport = transport
        self._user_agent = user_agent
        self._http: httpx.AsyncClient | None = None
        # Used by the CLI ``cloud connect`` flow to override the
        # token-provider callback once pairing returns the key.
        self._explicit_token: str | None = None

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> CloudClient:
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
            transport=self._transport,
            headers={"user-agent": self._user_agent},
        )
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    def set_token(self, token: str | None) -> None:
        """Override the token-provider with a fixed value.

        Used by the pairing CLI flow once ``cloud/pairing/poll`` returns
        the single-shot ``api_key``. The override beats the
        ``token_provider`` callback.
        """
        self._explicit_token = token

    # ------------------------------------------------------------------ #
    # Public endpoints (1:1 with the wire contract endpoint table)
    # ------------------------------------------------------------------ #

    async def pairing_start(
        self,
        *,
        hostname: str,
        daemon_version: str,
        platform: str,
    ) -> dict[str, Any]:
        """POST /v1/pairing/start. Returns the cloud's pairing payload."""
        return await self._request(
            "POST",
            "/v1/pairing/start",
            json={
                "hostname": hostname,
                "daemon_version": daemon_version,
                "platform": platform,
            },
            authenticated=False,
        )

    async def pairing_poll(
        self,
        *,
        pairing_code: str,
        poll_token: str,
    ) -> dict[str, Any]:
        """POST /v1/pairing/poll. Caller polls until terminal status."""
        return await self._request(
            "POST",
            "/v1/pairing/poll",
            json={"pairing_code": pairing_code, "poll_token": poll_token},
            authenticated=False,
        )

    async def whoami(self) -> dict[str, Any]:
        """GET /v1/daemon/whoami. Requires the bearer token."""
        return await self._request("GET", "/v1/daemon/whoami")

    async def disconnect(self) -> dict[str, Any]:
        """DELETE /v1/daemon/disconnect. Revokes this key cloud-side."""
        return await self._request("DELETE", "/v1/daemon/disconnect")

    async def batch_ingest(
        self,
        *,
        batch_id: str,
        records: Iterable[dict[str, Any]],
    ) -> dict[str, Any]:
        """POST /v1/requests/batch. Returns the ``BatchAck`` dict.

        ``records`` is an iterable of pre-serialised
        :func:`halton_meter.cloud.serialize.log_record_to_wire` dicts.
        Idempotency is on ``batch_id`` (UUIDv4) and on the per-record
        ``id``. Safe to re-post on transient failure.
        """
        # Materialise upfront so we can include length in retry logs and
        # so the iterable can't be exhausted by a half-completed request.
        payload_records = list(records)
        return await self._request(
            "POST",
            "/v1/requests/batch",
            json={"batch_id": batch_id, "records": payload_records},
        )

    async def reconciliation_totals(
        self,
        *,
        date_from: str,
        date_to: str,
        machine_id: str | None = None,
    ) -> dict[str, Any]:
        """GET /v1/reconciliation/daemon-totals.

        Args:
            date_from: ISO-8601 UTC date or datetime; the cloud accepts
                either. The Wave-0 contract leaves the exact precision
                up to the caller because pre-Wave-1B the endpoint is a
                501 stub.
            date_to: Inclusive upper bound. Same precision rules.
            machine_id: Optional scope filter. Daemons that have
                completed pairing know their machine_id from the
                pairing payload.
        """
        params: dict[str, str] = {"from": date_from, "to": date_to}
        if machine_id is not None:
            params["machine_id"] = machine_id
        return await self._request(
            "GET",
            "/v1/reconciliation/daemon-totals",
            params=params,
        )

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, str] | None = None,
        authenticated: bool = True,
    ) -> dict[str, Any]:
        """Issue one request with retry envelope. Returns parsed JSON.

        Raises a typed exception from
        :mod:`halton_meter.cloud.errors` on terminal failure.
        """
        if self._http is None:
            raise RuntimeError(
                "CloudClient used outside its async context manager — "
                "wrap calls in `async with CloudClient(...) as c:`."
            )

        headers: dict[str, str] = {}
        if authenticated:
            token = self._current_token()
            if not token:
                # Unauthorised before we even reach the wire. Surface as
                # the same exception type the cloud would emit on 401 —
                # the worker's pause path handles both identically.
                raise CloudUnauthorised(
                    "No cloud token configured; run `halton-meter cloud connect`."
                )
            headers["authorization"] = f"Bearer {token}"

        attempt = 0
        backoff = INITIAL_BACKOFF_SECONDS
        last_exc: Exception | None = None
        while attempt <= MAX_RETRIES:
            attempt += 1
            try:
                response = await self._http.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    headers=headers,
                )
            except httpx.HTTPError as exc:
                # Transport-level failure — connect refused, read
                # timeout, etc. Always retryable up to MAX_RETRIES.
                last_exc = CloudTransport(f"{method} {path}: {exc!r}")
                logger.warning(
                    "cloud.transport_error",
                    extra={"method": method, "path": path, "attempt": attempt},
                )
                if attempt > MAX_RETRIES:
                    raise last_exc from exc
                await _sleep_with_jitter(backoff)
                backoff = min(backoff * BACKOFF_MULTIPLIER, MAX_BACKOFF_SECONDS)
                continue

            # 401 — no retry, terminal pause signal.
            if response.status_code == 401:
                raise CloudUnauthorised(
                    f"{method} {path}: cloud rejected token (401)."
                )

            # 429 — honour Retry-After then retry, else fall through to
            # the exponential schedule (capped at MAX_BACKOFF).
            if response.status_code == 429:
                retry_after = _parse_retry_after(response.headers.get("retry-after"))
                last_exc = CloudRateLimited(
                    f"{method} {path}: 429",
                    retry_after_seconds=retry_after,
                )
                if attempt > MAX_RETRIES:
                    raise last_exc
                sleep_for = (
                    min(retry_after, MAX_BACKOFF_SECONDS)
                    if retry_after is not None
                    else backoff
                )
                await _sleep_with_jitter(sleep_for)
                backoff = min(backoff * BACKOFF_MULTIPLIER, MAX_BACKOFF_SECONDS)
                continue

            # 5xx — same retry envelope as transport failures.
            if 500 <= response.status_code < 600:
                last_exc = CloudTransport(
                    f"{method} {path}: {response.status_code}",
                    status_code=response.status_code,
                )
                if attempt > MAX_RETRIES:
                    raise last_exc
                await _sleep_with_jitter(backoff)
                backoff = min(backoff * BACKOFF_MULTIPLIER, MAX_BACKOFF_SECONDS)
                continue

            # 4xx (other) — terminal. Surface to caller, don't retry.
            if 400 <= response.status_code < 500:
                raise CloudSchemaMismatch(
                    f"{method} {path}: {response.status_code} {response.text[:200]}",
                    status_code=response.status_code,
                )

            # 2xx — done. Parse JSON defensively (some endpoints, like
            # disconnect, may legally return 204).
            if response.status_code == 204 or not response.content:
                return {}
            try:
                return response.json()
            except ValueError as exc:
                raise CloudSchemaMismatch(
                    f"{method} {path}: non-JSON response body"
                ) from exc

        # Loop guard — should be unreachable because every branch above
        # either returns, raises, or continues to the next attempt.
        assert last_exc is not None
        raise last_exc

    def _current_token(self) -> str | None:
        """Return the active bearer token, or ``None``.

        Resolution order: explicit override (``set_token``), then the
        configured ``token_provider``. The override path is what the
        pairing-CLI flow uses after ``pairing_poll`` returns the
        single-shot key.
        """
        if self._explicit_token is not None:
            return self._explicit_token
        return self._token_provider()


# ---------------------------------------------------------------------- #
# Small helpers — module-level so tests can monkeypatch them.
# ---------------------------------------------------------------------- #


async def _sleep_with_jitter(seconds: float) -> None:
    """Sleep with up to 20% jitter to avoid synchronised retries.

    A monkeypatchable hook: tests replace this with ``async def
    no_sleep(_): return None`` to keep retry-logic tests fast.
    """
    jitter = seconds * 0.2 * random.random()
    await asyncio.sleep(seconds + jitter)


def _parse_retry_after(header_value: str | None) -> float | None:
    """Parse the ``Retry-After`` header as seconds, or ``None``.

    Only the delta-seconds form is supported — HTTP-date form is
    extremely rare for API rate limiting and the cost of full RFC 7231
    parsing isn't worth it. Unparseable values fall through to the
    exponential schedule.
    """
    if header_value is None:
        return None
    try:
        value = float(header_value.strip())
    except (TypeError, ValueError):
        return None
    if value < 0:
        return None
    return value


__all__ = [
    "BACKOFF_MULTIPLIER",
    "INITIAL_BACKOFF_SECONDS",
    "MAX_BACKOFF_SECONDS",
    "MAX_RETRIES",
    "CloudClient",
    "TokenProvider",
]


# Allow tests / callers to await a no-op sleep helper. Re-export so the
# module-level ``_sleep_with_jitter`` symbol is patchable without
# touching name-mangled private internals.
async def _no_sleep(_: float) -> None:  # pragma: no cover - dev helper
    return None


# Worker imports use ``Awaitable`` from typing.collections; keep the
# alias re-export light to avoid pulling typing-heavy machinery into the
# hot import path.
_WorkerSleep = Callable[[float], Awaitable[None]]
