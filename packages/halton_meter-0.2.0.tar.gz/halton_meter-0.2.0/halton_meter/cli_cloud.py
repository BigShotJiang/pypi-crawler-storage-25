"""``halton-meter cloud`` CLI surface (Wave 1A.iii).

Surfaces:

- ``halton-meter cloud connect``    — pairing flow, end-to-end.
- ``halton-meter cloud disconnect`` — revoke key + clear local state.
- ``halton-meter cloud status``     — local sync visibility.
- ``halton-meter cloud whoami``     — echo cloud-bound workspace.
- ``halton-meter cloud sync``       — single drain pass and exit.
- ``halton-meter cloud reconcile``  — daemon ↔ cloud totals diff.
- ``halton-meter cloud pause``      — set paused_reason='paused_manual'.
- ``halton-meter cloud resume``     — clear paused_reason.

Plus the top-level alias ``halton-meter sync``.

This module is imported and wired by ``halton_meter.cli`` at the bottom
of that file. Kept separate to keep ``cli.py`` from growing further
(it's already 130k+).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform as _platform
import socket
import sys
import time
import tomllib
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from sqlalchemy import func, select

from halton_meter import __version__
from halton_meter.cli_runtime import configure_for_user_cli
from halton_meter.cloud.client import CloudClient
from halton_meter.cloud.config_glue import load_cloud_config, load_upload_policy
from halton_meter.cloud.errors import (
    CloudRateLimited,
    CloudSchemaMismatch,
    CloudTransport,
    CloudUnauthorised,
)
from halton_meter.cloud.privacy import (
    GATEABLE_FIELDS,
    UploadPreset,
    describe,
)
from halton_meter.cloud.worker import (
    run_once,
)
from halton_meter.config import load_config
from halton_meter.storage import StorageManager
from halton_meter.storage.models import CloudState, CloudSyncState, Request

console = Console()
logger = logging.getLogger(__name__)

# Backwards-compat 0600 credentials file. Wire contract § 6 names it the
# primary source for the token; the encrypted ``cloud_state`` row is the
# defence-in-depth mirror. Kept JSON-shaped so a future v0.3 introspector
# can read it without importing daemon code.
CLOUD_CREDENTIALS_PATH = Path("~/.halton-meter/cloud-credentials.json").expanduser()
_CRED_FILE_MODE = 0o600


# Exit codes — mirror what the existing CLI commands return so tooling
# can interpret them consistently. See phase2-daemon-changes.md § 3.
EXIT_OK = 0
EXIT_PARTIAL = 1  # retryable / unhealthy / within tolerance
EXIT_UNAUTH = 2   # 401 path — user must re-run ``cloud connect``.


# ---------------------------------------------------------------------- #
# State persistence — backs the CLI commands with real ``cloud_state``
# and ``cloud_sync_state`` rows. Wave 1A.i provided the storage tables;
# this module's job is to drive them.
# ---------------------------------------------------------------------- #


def _resolved_db_path() -> str:
    """Resolve the SQLite path the daemon writes to.

    Mirrors the resolution rule used by ``halton-meter report`` so the
    CLI and the daemon process always land on the same file.
    """
    cfg = load_config()
    return cfg.storage.db_path


def _resolved_endpoint() -> str:
    """The cloud endpoint URL keyed in ``cloud_state``/``cloud_sync_state``.

    Returns an empty string when no endpoint is configured — callers
    decide whether that should be fail-open (status, disconnect) or
    fail-loud (connect, sync).
    """
    cfg = load_cloud_config()
    return cfg.base_url or ""


def _write_credentials_file(payload: dict[str, Any]) -> None:
    """Write the 0600 ``cloud-credentials.json`` file atomically.

    The file is the primary token-source per the wire contract; the DB
    ciphertext is the mirror. Failure here is logged but not raised —
    pairing still succeeds against the DB row, and the user can re-run
    ``cloud connect`` to refresh.
    """
    try:
        CLOUD_CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = CLOUD_CREDENTIALS_PATH.with_suffix(".tmp")
        # Owner-only mode from creation to avoid a window where the file
        # is world-readable.
        fd = os.open(str(tmp), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, _CRED_FILE_MODE)
        try:
            os.write(fd, json.dumps(payload).encode("utf-8"))
        finally:
            os.close(fd)
        os.replace(tmp, CLOUD_CREDENTIALS_PATH)
        # Belt-and-braces: re-chmod in case the umask weakened it.
        try:
            CLOUD_CREDENTIALS_PATH.chmod(_CRED_FILE_MODE)
        except OSError:
            pass
    except OSError as exc:
        logger.warning("cloud.credentials_file_write_failed: %s", exc)


def _remove_credentials_file() -> None:
    """Best-effort wipe of the 0600 credentials file."""
    try:
        CLOUD_CREDENTIALS_PATH.unlink(missing_ok=True)
    except OSError as exc:
        logger.warning("cloud.credentials_file_remove_failed: %s", exc)


def _write_cloud_state_token(token: str, payload: dict[str, Any]) -> None:
    """Persist the pairing payload + token to ``cloud_state`` + 0600 file.

    Wire contract § 6: token never logged. We encrypt at rest via Fernet
    (handled inside ``StorageManager.cloud_set_state``) and the 0600 JSON
    file remains the primary source for backwards-compat with prior
    bootstrap scripts.
    """
    endpoint = payload.get("base_url") or _resolved_endpoint()
    if not endpoint:
        logger.warning("cloud.connect.no_endpoint")
        return

    # 0600 file first — it's the primary store per the contract. If the
    # DB write fails afterwards, the next ``cloud connect`` can still
    # recover by reading the file.
    _write_credentials_file(
        {
            "endpoint": endpoint,
            "api_key": token,
            "workspace_id": payload.get("workspace_id"),
            "workspace_name": payload.get("workspace_name"),
            "machine_id": payload.get("machine_id"),
        }
    )

    async def _persist() -> None:
        async with StorageManager(_resolved_db_path()) as storage:
            await storage.cloud_set_state(
                endpoint=endpoint,
                api_key_plaintext=token,
                workspace_id=payload.get("workspace_id"),
                workspace_name=payload.get("workspace_name"),
                machine_id=payload.get("machine_id"),
                hostname_reported=socket.gethostname(),
                base_url=endpoint,
                enabled=True,
                connected_at=datetime.now(tz=UTC),
                # Clearing any previous ``paused_*`` so a re-pair after a
                # 401-paused state resumes cleanly.
                paused_reason=None,
            )

    try:
        asyncio.run(_persist())
    except Exception as exc:
        # Cardinal: never crash the CLI on a DB hiccup. The 0600 file
        # already holds the token so the user is not stranded.
        logger.warning("cloud.state_write_failed: %s", exc)


def _clear_cloud_state_token() -> None:
    """Wipe local cloud token + workspace cache. Fail-open.

    Called by ``cloud disconnect``. Both the 0600 file and the DB column
    are NULLed out; the audit row is preserved so ``cloud status`` can
    still answer "you used to be paired with X".
    """
    endpoint = _resolved_endpoint()
    _remove_credentials_file()

    if not endpoint:
        return

    async def _persist() -> None:
        async with StorageManager(_resolved_db_path()) as storage:
            await storage.cloud_set_state(
                endpoint=endpoint,
                clear_api_key=True,
                enabled=False,
                paused_reason="disconnected",
            )

    try:
        asyncio.run(_persist())
    except Exception as exc:
        logger.warning("cloud.state_clear_failed: %s", exc)


def _set_cloud_enabled(enabled: bool, *, paused_reason: str | None) -> None:
    """Flip the ``cloud_state.enabled`` master switch + paused_reason.

    Used by ``cloud pause`` (``enabled=False, paused_reason='paused_manual'``)
    and ``cloud resume`` (``enabled=True, paused_reason=None``). The worker
    reads both columns on each tick.
    """
    endpoint = _resolved_endpoint()
    if not endpoint:
        return

    async def _persist() -> None:
        async with StorageManager(_resolved_db_path()) as storage:
            # ``cloud_set_state``'s contract is "None means don't touch".
            # Resume needs to *explicitly* NULL ``paused_reason``; we use
            # the sentinel ``""`` and translate to NULL via a direct SQL
            # update because the upsert helper treats None as no-op.
            await storage.cloud_set_state(
                endpoint=endpoint,
                enabled=enabled,
                paused_reason=paused_reason,
            )
            if paused_reason is None and enabled:
                # Explicitly NULL paused_reason on resume.
                async with storage._sessionmaker() as session, session.begin():  # type: ignore[union-attr]
                    state = await session.get(CloudState, endpoint)
                    if state is not None:
                        state.paused_reason = None

    try:
        asyncio.run(_persist())
    except Exception as exc:
        logger.warning("cloud.enabled_flip_failed: %s", exc)


async def _record_sync_failure(error: str, *, paused_reason: str | None = None) -> None:
    """Bump ``consecutive_failures`` and write ``last_error`` on a sync error.

    Called from the sync command's exception handler so transient
    transport errors keep a counter the operator can see in
    ``cloud status``. ``paused_reason`` is set when the failure is
    terminal (401).
    """
    endpoint = _resolved_endpoint()
    if not endpoint:
        return

    try:
        async with StorageManager(_resolved_db_path()) as storage:
            async with storage._sessionmaker() as session, session.begin():  # type: ignore[union-attr]
                state = await session.get(CloudSyncState, endpoint)
                if state is None:
                    state = CloudSyncState(
                        endpoint=endpoint,
                        consecutive_failures=1,
                        last_error=error[:512],
                        paused_reason=paused_reason,
                    )
                    session.add(state)
                else:
                    state.consecutive_failures = (state.consecutive_failures or 0) + 1
                    state.last_error = error[:512]
                    state.last_batch_attempted_at = datetime.now(tz=UTC)
                    if paused_reason is not None:
                        state.paused_reason = paused_reason
            # Mirror paused_reason onto cloud_state when terminal so
            # ``cloud status`` reads the same story from either table.
            if paused_reason is not None:
                await storage.cloud_set_state(
                    endpoint=endpoint, paused_reason=paused_reason
                )
    except Exception as exc:
        logger.warning("cloud.sync_failure_record_failed: %s", exc)


# ---------------------------------------------------------------------- #
# Click group + commands.
# ---------------------------------------------------------------------- #


@click.group(name="cloud")
def cloud_group() -> None:
    """Manage the link to the halton-meter-cloud SaaS."""
    configure_for_user_cli()


@cloud_group.command(name="connect")
@click.option(
    "--base-url",
    default=None,
    help="Cloud root URL. Defaults to the value of [cloud].base_url in config.",
)
@click.option(
    "--poll-interval-seconds",
    default=2.0,
    show_default=True,
    help="How often to poll /v1/pairing/poll while waiting for approval.",
)
@click.option(
    "--timeout-seconds",
    default=600.0,
    show_default=True,
    help="Hard cap on the total pairing wall-clock time.",
)
def cloud_connect_cmd(
    base_url: str | None,
    poll_interval_seconds: float,
    timeout_seconds: float,
) -> None:
    """Run the device-pairing flow end-to-end.

    Sequence (per wire contract § 4):

    1. ``POST /v1/pairing/start`` → cloud returns a pairing code +
       opaque ``poll_token``.
    2. Print the code + pairing URL to the user's terminal.
    3. Poll ``POST /v1/pairing/poll`` every ``poll_interval_seconds``
       until terminal status (``approved`` / ``denied`` / ``expired`` /
       ``consumed``).
    4. On ``approved``: persist the single-shot ``api_key`` to
       ``cloud_state`` and flip ``cloud.enabled = true``.
    """
    cfg = load_cloud_config()
    url = base_url or cfg.base_url
    if not url:
        console.print(
            "[red]No cloud base URL configured. Pass --base-url or set "
            "[cloud].base_url in ~/.halton-meter/config.toml.[/red]"
        )
        sys.exit(EXIT_PARTIAL)

    try:
        result = asyncio.run(
            _run_pairing_flow(
                base_url=url,
                poll_interval_seconds=poll_interval_seconds,
                timeout_seconds=timeout_seconds,
            )
        )
    except CloudUnauthorised as exc:
        console.print(f"[red]Pairing rejected by cloud: {exc}[/red]")
        sys.exit(EXIT_UNAUTH)
    except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
        console.print(f"[red]Pairing failed: {exc}[/red]")
        sys.exit(EXIT_PARTIAL)

    if result.get("status") != "approved":
        console.print(f"[yellow]Pairing ended in status {result.get('status')!r}.[/yellow]")
        sys.exit(EXIT_PARTIAL)

    console.print(
        f"[green]Paired with workspace {result.get('workspace_name')!r} "
        f"(machine_id={result.get('machine_id')}).[/green]"
    )
    # Persist token + DB state. The helper writes the 0600 file + the
    # encrypted cloud_state row and flips enabled=True.
    _write_cloud_state_token(result["api_key"], {**result, "base_url": url})


async def _run_pairing_flow(
    *,
    base_url: str,
    poll_interval_seconds: float,
    timeout_seconds: float,
) -> dict[str, Any]:
    """Drive the pairing handshake against ``base_url``.

    Split out from the Click callback so tests can call it directly
    against a ``httpx.MockTransport``.
    """
    deadline = time.monotonic() + timeout_seconds
    async with CloudClient(base_url=base_url) as client:
        start = await client.pairing_start(
            hostname=socket.gethostname(),
            daemon_version=__version__,
            platform=_platform.system(),
        )
        pairing_code = start["pairing_code"]
        poll_token = start["poll_token"]
        console.print(
            "[bold]Pairing code:[/bold] "
            f"[cyan]{pairing_code}[/cyan]\n"
            f"Open: {start.get('pairing_url', '(see dashboard)')}"
        )

        while True:
            if time.monotonic() > deadline:
                raise CloudTransport("pairing timed out before terminal status")
            polled = await client.pairing_poll(
                pairing_code=pairing_code,
                poll_token=poll_token,
            )
            status = polled.get("status")
            if status in ("approved", "denied", "expired", "consumed"):
                return polled
            await asyncio.sleep(poll_interval_seconds)


@cloud_group.command(name="disconnect")
def cloud_disconnect_cmd() -> None:
    """Revoke the current token cloud-side and clear local state."""
    cfg = load_cloud_config()
    if not cfg.base_url:
        # No cloud configured — nothing to do, but exit clean so the
        # command is idempotent in scripts.
        _clear_cloud_state_token()
        console.print("[yellow]No cloud configured; cleared any local state.[/yellow]")
        return

    async def _run() -> None:
        async with CloudClient(base_url=cfg.base_url) as client:
            try:
                await client.disconnect()
            except CloudUnauthorised:
                # Already disconnected as far as the cloud is concerned.
                pass

    try:
        asyncio.run(_run())
    except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
        console.print(f"[yellow]Cloud-side disconnect best-effort failed: {exc}[/yellow]")
    finally:
        _clear_cloud_state_token()
        console.print("[green]Disconnected.[/green]")


@cloud_group.command(name="status")
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON.")
def cloud_status_cmd(as_json: bool) -> None:
    """Print local cloud-sync state from config + DB.

    Reads ``cloud_state`` (auth visibility) and ``cloud_sync_state``
    (cursor + failure counters) and counts unsynced records past the
    cursor. Falls back to a config-only payload if the DB read fails.
    """
    cfg = load_cloud_config()
    endpoint = cfg.base_url or ""
    payload: dict[str, Any] = {
        "enabled": cfg.enabled,
        "base_url": cfg.base_url,
        "continuous": cfg.continuous,
        "sync_interval_seconds": cfg.sync_interval_seconds,
        "is_active": cfg.is_active,
        # DB-backed fields — populated below. Default to None so the JSON
        # shape is stable even when the DB is missing.
        "workspace_id": None,
        "workspace_name": None,
        "machine_id": None,
        "paused_reason": None,
        "last_error": None,
        "last_synced_request_recorded_at": None,
        "last_batch_succeeded_at": None,
        "consecutive_failures": 0,
        "unsynced_record_count": 0,
    }

    if endpoint:
        try:
            payload.update(asyncio.run(_load_status_payload(endpoint)))
        except Exception as exc:  # fail-open: never crash the CLI on DB hiccups
            logger.warning("cloud.status_db_read_failed: %s", exc)

    if as_json:
        click.echo(json.dumps(payload, indent=2, default=str))
    else:
        console.print(payload)
    sys.exit(EXIT_OK if cfg.is_active else EXIT_PARTIAL)


async def _load_status_payload(endpoint: str) -> dict[str, Any]:
    """Read both Phase-2 cloud tables plus the unsynced-row count.

    Split out so tests can call it directly against a tmp DB. The shape
    matches the keys the status command merges into its payload dict.
    """
    out: dict[str, Any] = {}
    async with StorageManager(_resolved_db_path()) as storage:
        state = await storage.cloud_get_state(endpoint)
        if state is not None:
            out["enabled"] = bool(state.enabled)
            out["workspace_id"] = state.workspace_id
            out["workspace_name"] = state.workspace_name
            out["machine_id"] = state.machine_id
            # cloud_state.paused_reason wins over cloud_sync_state's copy
            # when set — it's the one ``cloud pause`` writes.
            if state.paused_reason is not None:
                out["paused_reason"] = state.paused_reason
            if state.last_error is not None:
                out["last_error"] = state.last_error

        sync_state = await storage.cloud_get_sync_state(endpoint)
        cursor_at: datetime | None = None
        cursor_id: str = ""
        if sync_state is not None:
            out["last_synced_request_recorded_at"] = (
                sync_state.last_synced_request_recorded_at.isoformat()
                if sync_state.last_synced_request_recorded_at
                else None
            )
            out["last_batch_succeeded_at"] = (
                sync_state.last_batch_succeeded_at.isoformat()
                if sync_state.last_batch_succeeded_at
                else None
            )
            out["consecutive_failures"] = int(sync_state.consecutive_failures or 0)
            if sync_state.paused_reason and not out.get("paused_reason"):
                out["paused_reason"] = sync_state.paused_reason
            if sync_state.last_error and not out.get("last_error"):
                out["last_error"] = sync_state.last_error
            cursor_at = sync_state.last_synced_request_recorded_at
            cursor_id = sync_state.last_synced_request_id or ""

        # Count rows strictly past the cursor — same predicate as the
        # worker's batch loader, just COUNT instead of SELECT.
        async with storage._sessionmaker() as session:  # type: ignore[union-attr]
            stmt = select(func.count(Request.id))
            if cursor_at is not None:
                stmt = stmt.where(
                    (Request.recorded_at > cursor_at)
                    | (
                        (Request.recorded_at == cursor_at)
                        & (Request.id > cursor_id)
                    )
                )
            result = await session.execute(stmt)
            out["unsynced_record_count"] = int(result.scalar_one() or 0)
    return out


@cloud_group.command(name="whoami")
def cloud_whoami_cmd() -> None:
    """GET /v1/daemon/whoami and print the response."""
    cfg = load_cloud_config()
    if not cfg.base_url:
        console.print("[red]No cloud configured.[/red]")
        sys.exit(EXIT_PARTIAL)

    async def _run() -> dict[str, Any]:
        async with CloudClient(base_url=cfg.base_url) as client:
            return await client.whoami()

    try:
        payload = asyncio.run(_run())
    except CloudUnauthorised as exc:
        console.print(f"[red]Unauthorised: {exc}[/red]")
        sys.exit(EXIT_UNAUTH)
    except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
        console.print(f"[red]whoami failed: {exc}[/red]")
        sys.exit(EXIT_PARTIAL)
    console.print(payload)


@cloud_group.command(name="sync")
def cloud_sync_cmd() -> None:
    """Run a single drain pass and exit.

    Scaffolding: the loader callables write to no-ops until Wave 1A.i
    lands. Useful today as a smoke test against a stubbed cloud or in
    integration tests with a ``MockTransport``.
    """
    cfg = load_cloud_config()
    if not cfg.is_active:
        console.print("[yellow]Cloud sync is not active (check `cloud status`).[/yellow]")
        sys.exit(EXIT_PARTIAL)

    endpoint = cfg.base_url

    upload_policy = load_upload_policy()

    async def _run() -> None:
        async with CloudClient(base_url=endpoint) as client:
            await run_once(
                client,
                cursor_reader=_make_cursor_reader(endpoint),
                batch_loader=_make_batch_loader(upload_policy),
                cursor_advancer=_make_cursor_advancer(endpoint),
                pause_writer=_make_pause_writer(endpoint),
            )

    try:
        asyncio.run(_run())
    except CloudUnauthorised as exc:
        asyncio.run(
            _record_sync_failure(str(exc), paused_reason="paused_unauthorised")
        )
        sys.exit(EXIT_UNAUTH)
    except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
        asyncio.run(_record_sync_failure(str(exc)))
        console.print(f"[red]Sync failed: {exc}[/red]")
        sys.exit(EXIT_PARTIAL)


@cloud_group.command(name="reconcile")
@click.option("--days", default=1, show_default=True, type=int)
def cloud_reconcile_cmd(days: int) -> None:
    """Compare daemon vs cloud totals over the last ``--days`` days.

    Rendering is Wave 1B / Wave 3 territory; this scaffold just calls
    the cloud endpoint and prints the JSON so the surface is exercised.
    """
    cfg = load_cloud_config()
    if not cfg.is_active:
        console.print("[yellow]Cloud sync is not active.[/yellow]")
        sys.exit(EXIT_PARTIAL)

    import datetime as _dt

    end = _dt.datetime.now(_dt.UTC)
    start = end - _dt.timedelta(days=days)
    iso = lambda d: d.strftime("%Y-%m-%dT%H:%M:%SZ")  # noqa: E731

    async def _run() -> dict[str, Any]:
        async with CloudClient(base_url=cfg.base_url) as client:
            return await client.reconciliation_totals(
                date_from=iso(start), date_to=iso(end)
            )

    try:
        payload = asyncio.run(_run())
    except CloudUnauthorised:
        sys.exit(EXIT_UNAUTH)
    except (CloudTransport, CloudSchemaMismatch, CloudRateLimited) as exc:
        console.print(f"[red]Reconcile call failed: {exc}[/red]")
        sys.exit(EXIT_PARTIAL)
    console.print(payload)


@cloud_group.command(name="pause")
def cloud_pause_cmd() -> None:
    """Manually pause continuous sync. Cursor preserved."""
    _set_cloud_enabled(False, paused_reason="paused_manual")
    console.print("[yellow]Cloud sync paused (paused_manual).[/yellow]")


@cloud_group.command(name="resume")
def cloud_resume_cmd() -> None:
    """Clear a manual pause. Has no effect on paused_unauthorised."""
    _set_cloud_enabled(True, paused_reason=None)
    console.print("[green]Cloud sync resumed.[/green]")


# ---------------------------------------------------------------------- #
# Privacy (data-upload policy) subgroup.
# ---------------------------------------------------------------------- #


@cloud_group.group(name="privacy")
def cloud_privacy_group() -> None:
    """Inspect and adjust what data the daemon uploads to the cloud.

    The daemon decides what leaves the machine; the cloud cannot redact
    what it never receives. Three layers of control:

    \b
      preset = minimal | standard | full
      [cloud.upload.fields]   - global per-field overrides
      [cloud.upload.per_project."slug"] - per-project overrides

    Defaults to ``standard`` preset, which sends project slug + token
    counts + cost + prompt_hash but withholds the workdir path. Run
    ``halton-meter cloud privacy show`` to see the resolved policy.
    """


@cloud_privacy_group.command(name="show")
def cloud_privacy_show_cmd() -> None:
    """Print the resolved upload policy."""
    policy = load_upload_policy()
    console.print("[bold]Upload policy[/bold]")
    console.print(describe(policy))


@cloud_privacy_group.command(name="set")
@click.argument("target")
@click.argument("value")
@click.option(
    "--project",
    default=None,
    help="When set, the change applies to the per-project rules for this slug.",
)
def cloud_privacy_set_cmd(
    target: str, value: str, project: str | None
) -> None:
    """Adjust the upload policy.

    \b
      cloud privacy set preset standard
      cloud privacy set field.source_workdir false
      cloud privacy set upload false --project acme-secret
      cloud privacy set field.prompt_hash false --project client-x

    Writes ``[cloud.upload]`` into ``~/.halton-meter/config.toml`` and
    leaves every other section untouched. TOML comments outside the
    ``[cloud.upload]`` block are preserved; comments inside it are not.
    """
    cmd = _parse_privacy_set_target(target)
    if cmd is None:
        console.print(
            "[red]Unknown target. Use 'preset', 'field.<name>', or 'upload'.[/red]"
        )
        sys.exit(EXIT_PARTIAL)
    kind, name = cmd

    try:
        _apply_privacy_set(kind=kind, name=name, value=value, project=project)
    except _PrivacySetError as exc:
        console.print(f"[red]{exc}[/red]")
        sys.exit(EXIT_PARTIAL)

    # Echo the new resolved state so the user sees the consequence.
    console.print("[green]Updated.[/green]")
    console.print(describe(load_upload_policy()))


class _PrivacySetError(RuntimeError):
    """Raised by :func:`_apply_privacy_set` for any malformed input."""


def _parse_privacy_set_target(target: str) -> tuple[str, str] | None:
    """Split ``preset``, ``upload``, or ``field.<name>``.

    Returns ``(kind, name)`` where ``kind`` is ``preset``, ``upload``, or
    ``field``. For preset/upload the ``name`` is the empty string. For
    ``field.<name>`` the name must be in :data:`GATEABLE_FIELDS`.
    """
    target = target.strip()
    if target == "preset":
        return ("preset", "")
    if target == "upload":
        return ("upload", "")
    if target.startswith("field."):
        name = target[len("field."):]
        if name in GATEABLE_FIELDS:
            return ("field", name)
    return None


def _parse_bool_value(raw: str) -> bool:
    """Coerce the CLI value to bool. Reject anything ambiguous loudly."""
    norm = raw.strip().lower()
    if norm in ("true", "yes", "1", "on"):
        return True
    if norm in ("false", "no", "0", "off"):
        return False
    raise _PrivacySetError(
        f"expected a boolean (true/false), got {raw!r}"
    )


def _apply_privacy_set(
    *,
    kind: str,
    name: str,
    value: str,
    project: str | None,
) -> None:
    """Mutate ``[cloud.upload]`` in the config TOML.

    Strategy: read existing TOML with stdlib, rebuild the ``[cloud.upload]``
    table in-memory, then rewrite the whole file with ``tomli_w`` if
    available — but ``tomli_w`` is not a current dep, so we hand-render
    the ``[cloud.upload]`` block and splice it back in. Comments outside
    the block are preserved; comments inside the block are lost.
    """
    config_path = Path("~/.halton-meter/config.toml").expanduser()
    raw_text = config_path.read_text() if config_path.exists() else ""
    existing = tomllib.loads(raw_text) if raw_text else {}

    cloud_block = existing.get("cloud", {})
    if not isinstance(cloud_block, dict):
        cloud_block = {}
    upload_block = cloud_block.get("upload", {})
    if not isinstance(upload_block, dict):
        upload_block = {}

    if kind == "preset":
        if value.strip().lower() not in {p.value for p in UploadPreset}:
            allowed = ", ".join(p.value for p in UploadPreset)
            raise _PrivacySetError(
                f"unknown preset {value!r}; allowed: {allowed}"
            )
        if project is not None:
            raise _PrivacySetError(
                "preset is a global setting; do not pass --project"
            )
        upload_block["preset"] = value.strip().lower()

    elif kind == "field":
        send = _parse_bool_value(value)
        if project is None:
            fields_section = upload_block.setdefault("fields", {})
            if not isinstance(fields_section, dict):
                raise _PrivacySetError(
                    "[cloud.upload.fields] is not a table; fix the config "
                    "by hand before retrying"
                )
            fields_section[name] = send
        else:
            pp_section = upload_block.setdefault("per_project", {})
            if not isinstance(pp_section, dict):
                raise _PrivacySetError(
                    "[cloud.upload.per_project] is not a table; fix the "
                    "config by hand before retrying"
                )
            project_table = pp_section.setdefault(project, {})
            if not isinstance(project_table, dict):
                raise _PrivacySetError(
                    f"[cloud.upload.per_project.\"{project}\"] is not a "
                    "table; fix the config by hand before retrying"
                )
            proj_fields = project_table.setdefault("fields", {})
            if not isinstance(proj_fields, dict):
                raise _PrivacySetError(
                    f"per-project fields for {project!r} is not a table"
                )
            proj_fields[name] = send

    elif kind == "upload":
        if project is None:
            raise _PrivacySetError(
                "'upload' is a per-project switch; pass --project <slug>"
            )
        send = _parse_bool_value(value)
        pp_section = upload_block.setdefault("per_project", {})
        if not isinstance(pp_section, dict):
            raise _PrivacySetError(
                "[cloud.upload.per_project] is not a table"
            )
        project_table = pp_section.setdefault(project, {})
        if not isinstance(project_table, dict):
            raise _PrivacySetError(
                f"[cloud.upload.per_project.\"{project}\"] is not a table"
            )
        project_table["upload"] = send

    # Splice the rebuilt upload table back into the parent structures.
    cloud_block["upload"] = upload_block
    existing["cloud"] = cloud_block

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(_render_toml(existing))


def _render_toml(data: dict[str, Any]) -> str:
    """Render a config dict back to TOML.

    Hand-rolled because adding ``tomli_w`` as a runtime dep just for the
    privacy-set CLI is overkill — the only writes the daemon ever
    performs are config edits driven by user CLI actions. The renderer
    is intentionally minimal:

    * Top-level scalars first.
    * Nested tables emitted depth-first as ``[a.b.c]`` headers.
    * Dict-of-dict mappings emitted as ``[parent."key"]`` so slugs with
      hyphens / dots survive a round-trip.

    Lists are emitted inline; that's the only collection shape the
    upload policy uses, and the rest of the config doesn't have any
    list-of-table values today.
    """
    lines: list[str] = []
    _render_table(data, prefix=[], lines=lines)
    return "\n".join(lines) + "\n"


def _render_table(
    table: dict[str, Any], *, prefix: list[str], lines: list[str]
) -> None:
    """Emit one TOML table at ``prefix``, recursing into sub-tables."""
    scalars: dict[str, Any] = {}
    sub_tables: dict[str, dict[str, Any]] = {}
    for key, value in table.items():
        if isinstance(value, dict):
            sub_tables[key] = value
        else:
            scalars[key] = value

    if prefix:
        header = ".".join(_quote_key(k) for k in prefix)
        lines.append(f"[{header}]")
    for key, value in scalars.items():
        lines.append(f"{_quote_key(key)} = {_format_scalar(value)}")
    if prefix or scalars:
        lines.append("")

    for key, sub in sub_tables.items():
        _render_table(sub, prefix=[*prefix, key], lines=lines)


def _quote_key(key: str) -> str:
    """Quote a TOML key only when it needs it.

    Bare keys may contain ``[A-Za-z0-9_-]``; everything else (project
    slugs with dots, hyphenated names mixed with dots) is quoted.
    """
    if key and all(c.isalnum() or c in "_-" for c in key):
        return key
    escaped = key.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _format_scalar(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, list):
        inner = ", ".join(_format_scalar(v) for v in value)
        return f"[{inner}]"
    # Anything else (datetime etc.) falls back to repr — the upload-policy
    # surface doesn't introduce such values, so the fallback is a safety net.
    return repr(value)


# ---------------------------------------------------------------------- #
# Top-level alias: ``halton-meter sync``.
# ---------------------------------------------------------------------- #


@click.command(name="sync")
@click.pass_context
def top_level_sync_cmd(ctx: click.Context) -> None:
    """Alias for ``halton-meter cloud sync`` (single drain pass)."""
    ctx.invoke(cloud_sync_cmd)


# ---------------------------------------------------------------------- #
# Worker injection seams — read/write ``cloud_sync_state`` for real.
# ---------------------------------------------------------------------- #


# Factories were lifted out of this module into
# ``halton_meter.cloud._supervisor_glue`` so the supervisor in
# ``halton_meter.cli`` can wire the worker without importing any
# ``halton_meter.cli*`` module (proxy hot path must stay Click/rich-free).
# The one-shot ``cloud sync`` command below keeps calling them under the
# legacy underscore-prefixed names; the underscore aliases are preserved
# so any external test importing ``_make_cursor_reader`` from this module
# continues to work.
from halton_meter.cloud._supervisor_glue import (  # noqa: E402
    make_batch_loader as _make_batch_loader,
)
from halton_meter.cloud._supervisor_glue import (  # noqa: E402
    make_cursor_advancer as _make_cursor_advancer,
)
from halton_meter.cloud._supervisor_glue import (  # noqa: E402
    make_cursor_reader as _make_cursor_reader,
)
from halton_meter.cloud._supervisor_glue import (  # noqa: E402
    make_pause_writer as _make_pause_writer,
)

# ---------------------------------------------------------------------- #
# Registration helper — called from ``halton_meter.cli``.
# ---------------------------------------------------------------------- #


def register(cli: click.Group) -> None:
    """Attach the ``cloud`` group and the top-level ``sync`` alias.

    Called at the bottom of ``halton_meter.cli`` so import order doesn't
    have to be threaded through every cli.py reorg.
    """
    cli.add_command(cloud_group)
    cli.add_command(top_level_sync_cmd)
