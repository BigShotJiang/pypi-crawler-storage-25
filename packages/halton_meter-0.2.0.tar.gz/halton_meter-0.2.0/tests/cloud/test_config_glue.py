"""Config-glue read of the ``[cloud]`` TOML block."""

from __future__ import annotations

from pathlib import Path

from halton_meter.cloud.config_glue import load_cloud_config


def test_missing_file_yields_safe_defaults(tmp_path: Path):
    cfg = load_cloud_config(config_path=tmp_path / "does-not-exist.toml")
    assert cfg.enabled is False
    assert cfg.base_url == ""
    assert cfg.continuous is True
    assert cfg.sync_interval_seconds == 30
    assert cfg.is_active is False


def test_reads_cloud_block(tmp_path: Path):
    path = tmp_path / "config.toml"
    path.write_text(
        '\n'.join(
            [
                "[cloud]",
                "enabled = true",
                'base_url = "https://meter.example.test"',
                "continuous = false",
                "sync_interval_seconds = 15",
            ]
        )
    )
    cfg = load_cloud_config(config_path=path)
    assert cfg.enabled is True
    assert cfg.base_url == "https://meter.example.test"
    assert cfg.continuous is False
    assert cfg.sync_interval_seconds == 15
    assert cfg.is_active is True


def test_is_active_requires_both_flag_and_url(tmp_path: Path):
    """`enabled=True` without a base_url is not active."""
    path = tmp_path / "config.toml"
    path.write_text("[cloud]\nenabled = true\n")
    cfg = load_cloud_config(config_path=path)
    assert cfg.enabled is True
    assert cfg.is_active is False
