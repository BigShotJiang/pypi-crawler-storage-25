class UserSettingsNotFound(FileNotFoundError):
    pass
