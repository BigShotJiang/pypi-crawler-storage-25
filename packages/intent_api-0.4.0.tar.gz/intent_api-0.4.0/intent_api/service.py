"""
IntentService — The abstract base class for all intent handlers.

Every model in your application gets one IntentService subclass.
The framework dispatches intents to the correct method based on the action.

Two patterns for custom commands:

1. Decorator-based (recommended — auto-discoverable, click-to-source):

    class TodoService(IntentService):
        @custom_action(schema=ArchivePayload)
        async def archive(self, *, db, user, context, id, payload):
            ...

2. Manual override (legacy — backward compatible):

    class TodoService(IntentService):
        async def custom_action(self, *, command, db, user, context, id, payload):
            if command == "archive":
                ...

You may NOT mix both patterns on the same service — doing so raises
TypeError at class definition time.
"""

from abc import ABC
from typing import Any, Optional, Type

from fastapi import HTTPException
from pydantic import BaseModel

from intent_api.schemas import IntentContext


# ── @custom_action decorator ──────────────────────────────────────────────────


def custom_action(
    *,
    schema: Optional[Type[BaseModel]] = None,
    name: Optional[str] = None,
):
    """
    Decorator that marks a method as a dispatchable custom command.

    The framework auto-collects decorated methods into the service's
    `_registered_commands` registry at class definition time. Eliminates
    the need to write manual if/elif dispatch in `custom_action()`.

    Args:
        schema: Optional Pydantic model describing the command's payload.
            Used by the MCP server for typed schema generation. If omitted,
            the payload schema falls back to a loose `{"type": "object"}`.
        name: Optional explicit command name. Defaults to the method name.

    Example:
        class BlogPostService(IntentService):
            @custom_action(schema=GeneratePayload)
            async def generate(self, *, db, user, context, id, payload):
                ...

            @custom_action(name="export_mdx")
            async def export(self, *, db, user, context, id, payload):
                ...
    """

    def decorator(fn):
        fn._is_intent_command = True
        fn._command_name = name or fn.__name__
        fn._command_schema = schema
        return fn

    return decorator


# ── MutationResponse ──────────────────────────────────────────────────────────


class MutationResponse(BaseModel):
    """Standard response for create/update/delete operations."""

    success: bool
    message: Optional[str] = None
    id: Optional[str] = None
    data: Optional[dict] = None


# ── IntentService ─────────────────────────────────────────────────────────────


class IntentService(ABC):
    """
    Abstract base class for intent service handlers.

    Subclass this for each model/resource in your application.
    Override the methods you need — unimplemented methods will
    raise NotImplementedError by default.

    Class Attributes:
        is_admin_only: If True, this service is only accessible via admin surfaces.
        is_guest_allowed: If True, unauthenticated users can access this service.
        allowed_guest_actions: List of action strings allowed for guests.
            If None and is_guest_allowed is True, all actions are allowed.

    Auto-populated:
        _registered_commands: Dict of {command_name: {"handler": method_name, "schema": Pydantic model or None}}
            Populated at class creation time from methods decorated with @custom_action.
    """

    is_admin_only: bool = False
    is_guest_allowed: bool = False
    allowed_guest_actions: Optional[list[str]] = None

    # Populated by __init_subclass__
    _registered_commands: dict = {}
    _intent_policies: dict = {}

    # Optional class-level @intent default policy. Subclasses set this via:
    #   __default_intent__ = intent.defaults(...)
    __default_intent__ = None

    # ── Subclass initialization ───────────────────────────────────────────

    def __init_subclass__(cls, **kwargs) -> None:
        """
        Collect @custom_action commands and resolve @intent policies.

        Custom commands (Phase 1 of v0.2.0):
        - Walks cls.__dict__ for @custom_action-decorated methods
        - Merges with parent's _registered_commands

        Intent policies (Phase 1+2 of v0.3.0):
        - Walks cls.__dict__ for @intent-decorated methods
        - For methods without @intent but with __default_intent__ on the class,
          derives the policy from the default + READ_ACTIONS/WRITE_ACTIONS
        - Custom action methods without @intent get the write_preset

        Mixed-mode (custom_action decorators + manual custom_action override
        on the same class) raises TypeError at class definition time.
        """
        super().__init_subclass__(**kwargs)

        parent_commands = dict(getattr(cls, "_registered_commands", {}))
        own_commands: dict = {}

        for attr_name, method in cls.__dict__.items():
            if callable(method) and getattr(method, "_is_intent_command", False):
                command_name = getattr(method, "_command_name", attr_name)
                command_schema = getattr(method, "_command_schema", None)
                own_commands[command_name] = {
                    "handler": attr_name,
                    "schema": command_schema,
                }

        cls._registered_commands = {**parent_commands, **own_commands}

        has_decorators = len(own_commands) > 0
        has_manual_override = "custom_action" in cls.__dict__
        if has_decorators and has_manual_override:
            raise TypeError(
                f"{cls.__name__} cannot use both @custom_action decorators "
                f"and a manual custom_action() override on the same class. "
                f"Choose one pattern: either decorate individual command "
                f"methods with @custom_action, or override custom_action() "
                f"manually with if/elif dispatch."
            )

        # ── @intent policy collection (v0.3.0) ────────────────────────────
        from intent_api.constants import READ_ACTIONS, WRITE_ACTIONS
        from intent_api.policy import (
            IntentDefaultPolicy,
            resolve_default_policy,
        )

        parent_policies = dict(getattr(cls, "_intent_policies", {}))
        own_policies: dict = {}

        for attr_name, method in cls.__dict__.items():
            if not callable(method):
                continue
            if hasattr(method, "_intent_policy"):
                own_policies[attr_name] = method._intent_policy

        default_policy = cls.__dict__.get("__default_intent__") or getattr(
            cls, "__default_intent__", None
        )
        if default_policy is not None and not isinstance(
            default_policy, IntentDefaultPolicy
        ):
            raise TypeError(
                f"{cls.__name__}.__default_intent__ must be an IntentDefaultPolicy "
                f"(returned by intent.defaults(...)), got "
                f"{type(default_policy).__name__}."
            )

        if default_policy is not None:
            base_methods = {
                name: getattr(IntentService, name, None)
                for name in (*READ_ACTIONS, *WRITE_ACTIONS)
            }
            for method_name in (*READ_ACTIONS, *WRITE_ACTIONS):
                if method_name in own_policies:
                    continue
                method = getattr(cls, method_name, None)
                if method is None or method is base_methods.get(method_name):
                    continue
                own_policies[method_name] = resolve_default_policy(
                    method_name, default_policy, is_custom_action=False
                )

            for cmd_name, info in own_commands.items():
                handler_name = info.get("handler")
                if handler_name and handler_name not in own_policies:
                    own_policies[handler_name] = resolve_default_policy(
                        handler_name, default_policy, is_custom_action=True
                    )

        cls._intent_policies = {**parent_policies, **own_policies}

    # ── CRUD + List ───────────────────────────────────────────────────────

    async def create(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """Handle 'create' intents. Override in your subclass."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support 'create'."
        )

    async def read(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
    ) -> Any:
        """Handle 'read' intents. Override in your subclass."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support 'read'."
        )

    async def update(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """Handle 'update' intents. Override in your subclass."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support 'update'."
        )

    async def delete(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
    ) -> Any:
        """Handle 'delete' intents. Override in your subclass."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support 'delete'."
        )

    async def list(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        skip: int = 0,
        limit: int = 10,
    ) -> Any:
        """Handle 'list' intents. Override in your subclass."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support 'list'."
        )

    # ── Custom Commands ───────────────────────────────────────────────────

    async def custom_action(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        command: str,
        id: Optional[Any] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """
        Default dispatcher for 'custom' intents with named commands.

        Looks up the command in `_registered_commands` (populated from
        @custom_action-decorated methods) and invokes the matching handler.

        Subclasses MAY override this method to use manual if/elif dispatch
        instead of decorators — but cannot mix both patterns.
        """
        if command in self._registered_commands:
            handler_name = self._registered_commands[command]["handler"]
            handler = getattr(self, handler_name)
            return await handler(
                db=db,
                user=user,
                context=context,
                id=id,
                payload=payload,
            )
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unknown command '{command}' on "
                f"{self.__class__.__name__}."
            ),
        )

    # ── Guest Access Control ──────────────────────────────────────────────

    def guest_allowed(self, action: str, command: Optional[str] = None) -> bool:
        """Check if a guest (unauthenticated user) can perform this action."""
        if not self.is_guest_allowed:
            return False
        if self.allowed_guest_actions is None:
            return True
        action_key = (
            f"custom:{command}" if action == "custom" and command else action
        )
        return action_key in self.allowed_guest_actions

    # ── Context Helpers ───────────────────────────────────────────────────

    @staticmethod
    def get_context_value(
        context: Optional[IntentContext], key: str
    ) -> Optional[str]:
        """Safely extract a value from the intent context."""
        if not context:
            return None
        return getattr(context, key, None)
