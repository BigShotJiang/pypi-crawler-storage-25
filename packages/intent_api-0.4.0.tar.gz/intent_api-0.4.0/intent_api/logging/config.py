"""
Configuration types for intent-api logging.

`IntentLogConfig` is the single config object passed to setup_intent_logging()
and configure_celery_logging(). Frozen — pass a new instance to change config.

`IntentLoggingHandle` is returned by setup. Call `.shutdown()` in your
FastAPI lifespan or atexit to flush any batched OTel exports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class IntentLogConfig:
    """
    Frozen configuration for intent-api logging.

    Args:
        service_name: Required. Identifies the process in observability tools.
            Convention: `app-api` (FastAPI), `app-worker` (Celery worker),
            `app-scheduler` (Celery Beat).
        service_version: Optional version string for the service. Becomes
            `service.version` resource attribute on OTel exports.
        log_level: stdlib log level name. Defaults to "INFO".
        otel_endpoint: OTLP/HTTP collector endpoint. When `None` (default),
            only console output is configured — zero OTel imports attempted,
            zero external network calls. Set to enable OTel export.
        otel_api_key: Optional bearer token for the OTLP endpoint. When set,
            sent as `Authorization: Bearer <key>` header.
        otel_headers: Additional HTTP headers for the OTLP exporter
            (e.g. `{"x-honeycomb-team": "..."}`). Merged with the
            bearer token header if both are provided.
        json_console: If True, emit console logs as JSON instead of the
            human-readable structlog dev renderer. Useful in container
            environments that scrape stdout for log shipping.
    """

    service_name: str
    service_version: str = ""
    log_level: str = "INFO"
    otel_endpoint: Optional[str] = None
    otel_api_key: Optional[str] = None
    otel_headers: Optional[Dict[str, str]] = None
    json_console: bool = False

    def __post_init__(self) -> None:
        if not self.service_name:
            raise ValueError(
                "IntentLogConfig.service_name is required (non-empty string)."
            )
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if self.log_level.upper() not in valid_levels:
            raise ValueError(
                f"IntentLogConfig.log_level must be one of {sorted(valid_levels)}, "
                f"got {self.log_level!r}."
            )


@dataclass
class IntentLoggingHandle:
    """
    Handle returned by `setup_intent_logging()` and `configure_celery_logging()`.

    Call `.shutdown()` from your FastAPI lifespan (or `atexit.register(...)`)
    to flush any batched OTel exports before the process exits.

    Holds a reference to the OTel `LoggerProvider` (when configured) and the
    `StructlogLoggerProvider` to pass into `IntentRuntime(logger_provider=...)`.
    """

    logger_provider: Any
    otel_provider: Any = None
    config: Optional[IntentLogConfig] = None

    def shutdown(self) -> None:
        """Flush + shut down the OTel LoggerProvider, if configured."""
        if self.otel_provider is not None:
            try:
                self.otel_provider.shutdown()
            except Exception:
                pass
