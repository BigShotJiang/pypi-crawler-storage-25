"""
Celery integration for intent-api logging.

Lazy-imports Celery — `intent-api` does not depend on Celery. Importing
this module without Celery installed raises a clear `ImportError`.

`configure_celery_logging(celery_app, config)` does:
  1. Configure structlog + (optional) OTel — same chain as setup_intent_logging
     but WITHOUT installing FastAPI middleware (workers don't have an app).
  2. Register `task_prerun` signal — rebinds intent context from task
     headers (deferred) OR generates fresh context (Beat / scheduled).
  3. Register `task_postrun` signal — clears contextvars.
  4. Register `worker_shutting_down` signal — flushes OTel exports.

Returns the same `IntentLoggingHandle` that `setup_intent_logging` returns.
"""

from __future__ import annotations

import uuid
from typing import Any, Optional

import structlog

from intent_api.logging.config import IntentLogConfig, IntentLoggingHandle
from intent_api.logging.setup import setup_intent_logging


def configure_celery_logging(
    celery_app: Any, config: IntentLogConfig
) -> IntentLoggingHandle:
    """Configure structured logging + Celery context binding for a worker
    or scheduler process."""
    try:
        from celery.signals import (
            task_postrun,
            task_prerun,
            worker_shutting_down,
        )
    except ImportError as exc:
        raise ImportError(
            "Celery integration requires celery: pip install celery"
        ) from exc

    handle = setup_intent_logging(config, app=None)

    @task_prerun.connect(weak=False)
    def _intent_api_bind_task_context(  # noqa: ANN001
        task_id: str, task: Any, **_kwargs: Any
    ) -> None:
        structlog.contextvars.clear_contextvars()
        intent_context = _extract_intent_context_from_task(task)

        if intent_context:
            structlog.contextvars.bind_contextvars(
                task_id=task_id, **intent_context,
            )
        else:
            structlog.contextvars.bind_contextvars(
                request_id=f"beat-{uuid.uuid4()}",
                task_id=task_id,
                intent_id=getattr(task, "name", "celery.task"),
                surface="system",
                actor_id="system",
                team_id="system",
                phase="scheduled",
            )

    @task_postrun.connect(weak=False)
    def _intent_api_clear_task_context(**_kwargs: Any) -> None:
        structlog.contextvars.clear_contextvars()

    @worker_shutting_down.connect(weak=False)
    def _intent_api_flush_otel(**_kwargs: Any) -> None:
        handle.shutdown()

    return handle


def _extract_intent_context_from_task(task: Any) -> Optional[dict]:
    """Pull intent_context from the Celery task's request, if present.

    Search order (Celery's surface here is messy across versions):
      1. `task.request.intent_context` (custom attribute set by sender)
      2. `task.request.headers["intent_context"]` (standard Celery header)
    """
    request = getattr(task, "request", None)
    if request is None:
        return None

    direct = getattr(request, "intent_context", None)
    if direct:
        return dict(direct)

    headers = getattr(request, "headers", None) or {}
    if isinstance(headers, dict):
        ctx = headers.get("intent_context")
        if ctx:
            return dict(ctx)
    return None
