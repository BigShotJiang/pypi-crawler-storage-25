"""
Structured logging + observability for intent-api (v0.4.0).

Native structlog integration. Optional OpenTelemetry export.
Automatic intent context binding — every log emitted inside a handler
carries `request_id`, `intent_id`, `actor_id`, `team_id`, `surface`
without any manual context passing by the developer.

Public API:

    setup_intent_logging(app, config)       — one-call setup for FastAPI apps
    configure_celery_logging(celery_app, config) — Celery worker/scheduler setup
    IntentLogConfig                          — frozen dataclass for configuration
    IntentLoggingHandle                      — shutdown handle for OTel
    StructlogLoggerProvider                  — recommended LoggerProvider implementation
    IntentContextMiddleware                  — request_id middleware (auto-applied)
    bind_intent_context()                    — internal context binding (used by router)
    capture_intent_context()                 — captures contextvars for task propagation
"""

from intent_api.logging.config import IntentLogConfig, IntentLoggingHandle
from intent_api.logging.context import (
    bind_intent_context,
    capture_intent_context,
)
from intent_api.logging.middleware import IntentContextMiddleware
from intent_api.logging.setup import setup_intent_logging
from intent_api.logging.structlog_provider import StructlogLoggerProvider

__all__ = [
    "setup_intent_logging",
    "IntentLogConfig",
    "IntentLoggingHandle",
    "IntentContextMiddleware",
    "StructlogLoggerProvider",
    "bind_intent_context",
    "capture_intent_context",
]


def __getattr__(name: str):
    """Lazy-load the celery integration so importing intent_api.logging
    doesn't pull in celery."""
    if name == "configure_celery_logging":
        from intent_api.logging.celery import configure_celery_logging

        return configure_celery_logging
    raise AttributeError(f"module 'intent_api.logging' has no attribute {name!r}")
