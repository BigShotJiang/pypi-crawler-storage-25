"""
OpenTelemetry structlog processor.

Filled in for Phase 2. Lazy-imported only when `IntentLogConfig.otel_endpoint`
is set, so the base install never touches OTel packages.

Importing this module without `intent-api[otel]` installed raises ImportError —
`setup.py` catches and re-raises with a clearer message.
"""

from __future__ import annotations

import time
from typing import Any, Dict

import orjson  # noqa: F401 — confirms the otel extras are installed
from opentelemetry._logs import (
    LogRecord,
    SeverityNumber,
    set_logger_provider,
)
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.sdk.resources import Resource

import intent_api
from intent_api.logging.config import IntentLogConfig


_EXCLUDE_ATTRS = {"event", "message", "level", "timestamp", "_logger", "_record", "logger"}

_LEVEL_TO_SEVERITY = {
    "debug": SeverityNumber.DEBUG,
    "info": SeverityNumber.INFO,
    "warning": SeverityNumber.WARN,
    "warn": SeverityNumber.WARN,
    "error": SeverityNumber.ERROR,
    "critical": SeverityNumber.FATAL,
}


def build_otel_logger_provider(config: IntentLogConfig) -> LoggerProvider:
    """Construct an OTel LoggerProvider with the OTLP/HTTP exporter."""
    resource = Resource.create({
        "service.name": config.service_name,
        "service.version": config.service_version or "",
        "intent_api.version": intent_api.__version__,
    })
    provider = LoggerProvider(resource=resource)

    headers: Dict[str, str] = {}
    if config.otel_headers:
        headers.update(config.otel_headers)
    if config.otel_api_key:
        headers["Authorization"] = f"Bearer {config.otel_api_key}"

    exporter = OTLPLogExporter(
        endpoint=config.otel_endpoint,
        headers=headers or None,
    )
    provider.add_log_record_processor(BatchLogRecordProcessor(exporter))
    set_logger_provider(provider)
    return provider


def make_otel_processor(provider: LoggerProvider):
    """structlog processor that emits each event into the OTel LoggerProvider.

    Bypasses stdlib so context fields arrive as proper OTLP attributes
    (not packed into the log body).
    """
    otel_logger = provider.get_logger("intent_api")

    def _serialize(value: Any) -> Any:
        if isinstance(value, (bool, str, bytes, int, float)) or value is None:
            return value
        try:
            return orjson.dumps(value).decode("utf-8")
        except Exception:
            return str(value)

    def otel_processor(_logger, _method_name, event_dict):
        level = (event_dict.get("level") or "info").lower()
        message = event_dict.get("message") or event_dict.get("event") or ""

        attributes = {
            k: _serialize(v)
            for k, v in event_dict.items()
            if k not in _EXCLUDE_ATTRS
        }

        record = LogRecord(
            timestamp=time.time_ns(),
            severity_number=_LEVEL_TO_SEVERITY.get(level, SeverityNumber.INFO),
            severity_text=level.upper(),
            body=str(message),
            attributes=attributes,
        )
        try:
            otel_logger.emit(record)
        except Exception:
            pass
        return event_dict

    return otel_processor
