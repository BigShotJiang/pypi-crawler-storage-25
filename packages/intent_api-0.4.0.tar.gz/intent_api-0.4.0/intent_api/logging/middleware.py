"""
IntentContextMiddleware — auto-binds `request_id` for every HTTP request.

- Reads `X-Request-ID` header if present, else generates UUID v4
- Binds to structlog contextvars BEFORE the request handler runs
- Returns `X-Request-ID` in the response headers (always)
- Catches unhandled exceptions, logs them with full context, returns 500
- Clears contextvars after the response completes
"""

from __future__ import annotations

import uuid

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


class IntentContextMiddleware(BaseHTTPMiddleware):
    """Bind `request_id` to structlog contextvars for every HTTP request."""

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())

        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            method=request.method,
            path=request.url.path,
        )

        log = structlog.get_logger("intent_api.http")

        try:
            response = await call_next(request)
        except Exception:
            log.exception("unhandled_exception")
            response = JSONResponse(
                status_code=500,
                content={"detail": "Internal Server Error"},
            )

        response.headers["x-request-id"] = request_id
        structlog.contextvars.clear_contextvars()
        return response
