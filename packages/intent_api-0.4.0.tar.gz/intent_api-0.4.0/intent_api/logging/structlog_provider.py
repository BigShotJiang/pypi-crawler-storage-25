"""
StructlogLoggerProvider — the recommended LoggerProvider for v0.4.0.

Implements `intent_api.providers.LoggerProvider`. Routes runtime
lifecycle events through the structlog processor chain configured by
`setup_intent_logging()`. With OTel enabled, that chain emits to the
OTLP exporter.

Reads the optional `_level` field from the event dict (one of "info",
"warning", "error") to choose the structlog level. Defaults to "info".
The `_level` key is stripped before forwarding.
"""

from __future__ import annotations

from typing import Any, Dict

import structlog

_LEVEL_METHODS = {"debug", "info", "warning", "error", "critical"}


class StructlogLoggerProvider:
    """LoggerProvider that emits runtime events through structlog."""

    def __init__(self, name: str = "intent_api.runtime") -> None:
        self._name = name

    async def log(self, event: Dict[str, Any]) -> None:
        log = structlog.get_logger(self._name)

        forwarded = {k: v for k, v in event.items() if k != "_level"}
        level = (event.get("_level") or "info").lower()
        if level not in _LEVEL_METHODS:
            level = "info"

        method = getattr(log, level)
        intent_id = forwarded.get("intent_id", "unknown")
        status = forwarded.get("status", "unknown")
        method(f"intent.{status}", intent_id=intent_id, **{
            k: v for k, v in forwarded.items() if k != "intent_id"
        })
