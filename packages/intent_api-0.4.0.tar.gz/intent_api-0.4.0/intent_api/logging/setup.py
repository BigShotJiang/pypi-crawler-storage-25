"""
`setup_intent_logging(app, config)` — one-call configuration.

What this does:
- Configures structlog with the canonical processor chain
- Replaces stdlib root handlers with a structlog-rendered console handler
- Quiets noisy third-party loggers (uvicorn.access, asyncio, watchfiles)
- Optionally wires OTel export (lazy import — only if `otel_endpoint` set)
- Optionally adds `IntentContextMiddleware` to the FastAPI app
- Returns an `IntentLoggingHandle` for shutdown management

The framework owns structlog configuration. Callers do not need to (and
should not) call `structlog.configure()` themselves — doing so will
override the framework's processor chain and break context propagation.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import structlog

from intent_api.logging.config import IntentLogConfig, IntentLoggingHandle
from intent_api.logging.middleware import IntentContextMiddleware
from intent_api.logging.structlog_provider import StructlogLoggerProvider


def setup_intent_logging(
    config: IntentLogConfig,
    *,
    app: Optional[Any] = None,
) -> IntentLoggingHandle:
    """
    Configure structured logging for the current process.

    Args:
        config: Required IntentLogConfig instance.
        app: Optional FastAPI/Starlette app. When provided, the
            IntentContextMiddleware is automatically applied.

    Returns:
        IntentLoggingHandle — call `.shutdown()` to flush OTel exports.
    """
    log_level = getattr(logging, config.log_level.upper(), logging.INFO)

    otel_provider, otel_processor = _maybe_build_otel(config)

    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.EventRenamer("message"),
    ]
    if otel_processor is not None:
        processors.append(otel_processor)
    processors.append(structlog.stdlib.ProcessorFormatter.wrap_for_formatter)

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    _configure_stdlib_handler(config)
    _quiet_noisy_loggers()
    logging.getLogger().setLevel(log_level)

    if app is not None:
        app.add_middleware(IntentContextMiddleware)

    return IntentLoggingHandle(
        logger_provider=StructlogLoggerProvider(),
        otel_provider=otel_provider,
        config=config,
    )


# ── Internal helpers ─────────────────────────────────────────────────────────


def _configure_stdlib_handler(config: IntentLogConfig) -> None:
    """Install a single stdlib StreamHandler that uses a ProcessorFormatter
    to render through structlog (console JSON or human-readable)."""
    if config.json_console:
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(
            colors=True,
            event_key="message",
            exception_formatter=structlog.dev.plain_traceback,
        )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
        ],
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler()
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)


def _quiet_noisy_loggers() -> None:
    """Suppress chatty defaults that flood stdout in dev."""
    for name in (
        "uvicorn.access",
        "watchfiles.main",
        "watchfiles.watcher",
        "asyncio",
        "httpcore",
        "httpx",
    ):
        logging.getLogger(name).setLevel(logging.WARNING)


def _maybe_build_otel(config: IntentLogConfig):
    """Build the OTel LoggerProvider + structlog processor when configured.

    Lazy-imports OTel — when `otel_endpoint` is None, no OTel imports happen
    and (None, None) is returned so the chain stays console-only.
    """
    if config.otel_endpoint is None:
        return None, None

    try:
        from intent_api.logging.processors import (
            build_otel_logger_provider,
            make_otel_processor,
        )
    except ImportError as exc:
        raise ImportError(
            "OTel export requires intent-api[otel]: "
            "pip install 'intent-api[otel]'"
        ) from exc

    otel_provider = build_otel_logger_provider(config)
    otel_processor = make_otel_processor(otel_provider)
    return otel_provider, otel_processor
