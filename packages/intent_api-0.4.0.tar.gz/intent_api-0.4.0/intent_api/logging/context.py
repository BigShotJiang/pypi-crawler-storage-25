"""
Context binding helpers for intent-api logging.

`bind_intent_context()` is called by `_dispatch()` after resolving the user.
It binds intent-specific fields to structlog contextvars so every subsequent
log call inside the handler inherits them — zero manual context passing.

`capture_intent_context()` snapshots contextvars at deferred-dispatch time
so the worker can rebind them when the task runs.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

import structlog

# Names of the intent-specific keys we bind. Used by capture_intent_context()
# to filter the snapshot down to the canonical set + by tests.
INTENT_CONTEXT_KEYS = (
    "request_id",
    "intent_id",
    "intent_model",
    "intent_action",
    "intent_command",
    "actor_id",
    "team_id",
    "surface",
    "phase",
)


def bind_intent_context(
    *,
    model: str,
    action: str,
    command: Optional[str] = None,
    user: Any = None,
    surface: str,
) -> str:
    """
    Bind intent context to the current structlog contextvars.

    Called by `_dispatch()` immediately after resolving the user, BEFORE the
    runtime pipeline runs. All policy checks, hooks, and handler logs inherit
    these fields automatically.

    Returns the resolved `intent_id`.
    """
    action_or_command = command if (action == "custom" and command) else action
    intent_id = f"{model}.{action_or_command}"

    existing = structlog.contextvars.get_contextvars()
    if "request_id" not in existing:
        structlog.contextvars.bind_contextvars(request_id=str(uuid.uuid4()))

    actor_id = _safe_get(user, "id")
    team_id = _safe_get(user, "team_id")

    structlog.contextvars.bind_contextvars(
        intent_id=intent_id,
        intent_model=model,
        intent_action=action,
        intent_command=command,
        actor_id=str(actor_id) if actor_id is not None else None,
        team_id=str(team_id) if team_id is not None else None,
        surface=surface,
    )
    return intent_id


def capture_intent_context() -> Dict[str, Any]:
    """
    Snapshot current intent context for propagation to a deferred task.

    Returns only the canonical INTENT_CONTEXT_KEYS subset of contextvars
    plus `phase="deferred"` (so workers can distinguish deferred from
    request-time logs in their observability tools).
    """
    current = structlog.contextvars.get_contextvars()
    captured = {k: current[k] for k in INTENT_CONTEXT_KEYS if k in current}
    captured["phase"] = "deferred"
    return captured


def clear_intent_context() -> None:
    """Clear all bound contextvars. Called by middleware on response + by
    Celery task_postrun signal."""
    structlog.contextvars.clear_contextvars()


def _safe_get(obj: Any, attr: str) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(attr)
    return getattr(obj, attr, None)
