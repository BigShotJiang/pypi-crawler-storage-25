"""
The `@intent` decorator system.

Three usage patterns:

1. Raw decorator with explicit fields:

    @intent(permission="campaign:create", audit=True)
    async def create(self, *, db, user, context, payload): ...

2. Preset-based:

    @intent.preset("standard_write", permission="campaign:create")
    async def create(self, *, db, user, context, payload): ...

3. Class-level default (for undecorated methods):

    class CampaignService(IntentService):
        __default_intent__ = intent.defaults(
            permission_prefix="campaign",
            write_preset="standard_write",
        )

Custom presets:

    intent.define_preset(
        "seo_brew_ai_action",
        defaults={"execution": "deferred", "audit": True},
        requires=["permission", "feature", "quota"],
    )
"""

from __future__ import annotations

from typing import Any, Callable, List, Literal, Optional

from intent_api.constants import (
    BUILT_IN_PRESETS,
    READ_ACTIONS,
    VALID_EXECUTIONS,
    VALID_REQUIRES,
)
from intent_api.policy import (
    IntentDefaultPolicy,
    IntentPolicySpec,
    _register_custom_preset,
    _resolve_preset,
)


class _IntentDecoratorFactory:
    """
    Callable factory exposed publicly as `intent`.

    Behaves as a decorator when called: `@intent(permission="x")`.
    Also exposes `.preset()`, `.defaults()`, and `.define_preset()`.
    """

    def __call__(
        self,
        *,
        permission: Optional[str] = None,
        feature: Optional[str] = None,
        quota: Optional[str] = None,
        audit: bool = False,
        execution: Literal["immediate", "deferred"] = "immediate",
    ) -> Callable[[Callable], Callable]:
        if execution not in VALID_EXECUTIONS:
            raise ValueError(
                f"@intent execution must be one of {sorted(VALID_EXECUTIONS)}, got {execution!r}"
            )

        def decorator(fn: Callable) -> Callable:
            _validate_deferred_not_on_read_or_list(fn, execution)
            fn._intent_policy = IntentPolicySpec(  # type: ignore[attr-defined]
                permission=permission,
                feature=feature,
                quota=quota,
                audit=audit,
                execution=execution,
                preset_name=None,
            )
            return fn

        return decorator

    def preset(
        self, name: str, **overrides: Any
    ) -> Callable[[Callable], Callable]:
        preset = _resolve_preset(name)
        merged: dict = {**preset["defaults"], **overrides}

        if "execution" in merged and merged["execution"] not in VALID_EXECUTIONS:
            raise ValueError(
                f"Preset '{name}' override has invalid execution {merged['execution']!r}"
            )

        for required_field in preset.get("requires", []):
            if required_field not in merged or merged[required_field] is None:
                raise TypeError(
                    f"Preset '{name}' requires '{required_field}' but it was not provided. "
                    f"Pass it as a kwarg: @intent.preset({name!r}, {required_field}='...')"
                )

        spec_fields = {
            "permission": merged.get("permission"),
            "feature": merged.get("feature"),
            "quota": merged.get("quota"),
            "audit": merged.get("audit", False),
            "execution": merged.get("execution", "immediate"),
            "preset_name": name,
        }

        def decorator(fn: Callable) -> Callable:
            _validate_deferred_not_on_read_or_list(fn, spec_fields["execution"])
            fn._intent_policy = IntentPolicySpec(**spec_fields)  # type: ignore[attr-defined]
            return fn

        return decorator

    def defaults(
        self,
        *,
        write_preset: str = "standard_write",
        read_preset: str = "standard_read",
        permission_prefix: Optional[str] = None,
        audit: bool = True,
    ) -> IntentDefaultPolicy:
        if write_preset not in BUILT_IN_PRESETS and write_preset not in _list_custom_presets():
            raise ValueError(
                f"Unknown write_preset '{write_preset}'. Define it via "
                f"intent.define_preset() before referencing it in defaults()."
            )
        if read_preset not in BUILT_IN_PRESETS and read_preset not in _list_custom_presets():
            raise ValueError(
                f"Unknown read_preset '{read_preset}'. Define it via "
                f"intent.define_preset() before referencing it in defaults()."
            )
        return IntentDefaultPolicy(
            write_preset=write_preset,
            read_preset=read_preset,
            permission_prefix=permission_prefix,
            audit=audit,
        )

    def define_preset(
        self,
        name: str,
        defaults: dict,
        requires: Optional[List[str]] = None,
    ) -> None:
        if not isinstance(name, str) or not name:
            raise ValueError("Preset name must be a non-empty string.")
        if name in BUILT_IN_PRESETS:
            raise ValueError(
                f"Cannot redefine built-in preset '{name}'. "
                f"Choose a different name."
            )
        if not isinstance(defaults, dict):
            raise ValueError("Preset 'defaults' must be a dict.")

        execution = defaults.get("execution", "immediate")
        if execution not in VALID_EXECUTIONS:
            raise ValueError(
                f"Preset '{name}' has invalid execution {execution!r}. "
                f"Must be one of {sorted(VALID_EXECUTIONS)}."
            )

        audit = defaults.get("audit", False)
        if not isinstance(audit, bool):
            raise ValueError(
                f"Preset '{name}' audit must be bool, got {type(audit).__name__}."
            )

        requires = requires or []
        if not isinstance(requires, list):
            raise ValueError("Preset 'requires' must be a list of strings.")
        invalid = set(requires) - VALID_REQUIRES
        if invalid:
            raise ValueError(
                f"Preset '{name}' has invalid requires: {sorted(invalid)}. "
                f"Must be a subset of {sorted(VALID_REQUIRES)}."
            )

        _register_custom_preset(
            name, {"defaults": defaults, "requires": list(requires)}
        )


def _list_custom_presets() -> set:
    from intent_api.policy import _CUSTOM_PRESETS

    return set(_CUSTOM_PRESETS.keys())


def _validate_deferred_not_on_read_or_list(fn: Callable, execution: str) -> None:
    """B36: deferred execution is not supported for read/list actions."""
    if execution != "deferred":
        return
    name = getattr(fn, "__name__", "")
    if name in READ_ACTIONS:
        raise ValueError(
            f"Deferred execution not supported for read/list actions. "
            f"@intent(execution='deferred') on method '{name}' is invalid — "
            f"reads should return data immediately."
        )


intent = _IntentDecoratorFactory()
