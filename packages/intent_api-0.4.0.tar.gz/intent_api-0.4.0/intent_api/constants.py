"""
Framework-level constants for the Intent API runtime governance layer.

These constants drive default policy resolution, preset application,
and Inspector tooling. They are NOT configurable in v0.3.0 — locking
them in keeps the semantic layer stable across the ecosystem.
"""

from __future__ import annotations

from typing import Any, Dict, FrozenSet


READ_ACTIONS: FrozenSet[str] = frozenset({"read", "list"})
WRITE_ACTIONS: FrozenSet[str] = frozenset({"create", "update", "delete"})


BUILT_IN_PRESETS: Dict[str, Dict[str, Any]] = {
    "standard_read": {
        "defaults": {
            "execution": "immediate",
            "audit": False,
        },
        "requires": [],
    },
    "standard_write": {
        "defaults": {
            "execution": "immediate",
            "audit": True,
        },
        "requires": ["permission"],
    },
    "standard_deferred_paid_write": {
        "defaults": {
            "execution": "deferred",
            "audit": True,
        },
        "requires": ["permission", "feature", "quota"],
    },
    "admin_write": {
        "defaults": {
            "execution": "immediate",
            "audit": True,
        },
        "requires": ["permission"],
    },
    "machine_task": {
        "defaults": {
            "execution": "immediate",
            "audit": True,
        },
        "requires": [],
    },
    "system_job": {
        "defaults": {
            "execution": "immediate",
            "audit": True,
        },
        "requires": [],
    },
}


VALID_EXECUTIONS: FrozenSet[str] = frozenset({"immediate", "deferred"})
VALID_REQUIRES: FrozenSet[str] = frozenset({"permission", "feature", "quota"})
