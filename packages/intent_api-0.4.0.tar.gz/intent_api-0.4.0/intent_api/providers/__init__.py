"""
Provider interfaces and zero-dependency SimpleProvider implementations.

Seven provider Protocols define HOW policy is evaluated. The IntentRuntime
guarantees THAT policy is enforced — providers never run without the runtime
calling them, and policy decisions never reach handlers.

Public API:
    Interfaces (Protocols, all async except ActorSerializer):
        PermissionProvider, BillingProvider, QuotaProvider, TaskProvider,
        AuditProvider, LoggerProvider, ActorSerializer

    SimpleProviders (zero-dependency reference implementations):
        SimplePermissionProvider, SimpleBillingProvider, SimpleQuotaProvider,
        SimpleTaskProvider, SimpleAuditProvider, SimpleLoggerProvider,
        SimpleActorSerializer

    Errors:
        IntentRuntimeError, PermissionDenied, PlanUpgradeRequired,
        QuotaExceeded, ProviderNotConfigured, TaskDispatchFailed,
        UngovernedIntent
"""

from intent_api.providers.errors import (
    IntentRuntimeError,
    PermissionDenied,
    PlanUpgradeRequired,
    ProviderNotConfigured,
    QuotaExceeded,
    TaskDispatchFailed,
    UngovernedIntent,
)
from intent_api.providers.interfaces import (
    ActorSerializer,
    AuditProvider,
    BillingProvider,
    LoggerProvider,
    PermissionProvider,
    QuotaProvider,
    TaskProvider,
)
from intent_api.providers.simple import (
    SimpleActorSerializer,
    SimpleAuditProvider,
    SimpleBillingProvider,
    SimpleLoggerProvider,
    SimplePermissionProvider,
    SimpleQuotaProvider,
    SimpleTaskProvider,
)

__all__ = [
    # Interfaces
    "PermissionProvider",
    "BillingProvider",
    "QuotaProvider",
    "TaskProvider",
    "AuditProvider",
    "LoggerProvider",
    "ActorSerializer",
    # Simple implementations
    "SimplePermissionProvider",
    "SimpleBillingProvider",
    "SimpleQuotaProvider",
    "SimpleTaskProvider",
    "SimpleAuditProvider",
    "SimpleLoggerProvider",
    "SimpleActorSerializer",
    # Errors
    "IntentRuntimeError",
    "PermissionDenied",
    "PlanUpgradeRequired",
    "QuotaExceeded",
    "ProviderNotConfigured",
    "TaskDispatchFailed",
    "UngovernedIntent",
]
