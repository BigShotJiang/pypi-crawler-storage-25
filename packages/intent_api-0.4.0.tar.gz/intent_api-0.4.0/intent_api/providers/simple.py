"""
SimpleProviders — zero-dependency reference implementations.

Use these for development, testing, and small apps. Production deployments
typically replace SimpleQuotaProvider (Redis), SimpleTaskProvider (Celery),
and SimpleAuditProvider (database) with real implementations.

`SimpleTaskProvider` and `SimpleQuotaProvider` are explicitly marked
DEV/TESTING ONLY in their docstrings — they have semantics (in-memory state,
fire-and-forget, process-local) that are unsafe for multi-process production.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import uuid
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from intent_api.runtime import IntentRuntime

logger = logging.getLogger("intent_api.providers")
audit_logger = logging.getLogger("intent_api.audit")
runtime_logger = logging.getLogger("intent_api.runtime")


# ── SimplePermissionProvider ─────────────────────────────────────────────────


class SimplePermissionProvider:
    """
    Role → permissions mapping. Wildcard `"*"` grants all permissions.

    Reads `actor.role` (defaulting to "member" if missing).

    Example:
        SimplePermissionProvider({
            "admin":  ["*"],
            "member": ["campaign:create", "campaign:read", "campaign:list"],
            "viewer": ["campaign:read", "campaign:list"],
        })
    """

    def __init__(self, role_permissions: Dict[str, List[str]]) -> None:
        self._role_permissions: Dict[str, frozenset] = {
            role: frozenset(perms) for role, perms in role_permissions.items()
        }

    async def has_permission(
        self, actor: Any, permission: str, context: Dict[str, Any]
    ) -> bool:
        role = getattr(actor, "role", None) or (
            actor.get("role") if isinstance(actor, dict) else "member"
        )
        perms = self._role_permissions.get(role, frozenset())
        return "*" in perms or permission in perms


# ── SimpleBillingProvider ────────────────────────────────────────────────────


class SimpleBillingProvider:
    """
    Feature → allowed plans mapping.

    Reads `actor.plan` (defaulting to "free" if missing).

    Example:
        SimpleBillingProvider({
            "ai_generation": ["pro", "enterprise"],
            "exports":       ["enterprise"],
        })
    """

    def __init__(self, feature_plans: Dict[str, List[str]]) -> None:
        self._feature_plans: Dict[str, frozenset] = {
            feature: frozenset(plans) for feature, plans in feature_plans.items()
        }

    async def has_feature(
        self, actor: Any, feature: str, context: Dict[str, Any]
    ) -> bool:
        plan = getattr(actor, "plan", None) or (
            actor.get("plan") if isinstance(actor, dict) else "free"
        )
        allowed = self._feature_plans.get(feature, frozenset())
        return plan in allowed


# ── SimpleQuotaProvider ──────────────────────────────────────────────────────


class SimpleQuotaProvider:
    """
    In-memory per-actor quota counter.

    DEV/TESTING ONLY:
    - Counters reset on process restart
    - State is process-local (no sharing across workers)
    - Single web process only

    Production: use a RedisQuotaProvider or DBQuotaProvider with shared state.

    Thread-safe via threading.Lock — survives concurrent uvicorn workers
    in a single process.

    Reads `actor.team_id` (defaulting to "default") to scope the counter.
    """

    def __init__(self, quota_limits: Dict[str, int]) -> None:
        self._limits = dict(quota_limits)
        self._counters: Dict[str, int] = {}
        self._lock = threading.Lock()

    def _key(self, actor: Any, quota_key: str) -> str:
        team_id = getattr(actor, "team_id", None) or (
            actor.get("team_id") if isinstance(actor, dict) else "default"
        )
        return f"{team_id}:{quota_key}"

    async def check_and_consume(
        self, actor: Any, quota_key: str, context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any]]:
        key = self._key(actor, quota_key)
        limit = self._limits.get(quota_key, float("inf"))
        with self._lock:
            current = self._counters.get(key, 0)
            if current >= limit:
                return False, {"current": current, "limit": limit}
            self._counters[key] = current + 1
            return True, {"current": current + 1, "limit": limit}

    async def rollback(
        self, actor: Any, quota_key: str, context: Dict[str, Any]
    ) -> None:
        key = self._key(actor, quota_key)
        with self._lock:
            current = self._counters.get(key, 0)
            if current > 0:
                self._counters[key] = current - 1


# ── SimpleTaskProvider ───────────────────────────────────────────────────────


class SimpleTaskProvider:
    """
    Fire-and-forget background-thread task dispatcher.

    DEV/TESTING ONLY:
    - Tasks die when the process exits
    - No retry, no persistence, no observability
    - The returned `task_id` is opaque — no `get_status(task_id)` method
    - Process-local

    Production: use Celery, RQ, Dramatiq, or any real task broker.

    Constructed with a runtime reference and a session_factory because
    the worker thread runs `runtime.execute_deferred()` which needs a
    fresh DB session it can own.
    """

    def __init__(
        self,
        runtime: "IntentRuntime",
        *,
        session_factory: Optional[Callable[[], Any]] = None,
    ) -> None:
        self._runtime = runtime
        self._session_factory = session_factory or (lambda: None)

    async def dispatch(
        self,
        *,
        intent_id: str,
        actor_data: Dict[str, Any],
        payload: Dict[str, Any] | None,
        intent_context: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        task_id = str(uuid.uuid4())
        thread = threading.Thread(
            target=self._run_in_thread,
            args=(task_id, intent_id, actor_data, payload, intent_context or {}),
            daemon=True,
        )
        thread.start()
        return {"task_id": task_id, "status": "dispatched"}

    def _run_in_thread(
        self,
        task_id: str,
        intent_id: str,
        actor_data: Dict[str, Any],
        payload: Dict[str, Any] | None,
        intent_context: Dict[str, Any],
    ) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        db = None
        try:
            try:
                import structlog

                structlog.contextvars.clear_contextvars()
                if intent_context:
                    structlog.contextvars.bind_contextvars(
                        task_id=task_id, **intent_context,
                    )
            except Exception:
                pass

            db_iter = self._session_factory()
            if hasattr(db_iter, "__next__"):
                db = next(db_iter)
            else:
                db = db_iter

            loop.run_until_complete(
                self._runtime.execute_deferred(
                    intent_id=intent_id,
                    actor_data=actor_data,
                    payload=payload,
                    db=db,
                )
            )
        except Exception:
            logger.exception(
                "SimpleTaskProvider: task %s (%s) failed", task_id, intent_id
            )
        finally:
            try:
                if db is not None and hasattr(db, "close"):
                    db.close()
            except Exception:
                logger.exception(
                    "SimpleTaskProvider: failed closing db for task %s", task_id
                )
            try:
                import structlog

                structlog.contextvars.clear_contextvars()
            except Exception:
                pass
            try:
                loop.close()
            except Exception:
                pass


# ── SimpleAuditProvider ──────────────────────────────────────────────────────


class SimpleAuditProvider:
    """
    Emits audit events as structured JSON to the `intent_api.audit` logger.

    Production: replace with a DB-backed AuditProvider that writes to a
    durable audit_log table.
    """

    async def log(self, event: Dict[str, Any]) -> None:
        audit_logger.info(json.dumps(event, default=str, sort_keys=True))


# ── SimpleLoggerProvider ─────────────────────────────────────────────────────


class SimpleLoggerProvider:
    """
    Emits observability events as structured JSON to the
    `intent_api.runtime` logger. Replace in production with an OpenTelemetry,
    StatsD, or similar emitter.
    """

    async def log(self, event: Dict[str, Any]) -> None:
        runtime_logger.info(json.dumps(event, default=str, sort_keys=True))


# ── SimpleActorSerializer ────────────────────────────────────────────────────


class SimpleActorSerializer:
    """
    Default actor serializer.

    serialize(): handles Pydantic models (`model_dump`), plain objects with
    `__dict__` (filters dunders/privates), and dicts.

    deserialize(): returns SimpleNamespace, so `actor.id` and dict-style
    access both work in handlers.

    For production with real DB-backed user models, write a custom
    ActorSerializer that re-fetches the User object from the DB by id.
    """

    def serialize(self, actor: Any) -> Dict[str, Any]:
        if hasattr(actor, "model_dump"):
            return actor.model_dump()
        if isinstance(actor, dict):
            return dict(actor)
        if hasattr(actor, "__dict__"):
            return {
                k: v
                for k, v in actor.__dict__.items()
                if not k.startswith("_")
            }
        return {"value": actor}

    def deserialize(self, data: Dict[str, Any]) -> Any:
        return SimpleNamespace(**data)
