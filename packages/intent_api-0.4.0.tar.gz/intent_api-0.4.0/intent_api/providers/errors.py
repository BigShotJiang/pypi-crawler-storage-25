"""
Structured error types raised by the IntentRuntime.

All errors carry `code`, `message`, and `detail` so MCP clients and HTTP
clients can branch programmatically without parsing message strings.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class IntentRuntimeError(Exception):
    """Base for all runtime-emitted errors."""

    code: str = "INTENT_RUNTIME_ERROR"

    def __init__(
        self,
        message: str,
        *,
        code: Optional[str] = None,
        detail: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        if code is not None:
            self.code = code
        self.detail: Dict[str, Any] = detail or {}

    def to_dict(self) -> Dict[str, Any]:
        return {"code": self.code, "message": self.message, "detail": self.detail}


class PermissionDenied(IntentRuntimeError):
    code = "PERMISSION_DENIED"

    def __init__(self, permission: str, **detail: Any) -> None:
        super().__init__(
            f"Permission denied: {permission}",
            detail={"permission": permission, **detail},
        )


class PlanUpgradeRequired(IntentRuntimeError):
    code = "PLAN_UPGRADE_REQUIRED"

    def __init__(self, feature: str, **detail: Any) -> None:
        super().__init__(
            f"Plan upgrade required for feature: {feature}",
            detail={"feature": feature, **detail},
        )


class QuotaExceeded(IntentRuntimeError):
    code = "QUOTA_EXCEEDED"

    def __init__(self, quota: str, **detail: Any) -> None:
        super().__init__(
            f"Quota exceeded: {quota}",
            detail={"quota": quota, **detail},
        )


class ProviderNotConfigured(IntentRuntimeError):
    code = "PROVIDER_NOT_CONFIGURED"

    def __init__(self, provider_name: str) -> None:
        super().__init__(
            f"{provider_name.capitalize()}Provider is required by this intent's "
            f"policy but is not configured on the IntentRuntime.",
            detail={"provider": provider_name},
        )


class TaskDispatchFailed(IntentRuntimeError):
    code = "TASK_DISPATCH_FAILED"

    def __init__(self, intent_id: str, *, original: Optional[str] = None) -> None:
        super().__init__(
            f"Failed to dispatch deferred task for {intent_id}",
            detail={"intent_id": intent_id, "original_error": original},
        )


class UngovernedIntent(IntentRuntimeError):
    code = "UNGOVERNED_INTENT"

    def __init__(self, intent_id: str) -> None:
        super().__init__(
            f"Intent '{intent_id}' has no policy and strict mode is enabled.",
            detail={"intent_id": intent_id},
        )
