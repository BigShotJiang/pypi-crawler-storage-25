"""
Provider Protocol interfaces.

All async EXCEPT ActorSerializer (sync — pure data transformation).

Custom providers MAY perform real async I/O (Redis, Stripe, Postgres async
drivers) without wrapping. SimpleProviders implement async signatures even
when their internals are synchronous, so the runtime can always `await`.
"""

from __future__ import annotations

from typing import Any, Dict, Protocol, Tuple, runtime_checkable


@runtime_checkable
class PermissionProvider(Protocol):
    """Decide if an actor has a named permission."""

    async def has_permission(
        self, actor: Any, permission: str, context: Dict[str, Any]
    ) -> bool: ...


@runtime_checkable
class BillingProvider(Protocol):
    """Decide if an actor's plan includes a named feature."""

    async def has_feature(
        self, actor: Any, feature: str, context: Dict[str, Any]
    ) -> bool: ...


@runtime_checkable
class QuotaProvider(Protocol):
    """
    Track and consume named quotas.

    `check_and_consume` returns (allowed, metadata). If `allowed` is False,
    the runtime raises QuotaExceeded with `metadata` in the detail dict.

    `rollback` is called by the runtime when a deferred dispatch fails
    AFTER the quota was consumed. Best-effort — failures are logged but
    do not raise.
    """

    async def check_and_consume(
        self, actor: Any, quota_key: str, context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any]]: ...

    async def rollback(
        self, actor: Any, quota_key: str, context: Dict[str, Any]
    ) -> None: ...


@runtime_checkable
class TaskProvider(Protocol):
    """
    Dispatch a deferred handler to a worker.

    The runtime serializes the actor via ActorSerializer before calling
    `dispatch`. The provider returns a task reference dict (typically
    containing `task_id` and `status`) which is returned to the caller
    of `runtime.execute`.

    `intent_context` (added in v0.4.0) carries the structlog contextvars
    captured at dispatch time — `request_id`, `intent_id`, `actor_id`,
    `team_id`, `surface`, `phase="deferred"`. Workers MUST rebind these
    so logs emitted during deferred execution correlate with the
    triggering HTTP request.

    Backward compatibility: implementations from v0.3.0 that do not
    accept `intent_context` continue to work — the runtime introspects
    the dispatch signature and only passes `intent_context` if the
    parameter is present (or `**kwargs` is accepted).
    """

    async def dispatch(
        self,
        *,
        intent_id: str,
        actor_data: Dict[str, Any],
        payload: Dict[str, Any] | None,
        intent_context: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]: ...


@runtime_checkable
class AuditProvider(Protocol):
    """
    Write a durable audit record. Called by the runtime in `finally` —
    runs on success AND failure. Audit failures are caught and logged but
    do NOT break the request.
    """

    async def log(self, event: Dict[str, Any]) -> None: ...


@runtime_checkable
class LoggerProvider(Protocol):
    """
    Emit an observability/telemetry event. Same lifecycle as audit
    (finally block, never raises out of the runtime), but always emitted
    regardless of `spec.audit`.
    """

    async def log(self, event: Dict[str, Any]) -> None: ...


@runtime_checkable
class ActorSerializer(Protocol):
    """
    Serialize/deserialize actors across process boundaries (TaskProvider)
    and into structured event payloads (AuditProvider, LoggerProvider).

    Sync because this is pure data transformation. Production
    deserializers that hit a DB should wrap their I/O appropriately
    (asyncio.to_thread or sync session pattern).
    """

    def serialize(self, actor: Any) -> Dict[str, Any]: ...

    def deserialize(self, data: Dict[str, Any]) -> Any: ...
