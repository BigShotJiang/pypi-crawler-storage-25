"""
Policy types for the Intent API governance layer.

This module owns:
- IntentPolicySpec — the dataclass that's attached to every method via @intent
- IntentDefaultPolicy — the dataclass returned by intent.defaults()
- PolicyRegistry — the source-of-truth allowlist (added in Phase 3)
- resolve_default_policy() — resolves an IntentPolicySpec from a class default
- validate_all_intents() — startup validation engine (added in Phase 3)
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, FrozenSet, List, Literal, Optional

from intent_api.constants import READ_ACTIONS, WRITE_ACTIONS


# ── Policy Spec ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class IntentPolicySpec:
    """
    Declarative policy metadata attached to an IntentService method.

    All fields are optional. A spec where every field is None and
    audit=False is effectively "ungoverned" — the runtime will execute
    the handler without any policy enforcement (and emit a warning if
    Inspector is wired up).
    """

    permission: Optional[str] = None
    feature: Optional[str] = None
    quota: Optional[str] = None
    audit: bool = False
    execution: Literal["immediate", "deferred"] = "immediate"
    preset_name: Optional[str] = None


# ── Class-level Default Policy ───────────────────────────────────────────────


@dataclass(frozen=True)
class IntentDefaultPolicy:
    """
    Class-level default attached to a service via __default_intent__.

    The runtime uses this to derive an IntentPolicySpec for any method
    on the class that doesn't carry its own @intent decorator.
    """

    write_preset: str = "standard_write"
    read_preset: str = "standard_read"
    permission_prefix: Optional[str] = None
    audit: bool = True


# ── Default Policy Resolver (used in Phase 2) ────────────────────────────────


def resolve_default_policy(
    method_name: str,
    default: IntentDefaultPolicy,
    *,
    is_custom_action: bool = False,
) -> IntentPolicySpec:
    """
    Derive an IntentPolicySpec for a method using a class default.

    - Read actions (read, list) get the class's read_preset
    - Write actions (create, update, delete) get the class's write_preset
    - Custom actions get the write_preset (mutations by definition)
    """
    from intent_api.constants import BUILT_IN_PRESETS

    if not is_custom_action and method_name in READ_ACTIONS:
        preset_name = default.read_preset
    else:
        preset_name = default.write_preset

    preset = _CUSTOM_PRESETS.get(preset_name) or BUILT_IN_PRESETS.get(preset_name)
    if preset is None:
        raise ValueError(
            f"Class default references unknown preset '{preset_name}'. "
            f"Available presets: {sorted(set(BUILT_IN_PRESETS) | set(_CUSTOM_PRESETS))}"
        )

    permission: Optional[str] = None
    if default.permission_prefix:
        permission = f"{default.permission_prefix}:{method_name}"

    preset_defaults = preset["defaults"]
    return IntentPolicySpec(
        permission=permission,
        feature=None,
        quota=None,
        audit=default.audit,
        execution=preset_defaults.get("execution", "immediate"),
        preset_name=preset_name,
    )


# ── Custom preset registry (populated by intent.define_preset) ───────────────
# Phase 1 needs this to live somewhere both intent_decorator.py and policy.py
# can see. Keeping it here so resolve_default_policy works without importing
# from intent_decorator (which would cycle).

_CUSTOM_PRESETS: dict = {}


def _register_custom_preset(name: str, preset_def: dict) -> None:
    """Internal — used by intent.define_preset()."""
    _CUSTOM_PRESETS[name] = preset_def


def _resolve_preset(name: str) -> dict:
    """Resolve a preset by name from built-ins or custom registry."""
    from intent_api.constants import BUILT_IN_PRESETS

    if name in _CUSTOM_PRESETS:
        return _CUSTOM_PRESETS[name]
    if name in BUILT_IN_PRESETS:
        return BUILT_IN_PRESETS[name]
    raise ValueError(
        f"Unknown preset '{name}'. "
        f"Available: {sorted(set(BUILT_IN_PRESETS) | set(_CUSTOM_PRESETS))}"
    )


# ── PolicyRegistry + validation (filled in by Phase 3) ───────────────────────
# Forward declarations so __init__.py exports work cleanly. Real
# implementations land in Phase 3.


@dataclass(frozen=True)
class ValidationIssue:
    intent_id: str
    severity: Literal["error", "warning"]
    message: str
    field: Optional[str] = None
    value: Optional[str] = None


@dataclass(frozen=True)
class ValidationResult:
    issues: List[ValidationIssue]
    passed: bool

    @property
    def errors(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == "warning"]


class IntentValidationError(Exception):
    """Raised when strict-mode validation fails at startup."""

    def __init__(self, errors: List[ValidationIssue]) -> None:
        self.errors = errors
        msgs = "\n  - ".join(f"{e.intent_id}: {e.message}" for e in errors)
        super().__init__(
            f"Intent policy validation failed with {len(errors)} error(s):\n  - {msgs}"
        )


@dataclass(frozen=True)
class PolicyRegistry:
    """
    The source-of-truth allowlist for permission, feature, and quota strings.

    Cross-referenced against every resolved IntentPolicySpec at startup.
    Catches AI-hallucinated strings before they hit production.

    Use `PolicyRegistry.permissive()` for dev/testing — accepts anything.
    Production registries MUST pass explicit allowlists.
    """

    permissions: FrozenSet[str] = field(default_factory=frozenset)
    features: FrozenSet[str] = field(default_factory=frozenset)
    quotas: FrozenSet[str] = field(default_factory=frozenset)
    permissive: bool = False

    def __init__(
        self,
        permissions: Optional[List[str]] = None,
        features: Optional[List[str]] = None,
        quotas: Optional[List[str]] = None,
    ) -> None:
        # frozen dataclass requires object.__setattr__
        object.__setattr__(self, "permissions", frozenset(permissions or []))
        object.__setattr__(self, "features", frozenset(features or []))
        object.__setattr__(self, "quotas", frozenset(quotas or []))
        object.__setattr__(self, "permissive", False)

    @classmethod
    def permissive_registry(cls) -> "PolicyRegistry":
        """Internal — use PolicyRegistry.permissive() instead."""
        instance = cls.__new__(cls)
        object.__setattr__(instance, "permissions", frozenset())
        object.__setattr__(instance, "features", frozenset())
        object.__setattr__(instance, "quotas", frozenset())
        object.__setattr__(instance, "permissive", True)
        return instance

    @classmethod
    def permissive(cls) -> "PolicyRegistry":  # type: ignore[no-redef]
        """Return a registry that accepts any string. Dev/testing only."""
        return cls.permissive_registry()

    def validate_spec(
        self, intent_id: str, spec: IntentPolicySpec
    ) -> List[ValidationIssue]:
        if self.permissive:
            return []

        issues: List[ValidationIssue] = []

        if spec.permission is not None and spec.permission not in self.permissions:
            issues.append(
                ValidationIssue(
                    intent_id=intent_id,
                    severity="error",
                    field="permission",
                    value=spec.permission,
                    message=(
                        f"Permission '{spec.permission}' not found in PolicyRegistry"
                    ),
                )
            )
        if spec.feature is not None and spec.feature not in self.features:
            issues.append(
                ValidationIssue(
                    intent_id=intent_id,
                    severity="error",
                    field="feature",
                    value=spec.feature,
                    message=(
                        f"Feature '{spec.feature}' not found in PolicyRegistry"
                    ),
                )
            )
        if spec.quota is not None and spec.quota not in self.quotas:
            issues.append(
                ValidationIssue(
                    intent_id=intent_id,
                    severity="error",
                    field="quota",
                    value=spec.quota,
                    message=(
                        f"Quota '{spec.quota}' not found in PolicyRegistry"
                    ),
                )
            )
        return issues


# ── Validation Engine (called by IntentRuntime.validate, Phase 3) ────────────


def validate_all_intents(
    registry,
    policy_registry: Optional[PolicyRegistry],
    *,
    strict: bool = False,
) -> ValidationResult:
    """
    Cross-reference every resolved policy against PolicyRegistry + flag
    ungoverned methods. Called at IntentRuntime startup.

    Args:
        registry: ServiceRegistry instance.
        policy_registry: PolicyRegistry, or None for "no validation."
        strict: If True, ungoverned mutating methods produce errors instead
            of warnings, and the caller will raise IntentValidationError on
            any error.

    Returns:
        ValidationResult with all issues. Caller decides whether to raise
        on failure based on `strict`.
    """
    import logging

    logger = logging.getLogger("intent_api.policy")
    issues: List[ValidationIssue] = []

    for model_name in registry.models:
        service = registry.get(model_name)
        if service is None:
            continue
        policies = getattr(service.__class__, "_intent_policies", {}) or {}

        for method_name, spec in policies.items():
            intent_id = f"{model_name}.{method_name}"
            if policy_registry is not None:
                issues.extend(policy_registry.validate_spec(intent_id, spec))

            preset_name = spec.preset_name
            if preset_name:
                preset = _CUSTOM_PRESETS.get(preset_name)
                if preset is None:
                    from intent_api.constants import BUILT_IN_PRESETS
                    preset = BUILT_IN_PRESETS.get(preset_name)
                if preset:
                    for required in preset.get("requires", []):
                        if getattr(spec, required, None) is None:
                            issues.append(
                                ValidationIssue(
                                    intent_id=intent_id,
                                    severity="error",
                                    field=required,
                                    message=(
                                        f"Preset '{preset_name}' requires "
                                        f"'{required}' but it is not set"
                                    ),
                                )
                            )

        from intent_api.service import IntentService

        cls = service.__class__
        for method_name in (
            *READ_ACTIONS, *WRITE_ACTIONS,
        ):
            base_method = getattr(IntentService, method_name, None)
            method = getattr(cls, method_name, None)
            if method is None or method is base_method:
                continue
            if method_name not in policies:
                severity = "error" if (strict and method_name in WRITE_ACTIONS) else "warning"
                issues.append(
                    ValidationIssue(
                        intent_id=f"{model_name}.{method_name}",
                        severity=severity,
                        message="Method has no @intent policy (ungoverned)",
                    )
                )

        registered = getattr(cls, "_registered_commands", {}) or {}
        for cmd_name, info in registered.items():
            handler_name = info.get("handler")
            if handler_name and handler_name not in policies:
                severity = "error" if strict else "warning"
                issues.append(
                    ValidationIssue(
                        intent_id=f"{model_name}.{cmd_name}",
                        severity=severity,
                        message="Custom command has no @intent policy (ungoverned)",
                    )
                )

    for w in [i for i in issues if i.severity == "warning"]:
        logger.warning(f"intent validation: {w.intent_id} — {w.message}")
    for e in [i for i in issues if i.severity == "error"]:
        logger.error(f"intent validation: {e.intent_id} — {e.message}")

    errors = [i for i in issues if i.severity == "error"]
    return ValidationResult(issues=issues, passed=len(errors) == 0)
