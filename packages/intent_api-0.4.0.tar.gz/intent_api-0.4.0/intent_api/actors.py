"""
Built-in actor types.

`SystemActor` represents the caller for cron jobs, Celery Beat schedules,
internal background tasks, and any other code path where there is no
authenticated human user.

It flows through the normal policy pipeline — there is no magical bypass.
If a system job needs to call an intent that requires permission
"campaign:create", the SystemActor must have that permission granted via
the configured PermissionProvider (typically by adding a "system" role to
the role->permissions map).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class SystemActor:
    """
    Actor used for system-triggered intents (cron, Beat, internal jobs).

    Defaults to role="system", team_id="system", plan="system" — configure
    your providers to recognize these.
    """

    id: str = "system"
    role: str = "system"
    team_id: str = "system"
    plan: str = "system"
    metadata: Dict[str, Any] = field(default_factory=dict)
    email: Optional[str] = None

    def __getattr__(self, name: str) -> Any:
        if name in self.metadata:
            return self.metadata[name]
        raise AttributeError(name)
