"""
IntentRouter — The single-endpoint router factory.

Creates FastAPI routers that dispatch intents to registered services.
Supports multiple surfaces (standard, admin, guest, machine) from one configuration.

Example:
    from intent_api import IntentRouter, IntentService

    router = IntentRouter(debug=True)
    router.register("Todo", TodoService())

    # Standard surface (authenticated users)
    app.include_router(router.build(
        get_user=my_auth_dependency,
        get_db=my_db_dependency,
    ))

    # Machine surface (API key auth for SDKs / M2M)
    app.include_router(router.build_machine(
        get_user=my_api_key_auth,
        get_db=my_db_dependency,
    ))
"""

import inspect
import logging
from typing import Any, Awaitable, Callable, Dict, Optional, TYPE_CHECKING

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext, IntentRequest
from intent_api.service import IntentService

if TYPE_CHECKING:
    from intent_api.runtime import IntentRuntime

logger = logging.getLogger("intent_api")

# Type for the user-provided auth dependency
# Should accept (credentials, context) and return a user object
AuthDependency = Callable[..., Awaitable[Any]]

# Type for admin authorization check
# Should accept (user, context) and return True if authorized
AdminAuthorize = Callable[[Any, Optional[IntentContext]], bool]


# ── Debug Logging ─────────────────────────────────────────────────────────────


def _log_intent(
    intent: IntentRequest,
    user: Any,
    surface: str,
    debug_payload: bool = False,
) -> None:
    """Print a formatted debug box for an intent."""
    user_id = getattr(user, "id", user) if user else "guest"
    context_type = intent.context.type if intent.context else "none"

    logger.info("--------------------------------")
    logger.info("|")
    logger.info(f"| {surface} Intent received: {intent.model}")
    logger.info(f"| Action: {intent.action}")
    logger.info(f"| Command: {intent.command}")
    logger.info("|")
    logger.info(f"| ID: {intent.id}")
    logger.info(f"| User: {user_id}")
    logger.info(f"| Context: {context_type}")
    if debug_payload:
        logger.info(f"| Payload: {intent.payload}")
    logger.info("|")
    logger.info("--------------------------------")


# ── Dispatch ──────────────────────────────────────────────────────────────────


async def _dispatch(
    service: IntentService,
    intent: IntentRequest,
    db: Any,
    user: Any,
    context: Optional[IntentContext],
    runtime: Optional["IntentRuntime"] = None,
    model_name: Optional[str] = None,
    surface: str = "standard",
) -> Any:
    """
    Core dispatch logic. Routes an intent to the correct service method.

    If a runtime is configured, every dispatch flows through
    `runtime.execute()` — permission, billing, quota, audit, and logging
    are all enforced before the handler runs. With no runtime, behavior
    is identical to v0.2.0 (direct handler call).

    The `surface` argument is bound to structlog contextvars so every
    log emitted inside the handler carries its origin (standard/admin/
    guest/machine/mcp).
    """
    if intent.action == "custom" and not intent.command:
        raise HTTPException(
            status_code=400, detail="Missing 'command' for custom action."
        )

    handler, method_name = _resolve_service_handler(service, intent)
    resolved_model = model_name or service.__class__.__name__

    try:
        from intent_api.logging.context import bind_intent_context

        bind_intent_context(
            model=resolved_model,
            action=intent.action,
            command=intent.command,
            user=user,
            surface=surface,
        )
    except ImportError:
        pass

    if runtime is not None:
        intent_id = f"{resolved_model}.{method_name}"
        return await _execute_with_runtime(
            runtime=runtime,
            intent_id=intent_id,
            handler=handler,
            actor=user,
            db=db,
            context=context,
            intent=intent,
        )

    common: Dict[str, Any] = {"db": db, "user": user, "context": context}
    if intent.action == "create":
        return await handler(**common, payload=intent.payload)
    if intent.action == "read":
        return await handler(**common, id=intent.id)
    if intent.action == "update":
        return await handler(**common, id=intent.id, payload=intent.payload)
    if intent.action == "delete":
        return await handler(**common, id=intent.id)
    if intent.action == "list":
        return await handler(**common, skip=intent.skip, limit=intent.limit)
    if intent.action == "custom":
        return await service.custom_action(
            **common, command=intent.command, id=intent.id, payload=intent.payload
        )
    raise HTTPException(
        status_code=400, detail=f"Unknown action '{intent.action}'."
    )


def _resolve_service_handler(service: IntentService, intent: IntentRequest):
    """Return the bound handler + the method name used for intent_id."""
    if intent.action == "custom":
        commands = getattr(service.__class__, "_registered_commands", {}) or {}
        if intent.command in commands:
            handler_name = commands[intent.command]["handler"]
            return getattr(service, handler_name), intent.command
        return service.custom_action, intent.command
    return getattr(service, intent.action), intent.action


async def _execute_with_runtime(
    *,
    runtime: "IntentRuntime",
    intent_id: str,
    handler,
    actor: Any,
    db: Any,
    context: Optional[IntentContext],
    intent: IntentRequest,
) -> Any:
    from intent_api.providers.errors import (
        IntentRuntimeError,
        PermissionDenied,
        PlanUpgradeRequired,
        QuotaExceeded,
        ProviderNotConfigured,
        TaskDispatchFailed,
        UngovernedIntent,
    )

    try:
        if intent.action == "custom":
            return await runtime.execute(
                intent_id=intent_id, handler=handler, actor=actor, db=db,
                context=context, payload=intent.payload, id=intent.id,
            )
        if intent.action in ("read", "delete"):
            return await runtime.execute(
                intent_id=intent_id, handler=handler, actor=actor, db=db,
                context=context, id=intent.id,
            )
        if intent.action == "list":
            return await runtime.execute(
                intent_id=intent_id, handler=handler, actor=actor, db=db,
                context=context, skip=intent.skip, limit=intent.limit,
            )
        if intent.action == "update":
            return await runtime.execute(
                intent_id=intent_id, handler=handler, actor=actor, db=db,
                context=context, id=intent.id, payload=intent.payload,
            )
        return await runtime.execute(
            intent_id=intent_id, handler=handler, actor=actor, db=db,
            context=context, payload=intent.payload,
        )
    except PermissionDenied as exc:
        raise HTTPException(status_code=403, detail=exc.to_dict())
    except PlanUpgradeRequired as exc:
        raise HTTPException(status_code=402, detail=exc.to_dict())
    except QuotaExceeded as exc:
        raise HTTPException(status_code=429, detail=exc.to_dict())
    except ProviderNotConfigured as exc:
        raise HTTPException(status_code=500, detail=exc.to_dict())
    except TaskDispatchFailed as exc:
        raise HTTPException(status_code=500, detail=exc.to_dict())
    except UngovernedIntent as exc:
        raise HTTPException(status_code=500, detail=exc.to_dict())
    except IntentRuntimeError as exc:
        raise HTTPException(status_code=500, detail=exc.to_dict())


# ── Router Factory ────────────────────────────────────────────────────────────


class IntentRouter:
    """
    Factory for creating intent-based FastAPI routers.

    Usage:
        router = IntentRouter(debug=True, debug_payload=True)
        router.register("Todo", TodoService())
        router.register("User", UserService())

        app.include_router(router.build(
            get_user=my_auth_dependency,
            get_db=my_db_dependency,
        ))

    Args:
        prefix: URL prefix for all intent endpoints. Defaults to "/api".
        debug: Enable debug logging for all intents. Defaults to False.
        debug_payload: Also log the payload (may contain sensitive data — DEV only). Defaults to False.
    """

    def __init__(
        self,
        prefix: str = "/api",
        debug: bool = False,
        debug_payload: bool = False,
        runtime: Optional["IntentRuntime"] = None,
    ) -> None:
        self._registry = ServiceRegistry()
        self._prefix = prefix
        self._debug = debug
        self._debug_payload = debug_payload
        self._runtime = runtime
        self._validation_done = False
        if runtime is not None:
            runtime.bind(registry=self._registry)

    @property
    def runtime(self) -> Optional["IntentRuntime"]:
        return self._runtime

    def validate(self):
        """Run runtime validation. Idempotent."""
        if self._runtime is not None and not self._validation_done:
            result = self._runtime.validate()
            self._validation_done = True
            return result
        return None

    def _ensure_validated(self) -> None:
        if self._runtime is not None and not self._validation_done:
            self._runtime.validate()
            self._validation_done = True

    # ── Registration ──────────────────────────────────────────────────────

    def register(
        self,
        model: str,
        service: IntentService,
        expose_mcp: bool = True,
    ) -> None:
        """
        Register an IntentService for a model name.

        Args:
            model: The model name (e.g., "User", "Order"). Case-sensitive.
            service: An instance of an IntentService subclass.
            expose_mcp: If True (default), this service is visible to MCP
                clients. If False, the service is REST-only.
        """
        self._registry.register(model, service, expose_mcp=expose_mcp)

    # ── Registry Inspector (for DevTools) ─────────────────────────────────

    def _build_registry_map(self) -> Dict[str, Any]:
        """
        Introspect the service registry and return file paths + line numbers
        for every registered service method. Used by the debug endpoint.

        For services using @custom_action decorators, returns per-command
        line numbers (so DevTools click-to-source opens directly at the
        decorated method, not at custom_action()).

        v0.3.0: each method entry also carries a `policy` dict containing
        the resolved IntentPolicySpec + a `source` field
        (explicit_decorator | class_default | ungoverned).
        """
        registry_map = {}

        for model_name in self._registry.models:
            service = self._registry.get(model_name)
            if not service:
                continue

            try:
                source_file = inspect.getfile(service.__class__)
            except (TypeError, OSError):
                source_file = "unknown"

            methods: Dict[str, Any] = {}
            policies = getattr(service.__class__, "_intent_policies", {}) or {}

            for method_name in ["create", "read", "update", "delete", "list"]:
                method = getattr(service.__class__, method_name, None)
                base_method = getattr(IntentService, method_name, None)
                if method is None or method is base_method:
                    continue
                entry: Dict[str, Any] = {}
                try:
                    _, line_number = inspect.getsourcelines(method)
                    entry["line"] = line_number
                except (TypeError, OSError):
                    pass
                policy_meta = _policy_metadata(method, policies, method_name)
                if policy_meta:
                    entry["policy"] = policy_meta
                if entry:
                    methods[method_name] = entry

            registered_commands = getattr(
                service.__class__, "_registered_commands", {}
            )
            if registered_commands:
                for command_name, info in registered_commands.items():
                    handler_name = info.get("handler")
                    if not handler_name:
                        continue
                    handler = getattr(service.__class__, handler_name, None)
                    if handler is None:
                        continue
                    entry = {}
                    try:
                        _, line_number = inspect.getsourcelines(handler)
                        entry["line"] = line_number
                    except (TypeError, OSError):
                        pass
                    policy_meta = _policy_metadata(handler, policies, handler_name)
                    if policy_meta:
                        entry["policy"] = policy_meta
                    if entry:
                        methods[command_name] = entry
            else:
                custom_method = getattr(
                    service.__class__, "custom_action", None
                )
                if custom_method is not None:
                    try:
                        _, line_number = inspect.getsourcelines(custom_method)
                        methods["custom"] = {"line": line_number}
                    except (TypeError, OSError):
                        pass

            default = getattr(service.__class__, "__default_intent__", None)
            registry_map[model_name] = {
                "service": service.__class__.__name__,
                "file": source_file,
                "methods": methods,
                "default_policy": _default_policy_dict(default),
            }

        return registry_map

    def build_debug_router(self) -> APIRouter:
        """
        Build a debug router with the registry inspection + Inspector endpoints.
        Only mount this when debug=True.

        Endpoints:
          GET /api/intent-debug/registry    — file paths + line numbers + governance per method
          GET /api/intent-debug/governance  — every intent with resolved policy + source + summary
          GET /api/intent-debug/providers   — configured/missing providers + types + warnings
          GET /api/intent-debug/validation  — startup validation issues
        """
        debug_router = APIRouter(tags=["Intent API (Debug)"])
        prefix = self._prefix

        @debug_router.get(f"{prefix}/intent-debug/registry")
        async def get_registry_map():
            return self._build_registry_map()

        @debug_router.get(f"{prefix}/intent-debug/governance")
        async def get_governance():
            return self._build_governance_view()

        @debug_router.get(f"{prefix}/intent-debug/providers")
        async def get_providers():
            return self._build_providers_view()

        @debug_router.get(f"{prefix}/intent-debug/validation")
        async def get_validation():
            return self._build_validation_view()

        return debug_router

    # ── Inspector view builders ────────────────────────────────────────────

    def _build_governance_view(self) -> Dict[str, Any]:
        intents: list = []
        summary = {
            "total": 0,
            "governed": 0,
            "ungoverned": 0,
            "deferred": 0,
            "audited": 0,
            "explicit_decorator": 0,
            "class_default": 0,
        }

        for model_name in self._registry.models:
            service = self._registry.get(model_name)
            if service is None:
                continue
            cls = service.__class__
            policies = getattr(cls, "_intent_policies", {}) or {}
            handler_methods = self._enumerate_handlers(service)

            for method_name in handler_methods:
                summary["total"] += 1
                method = getattr(cls, _resolve_handler_name(cls, method_name), None)
                spec = policies.get(method_name) or policies.get(
                    _resolve_handler_name(cls, method_name)
                )
                source = _policy_source(method, spec)
                entry = {
                    "intent_id": f"{model_name}.{method_name}",
                    "permission": getattr(spec, "permission", None) if spec else None,
                    "feature": getattr(spec, "feature", None) if spec else None,
                    "quota": getattr(spec, "quota", None) if spec else None,
                    "audit": getattr(spec, "audit", False) if spec else False,
                    "execution": getattr(spec, "execution", "immediate") if spec else None,
                    "preset": getattr(spec, "preset_name", None) if spec else None,
                    "source": source,
                }
                intents.append(entry)
                if source == "ungoverned":
                    summary["ungoverned"] += 1
                else:
                    summary["governed"] += 1
                    summary[source] = summary.get(source, 0) + 1
                if entry.get("execution") == "deferred":
                    summary["deferred"] += 1
                if entry.get("audit"):
                    summary["audited"] += 1

        return {"intents": intents, "summary": summary}

    def _build_providers_view(self) -> Dict[str, Any]:
        if self._runtime is None:
            return {"runtime": False, "providers": {}, "warnings": ["No IntentRuntime configured"]}
        provider_status = self._runtime.provider_status()
        warnings = []
        if not provider_status["task"]["configured"]:
            governance = self._build_governance_view()
            if governance["summary"]["deferred"] > 0:
                warnings.append(
                    "TaskProvider not configured — intents with execution='deferred' will fail."
                )
        if not provider_status["actor_serializer"]["configured"] and (
            provider_status["task"]["configured"]
            or provider_status["audit"]["configured"]
        ):
            warnings.append(
                "ActorSerializer not configured — required when TaskProvider OR AuditProvider is set."
            )
        return {
            "runtime": True,
            "strict": self._runtime.strict,
            "providers": provider_status,
            "warnings": warnings,
        }

    def _build_validation_view(self) -> Dict[str, Any]:
        if self._runtime is None:
            return {"runtime": False, "issues": []}
        result = self._runtime.validation_result
        if result is None:
            self._ensure_validated()
            result = self._runtime.validation_result
        if result is None:
            return {"runtime": True, "passed": True, "issues": []}
        return {
            "runtime": True,
            "strict": self._runtime.strict,
            "passed": result.passed,
            "issues": [
                {
                    "intent_id": i.intent_id,
                    "severity": i.severity,
                    "field": i.field,
                    "value": i.value,
                    "message": i.message,
                }
                for i in result.issues
            ],
            "summary": {
                "errors": len(result.errors),
                "warnings": len(result.warnings),
            },
        }

    def _enumerate_handlers(self, service) -> list:
        from intent_api.constants import READ_ACTIONS, WRITE_ACTIONS

        names: list = []
        for n in (*READ_ACTIONS, *WRITE_ACTIONS):
            base = getattr(IntentService, n, None)
            method = getattr(service.__class__, n, None)
            if method is not None and method is not base:
                names.append(n)
        for cmd_name in (
            getattr(service.__class__, "_registered_commands", {}) or {}
        ):
            names.append(cmd_name)
        return names

    @property
    def registry(self) -> ServiceRegistry:
        """Access the underlying service registry."""
        return self._registry

    # ── Standard Surface ──────────────────────────────────────────────────

    def build(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the standard authenticated intent router.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        self._ensure_validated()
        api_router = APIRouter(tags=tags or ["Intent API"])
        registry = self._registry
        runtime = self._runtime
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            if debug:
                _log_intent(intent, user, "Standard", debug_payload)

            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            if service.is_admin_only:
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            return await _dispatch(
                service, intent, db, user, intent.context,
                runtime=runtime, model_name=intent.model, surface="standard",
            )

        return api_router

    # ── Admin Surface ─────────────────────────────────────────────────────

    def build_admin(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        authorize: AdminAuthorize,
        path: str = "/admin-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the admin intent router with an additional authorization check.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            authorize: A callable (user, context) -> bool that returns True
                if the user is authorized for admin access.
            path: Endpoint path (appended to prefix). Defaults to "/admin-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        self._ensure_validated()
        api_router = APIRouter(tags=tags or ["Intent API (Admin)"])
        registry = self._registry
        runtime = self._runtime
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_admin_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Admin", debug_payload)

            # Admin authorization gate
            if not authorize(user, intent.context):
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(
                service, intent, db, user, intent.context,
                runtime=self._runtime, model_name=intent.model, surface="admin",
            )

        return api_router

    # ── Machine Surface (API Key Auth) ──────────────────────────────────

    def build_machine(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/machine-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the machine-to-machine intent router (API key auth).

        For SDK clients, external services, and M2M communication.
        Auth is handled by the provided get_user dependency, which
        should verify an API key (e.g., Clerk API keys, custom keys)
        instead of a JWT token.

        The get_user function receives (credentials, context, db) just like
        the standard surface — but credentials will contain an API key
        instead of a JWT. Your get_user implementation decides how to verify it.

        Args:
            get_user: FastAPI dependency that verifies the API key and returns a user/context.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/machine-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.

        Example:
            async def get_machine_user(credentials, context, db):
                api_key = credentials.credentials  # "sk_live_xxx"
                # Verify with Clerk API keys or your own key table
                project = verify_api_key(db, api_key)
                return project.owner  # Return the user who owns this key

            app.include_router(intent_router.build_machine(
                get_user=get_machine_user,
                get_db=get_db,
            ))
        """
        self._ensure_validated()
        api_router = APIRouter(tags=tags or ["Intent API (Machine)"])
        registry = self._registry
        runtime = self._runtime
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_machine_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            if debug:
                _log_intent(intent, user, "Machine", debug_payload)

            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(
                service, intent, db, user, intent.context,
                runtime=runtime, model_name=intent.model, surface="machine",
            )

        return api_router

    # ── MCP Surface ────────────────────────────────────────────────────────

    def build_mcp(
        self,
        *,
        get_user: AuthDependency,
        get_db: Optional[Callable] = None,
        server_name: str = "intent-api",
        instructions: Optional[str] = None,
        resource_metadata_url: Optional[str] = None,
    ):
        """
        Build the MCP surface as an ASGI app for `app.mount()`.

        Unlike the REST surfaces (which return FastAPI Routers consumed
        with `app.include_router()`), MCP speaks JSON-RPC 2.0 over Streamable
        HTTP — it is a mounted protocol, not a REST router (Boundary B6).

        IMPORTANT: FastMCP's session manager requires its lifespan to be
        attached to the parent FastAPI app. Build once, mount once, and
        pass the lifespan explicitly:

            mcp_app = intent_router.build_mcp(
                get_user=clerk_mcp_auth(...),
                get_db=get_db,
                resource_metadata_url="https://api.example.com/.well-known/oauth-protected-resource",
            )
            app = FastAPI(lifespan=mcp_app.lifespan)
            app.mount("/mcp", mcp_app)

        Args:
            get_user: Async function with signature (credentials, context, db) -> user.
                Identical contract to build_machine's get_user. Must NOT use
                FastAPI Depends() in its signature (Boundary B32).
            get_db: Optional dependency that yields a db session (sync or async
                generator). The MCP middleware closes it in finally to prevent
                pool leaks under concurrent load (Boundary B31).
            server_name: MCP server name advertised in the initialize response.
            instructions: Optional natural-language instructions for clients.
            resource_metadata_url: URL to your /.well-known/oauth-protected-resource
                endpoint. Sent in the WWW-Authenticate header on 401.

        Returns:
            A Starlette ASGI app for `app.mount()`.
        """
        self._ensure_validated()
        from intent_api.mcp_server import build_mcp_app

        return build_mcp_app(
            registry=self._registry,
            get_user=get_user,
            get_db=get_db,
            server_name=server_name,
            instructions=instructions,
            resource_metadata_url=resource_metadata_url,
            debug=self._debug,
            debug_payload=self._debug_payload,
            runtime=self._runtime,
        )

    def build_mcp_well_known(
        self,
        *,
        resource_url: str,
        authorization_server: str,
        additional_authorization_servers: Optional[list[str]] = None,
        scopes_supported: Optional[list[str]] = None,
        resource_name: Optional[str] = None,
        resource_documentation: Optional[str] = None,
    ) -> APIRouter:
        """
        Build the OAuth Protected Resource Metadata router (RFC 9728).

        MUST be mounted at the application root, not under the MCP prefix:

            app.include_router(intent_router.build_mcp_well_known(
                resource_url="https://api.example.com/mcp",
                authorization_server="https://example.clerk.accounts.dev",
            ))

        Returns:
            A FastAPI Router exposing GET /.well-known/oauth-protected-resource.
        """
        from intent_api.mcp_auth import build_well_known_router

        return build_well_known_router(
            resource_url=resource_url,
            authorization_server=authorization_server,
            additional_authorization_servers=additional_authorization_servers,
            scopes_supported=scopes_supported,
            resource_name=resource_name,
            resource_documentation=resource_documentation,
        )

    # ── Guest Surface ─────────────────────────────────────────────────────

    def build_guest(
        self,
        *,
        get_db: Optional[Callable] = None,
        path: str = "/guest-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the guest (unauthenticated) intent router.

        Only services with `is_guest_allowed = True` are accessible.
        Only actions in `allowed_guest_actions` are permitted.

        Args:
            get_db: Optional FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/guest-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        self._ensure_validated()
        api_router = APIRouter(tags=tags or ["Intent API (Guest)"])
        registry = self._registry
        runtime = self._runtime
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        if get_db:

            @api_router.post(endpoint)
            async def handle_guest_intent_with_db(
                intent: IntentRequest,
                request: Request,
                db=Depends(get_db),
            ):
                return await _handle_guest(
                    registry, intent, db=db, debug=debug,
                    debug_payload=debug_payload, runtime=runtime,
                )

        else:

            @api_router.post(endpoint)
            async def handle_guest_intent(
                intent: IntentRequest,
                request: Request,
            ):
                return await _handle_guest(
                    registry, intent, db=None, debug=debug,
                    debug_payload=debug_payload, runtime=runtime,
                )

        return api_router


async def _handle_guest(
    registry: ServiceRegistry,
    intent: IntentRequest,
    db: Any = None,
    debug: bool = False,
    debug_payload: bool = False,
    runtime: Optional["IntentRuntime"] = None,
) -> Any:
    """Shared guest dispatch logic."""
    if debug:
        _log_intent(intent, None, "Guest", debug_payload)

    service = registry.get(intent.model)
    if not service:
        raise HTTPException(
            status_code=404, detail="This action is not allowed."
        )

    if not service.guest_allowed(intent.action, intent.command):
        raise HTTPException(
            status_code=403,
            detail="You don't have permission to perform this action.",
        )

    if intent.action not in ("read", "list", "custom"):
        raise HTTPException(
            status_code=403, detail="Guests can only read or list."
        )

    return await _dispatch(
        service, intent, db=db, user=None, context=intent.context,
        runtime=runtime, model_name=intent.model, surface="guest",
    )


# ── Inspector helpers ───────────────────────────────────────────────────────


def _policy_metadata(method, policies: dict, name: str) -> Optional[Dict[str, Any]]:
    spec = getattr(method, "_intent_policy", None) or policies.get(name)
    if spec is None:
        return None
    return {
        "permission": spec.permission,
        "feature": spec.feature,
        "quota": spec.quota,
        "audit": spec.audit,
        "execution": spec.execution,
        "preset": spec.preset_name,
        "source": _policy_source(method, spec),
    }


def _policy_source(method, spec) -> str:
    if spec is None:
        return "ungoverned"
    if method is not None and getattr(method, "_intent_policy", None) is not None:
        return "explicit_decorator"
    return "class_default"


def _default_policy_dict(default) -> Optional[Dict[str, Any]]:
    if default is None:
        return None
    return {
        "write_preset": default.write_preset,
        "read_preset": default.read_preset,
        "permission_prefix": default.permission_prefix,
        "audit": default.audit,
    }


def _resolve_handler_name(cls, method_name: str) -> str:
    commands = getattr(cls, "_registered_commands", {}) or {}
    if method_name in commands:
        return commands[method_name]["handler"]
    return method_name
