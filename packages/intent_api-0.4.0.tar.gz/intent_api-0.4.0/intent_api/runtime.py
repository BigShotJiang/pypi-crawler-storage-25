"""
IntentRuntime — the central execution engine.

Two execution paths:

* `execute()` — request side. Runs the full pipeline:
      permission → billing → quota → execute (immediate) OR dispatch (deferred)
                                          → audit → log

* `execute_deferred()` — worker side. Runs the worker pipeline:
      deserialize actor → resolve handler → execute → audit → log
      (no permission/billing/quota — already done at dispatch time)

Provider failures fail fast with `ProviderNotConfigured`. Quota consumed
during a deferred dispatch that subsequently fails is rolled back via
`QuotaProvider.rollback()`. Audit and logger emit in `finally` and never
break the request.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional

from intent_api.policy import (
    IntentPolicySpec,
    PolicyRegistry,
    ValidationResult,
    validate_all_intents,
    IntentValidationError,
)
from intent_api.providers.errors import (
    IntentRuntimeError,  # noqa: F401 — exposed via type hint
    PermissionDenied,
    PlanUpgradeRequired,
    ProviderNotConfigured,
    QuotaExceeded,
    TaskDispatchFailed,
    UngovernedIntent,
)
from intent_api.providers.interfaces import (
    ActorSerializer,
    AuditProvider,
    BillingProvider,
    LoggerProvider,
    PermissionProvider,
    QuotaProvider,
    TaskProvider,
)
from intent_api.providers.simple import (
    SimpleActorSerializer,
    SimpleAuditProvider,
    SimpleBillingProvider,
    SimpleLoggerProvider,
    SimplePermissionProvider,
    SimpleQuotaProvider,
)

if TYPE_CHECKING:
    from intent_api.registry import ServiceRegistry

logger = logging.getLogger("intent_api.runtime")


_UNGOVERNED_SPEC = IntentPolicySpec()


class IntentRuntime:
    """The execution engine. Pass to `IntentRouter(runtime=...)`."""

    def __init__(
        self,
        *,
        policy: Optional[PolicyRegistry] = None,
        permission_provider: Optional[PermissionProvider] = None,
        billing_provider: Optional[BillingProvider] = None,
        quota_provider: Optional[QuotaProvider] = None,
        task_provider: Optional[TaskProvider] = None,
        audit_provider: Optional[AuditProvider] = None,
        logger_provider: Optional[LoggerProvider] = None,
        actor_serializer: Optional[ActorSerializer] = None,
        strict: bool = False,
    ) -> None:
        self._policy = policy
        self._permission = permission_provider
        self._billing = billing_provider
        self._quota = quota_provider
        self._task = task_provider
        self._audit = audit_provider
        self._logger = logger_provider
        self._actor_serializer = actor_serializer
        self._strict = strict
        self._registry: Optional["ServiceRegistry"] = None
        self._validation_result: Optional[ValidationResult] = None

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def bind(self, *, registry: "ServiceRegistry") -> None:
        """Bind to a ServiceRegistry. Called by IntentRouter automatically."""
        self._registry = registry

    def set_task_provider(self, provider: TaskProvider) -> None:
        """Post-construction setter — used to resolve SimpleTaskProvider's
        circular reference to the runtime."""
        self._task = provider

    @property
    def registry(self) -> "ServiceRegistry":
        if self._registry is None:
            raise RuntimeError(
                "Runtime not bound to a registry. Construct it via "
                "IntentRouter(runtime=...) which binds automatically, or call "
                "runtime.bind(registry=...) manually for non-router usage."
            )
        return self._registry

    @property
    def validation_result(self) -> Optional[ValidationResult]:
        return self._validation_result

    @property
    def strict(self) -> bool:
        return self._strict

    @property
    def policy(self) -> Optional[PolicyRegistry]:
        return self._policy

    def validate(self) -> ValidationResult:
        """
        Run startup validation. Called automatically the first time
        `IntentRouter.build_*()` is invoked. Idempotent — caches the result.

        In `strict=True` mode, raises `IntentValidationError` on failure.
        """
        if self._validation_result is not None:
            return self._validation_result

        registry = self.registry
        startup_audit_serializer_required(self)
        result = validate_all_intents(registry, self._policy, strict=self._strict)
        self._validation_result = result

        if self._strict and not result.passed:
            raise IntentValidationError(result.errors)

        return result

    # ── Provider access for Inspector ──────────────────────────────────────

    def provider_status(self) -> Dict[str, Dict[str, Any]]:
        """Snapshot of which providers are configured. Used by Inspector."""
        return {
            "permission": _provider_info(self._permission),
            "billing": _provider_info(self._billing),
            "quota": _provider_info(self._quota),
            "task": _provider_info(self._task),
            "audit": _provider_info(self._audit),
            "logger": _provider_info(self._logger),
            "actor_serializer": _provider_info(self._actor_serializer),
        }

    # ── Spec resolution ────────────────────────────────────────────────────

    def _resolve_spec(self, handler: Callable, intent_id: str) -> IntentPolicySpec:
        spec = getattr(handler, "_intent_policy", None)
        if spec is None:
            func = getattr(handler, "__func__", None)
            if func is not None:
                spec = getattr(func, "_intent_policy", None)
        if spec is None:
            instance = getattr(handler, "__self__", None)
            if instance is not None:
                policies = getattr(instance.__class__, "_intent_policies", {}) or {}
                method_name = intent_id.rsplit(".", 1)[-1]
                spec = policies.get(method_name)
                if spec is None:
                    func_name = getattr(handler, "__name__", None)
                    if func_name and func_name != method_name:
                        spec = policies.get(func_name)
        if spec is not None:
            return spec
        if self._strict:
            raise UngovernedIntent(intent_id)
        return _UNGOVERNED_SPEC

    # ── Request-side pipeline ──────────────────────────────────────────────

    async def execute(
        self,
        *,
        intent_id: str,
        handler: Callable,
        actor: Any,
        db: Any = None,
        context: Optional[Any] = None,
        payload: Optional[Dict[str, Any]] = None,
        id: Any = None,
        skip: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> Any:
        spec = self._resolve_spec(handler, intent_id)
        ctx_dict = _context_to_dict(context)
        start_time = time.time()
        quota_consumed = False

        await self._on_intent_start(
            intent_id=intent_id, actor=actor, spec=spec, phase="request"
        )

        try:
            if spec.permission is not None:
                self._require_provider("permission", self._permission)
                ok = await self._permission.has_permission(actor, spec.permission, ctx_dict)
                if not ok:
                    raise PermissionDenied(spec.permission)

            if spec.feature is not None:
                self._require_provider("billing", self._billing)
                ok = await self._billing.has_feature(actor, spec.feature, ctx_dict)
                if not ok:
                    raise PlanUpgradeRequired(spec.feature)

            if spec.quota is not None:
                self._require_provider("quota", self._quota)
                allowed, meta = await self._quota.check_and_consume(
                    actor, spec.quota, ctx_dict
                )
                if not allowed:
                    raise QuotaExceeded(spec.quota, **meta)
                quota_consumed = True

            if spec.execution == "deferred":
                self._require_provider("task", self._task)
                self._require_provider("actor_serializer", self._actor_serializer)
                actor_data = self._actor_serializer.serialize(actor)
                try:
                    intent_context = _capture_intent_context_safe()
                    dispatch_kwargs = self._build_dispatch_kwargs(
                        intent_id=intent_id,
                        actor_data=actor_data,
                        payload=payload,
                        intent_context=intent_context,
                    )
                    result = await self._task.dispatch(**dispatch_kwargs)
                except Exception as exc:
                    if quota_consumed and spec.quota is not None:
                        await self._best_effort_rollback(
                            actor, spec.quota, ctx_dict
                        )
                    raise TaskDispatchFailed(intent_id, original=str(exc)) from exc
            else:
                kwargs = _build_handler_kwargs(
                    handler, db=db, user=actor, context=context,
                    payload=payload, id=id, skip=skip, limit=limit,
                )
                result = await handler(**kwargs)

            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_success(
                intent_id=intent_id, actor=actor, spec=spec,
                elapsed_ms=elapsed_ms, phase="request",
            )
            return result

        except IntentRuntimeError as exc:
            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_denied(
                intent_id=intent_id, actor=actor, spec=spec,
                error=exc, elapsed_ms=elapsed_ms, phase="request",
            )
            raise
        except Exception as exc:
            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_failure(
                intent_id=intent_id, actor=actor, spec=spec,
                error=exc, elapsed_ms=elapsed_ms, phase="request",
            )
            raise

    # ── Worker-side pipeline ───────────────────────────────────────────────

    async def execute_deferred(
        self,
        *,
        intent_id: str,
        actor_data: Dict[str, Any],
        payload: Optional[Dict[str, Any]],
        db: Any = None,
        id: Any = None,
        context: Optional[Any] = None,
    ) -> Any:
        self._require_provider("actor_serializer", self._actor_serializer)
        actor = self._actor_serializer.deserialize(actor_data)
        handler = self._resolve_handler(intent_id)
        spec = self._resolve_spec(handler, intent_id)
        start_time = time.time()

        await self._on_intent_start(
            intent_id=intent_id, actor=actor, spec=spec, phase="deferred"
        )

        try:
            kwargs = _build_handler_kwargs(
                handler, db=db, user=actor, context=context,
                payload=payload, id=id, skip=None, limit=None,
            )
            result = await handler(**kwargs)
            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_success(
                intent_id=intent_id, actor=actor, spec=spec,
                elapsed_ms=elapsed_ms, phase="deferred",
            )
            return result
        except IntentRuntimeError as exc:
            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_denied(
                intent_id=intent_id, actor=actor, spec=spec,
                error=exc, elapsed_ms=elapsed_ms, phase="deferred",
            )
            raise
        except Exception as exc:
            elapsed_ms = round((time.time() - start_time) * 1000)
            await self._on_intent_failure(
                intent_id=intent_id, actor=actor, spec=spec,
                error=exc, elapsed_ms=elapsed_ms, phase="deferred",
            )
            raise

    # ── Helpers ────────────────────────────────────────────────────────────

    def _require_provider(self, name: str, provider: Any) -> None:
        if provider is None:
            raise ProviderNotConfigured(name)

    def _resolve_handler(self, intent_id: str) -> Callable:
        if "." not in intent_id:
            raise ValueError(f"Invalid intent_id format: {intent_id!r} (expected 'Model.method')")
        model_name, method_name = intent_id.rsplit(".", 1)
        service = self.registry.get(model_name)
        if service is None:
            raise ValueError(f"Model '{model_name}' is not registered.")

        commands = getattr(service.__class__, "_registered_commands", {}) or {}
        if method_name in commands:
            handler_attr = commands[method_name]["handler"]
        else:
            handler_attr = method_name

        handler = getattr(service, handler_attr, None)
        if handler is None or not callable(handler):
            raise ValueError(
                f"Handler '{handler_attr}' not found on {service.__class__.__name__}."
            )
        return handler

    # ── Lifecycle hooks (v0.4.0) ───────────────────────────────────────────
    #
    # All four hooks are async and the runtime AWAITS them. Provider calls
    # inside use _safe_log which catches and logs any exception so a
    # broken logger/audit provider never breaks the request pipeline.
    #
    # AuditProvider and LoggerProvider receive the SAME canonical event
    # dict, including the serialized actor — so observability platforms
    # and compliance audit logs see the exact same data.

    async def _on_intent_start(
        self, *, intent_id: str, actor: Any, spec: IntentPolicySpec, phase: str
    ) -> None:
        event = self._build_event(
            intent_id=intent_id, actor=actor, spec=spec,
            phase=phase, status="start", elapsed_ms=None, error=None,
        )
        if self._logger is not None:
            await self._safe_log(self._logger, event, "logger")

    async def _on_intent_success(
        self, *, intent_id: str, actor: Any, spec: IntentPolicySpec,
        elapsed_ms: int, phase: str,
    ) -> None:
        event = self._build_event(
            intent_id=intent_id, actor=actor, spec=spec,
            phase=phase, status="success", elapsed_ms=elapsed_ms, error=None,
        )
        if self._logger is not None:
            await self._safe_log(self._logger, event, "logger")
        if spec.audit and self._audit is not None:
            await self._safe_log(self._audit, event, "audit")

    async def _on_intent_denied(
        self, *, intent_id: str, actor: Any, spec: IntentPolicySpec,
        error: "IntentRuntimeError", elapsed_ms: int, phase: str,
    ) -> None:
        event = self._build_event(
            intent_id=intent_id, actor=actor, spec=spec,
            phase=phase, status="denied", elapsed_ms=elapsed_ms,
            error=error.message,
        )
        event["intent_error_code"] = error.code
        event["intent_error_detail"] = error.detail
        event["_level"] = "warning"
        if self._logger is not None:
            await self._safe_log(self._logger, event, "logger")
        if spec.audit and self._audit is not None:
            await self._safe_log(self._audit, event, "audit")

    async def _on_intent_failure(
        self, *, intent_id: str, actor: Any, spec: IntentPolicySpec,
        error: BaseException, elapsed_ms: int, phase: str,
    ) -> None:
        event = self._build_event(
            intent_id=intent_id, actor=actor, spec=spec,
            phase=phase, status="failure", elapsed_ms=elapsed_ms,
            error=f"{type(error).__name__}: {error}",
        )
        event["_level"] = "error"
        if self._logger is not None:
            await self._safe_log(self._logger, event, "logger")
        if spec.audit and self._audit is not None:
            await self._safe_log(self._audit, event, "audit")

    def _build_event(
        self,
        *,
        phase: str,
        intent_id: str,
        actor: Any,
        spec: IntentPolicySpec,
        status: str,
        elapsed_ms: Optional[int],
        error: Optional[str],
    ) -> Dict[str, Any]:
        """Build the canonical lifecycle event dict.

        The same shape is sent to BOTH LoggerProvider and AuditProvider
        (B44 from v0.3.0, preserved in v0.4.0). `_level` may be added
        on top by hooks that need a non-default severity.
        """
        actor_payload: Any
        if self._actor_serializer is not None:
            try:
                actor_payload = self._actor_serializer.serialize(actor)
            except Exception:
                actor_payload = repr(actor)
        else:
            actor_payload = repr(actor)
        return {
            "intent_id": intent_id,
            "phase": phase,
            "actor": actor_payload,
            "policy": {
                "permission": spec.permission,
                "feature": spec.feature,
                "quota": spec.quota,
                "audit": spec.audit,
                "execution": spec.execution,
                "preset": spec.preset_name,
            },
            "status": status,
            "elapsed_ms": elapsed_ms,
            "error": error,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    async def _safe_log(self, provider: Any, event: Dict[str, Any], kind: str) -> None:
        try:
            await provider.log(event)
        except Exception:
            logger.exception("Runtime %s provider raised — swallowed", kind)

    def _build_dispatch_kwargs(
        self, *, intent_id: str, actor_data: Dict[str, Any],
        payload: Optional[Dict[str, Any]], intent_context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Build the kwargs dict for TaskProvider.dispatch().

        Introspects the provider's signature to decide whether to pass
        `intent_context` — preserves backward compatibility with custom
        TaskProviders written for v0.3.0 that don't accept the param.
        """
        kwargs: Dict[str, Any] = {
            "intent_id": intent_id,
            "actor_data": actor_data,
            "payload": payload,
        }
        try:
            sig = inspect.signature(self._task.dispatch)
            params = sig.parameters
            if "intent_context" in params or any(
                p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
            ):
                kwargs["intent_context"] = intent_context
        except (TypeError, ValueError):
            kwargs["intent_context"] = intent_context
        return kwargs

    async def _best_effort_rollback(
        self, actor: Any, quota_key: str, ctx: Dict[str, Any]
    ) -> None:
        if self._quota is None:
            return
        try:
            await self._quota.rollback(actor, quota_key, ctx)
        except Exception:
            logger.exception(
                "QuotaProvider.rollback() failed for %s — swallowed", quota_key
            )

    # ── Factory ────────────────────────────────────────────────────────────

    @classmethod
    def dev_mode(
        cls,
        *,
        role_permissions: Optional[Dict[str, list]] = None,
        feature_plans: Optional[Dict[str, list]] = None,
        quota_limits: Optional[Dict[str, int]] = None,
        strict: bool = False,
        use_structlog: bool = True,
    ) -> "IntentRuntime":
        """
        Return a runtime wired with all SimpleProviders (except TaskProvider).

        Wire SimpleTaskProvider afterward if you need deferred execution:

            runtime = IntentRuntime.dev_mode(...)
            runtime.set_task_provider(SimpleTaskProvider(runtime, session_factory=get_db))

        Args:
            use_structlog: If True (default), uses `StructlogLoggerProvider`
                so runtime events flow through the structlog pipeline (the
                v0.4.0 recommended default). Set False to fall back to the
                v0.3.0 `SimpleLoggerProvider` (Python stdlib logger).
        """
        if use_structlog:
            try:
                from intent_api.logging import StructlogLoggerProvider

                logger_provider = StructlogLoggerProvider()
            except ImportError:
                logger_provider = SimpleLoggerProvider()
        else:
            logger_provider = SimpleLoggerProvider()

        return cls(
            policy=PolicyRegistry.permissive(),
            permission_provider=SimplePermissionProvider(
                role_permissions or {"admin": ["*"]}
            ),
            billing_provider=SimpleBillingProvider(feature_plans or {}),
            quota_provider=SimpleQuotaProvider(quota_limits or {}),
            audit_provider=SimpleAuditProvider(),
            logger_provider=logger_provider,
            actor_serializer=SimpleActorSerializer(),
            strict=strict,
        )


# ── Module helpers ───────────────────────────────────────────────────────────


def startup_audit_serializer_required(runtime: IntentRuntime) -> None:
    """B37: ActorSerializer is required when TaskProvider OR AuditProvider is set."""
    needs = runtime._task is not None or runtime._audit is not None
    if needs and runtime._actor_serializer is None:
        raise ProviderNotConfigured("actor_serializer")


def _capture_intent_context_safe() -> Dict[str, Any]:
    """Safely capture structlog contextvars without forcing the import.

    Returns {} when intent-api[logging] isn't installed or no context is bound.
    Used by the deferred-dispatch path to propagate context into TaskProvider.
    """
    try:
        from intent_api.logging.context import capture_intent_context

        return capture_intent_context()
    except Exception:
        return {"phase": "deferred"}


def _provider_info(provider: Any) -> Dict[str, Any]:
    if provider is None:
        return {"configured": False, "type": None}
    return {"configured": True, "type": type(provider).__name__}


def _context_to_dict(context: Any) -> Dict[str, Any]:
    if context is None:
        return {}
    if isinstance(context, dict):
        return context
    if hasattr(context, "model_dump"):
        return context.model_dump()
    if hasattr(context, "__dict__"):
        return {k: v for k, v in context.__dict__.items() if not k.startswith("_")}
    return {"value": context}


def _build_handler_kwargs(
    handler: Callable,
    *,
    db: Any,
    user: Any,
    context: Any,
    payload: Optional[Dict[str, Any]],
    id: Any,
    skip: Optional[int],
    limit: Optional[int],
) -> Dict[str, Any]:
    """Build kwargs dict matching whatever the handler accepts."""
    sig = inspect.signature(handler)
    accepted = sig.parameters
    candidates = {
        "db": db,
        "user": user,
        "context": context,
        "payload": payload,
        "id": id,
        "skip": skip,
        "limit": limit,
    }
    return {k: v for k, v in candidates.items() if k in accepted}
