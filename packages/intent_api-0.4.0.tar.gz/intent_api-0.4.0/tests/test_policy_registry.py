"""Tests for PolicyRegistry + startup validation (Phase 3)."""

from __future__ import annotations

import pytest
from dataclasses import FrozenInstanceError

from intent_api import (
    IntentPolicySpec,
    IntentService,
    IntentValidationError,
    PolicyRegistry,
    ServiceRegistry,
    custom_action,
    intent,
)
from intent_api.policy import validate_all_intents


# ── PolicyRegistry basics ────────────────────────────────────────────────────


def test_known_permission_passes():
    reg = PolicyRegistry(permissions=["x:y"])
    spec = IntentPolicySpec(permission="x:y")
    assert reg.validate_spec("M.create", spec) == []


def test_unknown_permission_flagged():
    reg = PolicyRegistry(permissions=["x:y"])
    spec = IntentPolicySpec(permission="x:z")
    issues = reg.validate_spec("M.create", spec)
    assert len(issues) == 1
    assert issues[0].field == "permission"
    assert issues[0].severity == "error"
    assert "x:z" in issues[0].message


def test_unknown_feature_flagged():
    reg = PolicyRegistry(features=["a"])
    spec = IntentPolicySpec(feature="b")
    issues = reg.validate_spec("M.x", spec)
    assert len(issues) == 1
    assert issues[0].field == "feature"


def test_unknown_quota_flagged():
    reg = PolicyRegistry(quotas=["a"])
    spec = IntentPolicySpec(quota="b")
    issues = reg.validate_spec("M.x", spec)
    assert len(issues) == 1
    assert issues[0].field == "quota"


def test_permissive_accepts_everything():
    reg = PolicyRegistry.permissive()
    spec = IntentPolicySpec(permission="anything", feature="anything", quota="anything")
    assert reg.validate_spec("M.x", spec) == []


def test_registry_immutable():
    reg = PolicyRegistry(permissions=["x"])
    with pytest.raises(FrozenInstanceError):
        reg.permissions = frozenset(["y"])  # type: ignore


# ── End-to-end validation ────────────────────────────────────────────────────


class _S1(IntentService):
    __default_intent__ = intent.defaults(permission_prefix="campaign", audit=True)
    async def create(self, *, db, user, context, payload=None): pass
    async def list(self, *, db, user, context=None, skip=0, limit=10): pass


class _S2(IntentService):
    @intent(permission="x:y", feature="bad_feature", quota="bad_quota")
    @custom_action()
    async def thing(self, *, db, user, context, id, payload): pass


def _build_registry() -> ServiceRegistry:
    r = ServiceRegistry()
    r.register("Campaign", _S1())
    r.register("Other", _S2())
    return r


def test_validation_catches_unknown_permissions():
    registry = _build_registry()
    policy = PolicyRegistry(
        permissions=["campaign:create"],  # Missing campaign:list, x:y
        features=[],
        quotas=[],
    )
    result = validate_all_intents(registry, policy, strict=False)
    error_intents = {i.intent_id for i in result.errors}
    assert "Other.thing" in error_intents
    assert "Campaign.list" in error_intents


def test_strict_mode_raises_via_iiv():
    registry = _build_registry()
    policy = PolicyRegistry(permissions=["x"])
    result = validate_all_intents(registry, policy, strict=True)
    assert not result.passed


def test_intent_validation_error_message():
    from intent_api.policy import ValidationIssue
    err = IntentValidationError([
        ValidationIssue(intent_id="M.x", severity="error", message="bad"),
    ])
    assert "M.x" in str(err)
    assert "bad" in str(err)


# ── Ungoverned mutating method handling ──────────────────────────────────────


def test_strict_mode_flags_ungoverned_writes_as_errors():
    class S(IntentService):
        async def create(self, *, db, user, context, payload=None): pass
        async def list(self, *, db, user, context=None, skip=0, limit=10): pass

    r = ServiceRegistry()
    r.register("S", S())
    result = validate_all_intents(r, PolicyRegistry.permissive(), strict=True)

    severities = {i.intent_id: i.severity for i in result.issues}
    assert severities["S.create"] == "error"
    assert severities["S.list"] == "warning"


def test_non_strict_flags_all_ungoverned_as_warnings():
    class S(IntentService):
        async def create(self, *, db, user, context, payload=None): pass

    r = ServiceRegistry()
    r.register("S", S())
    result = validate_all_intents(r, PolicyRegistry.permissive(), strict=False)
    severities = {i.intent_id: i.severity for i in result.issues}
    assert severities["S.create"] == "warning"
