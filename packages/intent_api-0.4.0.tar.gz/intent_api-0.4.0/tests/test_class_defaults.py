"""Tests for __default_intent__ class-level policy resolution (Phase 2)."""

from __future__ import annotations

import pytest

from intent_api import IntentService, custom_action, intent


# ── Class default → CRUD policies derived ────────────────────────────────────


class CampaignService(IntentService):
    """Campaigns."""
    __default_intent__ = intent.defaults(
        permission_prefix="campaign",
        write_preset="standard_write",
        read_preset="standard_read",
        audit=True,
    )

    async def create(self, *, db, user, context, payload=None): pass
    async def read(self, *, db, user, id, context=None): pass
    async def update(self, *, db, user, id, context=None, payload=None): pass
    async def delete(self, *, db, user, id, context=None): pass
    async def list(self, *, db, user, context=None, skip=0, limit=10): pass

    @custom_action()
    async def archive(self, *, db, user, context, id, payload): pass


def test_class_default_resolves_crud_permissions():
    p = CampaignService._intent_policies
    assert p["create"].permission == "campaign:create"
    assert p["read"].permission == "campaign:read"
    assert p["update"].permission == "campaign:update"
    assert p["delete"].permission == "campaign:delete"
    assert p["list"].permission == "campaign:list"


def test_read_actions_use_read_preset():
    p = CampaignService._intent_policies
    assert p["read"].preset_name == "standard_read"
    assert p["list"].preset_name == "standard_read"


def test_write_actions_use_write_preset():
    p = CampaignService._intent_policies
    for name in ("create", "update", "delete"):
        assert p[name].preset_name == "standard_write"


def test_class_default_audit_overrides_preset_audit():
    p = CampaignService._intent_policies
    assert p["read"].audit is True
    assert p["list"].audit is True
    assert p["create"].audit is True


def test_custom_action_gets_write_preset_from_default():
    p = CampaignService._intent_policies
    assert p["archive"].permission == "campaign:archive"
    assert p["archive"].preset_name == "standard_write"


# ── Explicit @intent overrides class default completely ─────────────────────


def test_explicit_intent_overrides_completely():
    class S(IntentService):
        __default_intent__ = intent.defaults(permission_prefix="x", audit=True)

        @intent(permission="custom:perm", audit=False)
        async def create(self, *, db, user, context, payload=None): pass

    spec = S._intent_policies["create"]
    assert spec.permission == "custom:perm"
    assert spec.audit is False


# ── No default + no decorator → ungoverned ──────────────────────────────────


def test_no_default_no_decorator_is_ungoverned():
    class S(IntentService):
        async def create(self, *, db, user, context, payload=None): pass

    assert S._intent_policies == {}


# ── Mixed: some decorated, some defaulted ───────────────────────────────────


def test_mixed_explicit_and_default():
    class S(IntentService):
        __default_intent__ = intent.defaults(permission_prefix="x", audit=True)

        async def create(self, *, db, user, context, payload=None): pass

        @intent(permission="x:special_update")
        async def update(self, *, db, user, id, context=None, payload=None): pass

    p = S._intent_policies
    assert p["create"].permission == "x:create"
    assert p["create"].preset_name == "standard_write"
    assert p["update"].permission == "x:special_update"
    assert p["update"].preset_name is None


# ── Invalid __default_intent__ ───────────────────────────────────────────────


def test_invalid_default_intent_raises():
    with pytest.raises(TypeError, match="must be an IntentDefaultPolicy"):
        class S(IntentService):
            __default_intent__ = "not a policy"
            async def create(self, *, db, user, context, payload=None): pass


# ── v0.2.0 backward compat ───────────────────────────────────────────────────


def test_v020_service_with_only_custom_action_unchanged():
    class S(IntentService):
        @custom_action()
        async def archive(self, *, db, user, context, id, payload): pass

    assert "archive" in S._registered_commands
    assert S._intent_policies == {}
