"""Tests for IntentLogConfig + setup_intent_logging() (Phase 1)."""

from __future__ import annotations

import logging

import pytest
import structlog

from intent_api.logging import (
    IntentLogConfig,
    IntentLoggingHandle,
    StructlogLoggerProvider,
    setup_intent_logging,
)


def test_config_requires_service_name():
    with pytest.raises(ValueError, match="service_name is required"):
        IntentLogConfig(service_name="")


def test_config_validates_log_level():
    with pytest.raises(ValueError, match="log_level must be one of"):
        IntentLogConfig(service_name="x", log_level="LOUD")


def test_config_is_frozen():
    cfg = IntentLogConfig(service_name="x")
    with pytest.raises(Exception):
        cfg.service_name = "y"  # type: ignore


def test_setup_returns_handle_with_structlog_provider():
    handle = setup_intent_logging(IntentLogConfig(service_name="api-test"))
    assert isinstance(handle, IntentLoggingHandle)
    assert isinstance(handle.logger_provider, StructlogLoggerProvider)
    assert handle.otel_provider is None


def test_setup_replaces_root_handlers():
    handle = setup_intent_logging(IntentLogConfig(service_name="api-test"))
    handlers = logging.getLogger().handlers
    assert len(handlers) == 1


def test_setup_quiets_noisy_loggers():
    setup_intent_logging(IntentLogConfig(service_name="api-test"))
    for name in ("uvicorn.access", "asyncio", "httpx"):
        assert logging.getLogger(name).level == logging.WARNING


def test_setup_log_level_applied():
    setup_intent_logging(IntentLogConfig(service_name="x", log_level="WARNING"))
    assert logging.getLogger().level == logging.WARNING


def test_handle_shutdown_no_op_without_otel():
    handle = setup_intent_logging(IntentLogConfig(service_name="x"))
    handle.shutdown()
