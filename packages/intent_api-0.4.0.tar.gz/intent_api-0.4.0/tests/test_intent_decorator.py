"""Tests for the @intent decorator system (Phase 1)."""

from __future__ import annotations

import pytest
from pydantic import BaseModel

from intent_api import (
    IntentPolicySpec,
    IntentService,
    READ_ACTIONS,
    WRITE_ACTIONS,
    custom_action,
    intent,
)


class _Payload(BaseModel):
    name: str


# ── Raw decorator ────────────────────────────────────────────────────────────


def test_raw_decorator_attaches_spec():
    @intent(permission="x:y", audit=True)
    async def fn(self, *, db, user, context, payload=None):
        pass

    spec = fn._intent_policy
    assert spec.permission == "x:y"
    assert spec.audit is True
    assert spec.execution == "immediate"
    assert spec.preset_name is None


def test_raw_decorator_invalid_execution_raises():
    with pytest.raises(ValueError, match="execution must be one of"):
        @intent(execution="async")
        async def fn(self): pass


def test_deferred_on_read_method_raises():
    with pytest.raises(ValueError, match="Deferred execution not supported"):
        @intent(execution="deferred")
        async def read(self): pass


def test_deferred_on_list_method_raises():
    with pytest.raises(ValueError, match="Deferred execution not supported"):
        @intent(execution="deferred")
        async def list(self): pass


# ── Preset ───────────────────────────────────────────────────────────────────


def test_preset_resolves_defaults():
    @intent.preset("standard_write", permission="x:y")
    async def fn(self): pass

    spec = fn._intent_policy
    assert spec.preset_name == "standard_write"
    assert spec.permission == "x:y"
    assert spec.audit is True
    assert spec.execution == "immediate"


def test_preset_missing_required_raises_at_decoration():
    with pytest.raises(TypeError, match="requires 'permission'"):
        @intent.preset("standard_write")
        async def fn(self): pass


def test_preset_unknown_raises():
    with pytest.raises(ValueError, match="Unknown preset"):
        @intent.preset("nonexistent_preset", permission="x")
        async def fn(self): pass


# ── Custom presets ───────────────────────────────────────────────────────────


def test_define_preset_then_use():
    intent.define_preset("test_preset_1", {"execution": "immediate", "audit": True}, requires=["permission"])

    @intent.preset("test_preset_1", permission="x:y")
    async def fn(self): pass

    assert fn._intent_policy.preset_name == "test_preset_1"


def test_define_preset_invalid_execution():
    with pytest.raises(ValueError, match="invalid execution"):
        intent.define_preset("bad_exec", {"execution": "asnyc", "audit": True})


def test_define_preset_invalid_requires():
    with pytest.raises(ValueError, match="invalid requires"):
        intent.define_preset("bad_req", {"audit": True}, requires=["permission", "magic"])


def test_define_preset_invalid_audit():
    with pytest.raises(ValueError, match="audit must be bool"):
        intent.define_preset("bad_audit", {"audit": "yes"})


def test_define_preset_cannot_override_builtin():
    with pytest.raises(ValueError, match="Cannot redefine built-in"):
        intent.define_preset("standard_write", {"audit": True})


# ── Defaults ─────────────────────────────────────────────────────────────────


def test_defaults_returns_default_policy():
    d = intent.defaults(permission_prefix="x", audit=False)
    from intent_api import IntentDefaultPolicy
    assert isinstance(d, IntentDefaultPolicy)
    assert d.permission_prefix == "x"
    assert d.audit is False
    assert d.write_preset == "standard_write"


def test_defaults_unknown_preset_raises():
    with pytest.raises(ValueError, match="Unknown write_preset"):
        intent.defaults(write_preset="nonexistent")


# ── @intent + @custom_action compose ─────────────────────────────────────────


def test_intent_and_custom_action_compose():
    class S(IntentService):
        @intent(permission="x:y")
        @custom_action()
        async def my_cmd(self, *, db, user, context, id, payload): pass

    assert "my_cmd" in S._registered_commands
    assert S._intent_policies["my_cmd"].permission == "x:y"


# ── Constants ────────────────────────────────────────────────────────────────


def test_action_constants_are_frozen():
    assert isinstance(READ_ACTIONS, frozenset)
    assert isinstance(WRITE_ACTIONS, frozenset)
    assert "read" in READ_ACTIONS
    assert "list" in READ_ACTIONS
    assert "create" in WRITE_ACTIONS
