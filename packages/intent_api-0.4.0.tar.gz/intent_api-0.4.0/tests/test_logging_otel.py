"""Tests for the OTel structlog processor (Phase 2)."""

from __future__ import annotations

import structlog

from intent_api import IntentLogConfig, setup_intent_logging


def test_setup_without_endpoint_does_not_load_otel():
    handle = setup_intent_logging(IntentLogConfig(service_name="x"))
    assert handle.otel_provider is None


def test_setup_with_endpoint_builds_provider():
    handle = setup_intent_logging(IntentLogConfig(
        service_name="x",
        otel_endpoint="http://localhost:4318/v1/logs",
        otel_api_key="token",
        otel_headers={"x-extra": "y"},
    ))
    assert handle.otel_provider is not None
    handle.shutdown()


def test_otel_processor_emits_attributes():
    """When OTel is configured, emitting through structlog should
    invoke the otel processor without raising (even if the collector
    is unreachable — it's batched and retried)."""
    handle = setup_intent_logging(IntentLogConfig(
        service_name="x",
        otel_endpoint="http://127.0.0.1:1/v1/logs",
    ))
    log = structlog.get_logger()
    log.info("emitted_event", foo="bar", nested={"x": 1})
    log.warning("attrs_with_complex", items=[1, 2, 3])
    handle.shutdown()
