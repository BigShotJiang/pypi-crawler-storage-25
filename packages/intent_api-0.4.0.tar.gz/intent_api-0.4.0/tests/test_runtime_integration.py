"""Integration tests — full HTTP + MCP flows through IntentRuntime (Phase 5)."""

from __future__ import annotations

import asyncio
import json
import socket
import time
from threading import Thread

import httpx
import pytest
import uvicorn
from fastapi import FastAPI

from intent_api import (
    IntentRouter,
    IntentService,
    PolicyRegistry,
    custom_action,
    intent,
)
from intent_api.providers import (
    SimpleActorSerializer,
    SimpleAuditProvider,
    SimpleBillingProvider,
    SimpleLoggerProvider,
    SimplePermissionProvider,
    SimpleQuotaProvider,
)
from intent_api.runtime import IntentRuntime


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class _Actor(dict):
    pass


class CampaignService(IntentService):
    """Campaigns."""
    __default_intent__ = intent.defaults(permission_prefix="campaign", audit=True)

    async def list(self, *, db, user, context, skip=0, limit=10):
        return {"items": [], "user_id": user.get("id")}

    @intent(permission="campaign:export", feature="exports", quota="exports", audit=True)
    @custom_action()
    async def export(self, *, db, user, context, id, payload):
        return {"exported": True}


@pytest.fixture(scope="module")
def server():
    port = _free_port()

    runtime = IntentRuntime(
        policy=PolicyRegistry(
            permissions=["campaign:list", "campaign:create", "campaign:read",
                         "campaign:update", "campaign:delete", "campaign:export"],
            features=["exports"],
            quotas=["exports"],
        ),
        permission_provider=SimplePermissionProvider({
            "admin": ["*"],
            "member": ["campaign:list", "campaign:read"],
        }),
        billing_provider=SimpleBillingProvider({"exports": ["pro"]}),
        quota_provider=SimpleQuotaProvider({"exports": 2}),
        audit_provider=SimpleAuditProvider(),
        logger_provider=SimpleLoggerProvider(),
        actor_serializer=SimpleActorSerializer(),
    )
    router = IntentRouter(debug=True, runtime=runtime)
    router.register("Campaign", CampaignService())

    async def get_user(*, credentials, context, db):
        parts = credentials.credentials.split(":")
        role, plan = (parts + ["free"])[:2]
        return _Actor(id="u1", role=role, plan=plan, team_id="t1")

    def get_db():
        yield None

    app = FastAPI()
    app.include_router(router.build_machine(get_user=get_user, get_db=get_db))
    app.include_router(router.build_debug_router())

    s = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))

    def serve():
        asyncio.new_event_loop().run_until_complete(s.serve())

    Thread(target=serve, daemon=True).start()
    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)
    yield {"port": port}
    s.should_exit = True


@pytest.mark.asyncio
async def test_member_can_list(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.post(
            f"http://127.0.0.1:{server['port']}/api/machine-intent",
            headers={"Authorization": "Bearer member:free"},
            json={"model": "Campaign", "action": "list"},
        )
    assert r.status_code == 200
    assert r.json()["user_id"] == "u1"


@pytest.mark.asyncio
async def test_member_export_returns_403(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.post(
            f"http://127.0.0.1:{server['port']}/api/machine-intent",
            headers={"Authorization": "Bearer member:free"},
            json={"model": "Campaign", "action": "custom", "command": "export", "id": "x"},
        )
    assert r.status_code == 403
    assert r.json()["detail"]["code"] == "PERMISSION_DENIED"


@pytest.mark.asyncio
async def test_admin_free_export_returns_402(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.post(
            f"http://127.0.0.1:{server['port']}/api/machine-intent",
            headers={"Authorization": "Bearer admin:free"},
            json={"model": "Campaign", "action": "custom", "command": "export", "id": "x"},
        )
    assert r.status_code == 402
    assert r.json()["detail"]["code"] == "PLAN_UPGRADE_REQUIRED"


@pytest.mark.asyncio
async def test_admin_pro_quota_exhaustion(server):
    async with httpx.AsyncClient() as hx:
        url = f"http://127.0.0.1:{server['port']}/api/machine-intent"
        for _ in range(2):
            r = await hx.post(
                url,
                headers={"Authorization": "Bearer admin:pro"},
                json={"model": "Campaign", "action": "custom", "command": "export", "id": "x"},
            )
            assert r.status_code == 200
        r = await hx.post(
            url,
            headers={"Authorization": "Bearer admin:pro"},
            json={"model": "Campaign", "action": "custom", "command": "export", "id": "x"},
        )
        assert r.status_code == 429
        assert r.json()["detail"]["code"] == "QUOTA_EXCEEDED"
        assert r.json()["detail"]["detail"]["limit"] == 2


@pytest.mark.asyncio
async def test_inspector_governance_endpoint(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.get(f"http://127.0.0.1:{server['port']}/api/intent-debug/governance")
    body = r.json()
    intent_ids = {i["intent_id"] for i in body["intents"]}
    assert "Campaign.list" in intent_ids
    assert "Campaign.export" in intent_ids
    assert body["summary"]["governed"] >= 1


@pytest.mark.asyncio
async def test_inspector_providers_endpoint(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.get(f"http://127.0.0.1:{server['port']}/api/intent-debug/providers")
    body = r.json()
    assert body["providers"]["permission"]["configured"]
    assert body["providers"]["audit"]["configured"]


@pytest.mark.asyncio
async def test_inspector_validation_endpoint(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.get(f"http://127.0.0.1:{server['port']}/api/intent-debug/validation")
    body = r.json()
    assert body["passed"] is True


@pytest.mark.asyncio
async def test_registry_endpoint_includes_governance(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.get(f"http://127.0.0.1:{server['port']}/api/intent-debug/registry")
    body = r.json()
    assert "Campaign" in body
    methods = body["Campaign"]["methods"]
    assert "policy" in methods["list"]
    assert methods["list"]["policy"]["permission"] == "campaign:list"
