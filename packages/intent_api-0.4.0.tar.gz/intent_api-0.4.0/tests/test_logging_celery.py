"""Tests for Celery integration (Phase 5)."""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List

import pytest
import structlog

from intent_api import (
    IntentLogConfig,
    IntentRouter,
    IntentService,
    custom_action,
    intent,
    setup_intent_logging,
)
from intent_api.logging.context import capture_intent_context, clear_intent_context
from intent_api.providers import (
    SimpleActorSerializer,
    SimplePermissionProvider,
    SimpleTaskProvider,
)
from intent_api.runtime import IntentRuntime


@pytest.fixture(autouse=True)
def reset():
    clear_intent_context()
    yield
    clear_intent_context()


# ── intent_context propagation through TaskProvider ─────────────────────────


class _CapturingTaskProvider:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    async def dispatch(self, *, intent_id, actor_data, payload, intent_context=None):
        self.calls.append({
            "intent_id": intent_id, "actor_data": actor_data,
            "payload": payload, "intent_context": intent_context,
        })
        return {"task_id": "fake", "status": "dispatched"}


class _LegacyTaskProvider:
    """Custom TaskProvider written for v0.3.0 — no intent_context param."""

    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    async def dispatch(self, *, intent_id, actor_data, payload):
        self.calls.append({
            "intent_id": intent_id, "actor_data": actor_data, "payload": payload,
        })
        return {"task_id": "legacy", "status": "dispatched"}


class _S(IntentService):
    @intent(permission="x:do", execution="deferred", audit=True)
    @custom_action()
    async def do(self, *, db, user, context, id, payload):
        return {"ok": True}


def _runtime_with_task(task_provider) -> IntentRuntime:
    rt = IntentRuntime(
        permission_provider=SimplePermissionProvider({"admin": ["*"]}),
        actor_serializer=SimpleActorSerializer(),
    )
    rt.set_task_provider(task_provider)
    return rt


@pytest.mark.asyncio
async def test_intent_context_passed_to_task_provider():
    setup_intent_logging(IntentLogConfig(service_name="api"))
    structlog.contextvars.bind_contextvars(
        request_id="r-original", surface="machine",
    )

    tp = _CapturingTaskProvider()
    rt = _runtime_with_task(tp)
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)

    await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u-1", "role": "admin", "team_id": "t-1"}, payload={"x": 1})

    assert len(tp.calls) == 1
    ctx = tp.calls[0]["intent_context"]
    assert ctx is not None
    assert ctx["request_id"] == "r-original"
    assert ctx["phase"] == "deferred"


@pytest.mark.asyncio
async def test_legacy_task_provider_still_works():
    """Custom TaskProvider without intent_context param — backward compat."""
    tp = _LegacyTaskProvider()
    rt = _runtime_with_task(tp)
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)

    result = await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u-1", "role": "admin"}, payload={})
    assert result == {"task_id": "legacy", "status": "dispatched"}
    assert len(tp.calls) == 1


# ── Celery import lazy + error path ─────────────────────────────────────────


def test_configure_celery_logging_requires_celery(monkeypatch):
    import builtins
    real_import = builtins.__import__

    def fake(name, *a, **kw):
        if name.startswith("celery"):
            raise ImportError("No module named 'celery'")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", fake)

    from intent_api.logging import celery as cmod
    with pytest.raises(ImportError, match="celery"):
        cmod.configure_celery_logging(None, IntentLogConfig(service_name="worker"))


# ── Celery prerun rebinds context (using a fake task) ────────────────────────


def test_celery_prerun_binds_intent_context_from_headers():
    import sys

    pytest.importorskip("celery")
    from celery import Celery

    app = Celery("test")
    from intent_api.logging.celery import configure_celery_logging

    configure_celery_logging(app, IntentLogConfig(service_name="worker"))

    from celery.signals import task_prerun

    class FakeRequest:
        headers = {"intent_context": {
            "request_id": "r-orig", "intent_id": "X.create", "actor_id": "u-1",
            "team_id": "t-1", "surface": "machine", "phase": "deferred",
        }}
        intent_context = None

    class FakeTask:
        name = "fake.task"
        request = FakeRequest()

    clear_intent_context()
    task_prerun.send(sender=None, task_id="task-abc", task=FakeTask())

    ctx = structlog.contextvars.get_contextvars()
    assert ctx["request_id"] == "r-orig"
    assert ctx["task_id"] == "task-abc"
    assert ctx["intent_id"] == "X.create"

    clear_intent_context()


def test_celery_prerun_generates_beat_context_when_no_headers():
    pytest.importorskip("celery")
    from celery import Celery
    from celery.signals import task_prerun

    app = Celery("test_beat")
    from intent_api.logging.celery import configure_celery_logging

    configure_celery_logging(app, IntentLogConfig(service_name="scheduler"))

    class FakeRequest:
        headers = {}
        intent_context = None

    class FakeTask:
        name = "scheduled.cleanup"
        request = FakeRequest()

    clear_intent_context()
    task_prerun.send(sender=None, task_id="beat-task-abc", task=FakeTask())

    ctx = structlog.contextvars.get_contextvars()
    assert ctx["request_id"].startswith("beat-")
    assert ctx["surface"] == "system"
    assert ctx["phase"] == "scheduled"
    assert ctx["intent_id"] == "scheduled.cleanup"
    assert ctx["task_id"] == "beat-task-abc"

    clear_intent_context()
