"""Tests for IntentRuntime — execute() and execute_deferred() (Phase 5)."""

from __future__ import annotations

import asyncio
import json

import pytest

from intent_api import (
    IntentRouter,
    IntentService,
    PolicyRegistry,
    custom_action,
    intent,
)
from intent_api.providers import (
    PermissionDenied,
    PlanUpgradeRequired,
    ProviderNotConfigured,
    QuotaExceeded,
    SimpleActorSerializer,
    SimpleAuditProvider,
    SimpleBillingProvider,
    SimpleLoggerProvider,
    SimplePermissionProvider,
    SimpleQuotaProvider,
    TaskDispatchFailed,
    UngovernedIntent,
)
from intent_api.runtime import IntentRuntime


class _Actor(dict):
    pass


def _runtime(**overrides) -> IntentRuntime:
    return IntentRuntime(
        policy=PolicyRegistry.permissive(),
        permission_provider=overrides.get("permission_provider", SimplePermissionProvider({"admin": ["*"]})),
        billing_provider=overrides.get("billing_provider", SimpleBillingProvider({"ai": ["pro"]})),
        quota_provider=overrides.get("quota_provider", SimpleQuotaProvider({"q": 2})),
        audit_provider=overrides.get("audit_provider", SimpleAuditProvider()),
        logger_provider=overrides.get("logger_provider", SimpleLoggerProvider()),
        actor_serializer=overrides.get("actor_serializer", SimpleActorSerializer()),
        strict=overrides.get("strict", False),
    )


# ── Full pipeline ────────────────────────────────────────────────────────────


class _S(IntentService):
    @intent(permission="x:do", audit=True)
    @custom_action()
    async def do(self, *, db, user, context, id, payload):
        return {"ok": True, "user_id": user.get("id")}


def _setup() -> tuple[IntentRouter, IntentRuntime, _S]:
    rt = _runtime()
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    return r, rt, s


@pytest.mark.asyncio
async def test_full_pipeline_success():
    r, rt, s = _setup()
    result = await rt.execute(
        intent_id="S.do", handler=s.do,
        actor=_Actor(id="u1", role="admin", team_id="t1"),
        payload={},
    )
    assert result == {"ok": True, "user_id": "u1"}


@pytest.mark.asyncio
async def test_permission_denied():
    rt = _runtime(permission_provider=SimplePermissionProvider({"member": []}))
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    with pytest.raises(PermissionDenied):
        await rt.execute(
            intent_id="S.do", handler=s.do,
            actor=_Actor(id="u1", role="member"),
            payload={},
        )


@pytest.mark.asyncio
async def test_billing_denied():
    class S2(IntentService):
        @intent(permission="x", feature="ai", audit=True)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {"ok": True}

    rt = _runtime(billing_provider=SimpleBillingProvider({"ai": ["pro"]}))
    r = IntentRouter(runtime=rt)
    s = S2()
    r.register("S", s)

    with pytest.raises(PlanUpgradeRequired):
        await rt.execute(
            intent_id="S.do", handler=s.do,
            actor=_Actor(id="u1", role="admin", plan="free"),
            payload={},
        )


@pytest.mark.asyncio
async def test_quota_exceeded():
    class S3(IntentService):
        @intent(permission="x", quota="q", audit=True)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {"ok": True}

    rt = _runtime(quota_provider=SimpleQuotaProvider({"q": 1}))
    r = IntentRouter(runtime=rt)
    s = S3()
    r.register("S", s)

    actor = _Actor(id="u1", role="admin", team_id="t1")
    await rt.execute(intent_id="S.do", handler=s.do, actor=actor, payload={})
    with pytest.raises(QuotaExceeded):
        await rt.execute(intent_id="S.do", handler=s.do, actor=actor, payload={})


# ── Provider-not-configured fail-fast ────────────────────────────────────────


@pytest.mark.asyncio
async def test_missing_permission_provider_raises():
    rt = IntentRuntime(
        policy=PolicyRegistry.permissive(),
        actor_serializer=SimpleActorSerializer(),
    )
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    with pytest.raises(ProviderNotConfigured):
        await rt.execute(
            intent_id="S.do", handler=s.do,
            actor=_Actor(id="u1", role="admin"), payload={},
        )


# ── Quota rollback on dispatch failure ───────────────────────────────────────


class _FailingTask:
    async def dispatch(self, **kw):
        raise RuntimeError("broker unreachable")


@pytest.mark.asyncio
async def test_quota_rolled_back_on_dispatch_failure():
    class S(IntentService):
        @intent(permission="x", quota="q", execution="deferred", audit=True)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {"ok": True}

    quota = SimpleQuotaProvider({"q": 5})
    rt = IntentRuntime(
        policy=PolicyRegistry.permissive(),
        permission_provider=SimplePermissionProvider({"admin": ["*"]}),
        quota_provider=quota,
        task_provider=_FailingTask(),
        actor_serializer=SimpleActorSerializer(),
    )
    r = IntentRouter(runtime=rt)
    s = S()
    r.register("S", s)

    actor = _Actor(id="u1", role="admin", team_id="t1")
    with pytest.raises(TaskDispatchFailed):
        await rt.execute(intent_id="S.do", handler=s.do, actor=actor, payload={})

    ok, meta = await quota.check_and_consume(actor, "q", {})
    assert ok
    assert meta["current"] == 1


# ── execute_deferred() ───────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_execute_deferred_runs_handler_skips_policy():
    class S(IntentService):
        @intent(permission="x", quota="q", execution="deferred", audit=True)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {"ok": True, "user_id": user.id}

    rt = _runtime()
    r = IntentRouter(runtime=rt)
    s = S()
    r.register("S", s)

    result = await rt.execute_deferred(
        intent_id="S.do",
        actor_data={"id": "u1", "role": "member", "team_id": "t1"},
        payload={"x": 1},
        db=None,
    )
    assert result == {"ok": True, "user_id": "u1"}


# ── Ungoverned methods ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ungoverned_method_strict_raises_ungoverned_intent():
    class S(IntentService):
        async def create(self, *, db, user, context, payload=None):
            return {}

    rt = _runtime(strict=True)
    r = IntentRouter(runtime=rt)
    s = S()
    r.register("S", s)

    with pytest.raises(UngovernedIntent):
        await rt.execute(intent_id="S.create", handler=s.create, actor=_Actor(id="u1"), payload={})


@pytest.mark.asyncio
async def test_ungoverned_method_non_strict_executes():
    class S(IntentService):
        async def create(self, *, db, user, context, payload=None):
            return {"executed": True}

    rt = _runtime(strict=False)
    r = IntentRouter(runtime=rt)
    s = S()
    r.register("S", s)

    result = await rt.execute(
        intent_id="S.create", handler=s.create,
        actor=_Actor(id="u1", role="admin"), payload={},
    )
    assert result == {"executed": True}


# ── Lifecycle ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_runtime_execute_before_bind_raises():
    rt = _runtime()
    with pytest.raises(RuntimeError, match="not bound to a registry"):
        await rt.execute_deferred(intent_id="X.y", actor_data={}, payload={}, db=None)


def test_router_validation_runs_on_first_build():
    rt = _runtime()
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    # No build yet
    assert rt.validation_result is None
    # First build_machine triggers validation
    r.build_machine(get_user=lambda **kw: None, get_db=lambda: iter([None]))
    assert rt.validation_result is not None


# ── No runtime → v0.2.0 behavior ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_no_runtime_skips_pipeline():
    """With no runtime, dispatch is direct — no permission/quota/audit."""
    from intent_api import IntentRequest
    from intent_api.router import _dispatch

    class S(IntentService):
        @intent(permission="x:y", audit=True)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {"ok": True}

    s = S()
    intent_req = IntentRequest(model="S", action="custom", command="do", payload={})

    result = await _dispatch(s, intent_req, db=None, user=None, context=None, runtime=None)
    assert result == {"ok": True}
