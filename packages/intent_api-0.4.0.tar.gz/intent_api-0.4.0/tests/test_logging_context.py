"""Tests for context binding helpers (Phase 3)."""

from __future__ import annotations

import structlog

from intent_api.logging import IntentLogConfig, setup_intent_logging
from intent_api.logging.context import (
    bind_intent_context,
    capture_intent_context,
    clear_intent_context,
)


def setup_function(_):
    setup_intent_logging(IntentLogConfig(service_name="ctx-test"))
    clear_intent_context()


def teardown_function(_):
    clear_intent_context()


def test_bind_generates_request_id_when_missing():
    bind_intent_context(model="Brand", action="list", user={"id": "u1"}, surface="machine")
    ctx = structlog.contextvars.get_contextvars()
    assert "request_id" in ctx
    assert len(ctx["request_id"]) >= 8


def test_bind_preserves_existing_request_id():
    structlog.contextvars.bind_contextvars(request_id="r-from-middleware")
    bind_intent_context(model="Brand", action="list", user={"id": "u1"}, surface="machine")
    ctx = structlog.contextvars.get_contextvars()
    assert ctx["request_id"] == "r-from-middleware"


def test_bind_sets_all_intent_fields():
    bind_intent_context(
        model="BlogPost", action="custom", command="generate",
        user={"id": "u-1", "team_id": "t-1"}, surface="machine",
    )
    ctx = structlog.contextvars.get_contextvars()
    assert ctx["intent_id"] == "BlogPost.generate"
    assert ctx["intent_model"] == "BlogPost"
    assert ctx["intent_action"] == "custom"
    assert ctx["intent_command"] == "generate"
    assert ctx["actor_id"] == "u-1"
    assert ctx["team_id"] == "t-1"
    assert ctx["surface"] == "machine"


def test_bind_uses_action_when_no_command():
    bind_intent_context(model="Brand", action="list", user={"id": "u-1"}, surface="machine")
    assert structlog.contextvars.get_contextvars()["intent_id"] == "Brand.list"


def test_bind_handles_object_actor():
    class A:
        id = "u-obj"
        team_id = "t-obj"
    bind_intent_context(model="X", action="list", user=A(), surface="machine")
    ctx = structlog.contextvars.get_contextvars()
    assert ctx["actor_id"] == "u-obj"
    assert ctx["team_id"] == "t-obj"


def test_capture_returns_intent_context_keys_with_phase_deferred():
    structlog.contextvars.bind_contextvars(
        request_id="r-1", intent_id="X.create", actor_id="u-1",
        team_id="t-1", surface="machine", random_extra="should-not-leak",
    )
    captured = capture_intent_context()
    assert captured["request_id"] == "r-1"
    assert captured["intent_id"] == "X.create"
    assert captured["actor_id"] == "u-1"
    assert captured["surface"] == "machine"
    assert captured["phase"] == "deferred"
    assert "random_extra" not in captured
