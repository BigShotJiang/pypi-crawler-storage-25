"""Tests for StructlogLoggerProvider (Phase 4)."""

from __future__ import annotations

import logging

import pytest
import structlog

from intent_api.logging import IntentLogConfig, setup_intent_logging
from intent_api.logging.structlog_provider import StructlogLoggerProvider


@pytest.fixture(autouse=True)
def reset_logging():
    setup_intent_logging(IntentLogConfig(service_name="provider-test"))
    structlog.contextvars.clear_contextvars()
    yield
    structlog.contextvars.clear_contextvars()


@pytest.mark.asyncio
async def test_log_emits_through_structlog(caplog):
    provider = StructlogLoggerProvider()
    with caplog.at_level(logging.INFO, logger="intent_api.runtime"):
        await provider.log({"intent_id": "X.create", "status": "success", "elapsed_ms": 12})
    assert any("intent.success" in rec.message for rec in caplog.records)


@pytest.mark.asyncio
async def test_log_respects_level_field(caplog):
    provider = StructlogLoggerProvider()
    with caplog.at_level(logging.WARNING, logger="intent_api.runtime"):
        await provider.log({
            "intent_id": "X.do", "status": "denied",
            "intent_error_code": "PERMISSION_DENIED", "_level": "warning",
        })
    warning_records = [r for r in caplog.records if r.levelname == "WARNING"]
    assert any("intent.denied" in r.message for r in warning_records)


@pytest.mark.asyncio
async def test_log_strips_internal_level_field(caplog):
    provider = StructlogLoggerProvider()
    with caplog.at_level(logging.INFO, logger="intent_api.runtime"):
        await provider.log({"intent_id": "X.y", "status": "success", "_level": "info"})
    for rec in caplog.records:
        assert "_level" not in (rec.message or "")
