"""Tests for provider interfaces + SimpleProviders (Phase 4)."""

from __future__ import annotations

import asyncio
import threading

import pytest
from pydantic import BaseModel

from intent_api.actors import SystemActor
from intent_api.providers import (
    ActorSerializer,
    AuditProvider,
    BillingProvider,
    LoggerProvider,
    PermissionProvider,
    QuotaProvider,
    SimpleActorSerializer,
    SimpleAuditProvider,
    SimpleBillingProvider,
    SimpleLoggerProvider,
    SimplePermissionProvider,
    SimpleQuotaProvider,
)


# ── Protocol conformance ─────────────────────────────────────────────────────


def test_simple_implements_protocols():
    assert isinstance(SimplePermissionProvider({}), PermissionProvider)
    assert isinstance(SimpleBillingProvider({}), BillingProvider)
    assert isinstance(SimpleQuotaProvider({}), QuotaProvider)
    assert isinstance(SimpleAuditProvider(), AuditProvider)
    assert isinstance(SimpleLoggerProvider(), LoggerProvider)
    assert isinstance(SimpleActorSerializer(), ActorSerializer)


# ── SimplePermissionProvider ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_permission_role_match():
    p = SimplePermissionProvider({"member": ["x:y"]})
    class A: role = "member"
    assert await p.has_permission(A(), "x:y", {}) is True
    assert await p.has_permission(A(), "x:z", {}) is False


@pytest.mark.asyncio
async def test_permission_wildcard():
    p = SimplePermissionProvider({"admin": ["*"]})
    class A: role = "admin"
    assert await p.has_permission(A(), "anything", {}) is True


@pytest.mark.asyncio
async def test_permission_dict_actor():
    p = SimplePermissionProvider({"member": ["x:y"]})
    assert await p.has_permission({"role": "member"}, "x:y", {}) is True


# ── SimpleBillingProvider ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_billing_plan_match():
    p = SimpleBillingProvider({"ai": ["pro"]})
    class A: plan = "pro"
    assert await p.has_feature(A(), "ai", {}) is True
    class B: plan = "free"
    assert await p.has_feature(B(), "ai", {}) is False


# ── SimpleQuotaProvider ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_quota_consume_until_limit():
    q = SimpleQuotaProvider({"x": 2})
    class A: team_id = "t1"
    a = A()
    ok, _ = await q.check_and_consume(a, "x", {})
    assert ok
    ok, _ = await q.check_and_consume(a, "x", {})
    assert ok
    ok, meta = await q.check_and_consume(a, "x", {})
    assert not ok
    assert meta == {"current": 2, "limit": 2}


@pytest.mark.asyncio
async def test_quota_per_team_isolation():
    q = SimpleQuotaProvider({"x": 1})
    class T1: team_id = "t1"
    class T2: team_id = "t2"
    assert (await q.check_and_consume(T1(), "x", {}))[0]
    assert (await q.check_and_consume(T2(), "x", {}))[0]


@pytest.mark.asyncio
async def test_quota_rollback():
    q = SimpleQuotaProvider({"x": 1})
    class A: team_id = "t1"
    a = A()
    assert (await q.check_and_consume(a, "x", {}))[0]
    assert not (await q.check_and_consume(a, "x", {}))[0]
    await q.rollback(a, "x", {})
    assert (await q.check_and_consume(a, "x", {}))[0]


def test_quota_thread_safe_under_concurrency():
    q = SimpleQuotaProvider({"x": 50})
    class A: team_id = "t1"
    a = A()
    results: list = []
    lock = threading.Lock()

    def worker():
        loop = asyncio.new_event_loop()
        ok, _ = loop.run_until_complete(q.check_and_consume(a, "x", {}))
        loop.close()
        with lock:
            results.append(ok)

    threads = [threading.Thread(target=worker) for _ in range(100)]
    for t in threads: t.start()
    for t in threads: t.join()

    granted = sum(1 for r in results if r)
    assert granted == 50, f"Expected exactly 50 grants, got {granted}"


# ── SimpleActorSerializer ────────────────────────────────────────────────────


def test_serializer_handles_pydantic():
    class U(BaseModel):
        id: str
        role: str
    s = SimpleActorSerializer()
    out = s.serialize(U(id="u1", role="admin"))
    assert out == {"id": "u1", "role": "admin"}


def test_serializer_handles_dict():
    s = SimpleActorSerializer()
    out = s.serialize({"id": "u2", "role": "member"})
    assert out == {"id": "u2", "role": "member"}


def test_serializer_handles_object():
    s = SimpleActorSerializer()

    class Obj:
        def __init__(self):
            self.id = "u3"
            self._private = "hidden"

    out = s.serialize(Obj())
    assert out == {"id": "u3"}


def test_serializer_round_trip():
    s = SimpleActorSerializer()
    actor = {"id": "u1", "role": "admin", "team_id": "t1"}
    rebuilt = s.deserialize(s.serialize(actor))
    assert rebuilt.id == "u1"
    assert rebuilt.role == "admin"
    assert rebuilt.team_id == "t1"


# ── SystemActor ──────────────────────────────────────────────────────────────


def test_system_actor_has_required_attributes():
    s = SystemActor()
    assert s.id == "system"
    assert s.role == "system"
    assert s.team_id == "system"
    assert s.plan == "system"


def test_system_actor_passes_through_permission_check():
    p = SimplePermissionProvider({"system": ["*"]})

    async def go():
        return await p.has_permission(SystemActor(), "anything", {})

    assert asyncio.run(go()) is True


# ── Audit + Logger ───────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_audit_provider_does_not_raise():
    a = SimpleAuditProvider()
    await a.log({"intent_id": "M.x", "status": "success"})


@pytest.mark.asyncio
async def test_logger_provider_does_not_raise():
    l = SimpleLoggerProvider()
    await l.log({"intent_id": "M.x", "status": "error"})
