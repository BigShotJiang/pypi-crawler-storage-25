"""Tests for IntentRuntime lifecycle hooks (Phase 4)."""

from __future__ import annotations

from typing import Any, Dict, List

import pytest

from intent_api import (
    IntentRouter,
    IntentService,
    PolicyRegistry,
    custom_action,
    intent,
)
from intent_api.providers import (
    PermissionDenied,
    SimpleActorSerializer,
    SimplePermissionProvider,
)
from intent_api.runtime import IntentRuntime


class _CollectingProvider:
    def __init__(self) -> None:
        self.events: List[Dict[str, Any]] = []

    async def log(self, event: Dict[str, Any]) -> None:
        self.events.append(dict(event))


class _BrokenProvider:
    async def log(self, event: Dict[str, Any]) -> None:
        raise RuntimeError("boom")


def _runtime(
    *,
    audit: _CollectingProvider | None = None,
    logger: _CollectingProvider | None = None,
) -> IntentRuntime:
    return IntentRuntime(
        policy=PolicyRegistry.permissive(),
        permission_provider=SimplePermissionProvider({"admin": ["*"]}),
        audit_provider=audit,
        logger_provider=logger,
        actor_serializer=SimpleActorSerializer(),
    )


class _S(IntentService):
    @intent(permission="x:do", audit=True)
    @custom_action()
    async def do(self, *, db, user, context, id, payload):
        return {"ok": True}

    @intent(permission="x:fail", audit=True)
    @custom_action()
    async def fail(self, *, db, user, context, id, payload):
        raise ValueError("internal explosion")


def _setup(audit, logger):
    rt = _runtime(audit=audit, logger=logger)
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    return r, rt, s


@pytest.mark.asyncio
async def test_success_emits_two_events_to_logger_and_audit():
    audit = _CollectingProvider()
    logger = _CollectingProvider()
    _, rt, s = _setup(audit, logger)

    await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin", "team_id": "t1"}, payload={})

    statuses = [e["status"] for e in logger.events]
    assert statuses == ["start", "success"]
    assert [e["status"] for e in audit.events] == ["success"]
    assert "actor" in audit.events[0]
    assert audit.events[0]["actor"]["id"] == "u1"


@pytest.mark.asyncio
async def test_denied_emits_warning_with_error_code():
    audit = _CollectingProvider()
    logger = _CollectingProvider()
    _, rt, s = _setup(audit, logger)
    rt._permission = SimplePermissionProvider({"admin": []})  # no perms

    with pytest.raises(PermissionDenied):
        await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin", "team_id": "t1"}, payload={})

    statuses = [e["status"] for e in logger.events]
    assert statuses == ["start", "denied"]
    denied = logger.events[1]
    assert denied["intent_error_code"] == "PERMISSION_DENIED"
    assert denied["_level"] == "warning"
    assert [e["status"] for e in audit.events] == ["denied"]


@pytest.mark.asyncio
async def test_failure_emits_error_with_exception_info():
    audit = _CollectingProvider()
    logger = _CollectingProvider()
    _, rt, s = _setup(audit, logger)

    with pytest.raises(ValueError):
        await rt.execute(intent_id="S.fail", handler=s.fail, actor={"id": "u1", "role": "admin", "team_id": "t1"}, payload={})

    statuses = [e["status"] for e in logger.events]
    assert statuses == ["start", "failure"]
    failure = logger.events[1]
    assert failure["_level"] == "error"
    assert "ValueError" in failure["error"]
    assert [e["status"] for e in audit.events] == ["failure"]


@pytest.mark.asyncio
async def test_audit_does_not_fire_when_spec_audit_false():
    class S2(IntentService):
        @intent(permission="x:do", audit=False)
        @custom_action()
        async def do(self, *, db, user, context, id, payload):
            return {}

    audit = _CollectingProvider()
    logger = _CollectingProvider()
    rt = _runtime(audit=audit, logger=logger)
    r = IntentRouter(runtime=rt)
    s = S2()
    r.register("S", s)
    await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin"}, payload={})

    assert audit.events == []
    assert [e["status"] for e in logger.events] == ["start", "success"]


@pytest.mark.asyncio
async def test_start_does_not_fire_audit_provider():
    audit = _CollectingProvider()
    logger = _CollectingProvider()
    _, rt, s = _setup(audit, logger)
    await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin"}, payload={})

    audit_statuses = [e["status"] for e in audit.events]
    assert "start" not in audit_statuses


@pytest.mark.asyncio
async def test_broken_logger_does_not_break_request():
    rt = _runtime(audit=None, logger=_BrokenProvider())
    r = IntentRouter(runtime=rt)
    s = _S()
    r.register("S", s)
    result = await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin"}, payload={})
    assert result == {"ok": True}


@pytest.mark.asyncio
async def test_audit_and_logger_receive_same_event_shape():
    audit = _CollectingProvider()
    logger = _CollectingProvider()
    _, rt, s = _setup(audit, logger)
    await rt.execute(intent_id="S.do", handler=s.do, actor={"id": "u1", "role": "admin", "team_id": "t1"}, payload={})

    audit_success = audit.events[0]
    logger_success = next(e for e in logger.events if e["status"] == "success")

    for key in ("intent_id", "actor", "policy", "elapsed_ms", "phase", "timestamp"):
        assert key in audit_success
        assert key in logger_success
        assert audit_success[key] == logger_success[key]
