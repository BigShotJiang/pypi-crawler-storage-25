"""Tests for IntentContextMiddleware (Phase 3)."""

from __future__ import annotations

import structlog
from fastapi import FastAPI
from starlette.testclient import TestClient

from intent_api.logging import IntentLogConfig, setup_intent_logging


def _build_app():
    app = FastAPI()
    setup_intent_logging(IntentLogConfig(service_name="mw-test"), app=app)

    @app.get("/ping")
    async def ping():
        ctx = structlog.contextvars.get_contextvars()
        return {"request_id": ctx.get("request_id"), "method": ctx.get("method")}

    @app.get("/boom")
    async def boom():
        raise RuntimeError("nope")

    return app


def test_middleware_generates_request_id_when_missing():
    client = TestClient(_build_app())
    r = client.get("/ping")
    assert r.status_code == 200
    body = r.json()
    assert body["request_id"]
    assert r.headers["x-request-id"] == body["request_id"]


def test_middleware_uses_provided_request_id():
    client = TestClient(_build_app())
    r = client.get("/ping", headers={"X-Request-ID": "client-known-id"})
    assert r.json()["request_id"] == "client-known-id"
    assert r.headers["x-request-id"] == "client-known-id"


def test_middleware_returns_request_id_on_500():
    client = TestClient(_build_app(), raise_server_exceptions=False)
    r = client.get("/boom", headers={"X-Request-ID": "client-err"})
    assert r.status_code == 500
    assert r.headers.get("x-request-id") == "client-err"


def test_middleware_clears_context_after_response():
    client = TestClient(_build_app())
    client.get("/ping", headers={"X-Request-ID": "x-1"})
    assert structlog.contextvars.get_contextvars() == {}
