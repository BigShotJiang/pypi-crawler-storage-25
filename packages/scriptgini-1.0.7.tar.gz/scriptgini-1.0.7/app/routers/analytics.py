from sqlalchemy import case, func
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends, HTTPException

from app.database import get_db
from app.models.project import Project
from app.models.script_run import ScriptRun, ScriptRunStatus
from app.models.test_case import TestCase
from app.schemas.analytics import RunAnalyticsResponse, RecentFailureResponse

router = APIRouter(prefix="/projects/{project_id}/analytics", tags=["Run Analytics"])


@router.get("/runs", response_model=RunAnalyticsResponse)
def get_run_analytics(project_id: int, db: Session = Depends(get_db)):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    aggregate = (
        db.query(
            func.count(ScriptRun.id),
            func.sum(case((ScriptRun.success.is_(True), 1), else_=0)),
            func.sum(case((ScriptRun.status == ScriptRunStatus.failed, 1), else_=0)),
            func.sum(case((ScriptRun.status == ScriptRunStatus.timed_out, 1), else_=0)),
            func.avg(ScriptRun.duration_seconds),
        )
        .filter(ScriptRun.project_id == project_id)
        .one()
    )

    total_runs = int(aggregate[0] or 0)
    success_runs = int(aggregate[1] or 0)
    failed_runs = int(aggregate[2] or 0)
    timed_out_runs = int(aggregate[3] or 0)
    avg_duration = float(aggregate[4] or 0.0)

    failed_items = (
        db.query(ScriptRun, TestCase.title)
        .outerjoin(TestCase, TestCase.id == ScriptRun.test_case_id)
        .filter(ScriptRun.project_id == project_id)
        .filter(ScriptRun.success.is_(False))
        .order_by(ScriptRun.created_at.desc(), ScriptRun.id.desc())
        .limit(10)
        .all()
    )

    recent_failures = [
        RecentFailureResponse(
            run_id=run.id,
            script_id=run.script_id,
            test_case_id=run.test_case_id,
            test_case_title=tc_title,
            exit_code=run.exit_code,
            duration_seconds=run.duration_seconds,
            stderr_excerpt=(run.stderr or "")[:240],
            created_at=run.created_at,
        )
        for run, tc_title in failed_items
    ]

    success_rate = round((success_runs / total_runs) * 100, 2) if total_runs else 0.0

    return RunAnalyticsResponse(
        project_id=project_id,
        total_runs=total_runs,
        success_runs=success_runs,
        failed_runs=failed_runs,
        timed_out_runs=timed_out_runs,
        success_rate=success_rate,
        average_duration_seconds=round(avg_duration, 2),
        recent_failures=recent_failures,
    )
