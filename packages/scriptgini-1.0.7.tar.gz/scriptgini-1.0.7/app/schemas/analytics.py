from datetime import datetime

from pydantic import BaseModel, ConfigDict


class RecentFailureResponse(BaseModel):
    run_id: int
    script_id: int
    test_case_id: int
    test_case_title: str | None = None
    exit_code: int
    duration_seconds: float
    stderr_excerpt: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class RunAnalyticsResponse(BaseModel):
    project_id: int
    total_runs: int
    success_runs: int
    failed_runs: int
    timed_out_runs: int
    success_rate: float
    average_duration_seconds: float
    recent_failures: list[RecentFailureResponse]
