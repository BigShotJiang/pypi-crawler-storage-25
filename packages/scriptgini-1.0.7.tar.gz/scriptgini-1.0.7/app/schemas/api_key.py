from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class APIKeyCreateRequest(BaseModel):
    name: str
    scopes: list[str] = ["read"]
    expires_at: Optional[datetime] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "CI/CD Pipeline Key",
                "scopes": ["read", "execute"],
                "expires_at": None,
            }
        }
    }


class APIKeyResponse(BaseModel):
    id: int
    name: str
    prefix: str
    scopes: list[str]
    is_active: bool
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class APIKeyRevealResponse(BaseModel):
    """Shown only once when creating a new API key"""
    id: int
    name: str
    prefix: str
    secret_key: str  # The full secret (shown only once)
    scopes: list[str]
    is_active: bool
    expires_at: Optional[datetime]
    created_at: datetime

    model_config = {
        "json_schema_extra": {
            "example": {
                "id": 1,
                "name": "CI/CD Pipeline Key",
                "prefix": "sg_1234",
                "secret_key": "sg_1234_abcdefghijklmnopqrstuvwxyz123456",
                "scopes": ["read", "execute"],
                "is_active": True,
                "expires_at": None,
                "created_at": "2026-05-10T12:00:00Z",
            }
        }
    }


class APIKeyUpdateRequest(BaseModel):
    name: Optional[str] = None
    scopes: Optional[list[str]] = None
    expires_at: Optional[datetime] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "Updated Key Name",
                "scopes": ["read", "write"],
                "expires_at": None,
            }
        }
    }
