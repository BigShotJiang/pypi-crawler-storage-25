from datetime import datetime
from pydantic import BaseModel, HttpUrl, Field

from app.models.project import TestFramework, SelectorPreference


class ProjectCreate(BaseModel):
    name: str = Field(..., max_length=255)
    description: str | None = None
    aut_base_url: str = Field(..., description="Base URL of the Application Under Test")
    default_framework: TestFramework = TestFramework.playwright_python
    selector_preference: SelectorPreference = SelectorPreference.role
    auth_hints: str | None = None


class ProjectUpdate(BaseModel):
    name: str | None = Field(None, max_length=255)
    description: str | None = None
    aut_base_url: str | None = None
    default_framework: TestFramework | None = None
    selector_preference: SelectorPreference | None = None
    auth_hints: str | None = None


class ProjectResponse(BaseModel):
    id: int
    name: str
    description: str | None
    aut_base_url: str
    default_framework: TestFramework
    selector_preference: SelectorPreference
    auth_hints: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
