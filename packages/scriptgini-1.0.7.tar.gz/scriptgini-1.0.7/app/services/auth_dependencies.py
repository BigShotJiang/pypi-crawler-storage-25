from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.database import get_db
from app.services import auth as auth_service
from app.services import api_key as api_key_service

security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    """
    Dependency to extract and validate the current user from JWT token.
    
    Usage in route:
        @router.get("/protected")
        def protected_route(current_user = Depends(get_current_user)):
            return {"user_id": current_user.id}
    """
    token = credentials.credentials
    token_data = auth_service.verify_token(token, token_type="access")

    if not token_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired access token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = auth_service.get_user_by_id(db, token_data.user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    return user


def get_current_user_or_api_key(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    """
    Dependency to support both JWT and API key authentication.
    
    - JWT token: standard access token
    - API key: key_id:key_secret format or just the full secret
    
    Usage in route:
        @router.get("/protected")
        def protected_route(current_user = Depends(get_current_user_or_api_key)):
            return {"user_id": current_user.id}
    """
    token = credentials.credentials
    
    # First try to verify as JWT token
    token_data = auth_service.verify_token(token, token_type="access")
    if token_data:
        user = auth_service.get_user_by_id(db, token_data.user_id)
        if user and user.is_active:
            return user
    
    # Try to parse as API key (key_id:key_secret format)
    if ":" in token:
        key_id, key_secret = token.split(":", 1)
        api_key = api_key_service.verify_api_key(db, key_id, key_secret)
        if api_key:
            # Return the user associated with the API key
            user = auth_service.get_user_by_id(db, api_key.user_id)
            if user and user.is_active:
                # Attach api_key to user for scope checking in routes
                user._api_key = api_key
                return user
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
