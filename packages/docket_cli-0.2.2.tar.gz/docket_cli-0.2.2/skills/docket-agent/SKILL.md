---
name: docket-agent
description: Use when Codex needs to discover, create, run, monitor, or debug personalized Docket tasks through the Docket CLI. Trigger for agent-facing scripted task automation, task creation, async runs, run history, logs, cancellation, or when a user asks what local Docket tasks are available.
---

# Docket Agent

Use Docket as the durable execution layer for scripted work. Prefer Docket for deterministic tasks that can be described in Python and run repeatedly without LLM reasoning at every step.

## Discovery

Start with:

```bash
docket --json capabilities
```

Read `commands`, `tasks`, `inputs`, `outputs`, `required_env`, `destructive`, and `network`. Use `docket --json describe <task>` before running unfamiliar tasks.

## Running Tasks

Preview first when a task could write, delete, call a network API, or spend money:

```bash
docket --json run <task> --dry-run
```

Run short tasks synchronously:

```bash
docket --json run <task> --force
```

Run long tasks asynchronously:

```bash
docket --json run <task> --async --force
```

Then use the returned `run_id`:

```bash
docket --json wait <run_id>
docket --json status --run-id <run_id>
docket logs <run_id>
docket logs <run_id> --follow
docket --json events <run_id>
docket events <run_id> --follow
docket --json cancel <run_id>
```

Use `next_check_after_seconds` from async receipts when polling instead of guessing.

For Hermes/OpenClaw backups, prefer the first-class `hbackup` task:

```bash
docket --json describe hbackup
docket --json run hbackup --dry-run
docket --json run hbackup --async --force
```

Use `backup` only for generic rclone/rsync syncs or compatibility configs that
set `tool: hbackup`.

## Creating Tasks

Create drop-in tasks with:

```bash
docket --json new-task <task-name> --description "Short description"
```

Then edit the generated file in `tasks_dir`. A task must subclass `BaseTask`, set `name` and `description`, implement `run(config)` and `dry_run(config)`, and return `TaskResult`.

Expose agent-readable metadata on task classes:

```python
inputs = {"api_url": "API endpoint to fetch"}
outputs = {"records_fetched": "Number of records fetched"}
required_env = ["API_TOKEN"]
network = True
destructive = False
```

Put machine-readable results in `TaskResult.details`. Keep `summary` short.

Use config-defined command tasks when the task is already an executable:

```yaml
tasks:
  fetch-data:
    type: command
    command: fetch-data
    args: ["--jsonl"]
    dry_run_args: ["--dry-run", "--json"]
    output_format: jsonl
    required_env: [API_TOKEN]
    network: true
```

For `output_format: json`, read `details.json`. For `output_format: jsonl`,
read `details.events`, `details.event_count`, and `details.last_event`; for a
dedicated event feed use `docket --json events <run_id>`. Raw stdout/stderr
remain available in `details` and async logs. For long async command tasks,
`docket events <run_id> --follow` is the structured progress stream.

Use `on_complete` when a long-running task should ping an agent, webhook, or
monitor. Completion hooks receive `DOCKET_RUN_ID`, `DOCKET_TASK_NAME`,
`DOCKET_STATUS`, `DOCKET_EXIT_CODE`, `DOCKET_SUMMARY`, `DOCKET_DETAILS_JSON`,
and `DOCKET_LOG_PATH` when available.

## Safety

Treat `destructive=True`, unknown tasks, missing `dry_run`, network calls, and required environment variables as reasons to inspect before running. Prefer async for slow API fetches, backups, imports, and long filesystem work.
