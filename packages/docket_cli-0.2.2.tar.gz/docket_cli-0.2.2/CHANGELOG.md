# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-26

### Added
- Core task runner CLI with list, run, status, describe, doctor commands
- `--json` flag for structured machine-readable output
- `--dry-run` flag for safe task preview
- `--force` flag to bypass already-ran-today guard and lock acquisition
- BaseTask ABC with run()/dry_run() contract and TaskResult dataclass
- SQLite-backed state store tracking last run per task
- Task registry via entry points + drop-in directory (~/.docket/tasks/)
- YAML config loader with defaults and path expansion
- Built-in tasks: backup (rclone/rsync) and health-check (disk, memory, systemd)
- `docket install` command for systemd timer/service unit generation
- `docket configure` command for $EDITOR-based config editing
- Lock file support to prevent concurrent runs of the same task
- Configurable retry with exponential backoff (per-task retry/backoff_base)
- Notification hooks (on_success/on_failure shell commands)
- `docket doctor` self-diagnostic command
- Dual JSON/human logging
- 174 tests passing

### Security
- Hook commands use shell=True — only use config from trusted sources
- Environment variable expansion in hooks is intentional but allows arbitrary execution