"""Tests for docket.hooks — notification hook execution."""

from __future__ import annotations

import json
from typing import Any

import pytest

import docket.hooks
import docket.notify
from docket.hooks import Hooks
from docket.task import TaskResult


class TestSingleCommandHook:
    """A single string under on_success / on_failure."""

    def test_on_success_runs(self) -> None:
        cfg: dict[str, Any] = {"on_success": "echo hello"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        assert ec == 0
        assert "hello" in stdout

    def test_on_failure_runs(self) -> None:
        cfg: dict[str, Any] = {"on_failure": "echo oops"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_failure")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        assert ec == 0
        assert "oops" in stdout

    def test_failing_hook_still_returns(self) -> None:
        cfg: dict[str, Any] = {"on_success": "false"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        assert ec != 0


class TestListOfCommands:
    """on_success / on_failure can be a list of strings."""

    def test_list_of_commands(self) -> None:
        cfg: dict[str, Any] = {
            "on_success": [
                "echo first",
                "echo second",
            ],
        }
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 2
        assert results[0][2].strip() == "first"  # stdout of first
        assert results[1][2].strip() == "second"  # stdout of second

    def test_list_with_mixed_exit_codes(self) -> None:
        cfg: dict[str, Any] = {
            "on_failure": [
                "echo ok",
                "false",
                "echo still-runs",
            ],
        }
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_failure")
        assert len(results) == 3
        assert results[0][1] == 0
        assert results[1][1] != 0
        assert results[2][1] == 0
        # Non-blocking: later hooks still execute after a failure.
        assert "still-runs" in results[2][2]

    def test_on_complete_runs(self) -> None:
        cfg: dict[str, Any] = {"on_complete": "echo complete"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_complete")
        assert len(results) == 1
        assert results[0][1] == 0
        assert "complete" in results[0][2]


class TestTimeout:
    """Hook commands that exceed the 30s timeout."""

    def test_timeout_returns_negative_exit_code(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Use a very short sleep to keep tests fast — but patch the timeout
        # down to 0.5s so a 2s sleep triggers it.
        monkeypatch.setattr(Hooks, "TIMEOUT", 0.5)
        cfg: dict[str, Any] = {"on_success": "sleep 2"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        assert ec == -1
        assert "timed out" in stderr.lower()


class TestNonExistentCommand:
    """Hook referencing a command that doesn't exist."""

    def test_nonexistent_command(self) -> None:
        cfg: dict[str, Any] = {"on_success": "no-such-command-xyz-123"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        # shell returns 127 for command not found
        assert ec == 127


class TestVariableExpansion:
    """Environment variable expansion in hook commands."""

    def test_env_var_expansion(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("DOCKET_TEST_VAR", "expanded_value")
        cfg: dict[str, Any] = {"on_success": "echo $DOCKET_TEST_VAR"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        cmd, ec, stdout, stderr = results[0]
        assert ec == 0
        assert "expanded_value" in stdout

    def test_structured_run_env(self) -> None:
        cfg: dict[str, Any] = {"on_complete": "echo $DOCKET_RUN_ID $DOCKET_STATUS"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks(
            "on_complete",
            TaskResult(ok=True, summary="done", details={"files": 2}),
            {
                "run_id": "run-123",
                "task_name": "backup",
                "status": "succeeded",
                "started_at": "2026-01-01T00:00:00+00:00",
                "finished_at": "2026-01-01T00:00:02+00:00",
                "duration_seconds": 2.0,
                "exit_code": 0,
                "summary": "done",
                "details": {"files": 2},
            },
        )
        assert len(results) == 1
        assert "run-123" in results[0][2]
        assert "succeeded" in results[0][2]


class TestNativeNotifications:
    """Provider-backed notifications avoid shell hook glue for common channels."""

    def test_discord_notification_uses_webhook_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        calls: list[dict[str, Any]] = []

        class Response:
            status = 204

            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *args: object) -> None:
                return None

            def read(self) -> bytes:
                return b""

        def fake_urlopen(request: Any, timeout: float) -> Response:
            calls.append(
                {
                    "url": request.full_url,
                    "payload": json.loads(request.data.decode("utf-8")),
                    "timeout": timeout,
                }
            )
            return Response()

        monkeypatch.setenv("DISCORD_WEBHOOK_URL", "https://discord.test/webhook")
        monkeypatch.setattr(docket.notify.urllib.request, "urlopen", fake_urlopen)

        cfg: dict[str, Any] = {
            "notify": {
                "on": ["success"],
                "discord": {"username": "Docket"},
            }
        }
        hooks = Hooks(cfg)
        results = hooks.run_notifications(
            "success",
            TaskResult(ok=True, summary="done"),
            {
                "run_id": "run-123",
                "task_name": "vitals-morning",
                "status": "succeeded",
                "summary": "done",
                "duration_seconds": 1.25,
            },
        )

        assert results == [("notify:discord", 204, "", "")]
        assert calls[0]["url"] == "https://discord.test/webhook"
        assert "vitals-morning" in calls[0]["payload"]["content"]
        assert calls[0]["payload"]["username"] == "Docket"

    def test_telegram_notification_accepts_chat_alias(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        calls: list[dict[str, Any]] = []

        class Response:
            status = 200

            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *args: object) -> None:
                return None

            def read(self) -> bytes:
                return b'{"ok": true}'

        def fake_urlopen(request: Any, timeout: float) -> Response:
            calls.append(
                {
                    "url": request.full_url,
                    "payload": json.loads(request.data.decode("utf-8")),
                }
            )
            return Response()

        monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "bot-token")
        monkeypatch.setattr(docket.notify.urllib.request, "urlopen", fake_urlopen)

        hooks = Hooks({"notify": {"on": "failure", "telegram": {"chat": "8223639759"}}})
        results = hooks.run_notifications(
            "failure",
            TaskResult(ok=False, summary="failed"),
            {"task_name": "backup", "status": "failed", "summary": "failed"},
        )

        assert results[0][0] == "notify:telegram"
        assert results[0][1] == 200
        assert "/botbot-token/sendMessage" in calls[0]["url"]
        assert calls[0]["payload"]["chat_id"] == "8223639759"

    def test_notifications_default_to_failure_only(self) -> None:
        hooks = Hooks({"notify": {"discord": {"webhook_url": "https://example.test"}}})
        assert hooks.run_notifications("success", TaskResult(ok=True, summary="done")) == []

    def test_missing_provider_secret_is_reported(self) -> None:
        hooks = Hooks({"notify": {"on": "success", "discord": {}}})
        results = hooks.run_notifications("success", TaskResult(ok=True, summary="done"))
        assert results == [("notify:discord", -2, "", "Missing Discord webhook URL")]


class TestAgentHooks:
    def test_agent_hook_posts_structured_payload(self, monkeypatch: pytest.MonkeyPatch) -> None:
        calls: list[dict[str, Any]] = []

        class Response:
            status = 202

            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *args: object) -> None:
                return None

            def read(self) -> bytes:
                return b'{"accepted": true}'

        def fake_urlopen(request: Any, timeout: float) -> Response:
            calls.append(
                {
                    "url": request.full_url,
                    "payload": json.loads(request.data.decode("utf-8")),
                    "timeout": timeout,
                }
            )
            return Response()

        monkeypatch.setattr(docket.hooks.urllib.request, "urlopen", fake_urlopen)
        hooks = Hooks(
            {
                "on_failure": [
                    {
                        "type": "agent",
                        "url": "https://agent.example.test/hook",
                        "message": "Backup failed: {summary}. Run ID: {run_id}.",
                    }
                ]
            }
        )
        results = hooks.run_hooks(
            "on_failure",
            TaskResult(ok=False, summary="disk full", details={"path": "/data"}),
            {
                "run_id": "run-123",
                "task_name": "backup",
                "status": "failed",
                "exit_code": 1,
                "summary": "disk full",
                "details": {"path": "/data"},
            },
        )

        assert results == [("agent:https://agent.example.test/hook", 202, '{"accepted": true}', "")]
        assert calls[0]["payload"]["task_name"] == "backup"
        assert calls[0]["payload"]["run_id"] == "run-123"
        assert calls[0]["payload"]["exit_code"] == 1
        assert calls[0]["payload"]["details_json"] == '{"path": "/data"}'
        assert calls[0]["payload"]["message"] == "Backup failed: disk full. Run ID: run-123."

    def test_agent_hook_uses_url_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        class Response:
            status = 204

            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *args: object) -> None:
                return None

            def read(self) -> bytes:
                return b""

        seen: list[str] = []

        def fake_urlopen(request: Any, timeout: float) -> Response:
            seen.append(request.full_url)
            return Response()

        monkeypatch.setenv("AGENT_HOOK_URL", "https://agent.example.test/env")
        monkeypatch.setattr(docket.hooks.urllib.request, "urlopen", fake_urlopen)
        hooks = Hooks({"on_complete": {"type": "agent", "webhook_url_env": "AGENT_HOOK_URL"}})
        results = hooks.run_hooks("on_complete", TaskResult(ok=True, summary="done"))

        assert results[0][0] == "agent:https://agent.example.test/env"
        assert results[0][1] == 204
        assert seen == ["https://agent.example.test/env"]


class TestNoHooks:
    """When no hooks are configured."""

    def test_missing_on_success(self) -> None:
        hooks = Hooks({})
        assert hooks.run_hooks("on_success") == []

    def test_missing_on_failure(self) -> None:
        hooks = Hooks({})
        assert hooks.run_hooks("on_failure") == []

    def test_unknown_hook_type(self) -> None:
        hooks = Hooks({"on_success": "echo hi"})
        assert hooks.run_hooks("on_whatever") == []


class TestHookFailureDoesNotAffectResult:
    """Hook failures are non-blocking — they return results but don't raise."""

    def test_hook_error_returns_list(self) -> None:
        # Even a totally broken hook returns a tuple, not an exception.
        cfg: dict[str, Any] = {"on_success": "exit 42"}
        hooks = Hooks(cfg)
        results = hooks.run_hooks("on_success")
        assert len(results) == 1
        assert results[0][1] == 42
