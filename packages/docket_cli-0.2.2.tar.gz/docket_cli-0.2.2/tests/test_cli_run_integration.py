"""Integration / E2E tests for the `docket run` command.

Tests exercise the full CLI run flow including lock lifecycle, retry
logic, hook execution, JSON output, and state recording.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import pytest
import yaml
from click.testing import CliRunner

from docket.cli import cli
from docket.lockfile import LockFile
from docket.state import StateStore


def _extract_json(output: str) -> dict[str, Any]:
    """Extract the last valid JSON object from mixed stdout/stderr output.

    CliRunner mixes stdout and stderr. When ``--json`` is used, log lines
    (also JSON) appear before the actual command result. The result is
    always the last JSON object in the output.
    """
    # Find all top-level JSON objects by tracking brace depth.
    objects: list[str] = []
    depth = 0
    start = -1
    in_string = False
    escape = False

    for i, ch in enumerate(output):
        if escape:
            escape = False
            continue
        if ch == "\\" and in_string:
            escape = True
            continue
        if ch == '"' and not escape:
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                objects.append(output[start : i + 1])
                start = -1

    if not objects:
        raise ValueError(f"No JSON objects found in output:\n{output}")

    # Return the last one (the command result, not log lines).
    return json.loads(objects[-1])


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def docket_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Set up a full temporary Docket home, config, and tasks_dir.

    Patches ``DEFAULT_CONFIG_PATH`` so every CLI call in the test uses
    the temp config.  Returns the config directory path.
    """
    home = tmp_path / ".docket"
    home.mkdir()
    tasks_dir = home / "tasks"
    tasks_dir.mkdir()

    config = {
        "state_dir": str(home / "state.db"),
        "tasks_dir": str(tasks_dir),
        "tasks": {
            "health-check": {
                "checks": ["disk", "memory"],
            },
        },
    }
    cfg_file = home / "config.yaml"
    cfg_file.write_text(yaml.dump(config, default_flow_style=False))

    monkeypatch.setattr("docket.config.DEFAULT_CONFIG_PATH", cfg_file)
    yield home

    # Ensure no stale locks from tests leak out.
    locks_dir = home / "locks"
    if locks_dir.is_dir():
        for lf in locks_dir.glob("*.lock"):
            try:
                lf.unlink()
            except OSError:
                pass


@pytest.fixture
def config_path(docket_env: Path) -> Path:
    """Return the path to the temporary config file."""
    return docket_env / "config.yaml"


@pytest.fixture
def state_db(docket_env: Path) -> Path:
    """Return the path to the state database."""
    return docket_env / "state.db"


@pytest.fixture
def tasks_dir(docket_env: Path) -> Path:
    """Return the tasks drop-in directory."""
    return docket_env / "tasks"


def _write_config(docket_env: Path, tasks_config: dict[str, Any]) -> None:
    """Rewrite config.yaml with updated task configuration."""
    cfg_path = docket_env / "config.yaml"
    base: dict[str, Any] = yaml.safe_load(cfg_path.read_text())
    base["tasks"].update(tasks_config)
    cfg_path.write_text(yaml.dump(base, default_flow_style=False))


# ===========================================================================
# TestRunIntegration — Full run command lifecycle
# ===========================================================================


class TestRunIntegration:
    """End-to-end tests for `docket run` happy paths and guards."""

    def test_run_success_records_state(
        self,
        runner: CliRunner,
        docket_env: Path,
        state_db: Path,
    ) -> None:
        """Running health-check should record state in SQLite."""
        result = runner.invoke(cli, ["run", "health-check"])
        assert result.exit_code == 0, result.output

        with StateStore(str(state_db)) as state:
            rec = state.get("health-check")
            assert rec is not None, "expected a state record"
            assert rec["exit_code"] == 0
            assert rec["summary"] != ""

    def test_run_json_output_contains_all_fields(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """``--json run health-check --force`` should include all required keys."""
        result = runner.invoke(cli, ["--json", "run", "health-check", "--force"])
        assert result.exit_code == 0, result.output

        data = _extract_json(result.output)
        for key in ("ok", "summary", "details", "dry_run", "exit_code", "retry_count"):
            assert key in data, f"missing key: {key}"

    def test_run_dry_run_exit_code_2(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """``docket run health-check --dry-run`` should produce exit_code=2 in JSON."""
        result = runner.invoke(cli, ["--json", "run", "health-check", "--dry-run"])
        assert result.exit_code == 2, result.output

        data = _extract_json(result.output)
        assert data["exit_code"] == 2
        assert data["dry_run"] is True
        assert data["ok"] is True

    def test_already_ran_today_guard(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """Running health-check twice without --force should be skipped."""
        # First run — succeeds.
        result = runner.invoke(cli, ["run", "health-check"])
        assert result.exit_code == 0, result.output

        # Second run — should be skipped because it already ran today.
        result = runner.invoke(cli, ["run", "health-check"])
        assert "already ran" in result.output

    def test_already_ran_today_guard_json(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """Same as above, but --json mode should emit a skipped JSON payload."""
        result = runner.invoke(cli, ["--json", "run", "health-check"])
        assert result.exit_code == 0, result.output

        result = runner.invoke(cli, ["--json", "run", "health-check"])
        assert result.exit_code == 0, result.output
        data = _extract_json(result.output)
        assert data.get("skipped") is True
        assert data.get("reason") == "already_ran_today"

    def test_force_overrides_already_ran(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """``--force`` should override the 'already ran today' guard."""
        result = runner.invoke(cli, ["run", "health-check"])
        assert result.exit_code == 0, result.output

        result = runner.invoke(cli, ["run", "health-check", "--force"])
        assert result.exit_code == 0, result.output
        assert "already ran" not in result.output


# ===========================================================================
# TestRunLockIntegration — Lock file behavior through CLI
# ===========================================================================


class TestRunLockIntegration:
    """Lock acquisition / release via the CLI run command."""

    def test_lock_prevents_concurrent_run(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """Acquiring a lock should cause a second run to report 'already running'."""
        lock = LockFile(task_name="health-check")
        lock.path.parent.mkdir(parents=True, exist_ok=True)
        acquired = lock.acquire()
        assert acquired, "failed to acquire lock in test setup"

        try:
            result = runner.invoke(cli, ["run", "health-check"])
            # The lock guard should refuse the run.
            assert "already running" in result.output
        finally:
            lock.release()

    def test_lock_released_after_success(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """After a successful run, the lock should be re-acquirable.

        Note: release() closes the fd and releases the fcntl lock but does NOT
        delete the file. is_locked() returns True if the PID in the file is
        alive (which it is — it's our own process). So we test that a second
        run can acquire the lock (proving it was released).
        """
        result = runner.invoke(cli, ["run", "health-check"])
        assert result.exit_code == 0, result.output

        # Second run should succeed — lock was released after first run.
        result2 = runner.invoke(cli, ["run", "health-check", "--force"])
        assert result2.exit_code == 0, result2.output

    def test_force_skips_lock(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """``--force`` should bypass lock acquisition and still run the task."""
        # Write a stale lock (dead PID) so the lock check sees it's locked.
        lock = LockFile(task_name="health-check")
        lock.path.parent.mkdir(parents=True, exist_ok=True)
        lock.path.write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")

        try:
            result = runner.invoke(cli, ["run", "--force", "health-check"])
            # With --force the lock is bypassed entirely; task should succeed.
            assert result.exit_code == 0, result.output
            assert "already running" not in result.output
        finally:
            # Clean up the stale lock file
            if lock.path.exists():
                lock.path.unlink()

    def test_stale_lock_cleaned(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """A stale lock (dead PID) should be cleaned, and the run should succeed."""
        lock = LockFile(task_name="health-check")
        lock.path.parent.mkdir(parents=True, exist_ok=True)
        # Write a lock file with a PID that doesn't exist
        lock.path.write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")

        try:
            result = runner.invoke(cli, ["run", "health-check"])
            # Stale lock should be cleaned, run should succeed
            assert result.exit_code == 0, result.output
            assert "already running" not in result.output
        finally:
            # Clean up
            if lock.path.exists():
                lock.path.unlink()


# ===========================================================================
# TestRunRetryIntegration — Retry with exponential backoff
# ===========================================================================


class TestRunRetryIntegration:
    """Retry logic exercised through the full CLI run path."""

    def _write_flaky_task(self, tasks_dir: Path) -> None:
        """Create a drop-in task that fails once then succeeds."""
        flaky_code = """\
from docket.task import BaseTask, TaskResult
from typing import Any

class FlakyTask(BaseTask):
    name = "flaky-task"
    description = "A task that fails once then succeeds"
    _skip_validation = True

    _call_count = 0

    def run(self, config: dict[str, Any]) -> TaskResult:
        FlakyTask._call_count += 1
        if FlakyTask._call_count <= 1:
            return TaskResult(ok=False, summary="transient failure")
        return TaskResult(ok=True, summary="recovered")

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        return TaskResult(ok=True, summary="dry-run", dry_run=True)
"""
        (tasks_dir / "flaky_task.py").write_text(flaky_code)

    def _write_failing_task(self, tasks_dir: Path) -> None:
        """Create a drop-in task that always fails."""
        fail_code = """\
from docket.task import BaseTask, TaskResult
from typing import Any

class AlwaysFailTask(BaseTask):
    name = "always-fail"
    description = "A task that always fails"
    _skip_validation = True

    _call_count = 0

    def run(self, config: dict[str, Any]) -> TaskResult:
        AlwaysFailTask._call_count += 1
        return TaskResult(ok=False, summary="permanent failure")

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        return TaskResult(ok=True, summary="dry-run", dry_run=True)
"""
        (tasks_dir / "always_fail.py").write_text(fail_code)

    def test_retry_count_in_json_output(
        self,
        runner: CliRunner,
        docket_env: Path,
        tasks_dir: Path,
    ) -> None:
        """A task with ``retry: 2`` that fails once should show retry_count >= 1."""
        self._write_flaky_task(tasks_dir)

        _write_config(
            docket_env,
            {
                "flaky-task": {"retry": 2},
            },
        )

        result = runner.invoke(cli, ["--json", "run", "flaky-task", "--force"])
        assert result.exit_code == 0, result.output

        data = _extract_json(result.output)
        assert data["ok"] is True
        assert data["retry_count"] >= 1

    def test_no_retry_when_zero(
        self,
        runner: CliRunner,
        docket_env: Path,
        tasks_dir: Path,
    ) -> None:
        """With ``retry: 0`` (default), a failing task should not retry."""
        self._write_failing_task(tasks_dir)

        _write_config(
            docket_env,
            {
                "always-fail": {"retry": 0},
            },
        )

        result = runner.invoke(cli, ["--json", "run", "always-fail", "--force"])
        # Task fails → exit_code 1
        assert result.exit_code == 1, result.output

        data = _extract_json(result.output)
        assert data["ok"] is False
        assert data["retry_count"] == 0


# ===========================================================================
# TestRunHooksIntegration — Notification hooks
# ===========================================================================


class TestRunHooksIntegration:
    """Hook execution triggered by the CLI run command."""

    def test_on_success_hook_runs(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """``on_success`` hook output should appear in JSON response."""
        _write_config(
            docket_env,
            {
                "health-check": {
                    "checks": ["disk"],
                    "on_success": "echo success_hook_ran",
                },
            },
        )

        result = runner.invoke(cli, ["--json", "run", "health-check", "--force"])
        assert result.exit_code == 0, result.output

        data = _extract_json(result.output)
        assert data["ok"] is True
        assert "hooks" in data
        hooks = data["hooks"]
        assert len(hooks) >= 1
        # First hook should be the echo command
        assert "success_hook_ran" in hooks[0]["stdout"]

    def test_on_failure_hook_runs(
        self,
        runner: CliRunner,
        docket_env: Path,
        tasks_dir: Path,
    ) -> None:
        """``on_failure`` hook should execute when the task fails."""
        # Write a drop-in task that always fails
        fail_code = """\
from docket.task import BaseTask, TaskResult
from typing import Any

class FailTask(BaseTask):
    name = "fail-task"
    description = "Always fails"
    _skip_validation = True

    def run(self, config: dict[str, Any]) -> TaskResult:
        return TaskResult(ok=False, summary="deliberate failure")

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        return TaskResult(ok=True, summary="dry-run", dry_run=True)
"""
        (tasks_dir / "fail_task.py").write_text(fail_code)

        _write_config(
            docket_env,
            {
                "fail-task": {
                    "on_failure": "echo failure_hook_ran",
                },
            },
        )

        result = runner.invoke(cli, ["--json", "run", "fail-task", "--force"])
        # Task fails → exit_code 1
        assert result.exit_code == 1, result.output

        data = _extract_json(result.output)
        assert data["ok"] is False
        assert "hooks" in data
        hooks = data["hooks"]
        assert len(hooks) >= 1
        assert "failure_hook_ran" in hooks[0]["stdout"]

    def test_hook_failure_does_not_affect_result(
        self,
        runner: CliRunner,
        docket_env: Path,
    ) -> None:
        """A failing ``on_success`` hook must not make the task report failure."""
        _write_config(
            docket_env,
            {
                "health-check": {
                    "checks": ["disk"],
                    "on_success": "exit 1",
                },
            },
        )

        result = runner.invoke(cli, ["--json", "run", "health-check", "--force"])
        assert result.exit_code == 0, result.output

        data = _extract_json(result.output)
        # Task itself should still report success
        assert data["ok"] is True
        # Hook should be recorded with its non-zero exit code
        assert "hooks" in data
        assert data["hooks"][0]["exit_code"] != 0

    def test_hook_timeout_does_not_block(
        self,
        runner: CliRunner,
        docket_env: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """A long-running hook (sleep 60) should be timed out and not hang the run."""
        from docket import hooks as hooks_mod

        # Patch timeout down to 1s to keep the test fast.
        monkeypatch.setattr(hooks_mod.Hooks, "TIMEOUT", 1)

        _write_config(
            docket_env,
            {
                "health-check": {
                    "checks": ["disk"],
                    "on_success": "sleep 60",
                },
            },
        )

        start = time.time()
        result = runner.invoke(cli, ["--json", "run", "health-check", "--force"])
        elapsed = time.time() - start

        assert result.exit_code == 0, result.output
        # Should complete well under 60s — proving the timeout works.
        assert elapsed < 30, f"Run took {elapsed:.1f}s — hook timeout not working?"

        data = _extract_json(result.output)
        assert data["ok"] is True
        assert "hooks" in data
        # Hook should report timeout (exit_code == -1)
        assert data["hooks"][0]["exit_code"] == -1
