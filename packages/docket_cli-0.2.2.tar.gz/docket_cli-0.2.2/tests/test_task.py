"""Tests for docket.task — BaseTask ABC and TaskResult."""

from __future__ import annotations

import pytest

from docket.task import BaseTask, TaskResult


class TestTaskResult:
    """Tests for the TaskResult dataclass."""

    def test_ok_result_exit_code_0(self) -> None:
        r = TaskResult(ok=True, summary="done")
        assert r.exit_code == 0

    def test_failed_result_exit_code_1(self) -> None:
        r = TaskResult(ok=False, summary="boom")
        assert r.exit_code == 1

    def test_dry_run_ok_exit_code_2(self) -> None:
        r = TaskResult(ok=True, summary="would do x", dry_run=True)
        assert r.exit_code == 2

    def test_dry_run_failed_exit_code_1(self) -> None:
        r = TaskResult(ok=False, summary="bad", dry_run=True)
        assert r.exit_code == 1

    def test_details_default_empty(self) -> None:
        r = TaskResult(ok=True, summary="ok")
        assert r.details == {}

    def test_details_preserved(self) -> None:
        r = TaskResult(ok=True, summary="ok", details={"files": 3})
        assert r.details == {"files": 3}

    def test_frozen(self) -> None:
        r = TaskResult(ok=True, summary="ok")
        with pytest.raises(AttributeError):
            r.ok = False  # type: ignore[misc]


class ConcreteTask(BaseTask):
    name = "test-task"
    description = "A test task"

    def run(self, config):
        return TaskResult(ok=True, summary="ran")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="would run", dry_run=True)


class MissingNameTask(BaseTask):
    _skip_validation = True  # Allow class definition; validation at init
    name = ""
    description = "broken"

    def run(self, config):
        return TaskResult(ok=True, summary="x")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="x", dry_run=True)


class MissingDescTask(BaseTask):
    _skip_validation = True  # Allow class definition; validation at init
    name = "has-name"
    description = ""

    def run(self, config):
        return TaskResult(ok=True, summary="x")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="x", dry_run=True)


class TestBaseTask:
    def test_concrete_subclass_instantiates(self) -> None:
        task = ConcreteTask()
        assert task.name == "test-task"
        assert task.description == "A test task"

    def test_run_returns_result(self) -> None:
        task = ConcreteTask()
        result = task.run({})
        assert result.ok
        assert result.summary == "ran"
        assert not result.dry_run

    def test_dry_run_returns_result(self) -> None:
        task = ConcreteTask()
        result = task.dry_run({})
        assert result.ok
        assert result.dry_run

    def test_empty_name_raises(self) -> None:
        # Bypass _skip_validation by directly calling __init__ logic
        with pytest.raises(TypeError, match="must define a non-empty 'name'"):
            # Temporarily enable validation
            MissingNameTask._skip_validation = False
            try:
                MissingNameTask()
            finally:
                MissingNameTask._skip_validation = True

    def test_empty_description_raises(self) -> None:
        with pytest.raises(TypeError, match="must define a non-empty 'description'"):
            MissingDescTask._skip_validation = False
            try:
                MissingDescTask()
            finally:
                MissingDescTask._skip_validation = True

    def test_cannot_instantiate_base(self) -> None:
        with pytest.raises(TypeError):
            BaseTask()  # type: ignore[abstract]
