"""Tests for docket.lockfile — Lock file management."""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

from docket.lockfile import LockFile


class TestLockFileAcquireRelease:
    """Basic acquire and release cycle."""

    def test_acquire_returns_true(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        assert lock.acquire() is True
        lock.release()

    def test_acquire_creates_lock_file(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        lock.acquire()
        assert (tmp_path / "test.lock").exists()
        lock.release()

    def test_lock_file_contains_pid(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        lock.acquire()
        content = (tmp_path / "test.lock").read_text()
        assert f"pid={os.getpid()}" in content
        lock.release()

    def test_lock_file_contains_timestamp(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        lock.acquire()
        content = (tmp_path / "test.lock").read_text()
        assert "timestamp=" in content
        lock.release()

    def test_release_allows_reacquire(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        assert lock.acquire() is True
        lock.release()
        # Should be able to acquire again
        lock2 = LockFile(path=tmp_path / "test.lock")
        assert lock2.acquire() is True
        lock2.release()


class TestLockFileConcurrent:
    """Concurrent lock acquisition failure."""

    def test_second_lock_fails(self, tmp_path: Path) -> None:
        lock1 = LockFile(path=tmp_path / "test.lock")
        lock2 = LockFile(path=tmp_path / "test.lock")

        assert lock1.acquire() is True
        # Second lock on same path should fail (non-blocking)
        assert lock2.acquire() is False
        lock1.release()

    def test_second_lock_succeeds_after_release(self, tmp_path: Path) -> None:
        lock1 = LockFile(path=tmp_path / "test.lock")
        lock2 = LockFile(path=tmp_path / "test.lock")

        assert lock1.acquire() is True
        lock1.release()
        assert lock2.acquire() is True
        lock2.release()

    def test_concurrent_process_lock(self, tmp_path: Path) -> None:
        """Lock held in a child process should block the parent."""
        lock_path = tmp_path / "cross.lock"
        lock = LockFile(path=lock_path)

        # Start a child process that holds the lock for a few seconds
        child_code = f"""
import time
from pathlib import Path
from docket.lockfile import LockFile

lock = LockFile(path=Path(r'{lock_path}'))
if not lock.acquire():
    raise SystemExit(2)
time.sleep(5)
lock.release()
"""
        proc = subprocess.Popen(
            [sys.executable, "-c", child_code],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            # Give child time to acquire lock
            time.sleep(0.5)
            assert lock.acquire() is False
        finally:
            proc.terminate()
            proc.wait()


class TestLockFileIsLocked:
    """is_locked() behaviour."""

    def test_not_locked_when_no_file(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        assert lock.is_locked() is False

    def test_is_locked_when_held(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        lock.acquire()
        # The lock is held by us, so is_locked should read our PID and find it alive
        assert lock.is_locked() is True
        lock.release()

    def test_is_locked_with_stale_pid(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "test.lock"
        # Write a lock file with a PID that definitely doesn't exist
        lock_path.write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")
        lock = LockFile(path=lock_path)
        assert lock.is_locked() is False

    def test_is_locked_bad_content(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "test.lock"
        lock_path.write_text("garbage content\n")
        lock = LockFile(path=lock_path)
        assert lock.is_locked() is False


class TestLockFileCleanStale:
    """Stale lock cleanup."""

    def test_clean_stale_removes_dead_pid_lock(self, tmp_path: Path) -> None:
        locks_dir = tmp_path / "locks"
        locks_dir.mkdir()
        # Create a stale lock file
        (locks_dir / "stale.lock").write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")
        lock = LockFile(path=locks_dir / "stale.lock")
        cleaned = lock.clean_stale()
        assert cleaned == 1
        assert not (locks_dir / "stale.lock").exists()

    def test_clean_stale_keeps_alive_pid_lock(self, tmp_path: Path) -> None:
        locks_dir = tmp_path / "locks"
        locks_dir.mkdir()
        # Create a lock file with our own (alive) PID
        (locks_dir / "alive.lock").write_text(f"pid={os.getpid()}\ntimestamp=2025-01-01T00:00:00\n")
        lock = LockFile(path=locks_dir / "alive.lock")
        cleaned = lock.clean_stale()
        assert cleaned == 0
        assert (locks_dir / "alive.lock").exists()

    def test_clean_stale_no_dir(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "nonexistent" / "test.lock")
        assert lock.clean_stale() == 0

    def test_clean_stale_multiple_files(self, tmp_path: Path) -> None:
        locks_dir = tmp_path / "locks"
        locks_dir.mkdir()
        (locks_dir / "stale1.lock").write_text("pid=999999998\ntimestamp=2025-01-01T00:00:00\n")
        (locks_dir / "stale2.lock").write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")
        (locks_dir / "alive.lock").write_text(f"pid={os.getpid()}\ntimestamp=2025-01-01T00:00:00\n")
        lock = LockFile(path=locks_dir / "alive.lock")
        cleaned = lock.clean_stale()
        assert cleaned == 2


class TestLockFileTaskName:
    """Lock file with task_name generates default path."""

    def test_default_path_from_task_name(self) -> None:
        lock = LockFile(task_name="backup-gdrive")
        assert lock.path == Path.home() / ".docket" / "locks" / "backup-gdrive.lock"

    def test_no_args_raises(self) -> None:
        with pytest.raises(ValueError):
            LockFile()


class TestLockFileContextManager:
    """LockFile as context manager."""

    def test_context_manager_acquires_and_releases(self, tmp_path: Path) -> None:
        lock = LockFile(path=tmp_path / "test.lock")
        with lock:
            assert (tmp_path / "test.lock").exists()
        # After context, lock is released; another can acquire
        lock2 = LockFile(path=tmp_path / "test.lock")
        assert lock2.acquire() is True
        lock2.release()

    def test_context_manager_raises_on_failure(self, tmp_path: Path) -> None:
        lock1 = LockFile(path=tmp_path / "test.lock")
        lock1.acquire()
        lock2 = LockFile(path=tmp_path / "test.lock")
        with pytest.raises(RuntimeError, match="Could not acquire lock"):
            lock2.__enter__()
        lock1.release()
