"""Integration tests for docket configure — end-to-end editor interaction and validation."""

from __future__ import annotations

import stat
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml
from click.testing import CliRunner

from docket.cli import cli


@pytest.fixture
def config_path(tmp_path: Path) -> Path:
    """Return a fresh config path inside a temp directory."""
    return tmp_path / ".docket" / "config.yaml"


def _make_editor_script(tmp_path: Path, content_to_write: str) -> Path:
    """Create a Python script that writes *content_to_write* to the file given as $1.

    Uses a Python script because heredocs in shell scripts are fragile with YAML content.
    """
    content_file = tmp_path / "_editor_content.txt"
    content_file.write_text(content_to_write)

    script = tmp_path / "fake_editor.py"
    # Python script: read content from companion file, write to file in sys.argv[1]
    script_lines = [
        "#!/usr/bin/env python3",
        "import sys, shutil",
        f"shutil.copy({str(content_file)!r}, sys.argv[1])",
    ]
    script.write_text("\n".join(script_lines) + "\n")
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    return script


def _make_noop_editor(tmp_path: Path) -> Path:
    """Create a Python script that does nothing (exit 0)."""
    script = tmp_path / "noop_editor.py"
    script.write_text("#!/usr/bin/env python3\nimport sys\nsys.exit(0)\n")
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    return script


class TestConfigureCreatesDefaultConfig:
    """When config doesn't exist, running configure should create it with defaults."""

    def test_creates_config_file(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(_make_noop_editor(tmp_path)))

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])

        assert result.exit_code == 0
        assert config_path.exists(), "configure should create the config file"

    def test_default_config_has_state_dir(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(_make_noop_editor(tmp_path)))

        runner = CliRunner()
        runner.invoke(cli, ["configure"])

        data = yaml.safe_load(config_path.read_text())
        assert "state_dir" in data, "default config should contain state_dir"

    def test_default_config_has_tasks_dir(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(_make_noop_editor(tmp_path)))

        runner = CliRunner()
        runner.invoke(cli, ["configure"])

        data = yaml.safe_load(config_path.read_text())
        assert "tasks_dir" in data, "default config should contain tasks_dir"

    def test_default_config_has_empty_tasks(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(_make_noop_editor(tmp_path)))

        runner = CliRunner()
        runner.invoke(cli, ["configure"])

        data = yaml.safe_load(config_path.read_text())
        assert "tasks" in data
        assert data["tasks"] == {}, "default config should have an empty tasks dict"

    def test_default_config_paths_reference_config_parent(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Default state_dir and tasks_dir should point inside the config's parent dir."""
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(_make_noop_editor(tmp_path)))

        runner = CliRunner()
        runner.invoke(cli, ["configure"])

        data = yaml.safe_load(config_path.read_text())
        assert str(config_path.parent) in data["state_dir"]
        assert str(config_path.parent) in data["tasks_dir"]


class TestConfigureEditsAndValidates:
    """EDITOR writes valid YAML → configure validates successfully."""

    def test_edits_and_validates_successfully(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        valid_yaml = yaml.dump(
            {
                "state_dir": "/tmp/test-state",
                "tasks_dir": "/tmp/test-tasks",
                "tasks": {"backup": {"schedule": "0 2 * * *"}},
            }
        )

        editor_script = _make_editor_script(tmp_path, valid_yaml)
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(editor_script))

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])

        assert result.exit_code == 0, (
            f"Expected exit 0, got {result.exit_code}; output: {result.output}"
        )
        assert "validated" in result.output.lower()

    def test_edited_config_persists(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        new_config = {
            "state_dir": "/custom/state",
            "tasks_dir": "/custom/tasks",
            "tasks": {"hello": {"schedule": "*/5 * * * *"}},
        }
        valid_yaml = yaml.dump(new_config)
        editor_script = _make_editor_script(tmp_path, valid_yaml)
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(editor_script))

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])

        assert result.exit_code == 0, (
            f"Expected exit 0, got {result.exit_code}; output: {result.output}"
        )
        data = yaml.safe_load(config_path.read_text())
        assert data["tasks"] == new_config["tasks"]
        assert data["state_dir"] == new_config["state_dir"]


class TestConfigureRejectsInvalidYaml:
    """With EDITOR set to a script that writes invalid YAML, verify configure detects the error."""

    def test_invalid_yaml_detected(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        editor_script = _make_editor_script(tmp_path, "{{{:invalid yaml")
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(editor_script))

        runner = CliRunner()
        # Respond "n" to the re-edit prompt
        result = runner.invoke(cli, ["configure"], input="n\n")

        # Should detect invalid YAML and abort
        assert result.exit_code != 0 or "Invalid YAML" in result.output

    def test_invalid_yaml_with_re_edit(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If YAML is invalid and user chooses to re-edit, the loop continues."""
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        editor_script = _make_editor_script(tmp_path, "{{{:bad")
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(editor_script))

        runner = CliRunner()
        # Answer "y" to re-edit (which fails again with same bad content), then "n" to abort
        result = runner.invoke(cli, ["configure"], input="y\nn\n")

        # Should still error because every edit produces invalid YAML
        assert result.exit_code != 0 or "Invalid YAML" in result.output


class TestConfigureUsesEditorEnvVar:
    """Verify it uses the EDITOR environment variable."""

    def test_uses_editor_env_var(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        # Create an editor script that overwrites config with valid YAML
        valid_yaml = yaml.dump({"state_dir": "/test", "tasks_dir": "/test-tasks", "tasks": {}})
        editor_script = _make_editor_script(tmp_path, valid_yaml)
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(editor_script))

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])

        assert result.exit_code == 0, f"Got exit {result.exit_code}; output: {result.output}"
        # The file should have been overwritten by the editor script
        data = yaml.safe_load(config_path.read_text())
        assert data["state_dir"] == "/test"

    def test_custom_editor_path_respected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify the exact EDITOR value is used to launch the editor."""
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        # Create a Python editor that writes a marker file to prove it was called
        marker_path = tmp_path / "editor_was_called.txt"
        custom_editor = tmp_path / "my_custom_editor.py"
        custom_editor.write_text(
            "#!/usr/bin/env python3\n"
            "import sys, pathlib\n"
            f"pathlib.Path({str(marker_path)!r}).write_text('called')\n"
            "sys.exit(0)\n"
        )
        custom_editor.chmod(custom_editor.stat().st_mode | stat.S_IEXEC)

        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(custom_editor))

        runner = CliRunner()
        runner.invoke(cli, ["configure"])

        # The custom editor script should have been called (writes marker file)
        assert marker_path.exists(), "Custom EDITOR script should have been executed"
        assert marker_path.read_text() == "called"


class TestConfigureFallsBackToVi:
    """When EDITOR is unset, verify fallback to vi."""

    def test_fallback_to_vi_when_editor_unset(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.delenv("EDITOR", raising=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])

        # If vi doesn't exist in CI, we get a ClickException with "vi" in the message.
        # If vi does exist, it will try to run interactively (unlikely in test).
        # In either case, the code should have attempted to use "vi".
        if result.exit_code != 0:
            # The error should mention "vi" or "not found"
            output_lower = result.output.lower()
            assert "vi" in output_lower or "not found" in output_lower

    def test_fallback_message_when_vi_not_found(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When EDITOR is unset and vi is not available, error message mentions vi."""
        config_path = tmp_path / ".docket" / "config.yaml"
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.delenv("EDITOR", raising=False)

        # Patch subprocess.run to force FileNotFoundError for vi
        with patch("docket.cli.subprocess.run", side_effect=FileNotFoundError("vi not found")):
            runner = CliRunner()
            result = runner.invoke(cli, ["configure"])

            # Should raise ClickException about vi not found
            assert result.exit_code != 0
            assert "vi" in result.output.lower() or "not found" in result.output.lower()

    def test_editor_overrides_vi(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """When EDITOR is set, it should be used instead of vi."""
        config_path = tmp_path / ".docket" / "config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("tasks: {}\n")

        noop = _make_noop_editor(tmp_path)
        monkeypatch.setattr("docket.cli.DEFAULT_CONFIG_PATH", config_path)
        monkeypatch.setenv("EDITOR", str(noop))
        # Ensure no fallback would happen
        monkeypatch.delenv("VISUAL", raising=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["configure"])
        assert result.exit_code == 0
        assert "validated" in result.output.lower()
