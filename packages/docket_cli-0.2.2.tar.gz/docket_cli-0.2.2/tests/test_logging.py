"""Tests for docket.logging — structured logging setup."""

from __future__ import annotations

import json
import logging

from docket.logging import HumanFormatter, JSONFormatter, setup_logging


class TestJSONFormatter:
    def test_formats_as_json(self) -> None:
        fmt = JSONFormatter(datefmt="%Y-%m-%dT%H:%M:%S")
        record = logging.LogRecord(
            name="docket",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="hello world",
            args=(),
            exc_info=None,
        )
        output = fmt.format(record)
        data = json.loads(output)
        assert data["message"] == "hello world"
        assert data["level"] == "info"
        assert "timestamp" in data

    def test_includes_exception(self) -> None:
        fmt = JSONFormatter(datefmt="%Y-%m-%dT%H:%M:%S")
        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()
        record = logging.LogRecord(
            name="docket",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="error occurred",
            args=(),
            exc_info=exc_info,
        )
        output = fmt.format(record)
        data = json.loads(output)
        assert "exception" in data
        assert "ValueError" in data["exception"]


class TestHumanFormatter:
    def test_basic_format(self) -> None:
        fmt = HumanFormatter()
        record = logging.LogRecord(
            name="docket",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )
        record.isatty = False  # type: ignore[attr-defined]
        output = fmt.format(record)
        assert "INFO" in output
        assert "test message" in output


class TestSetupLogging:
    def test_sets_level_warning_by_default(self) -> None:
        setup_logging()
        logger = logging.getLogger("docket")
        assert logger.level == logging.WARNING

    def test_verbose_sets_info(self) -> None:
        setup_logging(verbosity=1)
        logger = logging.getLogger("docket")
        assert logger.level == logging.INFO

    def test_very_verbose_sets_debug(self) -> None:
        setup_logging(verbosity=2)
        logger = logging.getLogger("docket")
        assert logger.level == logging.DEBUG

    def test_json_mode_sets_json_formatter(self) -> None:
        setup_logging(json_mode=True)
        logger = logging.getLogger("docket")
        assert len(logger.handlers) == 1
        assert isinstance(logger.handlers[0].formatter, JSONFormatter)

    def test_reconfiguration_clears_old_handlers(self) -> None:
        setup_logging()
        logger = logging.getLogger("docket")
        first_handler = logger.handlers[0]
        setup_logging()
        assert len(logger.handlers) == 1
        assert logger.handlers[0] is not first_handler
