"""Tests for docket.cli — install command."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

import docket.config as cfg_mod
from docket.cli import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def docket_home_with_schedules(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Set up a temporary DOCKET_HOME directory with scheduled tasks."""
    home = tmp_path / ".docket"
    home.mkdir()
    tasks_dir = home / "tasks"
    tasks_dir.mkdir()

    config = {
        "state_dir": str(home / "state.db"),
        "tasks_dir": str(tasks_dir),
        "tasks": {
            "backup": {
                "schedule": "0 2 * * *",
                "description": "Daily backup",
            },
            "sync": {
                "schedule": "*/5 * * * *",
            },
            "health-check": {
                "checks": ["disk"],
            },
        },
    }
    (home / "config.yaml").write_text(yaml.dump(config))
    return home


@pytest.fixture
def docket_home_no_schedules(tmp_path: Path) -> Path:
    """Set up a temporary DOCKET_HOME with no scheduled tasks."""
    home = tmp_path / ".docket"
    home.mkdir()
    tasks_dir = home / "tasks"
    tasks_dir.mkdir()

    config = {
        "state_dir": str(home / "state.db"),
        "tasks_dir": str(tasks_dir),
        "tasks": {
            "health-check": {
                "checks": ["disk"],
            },
        },
    }
    (home / "config.yaml").write_text(yaml.dump(config))
    return home


class TestInstallList:
    """Tests for 'docket install --list'."""

    def test_list_shows_scheduled_tasks(
        self, runner: CliRunner, docket_home_with_schedules: Path
    ) -> None:
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "--list"])
            assert result.exit_code == 0
            assert "backup" in result.output
            assert "sync" in result.output
            assert (
                "health-check" not in result.output
                or "schedule" not in result.output.lower().split("health-check")[0]
                if "health-check" in result.output
                else True
            )
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_list_json(self, runner: CliRunner, docket_home_with_schedules: Path) -> None:
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "install", "--list"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert isinstance(data, dict)
            assert "backup" in data or "tasks" in data
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_list_no_scheduled_tasks(
        self, runner: CliRunner, docket_home_no_schedules: Path
    ) -> None:
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_no_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "--list"])
            assert result.exit_code == 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestInstallWrite:
    """Tests for 'docket install' (actual file write)."""

    def test_install_all_writes_units(
        self, runner: CliRunner, docket_home_with_schedules: Path, tmp_path: Path
    ) -> None:
        systemd_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "--output-dir", str(systemd_dir)])
            assert result.exit_code == 0
            # Check that unit files were created.
            assert (systemd_dir / "docket-backup.service").exists()
            assert (systemd_dir / "docket-backup.timer").exists()
            assert (systemd_dir / "docket-sync.service").exists()
            assert (systemd_dir / "docket-sync.timer").exists()
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_specific_task(
        self, runner: CliRunner, docket_home_with_schedules: Path, tmp_path: Path
    ) -> None:
        systemd_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "backup", "--output-dir", str(systemd_dir)])
            assert result.exit_code == 0
            assert (systemd_dir / "docket-backup.service").exists()
            assert (systemd_dir / "docket-backup.timer").exists()
            # sync should NOT be installed
            assert not (systemd_dir / "docket-sync.service").exists()
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_json_output(
        self, runner: CliRunner, docket_home_with_schedules: Path, tmp_path: Path
    ) -> None:
        systemd_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "install", "--output-dir", str(systemd_dir)])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert "installed" in data
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_prints_daemon_reload(
        self, runner: CliRunner, docket_home_with_schedules: Path, tmp_path: Path
    ) -> None:
        systemd_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_with_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "--output-dir", str(systemd_dir)])
            assert "daemon-reload" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_skips_unscheduled(
        self, runner: CliRunner, docket_home_no_schedules: Path, tmp_path: Path
    ) -> None:
        systemd_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home_no_schedules / "config.yaml"
        try:
            result = runner.invoke(cli, ["install", "--output-dir", str(systemd_dir)])
            assert result.exit_code == 0
            # No unit files should be created
            assert not list(systemd_dir.glob("docket-*.service"))
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original
