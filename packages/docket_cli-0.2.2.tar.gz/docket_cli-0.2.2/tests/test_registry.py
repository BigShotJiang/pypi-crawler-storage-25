"""Tests for docket.registry — task discovery."""

from __future__ import annotations

from pathlib import Path

import pytest

from docket.registry import Registry, RegistryError
from docket.task import BaseTask, TaskResult


class SimpleTask(BaseTask):
    name = "simple"
    description = "A simple test task"

    def run(self, config):
        return TaskResult(ok=True, summary="simple ran")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="would run simple", dry_run=True)


class AnotherTask(BaseTask):
    name = "another"
    description = "Another test task"

    def run(self, config):
        return TaskResult(ok=True, summary="another ran")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="would run another", dry_run=True)


class TestRegistryEntryPoints:
    def test_discover_finds_entry_points(self) -> None:
        registry = Registry()
        tasks = registry.discover()
        # The built-in tasks should be discoverable via entry points
        # (defined in pyproject.toml).
        assert "backup" in tasks or "health-check" in tasks

    def test_get_known_task(self) -> None:
        registry = Registry()
        try:
            cls = registry.get("backup")
            assert cls.name == "backup"
        except RegistryError:
            pytest.skip("backup task not registered via entry point")

    def test_get_unknown_task_raises(self) -> None:
        registry = Registry()
        with pytest.raises(RegistryError, match="Unknown task"):
            registry.get("nonexistent-task-xyz")

    def test_instantiate_creates_instance(self) -> None:
        registry = Registry()
        try:
            task = registry.instantiate("backup")
            assert isinstance(task, BaseTask)
        except RegistryError:
            pytest.skip("backup task not registered via entry point")

    def test_refresh_clears_cache(self) -> None:
        registry = Registry()
        registry.discover()
        assert registry._cache is not None
        registry.refresh()
        # After refresh, a new cache should have been built.
        tasks = registry.discover()
        assert isinstance(tasks, dict)


class TestRegistryDirectory:
    def test_scan_directory_finds_tasks(self, tasks_dir: Path) -> None:
        # Write a drop-in task file.
        code = """
from docket.task import BaseTask, TaskResult

class DropInTask(BaseTask):
    name = "dropin-demo"
    description = "A drop-in test task"

    def run(self, config):
        return TaskResult(ok=True, summary="dropin ran")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="would run dropin", dry_run=True)
"""
        (tasks_dir / "dropin.py").write_text(code)

        registry = Registry(tasks_dir=tasks_dir)
        tasks = registry.discover()
        assert "dropin-demo" in tasks

    def test_scan_empty_directory(self, tasks_dir: Path) -> None:
        # No Python files in the directory.
        registry = Registry(tasks_dir=tasks_dir)
        # Entry-point tasks may still exist, but no drop-in tasks.
        registry.discover()
        # Just confirm it doesn't crash.

    def test_scan_nonexistent_directory(self, tmp_path: Path) -> None:
        registry = Registry(tasks_dir=tmp_path / "nope")
        # Should not crash, just return entry-point tasks.
        registry.discover()

    def test_entry_points_override_dropin(self, tasks_dir: Path) -> None:
        # Create a drop-in task with the same name as an entry-point task.
        code = """
from docket.task import BaseTask, TaskResult

class BackupOverride(BaseTask):
    name = "backup"
    description = "Override attempt"

    def run(self, config):
        return TaskResult(ok=True, summary="override")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="would override", dry_run=True)
"""
        (tasks_dir / "backup.py").write_text(code)
        registry = Registry(tasks_dir=tasks_dir)
        tasks = registry.discover()
        # Entry point version should win if both exist.
        if "backup" in tasks:
            # We can't guarantee the entry point was loaded first,
            # but the dict should have exactly one "backup" entry.
            assert tasks["backup"].name == "backup"

    def test_invalid_drop_in_raises(self, tasks_dir: Path) -> None:
        code = "raise ValueError('bad module')"
        (tasks_dir / "bad_task.py").write_text(code)
        registry = Registry(tasks_dir=tasks_dir)
        with pytest.raises(RegistryError, match="Failed to load drop-in"):
            registry.discover()
