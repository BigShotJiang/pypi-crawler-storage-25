"""Integration tests for docket install — deeper coverage of systemd unit generation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml
from click.testing import CliRunner

import docket.config as cfg_mod
from docket.cli import cli
from docket.systemd import cron_to_systemd

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_config(
    tmp_path: Path,
    tasks: dict[str, dict[str, Any]],
    state_dir_suffix: str = "state.db",
    tasks_dir_suffix: str = "tasks",
) -> Path:
    """Write a config.yaml with the given tasks and return its path."""
    home = tmp_path / ".docket"
    home.mkdir(parents=True, exist_ok=True)
    tasks_dir = home / tasks_dir_suffix
    tasks_dir.mkdir(parents=True, exist_ok=True)

    config = {
        "state_dir": str(home / state_dir_suffix),
        "tasks_dir": str(tasks_dir),
        "tasks": tasks,
    }
    cfg_path = home / "config.yaml"
    cfg_path.write_text(yaml.dump(config, default_flow_style=False, sort_keys=False))
    return cfg_path


def _run_install(
    runner: CliRunner, cfg_path: Path, output_dir: Path, extra_args: list[str] | None = None
) -> Any:
    """Patch DEFAULT_CONFIG_PATH, invoke install, and restore."""
    original = cfg_mod.DEFAULT_CONFIG_PATH
    cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
    try:
        args = ["install", "--output-dir", str(output_dir)]
        if extra_args:
            args.extend(extra_args)
        return runner.invoke(cli, args)
    finally:
        cfg_mod.DEFAULT_CONFIG_PATH = original


def _run_install_list_json(
    runner: CliRunner, cfg_path: Path, extra_args: list[str] | None = None
) -> Any:
    """Patch DEFAULT_CONFIG_PATH, invoke install --list with --json, and restore."""
    original = cfg_mod.DEFAULT_CONFIG_PATH
    cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
    try:
        args = ["--json", "install", "--list"]
        if extra_args:
            args.extend(extra_args)
        return runner.invoke(cli, args)
    finally:
        cfg_mod.DEFAULT_CONFIG_PATH = original


# ---------------------------------------------------------------------------
# Tests: systemd service unit content
# ---------------------------------------------------------------------------


class TestInstallGeneratesValidSystemdService:
    """Install to tmp dir, verify .service has [Unit], [Service], [Install]."""

    def test_service_has_unit_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *", "description": "Daily backup"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "[Unit]" in service_content

    def test_service_has_service_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "[Service]" in service_content

    def test_service_has_install_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "[Install]" in service_content

    def test_service_type_oneshot(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "Type=oneshot" in service_content

    def test_service_has_execstart(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "ExecStart=" in service_content


# ---------------------------------------------------------------------------
# Tests: systemd timer unit content
# ---------------------------------------------------------------------------


class TestInstallGeneratesValidSystemdTimer:
    """Read .timer, verify [Unit], [Timer], [Install] with OnCalendar."""

    def test_timer_has_unit_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "[Unit]" in timer_content

    def test_timer_has_timer_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "[Timer]" in timer_content

    def test_timer_has_install_section(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "[Install]" in timer_content

    def test_timer_has_oncalendar(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "OnCalendar=" in timer_content

    def test_timer_has_persistent_true(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "Persistent=true" in timer_content


# ---------------------------------------------------------------------------
# Tests: specific schedule conversions
# ---------------------------------------------------------------------------


class TestInstallDailySchedule:
    """Config with schedule '0 2 * * *' should produce timer OnCalendar=*-*-* 02:00:00."""

    def test_daily_schedule_oncalendar(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-backup.timer").read_text()
        assert "OnCalendar=*-*-* 02:00:00" in timer_content

    def test_daily_schedule_via_cron_to_systemd(self) -> None:
        """Directly verify cron_to_systemd conversion for daily schedule."""
        assert cron_to_systemd("0 2 * * *") == "*-*-* 02:00:00"


class TestInstallEvery5Min:
    """Config with schedule '*/5 * * * *' should produce timer OnCalendar=*:0/5."""

    def test_every_5_min_oncalendar(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "sync": {"schedule": "*/5 * * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        timer_content = (output_dir / "docket-sync.timer").read_text()
        assert "OnCalendar=*:0/5" in timer_content

    def test_every_5_min_via_cron_to_systemd(self) -> None:
        """Directly verify cron_to_systemd conversion for every-5-min schedule."""
        assert cron_to_systemd("*/5 * * * *") == "*:0/5"


# ---------------------------------------------------------------------------
# Tests: ExecStart references docket
# ---------------------------------------------------------------------------


class TestInstallServiceExecstartReferencesDocket:
    """Verify ExecStart contains 'docket run <task>'."""

    def test_execstart_references_docket_run(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "docket run backup" in service_content

    def test_execstart_with_custom_docket_bin(self, tmp_path: Path) -> None:
        """When docket_bin is set in task config, ExecStart uses that binary path."""
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *", "docket_bin": "/usr/local/bin/docket"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-backup.service").read_text()
        assert "ExecStart=/usr/local/bin/docket run backup" in service_content

    def test_execstart_default_docket_bin(self, tmp_path: Path) -> None:
        """Without docket_bin, ExecStart should just use 'docket'."""
        cfg_path = _make_config(
            tmp_path,
            {
                "sync": {"schedule": "*/5 * * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        _run_install(runner, cfg_path, output_dir)

        service_content = (output_dir / "docket-sync.service").read_text()
        assert "ExecStart=docket run sync" in service_content


# ---------------------------------------------------------------------------
# Tests: install --list --json structure
# ---------------------------------------------------------------------------


class TestInstallListJsonStructure:
    """Run 'docket --json install --list', parse JSON, verify structure."""

    def test_json_has_task_names_as_keys(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
                "sync": {"schedule": "*/5 * * * *"},
            },
        )
        runner = CliRunner()
        result = _run_install_list_json(runner, cfg_path)
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert "backup" in data
        assert "sync" in data

    def test_json_task_has_schedule_key(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        runner = CliRunner()
        result = _run_install_list_json(runner, cfg_path)
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert "schedule" in data["backup"]
        assert data["backup"]["schedule"] == "0 2 * * *"

    def test_json_task_has_service_key(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        runner = CliRunner()
        result = _run_install_list_json(runner, cfg_path)
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert "service" in data["backup"]
        assert "[Unit]" in data["backup"]["service"]
        assert "[Service]" in data["backup"]["service"]

    def test_json_task_has_timer_key(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        runner = CliRunner()
        result = _run_install_list_json(runner, cfg_path)
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert "timer" in data["backup"]
        assert "[Timer]" in data["backup"]["timer"]
        assert "OnCalendar=" in data["backup"]["timer"]


# ---------------------------------------------------------------------------
# Tests: tasks without schedule are skipped
# ---------------------------------------------------------------------------


class TestInstallNoScheduleSkipsTask:
    """Verify tasks without the schedule key are not in --list output."""

    def test_no_schedule_not_in_list(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
                "cleanup": {"command": "/usr/bin/clean"},  # no schedule
            },
        )
        runner = CliRunner()
        result = _run_install_list_json(runner, cfg_path)
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert "backup" in data
        assert "cleanup" not in data, "Tasks without schedule should not appear in list"

    def test_no_schedule_not_in_plain_list(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
                "cleanup": {"command": "/usr/bin/clean"},
            },
        )
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
        try:
            runner = CliRunner()
            result = runner.invoke(cli, ["install", "--list"])
            assert result.exit_code == 0
            assert "backup" in result.output
            # cleanup should not appear in the scheduled tasks list
            # Just verify cleanup is not listed as scheduled
            assert (
                "cleanup" not in result.output
                or "schedule" not in result.output.split("cleanup")[0]
                if "cleanup" in result.output
                else True
            )
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_no_schedule_no_unit_files(self, tmp_path: Path) -> None:
        """Tasks without schedule should not have unit files written."""
        cfg_path = _make_config(
            tmp_path,
            {
                "cleanup": {"command": "/usr/bin/clean"},  # no schedule
            },
        )
        output_dir = tmp_path / "systemd"
        runner = CliRunner()
        result = _run_install(runner, cfg_path, output_dir)

        assert result.exit_code == 0
        assert not (output_dir / "docket-cleanup.service").exists()
        assert not (output_dir / "docket-cleanup.timer").exists()


# ---------------------------------------------------------------------------
# Tests: install specific task only
# ---------------------------------------------------------------------------


class TestInstallSpecificTaskOnly:
    """Install a specific task name, verify only that task's units are generated."""

    def test_only_specified_task_unit_files(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
                "sync": {"schedule": "*/5 * * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
        try:
            runner = CliRunner()
            result = runner.invoke(cli, ["install", "backup", "--output-dir", str(output_dir)])
            assert result.exit_code == 0

            # Only backup units should exist
            assert (output_dir / "docket-backup.service").exists()
            assert (output_dir / "docket-backup.timer").exists()
            # Sync units should NOT exist
            assert not (output_dir / "docket-sync.service").exists()
            assert not (output_dir / "docket-sync.timer").exists()
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_only_specified_task_in_list_json(self, tmp_path: Path) -> None:
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
                "sync": {"schedule": "*/5 * * * *"},
            },
        )
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
        try:
            runner = CliRunner()
            result = runner.invoke(cli, ["--json", "install", "--list", "backup"])
            assert result.exit_code == 0

            data = json.loads(result.output)
            assert "backup" in data
            assert "sync" not in data, "Only the specified task should appear"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_unknown_task_errors(self, tmp_path: Path) -> None:
        """Installing a task that doesn't exist in config should error."""
        cfg_path = _make_config(
            tmp_path,
            {
                "backup": {"schedule": "0 2 * * *"},
            },
        )
        output_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
        try:
            runner = CliRunner()
            result = runner.invoke(cli, ["install", "nonexistent", "--output-dir", str(output_dir)])
            assert result.exit_code != 0
            assert "Unknown task" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_install_specific_task_no_schedule_message(self, tmp_path: Path) -> None:
        """Installing a task that exists but has no schedule should give a message."""
        cfg_path = _make_config(
            tmp_path,
            {
                "cleanup": {"command": "/usr/bin/clean"},
            },
        )
        output_dir = tmp_path / "systemd"
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = cfg_path
        try:
            runner = CliRunner()
            result = runner.invoke(cli, ["install", "cleanup", "--output-dir", str(output_dir)])
            # Should indicate that the task has no schedule
            assert "no schedule" in result.output.lower() or result.exit_code == 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original
