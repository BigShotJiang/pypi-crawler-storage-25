"""Tests for task-specific config schema validation."""

from __future__ import annotations

import pytest

from docket.schema import SchemaError, validate_task_schema


def test_accepts_valid_schema_config() -> None:
    validate_task_schema(
        "vitals",
        {"time_of_day": "morning", "count": 2},
        {
            "time_of_day": {
                "type": "string",
                "required": True,
                "enum": ["morning", "midday", "evening"],
            },
            "count": {"type": "integer"},
        },
    )


def test_rejects_missing_required_key() -> None:
    with pytest.raises(SchemaError, match="missing required"):
        validate_task_schema("vitals", {}, {"time_of_day": {"type": "string", "required": True}})


def test_rejects_wrong_type() -> None:
    with pytest.raises(SchemaError, match="must be string"):
        validate_task_schema("vitals", {"time_of_day": 1}, {"time_of_day": {"type": "string"}})


def test_rejects_unknown_enum_value() -> None:
    with pytest.raises(SchemaError, match="must be one of"):
        validate_task_schema(
            "vitals",
            {"time_of_day": "night"},
            {"time_of_day": {"type": "string", "enum": ["morning", "evening"]}},
        )
