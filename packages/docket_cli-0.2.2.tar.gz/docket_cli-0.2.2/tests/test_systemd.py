"""Tests for docket.systemd — cron converter and unit generation."""

from __future__ import annotations

from pathlib import Path

from docket.systemd import (
    cron_to_systemd,
    generate_service_unit,
    generate_timer_unit,
    get_scheduled_tasks,
    install_units,
)

# ── cron_to_systemd ──────────────────────────────────────────────────────────


class TestCronToSystemd:
    """Tests for the cron_to_systemd converter."""

    def test_every_5_minutes(self) -> None:
        assert cron_to_systemd("*/5 * * * *") == "*:0/5"

    def test_every_6_hours(self) -> None:
        assert cron_to_systemd("0 */6 * * *") == "*:*:0/6"

    def test_daily_at_2am(self) -> None:
        assert cron_to_systemd("0 2 * * *") == "*-*-* 02:00:00"

    def test_weekly_monday(self) -> None:
        assert cron_to_systemd("0 0 * * 1") == "Mon *-*-* 00:00:00"

    def test_monthly(self) -> None:
        assert cron_to_systemd("0 0 1 * *") == "*-*-01 00:00:00"

    def test_every_minute_wildcard(self) -> None:
        assert cron_to_systemd("* * * * *") == "*:*"

    def test_every_1_minute(self) -> None:
        assert cron_to_systemd("*/1 * * * *") == "*:*"

    def test_specific_time_weekly_sunday(self) -> None:
        assert cron_to_systemd("30 3 * * 0") == "Sun *-*-* 03:30:00"

    def test_specific_time_weekly_sunday_alt(self) -> None:
        assert cron_to_systemd("30 3 * * 7") == "Sun *-*-* 03:30:00"

    def test_every_15_minutes(self) -> None:
        assert cron_to_systemd("*/15 * * * *") == "*:0/15"

    def test_every_2_hours(self) -> None:
        assert cron_to_systemd("0 */2 * * *") == "*:*:0/2"

    def test_hourly_on_the_hour(self) -> None:
        assert cron_to_systemd("0 * * * *") == "*-*-* *:00:00"

    def test_fallback_unparseable(self) -> None:
        assert cron_to_systemd("weird") == "weird"

    def test_fallback_too_few_fields(self) -> None:
        assert cron_to_systemd("* * *") == "* * *"

    def test_specific_hour_minute_with_padding(self) -> None:
        # Hours < 10 should be zero-padded
        assert cron_to_systemd("5 9 * * *") == "*-*-* 09:05:00"


# ── Unit generation ──────────────────────────────────────────────────────────


class TestGenerateServiceUnit:
    """Tests for service unit file generation."""

    def test_basic_service(self) -> None:
        content = generate_service_unit("backup", {"schedule": "0 2 * * *"})
        assert "[Unit]" in content
        assert "Description=Docket task: backup" in content
        assert "Type=oneshot" in content
        assert "ExecStart=docket run backup" in content
        assert "WantedBy=multi-user.target" in content

    def test_custom_description(self) -> None:
        content = generate_service_unit(
            "backup",
            {"schedule": "0 2 * * *", "description": "My backup job"},
        )
        assert "Description=My backup job" in content

    def test_custom_docket_bin(self) -> None:
        content = generate_service_unit(
            "backup",
            {"schedule": "0 2 * * *", "docket_bin": "/usr/local/bin/docket"},
        )
        assert "ExecStart=/usr/local/bin/docket run backup" in content


class TestGenerateTimerUnit:
    """Tests for timer unit file generation."""

    def test_basic_timer(self) -> None:
        content = generate_timer_unit("backup", {"schedule": "0 2 * * *"})
        assert "[Unit]" in content
        assert "Description=Docket timer for: backup" in content
        assert "OnCalendar=*-*-* 02:00:00" in content
        assert "Persistent=true" in content
        assert "WantedBy=timers.target" in content

    def test_timer_with_interval(self) -> None:
        content = generate_timer_unit("sync", {"schedule": "*/5 * * * *"})
        assert "OnCalendar=*:0/5" in content

    def test_timer_custom_description(self) -> None:
        content = generate_timer_unit(
            "backup",
            {"schedule": "0 2 * * *", "description": "Daily backup timer"},
        )
        assert "Description=Daily backup timer" in content


# ── install_units ────────────────────────────────────────────────────────────


class TestInstallUnits:
    """Tests for writing unit files to disk."""

    def test_writes_service_and_timer(self, tmp_path: Path) -> None:
        result = install_units("backup", {"schedule": "0 2 * * *"}, output_dir=tmp_path)
        assert len(result) == 2
        service_path, timer_path = sorted(result, key=lambda p: p.suffix)
        assert service_path.name == "docket-backup.service"
        assert timer_path.name == "docket-backup.timer"
        assert service_path.exists()
        assert timer_path.exists()

    def test_service_content_on_disk(self, tmp_path: Path) -> None:
        install_units("backup", {"schedule": "0 2 * * *"}, output_dir=tmp_path)
        content = (tmp_path / "docket-backup.service").read_text()
        assert "ExecStart=docket run backup" in content

    def test_timer_content_on_disk(self, tmp_path: Path) -> None:
        install_units("backup", {"schedule": "0 2 * * *"}, output_dir=tmp_path)
        content = (tmp_path / "docket-backup.timer").read_text()
        assert "OnCalendar=*-*-* 02:00:00" in content
        assert "Persistent=true" in content

    def test_skips_tasks_without_schedule(self, tmp_path: Path) -> None:
        result = install_units("backup", {"source": "/data"}, output_dir=tmp_path)
        assert result == []

    def test_creates_output_dir(self, tmp_path: Path) -> None:
        nested = tmp_path / "deep" / "dir"
        result = install_units("backup", {"schedule": "0 2 * * *"}, output_dir=nested)
        assert len(result) == 2
        assert nested.exists()


# ── get_scheduled_tasks ──────────────────────────────────────────────────────


class TestGetScheduledTasks:
    """Tests for extracting scheduled tasks from config."""

    def test_returns_only_scheduled(self) -> None:
        config = {
            "tasks": {
                "backup": {"schedule": "0 2 * * *"},
                "health": {"checks": ["disk"]},
                "sync": {"schedule": "*/5 * * * *"},
            }
        }
        result = get_scheduled_tasks(config)
        assert "backup" in result
        assert "sync" in result
        assert "health" not in result

    def test_empty_tasks(self) -> None:
        config = {"tasks": {}}
        result = get_scheduled_tasks(config)
        assert result == {}

    def test_no_tasks_key(self) -> None:
        config = {}
        result = get_scheduled_tasks(config)
        assert result == {}

    def test_tasks_not_dict(self) -> None:
        config = {"tasks": "not a dict"}
        result = get_scheduled_tasks(config)
        assert result == {}
