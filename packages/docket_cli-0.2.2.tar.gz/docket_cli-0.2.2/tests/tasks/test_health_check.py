"""Tests for built-in health-check task."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from docket.tasks.health_check import HealthCheckTask


class TestHealthCheckTask:
    def test_name_and_description(self) -> None:
        task = HealthCheckTask()
        assert task.name == "health-check"
        assert "health" in task.description.lower()

    def test_dry_run_reports_would_run(self) -> None:
        task = HealthCheckTask()
        result = task.dry_run({"checks": ["disk", "memory"]})
        assert result.ok
        assert result.dry_run
        assert "Would" in result.summary or "would" in result.summary

    def test_invalid_checks_list_type(self) -> None:
        task = HealthCheckTask()
        result = task.run({"checks": "disk"})
        assert not result.ok
        assert "list" in result.summary.lower() or "Invalid" in result.summary

    def test_unknown_check_name(self) -> None:
        task = HealthCheckTask()
        result = task.run({"checks": ["nonexistent"]})
        assert not result.ok
        assert "Unknown" in result.summary

    @patch("docket.tasks.health_check.shutil.disk_usage")
    def test_disk_check_under_threshold(self, mock_usage: MagicMock) -> None:
        # Simulate 50% disk usage.
        mock_usage.return_value = MagicMock(total=100, used=50, free=50)
        task = HealthCheckTask()
        result = task.run({"checks": ["disk"], "disk_threshold_pct": 90})
        assert result.ok
        assert result.details["disk"]["ok"] is True
        assert result.details["disk"]["used_pct"] == 50

    @patch("docket.tasks.health_check.shutil.disk_usage")
    def test_disk_check_over_threshold(self, mock_usage: MagicMock) -> None:
        # Simulate 95% disk usage.
        mock_usage.return_value = MagicMock(total=100, used=95, free=5)
        task = HealthCheckTask()
        result = task.run({"checks": ["disk"], "disk_threshold_pct": 90})
        assert not result.ok
        assert result.details["disk"]["ok"] is False
        assert result.details["disk"]["used_pct"] == 95

    def test_disk_check_oserror(self) -> None:
        task = HealthCheckTask()
        with patch("docket.tasks.health_check.shutil.disk_usage", side_effect=OSError("no disk")):
            result = task.run({"checks": ["disk"]})
            assert not result.ok
            assert "disk" in result.details

    @patch("docket.tasks.health_check.shutil.disk_usage")
    def test_memory_check_procfs_fallback(self, mock_usage: MagicMock) -> None:
        """Test that the health-check at least doesn't crash on memory checks."""
        mock_usage.return_value = MagicMock(total=100, used=50, free=50)
        task = HealthCheckTask()
        # Just run disk check to avoid needing /proc/meminfo or free.
        result = task.run({"checks": ["disk"]})
        assert result.ok

    def test_multiple_checks_one_fails(self) -> None:
        task = HealthCheckTask()
        with patch("docket.tasks.health_check.shutil.disk_usage") as mock_disk:
            mock_disk.return_value = MagicMock(total=100, used=5, free=95)
            with patch(
                "docket.tasks.health_check.HealthCheckTask._check_memory",
                return_value={"ok": False, "used_pct": 95, "threshold": 90},
            ):
                result = task.run({"checks": ["disk", "memory"]})
                assert not result.ok
                assert "memory" in result.summary

    def test_systemd_units_check_no_systemctl(self) -> None:
        task = HealthCheckTask()
        with patch("docket.tasks.health_check.shutil.which", return_value=None):
            result = task.run({"checks": ["systemd-units"]})
            assert result.ok  # Skip gracefully.

    @patch("docket.tasks.health_check.shutil.which", return_value="/usr/bin/systemctl")
    @patch("docket.tasks.health_check.subprocess.run")
    def test_systemd_units_all_active(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = MagicMock(stdout="active", returncode=0)
        task = HealthCheckTask()
        result = task.run(
            {
                "checks": ["systemd-units"],
                "systemd_units": ["sshd", "nginx"],
            }
        )
        assert result.ok
        assert result.details["systemd-units"]["ok"] is True

    @patch("docket.tasks.health_check.shutil.which", return_value="/usr/bin/systemctl")
    @patch("docket.tasks.health_check.subprocess.run")
    def test_systemd_units_one_failed(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.side_effect = [
            MagicMock(stdout="active", returncode=0),
            MagicMock(stdout="failed", returncode=3),
        ]
        task = HealthCheckTask()
        result = task.run(
            {
                "checks": ["systemd-units"],
                "systemd_units": ["sshd", "broken-service"],
            }
        )
        assert not result.ok
        assert "broken-service" in result.details["systemd-units"]["failed_units"]

    def test_empty_checks_list_defaults(self) -> None:
        """Default checks (disk, memory) should work."""
        task = HealthCheckTask()
        with patch("docket.tasks.health_check.shutil.disk_usage") as mock_disk:
            mock_disk.return_value = MagicMock(total=100, used=50, free=50)
            # We can't fully test memory without a real system, so test with disk only.
            result = task.run({"checks": ["disk"]})
            assert result.ok
