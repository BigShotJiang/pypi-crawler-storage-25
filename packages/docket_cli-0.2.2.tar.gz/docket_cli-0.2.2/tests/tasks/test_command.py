"""Tests for generic command tasks."""

from __future__ import annotations

import sys
from pathlib import Path

from docket.state import StateStore
from docket.tasks.command import CommandTask


class TestCommandTask:
    def test_run_parses_json_stdout(self) -> None:
        task = CommandTask()
        result = task.run(
            {
                "command": sys.executable,
                "args": [
                    "-c",
                    "import json; print(json.dumps({'records': 3, 'ok': True}))",
                ],
                "output_format": "json",
            }
        )
        assert result.ok
        assert result.details["json"] == {"records": 3, "ok": True}
        assert result.details["exit_code"] == 0

    def test_run_parses_jsonl_stdout(self) -> None:
        task = CommandTask()
        result = task.run(
            {
                "command": sys.executable,
                "args": [
                    "-c",
                    "print('{\"event\":\"start\"}'); print('{\"event\":\"done\",\"count\":2}')",
                ],
                "output_format": "jsonl",
            }
        )
        assert result.ok
        assert result.details["event_count"] == 2
        assert result.details["last_event"] == {"event": "done", "count": 2}

    def test_dry_run_without_dry_run_args_previews_only(self) -> None:
        task = CommandTask()
        result = task.dry_run({"command": "dangerous-binary", "args": ["--write"]})
        assert result.ok
        assert result.dry_run
        assert result.details["dry_run_supported"] is False
        assert result.details["command"] == ["dangerous-binary", "--write"]

    def test_dry_run_with_dry_run_args_executes_safe_preview(self) -> None:
        task = CommandTask()
        result = task.dry_run(
            {
                "command": sys.executable,
                "dry_run_args": ["-c", "print('{\"would_write\": true}')"],
                "output_format": "json",
            }
        )
        assert result.ok
        assert result.dry_run
        assert result.details["json"] == {"would_write": True}

    def test_missing_required_env_fails_before_execution(self) -> None:
        task = CommandTask()
        result = task.run(
            {
                "command": sys.executable,
                "args": ["-c", "print('nope')"],
                "required_env": ["DOCKET_TEST_MISSING_ENV"],
            }
        )
        assert not result.ok
        assert result.details["missing_env"] == ["DOCKET_TEST_MISSING_ENV"]

    def test_jsonl_streams_live_events(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        state_path = tmp_path / "state.db"
        with StateStore(state_path) as state:
            run = state.start_run("stream-task")

        monkeypatch.setenv("DOCKET_RUN_ID", run["run_id"])
        monkeypatch.setenv("DOCKET_STATE_PATH", str(state_path))
        task = CommandTask()
        result = task.run(
            {
                "command": sys.executable,
                "args": [
                    "-c",
                    (
                        "import sys, time; "
                        "print('{\"event\":\"start\"}', flush=True); "
                        "time.sleep(0.1); "
                        "print('{\"event\":\"done\"}', flush=True)"
                    ),
                ],
                "output_format": "jsonl",
            }
        )

        assert result.ok
        with StateStore(state_path) as state:
            events = state.list_events(run["run_id"])
        assert [event["event_type"] for event in events] == ["start", "done"]
