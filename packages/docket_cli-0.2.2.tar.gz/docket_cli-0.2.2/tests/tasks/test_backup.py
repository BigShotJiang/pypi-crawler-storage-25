"""Tests for built-in backup task."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from docket.tasks.backup import BackupTask, CommandResult, _idle_timeout, _run_command


class TestBackupTask:
    def test_name_and_description(self) -> None:
        task = BackupTask()
        assert task.name == "backup"
        assert "rclone" in task.description.lower() or "rsync" in task.description.lower()

    def test_dry_run_with_unknown_tool(self) -> None:
        task = BackupTask()
        result = task.dry_run({"tool": "tar", "source": "/a", "remote": "/b"})
        assert not result.ok
        assert result.dry_run

    def test_run_with_unknown_tool(self) -> None:
        task = BackupTask()
        result = task.run({"tool": "tar", "source": "/a", "remote": "/b"})
        assert not result.ok
        assert not result.dry_run

    def test_dry_run_returns_dry_run_result(self) -> None:
        task = BackupTask()
        # rclone not installed in test env, so it will fail with "not found".
        result = task.dry_run({})
        assert result.dry_run

    def test_rclone_not_found_dry_run(self) -> None:
        task = BackupTask()
        with patch("docket.tasks.backup.shutil.which", return_value=None):
            result = task.dry_run({"tool": "rclone"})
        assert not result.ok
        assert "rclone" in result.summary.lower() or "not found" in result.summary.lower()
        assert result.dry_run

    def test_rclone_not_found_run(self) -> None:
        task = BackupTask()
        with patch("docket.tasks.backup.shutil.which", return_value=None):
            result = task.run({"tool": "rclone"})
        assert not result.ok
        assert not result.dry_run

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_rclone_success(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="")
        task = BackupTask()
        result = task.run({"tool": "rclone", "source": "/src", "remote": "remote:dst"})
        assert result.ok
        assert "rclone" in result.summary
        assert not result.dry_run
        # Verify command includes sync and the paths.
        cmd = mock_run.call_args[0][0]
        assert "sync" in cmd
        assert "/src" in cmd
        assert "remote:dst" in cmd
        assert mock_run.call_args.kwargs["idle_timeout"] == 1800.0

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_rclone_dry_run_flag(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="")
        task = BackupTask()
        result = task.dry_run({"tool": "rclone", "source": "/src", "remote": "remote:dst"})
        assert result.ok
        assert result.dry_run
        cmd = mock_run.call_args[0][0]
        assert "--dry-run" in cmd
        assert "Would" in result.summary

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_rclone_failure(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=1, stdout="", stderr="error msg")
        task = BackupTask()
        result = task.run({"tool": "rclone", "source": "/src", "remote": "remote:dst"})
        assert not result.ok
        assert "exit 1" in result.summary

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rsync")
    @patch("docket.tasks.backup._run_command")
    def test_rsync_success(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="")
        task = BackupTask()
        result = task.run({"tool": "rsync", "source": "/src", "remote": "/dst"})
        assert result.ok
        cmd = mock_run.call_args[0][0]
        assert "rsync" in cmd
        assert "-avz" in cmd

    @patch("docket.tasks.backup.shutil.which", return_value=None)
    def test_rsync_not_found(self, mock_which: MagicMock) -> None:
        task = BackupTask()
        result = task.run({"tool": "rsync"})
        assert not result.ok
        assert "rsync" in result.summary.lower() or "not found" in result.summary.lower()

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_extra_args_passed(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="")
        task = BackupTask()
        task.run(
            {
                "tool": "rclone",
                "source": "/src",
                "remote": "remote:dst",
                "extra_args": ["--verbose", "--transfers", "4"],
            }
        )
        cmd = mock_run.call_args[0][0]
        assert "--verbose" in cmd
        assert "--transfers" in cmd

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.backup._run_command")
    def test_hbackup_success(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(
            returncode=0,
            stdout="",
            stderr=(
                "Found 12 files to back up\n"
                "Backup complete: /tmp/agent.tar.zst (12 files, 1.5 MB)\n"
            ),
        )
        task = BackupTask()
        result = task.run(
            {
                "tool": "hbackup",
                "output": "/tmp/agent.tar.zst",
                "excludes": ["target", ".git"],
            }
        )
        assert result.ok
        assert result.details["backend"] == "hbackup"
        assert result.details["archive_path"] == "/tmp/agent.tar.zst"
        assert result.details["file_count"] == 12
        cmd = mock_run.call_args[0][0]
        assert cmd[:2] == ["hbackup", "backup"]
        assert "--output" in cmd
        assert "--exclude" in cmd
        assert "target" in cmd
        assert ".git" in cmd

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.backup._run_command")
    def test_hbackup_dry_run_uses_backup_command(
        self, mock_run: MagicMock, mock_which: MagicMock
    ) -> None:
        mock_run.return_value = CommandResult(
            returncode=0,
            stdout="/home/user/.openclaw/config.yaml\n",
            stderr="Found 1 files to back up\nDry run: 1 files would be archived\n",
        )
        task = BackupTask()
        result = task.dry_run({"tool": "hbackup", "hbackup_command": "auto"})
        assert result.ok
        assert result.dry_run
        assert result.details["file_count"] == 1
        assert mock_run.call_args[0][0] == ["hbackup", "backup", "--dry-run"]

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.backup._run_command")
    def test_hbackup_auto_command(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="Upload complete.\n")
        task = BackupTask()
        result = task.run({"tool": "hbackup", "hbackup_command": "auto"})
        assert result.ok
        assert mock_run.call_args[0][0] == ["hbackup", "auto"]

    @patch("docket.tasks.backup.shutil.which", return_value=None)
    def test_hbackup_not_found(self, mock_which: MagicMock) -> None:
        task = BackupTask()
        result = task.run({"tool": "hbackup"})
        assert not result.ok
        assert "hbackup" in result.summary.lower()

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_idle_timeout_passed_from_config(
        self, mock_run: MagicMock, mock_which: MagicMock
    ) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="")
        task = BackupTask()
        task.run(
            {
                "tool": "rclone",
                "source": "/src",
                "remote": "remote:dst",
                "idle_timeout_seconds": 12,
            }
        )
        assert mock_run.call_args.kwargs["idle_timeout"] == 12.0

    @patch("docket.tasks.backup.shutil.which", return_value="/usr/bin/rclone")
    @patch("docket.tasks.backup._run_command")
    def test_idle_timeout_result(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(
            returncode=-9,
            stdout="started\n",
            stderr="",
            timed_out=True,
        )
        task = BackupTask()
        result = task.run(
            {
                "tool": "rclone",
                "source": "/src",
                "remote": "remote:dst",
                "idle_timeout_seconds": 3,
            }
        )
        assert not result.ok
        assert "timed out" in result.summary
        assert result.details["timed_out"] is True
        assert result.details["idle_timeout_seconds"] == 3.0


class TestBackupIdleTimeout:
    def test_idle_timeout_default(self) -> None:
        assert _idle_timeout({}) == 1800.0

    def test_idle_timeout_can_be_disabled(self) -> None:
        assert _idle_timeout({"idle_timeout_seconds": 0}) is None
        assert _idle_timeout({"idle_timeout_seconds": None}) is None

    def test_run_command_without_idle_timeout_uses_subprocess_run(self) -> None:
        with patch("docket.tasks.backup.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
            result = _run_command(["echo", "ok"], idle_timeout=None)
        assert result.returncode == 0
        assert result.stdout == "ok"
        assert not result.timed_out
