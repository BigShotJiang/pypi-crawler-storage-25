"""Tests for first-class hbackup task."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from docket.tasks.backup import CommandResult
from docket.tasks.hbackup import HBackupTask


class TestHBackupTask:
    @patch("docket.tasks.hbackup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.hbackup._run_command")
    def test_backup_success(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(
            returncode=0,
            stdout="",
            stderr=(
                "Found 12 files to back up\n"
                "Backup complete: /tmp/agent.tar.zst (12 files, 1.5 MB)\n"
            ),
        )
        task = HBackupTask()

        result = task.run(
            {
                "output": "/tmp/agent.tar.zst",
                "excludes": ["target", ".git"],
            }
        )

        assert result.ok
        assert result.details["backend"] == "hbackup"
        assert result.details["action"] == "backup"
        assert result.details["archive_path"] == "/tmp/agent.tar.zst"
        assert result.details["file_count"] == 12
        assert mock_run.call_args[0][0] == [
            "hbackup",
            "backup",
            "--output",
            "/tmp/agent.tar.zst",
            "--exclude",
            "target",
            "--exclude",
            ".git",
        ]

    @patch("docket.tasks.hbackup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.hbackup._run_command")
    def test_auto_dry_run_uses_backup_dry_run(
        self, mock_run: MagicMock, mock_which: MagicMock
    ) -> None:
        mock_run.return_value = CommandResult(
            returncode=0,
            stdout="/home/user/.openclaw/config.yaml\n",
            stderr="Found 1 files to back up\nDry run: 1 files would be archived\n",
        )
        task = HBackupTask()

        result = task.dry_run({"action": "auto"})

        assert result.ok
        assert result.dry_run
        assert result.details["action"] == "auto"
        assert result.details["effective_action"] == "backup"
        assert mock_run.call_args[0][0] == ["hbackup", "backup", "--dry-run"]

    @patch("docket.tasks.hbackup.shutil.which", return_value="/usr/bin/hbackup")
    @patch("docket.tasks.hbackup._run_command")
    def test_auto_run(self, mock_run: MagicMock, mock_which: MagicMock) -> None:
        mock_run.return_value = CommandResult(returncode=0, stdout="", stderr="Upload complete.\n")
        task = HBackupTask()

        result = task.run({"action": "auto"})

        assert result.ok
        assert result.details["action"] == "auto"
        assert mock_run.call_args[0][0] == ["hbackup", "auto"]

    @patch("docket.tasks.hbackup.shutil.which", return_value="/usr/bin/hbackup")
    def test_upload_dry_run_previews_without_execution(self, mock_which: MagicMock) -> None:
        task = HBackupTask()

        result = task.dry_run(
            {
                "action": "upload",
                "archive": "/tmp/agent.tar.zst",
                "drive": True,
                "drive_remote": "gdrive",
                "drive_folder": "backups/hermes",
            }
        )

        assert result.ok
        assert result.dry_run
        assert result.details["dry_run_supported"] is False
        assert result.details["command"] == [
            "hbackup",
            "upload",
            "--drive",
            "--drive-remote",
            "gdrive",
            "--drive-folder",
            "backups/hermes",
            "/tmp/agent.tar.zst",
        ]

    @patch("docket.tasks.hbackup.shutil.which", return_value=None)
    def test_hbackup_not_found(self, mock_which: MagicMock) -> None:
        task = HBackupTask()
        result = task.run({})
        assert not result.ok
        assert "hbackup" in result.summary.lower()
