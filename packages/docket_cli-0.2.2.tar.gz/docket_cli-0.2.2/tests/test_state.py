"""Tests for docket.state — SQLite state store."""

from __future__ import annotations

from pathlib import Path

from docket.state import StateStore


class TestStateStore:
    def test_record_and_get(self, state_path: Path) -> None:
        store = StateStore(state_path)
        run = store.record("backup", exit_code=0, summary="success", details={"files": 3})
        assert run["run_id"]
        assert run["status"] == "succeeded"
        assert run["duration_seconds"] is not None
        rec = store.get("backup")
        assert rec is not None
        assert rec["task_name"] == "backup"
        assert rec["run_id"] == run["run_id"]
        assert rec["exit_code"] == 0
        assert rec["summary"] == "success"
        assert rec["details"] == {"files": 3}
        assert not rec["dry_run"]
        store.close()

    def test_record_dry_run(self, state_path: Path) -> None:
        store = StateStore(state_path)
        store.record("backup", exit_code=2, summary="would backup", dry_run=True)
        rec = store.get("backup")
        assert rec is not None
        assert rec["dry_run"] is True
        assert rec["exit_code"] == 2
        store.close()

    def test_record_upserts(self, state_path: Path) -> None:
        store = StateStore(state_path)
        first = store.record("backup", exit_code=0, summary="first run")
        second = store.record("backup", exit_code=1, summary="second run")
        rec = store.get("backup")
        assert rec is not None
        assert rec["summary"] == "second run"
        assert rec["exit_code"] == 1
        assert rec["run_id"] == second["run_id"]
        assert first["run_id"] != second["run_id"]
        store.close()

    def test_get_missing_task(self, state_path: Path) -> None:
        store = StateStore(state_path)
        assert store.get("nonexistent") is None
        store.close()

    def test_list_all(self, state_path: Path) -> None:
        store = StateStore(state_path)
        store.record("backup", exit_code=0, summary="ok")
        store.record("health-check", exit_code=0, summary="healthy")
        records = store.list_all()
        assert len(records) == 2
        names = {r["task_name"] for r in records}
        assert "backup" in names
        assert "health-check" in names
        store.close()

    def test_list_all_empty(self, state_path: Path) -> None:
        store = StateStore(state_path)
        assert store.list_all() == []
        store.close()

    def test_delete(self, state_path: Path) -> None:
        store = StateStore(state_path)
        store.record("backup", exit_code=0, summary="ok")
        assert store.delete("backup") is True
        assert store.get("backup") is None
        store.close()

    def test_delete_missing(self, state_path: Path) -> None:
        store = StateStore(state_path)
        assert store.delete("nonexistent") is False
        store.close()

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        db_path = tmp_path / "nested" / "dir" / "state.db"
        store = StateStore(db_path)
        store.record("test", exit_code=0, summary="created dirs")
        rec = store.get("test")
        assert rec is not None
        store.close()

    def test_record_with_details(self, state_path: Path) -> None:
        store = StateStore(state_path)
        details = {"duration_s": 42.5, "files_synced": 100}
        store.record("backup", exit_code=0, summary="synced", details=details)
        rec = store.get("backup")
        assert rec is not None
        assert rec["details"]["duration_s"] == 42.5
        assert rec["details"]["files_synced"] == 100
        store.close()

    def test_last_run_is_iso_format(self, state_path: Path) -> None:
        from datetime import datetime

        store = StateStore(state_path)
        store.record("backup", exit_code=0, summary="ok")
        rec = store.get("backup")
        assert rec is not None
        # Should parse as a valid datetime.
        dt = datetime.fromisoformat(rec["last_run"])
        assert dt.tzinfo is not None
        store.close()

    def test_record_keeps_history(self, state_path: Path) -> None:
        store = StateStore(state_path)
        first = store.record("backup", exit_code=0, summary="first")
        second = store.record("backup", exit_code=1, summary="second")

        runs = store.list_runs("backup")
        assert len(runs) == 2
        assert {r["run_id"] for r in runs} == {first["run_id"], second["run_id"]}
        assert store.get_run(first["run_id"]) == first
        store.close()

    def test_duration_stats(self, state_path: Path) -> None:
        store = StateStore(state_path)
        store.record(
            "backup",
            exit_code=0,
            summary="one",
            started_at="2026-01-01T00:00:00+00:00",
            finished_at="2026-01-01T00:00:10+00:00",
        )
        store.record(
            "backup",
            exit_code=0,
            summary="two",
            started_at="2026-01-01T00:00:00+00:00",
            finished_at="2026-01-01T00:00:20+00:00",
        )

        stats = store.duration_stats("backup")
        assert stats["sample_size"] == 2
        assert stats["median_seconds"] == 15.0
        assert stats["p90_seconds"] == 19.0
        store.close()

    def test_start_update_complete_run(self, state_path: Path) -> None:
        store = StateStore(state_path)
        started = store.start_run("backup", dry_run=False)
        assert started["status"] == "running"
        assert started["finished_at"] is None
        assert started["exit_code"] is None

        updated = store.update_run(
            started["run_id"],
            summary="running in background",
            details={"pid": 123},
        )
        assert updated["summary"] == "running in background"
        assert updated["details"] == {"pid": 123}

        completed = store.complete_run(
            started["run_id"],
            exit_code=0,
            summary="done",
            details={"files": 1},
        )
        assert completed["run_id"] == started["run_id"]
        assert completed["status"] == "succeeded"
        assert completed["summary"] == "done"
        assert completed["details"] == {"pid": 123, "files": 1}
        assert completed["duration_seconds"] is not None

        latest = store.get("backup")
        assert latest is not None
        assert latest["run_id"] == started["run_id"]
        store.close()

    def test_add_and_list_events(self, state_path: Path) -> None:
        store = StateStore(state_path)
        run = store.record("fetch-data", exit_code=0, summary="done")

        events = store.add_events(
            run["run_id"],
            [
                {"event": "start", "count": 0},
                {"event": "done", "count": 2},
            ],
        )

        assert [event["event_index"] for event in events] == [1, 2]
        assert events[0]["event_type"] == "start"
        assert events[1]["event"] == {"event": "done", "count": 2}
        assert store.list_events(run["run_id"]) == events
        store.close()

    def test_add_events_replace(self, state_path: Path) -> None:
        store = StateStore(state_path)
        run = store.record("fetch-data", exit_code=0, summary="done")

        store.add_events(run["run_id"], [{"event": "old"}])
        events = store.add_events(run["run_id"], [{"event": "new"}], replace=True)

        assert len(events) == 1
        assert events[0]["event_index"] == 1
        assert events[0]["event_type"] == "new"
        store.close()
