"""Tests for docket.cli — Click CLI commands."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml
from click.testing import CliRunner

from docket.cli import cli
from docket.state import StateStore


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def docket_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Set up a temporary DOCKET_HOME directory with config."""
    home = tmp_path / ".docket"
    home.mkdir()
    tasks_dir = home / "tasks"
    tasks_dir.mkdir()

    config = {
        "state_dir": str(home / "state.db"),
        "tasks_dir": str(tasks_dir),
        "logs_dir": str(home / "logs"),
        "tasks": {},
    }
    (home / "config.yaml").write_text(yaml.dump(config))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    return home


class TestCLIHelp:
    def test_root_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "docket" in result.output.lower()

    def test_version(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.2.2" in result.output


class TestListCommand:
    def test_lists_tasks(self, runner: CliRunner, docket_home: Path) -> None:
        # Need to set the config path for load_config.
        config_path = docket_home / "config.yaml"
        # Patch DEFAULT_CONFIG_PATH in config module.
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["list"])
            # May or may not find tasks depending on entry points.
            assert result.exit_code == 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_list_json_mode(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "list"])
            assert result.exit_code == 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestStatusCommand:
    def test_status_no_runs(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["status"])
            assert result.exit_code == 0
            assert "No tasks" in result.output or "[]" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_status_json_no_runs(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "status"])
            assert result.exit_code == 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestCapabilitiesCommand:
    def test_capabilities_json_includes_commands_and_tasks(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "capabilities"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["tool"] == "docket"
            assert payload["agent_contract_version"] == 1
            assert any(command["name"] == "new-task" for command in payload["commands"])
            task_names = {task["name"] for task in payload["tasks"]}
            assert "backup" in task_names
            assert "hbackup" in task_names
            assert "health-check" in task_names
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_capabilities_includes_configured_command_task(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["echo-json"] = {
            "type": "command",
            "description": "Emit JSON for agents",
            "agent_notes": "Safe to run repeatedly.",
            "command": sys.executable,
            "args": ["-c", "print('{\"count\": 2}')"],
            "output_format": "json",
            "inputs": {"command": "Python executable"},
            "outputs": {"json": "Parsed JSON result"},
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "capabilities"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            tasks = {task["name"]: task for task in payload["tasks"]}
            assert tasks["echo-json"]["description"] == "Emit JSON for agents"
            assert tasks["echo-json"]["agent_notes"] == "Safe to run repeatedly."
            assert tasks["echo-json"]["outputs"] == {"json": "Parsed JSON result"}
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_describe_json_includes_agent_notes(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["echo-json"] = {
            "type": "command",
            "description": "Emit JSON for agents",
            "agent_notes": "Requires network; safe to retry.",
            "command": sys.executable,
            "args": ["-c", "print('{\"count\": 2}')"],
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "describe", "echo-json"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["agent_notes"] == "Requires network; safe to retry."
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_run_configured_command_task_returns_parsed_json(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["echo-json"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", "print('{\"count\": 2}')"],
            "output_format": "json",
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "run", "--force", "echo-json"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["details"]["json"] == {"count": 2}
            assert payload["task"] == "echo-json"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_command_task_jsonl_populates_events_command(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["emit-events"] = {
            "type": "command",
            "command": sys.executable,
            "args": [
                "-c",
                "print('{\"event\":\"start\"}'); print('{\"event\":\"done\",\"count\":2}')",
            ],
            "output_format": "jsonl",
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "run", "--force", "emit-events"])
            assert result.exit_code == 0, result.output
            run_id = json.loads(result.output)["run_id"]

            events_result = runner.invoke(cli, ["--json", "events", run_id])
            assert events_result.exit_code == 0, events_result.output
            events = json.loads(events_result.output)
            assert [event["event_type"] for event in events] == ["start", "done"]
            assert events[-1]["event"] == {"event": "done", "count": 2}
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_events_follow_rejects_json_mode(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "events", run["run_id"], "--follow"])
            assert result.exit_code != 0
            assert "cannot be combined" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_events_follow_completed_run_outputs_events(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.record("emit-events", exit_code=0, summary="done")
            state.add_events(run["run_id"], [{"event": "done", "count": 2}])

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["events", run["run_id"], "--follow"])
            assert result.exit_code == 0
            assert "done" in result.output
            assert "count" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestHealthCommand:
    def test_health_json_classifies_tasks(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["ok-task"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", "print('ok')"],
        }
        config["tasks"]["degraded-task"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", "print('ok')"],
        }
        config["tasks"]["failed-task"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", "raise SystemExit(1)"],
        }
        config["tasks"]["stale-task"] = {
            "type": "command",
            "command": sys.executable,
            "schedule": "0 2 * * *",
        }
        config["tasks"]["never-task"] = {
            "type": "command",
            "command": sys.executable,
        }
        config_path.write_text(yaml.dump(config))

        with StateStore(docket_home / "state.db") as state:
            state.record("ok-task", exit_code=0, summary="ok")
            state.record(
                "degraded-task",
                exit_code=1,
                summary="older failure",
                started_at="2026-01-01T00:00:00+00:00",
                finished_at="2026-01-01T00:00:01+00:00",
            )
            state.record(
                "degraded-task",
                exit_code=0,
                summary="latest success",
                started_at="2026-01-02T00:00:00+00:00",
                finished_at="2026-01-02T00:00:01+00:00",
            )
            state.record("failed-task", exit_code=1, summary="failed")
            state.record(
                "stale-task",
                exit_code=0,
                summary="old success",
                started_at="2026-01-01T00:00:00+00:00",
                finished_at="2026-01-01T00:00:01+00:00",
            )

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "health"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert "ok-task" in payload["healthy"]
            assert "degraded-task" in payload["degraded"]
            assert "failed-task" in payload["failed"]
            assert "stale-task" in payload["stale"]
            assert "never-task" in payload["never_run"]
            assert payload["details"]["failed-task"]["consecutive_failures"] == 1
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestDependencyChaining:
    def test_run_executes_dependencies_first(
        self, runner: CliRunner, docket_home: Path, tmp_path: Path
    ) -> None:
        import docket.config as cfg_mod

        marker = tmp_path / "dependency-ran"
        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["prepare-data"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", f"from pathlib import Path; Path({str(marker)!r}).write_text('ok')"],
        }
        config["tasks"]["process-data"] = {
            "type": "command",
            "command": sys.executable,
            "args": [
                "-c",
                (
                    f"from pathlib import Path; "
                    f"raise SystemExit(0 if Path({str(marker)!r}).exists() else 1)"
                ),
            ],
            "depends_on": ["prepare-data"],
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "run", "--force", "process-data"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["status"] == "succeeded"
            assert marker.exists()
            with StateStore(docket_home / "state.db") as state:
                assert state.get("prepare-data") is not None
                assert state.get("process-data") is not None
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_run_skips_when_dependency_fails(
        self, runner: CliRunner, docket_home: Path, tmp_path: Path
    ) -> None:
        import docket.config as cfg_mod

        marker = tmp_path / "should-not-exist"
        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["prepare-data"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", "raise SystemExit(1)"],
        }
        config["tasks"]["process-data"] = {
            "type": "command",
            "command": sys.executable,
            "args": ["-c", f"from pathlib import Path; Path({str(marker)!r}).write_text('bad')"],
            "depends_on": ["prepare-data"],
        }
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "run", "--force", "process-data"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["status"] == "skipped"
            assert 'predecessor "prepare-data" failed' in payload["summary"]
            assert not marker.exists()
            with StateStore(docket_home / "state.db") as state:
                rec = state.get_run(payload["run_id"])
                assert rec is not None
                assert rec["status"] == "skipped"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestNewTaskCommand:
    def test_new_task_creates_drop_in_file(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(
                cli,
                ["--json", "new-task", "fetch-invoices", "--description", "Fetch invoices"],
            )
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            task_path = Path(payload["path"])
            assert task_path.exists()
            assert "class FetchInvoicesTask" in task_path.read_text()

            list_result = runner.invoke(cli, ["--json", "capabilities"])
            tasks = {task["name"] for task in json.loads(list_result.output)["tasks"]}
            assert "fetch-invoices" in tasks
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_new_task_rejects_bad_name(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["new-task", "Bad_Name"])
            assert result.exit_code != 0
            assert "Task name" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_invalid_config_returns_click_error(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config_path.write_text(yaml.dump({"tasks": {"backup": {"tool": "tar"}}}))
        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["list"])
            assert result.exit_code != 0
            assert "tool" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_status_by_run_id_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        state_path = docket_home / "state.db"
        with StateStore(state_path) as state:
            run = state.record("backup", exit_code=0, summary="ok")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "status", "--run-id", run["run_id"]])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["run_id"] == run["run_id"]
            assert payload["status"] == "succeeded"
            assert payload["task_name"] == "backup"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestTaskSchemaValidation:
    def test_run_rejects_config_that_does_not_match_task_schema(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        task_file = docket_home / "tasks" / "vitals.py"
        task_file.write_text(
            """
from docket.task import BaseTask, TaskResult


class VitalsTask(BaseTask):
    name = "vitals"
    description = "Vitals"
    schema = {
        "time_of_day": {
            "type": "string",
            "required": True,
            "enum": ["morning", "midday", "evening"],
        }
    }

    def run(self, config):
        return TaskResult(ok=True, summary="ok")

    def dry_run(self, config):
        return TaskResult(ok=True, summary="ok", dry_run=True)
""",
            encoding="utf-8",
        )
        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["vitals"] = {"time_of_day": "night"}
        config_path.write_text(yaml.dump(config))

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["run", "vitals"])
            assert result.exit_code != 0
            assert "time_of_day" in result.output
            assert "must be one of" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestRunsCommand:
    def test_runs_lists_history_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        state_path = docket_home / "state.db"
        with StateStore(state_path) as state:
            first = state.record("backup", exit_code=0, summary="first")
            second = state.record("health-check", exit_code=1, summary="second")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "runs"])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            run_ids = {item["run_id"] for item in payload}
            assert {first["run_id"], second["run_id"]} <= run_ids
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestWaitCommand:
    def test_wait_completed_run_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        state_path = docket_home / "state.db"
        with StateStore(state_path) as state:
            run = state.record("backup", exit_code=0, summary="ok")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "wait", run["run_id"], "--timeout", "0"])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["run_id"] == run["run_id"]
            assert payload["status"] == "succeeded"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_wait_running_run_timeout_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        state_path = docket_home / "state.db"
        with StateStore(state_path) as state:
            run = state.start_run("backup")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(
                cli,
                ["--json", "wait", run["run_id"], "--timeout", "0", "--poll-interval", "0.1"],
            )
            assert result.exit_code == 1
            payload = json.loads(result.output)
            assert payload["status"] == "wait_timeout"
            assert payload["last_seen_status"] == "running"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_wait_missing_run_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "wait", "missing", "--timeout", "0"])
            assert result.exit_code == 1
            assert json.loads(result.output)["status"] == "not_found"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestRunAsync:
    def test_run_async_returns_receipt_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        proc = MagicMock()
        proc.pid = 12345
        try:
            with patch("docket.cli._spawn_async_run", return_value=proc) as spawn:
                result = runner.invoke(
                    cli,
                    ["--json", "run", "--async", "--force", "health-check"],
                )

            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["status"] == "running"
            assert payload["pid"] == 12345
            assert payload["run_id"]
            assert payload["log_path"].endswith(f"{payload['run_id']}.log")
            assert payload["next_check_after_seconds"] == 5
            spawn.assert_called_once()
            assert spawn.call_args.kwargs["log_path"].name == f"{payload['run_id']}.log"

            with StateStore(docket_home / "state.db") as state:
                run = state.get_run(payload["run_id"])
                assert run is not None
                assert run["status"] == "running"
                assert run["details"]["pid"] == 12345
                assert run["details"]["log_path"] == payload["log_path"]
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_runs_filters_by_task(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        state_path = docket_home / "state.db"
        with StateStore(state_path) as state:
            backup = state.record("backup", exit_code=0, summary="first")
            state.record("health-check", exit_code=0, summary="second")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "runs", "backup"])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert [item["run_id"] for item in payload] == [backup["run_id"]]
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestLogsCommand:
    def test_logs_outputs_captured_content(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        log_path = docket_home / "logs" / "run.log"
        log_path.parent.mkdir()
        log_path.write_text("one\ntwo\nthree\n")
        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup", details={"log_path": str(log_path)})

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["logs", run["run_id"], "--tail", "2"])
            assert result.exit_code == 0
            assert result.output == "two\nthree\n"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_logs_json_missing_log(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "logs", run["run_id"]])
            assert result.exit_code == 1
            assert json.loads(result.output)["status"] == "no_log"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_logs_follow_rejects_json_mode(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        log_path = docket_home / "logs" / "run.log"
        log_path.parent.mkdir()
        log_path.write_text("one\n")
        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup", details={"log_path": str(log_path)})

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "logs", run["run_id"], "--follow"])
            assert result.exit_code != 0
            assert "cannot be combined" in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_logs_follow_completed_run_outputs_content(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        log_path = docket_home / "logs" / "run.log"
        log_path.parent.mkdir()
        log_path.write_text("one\ntwo\n")
        with StateStore(docket_home / "state.db") as state:
            run = state.record(
                "backup",
                exit_code=0,
                summary="done",
                details={"log_path": str(log_path)},
            )

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["logs", run["run_id"], "--follow"])
            assert result.exit_code == 0
            assert result.output == "one\ntwo\n"
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestCancelCommand:
    def test_cancel_running_run_json(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup", details={"pid": 12345})

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            with (
                patch("docket.cli._terminate_pid", return_value={"method": "test"}) as terminate,
                patch("docket.cli._wait_for_pid_exit", return_value=True) as wait_for_exit,
            ):
                result = runner.invoke(cli, ["--json", "cancel", run["run_id"]])
            assert result.exit_code == 0
            terminate.assert_called_once_with(12345)
            wait_for_exit.assert_called_once_with(12345)
            payload = json.loads(result.output)
            assert payload["status"] == "cancelled"
            assert payload["exit_code"] == 130
            assert payload["details"]["pid"] == 12345
            assert payload["details"]["cancelled"] is True
            assert payload["details"]["termination"] == {"method": "test"}
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_cancel_running_run_reports_still_running(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.start_run("backup", details={"pid": 12345})

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            with (
                patch("docket.cli._terminate_pid", return_value={"method": "test"}),
                patch("docket.cli._wait_for_pid_exit", return_value=False),
            ):
                result = runner.invoke(cli, ["--json", "cancel", run["run_id"]])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["status"] == "cancel_requested"
            assert payload["cancelled"] is False
            assert payload["details"]["cancel_requested"] is True
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_cancel_completed_run_is_noop(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        with StateStore(docket_home / "state.db") as state:
            run = state.record("backup", exit_code=0, summary="done")

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "cancel", run["run_id"]])
            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["status"] == "succeeded"
            assert payload["cancelled"] is False
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestDescribeCommand:
    def test_describe_unknown_task(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["describe", "no-such-task"])
            assert result.exit_code != 0
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_describe_json_includes_agent_metadata(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "describe", "backup"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["name"] == "backup"
            assert "source" in payload["inputs"]
            assert payload["network"] is True
            assert payload["destructive"] is False
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_describe_hbackup_json_includes_agent_metadata(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["--json", "describe", "hbackup"])
            assert result.exit_code == 0, result.output
            payload = json.loads(result.output)
            assert payload["name"] == "hbackup"
            assert "action" in payload["inputs"]
            assert "archive_path" in payload["outputs"]
            assert payload["network"] is True
            assert payload["destructive"] is False
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original


class TestRunForceSkipsLock:
    """Test that --force skips lock acquisition."""

    def test_force_skips_lock(
        self, runner: CliRunner, docket_home: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"

        # Create a fake lock file to simulate another process holding the lock
        from docket.lockfile import LockFile

        lock = LockFile(task_name="backup")
        lock.path.parent.mkdir(parents=True, exist_ok=True)
        # Write a stale-looking lock with a dead PID so is_locked would return True initially
        # but we'll also hold the lock via fcntl to truly test
        lock.path.write_text("pid=999999999\ntimestamp=2025-01-01T00:00:00\n")

        try:
            # Without --force, the lock check should see stale PID → clean it, then try to acquire
            # But with --force, lock acquisition is skipped entirely
            result = runner.invoke(cli, ["run", "--force", "backup"])
            # Task won't be found (no backup task registered), but the point is
            # we should NOT see a "already running" message
            assert "already running" not in result.output
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_force_flag_available(self, runner: CliRunner) -> None:
        """The --force flag should be accepted by the run command."""
        result = runner.invoke(cli, ["run", "--help"])
        assert result.exit_code == 0
        assert "--force" in result.output


class TestDoctorCommand:
    def test_doctor_runs(self, runner: CliRunner, docket_home: Path) -> None:
        import docket.config as cfg_mod

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = docket_home / "config.yaml"
        try:
            result = runner.invoke(cli, ["doctor"])
            # Doctor will report status even if some checks fail.
            assert result.exit_code in (0, 1)
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original

    def test_doctor_agent_json_reports_operational_checks(
        self, runner: CliRunner, docket_home: Path
    ) -> None:
        import docket.config as cfg_mod

        config_path = docket_home / "config.yaml"
        config = yaml.safe_load(config_path.read_text())
        config["tasks"]["agent-task"] = {
            "type": "command",
            "command": sys.executable,
            "required_env": ["DOCKET_MISSING_TEST_ENV"],
        }
        config_path.write_text(yaml.dump(config))
        with StateStore(docket_home / "state.db") as state:
            for index in range(3):
                state.record(
                    "agent-task",
                    exit_code=1,
                    summary=f"failed {index}",
                    started_at=f"2026-01-0{index + 1}T00:00:00+00:00",
                    finished_at=f"2026-01-0{index + 1}T00:00:01+00:00",
                )

        original = cfg_mod.DEFAULT_CONFIG_PATH
        cfg_mod.DEFAULT_CONFIG_PATH = config_path
        try:
            result = runner.invoke(cli, ["--json", "doctor", "--agent"])
            assert result.exit_code == 1, result.output
            payload = json.loads(result.output)
            checks = {check["name"]: check for check in payload["checks"]}
            assert payload["healthy"] is False
            assert checks["config_valid"]["ok"] is True
            assert checks["state_db_accessible"]["ok"] is True
            assert checks["agent-task:command_exists"]["ok"] is True
            assert checks["agent-task:env:DOCKET_MISSING_TEST_ENV"]["ok"] is False
            assert checks["agent-task:last_3_runs_all_failed"]["ok"] is False
        finally:
            cfg_mod.DEFAULT_CONFIG_PATH = original
