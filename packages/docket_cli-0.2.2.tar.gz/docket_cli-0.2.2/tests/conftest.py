"""Shared test fixtures and helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import yaml


@pytest.fixture
def tmp_dir(tmp_path: Path) -> Path:
    """Return tmp_path — already provided by pytest, alias for clarity."""
    return tmp_path


@pytest.fixture
def config_dir(tmp_path: Path) -> Path:
    """Create and return a temporary Docket config directory."""
    d = tmp_path / ".docket"
    d.mkdir()
    return d


@pytest.fixture
def config_file(config_dir: Path) -> Path:
    """Create a minimal config file and return its path."""
    cfg = config_dir / "config.yaml"
    cfg.write_text(
        yaml.dump(
            {
                "state_dir": str(config_dir / "state.db"),
                "tasks_dir": str(config_dir / "tasks"),
                "tasks": {},
            }
        )
    )
    return cfg


@pytest.fixture
def state_path(config_dir: Path) -> Path:
    """Return a path for the state database inside config_dir."""
    return config_dir / "state.db"


@pytest.fixture
def sample_config() -> dict[str, Any]:
    """Return a sample config dict for tests."""
    return {
        "state_dir": "/tmp/docket-test-state.db",
        "tasks_dir": "/tmp/docket-test-tasks",
        "logs_dir": "/tmp/docket-test-logs",
        "tasks": {
            "backup": {
                "source": "/data/backup",
                "remote": "remote:backup",
                "tool": "rclone",
            },
            "health-check": {
                "checks": ["disk", "memory"],
            },
        },
    }


@pytest.fixture
def tasks_dir(config_dir: Path) -> Path:
    """Create and return a tasks drop-in directory."""
    d = config_dir / "tasks"
    d.mkdir()
    return d
