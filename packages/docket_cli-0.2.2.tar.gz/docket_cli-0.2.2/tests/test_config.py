"""Tests for docket.config — YAML config loader."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import yaml

from docket.config import ConfigError, get_task_config, load_config, validate_config


class TestLoadConfig:
    def test_returns_defaults_when_no_file(self, tmp_path: Path) -> None:
        config = load_config(tmp_path / "nonexistent.yaml")
        assert "state_dir" in config
        assert "tasks_dir" in config
        assert "logs_dir" in config
        assert config["tasks"] == {}

    def test_loads_yaml_file(self, config_file: Path) -> None:
        # config_file fixture writes state_dir and tasks_dir.
        config = load_config(config_file)
        assert "state_dir" in config
        assert "tasks_dir" in config

    def test_merges_file_over_defaults(self, config_dir: Path) -> None:
        cfg = config_dir / "config.yaml"
        cfg.write_text(yaml.dump({"tasks": {"backup": {"source": "/data"}}}))
        config = load_config(cfg)
        assert config["tasks"]["backup"]["source"] == "/data"
        # Defaults still present.
        assert "state_dir" in config

    def test_invalid_yaml_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.yaml"
        bad.write_text("{{invalid yaml")
        with pytest.raises(ConfigError, match="Invalid YAML"):
            load_config(bad)

    def test_non_dict_yaml_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "list.yaml"
        bad.write_text("- item1\n- item2\n")
        with pytest.raises(ConfigError, match="mapping"):
            load_config(bad)

    def test_empty_yaml_file(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty.yaml"
        empty.write_text("")
        config = load_config(empty)
        assert config["tasks"] == {}

    def test_expands_tilde_in_paths(self, config_dir: Path) -> None:
        cfg = config_dir / "config.yaml"
        cfg.write_text(
            yaml.dump(
                {
                    "state_dir": "~/docket/state.db",
                    "tasks_dir": "~/docket/tasks",
                }
            )
        )
        config = load_config(cfg)
        assert "~" not in config["state_dir"]
        assert "~" not in config["tasks_dir"]
        assert "~" not in config["logs_dir"]

    def test_expands_env_vars_in_paths(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("DOCKET_HOME", str(tmp_path))
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.dump(
                {
                    "state_dir": "$DOCKET_HOME/state.db",
                    "tasks_dir": "$DOCKET_HOME/tasks",
                }
            )
        )
        config = load_config(cfg)
        assert str(tmp_path) in config["state_dir"]

    def test_non_dict_tasks_raises(self, tmp_path: Path) -> None:
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.dump({"tasks": ["backup"]}))
        with pytest.raises(ConfigError, match="tasks"):
            load_config(cfg)


class TestValidateConfig:
    def test_allows_custom_task_keys(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["custom"] = {"command": "echo hi", "unknown": {"nested": True}}
        validate_config(sample_config)

    @pytest.mark.parametrize("key", ["state_dir", "tasks_dir", "logs_dir"])
    def test_top_level_paths_must_be_strings(self, sample_config: dict[str, Any], key: str) -> None:
        sample_config[key] = 123
        with pytest.raises(ConfigError, match=key):
            validate_config(sample_config)

    def test_task_config_must_be_mapping(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"] = "not a mapping"
        with pytest.raises(ConfigError, match="backup"):
            validate_config(sample_config)

    def test_retry_must_be_non_negative_int(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["retry"] = -1
        with pytest.raises(ConfigError, match="retry"):
            validate_config(sample_config)

    def test_backoff_base_must_be_positive(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["backoff_base"] = 0
        with pytest.raises(ConfigError, match="backoff_base"):
            validate_config(sample_config)

    def test_hooks_must_be_string_or_string_list(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["on_success"] = ["ok", 1]
        with pytest.raises(ConfigError, match="on_success"):
            validate_config(sample_config)

    def test_agent_hook_config_is_validated(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["on_failure"] = [
            {
                "type": "agent",
                "url": "https://agent.example.test/hook",
                "message": "Failed: {summary}",
            }
        ]
        validate_config(sample_config)

    def test_agent_hook_requires_url(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["on_failure"] = [
            {"type": "agent", "message": "Failed: {summary}"}
        ]
        with pytest.raises(ConfigError, match="agent hook needs"):
            validate_config(sample_config)

    def test_on_complete_hook_is_validated(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["on_complete"] = ["ok", 1]
        with pytest.raises(ConfigError, match="on_complete"):
            validate_config(sample_config)

    def test_notify_config_accepts_discord_and_telegram(
        self, sample_config: dict[str, Any]
    ) -> None:
        sample_config["tasks"]["backup"]["notify"] = {
            "on": ["success", "failure"],
            "message": "{task} {status}: {summary}",
            "discord": {
                "channel": "1486489493258113094",
                "webhook_url_env": "DISCORD_BACKUP_WEBHOOK_URL",
            },
            "telegram": {
                "chat": "8223639759",
                "bot_token_env": "TELEGRAM_BOT_TOKEN",
            },
        }
        validate_config(sample_config)

    def test_notify_rejects_unknown_event(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["notify"] = {
            "on": ["started"],
            "discord": {"webhook_url_env": "DISCORD_WEBHOOK_URL"},
        }
        with pytest.raises(ConfigError, match="notify.on"):
            validate_config(sample_config)

    def test_notify_provider_must_be_mapping(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["notify"] = {"discord": "yes"}
        with pytest.raises(ConfigError, match="notify.discord"):
            validate_config(sample_config)

    def test_schedule_must_be_non_empty_string(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["schedule"] = ""
        with pytest.raises(ConfigError, match="schedule"):
            validate_config(sample_config)

    def test_backup_tool_must_be_known(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["tool"] = "tar"
        with pytest.raises(ConfigError, match="tool"):
            validate_config(sample_config)

    def test_backup_allows_hbackup_tool(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"] = {
            "tool": "hbackup",
            "hbackup_command": "auto",
            "hbackup_bin": "hbackup",
        }
        validate_config(sample_config)

    def test_backup_hbackup_command_must_be_known(
        self, sample_config: dict[str, Any]
    ) -> None:
        sample_config["tasks"]["backup"] = {"tool": "hbackup", "hbackup_command": "restore"}
        with pytest.raises(ConfigError, match="hbackup_command"):
            validate_config(sample_config)

    def test_backup_hbackup_excludes_must_be_string_list(
        self, sample_config: dict[str, Any]
    ) -> None:
        sample_config["tasks"]["backup"] = {"tool": "hbackup", "excludes": ["target", 1]}
        with pytest.raises(ConfigError, match="excludes"):
            validate_config(sample_config)

    def test_hbackup_task_accepts_first_class_config(
        self, sample_config: dict[str, Any]
    ) -> None:
        sample_config["tasks"]["hbackup"] = {
            "action": "auto",
            "hbackup_bin": "hbackup",
            "output": "/tmp/agent.tar.zst",
            "excludes": ["target", ".git"],
            "idle_timeout_seconds": 1800,
            "on_complete": "echo done",
        }
        validate_config(sample_config)

    def test_hbackup_task_rejects_unknown_action(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["hbackup"] = {"action": "restore"}
        with pytest.raises(ConfigError, match="action"):
            validate_config(sample_config)

    def test_hbackup_drive_must_be_bool(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["hbackup"] = {"drive": "yes"}
        with pytest.raises(ConfigError, match="drive"):
            validate_config(sample_config)

    def test_command_task_requires_command(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["fetch-data"] = {"type": "command"}
        with pytest.raises(ConfigError, match="command"):
            validate_config(sample_config)

    def test_command_task_accepts_agent_metadata(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["fetch-data"] = {
            "type": "command",
            "description": "Fetch data",
            "agent_notes": "Takes a few minutes and needs API_TOKEN.",
            "command": "fetch-data",
            "args": ["--json"],
            "dry_run_args": ["--dry-run"],
            "output_format": "jsonl",
            "success_exit_codes": [0, 2],
            "env": {"MODE": "test"},
            "cwd": "/tmp",
            "timeout_seconds": 30,
            "inputs": {"api_url": "Endpoint"},
            "outputs": {"events": "JSONL events"},
            "required_env": ["API_TOKEN"],
            "depends_on": ["prepare-data"],
            "network": True,
            "destructive": False,
        }
        validate_config(sample_config)

    def test_agent_notes_must_be_string(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["fetch-data"] = {
            "type": "command",
            "command": "fetch-data",
            "agent_notes": ["not", "a", "string"],
        }
        with pytest.raises(ConfigError, match="agent_notes"):
            validate_config(sample_config)

    def test_dependency_cycle_is_rejected(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["first"] = {
            "type": "command",
            "command": "first",
            "depends_on": ["second"],
        }
        sample_config["tasks"]["second"] = {
            "type": "command",
            "command": "second",
            "depends_on": ["first"],
        }
        with pytest.raises(ConfigError, match="dependency cycle"):
            validate_config(sample_config)

    def test_command_task_rejects_unknown_output_format(
        self, sample_config: dict[str, Any]
    ) -> None:
        sample_config["tasks"]["fetch-data"] = {
            "type": "command",
            "command": "fetch-data",
            "output_format": "xml",
        }
        with pytest.raises(ConfigError, match="output_format"):
            validate_config(sample_config)

    def test_backup_extra_args_must_be_string_list(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["extra_args"] = ["--ok", 1]
        with pytest.raises(ConfigError, match="extra_args"):
            validate_config(sample_config)

    def test_backup_idle_timeout_must_be_non_negative(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["backup"]["idle_timeout_seconds"] = -1
        with pytest.raises(ConfigError, match="idle_timeout_seconds"):
            validate_config(sample_config)

    def test_health_check_unknown_check_rejected(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["health-check"]["checks"] = ["disk", "network"]
        with pytest.raises(ConfigError, match="network"):
            validate_config(sample_config)

    def test_health_check_threshold_percentage(self, sample_config: dict[str, Any]) -> None:
        sample_config["tasks"]["health-check"]["disk_threshold_pct"] = 101
        with pytest.raises(ConfigError, match="disk_threshold_pct"):
            validate_config(sample_config)


class TestGetTaskConfig:
    def test_returns_task_config(self, sample_config: dict[str, Any]) -> None:
        tc = get_task_config(sample_config, "backup")
        assert tc["tool"] == "rclone"

    def test_returns_empty_for_missing_task(self, sample_config: dict[str, Any]) -> None:
        tc = get_task_config(sample_config, "nonexistent")
        assert tc == {}

    def test_handles_missing_tasks_key(self) -> None:
        tc = get_task_config({}, "anything")
        assert tc == {}

    def test_handles_non_dict_tasks(self) -> None:
        tc = get_task_config({"tasks": "not a dict"}, "anything")
        assert tc == {}
