"""Tests for docket.retry — Retry with exponential backoff."""

from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from docket.retry import retry


class TestRetrySuccessOnFirstTry:
    """Function succeeds on the first attempt."""

    def test_returns_result_immediately(self) -> None:
        fn = MagicMock(return_value=42)
        result = retry(fn, max_retries=3)
        assert result == 42
        assert fn.call_count == 1

    def test_zero_retries_success(self) -> None:
        fn = MagicMock(return_value="ok")
        result = retry(fn, max_retries=0)
        assert result == "ok"
        assert fn.call_count == 1


class TestRetrySuccessAfterRetries:
    """Function succeeds after some failures."""

    def test_succeeds_after_one_failure(self) -> None:
        fn = MagicMock(side_effect=[ValueError("oops"), "ok"])
        result = retry(fn, max_retries=1, backoff_base=0.01)
        assert result == "ok"
        assert fn.call_count == 2

    def test_succeeds_after_multiple_failures(self) -> None:
        fn = MagicMock(
            side_effect=[
                ValueError("fail1"),
                ValueError("fail2"),
                ValueError("fail3"),
                "finally",
            ]
        )
        result = retry(fn, max_retries=3, backoff_base=0.01)
        assert result == "finally"
        assert fn.call_count == 4


class TestRetryMaxRetriesExceeded:
    """All retries exhausted — raises last exception."""

    def test_raises_last_exception(self) -> None:
        fn = MagicMock(side_effect=ValueError("permanent failure"))
        with pytest.raises(ValueError, match="permanent failure"):
            retry(fn, max_retries=2, backoff_base=0.01)
        # 1 initial + 2 retries = 3 total attempts
        assert fn.call_count == 3

    def test_zero_retries_raises_immediately(self) -> None:
        fn = MagicMock(side_effect=RuntimeError("boom"))
        with pytest.raises(RuntimeError, match="boom"):
            retry(fn, max_retries=0)
        assert fn.call_count == 1


class TestRetryExponentialBackoff:
    """Backoff timing is exponential."""

    def test_backoff_increases_exponentially(self) -> None:
        """Verify that wait times increase with each attempt."""
        calls_at: list[float] = []

        def mock_sleep(seconds: float) -> None:
            calls_at.append(seconds)

        fn = MagicMock(
            side_effect=[
                ValueError("1"),
                ValueError("2"),
                ValueError("3"),
            ]
        )

        with pytest.MonkeyPatch.context() as m:
            m.setattr(time, "sleep", mock_sleep)
            with pytest.raises(ValueError):
                retry(fn, max_retries=2, backoff_base=2.0)

        # attempt 0: backoff_base**0 = 1.0
        # attempt 1: backoff_base**1 = 2.0
        assert len(calls_at) == 2
        assert calls_at[0] == pytest.approx(1.0, abs=0.01)
        assert calls_at[1] == pytest.approx(2.0, abs=0.01)


class TestRetryMaxWait:
    """max_wait caps the backoff time."""

    def test_wait_capped_at_max_wait(self) -> None:
        sleep_times: list[float] = []

        def mock_sleep(seconds: float) -> None:
            sleep_times.append(seconds)

        fn = MagicMock(
            side_effect=[
                ValueError("1"),
                ValueError("2"),
                ValueError("3"),
            ]
        )

        with pytest.MonkeyPatch.context() as m:
            m.setattr(time, "sleep", mock_sleep)
            with pytest.raises(ValueError):
                retry(fn, max_retries=2, backoff_base=10.0, max_wait=5.0)

        # attempt 0: min(10**0, 5.0) = min(1, 5) = 1.0
        # attempt 1: min(10**1, 5.0) = min(10, 5) = 5.0
        assert len(sleep_times) == 2
        assert sleep_times[0] == pytest.approx(1.0, abs=0.01)
        assert sleep_times[1] == pytest.approx(5.0, abs=0.01)


class TestRetryCustomBackoffBase:
    """Custom backoff_base changes the wait calculation."""

    def test_custom_base_3(self) -> None:
        sleep_times: list[float] = []

        def mock_sleep(seconds: float) -> None:
            sleep_times.append(seconds)

        fn = MagicMock(
            side_effect=[
                ValueError("1"),
                ValueError("2"),
            ]
        )

        with pytest.MonkeyPatch.context() as m:
            m.setattr(time, "sleep", mock_sleep)
            with pytest.raises(ValueError):
                retry(fn, max_retries=1, backoff_base=3.0)

        # attempt 0: 3**0 = 1.0
        assert sleep_times[0] == pytest.approx(1.0, abs=0.01)

    def test_custom_base_half(self) -> None:
        sleep_times: list[float] = []

        def mock_sleep(seconds: float) -> None:
            sleep_times.append(seconds)

        fn = MagicMock(
            side_effect=[
                ValueError("1"),
                ValueError("2"),
                ValueError("3"),
            ]
        )

        with pytest.MonkeyPatch.context() as m:
            m.setattr(time, "sleep", mock_sleep)
            with pytest.raises(ValueError):
                retry(fn, max_retries=2, backoff_base=0.5)

        # attempt 0: 0.5**0 = 1.0
        # attempt 1: 0.5**1 = 0.5
        assert sleep_times[0] == pytest.approx(1.0, abs=0.01)
        assert sleep_times[1] == pytest.approx(0.5, abs=0.01)
