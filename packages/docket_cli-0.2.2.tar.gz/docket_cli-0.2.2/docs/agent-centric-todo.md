# Agent-Centric Docket Roadmap

Docket should be the durable execution layer for agents: a small CLI that starts
scripted work, records what happened, gives agents a stable receipt, and exposes
status without requiring the agent to re-run or inspect shell logs.

## Done

- Store immutable run history with run IDs, timestamps, durations, exit codes,
  summaries, details, and dry-run flags.
- Return a stable JSON contract from task execution, including `run_id`,
  `status`, `task`, `summary`, `exit_code`, and duration fields.
- Add commands for agents to inspect recent runs, wait on a run ID, and start
  tasks asynchronously.
- Add activity-based backup idle timeout support for long-running jobs.
- Capture per-run logs and expose them through `docket logs <run-id>`.
- Return historical-duration polling hints in async receipts.
- Add cancellation for active async runs.
- Validate shared config and built-in task config before commands run.
- Add `docket capabilities` so agents can query available commands, tasks,
  inputs, outputs, config, and safety flags.
- Add `docket new-task` to scaffold custom drop-in task modules.
- Add task metadata fields for agent-facing inputs, outputs, environment
  requirements, network use, and destructive behavior.
- Add a repo-local `docket-agent` Codex skill for discovery, task creation,
  async runs, logs, and safe execution.
- Add optional `hbackup` backend support so Docket can schedule and track
  Hermes/OpenClaw installation backups without owning the archive implementation.
- Add config-defined command tasks for Rust, Go, Bash, Node, and other external
  executables with JSON/JSONL output parsing.
- Promote command-task JSONL events into a first-class run event table.
- Add `docket logs --follow` for live async output.
- Add `on_complete` hooks with structured `DOCKET_*` environment variables.
- Verify cancellation and record `cancel_requested` when a process remains alive.
- Stream async command-task JSONL events into the event table while the process
  is still running.
- Add `docket events --follow` as a structured progress stream.

## Essential

- Add per-task custom validation hooks for third-party tasks.

## Next

- Ship a minimal MCP server as an optional adapter over Docket capabilities.
- Add launch smoke tests that install Docket into a clean virtual environment.

## Later

- Parse live progress from `rclone --progress` and `rsync --info=progress2`.
- Emit JSONL progress events for dashboards, MCP adapters, and agent monitors.
- Add completion hooks with structured `DOCKET_*` environment variables.
- Ship an MCP server as an optional adapter over the Docket CLI/state database.

## MCP Relationship

MCP should be treated as an interface to Docket, not a replacement for it.
Docket owns local execution, locking, retries, schedules, state, logs, and
history. An MCP server can then expose those capabilities to agents in a richer
protocol without losing the benefits of a deterministic CLI.
