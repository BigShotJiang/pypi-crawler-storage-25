# hbackup + Docket for Hermes/OpenClaw Backups

`hbackup` creates Hermes/OpenClaw archives. Docket makes that backup job
discoverable, schedulable, async-safe, and inspectable by agents.

## First-Class Integration

```yaml
tasks:
  hbackup:
    action: auto                 # backup, auto, list, upload, setup-drive
    hbackup_bin: hbackup
    idle_timeout_seconds: 1800
    schedule: "0 3 * * *"
    retry: 1
    on_complete: "curl -X POST https://example.test/docket-complete"
```

Use `action: backup` when you only want to create an archive. Use `action: auto`
when hbackup should create the archive and upload using `~/.config/hbackup/config.toml`.

The older generic backup wrapper still works:

```yaml
tasks:
  backup:
    tool: hbackup
    hbackup_command: auto
    idle_timeout_seconds: 1800
    schedule: "0 3 * * *"
    on_complete: "curl -X POST https://example.test/docket-complete"
```

## Agent Workflow

```bash
docket --json capabilities
docket --json describe hbackup
docket --json run hbackup --dry-run
docket --json run hbackup --async --force
docket logs <run_id> --follow
docket --json status --run-id <run_id>
```

For a future hbackup version that emits JSONL progress, set
`output_format: jsonl` and use:

```bash
docket events <run_id> --follow
```

This keeps hbackup focused on archive correctness while Docket owns the agent
contract: run IDs, history, logs, events, retries, cancellation, and completion
notifications.
