# MVP Launch Checklist

Docket is ready for a developer-preview launch when the CLI can be installed
fresh, an agent can discover tasks without prior knowledge, and long-running
jobs can be started, observed, and audited without reading source code.

## Launch Scope

- Agent self-discovery via `docket --json capabilities`.
- Python drop-in tasks via `docket new-task`.
- External command tasks for Rust, Go, Bash, Node, Python scripts, and other
  executables.
- Async run receipts with `run_id`, PID, log path, wait/status/log commands, and
  historical duration hints.
- SQLite run history, logs, structured JSONL events, retries, locks, dry-runs,
  cancellation, and completion hooks.
- First-class `hbackup` task showing how Docket complements a new Hermes/OpenClaw
  backup backend instead of replacing it.
- Codex skill in `skills/docket-agent`.

## Pre-Launch Smoke Test

```bash
python -m pip install -e ".[dev]"
docket --json capabilities
docket --json describe hbackup
docket --json run hbackup --dry-run
docket --json new-task hello-agent --description "Hello from Docket"
docket --json run hello-agent --dry-run
docket --json run hello-agent --async --force
docket --json wait <run_id>
docket logs <run_id>
```

For command tasks:

```yaml
tasks:
  emit-events:
    type: command
    command: python
    args:
      - -c
      - "print('{\"event\":\"start\"}'); print('{\"event\":\"done\"}')"
    output_format: jsonl
```

```bash
docket --json run emit-events --force
docket --json events <run_id>
```

## Not Required For MVP

- MCP server. Useful next, but the CLI contract already gives OpenClaw, Hermes,
  Codex, shell scripts, and future MCP adapters a stable substrate.
- Live partial parsing for non-JSONL text logs.
- Remote task registry/package manager.

## Recommended Launch Positioning

> Docket turns personal scripts and compiled tools into discoverable, auditable,
> async-safe agent tasks.

Lead with hbackup as the timely example:

> hbackup creates reliable Hermes/OpenClaw archives; Docket turns that backup
> into an agent-visible job with run IDs, logs, history, retries, cancellation,
> and completion notifications.
