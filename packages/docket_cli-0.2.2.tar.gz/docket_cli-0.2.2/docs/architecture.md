# Architecture

## Overview

Docket is a plugin-based CLI tool where each task is a Python class implementing the `BaseTask` ABC.

## Components

### Task Interface (`task.py`)

- **`TaskResult`**: Frozen dataclass with `ok`, `summary`, `details`, `dry_run` fields. Maps to exit codes.
- **`BaseTask`**: ABC requiring `name`, `description`, `run()`, and `dry_run()`. Validates at subclass creation time.

### Config (`config.py`)

- Loads `~/.docket/config.yaml` with YAML.
- Merges file values over sensible defaults.
- Expands `~` and `$ENV_VARS` in paths.
- Per-task config accessed via `get_task_config()`.

### Registry (`registry.py`)

- Two discovery sources: entry points (`docket.transactions` group) and filesystem drop-in directory (`~/.docket/tasks/`).
- Entry points win on name collision.
- Results are cached; call `refresh()` to re-scan.

### State (`state.py`)

- SQLite database at `~/.docket/state.db`.
- Stores one record per task: `last_run`, `exit_code`, `summary`, `details`, `dry_run`.
- Upsert semantics — recording always replaces the previous entry.

### Logging (`logging.py`)

- Dual-mode: human-readable (with optional ANSI colours) or JSON lines.
- JSON mode emits one JSON object per log line on stderr.
- Controlled via `--json` flag and `-v` / `-vv` verbosity.

### CLI (`cli.py`)

Click-based with subcommands: `list`, `run`, `status`, `describe`, `doctor`.

## Data Flow

```
User/Agent → CLI → Registry (discover task) → Task.run() / Task.dry_run()
                    ↓                              ↓
                 Config (load YAML)          TaskResult
                    ↓                              ↓
                 State (record outcome)     Output (human/JSON) + exit code
```