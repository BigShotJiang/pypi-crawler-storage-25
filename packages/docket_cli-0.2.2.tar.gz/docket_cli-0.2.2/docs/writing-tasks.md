# Writing Tasks

Every Docket task is a Python class that extends `BaseTask` and implements two methods: `run()` and `dry_run()`.

For a drop-in task, let Docket create the starting point:

```bash
docket --json new-task fetch-invoices --description "Fetch invoices from the API"
```

Then edit the generated file in `tasks_dir`. Agents can discover the new task
with `docket --json capabilities` or inspect it with `docket --json describe
fetch-invoices`.

Use `type: command` instead when the task already exists as a Rust, Go, Bash,
Node, or other executable and only needs a Docket contract.

## The contract

```python
from docket.task import BaseTask, TaskResult

class MyTask(BaseTask):
    name = "my-task"                   # Unique slug used in CLI commands
    description = "What it does"       # Shown in `docket list`
    inputs = {"source": "Where to read data from"}
    outputs = {"records": "Number of records processed"}
    schema = {"source": {"type": "string", "required": True}}
    required_env = ["API_TOKEN"]
    network = True
    destructive = False

    def run(self, config: dict) -> TaskResult:
        # Execute the task for real.
        return TaskResult(ok=True, summary="Did the thing", details={"records": 42})

    def dry_run(self, config: dict) -> TaskResult:
        # Preview — no side effects.
        return TaskResult(ok=True, summary="Would do the thing", dry_run=True)
```

### TaskResult fields

| Field | Type | Description |
|-------|------|-------------|
| `ok` | `bool` | Whether the task succeeded |
| `summary` | `str` | Human-readable one-line summary |
| `details` | `dict` | Optional machine-readable details (included in `--json` output) |
| `dry_run` | `bool` | `True` when this result comes from `dry_run()` |

The `exit_code` property is derived automatically:

- `ok=True, dry_run=False` → exit code `0`
- `ok=False` → exit code `1`
- `ok=True, dry_run=True` → exit code `2`

### Agent metadata fields

These class attributes are optional but make tasks much easier for agents to use:

| Field | Type | Description |
|-------|------|-------------|
| `inputs` | `dict[str, str]` | Config keys, user inputs, files, or external resources the task expects |
| `outputs` | `dict[str, str]` | Machine-readable values the task returns in `TaskResult.details` |
| `schema` | `dict[str, dict]` | Optional config validation schema checked before execution |
| `required_env` | `list[str]` | Environment variables needed at runtime |
| `network` | `bool` | Whether the task calls external services |
| `destructive` | `bool` | Whether the task can delete, overwrite, charge money, or mutate important state |

Keep `summary` short and put structured results in `details`; agents should not
have to parse prose to understand what happened.

### Config schema

Tasks can declare a small JSON-like `schema` for their own config. Docket
validates it before `run()` or `dry_run()` executes, so agents get fast,
side-effect-free errors:

```python
class VitalsCheckIn(BaseTask):
    name = "vitals-check-in"
    description = "Send a scheduled vitals check-in"
    schema = {
        "time_of_day": {
            "type": "string",
            "required": True,
            "enum": ["morning", "midday", "evening"],
        }
    }
```

Supported types are `string`, `integer`, `number`, `boolean`, `array`, and
`object` plus short aliases such as `str`, `int`, `bool`, `list`, and `dict`.
Unknown config keys are allowed unless a task validates them itself.

## Task config

The `config` dict passed to `run()` and `dry_run()` is the entire `tasks.<name>` mapping from `~/.docket/config.yaml`. Task-specific keys sit alongside Docket's own keys.

### Per-task config options

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `schedule` | string | — | Cron expression for systemd timer generation (used by `docket install`) |
| `retry` | int | `0` | Max retry attempts when the task returns `ok=False` |
| `backoff_base` | float | `2.0` | Base for exponential backoff: wait = `backoff_base ** attempt` seconds |
| `on_success` | string or list | — | Shell command(s) to run after a successful task run |
| `on_failure` | string or list | — | Shell command(s) to run after a failed task run |
| `on_complete` | string or list | — | Shell command(s) to run after any terminal result |
| `notify` | mapping | — | Native Discord/Telegram notifications |
| `docket_bin` | string | `docket` | Path to the docket binary (used in generated systemd service units) |

All other keys are passed through to the task unchanged. For example, the built-in `backup` task reads `source`, `remote`, and `tool` from its config dict, while `health-check` reads `checks`, `disk_threshold_pct`, etc.

```yaml
tasks:
  my-task:
    # Docket-level options
    schedule: "0 * * * *"
    retry: 3
    backoff_base: 2.0
    on_success: "echo 'my-task succeeded'"
    on_failure: "echo 'my-task failed'"

    # Task-specific options (passed to run() as-is)
    source: /data/stuff
    destination: s3://bucket/stuff
```

## Registration

### Option A: Command task

Define a command task directly in `~/.docket/config.yaml`:

```yaml
tasks:
  fetch-data:
    type: command
    description: Fetch API data with an external binary
    command: fetch-data
    args: ["--jsonl"]
    dry_run_args: ["--dry-run", "--json"]
    output_format: jsonl
    success_exit_codes: [0]
    timeout_seconds: 300
    required_env: [API_TOKEN]
    inputs:
      api_url: Endpoint configured by the command
    outputs:
      events: JSONL events emitted on stdout
    network: true
    destructive: false
```

Command tasks are discovered by `docket --json capabilities` like Python tasks.
They are best for compiled tools, existing scripts, or task packs owned outside
the Docket codebase.

Output handling:

| `output_format` | Behavior |
|-----------------|----------|
| `text` | Preserve raw stdout/stderr only |
| `json` | Parse stdout into `TaskResult.details["json"]` |
| `jsonl` | Parse one JSON object per stdout line into `details["events"]` |
| `auto` | Detect JSON or JSONL when stdout shape is obvious |

For JSONL, Docket also records `event_count`, `last_event`, and any
`invalid_jsonl_lines`. Async command tasks still return an immediate run
receipt; the child run writes the final parsed result to the run record and
captured Docket output to `logs_dir`.

Structured events are also stored separately:

```bash
docket --json events <run_id>
docket events <run_id> --follow
```

Use this when an agent needs progress/result events without parsing logs or the
full task details payload. Async command tasks write JSONL events to the event
table while they are running, so `events --follow` can be used as a structured
progress stream.

### Option B: Entry point (recommended for packages)

In your `pyproject.toml`:

```toml
[project.entry-points."docket.tasks"]
my-task = "my_package.tasks:MyTask"
```

Entry points take priority over drop-in files if both register the same task name.

### Option C: Drop-in file

Place a `.py` file in `~/.docket/tasks/`. Any concrete `BaseTask` subclass in the file is automatically discovered. No registration needed — just drop the file in and run `docket list` to see it.

The safer path for agents is:

```bash
docket --json new-task my-task --description "Short task description"
docket --json capabilities
docket --json describe my-task
docket --json run my-task --dry-run
```

## Lock files

When a task runs, Docket acquires a lock file at `~/.docket/locks/<task_name>.lock` to prevent concurrent execution. Locks use native file locking (`fcntl` on Unix, `msvcrt` on Windows) and store the owning PID and timestamp for debugging.

- **Automatic**: Locks are acquired before the task runs and released when it finishes (including on exceptions).
- **Stale detection**: If the PID in the lock file belongs to a process that is no longer running, the stale lock is cleaned up automatically.
- **Bypass with `--force`**: The `docket run <task> --force` flag skips lock acquisition entirely.
- **JSON output**: When a lock is held, `docket run` exits with code 1 and emits `{"error": "Task '<name>' is already running (PID <pid>)"}`.

## Notification hooks

Hooks are shell commands that run after a task completes. They are configured per-task in the YAML config under `on_success`, `on_failure`, and `on_complete`.

```yaml
tasks:
  backup:
    source: /data
    remote: remote:backup
    on_success: "notify-send 'Backup completed'"
    on_failure:
      - "notify-send 'Backup failed'"
      - "curl -X POST https://hooks.slack.com/services/xxx -d '{\"text\": \"Backup failed\"}'"
    on_complete: "curl -X POST https://example.test/docket-complete"
    notify:
      on: [success, failure]
      discord:
        webhook_url_env: DISCORD_WEBHOOK_URL
      telegram:
        chat: "8223639759"
        bot_token_env: TELEGRAM_BOT_TOKEN
```

Each hook value can be a single command string or a list of command strings. Hooks run sequentially and are **non-blocking** — a hook failure does not affect the task result or exit code.

Environment variable expansion is supported in hook commands (e.g., `$HOME`, `$TASK_NAME`):

```yaml
on_failure: "curl -X POST https://example.com/webhook -d '{\"task\": \"$TASK_NAME\"}'"
```

Hook results (command, exit code, stdout, stderr) are included in `--json` output under the `hooks` key. Hooks receive structured environment variables including `DOCKET_RUN_ID`, `DOCKET_TASK_NAME`, `DOCKET_STATUS`, `DOCKET_EXIT_CODE`, `DOCKET_SUMMARY`, `DOCKET_DETAILS_JSON`, and `DOCKET_LOG_PATH` when available.

> **Security note**: Hook commands use `shell=True` and support environment variable expansion. Only use config files from trusted sources, as hooks allow arbitrary shell execution.

### Native notifications

Use `notify` when a task should ping common agent channels without shell
wrappers. Discord uses webhooks; Telegram uses bot tokens and chat IDs.

```yaml
tasks:
  vitals-morning:
    notify:
      on: [success, failure]       # success, failure, or complete
      message: "{task} {status}: {summary} ({run_id})"
      discord:
        webhook_url_env: DISCORD_VITALS_WEBHOOK_URL
        username: Docket
      telegram:
        chat: "8223639759"
        bot_token_env: TELEGRAM_BOT_TOKEN
```

If `notify.on` is omitted, Docket sends notifications on failure only. Prefer
`webhook_url_env` and `bot_token_env` so secrets stay out of config files.
Notification delivery is non-blocking; failures are reported in `--json`
output under `hooks` as `notify:discord` or `notify:telegram`.

## Retry configuration

When a task returns `ok=False`, Docket can automatically retry it with exponential backoff:

```yaml
tasks:
  api-sync:
    retry: 3                    # Up to 3 retry attempts after initial failure
    backoff_base: 2.0           # Wait 2^0=1s, 2^1=2s, 2^2=4s between retries
```

- `retry`: Number of additional attempts after the initial failure. Default is `0` (no retries).
- `backoff_base`: Multiplier for exponential backoff. Wait time = `backoff_base ** attempt`. Default is `2.0`. Maximum wait between retries is capped at 60 seconds.

The retry count is included in `--json` output as `retry_count`. In human-readable output, a suffix like `(after 3 retries)` is appended.

Retries only apply to `docket run` (not `--dry-run`). The `--force` flag does not affect retry behavior.

## systemd integration

Tasks with a `schedule` key can be turned into systemd timers:

```yaml
tasks:
  backup:
    source: /data
    remote: remote:backup
    schedule: "0 2 * * *"       # Daily at 2:00 AM (cron syntax)
```

### Generate and install units

```bash
# Preview what would be generated
docket install --list

# Install for current user
docket install

# Install for a specific task only
docket install backup

# Write units to a custom directory
docket install --output-dir /tmp/units

# Reload systemd after installing
systemctl --user daemon-reload
systemctl --user enable --now docket-backup.timer
```

### Generated files

For a task named `backup` with `schedule: "0 2 * * *"`, Docket generates:

- `~/.config/systemd/user/docket-backup.service` — oneshot service that runs `docket run backup`
- `~/.config/systemd/user/docket-backup.timer` — timer with `OnCalendar=*-*-* 02:00:00` and `Persistent=true`

The cron-to-systemd conversion handles common patterns: daily, hourly, every-N-minutes, weekly, and monthly schedules. Unrecognized cron expressions are passed through as-is.

### Custom binary path

If `docket` is not on the `PATH` that systemd uses, set `docket_bin` in the task config:

```yaml
tasks:
  backup:
    schedule: "0 2 * * *"
    docket_bin: /usr/local/bin/docket
```

## Best practices

1. **Always implement `dry_run()`** — it's required by the ABC and essential for agent preview.
2. **Return structured `details`** — agents consume JSON; include counts, paths, durations.
3. **Don't swallow exceptions** — let unexpected errors propagate; the CLI catches them.
4. **Keep tasks idempotent** — re-running a successful task should be safe.
5. **Use `--force` carefully** — it bypasses both the "already ran today" guard and lock acquisition.
6. **Set `schedule`** on tasks you want to automate via systemd timers.
7. **Use notification hooks** for alerts — `on_failure` is ideal for Slack/webhook notifications.
