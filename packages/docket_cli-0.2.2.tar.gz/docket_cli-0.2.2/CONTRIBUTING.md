## Contributing to Docket

### Setup

```bash
pip install -e ".[dev]"
```

### Running tests

```bash
pytest
```

### Adding a built-in task

1. Create a new module in `src/docket/tasks/`
2. Extend `BaseTask`, implement `run()` and `dry_run()`
3. Add an entry point in `pyproject.toml` under `[project.entry-points."docket.tasks"]`
4. Add tests in `tests/tasks/`

### Adding a plugin task (separate package)

1. Create a new Python package
2. Depend on `docket` for the `BaseTask` import
3. Register your task class via the `docket.tasks` entry point group

### Code style

We use `ruff` for linting. Run `ruff check .` before committing.