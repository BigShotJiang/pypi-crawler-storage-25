"""Lock file management to prevent concurrent task execution."""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO, Optional

if sys.platform == "win32":
    import ctypes
    import msvcrt
else:
    import fcntl

logger = logging.getLogger("docket")
WINDOWS_LOCK_OFFSET = 2**31 - 1


class LockFile:
    """Manage a per-task non-blocking lock file.

    The lock file stores the PID and timestamp for debugging. Locks are
    automatically released when the file handle is closed or the process exits.

    Args:
        path: Path to the lock file. Defaults to ``~/.docket/locks/<task_name>.lock``
            if only a task_name is provided.
    """

    def __init__(self, path: str | Path | None = None, *, task_name: str | None = None) -> None:
        if path is not None:
            self._path = Path(path)
        elif task_name is not None:
            self._path = Path.home() / ".docket" / "locks" / f"{task_name}.lock"
        else:
            raise ValueError("Either path or task_name must be provided")
        self._fd: Optional[int] = None
        self._file: BinaryIO | None = None
        self._locked = False

    @property
    def path(self) -> Path:
        """Return the lock file path."""
        return self._path

    def acquire(self) -> bool:
        """Try to acquire the lock non-blocking."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if sys.platform == "win32":
            if not self._acquire_windows():
                return False
        elif not self._acquire_unix():
            return False

        now = datetime.now(timezone.utc).isoformat()
        content = f"pid={os.getpid()}\ntimestamp={now}\n"
        try:
            assert self._fd is not None
            os.lseek(self._fd, 0, os.SEEK_SET)
            os.ftruncate(self._fd, 0)
            os.write(self._fd, content.encode())
        except OSError:
            pass

        self._locked = True
        logger.debug("Lock acquired: %s", self._path)
        return True

    def _acquire_unix(self) -> bool:
        try:
            fd = os.open(str(self._path), os.O_RDWR | os.O_CREAT, 0o644)
        except OSError as exc:
            logger.warning("Cannot open lock file %s: %s", self._path, exc)
            return False

        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            os.close(fd)
            return False

        self._fd = fd
        return True

    def _acquire_windows(self) -> bool:
        try:
            file_obj = open(self._path, "a+b")
        except OSError as exc:
            logger.warning("Cannot open lock file %s: %s", self._path, exc)
            return False

        try:
            file_obj.seek(WINDOWS_LOCK_OFFSET)
            msvcrt.locking(file_obj.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            file_obj.close()
            return False

        self._file = file_obj
        self._fd = file_obj.fileno()
        return True

    def release(self) -> None:
        """Release the lock and close the file descriptor."""
        if self._fd is not None:
            try:
                if sys.platform == "win32":
                    assert self._file is not None
                    self._file.seek(WINDOWS_LOCK_OFFSET)
                    msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)
                    self._file.close()
                else:
                    fcntl.flock(self._fd, fcntl.LOCK_UN)
                    os.close(self._fd)
            except OSError:
                pass
            self._fd = None
            self._file = None
            self._locked = False
            logger.debug("Lock released: %s", self._path)

    def _read_pid(self) -> int | None:
        """Read the PID from the lock file, or None if unavailable."""
        try:
            text = self._path.read_text().strip()
            for line in text.splitlines():
                if line.startswith("pid="):
                    return int(line.split("=", 1)[1].strip())
        except (OSError, ValueError, IndexError):
            pass
        return None

    def is_locked(self) -> bool:
        """Check whether a live lock exists for this task."""
        if not self._path.exists():
            return False

        pid = self._read_pid()
        if pid is None:
            return False

        return self._pid_alive(pid)

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        """Return True if *pid* is a running process."""
        if sys.platform == "win32":
            return _pid_alive_windows(pid)
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError:
            return False
        return True

    def clean_stale(self) -> int:
        """Remove lock files whose recorded PID is no longer running."""
        locks_dir = self._path.parent
        cleaned = 0
        if not locks_dir.is_dir():
            return 0

        for lock_path in locks_dir.glob("*.lock"):
            try:
                text = lock_path.read_text().strip()
            except OSError:
                continue

            pid: int | None = None
            for line in text.splitlines():
                if line.startswith("pid="):
                    try:
                        pid = int(line.split("=", 1)[1].strip())
                    except (ValueError, IndexError):
                        pass
                    break

            if pid is not None and not self._pid_alive(pid):
                try:
                    lock_path.unlink()
                    cleaned += 1
                    logger.debug("Cleaned stale lock: %s (pid %d)", lock_path, pid)
                except OSError:
                    pass

        return cleaned

    def __enter__(self) -> LockFile:
        if not self.acquire():
            raise RuntimeError(f"Could not acquire lock: {self._path}")
        return self

    def __exit__(self, *exc: object) -> None:
        self.release()


def _pid_alive_windows(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True

    synchronize = 0x00100000
    process = ctypes.windll.kernel32.OpenProcess(synchronize, False, pid)
    if not process:
        return False
    try:
        exit_code = ctypes.c_ulong()
        if not ctypes.windll.kernel32.GetExitCodeProcess(process, ctypes.byref(exit_code)):
            return False
        still_active = 259
        return exit_code.value == still_active
    finally:
        ctypes.windll.kernel32.CloseHandle(process)
