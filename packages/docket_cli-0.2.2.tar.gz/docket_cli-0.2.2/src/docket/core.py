"""Core business logic for Docket operations.

These functions return structured data and raise :class:`DocketError` on
failure. They have no Click, formatting, or process-exit concerns. Both
the CLI and the programmatic API call into this module.
"""

from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from docket import __version__
from docket.config import ConfigError, get_task_config, load_config
from docket.hooks import Hooks
from docket.lockfile import LockFile
from docket.registry import Registry, RegistryError
from docket.retry import retry
from docket.schema import SchemaError, validate_task_schema
from docket.state import StateError, StateStore
from docket.task import TaskResult

logger = logging.getLogger("docket.core")

TERMINAL_STATUSES = {"succeeded", "failed", "timed_out", "cancelled", "skipped"}

COMMAND_CAPABILITIES = [
    {
        "name": "list",
        "summary": "List discovered tasks and latest task state.",
        "agent_use": "Discover personalized tasks available in this Docket installation.",
        "json": True,
    },
    {
        "name": "capabilities",
        "summary": "Return agent-facing command and task metadata.",
        "agent_use": "Bootstrap an agent without prior Docket knowledge.",
        "json": True,
    },
    {
        "name": "new-task",
        "summary": "Scaffold a drop-in task file.",
        "agent_use": "Create a personalized scripted task for later runs.",
        "json": True,
    },
    {
        "name": "describe <task>",
        "summary": "Show task config, inputs, outputs, and safety metadata.",
        "agent_use": "Understand what a task needs before running it.",
        "json": True,
    },
    {
        "name": "run <task>",
        "summary": "Run a task synchronously.",
        "agent_use": "Execute deterministic work and receive a structured result.",
        "json": True,
    },
    {
        "name": "run <task> --dry-run",
        "summary": "Preview a task without side effects.",
        "agent_use": "Check expected behavior before real execution.",
        "json": True,
    },
    {
        "name": "run <task> --async",
        "summary": "Start a task in the background and return a run receipt.",
        "agent_use": "Launch long-running work and poll, wait, cancel, or read logs later.",
        "json": True,
    },
    {
        "name": "status --run-id <id>",
        "summary": "Inspect one historical run.",
        "agent_use": "Check whether a specific run has finished.",
        "json": True,
    },
    {
        "name": "runs [task]",
        "summary": "List recent run history.",
        "agent_use": "Learn previous outcomes and durations.",
        "json": True,
    },
    {
        "name": "wait <run_id>",
        "summary": "Block until a run reaches a terminal status.",
        "agent_use": "Wait intentionally instead of guessing sleep durations.",
        "json": True,
    },
    {
        "name": "logs <run_id> [--follow]",
        "summary": "Read captured async output.",
        "agent_use": "Debug long-running or failed async work.",
        "json": True,
    },
    {
        "name": "events <run_id>",
        "summary": "Read structured JSONL events recorded for a run.",
        "agent_use": "Inspect machine-readable progress or result events.",
        "json": True,
    },
    {
        "name": "cancel <run_id>",
        "summary": "Cancel a running async task.",
        "agent_use": "Stop work that is no longer needed or appears unsafe.",
        "json": True,
    },
    {
        "name": "health",
        "summary": "Summarize task health across the Docket installation.",
        "agent_use": "Check for failed, degraded, stale, or never-run tasks in one call.",
        "json": True,
    },
]


class DocketError(Exception):
    """Raised when a Docket operation cannot complete normally.

    Carries an ``exit_code`` (the CLI exit code that should be emitted)
    and an optional structured ``payload`` for JSON consumers.
    """

    def __init__(
        self,
        message: str,
        *,
        exit_code: int = 1,
        payload: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code
        self.payload = payload


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _config() -> dict[str, Any]:
    try:
        return load_config()
    except ConfigError as exc:
        raise DocketError(str(exc)) from exc


def _registry(config: dict[str, Any]) -> Registry:
    return Registry(tasks_dir=config.get("tasks_dir"), task_configs=config.get("tasks"))


def _task_metadata(
    name: str,
    cls: type[Any],
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = config or {}
    return {
        "name": name,
        "description": cls.description,
        "agent_notes": config.get("agent_notes", ""),
        "inputs": getattr(cls, "inputs", {}),
        "outputs": getattr(cls, "outputs", {}),
        "schema": getattr(cls, "schema", {}),
        "required_env": getattr(cls, "required_env", []),
        "destructive": bool(getattr(cls, "destructive", False)),
        "network": bool(getattr(cls, "network", False)),
        "configured": bool(config),
        "config": config,
    }


def _log_path(config: dict[str, Any], run_id: str) -> Path:
    return Path(config["logs_dir"]) / f"{run_id}.log"


def _config_path_for_child() -> str:
    from docket.config import DEFAULT_CONFIG_PATH

    return str(Path(os.environ.get("DOCKET_CONFIG", DEFAULT_CONFIG_PATH)))


def spawn_async_run(
    task_name: str,
    *,
    run_id: str,
    dry_run: bool,
    force: bool,
    log_path: Path,
) -> subprocess.Popen[bytes]:
    """Spawn `python -m docket.cli ... run --run-id <id>` as a child process."""
    cmd = [
        sys.executable,
        "-m",
        "docket.cli",
        "--json",
        "run",
        "--run-id",
        run_id,
        "--skip-daily-guard",
    ]
    if dry_run:
        cmd.append("--dry-run")
    if force:
        cmd.append("--force")
    cmd.append(task_name)

    env = os.environ.copy()
    env["DOCKET_CONFIG"] = _config_path_for_child()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(log_path, "ab")
    try:
        kwargs: dict[str, Any] = {
            "env": env,
            "stdout": log_file,
            "stderr": subprocess.STDOUT,
        }
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True
        return subprocess.Popen(cmd, **kwargs)
    finally:
        log_file.close()


def terminate_pid(pid: int) -> dict[str, Any]:
    """Best-effort terminate a process group / process by PID."""
    if os.name == "nt":
        completed = subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            os.kill(pid, signal.SIGTERM)
        return {
            "method": "taskkill",
            "exit_code": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        }
    try:
        os.killpg(pid, signal.SIGTERM)
        return {"method": "process_group", "signal": signal.SIGTERM}
    except ProcessLookupError:
        return {"method": "process_group", "already_exited": True}
    except OSError:
        os.kill(pid, signal.SIGTERM)
        return {"method": "process", "signal": signal.SIGTERM}


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def wait_for_pid_exit(pid: int, timeout_seconds: float = 2.0) -> bool:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if not _pid_running(pid):
            return True
        time.sleep(0.1)
    return not _pid_running(pid)


def _set_run_env(
    *,
    run_id: str | None,
    task_name: str,
    state_path: str,
) -> dict[str, str | None]:
    previous = {
        "DOCKET_RUN_ID": os.environ.get("DOCKET_RUN_ID"),
        "DOCKET_TASK_NAME": os.environ.get("DOCKET_TASK_NAME"),
        "DOCKET_STATE_PATH": os.environ.get("DOCKET_STATE_PATH"),
    }
    if run_id:
        os.environ["DOCKET_RUN_ID"] = run_id
        os.environ["DOCKET_TASK_NAME"] = task_name
        os.environ["DOCKET_STATE_PATH"] = state_path
    return previous


def _restore_env(previous: dict[str, str | None]) -> None:
    for key, value in previous.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


def _record_result_events(
    state: StateStore,
    run_record: dict[str, Any],
    result: TaskResult,
) -> None:
    events = result.details.get("events")
    if isinstance(events, list) and all(isinstance(event, dict) for event in events):
        state.add_events(run_record["run_id"], events, replace=True)


def _poll_recommendation(duration_stats: dict[str, Any]) -> dict[str, Any]:
    if duration_stats.get("sample_size", 0) <= 0:
        return {"next_check_after_seconds": 5}
    median = float(duration_stats.get("median_seconds", 5))
    p90 = float(duration_stats.get("p90_seconds", median))
    return {
        "next_check_after_seconds": max(1, min(int(median / 4), 300)),
        "estimated_duration_seconds": median,
        "p90_duration_seconds": p90,
    }


def _cron_interval_seconds(schedule: str) -> float | None:
    parts = schedule.strip().split()
    if len(parts) != 5:
        return None
    minute, hour, day_of_month, month, day_of_week = parts
    if minute.startswith("*/") and hour == day_of_month == month == day_of_week == "*":
        return _positive_int_seconds(minute[2:], 60)
    if minute == "0" and hour.startswith("*/") and day_of_month == month == day_of_week == "*":
        return _positive_int_seconds(hour[2:], 3600)
    if minute not in {"*", ""} and hour == "*" and day_of_month == month == day_of_week == "*":
        return 3600
    if minute not in {"*", ""} and hour not in {"*", ""}:
        if day_of_month == month == day_of_week == "*":
            return 86400
        if day_of_week != "*" and day_of_month == "*" and month == "*":
            return 7 * 86400
        if day_of_month != "*" and month == "*" and day_of_week == "*":
            return 31 * 86400
    return None


def _positive_int_seconds(value: str, multiplier: int) -> float | None:
    try:
        number = int(value)
    except ValueError:
        return None
    if number <= 0:
        return None
    return float(number * multiplier)


def _consecutive_failures(runs: list[dict[str, Any]]) -> int:
    count = 0
    for run_record in runs:
        if run_record["status"] == "succeeded" or run_record["exit_code"] in (0, 2):
            break
        if run_record["status"] in {"failed", "timed_out", "cancelled"} or (
            run_record["exit_code"] not in (None, 0, 2)
        ):
            count += 1
    return count


# ---------------------------------------------------------------------------
# Public core operations
# ---------------------------------------------------------------------------


def list_tasks() -> list[dict[str, Any]]:
    """Return all discovered tasks with their latest state."""
    config = _config()
    registry = _registry(config)
    try:
        tasks = registry.discover()
    except RegistryError as exc:
        raise DocketError(str(exc)) from exc

    entries: list[dict[str, Any]] = []
    with StateStore(config["state_dir"]) as state:
        for name, cls in sorted(tasks.items()):
            rec = state.get(name)
            entries.append(
                {
                    "name": name,
                    "description": cls.description,
                    "last_run": rec,
                }
            )
    return entries


def describe_task(task_name: str) -> dict[str, Any]:
    """Return metadata for a single task. Raises :class:`DocketError`."""
    config = _config()
    registry = _registry(config)
    try:
        task_cls = registry.get(task_name)
    except RegistryError as exc:
        raise DocketError(str(exc)) from exc
    task_config = get_task_config(config, task_name)
    return _task_metadata(task_cls.name, task_cls, task_config)


def capabilities() -> dict[str, Any]:
    """Return the agent-facing capabilities payload."""
    config = _config()
    registry = _registry(config)
    try:
        tasks = registry.discover()
    except RegistryError as exc:
        raise DocketError(str(exc)) from exc

    task_payload = [
        _task_metadata(name, cls, get_task_config(config, name) or None)
        for name, cls in sorted(tasks.items())
    ]
    return {
        "tool": "docket",
        "version": __version__,
        "agent_contract_version": 1,
        "config": {
            "state_dir": config["state_dir"],
            "tasks_dir": config["tasks_dir"],
            "logs_dir": config["logs_dir"],
        },
        "commands": COMMAND_CAPABILITIES,
        "tasks": task_payload,
    }


def task_status(
    task_name: str | None = None,
    *,
    run_id: str | None = None,
) -> Any:
    """Return latest task state, a single task's state, or one historical run."""
    config = _config()
    with StateStore(config["state_dir"]) as state:
        if run_id:
            rec = state.get_run(run_id)
            if rec is None:
                raise DocketError(
                    f"Run '{run_id}' was not found.",
                    payload={"run_id": run_id, "status": "not_found"},
                )
            return rec
        if task_name:
            rec = state.get(task_name)
            if rec is None:
                return {"task": task_name, "status": "never_run"}
            return rec
        return state.list_all()


def task_runs(task_name: str | None = None, *, limit: int = 20) -> list[dict[str, Any]]:
    """Return recent historical task runs."""
    config = _config()
    with StateStore(config["state_dir"]) as state:
        return state.list_runs(task_name=task_name, limit=limit)


def wait_for_run(
    run_id: str,
    *,
    timeout: float | None = None,
    poll_interval: float = 1.0,
) -> dict[str, Any]:
    """Block until *run_id* hits a terminal status, then return the record.

    Raises :class:`DocketError` for unknown runs, wait timeouts, and
    completed runs whose ``exit_code`` is non-zero.
    """
    config = _config()
    deadline = None if timeout is None else time.monotonic() + max(timeout, 0)

    with StateStore(config["state_dir"]) as state:
        while True:
            rec = state.get_run(run_id)
            if rec is None:
                raise DocketError(
                    f"Run '{run_id}' was not found.",
                    payload={"run_id": run_id, "status": "not_found"},
                )

            if rec["status"] in TERMINAL_STATUSES:
                exit_code = rec["exit_code"] if rec["exit_code"] is not None else 1
                if exit_code != 0:
                    raise DocketError(
                        rec["summary"] or f"Run '{run_id}' ended with exit code {exit_code}.",
                        exit_code=exit_code,
                        payload=rec,
                    )
                return rec

            if deadline is not None and time.monotonic() >= deadline:
                payload = {
                    "run_id": run_id,
                    "task_name": rec["task_name"],
                    "status": "wait_timeout",
                    "last_seen_status": rec["status"],
                }
                raise DocketError(
                    f"Timed out waiting for run '{run_id}' (last status: {rec['status']}).",
                    payload=payload,
                )

            time.sleep(max(poll_interval, 0.1))


def run_logs(run_id: str, *, tail: int | None = None) -> dict[str, Any]:
    """Return captured stdout/stderr for an async run."""
    config = _config()
    with StateStore(config["state_dir"]) as state:
        rec = state.get_run(run_id)

    if rec is None:
        raise DocketError(
            f"Run '{run_id}' was not found.",
            payload={"run_id": run_id, "status": "not_found"},
        )

    log_path_raw = rec["details"].get("log_path")
    if not log_path_raw:
        raise DocketError(
            f"Run '{run_id}' has no captured log.",
            payload={"run_id": run_id, "status": "no_log"},
        )

    log_path = Path(log_path_raw)
    if not log_path.exists():
        raise DocketError(
            f"Log file does not exist: {log_path}",
            payload={"run_id": run_id, "status": "log_missing", "path": str(log_path)},
        )

    text = log_path.read_text(errors="replace")
    if tail is not None:
        if tail <= 0:
            text = ""
        else:
            lines = text.splitlines(keepends=True)
            text = "".join(lines[-tail:])

    return {
        "run_id": run_id,
        "status": "ok",
        "path": str(log_path),
        "content": text,
    }


def run_events(run_id: str, *, limit: int = 500) -> list[dict[str, Any]]:
    """Return structured events for a run, ordered by event index."""
    config = _config()
    with StateStore(config["state_dir"]) as state:
        rec = state.get_run(run_id)
        if rec is None:
            raise DocketError(
                f"Run '{run_id}' was not found.",
                payload={"run_id": run_id, "status": "not_found"},
            )
        return state.list_events(run_id, limit=limit)


def cancel_run(
    run_id: str,
    *,
    _terminate: Callable[[int], dict[str, Any]] | None = None,
    _wait_for_exit: Callable[[int], bool] | None = None,
) -> dict[str, Any]:
    """Cancel a running async run by terminating its child process.

    The ``_terminate`` and ``_wait_for_exit`` parameters exist so callers
    (notably the CLI) can substitute test-patched helpers.
    """
    terminate = _terminate or terminate_pid
    wait_for_exit = _wait_for_exit or wait_for_pid_exit
    config = _config()

    with StateStore(config["state_dir"]) as state:
        rec = state.get_run(run_id)
        if rec is None:
            raise DocketError(
                f"Run '{run_id}' was not found.",
                payload={"run_id": run_id, "status": "not_found"},
            )

        if rec["status"] != "running":
            return {**rec, "cancelled": False}

        pid = rec["details"].get("pid")
        if not isinstance(pid, int):
            msg = f"Run '{run_id}' does not have a cancellable PID."
            raise DocketError(
                msg,
                payload={"run_id": run_id, "status": "not_cancellable", "error": msg},
            )

        try:
            termination = terminate(pid)
        except OSError as exc:
            msg = f"Failed to terminate PID {pid}: {exc}"
            raise DocketError(
                msg,
                payload={"run_id": run_id, "status": "cancel_failed", "error": msg},
            ) from exc

        stopped = wait_for_exit(pid)
        if stopped:
            rec = state.complete_run(
                run_id,
                exit_code=130,
                summary=f"Cancelled async run (PID {pid})",
                details={"cancelled": True, "termination": termination},
                status="cancelled",
            )
        else:
            rec = state.update_run(
                run_id,
                status="cancel_requested",
                summary=f"Cancellation requested for PID {pid}, but it is still running",
                details={
                    **rec["details"],
                    "cancelled": False,
                    "cancel_requested": True,
                    "termination": termination,
                },
            )

    return {**rec, "cancelled": stopped}


def health() -> dict[str, Any]:
    """Summarize task health from latest state and run history."""
    config = _config()
    registry = _registry(config)
    try:
        tasks = registry.discover()
    except RegistryError as exc:
        raise DocketError(str(exc)) from exc

    categories: dict[str, list[str]] = {
        "healthy": [],
        "degraded": [],
        "failed": [],
        "stale": [],
        "never_run": [],
    }
    details: dict[str, dict[str, Any]] = {}
    now = datetime.now(timezone.utc)

    with StateStore(config["state_dir"]) as state:
        for name in sorted(tasks):
            task_config = get_task_config(config, name)
            latest = state.get(name)
            runs = state.list_runs(task_name=name, limit=10)
            consecutive_failures = _consecutive_failures(runs)
            task_detail: dict[str, Any] = {
                "last_run": latest,
                "consecutive_failures": consecutive_failures,
            }

            if latest is None:
                category = "never_run"
            elif latest["exit_code"] not in (0, 2):
                category = "failed"
            else:
                category = "healthy"
                interval_seconds = None
                schedule = task_config.get("schedule")
                if isinstance(schedule, str):
                    interval_seconds = _cron_interval_seconds(schedule)
                    task_detail["schedule"] = schedule
                    task_detail["schedule_interval_seconds"] = interval_seconds
                if interval_seconds:
                    last_run = datetime.fromisoformat(latest["last_run"])
                    if last_run.tzinfo is None:
                        last_run = last_run.replace(tzinfo=timezone.utc)
                    age = now - last_run
                    task_detail["seconds_since_last_run"] = round(age.total_seconds(), 3)
                    if age > timedelta(seconds=2 * interval_seconds):
                        category = "stale"
                if category == "healthy" and any(
                    run["status"] in {"failed", "timed_out", "cancelled"}
                    or run["exit_code"] not in (None, 0, 2)
                    for run in runs[1:5]
                ):
                    category = "degraded"

            task_detail["category"] = category
            details[name] = task_detail
            categories[category].append(name)

    summary = ", ".join(
        f"{len(categories[name])} {name.replace('_', ' ')}"
        for name in ("healthy", "degraded", "failed", "stale", "never_run")
    )
    return {**categories, "summary": summary, "details": details}


def doctor(*, agent: bool = False) -> dict[str, Any]:
    """Health check for the Docket installation itself."""
    config = _config()
    checks: list[dict[str, Any]] = []
    all_ok = True

    config_dir = os.path.expanduser("~/.docket")
    config_file = os.path.join(config_dir, "config.yaml")
    if os.path.isfile(config_file):
        checks.append({"check": "config_file", "status": "ok", "path": config_file})
    else:
        checks.append({"check": "config_file", "status": "missing", "path": config_file})
        all_ok = False

    try:
        state = StateStore(config["state_dir"])
        state._connect()
        checks.append({"check": "state_db", "status": "ok", "path": config["state_dir"]})
        state.close()
    except StateError as exc:
        checks.append({"check": "state_db", "status": "error", "error": str(exc)})
        all_ok = False

    try:
        registry = _registry(config)
        tasks = registry.discover()
        checks.append({"check": "task_discovery", "status": "ok", "tasks_found": len(tasks)})
    except RegistryError as exc:
        checks.append({"check": "task_discovery", "status": "error", "error": str(exc)})
        all_ok = False

    tasks_dir = config.get("tasks_dir", "")
    if tasks_dir and os.path.isdir(tasks_dir):
        checks.append({"check": "tasks_dir", "status": "ok", "path": tasks_dir})
    elif tasks_dir:
        checks.append({"check": "tasks_dir", "status": "missing", "path": tasks_dir})

    if agent:
        agent_checks = _agent_doctor_checks(config)
        agent_ok = all(check["ok"] for check in agent_checks)
        all_ok = all_ok and agent_ok
        return {
            "ok": all_ok,
            "healthy": all_ok,
            "checks": agent_checks,
            "installation_checks": checks,
        }

    return {"ok": all_ok, "checks": checks}


def _agent_doctor_checks(config: dict[str, Any]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []

    try:
        load_config()
        checks.append({"name": "config_valid", "ok": True})
    except ConfigError as exc:
        checks.append({"name": "config_valid", "ok": False, "detail": str(exc)})

    try:
        with StateStore(config["state_dir"]) as state:
            state.list_all()
        checks.append({"name": "state_db_accessible", "ok": True})
    except StateError as exc:
        checks.append({"name": "state_db_accessible", "ok": False, "detail": str(exc)})

    try:
        registry = _registry(config)
        tasks = registry.discover()
        checks.append({"name": "task_discovery", "ok": True, "detail": f"{len(tasks)} tasks"})
    except RegistryError as exc:
        checks.append({"name": "task_discovery", "ok": False, "detail": str(exc)})
        tasks = {}

    task_configs = config.get("tasks", {})
    task_configs = task_configs if isinstance(task_configs, dict) else {}
    with StateStore(config["state_dir"]) as state:
        for task_name in sorted(tasks):
            task_config = get_task_config(config, task_name)
            if task_config.get("type") == "command":
                ok, detail = _command_exists(task_config.get("command"))
                checks.append(
                    {"name": f"{task_name}:command_exists", "ok": ok, "detail": detail}
                )

            if task_config.get("tool") == "rclone" and isinstance(task_config.get("remote"), str):
                ok, detail = _rclone_remote_exists(task_config["remote"])
                checks.append(
                    {"name": f"{task_name}:rclone_remote_exists", "ok": ok, "detail": detail}
                )

            for env_name in task_config.get("required_env", []):
                ok = bool(os.environ.get(env_name))
                detail = "set" if ok else "missing or empty"
                checks.append(
                    {"name": f"{task_name}:env:{env_name}", "ok": ok, "detail": detail}
                )

            if "schedule" in task_config:
                ok, detail = _timer_active(task_name)
                checks.append({"name": f"{task_name}:timer_active", "ok": ok, "detail": detail})

            runs = state.list_runs(task_name=task_name, limit=3)
            if len(runs) == 3 and all(
                run["status"] in {"failed", "timed_out", "cancelled"}
                or run["exit_code"] not in (None, 0, 2)
                for run in runs
            ):
                checks.append(
                    {
                        "name": f"{task_name}:last_3_runs_all_failed",
                        "ok": False,
                        "detail": f"3 consecutive failures, last at {runs[0]['finished_at']}",
                    }
                )
            elif runs:
                checks.append(
                    {
                        "name": f"{task_name}:failure_pattern",
                        "ok": True,
                        "detail": "no last-3 failure streak",
                    }
                )

    for task_name in sorted(set(task_configs) - set(tasks)):
        checks.append(
            {"name": f"{task_name}:configured_task_discovered", "ok": False, "detail": "not found"}
        )

    return checks


def _command_exists(command_config: Any) -> tuple[bool, str]:
    command = command_config[0] if isinstance(command_config, list) else command_config
    if not isinstance(command, str) or not command:
        return False, "command is missing"
    path = Path(command)
    if path.is_absolute() or path.parent != Path("."):
        return (path.exists() and os.access(path, os.X_OK), f"{command} checked")
    found = shutil.which(command)
    if found:
        return True, f"{found} found"
    return False, f"{command} not found in PATH"


def _rclone_remote_exists(remote: str) -> tuple[bool, str]:
    import re

    remote_name = remote.split(":", 1)[0]
    if not remote_name:
        return False, "remote is empty"
    rclone = shutil.which("rclone")
    if not rclone:
        return False, "rclone not found in PATH"
    try:
        completed = subprocess.run(
            [rclone, "config", "show"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, "rclone config show timed out"
    if completed.returncode != 0:
        return False, completed.stderr.strip() or "rclone config show failed"
    pattern = re.compile(rf"^\[{re.escape(remote_name)}\]\s*$", re.MULTILINE)
    if pattern.search(completed.stdout):
        return True, f"remote '{remote_name}' found"
    return False, f"remote '{remote_name}' not found"


def _timer_active(task_name: str) -> tuple[bool, str]:
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return False, "systemctl not found"
    unit = f"docket-{task_name}.timer"
    completed = subprocess.run(
        [systemctl, "--user", "is-active", unit],
        capture_output=True,
        text=True,
        timeout=5,
        check=False,
    )
    status_text = completed.stdout.strip() or completed.stderr.strip() or "unknown"
    return completed.returncode == 0 and status_text == "active", f"{unit}: {status_text}"


# ---------------------------------------------------------------------------
# run_task — the most complex operation
# ---------------------------------------------------------------------------


def _run_dependencies(
    *,
    task_name: str,
    task_config: dict[str, Any],
    dry_run: bool,
    spawn_async: Callable[..., subprocess.Popen[bytes]],
) -> tuple[bool, list[dict[str, Any]], str | None]:
    dependencies = task_config.get("depends_on", [])
    if not dependencies:
        return True, [], None
    if not isinstance(dependencies, list):
        return False, [], "depends_on must be a list"

    results: list[dict[str, Any]] = []
    for dependency in dependencies:
        if not isinstance(dependency, str):
            return False, results, "depends_on must contain only task names"
        try:
            payload = run_task(
                dependency,
                dry_run=dry_run,
                force=True,
                spawn_async=spawn_async,
            )
        except DocketError as exc:
            payload = exc.payload if isinstance(exc.payload, dict) else {}
            payload = {**payload}
            payload.setdefault("task", dependency)
            payload.setdefault("exit_code", exc.exit_code)
            payload.setdefault("status", "failed")
            results.append(payload)
            return False, results, f'predecessor "{dependency}" failed'
        payload = {**payload}
        payload.setdefault("task", dependency)
        results.append(payload)
        succeeded = payload.get("exit_code") in (0, 2) and payload.get("status") != "failed"
        if not succeeded:
            return False, results, f'predecessor "{dependency}" failed'
    return True, results, None


def run_task(
    task_name: str,
    *,
    dry_run: bool = False,
    force: bool = False,
    async_mode: bool = False,
    existing_run_id: str | None = None,
    skip_daily_guard: bool = False,
    spawn_async: Callable[..., subprocess.Popen[bytes]] | None = None,
) -> dict[str, Any]:
    """Execute a task and return a structured result.

    The returned dict mirrors the JSON payload produced by ``docket run``
    in ``--json`` mode. ``exit_code`` (0 success, 1 failure, 2 dry-run)
    is included for callers that need to surface it.

    Raises :class:`DocketError` for unrecoverable conditions: unknown
    task, schema validation failure, or a failed async spawn.
    """
    spawn = spawn_async or spawn_async_run
    config = _config()
    registry = _registry(config)

    try:
        task_cls = registry.get(task_name)
    except RegistryError as exc:
        raise DocketError(str(exc)) from exc

    task = task_cls()
    task_config = get_task_config(config, task_name)
    try:
        validate_task_schema(task_name, task_config, getattr(task_cls, "schema", {}))
    except SchemaError as exc:
        raise DocketError(str(exc)) from exc

    if not existing_run_id:
        deps_ok, dep_results, skip_reason = _run_dependencies(
            task_name=task_name,
            task_config=task_config,
            dry_run=dry_run,
            spawn_async=spawn,
        )
        if not deps_ok:
            details = {"reason": skip_reason, "dependencies": dep_results}
            with StateStore(config["state_dir"]) as state:
                run_record = state.record(
                    task_name=task_name,
                    exit_code=0,
                    summary=f"Skipped: {skip_reason}",
                    details=details,
                    dry_run=dry_run,
                    status="skipped",
                )
            return {
                "ok": False,
                "status": "skipped",
                "task": task_name,
                "run_id": run_record["run_id"],
                "summary": f"Skipped: {skip_reason}",
                "details": details,
                "dry_run": dry_run,
                "exit_code": 0,
            }

    with StateStore(config["state_dir"]) as state:
        duration_stats = state.duration_stats(task_name)

        if not dry_run and not force and not skip_daily_guard:
            prev = state.get(task_name)
            if prev and prev["exit_code"] == 0 and not prev["dry_run"]:
                last = datetime.fromisoformat(prev["last_run"])
                now = datetime.now(timezone.utc)
                if last.date() == now.date():
                    return {
                        "skipped": True,
                        "reason": "already_ran_today",
                        "task": task_name,
                        "exit_code": 0,
                    }

        if async_mode:
            recommendation = _poll_recommendation(duration_stats)
            run_record = state.start_run(
                task_name,
                summary="Task started asynchronously",
                details={"mode": "async", **recommendation},
                dry_run=dry_run,
            )
            log_path = _log_path(config, run_record["run_id"])
            try:
                proc = spawn(
                    task_name,
                    run_id=run_record["run_id"],
                    dry_run=dry_run,
                    force=force,
                    log_path=log_path,
                )
            except OSError as exc:
                state.complete_run(
                    run_record["run_id"],
                    exit_code=1,
                    summary=f"Failed to start async task: {exc}",
                    details={"error": str(exc), "mode": "async"},
                    dry_run=dry_run,
                    status="failed",
                )
                raise DocketError(f"Failed to start async task: {exc}") from exc

            run_record = state.update_run(
                run_record["run_id"],
                status="running",
                summary="Task running asynchronously",
                details={
                    "mode": "async",
                    "pid": proc.pid,
                    "log_path": str(log_path),
                    **recommendation,
                },
            )
            payload: dict[str, Any] = {
                "ok": True,
                "status": "running",
                "task": task_name,
                "run_id": run_record["run_id"],
                "pid": proc.pid,
                "started_at": run_record["started_at"],
                "log_path": str(log_path),
                "status_command": f"docket --json status --run-id {run_record['run_id']}",
                "wait_command": f"docket --json wait {run_record['run_id']}",
                "logs_command": f"docket logs {run_record['run_id']}",
                "exit_code": 0,
                **recommendation,
            }
            if duration_stats.get("sample_size", 0) > 0:
                payload["typical_duration"] = duration_stats
            return payload

        lock: LockFile | None = None
        if not force:
            lock = LockFile(task_name=task_name)
            if lock.is_locked():
                lock.clean_stale()
                if not lock.acquire():
                    pid = lock._read_pid()
                    msg = (
                        f"Task '{task_name}' is already running (PID {pid})"
                        if pid
                        else f"Task '{task_name}' is already running"
                    )
                    if existing_run_id:
                        state.complete_run(
                            existing_run_id,
                            exit_code=1,
                            summary=msg,
                            details={"error": msg},
                            status="failed",
                        )
                    return {
                        "ok": False,
                        "error": msg,
                        "task": task_name,
                        "exit_code": 1,
                        "status": "locked",
                    }
            else:
                if not lock.acquire():
                    msg = f"Cannot acquire lock for '{task_name}'"
                    if existing_run_id:
                        state.complete_run(
                            existing_run_id,
                            exit_code=1,
                            summary=msg,
                            details={"error": msg},
                            status="failed",
                        )
                    return {
                        "ok": False,
                        "error": msg,
                        "task": task_name,
                        "exit_code": 1,
                        "status": "locked",
                    }

        try:
            started_at = datetime.now(timezone.utc)
            max_retries = int(task_config.get("retry", 0))
            backoff_base = float(task_config.get("backoff_base", 2.0))
            retry_count = 0
            result: TaskResult | None = None
            hook_results: list[tuple[str, int, str, str]] | None = None
            env_snapshot = _set_run_env(
                run_id=existing_run_id,
                task_name=task_name,
                state_path=config["state_dir"],
            )

            try:
                if dry_run:
                    result = task.dry_run(task_config)
                elif max_retries > 0:
                    attempt_counter = [0]

                    class TaskExecutionError(Exception):
                        def __init__(self, result: TaskResult) -> None:
                            self.result = result
                            super().__init__(result.summary)

                    def _run_and_track() -> TaskResult:
                        res = task.run(task_config)
                        if res.ok:
                            return res
                        attempt_counter[0] += 1
                        raise TaskExecutionError(res)

                    try:
                        result = retry(
                            _run_and_track,
                            max_retries=max_retries,
                            backoff_base=backoff_base,
                        )
                    except TaskExecutionError as exc:
                        result = exc.result
                    retry_count = attempt_counter[0]
                else:
                    result = task.run(task_config)

            except Exception as exc:
                result = TaskResult(ok=False, summary=f"Task raised unexpected error: {exc}")
            finally:
                _restore_env(env_snapshot)

            assert result is not None

            if existing_run_id:
                run_record = state.complete_run(
                    existing_run_id,
                    exit_code=result.exit_code,
                    summary=result.summary,
                    details=result.details,
                    dry_run=result.dry_run,
                )
            else:
                run_record = state.record(
                    task_name=task_name,
                    exit_code=result.exit_code,
                    summary=result.summary,
                    details=result.details,
                    dry_run=result.dry_run,
                    started_at=started_at,
                )
            _record_result_events(state, run_record, result)

            try:
                hooks = Hooks(task_config)
                hook_type = "on_success" if result.ok else "on_failure"
                hook_results = hooks.run_hooks(hook_type, result, run_record)
                hook_results.extend(hooks.run_hooks("on_complete", result, run_record))
                notify_event = "success" if result.ok else "failure"
                hook_results.extend(hooks.run_notifications(notify_event, result, run_record))
            except Exception:
                logger.exception("Hook execution failed")
                hook_results = None

            payload = {
                "ok": result.ok,
                "status": "succeeded" if result.ok else "failed",
                "summary": result.summary,
                "details": result.details,
                "dry_run": result.dry_run,
                "exit_code": result.exit_code,
                "retry_count": retry_count,
                "run_id": run_record["run_id"],
                "task": run_record["task_name"],
                "started_at": run_record["started_at"],
                "finished_at": run_record["finished_at"],
                "duration_seconds": run_record["duration_seconds"],
            }
            if duration_stats.get("sample_size", 0) > 0:
                payload["typical_duration"] = duration_stats
            if hook_results:
                payload["hooks"] = [
                    {"command": cmd, "exit_code": ec, "stdout": out, "stderr": err}
                    for cmd, ec, out, err in hook_results
                ]
            return payload
        finally:
            if lock is not None:
                lock.release()
