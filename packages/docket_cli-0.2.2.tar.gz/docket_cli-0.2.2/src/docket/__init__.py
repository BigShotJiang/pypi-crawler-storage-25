"""Docket — Deterministic task runner for AI agents."""

__version__ = "0.2.2"
