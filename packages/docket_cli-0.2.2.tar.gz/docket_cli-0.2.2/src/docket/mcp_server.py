"""MCP stdio server for Docket."""

from __future__ import annotations

import os
from typing import Any

from docket import api
from docket.api import DocketAPIError

# Substrings that mark a config key as secret-shaped. We redact rather than
# return raw values via MCP because an LLM client can be coerced (prompt
# injection in tool output) into exfiltrating anything it sees.
SECRET_KEY_SUBSTRINGS = (
    "token",
    "secret",
    "password",
    "passwd",
    "api_key",
    "apikey",
    "webhook_url",
    "authorization",
    "auth_token",
    "auth_key",
    "credentials",
    "private_key",
)
# Whole-key matches that are always treated as a bag of secrets.
SECRET_CONTAINER_KEYS = {"env"}


def _redact(key: str | None, value: Any) -> Any:
    """Recursively redact secret-shaped values from a JSON-able object."""
    if isinstance(value, dict):
        return {k: _redact(k, v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(key, v) for v in value]
    if isinstance(key, str):
        lower = key.lower()
        if lower in SECRET_CONTAINER_KEYS:
            # Inside an env mapping every value is potentially a secret.
            return "<redacted>" if value else value
        if any(pat in lower for pat in SECRET_KEY_SUBSTRINGS):
            return "<redacted>" if value else value
    return value


def _redact_task_metadata(meta: dict[str, Any]) -> dict[str, Any]:
    cleaned = dict(meta)
    if isinstance(cleaned.get("config"), dict):
        cleaned["config"] = {k: _redact(k, v) for k, v in cleaned["config"].items()}
    return cleaned


def _destructive_allowed() -> bool:
    return os.environ.get("DOCKET_MCP_ALLOW_DESTRUCTIVE", "").lower() in {
        "1",
        "true",
        "yes",
        "allow",
    }


def _check_destructive(task_name: str, dry_run: bool) -> None:
    """Refuse non-dry-run execution of destructive tasks unless explicitly opted in."""
    if dry_run or _destructive_allowed():
        return
    try:
        meta = api.describe_task(task_name)
    except DocketAPIError:
        return  # Unknown task — let api.run_task surface the real error.
    if meta.get("destructive"):
        raise DocketAPIError(
            f"Refusing to run destructive task '{task_name}' over MCP. "
            f"Set DOCKET_MCP_ALLOW_DESTRUCTIVE=1 in the server environment "
            f"or invoke with dry_run=True.",
            exit_code=1,
            payload={"task": task_name, "status": "destructive_blocked"},
        )


def _server() -> Any:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:  # pragma: no cover - exercised without optional extra
        raise RuntimeError("Install MCP support with: pip install docket[mcp]") from exc

    server = FastMCP("docket")

    @server.tool()
    def docket_list_tasks() -> list[dict[str, Any]]:
        """List discovered Docket tasks and latest task state."""
        return api.list_tasks()

    @server.tool()
    def docket_describe_task(task_name: str) -> dict[str, Any]:
        """Describe a Docket task. Secret-shaped config values are redacted."""
        return _redact_task_metadata(api.describe_task(task_name))

    @server.tool()
    def docket_run_task(
        task_name: str,
        dry_run: bool = False,
        force: bool = False,
    ) -> dict[str, Any]:
        """Run a Docket task synchronously."""
        _check_destructive(task_name, dry_run)
        return api.run_task(task_name, dry_run=dry_run, force=force)

    @server.tool()
    def docket_run_task_async(
        task_name: str,
        dry_run: bool = False,
        force: bool = False,
    ) -> dict[str, Any]:
        """Start a Docket task asynchronously."""
        _check_destructive(task_name, dry_run)
        return api.run_task_async(task_name, dry_run=dry_run, force=force)

    @server.tool()
    def docket_task_status(
        task_name: str | None = None,
        run_id: str | None = None,
    ) -> Any:
        """Return task or run status."""
        return api.task_status(task_name, run_id=run_id)

    @server.tool()
    def docket_task_runs(
        task_name: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Return recent Docket run history."""
        return api.task_runs(task_name, limit=limit)

    @server.tool()
    def docket_wait_run(
        run_id: str,
        timeout: float | None = None,
        poll_interval: float = 1.0,
    ) -> dict[str, Any]:
        """Wait for a Docket run to finish."""
        return api.wait_run(run_id, timeout=timeout, poll_interval=poll_interval)

    @server.tool()
    def docket_run_logs(run_id: str, tail: int | None = None) -> dict[str, Any]:
        """Return captured logs for an async Docket run."""
        return api.run_logs(run_id, tail=tail)

    @server.tool()
    def docket_run_events(run_id: str, limit: int = 500) -> list[dict[str, Any]]:
        """Return structured events for a Docket run."""
        return api.run_events(run_id, limit=limit)

    @server.tool()
    def docket_cancel_run(run_id: str) -> dict[str, Any]:
        """Cancel a running async Docket task."""
        return api.cancel_run(run_id)

    @server.tool()
    def docket_capabilities() -> dict[str, Any]:
        """Return Docket agent-facing capabilities."""
        return api.capabilities()

    return server


def main() -> None:
    """Run the Docket MCP server over stdio."""
    _server().run()


if __name__ == "__main__":
    main()
