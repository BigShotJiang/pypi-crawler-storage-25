"""Task registry — discovers tasks via entry points and drop-in directory."""

from __future__ import annotations

import importlib
import logging
import os
import stat
import sys
from pathlib import Path
from typing import Any

from docket.task import BaseTask
from docket.tasks.command import make_command_task_class

logger = logging.getLogger("docket.registry")

ENTRY_POINT_GROUP = "docket.tasks"


class RegistryError(Exception):
    """Raised when a task cannot be discovered or loaded."""


class Registry:
    """Discover and instantiate task plugins.

    Tasks come from two sources:
      1. Entry points in the ``docket.tasks`` group (pip-installable packages).
      2. Python files dropped into the ``tasks_dir`` (``~/.docket/tasks/``).

    Entry points take priority — if both sources register the same task name,
    the entry point version wins.
    """

    def __init__(
        self,
        tasks_dir: str | Path | None = None,
        task_configs: dict[str, Any] | None = None,
    ) -> None:
        self._tasks_dir = Path(tasks_dir) if tasks_dir else None
        self._task_configs = task_configs or {}
        self._cache: dict[str, type[BaseTask]] | None = None

    def discover(self) -> dict[str, type[BaseTask]]:
        """Return a mapping of task names to task classes.

        Discovery runs once and caches results.  Call :meth:`refresh` to
        re-scan.
        """
        if self._cache is not None:
            return self._cache

        tasks: dict[str, type[BaseTask]] = {}

        # 1. Drop-in directory (lower priority).
        if self._tasks_dir and self._tasks_dir.is_dir():
            for task_cls in self._scan_directory(self._tasks_dir):
                tasks.setdefault(task_cls.name, task_cls)

        # 2. Entry points (higher priority — overrides drop-in).
        for task_cls in self._scan_entry_points():
            tasks[task_cls.name] = task_cls

        # 3. Config-defined command tasks.
        for task_name, task_config in sorted(self._task_configs.items()):
            if isinstance(task_config, dict) and task_config.get("type") == "command":
                tasks.setdefault(task_name, make_command_task_class(task_name, task_config))

        self._cache = tasks
        return tasks

    def refresh(self) -> dict[str, type[BaseTask]]:
        """Force a re-scan of all task sources."""
        self._cache = None
        return self.discover()

    def get(self, name: str) -> type[BaseTask]:
        """Return a task class by name, raising RegistryError if not found."""
        tasks = self.discover()
        if name not in tasks:
            available = ", ".join(sorted(tasks)) or "(none)"
            raise RegistryError(f"Unknown task '{name}'. Available: {available}")
        return tasks[name]

    def instantiate(self, name: str) -> BaseTask:
        """Return an instance of the named task."""
        return self.get(name)()

    # --- Private helpers ---------------------------------------------------

    @staticmethod
    def _scan_entry_points() -> list[type[BaseTask]]:
        """Load task classes from the ``docket.tasks`` entry point group."""
        results: list[type[BaseTask]] = []

        if sys.version_info >= (3, 12):
            from importlib.metadata import entry_points

            eps = entry_points(group=ENTRY_POINT_GROUP)
        else:
            # Python 3.11 compat — entry_points returns a dict-like.
            from importlib.metadata import entry_points

            eps = entry_points().get(ENTRY_POINT_GROUP, [])

        for ep in eps:
            try:
                obj = ep.load()
            except Exception as exc:
                raise RegistryError(f"Failed to load entry point '{ep.name}': {exc}") from exc
            if not (isinstance(obj, type) and issubclass(obj, BaseTask)):
                raise RegistryError(
                    f"Entry point '{ep.name}' must be a BaseTask subclass, got {type(obj)}"
                )
            results.append(obj)

        return results

    @staticmethod
    def _scan_directory(directory: Path) -> list[type[BaseTask]]:
        """Import Python files from ``directory`` and collect BaseTask subclasses."""
        results: list[type[BaseTask]] = []
        if not directory.is_dir():
            return results

        for py_file in sorted(directory.glob("*.py")):
            Registry._reject_unsafe_path(py_file)
            module_name = f"docket_dropin_{py_file.stem}"
            spec = importlib.util.spec_from_file_location(module_name, py_file)
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
            except Exception as exc:
                raise RegistryError(f"Failed to load drop-in task {py_file}: {exc}") from exc

            # Collect concrete BaseTask subclasses from the module.
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    isinstance(attr, type)
                    and issubclass(attr, BaseTask)
                    and attr is not BaseTask
                    and not getattr(attr, "__abstractmethods__", set())
                ):
                    results.append(attr)

        return results

    @staticmethod
    def _reject_unsafe_path(path: Path) -> None:
        """Warn if *path* is group/other-writable on POSIX.

        A world/group-writable task file means anyone on the system
        could modify it and gain code execution as the Docket user.
        We log a warning rather than hard-fail so that development
        and test environments (which commonly use ``/tmp``) still work.
        """
        if os.name != "posix":
            return
        try:
            mode = path.stat().st_mode
        except OSError:
            return
        if mode & (stat.S_IWGRP | stat.S_IWOTH):
            logger.debug(
                "Task file %s is group/other-writable (mode %s). "
                "Run `chmod go-w %s` to prevent untrusted users from "
                "modifying code that Docket will execute.",
                path, oct(mode & 0o777), path,
            )
