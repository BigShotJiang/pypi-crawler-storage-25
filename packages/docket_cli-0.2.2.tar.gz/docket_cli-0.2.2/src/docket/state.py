"""SQLite state store for latest task state and immutable run history."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS task_runs (
    task_name   TEXT PRIMARY KEY,
    run_id      TEXT,
    started_at  TEXT,
    last_run    TEXT NOT NULL,
    duration_seconds REAL,
    exit_code   INTEGER NOT NULL,
    summary     TEXT NOT NULL,
    details     TEXT DEFAULT '{}',
    dry_run     INTEGER NOT NULL DEFAULT 0
)
"""

CREATE_HISTORY_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS task_run_history (
    run_id      TEXT PRIMARY KEY,
    task_name   TEXT NOT NULL,
    status      TEXT NOT NULL,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    duration_seconds REAL,
    exit_code   INTEGER,
    summary     TEXT NOT NULL DEFAULT '',
    details     TEXT DEFAULT '{}',
    dry_run     INTEGER NOT NULL DEFAULT 0
)
"""

CREATE_HISTORY_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_task_run_history_task_started
ON task_run_history (task_name, started_at DESC)
"""

CREATE_EVENTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS task_run_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id      TEXT NOT NULL,
    task_name   TEXT NOT NULL,
    event_index INTEGER NOT NULL,
    timestamp   TEXT NOT NULL,
    event_type  TEXT,
    event       TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES task_run_history(run_id)
)
"""

CREATE_EVENTS_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_task_run_events_run_index
ON task_run_events (run_id, event_index)
"""


class StateError(Exception):
    """Raised when the state store cannot be initialised or queried."""


class StateStore:
    """SQLite-backed store for latest task state and full run history."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        self._conn: sqlite3.Connection | None = None

    def _connect(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self._db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute(CREATE_TABLE_SQL)
            self._conn.execute(CREATE_HISTORY_TABLE_SQL)
            self._conn.execute(CREATE_HISTORY_INDEX_SQL)
            self._conn.execute(CREATE_EVENTS_TABLE_SQL)
            self._conn.execute(CREATE_EVENTS_INDEX_SQL)
            self._migrate_latest_table()
            self._conn.commit()
        except sqlite3.Error as exc:
            raise StateError(f"Cannot open state database {self._db_path}: {exc}") from exc
        return self._conn

    def _migrate_latest_table(self) -> None:
        """Add latest-table columns introduced after the initial schema."""
        assert self._conn is not None
        columns = {
            row["name"]
            for row in self._conn.execute("PRAGMA table_info(task_runs)").fetchall()
        }
        migrations = {
            "run_id": "ALTER TABLE task_runs ADD COLUMN run_id TEXT",
            "started_at": "ALTER TABLE task_runs ADD COLUMN started_at TEXT",
            "duration_seconds": "ALTER TABLE task_runs ADD COLUMN duration_seconds REAL",
        }
        for column, sql in migrations.items():
            if column not in columns:
                self._conn.execute(sql)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> StateStore:
        self._connect()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def record(
        self,
        task_name: str,
        exit_code: int,
        summary: str,
        details: dict[str, Any] | None = None,
        dry_run: bool = False,
        *,
        started_at: datetime | str | None = None,
        finished_at: datetime | str | None = None,
        status: str | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        """Persist a task run and update the latest state for the task."""
        conn = self._connect()
        finished_dt = _coerce_datetime(finished_at) or datetime.now(timezone.utc)
        started_dt = _coerce_datetime(started_at) or finished_dt
        duration_seconds = max((finished_dt - started_dt).total_seconds(), 0.0)
        finished = finished_dt.isoformat()
        started = started_dt.isoformat()
        run_id = run_id or _new_run_id(finished_dt)
        run_status = status or ("succeeded" if exit_code in (0, 2) else "failed")
        details_json = json.dumps(details or {})

        conn.execute(
            """
            INSERT INTO task_runs (
                task_name, run_id, started_at, last_run, duration_seconds,
                exit_code, summary, details, dry_run
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(task_name) DO UPDATE SET
                run_id = excluded.run_id,
                started_at = excluded.started_at,
                last_run = excluded.last_run,
                duration_seconds = excluded.duration_seconds,
                exit_code = excluded.exit_code,
                summary = excluded.summary,
                details = excluded.details,
                dry_run = excluded.dry_run
            """,
            (
                task_name,
                run_id,
                started,
                finished,
                duration_seconds,
                exit_code,
                summary,
                details_json,
                int(dry_run),
            ),
        )
        conn.execute(
            """
            INSERT INTO task_run_history (
                run_id, task_name, status, started_at, finished_at, duration_seconds,
                exit_code, summary, details, dry_run
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(run_id) DO UPDATE SET
                task_name = excluded.task_name,
                status = excluded.status,
                started_at = excluded.started_at,
                finished_at = excluded.finished_at,
                duration_seconds = excluded.duration_seconds,
                exit_code = excluded.exit_code,
                summary = excluded.summary,
                details = excluded.details,
                dry_run = excluded.dry_run
            """,
            (
                run_id,
                task_name,
                run_status,
                started,
                finished,
                duration_seconds,
                exit_code,
                summary,
                details_json,
                int(dry_run),
            ),
        )
        conn.commit()

        rec = self.get_run(run_id)
        assert rec is not None
        return rec

    def start_run(
        self,
        task_name: str,
        *,
        summary: str = "Task started",
        details: dict[str, Any] | None = None,
        dry_run: bool = False,
        started_at: datetime | str | None = None,
    ) -> dict[str, Any]:
        """Create a running history record without updating latest task state."""
        conn = self._connect()
        started_dt = _coerce_datetime(started_at) or datetime.now(timezone.utc)
        started = started_dt.isoformat()
        run_id = _new_run_id(started_dt)
        conn.execute(
            """
            INSERT INTO task_run_history (
                run_id, task_name, status, started_at, finished_at, duration_seconds,
                exit_code, summary, details, dry_run
            )
            VALUES (?, ?, 'running', ?, NULL, NULL, NULL, ?, ?, ?)
            """,
            (
                run_id,
                task_name,
                started,
                summary,
                json.dumps(details or {}),
                int(dry_run),
            ),
        )
        conn.commit()
        rec = self.get_run(run_id)
        assert rec is not None
        return rec

    def complete_run(
        self,
        run_id: str,
        *,
        exit_code: int,
        summary: str,
        details: dict[str, Any] | None = None,
        dry_run: bool | None = None,
        status: str | None = None,
        finished_at: datetime | str | None = None,
    ) -> dict[str, Any]:
        """Complete an existing running run and update latest task state."""
        existing = self.get_run(run_id)
        if existing is None:
            raise StateError(f"Unknown run_id: {run_id}")
        merged_details = {**existing["details"], **(details or {})}
        return self.record(
            task_name=existing["task_name"],
            exit_code=exit_code,
            summary=summary,
            details=merged_details,
            dry_run=existing["dry_run"] if dry_run is None else dry_run,
            started_at=existing["started_at"],
            finished_at=finished_at,
            status=status,
            run_id=run_id,
        )

    def update_run(
        self,
        run_id: str,
        *,
        status: str | None = None,
        summary: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update a non-terminal run record without touching latest task state."""
        existing = self.get_run(run_id)
        if existing is None:
            raise StateError(f"Unknown run_id: {run_id}")

        next_status = status or existing["status"]
        next_summary = summary if summary is not None else existing["summary"]
        next_details = details if details is not None else existing["details"]
        conn = self._connect()
        conn.execute(
            """
            UPDATE task_run_history
            SET status = ?, summary = ?, details = ?
            WHERE run_id = ?
            """,
            (next_status, next_summary, json.dumps(next_details), run_id),
        )
        conn.commit()
        rec = self.get_run(run_id)
        assert rec is not None
        return rec

    def get(self, task_name: str) -> dict[str, Any] | None:
        """Return the latest run record for *task_name*, or ``None``."""
        conn = self._connect()
        row = conn.execute(
            "SELECT task_name, run_id, started_at, last_run, duration_seconds, "
            "exit_code, summary, details, dry_run "
            "FROM task_runs WHERE task_name = ?",
            (task_name,),
        ).fetchone()
        if row is None:
            return None
        return _latest_row_to_dict(row)

    def list_all(self) -> list[dict[str, Any]]:
        """Return all latest task run records."""
        conn = self._connect()
        rows = conn.execute(
            "SELECT task_name, run_id, started_at, last_run, duration_seconds, "
            "exit_code, summary, details, dry_run "
            "FROM task_runs ORDER BY task_name"
        ).fetchall()
        return [_latest_row_to_dict(r) for r in rows]

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """Return one historical run by ID."""
        conn = self._connect()
        row = conn.execute(
            """
            SELECT run_id, task_name, status, started_at, finished_at,
                   duration_seconds, exit_code, summary, details, dry_run
            FROM task_run_history
            WHERE run_id = ?
            """,
            (run_id,),
        ).fetchone()
        if row is None:
            return None
        return _history_row_to_dict(row)

    def list_runs(self, task_name: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
        """Return recent historical runs, newest first."""
        conn = self._connect()
        safe_limit = max(1, min(int(limit), 500))
        if task_name:
            rows = conn.execute(
                """
                SELECT run_id, task_name, status, started_at, finished_at,
                       duration_seconds, exit_code, summary, details, dry_run
                FROM task_run_history
                WHERE task_name = ?
                ORDER BY started_at DESC
                LIMIT ?
                """,
                (task_name, safe_limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT run_id, task_name, status, started_at, finished_at,
                       duration_seconds, exit_code, summary, details, dry_run
                FROM task_run_history
                ORDER BY started_at DESC
                LIMIT ?
                """,
                (safe_limit,),
            ).fetchall()
        return [_history_row_to_dict(r) for r in rows]

    def duration_stats(self, task_name: str, limit: int = 20) -> dict[str, Any]:
        """Return simple historical duration stats for successful real runs."""
        conn = self._connect()
        rows = conn.execute(
            """
            SELECT duration_seconds
            FROM task_run_history
            WHERE task_name = ?
              AND status = 'succeeded'
              AND dry_run = 0
              AND duration_seconds IS NOT NULL
            ORDER BY started_at DESC
            LIMIT ?
            """,
            (task_name, max(1, min(int(limit), 500))),
        ).fetchall()
        durations = sorted(float(r["duration_seconds"]) for r in rows)
        if not durations:
            return {"sample_size": 0}
        return {
            "sample_size": len(durations),
            "median_seconds": _percentile(durations, 0.5),
            "p90_seconds": _percentile(durations, 0.9),
            "average_seconds": round(sum(durations) / len(durations), 3),
        }

    def add_events(
        self,
        run_id: str,
        events: list[dict[str, Any]],
        *,
        replace: bool = False,
    ) -> list[dict[str, Any]]:
        """Append structured JSONL-style events for a historical run."""
        if not events:
            return []
        run = self.get_run(run_id)
        if run is None:
            raise StateError(f"Unknown run_id: {run_id}")

        conn = self._connect()
        if replace:
            conn.execute("DELETE FROM task_run_events WHERE run_id = ?", (run_id,))
            next_index = 1
        else:
            row = conn.execute(
                "SELECT COALESCE(MAX(event_index), 0) AS max_index "
                "FROM task_run_events WHERE run_id = ?",
                (run_id,),
            ).fetchone()
            next_index = int(row["max_index"]) + 1

        timestamp = datetime.now(timezone.utc).isoformat()
        rows = []
        for offset, event in enumerate(events):
            event_index = next_index + offset
            event_type = event.get("event") or event.get("type") or event.get("status")
            rows.append(
                (
                    run_id,
                    run["task_name"],
                    event_index,
                    str(event.get("timestamp", timestamp)),
                    str(event_type) if event_type is not None else None,
                    json.dumps(event),
                )
            )
        conn.executemany(
            """
            INSERT INTO task_run_events (
                run_id, task_name, event_index, timestamp, event_type, event
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        conn.commit()
        return self.list_events(run_id)

    def list_events(self, run_id: str, limit: int = 500) -> list[dict[str, Any]]:
        """Return structured events for a run, ordered by event index."""
        conn = self._connect()
        safe_limit = max(1, min(int(limit), 5000))
        rows = conn.execute(
            """
            SELECT run_id, task_name, event_index, timestamp, event_type, event
            FROM task_run_events
            WHERE run_id = ?
            ORDER BY event_index
            LIMIT ?
            """,
            (run_id, safe_limit),
        ).fetchall()
        return [_event_row_to_dict(row) for row in rows]

    def delete(self, task_name: str) -> bool:
        """Delete a task's latest run record. Returns True if a row was removed."""
        conn = self._connect()
        cursor = conn.execute("DELETE FROM task_runs WHERE task_name = ?", (task_name,))
        conn.commit()
        return cursor.rowcount > 0


def _new_run_id(dt: datetime) -> str:
    stamp = dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{stamp}-{uuid.uuid4().hex[:8]}"


def _coerce_datetime(value: datetime | str | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _json_loads(value: str | None) -> dict[str, Any]:
    if not value:
        return {}
    loaded = json.loads(value)
    return loaded if isinstance(loaded, dict) else {"value": loaded}


def _latest_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "task_name": row["task_name"],
        "run_id": row["run_id"],
        "started_at": row["started_at"],
        "last_run": row["last_run"],
        "duration_seconds": row["duration_seconds"],
        "exit_code": row["exit_code"],
        "summary": row["summary"],
        "details": _json_loads(row["details"]),
        "dry_run": bool(row["dry_run"]),
    }


def _history_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "run_id": row["run_id"],
        "task_name": row["task_name"],
        "status": row["status"],
        "started_at": row["started_at"],
        "finished_at": row["finished_at"],
        "duration_seconds": row["duration_seconds"],
        "exit_code": row["exit_code"],
        "summary": row["summary"],
        "details": _json_loads(row["details"]),
        "dry_run": bool(row["dry_run"]),
    }


def _event_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "run_id": row["run_id"],
        "task_name": row["task_name"],
        "event_index": row["event_index"],
        "timestamp": row["timestamp"],
        "event_type": row["event_type"],
        "event": _json_loads(row["event"]),
    }


def _percentile(values: list[float], percentile: float) -> float:
    if len(values) == 1:
        return round(values[0], 3)
    index = (len(values) - 1) * percentile
    lower = int(index)
    upper = min(lower + 1, len(values) - 1)
    weight = index - lower
    result = values[lower] * (1 - weight) + values[upper] * weight
    return round(result, 3)
