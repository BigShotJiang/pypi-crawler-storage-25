"""Native notification delivery for Docket task results."""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from docket.utils import safe_format

logger = logging.getLogger("docket.notify")

NotificationResult = tuple[str, int, str, str]
VALID_NOTIFY_EVENTS = {"success", "failure", "complete"}


class NotificationError(Exception):
    """Raised when notification config is structurally invalid."""


class Notifier:
    """Send task completion notifications to configured providers."""

    TIMEOUT = 15

    def __init__(self, task_config: dict[str, Any]) -> None:
        raw = task_config.get("notify")
        self._config = raw if isinstance(raw, dict) else {}

    def notify(
        self,
        *,
        event: str,
        result: Any = None,
        run_record: dict[str, Any] | None = None,
    ) -> list[NotificationResult]:
        """Send notifications for *event* if configured.

        Notification failures are captured as results and never raised to the
        caller. That mirrors shell hooks: delivery should not change task
        success or failure.
        """
        if not self._config or not self._should_notify(event):
            return []

        message = _render_message(self._config, event, result, run_record)
        outcomes: list[NotificationResult] = []

        discord = self._config.get("discord")
        if isinstance(discord, dict) and discord.get("enabled", True):
            outcomes.append(_send_discord(discord, message))

        telegram = self._config.get("telegram")
        if isinstance(telegram, dict) and telegram.get("enabled", True):
            outcomes.append(_send_telegram(telegram, message))

        return outcomes

    def _should_notify(self, event: str) -> bool:
        raw = self._config.get("on", ["failure"])
        events = [raw] if isinstance(raw, str) else raw
        if not isinstance(events, list):
            return False
        normalized = {str(item).lower() for item in events}
        return event in normalized or "complete" in normalized


def _render_message(
    config: dict[str, Any],
    event: str,
    result: Any = None,
    run_record: dict[str, Any] | None = None,
) -> str:
    template = config.get("message")
    task_name = ""
    run_id = ""
    status = event
    summary = ""
    duration = ""

    if run_record:
        task_name = str(run_record.get("task_name", ""))
        run_id = str(run_record.get("run_id", ""))
        status = str(run_record.get("status", event))
        summary = str(run_record.get("summary", ""))
        duration_value = run_record.get("duration_seconds")
        if duration_value is not None:
            duration = f"{float(duration_value):.2f}s"

    if result is not None:
        summary = summary or str(getattr(result, "summary", ""))

    values = {
        "event": event,
        "task": task_name,
        "task_name": task_name,
        "run_id": run_id,
        "status": status,
        "summary": summary,
        "duration": duration,
    }

    if isinstance(template, str) and template.strip():
        try:
            return safe_format(template, values)
        except Exception as exc:  # noqa: BLE001 - config templates should not crash runs.
            logger.warning("Notification message template failed: %s", exc)

    prefix = "Docket"
    if task_name:
        prefix += f" {task_name}"
    text = f"{prefix} {status}: {summary or 'task completed'}"
    if run_id:
        text += f" ({run_id})"
    if duration:
        text += f" in {duration}"
    return text


def _send_discord(config: dict[str, Any], message: str) -> NotificationResult:
    provider = "notify:discord"
    url = _secret_value(config, "webhook_url", "webhook_url_env", "DISCORD_WEBHOOK_URL")
    if not url:
        return (provider, -2, "", "Missing Discord webhook URL")

    payload: dict[str, Any] = {"content": message}
    if config.get("username"):
        payload["username"] = str(config["username"])

    return _post_json(provider, url, payload)


def _send_telegram(config: dict[str, Any], message: str) -> NotificationResult:
    provider = "notify:telegram"
    token = _secret_value(config, "bot_token", "bot_token_env", "TELEGRAM_BOT_TOKEN")
    chat_id = config.get("chat_id", config.get("chat"))
    if not token:
        return (provider, -2, "", "Missing Telegram bot token")
    if chat_id is None or str(chat_id).strip() == "":
        return (provider, -2, "", "Missing Telegram chat_id")

    url = f"https://api.telegram.org/bot{urllib.parse.quote(str(token))}/sendMessage"
    payload = {"chat_id": str(chat_id), "text": message}
    if config.get("parse_mode"):
        payload["parse_mode"] = str(config["parse_mode"])

    return _post_json(provider, url, payload)


def _post_json(provider: str, url: str, payload: dict[str, Any]) -> NotificationResult:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=Notifier.TIMEOUT) as response:
            body = response.read().decode("utf-8", errors="replace").strip()
            return (provider, int(response.status), body, "")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace").strip()
        return (provider, exc.code, body, str(exc))
    except urllib.error.URLError as exc:
        return (provider, -1, "", str(exc.reason))
    except Exception as exc:  # noqa: BLE001 - delivery is best-effort.
        return (provider, -2, "", str(exc))


def _secret_value(
    config: dict[str, Any],
    value_key: str,
    env_key: str,
    default_env: str,
) -> str | None:
    explicit = config.get(value_key)
    if isinstance(explicit, str) and explicit.strip():
        return explicit
    env_name = config.get(env_key, default_env)
    if isinstance(env_name, str) and env_name.strip():
        value = os.environ.get(env_name)
        if value:
            return value
    return None
