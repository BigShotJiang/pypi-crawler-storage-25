"""Programmatic adapters for agent-facing Docket operations."""

from __future__ import annotations

from typing import Any

from docket import core
from docket.core import DocketError


class DocketAPIError(RuntimeError):
    """Raised when a Docket API operation fails."""

    def __init__(self, message: str, *, exit_code: int = 1, payload: Any = None) -> None:
        super().__init__(message)
        self.exit_code = exit_code
        self.payload = payload


def _check_run_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Translate a non-zero ``exit_code`` in *payload* into a raised error."""
    exit_code = int(payload.get("exit_code", 0) or 0)
    if exit_code != 0:
        message = payload.get("summary") or payload.get("error") or "Docket command failed"
        raise DocketAPIError(message, exit_code=exit_code, payload=payload)
    return payload


def _wrap(call):
    try:
        return call()
    except DocketError as exc:
        message = exc.message or str(exc) or "Docket command failed"
        raise DocketAPIError(message, exit_code=exc.exit_code, payload=exc.payload) from exc


def list_tasks() -> list[dict[str, Any]]:
    return _wrap(core.list_tasks)


def describe_task(task_name: str) -> dict[str, Any]:
    return _wrap(lambda: core.describe_task(task_name))


def run_task(task_name: str, *, dry_run: bool = False, force: bool = False) -> dict[str, Any]:
    payload = _wrap(lambda: core.run_task(task_name, dry_run=dry_run, force=force))
    return _check_run_payload(payload)


def run_task_async(task_name: str, *, dry_run: bool = False, force: bool = False) -> dict[str, Any]:
    payload = _wrap(
        lambda: core.run_task(task_name, dry_run=dry_run, force=force, async_mode=True)
    )
    return _check_run_payload(payload)


def task_status(task_name: str | None = None, *, run_id: str | None = None) -> Any:
    return _wrap(lambda: core.task_status(task_name, run_id=run_id))


def task_runs(task_name: str | None = None, *, limit: int = 20) -> list[dict[str, Any]]:
    return _wrap(lambda: core.task_runs(task_name, limit=limit))


def wait_run(
    run_id: str,
    *,
    timeout: float | None = None,
    poll_interval: float = 1.0,
) -> dict[str, Any]:
    return _wrap(
        lambda: core.wait_for_run(run_id, timeout=timeout, poll_interval=poll_interval)
    )


def run_logs(run_id: str, *, tail: int | None = None) -> dict[str, Any]:
    return _wrap(lambda: core.run_logs(run_id, tail=tail))


def run_events(run_id: str, *, limit: int = 500) -> list[dict[str, Any]]:
    return _wrap(lambda: core.run_events(run_id, limit=limit))


def cancel_run(run_id: str) -> dict[str, Any]:
    return _wrap(lambda: core.cancel_run(run_id))


def capabilities() -> dict[str, Any]:
    return _wrap(core.capabilities)


def health() -> dict[str, Any]:
    return _wrap(core.health)


def doctor(*, agent: bool = False) -> dict[str, Any]:
    payload = _wrap(lambda: core.doctor(agent=agent))
    if not payload.get("ok", True):
        raise DocketAPIError(
            "Docket doctor checks failed",
            exit_code=1,
            payload=payload,
        )
    return payload
