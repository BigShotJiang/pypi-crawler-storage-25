"""First-class hbackup integration for Hermes/OpenClaw backups."""

from __future__ import annotations

import shutil
from typing import Any

from docket.task import BaseTask, TaskResult
from docket.tasks.backup import (
    _hbackup_details,
    _hbackup_summary,
    _idle_timeout,
    _run_command,
    _timeout_result,
)

HBACKUP_ACTIONS = {"backup", "auto", "list", "upload", "setup-drive"}


class HBackupTask(BaseTask):
    """Run hbackup with Docket's agent-facing execution contract."""

    name = "hbackup"
    description = "Back up Hermes/OpenClaw state with hbackup"
    inputs = {
        "hbackup_bin": "hbackup executable path or command name",
        "action": "hbackup action: backup, auto, list, upload, or setup-drive",
        "output": "Archive path for hbackup backup output",
        "excludes": "Exclude patterns for hbackup backup",
        "archive": "Archive path for hbackup upload",
        "destination": "scp/rsync destination for hbackup upload",
        "drive": "Upload to Google Drive via hbackup/rclone",
        "drive_remote": "Google Drive rclone remote name",
        "drive_folder": "Google Drive folder path",
        "idle_timeout_seconds": "Maximum seconds without output before killing the job",
        "extra_args": "Additional hbackup CLI arguments",
    }
    outputs = {
        "archive_path": "Archive path reported by hbackup",
        "archive_size": "Archive size reported by hbackup",
        "file_count": "Number of files reported by hbackup",
        "stdout": "Captured hbackup stdout",
        "stderr": "Captured hbackup stderr",
        "timed_out": "True when hbackup was killed after idle timeout",
    }
    required_env: list[str] = []
    network = True
    destructive = False

    def run(self, config: dict[str, Any]) -> TaskResult:
        return _run_hbackup(config, dry=False)

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        return _run_hbackup(config, dry=True)


def _run_hbackup(config: dict[str, Any], dry: bool) -> TaskResult:
    hbackup_bin = config.get("hbackup_bin", "hbackup")
    if not shutil.which(hbackup_bin):
        return TaskResult(
            ok=False,
            summary="hbackup not found on PATH",
            details={"backend": "hbackup"},
            dry_run=dry,
        )

    action = config.get("action", config.get("hbackup_command", "backup"))
    if action not in HBACKUP_ACTIONS:
        return TaskResult(
            ok=False,
            summary=f"Unknown hbackup action: {action}",
            details={"backend": "hbackup", "action": action},
            dry_run=dry,
        )

    if dry and action in {"upload", "setup-drive"}:
        command = _build_hbackup_command(hbackup_bin, action, config)
        return TaskResult(
            ok=True,
            summary=f"Would run hbackup {action}: {' '.join(command)}",
            details={
                "backend": "hbackup",
                "action": action,
                "command": command,
                "dry_run_supported": False,
            },
            dry_run=True,
        )

    effective_action = "backup" if dry and action == "auto" else action
    command = _build_hbackup_command(hbackup_bin, effective_action, config)
    if dry and effective_action == "backup":
        command.append("--dry-run")

    idle_timeout = _idle_timeout(config)
    result = _run_command(command, idle_timeout=idle_timeout)
    details = _hbackup_details(result)
    details.update(
        {
            "backend": "hbackup",
            "action": action,
            "effective_action": effective_action,
            "command": command,
            "exit_code": result.returncode,
        }
    )

    summary = _hbackup_summary(effective_action, result, dry)
    if result.timed_out:
        timeout_result = _timeout_result(summary, result, idle_timeout, dry)
        timeout_result.details.update(details)
        return timeout_result
    if result.returncode != 0:
        return TaskResult(
            ok=False,
            summary=f"{summary} (exit {result.returncode})",
            details=details,
            dry_run=dry,
        )
    return TaskResult(ok=True, summary=summary, details=details, dry_run=dry)


def _build_hbackup_command(
    hbackup_bin: str,
    action: str,
    config: dict[str, Any],
) -> list[str]:
    if action == "setup-drive":
        return [hbackup_bin, "setup", "drive", *config.get("extra_args", [])]

    command = [hbackup_bin, action]
    if action == "backup":
        output = config.get("output")
        if output:
            command.extend(["--output", str(output)])
        for pattern in config.get("excludes", []):
            command.extend(["--exclude", pattern])
    elif action == "upload":
        if config.get("drive"):
            command.append("--drive")
        if config.get("drive_remote"):
            command.extend(["--drive-remote", str(config["drive_remote"])])
        if config.get("drive_folder"):
            command.extend(["--drive-folder", str(config["drive_folder"])])
        archive = config.get("archive")
        if archive:
            command.append(str(archive))
        destination = config.get("destination")
        if destination:
            command.append(str(destination))

    command.extend(config.get("extra_args", []))
    return command
