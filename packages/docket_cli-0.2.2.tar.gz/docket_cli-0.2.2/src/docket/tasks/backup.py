"""Backup task: generic rclone/rsync backup wrapper."""

from __future__ import annotations

import queue
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any

from docket.task import BaseTask, TaskResult

DEFAULT_IDLE_TIMEOUT_SECONDS = 1800.0
HBACKUP_COMPLETE_RE = re.compile(
    r"Backup complete:\s+(?P<archive>.+?)\s+\((?P<files>\d+)\s+files,\s+(?P<size>[^)]+)\)"
)
HBACKUP_FOUND_RE = re.compile(r"Found\s+(?P<files>\d+)\s+files")


@dataclass(frozen=True)
class CommandResult:
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False


class BackupTask(BaseTask):
    """Sync data using rclone, rsync, or hbackup.

    Config keys:
        source: Local directory path (default: /data/backup).
        remote: Remote destination (default: remote:backup).
        tool:   'rclone' (default), 'rsync', or 'hbackup'.
        extra_args: Additional CLI arguments for the backup tool.
        idle_timeout_seconds: Kill the command if it produces no output for
            this many seconds. Set to 0 or null to disable. Defaults to 1800.
        hbackup_bin: Optional hbackup binary path/name.
        hbackup_command: 'backup' (default) or 'auto'.
        output: Optional hbackup archive path.
        excludes: Optional hbackup exclude patterns.
    """

    name = "backup"
    description = "Sync local folder or agent state using rclone, rsync, or hbackup"
    inputs = {
        "source": "Local directory path to back up",
        "remote": "Remote destination for rclone or rsync",
        "tool": "Backup tool: rclone, rsync, or hbackup",
        "extra_args": "Additional command-line arguments for the backup tool",
        "idle_timeout_seconds": "Maximum seconds without output before killing the job",
        "hbackup_bin": "hbackup executable path or command name",
        "hbackup_command": "hbackup subcommand for real runs: backup or auto",
        "output": "Archive path for hbackup backup output",
        "excludes": "hbackup exclude patterns",
    }
    outputs = {
        "stdout": "Captured backup tool stdout",
        "stderr": "Captured backup tool stderr on failure",
        "timed_out": "True when the backup was killed after idle timeout",
        "archive_path": "Archive path reported by hbackup",
        "file_count": "Number of files reported by hbackup",
    }
    network = True

    def run(self, config: dict[str, Any]) -> TaskResult:
        tool = config.get("tool", "rclone")
        source = config.get("source", "/data/backup")
        remote = config.get("remote", "remote:backup")
        extra_args = config.get("extra_args", [])
        idle_timeout = _idle_timeout(config)

        if tool == "rclone":
            return self._run_rclone(
                source,
                remote,
                extra_args,
                dry=False,
                idle_timeout=idle_timeout,
            )
        elif tool == "rsync":
            return self._run_rsync(
                source,
                remote,
                extra_args,
                dry=False,
                idle_timeout=idle_timeout,
            )
        elif tool == "hbackup":
            return self._run_hbackup(config, dry=False, idle_timeout=idle_timeout)
        else:
            return TaskResult(ok=False, summary=f"Unknown backup tool: {tool}")

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        tool = config.get("tool", "rclone")
        source = config.get("source", "/data/backup")
        remote = config.get("remote", "remote:backup")
        extra_args = config.get("extra_args", [])
        idle_timeout = _idle_timeout(config)

        if tool == "rclone":
            return self._run_rclone(
                source,
                remote,
                extra_args,
                dry=True,
                idle_timeout=idle_timeout,
            )
        elif tool == "rsync":
            return self._run_rsync(
                source,
                remote,
                extra_args,
                dry=True,
                idle_timeout=idle_timeout,
            )
        elif tool == "hbackup":
            return self._run_hbackup(config, dry=True, idle_timeout=idle_timeout)
        else:
            return TaskResult(
                ok=False,
                summary=f"Unknown backup tool: {tool}",
                dry_run=True,
            )

    def _run_rclone(
        self,
        source: str,
        remote: str,
        extra_args: list[str],
        dry: bool,
        idle_timeout: float | None,
    ) -> TaskResult:
        if not shutil.which("rclone"):
            return TaskResult(
                ok=False,
                summary="rclone not found on PATH",
                dry_run=dry,
            )

        cmd = ["rclone", "sync", source, remote]
        cmd.extend(extra_args)
        if dry:
            cmd.append("--dry-run")

        result = _run_command(cmd, idle_timeout=idle_timeout)
        summary = f"rclone sync {source} -> {remote}"
        if dry:
            summary = f"Would {summary}"
        if result.timed_out:
            return _timeout_result(summary, result, idle_timeout, dry)
        if result.returncode != 0:
            summary += f" (exit {result.returncode})"
            return TaskResult(
                ok=False,
                summary=summary,
                details={"stderr": result.stderr, "stdout": result.stdout},
                dry_run=dry,
            )
        return TaskResult(
            ok=True,
            summary=summary,
            details={"stdout": result.stdout},
            dry_run=dry,
        )

    def _run_hbackup(
        self,
        config: dict[str, Any],
        dry: bool,
        idle_timeout: float | None,
    ) -> TaskResult:
        hbackup_bin = config.get("hbackup_bin", "hbackup")
        if not shutil.which(hbackup_bin):
            return TaskResult(
                ok=False,
                summary="hbackup not found on PATH",
                dry_run=dry,
            )

        command = config.get("hbackup_command", "backup")
        if command not in {"backup", "auto"}:
            return TaskResult(
                ok=False,
                summary=f"Unknown hbackup command: {command}",
                dry_run=dry,
            )

        effective_command = "backup" if dry else command
        cmd = [hbackup_bin, effective_command]
        if dry:
            cmd.append("--dry-run")
        if effective_command == "backup":
            output = config.get("output")
            if output:
                cmd.extend(["--output", str(output)])
            for pattern in config.get("excludes", []):
                cmd.extend(["--exclude", pattern])
            cmd.extend(config.get("extra_args", []))

        result = _run_command(cmd, idle_timeout=idle_timeout)
        summary = _hbackup_summary(effective_command, result, dry)
        details = _hbackup_details(result)
        details["backend"] = "hbackup"
        if result.timed_out:
            return _timeout_result(summary, result, idle_timeout, dry)
        if result.returncode != 0:
            return TaskResult(
                ok=False,
                summary=f"{summary} (exit {result.returncode})",
                details=details,
                dry_run=dry,
            )
        return TaskResult(ok=True, summary=summary, details=details, dry_run=dry)

    def _run_rsync(
        self,
        source: str,
        remote: str,
        extra_args: list[str],
        dry: bool,
        idle_timeout: float | None,
    ) -> TaskResult:
        if not shutil.which("rsync"):
            return TaskResult(
                ok=False,
                summary="rsync not found on PATH",
                dry_run=dry,
            )

        cmd = ["rsync", "-avz"]
        if dry:
            cmd.append("--dry-run")
        cmd.extend(extra_args)
        cmd.extend([source if source.endswith("/") else source + "/", remote])

        result = _run_command(cmd, idle_timeout=idle_timeout)
        summary = f"rsync {source} -> {remote}"
        if dry:
            summary = f"Would {summary}"
        if result.timed_out:
            return _timeout_result(summary, result, idle_timeout, dry)
        if result.returncode != 0:
            summary += f" (exit {result.returncode})"
            return TaskResult(
                ok=False,
                summary=summary,
                details={"stderr": result.stderr, "stdout": result.stdout},
                dry_run=dry,
            )
        return TaskResult(
            ok=True,
            summary=summary,
            details={"stdout": result.stdout},
            dry_run=dry,
        )


def _idle_timeout(config: dict[str, Any]) -> float | None:
    raw = config.get("idle_timeout_seconds", DEFAULT_IDLE_TIMEOUT_SECONDS)
    if raw is None:
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_IDLE_TIMEOUT_SECONDS
    return value if value > 0 else None


def _run_command(cmd: list[str], idle_timeout: float | None) -> CommandResult:
    if idle_timeout is None:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return CommandResult(
            returncode=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    output_queue: queue.Queue[tuple[str, str]] = queue.Queue()
    stdout_parts: list[str] = []
    stderr_parts: list[str] = []

    def _pump(name: str, stream: Any) -> None:
        try:
            for line in iter(stream.readline, ""):
                output_queue.put((name, line))
        finally:
            stream.close()

    threads = [
        threading.Thread(target=_pump, args=("stdout", proc.stdout), daemon=True),
        threading.Thread(target=_pump, args=("stderr", proc.stderr), daemon=True),
    ]
    for thread in threads:
        thread.start()

    last_output = time.monotonic()
    timed_out = False
    while proc.poll() is None:
        try:
            name, chunk = output_queue.get(timeout=0.1)
        except queue.Empty:
            if time.monotonic() - last_output > idle_timeout:
                timed_out = True
                proc.kill()
                break
            continue

        last_output = time.monotonic()
        if name == "stdout":
            stdout_parts.append(chunk)
        else:
            stderr_parts.append(chunk)

    for thread in threads:
        thread.join(timeout=1)
    while not output_queue.empty():
        name, chunk = output_queue.get()
        if name == "stdout":
            stdout_parts.append(chunk)
        else:
            stderr_parts.append(chunk)

    return CommandResult(
        returncode=proc.wait(),
        stdout="".join(stdout_parts),
        stderr="".join(stderr_parts),
        timed_out=timed_out,
    )


def _hbackup_summary(command: str, result: CommandResult, dry: bool) -> str:
    found_match = HBACKUP_FOUND_RE.search(result.stderr)
    complete_match = HBACKUP_COMPLETE_RE.search(result.stderr)
    prefix = "Would create" if dry else "Created"
    if dry and found_match:
        return f"Would create hbackup archive with {found_match.group('files')} files"
    if complete_match:
        return (
            f"{prefix} hbackup archive {complete_match.group('archive')} "
            f"({complete_match.group('files')} files, {complete_match.group('size')})"
        )
    if command == "auto":
        return "hbackup auto completed"
    return "hbackup backup completed" if not dry else "Would create hbackup archive"


def _hbackup_details(result: CommandResult) -> dict[str, Any]:
    details: dict[str, Any] = {
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
    found_match = HBACKUP_FOUND_RE.search(result.stderr)
    complete_match = HBACKUP_COMPLETE_RE.search(result.stderr)
    if found_match:
        details["file_count"] = int(found_match.group("files"))
    if complete_match:
        details["archive_path"] = complete_match.group("archive")
        details["file_count"] = int(complete_match.group("files"))
        details["archive_size"] = complete_match.group("size")
    return details


def _timeout_result(
    summary: str,
    result: CommandResult,
    idle_timeout: float | None,
    dry: bool,
) -> TaskResult:
    timeout = 0 if idle_timeout is None else idle_timeout
    return TaskResult(
        ok=False,
        summary=f"{summary} timed out after {timeout:g}s without output",
        details={
            "stdout": result.stdout,
            "stderr": result.stderr,
            "idle_timeout_seconds": idle_timeout,
            "timed_out": True,
        },
        dry_run=dry,
    )
