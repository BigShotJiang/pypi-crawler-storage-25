"""Generic external command task backend."""

from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time
from pathlib import Path
from typing import Any

from docket.state import StateStore
from docket.task import BaseTask, TaskResult


class CommandTask(BaseTask):
    """Run an external executable as a Docket task."""

    _skip_validation = True
    name = ""
    description = "Run an external command"
    inputs: dict[str, str] = {
        "command": "Executable path or command name",
        "args": "Arguments for real runs",
        "dry_run_args": "Arguments for dry runs",
        "output_format": "How stdout should be parsed: text, json, jsonl, or auto",
    }
    outputs: dict[str, str] = {
        "stdout": "Captured stdout",
        "stderr": "Captured stderr",
        "json": "Parsed JSON stdout when output_format is json or auto",
        "events": "Parsed JSONL events when output_format is jsonl",
    }
    required_env: list[str] = []
    destructive = False
    network = False

    def run(self, config: dict[str, Any]) -> TaskResult:
        missing = _missing_env(config)
        if missing:
            return TaskResult(
                ok=False,
                summary=f"Missing required environment variables: {', '.join(missing)}",
                details={"missing_env": missing},
            )
        return _run_command_config(config, dry=False)

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        missing = _missing_env(config)
        if missing:
            return TaskResult(
                ok=False,
                summary=f"Missing required environment variables: {', '.join(missing)}",
                details={"missing_env": missing},
                dry_run=True,
            )
        if "dry_run_command" not in config and "dry_run_args" not in config:
            command = _build_command(config, dry=False)
            return TaskResult(
                ok=True,
                summary=f"Would run: {_format_command(command)}",
                details={
                    "command": command,
                    "dry_run_supported": False,
                    "stdout": "",
                    "stderr": "",
                },
                dry_run=True,
            )
        return _run_command_config(config, dry=True)


def make_command_task_class(task_name: str, config: dict[str, Any]) -> type[CommandTask]:
    """Create a configured command task class for registry discovery."""
    attrs = {
        "_skip_validation": False,
        "name": task_name,
        "description": config.get("description", f"Run command task: {task_name}"),
        "inputs": config.get("inputs", CommandTask.inputs),
        "outputs": config.get("outputs", CommandTask.outputs),
        "required_env": config.get("required_env", []),
        "destructive": bool(config.get("destructive", False)),
        "network": bool(config.get("network", False)),
    }
    class_name = "".join(part.capitalize() for part in task_name.split("-")) + "CommandTask"
    return type(class_name, (CommandTask,), attrs)


def _run_command_config(config: dict[str, Any], dry: bool) -> TaskResult:
    command = _build_command(config, dry=dry)
    timeout = config.get("timeout_seconds")
    output_format = config.get("output_format", "text")
    if output_format == "jsonl":
        return _run_jsonl_command(config, command, dry=dry, timeout=timeout)

    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=_cwd(config),
            env=_env(config),
            timeout=timeout,
        )
    except FileNotFoundError:
        return TaskResult(
            ok=False,
            summary=f"Command not found: {command[0]}",
            details={"command": command},
            dry_run=dry,
        )
    except subprocess.TimeoutExpired as exc:
        details = {
            "command": command,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
            "timeout_seconds": timeout,
            "timed_out": True,
        }
        return TaskResult(
            ok=False,
            summary=f"Command timed out after {timeout}s: {_format_command(command)}",
            details=details,
            dry_run=dry,
        )

    details = _details_from_output(config, completed.stdout, completed.stderr)
    details["command"] = command
    details["exit_code"] = completed.returncode

    success_codes = config.get("success_exit_codes", [0])
    ok = completed.returncode in success_codes
    action = "Dry run" if dry else "Command"
    status = "completed" if ok else f"failed with exit {completed.returncode}"
    return TaskResult(
        ok=ok,
        summary=f"{action} {status}: {_format_command(command)}",
        details=details,
        dry_run=dry,
    )


def _run_jsonl_command(
    config: dict[str, Any],
    command: list[str],
    *,
    dry: bool,
    timeout: float | None,
) -> TaskResult:
    stdout_parts: list[str] = []
    stderr_parts: list[str] = []
    events: list[dict[str, Any]] = []
    invalid: list[dict[str, Any]] = []
    stderr_queue: queue.Queue[str] = queue.Queue()

    try:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            cwd=_cwd(config),
            env=_env(config),
        )
    except FileNotFoundError:
        return TaskResult(
            ok=False,
            summary=f"Command not found: {command[0]}",
            details={"command": command},
            dry_run=dry,
        )

    def _pump_stderr() -> None:
        assert proc.stderr is not None
        try:
            for line in iter(proc.stderr.readline, ""):
                stderr_queue.put(line)
        finally:
            proc.stderr.close()

    stderr_thread = threading.Thread(target=_pump_stderr, daemon=True)
    stderr_thread.start()

    deadline = None if timeout is None else time.monotonic() + float(timeout)
    timed_out = False
    assert proc.stdout is not None
    while True:
        if deadline is not None and time.monotonic() >= deadline:
            timed_out = True
            proc.kill()
            break
        line = proc.stdout.readline()
        if line:
            stdout_parts.append(line)
            event, error = _parse_jsonl_line(line, len(stdout_parts))
            if event is not None:
                events.append(event)
                _record_live_event(event)
            elif error is not None:
                invalid.append(error)
        elif proc.poll() is not None:
            break
        else:
            time.sleep(0.05)

    proc.stdout.close()
    stderr_thread.join(timeout=1)
    while not stderr_queue.empty():
        stderr_parts.append(stderr_queue.get())

    returncode = proc.wait()
    stdout = "".join(stdout_parts)
    stderr = "".join(stderr_parts)
    details: dict[str, Any] = {
        "stdout": stdout,
        "stderr": stderr,
        "events": events,
        "event_count": len(events),
        "command": command,
        "exit_code": returncode,
    }
    if events:
        details["last_event"] = events[-1]
    if invalid:
        details["invalid_jsonl_lines"] = invalid
    if timed_out:
        details["timeout_seconds"] = timeout
        details["timed_out"] = True
        return TaskResult(
            ok=False,
            summary=f"Command timed out after {timeout}s: {_format_command(command)}",
            details=details,
            dry_run=dry,
        )

    success_codes = config.get("success_exit_codes", [0])
    ok = returncode in success_codes
    action = "Dry run" if dry else "Command"
    status = "completed" if ok else f"failed with exit {returncode}"
    return TaskResult(
        ok=ok,
        summary=f"{action} {status}: {_format_command(command)}",
        details=details,
        dry_run=dry,
    )


def _build_command(config: dict[str, Any], dry: bool) -> list[str]:
    command_value = config.get("dry_run_command") if dry else config.get("command")
    if command_value is None:
        command_value = config.get("command")
    command = _string_or_list(command_value, key="command")
    args_key = "dry_run_args" if dry else "args"
    args = _string_list(config.get(args_key, []), key=args_key)
    return [*command, *args]


def _details_from_output(config: dict[str, Any], stdout: str, stderr: str) -> dict[str, Any]:
    details: dict[str, Any] = {"stdout": stdout, "stderr": stderr}
    output_format = config.get("output_format", "text")
    if output_format == "auto":
        output_format = _detect_output_format(stdout)
    if output_format == "json":
        try:
            details["json"] = json.loads(stdout)
        except json.JSONDecodeError as exc:
            details["parse_error"] = f"Invalid JSON stdout: {exc}"
    elif output_format == "jsonl":
        events, invalid = _parse_jsonl(stdout)
        details["events"] = events
        details["event_count"] = len(events)
        if events:
            details["last_event"] = events[-1]
        if invalid:
            details["invalid_jsonl_lines"] = invalid
    return details


def _parse_jsonl(text: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    events: list[dict[str, Any]] = []
    invalid: list[dict[str, Any]] = []
    for index, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        event, error = _parse_jsonl_line(line, index)
        if event is not None:
            events.append(event)
        elif error is not None:
            invalid.append(error)
    return events, invalid


def _parse_jsonl_line(
    line: str,
    index: int,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    try:
        value = json.loads(line)
    except json.JSONDecodeError as exc:
        return None, {"line": index, "error": str(exc), "text": line}
    if isinstance(value, dict):
        return value, None
    return None, {"line": index, "error": "JSONL event must be an object", "text": line}


def _record_live_event(event: dict[str, Any]) -> None:
    run_id = os.environ.get("DOCKET_RUN_ID")
    state_path = os.environ.get("DOCKET_STATE_PATH")
    if not run_id or not state_path:
        return
    try:
        with StateStore(state_path) as state:
            state.add_events(run_id, [event])
    except Exception:
        return


def _detect_output_format(stdout: str) -> str:
    stripped = stdout.strip()
    if not stripped:
        return "text"
    if stripped.startswith("{") or stripped.startswith("["):
        return "json"
    lines = [line for line in stdout.splitlines() if line.strip()]
    if lines and all(line.lstrip().startswith("{") for line in lines):
        return "jsonl"
    return "text"


def _string_or_list(value: Any, *, key: str) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        if value:
            return value
    raise ValueError(f"Command task key '{key}' must be a string or non-empty list of strings")


def _string_list(value: Any, *, key: str) -> list[str]:
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return value
    raise ValueError(f"Command task key '{key}' must be a list of strings")


def _missing_env(config: dict[str, Any]) -> list[str]:
    return [name for name in config.get("required_env", []) if not os.environ.get(name)]


def _env(config: dict[str, Any]) -> dict[str, str] | None:
    extra_env = config.get("env")
    if not extra_env:
        return None
    env = os.environ.copy()
    env.update({key: str(value) for key, value in extra_env.items()})
    return env


def _cwd(config: dict[str, Any]) -> str | None:
    cwd = config.get("cwd")
    if cwd is None:
        return None
    return str(Path(cwd).expanduser())


def _format_command(command: list[str]) -> str:
    return " ".join(command)
