"""Health check task — system health: disk, memory, services."""

from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any

from docket.task import BaseTask, TaskResult


class HealthCheckTask(BaseTask):
    """Run configurable system health checks.

    Config keys:
        checks: List of check names to run (default: ["disk", "memory"]).
                Available: disk, memory, systemd-units.
        disk_threshold_pct: Disk usage percentage threshold (default: 90).
        memory_threshold_pct: Memory usage percentage threshold (default: 90).
        systemd_units: List of systemd units that should be active (default: []).
    """

    name = "health-check"
    description = "Check system health: disk usage, memory, and systemd services"
    inputs = {
        "checks": "List of checks: disk, memory, systemd-units",
        "disk_threshold_pct": "Fail when disk usage is at or above this percentage",
        "memory_threshold_pct": "Fail when memory usage is at or above this percentage",
        "systemd_units": "List of systemd units that must be active",
    }
    outputs = {
        "disk": "Disk usage and threshold result",
        "memory": "Memory usage and threshold result",
        "systemd-units": "Systemd unit states and failures",
    }

    # Map of check name → method name.
    CHECK_METHODS = {
        "disk": "_check_disk",
        "memory": "_check_memory",
        "systemd-units": "_check_systemd_units",
    }

    def run(self, config: dict[str, Any]) -> TaskResult:
        return self._run_checks(config, dry=False)

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        return self._run_checks(config, dry=True)

    def _run_checks(self, config: dict[str, Any], dry: bool) -> TaskResult:
        requested = config.get("checks", ["disk", "memory"])
        if not isinstance(requested, list):
            return TaskResult(
                ok=False,
                summary=f"Invalid 'checks' config: expected list, got {type(requested).__name__}",
                dry_run=dry,
            )

        unknown = [c for c in requested if c not in self.CHECK_METHODS]
        if unknown:
            return TaskResult(
                ok=False,
                summary=f"Unknown checks: {', '.join(unknown)}",
                dry_run=dry,
            )

        if dry:
            names = ", ".join(requested)
            return TaskResult(
                ok=True,
                summary=f"Would run checks: {names}",
                details={"checks": requested},
                dry_run=True,
            )

        results: dict[str, Any] = {}
        all_ok = True
        for check_name in requested:
            method = getattr(self, self.CHECK_METHODS[check_name])
            try:
                check_result = method(config)
            except Exception as exc:
                check_result = {"ok": False, "error": str(exc)}
                all_ok = False
            results[check_name] = check_result
            if not check_result.get("ok", True):
                all_ok = False

        failed = [k for k, v in results.items() if not v.get("ok", True)]
        summary = "All health checks passed" if all_ok else f"Failed checks: {', '.join(failed)}"

        return TaskResult(ok=all_ok, summary=summary, details=results)

    def _check_disk(self, config: dict[str, Any]) -> dict[str, Any]:
        """Check disk usage against a threshold."""
        threshold = config.get("disk_threshold_pct", 90)

        try:
            usage = shutil.disk_usage("/")
        except OSError as exc:
            return {"ok": False, "error": str(exc)}

        used_pct = int((usage.used / usage.total) * 100)
        ok = used_pct < threshold
        return {
            "ok": ok,
            "used_pct": used_pct,
            "threshold": threshold,
            "total_gb": round(usage.total / (1024**3), 1),
            "used_gb": round(usage.used / (1024**3), 1),
            "free_gb": round(usage.free / (1024**3), 1),
        }

    def _check_memory(self, config: dict[str, Any]) -> dict[str, Any]:
        """Check memory usage against a threshold."""
        threshold = config.get("memory_threshold_pct", 90)

        try:
            result = subprocess.run(
                ["free", "-b"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                # Fallback: read from /proc/meminfo on Linux.
                return self._check_memory_procfs(threshold)

            # Parse `free -b` output.
            lines = result.stdout.strip().split("\n")
            if len(lines) < 2:
                return self._check_memory_procfs(threshold)

            mem_line = lines[1].split()
            total = int(mem_line[1])
            used = int(mem_line[2])
            used_pct = int((used / total) * 100) if total > 0 else 0
            ok = used_pct < threshold
            return {
                "ok": ok,
                "used_pct": used_pct,
                "threshold": threshold,
                "total_gb": round(total / (1024**3), 1),
                "used_gb": round(used / (1024**3), 1),
            }
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return self._check_memory_procfs(threshold)

    @staticmethod
    def _check_memory_procfs(threshold: int) -> dict[str, Any]:
        """Fallback memory check via /proc/meminfo."""
        meminfo_path = "/proc/meminfo"
        if not os.path.isfile(meminfo_path):
            return {"ok": True, "note": "memory check skipped (no /proc/meminfo or free)"}

        info: dict[str, int] = {}
        with open(meminfo_path) as f:
            for line in f:
                parts = line.split()
                key = parts[0].rstrip(":")
                value = int(parts[1]) * 1024  # Convert from kB to bytes
                info[key] = value

        total = info.get("MemTotal", 0)
        available = info.get("MemAvailable", 0)
        used = total - available
        used_pct = int((used / total) * 100) if total > 0 else 0
        ok = used_pct < threshold
        return {
            "ok": ok,
            "used_pct": used_pct,
            "threshold": threshold,
            "total_gb": round(total / (1024**3), 1),
            "used_gb": round(used / (1024**3), 1),
        }

    def _check_systemd_units(self, config: dict[str, Any]) -> dict[str, Any]:
        """Check that specified systemd units are active."""
        units = config.get("systemd_units", [])
        if not units:
            return {"ok": True, "note": "no units configured"}

        if not shutil.which("systemctl"):
            return {"ok": True, "note": "systemctl not found, skipping"}

        failed_units: list[str] = []
        unit_results: dict[str, str] = {}
        for unit in units:
            result = subprocess.run(
                ["systemctl", "is-active", unit],
                capture_output=True,
                text=True,
                timeout=10,
            )
            state = result.stdout.strip()
            unit_results[unit] = state
            if state != "active":
                failed_units.append(unit)

        return {
            "ok": len(failed_units) == 0,
            "failed_units": failed_units,
            "unit_states": unit_results,
        }
