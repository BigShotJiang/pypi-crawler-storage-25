"""Small config schema validator for task-specific options."""

from __future__ import annotations

from typing import Any


class SchemaError(Exception):
    """Raised when task-specific config does not match a task schema."""


TYPE_CHECKS = {
    "string": lambda value: isinstance(value, str),
    "str": lambda value: isinstance(value, str),
    "integer": lambda value: isinstance(value, int) and not isinstance(value, bool),
    "int": lambda value: isinstance(value, int) and not isinstance(value, bool),
    "number": lambda value: isinstance(value, (int, float)) and not isinstance(value, bool),
    "float": lambda value: isinstance(value, (int, float)) and not isinstance(value, bool),
    "boolean": lambda value: isinstance(value, bool),
    "bool": lambda value: isinstance(value, bool),
    "array": lambda value: isinstance(value, list),
    "list": lambda value: isinstance(value, list),
    "object": lambda value: isinstance(value, dict),
    "dict": lambda value: isinstance(value, dict),
}


def validate_task_schema(
    task_name: str,
    config: dict[str, Any],
    schema: dict[str, Any] | None,
) -> None:
    """Validate *config* against a task class' optional schema.

    The schema intentionally stays small and JSON-like:

    ``{"key": {"type": "string", "required": True, "enum": ["a", "b"]}}``
    """
    if not schema:
        return
    if not isinstance(schema, dict):
        raise SchemaError(f"Task '{task_name}' schema must be a mapping")

    for key, spec in schema.items():
        if not isinstance(key, str) or not key:
            raise SchemaError(f"Task '{task_name}' schema keys must be non-empty strings")
        if not isinstance(spec, dict):
            raise SchemaError(f"Task '{task_name}' schema for '{key}' must be a mapping")

        required = bool(spec.get("required", False))
        if key not in config:
            if required:
                raise SchemaError(f"Task '{task_name}' missing required config key '{key}'")
            continue

        value = config[key]
        expected_type = spec.get("type")
        if expected_type is not None:
            if not isinstance(expected_type, str) or expected_type not in TYPE_CHECKS:
                raise SchemaError(
                    f"Task '{task_name}' schema for '{key}' has unsupported type "
                    f"'{expected_type}'"
                )
            if not TYPE_CHECKS[expected_type](value):
                raise SchemaError(
                    f"Task '{task_name}' config key '{key}' must be {expected_type}"
                )

        if "enum" in spec:
            choices = spec["enum"]
            if not isinstance(choices, list):
                raise SchemaError(f"Task '{task_name}' schema for '{key}' enum must be a list")
            if value not in choices:
                allowed = ", ".join(str(choice) for choice in choices)
                raise SchemaError(
                    f"Task '{task_name}' config key '{key}' must be one of: {allowed}"
                )
