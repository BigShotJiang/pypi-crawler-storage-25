"""Shared utilities for Docket."""

from __future__ import annotations

import re
from typing import Any

SAFE_FIELD_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")


def safe_format(template: str, values: dict[str, Any]) -> str:
    """Resolve only flat ``{name}`` placeholders. No attribute or item access.

    Replaces ``str.format(**values)`` to prevent attribute traversal
    (``{x.__class__.__mro__[1]}``) when *template* comes from config.
    Unrecognised placeholders are left as-is.
    """
    def replace(match: re.Match[str]) -> str:
        return str(values.get(match.group(1), match.group(0)))
    return SAFE_FIELD_RE.sub(replace, template)
