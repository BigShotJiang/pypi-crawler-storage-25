"""YAML config loader with defaults and validation."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_DIR = Path.home() / ".docket"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.yaml"
DEFAULT_STATE_PATH = DEFAULT_CONFIG_DIR / "state.db"
DEFAULT_TASKS_DIR = DEFAULT_CONFIG_DIR / "tasks"
DEFAULT_LOGS_DIR = DEFAULT_CONFIG_DIR / "logs"


class ConfigError(Exception):
    """Raised when the config file is invalid or cannot be loaded."""


COMMON_TASK_KEYS = {
    "type",
    "schedule",
    "retry",
    "backoff_base",
    "on_success",
    "on_failure",
    "on_complete",
    "notify",
    "docket_bin",
    "description",
    "agent_notes",
    "inputs",
    "outputs",
    "required_env",
    "depends_on",
    "network",
    "destructive",
}

COMMAND_TASK_KEYS = {
    "command",
    "args",
    "dry_run_command",
    "dry_run_args",
    "output_format",
    "success_exit_codes",
    "env",
    "cwd",
    "timeout_seconds",
}

BACKUP_KEYS = {
    "source",
    "remote",
    "tool",
    "extra_args",
    "idle_timeout_seconds",
    "hbackup_bin",
    "hbackup_command",
    "output",
    "excludes",
}

HBACKUP_KEYS = {
    "hbackup_bin",
    "action",
    "hbackup_command",
    "output",
    "excludes",
    "archive",
    "destination",
    "drive",
    "drive_remote",
    "drive_folder",
    "extra_args",
    "idle_timeout_seconds",
}

HEALTH_CHECKS = {"disk", "memory", "systemd-units"}
HBACKUP_ACTIONS = {"backup", "auto", "list", "upload", "setup-drive"}


def _default_config() -> dict[str, Any]:
    """Return the default config structure."""
    return {
        "state_dir": str(DEFAULT_STATE_PATH),
        "tasks_dir": str(DEFAULT_TASKS_DIR),
        "logs_dir": str(DEFAULT_LOGS_DIR),
        "tasks": {},
    }


def _expand_path(value: str) -> str:
    """Expand ~ and environment variables in a path string."""
    return os.path.expanduser(os.path.expandvars(value))


def load_config(path: Path | None = None) -> dict[str, Any]:
    """Load and merge config from a YAML file with defaults.

    If ``path`` is None, falls back to ``~/.docket/config.yaml``.
    Missing files are not errors — defaults are returned and the
    config file is not created automatically.

    Returns:
        A merged config dict with all defaults filled in.
    """
    if path is None:
        path = Path(os.environ.get("DOCKET_CONFIG", DEFAULT_CONFIG_PATH))

    merged = _default_config()

    if path.exists():
        try:
            with open(path) as f:
                file_config = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ConfigError(f"Invalid YAML in {path}: {exc}") from exc
        except OSError as exc:
            raise ConfigError(f"Cannot read {path}: {exc}") from exc

        if file_config is None:
            file_config = {}
        if not isinstance(file_config, dict):
            raise ConfigError(f"Config must be a mapping, got {type(file_config).__name__}")

        if "tasks" in file_config and not isinstance(file_config["tasks"], dict):
            raise ConfigError("Config key 'tasks' must be a mapping")

        # Merge top-level keys (tasks dict is deep-merged).
        tasks_defaults = merged.pop("tasks", {})
        tasks_file = file_config.pop("tasks", {})
        merged.update(file_config)
        merged["tasks"] = {**tasks_defaults, **tasks_file}

    # Expand paths.
    for key in ("state_dir", "tasks_dir", "logs_dir"):
        if key in merged and isinstance(merged[key], str):
            merged[key] = _expand_path(merged[key])

    # Ensure tasks_dir path object exists as a string.
    merged.setdefault("tasks_dir", str(DEFAULT_TASKS_DIR))
    merged.setdefault("state_dir", str(DEFAULT_STATE_PATH))
    merged.setdefault("logs_dir", str(DEFAULT_LOGS_DIR))

    validate_config(merged)
    return merged


def get_task_config(config: dict[str, Any], task_name: str) -> dict[str, Any]:
    """Extract the config dict for a specific task.

    Returns an empty dict if the task has no configuration.
    """
    tasks = config.get("tasks", {})
    if not isinstance(tasks, dict):
        return {}
    task_config = tasks.get(task_name, {})
    return task_config if isinstance(task_config, dict) else {}


def validate_config(config: dict[str, Any]) -> None:
    """Validate Docket's shared configuration contract."""
    for key in ("state_dir", "tasks_dir", "logs_dir"):
        _require_str(config, key, context="config")

    tasks = config.get("tasks", {})
    if not isinstance(tasks, dict):
        raise ConfigError("Config key 'tasks' must be a mapping")

    for task_name, task_config in tasks.items():
        if not isinstance(task_name, str) or not task_name:
            raise ConfigError("Task names must be non-empty strings")
        if not isinstance(task_config, dict):
            raise ConfigError(f"Task '{task_name}' config must be a mapping")
        _validate_task_config(task_name, task_config)
    _validate_dependency_graph(tasks)


def _validate_task_config(task_name: str, config: dict[str, Any]) -> None:
    context = f"task '{task_name}'"
    if "schedule" in config:
        _require_str(config, "schedule", context=context, allow_empty=False)
    if "retry" in config:
        _require_non_negative_int(config, "retry", context=context)
    if "backoff_base" in config:
        _require_positive_number(config, "backoff_base", context=context)
    for key in ("on_success", "on_failure", "on_complete"):
        if key in config:
            _require_hook(config[key], key, context=context)
    if "notify" in config:
        _validate_notify_config(config["notify"], context=context)
    for key in ("docket_bin", "description", "agent_notes"):
        if key in config:
            _require_str(config, key, context=context, allow_empty=False)
    if "type" in config:
        _require_str(config, "type", context=context, allow_empty=False)
    if "inputs" in config:
        _require_str_mapping(config, "inputs", context=context)
    if "outputs" in config:
        _require_str_mapping(config, "outputs", context=context)
    if "required_env" in config:
        _require_str_list(config, "required_env", context=context)
    if "depends_on" in config:
        _require_str_list(config, "depends_on", context=context)
    for key in ("network", "destructive"):
        if key in config:
            _require_bool(config, key, context=context)

    if task_name == "backup":
        _validate_backup_config(config)
    elif task_name == "hbackup":
        _validate_hbackup_config(config)
    elif task_name == "health-check":
        _validate_health_check_config(config)
    elif config.get("type") == "command":
        _validate_command_task_config(task_name, config)


def _validate_backup_config(config: dict[str, Any]) -> None:
    context = "task 'backup'"
    for key in ("source", "remote"):
        if key in config:
            _require_str(config, key, context=context, allow_empty=False)
    if "tool" in config:
        tool = config["tool"]
        if tool not in {"rclone", "rsync", "hbackup"}:
            raise ConfigError(
                "task 'backup' key 'tool' must be 'rclone', 'rsync', or 'hbackup'"
            )
    if "extra_args" in config:
        _require_str_list(config, "extra_args", context=context)
    if "idle_timeout_seconds" in config and config["idle_timeout_seconds"] is not None:
        _require_non_negative_number(config, "idle_timeout_seconds", context=context)
    for key in ("hbackup_bin", "output"):
        if key in config:
            _require_str(config, key, context=context, allow_empty=False)
    if "hbackup_command" in config:
        command = config["hbackup_command"]
        if command not in {"backup", "auto"}:
            raise ConfigError("task 'backup' key 'hbackup_command' must be 'backup' or 'auto'")
    if "excludes" in config:
        _require_str_list(config, "excludes", context=context)


def _validate_hbackup_config(config: dict[str, Any]) -> None:
    context = "task 'hbackup'"
    for key in ("hbackup_bin", "output", "archive", "destination", "drive_remote", "drive_folder"):
        if key in config:
            _require_str(config, key, context=context, allow_empty=False)
    if "action" in config:
        action = config["action"]
        if action not in HBACKUP_ACTIONS:
            raise ConfigError(
                "task 'hbackup' key 'action' must be one of: "
                + ", ".join(sorted(HBACKUP_ACTIONS))
            )
    if "hbackup_command" in config:
        command = config["hbackup_command"]
        if command not in HBACKUP_ACTIONS:
            raise ConfigError(
                "task 'hbackup' key 'hbackup_command' must be one of: "
                + ", ".join(sorted(HBACKUP_ACTIONS))
            )
    if "excludes" in config:
        _require_str_list(config, "excludes", context=context)
    if "extra_args" in config:
        _require_str_list(config, "extra_args", context=context)
    if "drive" in config:
        _require_bool(config, "drive", context=context)
    if "idle_timeout_seconds" in config and config["idle_timeout_seconds"] is not None:
        _require_non_negative_number(config, "idle_timeout_seconds", context=context)


def _validate_health_check_config(config: dict[str, Any]) -> None:
    context = "task 'health-check'"
    if "checks" in config:
        checks = config["checks"]
        if not isinstance(checks, list) or not all(isinstance(c, str) for c in checks):
            raise ConfigError("task 'health-check' key 'checks' must be a list of strings")
        unknown = sorted(set(checks) - HEALTH_CHECKS)
        if unknown:
            raise ConfigError(f"task 'health-check' unknown checks: {', '.join(unknown)}")
    for key in ("disk_threshold_pct", "memory_threshold_pct"):
        if key in config:
            _require_percentage(config, key, context=context)
    if "systemd_units" in config:
        _require_str_list(config, "systemd_units", context=context)


def _validate_command_task_config(task_name: str, config: dict[str, Any]) -> None:
    context = f"task '{task_name}'"
    if config.get("type") != "command":
        return
    if "command" not in config:
        raise ConfigError(f"{context} key 'command' is required for command tasks")
    _require_str_or_str_list(config, "command", context=context, allow_empty=False)
    if "args" in config:
        _require_str_list(config, "args", context=context)
    if "dry_run_command" in config:
        _require_str_or_str_list(config, "dry_run_command", context=context, allow_empty=False)
    if "dry_run_args" in config:
        _require_str_list(config, "dry_run_args", context=context)
    if "output_format" in config and config["output_format"] not in {
        "text",
        "json",
        "jsonl",
        "auto",
    }:
        raise ConfigError(
            f"{context} key 'output_format' must be 'text', 'json', 'jsonl', or 'auto'"
        )
    if "success_exit_codes" in config:
        value = config["success_exit_codes"]
        if not isinstance(value, list) or not all(_is_int_code(item) for item in value):
            raise ConfigError(f"{context} key 'success_exit_codes' must be a list of integers")
    if "env" in config:
        value = config["env"]
        if not isinstance(value, dict) or not all(isinstance(k, str) for k in value):
            raise ConfigError(f"{context} key 'env' must be a mapping with string keys")
    if "cwd" in config:
        _require_str(config, "cwd", context=context, allow_empty=False)
    if "timeout_seconds" in config and config["timeout_seconds"] is not None:
        _require_positive_number(config, "timeout_seconds", context=context)


def _require_str(
    config: dict[str, Any],
    key: str,
    *,
    context: str,
    allow_empty: bool = True,
) -> None:
    value = config.get(key)
    if not isinstance(value, str):
        raise ConfigError(f"{context} key '{key}' must be a string")
    if not allow_empty and not value.strip():
        raise ConfigError(f"{context} key '{key}' must not be empty")


def _require_non_negative_int(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ConfigError(f"{context} key '{key}' must be a non-negative integer")


def _require_positive_number(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
        raise ConfigError(f"{context} key '{key}' must be a positive number")


def _require_non_negative_number(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
        raise ConfigError(f"{context} key '{key}' must be a non-negative number")


def _require_percentage(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 100:
        raise ConfigError(f"{context} key '{key}' must be a number between 0 and 100")


def _require_str_list(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigError(f"{context} key '{key}' must be a list of strings")


def _require_str_or_str_list(
    config: dict[str, Any],
    key: str,
    *,
    context: str,
    allow_empty: bool = True,
) -> None:
    value = config.get(key)
    if isinstance(value, str):
        if not allow_empty and not value.strip():
            raise ConfigError(f"{context} key '{key}' must not be empty")
        return
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        if not allow_empty and not value:
            raise ConfigError(f"{context} key '{key}' must not be empty")
        if not allow_empty and any(not item.strip() for item in value):
            raise ConfigError(f"{context} key '{key}' must not contain empty strings")
        return
    raise ConfigError(f"{context} key '{key}' must be a string or list of strings")


def _require_str_mapping(config: dict[str, Any], key: str, *, context: str) -> None:
    value = config.get(key)
    if not isinstance(value, dict) or not all(
        isinstance(k, str) and isinstance(v, str) for k, v in value.items()
    ):
        raise ConfigError(f"{context} key '{key}' must be a mapping of strings")


def _require_bool(config: dict[str, Any], key: str, *, context: str) -> None:
    if not isinstance(config.get(key), bool):
        raise ConfigError(f"{context} key '{key}' must be a boolean")


def _is_int_code(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _validate_dependency_graph(tasks: dict[str, Any]) -> None:
    graph = {
        name: cfg.get("depends_on", [])
        for name, cfg in tasks.items()
        if isinstance(cfg, dict) and isinstance(cfg.get("depends_on", []), list)
    }
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(name: str, path: list[str]) -> None:
        if name in visited:
            return
        if name in visiting:
            cycle = " -> ".join([*path, name])
            raise ConfigError(f"Task dependency cycle detected: {cycle}")
        visiting.add(name)
        for dep in graph.get(name, []):
            if dep in graph:
                visit(dep, [*path, name])
        visiting.remove(name)
        visited.add(name)

    for task_name in graph:
        visit(task_name, [])


def _require_hook(value: Any, key: str, *, context: str) -> None:
    if isinstance(value, str):
        return
    if isinstance(value, dict):
        _validate_hook_spec(value, key, context=context)
        return
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                continue
            if isinstance(item, dict):
                _validate_hook_spec(item, key, context=context)
                continue
            raise ConfigError(f"{context} key '{key}' must be a string or list of hook specs")
        return
    raise ConfigError(f"{context} key '{key}' must be a string or list of hook specs")


def _validate_hook_spec(value: dict[str, Any], key: str, *, context: str) -> None:
    hook_type = value.get("type", "shell")
    if hook_type not in {"shell", "agent"}:
        raise ConfigError(f"{context} key '{key}.type' must be 'shell' or 'agent'")
    if hook_type == "shell":
        if "command" not in value or not isinstance(value["command"], str) or not value["command"]:
            raise ConfigError(f"{context} key '{key}.command' must be a non-empty string")
        return
    has_url = any(
        isinstance(value.get(name), str) and value.get(name)
        for name in ("url", "webhook_url", "webhook_url_env")
    )
    if not has_url:
        raise ConfigError(
            f"{context} key '{key}' agent hook needs url, webhook_url, or webhook_url_env"
        )
    if "message" in value and not isinstance(value["message"], str):
        raise ConfigError(f"{context} key '{key}.message' must be a string")


def _validate_notify_config(value: Any, *, context: str) -> None:
    if not isinstance(value, dict):
        raise ConfigError(f"{context} key 'notify' must be a mapping")

    if "on" in value:
        events = [value["on"]] if isinstance(value["on"], str) else value["on"]
        if not isinstance(events, list) or not all(isinstance(item, str) for item in events):
            raise ConfigError(f"{context} key 'notify.on' must be a string or list of strings")
        unknown = sorted({item.lower() for item in events} - {"success", "failure", "complete"})
        if unknown:
            raise ConfigError(
                f"{context} key 'notify.on' unknown event(s): {', '.join(unknown)}"
            )

    if "message" in value and not isinstance(value["message"], str):
        raise ConfigError(f"{context} key 'notify.message' must be a string")

    for provider in ("discord", "telegram"):
        if provider in value:
            provider_config = value[provider]
            if not isinstance(provider_config, dict):
                raise ConfigError(f"{context} key 'notify.{provider}' must be a mapping")
            if "enabled" in provider_config and not isinstance(provider_config["enabled"], bool):
                raise ConfigError(f"{context} key 'notify.{provider}.enabled' must be a boolean")

    discord = value.get("discord")
    if isinstance(discord, dict):
        for key in ("webhook_url", "webhook_url_env", "username", "channel"):
            if key in discord and not isinstance(discord[key], str):
                raise ConfigError(f"{context} key 'notify.discord.{key}' must be a string")

    telegram = value.get("telegram")
    if isinstance(telegram, dict):
        for key in ("bot_token", "bot_token_env", "chat_id", "chat", "parse_mode"):
            if key in telegram and not isinstance(telegram[key], str):
                raise ConfigError(f"{context} key 'notify.telegram.{key}' must be a string")
