"""Generate systemd timer + service unit files from Docket schedule config."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def cron_to_systemd(cron_expr: str) -> str:
    """Convert a 5-field cron expression to a systemd OnCalendar expression.

    Handles common patterns:
        */5 * * * *   → *:0/5          (every 5 minutes)
        0 */6 * * *   → *:0/6          (every 6 hours)
        0 2 * * *     → *-*-* 02:00:00 (daily at 2am)
        0 0 * * 1     → Mon *-*-* 00:00:00 (weekly Monday)
        0 0 1 * *    → *-*-01 00:00:00    (monthly)

    Falls back to passing the expression through unchanged if it cannot be parsed.
    """
    parts = cron_expr.strip().split()
    if len(parts) != 5:
        # Not a standard 5-field cron — pass through.
        return cron_expr

    minute, hour, day_of_month, month, day_of_week = parts

    # All wildcards — every minute.
    if all(p == "*" for p in parts):
        return "*:*"

    # Every N minutes: */N * * * * → *:0/N
    if (
        minute.startswith("*/")
        and hour == "*"
        and day_of_month == "*"
        and month == "*"
        and day_of_week == "*"
    ):
        n = minute[2:]
        if n == "1":
            return "*:*"
        return f"*:0/{n}"

    # Every N hours on the hour: 0 */N * * * → *:*:0/N
    if (
        minute == "0"
        and hour.startswith("*/")
        and day_of_month == "*"
        and month == "*"
        and day_of_week == "*"
    ):
        n = hour[2:]
        return f"*:*:0/{n}"

    # Every hour on the hour: 0 * * * * → *-*-* *:00:00
    if (
        minute not in ("*",)
        and not minute.startswith("*/")
        and hour == "*"
        and day_of_month == "*"
        and month == "*"
        and day_of_week == "*"
    ):
        return f"*-*-* *:{int(minute):02d}:00"

    # Specific day of week + time: MM HH * * D → Day *-*-* HH:MM:00
    day_map = {
        "0": "Sun",
        "7": "Sun",
        "1": "Mon",
        "2": "Tue",
        "3": "Wed",
        "4": "Thu",
        "5": "Fri",
        "6": "Sat",
    }
    if (
        day_of_week in day_map
        and day_of_month == "*"
        and month == "*"
        and minute not in ("*",)
        and not minute.startswith("*/")
        and hour not in ("*",)
        and not hour.startswith("*/")
    ):
        weekday = day_map[day_of_week]
        return f"{weekday} *-*-* {int(hour):02d}:{int(minute):02d}:00"

    # Specific day of month + time: MM HH D * * → *-*-D HH:MM:00
    if (
        day_of_month != "*"
        and month == "*"
        and day_of_week == "*"
        and minute not in ("*",)
        and not minute.startswith("*/")
        and hour not in ("*",)
        and not hour.startswith("*/")
    ):
        return f"*-*-{int(day_of_month):02d} {int(hour):02d}:{int(minute):02d}:00"

    # Specific hour and minute with all days: MM HH * * * → *-*-* HH:MM:00
    # This must come AFTER the day-of-week and day-of-month checks so those
    # more specific patterns match first.
    if (
        day_of_month == "*"
        and month == "*"
        and day_of_week == "*"
        and minute not in ("*",)
        and not minute.startswith("*/")
        and hour not in ("*",)
        and not hour.startswith("*/")
    ):
        return f"*-*-* {int(hour):02d}:{int(minute):02d}:00"

    # Fallback: pass through the original expression.
    return cron_expr


def generate_service_unit(task_name: str, task_config: dict[str, Any]) -> str:
    """Generate a systemd service unit file content for a Docket task.

    The service runs ``docket run <task>`` as a oneshot unit.
    """
    description = task_config.get("description", f"Docket task: {task_name}")
    # Determine the docket executable path.
    docket_bin = task_config.get("docket_bin", "docket")

    lines = [
        "[Unit]",
        f"Description={description}",
        "",
        "[Service]",
        "Type=oneshot",
        f"ExecStart={docket_bin} run {task_name}",
        "",
        "[Install]",
        "WantedBy=multi-user.target",
    ]
    return "\n".join(lines) + "\n"


def generate_timer_unit(task_name: str, task_config: dict[str, Any]) -> str:
    """Generate a systemd timer unit file content for a Docket task.

    The timer uses the ``schedule`` key from task config, converted to
    systemd ``OnCalendar=`` format.
    """
    description = task_config.get("description", f"Docket timer for: {task_name}")
    cron_expr = task_config.get("schedule", "* * * * *")
    on_calendar = cron_to_systemd(cron_expr)

    lines = [
        "[Unit]",
        f"Description={description}",
        "",
        "[Timer]",
        f"OnCalendar={on_calendar}",
        "Persistent=true",
        "",
        "[Install]",
        "WantedBy=timers.target",
    ]
    return "\n".join(lines) + "\n"


def install_units(
    task_name: str,
    task_config: dict[str, Any],
    output_dir: Path | None = None,
) -> list[Path]:
    """Generate and write systemd unit files for a scheduled Docket task.

    Args:
        task_name: The task name (used for unit file naming).
        task_config: Task config dict; must contain a ``schedule`` key.
        output_dir: Directory to write unit files into.
            Defaults to ``~/.config/systemd/user/``.

    Returns:
        List of paths to the generated unit files.
    """
    if "schedule" not in task_config:
        return []

    if output_dir is None:
        output_dir = Path.home() / ".config" / "systemd" / "user"

    output_dir.mkdir(parents=True, exist_ok=True)

    service_content = generate_service_unit(task_name, task_config)
    timer_content = generate_timer_unit(task_name, task_config)

    service_path = output_dir / f"docket-{task_name}.service"
    timer_path = output_dir / f"docket-{task_name}.timer"

    service_path.write_text(service_content)
    timer_path.write_text(timer_content)

    return [service_path, timer_path]


def get_scheduled_tasks(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Return a dict of {task_name: task_config} for tasks that have a schedule key."""
    tasks = config.get("tasks", {})
    if not isinstance(tasks, dict):
        return {}
    return {name: cfg for name, cfg in tasks.items() if isinstance(cfg, dict) and "schedule" in cfg}
