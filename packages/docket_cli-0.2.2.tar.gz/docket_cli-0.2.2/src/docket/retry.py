"""Retry with exponential backoff for task execution."""

from __future__ import annotations

import logging
import time
from typing import Callable, TypeVar

logger = logging.getLogger("docket")

T = TypeVar("T")


def retry(
    fn: Callable[[], T],
    *,
    max_retries: int = 0,
    backoff_base: float = 2.0,
    max_wait: float = 60.0,
) -> T:
    """Execute *fn* with exponential backoff on failure.

    Args:
        fn: The callable to execute.
        max_retries: Maximum number of retry attempts (0 = no retries).
        backoff_base: Base for exponential backoff calculation.
            Wait time = backoff_base ** attempt, capped at max_wait.
        max_wait: Maximum wait time between retries in seconds.

    Returns:
        The result of *fn* on success.

    Raises:
        The last exception raised by *fn* after all retries are exhausted.
    """
    last_exc: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            result = fn()
            return result
        except Exception as exc:
            last_exc = exc
            if attempt < max_retries:
                wait = min(backoff_base**attempt, max_wait)
                logger.warning(
                    "Attempt %d/%d failed: %s — retrying in %.1fs",
                    attempt + 1,
                    max_retries + 1,
                    exc,
                    wait,
                )
                time.sleep(wait)
            else:
                logger.error(
                    "All %d attempt(s) exhausted. Last error: %s",
                    max_retries + 1,
                    exc,
                )

    # Should never reach here if max_retries >= 0, but satisfy the type checker.
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("retry() exited without a result or exception")
