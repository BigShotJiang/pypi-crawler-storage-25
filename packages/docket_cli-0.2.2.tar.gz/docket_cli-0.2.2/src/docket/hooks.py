"""Notification hooks — run shell commands on task success or failure."""

import json
import logging
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from typing import Any

from docket.notify import Notifier
from docket.utils import safe_format

logger = logging.getLogger("docket.hooks")
ENV_VAR_RE = re.compile(r"\$(?P<unix>[A-Za-z_][A-Za-z0-9_]*)|%(?P<windows>[A-Za-z_][A-Za-z0-9_]*)%")


class Hooks:
    """Execute notification hooks (shell commands) after task runs.

    Hooks are configured per-task under ``on_success`` / ``on_failure`` keys
    in ``~/.docket/config.yaml``.  Each hook can be a single shell command
    string or a list of strings.

    Hook execution is *non-blocking*: a failing hook never changes the
    task's own result.  All results are captured and returned for
    debugging / JSON reporting.
    """

    TIMEOUT = 30  # seconds per command

    def __init__(self, task_config: dict[str, Any]) -> None:
        self._on_success = task_config.get("on_success")
        self._on_failure = task_config.get("on_failure")
        self._on_complete = task_config.get("on_complete")
        self._notifier = Notifier(task_config)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_hooks(
        self,
        hook_type: str,
        result: Any = None,
        run_record: dict[str, Any] | None = None,
    ) -> list[tuple[str, int, str, str]]:
        """Run hooks for the given *hook_type* (``"on_success"`` or ``"on_failure"``).

        Returns a list of ``(command, exit_code, stdout, stderr)`` tuples,
        one per hook command that was executed.
        """
        hooks = self._get_hooks(hook_type)
        if not hooks:
            return []

        logger.info("Running %d %s hook(s)", len(hooks), hook_type)
        outcomes: list[tuple[str, int, str, str]] = []

        env = _hook_env(result, run_record)
        for hook in hooks:
            if hook["type"] == "agent":
                outcomes.append(self._run_agent(hook, result=result, run_record=run_record))
            else:
                outcomes.append(self._run_one(hook["command"], env=env))

        return outcomes

    def run_notifications(
        self,
        event: str,
        result: Any = None,
        run_record: dict[str, Any] | None = None,
    ) -> list[tuple[str, int, str, str]]:
        """Run native notification providers for a terminal task event."""
        return self._notifier.notify(event=event, result=result, run_record=run_record)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _get_hooks(self, hook_type: str) -> list[dict[str, Any]]:
        """Return normalized hook specs for *hook_type*."""
        raw: str | dict[str, Any] | list[Any] | None
        if hook_type == "on_success":
            raw = self._on_success
        elif hook_type == "on_failure":
            raw = self._on_failure
        elif hook_type == "on_complete":
            raw = self._on_complete
        else:
            logger.warning("Unknown hook type: %s", hook_type)
            return []

        if raw is None:
            return []
        if isinstance(raw, str):
            return [{"type": "shell", "command": raw}]
        if isinstance(raw, dict):
            return [self._normalize_hook(raw)]
        if isinstance(raw, list):
            return [
                self._normalize_hook(item)
                for item in raw
                if isinstance(item, (str, dict))
            ]
        logger.warning(
            "Hook value for %s must be str, dict, or list, got %s",
            hook_type,
            type(raw).__name__,
        )
        return []

    @staticmethod
    def _normalize_hook(raw: str | dict[str, Any]) -> dict[str, Any]:
        if isinstance(raw, str):
            return {"type": "shell", "command": raw}
        hook = dict(raw)
        hook.setdefault("type", "shell")
        return hook

    @staticmethod
    def _run_one(
        command: str,
        *,
        env: dict[str, str] | None = None,
    ) -> tuple[str, int, str, str]:
        """Execute a single shell command with a timeout.

        Returns ``(command, exit_code, stdout, stderr)``.
        On timeout, exit_code is ``-1`` and stderr includes a message.
        On other errors (command not found, etc.), exit_code is the OS
        error number or ``-2``.
        """
        # Security note: we use shell=True to allow pipes/redirects in hook
        # commands. Environment variable expansion is intentional (e.g. $TASK_NAME)
        # but means that commands sourcing from untrusted YAML are effectively
        # arbitrary shell execution. Hook commands should only come from config
        # files the operator controls.
        subprocess_env = os.environ.copy()
        if env:
            subprocess_env.update(env)
        expanded = _expand_command(command, subprocess_env)
        try:
            if sys.platform == "win32":
                proc = subprocess.run(
                    ["powershell", "-NoProfile", "-Command", expanded],
                    capture_output=True,
                    text=True,
                    timeout=Hooks.TIMEOUT,
                    env=subprocess_env,
                )
            else:
                proc = subprocess.run(
                    expanded,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=Hooks.TIMEOUT,
                    env=subprocess_env,
                )
            exit_code = proc.returncode
            stdout = proc.stdout
            stderr = proc.stderr
            if sys.platform == "win32" and exit_code == 1 and "not recognized" in stderr:
                exit_code = 127

            if exit_code == 0:
                logger.info("Hook succeeded: %s", command)
            else:
                logger.warning("Hook exited %d: %s", exit_code, command)

        except subprocess.TimeoutExpired:
            exit_code = -1
            stdout = ""
            stderr = f"Hook timed out after {Hooks.TIMEOUT}s"
            logger.error("Hook timed out: %s", command)

        except Exception as exc:  # noqa: BLE001 — broad catch is intentional
            exit_code = -2
            stdout = ""
            stderr = str(exc)
            logger.error("Hook error: %s — %s", command, exc)

        return (command, exit_code, stdout.strip(), stderr.strip())

    @staticmethod
    def _run_agent(
        hook: dict[str, Any],
        *,
        result: Any = None,
        run_record: dict[str, Any] | None = None,
    ) -> tuple[str, int, str, str]:
        url = _agent_hook_url(hook)
        label = f"agent:{url or '(missing-url)'}"
        if not url:
            return (label, -2, "", "Missing agent webhook URL")

        payload = _agent_payload(hook, result=result, run_record=run_record)
        data = json.dumps(payload, default=str).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": "docket-agent-hook"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=Hooks.TIMEOUT) as response:
                body = response.read().decode("utf-8", errors="replace")
                return (label, int(response.status), body.strip(), "")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            return (label, int(exc.code), body.strip(), str(exc))
        except Exception as exc:  # noqa: BLE001 - hook failures are non-blocking
            return (label, -2, "", str(exc))


def _hook_env(result: Any = None, run_record: dict[str, Any] | None = None) -> dict[str, str]:
    env: dict[str, str] = {}
    if run_record:
        env.update(
            {
                "DOCKET_RUN_ID": str(run_record.get("run_id", "")),
                "DOCKET_TASK_NAME": str(run_record.get("task_name", "")),
                "DOCKET_STATUS": str(run_record.get("status", "")),
                "DOCKET_STARTED_AT": str(run_record.get("started_at", "")),
                "DOCKET_FINISHED_AT": str(run_record.get("finished_at", "")),
                "DOCKET_DURATION_SECONDS": str(run_record.get("duration_seconds", "")),
                "DOCKET_EXIT_CODE": str(run_record.get("exit_code", "")),
                "DOCKET_SUMMARY": str(run_record.get("summary", "")),
                "DOCKET_DETAILS_JSON": json.dumps(run_record.get("details", {})),
            }
        )
        log_path = run_record.get("details", {}).get("log_path")
        if log_path:
            env["DOCKET_LOG_PATH"] = str(log_path)
    if result is not None:
        env.setdefault("DOCKET_SUMMARY", str(getattr(result, "summary", "")))
        env.setdefault("DOCKET_EXIT_CODE", str(getattr(result, "exit_code", "")))
        env.setdefault("DOCKET_DETAILS_JSON", json.dumps(getattr(result, "details", {})))
    return env


def _agent_hook_url(hook: dict[str, Any]) -> str:
    if hook.get("url"):
        return str(hook["url"])
    if hook.get("webhook_url"):
        return str(hook["webhook_url"])
    if hook.get("webhook_url_env"):
        return os.environ.get(str(hook["webhook_url_env"]), "")
    return ""


def _agent_payload(
    hook: dict[str, Any],
    *,
    result: Any = None,
    run_record: dict[str, Any] | None = None,
) -> dict[str, Any]:
    task_name = ""
    run_id = ""
    status = ""
    summary = ""
    details: dict[str, Any] = {}
    exit_code: int | None = None

    if run_record:
        task_name = str(run_record.get("task_name", ""))
        run_id = str(run_record.get("run_id", ""))
        status = str(run_record.get("status", ""))
        summary = str(run_record.get("summary", ""))
        details = run_record.get("details", {}) or {}
        exit_code = run_record.get("exit_code")
    if result is not None:
        summary = str(getattr(result, "summary", summary))
        details = getattr(result, "details", details) or {}
        exit_code = getattr(result, "exit_code", exit_code)
        status = status or ("succeeded" if getattr(result, "ok", False) else "failed")

    details_json = json.dumps(details, default=str)
    values = {
        "task_name": task_name,
        "run_id": run_id,
        "status": status,
        "exit_code": "" if exit_code is None else str(exit_code),
        "summary": summary,
        "details_json": details_json,
    }
    message_template = hook.get("message", "{task_name} {status}: {summary}")
    message = safe_format(str(message_template), values)
    return {
        "task_name": task_name,
        "run_id": run_id,
        "status": status,
        "exit_code": exit_code,
        "summary": summary,
        "details_json": details_json,
        "message": message,
    }


def _expand_command(command: str, env: dict[str, str]) -> str:
    def replace(match: re.Match[str]) -> str:
        key = match.group("unix") or match.group("windows")
        return env.get(key, match.group(0))

    return ENV_VAR_RE.sub(replace, command)
