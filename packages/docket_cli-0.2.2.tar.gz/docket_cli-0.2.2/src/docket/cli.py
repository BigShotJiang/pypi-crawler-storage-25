"""Click CLI — root group and subcommands."""

from __future__ import annotations

import json
import logging
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import click
import yaml

from docket import __version__, core
from docket.config import DEFAULT_CONFIG_PATH, ConfigError, load_config
from docket.core import (
    DocketError,
)
from docket.core import (
    spawn_async_run as _spawn_async_run,
)
from docket.core import (
    terminate_pid as _terminate_pid,
)
from docket.core import (
    wait_for_pid_exit as _wait_for_pid_exit,
)
from docket.logging import setup_logging
from docket.state import StateStore
from docket.systemd import (
    cron_to_systemd,
    generate_service_unit,
    generate_timer_unit,
    get_scheduled_tasks,
    install_units,
)

logger = logging.getLogger("docket.cli")
TASK_NAME_RE = re.compile(r"^[a-z][a-z0-9-]*$")


def _load_config() -> dict[str, Any]:
    try:
        return load_config()
    except ConfigError as exc:
        raise click.ClickException(str(exc)) from exc


def _editor_command(editor: str, config_path: Path) -> list[str]:
    """Build a portable editor command for configure."""
    if editor in {"true", "false"}:
        exit_code = "0" if editor == "true" else "1"
        return [sys.executable, "-c", f"import sys; sys.exit({exit_code})", str(config_path)]

    parts = shlex.split(editor, posix=os.name != "nt")
    if not parts:
        raise click.ClickException("EDITOR is empty")

    executable = Path(parts[0])
    if os.name == "nt" and executable.suffix.lower() == ".py":
        return [sys.executable, *parts, str(config_path)]

    return [*parts, str(config_path)]


def _tail_lines(text: str, count: int | None) -> str:
    if count is None:
        return text
    if count <= 0:
        return ""
    lines = text.splitlines(keepends=True)
    return "".join(lines[-count:])


def _follow_log(
    log_path: Path,
    run_id: str,
    state_path: str,
    poll_interval: float,
    start_position: int = 0,
) -> None:
    terminal_statuses = {"succeeded", "failed", "timed_out", "cancelled", "skipped"}
    position = start_position
    while True:
        if log_path.exists():
            with log_path.open("r", errors="replace") as handle:
                handle.seek(position)
                chunk = handle.read()
                position = handle.tell()
            if chunk:
                click.echo(chunk, nl=False)

        with StateStore(state_path) as state:
            rec = state.get_run(run_id)
        if rec is None or rec["status"] in terminal_statuses:
            if log_path.exists():
                with log_path.open("r", errors="replace") as handle:
                    handle.seek(position)
                    chunk = handle.read()
                if chunk:
                    click.echo(chunk, nl=False)
            return

        time.sleep(max(poll_interval, 0.1))


def _print_event_records(records: list[dict[str, Any]]) -> int:
    last_index = 0
    for record in records:
        event_type = record["event_type"] or "event"
        click.echo(
            f"  #{record['event_index']} {record['timestamp']} "
            f"{event_type}: {json.dumps(record['event'], default=str)}"
        )
        last_index = max(last_index, int(record["event_index"]))
    return last_index


def _follow_events(
    run_id: str,
    state_path: str,
    last_seen_index: int,
    poll_interval: float,
) -> None:
    terminal_statuses = {"succeeded", "failed", "timed_out", "cancelled", "skipped"}
    while True:
        with StateStore(state_path) as state:
            rec = state.get_run(run_id)
            records = state.list_events(run_id, limit=5000)

        new_records = [
            record for record in records if int(record["event_index"]) > last_seen_index
        ]
        if new_records:
            last_seen_index = _print_event_records(new_records)

        if rec is None or rec["status"] in terminal_statuses:
            return

        time.sleep(max(poll_interval, 0.1))


def _class_name_from_task_name(task_name: str) -> str:
    return "".join(part.capitalize() for part in task_name.split("-")) + "Task"


def _task_template(task_name: str, class_name: str, description: str) -> str:
    # `description` is interpolated as a Python repr (e.g. "foo" -> '"foo"')
    # so attacker-controlled CLI input cannot break out of the string literal
    # and inject code that would later run when the registry imports this file.
    return f'''"""Drop-in Docket task: {task_name}."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from docket.task import BaseTask, TaskResult


class {class_name}(BaseTask):
    name = "{task_name}"
    description = {description!r}
    inputs = {{
        "output_path": "File path for the generated artifact",
    }}
    outputs = {{
        "output_path": "Path written by the task",
    }}
    schema = {{
        "output_path": {{"type": "string", "required": False}},
    }}
    required_env: list[str] = []
    destructive = False
    network = False

    def run(self, config: dict[str, Any]) -> TaskResult:
        default_path = "~/.docket/output/{task_name}.txt"
        output_path = Path(config.get("output_path", default_path)).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("Hello from {task_name}\\n", encoding="utf-8")
        return TaskResult(
            ok=True,
            summary=f"Wrote {{output_path}}",
            details={{"output_path": str(output_path)}},
        )

    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        default_path = "~/.docket/output/{task_name}.txt"
        output_path = Path(config.get("output_path", default_path)).expanduser()
        return TaskResult(
            ok=True,
            summary=f"Would write {{output_path}}",
            details={{"output_path": str(output_path)}},
            dry_run=True,
        )
'''


def _build_run_text_output(payload: dict[str, Any]) -> str:
    """Format a successful/failed task run payload for terminal output."""
    dry_run = bool(payload.get("dry_run"))
    ok = bool(payload.get("ok"))
    prefix = "[DRY RUN] " if dry_run else ""
    status = "OK" if ok else "FAILED"
    retry_count = int(payload.get("retry_count", 0) or 0)
    retry_suffix = f" (after {retry_count} retries)" if retry_count > 0 else ""
    duration = payload.get("duration_seconds")
    duration_suffix = f" [{duration:.2f}s]" if isinstance(duration, (int, float)) else ""
    run_id = payload.get("run_id")
    run_suffix = f" (run {run_id})" if run_id else ""
    summary = payload.get("summary", "")
    return f"{prefix}{status}{retry_suffix}{duration_suffix}: {summary}{run_suffix}"


@click.group()
@click.version_option(version=__version__, prog_name="docket")
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v INFO, -vv DEBUG).")
@click.option(
    "--json", "json_mode", is_flag=True, help="Output structured JSON for agent consumption."
)
@click.pass_context
def cli(ctx: click.Context, verbose: int, json_mode: bool) -> None:
    """Docket — Deterministic task runner for AI agents."""
    ctx.ensure_object(dict)
    ctx.obj["json_mode"] = json_mode
    setup_logging(json_mode=json_mode, verbosity=verbose)


@cli.command("list")
@click.pass_context
def list_tasks(ctx: click.Context) -> None:
    """List all available tasks and their last run status."""
    json_mode = ctx.obj["json_mode"]
    try:
        entries = core.list_tasks()
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    if json_mode:
        click.echo(json.dumps(entries, indent=2, default=str))
        return

    if not entries:
        click.echo("No tasks available.")
        return
    for entry in entries:
        rec = entry["last_run"]
        status_line = ""
        if rec:
            status_line = f"  (last: exit={rec['exit_code']} at {rec['last_run']})"
        click.echo(f"  {entry['name']:30s} {entry['description']}{status_line}")


@cli.command("capabilities")
@click.pass_context
def capabilities(ctx: click.Context) -> None:
    """Return agent-facing command and task metadata."""
    json_mode = ctx.obj["json_mode"]
    try:
        payload = core.capabilities()
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    if json_mode:
        click.echo(json.dumps(payload, indent=2, default=str))
        return

    click.echo("Docket capabilities:")
    click.echo(f"  tasks_dir: {payload['config']['tasks_dir']}")
    click.echo(f"  logs_dir:  {payload['config']['logs_dir']}")
    click.echo("\nCommands:")
    for command in payload["commands"]:
        click.echo(f"  {command['name']:24s} {command['summary']}")
    click.echo("\nTasks:")
    if not payload["tasks"]:
        click.echo("  No tasks available.")
    for task in payload["tasks"]:
        flags = []
        if task["network"]:
            flags.append("network")
        if task["destructive"]:
            flags.append("destructive")
        suffix = f" [{', '.join(flags)}]" if flags else ""
        click.echo(f"  {task['name']:24s} {task['description']}{suffix}")


@cli.command("new-task")
@click.argument("task_name")
@click.option("--description", default=None, help="Task description for docket list/describe.")
@click.option("--force", is_flag=True, help="Overwrite an existing drop-in task file.")
@click.pass_context
def new_task(ctx: click.Context, task_name: str, description: str | None, force: bool) -> None:
    """Scaffold a personalized drop-in task."""
    config = _load_config()
    json_mode = ctx.obj["json_mode"]
    if not TASK_NAME_RE.match(task_name):
        raise click.ClickException(
            "Task name must start with a lowercase letter and contain only lowercase "
            "letters, digits, and hyphens."
        )
    if description is not None and any(ch in description for ch in ("\n", "\r", "\x00")):
        raise click.ClickException("Task description must be a single line.")

    tasks_dir = Path(config["tasks_dir"])
    tasks_dir.mkdir(parents=True, exist_ok=True)
    if os.name == "posix":
        try:
            os.chmod(tasks_dir, 0o700)
        except OSError:
            pass
    task_path = tasks_dir / f"{task_name.replace('-', '_')}.py"
    if task_path.exists() and not force:
        raise click.ClickException(f"Task file already exists: {task_path}")

    class_name = _class_name_from_task_name(task_name)
    task_description = description or f"Personalized task: {task_name}"
    task_path.write_text(_task_template(task_name, class_name, task_description), encoding="utf-8")

    payload = {
        "created": True,
        "task": task_name,
        "class_name": class_name,
        "path": str(task_path),
        "next_steps": [
            f"Edit {task_path}",
            f"docket describe {task_name}",
            f"docket run {task_name} --dry-run",
        ],
    }
    if json_mode:
        click.echo(json.dumps(payload, indent=2))
    else:
        click.echo(f"Created task '{task_name}' at {task_path}")
        click.echo(f"Next: edit the file, then run `docket run {task_name} --dry-run`.")


@cli.command()
@click.argument("task_name")
@click.option(
    "--dry-run", is_flag=True, help="Preview what the task would do without side effects."
)
@click.option("--force", is_flag=True, help="Skip 'already ran today' guard and lock acquisition.")
@click.option(
    "--async",
    "async_mode",
    is_flag=True,
    help="Start the task in the background and return a run ID immediately.",
)
@click.option("--run-id", "existing_run_id", hidden=True)
@click.option("--skip-daily-guard", is_flag=True, hidden=True)
@click.pass_context
def run(
    ctx: click.Context,
    task_name: str,
    dry_run: bool,
    force: bool,
    async_mode: bool,
    existing_run_id: str | None,
    skip_daily_guard: bool,
) -> None:
    """Execute a task."""
    json_mode = ctx.obj["json_mode"]
    try:
        payload = core.run_task(
            task_name,
            dry_run=dry_run,
            force=force,
            async_mode=async_mode,
            existing_run_id=existing_run_id,
            skip_daily_guard=skip_daily_guard,
            spawn_async=_spawn_async_run,
        )
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    # Daily-guard short-circuit
    if payload.get("skipped") and payload.get("reason") == "already_ran_today":
        if json_mode:
            click.echo(json.dumps({k: v for k, v in payload.items() if k != "exit_code"}))
        else:
            click.echo(f"Task '{task_name}' already ran today. Use --force to override.")
        ctx.exit(int(payload.get("exit_code", 0)))
        return

    # Lock contention (returned by core.run_task with status=locked)
    if payload.get("status") == "locked":
        msg = payload.get("error", "")
        if json_mode:
            click.echo(json.dumps({"error": msg, "task": task_name}))
        else:
            click.echo(msg)
        ctx.exit(int(payload.get("exit_code", 1)))
        return

    # Dependency-skipped run
    if payload.get("status") == "skipped":
        if json_mode:
            click.echo(json.dumps(payload, indent=2, default=str))
        else:
            skip_reason = payload.get("details", {}).get("reason", payload.get("summary"))
            click.echo(f"Skipping '{task_name}': {skip_reason}.")
            click.echo(f"SKIPPED: {skip_reason} (run {payload.get('run_id')})")
        ctx.exit(int(payload.get("exit_code", 0)))
        return

    # Async-mode receipt
    if payload.get("status") == "running":
        if json_mode:
            json_payload = {k: v for k, v in payload.items() if k != "exit_code"}
            click.echo(json.dumps(json_payload, indent=2, default=str))
        else:
            click.echo(
                f"Started '{task_name}' asynchronously as run {payload['run_id']} "
                f"(PID {payload['pid']})."
            )
        ctx.exit(int(payload.get("exit_code", 0)))
        return

    # Synchronous run completed (success or failure)
    if json_mode:
        click.echo(json.dumps(payload, indent=2, default=str))
    else:
        click.echo(_build_run_text_output(payload))
    ctx.exit(int(payload.get("exit_code", 0)))


@cli.command()
@click.argument("task_name", required=False)
@click.option("--run-id", help="Show a specific historical run by ID.")
@click.pass_context
def status(ctx: click.Context, task_name: str | None, run_id: str | None) -> None:
    """Show last run status for all tasks or a specific task."""
    json_mode = ctx.obj["json_mode"]
    try:
        result = core.task_status(task_name, run_id=run_id)
    except DocketError as exc:
        if json_mode:
            click.echo(json.dumps(exc.payload))
        else:
            click.echo(f"Run '{run_id}' was not found.")
        ctx.exit(exc.exit_code)
        return

    if run_id:
        rec = result
        if json_mode:
            click.echo(json.dumps(rec, indent=2, default=str))
        else:
            status_text = rec["status"].upper()
            duration = rec.get("duration_seconds")
            duration_text = f" in {duration:.2f}s" if duration is not None else ""
            click.echo(
                f"  {rec['task_name']} {status_text}{duration_text} "
                f"at {rec['finished_at']}"
            )
            if rec["summary"]:
                click.echo(f"    {rec['summary']}")
        return

    if task_name:
        rec = result
        if rec.get("status") == "never_run":
            if json_mode:
                click.echo(json.dumps(rec))
            else:
                click.echo(f"Task '{task_name}' has never been run.")
            return
        if json_mode:
            click.echo(json.dumps(rec, indent=2, default=str))
        else:
            status = "OK" if rec["exit_code"] == 0 else f"FAILED (exit {rec['exit_code']})"
            dr = " [DRY RUN]" if rec["dry_run"] else ""
            run = f" run={rec['run_id']}" if rec.get("run_id") else ""
            click.echo(f"  {rec['task_name']}: {status}{dr} at {rec['last_run']}{run}")
            if rec["summary"]:
                click.echo(f"    {rec['summary']}")
        return

    records = result
    if not records:
        click.echo("No tasks have been run yet." if not json_mode else "[]")
    elif json_mode:
        click.echo(json.dumps(records, indent=2, default=str))
    else:
        for rec in records:
            status = "OK" if rec["exit_code"] == 0 else f"FAIL({rec['exit_code']})"
            dr = " [DRY]" if rec["dry_run"] else ""
            run = f"  {rec['run_id']}" if rec.get("run_id") else ""
            click.echo(f"  {rec['task_name']:30s} {status}{dr}  {rec['last_run']}{run}")


@cli.command("runs")
@click.argument("task_name", required=False)
@click.option("--limit", default=20, show_default=True, help="Maximum runs to show.")
@click.pass_context
def runs(ctx: click.Context, task_name: str | None, limit: int) -> None:
    """List recent historical task runs."""
    json_mode = ctx.obj["json_mode"]
    try:
        records = core.task_runs(task_name, limit=limit)
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    if json_mode:
        click.echo(json.dumps(records, indent=2, default=str))
        return

    if not records:
        target = f" for '{task_name}'" if task_name else ""
        click.echo(f"No runs found{target}.")
        return

    for rec in records:
        duration = rec.get("duration_seconds")
        duration_text = f"{duration:.2f}s" if duration is not None else "-"
        exit_code = "-" if rec["exit_code"] is None else str(rec["exit_code"])
        click.echo(
            f"  {rec['run_id']}  {rec['task_name']:30s} "
            f"{rec['status']:10s} exit={exit_code:>2s} duration={duration_text}"
        )
        if rec["summary"]:
            click.echo(f"    {rec['summary']}")


@cli.command("wait")
@click.argument("run_id")
@click.option(
    "--timeout",
    "timeout_seconds",
    type=float,
    default=None,
    help="Maximum seconds to wait before returning a timeout error.",
)
@click.option(
    "--poll-interval",
    type=float,
    default=1.0,
    show_default=True,
    help="Seconds between state checks.",
)
@click.pass_context
def wait_for_run(
    ctx: click.Context,
    run_id: str,
    timeout_seconds: float | None,
    poll_interval: float,
) -> None:
    """Wait for a historical run to finish and return its final state."""
    json_mode = ctx.obj["json_mode"]
    try:
        rec = core.wait_for_run(run_id, timeout=timeout_seconds, poll_interval=poll_interval)
    except DocketError as exc:
        payload = exc.payload
        if json_mode:
            click.echo(json.dumps(payload, indent=2, default=str))
        else:
            if isinstance(payload, dict) and payload.get("status") == "not_found":
                click.echo(f"Run '{run_id}' was not found.")
            elif isinstance(payload, dict) and payload.get("status") == "wait_timeout":
                click.echo(
                    f"Timed out waiting for run '{run_id}' "
                    f"(last status: {payload.get('last_seen_status')})."
                )
            else:
                # Terminal completed run that ended non-zero
                rec = payload if isinstance(payload, dict) else None
                if rec is not None:
                    status_text = rec["status"].upper()
                    duration = rec.get("duration_seconds")
                    duration_text = f" in {duration:.2f}s" if duration is not None else ""
                    click.echo(
                        f"{rec['task_name']} {status_text}{duration_text}: {rec['summary']}"
                    )
                else:
                    click.echo(exc.message)
        ctx.exit(exc.exit_code)
        return

    if json_mode:
        click.echo(json.dumps(rec, indent=2, default=str))
    else:
        status_text = rec["status"].upper()
        duration = rec.get("duration_seconds")
        duration_text = f" in {duration:.2f}s" if duration is not None else ""
        click.echo(f"{rec['task_name']} {status_text}{duration_text}: {rec['summary']}")
    ctx.exit(rec["exit_code"] if rec["exit_code"] is not None else 0)


@cli.command("logs")
@click.argument("run_id")
@click.option("--tail", type=int, default=None, help="Show only the last N log lines.")
@click.option("--follow", is_flag=True, help="Follow log output until the run finishes.")
@click.option(
    "--poll-interval",
    type=float,
    default=1.0,
    show_default=True,
    help="Seconds between follow checks.",
)
@click.pass_context
def logs(
    ctx: click.Context,
    run_id: str,
    tail: int | None,
    follow: bool,
    poll_interval: float,
) -> None:
    """Show captured stdout/stderr for an async run."""
    json_mode = ctx.obj["json_mode"]

    if follow and json_mode:
        raise click.ClickException("logs --follow cannot be combined with --json")

    if follow:
        # Need direct access to state for follow-mode loop.
        config = _load_config()
        with StateStore(config["state_dir"]) as state:
            rec = state.get_run(run_id)
        if rec is None:
            click.echo(f"Run '{run_id}' was not found.")
            ctx.exit(1)
            return
        log_path_raw = rec["details"].get("log_path")
        if not log_path_raw:
            click.echo(f"Run '{run_id}' has no captured log.")
            ctx.exit(1)
            return
        log_path = Path(log_path_raw)
        if not log_path.exists():
            click.echo(f"Log file does not exist: {log_path}")
            ctx.exit(1)
            return
        content = _tail_lines(log_path.read_text(errors="replace"), tail)
        if content:
            click.echo(content, nl=False)
        _follow_log(
            log_path,
            run_id,
            config["state_dir"],
            poll_interval,
            start_position=log_path.stat().st_size,
        )
        return

    try:
        payload = core.run_logs(run_id, tail=tail)
    except DocketError as exc:
        if json_mode:
            click.echo(json.dumps(exc.payload))
        else:
            click.echo(exc.message)
        ctx.exit(exc.exit_code)
        return

    if json_mode:
        click.echo(json.dumps(payload, indent=2))
    else:
        content = payload["content"]
        click.echo(content, nl=not content.endswith("\n"))


@cli.command("events")
@click.argument("run_id")
@click.option("--limit", default=500, show_default=True, help="Maximum events to show.")
@click.option("--follow", is_flag=True, help="Follow events until the run finishes.")
@click.option(
    "--poll-interval",
    type=float,
    default=1.0,
    show_default=True,
    help="Seconds between follow checks.",
)
@click.pass_context
def events(
    ctx: click.Context,
    run_id: str,
    limit: int,
    follow: bool,
    poll_interval: float,
) -> None:
    """Show structured JSONL events recorded for a run."""
    json_mode = ctx.obj["json_mode"]
    if follow and json_mode:
        raise click.ClickException("events --follow cannot be combined with --json")

    try:
        records = core.run_events(run_id, limit=limit)
    except DocketError as exc:
        if json_mode:
            click.echo(json.dumps(exc.payload))
        else:
            click.echo(exc.message)
        ctx.exit(exc.exit_code)
        return

    if json_mode:
        click.echo(json.dumps(records, indent=2, default=str))
        return

    printed = _print_event_records(records)
    if follow:
        config = _load_config()
        _follow_events(run_id, config["state_dir"], printed, poll_interval)
        return

    if not records:
        click.echo(f"No events recorded for run '{run_id}'.")
        return


@cli.command("cancel")
@click.argument("run_id")
@click.pass_context
def cancel(ctx: click.Context, run_id: str) -> None:
    """Cancel a running async run by terminating its child process."""
    json_mode = ctx.obj["json_mode"]
    try:
        rec = core.cancel_run(
            run_id,
            _terminate=_terminate_pid,
            _wait_for_exit=_wait_for_pid_exit,
        )
    except DocketError as exc:
        if json_mode:
            click.echo(json.dumps(exc.payload))
        else:
            click.echo(exc.message)
        ctx.exit(exc.exit_code)
        return

    cancelled = bool(rec.get("cancelled"))
    pid = rec.get("details", {}).get("pid")
    if json_mode:
        click.echo(json.dumps(rec, indent=2, default=str))
    else:
        if rec.get("status") in ("succeeded", "failed", "timed_out"):
            click.echo(f"Run '{run_id}' is already {rec['status']}.")
        elif cancelled:
            click.echo(f"Cancelled run '{run_id}' (PID {pid}).")
        else:
            click.echo(f"Cancellation requested for run '{run_id}' (PID {pid}).")


@cli.command("mcp")
def mcp() -> None:
    """Run Docket's MCP stdio server."""
    try:
        from docket.mcp_server import main as mcp_main
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc

    mcp_main()


@cli.command()
@click.argument("task_name")
@click.pass_context
def describe(ctx: click.Context, task_name: str) -> None:
    """Show a task's description and configuration."""
    json_mode = ctx.obj["json_mode"]
    try:
        payload = core.describe_task(task_name)
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    if json_mode:
        click.echo(json.dumps(payload, indent=2, default=str))
    else:
        click.echo(f"Task: {payload['name']}")
        click.echo(f"Description: {payload['description']}")
        if payload["config"]:
            click.echo(f"Config: {json.dumps(payload['config'], indent=2, default=str)}")
        else:
            click.echo("Config: (default)")


@cli.command()
@click.argument("task_name", required=False)
@click.option(
    "--list", "list_only", is_flag=True, help="Show what would be generated without writing files."
)
@click.option(
    "--output-dir",
    default=None,
    help="Write units to this directory instead of ~/.config/systemd/user/.",
)
@click.pass_context
def install(
    ctx: click.Context, task_name: str | None, list_only: bool, output_dir: str | None
) -> None:
    """Generate systemd timer + service units for scheduled tasks."""
    config = _load_config()
    json_mode = ctx.obj["json_mode"]
    scheduled = get_scheduled_tasks(config)

    if not scheduled:
        if json_mode:
            click.echo(json.dumps({"installed": [], "message": "No scheduled tasks found"}))
        else:
            click.echo("No scheduled tasks found.")
        return

    if task_name:
        if task_name not in config.get("tasks", {}):
            raise click.ClickException(f"Unknown task: {task_name}")
        if task_name not in scheduled:
            if json_mode:
                click.echo(
                    json.dumps({"installed": [], "message": f"Task '{task_name}' has no schedule"})
                )
            else:
                click.echo(f"Task '{task_name}' has no schedule key.")
            return
        scheduled = {task_name: scheduled[task_name]}

    if list_only:
        entries = {}
        for name, cfg in sorted(scheduled.items()):
            entries[name] = {
                "schedule": cfg.get("schedule", ""),
                "service": generate_service_unit(name, cfg),
                "timer": generate_timer_unit(name, cfg),
            }
        if json_mode:
            click.echo(json.dumps(entries, indent=2, default=str))
        else:
            click.echo("Scheduled tasks:")
            for name, info in sorted(entries.items()):
                click.echo(f"  {name}:")
                click.echo(f"    schedule: {info['schedule']}")
                click.echo(f"    timer unit OnCalendar: {cron_to_systemd(info['schedule'])}")
        return

    if output_dir:
        unit_output_dir = Path(output_dir)
    else:
        unit_output_dir = Path.home() / ".config" / "systemd" / "user"

    installed_paths: list[str] = []
    for name, cfg in sorted(scheduled.items()):
        paths = install_units(name, cfg, output_dir=unit_output_dir)
        installed_paths.extend(str(p) for p in paths)

    if json_mode:
        click.echo(
            json.dumps(
                {
                    "installed": installed_paths,
                    "count": len(installed_paths),
                },
                indent=2,
            )
        )
    else:
        for p in installed_paths:
            click.echo(f"  Written: {p}")
        click.echo("\nRun 'systemctl --user daemon-reload' to activate")


@cli.command()
@click.pass_context
def configure(ctx: click.Context) -> None:
    """Open the Docket configuration file in your editor.

    If the config file does not exist, it is created with sensible defaults
    before opening.  After editing, the YAML is validated — if it cannot
    be parsed, you are prompted to re-edit or abort.
    """
    config_path = DEFAULT_CONFIG_PATH

    if not config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        defaults = {
            "state_dir": str(DEFAULT_CONFIG_PATH.parent / "state.db"),
            "tasks_dir": str(DEFAULT_CONFIG_PATH.parent / "tasks"),
            "logs_dir": str(DEFAULT_CONFIG_PATH.parent / "logs"),
            "tasks": {},
        }
        config_path.write_text(yaml.dump(defaults, default_flow_style=False, sort_keys=False))
        click.echo(f"Created default config at {config_path}")

    editor = os.environ.get("EDITOR", "vi")

    while True:
        try:
            subprocess.run(_editor_command(editor, config_path), check=False)
        except FileNotFoundError:
            raise click.ClickException(f"Editor '{editor}' not found. Set $EDITOR or install vi.")
        except OSError as exc:
            raise click.ClickException(f"Failed to launch editor: {exc}")

        try:
            load_config(config_path)
            click.echo("Configuration validated successfully.")
            break
        except (yaml.YAMLError, ConfigError) as exc:
            click.echo(f"Invalid configuration: {exc}", err=True)
            if not click.confirm("Re-edit to fix?", default=True):
                raise click.ClickException("Aborted; config file may be invalid.") from None


@cli.command()
@click.pass_context
def health(ctx: click.Context) -> None:
    """Summarize task health from latest state and run history."""
    json_mode = ctx.obj["json_mode"]
    try:
        payload = core.health()
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    if json_mode:
        click.echo(json.dumps(payload, indent=2, default=str))
        return

    click.echo(payload["summary"])
    for category in ("failed", "degraded", "stale", "never_run", "healthy"):
        tasks = payload[category]
        if tasks:
            click.echo(f"  {category}: {', '.join(tasks)}")


@cli.command()
@click.option("--agent", is_flag=True, help="Run deeper agent-oriented operational checks.")
@click.pass_context
def doctor(ctx: click.Context, agent: bool) -> None:
    """Health check for the Docket installation itself."""
    json_mode = ctx.obj["json_mode"]
    try:
        payload = core.doctor(agent=agent)
    except DocketError as exc:
        raise click.ClickException(exc.message) from exc

    all_ok = bool(payload["ok"])

    if agent:
        if json_mode:
            click.echo(
                json.dumps(
                    {
                        "healthy": payload["healthy"],
                        "checks": payload["checks"],
                        "installation_checks": payload["installation_checks"],
                    },
                    indent=2,
                    default=str,
                )
            )
            ctx.exit(0 if all_ok else 1)
            return
        # Human format: render installation checks first, then agent checks
        checks = list(payload["installation_checks"])
        for check in payload["checks"]:
            status = "ok" if check["ok"] else "error"
            detail = f": {check['detail']}" if check.get("detail") else ""
            checks.append({"check": check["name"], "status": status, "detail": detail})
        for c in checks:
            icon = "✓" if c["status"] == "ok" else "✗"
            click.echo(f"  {icon} {c['check']}: {c['status']}")
        if all_ok:
            click.echo("\nAll checks passed.")
        else:
            click.echo("\nSome checks failed. Run with --json for details.")
        ctx.exit(0 if all_ok else 1)
        return

    if json_mode:
        click.echo(json.dumps({"ok": all_ok, "checks": payload["checks"]}, indent=2))
    else:
        for c in payload["checks"]:
            icon = "✓" if c["status"] == "ok" else "✗"
            click.echo(f"  {icon} {c['check']}: {c['status']}")
        if all_ok:
            click.echo("\nAll checks passed.")
        else:
            click.echo("\nSome checks failed. Run with --json for details.")

    ctx.exit(0 if all_ok else 1)


if __name__ == "__main__":
    cli()
