"""Structured logging — human-readable or JSON modes."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any


class JSONFormatter(logging.Formatter):
    """Emit one JSON object per log record on a single line."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            payload["exception"] = self.formatException(record.exc_info)
        if hasattr(record, "docket_extra"):
            payload.update(record.docket_extra)
        return json.dumps(payload, default=str)


class HumanFormatter(logging.Formatter):
    """Coloured, human-friendly formatter for terminal output."""

    COLORS = {
        logging.DEBUG: "\033[36m",  # cyan
        logging.INFO: "\033[32m",  # green
        logging.WARNING: "\033[33m",  # yellow
        logging.ERROR: "\033[31m",  # red
        logging.CRITICAL: "\033[1;31m",  # bold red
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelno, "")
        # Strip colour if not a TTY.
        if not getattr(record, "isatty", True):
            color = ""
            reset = ""
        else:
            reset = self.RESET

        level = f"{color}{record.levelname:<8}{reset}" if color else f"{record.levelname:<8}"
        msg = record.getMessage()
        prefix = f"{level} "
        if record.name != "docket":
            prefix += f"[{record.name}] "
        output = prefix + msg

        if record.exc_info and record.exc_info[0] is not None:
            output += "\n" + self.formatException(record.exc_info)

        return output


def setup_logging(json_mode: bool = False, verbosity: int = 0) -> None:
    """Configure the ``docket`` logger.

    Args:
        json_mode: If True, emit JSON lines suitable for agent consumption.
        verbosity: 0 = WARNING, 1 = INFO, 2+ = DEBUG.
    """
    logger = logging.getLogger("docket")

    if verbosity >= 2:
        level = logging.DEBUG
    elif verbosity >= 1:
        level = logging.INFO
    else:
        level = logging.WARNING

    logger.setLevel(level)

    # Remove existing handlers (allows re-configuration).
    logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(level)

    if json_mode:
        handler.setFormatter(JSONFormatter(datefmt="%Y-%m-%dT%H:%M:%S"))
    else:
        fmt = HumanFormatter()
        handler.setFormatter(fmt)

    logger.addHandler(handler)

    # Tag records with TTY status so HumanFormatter can skip colours.
    # We patch the filter onto the handler so it runs before formatting.
    def _tty_filter(record: logging.LogRecord) -> bool:
        try:
            record.isatty = handler.stream.isatty()  # type: ignore[attr-defined]
        except ValueError:
            record.isatty = False  # type: ignore[attr-defined]
        return True

    handler.addFilter(_tty_filter)
