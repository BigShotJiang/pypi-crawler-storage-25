"""BaseTask ABC and TaskResult — the contract every task implements."""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class TaskResult:
    """Structured result returned by every task execution.

    Attributes:
        ok: Whether the task succeeded.
        summary: Human-readable one-line summary of what happened.
        details: Optional dict of machine-readable details for JSON output.
        dry_run: True when this result comes from a dry-run invocation.
    """

    ok: bool
    summary: str
    details: dict[str, Any] = field(default_factory=dict)
    dry_run: bool = False

    @property
    def exit_code(self) -> int:
        """Map result to an exit code.

        0 = success
        1 = failure
        2 = dry-run no-op
        """
        if self.dry_run and self.ok:
            return 2
        return 0 if self.ok else 1


class BaseTask(abc.ABC):
    """Abstract base class for all Docket tasks.

    Every task must define a ``name``, ``description``, and implement
    :meth:`run` and :meth:`dry_run`.

    ``run(config)`` executes the task for real and returns a :class:`TaskResult`.
    ``dry_run(config)`` previews what would happen without side effects.

    Set ``_skip_validation = True`` on a subclass to bypass name/description
    checks (useful for test fixtures).
    """

    name: str = ""
    description: str = ""
    inputs: dict[str, str] = {}
    outputs: dict[str, str] = {}
    schema: dict[str, Any] = {}
    required_env: list[str] = []
    destructive: bool = False
    network: bool = False
    _skip_validation: bool = False

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Skip validation for intermediate abstract classes or opt-out classes.
        if getattr(cls, "_skip_validation", False):
            return
        # Don't validate until instantiation — defer to __init__
        # so that test fixtures defining invalid classes don't explode at import.

    def __init__(self) -> None:
        """Validate name and description at instantiation time."""
        if not getattr(self, "_skip_validation", False):
            if not self.name:
                raise TypeError(f"{type(self).__qualname__} must define a non-empty 'name'")
            if not self.description:
                raise TypeError(f"{type(self).__qualname__} must define a non-empty 'description'")

    @abc.abstractmethod
    def run(self, config: dict[str, Any]) -> TaskResult:
        """Execute the task and return a result."""

    @abc.abstractmethod
    def dry_run(self, config: dict[str, Any]) -> TaskResult:
        """Preview what the task would do, without side effects."""
