# Engram — AI Agent Memory System

## Overview
AI 에이전트를 위한 지속적·구조적·신뢰할 수 있는 메모리 시스템.
SQLite+FTS5 기반, MCP 통합, 품질 게이트 내장.

## Tech Stack
- Language: Python 3.9+
- Storage: SQLite + FTS5 (표준 라이브러리, 제로 코어 의존성)
- Search: FTS5 내장 BM25 (기본) / 임베딩 시맨틱 (선택)
- Agent Integration: MCP 서버 (Codex / Codex)
- LLM: Optional 플러그인 (`pip install engram[llm]`)

## Project Structure
```
engram/
├── models/       # 순수 데이터 클래스 (로직 없음)
├── storage/      # SQLite+FTS5 백엔드 + Markdown 내보내기
├── search/       # FTS5 BM25 + 시맨틱 + 하이브리드
├── extraction/   # 정규식 NER + LLM 추출기
├── quality/      # 신뢰도, 충돌, PII 게이트
├── session/      # 세션 관리 + Working Memory
├── integrations/ # MCP 서버 + Python SDK
└── cli/          # 사람용 CLI 인터페이스
```

## Commands
- `pip install -e ".[dev]"` — 개발 설치
- `python3 -m pytest tests/ -v` — 전체 테스트
- `python3 -m engram.cli.app --db ~/.engram/memory.db init` — 메모리 DB 초기화
- `python3 -m engram.cli.app --db ~/.engram/memory.db store "텍스트"` — 정보 저장
- `python3 -m engram.cli.app --db ~/.engram/memory.db search "쿼리"` — 검색

## Engram Memory 사용 가이드 (Codex용)

### 대화에서 중요한 정보가 나왔을 때 — 저장하기

```bash
python3 -m engram.cli.app --db ~/.engram/memory.db store "저장할 정보"
```

### 이전 대화에서 논의한 내용이 필요할 때 — 검색하기

```bash
python3 -m engram.cli.app --db ~/.engram/memory.db search "검색어"
python3 -m engram.cli.app --db ~/.engram/memory.db --json search "검색어"
```

### 특정 인물/조직 정보 조회

```bash
python3 -m engram.cli.app --db ~/.engram/memory.db get "엔티티 이름"
python3 -m engram.cli.app --db ~/.engram/memory.db --json get "엔티티 이름"
```

### Python SDK로 직접 사용 (Bash 도구에서)

```python
python3 -c "
from pathlib import Path
from engram.config import EngramConfig
from engram.engine import MemoryEngine

engine = MemoryEngine(EngramConfig(base_dir=Path.home() / '.engram'))

# 저장
engine.store('저장할 텍스트')

# 검색
result = engine.search('검색어')
print(result.to_agent_context())

# 엔티티 조회
entity = engine.get_entity('이름')
facts = engine.get_facts('이름')

engine.close()
"
```

### 사용 시나리오

1. **사용자가 새로운 정보를 공유할 때**: `store`로 저장
2. **이전 대화 내용이 필요할 때**: `search`로 검색
3. **특정 인물/조직 배경이 필요할 때**: `get`으로 조회
4. **프로젝트 시작 시**: `search`로 관련 컨텍스트 로드

## Conventions
- 커밋 메시지: 한국어 허용, 변경 이유 중심으로 작성
- 코어 엔진에 `print()` 금지 — CLI 계층에서만 출력
- 모든 메서드는 구조화된 객체를 반환 (stdout 오염 없음)
- 타입 힌트 필수, `from __future__ import annotations` 사용
## Dependencies

- **jq** (필수): 모든 Codex hooks가 JSON 파싱에 사용. 미설치 시 hooks가 조용히 스킵됨
  - Windows: `winget install jqlang.jq`
  - macOS: `brew install jq`
  - Linux: `apt install jq` / `yum install jq`
- **engram** (선택): AI 대화 간 지식 유지 메모리. `pip install memorytrace`

## Windows 호환성

- Windows에서 `engram` CLI 사용 시 `PYTHONIOENCODING=utf-8` 환경변수 필요
- `cli_entry()`에서 stdout/stderr를 UTF-8로 reconfigure하여 cp949 인코딩 에러 방지
- 상세: `docs/05-windows-compatibility/windows-encoding.md` 참고

## Design Principles
1. **에이전트 퍼스트**: MCP/SDK가 1급 인터페이스, CLI는 래퍼
2. **LLM-Optional**: 코어는 제로 디펜던시, LLM은 선택적 플러그인
3. **이중 레이어 저장소**: SQLite(쿼리용) + Markdown(열람용)
4. **방어적 쓰기**: 품질 게이트 → 신뢰도 점수, 충돌 검사, PII 마스킹
5. **세션 연속성**: 대화 ID 기반 세션, Working Memory, 컨텍스트 캐리오버
6. **인터페이스 추상화**: storage/search/extraction 교체 가능한 Protocol

## 3단계 검증 (3-Step Verification)

모든 코드 변경 시 아래 3단계를 반드시 거칠 것:

### 1단계: 설계 검증 (Design Review)
- 변경 사항이 기존 아키텍처와 일관성이 있는가?
- 불필요한 복잡도를 추가하지 않는가?
- 해당 기능의 요구사항을 정확히 반영하는가?

### 2단계: 구현 검증 (Implementation Review)
- 코드가 정상 동작하는가? (빌드, 린트, 타입 체크)
- 보안 취약점이 없는가? (OWASP Top 10 기준)
- 에러 핸들링이 적절한가?

### 3단계: 통합 검증 (Integration Review)
- 기존 기능에 영향을 주지 않는가?
- 테스트가 모두 통과하는가?
- 성능 저하가 없는가?

## Code Review Protocol (코드리뷰)

"코드리뷰 진행해줘"라고 요청 시 아래 프로토콜을 따른다. 최대 15회차, 1회차씩 순차 진행. 한 번에 여러 회차 동시 진행 금지.

### 구조: 5단계 × 3회차

| 회차 | 단계 | 포커스 영역 | 체크 항목 |
|------|------|-----------|----------|
| 1~3 | 🔴 보안/권한 | OWASP Top 10 | 인증/인가 누락, 입력 검증, SQL 인젝션, XSS, 민감정보 노출, CORS, Rate Limit |
| 4~6 | 🟠 로직/정합성 | 비즈니스 로직 | 엣지 케이스, 에러 핸들링, null/undefined 처리, 트랜잭션 정합성, 데이터 정합성 |
| 7~9 | 🟡 성능/최적화 | 쿼리/연산 | N+1 쿼리, 불필요한 재렌더링, 메모리 누수, 번들 사이즈, 캐싱 부재, 인덱스 누락 |
| 10~12 | 🔵 구조/설계 | 아키텍처 | 의존성 방향, 모듈 분리, 중복 코드, 확장성, SOLID 원칙, 패키지 경계 |
| 13~15 | ⚪ 컨벤션/가독성 | 코드 품질 | 네이밍, 타입 정확성, 일관성, 불필요한 코드, 주석 필요 여부 |

### 회차 진행 규칙

1. **1회차에 1개 포커스만** — 해당 단계의 포커스 영역만 리뷰
2. **리뷰 → 수정 → 다음 리뷰** — 수정 없이 다음 회차 진행 금지 (이슈 0건 제외)
3. **다음 회차 시작 시 이전 수정 검증** — 회귀 체크 먼저 수행

### 조기 종료 조건

- 해당 단계 내 3회 연속 이슈 0건 → 다음 단계로 스킵
- 전체 리뷰에서 5회 연속 이슈 0건 → 코드리뷰 종료
- **최소 보장: 🔴 보안/권한 단계(1~3회차)는 반드시 수행**

### 이슈 심각도 분류

| 등급 | 라벨 | 설명 | 수정 필수 |
|------|------|------|----------|
| P0 | [CRITICAL] | 보안 취약점, 데이터 손실 가능 | 즉시 수정 |
| P1 | [ERROR] | 기능 오작동, 로직 오류 | 반드시 수정 |
| P2 | [WARNING] | 잠재적 문제, 성능 저하 | 권장 수정 |
| P3 | [INFO] | 개선 제안, 컨벤션 | 선택 수정 |

### 회차별 리포트 형식

```
## 코드리뷰 [N/15] — {단계 이모지} {단계명}

### 이전 수정 검증
[PASS/FAIL] {이전 회차 수정 사항 검증 결과}

### 발견 이슈
1. [P0/P1/P2/P3] 파일명:라인 — 이슈 설명
   → 수정 방안: ...

### 요약
- 발견: N건 (Critical: N, Error: N, Warning: N, Info: N)
- 수정 필요: N건
- 현재 진행: [N/15] {단계명}
```

### 코드리뷰 최종 리포트

모든 회차 종료 후 (또는 조기 종료 시) 최종 리포트 작성:

```
## 코드리뷰 최종 리포트
- 총 회차: N/15
- 총 발견 이슈: N건
- 수정 완료: N건
- 단계별 이슈: 🔴 N건 / 🟠 N건 / 🟡 N건 / 🔵 N건 / ⚪ N건
- 잔여 이슈: N건 (사유 명시)
```

## Development Rules

### Edit Safety
- 편집 전 파일 재읽기
- 함수/타입/변수 이름 변경 시: 모든 참조 grep 후 변경
- 파일 삭제 전 참조 없음 확인

### Context Management
- 10+ 메시지 후에는 파일 편집 전 반드시 재읽기
- 5+ 독립 파일 작업 시 서브에이전트 병렬 분배
