# Engram

Persistent memory for AI agents, backed by SQLite + FTS5.

## Install

```bash
pip install memorytrace
```

Optional extras:

```bash
pip install "memorytrace[llm]"
pip install "memorytrace[semantic]"
pip install "memorytrace[mcp]"
pip install "memorytrace[full]"
```

## Simple CLI

The default CLI is `engram`. `python -m engram` is equivalent.

```bash
engram init
engram save "Minseong Jeong is the CTO of Galaxy Corp"
engram find "CTO"
engram who "Minseong Jeong"
engram remember "Minseong Jeong" "Interested in AI and robotics"
engram status
```

## Advanced CLI

Use `engram-advanced` when you need structured options, JSON output, or a custom DB path.

```bash
engram-advanced --db ~/.engram/memory.db search "Galaxy Corp" --max-results 5
engram-advanced --json health
```

## Python SDK

```python
from engram.integrations.sdk import EngramSDK

with EngramSDK() as sdk:
    sdk.start_session("assistant")
    sdk.store("Minseong Jeong is the CTO of Galaxy Corp")
    sdk.add_fact("Minseong Jeong", "Interested in AI and robotics")
    result = sdk.search("Galaxy")
    print(result.to_agent_context())
```

## Source Checkout Compatibility

A repo-local `python mem ...` wrapper is kept for backward compatibility in source checkouts.
It forwards to the same simple CLI as `engram`, but it is not installed as a packaged console script.

## Docs

- `docs/04-usage-guide/01-quickstart.md`
- `docs/04-usage-guide/02-claude-code-setup.md`
- `docs/01-project-analysis/05-cli-commands.md`
- `docs/01-project-analysis/09-setup-guide.md`
