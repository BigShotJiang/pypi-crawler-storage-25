"""Tests for context transfer models and services."""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.exceptions import SessionError
from engram.models.brief import EntityRef, SessionBrief
from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.context_pack import ContextPack
from engram.models.health import HealthReport, LoopKind, LoopSeverity, OpenLoop
from engram.models.scope import ScopeSelection
from engram.session.transfer import ContextPackBuilder


@pytest.fixture
def engine(tmp_path):
    eng = MemoryEngine(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    yield eng
    eng.close()


def test_context_pack_to_dict_includes_rendered_text():
    pack = ContextPack(
        source_session_id="s-1",
        source_agent_id="planner",
        scope_id="scope-1",
        goal="task_handoff",
        summary="Need to continue the release checklist.",
        active_entities=[
            EntityRef(entity_id="e-1", name="Alice", entity_type="person"),
            EntityRef(entity_id="e-2", name="Release Bot", entity_type="service"),
        ],
        recent_queries=["release checklist", "rollback plan"],
        supporting_decisions=[],
        open_loops=[],
        rendered_text="Summary: continue the release checklist.",
    )

    payload = pack.to_dict()

    assert payload["goal"] == "task_handoff"
    assert payload["active_entities"][0]["name"] == "Alice"
    assert payload["rendered_text"].startswith("Summary:")


def test_build_context_pack_includes_summary_entities_and_queries(engine):
    session = engine.start_session("planner")
    engine.create_entity("Alice")
    engine.add_fact(
        "Alice",
        "Alice owns the release checklist.",
        predicate="role",
        session_id=session.session_id,
    )
    engine.search("release checklist", session_id=session.session_id)
    engine.end_session(session.session_id, summary="Release checklist ownership settled.")

    pack = engine.build_context_pack(session_id=session.session_id, goal="task_handoff")

    assert pack.summary == "Release checklist ownership settled."
    assert pack.active_entities[0].name == "Alice"
    assert "release checklist" in pack.recent_queries[0]


def test_context_pack_skips_diagnostics_when_no_entity_anchors(engine):
    class FailingDiagnostics:
        def run(self, max_open_loops=20):
            raise AssertionError("diagnostics.run() should not be called")

    session = engine.start_session("planner")
    engine.end_session(session.session_id, summary="Only summary is available.")
    saved = engine.storage.get_session(session.session_id)
    assert saved is not None

    pack = ContextPackBuilder(engine.storage, FailingDiagnostics()).build(
        session=saved,
        goal="task_handoff",
        max_chars=4000,
        session_brief=SessionBrief(session=saved),
    )

    assert pack.open_loops == []


def test_transfer_context_creates_target_session_with_metadata_and_events(engine):
    scope = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=scope.id)
    engine.create_entity("Alice")
    engine.add_fact(
        "Alice",
        "Alice owns the Alpha release checklist.",
        predicate="role",
        session_id=source.session_id,
    )
    engine.end_session(source.session_id, summary="Planner completed the first draft.")

    transfer = engine.transfer_context(
        from_session_id=source.session_id,
        to_agent_id="writer",
        note="Continue drafting the handoff memo.",
    )

    assert transfer.target_session.agent_id == "writer"
    assert transfer.target_session.scope_id == scope.id
    assert transfer.target_session.metadata["handoff_from_session_id"] == source.session_id
    assert transfer.target_session.metadata["handoff_note"] == "Continue drafting the handoff memo."


def test_transfer_context_rejects_parallel_target_agent_session(engine):
    source = engine.start_session("planner")
    engine.end_session(source.session_id, summary="Planner finished.")
    engine.start_session("writer")

    with pytest.raises(SessionError):
        engine.transfer_context(
            from_session_id=source.session_id,
            to_agent_id="writer",
        )


def test_transfer_context_masks_handoff_note_metadata(engine):
    source = engine.start_session("planner")
    engine.end_session(source.session_id, summary="Planner finished.")

    transfer = engine.transfer_context(
        from_session_id=source.session_id,
        to_agent_id="writer",
        note="Contact alice@example.com for rollout.",
    )

    assert "[REDACTED]" in transfer.target_session.metadata["handoff_note"]


def test_build_context_pack_filters_decisions_outside_source_scope(engine):
    alpha = engine.create_scope("project", "alpha")
    beta = engine.create_scope("project", "beta")
    alice = engine.create_entity("Alice")

    source = engine.start_session("planner", scope_id=alpha.id)
    engine.add_fact(
        "Alice",
        "Alice owns Alpha rollout.",
        predicate="role",
        session_id=source.session_id,
    )
    engine.end_session(source.session_id, summary="Alpha plan settled.")

    other = engine.start_session("writer", scope_id=beta.id)
    engine.end_session(other.session_id, summary="Beta plan settled.")
    engine.storage.replace_decisions(
        "session",
        other.session_id,
        [
            DecisionRecord(
                title="Beta decision",
                summary="We decided Beta rollout owner.",
                status=DecisionStatus.ACTIVE,
                confidence=0.9,
                source_kind="session",
                source_id=other.session_id,
                entity_id=alice.id,
                session_id=other.session_id,
                fingerprint="beta-decision-scope-test",
            )
        ],
    )

    pack = engine.build_context_pack(session_id=source.session_id)

    assert all(row.decision.title != "Beta decision" for row in pack.supporting_decisions)


def test_build_context_pack_respects_narrowed_scope_selection(engine):
    alpha = engine.create_scope("project", "alpha")
    task = engine.create_scope("task", "handoff", parent_scope_id=alpha.id)
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.end_session(source.session_id, summary="Planner finished.")

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=task.id,
            include_ancestors=False,
            include_global=False,
        ),
    )

    assert pack.scope_id == task.id


def test_build_context_pack_narrowing_excludes_broader_session_context(engine):
    alpha = engine.create_scope("project", "alpha")
    task = engine.create_scope("task", "handoff", parent_scope_id=alpha.id)
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Alice")
    engine.add_fact(
        "Alice",
        "Alice owns the Alpha release checklist.",
        predicate="role",
        session_id=source.session_id,
    )
    engine.search("Alpha release checklist", session_id=source.session_id)
    engine.end_session(source.session_id, summary="Alpha release context stays at the parent scope.")

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=task.id,
            include_ancestors=False,
            include_global=False,
        ),
    )

    assert pack.scope_id == task.id
    assert pack.summary == ""
    assert pack.recent_queries == []
    assert pack.active_entities == []
    assert pack.supporting_decisions == []
    assert pack.open_loops == []
    assert "Alpha release context" not in pack.rendered_text


def test_build_context_pack_same_scope_without_global_excludes_unscoped_text(engine):
    alpha = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Bob")
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.search("default release approver", session_id=source.session_id)
    engine.end_session(source.session_id, summary="Discussed default release approver")

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=False,
        ),
    )

    assert pack.scope_id == alpha.id
    assert pack.summary == ""
    assert pack.recent_queries == []
    assert "default release approver" not in pack.rendered_text


def test_build_context_pack_same_scope_with_scoped_search_restores_text_and_loops(engine):
    alpha = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Alice")
    engine.add_fact(
        "Alice",
        "Alice owns the Alpha release checklist.",
        predicate="role",
        session_id=source.session_id,
    )
    engine.search(
        "Alpha release checklist",
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=False,
        ),
    )
    engine.end_session(source.session_id, summary="Do not reuse the raw session summary.")

    alice = engine.get_entity("Alice")
    assert alice is not None
    report = HealthReport(
        open_loops=[
            OpenLoop(
                kind=LoopKind.CONFLICT,
                severity=LoopSeverity.WARNING,
                title="Resolve Alice handoff",
                target_id=alice.id,
                entity_name=alice.name,
            )
        ]
    )

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=False,
        ),
        health_report=report,
    )

    assert pack.scope_id == alpha.id
    assert pack.recent_queries == ["Alpha release checklist"]
    assert pack.summary
    assert "Do not reuse the raw session summary." not in pack.summary
    assert "Alice" in pack.summary or "Alpha release checklist" in pack.summary
    assert [loop.title for loop in pack.open_loops] == ["Resolve Alice handoff"]


def test_build_context_pack_include_global_keeps_global_entities(engine):
    alpha = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Bob")
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.get_entity("Bob", session_id=source.session_id)
    engine.end_session(source.session_id, summary="Discussed default release approver")

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )

    assert pack.scope_id == alpha.id
    assert any(row.name == "Bob" for row in pack.active_entities)


def test_build_context_pack_include_global_restores_global_scoped_queries(engine):
    alpha = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Bob")
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.search(
        "default release approver",
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )
    engine.end_session(source.session_id, summary="Discussed default release approver")

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )

    assert pack.recent_queries == ["default release approver"]


def test_build_context_pack_uses_batched_scope_lookup(engine, monkeypatch):
    alpha = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=alpha.id)
    engine.create_entity("Bob")
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.get_entity("Bob", session_id=source.session_id)
    engine.end_session(source.session_id, summary="Discussed default release approver")

    bob = engine.get_entity("Bob")
    calls: list[list[str]] = []

    def fake_scope_map(entity_ids: list[str]) -> dict[str, set[str | None]]:
        calls.append(list(entity_ids))
        return {bob.id: {None}}

    def fail_get_current_facts(_entity_id: str):
        raise AssertionError("build_context_pack should use batched scope lookup")

    monkeypatch.setattr(engine.storage, "list_current_fact_scopes", fake_scope_map, raising=False)
    monkeypatch.setattr(engine.storage, "get_current_facts", fail_get_current_facts)

    pack = engine.build_context_pack(
        session_id=source.session_id,
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )

    assert any(row.name == "Bob" for row in pack.active_entities)
    assert calls
