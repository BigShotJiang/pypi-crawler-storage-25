"""Tests for BriefBuilder and the engine.entity_brief / session_brief methods.

Covers the Feature 1 entry in
docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md.
"""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.relation import Relation
from engram.models.scope import ScopeSelection
from engram.models.source import Source, SourceType
from engram.session.brief import BriefBuilder


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


def _add_entity(engine: MemoryEngine, name: str, entity_type: str = "person", **state_kwargs) -> Entity:
    entity = engine.create_entity(name, entity_type=entity_type, tier=Tier.RECALL)
    if state_kwargs:
        entity.state = EntityState(**state_kwargs)
        engine.storage.update_entity(entity)
    return entity


def _add_fact(
    engine: MemoryEngine,
    entity: Entity,
    predicate: str,
    obj: str,
    *,
    confidence: float = 0.5,
    status: FactStatus = FactStatus.UNVERIFIED,
) -> Fact:
    fact = Fact(
        entity_id=entity.id,
        subject=entity.name,
        predicate=predicate,
        object=obj,
        raw_text=f"{entity.name} {predicate} {obj}",
        source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        confidence=confidence,
        status=status,
    )
    engine.storage.add_fact(fact)
    return fact


class TestEntityBrief:
    def test_missing_entity_returns_none(self, engine):
        assert engine.entity_brief("Nobody") is None

    def test_brief_includes_entity_state(self, engine):
        _add_entity(engine, "Alice", role="CEO", affiliation="Acme")
        brief = engine.entity_brief("Alice")
        assert brief is not None
        assert brief.entity.name == "Alice"
        assert brief.entity.state.role == "CEO"
        assert brief.entity.state.affiliation == "Acme"

    def test_top_facts_sorted_by_confidence_desc(self, engine):
        alice = _add_entity(engine, "Alice")
        _add_fact(engine, alice, "role", "CEO", confidence=0.3)
        _add_fact(engine, alice, "hobby", "climbing", confidence=0.9)
        _add_fact(engine, alice, "location", "Seoul", confidence=0.6)

        brief = engine.entity_brief("Alice", top_facts=10)
        confidences = [f.confidence for f in brief.top_facts]
        assert confidences == sorted(confidences, reverse=True)
        assert confidences[0] == 0.9

    def test_top_facts_excludes_retracted_and_expired(self, engine):
        alice = _add_entity(engine, "Alice")
        _add_fact(engine, alice, "a", "x", confidence=0.9, status=FactStatus.UNVERIFIED)
        _add_fact(engine, alice, "b", "y", confidence=0.8, status=FactStatus.RETRACTED)
        _add_fact(engine, alice, "c", "z", confidence=0.7, status=FactStatus.EXPIRED)

        brief = engine.entity_brief("Alice")
        predicates = {f.predicate for f in brief.top_facts}
        assert predicates == {"a"}

    def test_top_facts_honours_limit(self, engine):
        alice = _add_entity(engine, "Alice")
        for i in range(5):
            _add_fact(engine, alice, f"p{i}", f"v{i}", confidence=0.5 + i * 0.05)

        brief = engine.entity_brief("Alice", top_facts=2)
        assert len(brief.top_facts) == 2

    def test_related_entities_resolved_by_name(self, engine):
        alice = _add_entity(engine, "Alice")
        acme = _add_entity(engine, "Acme", entity_type="organization")
        engine.storage.add_relation(
            Relation(
                from_entity_id=alice.id,
                to_entity_id=acme.id,
                relation_type="works_at",
            )
        )

        brief = engine.entity_brief("Alice")
        assert len(brief.related_entities) == 1
        rel = brief.related_entities[0]
        assert rel.name == "Acme"
        assert rel.entity_type == "organization"
        assert rel.relation_type == "works_at"
        assert rel.direction == "outgoing"

    def test_related_entities_direction_distinguishes_incoming(self, engine):
        alice = _add_entity(engine, "Alice")
        bob = _add_entity(engine, "Bob")
        engine.storage.add_relation(
            Relation(
                from_entity_id=bob.id,
                to_entity_id=alice.id,
                relation_type="mentor_of",
            )
        )

        brief = engine.entity_brief("Alice")
        assert len(brief.related_entities) == 1
        assert brief.related_entities[0].direction == "incoming"
        assert brief.related_entities[0].name == "Bob"

    def test_recent_notes_surfaces_matches(self, engine):
        _add_entity(engine, "Alice")
        engine.store("Alice met with the design team yesterday.")
        engine.store("Alice is working on a new launch plan.")

        brief = engine.entity_brief("Alice", recent_notes=5)
        assert len(brief.recent_notes) >= 1
        assert all("alice" in n.text.lower() for n in brief.recent_notes)

    def test_unresolved_conflict_attributed_to_entity(self, engine):
        alice = _add_entity(engine, "Alice")
        f1 = _add_fact(engine, alice, "role", "CEO", confidence=0.8)
        f2 = _add_fact(engine, alice, "role", "CTO", confidence=0.7)
        engine.storage.add_conflict(
            {
                "id": "conflict-1",
                "existing_fact_id": f1.id,
                "new_fact_id": f2.id,
                "conflict_type": "contradiction",
                "suggested_resolution": "supersede",
            }
        )

        brief = engine.entity_brief("Alice")
        assert len(brief.unresolved_conflicts) == 1
        c = brief.unresolved_conflicts[0]
        assert c.conflict_id == "conflict-1"
        assert c.existing_fact_text is not None

    def test_conflicts_for_other_entity_excluded(self, engine):
        alice = _add_entity(engine, "Alice")
        bob = _add_entity(engine, "Bob")
        f_a = _add_fact(engine, alice, "a", "x")
        f_b = _add_fact(engine, bob, "b", "y")
        engine.storage.add_conflict(
            {
                "id": "conflict-x",
                "existing_fact_id": f_b.id,
                "new_fact_id": f_b.id,
                "conflict_type": "contradiction",
            }
        )
        engine.storage.add_conflict(
            {
                "id": "conflict-y",
                "existing_fact_id": f_a.id,
                "new_fact_id": f_a.id,
                "conflict_type": "contradiction",
            }
        )

        brief = engine.entity_brief("Alice")
        assert [c.conflict_id for c in brief.unresolved_conflicts] == ["conflict-y"]

    def test_access_count_incremented(self, engine):
        alice = _add_entity(engine, "Alice")
        assert alice.access_count == 0
        engine.entity_brief("Alice")
        refreshed = engine.storage.get_entity(alice.id)
        assert refreshed.access_count == 1

    def test_to_dict_round_trip(self, engine):
        alice = _add_entity(engine, "Alice", role="CEO")
        _add_fact(engine, alice, "hobby", "climbing", confidence=0.9)
        brief = engine.entity_brief("Alice")
        d = brief.to_dict()
        assert d["entity"]["name"] == "Alice"
        assert d["entity"]["state"]["role"] == "CEO"
        assert d["top_facts"][0]["predicate"] == "hobby"
        assert "generated_at" in d

    def test_to_agent_context_is_non_empty_markdown(self, engine):
        alice = _add_entity(engine, "Alice", role="CEO")
        _add_fact(engine, alice, "hobby", "climbing", confidence=0.9)
        brief = engine.entity_brief("Alice")
        text = brief.to_agent_context()
        assert text.startswith("## Entity: Alice")
        assert "hobby climbing" in text or "climbing" in text
        assert "CEO" in text

    def test_to_agent_context_respects_char_cap(self, engine):
        alice = _add_entity(engine, "Alice")
        for i in range(30):
            _add_fact(
                engine,
                alice,
                f"p{i}",
                f"value-{i} " * 10,
                confidence=0.5,
            )
        brief = engine.entity_brief("Alice", top_facts=30)
        text = brief.to_agent_context(max_chars=300)
        assert len(text) <= 300

    def test_brief_includes_supporting_hits(self, engine):
        _add_entity(engine, "Alice")
        engine.store("Alice is leading the launch meeting.")
        brief = engine.entity_brief("Alice")
        assert brief.supporting_hits
        assert brief.supporting_hits[0].entity_name == "Alice"
        assert brief.supporting_hits[0].explanation.summary


class TestSessionBrief:
    def test_missing_session_returns_none(self, engine):
        assert engine.session_brief("nope") is None

    def test_brief_covers_modifications_and_access(self, engine):
        session = engine.start_session("claude-code")
        _add_entity(engine, "Charlie")
        # Use add_fact (not extraction) so the test is deterministic regardless
        # of regex-extractor coverage.
        engine.add_fact(
            "Charlie",
            "leads the infra team",
            predicate="role",
            session_id=session.session_id,
        )
        engine.get_entity("Charlie", session_id=session.session_id)

        brief = engine.session_brief(session.session_id)
        assert brief is not None
        modified_names = {r.name for r in brief.entities_modified}
        accessed_names = {r.name for r in brief.entities_accessed}
        assert "Charlie" in modified_names or "Charlie" in accessed_names
        # At least one fact should have been added.
        assert len(brief.facts_added) >= 1
        first_fact = brief.facts_added[0]
        assert first_fact.entity_name == "Charlie"
        assert "infra" in first_fact.text

    def test_session_brief_includes_supporting_hits(self, engine):
        session = engine.start_session("codex")
        _add_entity(engine, "Alice")
        engine.add_fact(
            "Alice",
            "reviewed the session brief design",
            predicate="role",
            session_id=session.session_id,
        )
        brief = engine.session_brief(session.session_id)
        assert brief.supporting_hits
        assert brief.supporting_hits[0].explanation.summary

    def test_session_brief_does_not_append_support_search_events(self, engine):
        session = engine.start_session("codex")
        _add_entity(engine, "Alice")
        engine.add_fact(
            "Alice",
            "reviewed the session brief design",
            predicate="role",
            session_id=session.session_id,
        )
        engine.search("session brief", session_id=session.session_id)
        before = len(engine.storage.get_session_events(session.session_id, limit=50))

        brief = engine.session_brief(session.session_id)
        after = len(engine.storage.get_session_events(session.session_id, limit=50))

        assert brief is not None
        assert after == before

    def test_session_brief_supporting_hits_respect_scope(self, engine):
        scope = engine.create_scope("task", "handoff")
        session = engine.start_session("agent-x", scope_id=scope.id)
        _add_entity(engine, "Daisy")
        fact = Fact(
            entity_id=engine.get_entity("Daisy").id,
            subject="Daisy",
            predicate="role",
            object="handoff owner",
            raw_text="Daisy handles handoff.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0, session_id=session.session_id),
            scope_id=scope.id,
            confidence=0.8,
            status=FactStatus.UNVERIFIED,
        )
        engine.storage.add_fact(fact)
        engine.session_mgr.record_fact_added(session.session_id, fact.id)
        engine.session_mgr.record_entity_modified(session.session_id, fact.entity_id)

        brief = engine.session_brief(
            session.session_id,
            scope_selection=ScopeSelection(
                primary_scope_id=scope.id,
                include_global=False,
            ),
        )

        assert brief.supporting_hits
        assert all(hit.explanation.summary for hit in brief.supporting_hits)

    def test_brief_includes_working_memory(self, engine):
        session = engine.start_session("a")
        _add_entity(engine, "Zed")
        engine.get_entity("Zed", session_id=session.session_id)

        # Simulate working memory activity (search also updates it; here we push directly).
        wm = engine._working_memories[session.session_id]
        zed_id = engine.storage.get_entity_by_name("Zed").id
        wm.touch_entity(zed_id)
        engine.search("who is Zed", session_id=session.session_id)

        brief = engine.session_brief(session.session_id)
        assert any(r.name == "Zed" for r in brief.active_working_memory)
        assert "who is Zed" in brief.recent_queries

    def test_brief_to_dict_contains_session_metadata(self, engine):
        session = engine.start_session("agent-x")
        brief = engine.session_brief(session.session_id)
        d = brief.to_dict()
        assert d["session"]["agent_id"] == "agent-x"
        assert d["session"]["is_active"] is True

    def test_brief_to_agent_context_rendering(self, engine):
        session = engine.start_session("agent-x")
        _add_entity(engine, "Daisy")
        engine.store("Daisy joined the marketing team.", session_id=session.session_id)
        text = engine.session_brief(session.session_id).to_agent_context()
        assert text.startswith("## Session: ")
        assert "agent-x" in text


class TestBriefBuilderDirect:
    def test_entity_brief_without_working_memory_works(self, storage, sample_entity):
        # Uses the storage fixture from conftest — no engine involved.
        storage.create_entity(sample_entity)
        builder = BriefBuilder(storage)
        brief = builder.entity_brief("Simon Kim")
        assert brief is not None
        assert brief.entity.name == "Simon Kim"
        assert brief.top_facts == []
        assert brief.related_entities == []
        assert brief.unresolved_conflicts == []
