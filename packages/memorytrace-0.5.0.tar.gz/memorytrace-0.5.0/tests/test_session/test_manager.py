"""Tests for session management."""

import pytest

from engram.models.session import Session
from engram.session.manager import SessionManager
from engram.storage.sqlite_store import SQLiteStorage
from engram.exceptions import SessionError


@pytest.fixture
def session_setup(tmp_path):
    db_path = tmp_path / "session_test.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    mgr = SessionManager(storage)
    yield mgr, storage
    storage.close()


class TestSessionLifecycle:
    def test_start_session(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("claude-code")
        assert session.agent_id == "claude-code"
        assert session.is_active
        assert session.parent_session_id is None

    def test_start_session_links_to_previous(self, session_setup):
        mgr, _ = session_setup
        s1 = mgr.start_session("claude")
        mgr.end_session(s1.session_id, summary="First session")
        s2 = mgr.start_session("claude")
        assert s2.parent_session_id == s1.session_id

    def test_start_session_accepts_explicit_parent_and_metadata(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session(
            "writer",
            scope_id="scope-1",
            parent_session_id="source-session",
            metadata={"handoff_goal": "task_handoff"},
        )
        assert session.parent_session_id == "source-session"
        assert session.scope_id == "scope-1"
        assert session.metadata["handoff_goal"] == "task_handoff"

    def test_start_session_allows_explicit_root_parent(self, session_setup):
        mgr, _ = session_setup
        previous = mgr.start_session("writer")
        mgr.end_session(previous.session_id, summary="done")

        root = mgr.start_session("writer", parent_session_id=None)

        assert root.parent_session_id is None

    def test_start_session_rejects_parallel_same_agent(self, session_setup):
        mgr, _ = session_setup
        mgr.start_session("writer")

        with pytest.raises(SessionError):
            mgr.start_session("writer")

    def test_end_session(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        ended = mgr.end_session(session.session_id, summary="Done")
        assert not ended.is_active
        assert ended.summary == "Done"
        assert ended.duration_seconds is not None

    def test_end_nonexistent_session_raises(self, session_setup):
        mgr, _ = session_setup
        with pytest.raises(SessionError):
            mgr.end_session("nonexistent-id")

    def test_get_active_session(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        active = mgr.get_active_session(session.session_id)
        assert active is not None
        assert active.session_id == session.session_id

    def test_get_active_session_after_end(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        mgr.end_session(session.session_id)
        assert mgr.get_active_session(session.session_id) is None


class TestSessionTracking:
    def test_record_entity_access(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        mgr.record_entity_access(session.session_id, "entity-1")
        mgr.record_entity_access(session.session_id, "entity-2")
        mgr.record_entity_access(session.session_id, "entity-1")  # duplicate
        assert session.entities_accessed == ["entity-1", "entity-2"]

    def test_record_entity_modified(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        mgr.record_entity_modified(session.session_id, "entity-1")
        assert "entity-1" in session.entities_modified
        assert "entity-1" in session.entities_accessed

    def test_record_fact_added(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        mgr.record_fact_added(session.session_id, "fact-1")
        mgr.record_fact_added(session.session_id, "fact-2")
        assert len(session.facts_added) == 2

    def test_log_event(self, session_setup):
        mgr, _ = session_setup
        session = mgr.start_session("test")
        # Should not raise
        mgr.log_event(session.session_id, "search", target="Simon Kim", detail={"results": 3})


class TestContextCarryover:
    def test_carryover_from_completed_session(self, session_setup):
        mgr, storage = session_setup
        # Create a real entity so ID→name resolution works
        from engram.models.entity import Entity
        entity = Entity(name="Simon Kim", entity_type="person")
        storage.create_entity(entity)

        s1 = mgr.start_session("claude")
        mgr.record_entity_access(s1.session_id, entity.id)
        mgr.end_session(s1.session_id, summary="Discussed Simon Kim fund launch")

        carryover = mgr.get_context_carryover("claude")
        assert "Simon Kim fund launch" in carryover
        assert "Simon Kim" in carryover  # Resolved name, not UUID

    def test_carryover_empty_for_new_agent(self, session_setup):
        mgr, _ = session_setup
        assert mgr.get_context_carryover("new-agent") == ""

    def test_carryover_skips_active_session(self, session_setup):
        mgr, _ = session_setup
        mgr.start_session("claude")
        # Active session (not ended) should not be used for carryover
        assert mgr.get_context_carryover("claude") == ""
