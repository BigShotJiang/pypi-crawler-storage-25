"""Reference projection tests."""
