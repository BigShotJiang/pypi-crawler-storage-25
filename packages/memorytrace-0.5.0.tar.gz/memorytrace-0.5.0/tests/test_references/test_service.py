from __future__ import annotations

from engram.models.entity import Entity
from engram.references.service import ReferenceService


def _entity(storage, name: str, *, aliases=None) -> Entity:
    entity = Entity(name=name, aliases=list(aliases or []))
    storage.create_entity(entity)
    return entity


def test_index_note_creates_backlinks(storage):
    alice = _entity(storage, "Alice")
    storage.add_note("note-1", "Alice met Bob in Seoul.")

    service = ReferenceService(storage)
    edges = service.index_source("note", "note-1")

    assert len(edges) == 1
    assert edges[0].entity_id == alice.id
    assert "Alice met Bob" in edges[0].snippet


def test_alias_match_creates_backlink(storage):
    alice = _entity(storage, "Alice Johnson", aliases=["AJ"])
    storage.add_note("note-2", "AJ reviewed the launch plan.")

    service = ReferenceService(storage)
    service.index_source("note", "note-2")
    rows = service.backlinks("Alice Johnson")

    assert len(rows) == 1
    assert rows[0]["entity_id"] == alice.id
    assert rows[0]["matched_text"] == "AJ"


def test_rebuild_replaces_source_scoped_edges(storage):
    _entity(storage, "Alice")
    storage.add_note("note-3", "Alice reviewed this.")
    service = ReferenceService(storage)

    first = service.index_source("note", "note-3")
    storage._conn.execute("UPDATE notes SET text = ? WHERE id = ?", ("No entity here", "note-3"))
    storage._conn.commit()
    second = service.index_source("note", "note-3")

    assert len(first) == 1
    assert second == []
    assert storage.count_reference_edges_for_source("note", "note-3") == 0
