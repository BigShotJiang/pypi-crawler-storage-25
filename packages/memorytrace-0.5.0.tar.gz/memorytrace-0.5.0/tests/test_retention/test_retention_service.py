from __future__ import annotations

from datetime import datetime

import pytest


def _retention_imports():
    try:
        from engram.models.retention import (
            RetentionPolicyType,
            RetentionTargetKind,
        )
        from engram.retention.service import RetentionService
    except ModuleNotFoundError as exc:
        pytest.fail(str(exc))
    return RetentionPolicyType, RetentionTargetKind, RetentionService


def test_set_and_clear_retention_policy(storage):
    RetentionPolicyType, RetentionTargetKind, RetentionService = _retention_imports()
    service = RetentionService(storage)

    policy = service.set_policy(
        target_kind=RetentionTargetKind.FACT,
        target_id="fact-1",
        policy_type=RetentionPolicyType.PIN,
        reason="keep this forever",
    )

    assert policy.policy_type is RetentionPolicyType.PIN
    assert service.is_pinned(RetentionTargetKind.FACT, "fact-1") is True

    cleared = service.clear_policy(
        RetentionTargetKind.FACT,
        "fact-1",
        RetentionPolicyType.PIN,
    )

    assert cleared is True
    assert service.is_pinned(RetentionTargetKind.FACT, "fact-1") is False


def test_ttl_policy_round_trips_as_datetime(storage):
    RetentionPolicyType, RetentionTargetKind, RetentionService = _retention_imports()
    service = RetentionService(storage)

    service.set_policy(
        target_kind=RetentionTargetKind.DECISION,
        target_id="decision-1",
        policy_type=RetentionPolicyType.TTL,
        value="2026-05-01T00:00:00",
        reason="revisit in may",
    )

    ttl = service.get_ttl(RetentionTargetKind.DECISION, "decision-1")

    assert ttl is not None
    assert ttl == datetime.fromisoformat("2026-05-01T00:00:00")
