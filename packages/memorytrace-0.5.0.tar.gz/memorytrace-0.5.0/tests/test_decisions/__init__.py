"""Decision projection tests."""
