from __future__ import annotations

from engram.decisions.service import DecisionService
from engram.models.entity import Entity
from engram.models.session import Session
from engram.references.service import ReferenceService


def test_session_summary_creates_decision(storage):
    session = Session(session_id="session-1", agent_id="codex", summary="We decided to ship the patch tomorrow.")
    storage.save_session(session)

    service = DecisionService(storage)
    rows = service.index_source("session", "session-1")

    assert len(rows) == 1
    assert rows[0].source_kind == "session"
    assert rows[0].status.value == "active"


def test_debug_conclusion_creates_decision(storage):
    storage._conn.execute(
        "INSERT INTO debug_sessions (id, bug_description, status, conclusion, started_at) VALUES (?, ?, ?, ?, ?)",
        ("dbg-1", "bug", "resolved", "We decided to rotate the token and redeploy.", "2026-04-16T00:00:00"),
    )
    storage._conn.commit()

    service = DecisionService(storage)
    rows = service.index_source("debug_session", "dbg-1")

    assert len(rows) == 1
    assert "rotate the token" in rows[0].summary


def test_note_decision_can_bind_single_entity(storage):
    entity = Entity(name="Alice")
    storage.create_entity(entity)
    storage.add_note("note-d1", "Alice decided to pause the rollout.")

    service = DecisionService(storage, reference_service=ReferenceService(storage))
    rows = service.index_source("note", "note-d1")

    assert len(rows) == 1
    assert rows[0].entity_id == entity.id
