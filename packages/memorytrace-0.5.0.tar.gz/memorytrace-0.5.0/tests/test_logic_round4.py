"""Round-4 logic/consistency regressions.

Covers:
1. intake apply: REJECT path must not leave a dangling ``applied_target_id``.
2. debug: double-conclude raises instead of silently overwriting.
3. delete_entity: pending conflicts that reference the entity's facts get
   auto-resolved so orphan rows never surface via get_pending_conflicts.
"""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.debug import DebugSessionStatus
from engram.models.fact import Fact
from engram.models.intake import CandidateStatus
from engram.models.quality import Action
from engram.models.source import Source, SourceType


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestIntakeRejectedTargetIdCleanup:
    def test_rejected_fact_has_no_dangling_target(self, engine, monkeypatch):
        # Force the gate to REJECT so we exercise the dangling-id path.
        def force_reject(fact, extraction_method="intake"):
            from engram.models.quality import ValidationResult
            return ValidationResult(
                action=Action.REJECT,
                reason="forced for test",
                confidence=0.0,
            )
        monkeypatch.setattr(engine.quality_gate, "validate", force_reject)

        batch = engine.intake("Alice Smith is the CEO of Acme Corp.")
        result = engine.apply_intake(batch.id)

        # At least one candidate should have ended up rejected.
        assert result.rejected, "expected at least one rejected candidate"
        for cand in result.rejected:
            assert cand.applied_target_id is None, (
                f"rejected candidate {cand.id} still carries target_id "
                f"{cand.applied_target_id!r}"
            )

        # And the persisted row matches.
        refreshed = engine.get_intake(batch.id)
        for cand in refreshed.candidates:
            if cand.status == CandidateStatus.REJECTED:
                assert cand.applied_target_id is None


class TestDebugDoubleConclude:
    def test_second_conclude_raises(self, engine):
        session = engine.debug_start("bug")
        engine.debug_hypothesis(session.id, "h1")
        engine.debug_conclude(session.id, conclusion="v1")
        with pytest.raises(ValueError) as exc:
            engine.debug_conclude(session.id, conclusion="v2")
        assert "already concluded" in str(exc.value).lower()

    def test_original_conclusion_preserved(self, engine):
        session = engine.debug_start("bug")
        engine.debug_conclude(session.id, conclusion="original")
        try:
            engine.debug_conclude(session.id, conclusion="overwritten")
        except ValueError:
            pass
        fetched = engine.get_debug_session(session.id)
        assert fetched.conclusion == "original"


class TestDeleteEntityResolvesConflicts:
    def test_deleting_entity_auto_resolves_its_pending_conflicts(self, engine):
        engine.create_entity("Alice Smith")
        alice = engine.storage.get_entity_by_name("Alice Smith")

        # Seed two facts and a pending conflict between them.
        source = Source(type=SourceType.USER_INPUT, author="press")
        f1 = Fact(
            entity_id=alice.id,
            subject=alice.name,
            predicate="role",
            object="CEO",
            raw_text="Alice Smith is CEO",
            source=source,
            confidence=0.9,
        )
        f2 = Fact(
            entity_id=alice.id,
            subject=alice.name,
            predicate="role",
            object="CTO",
            raw_text="Alice Smith is CTO",
            source=source,
            confidence=0.8,
        )
        engine.storage.add_fact(f1)
        engine.storage.add_fact(f2)
        engine.storage.add_conflict(
            {
                "id": "c-entity-scoped",
                "existing_fact_id": f1.id,
                "new_fact_id": f2.id,
                "conflict_type": "contradiction",
                "suggested_resolution": "supersede",
            }
        )

        # Sanity: conflict is pending before deletion.
        pending_before = engine.storage.get_pending_conflicts()
        assert any(c["id"] == "c-entity-scoped" for c in pending_before)

        # Delete the entity — conflict must auto-resolve, not orphan.
        engine.delete_entity("Alice Smith")

        pending_after = engine.storage.get_pending_conflicts()
        assert not any(c["id"] == "c-entity-scoped" for c in pending_after)

        # The row survives with resolution = 'entity_deleted' for audit.
        row = engine.storage._conn.execute(
            "SELECT resolution, resolved_by FROM conflicts WHERE id = ?",
            ("c-entity-scoped",),
        ).fetchone()
        assert row["resolution"] == "entity_deleted"
        assert row["resolved_by"] == "auto_delete_entity"

    def test_other_entity_conflicts_unaffected(self, engine):
        engine.create_entity("Alice Smith")
        engine.create_entity("Bob Wright")
        alice = engine.storage.get_entity_by_name("Alice Smith")
        bob = engine.storage.get_entity_by_name("Bob Wright")

        source = Source(type=SourceType.USER_INPUT)
        bob_fact = Fact(
            entity_id=bob.id,
            subject=bob.name,
            predicate="role",
            object="CTO",
            raw_text="Bob Wright is CTO",
            source=source,
            confidence=0.9,
        )
        engine.storage.add_fact(bob_fact)
        engine.storage.add_conflict(
            {
                "id": "c-bob",
                "existing_fact_id": bob_fact.id,
                "new_fact_id": bob_fact.id,
                "conflict_type": "contradiction",
            }
        )

        engine.delete_entity("Alice Smith")
        pending = engine.storage.get_pending_conflicts()
        assert any(c["id"] == "c-bob" for c in pending), (
            "Bob's conflict should not be touched when Alice is deleted"
        )
