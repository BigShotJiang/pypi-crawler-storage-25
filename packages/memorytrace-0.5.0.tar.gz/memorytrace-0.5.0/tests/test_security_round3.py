"""Round-3 security regressions.

Three new surfaces get covered here:

1. ``engine.restore_snapshot`` refuses to write into blocklisted paths unless
   the caller passes ``allow_unsafe_path=True``. This is the write-side
   mirror of the intake ``--from-file`` read-side guard.
2. ``SessionManager.log_event`` masks string values in both ``target`` and
   ``detail`` so future callers passing user text can't quietly leak PII
   into ``session_events``.
3. ``SnapshotService._resolve_snapshot_path`` rejects manifests whose
   ``file_path`` escapes the snapshots directory — defense-in-depth against
   a poisoned manifest row pointing at ``../../etc/passwd``.
"""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.session.manager import SessionManager
from engram.snapshots.service import SnapshotService


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestRestoreWritePathSafety:
    def test_refuses_to_write_into_ssh_dir(self, engine, tmp_path):
        snap = engine.create_snapshot()
        bad = tmp_path / ".ssh" / "authorized_keys"
        with pytest.raises(PermissionError):
            engine.restore_snapshot(snap.id, bad)

    def test_refuses_bashrc(self, engine, tmp_path):
        snap = engine.create_snapshot()
        bad = tmp_path / ".bashrc"
        with pytest.raises(PermissionError):
            engine.restore_snapshot(snap.id, bad)

    def test_refuses_pem_extension(self, engine, tmp_path):
        snap = engine.create_snapshot()
        bad = tmp_path / "restored.pem"
        with pytest.raises(PermissionError):
            engine.restore_snapshot(snap.id, bad)

    def test_allow_unsafe_path_bypasses_blocklist(self, engine, tmp_path):
        snap = engine.create_snapshot()
        target = tmp_path / "key-like.pem"
        path = engine.restore_snapshot(snap.id, target, allow_unsafe_path=True)
        assert path.exists()

    def test_ordinary_target_works(self, engine, tmp_path):
        snap = engine.create_snapshot()
        target = tmp_path / "ok.db"
        path = engine.restore_snapshot(snap.id, target)
        assert path.exists()


class TestSessionEventMaskingDetail:
    def test_detail_string_values_masked(self, engine):
        session = engine.start_session("agent")
        # Direct call to session_mgr.log_event — simulates a future feature
        # that tucks user text into ``detail`` instead of ``target``.
        engine.session_mgr.log_event(
            session.session_id,
            event_type="unit-test",
            target="clean",
            detail={"note_count": 1, "sample": "leaked bob@acme.internal"},
        )
        rows = engine.storage._conn.execute(
            "SELECT detail FROM session_events WHERE event_type = 'unit-test'"
        ).fetchall()
        assert rows
        raw = rows[0]["detail"]
        assert "bob@acme.internal" not in raw
        assert "[REDACTED]" in raw
        # Non-string values remain intact.
        assert "1" in raw  # note_count serialized

    def test_target_still_masked(self, engine):
        session = engine.start_session("agent")
        engine.session_mgr.log_event(
            session.session_id,
            event_type="unit-test",
            target="send to alice@corp.io about it",
            detail={},
        )
        rows = engine.storage._conn.execute(
            "SELECT target FROM session_events WHERE event_type = 'unit-test'"
        ).fetchall()
        assert "alice@corp.io" not in rows[0]["target"]

    def test_session_manager_without_detector_is_pass_through(self, storage):
        mgr = SessionManager(storage)
        session = mgr.start_session("t")
        mgr.log_event(
            session.session_id,
            event_type="raw",
            target="retains bob@acme.io",
            detail={"q": "sk-abcdefghijklmnopqrstuvwxyz0123"},
        )
        rows = storage._conn.execute(
            "SELECT target, detail FROM session_events WHERE event_type = 'raw'"
        ).fetchall()
        assert "bob@acme.io" in rows[0]["target"]
        assert "sk-abcdefghijklmnopqrstuvwxyz0123" in rows[0]["detail"]


class TestSnapshotPathTraversalGuard:
    def test_poisoned_file_path_rejected_on_open(self, engine):
        snap = engine.create_snapshot()
        # Poison the manifest row so file_path escapes snapshots_dir.
        engine.storage._conn.execute(
            "UPDATE snapshots SET file_path = ? WHERE id = ?",
            ("../escape.db.gz", snap.id),
        )
        engine.storage._conn.commit()

        svc = SnapshotService(engine.storage, engine.config.snapshots_dir)
        with pytest.raises(ValueError) as exc:
            with svc.open_snapshot(snap.id):
                pass
        assert "escape" in str(exc.value).lower() or "snapshots dir" in str(exc.value).lower()

    def test_poisoned_file_path_deletion_still_drops_manifest(self, engine):
        snap = engine.create_snapshot()
        engine.storage._conn.execute(
            "UPDATE snapshots SET file_path = ? WHERE id = ?",
            ("../../etc/passwd", snap.id),
        )
        engine.storage._conn.commit()

        # Delete must NOT touch /etc/passwd — the ValueError from the
        # resolver is swallowed and only the DB row goes away.
        assert engine.delete_snapshot(snap.id) is True
        assert engine.get_snapshot(snap.id) is None
