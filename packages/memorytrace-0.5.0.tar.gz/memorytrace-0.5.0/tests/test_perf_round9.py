"""Round-9 performance regression tests for snapshot diff."""

from __future__ import annotations

import inspect

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.snapshots.service import SnapshotService


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestSnapshotDiffBatching:
    def test_entity_signatures_uses_join_aggregation(self, engine):
        source = inspect.getsource(SnapshotService._entity_signatures)
        assert "LEFT JOIN facts f" in source
        assert "COUNT(f.id) AS cur_fact_count" in source
        assert "SELECT COUNT(*) FROM facts f" not in source

    def test_entity_signatures_still_counts_current_facts(self, engine):
        engine.create_entity("Alice Smith")
        engine.add_fact("Alice Smith", "CEO of Acme", predicate="role")
        engine.create_entity("Bob Wright")

        service = SnapshotService(engine.storage, engine.config.snapshots_dir)
        signatures = service._entity_signatures(engine.storage._conn)

        alice = next(v for v in signatures.values() if v["name"] == "Alice Smith")
        bob = next(v for v in signatures.values() if v["name"] == "Bob Wright")
        assert alice["sig"][-1] == 1
        assert bob["sig"][-1] == 0
