"""Integration tests for MemoryEngine."""

from datetime import datetime, timedelta
import pytest
from pathlib import Path

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.exceptions import SessionError
from engram.models.fact import Fact, FactStatus
from engram.models.entity import Entity, Tier
from engram.models.quality import Action
from engram.models.source import Source, SourceType
from engram.models.search import RetrievalContext, SearchOptions
from engram.models.decision import DecisionStatus
from engram.models.decision import DecisionRecord
from engram.models.governance import GovernanceCandidateStatus, GovernanceCandidateType, GovernanceResolution
from engram.models.retention import RetentionPolicyType, RetentionTargetKind
from engram.models.reference import ReferenceEdge
from engram.models.scope import ScopeSelection
from engram.models.verification import VerificationResolution


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=True,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class _SecondaryIndexStub:
    def __init__(self):
        self.indexed: list[tuple[str, str]] = []
        self.removed: list[str] = []
        self.cleared = 0

    def close(self) -> None:
        return None

    def index_entity(self, entity_id: str, text: str) -> None:
        self.indexed.append((entity_id, text))

    def remove_from_index(self, entity_id: str) -> None:
        self.removed.append(entity_id)

    def clear_index(self) -> None:
        self.cleared += 1


def _add_scoped_fact(engine: MemoryEngine, *, name: str, raw_text: str, obj: str, scope_id: str) -> None:
    entity = engine.get_entity(name)
    if entity is None:
        entity = engine.create_entity(name, entity_type="person", tier=Tier.RECALL)
    fact = Fact(
        entity_id=entity.id,
        subject=entity.name,
        predicate="role",
        object=obj,
        raw_text=raw_text,
        source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        scope_id=scope_id,
        confidence=0.8,
        status=FactStatus.UNVERIFIED,
    )
    engine.storage.add_fact(fact)


class TestEngineStore:
    def test_store_extracts_and_saves(self, engine):
        result = engine.store("Simon Kim is the CEO of Hashed.")
        assert len(result.entities_created) >= 1
        names = [e.name for e in result.entities_created]
        assert "Simon Kim" in names

    def test_store_creates_facts(self, engine):
        result = engine.store("Simon Kim is the CEO of Hashed.")
        assert len(result.facts_added) + len(result.facts_quarantined) >= 0

    def test_store_empty_text(self, engine):
        result = engine.store("")
        assert len(result.entities_created) == 0

    def test_store_with_source(self, engine):
        source = Source(type=SourceType.DIRECT_SPEECH, confidence=1.0, author="Simon")
        result = engine.store("Simon Kim launched a $200M fund.", source=source)
        assert len(result.entities_created) >= 1

    def test_store_deduplicates_entities(self, engine):
        engine.store("Simon Kim is the CEO.")
        result = engine.store("Simon Kim launched a fund.")
        # Simon Kim should be in updated, not created (already exists)
        created_names = [e.name for e in result.entities_created]
        assert "Simon Kim" not in created_names

    def test_store_exports_markdown(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        md_files = list(engine.config.export_dir.glob("*.md"))
        assert len(md_files) >= 1

    def test_store_entity_only_updates_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        result = engine.store("Alice Johnson met the team.")

        assert len(result.entities_created) >= 1
        created_ids = {entity.id for entity in result.entities_created}
        indexed_ids = {entity_id for entity_id, _ in stub.indexed}
        assert created_ids.issubset(indexed_ids)

    def test_store_enqueues_index_job_for_scoped_note(self, engine):
        scope = engine.create_scope("project", "alpha")

        engine.store("Alice owns Alpha.", scope_id=scope.id)
        jobs = engine.list_jobs(job_type="index_source")

        assert jobs
        assert jobs[0].payload["scope_id"] == scope.id


class TestEngineSearch:
    def test_search_after_store(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        result = engine.search("CEO")
        assert result.total_count >= 1

    def test_search_with_options(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        result = engine.search("CEO", SearchOptions(max_results=1))
        assert len(result.hits) <= 1

    def test_search_no_results(self, engine):
        result = engine.search("nonexistent")
        assert result.total_count == 0

    def test_search_supports_reranking_explanations(self, engine):
        session = engine.start_session("codex")
        engine.create_entity("Alice")
        engine.add_fact("Alice", "leading the meeting prep", predicate="role", session_id=session.session_id)
        result = engine.search(
            "meeting prep",
            SearchOptions(query="meeting prep"),
            session_id=session.session_id,
        )
        assert result.hits
        assert result.hits[0].base_score >= 0
        assert result.hits[0].explanation.summary
        assert result.hits[0].explanation.trace is not None

    def test_search_filters_hits_outside_scope(self, engine):
        alpha = engine.create_scope("project", "alpha")
        beta = engine.create_scope("project", "beta")
        _add_scoped_fact(
            engine,
            name="Alice",
            raw_text="Alice leads the Alpha roadmap.",
            obj="Alpha roadmap lead",
            scope_id=alpha.id,
        )
        _add_scoped_fact(
            engine,
            name="Alice",
            raw_text="Alice leads the Beta roadmap.",
            obj="Beta roadmap lead",
            scope_id=beta.id,
        )

        result = engine.search(
            "Alice roadmap",
            scope_selection=ScopeSelection(
                primary_scope_id=alpha.id,
                include_global=False,
            ),
        )

        assert result.hits
        assert all(hit.explanation.summary for hit in result.hits)
        assert all("beta" not in hit.snippet.lower() for hit in result.hits)

    def test_search_keeps_scope_match_factor(self, engine):
        alpha = engine.create_scope("project", "alpha")
        _add_scoped_fact(
            engine,
            name="Alice",
            raw_text="Alice leads the Alpha roadmap.",
            obj="Alpha roadmap lead",
            scope_id=alpha.id,
        )

        result = engine.search(
            "Alice roadmap",
            SearchOptions(
                query="Alice roadmap",
                context=RetrievalContext(include_explanations=True),
            ),
            scope_selection=ScopeSelection(
                primary_scope_id=alpha.id,
                include_global=False,
            ),
        )

        assert result.hits
        assert any(
            factor.name == "scope_match"
            for factor in result.hits[0].ranking_factors
        )

    def test_search_applies_stale_penalty_and_opens_request(self, engine):
        entity = engine.create_entity("Alice")
        fact = engine.storage.add_fact(
            Fact(
                entity_id=entity.id,
                subject="Alice",
                predicate="role",
                object="platform lead",
                raw_text="Alice leads platform work.",
                source=Source(type=SourceType.USER_INPUT),
            )
        )
        engine.storage.update_fact_freshness(
            fact.id,
            verification_status="stale",
            verification_due_at="2000-01-01T00:00:00",
        )

        result = engine.search("platform work")

        assert result.hits
        assert any(
            factor.name == "freshness_penalty"
            for factor in result.hits[0].ranking_factors
        )
        requests = engine.storage.list_verification_requests()
        assert len(requests) == 1

    def test_search_excludes_archive_only_fact(self, engine):
        engine.create_entity("Alice")
        engine.add_fact("Alice", "Alice owns the alpha plan", predicate="role")
        fact = engine.get_facts("Alice")[0]
        engine.set_retention_policy(
            RetentionTargetKind.FACT,
            fact.id,
            RetentionPolicyType.ARCHIVE_ONLY,
            reason="historical",
        )

        result = engine.search("alpha plan")

        assert result.total_count == 0

    def test_search_context_rejects_invalid_expand_hops(self, engine):
        with pytest.raises(ValueError):
            engine.search_context("alpha", expand_hops=3)

    def test_search_can_filter_by_applicability_tags(self, engine):
        engine.create_entity("Alice")
        engine.add_fact(
            "Alice",
            "Alice owns the incident response rotation.",
            predicate="role",
            applies_if=["incident"],
        )

        mismatched = engine.search(
            "incident response rotation",
            SearchOptions(
                query="incident response rotation",
                context_tags=["sales"],
            ),
        )
        matched = engine.search(
            "incident response rotation",
            SearchOptions(
                query="incident response rotation",
                context_tags=["incident"],
            ),
        )

        assert mismatched.total_count == 0
        assert matched.total_count == 1



class TestEngineEntity:
    def test_get_entity(self, engine):
        engine.store("Simon Kim is the CEO.")
        entity = engine.get_entity("Simon Kim")
        assert entity is not None
        assert entity.name == "Simon Kim"

    def test_get_entity_not_found(self, engine):
        assert engine.get_entity("Nobody") is None

    def test_create_entity_manually(self, engine):
        entity = engine.create_entity("Hashed", entity_type="organization", tier=Tier.CORE)
        assert entity.name == "Hashed"
        assert entity.tier == Tier.CORE
        retrieved = engine.get_entity("Hashed")
        assert retrieved is not None

    def test_list_entities(self, engine):
        engine.create_entity("Alice Smith", entity_type="person")
        engine.create_entity("Bob Corp", entity_type="organization")
        all_entities = engine.list_entities()
        assert len(all_entities) == 2

    def test_list_entities_filter(self, engine):
        engine.create_entity("Alice Smith", entity_type="person")
        engine.create_entity("Bob Corp", entity_type="organization")
        orgs = engine.list_entities(entity_type="organization")
        assert len(orgs) == 1
        assert orgs[0].name == "Bob Corp"

    def test_create_entity_updates_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        entity = engine.create_entity("Hashed", entity_type="organization", tier=Tier.CORE)

        assert stub.indexed == [(entity.id, "Hashed")]

    def test_delete_entity_removes_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        entity = engine.create_entity("Hashed", entity_type="organization", tier=Tier.CORE)
        stub.indexed.clear()

        assert engine.delete_entity("Hashed") is True
        assert stub.removed == [entity.id]
        assert engine.get_entity("Hashed") is None


class TestEngineFact:
    def test_add_fact(self, engine):
        engine.create_entity("Simon Kim")
        result = engine.add_fact("Simon Kim", "CEO of Hashed", predicate="role")
        assert result.is_accepted

    def test_add_fact_entity_not_found(self, engine):
        from engram.exceptions import EntityNotFoundError
        with pytest.raises(EntityNotFoundError):
            engine.add_fact("Nobody", "Some fact")

    def test_get_facts(self, engine):
        engine.create_entity("Simon Kim")
        engine.add_fact("Simon Kim", "CEO of Hashed", predicate="role")
        facts = engine.get_facts("Simon Kim")
        assert len(facts) >= 1

    def test_add_fact_updates_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        entity = engine.create_entity("Simon Kim")
        stub.indexed.clear()

        engine.add_fact("Simon Kim", "CEO of Hashed", predicate="role")

        assert len(stub.indexed) == 1
        indexed_id, indexed_text = stub.indexed[0]
        assert indexed_id == entity.id
        assert "CEO of Hashed" in indexed_text

    def test_add_fact_persists_applicability_metadata(self, engine):
        engine.create_entity("Alice")

        engine.add_fact(
            "Alice",
            "Use the handoff template.",
            predicate="guide",
            applies_if=["handoff"],
            except_if=["incident"],
        )

        fact = engine.get_facts("Alice")[0]

        assert fact.applicability.applies_if == ["handoff"]
        assert fact.applicability.except_if == ["incident"]


class TestEngineSession:
    def test_session_lifecycle(self, engine):
        session = engine.start_session("claude-code")
        assert session.is_active

        ended = engine.end_session(session.session_id, summary="Test session")
        assert not ended.is_active
        assert ended.summary == "Test session"

    def test_session_context(self, engine):
        s1 = engine.start_session("claude")
        engine.end_session(s1.session_id, summary="Discussed funding")

        context = engine.get_session_context("claude")
        assert context["entity_count"] >= 0
        assert context["previous_summary"] == "Discussed funding"

    def test_session_context_new_agent(self, engine):
        context = engine.get_session_context("new-agent")
        assert context["previous_summary"] == ""

    def test_session_context_keeps_key_facts_when_recent_session_contains_missing_entity_ids(self, engine):
        engine.create_entity("Alice")
        engine.add_fact("Alice", "Alice owns the migration plan.", predicate="role")

        session = engine.start_session("claude")
        session.entities_accessed.extend(["missing-entity-id", engine.get_entity("Alice").id])
        engine.end_session(session.session_id, summary="Discussed migration ownership")

        context = engine.get_session_context("claude")

        assert context["recent_entity_details"][0]["name"] == "Alice"
        assert any(
            row["entity"] == "Alice" and "migration plan" in row["fact"]
            for row in context["key_facts"]
        )

    def test_end_session_indexes_decisions(self, engine):
        session = engine.start_session("codex")
        ended = engine.end_session(session.session_id, summary="We decided to deploy the patch.")
        rows = engine.list_decisions(status=DecisionStatus.ACTIVE)
        assert ended.summary is not None
        assert any(row.source_kind == "session" for row in rows)

    def test_get_decision_returns_explained_view(self, engine):
        session = engine.start_session("codex")
        engine.end_session(session.session_id, summary="We decided to deploy the patch.")
        decision = engine.list_decisions(status=DecisionStatus.ACTIVE)[0]

        decision_view = engine.get_decision(decision.id)

        assert decision_view is not None
        assert decision_view.explanation.summary
        assert decision_view.explanation.evidence

    def test_get_decision_adds_freshness_warning(self, engine):
        session = engine.start_session("codex")
        engine.end_session(session.session_id, summary="We decided to ship the fix.")
        decision = engine.list_decisions(status=DecisionStatus.ACTIVE)[0]
        engine.storage.update_decision_freshness(
            decision.id,
            verification_status="stale",
            verification_due_at="2000-01-01T00:00:00",
        )

        payload = engine.get_decision(decision.id)

        assert payload is not None
        assert payload.explanation.warnings

    def test_end_session_keeps_session_scope(self, engine):
        scope = engine.create_scope("task", "handoff")

        session = engine.start_session("agent-x", scope_id=scope.id)
        engine.end_session(session.session_id, summary="Wrapped handoff")
        saved = engine.storage.get_session(session.session_id)

        assert saved.scope_id == scope.id

    def test_add_fact_inherits_session_scope(self, engine):
        scope = engine.create_scope("task", "handoff")
        engine.create_entity("Alice")
        session = engine.start_session("agent-x", scope_id=scope.id)

        engine.add_fact(
            "Alice",
            "Alice owns the handoff checklist.",
            predicate="role",
            session_id=session.session_id,
        )

        fact = engine.get_facts("Alice")[0]

        assert fact.scope_id == scope.id

    def test_add_fact_rejects_missing_session_before_write(self, engine):
        engine.create_entity("Alice")

        with pytest.raises(SessionError):
            engine.add_fact(
                "Alice",
                "Alice owns the handoff checklist.",
                predicate="role",
                session_id="missing-session",
            )

        assert engine.get_facts("Alice") == []

    def test_build_context_pack_raises_for_missing_session(self, engine):
        with pytest.raises(ValueError):
            engine.build_context_pack(session_id="missing-session")

    def test_transfer_context_raises_for_missing_session(self, engine):
        with pytest.raises(ValueError):
            engine.transfer_context(
                from_session_id="missing-session",
                to_agent_id="writer",
            )


class TestEngineMaintenance:
    def test_health_check(self, engine):
        health = engine.health_check()
        assert "entity_count" in health
        assert "status" in health

    def test_export_markdown(self, engine):
        engine.create_entity("Test Entity")
        count = engine.export_markdown()
        assert count >= 1

    def test_reindex(self, engine):
        engine.create_entity("Test Entity")
        count = engine.reindex()
        assert count >= 1

    def test_reindex_refreshes_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        first = engine.create_entity("First Entity")
        second = engine.create_entity("Second Entity")
        stub.indexed.clear()

        count = engine.reindex()

        assert count == 2
        assert stub.cleared == 1
        indexed_ids = {entity_id for entity_id, _ in stub.indexed}
        assert indexed_ids == {first.id, second.id}

    def test_run_maintenance_persists_run(self, engine):
        engine.create_entity("Lonely")
        run = engine.run_maintenance()
        saved = engine.get_maintenance_run(run.id)
        assert saved is not None
        assert saved.run.id == run.id
        assert saved.items
        assert saved.items[0].explanation.summary

    def test_maintenance_run_includes_job_backlog(self, engine):
        engine.enqueue_job("maintenance_run", {})
        run = engine.run_maintenance()
        assert any(item.kind == "projection_drift" for item in run.items)

    def test_backlinks_exposed_via_engine(self, engine):
        engine.create_entity("Alice")
        engine.store("Alice met the team.")
        rows = engine.backlinks("Alice")
        assert rows
        assert rows[0]["explanation"]["summary"]

    def test_entity_brief_excludes_never_summarize_fact(self, engine):
        engine.create_entity("Alice")
        engine.add_fact("Alice", "Alice carries a temporary credential", predicate="note")
        fact = engine.get_facts("Alice")[0]
        engine.set_retention_policy(
            RetentionTargetKind.FACT,
            fact.id,
            RetentionPolicyType.NEVER_SUMMARIZE,
            reason="sensitive",
        )

        brief = engine.entity_brief("Alice")

        assert brief is not None
        assert brief.top_facts == []

    def test_list_recommendations_emits_stale_decision(self, engine):
        decision = DecisionRecord(
            title="Ship the fix",
            summary="We decided to ship the fix.",
            status=DecisionStatus.ACTIVE,
            confidence=0.9,
            source_kind="session",
            source_id="session-1",
            fingerprint="decision-retention-1",
        )
        engine.storage.replace_decisions("session", "session-1", [decision])
        stored = engine.storage.get_decision(decision.id)
        engine.storage.update_decision_freshness(
            stored.id,
            verification_status="stale",
            verification_due_at="2000-01-01T00:00:00",
        )

        rows = engine.list_recommendations()

        assert any(row.kind.value == "stale_decision" for row in rows)

    def test_pinned_stale_decision_is_not_recommended(self, engine):
        decision = DecisionRecord(
            title="Ship the fix",
            summary="We decided to ship the fix.",
            status=DecisionStatus.ACTIVE,
            confidence=0.9,
            source_kind="session",
            source_id="session-2",
            fingerprint="decision-retention-2",
        )
        engine.storage.replace_decisions("session", "session-2", [decision])
        stored = engine.storage.get_decision(decision.id)
        engine.storage.update_decision_freshness(
            stored.id,
            verification_status="stale",
            verification_due_at="2000-01-01T00:00:00",
        )
        engine.set_retention_policy(
            RetentionTargetKind.DECISION,
            stored.id,
            RetentionPolicyType.PIN,
            reason="keep visible",
        )

        rows = engine.list_recommendations()

        assert all(row.target_id != stored.id for row in rows)

    def test_open_loop_escalation_requires_repeat_run(self, engine):
        engine.create_entity("Lonely")
        engine.run_maintenance()
        engine.run_maintenance()

        rows = engine.list_recommendations()

        assert any(row.kind.value == "open_loop_escalation" for row in rows)

    def test_open_loop_escalation_does_not_trigger_after_single_run(self, engine):
        engine.create_entity("Lonely")
        engine.run_maintenance()

        rows = engine.list_recommendations()

        assert all(row.kind.value != "open_loop_escalation" for row in rows)

    def test_list_recommendations_emits_merge_recommendation(self, engine):
        engine.create_entity("Simon Kim")
        engine.create_entity("S. Kim")
        secondary = engine.get_entity("S. Kim")
        secondary.aliases = ["Simon Kim"]
        engine.storage.update_entity(secondary)

        engine.generate_governance_candidates()
        rows = engine.list_recommendations()

        assert any(row.kind.value == "merge_recommendation" for row in rows)

    def test_merge_recommendation_reports_pin_conflict(self, engine):
        primary = engine.create_entity("Simon Kim")
        engine.create_entity("S. Kim")
        secondary = engine.get_entity("S. Kim")
        secondary.aliases = ["Simon Kim"]
        engine.storage.update_entity(secondary)
        engine.set_retention_policy(
            RetentionTargetKind.ENTITY,
            primary.id,
            RetentionPolicyType.PIN,
            reason="important identity",
        )

        engine.generate_governance_candidates()
        rows = engine.list_recommendations(kind="merge_recommendation")

        assert rows
        assert "pin" in rows[0].policy_conflicts

    def test_follow_up_task_emits_for_aged_verification_request(self, engine):
        engine.create_entity("Alice")
        engine.add_fact("Alice", "Alice owns launch", predicate="role")
        fact = engine.get_facts("Alice")[0]
        request = engine.request_fact_verification(fact.id, reason="manual")
        request.requested_at = datetime.now() - timedelta(days=4)
        engine.storage.update_verification_request(request)

        rows = engine.list_recommendations(kind="follow_up_task")

        assert any(
            row.target_kind == "verification_request" and row.target_id == request.id
            for row in rows
        )

    def test_follow_up_task_skips_resolved_verification_request(self, engine):
        engine.create_entity("Alice")
        engine.add_fact("Alice", "Alice owns launch", predicate="role")
        fact = engine.get_facts("Alice")[0]
        request = engine.request_fact_verification(fact.id, reason="manual")
        engine.resolve_verification_request(request.id, VerificationResolution.VERIFIED)

        rows = engine.list_recommendations(kind="follow_up_task")

        assert all(row.target_id != request.id for row in rows)

    def test_follow_up_task_emits_for_open_split_candidate(self, engine):
        entity = engine.create_entity("Jordan Lee")
        for value in ("CTO", "HR Manager"):
            engine.storage.add_fact(
                Fact(
                    entity_id=entity.id,
                    subject="Jordan Lee",
                    predicate="role",
                    object=value,
                    raw_text=f"Jordan Lee is {value}.",
                    source=Source(type=SourceType.USER_INPUT, confidence=1.0),
                )
            )
        candidate = next(
            row for row in engine.generate_governance_candidates()
            if row.candidate_type is GovernanceCandidateType.SPLIT
        )
        engine.storage._conn.execute(
            "UPDATE governance_candidates SET created_at = ?, updated_at = ? WHERE id = ?",
            (
                (datetime.now() - timedelta(days=4)).isoformat(),
                (datetime.now() - timedelta(days=4)).isoformat(),
                candidate.id,
            ),
        )
        engine.storage._conn.commit()

        rows = engine.list_recommendations(kind="follow_up_task")

        assert any(
            row.target_kind == "governance_candidate" and row.target_id == candidate.id
            for row in rows
        )

    def test_follow_up_task_emits_for_critical_open_loop(self, engine):
        engine.create_entity("Lonely")
        engine.run_maintenance()
        engine.run_maintenance()
        engine.run_maintenance()

        rows = engine.list_recommendations(kind="follow_up_task")

        assert any(row.target_kind == "open_loop" for row in rows)

    def test_merge_entities_updates_secondary_index(self, engine):
        engine.search_engine.close()
        stub = _SecondaryIndexStub()
        engine.search_engine = stub

        primary = engine.create_entity("Simon Kim")
        secondary = engine.create_entity("S. Kim")
        stub.indexed.clear()

        merged = engine.merge_entities("Simon Kim", "S. Kim")

        assert merged.id == primary.id
        assert secondary.id in stub.removed
        assert any(entity_id == primary.id for entity_id, _ in stub.indexed)

    def test_run_operations_review_returns_operations_review(self, engine):
        engine.create_entity("Lonely")

        review = engine.run_operations_review()

        assert review.summary_lines
        assert review.maintenance_run is not None


class TestGovernance:
    def test_approve_merge_candidate_rebinds_facts_references_and_decisions(self, engine):
        primary = engine.create_entity("Simon Kim")
        secondary = engine.create_entity("S. Kim")
        secondary.aliases = ["Simon Kim"]
        engine.storage.update_entity(secondary)

        fact = Fact(
            entity_id=secondary.id,
            subject="S. Kim",
            predicate="role",
            object="Platform Lead",
            raw_text="S. Kim leads the platform team.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            confidence=0.9,
            status=FactStatus.UNVERIFIED,
        )
        engine.storage.add_fact(fact)
        engine.storage.replace_reference_edges(
            "note",
            "note-1",
            [
                ReferenceEdge(
                    entity_id=secondary.id,
                    source_kind="note",
                    source_id="note-1",
                    snippet="S. Kim leads the platform team.",
                    matched_text="S. Kim",
                    match_start=0,
                    match_end=6,
                )
            ],
        )
        engine.storage.replace_decisions(
            "note",
            "note-1",
            [
                DecisionRecord(
                    title="Ownership",
                    summary="S. Kim owns rollout.",
                    status=DecisionStatus.ACTIVE,
                    confidence=0.9,
                    source_kind="note",
                    source_id="note-1",
                    entity_id=secondary.id,
                    fingerprint="decision-governance-1",
                )
            ],
        )

        candidate = next(
            row
            for row in engine.generate_governance_candidates()
            if row.candidate_type is GovernanceCandidateType.MERGE
        )

        resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)

        assert resolved.status is GovernanceCandidateStatus.APPLIED
        assert engine.storage.get_entity(secondary.id) is None
        refreshed = engine.get_entity("Simon Kim")
        assert refreshed is not None
        assert "S. Kim" in refreshed.aliases
        facts = engine.storage.get_facts(primary.id)
        assert all(row.entity_id == primary.id for row in facts)
        refs = engine.storage.list_reference_edges(primary.id)
        assert refs and refs[0].entity_id == primary.id
        decisions = engine.list_decisions(entity_name="Simon Kim")
        assert decisions and decisions[0].entity_id == primary.id

    def test_approve_alias_candidate_adds_alias_without_duplicate(self, engine):
        entity = engine.create_entity("Acme Labs")
        candidate = engine.governance_service.build_alias_candidate(entity, "Acme")

        engine.storage.upsert_governance_candidate(candidate)
        resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)
        refreshed = engine.get_entity("Acme Labs")

        assert resolved.status is GovernanceCandidateStatus.APPLIED
        assert refreshed is not None
        assert refreshed.aliases.count("Acme") == 1

    def test_approve_merge_candidate_cancels_redundant_alias_candidate(self, engine):
        engine.create_entity("Simon Kim")
        engine.create_entity("S. Kim")
        secondary = engine.get_entity("S. Kim")
        secondary.aliases = ["Simon Kim"]
        engine.storage.update_entity(secondary)

        rows = engine.generate_governance_candidates()
        merge = next(row for row in rows if row.candidate_type is GovernanceCandidateType.MERGE)
        primary = engine.get_entity("Simon Kim")
        alias = engine.governance_service.build_alias_candidate(primary, "S. Kim")
        alias = engine.storage.upsert_governance_candidate(alias)

        engine.resolve_governance_candidate(merge.id, GovernanceResolution.APPROVE)
        refreshed_alias = engine.get_governance_candidate(alias.id)

        assert refreshed_alias is not None
        assert refreshed_alias.status is GovernanceCandidateStatus.CANCELLED

    def test_resolve_split_candidate_marks_review_only_applied(self, engine):
        entity = engine.create_entity("Jordan Lee")
        for value in ("CTO", "HR Manager"):
            engine.storage.add_fact(
                Fact(
                    entity_id=entity.id,
                    subject="Jordan Lee",
                    predicate="role",
                    object=value,
                    raw_text=f"Jordan Lee is {value}.",
                    source=Source(type=SourceType.USER_INPUT, confidence=1.0),
                    confidence=0.9,
                    status=FactStatus.UNVERIFIED,
                )
            )

        candidate = next(
            row
            for row in engine.generate_governance_candidates()
            if row.candidate_type is GovernanceCandidateType.SPLIT
        )
        resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)

        facts = engine.storage.get_facts(entity.id)
        assert resolved.status is GovernanceCandidateStatus.APPLIED
        assert len(facts) == 2
