"""Tests for Korean NER — precision and recall."""

import pytest

from engram.extraction.ner.korean import extract_korean_entities


class TestKoreanPersonDetection:
    def test_basic_korean_name(self):
        entities = extract_korean_entities("김민수가 발표를 했다.")
        names = [e.name for e in entities]
        assert "김민수" in names

    def test_two_syllable_name(self):
        entities = extract_korean_entities("이준은 회의에 참석했다.")
        names = [e.name for e in entities]
        assert "이준" in names

    def test_three_syllable_given_name(self):
        entities = extract_korean_entities("박서연이 프로젝트를 리드한다.")
        names = [e.name for e in entities]
        assert any("박서연" in n for n in names)

    def test_multiple_names(self):
        entities = extract_korean_entities("김민수와 이서연이 만났다.")
        names = [e.name for e in entities]
        assert "김민수" in names

    def test_deduplication(self):
        entities = extract_korean_entities("김민수가 왔다. 김민수는 갔다.")
        names = [e.name for e in entities]
        assert names.count("김민수") == 1


class TestKoreanFalsePositiveRejection:
    """Common Korean words that should NOT be detected as names."""

    def test_reject_common_words(self):
        entities = extract_korean_entities("오늘 회의에서 논의했다.")
        names = [e.name for e in entities]
        assert "오늘" not in names
        assert "회의" not in names

    def test_reject_business_terms(self):
        entities = extract_korean_entities("투자를 확대하고 사업을 성장시켰다.")
        # These should not produce person entities
        person_names = [e.name for e in entities if e.entity_type == "person"]
        assert len(person_names) == 0


class TestKoreanOrganizationDetection:
    def test_org_with_keyword(self):
        entities = extract_korean_entities("삼성전자 주식회사가 발표했다.")
        orgs = [e for e in entities if e.entity_type == "organization"]
        assert len(orgs) >= 1

    def test_org_university(self):
        entities = extract_korean_entities("서울대학교에서 연구를 진행한다.")
        orgs = [e for e in entities if e.entity_type == "organization"]
        org_names = [e.name for e in orgs]
        assert any("서울대학교" in n for n in org_names)


class TestKoreanEdgeCases:
    def test_empty_string(self):
        assert extract_korean_entities("") == []

    def test_english_only(self):
        # Should not extract anything from English-only text
        entities = extract_korean_entities("Simon Kim is the CEO of Hashed.")
        assert len(entities) == 0
