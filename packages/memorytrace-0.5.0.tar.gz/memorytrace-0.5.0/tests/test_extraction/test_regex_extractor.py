"""Tests for the regex-based extractor."""

import pytest

from engram.extraction.regex_extractor import RegexExtractor
from engram.models.entity import Entity
from engram.models.source import Source, SourceType


@pytest.fixture
def extractor():
    return RegexExtractor(
        default_source=Source(type=SourceType.DOCUMENT, confidence=0.8)
    )


class TestExtractEntities:
    def test_english_entities(self, extractor):
        entities = extractor.extract_entities("Simon Kim is the CEO of Hashed Inc.")
        names = [e.name for e in entities]
        assert "Simon Kim" in names

    def test_korean_entities(self, extractor):
        entities = extractor.extract_entities("김민수가 발표를 했다.")
        names = [e.name for e in entities]
        assert "김민수" in names

    def test_mixed_language(self, extractor):
        text = "Simon Kim은 김민수와 함께 Ethereum Foundation에서 만났다."
        entities = extractor.extract_entities(text)
        names = [e.name for e in entities]
        assert "Simon Kim" in names

    def test_dedup_across_languages(self, extractor):
        entities = extractor.extract_entities("Simon Kim이 왔다. Simon Kim이 갔다.")
        names = [e.name for e in entities]
        assert names.count("Simon Kim") == 1

    def test_empty_text(self, extractor):
        assert extractor.extract_entities("") == []


class TestExtractFacts:
    def test_basic_fact(self, extractor):
        text = "Simon Kim is the CEO of Hashed."
        entities = extractor.extract_entities(text)
        facts = extractor.extract_facts(text, entities)
        assert len(facts) >= 1
        assert any("CEO" in f.raw_text for f in facts)

    def test_fact_grounded_to_entity(self, extractor):
        text = "Simon Kim founded a new company."
        entities = [Entity(name="Simon Kim", entity_type="person")]
        facts = extractor.extract_facts(text, entities)
        for fact in facts:
            assert fact.entity_id == entities[0].id

    def test_no_facts_without_entities(self, extractor):
        text = "Simon Kim is the CEO."
        facts = extractor.extract_facts(text, [])  # No entities provided
        assert len(facts) == 0

    def test_long_object_truncated(self, extractor):
        long_text = "Simon Kim is " + "a very important person " * 50 + "."
        entities = [Entity(name="Simon Kim", entity_type="person")]
        facts = extractor.extract_facts(long_text, entities)
        for fact in facts:
            assert len(fact.object) <= 200


class TestExtractRelations:
    def test_ceo_relation(self, extractor):
        text = "Simon Kim is the CEO of Hashed."
        entities = [
            Entity(name="Simon Kim", entity_type="person"),
            Entity(name="Hashed", entity_type="organization"),
        ]
        relations = extractor.extract_relations(text, entities)
        assert len(relations) >= 1
        assert any("CEO" in r.relation_type for r in relations)

    def test_relation_requires_both_entities(self, extractor):
        text = "Simon Kim is the CEO of Hashed."
        entities = [Entity(name="Simon Kim", entity_type="person")]
        # Only one entity — should not create relation
        relations = extractor.extract_relations(text, entities)
        assert len(relations) == 0

    def test_no_relations_in_plain_text(self, extractor):
        text = "The weather is nice today."
        relations = extractor.extract_relations(text, [])
        assert len(relations) == 0
