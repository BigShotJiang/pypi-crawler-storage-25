"""Tests for LLM extractor — mock-based (no actual API calls)."""

import pytest
import json
from unittest.mock import MagicMock, patch

from engram.models.entity import Entity
from engram.models.fact import Fact


class TestLLMExtractorParsing:
    """Test JSON parsing logic without actual LLM calls."""

    def test_parse_json_response_clean(self):
        from engram.extraction.llm_extractor import LLMExtractor
        # Mock client to avoid ImportError
        with patch.dict("sys.modules", {"anthropic": MagicMock()}):
            ext = LLMExtractor.__new__(LLMExtractor)
            result = ext._parse_json_response('[{"name": "Simon Kim", "entity_type": "person"}]')
            assert len(result) == 1
            assert result[0]["name"] == "Simon Kim"

    def test_parse_json_response_with_code_block(self):
        from engram.extraction.llm_extractor import LLMExtractor
        ext = LLMExtractor.__new__(LLMExtractor)
        text = '```json\n[{"name": "Simon Kim"}]\n```'
        result = ext._parse_json_response(text)
        assert len(result) == 1

    def test_parse_json_response_invalid(self):
        from engram.extraction.llm_extractor import LLMExtractor
        ext = LLMExtractor.__new__(LLMExtractor)
        result = ext._parse_json_response("not json at all")
        assert result == []

    def test_parse_json_response_empty(self):
        from engram.extraction.llm_extractor import LLMExtractor
        ext = LLMExtractor.__new__(LLMExtractor)
        result = ext._parse_json_response("[]")
        assert result == []


class TestLLMExtractorWithMock:
    """Test full extraction flow with mocked LLM responses."""

    @pytest.fixture
    def mock_extractor(self):
        from engram.extraction.llm_extractor import LLMExtractor
        ext = LLMExtractor.__new__(LLMExtractor)
        ext.provider = "anthropic"
        ext.model = "test-model"
        ext._client = MagicMock()
        return ext

    def test_extract_entities_mock(self, mock_extractor):
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text='[{"name": "Simon Kim", "entity_type": "person"}]')]
        mock_extractor._client.messages.create.return_value = mock_response

        entities = mock_extractor.extract_entities("Simon Kim is the CEO.")
        assert len(entities) == 1
        assert entities[0].name == "Simon Kim"

    def test_extract_entities_dedup(self, mock_extractor):
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text='[{"name": "Simon Kim"}, {"name": "simon kim"}]')]
        mock_extractor._client.messages.create.return_value = mock_response

        entities = mock_extractor.extract_entities("Text")
        assert len(entities) == 1

    def test_extract_entities_empty_text(self, mock_extractor):
        assert mock_extractor.extract_entities("") == []

    def test_extract_entities_api_failure(self, mock_extractor):
        mock_extractor._client.messages.create.side_effect = Exception("API error")
        entities = mock_extractor.extract_entities("Some text")
        assert entities == []  # Graceful fallback

    def test_extract_facts_mock(self, mock_extractor):
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text=json.dumps([
            {"subject": "Simon Kim", "predicate": "role", "object": "CEO", "raw_text": "Simon Kim is CEO", "confidence": 0.9}
        ]))]
        mock_extractor._client.messages.create.return_value = mock_response

        entities = [Entity(name="Simon Kim", entity_type="person")]
        facts = mock_extractor.extract_facts("Simon Kim is CEO.", entities)
        assert len(facts) == 1
        assert facts[0].confidence == 0.9

    def test_extract_facts_no_entities(self, mock_extractor):
        assert mock_extractor.extract_facts("Text", []) == []

    def test_extract_relations_mock(self, mock_extractor):
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text=json.dumps([
            {"from_name": "Simon Kim", "to_name": "Hashed", "relation_type": "CEO_OF"}
        ]))]
        mock_extractor._client.messages.create.return_value = mock_response

        entities = [
            Entity(name="Simon Kim", entity_type="person"),
            Entity(name="Hashed", entity_type="organization"),
        ]
        relations = mock_extractor.extract_relations("Simon Kim is CEO of Hashed.", entities)
        assert len(relations) == 1
        assert relations[0].relation_type == "CEO_OF"

    def test_extract_relations_single_entity(self, mock_extractor):
        entities = [Entity(name="Simon Kim")]
        assert mock_extractor.extract_relations("Text", entities) == []
