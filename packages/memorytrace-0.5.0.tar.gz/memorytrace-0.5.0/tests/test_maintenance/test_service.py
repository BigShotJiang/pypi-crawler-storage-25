from __future__ import annotations

from engram.config import EngramConfig
from engram.maintenance.service import MaintenanceService
from engram.models.entity import Entity
from engram.quality.diagnostics import Diagnostics
from engram.storage.sqlite_store import SQLiteStorage


def test_run_persists_summary_and_items(tmp_path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    storage.create_entity(Entity(name="Lonely"))

    service = MaintenanceService(storage, Diagnostics(storage, EngramConfig(base_dir=tmp_path / "engram")))
    run = service.run()

    try:
        assert run.id
        assert run.items
        saved = storage.get_maintenance_run(run.id)
        assert saved is not None
        assert saved.grade == run.grade
        assert len(saved.items) == len(run.items)
    finally:
        storage.close()
