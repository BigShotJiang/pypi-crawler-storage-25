"""Tests for operations review models and orchestration."""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.operations import OperationsReview


@pytest.fixture
def engine(tmp_path):
    eng = MemoryEngine(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    yield eng
    eng.close()


def test_operations_review_to_dict_keeps_summary_lines():
    review = OperationsReview(summary_lines=["2 open loops", "1 queued job"])

    payload = review.to_dict()

    assert payload["summary_lines"] == ["2 open loops", "1 queued job"]


def test_run_operations_review_returns_health_maintenance_and_drift(engine):
    engine.create_entity("Lonely")

    review = engine.run_operations_review()

    assert review.health_report is not None
    assert review.maintenance_run is not None
    assert isinstance(review.reference_drift, list)
    assert isinstance(review.decision_drift, list)
    assert review.summary_lines


def test_run_operations_review_can_execute_jobs(engine):
    scope = engine.create_scope("project", "alpha")
    engine.store("Alice owns Alpha.", scope_id=scope.id)

    review = engine.run_operations_review(run_jobs=True, job_limit=10)

    assert review.job_result is not None
    assert review.job_result.completed >= 1
