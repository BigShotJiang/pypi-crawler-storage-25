"""Persisted maintenance tests."""
