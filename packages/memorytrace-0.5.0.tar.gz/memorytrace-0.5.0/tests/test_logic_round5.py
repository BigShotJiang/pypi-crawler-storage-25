"""Round-5 logic/consistency regressions."""

from __future__ import annotations

import json

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import EntityState, Tier
from engram.models.intake import BatchStatus
from engram.models.source import Source, SourceType


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestMergeEntitiesFullStateMerge:
    def test_email_filled_from_secondary(self, engine):
        primary = engine.create_entity("Alice Smith")
        secondary = engine.create_entity("A. Smith")
        # Set state on each side.
        primary.state.role = "CEO"
        engine.storage.update_entity(primary)
        secondary.state.email = "alice@acme.example"
        engine.storage.update_entity(secondary)

        merged = engine.merge_entities("Alice Smith", "A. Smith")
        refreshed = engine.storage.get_entity_by_name("Alice Smith")
        assert refreshed.state.email == "alice@acme.example"
        assert refreshed.state.role == "CEO"

    def test_custom_keys_filled_without_clobber(self, engine):
        primary = engine.create_entity("Alice Smith")
        secondary = engine.create_entity("A. Smith")

        primary.state.custom = {"favourite_color": "blue"}
        engine.storage.update_entity(primary)
        secondary.state.custom = {
            "favourite_color": "red",  # must NOT clobber primary
            "pronouns": "she/her",
        }
        engine.storage.update_entity(secondary)

        engine.merge_entities("Alice Smith", "A. Smith")
        refreshed = engine.storage.get_entity_by_name("Alice Smith")
        assert refreshed.state.custom.get("favourite_color") == "blue"
        assert refreshed.state.custom.get("pronouns") == "she/her"


class TestBatchStatusAllSkipped:
    def test_all_skipped_becomes_applied(self, engine):
        # Pre-create the entity so intake's candidate is a duplicate and gets
        # skipped during apply.
        engine.create_entity("Alice Smith")
        engine.storage.update_entity(engine.storage.get_entity_by_name("Alice Smith"))

        batch = engine.intake("Alice Smith is the CEO of Acme Corp.")
        result = engine.apply_intake(batch.id)

        # Entity reused → candidate APPLIED (reused), may or may not be
        # skipped depending on extractor output. Force the all-skipped case
        # by rejecting fact/relation candidates, applying only entities, and
        # then re-applying entities which are already in the DB.
        # Simpler: directly mark all pending candidates as skipped via the
        # service and recompute.
        svc = engine._intake_service()
        for cand in engine.get_intake(batch.id).candidates:
            if cand.status.value == "pending":
                engine.storage._conn.execute(
                    "UPDATE staging_candidates SET status='skipped' WHERE id=?",
                    (cand.id,),
                )
        engine.storage._conn.commit()
        svc._recompute_batch_status(batch.id)

        refreshed = engine.get_intake(batch.id)
        assert refreshed.status == BatchStatus.APPLIED, (
            "all-skipped should be treated as a successful no-op batch"
        )


class TestEndSessionCompactErrorLogged:
    def test_compact_failure_records_session_event(self, engine, monkeypatch):
        session = engine.start_session("agent")
        # Seed an entity and mark it as modified so end_session would try to
        # compact it.
        engine.create_entity("Alice Smith")
        entity = engine.storage.get_entity_by_name("Alice Smith")
        engine.session_mgr.record_entity_modified(session.session_id, entity.id)
        # Pretend there are enough current facts to trigger compact.
        def fake_current_facts(eid):
            return [object()] * 20  # > 15 triggers compact
        monkeypatch.setattr(
            engine.storage, "get_current_facts", fake_current_facts
        )
        # Make compact blow up.
        def boom(name):
            raise RuntimeError("synthetic compact failure")
        monkeypatch.setattr(engine, "compact_entity", boom)

        engine.end_session(session.session_id)

        # end_session must succeed AND record a compact_error event.
        rows = engine.storage._conn.execute(
            "SELECT event_type, target, detail FROM session_events "
            "WHERE session_id = ? AND event_type = 'compact_error'",
            (session.session_id,),
        ).fetchall()
        assert rows, "compact failure should have been recorded"
        detail = json.loads(rows[0]["detail"])
        assert detail["error_type"] == "RuntimeError"
        assert "synthetic" in detail["message"]
