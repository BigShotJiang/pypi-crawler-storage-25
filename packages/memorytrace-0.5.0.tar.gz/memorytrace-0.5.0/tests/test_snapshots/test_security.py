"""Security regression tests for SnapshotService (P1 from review 1/15).

Snapshot files and the snapshots directory must be owner-only on POSIX, the
same way :mod:`engram.storage.sqlite_store` hardens the live DB. Skipped on
Windows where the permission bits don't translate.
"""

from __future__ import annotations

import os
import stat
import sys

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.source import Source, SourceType


pytestmark = pytest.mark.skipif(
    sys.platform == "win32",
    reason="POSIX mode bits don't apply on Windows",
)


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


def _perm_bits(path) -> int:
    return stat.S_IMODE(os.stat(path).st_mode)


class TestSnapshotPermissions:
    def test_snapshots_dir_is_owner_only(self, engine):
        # Trigger snapshot service to materialize the dir.
        engine.create_snapshot(label="init")
        dir_mode = _perm_bits(engine.config.snapshots_dir)
        assert dir_mode & 0o077 == 0, (
            f"snapshots dir mode {dir_mode:o} leaks access to group/other"
        )

    def test_snapshot_file_is_owner_only(self, engine):
        engine.create_entity("Alice Smith")
        engine.add_fact(
            "Alice Smith",
            "CEO of Acme",
            predicate="role",
            source=Source(type=SourceType.USER_INPUT, author="press"),
        )
        snap = engine.create_snapshot()
        path = engine.config.snapshots_dir / snap.file_path
        file_mode = _perm_bits(path)
        assert file_mode == 0o600, (
            f"snapshot file mode {file_mode:o} should be 0o600"
        )

    def test_restored_file_is_owner_only(self, engine, tmp_path):
        snap = engine.create_snapshot()
        target = tmp_path / "restored.db"
        engine.restore_snapshot(snap.id, target)
        mode = _perm_bits(target)
        assert mode == 0o600
