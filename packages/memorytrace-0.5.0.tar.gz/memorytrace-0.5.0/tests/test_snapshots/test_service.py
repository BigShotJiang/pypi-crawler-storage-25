"""Tests for SnapshotService / engine.*_snapshot (Feature 6).

Covers docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §6.
"""

from __future__ import annotations

import gzip
import sqlite3
from pathlib import Path

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.source import Source, SourceType
from engram.snapshots.service import SnapshotService


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


def _seed_basic(engine: MemoryEngine) -> None:
    """Seed a small graph: one entity + one fact."""
    engine.create_entity("Alice Smith")
    engine.add_fact(
        "Alice Smith",
        "CEO of Acme",
        predicate="role",
        source=Source(type=SourceType.USER_INPUT, author="press", channel="news"),
    )


class TestCreateSnapshot:
    def test_create_writes_file_and_manifest(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot(label="pre-migration", description="test")
        assert snap.id
        assert snap.label == "pre-migration"
        assert snap.entity_count == 1
        assert snap.fact_count == 1
        assert snap.schema_version  # non-empty

        # File exists on disk and is gzip-readable.
        path = engine.config.snapshots_dir / snap.file_path
        assert path.exists()
        with gzip.open(path, "rb") as f:
            header = f.read(16)
        assert header.startswith(b"SQLite format 3"), (
            "Decompressed blob must be a valid SQLite file"
        )

        # Manifest round-trips.
        fetched = engine.get_snapshot(snap.id)
        assert fetched is not None
        assert fetched.label == "pre-migration"
        assert fetched.entity_count == 1

    def test_compression_reduces_size(self, engine):
        # Seed enough data so compression is measurable.
        engine.create_entity("Alice Smith")
        for i in range(50):
            engine.add_fact(
                "Alice Smith",
                f"fact number {i} with some repetition " * 10,
                predicate="attribute",
                source=Source(type=SourceType.USER_INPUT),
            )
        snap = engine.create_snapshot()
        assert snap.uncompressed_size > 0
        assert snap.compressed_size <= snap.uncompressed_size

    def test_list_returns_newest_first(self, engine):
        _seed_basic(engine)
        s1 = engine.create_snapshot(label="first")
        s2 = engine.create_snapshot(label="second")
        snaps = engine.list_snapshots()
        assert [s.id for s in snaps[:2]] == [s2.id, s1.id]


class TestOpenSnapshot:
    def test_open_yields_read_only_connection(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        svc = SnapshotService(engine.storage, engine.config.snapshots_dir)
        with svc.open_snapshot(snap.id) as conn:
            rows = conn.execute("SELECT name FROM entities").fetchall()
            assert any(r["name"] == "Alice Smith" for r in rows)
            # Writes must fail on a read-only connection.
            with pytest.raises(sqlite3.OperationalError):
                conn.execute(
                    "INSERT INTO entities (id,name,entity_type,tier,created_at,updated_at) "
                    "VALUES ('x','Bob','person','recall','2024-01-01','2024-01-01')"
                )

    def test_open_missing_snapshot_raises(self, engine):
        svc = SnapshotService(engine.storage, engine.config.snapshots_dir)
        with pytest.raises(ValueError):
            with svc.open_snapshot("nonexistent"):
                pass

    def test_temp_file_cleanup_after_context(self, engine, tmp_path):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        svc = SnapshotService(engine.storage, engine.config.snapshots_dir)
        with svc.open_snapshot(snap.id) as conn:
            conn.execute("SELECT 1").fetchone()
        # Nothing to assert directly — the point is the context exited without
        # raising on Windows file locking. A second open must also work:
        with svc.open_snapshot(snap.id) as conn:
            conn.execute("SELECT 1").fetchone()


class TestSnapshotIsolation:
    """Changes made after a snapshot must not bleed into it."""

    def test_entity_added_after_snapshot_not_visible(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot()

        # Mutate live DB after the snapshot.
        engine.create_entity("Bob Wright")

        data = engine.get_entity_at_snapshot(snap.id, "Bob Wright")
        assert data is None

        # The snapshot still sees only Alice.
        hits = engine.search_snapshot(snap.id, "Alice")
        assert any("Alice" in (h.get("entity_name") or "") for h in hits)

    def test_fact_added_after_snapshot_not_visible_in_entity_pack(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        engine.add_fact(
            "Alice Smith", "joined the board", predicate="attribute"
        )
        pack = engine.get_entity_at_snapshot(snap.id, "Alice Smith")
        fact_texts = [f["raw_text"] for f in pack["facts"]]
        assert "CEO of Acme" in fact_texts
        assert "joined the board" not in fact_texts


class TestSnapshotDiff:
    def test_added_removed_modified_all_detected(self, engine):
        engine.create_entity("Alice Smith")
        engine.create_entity("Bob Wright")
        engine.add_fact("Alice Smith", "CEO of Acme", predicate="role")

        snap_a = engine.create_snapshot(label="A")

        # Between A and B: add Carol, remove Bob, modify Alice (add a fact).
        engine.create_entity("Carol Doe")
        engine.delete_entity("Bob Wright")
        engine.add_fact("Alice Smith", "joined the board", predicate="attribute")

        snap_b = engine.create_snapshot(label="B")

        diff = engine.diff_snapshots(snap_a.id, snap_b.id)
        assert "Carol Doe" in diff.entities_added
        assert "Bob Wright" in diff.entities_removed
        assert "Alice Smith" in diff.entities_modified
        assert diff.facts_delta == 1

    def test_identical_snapshots_have_empty_diff(self, engine):
        _seed_basic(engine)
        a = engine.create_snapshot()
        b = engine.create_snapshot()  # no writes between
        diff = engine.diff_snapshots(a.id, b.id)
        assert diff.entities_added == []
        assert diff.entities_removed == []
        assert diff.entities_modified == []
        assert diff.facts_delta == 0


class TestSnapshotQueries:
    def test_search_at_returns_bm25_hits(self, engine):
        _seed_basic(engine)
        engine.create_entity("Unrelated Guy")
        snap = engine.create_snapshot()
        results = engine.search_snapshot(snap.id, "Alice")
        names = [r.get("entity_name") for r in results]
        assert any("Alice" in (n or "") for n in names)

    def test_get_entity_at_returns_none_for_missing(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        assert engine.get_entity_at_snapshot(snap.id, "Nobody") is None


class TestDelete:
    def test_delete_removes_file_and_row(self, engine):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        path = engine.config.snapshots_dir / snap.file_path
        assert path.exists()

        assert engine.delete_snapshot(snap.id) is True
        assert not path.exists()
        assert engine.get_snapshot(snap.id) is None
        assert engine.delete_snapshot(snap.id) is False  # already gone


class TestRestore:
    def test_restore_decompresses_to_target(self, engine, tmp_path):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        target = tmp_path / "restored.db"

        returned = engine.restore_snapshot(snap.id, target)
        assert returned == target
        assert target.exists()

        # Restored file is a usable SQLite DB with the entity we seeded.
        conn = sqlite3.connect(str(target))
        try:
            row = conn.execute(
                "SELECT name FROM entities WHERE name = 'Alice Smith'"
            ).fetchone()
            assert row is not None
        finally:
            conn.close()

    def test_restore_refuses_to_overwrite(self, engine, tmp_path):
        _seed_basic(engine)
        snap = engine.create_snapshot()
        target = tmp_path / "already.db"
        target.write_bytes(b"do not overwrite me")
        with pytest.raises(FileExistsError):
            engine.restore_snapshot(snap.id, target)
