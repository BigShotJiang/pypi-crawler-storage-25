"""Tests for SDK integration surfaces."""

from __future__ import annotations

from engram.config import EngramConfig
from engram.integrations.sdk import EngramSDK


def test_sdk_search_context_delegates_to_engine(tmp_path, monkeypatch):
    sdk = EngramSDK(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    called: dict = {}

    def fake_search_context(query, **kwargs):
        called["query"] = query
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "search_context", fake_search_context)

    result = sdk.search_context(
        "release owner",
        goal="task_handoff",
        plan_query=True,
        context_tags=["handoff"],
    )

    assert result == {"ok": True}
    assert called["query"] == "release owner"
    assert called["goal"] == "task_handoff"
    assert called["plan_query"] is True
    assert called["context_tags"] == ["handoff"]
    sdk.close()


def test_sdk_build_query_plan_delegates_to_engine(tmp_path, monkeypatch):
    sdk = EngramSDK(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    called: dict = {}

    def fake_build_query_plan(query):
        called["query"] = query
        return {"fragments": ["release owner", "rollback approver"]}

    monkeypatch.setattr(sdk.engine, "build_query_plan", fake_build_query_plan)

    result = sdk.build_query_plan("release owner and rollback approver")

    assert result == {"fragments": ["release owner", "rollback approver"]}
    assert called["query"] == "release owner and rollback approver"
    sdk.close()


def test_sdk_build_context_pack_delegates_to_engine(tmp_path, monkeypatch):
    sdk = EngramSDK(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    called: dict = {}

    def fake_build_context_pack(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "build_context_pack", fake_build_context_pack)

    result = sdk.build_context_pack(session_id="session-1")

    assert result == {"ok": True}
    assert called["session_id"] == "session-1"
    sdk.close()


def test_sdk_transfer_context_delegates_to_engine(tmp_path, monkeypatch):
    sdk = EngramSDK(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    called: dict = {}

    def fake_transfer_context(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "transfer_context", fake_transfer_context)

    result = sdk.transfer_context(
        from_session_id="session-1",
        to_agent_id="writer",
        note="Continue the memo.",
    )

    assert result == {"ok": True}
    assert called["to_agent_id"] == "writer"
    sdk.close()


def test_sdk_operations_review_delegates_to_engine(tmp_path, monkeypatch):
    sdk = EngramSDK(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    called: dict = {}

    def fake_run_operations_review(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "run_operations_review", fake_run_operations_review)

    result = sdk.operations_review(run_jobs=True, job_limit=10)

    assert result == {"ok": True}
    assert called["run_jobs"] is True
    assert called["job_limit"] == 10
    sdk.close()
