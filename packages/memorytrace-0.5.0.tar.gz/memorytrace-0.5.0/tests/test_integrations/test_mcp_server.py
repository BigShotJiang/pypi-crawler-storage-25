"""Tests for MCP server tool functions (without running actual MCP server)."""

import sys
import types

import pytest


class TestMCPServerImport:
    def test_mcp_server_module_importable(self):
        """The module should be importable even without mcp package."""
        # This tests that the module doesn't crash on import
        from engram.integrations import mcp_server
        assert hasattr(mcp_server, "run_server")
        assert hasattr(mcp_server, "_get_engine")

    def test_run_server_registers_context_search_tool(self, monkeypatch):
        from engram.integrations import mcp_server

        tool_names: list[str] = []

        class FakeServer:
            def __init__(self, _name: str):
                self.name = _name

            def tool(self):
                def decorator(func):
                    tool_names.append(func.__name__)
                    return func

                return decorator

        async def fake_stdio_server(_app):
            return None

        mcp_module = types.ModuleType("mcp")
        server_module = types.ModuleType("mcp.server")
        stdio_module = types.ModuleType("mcp.server.stdio")
        server_module.Server = FakeServer
        stdio_module.stdio_server = fake_stdio_server
        monkeypatch.setitem(sys.modules, "mcp", mcp_module)
        monkeypatch.setitem(sys.modules, "mcp.server", server_module)
        monkeypatch.setitem(sys.modules, "mcp.server.stdio", stdio_module)

        mcp_server.run_server("stdio")

        assert "memory_context_search" in tool_names
        assert "memory_context_pack" in tool_names
        assert "memory_context_transfer" in tool_names
        assert "memory_query_plan" in tool_names
        assert "memory_operations_review" in tool_names
