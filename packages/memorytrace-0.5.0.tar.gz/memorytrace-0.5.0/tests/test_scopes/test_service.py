from __future__ import annotations

from engram.scopes.service import ScopeService
from engram.models.scope import ScopeSelection


def test_scope_service_creates_hierarchical_scope(storage):
    service = ScopeService(storage)

    workspace = service.create("workspace", "engram")
    project = service.create("project", "phase-2", parent_scope_id=workspace.id)

    resolved = service.resolve_selection(
        ScopeSelection(primary_scope_id=project.id, include_ancestors=True)
    )

    assert project.id in resolved.allowed_scope_ids
    assert workspace.id in resolved.allowed_scope_ids


def test_scope_service_rejects_duplicate_kind_path(storage):
    service = ScopeService(storage)
    service.create("project", "alpha")

    try:
        service.create("project", "alpha")
    except ValueError as exc:
        assert "already exists" in str(exc)
    else:
        raise AssertionError("duplicate scope create must fail")
