"""Scope service tests."""
