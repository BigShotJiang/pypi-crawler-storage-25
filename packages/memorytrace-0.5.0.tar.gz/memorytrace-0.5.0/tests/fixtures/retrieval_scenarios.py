from __future__ import annotations

from engram.models.entity import Entity, Tier
from engram.models.search import SearchHit, SearchResult


def make_search_result() -> SearchResult:
    alice = Entity(name="Alice", entity_type="person", tier=Tier.RECALL)
    acme = Entity(name="Acme", entity_type="organization", tier=Tier.RECALL)
    return SearchResult(
        query="meeting prep",
        hits=[
            SearchHit(entity=acme, relevance_score=0.9, base_score=0.9, snippet="Acme planning"),
            SearchHit(entity=alice, relevance_score=0.7, base_score=0.7, snippet="Alice joins meeting"),
        ],
        total_count=2,
    )
