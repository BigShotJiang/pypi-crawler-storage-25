from __future__ import annotations


def assert_explanation_bundle(payload: dict) -> None:
    assert payload["summary"] is not None
    assert "factors" in payload
    assert "evidence" in payload
    assert "warnings" in payload
