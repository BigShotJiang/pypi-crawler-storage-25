"""Round-6 logic/consistency regressions.

* Debug reject/confirm parallel to round-4 conclude: idempotency-by-refusal
  instead of silent overwrite.
* Relation dedup on intake apply.
* Snapshot ``get_entity_at`` alias fallback.
"""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.debug import HypothesisStatus


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestDebugClosedHypothesisGuards:
    def test_reject_already_rejected_raises(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "theory")
        engine.debug_reject(h.id, "original reason")
        with pytest.raises(ValueError) as exc:
            engine.debug_reject(h.id, "new reason")
        assert "already" in str(exc.value).lower()

    def test_confirm_already_confirmed_raises(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "theory")
        engine.debug_confirm(h.id)
        with pytest.raises(ValueError):
            engine.debug_confirm(h.id)

    def test_reject_a_confirmed_hypothesis_raises(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "theory")
        engine.debug_confirm(h.id)
        with pytest.raises(ValueError):
            engine.debug_reject(h.id, "contradicting evidence found")


class TestIntakeRelationDedup:
    def test_second_apply_does_not_duplicate_relation(self, engine):
        # Stage and apply once.
        batch1 = engine.intake("Simon Kim is the CEO of Hashed.")
        engine.apply_intake(batch1.id)

        before = engine.storage._conn.execute(
            "SELECT COUNT(*) AS c FROM relations"
        ).fetchone()["c"]
        # Stage the SAME content again and apply.
        batch2 = engine.intake("Simon Kim is the CEO of Hashed.")
        result = engine.apply_intake(batch2.id)
        after = engine.storage._conn.execute(
            "SELECT COUNT(*) AS c FROM relations"
        ).fetchone()["c"]

        # Relation count must not have grown — duplicates are skipped.
        assert after == before, (
            f"relations table grew from {before} to {after}; "
            f"expected dedup to skip"
        )
        # Relation candidates should be reported as skipped, not applied.
        from engram.models.intake import CandidateType, CandidateStatus
        relation_cands = [
            c for c in result.applied + result.skipped
            if c.candidate_type == CandidateType.RELATION
        ]
        if relation_cands:
            for rc in relation_cands:
                if rc.candidate_type == CandidateType.RELATION:
                    assert rc.status in (CandidateStatus.SKIPPED, CandidateStatus.APPLIED)


class TestSnapshotGetEntityAtAliases:
    def test_alias_lookup_matches(self, engine):
        alice = engine.create_entity("Alice Smith")
        alice.aliases = ["Ally", "AS"]
        engine.storage.update_entity(alice)
        snap = engine.create_snapshot()

        # Canonical name still works.
        by_name = engine.get_entity_at_snapshot(snap.id, "Alice Smith")
        assert by_name is not None

        # Alias resolves to the same entity.
        by_alias = engine.get_entity_at_snapshot(snap.id, "Ally")
        assert by_alias is not None
        assert by_alias["entity"]["id"] == by_name["entity"]["id"]

        # Non-matching name still returns None.
        assert engine.get_entity_at_snapshot(snap.id, "Nobody") is None
