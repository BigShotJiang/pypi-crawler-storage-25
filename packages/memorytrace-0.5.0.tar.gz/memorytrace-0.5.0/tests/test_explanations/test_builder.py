from __future__ import annotations

from engram.models.explanation import (
    EvidenceRef,
    ExplanationBundle,
    ExplanationFactor,
    ProvenanceReason,
    ProvenanceTrace,
)
from engram.models.entity import Entity, Tier
from engram.models.fact import Fact
from engram.models.search import RankingFactor, SearchHit
from engram.models.source import Source, SourceType
from engram.explanations.builder import ExplanationBuilder


def test_explanation_bundle_serializes_nested_objects() -> None:
    bundle = ExplanationBundle(
        summary="Matched active entity memory.",
        trace=ProvenanceTrace(
            retriever="fts5_bm25",
            query="alice project",
            base_score=2.5,
            snippet="Alice owns the roadmap.",
            matched_fact_ids=["fact-1"],
            reasons=[ProvenanceReason(kind="bm25", detail="Matched alice")],
        ),
        factors=[
            ExplanationFactor(
                name="active_entity_boost",
                stage="rerank",
                delta=0.4,
                reason="Entity is active in working memory",
            )
        ],
        evidence=[
            EvidenceRef(
                kind="fact",
                id="fact-1",
                label="Alice owns the roadmap",
                snippet="Alice owns the roadmap.",
                entity_id="entity-1",
                source_kind="note",
                source_id="note-1",
            )
        ],
        warnings=[],
    )

    payload = bundle.to_dict()

    assert payload["summary"] == "Matched active entity memory."
    assert payload["trace"]["query"] == "alice project"
    assert payload["factors"][0]["name"] == "active_entity_boost"
    assert payload["evidence"][0]["kind"] == "fact"


def test_builder_creates_bundle_from_search_hit() -> None:
    hit = SearchHit(
        entity=Entity(name="Alice", entity_type="person", tier=Tier.RECALL),
        facts=[
            Fact(
                entity_id="entity-1",
                subject="Alice",
                predicate="role",
                object="owner",
                raw_text="Alice owns the roadmap.",
                source=Source(type=SourceType.USER_INPUT, url="note-1"),
            )
        ],
        relevance_score=1.4,
        base_score=1.0,
        snippet="Alice owns the roadmap.",
        ranking_factors=[
            RankingFactor(
                name="active_entity_boost",
                delta=0.4,
                reason="Entity is active in working memory",
            )
        ],
        provenance=ProvenanceTrace(
            retriever="fts5_bm25",
            query="alice roadmap",
            base_score=1.0,
            snippet="Alice owns the roadmap.",
            matched_fact_ids=["fact-1"],
            reasons=[ProvenanceReason(kind="bm25", detail="Matched alice")],
        ),
    )

    bundle = ExplanationBuilder().from_search_hit("alice roadmap", hit)

    assert bundle.summary == "Retrieved Alice via fts5_bm25."
    assert bundle.trace is not None
    assert bundle.trace.query == "alice roadmap"
    assert bundle.factors[0].name == "active_entity_boost"
    assert bundle.evidence[0].kind == "fact"
