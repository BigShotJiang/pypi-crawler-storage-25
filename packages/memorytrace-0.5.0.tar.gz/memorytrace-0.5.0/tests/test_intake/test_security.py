"""Security regression tests for IntakeService (P0/P1 from review 1/15).

These pin behavior that was broken before the 2026-04-15 security review:

* PII must be masked BEFORE landing in ``staging_batches`` / ``staging_candidates``
  so rejected batches don't leave credit-card numbers, SSNs, or API keys in
  the database.
* The CLI ``intake --from-file`` must refuse a blocklist of sensitive paths
  and a handful of secret-ish filename extensions.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from engram.cli import app as cli_app
from engram.cli.app import _read_intake_file
from engram.config import EngramConfig
from engram.engine import MemoryEngine


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestIntakePIIMasking:
    def test_raw_text_masked_in_staging(self, engine):
        text = "Alice Smith SSN 123-45-6789 should be confidential."
        batch = engine.intake(text)

        # Reload from DB to ensure we're inspecting persisted values.
        persisted = engine.get_intake(batch.id)
        assert persisted is not None
        assert "123-45-6789" not in persisted.raw_text
        assert "[REDACTED]" in persisted.raw_text

    def test_email_masked_in_raw_text(self, engine):
        batch = engine.intake("Bob Wright (bob@acme.internal) joined today.")
        persisted = engine.get_intake(batch.id)
        assert "bob@acme.internal" not in persisted.raw_text
        assert "[REDACTED]" in persisted.raw_text

    def test_api_key_masked_in_candidate_payload(self, engine):
        # Use a key-like pattern the detector knows about.
        text = "Alice Smith leaked sk-abcdefghijklmnopqrstuvwxyz0123 by accident."
        batch = engine.intake(text)

        persisted = engine.get_intake(batch.id)
        # Scan the entire batch + all candidate payloads as JSON.
        serialized = json.dumps(persisted.to_dict(), ensure_ascii=False)
        assert "sk-abcdefghijklmnopqrstuvwxyz0123" not in serialized
        assert "[REDACTED]" in serialized

    def test_no_pii_means_no_change(self, engine):
        """PII masking is a no-op when the text has no matches."""
        text = "Alice Smith is the CEO of Acme Corp."
        batch = engine.intake(text)
        persisted = engine.get_intake(batch.id)
        assert persisted.raw_text == text
        assert "[REDACTED]" not in persisted.raw_text

    def test_rejected_batch_does_not_expose_raw_secrets(self, engine):
        """Even after rejection, the staging rows must not hold cleartext PII."""
        batch = engine.intake(
            "Card 4111-1111-1111-1111 belongs to Alice Smith."
        )
        engine.reject_intake(batch.id)
        persisted = engine.get_intake(batch.id)
        serialized = json.dumps(persisted.to_dict(), ensure_ascii=False)
        assert "4111-1111-1111-1111" not in serialized


class TestIntakeFilePathSafety:
    def test_rejects_ssh_private_key_path(self, tmp_path):
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()
        key_path = ssh_dir / "id_rsa"
        key_path.write_text("-----BEGIN OPENSSH PRIVATE KEY-----\n...\n")

        with pytest.raises(PermissionError) as exc:
            _read_intake_file(str(key_path), allow_unsafe=False)
        assert ".ssh/" in str(exc.value) or "id_rsa" in str(exc.value)

    def test_rejects_pem_extension(self, tmp_path):
        cert = tmp_path / "server.pem"
        cert.write_text("-----BEGIN CERTIFICATE-----\nX\n-----END CERTIFICATE-----\n")
        with pytest.raises(PermissionError):
            _read_intake_file(str(cert), allow_unsafe=False)

    def test_rejects_dotenv(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("API_KEY=hunter2\n")
        with pytest.raises(PermissionError):
            _read_intake_file(str(env), allow_unsafe=False)

    def test_unsafe_path_bypasses_blocklist(self, tmp_path):
        # With the explicit opt-in, the same path reads successfully.
        cert = tmp_path / "server.pem"
        cert.write_text("legit content\n")
        content = _read_intake_file(str(cert), allow_unsafe=True)
        assert content.strip() == "legit content"

    def test_rejects_oversize_file(self, tmp_path):
        big = tmp_path / "big.txt"
        # 2 MiB of text — above the 1 MiB cap.
        big.write_text("a" * (2 * 1024 * 1024))
        with pytest.raises(ValueError) as exc:
            _read_intake_file(str(big), allow_unsafe=False)
        assert "bytes" in str(exc.value).lower()

    def test_rejects_binary_content(self, tmp_path):
        binary = tmp_path / "pic.txt"
        binary.write_bytes(b"\xff\xfe\xfa\x00\x01\x02")
        with pytest.raises(ValueError) as exc:
            _read_intake_file(str(binary), allow_unsafe=False)
        assert "utf-8" in str(exc.value).lower()

    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            _read_intake_file(str(tmp_path / "nope.txt"), allow_unsafe=False)

    def test_normal_path_is_allowed(self, tmp_path):
        doc = tmp_path / "notes.txt"
        doc.write_text("Alice Smith is the CEO of Acme Corp.\n")
        assert _read_intake_file(str(doc), allow_unsafe=False).startswith("Alice")
