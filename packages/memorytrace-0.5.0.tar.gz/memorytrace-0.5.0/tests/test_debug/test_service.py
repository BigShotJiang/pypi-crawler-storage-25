"""Tests for DebugService / engine.debug_* (Feature 5).

Covers docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §5.
"""

from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.debug.service import DebugService
from engram.engine import MemoryEngine
from engram.models.debug import (
    DebugSessionStatus,
    EvidenceResult,
    HypothesisStatus,
)


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestSessionLifecycle:
    def test_start_returns_open_session(self, engine):
        s = engine.debug_start("Intake apply drops relations")
        assert s.status == DebugSessionStatus.OPEN
        assert s.bug_description == "Intake apply drops relations"
        assert s.hypotheses == []
        assert s.closed_at is None

    def test_start_rejects_empty_description(self, engine):
        with pytest.raises(ValueError):
            engine.debug_start("   ")

    def test_conclude_marks_closed(self, engine):
        s = engine.debug_start("bug")
        closed = engine.debug_conclude(s.id, conclusion="fixed it")
        assert closed.status == DebugSessionStatus.RESOLVED
        assert closed.conclusion == "fixed it"
        assert closed.closed_at is not None

    def test_conclude_abandons_open_hypotheses(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "maybe caching")
        closed = engine.debug_conclude(s.id, conclusion="moved on", status=DebugSessionStatus.ABANDONED)
        assert closed.status == DebugSessionStatus.ABANDONED
        refreshed = engine.get_debug_session(s.id)
        target = next(hy for hy in refreshed.hypotheses if hy.id == h.id)
        assert target.status == HypothesisStatus.ABANDONED

    def test_conclude_missing_session_raises(self, engine):
        with pytest.raises(ValueError):
            engine.debug_conclude("nonexistent-id")

    def test_conclude_cannot_reopen(self, engine):
        s = engine.debug_start("bug")
        with pytest.raises(ValueError):
            engine.debug_conclude(s.id, status=DebugSessionStatus.OPEN)


class TestHypothesisLifecycle:
    def test_add_hypothesis_under_open_session(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "the cache is stale")
        assert h.debug_session_id == s.id
        assert h.status == HypothesisStatus.OPEN
        assert h.text == "the cache is stale"

    def test_cannot_add_hypothesis_to_closed_session(self, engine):
        s = engine.debug_start("bug")
        engine.debug_conclude(s.id, conclusion="done")
        with pytest.raises(ValueError):
            engine.debug_hypothesis(s.id, "late hypothesis")

    def test_reject_records_reason(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "locks are the problem")
        rejected = engine.debug_reject(h.id, "no lock contention observed")
        assert rejected.status == HypothesisStatus.REJECTED
        assert rejected.rejection_reason == "no lock contention observed"
        assert rejected.closed_at is not None

    def test_reject_requires_reason(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "x")
        with pytest.raises(ValueError):
            engine.debug_reject(h.id, "  ")

    def test_confirm_marks_confirmed(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "nonidempotent write")
        confirmed = engine.debug_confirm(h.id)
        assert confirmed.status == HypothesisStatus.CONFIRMED
        assert confirmed.closed_at is not None

    def test_debug_hypothesis_indexes_references(self, engine):
        engine.create_entity("Alice")
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "Alice might own the cache bug")
        rows = engine.backlinks("Alice", source_kind="debug_hypothesis")
        assert any(row["source_id"] == h.id for row in rows)


class TestEvidence:
    def test_evidence_counts_by_result(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "slow SQL")
        engine.debug_evidence(h.id, "query EXPLAIN shows seq scan", result=EvidenceResult.SUPPORTS)
        engine.debug_evidence(h.id, "index exists and is used elsewhere", result=EvidenceResult.CONTRADICTS)
        engine.debug_evidence(h.id, "not relevant", result=EvidenceResult.NEUTRAL)
        refreshed = engine.get_debug_session(s.id)
        target = next(hy for hy in refreshed.hypotheses if hy.id == h.id)
        assert target.support_count == 1
        assert target.contradict_count == 1
        assert len(target.evidence) == 3

    def test_evidence_against_missing_hypothesis_raises(self, engine):
        with pytest.raises(ValueError):
            engine.debug_evidence("no-such-hyp", "whatever")

    def test_evidence_requires_text(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "something")
        with pytest.raises(ValueError):
            engine.debug_evidence(h.id, "   ")


class TestQueries:
    def test_list_filters_by_status(self, engine):
        s1 = engine.debug_start("bug A")
        s2 = engine.debug_start("bug B")
        engine.debug_conclude(s2.id, conclusion="done")
        open_only = engine.list_debug_sessions(status=DebugSessionStatus.OPEN)
        resolved_only = engine.list_debug_sessions(status=DebugSessionStatus.RESOLVED)
        assert [s.id for s in open_only] == [s1.id]
        assert [s.id for s in resolved_only] == [s2.id]

    def test_search_finds_rejected_hypothesis(self, engine):
        s = engine.debug_start("bug")
        h = engine.debug_hypothesis(s.id, "GC is pausing the world")
        engine.debug_reject(h.id, "GC logs show 2ms pauses")

        hits = engine.search_debug_hypotheses("GC")
        assert any(found.id == h.id for found in hits)
        assert all(hh.status in HypothesisStatus for hh in hits)

    def test_search_can_restrict_to_rejected(self, engine):
        s = engine.debug_start("bug")
        open_h = engine.debug_hypothesis(s.id, "cache coherence issue")
        rejected_h = engine.debug_hypothesis(s.id, "cache staleness on replica")
        engine.debug_reject(rejected_h.id, "cache is write-through")
        hits = engine.search_debug_hypotheses(
            "cache", statuses=[HypothesisStatus.REJECTED]
        )
        hit_ids = {h.id for h in hits}
        assert rejected_h.id in hit_ids
        assert open_h.id not in hit_ids

    def test_debug_conclude_indexes_decisions(self, engine):
        s = engine.debug_start("bug")
        engine.debug_conclude(s.id, conclusion="We decided to rollback the deployment.")
        rows = engine.list_decisions()
        assert any(row.source_kind == "debug_session" for row in rows)


class TestRendering:
    def test_session_to_dict_round_trip(self, engine):
        s = engine.debug_start("bug")
        engine.debug_hypothesis(s.id, "something")
        refreshed = engine.get_debug_session(s.id)
        d = refreshed.to_dict()
        assert d["bug_description"] == "bug"
        assert d["hypothesis_counts"].get("open") == 1
        assert d["hypotheses"][0]["status"] == "open"

    def test_session_agent_context_renders_structure(self, engine):
        s = engine.debug_start("Intake drops relations")
        h = engine.debug_hypothesis(s.id, "batch status stuck on mixed")
        engine.debug_evidence(h.id, "reproduced with partial apply", result=EvidenceResult.SUPPORTS)
        text = engine.get_debug_session(s.id).to_agent_context()
        assert text.startswith("## Debug Session: ")
        assert "Intake drops relations" in text
        assert "### Hypotheses" in text
        assert "batch status stuck on mixed" in text
        assert "supports=1" in text


class TestDirectService:
    def test_service_accepts_bare_storage(self, storage):
        svc = DebugService(storage)
        s = svc.start_session("bare bug")
        h = svc.add_hypothesis(s.id, "something")
        svc.add_evidence(h.id, "observed", result=EvidenceResult.SUPPORTS)
        svc.confirm_hypothesis(h.id)
        svc.conclude(s.id, conclusion="ok")
        refreshed = svc.get_session(s.id)
        assert refreshed.status == DebugSessionStatus.RESOLVED
        assert refreshed.hypotheses[0].status == HypothesisStatus.CONFIRMED
