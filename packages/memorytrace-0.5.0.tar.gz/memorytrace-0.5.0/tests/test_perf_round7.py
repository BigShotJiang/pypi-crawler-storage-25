"""Round-7 performance regressions — verifies brief builder batching.

Strategy: wrap ``sqlite3.Connection.execute`` with a counting decorator so a
single test can assert that an operation that touches N rows executes O(1)
queries instead of the previous O(N).
"""

from __future__ import annotations

from contextlib import contextmanager

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.fact import Fact
from engram.models.relation import Relation
from engram.models.source import Source, SourceType


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


@contextmanager
def count_queries(conn):
    """Yield a list that collects every SQL statement executed on ``conn``.

    Only covers the main engine connection (FTS/backup use their own).
    """
    seen: list[str] = []

    def tracer(sql):
        seen.append(sql)

    conn.set_trace_callback(tracer)
    try:
        yield seen
    finally:
        conn.set_trace_callback(None)


def _select_counts(sqls: list[str], target_keyword: str) -> int:
    """Return the count of SELECTs that mention ``target_keyword`` (e.g. FROM entities)."""
    return sum(
        1
        for s in sqls
        if s.strip().upper().startswith("SELECT") and target_keyword in s
    )


def _selects(sqls: list[str], target_keyword: str) -> list[str]:
    return [
        s for s in sqls
        if s.strip().upper().startswith("SELECT") and target_keyword in s
    ]


class TestEntityBriefRelatedBatch:
    def test_many_related_entities_use_single_select(self, engine):
        hub = engine.create_entity("Hub Node")
        for i in range(20):
            neighbor = engine.create_entity(f"Neighbor {i:02d}")
            engine.storage.add_relation(
                Relation(
                    from_entity_id=hub.id,
                    to_entity_id=neighbor.id,
                    relation_type="peers_with",
                )
            )

        with count_queries(engine.storage._conn) as sqls:
            brief = engine.entity_brief("Hub Node")

        assert brief is not None
        assert len(brief.related_entities) == 20
        # Before batching, resolving 20 neighbors produced 20 individual
        # "SELECT * FROM entities WHERE id = ?" queries. After batching, a
        # single "WHERE id IN (...)" does the work. Allow some headroom
        # (<= 4) for other incidental SELECTs from entity_brief.
        entity_selects = _select_counts(sqls, "FROM entities")
        assert entity_selects <= 4, (
            f"entity-brief related resolution should batch; got "
            f"{entity_selects} entities SELECTs (expected <= 4)"
        )


class TestSessionBriefFactBatch:
    def test_many_facts_use_single_select(self, engine):
        engine.create_entity("Alice Smith")
        session = engine.start_session("agent")
        # Add many facts through the session.
        for i in range(25):
            engine.add_fact(
                "Alice Smith",
                f"observation {i}",
                predicate=f"pred_{i}",
                source=Source(type=SourceType.USER_INPUT),
                session_id=session.session_id,
            )

        with count_queries(engine.storage._conn) as sqls:
            brief = engine.session_brief(session.session_id)

        assert brief is not None
        assert len(brief.facts_added) == 25
        fact_selects = _select_counts(sqls, "FROM facts f")
        assert fact_selects <= 2, (
            f"session-brief fact resolution should batch; got "
            f"{fact_selects} fact SELECTs"
        )


class TestConflictBatch:
    def test_many_conflicts_resolved_with_single_fact_select(self, engine):
        alice = engine.create_entity("Alice Smith")
        # Create 10 facts and 10 pending conflicts, each pointing at one of
        # the facts.
        source = Source(type=SourceType.USER_INPUT)
        for i in range(10):
            f1 = Fact(
                entity_id=alice.id,
                subject=alice.name,
                predicate=f"predA_{i}",
                object=f"value_{i}",
                raw_text=f"Alice observation A{i}",
                source=source,
                confidence=0.9,
            )
            f2 = Fact(
                entity_id=alice.id,
                subject=alice.name,
                predicate=f"predB_{i}",
                object=f"other_{i}",
                raw_text=f"Alice observation B{i}",
                source=source,
                confidence=0.8,
            )
            engine.storage.add_fact(f1)
            engine.storage.add_fact(f2)
            engine.storage.add_conflict(
                {
                    "id": f"c_{i}",
                    "existing_fact_id": f1.id,
                    "new_fact_id": f2.id,
                    "conflict_type": "contradiction",
                }
            )

        with count_queries(engine.storage._conn) as sqls:
            brief = engine.entity_brief("Alice Smith")

        assert brief is not None
        assert len(brief.unresolved_conflicts) == 10
        # Previously: ~2 SELECTs per conflict (existing + new fact). After
        # batching: a single IN(...) round-trip.
        fact_selects = _select_counts(sqls, "FROM facts")
        assert fact_selects <= 4, (
            f"conflict resolution should batch fact fetches; got "
            f"{fact_selects} fact SELECTs (expected <= 4)"
        )


class TestConflictScoping:
    def test_session_brief_queries_only_session_conflicts(self, engine):
        engine.create_entity("Alice Smith")
        bob = engine.create_entity("Bob Stone")
        session = engine.start_session("agent")

        source = Source(type=SourceType.USER_INPUT)
        engine.add_fact(
            "Alice Smith",
            "session scoped fact",
            predicate="status",
            source=source,
            session_id=session.session_id,
        )
        session_fact_id = session.facts_added[-1]

        bob_facts: list[Fact] = []
        for i in range(4):
            f1 = Fact(
                entity_id=bob.id,
                subject=bob.name,
                predicate=f"predA_{i}",
                object=f"value_{i}",
                raw_text=f"Bob observation A{i}",
                source=source,
                confidence=0.9,
            )
            f2 = Fact(
                entity_id=bob.id,
                subject=bob.name,
                predicate=f"predB_{i}",
                object=f"other_{i}",
                raw_text=f"Bob observation B{i}",
                source=source,
                confidence=0.8,
            )
            engine.storage.add_fact(f1)
            engine.storage.add_fact(f2)
            bob_facts.extend([f1, f2])
            engine.storage.add_conflict(
                {
                    "id": f"bob_{i}",
                    "existing_fact_id": f1.id,
                    "new_fact_id": f2.id,
                    "conflict_type": "contradiction",
                }
            )

        engine.storage.add_conflict(
            {
                "id": "session_conflict",
                "existing_fact_id": session_fact_id,
                "new_fact_id": bob_facts[0].id,
                "conflict_type": "contradiction",
            }
        )

        with count_queries(engine.storage._conn) as sqls:
            brief = engine.session_brief(session.session_id)

        assert brief is not None
        assert [c.conflict_id for c in brief.open_conflicts] == ["session_conflict"]
        conflict_selects = _selects(sqls, "FROM conflicts")
        assert len(conflict_selects) == 1
        assert "SELECT * FROM conflicts WHERE resolved_at IS NULL" not in conflict_selects[0]
        assert session_fact_id in conflict_selects[0]

    def test_entity_brief_queries_only_entity_conflicts(self, engine):
        alice = engine.create_entity("Alice Smith")
        bob = engine.create_entity("Bob Stone")
        source = Source(type=SourceType.USER_INPUT)

        alice_fact_1 = Fact(
            entity_id=alice.id,
            subject=alice.name,
            predicate="role",
            object="CEO",
            raw_text="Alice is CEO",
            source=source,
            confidence=0.9,
        )
        alice_fact_2 = Fact(
            entity_id=alice.id,
            subject=alice.name,
            predicate="role",
            object="CTO",
            raw_text="Alice is CTO",
            source=source,
            confidence=0.8,
        )
        engine.storage.add_fact(alice_fact_1)
        engine.storage.add_fact(alice_fact_2)
        engine.storage.add_conflict(
            {
                "id": "alice_conflict",
                "existing_fact_id": alice_fact_1.id,
                "new_fact_id": alice_fact_2.id,
                "conflict_type": "contradiction",
            }
        )

        for i in range(4):
            f1 = Fact(
                entity_id=bob.id,
                subject=bob.name,
                predicate=f"predA_{i}",
                object=f"value_{i}",
                raw_text=f"Bob observation A{i}",
                source=source,
                confidence=0.9,
            )
            f2 = Fact(
                entity_id=bob.id,
                subject=bob.name,
                predicate=f"predB_{i}",
                object=f"other_{i}",
                raw_text=f"Bob observation B{i}",
                source=source,
                confidence=0.8,
            )
            engine.storage.add_fact(f1)
            engine.storage.add_fact(f2)
            engine.storage.add_conflict(
                {
                    "id": f"bob_conflict_{i}",
                    "existing_fact_id": f1.id,
                    "new_fact_id": f2.id,
                    "conflict_type": "contradiction",
                }
            )

        with count_queries(engine.storage._conn) as sqls:
            brief = engine.entity_brief("Alice Smith")

        assert brief is not None
        assert [c.conflict_id for c in brief.unresolved_conflicts] == ["alice_conflict"]
        conflict_selects = _selects(sqls, "FROM conflicts")
        assert len(conflict_selects) == 1
        assert "SELECT * FROM conflicts WHERE resolved_at IS NULL" not in conflict_selects[0]
        assert alice.id in conflict_selects[0]
