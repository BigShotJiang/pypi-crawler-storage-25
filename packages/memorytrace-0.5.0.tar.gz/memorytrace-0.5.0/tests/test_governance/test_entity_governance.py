from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.fact import Fact
from engram.models.governance import GovernanceCandidateType
from engram.models.source import Source, SourceType


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


def test_generate_candidates_finds_duplicate_name_pair(engine):
    engine.create_entity("Simon Kim", entity_type="person")
    engine.create_entity("S. Kim", entity_type="person")
    secondary = engine.get_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)

    rows = engine.generate_governance_candidates()

    assert any(row.candidate_type is GovernanceCandidateType.MERGE for row in rows)


def test_generate_candidates_dedupes_on_rerun(engine):
    engine.create_entity("Alice Smith")
    engine.create_entity("A. Smith")
    secondary = engine.get_entity("A. Smith")
    secondary.aliases = ["Alice Smith"]
    engine.storage.update_entity(secondary)

    first = engine.generate_governance_candidates()
    second = engine.generate_governance_candidates()

    assert len(first) == len(second)
    assert {row.fingerprint for row in first} == {row.fingerprint for row in second}


def test_generate_candidates_emits_split_for_conflicting_role_facts(engine):
    entity = engine.create_entity("Jordan Lee")
    for value in ("CTO", "HR Manager"):
        engine.storage.add_fact(
            Fact(
                entity_id=entity.id,
                subject="Jordan Lee",
                predicate="role",
                object=value,
                raw_text=f"Jordan Lee is {value}.",
                source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            )
        )

    rows = engine.generate_governance_candidates()

    split = next(row for row in rows if row.candidate_type is GovernanceCandidateType.SPLIT)
    assert split.entity_id == entity.id
    assert split.related_entity_id is None
    assert split.details["conflicting_predicates"] == "role"


def test_generate_candidates_skips_split_for_single_value_fact(engine):
    entity = engine.create_entity("Taylor Kim")
    engine.storage.add_fact(
        Fact(
            entity_id=entity.id,
            subject="Taylor Kim",
            predicate="role",
            object="Designer",
            raw_text="Taylor Kim is Designer.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
    )

    rows = engine.generate_governance_candidates()

    assert all(row.candidate_type is not GovernanceCandidateType.SPLIT for row in rows)
