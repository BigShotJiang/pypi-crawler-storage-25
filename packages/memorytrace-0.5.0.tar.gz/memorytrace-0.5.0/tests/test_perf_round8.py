"""Round-8 performance regressions for debug and intake services."""

from __future__ import annotations

import json
import uuid
from contextlib import contextmanager

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.debug import EvidenceResult
from engram.models.intake import CandidateType


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
        min_confidence=0.0,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


@contextmanager
def count_queries(conn):
    seen: list[str] = []

    def tracer(sql):
        seen.append(sql)

    conn.set_trace_callback(tracer)
    try:
        yield seen
    finally:
        conn.set_trace_callback(None)


def _select_counts(sqls: list[str], target_keyword: str) -> int:
    return sum(
        1
        for s in sqls
        if s.strip().upper().startswith("SELECT") and target_keyword in s
    )


class CommitCountingConnection:
    def __init__(self, real_conn: object) -> None:
        self._real_conn = real_conn
        self.commit_calls = 0

    def commit(self):
        self.commit_calls += 1
        return self._real_conn.commit()

    def __getattr__(self, name: str) -> object:
        return getattr(self._real_conn, name)


class TestDebugBatching:
    def test_list_sessions_batches_hypotheses_and_evidence(self, engine):
        for i in range(3):
            session = engine.debug_start(f"bug {i}")
            for j in range(2):
                hypothesis = engine.debug_hypothesis(session.id, f"cache issue {i}-{j}")
                engine.debug_evidence(
                    hypothesis.id,
                    f"supports {i}-{j}",
                    result=EvidenceResult.SUPPORTS,
                )
                engine.debug_evidence(
                    hypothesis.id,
                    f"neutral {i}-{j}",
                    result=EvidenceResult.NEUTRAL,
                )

        with count_queries(engine.storage._conn) as sqls:
            sessions = engine.list_debug_sessions(limit=10)

        assert len(sessions) == 3
        assert all(len(session.hypotheses) == 2 for session in sessions)
        assert _select_counts(sqls, "FROM debug_hypotheses") <= 1
        assert _select_counts(sqls, "FROM debug_evidence") <= 1

    def test_search_hypotheses_batches_evidence(self, engine):
        session = engine.debug_start("cache bug")
        for i in range(5):
            hypothesis = engine.debug_hypothesis(session.id, f"cache issue {i}")
            engine.debug_evidence(
                hypothesis.id,
                f"supports {i}",
                result=EvidenceResult.SUPPORTS,
            )

        with count_queries(engine.storage._conn) as sqls:
            hits = engine.search_debug_hypotheses("cache", limit=10)

        assert len(hits) == 5
        assert all(len(h.evidence) == 1 for h in hits)
        assert _select_counts(sqls, "FROM debug_hypotheses") <= 1
        assert _select_counts(sqls, "FROM debug_evidence") <= 1


class TestIntakeBatching:
    def test_list_batches_loads_candidates_in_one_query(self, engine):
        texts = [
            "Alice Smith is the CEO of Acme Corp.",
            "Bob Wright is the CTO of Initech Holdings.",
            "Carol Lee works at Globex.",
            "Daisy Kim joined OpenAI.",
        ]
        for text in texts:
            engine.intake(text)

        with count_queries(engine.storage._conn) as sqls:
            batches = engine.list_intakes(limit=10)

        assert len(batches) == 4
        assert all(batch.candidates for batch in batches)
        assert _select_counts(sqls, "FROM staging_batches") <= 1
        assert _select_counts(sqls, "FROM staging_candidates") <= 1

    def test_apply_skipped_candidates_commits_once(self, engine):
        batch = engine.intake("Totally unrelated sentence.")
        fake_ids: list[str] = []
        for i in range(5):
            candidate_id = str(uuid.uuid4())
            fake_ids.append(candidate_id)
            engine.storage._conn.execute(
                """INSERT INTO staging_candidates
                    (id, batch_id, candidate_type, payload, status,
                     applied_target_id, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)""",
                (
                    candidate_id,
                    batch.id,
                    CandidateType.FACT.value,
                    json.dumps(
                        {
                            "entity_name": f"Missing Person {i}",
                            "subject": f"Missing Person {i}",
                            "predicate": "role",
                            "object": "ghost",
                            "raw_text": "ghost role",
                            "confidence": 0.9,
                        }
                    ),
                    "pending",
                    None,
                    "",
                ),
            )
        engine.storage._conn.commit()

        real_conn = engine.storage._local.conn
        proxy_conn = CommitCountingConnection(real_conn)
        engine.storage._local.conn = proxy_conn
        try:
            result = engine.apply_intake(batch.id, candidate_ids=fake_ids)
        finally:
            engine.storage._local.conn = real_conn

        assert len(result.skipped) == 5
        assert proxy_conn.commit_calls == 1
