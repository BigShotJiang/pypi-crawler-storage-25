"""Security regression tests for PII sinks outside intake (review 2/15).

Round 1 fixed intake. Round 2 closes the remaining cleartext sinks:
* ``engine.store()`` writes raw text to the notes table.
* ``session_events.target`` captures search queries verbatim.
* ``DebugService`` persists every user-authored text field without masking.
"""

from __future__ import annotations

import json

import pytest

from engram.config import EngramConfig
from engram.debug.service import DebugService
from engram.engine import MemoryEngine
from engram.models.debug import EvidenceResult
from engram.quality.pii import PIIDetector, mask_if_needed


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestMaskIfNeededUtility:
    def test_returns_input_unchanged_when_disabled(self):
        det = PIIDetector()
        assert mask_if_needed(det, "My SSN is 123-45-6789", enabled=False) == (
            "My SSN is 123-45-6789"
        )

    def test_returns_input_unchanged_when_detector_missing(self):
        assert mask_if_needed(None, "contact bob@acme.io") == "contact bob@acme.io"

    def test_no_op_on_empty_string(self):
        det = PIIDetector()
        assert mask_if_needed(det, "") == ""
        assert mask_if_needed(det, None) is None

    def test_masks_when_match_found(self):
        det = PIIDetector()
        result = mask_if_needed(det, "SSN 123-45-6789 today")
        assert "123-45-6789" not in result
        assert "[REDACTED]" in result


class TestStoreMasksNotes:
    def test_note_does_not_retain_ssn(self, engine):
        engine.store("Alice Smith SSN 123-45-6789 is a secret.")
        rows = engine.storage._conn.execute(
            "SELECT text FROM notes"
        ).fetchall()
        assert rows, "store() should have persisted a note"
        for row in rows:
            assert "123-45-6789" not in row["text"]
            assert "[REDACTED]" in row["text"]

    def test_note_does_not_retain_api_key(self, engine):
        engine.store("Bob Wright leaked sk-abcdefghijklmnopqrstuvwxyz0123 key.")
        rows = engine.storage._conn.execute(
            "SELECT text FROM notes"
        ).fetchall()
        for row in rows:
            assert "sk-abcdefghijklmnopqrstuvwxyz0123" not in row["text"]

    def test_pii_free_note_round_trips_verbatim(self, engine):
        clean = "Alice Smith is the CEO of Acme Corp."
        engine.store(clean)
        rows = engine.storage._conn.execute(
            "SELECT text FROM notes ORDER BY created_at DESC LIMIT 1"
        ).fetchall()
        assert rows[0]["text"] == clean


class TestSearchEventMasked:
    def test_search_query_redacted_in_session_events(self, engine):
        session = engine.start_session("agent-x")
        # Seed a note whose FTS5 tokens match the query we're about to run.
        # (FTS5 splits "bob@acme.internal" into three tokens: bob/acme/internal.)
        engine.storage.add_note(
            "note-1", "bob@acme.internal met Alice", "user_input"
        )

        engine.search("bob@acme.internal", session_id=session.session_id)

        rows = engine.storage._conn.execute(
            "SELECT target FROM session_events WHERE event_type = 'notes_searched'"
        ).fetchall()
        assert rows, "search over a matching note should log a notes_searched event"
        for row in rows:
            assert "bob@acme.internal" not in (row["target"] or "")
            assert "[REDACTED]" in (row["target"] or "")


class TestDebugServiceMasksText:
    def test_bug_description_masked(self, engine):
        session = engine.debug_start(
            "Token sk-abcdefghijklmnopqrstuvwxyz0123 leaked via reset flow"
        )
        fetched = engine.get_debug_session(session.id)
        assert "sk-abcdefghijklmnopqrstuvwxyz0123" not in fetched.bug_description
        assert "[REDACTED]" in fetched.bug_description

    def test_hypothesis_text_masked(self, engine):
        session = engine.debug_start("bug")
        hyp = engine.debug_hypothesis(
            session.id, "customer-leak@acme.io appears in breach logs"
        )
        fetched = engine.get_debug_session(session.id)
        target = next(h for h in fetched.hypotheses if h.id == hyp.id)
        assert "customer-leak@acme.io" not in target.text

    def test_evidence_text_masked(self, engine):
        session = engine.debug_start("bug")
        hyp = engine.debug_hypothesis(session.id, "auth middleware")
        engine.debug_evidence(
            hyp.id,
            "logs show AUTH_TOKEN=sk-abcdefghijklmnopqrstuvwxyz0123",
            result=EvidenceResult.SUPPORTS,
        )
        fetched = engine.get_debug_session(session.id)
        ev = fetched.hypotheses[0].evidence[0]
        assert "sk-abcdefghijklmnopqrstuvwxyz0123" not in ev.text

    def test_rejection_reason_masked(self, engine):
        session = engine.debug_start("bug")
        hyp = engine.debug_hypothesis(session.id, "rate limit")
        engine.debug_reject(
            hyp.id, "counter-example: card 4111-1111-1111-1111 bypassed"
        )
        fetched = engine.get_debug_session(session.id)
        rejected = fetched.hypotheses[0]
        assert "4111-1111-1111-1111" not in (rejected.rejection_reason or "")

    def test_conclusion_masked(self, engine):
        session = engine.debug_start("bug")
        engine.debug_hypothesis(session.id, "hypothesis")
        concluded = engine.debug_conclude(
            session.id, conclusion="fixed after rotating 123-45-6789 token"
        )
        assert "123-45-6789" not in (concluded.conclusion or "")

    def test_debug_service_without_quality_gate_is_pass_through(self, storage):
        # Bare-storage construction keeps working — no gate means no masking,
        # which is the pragmatic choice (tests and SDK-internal uses).
        svc = DebugService(storage)
        s = svc.start_session("keeps original: sk-abcdefghijklmnopqrstuvwxyz0123")
        assert "sk-abcdefghijklmnopqrstuvwxyz0123" in s.bug_description
