from __future__ import annotations

from datetime import datetime, timedelta

from engram.jobs.service import JobRunnerService


def test_job_runner_retries_and_dead_letters(storage):
    runner = JobRunnerService(storage)

    job = runner.enqueue("rebuild_references", {"source_kind": "note"}, max_attempts=2)
    failed = runner.mark_failed(job.id, "boom")
    assert failed.status == "queued"

    dead = runner.mark_failed(job.id, "boom-again")
    assert dead.status == "dead_letter"
    assert dead.last_error == "boom-again"


def test_job_runner_leases_queued_jobs(storage):
    runner = JobRunnerService(storage)
    runner.enqueue("index_source", {"source_kind": "note", "source_id": "n1"})
    runner.enqueue("index_source", {"source_kind": "note", "source_id": "n2"})

    leased = runner.lease(limit=1, lease_owner="pytest")

    assert len(leased) == 1
    assert leased[0].status == "running"
    assert leased[0].lease_owner == "pytest"


def test_job_runner_does_not_lease_future_jobs(storage):
    runner = JobRunnerService(storage)
    job = runner.enqueue("index_source", {"source_kind": "note", "source_id": "future"})
    job.available_at = datetime.now() + timedelta(minutes=5)
    storage.update_job(job)

    leased = runner.lease(limit=5, lease_owner="pytest")

    assert leased == []
