"""Tests for Diagnostics / HealthReport (Feature 2).

Covers docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §2.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import Tier
from engram.models.fact import Fact, FactStatus
from engram.models.health import HealthStatus, LoopKind, LoopSeverity
from engram.models.source import Source, SourceType
from engram.quality.diagnostics import Diagnostics


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


def _make_fact(
    engine: MemoryEngine,
    entity_name: str,
    text: str,
    *,
    source_author: str = "",
    source_type: SourceType = SourceType.USER_INPUT,
    source_channel: str = "cli",
    confidence: float = 0.5,
    created_at: datetime = None,
    status: FactStatus = FactStatus.UNVERIFIED,
) -> Fact:
    entity = engine.storage.get_entity_by_name(entity_name)
    assert entity is not None, f"Create entity '{entity_name}' first"
    fact = Fact(
        entity_id=entity.id,
        subject=entity_name,
        predicate="attribute",
        object=text,
        raw_text=text,
        source=Source(
            type=source_type,
            author=source_author,
            channel=source_channel,
            confidence=1.0,
        ),
        confidence=confidence,
        status=status,
    )
    engine.storage.add_fact(fact)
    if created_at is not None:
        # Override created_at after insert since add_fact resets it.
        engine.storage._conn.execute(
            "UPDATE facts SET created_at = ? WHERE id = ?",
            (created_at.isoformat(), fact.id),
        )
        engine.storage._conn.commit()
    return fact


class TestHealthReportEmpty:
    def test_empty_db_gives_perfect_grade(self, engine):
        report = engine.health_report()
        assert report.entity_count == 0
        assert report.fact_count == 0
        assert report.grade == "A"
        assert report.score_value >= 90
        assert report.open_loops == []


class TestGovernanceDiagnostics:
    def test_health_report_flags_governance_backlog(self, engine):
        engine.create_entity("Simon Kim")
        engine.create_entity("S. Kim")
        secondary = engine.get_entity("S. Kim")
        secondary.aliases = ["Simon Kim"]
        engine.storage.update_entity(secondary)
        engine.generate_governance_candidates()

        report = engine.health_report()

        assert any(loop.kind == LoopKind.ENTITY_GOVERNANCE for loop in report.open_loops)


class TestConflictDetection:
    def test_single_pending_conflict_is_warning(self, engine):
        engine.create_entity("Alice")
        engine.storage.add_conflict(
            {
                "id": "conflict-1",
                "conflict_type": "contradiction",
                "suggested_resolution": "supersede",
            }
        )
        report = engine.health_report()
        conflict_metric = next(m for m in report.metrics if m.name == "pending_conflicts")
        assert conflict_metric.value == 1
        assert conflict_metric.status == HealthStatus.WARN

        conflict_loops = report.loops_by_kind(LoopKind.CONFLICT)
        assert len(conflict_loops) == 1
        assert conflict_loops[0].severity == LoopSeverity.WARNING
        assert "resolve conflict-1" in (conflict_loops[0].recommended_action or "")

    def test_many_conflicts_escalate_to_critical(self, engine):
        engine.create_entity("Alice")
        for i in range(5):
            engine.storage.add_conflict(
                {"id": f"c-{i}", "conflict_type": "contradiction"}
            )
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "pending_conflicts")
        assert metric.status == HealthStatus.CRIT
        assert all(
            l.severity == LoopSeverity.CRITICAL
            for l in report.loops_by_kind(LoopKind.CONFLICT)
        )


class TestSourceCoverage:
    def test_fully_attributed_facts_yield_ok(self, engine):
        engine.create_entity("Alice")
        _make_fact(
            engine, "Alice", "fact with source",
            source_author="press", source_channel="news",
        )
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "source_coverage")
        assert metric.value == 100.0
        assert metric.status == HealthStatus.OK
        assert report.loops_by_kind(LoopKind.MISSING_SOURCE) == []

    def test_missing_source_triggers_warn_or_crit(self, engine):
        engine.create_entity("Alice")
        _make_fact(engine, "Alice", "orphan fact", source_channel="cli")
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "source_coverage")
        assert metric.value == 0.0
        assert metric.status == HealthStatus.CRIT
        loops = report.loops_by_kind(LoopKind.MISSING_SOURCE)
        assert len(loops) == 1
        assert loops[0].severity == LoopSeverity.INFO
        assert "orphan fact" in loops[0].title

    def test_web_channel_counts_as_attributed(self, engine):
        engine.create_entity("Alice")
        _make_fact(
            engine, "Alice", "from web", source_channel="web", source_author="",
        )
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "source_coverage")
        assert metric.value == 100.0


class TestStaleFacts:
    def test_old_fact_counted_stale(self, engine):
        engine.create_entity("Alice")
        long_ago = datetime.now() - timedelta(days=200)
        _make_fact(engine, "Alice", "ancient wisdom", created_at=long_ago)

        report = engine.health_report(stale_days=90)
        metric = next(m for m in report.metrics if m.name == "stale_facts_ratio")
        assert metric.value == 100.0
        assert metric.status == HealthStatus.CRIT

        loops = report.loops_by_kind(LoopKind.STALE_FACT)
        assert len(loops) == 1
        assert loops[0].entity_name == "Alice"

    def test_fresh_facts_yield_ok_metric(self, engine):
        engine.create_entity("Alice")
        _make_fact(engine, "Alice", "fresh fact")
        report = engine.health_report(stale_days=90)
        metric = next(m for m in report.metrics if m.name == "stale_facts_ratio")
        assert metric.value == 0.0
        assert metric.status == HealthStatus.OK


class TestOrphanEntities:
    def test_entity_without_facts_is_orphan(self, engine):
        engine.create_entity("Lonely")
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "orphan_entity_ratio")
        assert metric.value == 100.0
        loops = report.loops_by_kind(LoopKind.ORPHAN_ENTITY)
        assert len(loops) == 1
        assert loops[0].entity_name == "Lonely"

    def test_entity_with_current_fact_not_orphan(self, engine):
        engine.create_entity("Busy")
        _make_fact(engine, "Busy", "active fact", source_channel="web")
        report = engine.health_report()
        metric = next(m for m in report.metrics if m.name == "orphan_entity_ratio")
        assert metric.value == 0.0
        assert report.loops_by_kind(LoopKind.ORPHAN_ENTITY) == []


class TestReportRendering:
    def test_grade_reflects_status_mix(self, engine):
        # Pure OK run should be A.
        report = engine.health_report()
        assert report.grade == "A"

        # Introduce a CRIT metric.
        engine.create_entity("Alice")
        _make_fact(engine, "Alice", "sans source", source_channel="cli")
        report2 = engine.health_report()
        assert report2.grade in ("B", "C", "D")

    def test_to_agent_context_mentions_grade_and_counts(self, engine):
        engine.create_entity("Alice")
        text = engine.health_report().to_agent_context()
        assert text.startswith("## Engram Health:")
        assert "Entities: 1" in text
        assert "Open Loops" in text

    def test_to_dict_has_all_fields(self, engine):
        report = engine.health_report()
        d = report.to_dict()
        assert "grade" in d
        assert "metrics" in d
        assert "open_loops" in d
        assert "generated_at" in d

    def test_loop_cap_honoured(self, engine):
        for i in range(5):
            engine.create_entity(f"Orphan_{i}")
        report = engine.health_report(max_open_loops=2)
        assert len(report.open_loops) == 2


class TestDirectDiagnostics:
    def test_diagnostics_works_without_config(self, storage):
        # Diagnostics should build a report from a bare storage instance.
        report = Diagnostics(storage).run()
        assert report.grade in ("A", "B", "C", "D")
        assert report.entity_count == 0


class TestProjectionDrift:
    def test_projection_drift_detects_missing_note_index(self, engine):
        engine.create_entity("Alice")
        note_id, _ = engine.storage.add_note("note-drift", "Alice met the team.")
        report = engine.health_report()

        drift_loops = report.loops_by_kind(LoopKind.PROJECTION_DRIFT)
        assert any("Missing references for note" in loop.title for loop in drift_loops)

    def test_health_report_flags_failed_jobs(self, engine):
        job = engine.enqueue_job("rebuild_projections", {}, max_attempts=1)
        engine.job_runner.mark_failed(job.id, "boom")

        report = engine.health_report()

        drift_loops = report.loops_by_kind(LoopKind.PROJECTION_DRIFT)
        assert any("Failed job" in loop.title for loop in drift_loops)


class TestFreshnessDiagnostics:
    def test_health_report_flags_verification_backlog(self, engine):
        engine.create_entity("Alice")
        result = engine.add_fact("Alice", "Alice leads platform work", predicate="role")
        fact = engine.storage.get_facts(engine.get_entity("Alice").id)[0]
        engine.freshness_service.ensure_fact_request(
            fact,
            reason="manual",
            requested_by="test",
        )

        report = engine.health_report()

        assert any(
            metric.name == "verification_backlog_count"
            for metric in report.metrics
        )
        assert any(
            loop.kind.value == "verification_backlog"
            for loop in report.open_loops
        )

    def test_health_report_flags_stale_decision(self, engine):
        session = engine.start_session("codex")
        engine.end_session(session.session_id, summary="We decided to ship the fix.")
        decision = engine.list_decisions()[0]
        engine.storage.update_decision_freshness(
            decision.id,
            verification_status="stale",
            verification_due_at="2000-01-01T00:00:00",
        )

        report = engine.health_report()

        assert any(metric.name == "stale_decision_count" for metric in report.metrics)
        assert any(loop.kind.value == "stale_decision" for loop in report.open_loops)

    def test_health_report_flags_due_decision_even_if_status_not_stale(self, engine):
        session = engine.start_session("codex")
        engine.end_session(session.session_id, summary="We decided to ship the fix.")
        decision = engine.list_decisions()[0]
        engine.storage.update_decision_freshness(
            decision.id,
            verification_status="verified",
            verification_due_at="2000-01-01T00:00:00",
        )

        report = engine.health_report()

        assert any(metric.name == "stale_decision_count" for metric in report.metrics)
        assert any(loop.kind.value == "stale_decision" for loop in report.open_loops)
