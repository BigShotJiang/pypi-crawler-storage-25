"""Tests for MemoryType classifier + DecayPolicy + engine.reclassify_facts.

Covers Feature 4 in
docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.fact import Fact, FactStatus
from engram.models.memory_type import (
    MemoryType,
    classify_fact,
    classify_predicate,
)
from engram.models.source import Source, SourceType
from engram.quality.decay import find_stale_facts
from engram.quality.decay_policy import DEFAULT_HALF_LIVES, DecayPolicy


class TestClassifyPredicate:
    @pytest.mark.parametrize(
        "predicate,expected",
        [
            ("role", MemoryType.IDENTITY),
            ("affiliation", MemoryType.IDENTITY),
            ("current_role", MemoryType.IDENTITY),
            ("employer", MemoryType.IDENTITY),
            ("prefers", MemoryType.PREFERENCE),
            ("favorite_color", MemoryType.PREFERENCE),
            ("hobby", MemoryType.PREFERENCE),
            ("currently_doing", MemoryType.TRANSIENT),
            ("today_mood", MemoryType.TRANSIENT),
            ("attended_conference", MemoryType.EPISODIC),
            ("", MemoryType.EPISODIC),
        ],
    )
    def test_keyword_routing(self, predicate, expected):
        assert classify_predicate(predicate) == expected

    def test_text_fallback_for_transient(self):
        assert classify_fact("", "Currently in a meeting") == MemoryType.TRANSIENT

    def test_text_fallback_respects_predicate_first(self):
        # Predicate wins over text.
        assert (
            classify_fact("role", "currently away")
            == MemoryType.IDENTITY
        )


class TestDecayPolicy:
    def test_defaults_order_identity_slowest(self):
        policy = DecayPolicy()
        assert policy.half_life(MemoryType.IDENTITY) > policy.half_life(
            MemoryType.PREFERENCE
        )
        assert policy.half_life(MemoryType.PREFERENCE) > policy.half_life(
            MemoryType.EPISODIC
        )
        assert policy.half_life(MemoryType.EPISODIC) > policy.half_life(
            MemoryType.TRANSIENT
        )

    def test_decay_factor_monotonic(self):
        policy = DecayPolicy()
        now = datetime(2026, 4, 15)
        fact_new = Fact(raw_text="x", memory_type=MemoryType.EPISODIC, created_at=now)
        fact_old = Fact(
            raw_text="x",
            memory_type=MemoryType.EPISODIC,
            created_at=now - timedelta(days=90),
        )
        assert policy.decay_factor(fact_new, now) > policy.decay_factor(fact_old, now)
        # Half-life of EPISODIC is 30 days, so 90 days ≈ (1/2)**3 = 0.125.
        assert policy.decay_factor(fact_old, now) == pytest.approx(0.125, abs=0.05)

    def test_transient_stale_before_identity(self):
        policy = DecayPolicy()
        now = datetime(2026, 4, 15)
        age = timedelta(days=60)
        transient = Fact(
            raw_text="t",
            memory_type=MemoryType.TRANSIENT,
            created_at=now - age,
        )
        identity = Fact(
            raw_text="i",
            memory_type=MemoryType.IDENTITY,
            created_at=now - age,
        )
        assert policy.is_stale(transient, now) is True
        assert policy.is_stale(identity, now) is False

    def test_effective_confidence_respects_decay(self):
        policy = DecayPolicy()
        now = datetime(2026, 4, 15)
        f = Fact(
            raw_text="x",
            memory_type=MemoryType.EPISODIC,
            confidence=0.8,
            created_at=now - timedelta(days=30),
        )
        # Half-life 30 → decay factor 0.5 → effective 0.4.
        assert policy.effective_confidence(f, now) == pytest.approx(0.4, abs=0.02)

    def test_overrides_apply(self):
        policy = DecayPolicy(half_lives={MemoryType.EPISODIC: 1.0})
        now = datetime(2026, 4, 15)
        fact = Fact(
            raw_text="x",
            memory_type=MemoryType.EPISODIC,
            created_at=now - timedelta(days=2),
        )
        # 2 days ≈ 2 half-lives → factor ≈ 0.25.
        assert policy.decay_factor(fact, now) == pytest.approx(0.25, abs=0.01)


class TestFindStaleFactsWithPolicy:
    def test_policy_routes_per_type(self):
        now = datetime(2026, 4, 15)
        policy = DecayPolicy()
        old_transient = Fact(
            memory_type=MemoryType.TRANSIENT,
            raw_text="gone",
            created_at=now - timedelta(days=30),
        )
        old_identity = Fact(
            memory_type=MemoryType.IDENTITY,
            raw_text="still solid",
            created_at=now - timedelta(days=30),
        )
        stale = find_stale_facts(
            [old_transient, old_identity], reference_time=now, policy=policy
        )
        assert old_transient in stale
        assert old_identity not in stale

    def test_flat_days_fallback(self):
        now = datetime(2026, 4, 15)
        fact = Fact(
            memory_type=MemoryType.IDENTITY,
            raw_text="x",
            created_at=now - timedelta(days=200),
        )
        # Without a policy, flat `days=90` treats any 200-day-old fact as stale
        # regardless of memory type.
        stale = find_stale_facts([fact], days=90, reference_time=now)
        assert fact in stale


class TestEnginePersistsMemoryType:
    @pytest.fixture
    def engine(self, tmp_path):
        config = EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
            min_confidence=0.0,
        )
        eng = MemoryEngine(config)
        yield eng
        eng.close()

    def test_store_round_trip_preserves_type(self, engine):
        engine.create_entity("Alice Smith")
        source = Source(type=SourceType.USER_INPUT, author="press")
        engine.add_fact("Alice Smith", "CEO", predicate="role", source=source)

        facts = engine.get_facts("Alice Smith")
        assert facts
        assert facts[0].memory_type == MemoryType.IDENTITY

    def test_store_defaults_to_episodic_for_generic_predicate(self, engine):
        engine.create_entity("Alice Smith")
        source = Source(type=SourceType.USER_INPUT, author="press")
        engine.add_fact("Alice Smith", "went to Paris", predicate="attribute", source=source)
        facts = engine.get_facts("Alice Smith")
        assert facts[0].memory_type == MemoryType.EPISODIC


class TestReclassifyFacts:
    @pytest.fixture
    def engine(self, tmp_path):
        config = EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
            min_confidence=0.0,
        )
        eng = MemoryEngine(config)
        yield eng
        eng.close()

    def _seed_fact(self, engine, entity_name, predicate, obj, memory_type):
        entity = engine.storage.get_entity_by_name(entity_name)
        fact = Fact(
            entity_id=entity.id,
            subject=entity_name,
            predicate=predicate,
            object=obj,
            raw_text=f"{entity_name} {predicate} {obj}",
            source=Source(type=SourceType.USER_INPUT, channel="test"),
            memory_type=memory_type,
            status=FactStatus.UNVERIFIED,
            confidence=0.5,
        )
        engine.storage.add_fact(fact)
        return fact

    def test_reclassify_changes_default_types(self, engine):
        engine.create_entity("Alice Smith")
        # Seed a fact stored as EPISODIC but whose predicate should be IDENTITY.
        self._seed_fact(engine, "Alice Smith", "role", "CEO", MemoryType.EPISODIC)

        stats = engine.reclassify_facts()
        assert stats["updated"] == 1
        assert stats["by_type"].get(MemoryType.IDENTITY.value) == 1

        fact = engine.get_facts("Alice Smith")[0]
        assert fact.memory_type == MemoryType.IDENTITY

    def test_reclassify_preserves_custom_types_by_default(self, engine):
        engine.create_entity("Alice Smith")
        # User already tagged this fact as PREFERENCE manually.
        self._seed_fact(
            engine, "Alice Smith", "role", "CEO", MemoryType.PREFERENCE
        )

        stats = engine.reclassify_facts()
        assert stats["updated"] == 0

        stats2 = engine.reclassify_facts(only_default=False)
        assert stats2["updated"] == 1

    def test_reclassify_scoped_to_entity(self, engine):
        engine.create_entity("Alice Smith")
        engine.create_entity("Bob Wright")
        self._seed_fact(engine, "Alice Smith", "role", "CEO", MemoryType.EPISODIC)
        self._seed_fact(engine, "Bob Wright", "role", "CTO", MemoryType.EPISODIC)

        stats = engine.reclassify_facts(entity_name="Alice Smith")
        assert stats["scanned"] == 1
        assert stats["updated"] == 1

    def test_reclassify_missing_entity_returns_zero(self, engine):
        stats = engine.reclassify_facts(entity_name="Nobody")
        assert stats == {"scanned": 0, "updated": 0, "by_type": {}}
