"""Tests for conflict detection."""

import pytest

from engram.models.entity import Entity, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.source import Source, SourceType
from engram.quality.conflict import ConflictDetector
from engram.storage.sqlite_store import SQLiteStorage


@pytest.fixture
def conflict_setup(tmp_path):
    """Set up storage with entity and existing fact, return detector."""
    db_path = tmp_path / "conflict_test.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()

    entity = Entity(name="Simon Kim", entity_type="person", tier=Tier.CORE)
    storage.create_entity(entity)

    existing = Fact(
        entity_id=entity.id,
        subject="Simon Kim",
        predicate="role",
        object="CEO",
        raw_text="Simon Kim is the CEO",
        source=Source(type=SourceType.DOCUMENT, confidence=0.8),
        confidence=0.8,
    )
    storage.add_fact(existing)

    detector = ConflictDetector(storage)
    yield detector, storage, entity, existing
    storage.close()


class TestConflictDetection:
    def test_no_conflict_different_predicate(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="location",
            object="Seoul",
            raw_text="Simon Kim is in Seoul",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 0

    def test_no_conflict_same_value(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CEO",
            raw_text="Simon Kim is the CEO",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 0

    def test_conflict_different_value(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CTO",
            raw_text="Simon Kim is the CTO",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1
        assert conflicts[0].conflict_type == "value_change"

    def test_conflict_case_insensitive_predicate(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="Role",  # different case
            object="CTO",
            raw_text="Simon Kim is the CTO",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1

    def test_conflict_case_insensitive_object_no_conflict(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="ceo",  # same value different case
            raw_text="Simon Kim is CEO",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 0

    def test_resolution_supersede_high_trust(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        # Existing: DOCUMENT(0.85) × 0.8 = trust 0.68
        # New: DIRECT_SPEECH(0.95) × 1.0 = trust 0.95
        # Diff = 0.27, which is < 0.3 threshold → manual_review
        # For supersede, need trust diff > 0.3
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="Founder",
            raw_text="Simon Kim is now Founder",
            source=Source(type=SourceType.DIRECT_SPEECH, confidence=1.0),
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1
        # Trust diff = 0.27, not enough for auto-supersede
        assert conflicts[0].suggested_resolution == "manual_review"

    def test_resolution_supersede_very_high_trust_diff(self, tmp_path):
        # Fresh setup with very low trust existing fact
        db_path = tmp_path / "supersede_test.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()
        entity = Entity(name="Test Person", entity_type="person", tier=Tier.CORE)
        storage.create_entity(entity)

        # Low trust existing fact: AGENT_INFERENCE(0.4) × 0.2 = trust 0.08
        existing = Fact(
            entity_id=entity.id,
            subject="Test Person",
            predicate="role",
            object="Intern",
            raw_text="Test Person is an intern",
            source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.2),
            confidence=0.08,
        )
        storage.add_fact(existing)

        detector = ConflictDetector(storage)

        # High trust new fact: DIRECT_SPEECH(0.95) × 1.0 = trust 0.95
        # Diff = 0.95 - 0.08 = 0.87 > 0.3
        new_fact = Fact(
            entity_id=entity.id,
            subject="Test Person",
            predicate="role",
            object="CEO",
            raw_text="Test Person is now CEO",
            source=Source(type=SourceType.DIRECT_SPEECH, confidence=1.0),
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1
        assert conflicts[0].suggested_resolution == "supersede"
        storage.close()

    def test_resolution_keep_old_low_trust(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="Intern",
            raw_text="Simon Kim is an intern",
            source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.3),
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1
        assert conflicts[0].suggested_resolution == "keep_old"

    def test_resolution_manual_review_similar_trust(self, conflict_setup):
        detector, _, entity, _ = conflict_setup
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CTO",
            raw_text="Simon Kim is the CTO",
            source=Source(type=SourceType.DOCUMENT, confidence=0.85),
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 1
        assert conflicts[0].suggested_resolution == "manual_review"

    def test_no_conflict_with_expired_fact(self, conflict_setup):
        detector, storage, entity, existing = conflict_setup
        # Expire the existing fact
        existing.status = FactStatus.EXPIRED
        existing.superseded_by = "some-id"
        storage.update_fact(existing)

        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CTO",
            raw_text="Simon Kim is the CTO",
        )
        conflicts = detector.find_conflicts(new_fact)
        assert len(conflicts) == 0
