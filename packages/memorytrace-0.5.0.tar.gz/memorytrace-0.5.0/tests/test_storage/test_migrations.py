"""Schema migration tests — ensures existing v1 databases upgrade safely."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from engram.storage.migrations import (
    CURRENT_VERSION,
    _column_exists,
    _migrate_v1_to_v2,
    get_schema_version,
    migrate,
)
from engram.storage.sqlite_store import SQLiteStorage


def _create_v1_facts_table(conn: sqlite3.Connection) -> None:
    """Recreate the pre-migration facts schema — no memory_type column."""
    conn.executescript(
        """
        CREATE TABLE _meta (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE entities (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            entity_type TEXT NOT NULL DEFAULT 'person',
            tier TEXT NOT NULL DEFAULT 'recall',
            summary TEXT DEFAULT '',
            aliases TEXT DEFAULT '[]',
            state TEXT DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT
        );
        CREATE TABLE facts (
            id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            subject TEXT NOT NULL,
            predicate TEXT NOT NULL,
            object TEXT NOT NULL,
            raw_text TEXT NOT NULL,
            source_type TEXT NOT NULL,
            source_author TEXT DEFAULT '',
            source_channel TEXT DEFAULT '',
            source_timestamp TEXT,
            source_url TEXT,
            source_session_id TEXT,
            source_confidence REAL DEFAULT 1.0,
            confidence REAL NOT NULL DEFAULT 0.5,
            status TEXT NOT NULL DEFAULT 'unverified',
            valid_from TEXT,
            valid_to TEXT,
            superseded_by TEXT,
            created_at TEXT NOT NULL
        );
        INSERT INTO _meta (key, value) VALUES ('schema_version', '1');
        """
    )
    conn.commit()


class TestMigrationV1ToV2:
    def test_detects_missing_column_and_adds_it(self, tmp_path):
        db = tmp_path / "migration_v1.db"
        conn = sqlite3.connect(str(db))
        _create_v1_facts_table(conn)
        assert _column_exists(conn, "facts", "memory_type") is False
        assert get_schema_version(conn) == 1

        migrate(conn)

        assert _column_exists(conn, "facts", "memory_type") is True
        assert get_schema_version(conn) == CURRENT_VERSION

    def test_is_idempotent(self, tmp_path):
        db = tmp_path / "migration_v1.db"
        conn = sqlite3.connect(str(db))
        _create_v1_facts_table(conn)

        migrate(conn)
        version_after_first = get_schema_version(conn)
        _migrate_v1_to_v2(conn)  # should be a no-op thanks to _column_exists
        migrate(conn)  # should early-return

        assert get_schema_version(conn) == CURRENT_VERSION == version_after_first

    def test_existing_facts_default_to_episodic(self, tmp_path):
        db = tmp_path / "migration_v1.db"
        conn = sqlite3.connect(str(db))
        _create_v1_facts_table(conn)
        conn.execute(
            """INSERT INTO entities (id, name, entity_type, tier,
                created_at, updated_at)
               VALUES ('e1', 'Alice', 'person', 'recall', '2024-01-01T00:00:00', '2024-01-01T00:00:00')"""
        )
        conn.execute(
            """INSERT INTO facts
                (id, entity_id, subject, predicate, object, raw_text,
                 source_type, confidence, status, created_at)
                VALUES ('f1', 'e1', 'Alice', 'role', 'CEO', 'Alice is CEO',
                        'user_input', 0.9, 'unverified', '2024-01-01T00:00:00')"""
        )
        conn.commit()

        migrate(conn)

        row = conn.execute(
            "SELECT memory_type FROM facts WHERE id = 'f1'"
        ).fetchone()
        assert row[0] == "episodic"


class TestFullStackMigration:
    def test_storage_initialize_migrates_legacy_db(self, tmp_path: Path):
        # Pre-create a legacy DB at the storage's path.
        db_path = tmp_path / "memory.db"
        conn = sqlite3.connect(str(db_path))
        _create_v1_facts_table(conn)
        conn.close()

        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            # Fresh initialize should have run the migration.
            raw = storage._conn.execute(
                "PRAGMA table_info(facts)"
            ).fetchall()
            cols = {row[1] for row in raw}
            assert "memory_type" in cols
            assert get_schema_version(storage._conn) == CURRENT_VERSION
        finally:
            storage.close()

    def test_storage_initialize_creates_projection_tables(self, tmp_path: Path):
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            tables = {
                row[0]
                for row in storage._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            }
            assert "reference_edges" in tables
            assert "decisions" in tables
            assert "maintenance_runs" in tables
            assert "maintenance_run_items" in tables
            assert get_schema_version(storage._conn) == CURRENT_VERSION
        finally:
            storage.close()

    def test_storage_initialize_creates_scope_and_job_tables(self, tmp_path: Path):
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            tables = {
                row[0]
                for row in storage._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            }
            assert "memory_scopes" in tables
            assert "jobs" in tables
            assert get_schema_version(storage._conn) == CURRENT_VERSION
        finally:
            storage.close()

    @pytest.mark.parametrize(
        ("table", "column"),
        [
            ("facts", "scope_id"),
            ("notes", "scope_id"),
            ("sessions", "scope_id"),
            ("session_events", "scope_id"),
            ("debug_sessions", "scope_id"),
            ("debug_hypotheses", "scope_id"),
            ("debug_evidence", "scope_id"),
        ],
    )
    def test_storage_initialize_adds_scope_columns(
        self,
        tmp_path: Path,
        table: str,
        column: str,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            cols = {
                row[1]
                for row in storage._conn.execute(
                    f"PRAGMA table_info({table})"
                ).fetchall()
            }
            assert column in cols
        finally:
            storage.close()

    def test_storage_initialize_adds_fact_freshness_columns(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            cols = {
                row[1]
                for row in storage._conn.execute(
                    "PRAGMA table_info(facts)"
                ).fetchall()
            }
            assert "verification_status" in cols
            assert "last_verified_at" in cols
            assert "verification_due_at" in cols
        finally:
            storage.close()

    def test_storage_initialize_adds_fact_applicability_columns(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            cols = {
                row[1]
                for row in storage._conn.execute(
                    "PRAGMA table_info(facts)"
                ).fetchall()
            }
            assert "applies_if" in cols
            assert "except_if" in cols
        finally:
            storage.close()

    def test_storage_initialize_adds_decision_freshness_and_request_table(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            decision_cols = {
                row[1]
                for row in storage._conn.execute(
                    "PRAGMA table_info(decisions)"
                ).fetchall()
            }
            tables = {
                row[0]
                for row in storage._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            }
            assert "verification_status" in decision_cols
            assert "last_verified_at" in decision_cols
            assert "verification_due_at" in decision_cols
            assert "verification_requests" in tables
        finally:
            storage.close()

    def test_storage_initialize_adds_governance_candidates_table(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            tables = {
                row[0]
                for row in storage._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            }
            assert "governance_candidates" in tables
        finally:
            storage.close()

    def test_storage_initialize_allows_split_governance_candidates(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            storage._conn.execute(
                """
                INSERT INTO governance_candidates (
                    id, candidate_type, status, entity_id, related_entity_id,
                    proposed_alias, score, fingerprint, rationale, details,
                    created_at, updated_at
                ) VALUES (?, 'split', 'open', ?, NULL, NULL, 0.8, ?, '', '{}', ?, ?)
                """,
                (
                    "candidate-1",
                    "entity-1",
                    "fingerprint-1",
                    "2026-04-16T00:00:00",
                    "2026-04-16T00:00:00",
                ),
            )
            storage._conn.commit()
            count = storage._conn.execute(
                "SELECT COUNT(*) FROM governance_candidates WHERE candidate_type = 'split'"
            ).fetchone()[0]
            assert count == 1
        finally:
            storage.close()

    def test_storage_initialize_adds_retention_policy_table(
        self,
        tmp_path: Path,
    ) -> None:
        db_path = tmp_path / "memory.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()

        try:
            tables = {
                row[0]
                for row in storage._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            }
            assert "retention_policies" in tables
            assert get_schema_version(storage._conn) == CURRENT_VERSION
        finally:
            storage.close()
