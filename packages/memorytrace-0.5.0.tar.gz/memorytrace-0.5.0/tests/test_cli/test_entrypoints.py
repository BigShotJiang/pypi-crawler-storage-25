"""Tests for source-checkout entrypoints."""

from __future__ import annotations

import runpy
from pathlib import Path


def test_module_entrypoint_delegates_to_simple_cli(monkeypatch):
    called = []

    def fake_cli_entry():
        called.append("module")

    monkeypatch.setattr("engram.cli.simple.cli_entry", fake_cli_entry)

    runpy.run_module("engram.__main__", run_name="__main__")

    assert called == ["module"]


def test_mem_wrapper_delegates_to_simple_cli(monkeypatch):
    called = []

    def fake_cli_entry():
        called.append("mem")

    monkeypatch.setattr("engram.cli.simple.cli_entry", fake_cli_entry)

    script_path = Path(__file__).resolve().parents[2] / "mem"
    runpy.run_path(str(script_path), run_name="__main__")

    assert called == ["mem"]
