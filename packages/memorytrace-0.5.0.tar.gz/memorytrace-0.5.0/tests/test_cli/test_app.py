"""Tests for CLI app — invokes CLI via main() with argv."""

import json
import sqlite3
import pytest
from io import StringIO
from unittest.mock import patch

from engram.cli.app import _build_parser, main
from engram.models.session import Session
from engram.storage.sqlite_store import SQLiteStorage
from tests.fixtures.explanation_scenarios import assert_explanation_bundle


@pytest.fixture(autouse=True)
def use_tmp_db(tmp_path, monkeypatch):
    """Override default DB path for all CLI tests."""
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("HOME", str(tmp_path))
    return db_path


class TestCLIInit:
    def test_init(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "init"])
        assert code == 0

    def test_init_quiet(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "--quiet", "init"])
        assert code == 0


class TestCLIStore:
    def test_store_text(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        assert code == 0

    def test_store_json_output(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        capsys.readouterr()  # clear init output
        main(["--db", use_tmp_db, "--json", "store", "Simon Kim is the CEO."])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "entities_created" in data

    def test_store_empty_returns_0(self, use_tmp_db):
        main(["--db", use_tmp_db, "--quiet", "init"])
        code = main(["--db", use_tmp_db, "store", "hello world"])
        assert code == 0


class TestCLISearch:
    def test_search(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        code = main(["--db", use_tmp_db, "search", "CEO"])
        assert code == 0

    def test_search_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        capsys.readouterr()  # clear previous output
        main(["--db", use_tmp_db, "--json", "search", "CEO"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "hits" in data
        assert_explanation_bundle(data["hits"][0]["explanation"])

    def test_context_search_cli_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "store", "Alice owns the release checklist."])
        capsys.readouterr()

        code = main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "context-search",
                "release checklist",
                "--goal",
                "task_handoff",
            ]
        )

        payload = json.loads(capsys.readouterr().out)
        assert code == 0
        assert payload["goal"] == "task_handoff"
        assert "base_result" in payload

    def test_query_plan_cli_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        capsys.readouterr()

        code = main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "query-plan",
                "release owner and rollback approver",
            ]
        )

        payload = json.loads(capsys.readouterr().out)
        assert code == 0
        assert payload["should_expand"] is True
        assert payload["fragments"] == ["release owner", "rollback approver"]

    def test_search_no_results(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "search", "nonexistent"])
        assert code == 0


class TestCLIEntity:
    def test_create_and_get(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith", "--type", "person"])
        code = main(["--db", use_tmp_db, "get", "Alice Smith"])
        assert code == 0
        captured = capsys.readouterr()
        assert "Alice Smith" in captured.out

    def test_get_not_found(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "get", "Nobody"])
        assert code == 1

    def test_list(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith"])
        main(["--db", use_tmp_db, "create", "Bob Corp", "--type", "organization"])
        main(["--db", use_tmp_db, "list"])
        captured = capsys.readouterr()
        assert "Alice Smith" in captured.out
        assert "Bob Corp" in captured.out

    def test_list_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "list"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert len(data) >= 1

    def test_list_filter_type(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice", "--type", "person"])
        main(["--db", use_tmp_db, "create", "Corp", "--type", "organization"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "list", "--type", "organization"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert all(e["type"] == "organization" for e in data)


class TestCLIFact:
    def test_add_fact(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        code = main(["--db", use_tmp_db, "add-fact", "Simon Kim", "CEO of Hashed"])
        assert code == 0

    def test_add_fact_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "add-fact", "Simon Kim", "CEO of Hashed"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "action" in data

    def test_add_fact_with_applicability(self, use_tmp_db):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        code = main(
            [
                "--db",
                use_tmp_db,
                "add-fact",
                "Alice",
                "Use the handoff template",
                "--applies-if",
                "handoff",
                "--except-if",
                "incident",
            ]
        )

        assert code == 0

        storage = SQLiteStorage(use_tmp_db)
        storage.initialize()
        try:
            entity = storage.get_entity_by_name("Alice")
            facts = storage.get_facts(entity.id)
            assert facts[0].applicability.applies_if == ["handoff"]
            assert facts[0].applicability.except_if == ["incident"]
        finally:
            storage.close()


class TestCLIHealth:
    def test_health(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "health"])
        assert code == 0

    def test_health_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "health"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "entity_count" in data


class TestCLIMaintenance:
    def test_scope_create_and_list(self, use_tmp_db, capsys):
        assert main(["--db", use_tmp_db, "--json", "scope-create", "project", "alpha"]) == 0
        created = json.loads(capsys.readouterr().out)
        assert created["kind"] == "project"

        assert main(["--db", use_tmp_db, "--json", "scope-list"]) == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload
        assert payload[0]["kind"] == "project"

    def test_jobs_run_executes_queued_jobs(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "--json", "scope-create", "project", "alpha"])
        scope = json.loads(capsys.readouterr().out)
        main(
            [
                "--db",
                use_tmp_db,
                "store",
                "Alice met the design team.",
                "--scope-id",
                scope["id"],
            ]
        )
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "jobs-run", "--limit", "10"])
        payload = json.loads(capsys.readouterr().out)
        assert payload["completed"] >= 1

        main(["--db", use_tmp_db, "--json", "jobs-list", "--status", "completed"])
        jobs = json.loads(capsys.readouterr().out)
        assert jobs

    def test_export(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Test Entity"])
        code = main(["--db", use_tmp_db, "export"])
        assert code == 0

    def test_reindex(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "reindex"])
        assert code == 0

    def test_maintenance_run_and_list(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Lonely"])
        code = main(["--db", use_tmp_db, "maintenance-run"])
        assert code == 0
        code = main(["--db", use_tmp_db, "maintenance-list"])
        assert code == 0

    def test_backlinks_and_rebuild(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "store", "Alice met the design team."])
        assert main(["--db", use_tmp_db, "backlinks", "Alice"]) == 0
        assert main(["--db", use_tmp_db, "rebuild-projections"]) == 0

    def test_backlinks_json_includes_explanation(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        main(["--db", use_tmp_db, "store", "Alice met the design team."])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "backlinks", "Alice"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data
        assert_explanation_bundle(data[0]["explanation"])

    def test_decision_show_json_includes_explanation(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "--json", "debug-start", "deployment issue"])
        session = json.loads(capsys.readouterr().out)
        main(
            [
                "--db",
                use_tmp_db,
                "debug-conclude",
                session["id"],
                "We decided to ship the fix.",
            ]
        )
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "decisions"])
        decisions = json.loads(capsys.readouterr().out)

        assert decisions
        main(["--db", use_tmp_db, "--json", "decision-show", decisions[0]["id"]])
        payload = json.loads(capsys.readouterr().out)
        assert_explanation_bundle(payload["explanation"])

    def test_decision_show_text_uses_view_wrapper(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "--json", "debug-start", "deployment issue"])
        session = json.loads(capsys.readouterr().out)
        main(
            [
                "--db",
                use_tmp_db,
                "debug-conclude",
                session["id"],
                "We decided to ship the fix.",
            ]
        )
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "decisions"])
        decisions = json.loads(capsys.readouterr().out)

        code = main(["--db", use_tmp_db, "decision-show", decisions[0]["id"]])
        captured = capsys.readouterr()

        assert code == 0
        assert "ship the fix" in captured.out

    def test_maintenance_show_text_uses_view_wrapper(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Lonely"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "maintenance-run"])
        run = json.loads(capsys.readouterr().out)

        code = main(["--db", use_tmp_db, "maintenance-show", run["id"]])
        captured = capsys.readouterr()

        assert code == 0
        assert "grade=" in captured.out

    def test_maintenance_show_json_includes_explanation(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Lonely"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "maintenance-run"])
        run = json.loads(capsys.readouterr().out)
        main(["--db", use_tmp_db, "--json", "maintenance-show", run["id"]])
        payload = json.loads(capsys.readouterr().out)
        assert payload["items"]
        assert "items" not in payload["run"]
        assert_explanation_bundle(payload["items"][0]["explanation"])

    def test_verification_request_and_list(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        main(["--db", use_tmp_db, "add-fact", "Alice", "Alice leads platform work"])
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            fact_id = conn.execute(
                "SELECT id FROM facts ORDER BY created_at DESC LIMIT 1"
            ).fetchone()[0]

        main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "verification-request",
                "fact",
                fact_id,
            ]
        )
        request = json.loads(capsys.readouterr().out)
        assert request["target_kind"] == "fact"

        main(["--db", use_tmp_db, "--json", "verification-list"])
        rows = json.loads(capsys.readouterr().out)
        assert rows

    def test_verification_resolve_updates_status(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        main(["--db", use_tmp_db, "add-fact", "Alice", "Alice leads platform work"])
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            fact_id = conn.execute(
                "SELECT id FROM facts ORDER BY created_at DESC LIMIT 1"
            ).fetchone()[0]

        main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "verification-request",
                "fact",
                fact_id,
            ]
        )
        request = json.loads(capsys.readouterr().out)

        main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "verification-resolve",
                request["id"],
                "verified",
            ]
        )
        resolved = json.loads(capsys.readouterr().out)
        assert resolved["status"] == "resolved"

    def test_governance_run_and_resolve(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        main(["--db", use_tmp_db, "create", "S. Kim"])
        with sqlite3.connect(use_tmp_db) as conn:
            conn.execute(
                "UPDATE entities SET aliases = ? WHERE name = ?",
                (json.dumps(["Simon Kim"]), "S. Kim"),
            )
            conn.commit()
        capsys.readouterr()

        main(["--db", use_tmp_db, "--json", "governance-run"])
        rows = json.loads(capsys.readouterr().out)
        assert rows
        candidate_id = rows[0]["id"]

        main(["--db", use_tmp_db, "--json", "governance-resolve", candidate_id, "approve"])
        resolved = json.loads(capsys.readouterr().out)
        assert resolved["status"] == "applied"

    def test_governance_list_accepts_split_filter(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Jordan Lee"])
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            entity_id = conn.execute(
                "SELECT id FROM entities WHERE name = ?",
                ("Jordan Lee",),
            ).fetchone()[0]
            conn.execute(
                """
                INSERT INTO governance_candidates (
                    id, candidate_type, status, entity_id, related_entity_id, proposed_alias,
                    score, fingerprint, rationale, details, created_at, updated_at
                ) VALUES (?, 'split', 'open', ?, NULL, NULL, 0.8, 'split-1', 'needs review', '{}', ?, ?)
                """,
                (
                    "candidate-1",
                    entity_id,
                    "2026-04-16T00:00:00",
                    "2026-04-16T00:00:00",
                ),
            )
            conn.commit()

        main(["--db", use_tmp_db, "--json", "governance-list", "--type", "split"])
        rows = json.loads(capsys.readouterr().out)
        assert rows and rows[0]["candidate_type"] == "split"

    def test_retention_set_and_list(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            entity_id = conn.execute(
                "SELECT id FROM entities WHERE name = ?",
                ("Alice",),
            ).fetchone()[0]

        main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "retention-set",
                "entity",
                entity_id,
                "pin",
                "--reason",
                "keep",
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        assert payload["policy_type"] == "pin"

        main(
            [
                "--db",
                use_tmp_db,
                "--json",
                "retention-list",
                "--target-kind",
                "entity",
            ]
        )
        rows = json.loads(capsys.readouterr().out)
        assert rows

    def test_recommendations_command_returns_stale_decision(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "--json", "debug-start", "deployment issue"])
        session = json.loads(capsys.readouterr().out)
        main(
            [
                "--db",
                use_tmp_db,
                "debug-conclude",
                session["id"],
                "We decided to ship the fix.",
            ]
        )
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            conn.execute(
                """
                UPDATE decisions
                SET verification_status = 'stale',
                    verification_due_at = '2000-01-01T00:00:00'
                """
            )
            conn.commit()

        main(["--db", use_tmp_db, "--json", "recommendations"])
        rows = json.loads(capsys.readouterr().out)
        assert any(row["kind"] == "stale_decision" for row in rows)

    def test_recommendations_command_accepts_merge_kind(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        main(["--db", use_tmp_db, "create", "S. Kim"])
        with sqlite3.connect(use_tmp_db) as conn:
            conn.execute(
                "UPDATE entities SET aliases = ? WHERE name = ?",
                (json.dumps(["Simon Kim"]), "S. Kim"),
            )
            conn.commit()
        capsys.readouterr()

        main(["--db", use_tmp_db, "--quiet", "governance-run"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "recommendations", "--kind", "merge_recommendation"])
        rows = json.loads(capsys.readouterr().out)
        assert rows and rows[0]["kind"] == "merge_recommendation"

    def test_recommendations_command_accepts_follow_up_task_kind(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice"])
        main(["--db", use_tmp_db, "add-fact", "Alice", "Alice owns launch", "--predicate", "role"])
        capsys.readouterr()

        with sqlite3.connect(use_tmp_db) as conn:
            fact_id = conn.execute("SELECT id FROM facts LIMIT 1").fetchone()[0]
        main(["--db", use_tmp_db, "--quiet", "verification-request", "fact", fact_id, "--reason", "manual"])
        capsys.readouterr()
        with sqlite3.connect(use_tmp_db) as conn:
            conn.execute(
                "UPDATE verification_requests SET requested_at = ?",
                ("2000-01-01T00:00:00",),
            )
            conn.commit()

        main(["--db", use_tmp_db, "--json", "recommendations", "--kind", "follow_up_task"])
        rows = json.loads(capsys.readouterr().out)
        assert rows and rows[0]["kind"] == "follow_up_task"


def test_context_pack_cli_json(use_tmp_db, capsys):
    storage = SQLiteStorage(use_tmp_db)
    storage.initialize()
    session = Session(
        agent_id="planner",
        summary="Planner assembled the first draft.",
    )
    storage.save_session(session)
    storage.close()
    capsys.readouterr()

    code = main(["--db", use_tmp_db, "--json", "context-pack", session.session_id])
    payload = json.loads(capsys.readouterr().out)

    assert code == 0
    assert payload["source_session_id"] == session.session_id


def test_operations_review_cli_json(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])

    code = main(["--db", use_tmp_db, "--json", "operations-review"])
    payload = json.loads(capsys.readouterr().out)

    assert code == 0
    assert "summary_lines" in payload
    assert "maintenance_run" in payload


def test_cli_rejects_forbidden_legacy_aliases():
    parser = _build_parser()
    for argv in (
        ["agentic-search", "alice"],
        ["agent-inject", "session-1"],
        ["agent-handoff", "session-1", "writer"],
        ["dream"],
    ):
        with pytest.raises(SystemExit):
            parser.parse_args(argv)


class TestCLIServe:
    def test_serve_rejects_unsupported_transport(self):
        parser = _build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["serve", "--transport", "sse"])


class TestCLINoCommand:
    def test_no_command_shows_help(self, capsys):
        code = main([])
        assert code == 0

    def test_exit_code_on_error(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "get", "Nonexistent"])
        assert code == 1
