from __future__ import annotations

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.fact import Fact, FactStatus
from engram.models.relation import Relation
from engram.models.scope import ScopeSelection
from engram.models.source import Source, SourceType


@pytest.fixture
def engine(tmp_path):
    eng = MemoryEngine(
        EngramConfig(
            base_dir=tmp_path / "engram",
            enable_markdown_export=False,
        )
    )
    yield eng
    eng.close()


def test_search_context_returns_base_hits_and_related_entities(engine):
    alice = engine.create_entity("Alice")
    bob = engine.create_entity("Bob")
    engine.add_fact("Alice", "Alice leads the Alpha roadmap.", predicate="role")
    engine.add_fact("Bob", "Bob coordinates release reviews with Alice.", predicate="role")
    engine.storage.add_relation(
        Relation(
            from_entity_id=alice.id,
            to_entity_id=bob.id,
            relation_type="WORKS_WITH",
        )
    )

    result = engine.search_context("Alice", goal="task_handoff", max_results=1)

    assert result.base_result.hits
    assert any(row.name == "Bob" for row in result.related_entities)
    assert "expanded relation neighbors" in result.expansion_notes


def test_search_context_preserves_freshness_penalty(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns the migration plan", predicate="role")
    fact = engine.get_facts("Alice")[0]
    engine.storage.update_fact_freshness(
        fact.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    result = engine.search_context("migration plan", goal="task_handoff")

    assert result.base_result.hits
    assert any(
        factor.name == "freshness_penalty"
        for factor in result.base_result.hits[0].ranking_factors
    )


def test_search_context_with_zero_hops_returns_base_only(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns the release checklist.", predicate="role")

    result = engine.search_context("release checklist", expand_hops=0)

    assert result.base_result.hits
    assert result.related_entities == []
    assert result.related_decisions == []


def test_search_context_filters_related_decisions_by_scope(engine):
    alpha = engine.create_scope("project", "alpha")
    beta = engine.create_scope("project", "beta")
    alice = engine.create_entity("Alice")

    alpha_session = engine.start_session("planner", scope_id=alpha.id)
    engine.add_fact(
        "Alice",
        "Alice owns the Alpha release checklist.",
        predicate="role",
        session_id=alpha_session.session_id,
    )
    engine.end_session(alpha_session.session_id, summary="Alpha plan settled.")

    beta_session = engine.start_session("writer", scope_id=beta.id)
    engine.end_session(beta_session.session_id, summary="Beta plan settled.")
    engine.storage.replace_decisions(
        "session",
        beta_session.session_id,
        [
            DecisionRecord(
                title="Beta decision",
                summary="Only valid for Beta scope.",
                status=DecisionStatus.ACTIVE,
                confidence=0.8,
                source_kind="session",
                source_id=beta_session.session_id,
                fingerprint="beta-decision",
                entity_id=alice.id,
                session_id=beta_session.session_id,
            )
        ],
    )

    result = engine.search_context(
        "Alpha release checklist",
        goal="task_handoff",
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=False,
        ),
    )

    assert result.base_result.hits
    assert all(row.decision.title != "Beta decision" for row in result.related_decisions)


def test_search_context_filters_related_entities_by_scope(engine):
    alpha = engine.create_scope("project", "alpha")
    beta = engine.create_scope("project", "beta")
    alice = engine.create_entity("Alice")
    bob = engine.create_entity("Bob")

    engine.storage.add_fact(
        Fact(
            entity_id=alice.id,
            subject="Alice",
            predicate="role",
            object="Alpha roadmap lead",
            raw_text="Alice leads the Alpha roadmap.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            scope_id=alpha.id,
            confidence=0.9,
            status=FactStatus.UNVERIFIED,
        )
    )
    engine.storage.add_fact(
        Fact(
            entity_id=bob.id,
            subject="Bob",
            predicate="role",
            object="Beta roadmap lead",
            raw_text="Bob leads the Beta roadmap.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            scope_id=beta.id,
            confidence=0.9,
            status=FactStatus.UNVERIFIED,
        )
    )
    engine.storage.add_relation(
        Relation(
            from_entity_id=alice.id,
            to_entity_id=bob.id,
            relation_type="WORKS_WITH",
        )
    )

    result = engine.search_context(
        "Alpha roadmap",
        goal="task_handoff",
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=False,
        ),
    )

    assert result.base_result.hits
    assert all(row.name != "Bob" for row in result.related_entities)


def test_search_context_include_global_keeps_global_related_entities(engine):
    alpha = engine.create_scope("project", "alpha")
    alice = engine.create_entity("Alice")
    bob = engine.create_entity("Bob")

    engine.storage.add_fact(
        Fact(
            entity_id=alice.id,
            subject="Alice",
            predicate="role",
            object="Alpha roadmap lead",
            raw_text="Alice leads the Alpha roadmap.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            scope_id=alpha.id,
            confidence=0.9,
            status=FactStatus.UNVERIFIED,
        )
    )
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.storage.add_relation(
        Relation(
            from_entity_id=alice.id,
            to_entity_id=bob.id,
            relation_type="WORKS_WITH",
        )
    )

    result = engine.search_context(
        "Alpha roadmap",
        goal="task_handoff",
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )

    assert result.base_result.hits
    assert any(row.name == "Bob" for row in result.related_entities)


def test_search_context_uses_batched_scope_lookup_for_related_entities(engine, monkeypatch):
    alpha = engine.create_scope("project", "alpha")
    alice = engine.create_entity("Alice")
    bob = engine.create_entity("Bob")

    engine.storage.add_fact(
        Fact(
            entity_id=alice.id,
            subject="Alice",
            predicate="role",
            object="Alpha roadmap lead",
            raw_text="Alice leads the Alpha roadmap.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            scope_id=alpha.id,
            confidence=0.9,
            status=FactStatus.UNVERIFIED,
        )
    )
    engine.add_fact("Bob", "Bob is the default release approver.", predicate="role")
    engine.storage.add_relation(
        Relation(
            from_entity_id=alice.id,
            to_entity_id=bob.id,
            relation_type="WORKS_WITH",
        )
    )

    calls: list[list[str]] = []

    def fake_scope_map(entity_ids: list[str]) -> dict[str, set[str | None]]:
        calls.append(list(entity_ids))
        return {bob.id: {None}}

    def fail_get_current_facts(_entity_id: str):
        raise AssertionError("search_context should use batched scope lookup")

    monkeypatch.setattr(engine.storage, "list_current_fact_scopes", fake_scope_map, raising=False)
    monkeypatch.setattr(engine.storage, "get_current_facts", fail_get_current_facts)

    result = engine.search_context(
        "Alpha roadmap",
        goal="task_handoff",
        scope_selection=ScopeSelection(
            primary_scope_id=alpha.id,
            include_ancestors=False,
            include_global=True,
        ),
    )

    assert any(row.name == "Bob" for row in result.related_entities)
    assert calls


def test_search_context_can_apply_query_plan(engine):
    engine.create_entity("Alice")
    engine.create_entity("Bob")
    engine.add_fact("Alice", "Alice is the release owner.", predicate="role")
    engine.add_fact("Bob", "Bob is the rollback approver.", predicate="role")

    result = engine.search_context(
        "release owner and rollback approver",
        goal="task_handoff",
        plan_query=True,
        max_results=2,
    )

    assert result.query_plan is not None
    assert result.query_plan.fragments == ["release owner", "rollback approver"]
    names = {hit.entity.name for hit in result.base_result.hits}
    assert {"Alice", "Bob"}.issubset(names)
