from __future__ import annotations

from engram.models.search import RetrievalContext
from engram.search.reranker import RerankingService
from tests.fixtures.retrieval_scenarios import make_search_result
from tests.fixtures.explanation_scenarios import assert_explanation_bundle


def test_reranker_boosts_active_entity(storage):
    result = make_search_result()
    alice_id = result.hits[1].entity.id
    reranked = RerankingService(storage).rerank(
        result,
        RetrievalContext(
            goal="meeting_prep",
            active_entity_ids=[alice_id],
            include_explanations=True,
        ),
    )

    assert reranked.hits[0].entity.id == alice_id
    assert reranked.hits[0].ranking_factors[0].name == "active_entity"


def test_search_result_serializes_provenance(storage):
    result = make_search_result()
    reranked = RerankingService(storage).rerank(
        result,
        RetrievalContext(goal="meeting_prep", include_explanations=True),
    )
    payload = reranked.to_dict()

    assert "base_score" in payload["hits"][0]
    assert "ranking_factors" in payload["hits"][0]
    assert "provenance" in payload["hits"][0]
    assert_explanation_bundle(payload["hits"][0]["explanation"])
