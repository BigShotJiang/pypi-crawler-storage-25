"""Tests for semantic search — module import and basic structure."""

import pytest


class TestSemanticSearchImport:
    def test_module_importable(self):
        """Semantic search module should import without numpy installed."""
        try:
            from engram.search.semantic import SemanticSearch
            assert True  # numpy is available
        except ImportError:
            assert True  # numpy not available, graceful error


class TestHybridSearchImport:
    def test_module_importable(self):
        from engram.search.hybrid import HybridSearch
        assert HybridSearch is not None
