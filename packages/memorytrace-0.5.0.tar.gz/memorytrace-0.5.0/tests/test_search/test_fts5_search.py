"""Tests for FTS5 BM25 search."""

import pytest
from pathlib import Path

from engram.storage.sqlite_store import SQLiteStorage
from engram.search.fts5_search import FTS5Search
from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact
from engram.models.source import Source, SourceType
from engram.models.search import SearchOptions, SearchResult


@pytest.fixture
def search_db(tmp_path: Path):
    """Set up storage with test data and return search engine."""
    db_path = tmp_path / "search_test.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()

    # Create entities
    e1 = Entity(
        name="Simon Kim",
        entity_type="person",
        state=EntityState(role="CEO", affiliation="Hashed"),
        tier=Tier.CORE,
        summary="Blockchain investor and CEO of Hashed.",
    )
    e2 = Entity(
        name="Vitalik Buterin",
        entity_type="person",
        state=EntityState(role="Co-founder", affiliation="Ethereum Foundation"),
        tier=Tier.CORE,
        summary="Creator of Ethereum.",
    )
    e3 = Entity(
        name="Hashed",
        entity_type="organization",
        tier=Tier.RECALL,
        summary="Korean blockchain investment firm.",
    )
    e4 = Entity(
        name="김민수",
        entity_type="person",
        state=EntityState(role="CTO"),
        tier=Tier.RECALL,
        summary="소프트웨어 엔지니어이자 CTO.",
    )
    e5 = Entity(
        name="Archived Project",
        entity_type="project",
        tier=Tier.ARCHIVAL,
        summary="An old archived project.",
    )

    for e in [e1, e2, e3, e4, e5]:
        storage.create_entity(e)

    # Add facts
    facts = [
        Fact(
            entity_id=e1.id, subject="Simon Kim", predicate="role",
            object="CEO", raw_text="Simon Kim is the CEO of Hashed",
            source=Source(type=SourceType.DOCUMENT, confidence=0.9),
            confidence=0.85,
        ),
        Fact(
            entity_id=e1.id, subject="Simon Kim", predicate="investment",
            object="$200M fund", raw_text="Simon Kim launched a $200M crypto fund",
            source=Source(type=SourceType.DOCUMENT, confidence=0.8),
            confidence=0.75,
        ),
        Fact(
            entity_id=e2.id, subject="Vitalik Buterin", predicate="role",
            object="Co-founder", raw_text="Vitalik Buterin co-founded Ethereum",
            source=Source(type=SourceType.DOCUMENT, confidence=0.95),
            confidence=0.95,
        ),
        Fact(
            entity_id=e3.id, subject="Hashed", predicate="type",
            object="investment firm", raw_text="Hashed is a blockchain investment firm based in Seoul",
            source=Source(type=SourceType.WEB, confidence=0.7),
            confidence=0.6,
        ),
        Fact(
            entity_id=e4.id, subject="김민수", predicate="role",
            object="CTO", raw_text="김민수는 회사의 CTO로 근무하고 있다",
            source=Source(type=SourceType.USER_INPUT, confidence=0.9),
            confidence=0.8,
        ),
    ]
    for f in facts:
        storage.add_fact(f)

    storage.close()

    search = FTS5Search(db_path)
    yield search, db_path, {"e1": e1, "e2": e2, "e3": e3, "e4": e4, "e5": e5}
    search.close()


class TestBasicSearch:
    def test_search_by_name(self, search_db):
        search, _, entities = search_db
        result = search.search(SearchOptions(query="Simon Kim"))
        assert result.total_count >= 1
        names = [h.entity.name for h in result.hits]
        assert "Simon Kim" in names

    def test_search_by_fact_content(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="crypto fund"))
        assert result.total_count >= 1
        names = [h.entity.name for h in result.hits]
        assert "Simon Kim" in names

    def test_search_by_role(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="CEO"))
        assert result.total_count >= 1
        names = [h.entity.name for h in result.hits]
        assert "Simon Kim" in names

    def test_search_by_organization(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="Hashed"))
        assert result.total_count >= 1

    def test_search_no_results(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="xyznonexistent"))
        assert result.total_count == 0
        assert result.hits == []

    def test_search_empty_query(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query=""))
        assert result.total_count == 0

    def test_search_returns_relevance_scores(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="Simon Kim CEO Hashed"))
        assert result.total_count >= 1
        assert all(h.relevance_score > 0 for h in result.hits)

    def test_search_timing(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="blockchain"))
        assert result.search_time_ms >= 0


class TestKoreanSearch:
    def test_search_korean_name(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="김민수"))
        assert result.total_count >= 1
        names = [h.entity.name for h in result.hits]
        assert "김민수" in names

    def test_search_korean_content(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="CTO"))
        assert result.total_count >= 1


class TestSearchFilters:
    def test_filter_by_entity_type(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="Hashed",
            entity_types=["organization"],
        ))
        assert all(h.entity.entity_type == "organization" for h in result.hits)

    def test_filter_excludes_archived_by_default(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="archived project"))
        names = [h.entity.name for h in result.hits]
        assert "Archived Project" not in names

    def test_filter_includes_archived(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="archived project",
            include_archived=True,
        ))
        names = [h.entity.name for h in result.hits]
        assert "Archived Project" in names

    def test_filter_by_tier(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="CEO",
            tiers=["core"],
        ))
        assert all(h.entity.tier == Tier.CORE for h in result.hits)

    def test_max_results(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="CEO",
            max_results=1,
        ))
        assert len(result.hits) <= 1

    def test_min_confidence_filters_facts(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="Simon Kim",
            min_confidence=0.9,
        ))
        if result.hits:
            for hit in result.hits:
                for fact in hit.facts:
                    assert fact.confidence >= 0.9


class TestTokenBudget:
    def test_token_budget_limits_results(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(
            query="CEO blockchain",
            max_tokens=50,  # Very small budget
        ))
        assert result.total_tokens <= 100  # Some tolerance


class TestFTS5SpecialChars:
    def test_query_with_quotes(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query='"Simon" Kim'))
        # Should not crash
        assert isinstance(result, SearchResult)

    def test_query_with_asterisk(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="Simon*"))
        assert isinstance(result, SearchResult)

    def test_query_with_parentheses(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="(CEO OR CTO)"))
        assert isinstance(result, SearchResult)

    def test_query_with_near(self, search_db):
        search, _, _ = search_db
        result = search.search(SearchOptions(query="NEAR Simon Kim"))
        assert isinstance(result, SearchResult)
