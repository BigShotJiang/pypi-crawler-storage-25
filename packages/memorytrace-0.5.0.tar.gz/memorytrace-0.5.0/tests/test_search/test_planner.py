from __future__ import annotations


def test_query_planner_extracts_fragments_from_compound_query():
    from engram.search.planner import QueryPlanner

    plan = QueryPlanner().build("release owner and rollback approver")

    assert plan.original_query == "release owner and rollback approver"
    assert plan.fragments == ["release owner", "rollback approver"]
    assert plan.should_expand is True
