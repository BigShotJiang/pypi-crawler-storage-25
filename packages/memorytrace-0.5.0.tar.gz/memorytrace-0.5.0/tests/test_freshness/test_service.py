from __future__ import annotations

from datetime import datetime

import pytest

from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.memory_type import MemoryType
from engram.models.source import Source, SourceType


def _freshness_imports():
    try:
        from engram.freshness.service import FreshnessService
        from engram.models.verification import (
            VerificationResolution,
            VerificationRequestStatus,
            VerificationStatus,
        )
    except ModuleNotFoundError as exc:
        pytest.fail(str(exc))
    return (
        FreshnessService,
        VerificationResolution,
        VerificationRequestStatus,
        VerificationStatus,
    )


def test_ensure_fact_request_dedupes_open_request(storage):
    (
        FreshnessService,
        _VerificationResolution,
        _VerificationRequestStatus,
        VerificationStatus,
    ) = _freshness_imports()
    entity = storage.create_entity(Entity(name="Alice"))
    fact = storage.add_fact(
        Fact(
            entity_id=entity.id,
            subject="Alice",
            predicate="role",
            object="platform lead",
            raw_text="Alice leads platform work.",
            source=Source(type=SourceType.USER_INPUT),
            memory_type=MemoryType.EPISODIC,
        )
    )
    service = FreshnessService(storage)

    first = service.ensure_fact_request(
        fact,
        reason="verify_on_read",
        requested_by="test",
    )
    second = service.ensure_fact_request(
        fact,
        reason="verify_on_read",
        requested_by="test",
    )

    assert first is not None
    assert second is not None
    assert first.id == second.id
    refreshed = storage.get_facts(entity.id)[0]
    assert refreshed.verification_status is VerificationStatus.PENDING


def test_resolve_request_marks_decision_verified(storage):
    (
        FreshnessService,
        VerificationResolution,
        VerificationRequestStatus,
        VerificationStatus,
    ) = _freshness_imports()
    decision = DecisionRecord(
        title="Ship the fix",
        summary="We decided to ship the fix.",
        status=DecisionStatus.ACTIVE,
        confidence=0.9,
        source_kind="session",
        source_id="session-1",
        fingerprint="decision-1",
        created_at=datetime.now(),
        indexed_at=datetime.now(),
    )
    storage.replace_decisions("session", "session-1", [decision])
    stored = storage.get_decision(decision.id)
    service = FreshnessService(storage)
    request = service.ensure_decision_request(
        stored,
        reason="decision_read",
        requested_by="test",
    )

    resolved = service.resolve_request(request.id, VerificationResolution.VERIFIED)
    refreshed = storage.get_decision(decision.id)

    assert resolved.status is VerificationRequestStatus.RESOLVED
    assert refreshed.verification_status is VerificationStatus.VERIFIED
    assert refreshed.verification_due_at is not None
