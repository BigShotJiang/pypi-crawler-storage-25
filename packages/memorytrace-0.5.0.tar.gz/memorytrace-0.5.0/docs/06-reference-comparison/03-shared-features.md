﻿# 공유 기능 비교

양쪽 모두 존재하는 9개 핵심 기능의 구현 차이를 비교한다.

---

## 1. 엔티티 관리

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 저장 | Markdown 파일 (entities/, live-notes/) | SQLite `entities` 테이블 |
| 상태 관리 | 마크다운 섹션 파싱 | 구조화된 `EntityState` (role, affiliation, location, email, custom) |
| 계층(Tier) | core/recall/archival | 동일 — `Tier` enum |
| 별칭 | 없음 | `aliases` 리스트 + `get_entity_by_name()` 별칭 해소 |
| 병합 | 없음 | `merge_entities()` — 팩트/관계/별칭/상태 전체 이전 |
| 압축 | 없음 | `compact_entity()` — predicate별 최선 팩트만 보존 |
| 브리프 | `brief()` — 마크다운 요약 | `EntityBrief` — 상위 팩트, 관련 엔티티, 최근 노트, 세션, 미해결 충돌 합성 |
| 접근 추적 | 없음 | `touch()` 접근 카운트 + 타임스탬프 |

**판정**: **대폭 개선** — SQL 쿼리가 파일 스캔 대체, 엔티티 병합/압축은 진정한 운영 기능.

---

## 2. NER/추출

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 구조 | `core.py` 내 인라인 | 모듈형 (`extraction/regex_extractor.py`, `ner/english.py`, `ner/korean.py`, `ner/cjk.py`) |
| 영어 NER | Title Case 이름 (2-3 단어) | 동일 + 조직 접미사, 블록리스트 확장 |
| 한국어 NER | 한글 2-4자 + 성씨 시작 | **문맥 기반**: 이름+존칭, 소개 패턴, 2음절+조사, 3음절+상위10 성씨. 90+ 성씨 |
| CJK NER | 중국 100성씨, 일본 85성씨 | 동일 접근 |
| 불용어 | `stopwords.json` (813항목) | 언어별 모듈 내 `frozenset`/`tuple` |
| 팩트 추출 | `extract_facts_registry()` | `regex_extractor.py` — 팩트 + 관계 통합 추출 |
| LLM 추출 | 없음 | `llm_extractor.py` — 선택적 플러그인 |
| 인터페이스 | 없음 | `Extractor` Protocol — 백엔드 교체 가능 |

**판정**: **개선** — 특히 한국어 NER이 "모든 2-4자 한글"에서 "문맥 증거 기반"으로 정밀도 대폭 향상.

---

## 3. 충돌 검출

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 탐지 | 동일 엔티티의 모순 팩트 | 동일 entity + predicate + 다른 object |
| 해소 전략 | newest, confidence, keep-both, prompt | accept_new, keep_old, merge (양쪽 보존) |
| 자동 해소 | 없음 | 신뢰도 차이 기반 자동 해소 (임계값 설정 가능) |
| 영속화 | 메모리 내 + `CONFLICTS.md` | SQLite `conflicts` 테이블 |
| 변증법 합성 | 모순을 합성된 관점으로 통합 | **없음** — merge는 양쪽을 그대로 보존 |
| 대화형 해소 | `prompt` 전략 (사용자에게 질문) | **없음** |

**판정**: **동등~개선** — 자동 해소와 영속화는 개선. 변증법 합성과 대화형 해소는 상실.

---

## 4. 디버그 서비스

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 워크플로우 | OBSERVE → HYPOTHESIZE → EXPERIMENT → CONCLUDE | 동일 (start → hypothesis → evidence → conclude) |
| 저장 | `debug/` 디렉토리에 Markdown 파일 | SQLite 3개 테이블 (`debug_sessions`, `debug_hypotheses`, `debug_evidence`) |
| 가설 상태 | open/confirmed/rejected | 동일 + abandoned |
| 증거 분류 | 없음 (텍스트만) | supports/contradicts/neutral |
| PII 마스킹 | 없음 | 모든 텍스트 필드에 PII 마스킹 |
| 검색 | `search_rejected_hypotheses()` | `search_hypotheses()` (전체 검색 가능) |
| 2-fail 경고 | 2번 기각 후 자동 경고 | 없음 (별도 구현 필요 시 추가 가능) |

**판정**: **개선** — SQL 영속화, PII 마스킹, 증거 분류, 검색 가능한 가설 이력.

---

## 5. 스냅샷 / 시간여행

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 스냅샷 생성 | 매니페스트 (해시, 크기, 요약, 섹션, 팩트, 링크) | `sqlite3.Connection.backup()` + gzip 압축 |
| 스냅샷 내 검색 | 없음 (매니페스트만) | 스냅샷 DB를 읽기 전용 열어 FTS5 검색 |
| 시간여행 | `time_travel(query, date)` — 임의 시점 쿼리 | `search_at(snapshot_id, query)` — 스냅샷 ID 필요 |
| 엔티티 이력 | `snapshot_entity(name)` — 스냅샷 간 엔티티 추적 | `get_entity_at(snapshot_id, name)` |
| 스냅샷 비교 | `snapshot_diff()` | `diff(a_id, b_id)` — 엔티티/팩트/노트 delta |
| 보안 | 없음 | `0o600` 파일 권한, 경로 순회 공격 방지 |

**판정**: **개선** — 실제 DB 백업, 스냅샷 내 FTS5 검색, 보안 강화. 다만 임의 시점 쿼리 대신 명시적 스냅샷 ID가 필요하여 워크플로우가 약간 무거움.

---

## 6. 세션 / 작업 메모리

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 세션 관리 | JSONL 이벤트 로그 | `SessionManager` — 시작/종료, 엔티티 접근/수정 추적, 이벤트 로깅 |
| 작업 메모리 | 채널/태스크/에이전트별 컨텍스트 | `WorkingMemory` — 활성 엔티티(최대 50), 최근 쿼리(최대 20), 인메모리 |
| 채널 컨텍스트 | `channel_save/load/update()` 영속 | **없음** — WorkingMemory는 세션 종료 시 소멸 |
| 태스크 관리 | `task_start/update/complete/delegate()` | **없음** (별도 태스크 서비스 없음) |
| 에이전트 핸드오프 | `agent_handoff()` — 에이전트 간 메모리 이전 | **없음** |
| 컨텍스트 캐리오버 | 이전 1개 세션 | 최근 5개 세션 엔티티 접근 이력 집계 |
| PII 마스킹 | 없음 | 세션 이벤트에 PII 마스킹 |
| 스코프 | 없음 | `scope_id` 기반 네임스페이스 격리 |

**판정**: **단일 에이전트는 개선** — 풍부한 컨텍스트 캐리오버, PII 마스킹, 스코프. **멀티 에이전트는 후퇴** — 핸드오프와 채널 영속 컨텍스트 누락.

---

## 7. 의사결정 추적

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 추출 | `distill_decisions()` — 키워드 스캔 | `DecisionService` — 노트/세션/디버그 결론 스캔 |
| 키워드 | 영어만 ("decided to", "we will", ...) | 이중언어 — 영어 + 한국어 ("결정", "하기로", "채택", "보류") |
| 상태 | 없음 | ACTIVE / DRAFT (보류/draft/consider 키워드 기반) |
| 영속화 | `decisions/` 디렉토리 Markdown | SQLite `decisions` 테이블 + SHA-256 핑거프린트 |
| 엔티티 링크 | 없음 | `ReferenceService.match_entity_ids()` 자동 링크 |
| 드리프트 감지 | 없음 | `projection_drift()` — 인덱싱 안 된 의사결정 소스 식별 |
| 검증 | 없음 | 신선도 서비스 연계 (`verification_status`, `verification_due_at`) |

**판정**: **대폭 개선** — 영속화, 이중언어, 엔티티 링크, 드리프트 감지, 검증 연계.

---

## 8. 헬스/진단

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 메트릭 수 | 5개 assertion | 8개 메트릭 |
| 메트릭 목록 | (비공개 5개 체크) | 미해결 충돌, 소스 커버리지, 노후 팩트 비율, 검증 백로그, 노후 의사결정, 거버넌스 백로그, 고아 엔티티, 프로젝션 드리프트 |
| 등급 | 알파벳 (A/B/C/D) | 가중 복합 점수 + 알파벳 (A/B/C/D) |
| 실행 가능한 항목 | 없음 | `OpenLoop` — 종류, 심각도, 제목, 상세, 대상 ID, 권장 CLI 명령 |
| 출력 | 터미널 텍스트 | `HealthReport.to_agent_context()` — 에이전트 소비용 Markdown |

**판정**: **대폭 개선** — 8개 메트릭, 실행 가능한 OpenLoop, 에이전트 소비용 출력.

---

## 9. 메모리 타입

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| 타입 수 | 8종 | 4종 |
| 타입 목록 | identity, belief, preference, relationship, skill, episodic, routine, transient | IDENTITY, PREFERENCE, EPISODIC, TRANSIENT |
| 분류 방식 | `classify_memory_type()` | `classify_predicate()`, `classify_fact()` — 키워드 기반 |
| 감쇠 연동 | 타입별 차등 감쇠 (상수) | 타입별 지수 감쇠 (반감기: IDENTITY 365일, PREFERENCE 180일, EPISODIC 30일, TRANSIENT 7일) |
| 재분류 | 없음 | `reclassify_facts()` — 소급 재분류 |

**판정**: **의도적 트레이드오프** — "4개 버킷으로 'identity는 잊지 말고 / 어제 기분은 빨리 폐기'를 표현하기에 충분. LLM 없이 분류 문제를 만들지 않는다." ?? ??의 8종은 라벨만 존재하고 차등 행동을 구동하지 않았으나, Engram의 4종은 각각 감쇠율을 직접 결정한다.

