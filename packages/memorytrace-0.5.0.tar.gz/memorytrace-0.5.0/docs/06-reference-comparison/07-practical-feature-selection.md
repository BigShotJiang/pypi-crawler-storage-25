﻿# ?? ?? 기능 중 Engram에 실질적으로 필요한 것만 다시 추린 분석

이 문서는 기존 비교 문서의 범위를 더 좁혀, ?? ?? 기능 중에서 지금 Engram에 실제로 도움이 되는 것만 다시 추린 결론 문서다.
비교 자체보다 중요한 질문은 "무엇을 더 붙일까"가 아니라 "Engram의 현재 구조를 더 강하게 만드는 기능이 무엇인가"다.

## 판단 기준

아래 세 기준을 동시에 만족하는 기능만 채택 대상으로 본다.

1. Engram의 핵심 루프를 직접 강화하는가
   저장, 검색, 검증, 핸드오프, 운영 자동화 중 하나를 실제로 개선해야 한다.
2. 기존 Engram 구조를 재사용할 수 있는가
   `search`, `references`, `scopes`, `freshness`, `governance`, `sessions` 위에 얹을 수 있어야 한다.
3. 새로운 진실 저장소를 또 만들지 않는가
   별도 JSON 저장소나 별도 위키 규약처럼 현재 SQLite 중심 구조와 충돌하는 기능은 피한다.

## 결론 요약

| ?? ?? 기능 | 판단 | 이유 |
|---|---|---|
| `agentic_search()` | 채택 | Engram의 가장 큰 남은 갭이다. 저장보다 "필요한 맥락을 맞게 꺼내는 것"이 더 중요하다. |
| `agent_handoff()` / `agent_inject()` | 채택 | 세션과 Working Memory는 있지만 교차 에이전트 전달 API가 없다. Engram의 agent-first 방향과 맞는다. |
| `dream()` | 축소 채택 | 이미 Engram에는 health, maintenance run, freshness, governance, recommendation이 있다. 새 코어 기능보다 단일 운영 진입점이 필요하다. |
| `channel_save/load/update()` | 비채택 | `scope`, `session`, `source.channel`로 대체 가능하다. 별도 channel JSON 저장소는 중복이다. |
| task continuity / `retro()` | 비채택 | 에이전트 오케스트레이션 계층의 책임에 가깝다. 메모리 엔진 코어 우선순위가 아니다. |
| `suggest_links()` / wiki-link 중심 구조 | 비채택 | Engram은 이미 `ReferenceEdge`와 `Relation` 기반 구조를 갖고 있다. Markdown 위키 링크를 다시 들일 이유가 약하다. |
| 8종 memory type | 비채택 | Engram의 4종 분류는 단순 라벨이 아니라 decay/verification 동작과 연결돼 있다. 지금 더 늘릴 이유가 없다. |
| `health_check()`, snapshot/time-travel | 이미 있음 | Engram에도 이미 대응 기능이 있다. 재구현 대상이 아니다. |

## 1. 반드시 가져와야 할 기능

### 1.1 Goal-aware retrieval로 재해석한 `agentic_search()`

?? ??의 `agentic_search()`는 단순 문자열 검색이 아니라, 질의 맥락에 따라 관련 엔티티와 연결 정보를 더 따라가며 결과를 재정렬하는 쪽에 가깝다.
이 문제는 Engram에도 그대로 남아 있다.

현재 Engram은 이미 좋은 기반을 갖고 있다.

- `engram/engine.py`의 `search()`는 FTS5 검색 이후 scope, retention, freshness penalty, reranking까지 적용한다.
- `engram/references/service.py`는 source 기준 백링크와 projection drift를 제공한다.
- `engram/decisions/service.py`는 note/session/debug source에서 의사결정을 추출한다.
- `engram/scopes/service.py`는 `global / workspace / project / task / agent` 류의 계층 선택을 처리한다.

문제는 이 조각들이 아직 하나의 retrieval 전략으로 묶여 있지 않다는 점이다.
즉, Engram은 "무엇을 저장했는가"는 점점 강해졌지만, "지금 이 질문에 어떤 기억 묶음을 우선 꺼내야 하는가"는 아직 약하다.

그래서 Engram에 필요한 것은 ?? ?? 구현을 그대로 복제하는 것이 아니라, 아래 방향의 goal-aware retrieval이다.

1. 1차 FTS5 검색으로 후보 엔티티와 노트를 뽑는다.
2. 후보 엔티티에서 `Relation`, `ReferenceEdge`, `DecisionRecord`를 따라 1-hop 또는 2-hop 확장을 한다.
3. 현재 `session_id`, `scope_selection`, freshness 상태, open loop를 반영해 재정렬한다.
4. 최종 결과를 "왜 이 결과가 올라왔는지" 설명 가능한 형태로 반환한다.

이 기능은 ?? ?? 비교 문맥을 떠나서도 Engram의 다음 우선순위로 봐야 한다.
이미 로드맵에서도 retrieval, provenance, scoped memory가 다음 단계로 잡혀 있고, 실제 agent memory 품질도 대부분 retrieval에서 결정되기 때문이다.

### 1.2 `agent_handoff()` 대신 Engram식 context pack / handoff

?? ??의 다중 에이전트 기능에서 가장 실용적인 부분은 channel/task/agent JSON 저장소 자체가 아니라, 최종적으로 "다음 에이전트에게 넘길 준비가 된 컨텍스트 블록"을 만들어 준다는 점이다.

현재 Engram은 여기까지는 아직 가지 못했다.

- `engram/session/working_memory.py`의 `WorkingMemory`는 세션 내 단기 메모리다.
- `engram/session/manager.py`는 세션 시작/종료, 이벤트 로그, carryover를 관리한다.
- `engram/session/context.py`의 `build_session_context()`는 같은 agent의 최근 세션을 요약한다.
- 하지만 Working Memory는 세션 종료와 함께 메모리 내에서 사라지고, 다른 agent에게 넘기는 명시적 API는 없다.

이 때문에 Engram에 실질적으로 필요한 기능은 별도 `agents/{id}.json` 저장소가 아니라 아래 두 API다.

1. `context_pack(...)`
   세션 요약, 활성 엔티티, 최근 쿼리, 현재 scope, 관련 decision/open loop를 하나의 주입용 컨텍스트로 만든다.
2. `handoff(from_session_id, to_agent_id, note=None)`
   현재 세션 맥락을 새로운 agent 시작점에 맞게 압축하고, handoff 이벤트를 영속 기록으로 남긴다.

핵심은 "상태를 또 저장하는 것"이 아니라 "이미 저장된 상태를 다음 에이전트용으로 안전하게 재조립하는 것"이다.
이 방향이 Engram의 SQLite 중심 구조, quality gate, auditable session 기록과 가장 잘 맞는다.

## 2. 있으면 좋지만 Engram 방식으로만 가져올 기능

### 2.1 `dream()`의 핵심은 기능 추가가 아니라 운영 진입점 통합이다

?? ??의 `dream()`은 여러 maintenance 성격의 작업을 하나의 이름으로 묶어 호출하는 운영 UX다.
이 점 자체는 실용적이다.
다만 Engram은 이미 내부 부품을 상당수 갖고 있다.

- `health_check()`와 `health_report()`
- `run_maintenance()`와 persisted maintenance run
- `FreshnessService`
- `EntityGovernanceService`
- `RecommendationService`
- `JobRunnerService`

따라서 Engram이 가져와야 할 것은 ?? ??식 dream cycle 로직 전체가 아니다.
필요한 것은 아래 두 가지다.

1. 운영자가 한 번에 실행할 수 있는 단일 orchestration 명령
2. 에이전트가 호출하기 쉬운 MCP/SDK 표면

즉, 이 항목은 "새로운 메모리 기능"이 아니라 "이미 있는 운영 기능을 한 덩어리로 노출하는 작업"으로 처리하는 편이 맞다.

## 3. 지금은 가져오지 말아야 할 기능

### 3.1 별도 channel context 저장소

?? ??의 `channel_save/load/update()`는 메신저 환경에서는 편하다.
하지만 Engram에는 이미 이 기능을 흡수할 수 있는 구조가 있다.

- `Source.channel`
- `Session.scope_id`
- `ScopeService`

여기서 channel을 별도 JSON 저장소로 또 빼면, "동일한 맥락이 scope에도 있고 channel file에도 있는" 이중 진실 문제가 생긴다.
Engram에서는 channel이 필요하면 `channel` kind scope 또는 scope metadata로 녹이는 편이 맞다.

### 3.2 task continuity register와 `retro()`

Task lifecycle과 일일 retrospective는 유용하지만, 메모리 엔진 코어의 최우선 과제는 아니다.
Engram은 이미 recommendation 계층에서 `follow_up_task`를 계산하고 있고, decision/maintenance/governance와 연결된 액션 신호를 만들고 있다.

즉, 지금 필요한 것은 task DB를 하나 더 만드는 일이 아니라:

- retrieval이 더 정확해지는 것
- stale/open loop를 더 잘 드러내는 것
- handoff 시 다음 에이전트가 바로 일할 수 있는 것

이다.

task register와 retro는 상위 orchestration 제품이나 CLI 보조 기능으로 가는 편이 자연스럽다.

### 3.3 `suggest_links()`와 Markdown wiki-link 중심 연결

?? ??에서는 위키 링크가 곧 연결 구조라서 `suggest_links()`가 의미가 있다.
하지만 Engram은 연결의 기준이 이미 다르다.

- `ReferenceService`는 source에서 entity mention을 추출해 `ReferenceEdge`로 저장한다.
- `backlinks()`와 `projection_drift()`가 이미 구조적 품질 확인 도구 역할을 한다.
- `Relation`은 본문 문법이 아니라 명시적 모델이다.

따라서 Engram이 해야 할 일은 wiki-link 제안이 아니라:

- reference edge 누락 탐지 강화
- relation suggestion 또는 graph expansion 품질 개선

이다.

### 3.4 8종 memory type 확장

?? ??는 8종 분류를 두고 있지만, Engram은 4종 분류를 동작 중심으로 사용한다.
이미 decay, freshness, retention 판단이 이 구조 위에 얹혀 있다.

여기서 타입 수를 늘리면 분류 복잡도만 커지고, retrieval/verification 이득은 작을 가능성이 높다.
지금 시점의 Engram에는 "더 많은 타입"보다 "더 좋은 retrieval과 handoff"가 훨씬 중요하다.

## 최종 우선순위

1. Goal-aware retrieval / multi-hop search
2. Context pack / agent handoff
3. 통합 maintenance orchestration + MCP 노출
4. 나머지 ?? ?? 전용 기능은 당분간 비채택

## 한 줄 결론

Engram이 ?? ??에서 지금 당장 배워야 할 것은 "기능 수"가 아니라 두 가지다.
첫째는 더 똑똑한 retrieval이고, 둘째는 더 실용적인 handoff다.
그 외 channel JSON, task register, wiki-link 제안 같은 기능은 Engram의 현재 구조를 더 강하게 만들기보다 중복 계층을 늘릴 가능성이 크다.

## 참고 근거

- ?? ?? 공개 문서: [seojoonkim/?? ??](https://github.com/seojoonkim/?? ??)
- Engram 검색/운영 진입점: [engram/engine.py](../../engram/engine.py)
- Engram 세션 단기 메모리: [engram/session/working_memory.py](../../engram/session/working_memory.py)
- Engram 세션 carryover: [engram/session/context.py](../../engram/session/context.py)
- Engram reference/backlink 계층: [engram/references/service.py](../../engram/references/service.py)
- Engram scope 계층: [engram/scopes/service.py](../../engram/scopes/service.py)
- Engram freshness 계층: [engram/freshness/service.py](../../engram/freshness/service.py)
- Engram governance 계층: [engram/governance/service.py](../../engram/governance/service.py)
- Engram maintenance/recommendation 계층: [engram/maintenance/service.py](../../engram/maintenance/service.py), [engram/recommendations/service.py](../../engram/recommendations/service.py)
- Engram MCP 노출 범위: [engram/integrations/mcp_server.py](../../engram/integrations/mcp_server.py)

