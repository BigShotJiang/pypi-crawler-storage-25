﻿# ?? ?? vs Engram 비교 분석

> **원격**: ?? ???? ????? (?? ?? ??)
> **로컬**: Engram (v0.3.1, PyPI: `memorytrace`)
> **분석일**: 2026-04-16

## 프로젝트 개요

| 관점 | ?? ?? | Engram |
|------|----------|--------|
| **한줄 요약** | Zero-dependency compound knowledge system for AI agents | AI 에이전트를 위한 지속적·구조적·신뢰할 수 있는 메모리 시스템 |
| **코어 구조** | 단일 클래스 모놀리스 (`core.py` ~4,362줄) | 모듈형 아키텍처 (models/storage/search/quality/session/cli + 12개 feature service) |
| **저장소** | Plain Markdown 파일 (디렉토리 기반) | SQLite + FTS5 (+ 선택적 Markdown 내보내기) |
| **검색** | difflib + IDF + fuzzy (stdlib) | FTS5 BM25 + Reranker + 선택적 시맨틱 |
| **의존성** | Zero (stdlib only) | Zero core (LLM/semantic은 optional extras) |
| **에이전트 통합** | CLI + Python SDK | MCP 서버 + CLI + Python SDK |
| **출력 방식** | `print()` 직접 출력 | 구조화된 객체 반환 (core에 print 없음) |
| **스키마 관리** | 없음 (파일 기반) | 11단계 마이그레이션 시스템 |
| **언어 지원** | EN/KR/CN/JP NER | EN/KR/CN/JP NER (한국어 문맥 기반으로 개선) |
| **테스트** | 7개 파일 | 30+ 파일, 기능별 디렉토리 분리 |
| **라이선스** | MIT | MIT |

## 디렉토리 구조 비교

### ?? ??

```
src/reference/
├── __init__.py
├── core.py            # ~4,362줄, 전체 로직이 하나의 클래스에 집중
├── cli.py             # ~600줄, argparse CLI 래퍼
├── stopwords.json     # ~813줄 (KR/CN/JP 불용어)
└── templates/
    ├── RESOLVER.md    # MECE 분류 결정 트리
    └── TEMPLATES.md   # 엔티티/회사 페이지 템플릿
```

### Engram

```
engram/
├── models/          # 20개 순수 데이터클래스 (entity, fact, source, relation, session, ...)
├── storage/         # SQLite+FTS5 백엔드 + 마이그레이션 (v1~v11) + Markdown 내보내기
├── search/          # FTS5 BM25 + 시맨틱 + 하이브리드 + 리랭커 + 토크나이저
├── extraction/      # regex NER (EN/KR/CJK) + LLM 추출기
├── quality/         # confidence, conflict, decay, PII, diagnostics, gate
├── session/         # manager, brief, context, working_memory
├── cli/             # app.py, formatters.py, simple.py
├── integrations/    # MCP 서버 + Python SDK
├── safety/          # 경로 안전성 검증
├── debug/           # 가설 기반 디버그 서비스
├── decisions/       # 의사결정 추적 서비스
├── explanations/    # 프로비넌스 추적 빌더
├── intake/          # 단계적 쓰기 파이프라인
├── maintenance/     # 유지보수 실행 기록
├── references/      # 백링크 프로젝션
├── snapshots/       # 시점 백업 + 시간여행 쿼리
├── freshness/       # 신선도 검증 (미커밋)
├── governance/      # 엔티티 거버넌스 (미커밋)
├── jobs/            # 작업 큐 (미커밋)
├── recommendations/ # 추천 서비스 (미커밋)
├── retention/       # 보존 정책 (미커밋)
└── scopes/          # 스코프 메모리 (미커밋)
```

## 문서 구성

| 문서 | 내용 |
|------|------|
| [01-overview.md](./01-overview.md) | 프로젝트 개요 및 구조 비교 (이 문서) |
| [02-architecture-changes.md](./02-architecture-changes.md) | 핵심 아키텍처 변경 분석 (저장소, 모듈화, 검색, 품질 게이트, MCP) |
| [03-shared-features.md](./03-shared-features.md) | 공유 기능 비교 (양쪽 모두 존재하는 기능의 구현 차이) |
| [04-new-features.md](./04-new-features.md) | Engram 신규 기능 유효성 분석 (6개 신규 기능) |
| [05-missing-features.md](./05-missing-features.md) | ?? ??에만 존재하는 기능 (Engram 누락 분석) |
| [06-risks-and-recommendations.md](./06-risks-and-recommendations.md) | 리스크, 개선 권고, 결론 |
| [07-practical-feature-selection.md](./07-practical-feature-selection.md) | Engram에 실질적으로 필요한 기능만 다시 추린 결론 문서 |

