﻿# 핵심 아키텍처 변경 분석

?? ?? → Engram 전환에서 발생한 5가지 핵심 아키텍처 변경을 분석한다.

---

## 1. 저장소: Markdown 파일 → SQLite+FTS5

### 변경 내용

?? ??는 디렉토리 기반 Markdown 파일에 모든 데이터를 저장한다. 엔티티는 `entities/`, `live-notes/` 디렉토리에, 의사결정은 `decisions/`에, 세션 이벤트는 `sessions/`에 JSONL로 기록된다.

Engram은 SQLite 단일 파일에 20+ 테이블로 구조화된 스키마를 사용한다. WAL 모드, 외래키 강제, busy_timeout 5000ms가 적용되며, 선택적으로 Markdown 내보내기(`MarkdownExporter`)를 지원한다.

### 평가

| 항목 | 평가 |
|------|------|
| **유효성** | **유효함** — ACID 트랜잭션, 원자적 쓰기, 서브밀리초 쿼리, FTS5 전문 검색 지원 |
| **필요성** | **필수** — FTS5 전문 검색, 충돌 검사의 원자적 처리, 동시 접근은 파일 기반으로 불가능 |
| **품질** | **보통** |

### 구현 상세

**강점**:
- `threading.local()` 기반 thread-local 연결로 SQLite 스레딩 이슈 방지
- 모든 쓰기 작업에 명시적 rollback 처리
- 파일 생성 시 `0o600` 권한 설정 (보안 위생)
- FTS5 인덱스가 entity name, type, facts, state, summary, relation targets를 포괄
- 노트 중복 검출에 SHA-256 해시 컬럼 + 인덱스 사용

**우려점**:
- `sqlite_store.py`가 2,113줄 — 20+ 테이블의 CRUD를 하나의 클래스에서 처리하는 God Object
- `_SCHEMA_SQL` 상수와 마이그레이션이 동일 스키마를 별도 관리하는 이중진실(dual-truth) 문제
- `_row_to_fact()`가 `"scope_id" in row.keys()` 같은 마이그레이션 상태 인식 코드를 포함 (누수 추상화)

### 트레이드오프

| 관점 | Markdown (?? ??) | SQLite (Engram) |
|------|---------------------|-----------------|
| 가독성 | 사람이 직접 파일 탐색기로 열람 가능 | CLI/API 통해서만 접근 (Markdown 내보내기 선택적) |
| Git 추적 | 파일별 diff/blame 자연스러움 | 바이너리 파일이라 diff 불가 |
| 쿼리 성능 | 파일 스캔 필요 (O(N)) | 인덱스 기반 서브밀리초 (O(log N)) |
| 트랜잭션 | 없음 (부분 쓰기 가능) | ACID 보장 |
| 동시 접근 | 파일 잠금 필요 | WAL 모드로 동시 읽기/쓰기 지원 |

---

## 2. 모놀리스 → 모듈형 아키텍처

### 변경 내용

?? ??는 `?? ??` 단일 클래스(~4,362줄)에 모든 기능을 포함한다.

Engram은 `MemoryEngine`(~1,922줄)이 15+ 서비스를 조합하는 Facade 패턴을 사용한다. `StorageBackend` Protocol로 인터페이스를 추상화했다.

### 평가

| 항목 | 평가 |
|------|------|
| **유효성** | **유효함** — Protocol 기반 인터페이스 추상화, 의존성 주입 패턴 적용 |
| **필요성** | **부분적** — 코어(storage/search/quality/session) 분리는 필수. Feature service 증식은 과잉 위험 |
| **품질** | **보통** |

### 구현 상세

**강점**:
- `StorageBackend` Protocol에 `@runtime_checkable` 적용 → 테스트 시 mock 백엔드 사용 가능
- `__init__`에서 모든 서비스를 명시적 DI로 생성 (전역 상태, 서비스 로케이터 없음)
- 추출기와 Markdown 내보내기는 lazy 초기화 → LLM 의존성 불필요 시 로딩 안 함
- 검색 엔진 graceful degradation: hybrid → semantic → FTS5

**우려점**:
- `engine.py` 1,922줄, 70+ public 메서드 — 여전히 God Class
- 일부 서비스는 eager 생성(`__init__`), 일부는 lazy 생성(호출 시 `_maintenance_service()`) → 비일관
- `models/` 패키지에 20개 파일 — `view.py`, `brief.py`, `explanation.py` 같은 얇은 래퍼는 서비스와 co-locate 가능

---

## 3. 검색: difflib+regex → FTS5 BM25+Reranker

### 변경 내용

?? ??는 stdlib 기반 검색을 사용한다:
- 정확 매칭: 파일명/내용 substring 검색
- IDF 가중 토큰 스코어링: 희소 토큰에 높은 점수
- Fuzzy 매칭: `difflib.SequenceMatcher`
- Phrase 보너스, 제목 보너스, 최신성 보너스

Engram은 SQLite FTS5 기반 검색을 사용한다:
- BM25 스코어링 (컬럼별 가중치)
- CJK/한국어 토크나이저
- 세션 컨텍스트 기반 리랭킹
- 선택적 시맨틱/하이브리드 검색

### 평가

| 항목 | 평가 |
|------|------|
| **유효성** | **유효함** — FTS5 BM25는 TF-IDF 포화, 문서 길이 정규화를 기본 지원 |
| **필요성** | **필수** — 규모 있는 메모리 시스템에 적절한 전문 검색은 필수 |
| **품질** | **우수** |

### BM25 컬럼 가중치

```python
_BM25_WEIGHTS = (0.0, 10.0, 1.0, 3.0, 2.0, 5.0)
# entity_id: 0, entity_name: 10, entity_type: 1, fact_text: 3, state_text: 2, summary: 5
```

엔티티 이름(10x)에 최고 가중치, 요약(5x), 팩트 텍스트(3x) 순서.

### 리랭킹 부스트

| 조건 | 부스트 |
|------|--------|
| 세션에서 활성 엔티티 | +0.6 |
| 최근 접근 엔티티 | +0.2 |
| 선호 엔티티 | +0.4 |
| 목표 타입 선호 (예: meeting_prep → person) | +0.25 |

### 검색 파이프라인 (Engram)

```
쿼리 → 토크나이저(CJK 지원) → FTS5 BM25 → 신선도 페널티 적용 →
스코프 필터링 → 보존 정책 필터링 → 세션 리랭킹 → 프로비넌스 추적 → 결과 반환
```

---

## 4. Quality Gate 도입

### 변경 내용

?? ??에는 쓰기 경로에 품질 검증이 없다. Engram은 5단계 `QualityGate`를 모든 쓰기 경로에 적용한다.

### 평가

| 항목 | 평가 |
|------|------|
| **유효성** | **유효함** — PII 마스킹, 중복 검출, 충돌 감지가 실질적 문제 해결 |
| **필요성** | **필수** (PII/중복) / **Nice-to-have** (전체 진단 스위트) |
| **품질** | **우수** |

### 5단계 파이프라인

```
1. 신뢰도 스코어링
   base_trust(source_type) × source_confidence × extraction_multiplier
   source: direct_speech=0.95, document=0.90, API=0.85
   extraction: LLM=1.0, manual=1.0, regex=0.7

2. 메모리 타입 분류
   predicate 키워드 기반 IDENTITY/PREFERENCE/EPISODIC/TRANSIENT 자동 분류

3. PII 탐지 및 마스킹
   - 신용카드 (Luhn 알고리즘 검증)
   - 주민등록번호, SSN
   - API 키, 이메일
   - 한국 전화번호, 한국 주민등록번호
   마스킹 결과: [credit_card:19chars] (원본 PII 절대 저장 안 함)

4. 중복 검출
   동일 entity + predicate + object (정규화, 대소문자/관사 제거)

5. 충돌 검출
   동일 entity + predicate, 다른 object → 신뢰도 차이 기반 자동 해소
   - supersede: 새 팩트 신뢰도 ≫ 기존
   - keep_old: 기존 신뢰도 ≫ 새 팩트
   - manual_review: 신뢰도 차이 작음
```

---

## 5. MCP 통합

### 변경 내용

?? ??는 CLI와 Python SDK만 제공한다. Engram은 MCP(Model Context Protocol) 서버를 추가하여 Claude Code와 네이티브 통합한다.

### 평가

| 항목 | 평가 |
|------|------|
| **유효성** | **유효함** — MCP는 Claude Code의 네이티브 통합 프로토콜 |
| **필요성** | **필수** — MCP 없으면 에이전트가 CLI로 셸아웃 해야 함 |
| **품질** | **보통** — 기본 CRUD는 커버하나 확장 여지 있음 |

### 제공 MCP 도구 (7개)

| 도구 | 기능 |
|------|------|
| `memory_search` | BM25 검색 (토큰 버짓 제한) |
| `memory_store` | 정보 저장 (source type, confidence) |
| `memory_get_entity` | 엔티티 조회 + 팩트 |
| `memory_list_entities` | 필터링된 엔티티 목록 |
| `memory_session_start` | 세션 시작 + 컨텍스트 |
| `memory_session_end` | 세션 종료 + 요약 |
| `memory_resolve_conflict` | 충돌 해소 |

### 누락된 MCP 도구 (확장 권고)

- `memory_health` — 진단/헬스체크
- `memory_maintenance` — 유지보수 실행
- `memory_brief` — 엔티티/세션 브리프
- `memory_governance` — 거버넌스 후보 조회/해소
- `memory_retention` — 보존 정책 관리

