﻿# ?? ?? 전용 기능 — Engram 누락 분석

?? ??에는 존재하지만 Engram에 없거나 부분적으로만 존재하는 기능을 분석한다.

---

## 누락 현황 요약

| 기능 | 상태 | 구현 우선순위 | 이유 |
|------|:----:|:---:|------|
| `agentic_search()` | **누락** | 🔴 높음 | 에이전트 메모리의 핵심 차별화 |
| `agent_handoff()` | **누락** | 🔴 높음 | 멀티 에이전트 핵심 기능 |
| `channel_save/load/update()` | **누락** | 🟡 중간 | 채널 기반 에이전트 운영 필요 |
| `dream()` | **부분 존재** | 🟡 중간 | 통합 유지보수 사이클 가치 |
| 변증법 합성 | **누락** | 🟡 중간 | 충돌 해소의 고급 전략 |
| `retro()` | **누락** | 🟢 낮음 | 세션 요약이 부분 대체 |
| `suggest_links()` | **부분 존재** | 🟢 낮음 | 백링크는 존재, 선행적 제안 없음 |
| 메모리 타입 8종 | **의도적 축소** | ⚪ 해당 없음 | 4종이 감쇠율을 구동하여 더 실용적 |

---

## 상세 분석

### 1. `agentic_search()` — 멀티홉 질의 분해 + 위키링크 순회 🔴

**?? ?? 구현**:
```
쿼리 입력 → 질의 분해 (하위 질문 생성)
          → 각 하위 질문을 IDF 검색
          → 결과에서 [[wiki-links]] 추출 → 링크된 문서도 검색
          → Conway SMS 기반 목표 가중 리랭킹
          → 종합 결과 반환
```

**Engram 현재 상태**: 단일 홉 FTS5 BM25 검색만 지원. `RerankingService`가 세션 컨텍스트 기반 리랭킹을 하지만, 질의 분해나 그래프 순회는 없다. `ReferenceService`가 엔티티→소스 백링크를 추적하지만 검색에는 활용하지 않는다.

**왜 필요한가**: "에이전트 메모리 시스템"이라는 정체성의 핵심. 단순 키워드 검색은 사람도 할 수 있지만, 멀티홉 추론("김민수가 참여한 프로젝트 중 React를 쓰는 것은?")은 에이전트만의 가치.

**구현 방향 제안**:
- Engram의 기존 `Relation` 그래프 + `ReferenceService` 백링크를 활용한 그래프 순회
- FTS5 검색 → 엔티티 추출 → 관계 그래프 탐색 → 2차 검색 파이프라인
- 리랭커에 목표 컨텍스트(Conway SMS) 추가

---

### 2. `agent_handoff()` — 에이전트 간 작업 메모리 이전 🔴

**?? ?? 구현**:
```python
mk.agent_handoff(from_agent="researcher", to_agent="writer")
# researcher의 working memory를 writer에게 이전
# 태스크, 채널 컨텍스트, 엔티티 상태 포함
```

**Engram 현재 상태**: `WorkingMemory`는 세션 스코프, 인메모리 전용. 세션 종료 시 소멸. `build_session_context()`가 동일 에이전트의 최근 세션 이력을 집계하지만, 교차 에이전트 이전 메커니즘은 없다.

**왜 필요한가**: 멀티 에이전트 시나리오(리서처 → 작성자 → 리뷰어)에서 컨텍스트 유실 방지. 각 에이전트가 처음부터 검색해야 하면 비효율.

**구현 방향 제안**:
- `WorkingMemory` 직렬화/역직렬화 메서드 추가
- `SessionManager`에 `handoff(from_session_id, to_agent_id)` 구현
- 핸드오프 시 활성 엔티티, 최근 쿼리, 관련 팩트를 대상 에이전트의 새 세션으로 복사

---

### 3. `channel_save/load/update()` — 채널별 영속 컨텍스트 🟡

**?? ?? 구현**:
```python
mk.channel_save("slack-dev", context={"focus": "migration", "participants": [...]})
mk.channel_load("slack-dev")  # 영속된 채널 컨텍스트 복원
mk.channel_update("slack-dev", mode="merge", context={"new_key": "value"})
```

**Engram 현재 상태**: `Source` 모델에 `channel` 필드가 있고, 세션에 `agent_id`가 있지만, 채널별 영속 컨텍스트 저장/로드 API는 없다.

**왜 필요한가**: Slack/Discord 등 채널 기반 에이전트 운영 시 채널별 맥락(현재 논의 주제, 참여자, 선호도)을 유지해야 한다.

**구현 방향 제안**:
- Scoped Memory의 `channel` kind를 활용하여 채널 스코프 생성
- 스코프에 메타데이터(JSON) 저장 기능 추가
- 또는 별도 `channel_contexts` 테이블로 key-value 영속화

---

### 4. `dream()` — 7단계 유지보수 사이클 🟡

**?? ?? 구현**:
```
dream() 실행 시:
1. 인덱스 재구축
2. 노후 데이터 감쇠
3. 중복 팩트 병합
4. 페이지 요약 (블로트 방지)
5. 충돌 검출
6. OpenLoop 집계
7. 헬스체크 (등급 부여)
+ 선택적: 충돌 자동 해소
```

**Engram 현재 상태**: `maintenance()` 메서드가 노후 팩트 플래깅, 엔티티 압축, 충돌 자동 해소를 수행. `Diagnostics`가 8개 메트릭 헬스체크를 수행. 하지만 이들이 하나의 통합 사이클("dream")로 묶여 있지 않다.

**왜 필요한가**: "잠자기" 같은 직관적 메타포가 에이전트 운영자에게 단일 진입점을 제공. "dream 실행해" 하나로 모든 유지보수가 돌아가는 것이 편리.

**구현 방향 제안**:
- `engine.dream(dry_run=False)` 메서드 추가
- 내부에서 maintenance → diagnostics → governance generate → freshness sweep 순차 실행
- `MaintenanceRun` 기록에 dream 태그 추가

---

### 5. 변증법 합성 (Dialectic Synthesis) 🟡

**?? ?? 구현**: 충돌하는 두 팩트를 "A이지만 B이기도 하다" 또는 "과거에는 A였으나 현재 B로 변경" 형태로 합성하는 전략.

**Engram 현재 상태**: 충돌 해소 전략으로 `accept_new`, `keep_old`, `merge`(양쪽 보존)만 지원. 양쪽을 통합한 합성 텍스트를 생성하지 않음.

**왜 필요한가**: 시간에 따른 변화("2024년에 CTO, 2025년에 CEO")를 단일 팩트로 표현할 수 있다. 양쪽 보존(merge)은 두 개의 모순 팩트가 그대로 남는다.

**구현 방향 제안**:
- `resolve_conflict()` 전략에 `synthesize` 추가
- LLM 플러그인 활용하여 두 팩트를 합성 텍스트로 변환
- 또는 규칙 기반: 날짜가 있으면 "과거 A → 현재 B" 패턴 적용

---

### 6. `retro()` — 일일 회고 🟢

**?? ?? 구현**: 하루 동안의 세션/이벤트를 집계하여 "잘한 점 / 못한 점 / 다음 할 일" 형태로 정리.

**Engram 현재 상태**: 세션 종료 시 요약(`end_session(summary=...)`)이 생성되지만, 일일 단위 집계 기능은 없다.

**우선순위가 낮은 이유**: 세션 요약이 부분적으로 대체. 일일 회고는 에이전트보다 사람 운영자를 위한 기능이므로, 에이전트-퍼스트 설계에서 우선순위가 낮다.

---

### 7. `suggest_links()` — 누락 위키링크 제안 🟢

**?? ?? 구현**: 엔티티 간 언급은 있으나 `[[wiki-link]]`가 없는 경우를 탐지하여 링크 추가 제안.

**Engram 현재 상태**: `ReferenceService`가 엔티티→소스 백링크를 추적. `projection_drift()`가 인덱싱 안 된 소스를 식별. 하지만 "엔티티 A 페이지에서 엔티티 B를 언급하는데 링크가 없다"는 선행적 제안은 없음.

**우선순위가 낮은 이유**: Engram은 Markdown 위키링크 대신 SQL 관계(`Relation`)와 참조(`ReferenceEdge`)로 엔티티 연결을 관리하므로, 위키링크 제안의 필요성이 감소.

---

### 8. 메모리 타입 8종 → 4종 축소 ⚪

**변경 사유**: Engram 코드 주석 — "Four buckets are enough to express 'don't forget identity' vs 'age out yesterday's mood' without creating a classification problem that needs an LLM to solve."

**제거된 타입과 현재 매핑**:

| 제거된 타입 | Engram에서의 처리 |
|-----------|-----------------|
| `belief` | EPISODIC으로 분류 (감쇠 적용) |
| `relationship` | `Relation` 모델로 별도 관리 (메모리 타입과 무관) |
| `skill` | EPISODIC으로 분류 |
| `routine` | EPISODIC으로 분류 |

**판정**: 의도적 설계 선택. ?? ??의 8종은 라벨만 있고 차등 행동을 구동하지 않았으나, Engram의 4종은 각각 감쇠 반감기를 직접 결정한다. 기능적으로 더 실용적.

