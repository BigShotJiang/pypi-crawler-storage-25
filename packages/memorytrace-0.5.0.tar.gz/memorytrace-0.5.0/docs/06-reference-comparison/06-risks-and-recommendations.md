﻿# 리스크, 개선 권고, 결론

---

## 1. 구조적 리스크

### 1.1 God Object 재발생

| 파일 | 줄 수 | 문제 |
|------|-------|------|
| `engram/storage/sqlite_store.py` | 2,113줄 | 20+ 테이블의 모든 CRUD를 단일 클래스에서 처리 |
| `engram/engine.py` | 1,922줄 | 70+ public 메서드를 가진 Facade. 15+ 서비스를 조합하지만 본체가 거대 |

**위험**: ?? ??의 `core.py`(4,362줄) 모놀리스를 분해했으나, storage와 engine이 각각 2,000줄급으로 재응집. 모듈화의 이점이 희석.

**권고**:
- `sqlite_store.py`를 도메인별 Repository로 분리 (`EntityRepository`, `FactRepository`, `SessionRepository` 등)
- `engine.py`에서 도메인별 Use Case 클래스 추출 (`StoreUseCase`, `SearchUseCase`, `MaintenanceUseCase` 등)

### 1.2 스키마 이중진실 (Dual-Truth)

`sqlite_store.py`의 `_SCHEMA_SQL` 상수(줄 40-359)와 `migrations.py`의 11단계 마이그레이션이 동일 스키마를 별도 정의.

- **신규 DB**: `_SCHEMA_SQL`로 생성 후 마이그레이션 적용
- **기존 DB**: 마이그레이션만 적용

두 경로의 결과가 동일해야 하지만 검증 메커니즘이 없다. 스키마 변경 시 양쪽을 동기화하지 않으면 불일치 발생.

**권고**: `_SCHEMA_SQL`을 제거하고 모든 DB 생성을 마이그레이션 체인으로 통일. 또는 테스트에서 양쪽 경로의 스키마 동일성을 검증.

### 1.3 DRY 위반 — Search ↔ Storage 간 Row 매핑 중복

`fts5_search.py`의 `_get_entity_facts()`가 `sqlite_store.py`의 `_row_to_fact()` 로직을 중복 구현. 스키마 변경 시 한쪽만 수정하면 버그 발생.

**권고**: 공유 매핑 함수를 추출하거나, Search가 Storage의 매핑 메서드를 호출하도록 변경.

---

## 2. 기능 갭 — 우선 구현 권고

### 2.1 [높음] `agentic_search()` — 멀티홉 검색

에이전트 메모리 시스템의 핵심 차별화 포인트. 현재 단일 홉 FTS5만 지원.

**접근 방향**:
1. FTS5 검색 결과에서 엔티티 추출
2. `Relation` 그래프 + `ReferenceService` 백링크 순회
3. 관련 엔티티에 대한 2차 FTS5 검색
4. Conway SMS 스타일 목표 가중 리랭킹

**예상 작업량**: 중간 (search 파이프라인 확장, 그래프 순회 추가)

### 2.2 [높음] `agent_handoff()` — 에이전트 간 작업 메모리 이전

멀티 에이전트 워크플로우의 핵심 기능.

**접근 방향**:
1. `WorkingMemory` 직렬화/역직렬화
2. `SessionManager.handoff(from_session, to_agent)` 구현
3. 활성 엔티티 + 최근 쿼리 + 관련 팩트 이전

**예상 작업량**: 작음 (WorkingMemory 직렬화 + 세션 연결)

### 2.3 [중간] MCP 도구 확장

현재 7개 도구만 노출. 기존 기능 대비 MCP 커버리지 부족.

**추가 권고 도구**:
- `memory_health` — 진단 실행 + 결과 반환
- `memory_brief` — 엔티티/세션 브리프
- `memory_maintenance` — dream/유지보수 실행
- `memory_governance` — 거버넌스 후보 조회/해소

---

## 3. 보류 기능 조치 권고

### 3.1 Job Runner — 단순화 또는 보류

**현재**: enqueue 후 즉시 동기 실행. 사실상 로그 테이블.

**선택지**:
- **A) 단순화**: Job 테이블과 서비스를 제거하고, 현재의 동기 실행 로직만 유지. 향후 비동기 필요 시 재도입.
- **B) 보류**: 코드를 유지하되 "비동기 실행 없이 로그만" 상태를 문서화. 백그라운드 러너 도입 시 활성화.

**권고**: **B) 보류** — 구현이 깔끔하고 스키마 비용이 미미하므로 제거보다 보류가 낫다.

### 3.2 Recommendations — 테스트 추가 또는 보류

**현재**: 테스트 없음. 로직 중복. 비효율적 조회.

**선택지**:
- **A) 테스트 추가 + 리팩토링**: `get_recommendation()` 효율화, 로직 중복 제거, 전용 모델 파일 분리.
- **B) 보류**: 코드를 주석 처리하거나 engine에서 분리. MCP "추천" 엔드포인트 필요 시 재활성화.

**권고**: **B) 보류** — 명확한 소비자 없이 유지보수 비용만 발생.

---

## 4. 종합 결론

### Engram이 ?? ?? 대비 개선한 것

| 영역 | 개선 내용 |
|------|----------|
| **인프라** | SQLite+FTS5, BM25 검색, 11단계 마이그레이션, MCP 통합 |
| **안전성** | Quality Gate (PII 마스킹, 충돌 감지, 중복 검출) |
| **운영성** | 8개 메트릭 진단, 신선도 검증, 엔티티 거버넌스, 보존 정책 |
| **확장성** | 모듈형 아키텍처, Protocol 기반 인터페이스, 스코프 메모리 |
| **구조** | 순수 데이터클래스 20개, 구조화된 객체 반환, core에 print 없음 |

### Engram이 ?? ?? 대비 잃은 것

| 영역 | 상실 내용 | 중요도 |
|------|----------|:------:|
| **멀티홉 검색** | agentic_search() — 질의 분해 + 그래프 순회 | 🔴 높음 |
| **멀티 에이전트** | agent_handoff() — 에이전트 간 메모리 이전 | 🔴 높음 |
| **채널 컨텍스트** | channel_save/load/update() — 영속 채널 상태 | 🟡 중간 |
| **통합 유지보수** | dream() — 단일 진입점 유지보수 사이클 | 🟡 중간 |
| **충돌 합성** | 변증법 합성 — 모순 팩트를 통합 텍스트로 | 🟡 중간 |
| **가독성** | Markdown 파일 직접 열람 (Git diff 자연스러움) | 🟢 낮음 |

### 최종 권고 우선순위

```
1순위: agentic_search() 구현 — 에이전트 메모리 핵심 차별화
2순위: agent_handoff() 구현 — 멀티 에이전트 시나리오 지원
3순위: MCP 도구 확장 — 기존 기능의 에이전트 노출 확대
4순위: dream() 통합 사이클 — 운영 편의성
5순위: channel context 영속화 — 채널 기반 에이전트 지원
6순위: 변증법 합성 — 충돌 해소 고급 전략 (LLM 플러그인 활용)
```

### 신규 기능 판정 요약

```
KEEP (4): Freshness, Governance, Retention, Scopes
DEFER (2): Job Runner, Recommendations
```

