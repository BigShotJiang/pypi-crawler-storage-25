﻿# Engram 신규 기능 유효성 분석

Engram에만 존재하는 6개 신규 기능(미커밋 상태)의 유효성, 필요성, 품질을 분석한다.

---

## 종합 판정

```
┌──────────────────────┬───────────┬───────────┬─────────┬─────────────────────────────────┐
│ 기능                  │ 유효한가? │ 필요한가? │ 유용성  │ 판정                             │
├──────────────────────┼───────────┼───────────┼─────────┼─────────────────────────────────┤
│ Freshness            │ ✅ Yes    │ ✅ Yes    │ 4/5     │ KEEP — 검색 신뢰도 핵심         │
│ Entity Governance    │ ✅ Yes    │ ✅ Yes    │ 4/5     │ KEEP — NER 중복 해소 필수       │
│ Retention Policies   │ ✅ Yes    │ ✅ Yes    │ 4/5     │ KEEP — 감쇠/압축 보완 필수      │
│ Scoped Memory        │ ✅ Yes    │ ✅ Yes    │ 4/5     │ KEEP — 멀티컨텍스트 필수        │
│ Job Runner           │ ✅ Yes    │ ⚠️ Not yet│ 3/5     │ DEFER — 비동기 미활용           │
│ Recommendations      │ ⚠️ Partial│ ❌ No     │ 2/5     │ DEFER — 시그널 재집계, 테스트 無 │
└──────────────────────┴───────────┴───────────┴─────────┴─────────────────────────────────┘
```

---

## 1. Freshness Verification (신선도 검증) — KEEP

**파일**: `engram/freshness/service.py` (302줄), `engram/models/verification.py` (79줄)
**테스트**: `tests/test_freshness/test_service.py` (2/2 통과)

### 기능

팩트와 의사결정의 신선도를 추적하는 검증 생명주기를 관리한다.

```
팩트/의사결정 저장 → verification_due_at 설정 (메모리 타입별 감쇠 정책 기반)
                → 검색 시 만료 여부 확인 → 만료 시 VerificationRequest 자동 생성
                → 해소: VERIFIED (재검증), STALE, RETRACTED, SUPERSEDED
```

- 검색 시 만료된 팩트에 **-0.30 점수 페널티** 자동 적용
- "verify on read" 패턴: 전체 스캔 대신 검색 시점에 lazy하게 만료 감지
- 요청 중복 방지: `find_open_verification_request()`로 동일 대상 재요청 방지

### 유효성 분석

**필요한 이유**: 장기 메모리에서 팩트 노후화는 불가피하다. 누군가의 직책이 바뀌거나, 프로젝트가 방향을 전환하거나, 의사결정이 번복된다. 신선도 추적 없이는 에이전트가 오래된 정보를 현재 사실처럼 자신 있게 제시한다.

**설계 품질**: 평가(순수 로직 `FreshnessAssessment`)와 변경(요청 생성/해소)이 깔끔하게 분리되어 있다. `DecayPolicy`의 메모리 타입별 반감기를 재사용하므로 별도 설정 불필요.

---

## 2. Entity Governance (엔티티 거버넌스) — KEEP

**파일**: `engram/governance/service.py` (288줄), `engram/models/governance.py` (65줄)
**테스트**: `tests/test_governance/test_entity_governance.py` (4/4 통과)

### 기능

엔티티 중복을 탐지하고 해소하는 거버넌스 워크플로우를 제공한다.

```
generate_candidates() → O(n²) 페어와이즈 비교
  ├─ MERGE: 정규화 이름 일치 또는 별칭 교차 매칭
  ├─ ALIAS: 한쪽이 다른 쪽의 별칭 후보
  └─ SPLIT: 동일 엔티티에 모순 속성 (role, affiliation, location, email)

resolve_candidate()
  ├─ approve → merge: merge_entities_by_id() 실행, 중복 alias 후보 자동 취소
  ├─ approve → alias: 별칭 추가
  └─ reject → 후보 기각
```

- 핑거프린트 기반 멱등 업서트: 동일 후보 재생성 방지
- `limit=5000` 엔티티로 O(n²) 바운드

### 유효성 분석

**필요한 이유**: NER 기반 시스템에서 "Simon Kim" vs "S. Kim" vs "김시몬" 중복은 예견된 고빈도 문제다. Split 탐지("CTO"와 "HR Manager"를 동시에 가진 엔티티 = 동명이인 혼재)도 실질적 가치가 있다.

**설계 품질**: `merge_fn` 콜백을 통한 느슨한 결합, 병합 후 중복 alias 후보 자동 정리 등 라이프사이클을 잘 고려한 설계.

---

## 3. Job Runner (작업 큐) — DEFER

**파일**: `engram/jobs/service.py` (65줄), `engram/models/job.py` (27줄)
**테스트**: `tests/test_jobs/test_service.py` (3/3 통과)

### 기능

SQLite 기반 영속 작업 큐. enqueue → lease → execute → mark_failed/complete.

```
enqueue(job_type, payload, max_attempts)
  → lease(owner) — 원자적 작업 할당
  → mark_failed() — 재시도 (max_attempts 미달) 또는 dead_letter
```

지원 작업 타입: `index_source`, `rebuild_references`, `rebuild_decisions`, `rebuild_projections`, `maintenance_run`

### 유효성 분석

**문제점**: 현재 `engine.py`에서 enqueue 후 **즉시 동기 실행**한다:
```python
# store() 메서드 내부
self._job_runner.enqueue("index_source", ...)  # 작업 등록
self._index_source(note_id)                     # 바로 실행
```

실질적으로 `jobs` 테이블은 실행 로그일 뿐 진정한 비동기 큐가 아니다. `run_jobs()` API는 존재하지만 호출하는 자동 스케줄러가 없다.

**보류 사유**: 백그라운드 데몬이나 cron 기반 스케줄러가 도입될 때까지 불필요한 스키마 복잡도(테이블 + 인덱스)만 추가한다. 구현 자체는 깔끔하므로 코드를 유지하되 활성화는 보류.

---

## 4. Recommendations (추천 서비스) — DEFER

**파일**: `engram/recommendations/service.py` (448줄), 모델은 `engram/models/retention.py`에 혼입
**테스트**: **없음**

### 기능

4가지 추천을 현재 상태로부터 계산한다:

| 추천 종류 | 소스 |
|----------|------|
| `STALE_DECISION` | verification_due_at 경과 + 열린 요청 없는 의사결정 |
| `OPEN_LOOP_ESCALATION` | 반복 OpenLoop (2+회 = warning, 3+ = critical) + 노후 (7+일) |
| `MERGE_RECOMMENDATION` | 열린 merge 거버넌스 후보 + 보존 정책 충돌 감지 |
| `FOLLOW_UP_TASK` | 노후 검증 요청(3+일), 거버넌스 후보, critical 반복 OpenLoop |

### 유효성 분석

**문제점**:
1. **새 정보 없음**: freshness, governance, maintenance 시그널을 재집계하는 간접 레이어. 각 서비스 API로 직접 접근 가능한 정보만 다시 포장.
2. **비효율적 조회**: `get_recommendation(id)`이 전체 목록(limit=200)을 재계산 후 선형 스캔.
3. **로직 중복**: `_stale_decision_recommendations()`가 freshness 평가 로직을 재구현.
4. **모델 위치**: `RecommendationView`가 `models/retention.py`에 혼입 (구조적 냄새).
5. **테스트 없음**.

**보류 사유**: MCP "what should I do?" 엔드포인트 같은 명확한 소비자가 생길 때까지 부가가치 없음.

---

## 5. Retention Policies (보존 정책) — KEEP

**파일**: `engram/retention/service.py` (122줄), `engram/models/retention.py` (92줄)
**테스트**: `tests/test_retention/test_retention_service.py` (2/2 통과)

### 기능

대상별(entity/fact/decision/note/session) 보존 정책을 관리한다.

| 정책 타입 | 효과 |
|----------|------|
| `PIN` | 감쇠/삭제 대상에서 영구 제외 |
| `TTL` | 지정 시점 이후 만료 |
| `ARCHIVE_ONLY` | 기본 검색에서 숨김 (명시적 조회만 가능) |
| `NEVER_SUMMARIZE` | 압축/요약 대상에서 제외 (원문 보존) |

### 유효성 분석

**필요한 이유**: 감쇠와 압축을 수행하는 메모리 시스템에서 "이것만은 절대 잊지 마라" (PIN), "검색에서 숨기되 삭제하지 마라" (ARCHIVE_ONLY), "요약으로 뭉개지 마라" (NEVER_SUMMARIZE)는 자연스러운 요구사항이다.

**설계 품질**: 매우 깔끔. 얇고 타입 안전한 래퍼. `is_pinned()`, `is_archive_only()`, `get_ttl()` 같은 편의 메서드가 engine 전체에서 참조됨. 검색 결과 필터링(`_apply_retention_to_search_result`), 브리프 필터링에 깊이 통합됨.

---

## 6. Scoped Memory (스코프 메모리) — KEEP

**파일**: `engram/scopes/service.py` (77줄), `engram/models/scope.py` (41줄)
**테스트**: `tests/test_scopes/test_service.py` (2/2 통과)

### 기능

계층적 네임스페이스로 메모리를 분리한다.

```
global
└── workspace: "company-a"
    ├── project: "engram"
    │   ├── channel: "dev-chat"
    │   └── task: "migration-v11"
    └── project: "other-project"
        └── agent: "reviewer-bot"
```

- `create(name, kind, parent_id)` — 경로 자동 구축, "/" 금지 (경로 주입 방지)
- `resolve_selection(ScopeSelection)` → `ResolvedScope` (허용 scope ID 목록)
  - `include_ancestors`: 상위 스코프 팩트 상속
  - `include_global`: 전역 팩트 포함
  - `fallback_scope_ids`: 대체 스코프

### 유효성 분석

**필요한 이유**: 멀티 프로젝트/멀티 에이전트 환경에서 "project-alpha의 팩트가 project-beta 검색에 나오면 안 된다"는 기본 요구사항. 계층 구조(workspace > project > channel > task)는 개발 작업 조직 방식에 자연스럽게 매핑.

**설계 품질**: 최소주의적이고 잘 설계됨. 77줄 서비스 + 41줄 모델. `ScopeSelection` → `ResolvedScope` 패턴으로 호출자가 원하는 것을 선언하면 서비스가 해소. store, search, sessions에 모두 `scope_id` 통합.

