# 17. Engram 4차 코드 리뷰 및 한국어 2음절 이름 개선안 (2026-04-12)

> 검토 대상: `default/engram`
>
> 목적: 이전 리뷰에서 잡지 못했거나 아직 문서화하지 않은 read path, session continuity, SDK integration 문제를 추가로 정리하고, 한국어 2음절 이름 회귀를 어떤 방식으로 고치는 게 좋은지 설계 방향까지 남긴다.

---

## 1. 이번 라운드 검토 방식

이번 검토는 영역을 나눠서 다시 확인했다.

- core: `engine.py`, `search/`, `quality/`
- persistence/integration: `storage/`, `session/`, `integrations/`, `cli/`
- Korean NER: `extraction/ner/korean.py`, `tests/test_extraction/test_ner/test_korean.py`

실제 서브 에이전트를 띄우는 도구는 이 세션에 노출되어 있지 않아, 범위를 분리한 병렬 탐색과 수동 재현 스크립트로 대체했다.

---

## 2. 추가로 확인된 문제점

### 2.1 [P2] `get_facts()` read path는 아직 세션 추적에서 빠져 있다

관련 파일:

- `engram/engine.py:167-174`
- `engram/integrations/sdk.py:101-102`

문제:

- `get_facts()`는 엔티티를 조회하지만 `session_id`를 받지 않고, `record_entity_access()`도 호출하지 않는다.
- SDK의 `get_facts()`도 그대로 이 경로를 사용한다.

재현:

1. 세션 시작
2. `get_facts("Simon Kim")`만 호출
3. 세션 종료
4. 결과:
   - `entities_accessed = []`
   - `summary = "Session with no significant changes"`

영향:

- 사용자가 엔티티를 읽고 있었어도 세션 기록에는 남지 않는다.
- "대화를 이어가기 위한 메모리" 목적에서 read-only 세션이 다시 사라진다.

정리:

- `get_facts()`도 `session_id`를 받을 수 있어야 하고, 최소한 대상 엔티티 access는 기록해야 한다.

---

### 2.2 [P2] note-only 검색은 결과가 있어도 세션 요약에 전혀 반영되지 않는다

관련 파일:

- `engram/engine.py:133-140`
- `engram/session/manager.py:50-72`

문제:

- entity hit가 없을 때 `search()`는 raw notes fallback을 사용한다.
- 하지만 note hit는 어떤 형태로도 세션 매니저에 기록되지 않는다.
- 요약 생성도 `entities_accessed`, `entities_modified`, `facts_added`만 보기 때문에 note-only 세션은 항상 빈 세션처럼 끝난다.

재현:

1. entity 추출이 거의 없는 자유 텍스트 note 저장
2. 새 세션에서 그 note를 검색
3. 결과:
   - `notes = 1`
   - `entities_accessed = []`
   - `summary = "Session with no significant changes"`

영향:

- 검색은 성공했는데 세션 컨텍스트에는 아무 흔적도 남지 않는다.
- 자유 메모/회의 로그 중심 워크플로우에서는 session carryover 품질이 낮아진다.

정리:

- notes도 별도 access 타입으로 기록하거나, 최소한 note-only search 사실은 summary에 반영해야 한다.

---

### 2.3 [P2] SDK function-calling schema는 아직 `session_id`를 전달할 수 없다

관련 파일:

- `engram/integrations/sdk.py:144-193`

문제:

- `get_tool_schemas()`가 반환하는 `memory_search`, `memory_store`, `memory_get_entity` schema에는 `session_id` 필드가 없다.
- 엔진과 MCP 레벨에서는 이미 `session_id`가 지원되지만, 함수 호출 스키마에서는 빠져 있다.

영향:

- OpenAI function calling이나 tool wrapper가 이 schema를 그대로 쓰면 세션 continuity를 연결할 수 없다.
- 즉, 내부 구현은 세션을 지원하지만 외부 통합 표면은 여전히 세션 없는 API처럼 보인다.

정리:

- tool schema도 현재 런타임 API와 동일하게 `session_id`를 노출해야 한다.

---

### 2.4 [P3] migration 경로가 아직 런타임에 연결되어 있지 않다

관련 파일:

- `engram/storage/sqlite_store.py:175-187`
- `engram/storage/migrations.py:18`

문제:

- `SQLiteStorage.initialize()`는 schema SQL을 바로 실행하고 `_meta.schema_version`만 세팅한다.
- 하지만 `migrations.py`의 `migrate()` 호출 경로는 현재 찾지 못했다.

영향:

- 지금은 schema version이 `1`이라 당장 표면화되지 않는다.
- 이후 schema가 바뀌면 "버전은 저장하지만 upgrade path는 안 타는" 구조가 될 가능성이 높다.

정리:

- 다음 schema 변경 전에 migration 호출 경로를 연결하는 편이 안전하다.

---

## 3. 한국어 2음절 이름 회귀: 어떻게 바꾸는 게 좋은가

### 3.1 현재 문제의 성격

현재 구현은 `engram/extraction/ner/korean.py:117-129`에서 bare-name fallback을 다음처럼 매우 보수적으로 제한한다.

- top-10 성씨만 허용
- 길이 3만 허용
- 구조적 suffix는 제외

이 정책 덕분에 false positive는 많이 줄었지만, `이준`, `김봄`, `박윤` 같은 2음절 이름을 놓친다. 현재 전체 테스트의 유일한 실패도 이 케이스다.

핵심은 다음 둘의 균형이다.

- recall을 조금 올리고 싶다
- 하지만 "이슈", "기준", "김치", "박스" 같은 일반 명사를 이름으로 오인하면 안 된다

즉, 단순히 `len(name) == 3`을 `len(name) in (2, 3)`으로 바꾸는 방식은 권장되지 않는다.

---

### 3.2 권장 방향: "맥락 있는 2음절 이름"만 추가 허용

가장 안전한 방향은 2음절 bare name을 전면 허용하는 것이 아니라, 다음 조건을 만족할 때만 별도 규칙으로 받아들이는 것이다.

권장 규칙:

1. 후보 길이는 정확히 2음절
2. 첫 글자는 `_TOP_SURNAMES` 안에 있어야 함
3. 뒤에 조사/격조사가 붙어 있어야 함
4. 주변 문맥이 사람 주어/목적어처럼 보여야 함
5. 일반 명사/조직어로 자주 쓰이는 단어는 제외

예시 패턴:

- `이준은`
- `김봄이`
- `박윤을`
- `최민과`

반대로 바로 막아야 할 예시:

- `이슈는`
- `기준은`
- `김치는`
- `박스가`

이 방식이면 `이준은 회의에 참석했다.` 같은 테스트는 통과시키면서, 2음절 일반 단어 폭증은 어느 정도 막을 수 있다.

---

### 3.3 추천 구현안

현재 순서를 유지하되, 3음절 bare fallback 앞에 "2음절 + 조사 문맥" 단계를 하나 추가하는 것이 가장 무난하다.

추천 단계:

1. 기존 high-confidence 규칙 유지
   - 이름 + 직함
   - 이름 소개 패턴
2. 새 규칙 추가
   - `top surname + 1 syllable`
   - 바로 뒤에 조사 존재
   - 토큰이 common noun blocklist에 없을 것
   - 조직/직책 suffix로 끝나지 않을 것
3. 기존 3음절 bare fallback 유지

형태 예시:

```python
_TWO_SYLLABLE_NAME_WITH_PARTICLE = re.compile(
    r'([가-힣]{2})(?:은|는|이|가|을|를|과|와|도|에게|한테)'
)
```

후처리:

- `candidate[0] in _TOP_SURNAMES`
- `candidate not in _COMMON_TWO_SYLLABLE_NOUNS`
- `candidate[-1] not in _STRUCTURAL_SUFFIXES`

이 방식의 장점:

- 현재 구현 철학인 "positive evidence가 있을 때만 person으로 본다"를 유지한다
- 테스트 하나를 고치기 위해 false positive를 크게 열지 않는다
- 규칙 추가 범위가 작아서 롤백이나 튜닝이 쉽다

---

### 3.4 왜 "2음절 bare fallback 전면 허용"은 피해야 하는가

다음처럼 고치는 건 쉬워 보이지만 위험하다.

```python
if len(name) not in (2, 3):
    continue
```

이 접근의 문제:

- 한국어 2음절 일반 명사가 매우 많다
- 특히 첫 글자가 흔한 성씨와 같은 경우가 많다
- 결국 blocklist를 끝없이 늘려야 한다

현재 모듈 주석도 "negative blocklist 확장은 끝이 없다"는 방향을 이미 택하고 있다. 따라서 2음절 회귀도 같은 철학 안에서 풀어야 한다.

---

### 3.5 테스트 전략

2음절 규칙을 넣을 때는 positive test만 추가하면 안 된다. false positive 회귀를 막는 테스트를 같이 늘려야 한다.

추가 권장 positive 케이스:

- `이준은 회의에 참석했다.`
- `김봄이 발표를 맡았다.`
- `박윤을 만났다.`
- `최민과 통화했다.`

추가 권장 negative 케이스:

- `이슈는 여전히 남아 있다.`
- `기준은 다음과 같다.`
- `김치는 맛있다.`
- `박스가 도착했다.`

추가 권장 mixed 케이스:

- `이준은 회의에 참석했고, 이슈는 다음 안건이다.`

즉, 2음절 이름을 허용하되 "이슈" 같은 단어는 절대 사람으로 잡히지 않는다는 걸 함께 고정해야 한다.

---

### 3.6 단계별 적용안

가장 현실적인 적용 순서는 다음과 같다.

1. 최소 수정
   - 2음절 + 조사 규칙 추가
   - top surname 제한 유지
   - 소수의 명백한 common noun blocklist 추가
2. 테스트 확대
   - positive/negative/mixed 케이스 동시 추가
3. 실제 데이터 관찰
   - false positive가 많은지 확인
4. 필요하면 2차 보정
   - 동사/서술어 문맥까지 보는 추가 규칙
   - score 기반 candidate ranking 도입 검토

이 순서가 좋은 이유는, 회귀를 고치면서 precision 붕괴를 최소화할 수 있기 때문이다.

---

## 4. 우선순위 제안

### 바로 반영할 것

- `get_facts()` session tracking 추가
- note-only search summary 보강
- SDK tool schema에 `session_id` 추가
- 한국어 2음절 이름용 "조사 기반 보수 규칙" 추가

### 다음 단계에서 볼 것

- migration 경로 연결
- 2음절 이름 false positive 데이터셋 확장
- 필요하면 score 기반 Korean NER 후보 랭킹 검토

---

## 5. 결론

이번 라운드에서 새로 드러난 핵심은 "쓰기 경로"보다 "읽기 경로와 외부 통합 표면"에 남아 있는 구멍이다.

특히 세션 continuity 관점에서는 다음 셋이 중요하다.

1. `get_facts()`가 세션에 남지 않는 문제
2. note-only 검색이 세션 요약에 반영되지 않는 문제
3. SDK tool schema가 `session_id`를 노출하지 않는 문제

한국어 2음절 이름 회귀는 단순 완화가 아니라 "맥락 있는 2음절만 허용"하는 방식으로 고치는 것이 가장 안전하다. 이 접근이 현재 모듈의 보수적 철학과도 가장 잘 맞는다.
