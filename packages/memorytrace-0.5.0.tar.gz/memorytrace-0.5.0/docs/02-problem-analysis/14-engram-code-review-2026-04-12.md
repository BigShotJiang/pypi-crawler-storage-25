# 14. Engram 코드 리뷰 결과 (2026-04-12)

> 대상 경로: `default/engram`
>
> 목적: "에이전트가 데이터를 저장하고 나중에 다시 불러와 세션을 잃지 않도록 한다"는 프로젝트 목표 기준으로 현재 구현의 문제점과 개선 우선순위를 정리한다.

---

## 1. 검토 범위

이번 리뷰는 다음 영역을 기준으로 진행했다.

- 엔진 진입점과 저장/조회 흐름
- 세션 연속성 구현
- 품질 게이트와 충돌 처리
- SQLite/FTS5 저장소와 Markdown export
- CLI/SDK/MCP 진입 경로
- 테스트 스위트와 실제 재현 결과

---

## 2. 검토 방법

다음 순서로 여러 번 교차 확인했다.

1. 저장소 구조와 핵심 파일 독해
2. 전체 테스트 실행
3. 실패 테스트 재실행
4. 재현 스크립트로 실제 동작 확인
5. 문서/설정/구현 간 불일치 점검

실행 결과:

- 전체 테스트: `247`개 중 `244`개 통과, `3`개 실패
- 실패 항목:
  - Windows 환경에서 Markdown export 읽기 실패 2건
  - 한국어 2음절 이름 추출 실패 1건

---

## 3. 핵심 결론

현재 Engram은 "정보를 저장한다"는 기본 기능은 이미 갖추고 있다. 다만 프로젝트의 핵심 목표인 "세션을 잃지 않는 에이전트 메모리" 관점에서는 아직 중요한 결함이 남아 있다.

가장 큰 문제는 다음 두 가지다.

- 세션 기록이 쓰기 중심이라, 읽기/검색 위주의 실제 대화 맥락이 세션에 거의 남지 않는다.
- 충돌 자동 해결이 이름만 자동 해결일 뿐, 실제 데이터 상태를 정리하지 못한다.

즉, 지금 상태는 "메모리를 쌓는 시스템"에는 가깝지만, "대화 맥락을 안정적으로 이어주는 시스템"으로 보기에는 부족하다.

---

## 4. 주요 문제점

### 4.1 치명: 자동 충돌 해결이 실제로는 충돌을 해결하지 않음

관련 파일:

- `engram/quality/gate.py`
- `engram/engine.py`

문제:

- `QualityGate._try_auto_resolve()`는 `suggested_resolution == "supersede"`면 자동 해결된 것으로 간주한다.
- 하지만 기존 fact를 `retracted` 또는 `expired` 처리하거나 `superseded_by`를 설정하는 실제 후처리는 없다.
- 그 결과 새 사실이 들어와도 예전 사실이 current 상태로 남을 수 있다.

재현:

- `CEO` fact 추가
- 더 신뢰도 높은 `CTO` fact 추가
- 결과: `pending_conflicts = []`
- 하지만 두 fact가 모두 유효한 상태로 남음

영향:

- 충돌이 해결된 것처럼 보이지만 실제 데이터는 모순 상태
- 검색, export, 요약, 후속 reasoning이 모두 오염될 수 있음

판단:

- 이 문제는 메모리 시스템의 신뢰성을 직접 깨는 결함이다.

---

### 4.2 치명: 세션 연속성이 읽기 경로에서는 거의 작동하지 않음

관련 파일:

- `engram/engine.py`
- `engram/session/manager.py`
- `engram/session/context.py`
- `engram/integrations/sdk.py`

문제:

- `get_entity()`는 entity access를 session에 기록하지 않는다.
- `search()`는 결과 hit를 `entities_accessed`에 기록하지 않는다.
- `SDK.search()`는 현재 세션 ID를 엔진에 전달하지 않는다.
- 결과적으로 읽기 전용 세션은 대화를 많이 했어도 "변화 없음"처럼 끝날 수 있다.

재현:

- 기존 데이터를 저장
- 새 세션 시작
- `search()`와 `get_entity()`만 수행
- 세션 종료
- 결과: `entities_accessed = []`, `entities_modified = []`
- 요약: `Session with no significant changes`

영향:

- 이전 대화에서 무엇을 봤는지, 무엇을 중심으로 이야기했는지 복원 불가
- "세션을 잃지 않기 위함"이라는 프로젝트 목적과 가장 크게 충돌

판단:

- 이 문제는 기능 결함이 아니라 제품 정체성 문제에 가깝다.

---

### 4.3 높음: 수동 fact 추가가 entity state를 갱신하지 않음

관련 파일:

- `engram/engine.py`

문제:

- `store()` 경로에서는 일부 predicate가 `entity.state`로 반영된다.
- 하지만 `add_fact()` 경로에서는 같은 후처리가 없다.
- 예를 들어 `predicate="role"`로 fact를 넣어도 `entity.state.role`은 비어 있다.

재현:

- `create_entity("Simon Kim")`
- `add_fact("Simon Kim", "CEO", predicate="role")`
- 조회 결과: `entity.state.role is None`

영향:

- `who/get` 출력 품질 저하
- Markdown `State` 섹션 누락
- state 기반 요약과 검색 정확도 저하
- 자동 추출 경로와 수동 입력 경로의 동작 불일치

---

### 4.4 높음: Windows에서 `python -m engram` 경로가 깨짐

관련 파일:

- `engram/__main__.py`
- `engram/cli/app.py`
- `engram/cli/simple.py`

문제:

- `__main__.py`는 `cli_entry()`가 아니라 `main()`을 직접 호출한다.
- 따라서 Windows용 UTF-8 stdout/stderr 재설정 로직을 우회한다.
- `--help` 출력 시 description의 유니코드 문자 때문에 `UnicodeEncodeError`가 발생할 수 있다.

재현:

- Windows에서 `python -m engram --help`
- 실제로 `UnicodeEncodeError` 재현됨

영향:

- package entry point와 module entry point의 품질이 다름
- 설치 방식에 따라 CLI가 동작하거나 깨지는 불안정한 상태

---

### 4.5 높음: Windows 인코딩 문제로 Markdown export가 테스트에서 실패함

관련 파일:

- `engram/storage/markdown_export.py`
- `tests/test_e2e.py`

문제:

- Markdown export는 UTF-8로 파일을 쓴다.
- 파일 내용에 `→`, `←`, `✓`, `✗` 같은 문자가 포함된다.
- Windows 기본 로케일(`cp949`)로 `Path.read_text()`를 호출하면 decode 실패가 발생한다.

테스트 실패:

- `tests/test_e2e.py::TestE2EStoreSearchRetrieve::test_full_cycle`
- `tests/test_e2e.py::TestE2EMarkdownExport::test_exported_markdown_structure`

영향:

- Windows 사용자의 export 검증/재처리 경로가 깨질 수 있음
- CI 환경이나 사용자 로컬 환경에 따라 동일 코드가 다르게 보일 수 있음

---

### 4.6 중간: `search_backend` 설정이 실제로 사용되지 않음

관련 파일:

- `engram/config.py`
- `engram/engine.py`
- `engram/search/semantic.py`
- `engram/search/hybrid.py`

문제:

- 설정에는 `fts5`, `semantic`, `hybrid`가 정의되어 있다.
- 하지만 엔진 초기화는 항상 `FTS5Search`를 사용한다.
- 즉, 설정상 지원하는 것처럼 보이지만 실제 runtime wiring은 없다.

재현:

- `EngramConfig(search_backend="semantic")`
- 엔진 생성
- 실제 `search_engine` 타입은 `FTS5Search`

영향:

- 문서/설정/구현 간 불일치
- 사용자 기대를 잘못 유도
- 향후 유지보수 시 "있어 보이지만 죽은 코드"가 늘어남

---

### 4.7 중간: 한국어 NER이 2음절 이름을 놓침

관련 파일:

- `engram/extraction/ner/korean.py`
- `tests/test_extraction/test_ner/test_korean.py`

문제:

- fallback 규칙이 사실상 `3음절 이름 + 상위 성씨`만 허용한다.
- 그래서 `이준` 같은 2음절 이름은 title/context가 없으면 잡히지 않는다.

실패 테스트:

- `test_two_syllable_name`

영향:

- 한국어 입력 recall 저하
- 실제 사용자 데이터에서 인물 추출 누락 가능성 높음

주의:

- 이 부분은 precision과 recall의 정책 선택 문제도 있다.
- 다만 현재는 테스트 기대치와 구현 정책이 어긋나 있다.

---

## 5. 추가 관찰 사항

### 5.1 세션 요약은 "쓰기"가 있을 때만 그럴듯해짐

`SessionManager._auto_summary()`는 `entities_modified`, `entities_accessed`, `facts_added`에 의존한다.

그런데 현재 구조상 읽기 경로가 제대로 기록되지 않으므로, 실사용 시 가장 자주 발생할 "검색 중심 대화"의 요약 품질이 낮다.

### 5.2 `add_fact()`와 `store()`의 후처리 정책이 다름

같은 fact가 들어와도 자동 추출 경로와 수동 추가 경로의 결과가 달라진다. 이 차이는 시간이 갈수록 데이터 품질 편차를 만든다.

### 5.3 테스트가 많지만 핵심 시나리오 몇 개가 비어 있음

현재 테스트 수는 충분히 많다. 하지만 아래 핵심 시나리오는 빠져 있다.

- auto-resolve 이후 기존 fact가 실제로 비활성화되는지
- 읽기 전용 세션이 access history를 남기는지
- `python -m engram` 경로가 Windows에서 동작하는지
- `search_backend`가 config에 따라 실제로 바뀌는지
- `add_fact()`가 state를 동기화하는지

---

## 6. 우선순위별 개선 제안

### 1순위: 데이터 정합성 복구

- auto-resolve 시 기존 fact 상태를 반드시 갱신
- `superseded_by`, `valid_to`, `status`를 같은 트랜잭션 안에서 처리
- 충돌 판정과 충돌 반영을 분리하지 말고 하나의 쓰기 흐름으로 묶기

### 2순위: 세션 연속성 복구

- `search()`, `get_entity()`, `get_facts()`에 session access 추적 추가
- search hit entity를 `record_entity_access()`로 기록
- SDK의 `search()`도 `session_id`를 엔진에 넘기도록 수정
- session summary가 읽기 위주 대화도 반영하도록 보강

### 3순위: 수동 입력 경로 정렬

- `add_fact()`에도 `store()`와 동일한 state 동기화 로직 추가
- role, affiliation, location 등 핵심 predicate를 공통 후처리 함수로 분리

### 4순위: Windows 호환성 정리

- `__main__.py`에서 `cli_entry()` 호출
- export 포맷을 ASCII-safe로 낮추거나
- 테스트/리더 쪽에서 UTF-8을 명시하도록 일관화

### 5순위: 설정/구현 불일치 제거

- `search_backend`를 실제로 wiring
- 당장 미구현이라면 config와 docs에서 숨기기

### 6순위: 한국어 추출 정책 정리

- 2음절 이름 recall을 늘릴지
- 현 precision 정책을 유지할지 먼저 결정
- 결정 후 테스트와 규칙을 같은 방향으로 맞추기

---

## 7. 권장 수정 순서

실제 작업 순서는 아래가 가장 안전하다.

1. auto-resolve와 fact 상태 전이 수정
2. session access 추적 추가
3. `add_fact()` state 동기화
4. Windows CLI/Markdown 인코딩 정리
5. `search_backend` wiring 또는 제거
6. 한국어 NER 정책 보정
7. 누락된 회귀 테스트 추가

---

## 8. 결론

Engram은 구조 자체는 나쁘지 않다. 모듈 분리도 비교적 명확하고, SQLite + FTS5 중심 설계도 경량 메모리 시스템에 잘 맞는다.

문제는 현재 구현이 "정보 저장"에는 어느 정도 도달했지만, "세션을 잃지 않는 에이전트 메모리"라는 목표에는 아직 핵심 경로가 덜 완성되었다는 점이다.

특히 다음 두 질문에 현재 답이 약하다.

- 읽기 위주 대화의 맥락을 정말 다음 세션으로 넘길 수 있는가?
- 충돌하거나 갱신된 사실을 시간이 지나도 일관되게 유지할 수 있는가?

이 두 축을 먼저 보완하면, Engram은 단순 저장소에서 실제 에이전트 메모리 시스템으로 한 단계 올라갈 수 있다.
