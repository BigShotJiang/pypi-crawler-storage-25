# 15. Engram 추가 코드 리뷰 결과 (2026-04-12)

> 대상 경로: `default/engram`
>
> 목적: 1차 코드 리뷰 이후 현재 구현을 다시 점검해, 아직 남아 있는 정합성 문제와 통합 경로의 결함을 추가로 정리한다.

---

## 1. 검토 목적

이번 리뷰는 이전 리뷰를 반복하는 대신, 아래 항목을 중심으로 다시 점검했다.

- 충돌 해결이 실제 데이터 상태를 끝까지 정리하는지
- MCP/SDK/CLI 같은 실제 사용 경로에서 세션과 설정이 제대로 연결되는지
- semantic/hybrid 검색 설정이 runtime에서 실제로 동작하는지
- maintenance, merge, export처럼 상대적으로 덜 테스트된 경로에 정합성 문제가 없는지

---

## 2. 검토 결과 요약

현재 기준으로 전체 테스트는 거의 통과한다.

- 전체 테스트: `246 passed`, `1 failed`
- 남은 실패: 한국어 2음절 이름 추출 테스트 1건

하지만 테스트 통과율과 별개로, 실제 동작에서는 아래와 같은 중요한 문제들이 남아 있었다.

- conflict를 해결했다고 표시해도 실제 winner fact가 검색 가능 상태가 되지 않는 경우가 있다.
- MCP 세션 API가 있어도 실제 MCP read/write 도구는 그 세션 ID를 쓰지 않는다.
- semantic 검색은 설정상 지원되지만, 기본 환경에서는 첫 검색 시점에 바로 깨질 수 있다.
- maintenance, merge, export 같은 보조 경로에 데이터 정합성 문제가 남아 있다.

---

## 3. 주요 추가 문제점

### 3.1 치명: 수동 conflict 해결 후에도 새 fact가 current 상태가 되지 않음

관련 파일:

- `engram/engine.py`
- `engram/search/fts5_search.py`

문제:

- `resolve_conflict(..., "accept_new")`는 기존 fact만 `retracted` 처리한다.
- 하지만 새 fact는 여전히 `conflicted` 상태로 남는다.
- 검색 계층은 `conflicted` fact를 제외하므로, 사용자가 "새 사실 채택"을 선택해도 그 사실이 검색에 안 잡힐 수 있다.

재현:

- `CEO` fact 저장
- `CTO` fact 저장 -> conflict 발생
- `accept_new`로 해결
- 결과:
  - 기존 `CEO` fact는 `retracted`
  - 새 `CTO` fact는 `conflicted` 그대로
  - 검색에서는 새 사실이 제외됨

영향:

- UI나 CLI에서는 conflict가 해결된 것처럼 보이지만 실제 검색 결과는 틀릴 수 있다.
- 사용자가 데이터 정합성을 신뢰하기 어려워진다.

---

### 3.2 치명: `merge` conflict resolution이 사실상 no-op

관련 파일:

- `engram/engine.py`

문제:

- CLI와 MCP는 `merge`를 허용한다.
- 하지만 `resolve_conflict()`는 `accept_new`, `keep_old`만 처리하고 `merge` 분기는 없다.
- 결국 conflict row만 resolve되고 fact 상태는 아무것도 바뀌지 않는다.

재현:

- conflict 생성
- `merge` 선택
- 결과:
  - pending conflict는 사라짐
  - fact 두 개는 그대로 유지

영향:

- 사용자에게는 지원되는 해법처럼 보이지만 실제 의미 있는 동작이 없다.
- 잘못된 완료 상태를 만들기 때문에 단순 미구현보다 더 위험하다.

---

### 3.3 치명: MCP 세션 시작/종료 도구와 실제 메모리 도구가 연결되지 않음

관련 파일:

- `engram/integrations/mcp_server.py`

문제:

- `memory_session_start()`는 `session_id`를 발급한다.
- 하지만 `memory_search()`, `memory_store()`, `memory_get_entity()`는 그 ID를 입력받지도 않고 엔진에 전달하지도 않는다.
- 즉, MCP 통합 경로에서는 세션 기능이 사실상 분리되어 있다.

영향:

- MCP를 통해 쓰고 읽는 실제 대화는 session access/modify 기록이 남지 않는다.
- 세션 연속성이 구현돼 있어도 MCP 사용자에게는 거의 체감되지 않는다.

판단:

- 이 프로젝트가 에이전트 메모리 시스템이라는 점을 생각하면, 핵심 통합 경로의 단절 문제다.

---

### 3.4 치명: semantic 검색은 설정되어도 첫 검색 시 ImportError로 터질 수 있음

관련 파일:

- `engram/engine.py`
- `engram/search/semantic.py`

문제:

- 엔진은 `search_backend="semantic"` 또는 `"hybrid"`를 설정하면 해당 객체를 만든다.
- 하지만 semantic backend는 `openai` 패키지를 생성 시점이 아니라 검색 시점에 lazy-load한다.
- 따라서 엔진 생성은 성공해도 첫 `search()`에서 `ImportError`가 날 수 있다.

재현:

- `search_backend="semantic"`으로 엔진 생성
- `search("CEO")`
- 결과: `OpenAI SDK not installed` 예외 발생

영향:

- 설정은 먹는 것처럼 보이는데 실제 runtime에서 뒤늦게 깨진다.
- fallback 설계가 있는 것처럼 보이지만 사용자 체감상 안전하지 않다.

---

### 3.5 높음: semantic/hybrid는 index를 실제로 쌓지 않음

관련 파일:

- `engram/search/semantic.py`
- `engram/engine.py`

문제:

- `SemanticSearch.index_entity()`는 존재한다.
- 그러나 일반 저장 경로는 SQLite FTS 재색인만 수행하고 semantic embedding index는 갱신하지 않는다.
- 따라서 의존성을 모두 설치해도 semantic search 결과가 비어 있을 가능성이 높다.

영향:

- 설정/클래스는 존재하지만 실제 기능이 연결되지 않았다.
- search backend 옵션이 부분 구현 상태로 남아 있다.

---

### 3.6 높음: `maintenance()`가 conflict를 잘못 해소하고 fact 상태는 정리하지 않음

관련 파일:

- `engram/engine.py`

문제:

- 주석은 "30일 이상 지난 conflict"라고 쓰여 있지만 실제로는 날짜 조건이 없다.
- 그리고 `engine.resolve_conflict()`가 아니라 `storage.resolve_conflict()`를 직접 호출한다.
- 그래서 conflict row는 resolved 되지만 fact status는 반영되지 않는다.

재현:

- pending conflict 생성
- `maintenance()` 실행
- 결과:
  - pending conflict는 사라짐
  - fact 상태는 그대로 유지

영향:

- 백그라운드 maintenance가 데이터 상태를 더 일관되게 만드는 게 아니라, 표시상 문제만 숨길 수 있다.

---

### 3.7 높음: entity merge 후 다른 엔티티의 FTS relation 텍스트가 stale 상태로 남음

관련 파일:

- `engram/engine.py`
- `engram/storage/sqlite_store.py`

문제:

- FTS 인덱스는 relation 대상 이름까지 fact text에 포함한다.
- 그런데 `merge_entities()`는 relation row만 옮기고, relation을 참조하던 다른 엔티티를 재색인하지 않는다.

재현:

- `Acme Corp -> Alicia` relation 생성
- `Alicia`를 `Alice`에 merge
- `Acme Corp`의 FTS row 확인
- 결과: 여전히 `KNOWS Alicia`

영향:

- 검색 인덱스와 실제 DB relation 상태가 어긋난다.
- merge 직후 검색 결과가 오래된 이름을 계속 반영할 수 있다.

---

### 3.8 높음: `engram export --dir ...`가 실제 저장 위치를 바꾸지 못함

관련 파일:

- `engram/cli/app.py`
- `engram/engine.py`

문제:

- CLI는 `engine.config.export_dir_name = args.dir`만 바꾼다.
- 하지만 엔진 내부 exporter는 이미 초기화되어 있고, `export_markdown()`은 이를 재사용한다.

재현:

- `engram export --dir C:\tmp\custom-export`
- 출력 메시지는 custom-export로 저장했다고 표시
- 실제 파일은 기본 `readable/` 아래 생성

영향:

- CLI 출력과 실제 동작이 다르다.
- 사용자 입장에서는 export 경로를 신뢰할 수 없다.

---

### 3.9 중간: token budget 처리 때문에 결과 전체가 사라질 수 있음

관련 파일:

- `engram/search/fts5_search.py`

문제:

- 첫 번째 hit가 token budget을 넘으면 `break` 한다.
- 즉, 뒤에 더 짧은 hit가 있어도 확인조차 하지 않는다.

재현:

- 긴 상위 hit가 있는 상태에서 `max_tokens`를 작게 설정
- 결과: `total_count`는 1 이상인데 `hits`는 0

영향:

- "검색 결과는 있는데 아무것도 안 보이는" 현상이 생긴다.
- 에이전트 문맥 주입이나 축약 응답에서 품질 저하가 클 수 있다.

---

### 3.10 중간: `auto_resolve_threshold` 설정값은 여전히 사용되지 않음

관련 파일:

- `engram/quality/gate.py`
- `engram/quality/conflict.py`

문제:

- 설정 객체에는 `auto_resolve_threshold`가 있다.
- 하지만 실제 판정은 `trust_diff > 0.3` 하드코딩으로 이루어진다.

영향:

- 설정 파일/코드 상의 조절 가능성은 있지만 실제 동작은 고정돼 있다.
- 운영자가 정책을 바꾸고 싶어도 효과가 없다.

---

### 3.11 중간: entity state 동기화는 여전히 일부 predicate만 처리함

관련 파일:

- `engram/engine.py`

문제:

- `_sync_entity_state()`는 현재 `role`, `location`만 처리한다.
- `affiliation`이나 조직 소속처럼 자주 쓰이는 상태는 fact로만 남고 entity state에는 반영되지 않는다.

영향:

- `entity.state` 기반 출력/요약/검색 품질이 제한된다.
- 구조화된 상태 모델을 만들었지만 활용 범위가 아직 좁다.

---

### 3.12 중간: 한국어 2음절 이름 문제는 아직 남아 있음

관련 파일:

- `engram/extraction/ner/korean.py`
- `tests/test_extraction/test_ner/test_korean.py`

문제:

- fallback 규칙은 여전히 3음절 중심이다.
- `이준` 같은 2음절 이름은 테스트 기대와 달리 추출되지 않는다.

현재 상태:

- 전체 테스트의 유일한 실패가 이 항목이다.

---

## 4. 이번 리뷰에서 확인된 것

1차 리뷰에서 지적했던 일부 항목은 실제로 개선되어 있었다.

- `python -m engram`는 이제 `cli_entry()`를 통해 UTF-8 설정을 거친다.
- `get_entity()`와 `search()`는 엔진 레벨에서 session access 기록이 들어갔다.
- `search_backend`는 최소한 엔진 설정에 따라 객체를 고르는 수준까지는 연결됐다.
- `add_fact()`는 이제 accepted fact에 대해 state sync를 시도한다.

즉, 프로젝트가 정체된 상태는 아니다. 다만 이번 리뷰에서 확인된 문제들은 "핵심 기능 추가"보다 "끝까지 정합성 있게 마무리되지 않은 경로"에 더 가깝다.

---

## 5. 권장 수정 우선순위

### 1순위

- `resolve_conflict()`에서 winner fact를 실제 current 상태로 반영
- `merge` resolution을 진짜 의미 있는 동작으로 구현하거나 옵션에서 제거
- MCP 도구에 `session_id`를 일관되게 연결

### 2순위

- semantic/hybrid backend를 런타임 안전하게 정리
- semantic index 생성 경로를 실제 write path에 연결
- `maintenance()`가 fact 상태까지 제대로 정리하도록 수정

### 3순위

- merge 후 연관 엔티티까지 재색인
- `export --dir`가 실제 저장 위치를 바꾸도록 수정
- token budget 로직에서 oversize hit를 건너뛰고 다음 hit를 계속 보도록 수정

### 4순위

- `auto_resolve_threshold` 설정을 실제 conflict 로직과 연결
- `_sync_entity_state()` 범위를 확장
- 한국어 2음절 이름 정책을 테스트와 일치시키기

---

## 6. 결론

이번 2차 리뷰의 핵심은 다음이다.

- Engram은 전반적으로 개선 중이지만, 아직 "작동은 하는데 끝까지 정리되지는 않은" 경로가 남아 있다.
- 특히 conflict resolution, MCP session wiring, semantic backend, maintenance 정합성은 사용자가 실제로 믿고 쓰기 위해 반드시 정리돼야 한다.

현재 상태를 한 문장으로 요약하면 이렇다.

> 기본 기능은 상당 부분 갖추었지만, 고급 경로와 예외 경로에서 상태 일관성이 아직 완성되지 않았다.

이 문제들을 정리하면 Engram은 단순 저장소를 넘어, 실제 에이전트 메모리 시스템으로 더 안정적으로 쓸 수 있는 단계에 가까워질 것이다.
