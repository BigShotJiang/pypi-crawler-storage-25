# 16. Engram 3차 코드 리뷰 (2026-04-12)

> 검토 대상: `default/engram`
>
> 목적: 1차, 2차 리뷰 이후 현재 코드 기준으로 다시 확인하고, 이미 수정된 항목은 제외한 채 실제로 남아 있는 문제만 정리한다.

---

## 1. 검토 범위

이번 라운드에서는 다음 경로를 다시 확인했다.

- `engram/engine.py`
- `engram/quality/gate.py`
- `engram/search/fts5_search.py`
- `engram/models/search.py`
- `engram/storage/sqlite_store.py`
- `engram/extraction/ner/korean.py`

추가로 `pytest -q` 전체 테스트와 몇 가지 수동 재현 스크립트를 다시 실행했다.

---

## 2. 검증 결과 요약

### 전체 테스트

- 결과: `246 passed, 1 failed`
- 남은 실패:
  - `tests/test_extraction/test_ner/test_korean.py::TestKoreanPersonDetection::test_two_syllable_name`

### 이번 라운드에서 재확인한 항목

- `QualityGate.validate()` 부작용
- `resolve_conflict("accept_new")` 이후 entity state 정합성
- FTS snippet에 과거/충돌 fact가 섞이는 문제
- relation 저장 이후 FTS 미갱신 문제
- `SearchResult.to_agent_context()`의 token budget 처리

### 이전 리뷰 대비 해결된 것으로 확인한 항목

- MCP `session_id`는 현재 `memory_search`, `memory_store`, `memory_get_entity`까지 전달된다.
- `engram export --dir ...`는 현재 실제로 지정한 디렉터리에 export된다.
- `search_backend="semantic"`은 이 환경에서 FTS5로 fallback된다.

즉, 이번 문서는 과거 이슈 전체 재반복이 아니라 현재 코드 기준으로 남아 있는 문제만 다룬다.

---

## 3. 핵심 문제점

### 3.1 [P1] `QualityGate.validate()`가 검증 단계에서 이미 DB를 변경한다

관련 파일:

- `engram/quality/gate.py:88-129`

문제:

- `validate()`는 이름상 사전 검증 단계인데, `_try_auto_resolve()` 안에서 기존 fact를 바로 `retracted` 처리한다.
- 즉, 새 fact 저장이 아직 일어나지 않았는데도 기존 데이터가 먼저 바뀐다.

재현:

1. 수동으로 기존 role fact `Intern` 저장
2. 더 높은 신뢰도의 새 role fact `CEO` 생성
3. `gate.validate(new_fact)`만 호출
4. 결과:
   - 반환값은 `Action.ACCEPT`
   - DB 상태는 이미 `Intern -> retracted`
   - 새 fact는 아직 저장되지 않음

영향:

- 이후 저장 단계에서 예외가 나면 DB가 "기존 사실은 철회됐지만 새 사실은 없음" 상태로 남는다.
- 검증과 쓰기 사이에 원자성이 깨진다.

정리:

- auto-resolve는 `validate()` 안에서 영구 반영하면 안 된다.
- 검증은 "어떤 변경이 필요하다"만 반환하고, 실제 상태 전이는 저장 트랜잭션 안에서 처리해야 한다.

---

### 3.2 [P1] `accept_new`는 fact 상태는 바꾸지만 `entity.state`는 갱신하지 않아 카드 정보가 stale 상태로 남는다

관련 파일:

- `engram/engine.py:194-212`
- `engram/engine.py:471-500`

문제:

- `resolve_conflict(..., "accept_new")`는 기존 fact를 `retracted`로, 새 fact를 `unverified`로 바꾼다.
- 하지만 그 뒤에 `entity.state.role/location/affiliation`을 다시 동기화하지 않는다.
- `_sync_entity_state()`도 "비어 있을 때만" 채우는 구조라 기존 값이 있으면 새 사실로 덮어쓰지 않는다.

재현:

1. `Simon Kim is CEO` 저장
2. `CTO` role fact 추가 후 conflict 생성
3. `accept_new` 실행
4. 결과:
   - facts: `CEO -> retracted`, `CTO -> unverified`
   - `entity.state.role == "CEO"`

영향:

- 검색 결과, entity 상세 조회, Markdown state 블록이 실제 current fact와 어긋난다.
- 사용자는 충돌을 해결했는데 UI/컨텍스트에는 이전 역할이 남아 있는 상태를 보게 된다.

정리:

- conflict 해결 후에는 승자 fact 기준으로 `entity.state`를 재계산해야 한다.
- 현재 구조처럼 "빈 값만 채우는" 보조 함수로는 상태 변경 케이스를 처리할 수 없다.

---

### 3.3 [P1] FTS index와 snippet이 여전히 `conflicted`/`retracted` fact를 노출한다

관련 파일:

- `engram/storage/sqlite_store.py:634-666`
- `engram/search/fts5_search.py:77`
- `engram/search/fts5_search.py:165-173`

문제:

- 검색 결과의 structured facts는 `_get_entity_facts()`에서 `expired`, `retracted`, `conflicted`를 제외한다.
- 하지만 FTS 문서를 만들 때는 `_reindex_entity()`가 `self.get_facts(entity.id)`를 그대로 쓰고, `_index_entity()`도 상태 필터 없이 `raw_text`를 합친다.
- 그래서 snippet에는 이미 버려졌어야 할 문장이 그대로 들어간다.

재현 1:

1. `CEO` 저장
2. `CTO` 추가 후 unresolved conflict 상태 유지
3. `search("CTO")`
4. 결과:
   - structured facts: `CEO`만 반환
   - snippet: `CTO Simon Kim is CEO`

재현 2:

1. 같은 conflict에서 `accept_new` 실행
2. `search("CTO")`
3. 결과:
   - structured facts: `CTO`
   - snippet: 여전히 `Simon Kim is CEO` 포함

영향:

- 에이전트는 structured facts보다 snippet을 더 강하게 읽는 경우가 많다.
- 결과적으로 철회되었거나 아직 미해결인 사실이 검색 컨텍스트에 다시 유입된다.

정리:

- FTS `fact_text` 생성 시 current fact만 포함해야 한다.
- 그렇지 않으면 conflict 시스템과 검색 시스템이 서로 다른 진실을 보여준다.

---

### 3.4 [P2] relation 저장 시 FTS가 갱신되지 않아 relation 기반 검색이 바로 동작하지 않는다

관련 파일:

- `engram/storage/sqlite_store.py:390-406`
- `engram/storage/sqlite_store.py:634-666`
- `engram/engine.py:323`

문제:

- `_index_entity()`는 relation 대상 이름까지 `fact_text`에 넣어 relation 검색을 지원하도록 설계돼 있다.
- 그런데 `add_relation()`은 relation row만 insert하고 어떤 엔티티도 `_reindex_entity()`하지 않는다.
- `engine.store()`도 relation 저장 직후 재색인을 하지 않는다.

재현:

1. `Alice`, `Carol` 엔티티 생성
2. `Alice -KNOWS-> Carol` relation 저장
3. 바로 `search("KNOWS")`
4. 결과: `0 hits`
5. 이후 `engine.reindex()` 실행
6. 다시 `search("KNOWS")`
7. 결과: `Alice`, `Carol` 두 엔티티가 정상 검색됨

영향:

- relation은 DB에는 저장되지만 검색 계층에는 즉시 반영되지 않는다.
- 사용자는 방금 저장한 관계를 검색으로 다시 찾을 수 없다.

정리:

- relation 저장 후 최소한 양쪽 엔티티를 재색인해야 한다.
- 지금 구조는 relation 검색을 설계만 해 두고 write path에 연결하지 않은 상태다.

---

### 3.5 [P2] `SearchResult.to_agent_context()`는 hit가 있어도 빈 문자열을 반환할 수 있다

관련 파일:

- `engram/models/search.py:51-82`

문제:

- 첫 번째 hit의 예상 token 수가 예산을 넘으면 `break`로 즉시 종료한다.
- 이 경우 `hits`는 존재하지만 반환 문자열은 `""`가 된다.
- "결과가 없음"도 아니고, 일부라도 잘라서 주는 것도 아니라서 호출자 입장에서 해석하기 어렵다.

재현:

1. 긴 snippet을 가진 검색 결과 1건 생성
2. `search(..., max_tokens=500)`로 hit 1건 확보
3. 같은 결과 객체에 대해 `to_agent_context(max_tokens=1)` 또는 `to_agent_context(max_tokens=20)` 호출
4. 결과:
   - `hits == 1`
   - 반환값 `''`

영향:

- 상위 MCP/SDK 계층은 "검색은 성공했는데 컨텍스트 문자열은 빈 값"을 받게 된다.
- 사용자는 결과가 없다고 오해할 수 있고, 에이전트도 fallback 로직을 잘못 타게 된다.

정리:

- 첫 hit가 너무 크면 `break`가 아니라 축약 출력, `continue`, 혹은 최소 결과 보장 정책이 필요하다.

---

### 3.6 [P3] 한국어 2음절 이름 추출 회귀가 아직 남아 있다

관련 파일:

- `engram/extraction/ner/korean.py:117-129`
- `tests/test_extraction/test_ner/test_korean.py:17`

문제:

- bare-name fallback이 여전히 `len(name) == 3`에 묶여 있다.
- 그래서 `이준` 같은 2음절 이름은 title/context 패턴이 없으면 추출되지 않는다.

검증:

- `pytest -q` 전체 테스트에서 현재 유일한 실패가 이 케이스다.

영향:

- 한국어 인명 recall이 여전히 불안정하다.
- 특히 메신저, 회의 메모처럼 짧은 문장에서는 실제 체감 품질이 낮다.

---

## 4. 추가 관찰

이번 라운드에서 주된 finding으로 올리지는 않았지만, 코드상 추가로 주의할 만한 점은 있다.

- `HybridSearch`는 `index_entity()`를 구현하지 않는데, 일반 write path는 `hasattr(self.search_engine, "index_entity")`일 때만 semantic index를 갱신한다.
- 현재 환경에서는 `openai` 의존성이 없어 hybrid가 FTS5로 fallback되어 실동작 재현은 하지 못했지만, hybrid를 실제로 켜면 semantic 쪽 색인이 뒤처질 가능성이 있다.
- `engram/storage/migrations.py`의 `migrate()`는 현재 호출 경로를 찾지 못했다. 지금은 schema version이 `1`이라 바로 문제는 아니지만, 이후 스키마 변경 시 위험 요인이 될 수 있다.

이 둘은 "현재 재현 완료된 버그"라기보다는 "다음 변경에서 문제를 만들 가능성이 높은 구조"로 보는 편이 맞다.

---

## 5. 우선순위 제안

### 1순위

- `QualityGate.validate()`를 pure validation으로 되돌리고, auto-resolve 실제 반영은 저장 트랜잭션 안으로 이동
- conflict 해결 후 `entity.state` 재계산 로직 추가
- FTS 색인 생성 시 current fact만 포함하도록 정리

### 2순위

- relation 저장 후 양쪽 엔티티 FTS 재색인
- `to_agent_context()`의 최소 출력 보장 정책 정리

### 3순위

- 한국어 2음절 이름 정책 확정 후 NER 보정
- hybrid/semantic 색인 경로와 migration 경로 점검

---

## 6. 결론

이번 3차 리뷰 기준으로 Engram은 이전보다 정리된 부분이 분명 있다. 다만 아직 남아 있는 핵심 문제는 "검색과 상태 표현이 실제 current fact와 일치하지 않는 구간"에 모여 있다.

특히 다음 세 가지는 우선적으로 손봐야 한다.

1. 검증 단계에서 DB를 바꾸는 문제
2. conflict 해결 후 entity state가 stale 상태로 남는 문제
3. FTS snippet이 폐기된 사실을 다시 노출하는 문제

이 세 항목은 단순 품질 문제가 아니라, 에이전트가 잘못된 기억을 다시 읽게 만드는 경로이기 때문에 우선순위가 높다.
