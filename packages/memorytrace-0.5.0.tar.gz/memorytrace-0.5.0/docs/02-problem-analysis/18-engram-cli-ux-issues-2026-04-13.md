# 18. Engram CLI UX 문제 분석 — 실사용 기반 (2026-04-13)

> 대상: `default/engram/cli/simple.py`, `default/engram/engine.py`, `default/engram/storage/sqlite_store.py`
>
> 맥락: 종교앱 프로젝트에서 세션 간 컨텍스트 유지를 위해 engram을 실제 사용하면서 발견한 문제점을 정리한다. Claude Code 에이전트가 `engram save` / `engram find` / `engram recent` 명령을 반복 사용하는 워크플로우에서 관찰됨.

---

## 1. 문제 요약

| # | 문제 | 심각도 | 영향 |
|---|------|--------|------|
| 1 | `engram find` 결과 텍스트가 100자에서 잘림 | P1 | 이전 세션 컨텍스트 복구 실패 |
| 2 | `engram recent` 결과 텍스트가 120자에서 잘림 | P1 | 긴 세션 요약을 읽을 수 없음 |
| 3 | `engram save` 응답이 모호함 | P2 | 저장 성공 여부 확인 불가 |
| 4 | 중복 감지가 원본 note를 덮어쓰는 방식 | P2 | 의도치 않은 데이터 갱신 |
| 5 | `engram find`가 entity 중심이라 note 검색이 부차적 | P2 | 자유 텍스트 검색 약함 |

---

## 2. 문제 상세

### 2.1 `engram find` — 노트 텍스트 100자 잘림

**코드 위치**: `cli/simple.py:109`

```python
for n in result.notes:
    t = n['text']
    print(f"  [Note] {t[:100]}{'...' if len(t) > 100 else ''}")
```

**재현 시나리오**:
```bash
engram save "[종교앱] 디자인 적용 작업 진행중 (2026-04-13): design/ 폴더의 Figma Make 디자인(12개 화면)을 모바일 React Native로 변환 중. 완료: 1)ProfileScreen(확장판-통계+메뉴+게스트뷰) 2)ProfileEditScreen(신규) 3)MyReviewsScreen 4)AllReviewsScreen(신규). 남은 화면: ChurchDetailScreen, GameHomeScreen, SearchScreen 외 6개"

engram find "디자인 적용"
# 출력:
#   [Note] [종교앱] 디자인 적용 작업 진행중 (2026-04-13): design/ 폴더의 Figma Make 디자인(12개 화면)을 모바일 React Na...
```

**문제**: 100자 이후가 `...`으로 잘린다. 에이전트 입장에서 "완료된 화면 목록"과 "남은 화면 목록"이 보이지 않아 이전 세션 컨텍스트를 복구할 수 없다.

**영향**: 세션 시작 시 `engram find`로 이전 진행 상황을 파악하려 했으나, 핵심 정보(어디까지 했고 뭐가 남았는지)가 잘려서 결국 파일 시스템을 직접 탐색해야 했다.

---

### 2.2 `engram recent` — 노트 텍스트 120자 잘림

**코드 위치**: `cli/simple.py:181`

```python
for n in notes:
    ts = n["created_at"][:16].replace("T", " ")
    t = n["text"]
    print(f"  [{ts}] {t[:120]}{'...' if len(t) > 120 else ''}")
```

**문제**: `find`보다 20자 더 보여주지만 여전히 부족하다. 세션 요약 노트는 보통 200~400자인데, 절반 이상이 잘린다.

**비교**:

| 명령 | 잘림 기준 | 전형적 노트 길이 | 잘림 비율 |
|------|----------|----------------|----------|
| `find` | 100자 | 200~400자 | 50~75% 손실 |
| `recent` | 120자 | 200~400자 | 40~70% 손실 |

---

### 2.3 `engram save` — 응답 메시지가 모호함

**코드 위치**: `cli/simple.py:83-97`

```python
elif cmd == "save":
    result = engine.store(rest)
    created = [e.name for e in result.entities_created]
    updated = [e.name for e in result.entities_updated]
    if created:
        print(f"  New: {', '.join(created)}")
    if updated:
        print(f"  Updated: {', '.join(updated)}")
    if result.facts_added:
        print(f"  Learned {len(result.facts_added)} fact(s)")
    if not created and not updated and not result.facts_added:
        print("  Saved (no entities auto-detected)")
```

**재현**:
```bash
engram save "[종교앱] 디자인 적용 완료 (2026-04-13): 13개 화면 전체 변환 완료"
# 출력:
#   Updated: Figma Make, React Native
```

**문제 분석**:

1. **"Updated"가 의미하는 것**: NER이 텍스트에서 "Figma Make"와 "React Native"라는 엔티티를 추출하고, 이들이 이미 DB에 존재하므로 `entities_updated`에 추가된 것이다. 그러나 사용자/에이전트 입장에서는 "내 노트가 저장됐는지"가 중요하지 "Figma Make 엔티티가 업데이트됐는지"가 아니다.

2. **노트 저장 확인 없음**: `engine.store()` 내부에서 항상 `storage.add_note()`를 호출하여 원문이 note로 저장되지만(engine.py:370-373), CLI 출력에서는 note 저장 여부를 전혀 알려주지 않는다.

3. **혼란 유발 케이스**:
   - 엔티티가 추출된 경우: "New/Updated: ..." → 노트가 저장된 건지 엔티티가 추출된 건지 불분명
   - 엔티티가 없는 경우: "Saved (no entities auto-detected)" → 이 메시지가 상대적으로 나음
   - 중복 노트인 경우: 동일하게 "New/Updated" 출력 → 기존 노트가 덮어씌워졌는지 알 수 없음

---

### 2.4 중복 감지가 원본 note의 timestamp를 덮어씀

**코드 위치**: `storage/sqlite_store.py:514-523`

```python
if deduplicate:
    existing = self._find_duplicate_note(text)
    if existing:
        now = datetime.now().isoformat()
        self._conn.execute(
            "UPDATE notes SET created_at = ?, session_id = ? WHERE id = ?",
            (now, session_id, existing["id"]),
        )
        self._conn.commit()
        return existing["id"]
```

**문제**: 동일한 텍스트로 `save`하면 새 노트를 만들지 않고 기존 노트의 `created_at`과 `session_id`를 현재 시점으로 갱신한다. 이로 인해:

1. 원래 노트가 처음 작성된 시점(원본 타임스탬프)이 사라짐
2. `engram recent`에서 마치 방금 작성한 것처럼 보임
3. CLI에서는 새로 저장된 것과 구분 불가능 (동일한 출력)

---

### 2.5 `engram find`의 검색 우선순위 문제

**코드 위치**: `cli/simple.py:100-118`

```python
result = engine.search(rest)
if not result.hits:
    if hasattr(result, 'notes') and result.notes:
        for n in result.notes:
            ...
    else:
        print(f"  Nothing found for \"{rest}\"")
else:
    for h in result.hits:
        print(f"  {h.entity.name} ({h.entity.entity_type})")
        ...
```

**문제**: `find`는 엔티티 검색(`result.hits`)이 우선이다. note 검색(`result.notes`)은 엔티티가 없을 때만 fallback으로 보여준다.

에이전트의 전형적 사용 패턴은:
```bash
engram save "[프로젝트] 세션 요약: X 완성, Y 진행 중, Z 미시작"
# 다음 세션에서:
engram find "세션 요약"
```

이 경우 "세션 요약"이 엔티티 이름과 매칭되지 않으면 note fallback으로 가는데, 그마저도 100자 잘림 문제에 걸린다.

---

## 3. 개선 제안

### 3.1 즉시 수정 가능 (CLI만 변경)

#### A. 잘림 길이를 설정 가능하게

```python
# cli/simple.py - find
MAX_NOTE_PREVIEW = int(os.environ.get("ENGRAM_NOTE_PREVIEW", "300"))
print(f"  [Note] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")

# cli/simple.py - recent
print(f"  [{ts}] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")
```

기본값을 300자로 올리고, 환경변수로 조절 가능하게 한다. 에이전트 hook에서 `ENGRAM_NOTE_PREVIEW=500` 설정 가능.

#### B. save 출력에 note 저장 확인 추가

```python
elif cmd == "save":
    result = engine.store(rest)
    # 항상 노트 저장됨을 먼저 알려줌
    print(f"  ✓ Note saved ({len(rest)} chars)")
    # 그 다음 엔티티 추출 결과
    if created:
        print(f"  Entities new: {', '.join(created)}")
    if updated:
        print(f"  Entities updated: {', '.join(updated)}")
```

#### C. `find` 명령에 `--full` 플래그 추가

```python
elif cmd in ("find", "search"):
    full = "--full" in args
    # ...
    for n in result.notes:
        t = n['text']
        if full:
            print(f"  [Note] {t}")
        else:
            print(f"  [Note] {t[:MAX_NOTE_PREVIEW]}...")
```

### 3.2 설계 수준 개선 (engine 변경 필요)

#### D. 중복 note 처리 개선

현재: 동일 텍스트 → timestamp 갱신 (원본 손실)
제안: 동일 텍스트 → 새 저장 스킵 + CLI에 "이미 저장된 노트입니다" 표시

```python
def add_note(self, ..., deduplicate=True) -> tuple[str, bool]:
    """Returns (note_id, is_new)."""
    if deduplicate:
        existing = self._find_duplicate_note(text)
        if existing:
            return existing["id"], False  # 기존 ID, 신규 아님
    ...
    return note_id, True
```

#### E. note 전용 검색 명령 추가

```bash
engram notes "검색어"         # note만 검색 (entity 스킵)
engram notes --full "검색어"  # 전체 텍스트 출력
```

현재 `find`는 entity 우선 → note fallback 구조인데, 에이전트가 세션 요약을 찾을 때는 note 직접 검색이 더 적합하다.

---

## 4. 에이전트 워크플로우에서의 실제 영향

### 영향받은 시나리오 (2026-04-13 실제 발생)

```
1. 이전 세션에서 engram save로 디자인 작업 진행 상황 저장
2. 새 세션 시작 → engram find "디자인 적용" 실행
3. 결과: "design/ 폴더의 Figma Make 디자인(12개 화면)을 모바일 React Na..."
4. 핵심 정보(완료 화면 목록, 남은 화면)가 잘려서 보이지 않음
5. 결국 git status, ls, 파일 직접 읽기로 컨텍스트 복구
6. engram의 세션 연속성 목적이 달성되지 않음
```

### 우회 방법 (현재 가능)

1. **짧은 노트 여러 개로 분할 저장**: 100자 이내 단위로 쪼개면 잘리지 않음
2. **engram json find "검색어"로 JSON 출력 사용**: `result.notes`에 전체 텍스트가 포함될 수 있음
3. **파일 시스템 직접 확인**: engram 대신 git status/diff로 컨텍스트 파악

---

## 5. 우선순위 정리

| 순위 | 수정 | 난이도 | 기대 효과 |
|------|------|--------|----------|
| 1 | 잘림 길이 300자로 증가 | 1줄 수정 | 세션 요약의 대부분이 보임 |
| 2 | save 출력에 note 확인 추가 | 3줄 추가 | 저장 성공 여부 명확 |
| 3 | `--full` 플래그 | 5줄 추가 | 필요시 전체 텍스트 확인 가능 |
| 4 | note 전용 검색 명령 | 20줄 추가 | 에이전트 워크플로우 최적화 |
| 5 | 중복 note 처리 개선 | engine 수정 | 데이터 무결성 향상 |

---

## 부록: 관련 코드 참조

| 파일 | 라인 | 역할 |
|------|------|------|
| `cli/simple.py:109` | find → note 출력 (100자 잘림) |
| `cli/simple.py:181` | recent → note 출력 (120자 잘림) |
| `cli/simple.py:83-97` | save → 응답 메시지 로직 |
| `engine.py:370-373` | store() → 항상 note 저장 |
| `storage/sqlite_store.py:507-523` | add_note → 중복 감지 + timestamp 갱신 |
| `storage/sqlite_store.py:584-601` | search_notes → FTS5 검색 (전체 텍스트 반환) |
