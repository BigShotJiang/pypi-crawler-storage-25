# Engram Docs

Main documentation index for setup notes, usage guides, and internal design records.

## User Docs

| Document | Summary |
|------|------|
| [Quickstart](./04-usage-guide/01-quickstart.md) | Install, initialize, and use the main CLI and SDK quickly. |
| [Claude Code / Codex Setup](./04-usage-guide/02-claude-code-setup.md) | Notes for using Engram from agent-driven environments. |
| [CLI Commands](./01-project-analysis/05-cli-commands.md) | Current `engram` and `engram-advanced` command surface. |
| [Setup Guide](./01-project-analysis/09-setup-guide.md) | Development setup, extras, and local environment notes. |

## Design and Plans

| Document | Summary |
|------|------|
| [23-engram-next-capabilities-roadmap-2026-04-16.md](./03-improvement-plan/23-engram-next-capabilities-roadmap-2026-04-16.md) | Capability roadmap after the core memory phases. |
| [2026-04-16-backlinks-decisions-maintenance-design.md](./superpowers/specs/2026-04-16-backlinks-decisions-maintenance-design.md) | Backlinks, decisions, and maintenance design. |
| [2026-04-16-backlinks-decisions-maintenance.md](./superpowers/plans/2026-04-16-backlinks-decisions-maintenance.md) | Backlinks, decisions, and maintenance implementation plan. |
| [2026-04-16-goal-aware-retrieval-reranking.md](./superpowers/plans/2026-04-16-goal-aware-retrieval-reranking.md) | Goal-aware retrieval and reranking plan. |
| [2026-04-16-phase0-provenance-trace.md](./superpowers/plans/2026-04-16-phase0-provenance-trace.md) | Phase 0 evaluation baseline and provenance trace plan. |
| [2026-04-16-phase0-provenance-trace-design.md](./superpowers/specs/2026-04-16-phase0-provenance-trace-design.md) | Phase 0 evaluation baseline and provenance trace design. |
| [2026-04-16-freshness-verification-design.md](./superpowers/specs/2026-04-16-freshness-verification-design.md) | Freshness and verification workflow design. |
| [2026-04-16-freshness-verification.md](./superpowers/plans/2026-04-16-freshness-verification.md) | Freshness and verification workflow implementation plan. |
| [2026-04-16-entity-governance-design.md](./superpowers/specs/2026-04-16-entity-governance-design.md) | Entity governance design. |
| [2026-04-16-entity-governance.md](./superpowers/plans/2026-04-16-entity-governance.md) | Entity governance implementation plan. |
| [2026-04-16-governance-split-merge-recommendations-design.md](./superpowers/specs/2026-04-16-governance-split-merge-recommendations-design.md) | Split governance candidates and merge recommendation design. |
| [2026-04-16-governance-split-merge-recommendations.md](./superpowers/plans/2026-04-16-governance-split-merge-recommendations.md) | Split governance candidates and merge recommendation implementation plan. |
| [2026-04-16-follow-up-task-recommendations-design.md](./superpowers/specs/2026-04-16-follow-up-task-recommendations-design.md) | Follow-up task recommendation design. |
| [2026-04-16-follow-up-task-recommendations.md](./superpowers/plans/2026-04-16-follow-up-task-recommendations.md) | Follow-up task recommendation implementation plan. |
| [2026-04-16-retention-recommendations-design.md](./superpowers/specs/2026-04-16-retention-recommendations-design.md) | Retention policies and first-batch recommendation triggers design. |
| [2026-04-16-retention-recommendations.md](./superpowers/plans/2026-04-16-retention-recommendations.md) | Retention policies and first-batch recommendation triggers implementation plan. |
| [2026-04-16-scoped-memory-job-runner-design.md](./superpowers/specs/2026-04-16-scoped-memory-job-runner-design.md) | Scoped memory and async job runner design. |
| [2026-04-16-scoped-memory-job-runner.md](./superpowers/plans/2026-04-16-scoped-memory-job-runner.md) | Scoped memory and async job runner implementation plan. |
| [2026-04-16-projection-reranking-phase1-design.md](./superpowers/specs/2026-04-16-projection-reranking-phase1-design.md) | Projection and reranking phase 1 design. |
| [2026-04-16-projection-reranking-phase1.md](./superpowers/plans/2026-04-16-projection-reranking-phase1.md) | Projection and reranking phase 1 implementation plan. |
