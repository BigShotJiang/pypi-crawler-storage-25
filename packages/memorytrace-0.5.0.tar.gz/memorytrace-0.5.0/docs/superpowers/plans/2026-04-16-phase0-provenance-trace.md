# Phase 0 and Provenance Trace Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a shared explanation contract for search, briefs, decisions, backlinks, and maintenance views, then lock it down with explanation-focused golden scenarios.

**Architecture:** Add one reusable explanation model and one small builder layer, then wire search and read-path adapters onto it without changing canonical storage. Keep legacy search explanation fields for compatibility while introducing `explanation` as the preferred interface.

**Tech Stack:** Python 3.9+, dataclasses, SQLite-backed Engram services, pytest

---

## File Map

- Create: `engram/models/explanation.py`
- Create: `engram/models/view.py`
- Create: `engram/explanations/__init__.py`
- Create: `engram/explanations/builder.py`
- Modify: `engram/models/search.py`
- Modify: `engram/models/brief.py`
- Modify: `engram/engine.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/maintenance/service.py`
- Modify: `tests/fixtures/retrieval_scenarios.py`
- Create: `tests/fixtures/explanation_scenarios.py`
- Create: `tests/test_explanations/test_builder.py`
- Modify: `tests/test_search/test_reranker.py`
- Modify: `tests/test_session/test_brief.py`
- Modify: `tests/test_engine.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

## Task 1: Add Shared Explanation Models

**Files:**
- Create: `engram/models/explanation.py`
- Create: `engram/models/view.py`
- Test: `tests/test_explanations/test_builder.py`

- [ ] **Step 1: Write the failing model serialization test**

```python
from engram.models.explanation import (
    EvidenceRef,
    ExplanationBundle,
    ExplanationFactor,
    ProvenanceTrace,
    ProvenanceReason,
)


def test_explanation_bundle_serializes_nested_objects() -> None:
    bundle = ExplanationBundle(
        summary="Matched active entity memory.",
        trace=ProvenanceTrace(
            retriever="fts5_bm25",
            query="alice project",
            base_score=2.5,
            snippet="Alice owns the roadmap.",
            matched_fact_ids=["fact-1"],
            reasons=[ProvenanceReason(kind="bm25", detail="Matched alice")],
        ),
        factors=[
            ExplanationFactor(
                name="active_entity_boost",
                stage="rerank",
                delta=0.4,
                reason="Entity is active in working memory",
            )
        ],
        evidence=[
            EvidenceRef(
                kind="fact",
                id="fact-1",
                label="Alice owns the roadmap",
                snippet="Alice owns the roadmap.",
                entity_id="entity-1",
                source_kind="note",
                source_id="note-1",
            )
        ],
        warnings=[],
    )

    payload = bundle.to_dict()

    assert payload["summary"] == "Matched active entity memory."
    assert payload["trace"]["query"] == "alice project"
    assert payload["factors"][0]["name"] == "active_entity_boost"
    assert payload["evidence"][0]["kind"] == "fact"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_explanations/test_builder.py::test_explanation_bundle_serializes_nested_objects -q`
Expected: FAIL with `ModuleNotFoundError` or missing symbol errors for `engram.models.explanation`

- [ ] **Step 3: Write minimal explanation models**

```python
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ProvenanceReason:
    kind: str
    detail: str

    def to_dict(self) -> dict:
        return {"kind": self.kind, "detail": self.detail}


@dataclass
class ProvenanceTrace:
    retriever: str
    query: str = ""
    base_score: float = 0.0
    snippet: str = ""
    matched_fact_ids: list[str] = field(default_factory=list)
    reasons: list[ProvenanceReason] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "retriever": self.retriever,
            "query": self.query,
            "base_score": self.base_score,
            "snippet": self.snippet,
            "matched_fact_ids": list(self.matched_fact_ids),
            "reasons": [reason.to_dict() for reason in self.reasons],
        }


@dataclass
class ExplanationFactor:
    name: str
    stage: str
    delta: float
    reason: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "stage": self.stage,
            "delta": self.delta,
            "reason": self.reason,
        }


@dataclass
class EvidenceRef:
    kind: str
    id: str
    label: str
    snippet: str = ""
    entity_id: Optional[str] = None
    source_kind: Optional[str] = None
    source_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "id": self.id,
            "label": self.label,
            "snippet": self.snippet,
            "entity_id": self.entity_id,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
        }


@dataclass
class ExplanationBundle:
    summary: str
    trace: Optional[ProvenanceTrace] = None
    factors: list[ExplanationFactor] = field(default_factory=list)
    evidence: list[EvidenceRef] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "trace": self.trace.to_dict() if self.trace else None,
            "factors": [factor.to_dict() for factor in self.factors],
            "evidence": [evidence.to_dict() for evidence in self.evidence],
            "warnings": list(self.warnings),
        }
```

- [ ] **Step 4: Add lightweight read views**

```python
from __future__ import annotations

from dataclasses import dataclass

from engram.models.decision import DecisionRecord
from engram.models.explanation import ExplanationBundle
from engram.models.maintenance import MaintenanceRun, MaintenanceRunItem


@dataclass
class DecisionView:
    decision: DecisionRecord
    explanation: ExplanationBundle

    def to_dict(self) -> dict:
        return {
            "decision": self.decision.to_dict(),
            "explanation": self.explanation.to_dict(),
        }


@dataclass
class MaintenanceItemView:
    item: MaintenanceRunItem
    explanation: ExplanationBundle

    def to_dict(self) -> dict:
        return {
            "item": self.item.to_dict(),
            "explanation": self.explanation.to_dict(),
        }


@dataclass
class MaintenanceRunView:
    run: MaintenanceRun
    items: list[MaintenanceItemView]

    def to_dict(self) -> dict:
        return {
            "run": self.run.to_dict(),
            "items": [item.to_dict() for item in self.items],
        }
```

- [ ] **Step 5: Run test to verify it passes**

Run: `python -m pytest tests/test_explanations/test_builder.py::test_explanation_bundle_serializes_nested_objects -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add engram/models/explanation.py engram/models/view.py tests/test_explanations/test_builder.py
git commit -m "feat: add shared explanation models"
```

## Task 2: Add Explanation Builder and Search Wiring

**Files:**
- Create: `engram/explanations/__init__.py`
- Create: `engram/explanations/builder.py`
- Modify: `engram/models/search.py`
- Modify: `engram/engine.py`
- Modify: `tests/test_search/test_reranker.py`

- [ ] **Step 1: Write the failing search explanation test**

```python
from engram.models.search import SearchOptions


def test_search_hit_exposes_explanation_bundle(engine_with_retrieval_data) -> None:
    result = engine_with_retrieval_data.search(
        "alice roadmap",
        SearchOptions(query="alice roadmap", max_results=5),
    )

    hit = result.hits[0]

    assert hit.explanation.summary
    assert hit.explanation.trace is not None
    assert any(factor.name == "active_entity_boost" for factor in hit.explanation.factors)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_search/test_reranker.py::test_search_hit_exposes_explanation_bundle -q`
Expected: FAIL with missing `explanation` on `SearchHit`

- [ ] **Step 3: Add the explanation builder**

```python
from __future__ import annotations

from engram.models.explanation import (
    EvidenceRef,
    ExplanationBundle,
    ExplanationFactor,
    ProvenanceTrace,
)
from engram.models.search import RankingFactor, SearchHit


class ExplanationBuilder:
    def from_search_hit(self, query: str, hit: SearchHit) -> ExplanationBundle:
        factors = [
            ExplanationFactor(
                name=factor.name,
                stage="rerank",
                delta=factor.delta,
                reason=factor.reason,
            )
            for factor in hit.ranking_factors
        ]
        evidence = [
            EvidenceRef(
                kind="fact",
                id=fact.id,
                label=fact.raw_text,
                snippet=fact.raw_text,
                entity_id=fact.entity_id,
                source_kind=fact.source.type.value if fact.source else None,
                source_id=fact.source.uri if fact.source else None,
            )
            for fact in hit.facts
        ]
        trace = ProvenanceTrace(
            retriever=hit.provenance.retriever,
            query=query,
            base_score=hit.base_score,
            snippet=hit.provenance.snippet,
            matched_fact_ids=list(hit.provenance.matched_fact_ids),
            reasons=list(hit.provenance.reasons),
        )
        summary = f"Retrieved {hit.entity.name} via {trace.retriever}."
        return ExplanationBundle(
            summary=summary,
            trace=trace,
            factors=factors,
            evidence=evidence,
            warnings=[],
        )
```

- [ ] **Step 4: Add `explanation` to search models and engine output**

```python
@dataclass
class SearchHit:
    entity: Entity
    facts: list[Fact] = field(default_factory=list)
    relevance_score: float = 0.0
    base_score: float = 0.0
    snippet: str = ""
    token_count: int = 0
    ranking_factors: list[RankingFactor] = field(default_factory=list)
    provenance: ProvenanceTrace = field(default_factory=ProvenanceTrace)
    explanation: ExplanationBundle = field(
        default_factory=lambda: ExplanationBundle(summary="")
    )
```

```python
result = self.search_engine.search(options)
result = self.reranking_service.rerank(result, context)
for hit in result.hits:
    hit.explanation = self._explanation_builder.from_search_hit(query, hit)
```

- [ ] **Step 5: Run focused tests**

Run: `python -m pytest tests/test_search/test_reranker.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add engram/explanations/__init__.py engram/explanations/builder.py engram/models/search.py engram/engine.py tests/test_search/test_reranker.py
git commit -m "feat: add search explanation bundles"
```

## Task 3: Add Brief, Decision, Backlink, and Maintenance Explanations

**Files:**
- Modify: `engram/models/brief.py`
- Modify: `engram/engine.py`
- Modify: `engram/maintenance/service.py`
- Modify: `tests/test_session/test_brief.py`
- Modify: `tests/test_engine.py`
- Modify: `tests/test_cli/test_app.py`

- [ ] **Step 1: Write failing brief and decision view tests**

```python
def test_entity_brief_supporting_hit_contains_explanation(engine_with_retrieval_data) -> None:
    brief = engine_with_retrieval_data.entity_brief("Alice")

    assert brief is not None
    assert brief.supporting_hits
    assert brief.supporting_hits[0].explanation.summary


def test_get_decision_returns_decision_view(engine_with_decision_data) -> None:
    decision = engine_with_decision_data.list_decisions(limit=1)[0]
    decision_view = engine_with_decision_data.get_decision(decision.id)

    assert decision_view is not None
    assert decision_view.explanation.evidence
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_session/test_brief.py::test_entity_brief_supporting_hit_contains_explanation tests/test_engine.py::test_get_decision_returns_decision_view -q`
Expected: FAIL because `SupportingHit` and decision responses do not expose shared explanation bundles

- [ ] **Step 3: Add explanation to supporting hits and projection read paths**

```python
@dataclass
class SupportingHit:
    entity_id: str
    entity_name: str
    entity_type: str
    relevance_score: float
    snippet: str = ""
    explanation: ExplanationBundle = field(
        default_factory=lambda: ExplanationBundle(summary="")
    )
```

```python
def _to_supporting_hits(result, limit: int = 3) -> list[SupportingHit]:
    hits: list[SupportingHit] = []
    for hit in result.hits[:limit]:
        hits.append(
            SupportingHit(
                entity_id=hit.entity.id,
                entity_name=hit.entity.name,
                entity_type=hit.entity.entity_type,
                relevance_score=hit.relevance_score,
                snippet=hit.snippet,
                explanation=hit.explanation,
            )
        )
    return hits
```

```python
def get_decision(self, decision_id: str) -> Optional[DecisionView]:
    row = self.decision_service.get_decision(decision_id)
    if row is None:
        return None
    explanation = self._explanation_builder.for_decision(row)
    return DecisionView(decision=row, explanation=explanation)
```

- [ ] **Step 4: Add backlink and maintenance explanations**

```python
def backlinks(self, name: str, source_kind: Optional[str] = None, limit: int = 50) -> list[dict]:
    rows = self.reference_service.backlinks(name, source_kind=source_kind, limit=limit)
    return [
        {
            **row,
            "explanation": self._explanation_builder.for_backlink(name, row).to_dict(),
        }
        for row in rows
    ]
```

```python
def get_maintenance_run(self, run_id: str) -> Optional[MaintenanceRunView]:
    run = self._maintenance_service().get_run(run_id)
    if run is None:
        return None
    item_views = [
        MaintenanceItemView(
            item=item,
            explanation=self._explanation_builder.for_maintenance_item(item),
        )
        for item in run.items
    ]
    return MaintenanceRunView(run=run, items=item_views)
```

- [ ] **Step 5: Run focused tests**

Run: `python -m pytest tests/test_session/test_brief.py tests/test_engine.py tests/test_cli/test_app.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add engram/models/brief.py engram/engine.py engram/maintenance/service.py tests/test_session/test_brief.py tests/test_engine.py tests/test_cli/test_app.py
git commit -m "feat: add projection and brief explanations"
```

## Task 4: Add Phase 0 Golden Scenarios and Parity Checks

**Files:**
- Create: `tests/fixtures/explanation_scenarios.py`
- Modify: `tests/fixtures/retrieval_scenarios.py`
- Modify: `tests/test_explanations/test_builder.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

- [ ] **Step 1: Write the failing parity tests**

```python
def test_cli_search_json_includes_explanation(cli_runner, seeded_db_path) -> None:
    result = cli_runner(["--db", str(seeded_db_path), "--json", "search", "alice roadmap"])

    payload = json.loads(result.stdout)

    assert payload["hits"][0]["explanation"]["summary"]
    assert "evidence" in payload["hits"][0]["explanation"]


def test_backlinks_json_includes_explanation(cli_runner, seeded_db_path) -> None:
    result = cli_runner(["--db", str(seeded_db_path), "--json", "backlinks", "Alice"])

    payload = json.loads(result.stdout)

    assert payload[0]["explanation"]["summary"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_cli/test_app.py::test_cli_search_json_includes_explanation tests/test_cli/test_app.py::test_backlinks_json_includes_explanation -q`
Expected: FAIL because CLI payloads do not serialize the new explanation contract everywhere yet

- [ ] **Step 3: Add fixture helpers and parity assertions**

```python
def assert_explanation_bundle(payload: dict) -> None:
    assert payload["summary"] is not None
    assert "factors" in payload
    assert "evidence" in payload
    assert "warnings" in payload
```

```python
def test_search_hit_to_dict_includes_explanation_bundle(...) -> None:
    result = engine.search("alice roadmap")
    hit = result.to_dict()["hits"][0]
    assert_explanation_bundle(hit["explanation"])
```

- [ ] **Step 4: Run scenario bundle and full suite**

Run: `python -m pytest tests/test_explanations/test_builder.py tests/test_search/test_reranker.py tests/test_session/test_brief.py tests/test_engine.py tests/test_cli/test_app.py -q`
Expected: PASS

Run: `python -m pytest tests -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/fixtures/explanation_scenarios.py tests/fixtures/retrieval_scenarios.py tests/test_explanations/test_builder.py tests/test_cli/test_app.py docs/README.md
git commit -m "test: add provenance trace golden scenarios"
```

## Task 5: Verification and Review Preparation

**Files:**
- Modify: none unless failures require fixes
- Test: full regression bundle

- [ ] **Step 1: Run compile verification**

Run: `python -m compileall engram tests`
Expected: success with no syntax errors

- [ ] **Step 2: Run diff hygiene**

Run: `git diff --check`
Expected: no whitespace errors

- [ ] **Step 3: Run targeted integration bundle**

Run: `python -m pytest tests/test_search tests/test_session/test_brief.py tests/test_engine.py tests/test_cli/test_app.py tests/test_quality/test_diagnostics.py -q`
Expected: PASS

- [ ] **Step 4: Run full suite**

Run: `python -m pytest tests -q`
Expected: PASS

- [ ] **Step 5: Commit any final verification-driven fix**

```bash
git add -A
git commit -m "fix: stabilize provenance trace integration"
```
