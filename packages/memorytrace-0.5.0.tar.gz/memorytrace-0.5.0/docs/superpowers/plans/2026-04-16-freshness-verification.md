# Freshness and Verification Workflow Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add persisted freshness metadata and a verification backlog so facts and decisions can become due, stale, revalidated, and surfaced consistently across search, decision lookup, diagnostics, maintenance, and CLI.

**Architecture:** Extend the SQLite schema with freshness columns on `facts`/`decisions` plus a `verification_requests` backlog table, then add a focused `FreshnessService` that owns assessment, deduped request creation, and resolution. Read paths remain best-effort and explanation-driven: search, briefs, and decision views attach freshness warnings and penalties without becoming dependent on successful queue writes.

**Tech Stack:** Python 3.9+, sqlite3, dataclasses, existing `MemoryEngine` / `SQLiteStorage` / `Diagnostics` architecture, pytest, argparse CLI.

---

## File Structure

- Create: `engram/models/verification.py`
- Create: `engram/freshness/__init__.py`
- Create: `engram/freshness/service.py`
- Modify: `engram/models/fact.py`
- Modify: `engram/models/decision.py`
- Modify: `engram/models/health.py`
- Modify: `engram/models/view.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/base.py`
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/search/reranker.py`
- Modify: `engram/search/fts5_search.py`
- Modify: `engram/explanations/builder.py`
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/maintenance/service.py`
- Modify: `engram/engine.py`
- Modify: `engram/cli/app.py`
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_freshness/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_cli/test_app.py`

## Task 1: Add Freshness Schema and Models

**Files:**
- Create: `engram/models/verification.py`
- Modify: `engram/models/fact.py`
- Modify: `engram/models/decision.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/base.py`
- Test: `tests/test_storage/test_migrations.py`

- [ ] **Step 1: Write the failing migration tests**

```python
def test_storage_initialize_adds_fact_freshness_columns(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    with sqlite3.connect(db_path) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(facts)")}
        assert "verification_status" in columns
        assert "last_verified_at" in columns
        assert "verification_due_at" in columns


def test_storage_initialize_adds_decision_freshness_and_request_table(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    with sqlite3.connect(db_path) as conn:
        decision_columns = {row[1] for row in conn.execute("PRAGMA table_info(decisions)")}
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        assert "verification_status" in decision_columns
        assert "verification_due_at" in decision_columns
        assert "verification_requests" in tables
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_adds_fact_freshness_columns tests/test_storage/test_migrations.py::test_storage_initialize_adds_decision_freshness_and_request_table -q`  
Expected: `FAIL` because schema version 7 does not add freshness columns or `verification_requests`.

- [ ] **Step 3: Add minimal models and migration v8**

```python
class VerificationStatus(str, Enum):
    UNKNOWN = "unknown"
    PENDING = "pending"
    VERIFIED = "verified"
    STALE = "stale"


class VerificationRequestStatus(str, Enum):
    OPEN = "open"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"


class VerificationResolution(str, Enum):
    VERIFIED = "verified"
    STALE = "stale"
    RETRACTED = "retracted"
    SUPERSEDED = "superseded"
```

```python
CURRENT_VERSION = 8

def _migrate_v7_to_v8(conn: sqlite3.Connection) -> None:
    if not _column_exists(conn, "facts", "verification_status"):
        conn.execute(
            "ALTER TABLE facts ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'unknown'"
        )
    if not _column_exists(conn, "facts", "last_verified_at"):
        conn.execute("ALTER TABLE facts ADD COLUMN last_verified_at TEXT")
    if not _column_exists(conn, "facts", "verification_due_at"):
        conn.execute("ALTER TABLE facts ADD COLUMN verification_due_at TEXT")
    if not _column_exists(conn, "decisions", "verification_status"):
        conn.execute(
            "ALTER TABLE decisions ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'unknown'"
        )
    if not _column_exists(conn, "decisions", "last_verified_at"):
        conn.execute("ALTER TABLE decisions ADD COLUMN last_verified_at TEXT")
    if not _column_exists(conn, "decisions", "verification_due_at"):
        conn.execute("ALTER TABLE decisions ADD COLUMN verification_due_at TEXT")
    conn.executescript(
        '''
        CREATE TABLE IF NOT EXISTS verification_requests (
            id TEXT PRIMARY KEY,
            target_kind TEXT NOT NULL CHECK(target_kind IN ('fact','decision')),
            target_id TEXT NOT NULL,
            entity_id TEXT,
            scope_id TEXT,
            reason TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('open','resolved','cancelled')),
            requested_by TEXT NOT NULL,
            resolution TEXT,
            detail TEXT NOT NULL DEFAULT '',
            requested_at TEXT NOT NULL,
            resolved_at TEXT,
            metadata TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_verification_requests_status
            ON verification_requests(status, requested_at DESC);
        CREATE INDEX IF NOT EXISTS idx_verification_requests_target
            ON verification_requests(target_kind, target_id, status);
        '''
    )
```

- [ ] **Step 4: Run migration tests to verify they pass**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_adds_fact_freshness_columns tests/test_storage/test_migrations.py::test_storage_initialize_adds_decision_freshness_and_request_table -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/models/verification.py engram/models/fact.py engram/models/decision.py engram/storage/migrations.py engram/storage/base.py tests/test_storage/test_migrations.py
git commit -m "feat: add freshness schema primitives"
```

## Task 2: Add FreshnessService and Storage Helpers

**Files:**
- Create: `engram/freshness/__init__.py`
- Create: `engram/freshness/service.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_freshness/test_service.py`

- [ ] **Step 1: Write the failing service tests**

```python
def test_ensure_fact_request_dedupes_open_request(engine):
    engine.create_entity("Alice")
    result = engine.add_fact("Alice", "Alice leads platform work", predicate="role")
    fact = result.fact
    service = FreshnessService(engine.storage, engine.decay_policy)

    first = service.ensure_fact_request(fact, reason="verify_on_read", requested_by="test")
    second = service.ensure_fact_request(fact, reason="verify_on_read", requested_by="test")

    assert first is not None
    assert second is not None
    assert first.id == second.id


def test_resolve_request_marks_decision_verified(engine):
    session = engine.start_session("codex")
    engine.end_session(session.session_id, summary="We decided to ship the fix.")
    decision = engine.list_decisions()[0]
    service = FreshnessService(engine.storage, engine.decay_policy)
    request = service.ensure_decision_request(decision, reason="decision_read", requested_by="test")

    resolved = service.resolve_request(request.id, VerificationResolution.VERIFIED)
    refreshed = engine.decision_service.get_decision(decision.id)

    assert resolved.status is VerificationRequestStatus.RESOLVED
    assert refreshed.verification_status is VerificationStatus.VERIFIED
    assert refreshed.verification_due_at is not None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_freshness/test_service.py -q`  
Expected: `FAIL` because the service and storage helpers do not exist.

- [ ] **Step 3: Implement storage helpers and `FreshnessService`**

```python
class FreshnessService:
    def assess_fact(self, fact: Fact) -> FreshnessAssessment:
        ...

    def ensure_fact_request(self, fact: Fact, reason: str, requested_by: str) -> VerificationRequest | None:
        ...

    def resolve_request(
        self,
        request_id: str,
        resolution: VerificationResolution,
        detail: str = "",
    ) -> VerificationRequest:
        ...
```

```python
def create_verification_request(self, request: VerificationRequest) -> VerificationRequest:
    ...

def find_open_verification_request(self, target_kind: str, target_id: str) -> VerificationRequest | None:
    ...

def update_fact_freshness(...):
    ...
```

- [ ] **Step 4: Run service tests to verify they pass**

Run: `python -m pytest tests/test_freshness/test_service.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/freshness/__init__.py engram/freshness/service.py engram/storage/sqlite_store.py tests/test_freshness/test_service.py
git commit -m "feat: add freshness service and verification backlog"
```

## Task 3: Wire Search, Brief, and Decision Reads

**Files:**
- Modify: `engram/search/reranker.py`
- Modify: `engram/search/fts5_search.py`
- Modify: `engram/explanations/builder.py`
- Modify: `engram/models/view.py`
- Modify: `engram/engine.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing read-path tests**

```python
def test_search_applies_stale_penalty_and_opens_request(engine):
    engine.create_entity("Alice")
    fact = engine.storage.add_fact(
        Fact(
            entity_id=engine.get_entity("Alice").id,
            subject="Alice",
            predicate="role",
            object="platform lead",
            raw_text="Alice leads platform work.",
            source=Source(type=SourceType.USER_INPUT),
        )
    )
    engine.storage.update_fact_freshness(
        fact.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    result = engine.search("platform work")

    assert result.hits
    assert any(f.name == "freshness_penalty" for f in result.hits[0].ranking_factors)
    requests = engine.list_verification_requests()
    assert len(requests) == 1


def test_get_decision_adds_freshness_warning(engine):
    session = engine.start_session("codex")
    engine.end_session(session.session_id, summary="We decided to ship the fix.")
    decision = engine.list_decisions()[0]
    engine.storage.update_decision_freshness(
        decision.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    payload = engine.get_decision(decision.id)

    assert payload is not None
    assert payload.explanation.warnings
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_engine.py::test_search_applies_stale_penalty_and_opens_request tests/test_engine.py::test_get_decision_adds_freshness_warning -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement read-path freshness hooks**

```python
assessment = self.freshness_service.assess_fact(fact)
if assessment.penalty:
    hit.ranking_factors.append(
        RankingFactor("freshness_penalty", assessment.penalty, assessment.reason)
    )
if assessment.should_open_request:
    self.freshness_service.ensure_fact_request(
        fact,
        reason="verify_on_read",
        requested_by="search",
    )
```

```python
if assessment.warning:
    explanation = self.explanation_builder.for_decision(row)
    explanation.warnings.append(assessment.warning)
```

- [ ] **Step 4: Run read-path tests to verify they pass**

Run: `python -m pytest tests/test_engine.py::test_search_applies_stale_penalty_and_opens_request tests/test_engine.py::test_get_decision_adds_freshness_warning -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/search/reranker.py engram/search/fts5_search.py engram/explanations/builder.py engram/models/view.py engram/engine.py tests/test_engine.py
git commit -m "feat: wire freshness into read paths"
```

## Task 4: Extend Diagnostics and Maintenance Views

**Files:**
- Modify: `engram/models/health.py`
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/maintenance/service.py`
- Modify: `engram/engine.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing diagnostics tests**

```python
def test_health_report_flags_verification_backlog(engine):
    engine.create_entity("Alice")
    result = engine.add_fact("Alice", "Alice leads platform work", predicate="role")
    engine.request_fact_verification(result.fact.id, reason="manual", requested_by="test")

    report = engine.health_report()

    assert any(metric.name == "verification_backlog_count" for metric in report.metrics)
    assert any(loop.kind.value == "verification_backlog" for loop in report.open_loops)


def test_health_report_flags_stale_decision(engine):
    session = engine.start_session("codex")
    engine.end_session(session.session_id, summary="We decided to ship the fix.")
    decision = engine.list_decisions()[0]
    engine.storage.update_decision_freshness(
        decision.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    report = engine.health_report()

    assert any(metric.name == "stale_decision_count" for metric in report.metrics)
    assert any(loop.kind.value == "stale_decision" for loop in report.open_loops)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_quality/test_diagnostics.py::test_health_report_flags_verification_backlog tests/test_quality/test_diagnostics.py::test_health_report_flags_stale_decision -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement metrics and maintenance visibility**

```python
class LoopKind(str, Enum):
    ...
    VERIFICATION_BACKLOG = "verification_backlog"
    STALE_DECISION = "stale_decision"
```

```python
verification_metric, verification_loops = self._verification_backlog(max_open_loops)
stale_decision_metric, stale_decision_loops = self._stale_decisions(max_open_loops)
metrics.extend([verification_metric, stale_decision_metric])
loops.extend(verification_loops)
loops.extend(stale_decision_loops)
```

- [ ] **Step 4: Run diagnostics tests and maintenance regression**

Run: `python -m pytest tests/test_quality/test_diagnostics.py tests/test_engine.py::test_run_maintenance_persists_run -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/models/health.py engram/quality/diagnostics.py engram/maintenance/service.py engram/engine.py tests/test_quality/test_diagnostics.py tests/test_engine.py
git commit -m "feat: expose freshness backlog in diagnostics"
```

## Task 5: Add CLI Surface and Regression Bundle

**Files:**
- Modify: `engram/cli/app.py`
- Test: `tests/test_cli/test_app.py`
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_freshness/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_quality/test_diagnostics.py`

- [ ] **Step 1: Write the failing CLI tests**

```python
def test_verification_request_and_list(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "create", "Alice"])
    main(["--db", use_tmp_db, "--json", "add-fact", "Alice", "Alice leads platform work"])
    payload = json.loads(capsys.readouterr().out)
    fact_id = payload["fact"]["id"]

    main(["--db", use_tmp_db, "--json", "verification-request", "fact", fact_id])
    request = json.loads(capsys.readouterr().out)
    assert request["target_kind"] == "fact"

    main(["--db", use_tmp_db, "--json", "verification-list"])
    rows = json.loads(capsys.readouterr().out)
    assert rows


def test_verification_resolve_updates_status(use_tmp_db, capsys):
    ...
    main(["--db", use_tmp_db, "--json", "verification-resolve", request_id, "verified"])
    resolved = json.loads(capsys.readouterr().out)
    assert resolved["status"] == "resolved"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_cli/test_app.py::test_verification_request_and_list tests/test_cli/test_app.py::test_verification_resolve_updates_status -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement verification CLI handlers**

```python
p = sub.add_parser("verification-request", help="Open a verification request")
p.add_argument("target_kind", choices=["fact", "decision"])
p.add_argument("target_id")
p.add_argument("--reason", default="manual")
```

```python
elif args.command == "verification-resolve":
    request = engine.resolve_verification_request(
        args.request_id,
        args.resolution,
        detail=args.detail,
    )
```

- [ ] **Step 4: Run focused regression bundle**

Run: `python -m pytest tests/test_storage/test_migrations.py tests/test_freshness/test_service.py tests/test_engine.py tests/test_quality/test_diagnostics.py tests/test_cli/test_app.py -q`  
Expected: `PASS`

- [ ] **Step 5: Run full suite and commit**

Run: `python -m pytest tests -q`  
Expected: `PASS`

```bash
git add engram/cli/app.py tests/test_cli/test_app.py tests/test_storage/test_migrations.py tests/test_freshness/test_service.py tests/test_engine.py tests/test_quality/test_diagnostics.py
git commit -m "feat: add freshness verification workflow"
```

## Self-Review

- Spec coverage:
  - freshness columns and request queue: Task 1
  - service design and dedupe/resolution: Task 2
  - read-path penalties/warnings and verify-on-read: Task 3
  - diagnostics and maintenance visibility: Task 4
  - CLI inspection and resolution flow: Task 5
- Placeholder scan: no `TODO`, `TBD`, or deferred implementation markers remain.
- Type consistency:
  - `VerificationStatus`, `VerificationRequestStatus`, and `VerificationResolution` are introduced before later tasks use them.
  - storage helper names used by engine/CLI are established in Task 2 before later tasks depend on them.
