# Retention Policies and Recommendation Triggers Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add persisted retention policies plus first-batch computed recommendations so Engram can deliberately preserve memory, hide archival content from default retrieval, and surface actionable stale-decision and open-loop escalation guidance.

**Architecture:** Add a new `retention_policies` table and a focused `RetentionService` for policy CRUD and lookups. Add a computed `RecommendationService` that derives views from freshness and maintenance state, then wire policy enforcement into search and brief paths and expose both layers through engine and CLI.

**Tech Stack:** Python 3.9+, SQLite migrations, dataclass models, existing `MemoryEngine` / CLI / pytest stack

---

## File Map

- Create: `engram/models/retention.py`
- Create: `engram/retention/__init__.py`
- Create: `engram/retention/service.py`
- Create: `engram/recommendations/__init__.py`
- Create: `engram/recommendations/service.py`
- Create: `tests/test_retention/test_service.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/engine.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/session/brief.py`
- Modify: `tests/test_storage/test_migrations.py`
- Modify: `tests/test_engine.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

### Task 1: Add retention schema and model contracts

**Files:**
- Create: `engram/models/retention.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_storage/test_migrations.py`

- [ ] **Step 1: Write the failing migration test**

```python
def test_storage_initialize_adds_retention_policy_table(self, tmp_path: Path) -> None:
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()

    try:
        tables = {
            row[0]
            for row in storage._conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            ).fetchall()
        }
        assert "retention_policies" in tables
        assert get_schema_version(storage._conn) == CURRENT_VERSION
    finally:
        storage.close()
```

- [ ] **Step 2: Run the test to verify RED**

Run: `python -m pytest tests/test_storage/test_migrations.py::TestFullStackMigration::test_storage_initialize_adds_retention_policy_table -q`

Expected: FAIL because `retention_policies` does not exist yet.

- [ ] **Step 3: Add the minimal schema + model surface**

```python
# engram/models/retention.py
class RetentionTargetKind(str, Enum):
    ENTITY = "entity"
    FACT = "fact"
    DECISION = "decision"
    NOTE = "note"
    SESSION = "session"


class RetentionPolicyType(str, Enum):
    PIN = "pin"
    TTL = "ttl"
    ARCHIVE_ONLY = "archive_only"
    NEVER_SUMMARIZE = "never_summarize"


@dataclass
class RetentionPolicy:
    target_kind: RetentionTargetKind
    target_id: str
    policy_type: RetentionPolicyType
    value: Optional[str] = None
    reason: str = ""
```

```python
# engram/storage/migrations.py
CURRENT_VERSION = 10

def _migrate_v9_to_v10(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS retention_policies (
            id TEXT PRIMARY KEY,
            target_kind TEXT NOT NULL,
            target_id TEXT NOT NULL,
            policy_type TEXT NOT NULL,
            value TEXT,
            reason TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_retention_policies_target_type
            ON retention_policies(target_kind, target_id, policy_type);
        CREATE INDEX IF NOT EXISTS idx_retention_policies_target
            ON retention_policies(target_kind, target_id);
        """
    )
```

- [ ] **Step 4: Run the test to verify GREEN**

Run: `python -m pytest tests/test_storage/test_migrations.py::TestFullStackMigration::test_storage_initialize_adds_retention_policy_table -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add engram/models/retention.py engram/storage/migrations.py engram/storage/sqlite_store.py tests/test_storage/test_migrations.py
git commit -m "feat: retention policy schema 추가"
```

### Task 2: Add retention storage + service CRUD

**Files:**
- Create: `engram/retention/__init__.py`
- Create: `engram/retention/service.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_retention/test_service.py`

- [ ] **Step 1: Write the failing service tests**

```python
def test_set_and_clear_retention_policy(storage):
    from engram.retention.service import RetentionService
    from engram.models.retention import RetentionPolicyType, RetentionTargetKind

    service = RetentionService(storage)
    policy = service.set_policy(
        target_kind=RetentionTargetKind.FACT,
        target_id="fact-1",
        policy_type=RetentionPolicyType.PIN,
        reason="keep this forever",
    )

    assert service.is_pinned(RetentionTargetKind.FACT, "fact-1") is True
    cleared = service.clear_policy(
        RetentionTargetKind.FACT,
        "fact-1",
        RetentionPolicyType.PIN,
    )
    assert cleared is True
    assert service.is_pinned(RetentionTargetKind.FACT, "fact-1") is False
```

```python
def test_ttl_policy_round_trips_as_datetime(storage):
    from engram.retention.service import RetentionService
    from engram.models.retention import RetentionPolicyType, RetentionTargetKind

    service = RetentionService(storage)
    service.set_policy(
        target_kind=RetentionTargetKind.DECISION,
        target_id="decision-1",
        policy_type=RetentionPolicyType.TTL,
        value="2026-05-01T00:00:00",
        reason="revisit in may",
    )

    ttl = service.get_ttl(RetentionTargetKind.DECISION, "decision-1")
    assert ttl is not None
    assert ttl.isoformat() == "2026-05-01T00:00:00"
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_retention/test_service.py -q`

Expected: FAIL because the service and storage helpers do not exist yet.

- [ ] **Step 3: Write minimal storage and service code**

```python
# engram/storage/sqlite_store.py
def upsert_retention_policy(self, policy: RetentionPolicy) -> RetentionPolicy: ...
def clear_retention_policy(self, target_kind: str, target_id: str, policy_type: str) -> bool: ...
def list_retention_policies(... ) -> list[RetentionPolicy]: ...
def get_retention_policy(... ) -> Optional[RetentionPolicy]: ...
def get_retention_policies_for_target(... ) -> list[RetentionPolicy]: ...
```

```python
# engram/retention/service.py
class RetentionService:
    def set_policy(... ) -> RetentionPolicy: ...
    def clear_policy(... ) -> bool: ...
    def list_policies(... ) -> list[RetentionPolicy]: ...
    def get_policies_for_target(... ) -> list[RetentionPolicy]: ...
    def is_pinned(... ) -> bool: ...
    def is_archive_only(... ) -> bool: ...
    def is_never_summarize(... ) -> bool: ...
    def get_ttl(... ) -> Optional[datetime]: ...
```

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_retention/test_service.py tests/test_storage/test_migrations.py -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add engram/retention engram/models/retention.py engram/storage/sqlite_store.py tests/test_retention/test_service.py tests/test_storage/test_migrations.py
git commit -m "feat: retention policy CRUD 추가"
```

### Task 3: Enforce retention in search and brief flows

**Files:**
- Modify: `engram/engine.py`
- Modify: `engram/session/brief.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing engine tests**

```python
def test_search_excludes_archive_only_fact(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns the alpha plan", predicate="role")
    fact = engine.get_facts("Alice")[0]
    engine.set_retention_policy("fact", fact.id, "archive_only", reason="historical")

    result = engine.search("alpha plan")

    assert result.total_count == 0
```

```python
def test_entity_brief_excludes_never_summarize_fact(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice carries a temporary credential", predicate="note")
    fact = engine.get_facts("Alice")[0]
    engine.set_retention_policy("fact", fact.id, "never_summarize", reason="sensitive")

    brief = engine.entity_brief("Alice")

    assert brief is not None
    assert brief.top_facts == []
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_engine.py::TestEngineSearch::test_search_excludes_archive_only_fact tests/test_engine.py::TestEngineMaintenance::test_entity_brief_excludes_never_summarize_fact -q`

Expected: FAIL because the engine does not apply retention filters yet.

- [ ] **Step 3: Implement minimal enforcement**

```python
# engram/engine.py
def _apply_retention_to_search_result(self, result: SearchResult, options: SearchOptions) -> SearchResult: ...
def _apply_retention_to_entity_brief(self, brief: EntityBrief) -> EntityBrief: ...
def _apply_retention_to_session_brief(self, brief: SessionBrief) -> SessionBrief: ...
```

Rules:
- drop `archive_only` entities/facts/notes from default search unless `options.include_archived`
- drop `never_summarize` facts/notes from brief summary-facing lists
- keep explicit inspection APIs unchanged

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_engine.py -k "archive_only or never_summarize" -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add engram/engine.py engram/session/brief.py tests/test_engine.py
git commit -m "feat: retention policy를 검색과 brief에 반영"
```

### Task 4: Add computed recommendation service

**Files:**
- Create: `engram/recommendations/__init__.py`
- Create: `engram/recommendations/service.py`
- Modify: `engram/engine.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing recommendation tests**

```python
def test_list_recommendations_emits_stale_decision(engine):
    from datetime import datetime
    from engram.models.decision import DecisionRecord, DecisionStatus

    decision = DecisionRecord(
        title="Ship the fix",
        summary="We decided to ship the fix.",
        status=DecisionStatus.ACTIVE,
        confidence=0.9,
        source_kind="session",
        source_id="session-1",
        fingerprint="decision-retention-1",
        created_at=datetime.now(),
        indexed_at=datetime.now(),
    )
    engine.storage.replace_decisions("session", "session-1", [decision])
    engine.storage.update_decision_freshness(
        decision.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    rows = engine.list_recommendations()

    assert any(row.kind.value == "stale_decision" for row in rows)
```

```python
def test_open_loop_escalation_requires_repeat_run(engine):
    engine.create_entity("Lonely")
    engine.run_maintenance()
    engine.run_maintenance()

    rows = engine.list_recommendations()

    assert any(row.kind.value == "open_loop_escalation" for row in rows)
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_engine.py -k "stale_decision or open_loop_escalation" -q`

Expected: FAIL because recommendation APIs do not exist yet.

- [ ] **Step 3: Implement minimal computed recommendation views**

```python
# engram/recommendations/service.py
class RecommendationService:
    def list_recommendations(... ) -> list[RecommendationView]: ...
    def get_recommendation(... ) -> RecommendationView | None: ...
```

Behavior:
- `stale_decision`: stale or overdue decision, no open verification request, not pinned
- `open_loop_escalation`: same loop key repeats across recent maintenance runs or remains old enough to escalate

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_engine.py -k "stale_decision or open_loop_escalation" -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add engram/recommendations engram/engine.py tests/test_engine.py
git commit -m "feat: recommendation 계산 서비스 추가"
```

### Task 5: Expose retention and recommendations through CLI

**Files:**
- Modify: `engram/cli/app.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

- [ ] **Step 1: Write the failing CLI tests**

```python
def test_retention_set_and_list(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "create", "Alice"])
    capsys.readouterr()

    main(["--db", use_tmp_db, "--json", "retention-set", "entity", "Alice", "pin", "--reason", "keep"])
    payload = json.loads(capsys.readouterr().out)
    assert payload["policy_type"] == "pin"

    main(["--db", use_tmp_db, "--json", "retention-list", "--target-kind", "entity"])
    rows = json.loads(capsys.readouterr().out)
    assert rows
```

```python
def test_recommendations_command_returns_stale_decision(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    # seed stale decision through the engine-backed debug path
    ...
    main(["--db", use_tmp_db, "--json", "recommendations"])
    rows = json.loads(capsys.readouterr().out)
    assert any(row["kind"] == "stale_decision" for row in rows)
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_cli/test_app.py -k "retention or recommendations" -q`

Expected: FAIL because CLI commands do not exist yet.

- [ ] **Step 3: Implement minimal CLI surface**

```python
# engram/cli/app.py
sub.add_parser("retention-list", ...)
sub.add_parser("retention-set", ...)
sub.add_parser("retention-clear", ...)
sub.add_parser("recommendations", ...)
sub.add_parser("recommendation-show", ...)
```

And wire them to:
- `engine.set_retention_policy`
- `engine.clear_retention_policy`
- `engine.list_retention_policies`
- `engine.list_recommendations`
- `engine.get_recommendation`

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_cli/test_app.py -k "retention or recommendations" -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add engram/cli/app.py tests/test_cli/test_app.py docs/README.md
git commit -m "feat: retention과 recommendation CLI 추가"
```

### Task 6: Final regression bundle

**Files:**
- Modify as needed: touched files from Tasks 1-5
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_retention/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Run the focused regression bundle**

Run:

```bash
python -m pytest tests/test_storage/test_migrations.py tests/test_retention/test_service.py tests/test_engine.py tests/test_cli/test_app.py -q
```

Expected: all PASS

- [ ] **Step 2: Run the full test suite**

Run:

```bash
python -m pytest tests -q
```

Expected: full suite PASS with no new failures

- [ ] **Step 3: Commit final cleanup**

```bash
git add engram docs tests
git commit -m "feat: retention policy와 recommendation 1차 완성"
```
