# Scoped Memory and Job Runner Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add first-class scope-aware memory plus a persisted job runner that moves projection and maintenance work out of canonical write paths.

**Architecture:** Extend SQLite schema with scope and job tables, then layer small scope/job services under the existing engine. Canonical writes attach `scope_id` and enqueue follow-up jobs. Reads stay synchronous and become scope-aware through filtering and reranking rather than a full FTS redesign.

**Tech Stack:** Python 3.9+, sqlite3, existing dataclass models, pytest, current `MemoryEngine` / `SQLiteStorage` architecture.

---

## File Structure

- Create: `engram/models/scope.py`
- Create: `engram/models/job.py`
- Create: `engram/scopes/__init__.py`
- Create: `engram/scopes/service.py`
- Create: `engram/jobs/__init__.py`
- Create: `engram/jobs/service.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/base.py`
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/models/search.py`
- Modify: `engram/models/brief.py`
- Modify: `engram/explanations/builder.py`
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/engine.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/integrations/mcp_server.py`
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_scopes/test_service.py`
- Test: `tests/test_jobs/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_session/test_brief.py`
- Test: `tests/test_cli/test_app.py`
- Test: `tests/test_quality/test_diagnostics.py`

### Task 1: Add Scope and Job Schema + Models

**Files:**
- Create: `engram/models/scope.py`
- Create: `engram/models/job.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/base.py`
- Test: `tests/test_storage/test_migrations.py`

- [ ] **Step 1: Write the failing migration tests**

```python
def test_storage_initialize_creates_scope_and_job_tables(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    with sqlite3.connect(db_path) as conn:
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            ).fetchall()
        }
        assert "memory_scopes" in tables
        assert "jobs" in tables


def test_storage_initialize_adds_scope_columns(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    with sqlite3.connect(db_path) as conn:
        fact_cols = {row[1] for row in conn.execute("PRAGMA table_info(facts)")}
        note_cols = {row[1] for row in conn.execute("PRAGMA table_info(notes)")}
        assert "scope_id" in fact_cols
        assert "scope_id" in note_cols
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_creates_scope_and_job_tables tests/test_storage/test_migrations.py::test_storage_initialize_adds_scope_columns -q`  
Expected: `FAIL` because schema version 6 does not create scope/job tables or `scope_id` columns.

- [ ] **Step 3: Add minimal models and migration v7**

```python
@dataclass
class MemoryScope:
    id: str
    kind: str
    name: str
    path: str
    parent_scope_id: str | None = None
    status: str = "active"
    metadata: dict = field(default_factory=dict)


@dataclass
class JobRecord:
    id: str
    job_type: str
    status: str
    payload: dict = field(default_factory=dict)
```

```python
CURRENT_VERSION = 7

def _migrate_v6_to_v7(conn: sqlite3.Connection) -> None:
    conn.executescript(
        \"\"\"
        CREATE TABLE IF NOT EXISTS memory_scopes (...);
        CREATE TABLE IF NOT EXISTS jobs (...);
        ALTER TABLE facts ADD COLUMN scope_id TEXT;
        ALTER TABLE notes ADD COLUMN scope_id TEXT;
        \"\"\"
    )
```

- [ ] **Step 4: Run migration tests to verify they pass**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_creates_scope_and_job_tables tests/test_storage/test_migrations.py::test_storage_initialize_adds_scope_columns -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/models/scope.py engram/models/job.py engram/storage/migrations.py engram/storage/base.py tests/test_storage/test_migrations.py
git commit -m "feat: add scope and job schema primitives"
```

### Task 2: Add ScopeService and JobRunnerService

**Files:**
- Create: `engram/scopes/service.py`
- Create: `engram/jobs/service.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_scopes/test_service.py`
- Test: `tests/test_jobs/test_service.py`

- [ ] **Step 1: Write failing service tests**

```python
def test_scope_service_creates_hierarchical_scope(storage):
    service = ScopeService(storage)
    workspace = service.create("workspace", "engram")
    project = service.create("project", "phase-2", parent_scope_id=workspace.id)
    resolved = service.resolve_selection(
        ScopeSelection(primary_scope_id=project.id, include_ancestors=True)
    )
    assert workspace.id in resolved.allowed_scope_ids
    assert project.id in resolved.allowed_scope_ids


def test_job_runner_retries_and_dead_letters(storage):
    runner = JobRunnerService(storage)
    job = runner.enqueue("rebuild_references", {"source_kind": "note"}, max_attempts=2)
    runner.mark_failed(job.id, "boom")
    runner.mark_failed(job.id, "boom-again")
    stored = runner.get(job.id)
    assert stored.status == "dead_letter"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_scopes/test_service.py tests/test_jobs/test_service.py -q`  
Expected: `FAIL` because services and storage helpers do not exist.

- [ ] **Step 3: Implement storage helpers and services**

```python
class ScopeService:
    def create(self, kind: str, name: str, parent_scope_id: str | None = None, metadata: dict | None = None) -> MemoryScope:
        ...

    def resolve_selection(self, selection: ScopeSelection | None) -> ResolvedScope:
        ...
```

```python
class JobRunnerService:
    def enqueue(self, job_type: str, payload: dict, max_attempts: int = 3) -> JobRecord:
        ...

    def lease(self, limit: int, lease_owner: str) -> list[JobRecord]:
        ...
```

- [ ] **Step 4: Run service tests to verify they pass**

Run: `python -m pytest tests/test_scopes/test_service.py tests/test_jobs/test_service.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/scopes/__init__.py engram/scopes/service.py engram/jobs/__init__.py engram/jobs/service.py engram/storage/sqlite_store.py tests/test_scopes/test_service.py tests/test_jobs/test_service.py
git commit -m "feat: add scope and job services"
```

### Task 3: Wire Scoped Writes and Async Projection Jobs

**Files:**
- Modify: `engram/engine.py`
- Modify: `engram/models/source.py`
- Modify: `engram/intake/service.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write failing engine tests for scoped writes**

```python
def test_store_enqueues_index_job_for_scoped_note(engine):
    scope = engine.create_scope("project", "alpha")
    engine.store("Alice owns Alpha.", scope_id=scope.id)
    jobs = engine.list_jobs(job_type="index_source")
    assert jobs
    assert jobs[0].payload["scope_id"] == scope.id


def test_end_session_keeps_session_scope(engine):
    scope = engine.create_scope("task", "handoff")
    session = engine.start_session("agent-x", scope_id=scope.id)
    engine.end_session(session.session_id, summary="Wrapped handoff")
    saved = engine.storage.get_session(session.session_id)
    assert saved.scope_id == scope.id
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_engine.py::test_store_enqueues_index_job_for_scoped_note tests/test_engine.py::test_end_session_keeps_session_scope -q`  
Expected: `FAIL` because scope-aware writes and job enqueueing are not wired.

- [ ] **Step 3: Implement minimal scoped write wiring**

```python
def store(self, text: str, source: Source | None = None, session_id: str | None = None, scope_id: str | None = None) -> StoreResult:
    ...
    self.storage.add_note(note_id, text, source.type.value, session_id, scope_id=scope_id)
    self.job_runner.enqueue("index_source", {"source_kind": "note", "source_id": note_id, "scope_id": scope_id})
```

```python
def end_session(self, session_id: str, summary: str | None = None) -> Session:
    ...
    if session.summary:
        self.job_runner.enqueue("index_source", {"source_kind": "session", "source_id": session.session_id, "scope_id": session.scope_id})
```

- [ ] **Step 4: Run engine tests to verify they pass**

Run: `python -m pytest tests/test_engine.py::test_store_enqueues_index_job_for_scoped_note tests/test_engine.py::test_end_session_keeps_session_scope -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/engine.py engram/models/source.py engram/intake/service.py tests/test_engine.py
git commit -m "feat: wire scoped writes and async projection jobs"
```

### Task 4: Add Scope-Aware Reads and Explanations

**Files:**
- Modify: `engram/models/search.py`
- Modify: `engram/models/brief.py`
- Modify: `engram/search/reranker.py`
- Modify: `engram/search/fts5_search.py`
- Modify: `engram/explanations/builder.py`
- Modify: `engram/engine.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_session/test_brief.py`

- [ ] **Step 1: Write failing read-path tests**

```python
def test_search_filters_hits_outside_scope(engine):
    alpha = engine.create_scope("project", "alpha")
    beta = engine.create_scope("project", "beta")
    engine.store("Alice owns Alpha roadmap.", scope_id=alpha.id)
    engine.store("Alice owns Beta roadmap.", scope_id=beta.id)
    result = engine.search("Alice roadmap", scope_selection=ScopeSelection(primary_scope_id=alpha.id))
    assert all(hit.explanation.summary for hit in result.hits)
    assert all("beta" not in hit.snippet.lower() for hit in result.hits)


def test_session_brief_supporting_hits_respect_scope(engine):
    scope = engine.create_scope("task", "handoff")
    session = engine.start_session("agent-x", scope_id=scope.id)
    engine.store("Daisy handles handoff.", session_id=session.session_id, scope_id=scope.id)
    brief = engine.session_brief(session.session_id, scope_selection=ScopeSelection(primary_scope_id=scope.id))
    assert brief.supporting_hits
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_engine.py::test_search_filters_hits_outside_scope tests/test_session/test_brief.py::test_session_brief_supporting_hits_respect_scope -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement scope filtering and explanation factors**

```python
@dataclass
class ScopeSelection:
    primary_scope_id: str | None = None
    include_ancestors: bool = False
    include_global: bool = True
    fallback_scope_ids: list[str] = field(default_factory=list)
```

```python
if resolved_scope and hit_has_exact_scope:
    factors.append(RankingFactor("scope_match", 0.35, "hit has evidence in the selected scope"))
elif resolved_scope and not hit_has_allowed_scope:
    continue
```

- [ ] **Step 4: Run read-path tests to verify they pass**

Run: `python -m pytest tests/test_engine.py::test_search_filters_hits_outside_scope tests/test_session/test_brief.py::test_session_brief_supporting_hits_respect_scope -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/models/search.py engram/models/brief.py engram/search/reranker.py engram/search/fts5_search.py engram/explanations/builder.py engram/engine.py tests/test_engine.py tests/test_session/test_brief.py
git commit -m "feat: add scope-aware reads and explanations"
```

### Task 5: Add Scope and Job CLI Surface

**Files:**
- Modify: `engram/cli/app.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Write failing CLI tests**

```python
def test_scope_create_and_list(use_tmp_db, capsys):
    assert main(["--db", use_tmp_db, "--json", "scope-create", "project", "alpha"]) == 0
    main(["--db", use_tmp_db, "--json", "scope-list"])
    payload = json.loads(capsys.readouterr().out)
    assert payload[0]["kind"] == "project"


def test_jobs_run_executes_queued_jobs(use_tmp_db):
    main(["--db", use_tmp_db, "store", "Alice owns roadmap.", "--scope", "scope-missing"])
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_cli/test_app.py::test_scope_create_and_list tests/test_cli/test_app.py::test_jobs_run_executes_queued_jobs -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement CLI parsers and handlers**

```python
p = sub.add_parser("scope-create", help="Create a memory scope")
p.add_argument("kind")
p.add_argument("name")

p = sub.add_parser("jobs-run", help="Run queued jobs")
p.add_argument("--limit", type=int, default=20)
```

```python
elif args.command == "jobs-run":
    result = engine.run_jobs(limit=args.limit)
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else f"  Ran {result['completed']} jobs.")
```

- [ ] **Step 4: Run CLI tests to verify they pass**

Run: `python -m pytest tests/test_cli/test_app.py::test_scope_create_and_list tests/test_cli/test_app.py::test_jobs_run_executes_queued_jobs -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/cli/app.py tests/test_cli/test_app.py
git commit -m "feat: add scope and job runner CLI commands"
```

### Task 6: Add Diagnostics and Regression Coverage

**Files:**
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/maintenance/service.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Write failing diagnostics tests**

```python
def test_health_report_flags_failed_jobs(engine):
    job = engine.enqueue_job("rebuild_projections", {})
    engine.job_runner.mark_failed(job.id, "boom")
    report = engine.health_report()
    assert any(loop.kind.value == "projection_drift" for loop in report.open_loops)


def test_maintenance_run_includes_job_backlog(engine):
    engine.enqueue_job("maintenance_run", {})
    run = engine.run_maintenance()
    assert any(item.kind == "projection_drift" for item in run.items)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_quality/test_diagnostics.py::test_health_report_flags_failed_jobs tests/test_engine.py::test_maintenance_run_includes_job_backlog -q`  
Expected: `FAIL`

- [ ] **Step 3: Implement job-aware diagnostics**

```python
failed_jobs = self.storage.list_jobs(status="failed", limit=max_loops)
for job in failed_jobs:
    loops.append(OpenLoop(kind=LoopKind.PROJECTION_DRIFT, title=f"Failed job: {job.job_type}", ...))
```

- [ ] **Step 4: Run focused regression bundle**

Run: `python -m pytest tests/test_storage/test_migrations.py tests/test_scopes/test_service.py tests/test_jobs/test_service.py tests/test_engine.py tests/test_session/test_brief.py tests/test_cli/test_app.py tests/test_quality/test_diagnostics.py -q`  
Expected: `PASS`

- [ ] **Step 5: Run full suite and commit**

Run: `python -m pytest tests -q`  
Expected: `PASS`

```bash
git add engram/quality/diagnostics.py engram/maintenance/service.py tests/test_quality/test_diagnostics.py tests/test_engine.py tests/test_cli/test_app.py
git commit -m "feat: integrate scoped memory diagnostics and job backlog"
```

## Self-Review

- Spec coverage:
  - scope model/schema: Tasks 1-2
  - scoped writes: Task 3
  - scoped reads and explanations: Task 4
  - CLI surface: Task 5
  - diagnostics and maintenance visibility: Task 6
- Placeholder scan: no `TODO`, `TBD`, or deferred code placeholders remain.
- Type consistency:
  - `ScopeSelection`, `MemoryScope`, and `JobRecord` are introduced before later tasks use them.
  - Engine APIs referenced in later tasks are declared in earlier tasks.
