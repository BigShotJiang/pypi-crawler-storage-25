# Goal-Aware Retrieval / Context-Aware Reranking Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a context-aware reranking layer that turns Engram search from plain BM25 retrieval into goal-aware retrieval for search, brief, and agent context assembly.

**Architecture:** Keep `FTS5Search` as the fast base retriever and add a separate reranking layer on top. The reranker consumes a structured `RetrievalContext`, applies explicit scoring factors, emits explanations, and is wired into `MemoryEngine.search()` plus the brief entrypoints without changing canonical storage semantics.

**Tech Stack:** Python 3.9+, existing `MemoryEngine`, SQLite-backed storage, dataclass models, pytest unit/integration coverage, current worktree baseline `codex/backlinks-decisions-maintenance`.

---

## File Map

### New Files

- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/search/reranker.py`
  - `RerankingService`
  - goal presets and explicit scoring factors
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_search/test_reranker.py`
  - unit coverage for factor scoring and explanation output
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/fixtures/retrieval_scenarios.py`
  - stable retrieval scenarios used by engine and brief tests

### Modified Files

- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/models/search.py`
  - `RetrievalContext`, `RankingFactor`, richer `SearchHit`/`SearchOptions`
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/engine.py`
  - build retrieval context, invoke reranker, expose explanations
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/models/brief.py`
  - optional supporting retrieval hits in brief payloads
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/session/brief.py`
  - no ranking logic, but brief builder accepts reranked support hits from engine
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_engine.py`
  - end-to-end reranking behavior
- `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_session/test_brief.py`
  - brief integration with reranked supporting hits

### Non-Goals for This Plan

- No task/channel/agent persistent memory tables yet
- No graph traversal yet
- No applicability conditions yet
- No feedback loop yet

Those belong to later waves. Wave 1 only establishes the reranking substrate and the retrieval-context contract.

## Task 1: Add RetrievalContext and Ranking Models

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/models/search.py`
- Test: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_search/test_reranker.py`

- [ ] **Step 1: Write the failing model tests**

```python
from engram.models.search import RetrievalContext, SearchHit, SearchOptions


def test_search_options_accepts_retrieval_context():
    context = RetrievalContext(
        goal="meeting_prep",
        session_id="session-1",
        active_entity_ids=["entity-1"],
        preferred_entity_types=["person"],
        include_explanations=True,
    )

    options = SearchOptions(query="Hashed", context=context)

    assert options.context is context
    assert options.context.goal == "meeting_prep"
    assert options.context.active_entity_ids == ["entity-1"]


def test_search_hit_serializes_ranking_factors():
    hit = SearchHit(
        entity=None,  # fill with a fixture entity in the real test
        relevance_score=1.2,
        base_score=0.8,
        ranking_factors=[
            {"name": "active_entity", "delta": 0.4, "reason": "entity is active in session"},
        ],
    )

    payload = hit.to_dict()

    assert payload["base_score"] == 0.8
    assert payload["relevance_score"] == 1.2
    assert payload["ranking_factors"][0]["name"] == "active_entity"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_search/test_reranker.py -q`
Expected: `FAIL` because `RetrievalContext`, `base_score`, and `ranking_factors` do not exist yet.

- [ ] **Step 3: Add the retrieval context and ranking factor dataclasses**

```python
@dataclass
class RetrievalContext:
    goal: str = "general"
    session_id: Optional[str] = None
    active_entity_ids: list[str] = field(default_factory=list)
    recent_entity_ids: list[str] = field(default_factory=list)
    preferred_entity_ids: list[str] = field(default_factory=list)
    preferred_entity_types: list[str] = field(default_factory=list)
    preferred_tiers: list[str] = field(default_factory=list)
    include_explanations: bool = False


@dataclass
class RankingFactor:
    name: str
    delta: float
    reason: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "delta": self.delta,
            "reason": self.reason,
        }
```

```python
@dataclass
class SearchOptions:
    query: str = ""
    max_results: int = 10
    max_tokens: int = 500
    min_confidence: float = 0.0
    entity_types: list[str] = field(default_factory=list)
    tiers: list[str] = field(default_factory=list)
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    include_archived: bool = False
    context: Optional[RetrievalContext] = None


@dataclass
class SearchHit:
    entity: Entity
    facts: list[Fact] = field(default_factory=list)
    relevance_score: float = 0.0
    base_score: float = 0.0
    snippet: str = ""
    token_count: int = 0
    ranking_factors: list[RankingFactor] = field(default_factory=list)
```

- [ ] **Step 4: Extend `SearchResult.to_dict()` to include base score and factor explanations**

```python
"hits": [
    {
        "entity_name": h.entity.name,
        "entity_type": h.entity.entity_type,
        "base_score": h.base_score,
        "relevance_score": h.relevance_score,
        "snippet": h.snippet,
        "ranking_factors": [factor.to_dict() for factor in h.ranking_factors],
        "facts": [
            {"text": f.raw_text, "confidence": f.confidence, "status": f.status.value}
            for f in h.facts
        ],
    }
    for h in self.hits
]
```

- [ ] **Step 5: Run tests to verify the model layer passes**

Run: `python -m pytest tests/test_search/test_reranker.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/models/search.py tests/test_search/test_reranker.py
git commit -m "feat: add retrieval context and ranking models"
```

## Task 2: Implement the Reranking Service

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/search/reranker.py`
- Test: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_search/test_reranker.py`

- [ ] **Step 1: Add failing reranker tests**

```python
def test_reranker_boosts_active_entity(storage, entity_factory, fact_factory):
    alice = entity_factory("Alice")
    bob = entity_factory("Bob")
    alice_hit = _hit_for(alice, base_score=0.6)
    bob_hit = _hit_for(bob, base_score=0.9)

    context = RetrievalContext(
        goal="task_handoff",
        active_entity_ids=[alice.id],
        include_explanations=True,
    )

    reranked = RerankingService(storage).rerank(
        SearchResult(query="who owns this task", hits=[bob_hit, alice_hit]),
        context,
    )

    assert reranked.hits[0].entity.id == alice.id
    assert reranked.hits[0].ranking_factors[0].name == "active_entity"


def test_reranker_applies_goal_specific_entity_type_preference(storage, entity_factory):
    person = entity_factory("Alice", entity_type="person")
    company = entity_factory("Acme", entity_type="organization")
    result = SearchResult(
        query="meeting prep",
        hits=[
            _hit_for(company, base_score=0.8),
            _hit_for(person, base_score=0.7),
        ],
    )

    reranked = RerankingService(storage).rerank(
        result,
        RetrievalContext(goal="meeting_prep"),
    )

    assert reranked.hits[0].entity.entity_type == "person"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_search/test_reranker.py -q`
Expected: `FAIL` because `RerankingService` does not exist yet.

- [ ] **Step 3: Implement `RerankingService` with explicit, additive factors**

```python
class RerankingService:
    _GOAL_ENTITY_TYPE_BOOSTS = {
        "meeting_prep": {"person": 0.30, "organization": 0.20},
        "task_handoff": {"person": 0.15, "organization": 0.15},
        "debug": {"service": 0.35, "system": 0.35, "organization": 0.10},
        "research": {"organization": 0.25, "concept": 0.20},
    }

    def __init__(self, storage: SQLiteStorage) -> None:
        self.storage = storage

    def rerank(
        self,
        result: SearchResult,
        context: Optional[RetrievalContext],
    ) -> SearchResult:
        if context is None or not result.hits:
            for hit in result.hits:
                hit.base_score = hit.relevance_score
            return result

        for hit in result.hits:
            hit.base_score = hit.relevance_score
            factors: list[RankingFactor] = []
            score = hit.base_score

            if hit.entity.id in context.active_entity_ids:
                score += 0.50
                factors.append(
                    RankingFactor(
                        name="active_entity",
                        delta=0.50,
                        reason="entity is active in the current session",
                    )
                )

            if hit.entity.id in context.recent_entity_ids:
                score += 0.20
                factors.append(
                    RankingFactor(
                        name="recent_entity",
                        delta=0.20,
                        reason="entity was recently accessed",
                    )
                )

            goal_boost = self._GOAL_ENTITY_TYPE_BOOSTS.get(context.goal, {}).get(
                hit.entity.entity_type,
                0.0,
            )
            if goal_boost:
                score += goal_boost
                factors.append(
                    RankingFactor(
                        name="goal_entity_type",
                        delta=goal_boost,
                        reason=f"goal '{context.goal}' prefers {hit.entity.entity_type}",
                    )
                )

            hit.relevance_score = round(score, 4)
            hit.ranking_factors = factors if context.include_explanations else []

        result.hits.sort(key=lambda h: h.relevance_score, reverse=True)
        return result
```

- [ ] **Step 4: Add a confidence-preserving tie-break rule**

```python
result.hits.sort(
    key=lambda h: (
        h.relevance_score,
        max((fact.confidence for fact in h.facts), default=0.0),
        h.entity.access_count,
    ),
    reverse=True,
)
```

- [ ] **Step 5: Run reranker unit tests**

Run: `python -m pytest tests/test_search/test_reranker.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/search/reranker.py tests/test_search/test_reranker.py
git commit -m "feat: add goal-aware reranking service"
```

## Task 3: Wire RetrievalContext into `MemoryEngine.search()`

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/engine.py`
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_engine.py`

- [ ] **Step 1: Add failing engine tests**

```python
def test_search_boosts_working_memory_entities_via_reranker(engine):
    engine.store("Alice owns the deployment checklist.")
    engine.store("Bob owns the hiring process.")
    session = engine.start_session("assistant")
    alice = engine.get_entity("Alice")
    engine._working_memories[session.session_id].active_entities.add(alice.id)

    result = engine.search(
        "owns",
        SearchOptions(
            max_results=5,
            context=RetrievalContext(goal="task_handoff", include_explanations=True),
        ),
        session_id=session.session_id,
    )

    assert result.hits[0].entity.name == "Alice"
    assert any(f.name == "active_entity" for f in result.hits[0].ranking_factors)


def test_search_context_can_prefer_people_for_meeting_prep(engine):
    engine.store("Alice is the CEO of Acme.")
    engine.store("Acme is based in Seoul.")

    result = engine.search(
        "Acme",
        SearchOptions(
            context=RetrievalContext(goal="meeting_prep", include_explanations=True),
        ),
    )

    assert result.hits[0].entity.entity_type == "person"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_engine.py::TestEngineSearch -q`
Expected: `FAIL` because `MemoryEngine.search()` still applies only the old 1.5x working-memory multiplier.

- [ ] **Step 3: Replace the inline multiplier with a context builder + reranker**

```python
def _build_retrieval_context(
    self,
    options: SearchOptions,
    session_id: Optional[str],
) -> Optional[RetrievalContext]:
    context = copy.deepcopy(options.context) if options.context else RetrievalContext()

    if session_id:
        context.session_id = context.session_id or session_id
        wm = self._working_memories.get(session_id)
        if wm is not None:
            context.active_entity_ids = list(
                dict.fromkeys([*context.active_entity_ids, *wm.active_entities])
            )
            context.recent_entity_ids = list(
                dict.fromkeys([*context.recent_entity_ids, *wm.recent_entities])
            )

    if (
        context.goal == "general"
        and not context.active_entity_ids
        and not context.recent_entity_ids
        and not context.preferred_entity_ids
    ):
        return None

    return context
```

```python
base = self.search_engine.search(options)
context = self._build_retrieval_context(options, session_id)
result = RerankingService(self.storage).rerank(base, context)
```

- [ ] **Step 4: Keep session side effects after reranking, not before**

```python
if session_id and result.hits:
    for hit in result.hits:
        self.session_mgr.record_entity_access(session_id, hit.entity.id)

    wm = self._working_memories.get(session_id)
    if wm is not None:
        wm.add_query(query)
```

- [ ] **Step 5: Run engine search tests**

Run: `python -m pytest tests/test_engine.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/engine.py tests/test_engine.py
git commit -m "feat: rerank engine search with retrieval context"
```

## Task 4: Surface Reranked Support Hits in Briefs

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/models/brief.py`
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/engram/engine.py`
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_session/test_brief.py`

- [ ] **Step 1: Add failing brief integration tests**

```python
def test_entity_brief_contains_supporting_hits_from_goal_aware_search(engine):
    engine.store("Alice runs product at Acme.")
    engine.store("Acme is expanding to Seoul.")

    brief = engine.entity_brief(
        "Acme",
        session_id=None,
        retrieval_context=RetrievalContext(goal="meeting_prep", include_explanations=True),
    )

    assert brief is not None
    assert brief.supporting_hits
    assert brief.supporting_hits[0]["entity_type"] in {"person", "organization"}


def test_session_brief_contains_supporting_hits_for_recent_topics(engine):
    session = engine.start_session("assistant")
    engine.store("Alice owns deployment planning.")
    engine.end_session(session.session_id, summary="Deployment planning review")

    brief = engine.session_brief(
        session.session_id,
        retrieval_context=RetrievalContext(goal="task_handoff"),
    )

    assert brief is not None
    assert brief.supporting_hits is not None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_session/test_brief.py -q`
Expected: `FAIL` because brief models and engine methods do not expose supporting retrieval hits.

- [ ] **Step 3: Add a lightweight `supporting_hits` field to brief models**

```python
@dataclass
class EntityBrief:
    entity: Entity
    top_facts: list[Fact] = field(default_factory=list)
    related_entities: list[RelatedEntity] = field(default_factory=list)
    recent_notes: list[NoteInfo] = field(default_factory=list)
    recent_sessions: list[SessionRef] = field(default_factory=list)
    unresolved_conflicts: list[ConflictInfo] = field(default_factory=list)
    supporting_hits: list[dict] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)
```

- [ ] **Step 4: Populate `supporting_hits` in the engine, not in `BriefBuilder`**

```python
def entity_brief(
    self,
    name: str,
    top_facts: int = 10,
    recent_notes: int = 5,
    recent_sessions: int = 3,
    session_id: Optional[str] = None,
    retrieval_context: Optional[RetrievalContext] = None,
) -> Optional[EntityBrief]:
    brief = BriefBuilder(self.storage).entity_brief(
        name,
        top_facts=top_facts,
        recent_notes=recent_notes,
        recent_sessions=recent_sessions,
    )
    if brief is None:
        return None

    result = self.search(
        name,
        SearchOptions(
            max_results=5,
            context=retrieval_context,
        ),
        session_id=session_id,
    )
    brief.supporting_hits = result.to_dict()["hits"][:3]
    return brief
```

- [ ] **Step 5: Run brief tests**

Run: `python -m pytest tests/test_session/test_brief.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/models/brief.py engram/engine.py tests/test_session/test_brief.py
git commit -m "feat: include reranked support hits in briefs"
```

## Task 5: Add Retrieval Scenarios and Regression Coverage

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/fixtures/retrieval_scenarios.py`
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_engine.py`
- Modify: `C:/Users/qwaqw/Desktop/default/.worktrees/codex-backlinks-decisions-maintenance/tests/test_session/test_brief.py`

- [ ] **Step 1: Add stable retrieval scenarios**

```python
MEETING_PREP_SCENARIO = [
    "Alice is the CEO of Acme Ventures.",
    "Acme Ventures is a Seoul-based investment firm.",
    "Alice will join the board review meeting next Tuesday.",
]

TASK_HANDOFF_SCENARIO = [
    "DeployBot owns the rollout checklist for project Orion.",
    "Orion is blocked on staging access.",
    "Alice reviewed the Orion deployment plan yesterday.",
]
```

- [ ] **Step 2: Add a regression test that compares base retrieval vs reranked retrieval**

```python
def test_goal_aware_reranking_changes_top_hit_for_meeting_prep(engine):
    for text in MEETING_PREP_SCENARIO:
        engine.store(text)

    base = engine.search("Acme", SearchOptions(max_results=5))
    reranked = engine.search(
        "Acme",
        SearchOptions(
            max_results=5,
            context=RetrievalContext(goal="meeting_prep"),
        ),
    )

    assert base.hits
    assert reranked.hits
    assert base.hits[0].entity.id != reranked.hits[0].entity.id
```

- [ ] **Step 3: Run the focused regression bundle**

Run: `python -m pytest tests/test_search/test_reranker.py tests/test_engine.py tests/test_session/test_brief.py -q`
Expected: `PASS`

- [ ] **Step 4: Run the full suite**

Run: `python -m pytest tests -q`
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add tests/fixtures/retrieval_scenarios.py tests/test_search/test_reranker.py tests/test_engine.py tests/test_session/test_brief.py
git commit -m "test: add goal-aware retrieval regression scenarios"
```

## Spec Coverage Check

- `goal-aware retrieval / context-aware reranking`: Tasks 1, 2, 3
- `ranking explanations`: Tasks 1, 2, 3
- `brief integration`: Task 4
- `baseline scenarios and measurable improvement`: Task 5

No task in this plan adds channel/task/agent persistent storage, graph traversal, applicability conditions, or feedback learning. Those are intentionally deferred to later waves.

## Execution Notes

- Implement this plan only after the current projection branch (`codex/backlinks-decisions-maintenance`) is merged or used as the execution baseline.
- Keep `FTS5Search` unchanged as the base retriever; all behavior change belongs in the reranker layer.
- Do not put goal heuristics directly into `MemoryEngine.search()` beyond context assembly.
- Do not make `BriefBuilder` depend on search internals; the engine should inject reranked support hits.

