# Split Governance and Merge Recommendation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add persisted split governance candidates and computed merge recommendations so Engram can flag likely mixed-identity entities and surface merge backlog through the recommendation layer.

**Architecture:** Extend the existing governance enum and candidate generation path with conservative split heuristics over current facts. Extend the recommendation enum and service to derive `merge_recommendation` rows from open merge governance candidates, then expose both changes through engine, CLI, and regression tests.

**Tech Stack:** Python 3.9+, sqlite3, existing governance/recommendation services, argparse CLI, pytest

---

## File Map

- Modify: `engram/models/governance.py`
- Modify: `engram/models/retention.py`
- Modify: `engram/governance/service.py`
- Modify: `engram/recommendations/service.py`
- Modify: `engram/cli/app.py`
- Modify: `tests/test_governance/test_entity_governance.py`
- Modify: `tests/test_engine.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

### Task 1: Add enum surface for split governance and merge recommendations

**Files:**
- Modify: `engram/models/governance.py`
- Modify: `engram/models/retention.py`
- Test: `tests/test_governance/test_entity_governance.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_generate_candidates_emits_split_for_conflicting_role_facts(engine):
    entity = engine.create_entity("Jordan Lee")
    engine.storage.add_fact(
        Fact(
            entity_id=entity.id,
            subject="Jordan Lee",
            predicate="role",
            object="CTO",
            raw_text="Jordan Lee is CTO.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
    )
    engine.storage.add_fact(
        Fact(
            entity_id=entity.id,
            subject="Jordan Lee",
            predicate="role",
            object="HR Manager",
            raw_text="Jordan Lee is HR Manager.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
    )

    rows = engine.generate_governance_candidates()

    assert any(row.candidate_type is GovernanceCandidateType.SPLIT for row in rows)
```

```python
def test_merge_recommendation_kind_serializes():
    row = RecommendationView(
        kind=RecommendationKind.MERGE_RECOMMENDATION,
        severity=RecommendationSeverity.WARNING,
        target_kind="governance_candidate",
        target_id="candidate-1",
        title="Review merge",
        detail="Potential duplicate pair",
        recommended_action="engram governance-resolve candidate-1 approve",
    )

    assert row.to_dict()["kind"] == "merge_recommendation"
```

- [ ] **Step 2: Run tests to verify RED**

Run: `python -m pytest tests/test_governance/test_entity_governance.py tests/test_engine.py -q`
Expected: FAIL because `split` and `merge_recommendation` enum values do not exist yet.

- [ ] **Step 3: Add the minimal enum support**

```python
class GovernanceCandidateType(str, Enum):
    MERGE = "merge"
    ALIAS = "alias"
    SPLIT = "split"
```

```python
class RecommendationKind(str, Enum):
    STALE_DECISION = "stale_decision"
    OPEN_LOOP_ESCALATION = "open_loop_escalation"
    MERGE_RECOMMENDATION = "merge_recommendation"
```

- [ ] **Step 4: Run tests to verify GREEN**

Run: `python -m pytest tests/test_governance/test_entity_governance.py tests/test_engine.py -q`
Expected: enum import failures disappear; remaining failures point at missing service logic.

### Task 2: Generate persisted split candidates

**Files:**
- Modify: `engram/governance/service.py`
- Modify: `tests/test_governance/test_entity_governance.py`

- [ ] **Step 1: Write the failing service tests**

```python
def test_generate_candidates_emits_split_for_conflicting_role_facts(engine):
    entity = engine.create_entity("Jordan Lee")
    for value in ("CTO", "HR Manager"):
        engine.storage.add_fact(
            Fact(
                entity_id=entity.id,
                subject="Jordan Lee",
                predicate="role",
                object=value,
                raw_text=f"Jordan Lee is {value}.",
                source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            )
        )

    rows = engine.generate_governance_candidates()

    split = next(row for row in rows if row.candidate_type is GovernanceCandidateType.SPLIT)
    assert split.entity_id == entity.id
    assert split.related_entity_id is None
    assert split.details["conflicting_predicates"] == "role"
```

```python
def test_generate_candidates_skips_split_for_single_value_fact(engine):
    entity = engine.create_entity("Taylor Kim")
    engine.storage.add_fact(
        Fact(
            entity_id=entity.id,
            subject="Taylor Kim",
            predicate="role",
            object="Designer",
            raw_text="Taylor Kim is Designer.",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
    )

    rows = engine.generate_governance_candidates()

    assert all(row.candidate_type is not GovernanceCandidateType.SPLIT for row in rows)
```

- [ ] **Step 2: Run tests to verify RED**

Run: `python -m pytest tests/test_governance/test_entity_governance.py -q`
Expected: FAIL because split candidate generation is not implemented.

- [ ] **Step 3: Implement conservative split detection**

```python
def generate_candidates(self, limit: int = 100) -> list[GovernanceCandidate]:
    entities = self.storage.list_entities(limit=5000)
    generated: list[GovernanceCandidate] = []
    seen: set[str] = set()
    for index, primary in enumerate(entities):
        for secondary in entities[index + 1:]:
            ...
    for entity in entities:
        split = self._build_split_candidate(entity)
        if split is None or split.fingerprint in seen:
            continue
        seen.add(split.fingerprint)
        generated.append(self.storage.upsert_governance_candidate(split))
        if len(generated) >= limit:
            return generated[:limit]
    return generated
```

```python
def _build_split_candidate(self, entity: Entity) -> GovernanceCandidate | None:
    monitored = {"role", "affiliation", "location", "email"}
    current_facts = self.storage.get_current_facts(entity.id)
    conflicting: dict[str, list[str]] = {}
    supporting_ids: list[str] = []
    for predicate in monitored:
        values = []
        for fact in current_facts:
            if fact.predicate != predicate:
                continue
            normalized = self._normalize(fact.object)
            if not normalized:
                continue
            values.append((normalized, fact.object, fact.id))
        distinct = {item[0]: item[1] for item in values}
        if len(distinct) >= 2:
            conflicting[predicate] = list(distinct.values())
            supporting_ids.extend(item[2] for item in values)
    if not conflicting:
        return None
    fingerprint = hashlib.sha256(
        f"split|{entity.id}|{json.dumps(conflicting, sort_keys=True, ensure_ascii=False)}".encode("utf-8")
    ).hexdigest()[:24]
    now = datetime.now()
    return GovernanceCandidate(
        candidate_type=GovernanceCandidateType.SPLIT,
        status=GovernanceCandidateStatus.OPEN,
        entity_id=entity.id,
        score=0.8,
        fingerprint=fingerprint,
        rationale="entity has conflicting monitored facts that may indicate mixed identity",
        details={
            "entity_name": entity.name,
            "conflicting_predicates": ",".join(sorted(conflicting)),
            "conflicting_values": json.dumps(conflicting, ensure_ascii=False, sort_keys=True),
            "supporting_fact_ids": json.dumps(sorted(set(supporting_ids))),
            "suggested_action": "review entity for manual split",
        },
        created_at=now,
        updated_at=now,
    )
```

- [ ] **Step 4: Run tests to verify GREEN**

Run: `python -m pytest tests/test_governance/test_entity_governance.py -q`
Expected: PASS

### Task 3: Add split resolution semantics

**Files:**
- Modify: `engram/governance/service.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: Write the failing engine test**

```python
def test_resolve_split_candidate_marks_review_only_applied(engine):
    entity = engine.create_entity("Jordan Lee")
    for value in ("CTO", "HR Manager"):
        engine.storage.add_fact(
            Fact(
                entity_id=entity.id,
                subject="Jordan Lee",
                predicate="role",
                object=value,
                raw_text=f"Jordan Lee is {value}.",
                source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            )
        )

    candidate = next(
        row for row in engine.generate_governance_candidates()
        if row.candidate_type is GovernanceCandidateType.SPLIT
    )
    resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)

    facts = engine.storage.get_facts(entity.id)
    assert resolved.status is GovernanceCandidateStatus.APPLIED
    assert len(facts) == 2
```

- [ ] **Step 2: Run test to verify RED**

Run: `python -m pytest tests/test_engine.py::TestGovernance::test_resolve_split_candidate_marks_review_only_applied -q`
Expected: FAIL because split approvals are not handled.

- [ ] **Step 3: Implement the minimal resolution path**

```python
elif approved.candidate_type is GovernanceCandidateType.SPLIT:
    entity = self.storage.get_entity(approved.entity_id)
    if entity is None:
        raise EntityNotFoundError(f"Entity '{approved.entity_id}' not found")
    # review-only in this phase; no mutation
```

- [ ] **Step 4: Run test to verify GREEN**

Run: `python -m pytest tests/test_engine.py::TestGovernance::test_resolve_split_candidate_marks_review_only_applied -q`
Expected: PASS

### Task 4: Add computed merge recommendations

**Files:**
- Modify: `engram/recommendations/service.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: Write the failing recommendation tests**

```python
def test_list_recommendations_emits_merge_recommendation(engine):
    engine.create_entity("Simon Kim")
    engine.create_entity("S. Kim")
    secondary = engine.get_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)

    engine.generate_governance_candidates()
    rows = engine.list_recommendations()

    assert any(row.kind is RecommendationKind.MERGE_RECOMMENDATION for row in rows)
```

```python
def test_merge_recommendation_reports_pin_conflict(engine):
    primary = engine.create_entity("Simon Kim")
    engine.create_entity("S. Kim")
    secondary = engine.get_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)

    engine.set_retention_policy(
        RetentionTargetKind.ENTITY,
        primary.id,
        RetentionPolicyType.PIN,
        reason="important identity",
    )
    engine.generate_governance_candidates()
    rows = engine.list_recommendations(kind="merge_recommendation")

    assert rows
    assert "pin" in rows[0].policy_conflicts
```

- [ ] **Step 2: Run tests to verify RED**

Run: `python -m pytest tests/test_engine.py -q`
Expected: FAIL because merge recommendations are not computed yet.

- [ ] **Step 3: Implement merge recommendation derivation**

```python
def list_recommendations(... ) -> list[RecommendationView]:
    rows = [
        *self._stale_decision_recommendations(limit=limit),
        *self._open_loop_escalations(limit=limit, max_open_loops=max_open_loops, stale_days=stale_days),
        *self._merge_recommendations(limit=limit),
    ]
```

```python
def _merge_recommendations(self, *, limit: int) -> list[RecommendationView]:
    rows: list[RecommendationView] = []
    for candidate in self.storage.list_governance_candidates(
        status=GovernanceCandidateStatus.OPEN,
        candidate_type=GovernanceCandidateType.MERGE,
        limit=max(limit * 4, 100),
    ):
        policy_conflicts: list[str] = []
        if self.retention_service.is_pinned(RetentionTargetKind.ENTITY, candidate.entity_id):
            policy_conflicts.append("pin")
        if candidate.related_entity_id and self.retention_service.is_pinned(
            RetentionTargetKind.ENTITY,
            candidate.related_entity_id,
        ):
            policy_conflicts.append("pin")
        rows.append(
            RecommendationView(
                kind=RecommendationKind.MERGE_RECOMMENDATION,
                severity=(
                    RecommendationSeverity.CRITICAL
                    if candidate.score >= 0.95
                    else RecommendationSeverity.WARNING
                ),
                target_kind="governance_candidate",
                target_id=candidate.id,
                title=f"Review merge candidate: {candidate.details.get('primary_name', candidate.entity_id)}",
                detail=candidate.rationale,
                recommended_action=f"engram governance-resolve {candidate.id} approve",
                evidence=[
                    {
                        "candidate_type": candidate.candidate_type.value,
                        "score": candidate.score,
                        "related_entity_id": candidate.related_entity_id,
                        "details": candidate.details,
                    }
                ],
                policy_conflicts=policy_conflicts,
            )
        )
        if len(rows) >= limit:
            break
    return rows
```

- [ ] **Step 4: Run tests to verify GREEN**

Run: `python -m pytest tests/test_engine.py -q`
Expected: PASS

### Task 5: Extend CLI filters and regression coverage

**Files:**
- Modify: `engram/cli/app.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

- [ ] **Step 1: Write the failing CLI tests**

```python
def test_governance_list_accepts_split_filter(self, use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "create", "Jordan Lee"])
    capsys.readouterr()
    with sqlite3.connect(use_tmp_db) as conn:
        entity_id = conn.execute("SELECT id FROM entities WHERE name = ?", ("Jordan Lee",)).fetchone()[0]
        conn.execute(
            """
            INSERT INTO governance_candidates (
                id, candidate_type, status, entity_id, related_entity_id, proposed_alias,
                score, fingerprint, rationale, details, created_at, updated_at
            ) VALUES (?, 'split', 'open', ?, NULL, NULL, 0.8, 'split-1', 'needs review', '{}', ?, ?)
            """,
            ("candidate-1", entity_id, "2026-04-16T00:00:00", "2026-04-16T00:00:00"),
        )
        conn.commit()

    main(["--db", use_tmp_db, "--json", "governance-list", "--type", "split"])
    rows = json.loads(capsys.readouterr().out)
    assert rows and rows[0]["candidate_type"] == "split"
```

```python
def test_recommendations_command_accepts_merge_kind(self, use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "create", "Simon Kim"])
    main(["--db", use_tmp_db, "create", "S. Kim"])
    with sqlite3.connect(use_tmp_db) as conn:
        conn.execute(
            "UPDATE entities SET aliases = ? WHERE name = ?",
            (json.dumps(["Simon Kim"]), "S. Kim"),
        )
        conn.commit()
    capsys.readouterr()

    main(["--db", use_tmp_db, "--quiet", "governance-run"])
    capsys.readouterr()
    main(["--db", use_tmp_db, "--json", "recommendations", "--kind", "merge_recommendation"])
    rows = json.loads(capsys.readouterr().out)
    assert rows and rows[0]["kind"] == "merge_recommendation"
```

- [ ] **Step 2: Run tests to verify RED**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: FAIL because CLI choices do not include `split` or `merge_recommendation`.

- [ ] **Step 3: Implement CLI updates and docs index**

```python
p.add_argument("--type", dest="candidate_type", choices=["merge", "alias", "split"], default=None)
...
p.add_argument("--kind", choices=["stale_decision", "open_loop_escalation", "merge_recommendation"], default=None)
```

- [ ] **Step 4: Run tests to verify GREEN**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: PASS

### Task 6: Run focused and full regression verification

**Files:**
- Modify: none expected
- Test: `tests/test_governance/test_entity_governance.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Run focused regression bundle**

Run: `python -m pytest tests/test_governance/test_entity_governance.py tests/test_engine.py tests/test_cli/test_app.py -q`
Expected: PASS

- [ ] **Step 2: Run full suite**

Run: `python -m pytest tests -q`
Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add engram/models/governance.py engram/models/retention.py engram/governance/service.py engram/recommendations/service.py engram/cli/app.py tests/test_governance/test_entity_governance.py tests/test_engine.py tests/test_cli/test_app.py docs/README.md docs/superpowers/specs/2026-04-16-governance-split-merge-recommendations-design.md docs/superpowers/plans/2026-04-16-governance-split-merge-recommendations.md
git commit -m "feat: split governance와 merge recommendation 추가"
```
