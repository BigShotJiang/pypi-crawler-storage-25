# Backlinks, Decisions, and Dream Cycle-lite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add rebuildable reference, decision, and maintenance projections to Engram without changing canonical memory semantics or breaking existing write paths.

**Architecture:** Introduce three new projection domains on top of the current SQLite source-of-truth. Canonical writes still land in existing tables first, then post-write indexing replaces source-scoped projection rows. The rollout lands in three slices: references, decisions, then maintenance, with rebuild commands and diagnostics drift checks closing the loop.

**Tech Stack:** Python 3.9+, SQLite, existing `MemoryEngine` orchestration, dataclass models, pytest CLI/service/storage coverage.

---

## File Map

### New Files

- `C:/Users/qwaqw/Desktop/default/engram/models/reference.py`
  - `ReferenceSourceKind`, `ReferenceEdge`, `BacklinkResult`
- `C:/Users/qwaqw/Desktop/default/engram/models/decision.py`
  - `DecisionStatus`, `DecisionRecord`
- `C:/Users/qwaqw/Desktop/default/engram/models/maintenance.py`
  - `MaintenanceRun`, `MaintenanceRunItem`
- `C:/Users/qwaqw/Desktop/default/engram/references/service.py`
  - source loading, entity matching, source-scoped reference replacement
- `C:/Users/qwaqw/Desktop/default/engram/decisions/service.py`
  - deterministic decision extraction, fingerprinting, source-scoped replacement
- `C:/Users/qwaqw/Desktop/default/engram/maintenance/service.py`
  - persisted maintenance run orchestration over diagnostics data
- `C:/Users/qwaqw/Desktop/default/tests/test_references/test_service.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_decisions/test_service.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_maintenance/test_service.py`

### Modified Files

- `C:/Users/qwaqw/Desktop/default/engram/storage/base.py`
  - projection storage protocol additions
- `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
  - new tables, CRUD helpers, source enumeration, rebuild helpers
- `C:/Users/qwaqw/Desktop/default/engram/storage/migrations.py`
  - schema version bump and migration path
- `C:/Users/qwaqw/Desktop/default/engram/engine.py`
  - projection service wiring and public APIs
- `C:/Users/qwaqw/Desktop/default/engram/cli/app.py`
  - backlinks/decisions/maintenance/rebuild commands
- `C:/Users/qwaqw/Desktop/default/engram/quality/diagnostics.py`
  - projection drift metric + loops
- `C:/Users/qwaqw/Desktop/default/engram/models/health.py`
  - new loop kind for projection drift
- `C:/Users/qwaqw/Desktop/default/engram/snapshots/service.py`
  - projection-aware tests and manifest stability if needed
- `C:/Users/qwaqw/Desktop/default/tests/test_storage/test_migrations.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_cli/test_app.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_quality/test_diagnostics.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_snapshots/test_service.py`

### Execution Order

1. Schema and model scaffolding
2. Reference projections end to end
3. Decision projections end to end
4. Maintenance persistence and drift detection
5. CLI and rebuild surface
6. Integration verification and cleanup

## Task 1: Add Schema and Model Scaffolding

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/engram/models/reference.py`
- Create: `C:/Users/qwaqw/Desktop/default/engram/models/decision.py`
- Create: `C:/Users/qwaqw/Desktop/default/engram/models/maintenance.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/migrations.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/base.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_storage/test_migrations.py`

- [ ] **Step 1: Write the failing migration and model tests**

```python
def test_migrate_v3_to_v4_adds_projection_tables(tmp_path):
    db = tmp_path / "migration.db"
    conn = sqlite3.connect(str(db))
    _create_v3_schema(conn)

    migrate(conn)

    tables = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        ).fetchall()
    }
    assert "reference_edges" in tables
    assert "decisions" in tables
    assert "maintenance_runs" in tables
    assert "maintenance_run_items" in tables
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_migrate_v3_to_v4_adds_projection_tables -q`
Expected: `FAIL` because schema version `4` and the new tables do not exist yet.

- [ ] **Step 3: Add model dataclasses with stable serialization**

```python
@dataclass
class ReferenceEdge:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entity_id: str = ""
    source_kind: ReferenceSourceKind = ReferenceSourceKind.NOTE
    source_id: str = ""
    snippet: str = ""
    matched_text: str = ""
    match_start: int = 0
    match_end: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    indexed_at: datetime = field(default_factory=datetime.now)
```

```python
class DecisionStatus(str, Enum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    DRAFT = "draft"
```

```python
@dataclass
class MaintenanceRunItem:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    run_id: str = ""
    kind: str = ""
    severity: str = ""
    target_id: Optional[str] = None
    entity_name: Optional[str] = None
    title: str = ""
    detail: str = ""
    recommended_action: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
```

- [ ] **Step 4: Add migration `v3 -> v4` and schema DDL**

```python
CURRENT_VERSION = 4

def _migrate_v3_to_v4(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS reference_edges (
            id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL,
            source_kind TEXT NOT NULL,
            source_id TEXT NOT NULL,
            snippet TEXT NOT NULL DEFAULT '',
            matched_text TEXT NOT NULL DEFAULT '',
            match_start INTEGER NOT NULL,
            match_end INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            indexed_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_reference_edges_entity
            ON reference_edges(entity_id, indexed_at DESC);
        CREATE INDEX IF NOT EXISTS idx_reference_edges_source
            ON reference_edges(source_kind, source_id);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_reference_edges_unique
            ON reference_edges(entity_id, source_kind, source_id, match_start, match_end);
        """
    )
```

- [ ] **Step 5: Extend `StorageBackend` and `SQLiteStorage.initialize()` skeletons**

```python
class StorageBackend(Protocol):
    def list_reference_edges(self, entity_id: str, source_kind: Optional[str] = None, limit: int = 50) -> list[ReferenceEdge]: ...
    def replace_reference_edges(self, source_kind: str, source_id: str, edges: list[ReferenceEdge]) -> None: ...
    def replace_decisions_for_source(self, source_kind: str, source_id: str, decisions: list[DecisionRecord]) -> None: ...
    def save_maintenance_run(self, run: MaintenanceRun, items: list[MaintenanceRunItem]) -> None: ...
```

- [ ] **Step 6: Run migration tests**

Run: `python -m pytest tests/test_storage/test_migrations.py -q`
Expected: `PASS`

- [ ] **Step 7: Commit**

```bash
git add engram/models/reference.py engram/models/decision.py engram/models/maintenance.py engram/storage/base.py engram/storage/sqlite_store.py engram/storage/migrations.py tests/test_storage/test_migrations.py
git commit -m "feat: add projection schema scaffolding"
```

## Task 2: Implement Reference Projections and Backlink Queries

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/engram/references/service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_references/test_service.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_engine.py`

- [ ] **Step 1: Write failing reference service tests**

```python
def test_index_note_creates_reference_edges(engine: MemoryEngine):
    engine.create_entity("Alice")
    result = engine.store("Alice joined the platform team.")
    note_id = engine.storage.get_recent_notes(limit=1)[0]["id"]

    backlinks = engine.backlinks("Alice")

    assert len(backlinks) == 1
    assert backlinks[0].source_kind == "note"
    assert backlinks[0].source_id == note_id
```

```python
def test_reindex_same_note_replaces_rows(engine: MemoryEngine):
    engine.create_entity("Alice")
    note_id, _ = engine.storage.add_note("note-1", "Alice met Alice", "user_input", None)
    engine.rebuild_references()
    first = engine.storage.list_reference_edges(engine.get_entity("Alice").id)
    engine.rebuild_references()
    second = engine.storage.list_reference_edges(engine.get_entity("Alice").id)
    assert len(first) == len(second) == 2
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_references/test_service.py -q`
Expected: `FAIL` because `ReferenceService` and `engine.backlinks()` do not exist yet.

- [ ] **Step 3: Implement source loading and conservative entity matching**

```python
class ReferenceService:
    def index_source(self, source_kind: ReferenceSourceKind, source_id: str) -> list[ReferenceEdge]:
        source = self._load_source(source_kind, source_id)
        edges = self._extract_edges(source)
        self.storage.replace_reference_edges(source_kind.value, source_id, edges)
        return edges

    def backlinks(self, entity_name: str, source_kind: Optional[ReferenceSourceKind] = None, limit: int = 50) -> list[ReferenceEdge]:
        entity = self.storage.get_entity_by_name(entity_name)
        if entity is None:
            return []
        return self.storage.list_reference_edges(entity.id, source_kind.value if source_kind else None, limit)
```

- [ ] **Step 4: Add storage helpers and rebuild enumerators**

```python
def replace_reference_edges(self, source_kind: str, source_id: str, edges: list[ReferenceEdge]) -> None:
    with self._conn:
        self._conn.execute(
            "DELETE FROM reference_edges WHERE source_kind = ? AND source_id = ?",
            (source_kind, source_id),
        )
        self._conn.executemany(
            """
            INSERT INTO reference_edges
                (id, entity_id, source_kind, source_id, snippet, matched_text,
                 match_start, match_end, created_at, indexed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [...],
        )
```

- [ ] **Step 5: Wire engine methods**

```python
def backlinks(self, name: str, source_kind: Optional[str] = None, limit: int = 50) -> list[ReferenceEdge]:
    return self._reference_service.backlinks(name, source_kind=ReferenceSourceKind(source_kind) if source_kind else None, limit=limit)

def rebuild_references(self) -> int:
    return self._reference_service.rebuild_all()
```

- [ ] **Step 6: Run service and engine tests**

Run: `python -m pytest tests/test_references/test_service.py tests/test_engine.py -q`
Expected: `PASS`

- [ ] **Step 7: Commit**

```bash
git add engram/references/service.py engram/storage/sqlite_store.py engram/engine.py tests/test_references/test_service.py tests/test_engine.py
git commit -m "feat: add backlink reference projections"
```

## Task 3: Hook Reference Indexing into Canonical Write Paths

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/debug/service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/intake/service.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_debug/test_service.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_e2e.py`

- [ ] **Step 1: Add failing integration tests for post-write indexing**

```python
def test_debug_conclude_indexes_references(engine: MemoryEngine):
    engine.create_entity("Alice")
    dbg = engine.debug_start("bug in onboarding")
    engine.debug_conclude(dbg.id, conclusion="Alice approved the fix.")

    backlinks = engine.backlinks("Alice", source_kind="debug_session")
    assert len(backlinks) == 1
```

```python
def test_session_end_indexes_references(engine: MemoryEngine):
    engine.create_entity("Roadmap")
    session = engine.start_session("assistant")
    engine.end_session(session.session_id, summary="Roadmap was reviewed.")

    backlinks = engine.backlinks("Roadmap", source_kind="session")
    assert len(backlinks) == 1
```

- [ ] **Step 2: Run those tests to verify failure**

Run: `python -m pytest tests/test_debug/test_service.py::test_debug_conclude_indexes_references tests/test_e2e.py::test_session_end_indexes_references -q`
Expected: `FAIL` because write paths do not call reference indexing yet.

- [ ] **Step 3: Call `index_source()` after canonical writes**

```python
note_id, note_is_new = self.storage.add_note(note_id, text, source.type.value, session_id)
try:
    self._reference_service.index_source(ReferenceSourceKind.NOTE, note_id)
except Exception:
    self.session_mgr.log_event(session_id, "projection_index_failed", target=note_id, detail={"source_kind": "note"})
```

```python
session = self.session_mgr.end_session(session_id, summary=summary)
if summary:
    self._reference_service.index_source(ReferenceSourceKind.SESSION, session_id)
```

- [ ] **Step 4: Ensure failures do not roll back primary writes**

```python
try:
    self._reference_service.index_source(...)
except Exception:
    # swallow only after logging because projections are rebuildable
    pass
```

- [ ] **Step 5: Run integration coverage**

Run: `python -m pytest tests/test_debug/test_service.py tests/test_e2e.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/engine.py engram/debug/service.py engram/intake/service.py tests/test_debug/test_service.py tests/test_e2e.py
git commit -m "feat: index backlinks on canonical writes"
```

## Task 4: Implement Decision Projections

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/engram/decisions/service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_decisions/test_service.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_debug/test_service.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_e2e.py`

- [ ] **Step 1: Write failing decision extraction tests**

```python
def test_debug_conclusion_creates_active_decision(engine: MemoryEngine):
    dbg = engine.debug_start("api bug")
    engine.debug_conclude(dbg.id, conclusion="We decided to add request validation.")

    decisions = engine.list_decisions()
    assert len(decisions) == 1
    assert decisions[0].status.value == "active"
    assert "request validation" in decisions[0].summary
```

```python
def test_reindex_same_source_does_not_duplicate_decisions(engine: MemoryEngine):
    session = engine.start_session("assistant")
    engine.end_session(session.session_id, summary="We decided to ship the patch today.")
    first = engine.list_decisions()
    engine.rebuild_decisions()
    second = engine.list_decisions()
    assert len(first) == len(second) == 1
```

- [ ] **Step 2: Run tests to verify failure**

Run: `python -m pytest tests/test_decisions/test_service.py -q`
Expected: `FAIL` because decisions and fingerprinting are not implemented.

- [ ] **Step 3: Implement deterministic extraction and fingerprinting**

```python
class DecisionService:
    ACTIVE_PATTERNS = ("decided to", "we will", "agreed to", "결정", "하기로", "채택")
    DRAFT_PATTERNS = ("보류", "hold", "defer")

    def index_source(self, source_kind: str, source_id: str) -> list[DecisionRecord]:
        source = self._load_source(source_kind, source_id)
        extracted = self._extract(source)
        self.storage.replace_decisions_for_source(source_kind, source_id, extracted)
        return extracted

    def _fingerprint(self, title: str, summary: str, source_kind: str, source_id: str) -> str:
        raw = f"{self._normalize(title)}|{self._normalize(summary)}|{source_kind}|{source_id}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()
```

- [ ] **Step 4: Wire decision indexing into session and debug conclude paths**

```python
if summary:
    self._decision_service.index_source("session", session_id)
if conclusion:
    self._decision_service.index_source("debug_session", debug_session_id)
```

- [ ] **Step 5: Add engine read APIs**

```python
def list_decisions(self, *, entity_name: Optional[str] = None, status: Optional[DecisionStatus] = None, limit: int = 50) -> list[DecisionRecord]:
    return self._decision_service.list_decisions(entity_name=entity_name, status=status, limit=limit)

def get_decision(self, decision_id: str) -> Optional[DecisionRecord]:
    return self._decision_service.get_decision(decision_id)
```

- [ ] **Step 6: Run decision and integration tests**

Run: `python -m pytest tests/test_decisions/test_service.py tests/test_debug/test_service.py tests/test_e2e.py -q`
Expected: `PASS`

- [ ] **Step 7: Commit**

```bash
git add engram/decisions/service.py engram/storage/sqlite_store.py engram/engine.py tests/test_decisions/test_service.py tests/test_debug/test_service.py tests/test_e2e.py
git commit -m "feat: add decision projection service"
```

## Task 5: Persist Maintenance Runs and Projection Drift

**Files:**
- Create: `C:/Users/qwaqw/Desktop/default/engram/maintenance/service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/models/health.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/quality/diagnostics.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_quality/test_diagnostics.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_maintenance/test_service.py`

- [ ] **Step 1: Write failing diagnostics and maintenance tests**

```python
def test_projection_drift_creates_open_loop(engine: MemoryEngine):
    engine.create_entity("Alice")
    note_id, _ = engine.storage.add_note("n1", "Alice approved the plan.", "user_input", None)

    report = engine.health_report()

    assert any(loop.kind.value == "projection_drift" for loop in report.open_loops)
```

```python
def test_maintenance_run_persists_items(engine: MemoryEngine):
    run = engine.run_maintenance()
    stored = engine.get_maintenance_run(run.id)
    assert stored is not None
    assert stored.id == run.id
    assert isinstance(stored.items, list)
```

- [ ] **Step 2: Run tests to verify failure**

Run: `python -m pytest tests/test_quality/test_diagnostics.py tests/test_maintenance/test_service.py -q`
Expected: `FAIL` because drift kind and maintenance persistence do not exist yet.

- [ ] **Step 3: Extend health loop model and diagnostics**

```python
class LoopKind(str, Enum):
    CONFLICT = "conflict"
    STALE_FACT = "stale_fact"
    ORPHAN_ENTITY = "orphan_entity"
    MISSING_SOURCE = "missing_source"
    PROJECTION_DRIFT = "projection_drift"
```

```python
def _projection_drift_loops(self, max_loops: int) -> list[OpenLoop]:
    stale_sources = self.storage.find_projection_drift(limit=max_loops)
    return [
        OpenLoop(
            kind=LoopKind.PROJECTION_DRIFT,
            severity=LoopSeverity.INFO,
            title=f"Projection drift for {row['source_kind']}:{row['source_id']}",
            recommended_action="run rebuild-projections",
        )
        for row in stale_sources
    ]
```

- [ ] **Step 4: Implement maintenance run persistence**

```python
class MaintenanceService:
    def run(self) -> MaintenanceRun:
        report = self.diagnostics.run()
        run = MaintenanceRun(grade=report.grade, score_value=report.score_value, summary=f"{len(report.open_loops)} loop(s)")
        items = [MaintenanceRunItem(...loop fields... ) for loop in report.open_loops]
        self.storage.save_maintenance_run(run, items)
        return self.storage.get_maintenance_run(run.id)
```

- [ ] **Step 5: Add engine read methods**

```python
def run_maintenance(self) -> MaintenanceRun:
    return self._maintenance_service.run()

def list_maintenance_runs(self, limit: int = 20) -> list[MaintenanceRun]:
    return self._maintenance_service.list_runs(limit=limit)
```

- [ ] **Step 6: Run diagnostics and maintenance tests**

Run: `python -m pytest tests/test_quality/test_diagnostics.py tests/test_maintenance/test_service.py -q`
Expected: `PASS`

- [ ] **Step 7: Commit**

```bash
git add engram/maintenance/service.py engram/models/health.py engram/quality/diagnostics.py engram/storage/sqlite_store.py engram/engine.py tests/test_quality/test_diagnostics.py tests/test_maintenance/test_service.py
git commit -m "feat: persist maintenance runs and projection drift"
```

## Task 6: Add CLI Commands and Rebuild Operations

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/engram/cli/app.py`
- Modify: `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- Test: `C:/Users/qwaqw/Desktop/default/tests/test_cli/test_app.py`

- [ ] **Step 1: Write failing CLI tests**

```python
def test_backlinks_json(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "init"])
    main(["--db", use_tmp_db, "store", "Alice joined the team."])
    capsys.readouterr()
    code = main(["--db", use_tmp_db, "--json", "backlinks", "Alice"])
    data = json.loads(capsys.readouterr().out)
    assert code == 0
    assert data[0]["source_kind"] == "note"
```

```python
def test_maintenance_run_json(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    capsys.readouterr()
    code = main(["--db", use_tmp_db, "--json", "maintenance-run"])
    data = json.loads(capsys.readouterr().out)
    assert code == 0
    assert "grade" in data
```

- [ ] **Step 2: Run CLI tests to verify failure**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: `FAIL` because the new commands do not exist.

- [ ] **Step 3: Add parser commands and rendering**

```python
p = sub.add_parser("backlinks", help="List sources that reference an entity")
p.add_argument("name")
p.add_argument("--kind", default=None, choices=["note", "session", "debug_session", "debug_hypothesis", "debug_evidence"])
p.add_argument("--limit", type=int, default=20)

p = sub.add_parser("maintenance-run", help="Persist a Dream Cycle-lite run")
p = sub.add_parser("rebuild-projections", help="Rebuild references and decisions from canonical rows")
```

```python
elif args.command == "backlinks":
    rows = engine.backlinks(args.name, source_kind=args.kind, limit=args.limit)
    if args.json:
        print(json.dumps([r.to_dict() for r in rows], ensure_ascii=False, indent=2))
    else:
        ...
```

- [ ] **Step 4: Expose rebuild helpers**

```python
def rebuild_projections(self) -> dict[str, int]:
    return {
        "references": self.rebuild_references(),
        "decisions": self.rebuild_decisions(),
    }
```

- [ ] **Step 5: Run CLI coverage**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/cli/app.py engram/engine.py tests/test_cli/test_app.py
git commit -m "feat: add projection and maintenance CLI commands"
```

## Task 7: Add Snapshot, Rebuild, and End-to-End Regression Coverage

**Files:**
- Modify: `C:/Users/qwaqw/Desktop/default/engram/snapshots/service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/tests/test_snapshots/test_service.py`
- Modify: `C:/Users/qwaqw/Desktop/default/tests/test_e2e.py`
- Modify: `C:/Users/qwaqw/Desktop/default/tests/test_storage/test_sqlite_store.py`

- [ ] **Step 1: Write failing projection snapshot tests**

```python
def test_snapshot_restore_preserves_reference_edges(engine: MemoryEngine, tmp_path):
    engine.create_entity("Alice")
    engine.store("Alice approved the patch.")
    snap = engine.create_snapshot(label="with-projections")
    restored = engine.restore_snapshot(snap.id, str(tmp_path / "restored.db"))

    restored_storage = SQLiteStorage(Path(restored))
    restored_storage.initialize()
    try:
        rows = restored_storage._conn.execute("SELECT COUNT(*) FROM reference_edges").fetchone()
        assert rows[0] > 0
    finally:
        restored_storage.close()
```

- [ ] **Step 2: Run targeted tests to verify failure**

Run: `python -m pytest tests/test_snapshots/test_service.py tests/test_storage/test_sqlite_store.py -q`
Expected: `FAIL` until projection tables and rebuild coverage are present.

- [ ] **Step 3: Add storage-level rebuild enumeration tests**

```python
def test_iter_reference_sources_returns_notes_sessions_and_debug(storage):
    kinds = {(kind, source_id) for kind, source_id in storage.iter_reference_sources()}
    assert ("note", "note-1") in kinds
    assert ("session", "session-1") in kinds
```

- [ ] **Step 4: Run end-to-end verification bundle**

Run: `python -m pytest tests/test_references/test_service.py tests/test_decisions/test_service.py tests/test_maintenance/test_service.py tests/test_quality/test_diagnostics.py tests/test_cli/test_app.py tests/test_snapshots/test_service.py tests/test_storage/test_migrations.py tests/test_storage/test_sqlite_store.py tests/test_e2e.py -q`
Expected: `PASS`

- [ ] **Step 5: Run the full suite**

Run: `python -m pytest tests -q`
Expected: `PASS`

- [ ] **Step 6: Commit**

```bash
git add engram/snapshots/service.py tests/test_snapshots/test_service.py tests/test_e2e.py tests/test_storage/test_sqlite_store.py
git commit -m "test: cover projection rebuild and snapshot flow"
```

## Self-Review Checklist

- Spec coverage:
  - references: Tasks 1-3, 6, 7
  - decisions: Tasks 1, 4, 6, 7
  - maintenance and drift: Tasks 1, 5, 6, 7
  - rebuildability: Tasks 2, 6, 7
  - post-write non-blocking behavior: Tasks 3 and 4
- Placeholder scan:
  - no `TODO`, `TBD`, or deferred implementation markers remain in this plan
- Type consistency:
  - shared API names in this plan are `index_source`, `backlinks`, `list_decisions`, `get_decision`, `run_maintenance`, `list_maintenance_runs`, `get_maintenance_run`, `rebuild_references`, `rebuild_decisions`, and `rebuild_projections`

## Notes for the Implementer

- Keep indexing conservative. Do not add fuzzy matching or semantic expansion during this plan.
- Treat projection tables as replaceable caches with audit value, not canonical truth.
- Do not let projection indexing failures abort canonical writes.
- Prefer adding helper methods to `SQLiteStorage` instead of raw SQL in engine code.
- Keep CLI output structured first, pretty-printing second.
