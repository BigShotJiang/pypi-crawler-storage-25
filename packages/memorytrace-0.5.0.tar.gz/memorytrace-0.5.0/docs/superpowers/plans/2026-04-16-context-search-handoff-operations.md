# Context Search, Context Transfer, and Operations Review Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Engram-native `context-search`, `context-pack`, `context-transfer`, and `operations-review` surfaces without exposing legacy external command names.

**Architecture:** Keep phase 1 additive. Reuse existing search, session, maintenance, freshness, references, decisions, and recommendations flows, then layer small orchestration services and view models on top. Do not add new tables; reuse `sessions.metadata` and `session_events`, and add only the smallest storage read helper needed to consume those records cleanly.

**Tech Stack:** Python 3.9+, existing `MemoryEngine`, SQLite storage, dataclass models, `argparse`, current MCP server module, pytest.

---

## File Structure

### Create

- `engram/models/context_pack.py`
  - `ContextPack`, `ContextTransferResult`
- `engram/models/operations.py`
  - `ProjectionDriftItem`, `JobRunSummary`, `OperationsReview`
- `engram/search/contextual.py`
  - `ContextSearchService`
- `engram/session/transfer.py`
  - `ContextPackBuilder`
- `engram/maintenance/review.py`
  - `OperationsReviewService`
- `tests/test_search/test_contextual.py`
- `tests/test_session/test_transfer.py`
- `tests/test_maintenance/test_review.py`
- `tests/test_integrations/test_sdk.py`

### Modify

- `engram/models/view.py`
  - add `ContextSearchResult` beside other explanation-rich views
- `engram/storage/base.py`
- `engram/storage/sqlite_store.py`
- `engram/session/manager.py`
- `engram/session/context.py`
- `engram/session/brief.py`
- `engram/engine.py`
- `engram/search/reranker.py`
- `engram/integrations/sdk.py`
- `engram/integrations/mcp_server.py`
- `engram/cli/app.py`
- `tests/test_storage/test_sqlite_store.py`
- `tests/test_session/test_manager.py`
- `tests/test_engine.py`
- `tests/test_cli/test_app.py`
- `tests/test_integrations/test_mcp_server.py`

### Non-Goals For This Plan

- No legacy external command aliases
- No new durable tables for packs or transfers
- No embedding backend
- No automatic task delegation outside Engram
- No `channel_*`, `agentic_search`, `agent_handoff`, `agent_inject`, or `dream` compatibility wrappers

## Review Adjudication

### Accepted And Fixed In This Plan

- `start_session()` parent resolution now uses an explicit sentinel so "use recent parent" and "no parent" are distinguishable.
- Parallel active sessions for the same `agent_id` are rejected by default; `transfer_context()` must not silently create a second active session for the target agent.
- `ContextPack.recent_queries` must come from masked `session_events`, never directly from raw `WorkingMemory.recent_queries`.
- `ContextPack` reuses existing Engram models where possible: `EntityRef`, `DecisionView`, and `OpenLoop`.
- `ContextSearchResult` uses typed related-entity views and lives in `engram/models/view.py`.
- `ContextSearchService` must reuse a scorer extracted from `engram/search/reranker.py` so related entities can be ranked with the same retrieval context signals.
- `search_context()` must apply a token budget to expansion results and define `expand_hops=0` as "base search only".
- `operations-review` is explicitly write-bearing because it persists a maintenance run every time it executes.
- `OperationsReview.job_result` is a typed wrapper over the existing `run_jobs()` dict so phase 1 preserves backward compatibility without leaking another raw dict into the new model.
- The plan now requires error-path tests for invalid hop counts, missing sessions, parallel-session rejection, and scope-widening rejection.
- Scope inheritance on transfer is constrained to the source scope or a narrower explicitly selected scope. Phase 1 assumes one trust domain and does not introduce an ACL system.

### Evaluated And Not Adopted As Separate Work

- A new graph-neighbor convenience method is not required in phase 1. Existing `storage.get_relations()` plus entity lookup is sufficient for one-hop expansion.
- `WorkingMemory` serialization is intentionally avoided in this batch. Session carryover uses persisted sessions plus masked session events instead.
- `build_session_context()` is not being redesigned in this batch. Shared masked-query helpers are added for `SessionBrief` and `ContextPack`, but the existing start-of-session summary flow remains separate.
- Recommendations are not a deferred dependency. `RecommendationService` already exists in the current codebase, so `operations-review` can use it directly.

## Cross-Cutting Contracts

### Session Lifecycle Contract

- `parent_session_id` defaults to "reuse most recent completed lineage" only when the caller does not specify a parent value at all.
- Passing `parent_session_id=None` means "start a root session with no parent".
- `transfer_context()` may read from an active or ended source session.
- If the target agent already has an active session in the current process, `transfer_context()` must raise `SessionError` instead of creating a second active target session.

### Query Masking Contract

- `search()` must log a masked `search` session event in addition to the existing `notes_searched` event.
- `SessionBrief` and `ContextPack` must read recent queries through a shared helper that consumes masked session events.
- Raw `WorkingMemory.recent_queries` stays ephemeral and must not be serialized into durable handoff artifacts.

### Rendering Contract

- `ContextPack.rendered_text` uses deterministic section order: summary, active entities, recent queries, supporting decisions, open loops.
- `OperationsReview.summary_lines` uses deterministic section order: open loops, maintenance grade, job summary, reference drift, decision drift, recommendations.
- Both renderers must be truncation-aware and preserve section headers when trimmed.

### Scope Contract

- Default transfer behavior inherits the source session scope unchanged.
- If a caller supplies a narrower `ScopeSelection`, the selected scope must resolve inside the source scope lineage; widening to an unrelated scope is an error.
- Phase 1 does not introduce per-agent authorization. The safety boundary is "same trust domain, no silent widening".

## Task 1: Add View Models and Session/Storage Primitives

**Files:**
- Create: `engram/models/context_pack.py`
- Create: `engram/models/operations.py`
- Modify: `engram/storage/base.py`
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/session/manager.py`
- Test: `tests/test_storage/test_sqlite_store.py`
- Test: `tests/test_session/test_manager.py`
- Test: `tests/test_session/test_transfer.py`
- Test: `tests/test_maintenance/test_review.py`

- [ ] **Step 1: Write the failing primitive tests**

```python
from datetime import datetime

from engram.models.session import Session, SessionEvent


def test_storage_get_session_events_returns_newest_first(storage):
    session = Session(agent_id="planner")
    storage.save_session(session)

    older = SessionEvent(
        session_id=session.session_id,
        event_type="search",
        target="alpha roadmap",
        timestamp=datetime(2026, 4, 16, 10, 0, 0),
    )
    newer = SessionEvent(
        session_id=session.session_id,
        event_type="search",
        target="beta roadmap",
        timestamp=datetime(2026, 4, 16, 10, 1, 0),
    )
    storage.add_session_event(older)
    storage.add_session_event(newer)

    events = storage.get_session_events(session.session_id, limit=10)

    assert [event.target for event in events] == ["beta roadmap", "alpha roadmap"]


def test_start_session_accepts_explicit_parent_and_metadata(session_setup):
    mgr, _ = session_setup

    session = mgr.start_session(
        "writer",
        scope_id="scope-1",
        parent_session_id="source-session",
        metadata={"handoff_goal": "task_handoff"},
    )

    assert session.parent_session_id == "source-session"
    assert session.scope_id == "scope-1"
    assert session.metadata["handoff_goal"] == "task_handoff"
```

```python
from engram.models.context_pack import ContextPack
from engram.models.operations import OperationsReview
from engram.models.brief import EntityRef


def test_context_pack_to_dict_includes_rendered_text():
    pack = ContextPack(
        source_session_id="s-1",
        source_agent_id="planner",
        scope_id="scope-1",
        goal="task_handoff",
        summary="Need to continue the release checklist.",
        active_entities=[
            EntityRef(entity_id="e-1", name="Alice", entity_type="person"),
            EntityRef(entity_id="e-2", name="Release Bot", entity_type="service"),
        ],
        recent_queries=["release checklist", "rollback plan"],
        supporting_decisions=[],
        open_loops=[],
        rendered_text="Summary: continue the release checklist.",
    )

    payload = pack.to_dict()

    assert payload["goal"] == "task_handoff"
    assert payload["active_entities"][0]["name"] == "Alice"
    assert payload["rendered_text"].startswith("Summary:")


def test_operations_review_to_dict_keeps_summary_lines():
    review = OperationsReview(summary_lines=["2 open loops", "1 queued job"])

    payload = review.to_dict()

    assert payload["summary_lines"] == ["2 open loops", "1 queued job"]
```

- [ ] **Step 2: Run the primitive tests to verify they fail**

Run: `python -m pytest tests/test_storage/test_sqlite_store.py tests/test_session/test_manager.py tests/test_session/test_transfer.py tests/test_maintenance/test_review.py -q`  
Expected: `FAIL` because `get_session_events()`, the new `start_session()` parameters, and the new view models do not exist yet.

- [ ] **Step 3: Add the models and the minimum storage/session contract**

```python
from engram.models.brief import EntityRef
from engram.models.health import OpenLoop
from engram.models.view import DecisionView


@dataclass
class ContextPack:
    source_session_id: str
    source_agent_id: str
    scope_id: str | None
    goal: str
    summary: str
    source_session_active: bool = False
    active_entities: list[EntityRef] = field(default_factory=list)
    recent_queries: list[str] = field(default_factory=list)
    supporting_decisions: list[DecisionView] = field(default_factory=list)
    open_loops: list[OpenLoop] = field(default_factory=list)
    rendered_text: str = ""

    def to_dict(self) -> dict:
        return {
            "source_session_id": self.source_session_id,
            "source_agent_id": self.source_agent_id,
            "scope_id": self.scope_id,
            "goal": self.goal,
            "summary": self.summary,
            "source_session_active": self.source_session_active,
            "active_entities": [row.to_dict() for row in self.active_entities],
            "recent_queries": list(self.recent_queries),
            "supporting_decisions": [row.to_dict() for row in self.supporting_decisions],
            "open_loops": [row.to_dict() for row in self.open_loops],
            "rendered_text": self.rendered_text,
        }


@dataclass
class ContextTransferResult:
    pack: ContextPack
    target_session: Session
    transfer_note: str = ""

    def to_dict(self) -> dict:
        return {
            "pack": self.pack.to_dict(),
            "target_session": {
                "session_id": self.target_session.session_id,
                "agent_id": self.target_session.agent_id,
                "scope_id": self.target_session.scope_id,
                "parent_session_id": self.target_session.parent_session_id,
                "metadata": dict(self.target_session.metadata),
            },
            "transfer_note": self.transfer_note,
        }
```

```python
@dataclass
class ProjectionDriftItem:
    source_kind: str
    source_id: str
    title: str
    detail: str

    @classmethod
    def from_dict(cls, payload: dict) -> "ProjectionDriftItem":
        return cls(
            source_kind=payload["source_kind"],
            source_id=payload["source_id"],
            title=payload["title"],
            detail=payload["detail"],
        )

    def to_dict(self) -> dict:
        return {
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "title": self.title,
            "detail": self.detail,
        }


@dataclass
class JobRunSummary:
    leased: int = 0
    completed: int = 0
    failed: int = 0

    @classmethod
    def from_dict(cls, payload: dict) -> "JobRunSummary":
        return cls(
            leased=int(payload.get("leased", 0)),
            completed=int(payload.get("completed", 0)),
            failed=int(payload.get("failed", 0)),
        )

    def to_dict(self) -> dict:
        return {
            "leased": self.leased,
            "completed": self.completed,
            "failed": self.failed,
        }


@dataclass
class OperationsReview:
    health_report: HealthReport | None = None
    maintenance_run: MaintenanceRunView | None = None
    job_result: JobRunSummary | None = None
    reference_drift: list[ProjectionDriftItem] = field(default_factory=list)
    decision_drift: list[ProjectionDriftItem] = field(default_factory=list)
    recommendations: list[RecommendationView] = field(default_factory=list)
    summary_lines: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "health_report": self.health_report.to_dict() if self.health_report else None,
            "maintenance_run": self.maintenance_run.to_dict() if self.maintenance_run else None,
            "job_result": self.job_result.to_dict() if self.job_result else None,
            "reference_drift": [row.to_dict() for row in self.reference_drift],
            "decision_drift": [row.to_dict() for row in self.decision_drift],
            "recommendations": [row.to_dict() for row in self.recommendations],
            "summary_lines": list(self.summary_lines),
        }
```

```python
class StorageBackend(Protocol):
    def get_session_events(
        self,
        session_id: str,
        limit: int = 50,
    ) -> list[SessionEvent]:
        pass
```

```python
def get_session_events(self, session_id: str, limit: int = 50) -> list[SessionEvent]:
    rows = self._conn.execute(
        """
        SELECT * FROM session_events
        WHERE session_id = ?
        ORDER BY timestamp DESC, id DESC
        LIMIT ?
        """,
        (session_id, limit),
    ).fetchall()
    return [self._row_to_session_event(row) for row in rows]


def _row_to_session_event(self, row: sqlite3.Row) -> SessionEvent:
    return SessionEvent(
        id=row["id"],
        session_id=row["session_id"],
        event_type=row["event_type"],
        target=row["target"] or "",
        detail=json.loads(row["detail"]) if row["detail"] else {},
        timestamp=_str_to_dt(row["timestamp"]) or datetime.now(),
    )
```

```python
_USE_RECENT_PARENT = object()


def start_session(
    self,
    agent_id: str = "default",
    scope_id: Optional[str] = None,
    *,
    parent_session_id: object = _USE_RECENT_PARENT,
    metadata: Optional[dict] = None,
    allow_parallel: bool = False,
) -> Session:
    if not allow_parallel:
        for active in self._active.values():
            if active.agent_id == agent_id:
                raise SessionError(f"Agent '{agent_id}' already has an active session")
    previous = self.storage.get_recent_sessions(agent_id, limit=1)
    effective_parent = (
        previous[0].session_id
        if parent_session_id is _USE_RECENT_PARENT and previous
        else parent_session_id
    )
    if effective_parent is _USE_RECENT_PARENT:
        effective_parent = None
    session = Session(
        session_id=str(uuid.uuid4()),
        agent_id=agent_id,
        started_at=datetime.now(),
        parent_session_id=effective_parent,
        scope_id=scope_id,
        metadata=dict(metadata or {}),
    )
    self.storage.save_session(session)
    self._active[session.session_id] = session
    return session
```

- [ ] **Step 4: Run the primitive tests to verify they pass**

Run: `python -m pytest tests/test_storage/test_sqlite_store.py tests/test_session/test_manager.py tests/test_session/test_transfer.py tests/test_maintenance/test_review.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/models/context_pack.py engram/models/operations.py engram/storage/base.py engram/storage/sqlite_store.py engram/session/manager.py tests/test_storage/test_sqlite_store.py tests/test_session/test_manager.py tests/test_session/test_transfer.py tests/test_maintenance/test_review.py
git commit -m "feat: add context transfer and operations review primitives"
```

## Task 2: Implement `ContextSearchService` and `MemoryEngine.search_context()`

**Files:**
- Create: `engram/search/contextual.py`
- Modify: `engram/models/view.py`
- Modify: `engram/search/reranker.py`
- Modify: `engram/engine.py`
- Test: `tests/test_search/test_contextual.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing contextual search tests**

```python
from engram.models.relation import Relation


def test_search_context_returns_base_hits_and_related_entities(engine):
    engine.store("Alice leads the Alpha roadmap.")
    engine.store("Bob coordinates release reviews with Alice.")
    alice = engine.get_entity("Alice")
    bob = engine.get_entity("Bob")
    engine.storage.add_relation(
        Relation(
            from_entity_id=alice.id,
            to_entity_id=bob.id,
            relation_type="WORKS_WITH",
        )
    )

    result = engine.search_context("Alice", goal="task_handoff")

    assert result.base_result.hits
    assert any(row.name == "Bob" for row in result.related_entities)
    assert "expanded relation neighbors" in result.expansion_notes


def test_search_context_preserves_freshness_penalty(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns the migration plan", predicate="role")
    fact = engine.get_facts("Alice")[0]
    engine.storage.update_fact_freshness(
        fact.id,
        verification_status="stale",
        verification_due_at="2000-01-01T00:00:00",
    )

    result = engine.search_context("migration plan", goal="task_handoff")

    assert result.base_result.hits
    assert any(
        factor.name == "freshness_penalty"
        for factor in result.base_result.hits[0].ranking_factors
    )


def test_search_context_with_zero_hops_returns_base_only(engine):
    engine.store("Alice owns the release checklist.")

    result = engine.search_context("release checklist", expand_hops=0)

    assert result.base_result.hits
    assert result.related_entities == []
    assert result.related_decisions == []
```

- [ ] **Step 2: Run the contextual search tests to verify they fail**

Run: `python -m pytest tests/test_search/test_contextual.py tests/test_engine.py -q`  
Expected: `FAIL` because `search_context()` and `ContextSearchResult` do not exist yet.

- [ ] **Step 3: Implement the new contextual search view and service**

```python
from engram.models.brief import RelatedEntity


@dataclass
class ContextSearchResult:
    query: str
    goal: str
    base_result: SearchResult
    related_entities: list[RelatedEntity] = field(default_factory=list)
    related_decisions: list[DecisionView] = field(default_factory=list)
    expansion_notes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "goal": self.goal,
            "base_result": self.base_result.to_dict(),
            "related_entities": [row.to_dict() for row in self.related_entities],
            "related_decisions": [row.to_dict() for row in self.related_decisions],
            "expansion_notes": list(self.expansion_notes),
            "warnings": list(self.warnings),
        }
```

```python
def score_entity(
    self,
    entity: Entity,
    context: RetrievalContext | None,
    *,
    base_score: float = 0.0,
) -> tuple[float, list[RankingFactor]]:
    score = base_score
    factors: list[RankingFactor] = []
    if context is None:
        return score, factors
    if entity.id in context.active_entity_ids:
        score += 0.6
        factors.append(RankingFactor("active_entity", 0.6, "entity is active in session"))
    if entity.entity_type in context.preferred_entity_types:
        score += 0.25
        factors.append(RankingFactor("preferred_type", 0.25, "entity type matches requested scope"))
    for entity_type, delta in self._GOAL_TYPE_PREFERENCES.get(context.goal, {}).items():
        if entity.entity_type == entity_type:
            score += delta
            factors.append(RankingFactor("goal_type", delta, f"context goal favors {entity_type}"))
    return round(score, 6), factors
```

```python
class ContextSearchService:
    def __init__(
        self,
        storage: SQLiteStorage,
        reference_service: ReferenceService,
        decision_service: DecisionService,
        reranking_service: RerankingService,
        freshness_service: FreshnessService,
    ) -> None:
        self.storage = storage
        self.reference_service = reference_service
        self.decision_service = decision_service
        self.reranking_service = reranking_service
        self.freshness_service = freshness_service

    def expand(
        self,
        *,
        query: str,
        goal: str,
        base_result: SearchResult,
        context: RetrievalContext,
        expand_hops: int,
        max_related: int,
        related_token_budget: int,
        include_decisions: bool,
        include_references: bool,
    ) -> ContextSearchResult:
        if expand_hops == 0:
            return ContextSearchResult(query=query, goal=goal, base_result=base_result)
        seed_ids = [hit.entity.id for hit in base_result.hits]
        related_entities = self._related_entities(
            seed_ids,
            context=context,
            max_related=max_related,
            token_budget=related_token_budget,
        )
        related_decisions = (
            self._related_decisions(seed_ids, limit=max_related, token_budget=related_token_budget)
            if include_decisions
            else []
        )
        notes = []
        if related_entities:
            notes.append("expanded relation neighbors")
        if include_references:
            notes.append("inspected reference edges")
        if related_decisions:
            notes.append("collected supporting decisions")
        return ContextSearchResult(
            query=query,
            goal=goal,
            base_result=base_result,
            related_entities=related_entities,
            related_decisions=related_decisions,
            expansion_notes=notes,
        )

    def _related_entities(
        self,
        seed_ids: list[str],
        *,
        context: RetrievalContext,
        max_related: int,
        token_budget: int,
    ) -> list[RelatedEntity]:
        scored_rows: list[tuple[float, RelatedEntity]] = []
        seen: set[str] = set(seed_ids)
        tokens_used = 0
        for entity_id in seed_ids:
            for relation in self.storage.get_relations(entity_id):
                candidate_id = relation.to_entity_id if relation.from_entity_id == entity_id else relation.from_entity_id
                if candidate_id in seen:
                    continue
                entity = self.storage.get_entity(candidate_id)
                if entity is None:
                    continue
                seen.add(candidate_id)
                score, _ranking_factors = self.reranking_service.score_entity(
                    entity,
                    context,
                    base_score=0.0,
                )
                estimate = max(1, len(entity.name) // 4)
                if token_budget > 0 and tokens_used + estimate > token_budget:
                    break
                scored_rows.append(
                    (
                        score,
                        RelatedEntity(
                            entity_id=entity.id,
                            name=entity.name,
                            entity_type=entity.entity_type,
                            relation_type=relation.relation_type,
                            direction=(
                                "outgoing"
                                if relation.from_entity_id == entity_id
                                else "incoming"
                            ),
                        ),
                    )
                )
                tokens_used += estimate
                if len(scored_rows) >= max_related:
                    break
            if len(scored_rows) >= max_related:
                break
        scored_rows.sort(key=lambda pair: pair[0], reverse=True)
        return [row for _, row in scored_rows[:max_related]]

    def _related_decisions(
        self,
        seed_ids: list[str],
        *,
        limit: int,
        token_budget: int,
    ) -> list[DecisionView]:
        rows: list[DecisionView] = []
        tokens_used = 0
        for decision in self.storage.list_decisions(limit=max(limit * 4, 50)):
            if decision.entity_id not in seed_ids:
                continue
            assessment = self.freshness_service.assess_decision(decision)
            estimate = max(1, len(decision.title) // 4)
            if token_budget > 0 and tokens_used + estimate > token_budget:
                break
            rows.append(
                DecisionView(
                    decision=decision,
                    explanation=ExplanationBundle(
                        summary=f"Decision linked to entity {decision.entity_id}.",
                        warnings=[assessment.warning] if assessment.warning else [],
                    ),
                )
            )
            tokens_used += estimate
            if len(rows) >= limit:
                break
        return rows
```

```python
def search_context(
    self,
    query: str,
    *,
    goal: str = "general",
    session_id: Optional[str] = None,
    scope_selection: Optional[ScopeSelection] = None,
    expand_hops: int = 1,
    include_decisions: bool = True,
    include_references: bool = True,
    max_results: int = 5,
    max_related: int = 10,
    max_tokens: int = 800,
) -> ContextSearchResult:
    if expand_hops < 0 or expand_hops > 2:
        raise ValueError("expand_hops must be between 0 and 2")

    wm = self._working_memories.get(session_id) if session_id else None
    context = RetrievalContext(
        goal=goal,
        session_id=session_id,
        active_entity_ids=wm.get_active_entity_ids() if wm else [],
        include_explanations=True,
    )
    options = SearchOptions(
        query=query,
        max_results=max_results,
        max_tokens=max_tokens,
        context=context,
    )
    base = self.search(
        query,
        options,
        session_id=session_id,
        scope_selection=scope_selection,
    )
    remaining_tokens = max(max_tokens - base.total_tokens, 0)
    service = ContextSearchService(
        self.storage,
        self.reference_service,
        self.decision_service,
        self.reranking_service,
        self.freshness_service,
    )
    return service.expand(
        query=query,
        goal=goal,
        base_result=base,
        context=context,
        expand_hops=expand_hops,
        max_related=max_related,
        related_token_budget=remaining_tokens,
        include_decisions=include_decisions,
        include_references=include_references,
    )
```

- [ ] **Step 4: Run the contextual search tests to verify they pass**

Run: `python -m pytest tests/test_search/test_contextual.py tests/test_engine.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/search/contextual.py engram/search/reranker.py engram/models/view.py engram/engine.py tests/test_search/test_contextual.py tests/test_engine.py
git commit -m "feat: add engram context search orchestration"
```

## Task 3: Expose `context-search` Through SDK, CLI, and MCP

**Files:**
- Modify: `engram/integrations/sdk.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/integrations/mcp_server.py`
- Create: `tests/test_integrations/test_sdk.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `tests/test_integrations/test_mcp_server.py`

- [ ] **Step 1: Write the failing surface tests for `context-search`**

```python
def test_sdk_search_context_delegates_to_engine(monkeypatch):
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    called = {}

    def fake_search_context(query, **kwargs):
        called["query"] = query
        called["goal"] = kwargs["goal"]
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "search_context", fake_search_context)

    result = sdk.search_context("release owner", goal="task_handoff")

    assert result == {"ok": True}
    assert called == {"query": "release owner", "goal": "task_handoff"}
    sdk.close()
```

```python
def test_context_search_cli_json(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "store", "Alice owns the release checklist."])
    capsys.readouterr()

    code = main([
        "--db",
        use_tmp_db,
        "--json",
        "context-search",
        "release checklist",
        "--goal",
        "task_handoff",
    ])

    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert payload["goal"] == "task_handoff"
    assert "base_result" in payload
```

- [ ] **Step 2: Run the surface tests to verify they fail**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py -q`  
Expected: `FAIL` because the SDK method, CLI command, and MCP tool are not registered yet.

- [ ] **Step 3: Add the public surface without adding legacy external aliases**

```python
def search_context(
    self,
    query: str,
    *,
    goal: str = "general",
    max_results: int = 5,
    max_related: int = 10,
    max_tokens: int = 800,
) -> ContextSearchResult:
    return self.engine.search_context(
        query,
        goal=goal,
        session_id=self.session_id,
        max_results=max_results,
        max_related=max_related,
        max_tokens=max_tokens,
    )
```

```python
p = sub.add_parser("context-search", help="Search memory plus related context")
p.add_argument("query")
p.add_argument("--goal", default="general")
p.add_argument("--max-results", type=int, default=5)
p.add_argument("--max-related", type=int, default=10)
p.add_argument("--max-tokens", type=int, default=800)
p.add_argument("--scope-id", default=None)
```

```python
elif args.command == "context-search":
    scope_selection = (
        ScopeSelection(primary_scope_id=args.scope_id)
        if args.scope_id
        else None
    )
    result = engine.search_context(
        args.query,
        goal=args.goal,
        scope_selection=scope_selection,
        max_results=args.max_results,
        max_related=args.max_related,
        max_tokens=args.max_tokens,
    )
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
    else:
        print(result.base_result.to_agent_context())
        if result.related_entities:
            print("Related:")
            for row in result.related_entities:
                print(f"  - {row.name} ({row.relation_type})")
```

```python
@app.tool()
async def memory_context_search(
    query: str,
    goal: str = "general",
    max_results: int = 5,
    max_related: int = 10,
    max_tokens: int = 800,
    session_id: str = "",
) -> str:
    """Search memory plus related context for a goal-oriented handoff or lookup.

    Returns the base search result plus typed relation/decision expansions.
    """
    engine = _get_engine()
    result = engine.search_context(
        query,
        goal=goal,
        session_id=session_id or None,
        max_results=max_results,
        max_related=max_related,
        max_tokens=max_tokens,
    )
    return json.dumps(result.to_dict(), ensure_ascii=False)
```

- [ ] **Step 4: Run the surface tests to verify they pass**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/integrations/sdk.py engram/cli/app.py engram/integrations/mcp_server.py tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py
git commit -m "feat: expose context search across sdk cli and mcp"
```

## Task 4: Implement `ContextPackBuilder` and `MemoryEngine.transfer_context()`

**Files:**
- Create: `engram/session/transfer.py`
- Modify: `engram/engine.py`
- Modify: `engram/session/manager.py`
- Modify: `engram/session/context.py`
- Modify: `engram/session/brief.py`
- Modify: `engram/storage/base.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_session/test_transfer.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing pack/transfer tests**

```python
def test_build_context_pack_includes_summary_entities_and_queries(engine):
    session = engine.start_session("planner")
    engine.store("Alice owns the release checklist.", session_id=session.session_id)
    engine.search("release checklist", session_id=session.session_id)
    engine.end_session(session.session_id, summary="Release checklist ownership settled.")

    pack = engine.build_context_pack(session_id=session.session_id, goal="task_handoff")

    assert pack.summary == "Release checklist ownership settled."
    assert pack.active_entities[0].name == "Alice"
    assert "release checklist" in pack.recent_queries[0]


def test_transfer_context_creates_target_session_with_metadata_and_events(engine):
    scope = engine.create_scope("project", "alpha")
    source = engine.start_session("planner", scope_id=scope.id)
    engine.store("Alice owns the Alpha release checklist.", session_id=source.session_id)
    engine.end_session(source.session_id, summary="Planner completed the first draft.")

    transfer = engine.transfer_context(
        from_session_id=source.session_id,
        to_agent_id="writer",
        note="Continue drafting the handoff memo.",
    )

    assert transfer.target_session.agent_id == "writer"
    assert transfer.target_session.scope_id == scope.id
    assert transfer.target_session.metadata["handoff_from_session_id"] == source.session_id
    assert transfer.target_session.metadata["handoff_note"] == "Continue drafting the handoff memo."


def test_transfer_context_rejects_parallel_target_agent_session(engine):
    source = engine.start_session("planner")
    engine.end_session(source.session_id, summary="Planner finished.")
    engine.start_session("writer")

    with pytest.raises(SessionError):
        engine.transfer_context(
            from_session_id=source.session_id,
            to_agent_id="writer",
        )
```

- [ ] **Step 2: Run the pack/transfer tests to verify they fail**

Run: `python -m pytest tests/test_session/test_transfer.py tests/test_engine.py -q`  
Expected: `FAIL` because the pack builder, transfer method, and durable query reconstruction do not exist yet.

- [ ] **Step 3: Implement pack building, durable search events, and transfer**

```python
def list_masked_session_queries(
    storage: StorageBackend,
    session_id: str,
    *,
    limit: int = 5,
) -> list[str]:
    rows = []
    for event in storage.get_session_events(session_id, limit=50):
        if event.event_type not in {"search", "notes_searched"}:
            continue
        if not event.target:
            continue
        rows.append(event.target)
        if len(rows) >= limit:
            break
    return rows
```

```python
def session_brief(
    self,
    session_id: str,
    working_memory: Optional[WorkingMemory] = None,
    active_session: Optional[Session] = None,
) -> Optional[SessionBrief]:
    session = active_session or self.storage.get_session(session_id)
    if session is None:
        return None

    modified = self._resolve_entity_refs(session.entities_modified)
    accessed = self._resolve_entity_refs(session.entities_accessed)
    facts = self._resolve_fact_refs(session.facts_added)
    active_wm = (
        self._resolve_entity_refs(working_memory.get_active_entity_ids())
        if working_memory is not None
        else []
    )
    recent_queries = list_masked_session_queries(self.storage, session.session_id, limit=5)
    open_conflicts = self._conflicts_for_session(session)
    return SessionBrief(
        session=session,
        entities_modified=modified,
        entities_accessed=accessed,
        facts_added=facts,
        active_working_memory=active_wm,
        recent_queries=recent_queries,
        open_conflicts=open_conflicts,
        generated_at=datetime.now(),
    )
```

```python
class ContextPackBuilder:
    def __init__(
        self,
        storage: SQLiteStorage,
        diagnostics: Diagnostics,
    ) -> None:
        self.storage = storage
        self.diagnostics = diagnostics

    def build(
        self,
        *,
        session: Session,
        goal: str,
        max_chars: int,
        session_brief: SessionBrief,
    ) -> ContextPack:
        entity_ids = [
            *[row.entity_id for row in session_brief.entities_modified],
            *[row.entity_id for row in session_brief.entities_accessed],
        ]
        active_entities = list(session_brief.active_working_memory or session_brief.entities_accessed[:8])
        recent_queries = list(session_brief.recent_queries[:5])
        decisions = [
            DecisionView(
                decision=decision,
                explanation=ExplanationBundle(summary="Decision supports this handoff."),
            )
            for decision in self.storage.list_decisions(limit=100)
            if decision.session_id == session.session_id or decision.entity_id in entity_ids
        ][:5]
        open_loops = [
            loop
            for loop in self.diagnostics.run(max_open_loops=20).open_loops
            if loop.target_id in entity_ids or loop.entity_name in {row.name for row in active_entities}
        ][:5]
        rendered = self._render_text(
            summary=session.summary or "",
            active_entities=active_entities,
            recent_queries=recent_queries,
            decisions=decisions,
            open_loops=open_loops,
            max_chars=max_chars,
        )
        return ContextPack(
            source_session_id=session.session_id,
            source_agent_id=session.agent_id,
            scope_id=session.scope_id,
            goal=goal,
            summary=session.summary or "",
            source_session_active=session.is_active,
            active_entities=active_entities,
            recent_queries=recent_queries,
            supporting_decisions=decisions,
            open_loops=open_loops,
            rendered_text=rendered,
        )

    def _render_text(
        self,
        *,
        summary: str,
        active_entities: list[EntityRef],
        recent_queries: list[str],
        decisions: list[DecisionView],
        open_loops: list[OpenLoop],
        max_chars: int,
    ) -> str:
        sections = [
            f"Summary: {summary or 'No session summary.'}",
            "Active entities: " + (", ".join(row.name for row in active_entities) if active_entities else "None"),
            f"Recent queries: {', '.join(recent_queries) if recent_queries else 'None'}",
            "Supporting decisions: " + "; ".join(row.decision.title for row in decisions) if decisions else "Supporting decisions: None",
            "Open loops: " + "; ".join(row.title for row in open_loops) if open_loops else "Open loops: None",
        ]
        text = "\n".join(sections)
        return text[:max_chars]
```

```python
if session_id:
    self.session_mgr.log_event(
        session_id,
        event_type="search",
        target=self._mask_text(query) or query,
        detail={"hit_count": len(result.hits)},
    )
```

```python
def build_context_pack(
    self,
    *,
    session_id: str,
    goal: str = "task_handoff",
    max_chars: int = 4000,
    scope_selection: Optional[ScopeSelection] = None,
) -> ContextPack:
    session = self.session_mgr.get_active_session(session_id) or self.storage.get_session(session_id)
    if session is None:
        raise ValueError(f"Session '{session_id}' not found")
    brief = self.session_brief(session_id, scope_selection=scope_selection)
    if brief is None:
        raise ValueError(f"Session '{session_id}' not found")
    builder = ContextPackBuilder(self.storage, Diagnostics(self.storage, self.config))
    return builder.build(
        session=session,
        goal=goal,
        max_chars=max_chars,
        session_brief=brief,
    )


def transfer_context(
    self,
    *,
    from_session_id: str,
    to_agent_id: str,
    note: str = "",
    goal: str = "task_handoff",
    scope_selection: Optional[ScopeSelection] = None,
) -> ContextTransferResult:
    source_session = self.session_mgr.get_active_session(from_session_id) or self.storage.get_session(from_session_id)
    if source_session is None:
        raise ValueError(f"Session '{from_session_id}' not found")
    if any(
        active.agent_id == to_agent_id
        for active in self.session_mgr._active.values()
    ):
        raise SessionError(f"Agent '{to_agent_id}' already has an active session")
    target_scope_id = source_session.scope_id
    if scope_selection is not None and scope_selection.primary_scope_id is not None:
        resolved = self.scope_service.resolve_selection(scope_selection)
        if source_session.scope_id is not None and scope_selection.primary_scope_id not in resolved.allowed_scope_ids:
            raise ValueError("transfer_context must not widen scope outside the source lineage")
        target_scope_id = scope_selection.primary_scope_id
    pack = self.build_context_pack(
        session_id=from_session_id,
        goal=goal,
        scope_selection=scope_selection,
    )
    target_session = self.start_session(
        to_agent_id,
        scope_id=target_scope_id,
        parent_session_id=from_session_id,
        metadata={
            "handoff_from_session_id": from_session_id,
            "handoff_from_agent_id": source_session.agent_id,
            "handoff_note": note,
            "handoff_goal": goal,
        },
    )
    self.session_mgr.log_event(
        from_session_id,
        "context_transferred",
        target=target_session.session_id,
        detail={"to_agent_id": to_agent_id, "goal": goal},
    )
    self.session_mgr.log_event(
        target_session.session_id,
        "context_received",
        target=from_session_id,
        detail={"from_agent_id": source_session.agent_id, "goal": goal},
    )
    return ContextTransferResult(pack=pack, target_session=target_session, transfer_note=note)
```

- [ ] **Step 4: Run the pack/transfer tests to verify they pass**

Run: `python -m pytest tests/test_session/test_transfer.py tests/test_engine.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/session/transfer.py engram/session/context.py engram/session/brief.py engram/engine.py engram/session/manager.py engram/storage/base.py engram/storage/sqlite_store.py tests/test_session/test_transfer.py tests/test_engine.py
git commit -m "feat: add context pack builder and transfer flow"
```

## Task 5: Expose `context-pack` and `context-transfer` Through SDK, CLI, and MCP

**Files:**
- Modify: `engram/integrations/sdk.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/integrations/mcp_server.py`
- Modify: `tests/test_integrations/test_sdk.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `tests/test_integrations/test_mcp_server.py`

- [ ] **Step 1: Write the failing surface tests for transfer features**

```python
def test_context_pack_cli_json(use_tmp_db, capsys):
    storage = SQLiteStorage(use_tmp_db)
    storage.initialize()
    session = Session(
        agent_id="planner",
        summary="Planner assembled the first draft.",
    )
    storage.save_session(session)
    storage.close()
    capsys.readouterr()

    code = main(["--db", use_tmp_db, "--json", "context-pack", session.session_id])
    payload = json.loads(capsys.readouterr().out)

    assert code == 0
    assert payload["source_session_id"] == session.session_id
```

```python
def test_sdk_build_context_pack_delegates_to_engine(monkeypatch):
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    called = {}

    def fake_build_context_pack(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "build_context_pack", fake_build_context_pack)

    result = sdk.build_context_pack(session_id="session-1")

    assert result == {"ok": True}
    assert called["session_id"] == "session-1"
    sdk.close()
```

```python
def test_sdk_transfer_context_delegates_to_engine(monkeypatch):
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    called = {}

    def fake_transfer_context(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "transfer_context", fake_transfer_context)

    result = sdk.transfer_context(
        from_session_id="session-1",
        to_agent_id="writer",
        note="Continue the memo.",
    )

    assert result == {"ok": True}
    assert called["to_agent_id"] == "writer"
    sdk.close()
```

- [ ] **Step 2: Run the transfer surface tests to verify they fail**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py -q`  
Expected: `FAIL` because the SDK methods, CLI commands, and MCP tools do not exist yet.

- [ ] **Step 3: Register the pack and transfer entrypoints**

```python
def build_context_pack(
    self,
    *,
    session_id: str,
    goal: str = "task_handoff",
    max_chars: int = 4000,
) -> ContextPack:
    return self.engine.build_context_pack(
        session_id=session_id,
        goal=goal,
        max_chars=max_chars,
    )


def transfer_context(
    self,
    *,
    from_session_id: str,
    to_agent_id: str,
    note: str = "",
    goal: str = "task_handoff",
    scope_selection: ScopeSelection | None = None,
) -> ContextTransferResult:
    return self.engine.transfer_context(
        from_session_id=from_session_id,
        to_agent_id=to_agent_id,
        note=note,
        goal=goal,
        scope_selection=scope_selection,
    )
```

```python
p = sub.add_parser("context-pack", help="Build a reusable context pack from a session")
p.add_argument("session_id")
p.add_argument("--goal", default="task_handoff")
p.add_argument("--max-chars", type=int, default=4000)

p = sub.add_parser("context-transfer", help="Create a new session from a source session handoff")
p.add_argument("session_id")
p.add_argument("to_agent_id")
p.add_argument("--note", default="")
p.add_argument("--goal", default="task_handoff")
p.add_argument("--scope-id", default=None, help="Optionally narrow the inherited scope")
```

```python
elif args.command == "context-pack":
    pack = engine.build_context_pack(
        session_id=args.session_id,
        goal=args.goal,
        max_chars=args.max_chars,
    )
    if args.json:
        print(json.dumps(pack.to_dict(), ensure_ascii=False))
    else:
        print(pack.rendered_text)

elif args.command == "context-transfer":
    scope_selection = (
        ScopeSelection(primary_scope_id=args.scope_id, include_ancestors=False, include_global=False)
        if args.scope_id
        else None
    )
    result = engine.transfer_context(
        from_session_id=args.session_id,
        to_agent_id=args.to_agent_id,
        note=args.note,
        goal=args.goal,
        scope_selection=scope_selection,
    )
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
    else:
        print(result.pack.rendered_text)
        print(f"Target session: {result.target_session.session_id}")
```

```python
@app.tool()
async def memory_context_pack(
    session_id: str,
    goal: str = "task_handoff",
    max_chars: int = 4000,
) -> str:
    """Build a reusable, masked context pack from one source session."""
    engine = _get_engine()
    pack = engine.build_context_pack(
        session_id=session_id,
        goal=goal,
        max_chars=max_chars,
    )
    return json.dumps(pack.to_dict(), ensure_ascii=False)


@app.tool()
async def memory_context_transfer(
    from_session_id: str,
    to_agent_id: str,
    note: str = "",
    goal: str = "task_handoff",
    scope_id: str = "",
) -> str:
    """Create a target session from a source-session handoff without widening scope."""
    engine = _get_engine()
    result = engine.transfer_context(
        from_session_id=from_session_id,
        to_agent_id=to_agent_id,
        note=note,
        goal=goal,
        scope_selection=(
            ScopeSelection(primary_scope_id=scope_id, include_ancestors=False, include_global=False)
            if scope_id
            else None
        ),
    )
    return json.dumps(result.to_dict(), ensure_ascii=False)
```

- [ ] **Step 4: Run the transfer surface tests to verify they pass**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/integrations/sdk.py engram/cli/app.py engram/integrations/mcp_server.py tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py
git commit -m "feat: expose context pack and transfer surfaces"
```

## Task 6: Implement `OperationsReviewService` and `MemoryEngine.run_operations_review()`

**Files:**
- Create: `engram/maintenance/review.py`
- Modify: `engram/engine.py`
- Test: `tests/test_maintenance/test_review.py`
- Test: `tests/test_engine.py`

This task is intentionally write-bearing. `run_operations_review()` must persist a maintenance run by calling `run_maintenance()`, so callers must not treat it as a read-only inspection API.

- [ ] **Step 1: Write the failing operations review tests**

```python
def test_run_operations_review_returns_health_maintenance_and_drift(engine):
    engine.create_entity("Lonely")

    review = engine.run_operations_review()

    assert review.health_report is not None
    assert review.maintenance_run is not None
    assert isinstance(review.reference_drift, list)
    assert isinstance(review.decision_drift, list)
    assert review.summary_lines


def test_run_operations_review_can_execute_jobs(engine):
    scope = engine.create_scope("project", "alpha")
    engine.store("Alice owns Alpha.", scope_id=scope.id)

    review = engine.run_operations_review(run_jobs=True, job_limit=10)

    assert review.job_result is not None
    assert review.job_result.completed >= 1
```

- [ ] **Step 2: Run the operations review tests to verify they fail**

Run: `python -m pytest tests/test_maintenance/test_review.py tests/test_engine.py -q`  
Expected: `FAIL` because `run_operations_review()` and `OperationsReviewService` do not exist yet.

- [ ] **Step 3: Implement the operations review orchestration**

```python
class OperationsReviewService:
    def __init__(
        self,
        *,
        health_report_fn,
        maintenance_run_fn,
        maintenance_view_fn,
        run_jobs_fn,
        reference_service: ReferenceService,
        decision_service: DecisionService,
        recommendation_service: RecommendationService,
    ) -> None:
        self.health_report_fn = health_report_fn
        self.maintenance_run_fn = maintenance_run_fn
        self.maintenance_view_fn = maintenance_view_fn
        self.run_jobs_fn = run_jobs_fn
        self.reference_service = reference_service
        self.decision_service = decision_service
        self.recommendation_service = recommendation_service

    def run(
        self,
        *,
        max_open_loops: int = 50,
        stale_days: int | None = None,
        run_jobs: bool = False,
        job_limit: int = 20,
        lease_owner: str = "operations_review",
        include_projection_drift: bool = True,
        include_recommendations: bool = True,
    ) -> OperationsReview:
        health_report = self.health_report_fn(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )
        persisted = self.maintenance_run_fn(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )
        maintenance_view = self.maintenance_view_fn(persisted.id)
        raw_job_result = (
            self.run_jobs_fn(limit=job_limit, lease_owner=lease_owner)
            if run_jobs
            else None
        )
        job_result = JobRunSummary.from_dict(raw_job_result) if raw_job_result else None
        reference_drift = (
            [ProjectionDriftItem.from_dict(row) for row in self.reference_service.projection_drift(limit=max_open_loops)]
            if include_projection_drift
            else []
        )
        decision_drift = (
            [ProjectionDriftItem.from_dict(row) for row in self.decision_service.projection_drift(limit=max_open_loops)]
            if include_projection_drift
            else []
        )
        recommendations = (
            self.recommendation_service.list_recommendations(
                limit=10,
                max_open_loops=max_open_loops,
                stale_days=stale_days,
            )
            if include_recommendations
            else []
        )
        summary_lines = [
            f"open_loops={len(health_report.open_loops)}",
            f"maintenance_grade={maintenance_view.run.grade if maintenance_view else 'unknown'}",
            f"jobs_completed={job_result.completed}" if job_result else "jobs_completed=skipped",
            f"reference_drift={len(reference_drift)}",
            f"decision_drift={len(decision_drift)}",
            f"recommendations={len(recommendations)}",
        ]
        return OperationsReview(
            health_report=health_report,
            maintenance_run=maintenance_view,
            job_result=job_result,
            reference_drift=reference_drift,
            decision_drift=decision_drift,
            recommendations=recommendations,
            summary_lines=summary_lines,
        )
```

```python
def run_operations_review(
    self,
    *,
    max_open_loops: int = 50,
    stale_days: int | None = None,
    run_jobs: bool = False,
    job_limit: int = 20,
    lease_owner: str = "operations_review",
    include_projection_drift: bool = True,
    include_recommendations: bool = True,
) -> OperationsReview:
    service = OperationsReviewService(
        health_report_fn=self.health_report,
        maintenance_run_fn=self.run_maintenance,
        maintenance_view_fn=self.get_maintenance_run,
        run_jobs_fn=self.run_jobs,
        reference_service=self.reference_service,
        decision_service=self.decision_service,
        recommendation_service=self.recommendation_service,
    )
    return service.run(
        max_open_loops=max_open_loops,
        stale_days=stale_days,
        run_jobs=run_jobs,
        job_limit=job_limit,
        lease_owner=lease_owner,
        include_projection_drift=include_projection_drift,
        include_recommendations=include_recommendations,
    )
```

- [ ] **Step 4: Run the operations review tests to verify they pass**

Run: `python -m pytest tests/test_maintenance/test_review.py tests/test_engine.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/maintenance/review.py engram/engine.py tests/test_maintenance/test_review.py tests/test_engine.py
git commit -m "feat: add operations review orchestration"
```

## Task 7: Expose `operations-review` and Add Naming Regression Tests

**Files:**
- Modify: `engram/integrations/sdk.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/integrations/mcp_server.py`
- Modify: `tests/test_integrations/test_sdk.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `tests/test_integrations/test_mcp_server.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: Write the failing operations-review and alias-boundary tests**

```python
def test_sdk_operations_review_delegates_to_engine(monkeypatch):
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    called = {}

    def fake_run_operations_review(**kwargs):
        called.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(sdk.engine, "run_operations_review", fake_run_operations_review)

    result = sdk.operations_review(run_jobs=True, job_limit=10)

    assert result == {"ok": True}
    assert called["run_jobs"] is True
    assert called["job_limit"] == 10
    sdk.close()
```

```python
def test_operations_review_cli_json(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])

    code = main(["--db", use_tmp_db, "--json", "operations-review"])
    payload = json.loads(capsys.readouterr().out)

    assert code == 0
    assert "summary_lines" in payload
    assert "maintenance_run" in payload


def test_cli_rejects_legacy_aliases():
    parser = _build_parser()
    for argv in (
        ["agentic-search", "alice"],
        ["agent-inject", "session-1"],
        ["agent-handoff", "session-1", "writer"],
        ["dream"],
    ):
        with pytest.raises(SystemExit):
            parser.parse_args(argv)
```

```python
def test_context_transfer_rejects_parallel_session_in_cli(use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    storage = SQLiteStorage(use_tmp_db)
    storage.initialize()
    source = Session(agent_id="planner", summary="Planner finished.")
    storage.save_session(source)
    target = Session(agent_id="writer")
    storage.save_session(target)
    storage.close()
    capsys.readouterr()

    code = main([
        "--db",
        use_tmp_db,
        "context-transfer",
        source.session_id,
        "writer",
    ])

    assert code == 1
```

```python
def test_engine_and_sdk_do_not_expose_legacy_names():
    from engram.engine import MemoryEngine
    from engram.integrations.sdk import EngramSDK

    assert not hasattr(MemoryEngine, "agentic_search")
    assert not hasattr(MemoryEngine, "agent_handoff")
    assert not hasattr(MemoryEngine, "dream")
    assert not hasattr(EngramSDK, "agentic_search")
    assert not hasattr(EngramSDK, "agent_inject")
    assert not hasattr(EngramSDK, "dream")
```

```python
def test_mcp_server_does_not_register_legacy_tool_names():
    from engram.integrations import mcp_server

    assert not hasattr(mcp_server, "memory_agentic_search")
    assert not hasattr(mcp_server, "memory_agent_handoff")
    assert not hasattr(mcp_server, "memory_dream")
```

- [ ] **Step 2: Run the operations-review and alias tests to verify they fail**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py tests/test_engine.py -q`  
Expected: `FAIL` because the new surface is not exposed and the alias-boundary tests do not pass yet.

- [ ] **Step 3: Register the last surface and keep the boundary explicit**

```python
def operations_review(
    self,
    *,
    max_open_loops: int = 50,
    stale_days: int | None = None,
    run_jobs: bool = False,
    job_limit: int = 20,
) -> OperationsReview:
    return self.engine.run_operations_review(
        max_open_loops=max_open_loops,
        stale_days=stale_days,
        run_jobs=run_jobs,
        job_limit=job_limit,
    )
```

```python
p = sub.add_parser("operations-review", help="Run a unified operations review")
p.add_argument("--max-loops", type=int, default=50)
p.add_argument("--stale-days", type=int, default=None)
p.add_argument("--run-jobs", action="store_true")
p.add_argument("--job-limit", type=int, default=20)
```

```python
elif args.command == "operations-review":
    result = engine.run_operations_review(
        max_open_loops=args.max_loops,
        stale_days=args.stale_days,
        run_jobs=args.run_jobs,
        job_limit=args.job_limit,
    )
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
    else:
        for line in result.summary_lines:
            print(line)
```

```python
@app.tool()
async def memory_operations_review(
    max_open_loops: int = 50,
    stale_days: int | None = None,
    run_jobs: bool = False,
    job_limit: int = 20,
) -> str:
    """Run a write-bearing operations review and return the persisted maintenance view."""
    engine = _get_engine()
    result = engine.run_operations_review(
        max_open_loops=max_open_loops,
        stale_days=stale_days,
        run_jobs=run_jobs,
        job_limit=job_limit,
    )
    return json.dumps(result.to_dict(), ensure_ascii=False)
```

- [ ] **Step 4: Run the operations-review and alias tests to verify they pass**

Run: `python -m pytest tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py tests/test_engine.py -q`  
Expected: `PASS`

- [ ] **Step 5: Commit**

```bash
git add engram/integrations/sdk.py engram/cli/app.py engram/integrations/mcp_server.py tests/test_integrations/test_sdk.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py tests/test_engine.py
git commit -m "feat: expose operations review and lock name boundary"
```

## Final Verification

- [ ] **Step 1: Run the focused regression suite**

Run:

```bash
python -m pytest tests/test_search/test_contextual.py tests/test_session/test_transfer.py tests/test_maintenance/test_review.py tests/test_integrations/test_sdk.py tests/test_storage/test_sqlite_store.py tests/test_session/test_manager.py tests/test_engine.py tests/test_cli/test_app.py tests/test_integrations/test_mcp_server.py -q
```

Expected: `PASS`

- [ ] **Step 2: Run the existing broader safety suite**

Run:

```bash
python -m pytest tests/test_search/test_reranker.py tests/test_session/test_working_memory.py tests/test_jobs/test_service.py tests/test_references/test_service.py tests/test_decisions/test_service.py tests/test_freshness/test_service.py tests/test_scopes/test_service.py tests/test_maintenance/test_service.py -q
```

Expected: `PASS`

- [ ] **Step 3: Confirm the public name boundary**

Run:

```bash
rg -n "agentic_search|agent_handoff|agent_inject|memory_agentic_search|memory_agent_handoff|memory_dream" engram tests
```

Expected: Only the explicit negative regression tests may mention those strings. No production file under `engram/` should expose them.
