# Follow-up Task Recommendation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `follow_up_task` as the final computed recommendation kind so Engram can elevate aged verification, governance, and actionable open-loop items into explicit next-work recommendations.

**Architecture:** Extend `RecommendationKind`, then add a `_follow_up_task_recommendations()` branch inside `RecommendationService` that reads open verification requests, open governance candidates, and current diagnostics. Reuse existing engine and CLI recommendation surfaces and add regression coverage for each source type.

**Tech Stack:** Python 3.9+, existing `RecommendationService`, `FreshnessService`, `Diagnostics`, argparse CLI, pytest

---

## File Map

- Modify: `engram/models/retention.py`
- Modify: `engram/recommendations/service.py`
- Modify: `engram/cli/app.py`
- Modify: `tests/test_engine.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

### Task 1: Add `follow_up_task` recommendation surface

**Files:**
- Modify: `engram/models/retention.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing test**

```python
def test_follow_up_task_kind_serializes():
    row = RecommendationView(
        kind=RecommendationKind.FOLLOW_UP_TASK,
        severity=RecommendationSeverity.WARNING,
        target_kind="verification_request",
        target_id="request-1",
        title="Follow up verification request",
        detail="Needs review",
        recommended_action="engram verification-show request-1",
    )

    assert row.to_dict()["kind"] == "follow_up_task"
```

- [ ] **Step 2: Run the test to verify RED**

Run: `python -m pytest tests/test_engine.py -q`
Expected: FAIL because `FOLLOW_UP_TASK` does not exist yet.

- [ ] **Step 3: Add the minimal enum value**

```python
class RecommendationKind(str, Enum):
    STALE_DECISION = "stale_decision"
    OPEN_LOOP_ESCALATION = "open_loop_escalation"
    MERGE_RECOMMENDATION = "merge_recommendation"
    FOLLOW_UP_TASK = "follow_up_task"
```

- [ ] **Step 4: Run the test to verify GREEN**

Run: `python -m pytest tests/test_engine.py -q`
Expected: enum failure disappears and remaining failures point to missing service logic.

### Task 2: Emit follow-up recommendations for verification requests

**Files:**
- Modify: `engram/recommendations/service.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: Write the failing test**

```python
def test_follow_up_task_emits_for_aged_verification_request(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns launch", predicate="role")
    fact = engine.get_facts("Alice")[0]
    request = engine.request_fact_verification(fact.id, reason="manual")
    request.requested_at = datetime.now() - timedelta(days=4)
    engine.storage.update_verification_request(request)

    rows = engine.list_recommendations(kind="follow_up_task")

    assert any(
        row.target_kind == "verification_request" and row.target_id == request.id
        for row in rows
    )
```

```python
def test_follow_up_task_skips_resolved_verification_request(engine):
    engine.create_entity("Alice")
    engine.add_fact("Alice", "Alice owns launch", predicate="role")
    fact = engine.get_facts("Alice")[0]
    request = engine.request_fact_verification(fact.id, reason="manual")
    engine.resolve_verification_request(request.id, VerificationResolution.VERIFIED)

    rows = engine.list_recommendations(kind="follow_up_task")

    assert all(row.target_id != request.id for row in rows)
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_engine.py -q`
Expected: FAIL because follow-up verification recommendations are not implemented.

- [ ] **Step 3: Implement verification follow-up generation**

```python
def _follow_up_task_recommendations(...):
    ...
    for request in self.storage.list_verification_requests(
        status=VerificationRequestStatus.OPEN,
        limit=max(limit * 4, 100),
    ):
        age_days = (datetime.now() - request.requested_at).days
        if age_days < 3:
            continue
        ...
```

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_engine.py -q`
Expected: PASS for verification follow-up cases.

### Task 3: Emit follow-up recommendations for governance candidates and actionable open loops

**Files:**
- Modify: `engram/recommendations/service.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: Write the failing tests**

```python
def test_follow_up_task_emits_for_open_split_candidate(engine):
    entity = engine.create_entity("Jordan Lee")
    for value in ("CTO", "HR Manager"):
        engine.storage.add_fact(
            Fact(
                entity_id=entity.id,
                subject="Jordan Lee",
                predicate="role",
                object=value,
                raw_text=f"Jordan Lee is {value}.",
                source=Source(type=SourceType.USER_INPUT, confidence=1.0),
            )
        )
    candidate = next(
        row for row in engine.generate_governance_candidates()
        if row.candidate_type is GovernanceCandidateType.SPLIT
    )
    candidate.created_at = datetime.now() - timedelta(days=4)
    candidate.updated_at = candidate.created_at
    engine.storage.upsert_governance_candidate(candidate)

    rows = engine.list_recommendations(kind="follow_up_task")

    assert any(
        row.target_kind == "governance_candidate" and row.target_id == candidate.id
        for row in rows
    )
```

```python
def test_follow_up_task_emits_for_critical_open_loop(engine):
    engine.create_entity("Lonely")
    engine.run_maintenance()
    engine.run_maintenance()
    engine.run_maintenance()

    rows = engine.list_recommendations(kind="follow_up_task")

    assert any(row.target_kind == "open_loop" for row in rows)
```

- [ ] **Step 2: Run the tests to verify RED**

Run: `python -m pytest tests/test_engine.py -q`
Expected: FAIL because governance/open-loop follow-up generation is not implemented.

- [ ] **Step 3: Implement governance and open-loop follow-up generation**

```python
for candidate in self.storage.list_governance_candidates(
    status=GovernanceCandidateStatus.OPEN,
    limit=max(limit * 4, 100),
):
    if candidate.candidate_type not in {GovernanceCandidateType.MERGE, GovernanceCandidateType.SPLIT}:
        continue
    ...

report = self.diagnostics.run(max_open_loops=max_open_loops, stale_days=stale_days)
for loop in report.open_loops:
    ...
```

- [ ] **Step 4: Run the tests to verify GREEN**

Run: `python -m pytest tests/test_engine.py -q`
Expected: PASS

### Task 4: Extend CLI filter support and regression coverage

**Files:**
- Modify: `engram/cli/app.py`
- Modify: `tests/test_cli/test_app.py`
- Modify: `docs/README.md`

- [ ] **Step 1: Write the failing CLI test**

```python
def test_recommendations_command_accepts_follow_up_task_kind(self, use_tmp_db, capsys):
    main(["--db", use_tmp_db, "--quiet", "init"])
    main(["--db", use_tmp_db, "create", "Alice"])
    main(["--db", use_tmp_db, "add-fact", "Alice", "Alice owns launch", "--predicate", "role"])
    capsys.readouterr()

    with sqlite3.connect(use_tmp_db) as conn:
        fact_id = conn.execute("SELECT id FROM facts LIMIT 1").fetchone()[0]
    main(["--db", use_tmp_db, "--quiet", "verification-request", "fact", fact_id, "--reason", "manual"])
    capsys.readouterr()
    with sqlite3.connect(use_tmp_db) as conn:
        conn.execute(
            "UPDATE verification_requests SET requested_at = ?",
            ("2000-01-01T00:00:00",),
        )
        conn.commit()

    main(["--db", use_tmp_db, "--json", "recommendations", "--kind", "follow_up_task"])
    rows = json.loads(capsys.readouterr().out)
    assert rows and rows[0]["kind"] == "follow_up_task"
```

- [ ] **Step 2: Run the test to verify RED**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: FAIL because CLI kind choices do not include `follow_up_task`.

- [ ] **Step 3: Add CLI support**

```python
p.add_argument(
    "--kind",
    choices=["stale_decision", "open_loop_escalation", "merge_recommendation", "follow_up_task"],
    default=None,
)
```

- [ ] **Step 4: Run the test to verify GREEN**

Run: `python -m pytest tests/test_cli/test_app.py -q`
Expected: PASS

### Task 5: Run focused and full regression verification

**Files:**
- Modify: none expected
- Test: `tests/test_engine.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Run focused verification**

Run: `python -m pytest tests/test_engine.py tests/test_cli/test_app.py -q`
Expected: PASS

- [ ] **Step 2: Run full suite**

Run: `python -m pytest tests -q`
Expected: PASS
