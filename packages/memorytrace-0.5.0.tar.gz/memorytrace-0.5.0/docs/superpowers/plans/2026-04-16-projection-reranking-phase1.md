# Projection and Reranking Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement the missing projection layer and goal-aware reranking layer that the current design already assumes.

**Architecture:** Extend SQLite storage with rebuildable projection tables and persisted maintenance history, then layer a reranker on top of existing FTS5 retrieval. Wire both through `MemoryEngine`, diagnostics, briefs, and CLI without changing canonical write semantics.

**Tech Stack:** Python 3.9+, sqlite3, dataclasses, existing `MemoryEngine`, argparse CLI, pytest.

---

## File Map

### New Files

- `C:/Users/qwaqw/Desktop/default/engram/models/reference.py`
- `C:/Users/qwaqw/Desktop/default/engram/models/decision.py`
- `C:/Users/qwaqw/Desktop/default/engram/models/maintenance.py`
- `C:/Users/qwaqw/Desktop/default/engram/references/service.py`
- `C:/Users/qwaqw/Desktop/default/engram/decisions/service.py`
- `C:/Users/qwaqw/Desktop/default/engram/maintenance/service.py`
- `C:/Users/qwaqw/Desktop/default/engram/search/reranker.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_references/test_service.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_decisions/test_service.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_maintenance/test_service.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_search/test_reranker.py`
- `C:/Users/qwaqw/Desktop/default/tests/fixtures/retrieval_scenarios.py`

### Modified Files

- `C:/Users/qwaqw/Desktop/default/engram/storage/migrations.py`
- `C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py`
- `C:/Users/qwaqw/Desktop/default/engram/models/search.py`
- `C:/Users/qwaqw/Desktop/default/engram/models/brief.py`
- `C:/Users/qwaqw/Desktop/default/engram/models/health.py`
- `C:/Users/qwaqw/Desktop/default/engram/quality/diagnostics.py`
- `C:/Users/qwaqw/Desktop/default/engram/debug/service.py`
- `C:/Users/qwaqw/Desktop/default/engram/session/manager.py`
- `C:/Users/qwaqw/Desktop/default/engram/session/brief.py`
- `C:/Users/qwaqw/Desktop/default/engram/engine.py`
- `C:/Users/qwaqw/Desktop/default/engram/cli/app.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_storage/test_migrations.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_engine.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_quality/test_diagnostics.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_cli/test_app.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_session/test_brief.py`
- `C:/Users/qwaqw/Desktop/default/tests/test_debug/test_service.py`

## Execution Slices

### Slice 1: Schema and Models

- Add migration v6 for projections and maintenance history
- Add projection and maintenance model dataclasses
- Add storage helpers for create/read/delete-by-source and list APIs

### Slice 2: Projection Services

- Implement `ReferenceService`
- Implement `DecisionService`
- Implement `MaintenanceService`
- Add `projection_drift` to diagnostics

### Slice 3: Engine and CLI Wiring

- Wire post-write indexing into note/session/debug flows
- Add engine APIs and rebuild APIs
- Add CLI commands for backlinks, decisions, and maintenance

### Slice 4: Reranking and Brief Support

- Add retrieval context and factor models
- Implement reranker
- Wire reranking into `MemoryEngine.search()`
- Add brief-level `supporting_hits`

### Slice 5: Verification and Cleanup

- Add regression tests for projections and reranking
- Run focused and full validation
- Fix findings
- Commit and push
