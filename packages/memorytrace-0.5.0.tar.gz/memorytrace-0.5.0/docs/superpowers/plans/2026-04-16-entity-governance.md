# Entity Governance Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a persisted entity governance workflow that detects duplicate entities, stores merge and alias candidates, and lets users approve or reject them safely.

**Architecture:** Extend SQLite with a governance candidate backlog, add a focused `EntityGovernanceService` for candidate generation and resolution, then expose it through engine, diagnostics, and CLI. Approved merge candidates delegate to an ID-safe merge path that also rebinds references and decisions.

**Tech Stack:** Python 3.9+, sqlite3, dataclasses, existing `MemoryEngine` / `SQLiteStorage` / `Diagnostics` / argparse CLI stack, pytest.

---

## File Structure

- Create: `engram/models/governance.py`
- Create: `engram/governance/__init__.py`
- Create: `engram/governance/service.py`
- Modify: `engram/models/health.py`
- Modify: `engram/storage/migrations.py`
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/engine.py`
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/cli/app.py`
- Modify: `docs/README.md`
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_governance/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_cli/test_app.py`

## Task 1: Add Governance Schema and Models

**Files:**
- Create: `engram/models/governance.py`
- Modify: `engram/storage/migrations.py`
- Test: `tests/test_storage/test_migrations.py`

- [ ] **Step 1: Write the failing migration test**

```python
def test_storage_initialize_adds_governance_candidates_table(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()
    with sqlite3.connect(db_path) as conn:
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        assert "governance_candidates" in tables
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_adds_governance_candidates_table -q`  
Expected: `FAIL` because migration v9 does not exist yet.

- [ ] **Step 3: Add minimal governance model and migration**

```python
class GovernanceCandidateType(str, Enum):
    MERGE = "merge"
    ALIAS = "alias"


class GovernanceCandidateStatus(str, Enum):
    OPEN = "open"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLIED = "applied"
    CANCELLED = "cancelled"
```

```python
CURRENT_VERSION = 9

def _migrate_v8_to_v9(conn: sqlite3.Connection) -> None:
    conn.executescript(
        '''
        CREATE TABLE IF NOT EXISTS governance_candidates (
            id TEXT PRIMARY KEY,
            candidate_type TEXT NOT NULL CHECK(candidate_type IN ('merge','alias')),
            status TEXT NOT NULL CHECK(status IN ('open','approved','rejected','applied','cancelled')),
            entity_id TEXT NOT NULL,
            related_entity_id TEXT,
            proposed_alias TEXT,
            score REAL NOT NULL DEFAULT 0.0,
            fingerprint TEXT NOT NULL,
            rationale TEXT NOT NULL DEFAULT '',
            details TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            resolved_at TEXT,
            resolved_by TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_governance_candidates_fingerprint
            ON governance_candidates(fingerprint);
        CREATE INDEX IF NOT EXISTS idx_governance_candidates_status
            ON governance_candidates(status, updated_at DESC);
        '''
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/test_storage/test_migrations.py::test_storage_initialize_adds_governance_candidates_table -q`  
Expected: `PASS`

## Task 2: Build Governance Service with Duplicate Detection

**Files:**
- Create: `engram/governance/__init__.py`
- Create: `engram/governance/service.py`
- Modify: `engram/storage/sqlite_store.py`
- Test: `tests/test_governance/test_service.py`

- [ ] **Step 1: Write the failing service tests**

```python
def test_generate_candidates_finds_duplicate_name_pair(engine):
    engine.create_entity("Simon Kim", entity_type="person")
    engine.create_entity("S. Kim", entity_type="person")
    secondary = engine.get_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)

    rows = engine.generate_governance_candidates()

    assert any(row.candidate_type is GovernanceCandidateType.MERGE for row in rows)


def test_generate_candidates_dedupes_on_rerun(engine):
    engine.create_entity("Alice Smith")
    engine.create_entity("A. Smith")
    secondary = engine.get_entity("A. Smith")
    secondary.aliases = ["Alice Smith"]
    engine.storage.update_entity(secondary)

    first = engine.generate_governance_candidates()
    second = engine.generate_governance_candidates()

    assert len(first) == len(second)
    assert {row.fingerprint for row in first} == {row.fingerprint for row in second}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_governance/test_service.py -q`  
Expected: `FAIL` because governance service and engine API do not exist.

- [ ] **Step 3: Implement storage helpers and candidate generation**

```python
class EntityGovernanceService:
    def generate_candidates(self, limit: int = 100) -> list[GovernanceCandidate]:
        entities = self.storage.list_entities(limit=5000)
        generated: list[GovernanceCandidate] = []
        for primary, secondary in self._iter_duplicate_pairs(entities):
            generated.append(self._upsert_merge_candidate(primary, secondary))
            alias = self.build_alias_candidate(primary, secondary.name)
            if alias is not None:
                generated.append(self.storage.upsert_governance_candidate(alias))
            if len(generated) >= limit:
                break
        return generated[:limit]

    def list_candidates(
        self,
        *,
        status: GovernanceCandidateStatus | None = None,
        candidate_type: GovernanceCandidateType | None = None,
        limit: int = 50,
    ) -> list[GovernanceCandidate]:
        return self.storage.list_governance_candidates(
            status=status,
            candidate_type=candidate_type,
            limit=limit,
        )
```

```python
def upsert_governance_candidate(self, candidate: GovernanceCandidate) -> GovernanceCandidate:
    self._conn.execute(
        """INSERT INTO governance_candidates (
               id, candidate_type, status, entity_id, related_entity_id,
               proposed_alias, score, fingerprint, rationale, details,
               created_at, updated_at, resolved_at, resolved_by
           ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(fingerprint) DO UPDATE SET
               score=excluded.score,
               rationale=excluded.rationale,
               details=excluded.details,
               updated_at=excluded.updated_at
           """,
        (
            candidate.id,
            candidate.candidate_type.value,
            candidate.status.value,
            candidate.entity_id,
            candidate.related_entity_id,
            candidate.proposed_alias,
            candidate.score,
            candidate.fingerprint,
            candidate.rationale,
            json.dumps(candidate.details, ensure_ascii=False),
            candidate.created_at.isoformat(),
            candidate.updated_at.isoformat(),
            candidate.resolved_at.isoformat() if candidate.resolved_at else None,
            candidate.resolved_by,
        ),
    )
    self._conn.commit()
    return self.get_governance_candidate_by_fingerprint(candidate.fingerprint)

def list_governance_candidates(
    self,
    *,
    status: GovernanceCandidateStatus | None = None,
    candidate_type: GovernanceCandidateType | None = None,
    limit: int = 50,
) -> list[GovernanceCandidate]:
    query = "SELECT * FROM governance_candidates WHERE 1=1"
    params: list[object] = []
    if status is not None:
        query += " AND status = ?"
        params.append(status.value)
    if candidate_type is not None:
        query += " AND candidate_type = ?"
        params.append(candidate_type.value)
    query += " ORDER BY score DESC, updated_at DESC LIMIT ?"
    params.append(limit)
    rows = self._conn.execute(query, params).fetchall()
    return [self._row_to_governance_candidate(row) for row in rows]
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python -m pytest tests/test_governance/test_service.py -q`  
Expected: `PASS`

## Task 3: Add Resolution Paths for Merge and Alias Approval

**Files:**
- Modify: `engram/storage/sqlite_store.py`
- Modify: `engram/engine.py`
- Modify: `engram/governance/service.py`
- Test: `tests/test_engine.py`

- [ ] **Step 1: Write the failing engine tests**

```python
def test_approve_merge_candidate_rebinds_facts_and_decisions(engine):
    primary = engine.create_entity("Simon Kim")
    secondary = engine.create_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)
    engine.store("S. Kim leads the platform team.")
    engine.add_note("We decided Simon Kim owns rollout.")
    engine.rebuild_decisions()
    candidate = next(
        row for row in engine.generate_governance_candidates()
        if row.candidate_type is GovernanceCandidateType.MERGE
    )

    resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)

    assert resolved.status is GovernanceCandidateStatus.APPLIED
    assert engine.get_entity("S. Kim") is None
    refreshed = engine.get_entity("Simon Kim")
    assert "S. Kim" in refreshed.aliases
    assert all(f.entity_id == primary.id for f in engine.get_facts("Simon Kim"))


def test_approve_alias_candidate_adds_alias_without_duplicate(engine):
    entity = engine.create_entity("Acme Labs")
    candidate = engine.governance_service.build_alias_candidate(entity, "Acme")

    engine.storage.upsert_governance_candidate(candidate)
    resolved = engine.resolve_governance_candidate(candidate.id, GovernanceResolution.APPROVE)
    refreshed = engine.get_entity("Acme Labs")

    assert resolved.status is GovernanceCandidateStatus.APPLIED
    assert refreshed.aliases.count("Acme") == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_engine.py::TestGovernance -q`  
Expected: `FAIL` because resolution APIs and entity-ID merge path do not exist.

- [ ] **Step 3: Implement resolution and ID-safe merge**

```python
def merge_entities_by_id(self, primary_id: str, secondary_id: str) -> Entity:
    primary = self.storage.get_entity(primary_id)
    secondary = self.storage.get_entity(secondary_id)
    if primary is None or secondary is None:
        raise EntityNotFoundError("merge target not found")
    secondary_relations = self.storage.get_relations(secondary.id)
    self.storage.transfer_facts(secondary.id, primary.id, primary.name)
    self.storage.transfer_relations(secondary.id, primary.id)
    self.storage.transfer_reference_edges(secondary.id, primary.id)
    self.storage.transfer_decisions(secondary.id, primary.id)
    if secondary.name not in primary.aliases:
        primary.aliases.append(secondary.name)
    for alias in secondary.aliases:
        if alias not in primary.aliases:
            primary.aliases.append(alias)
    self.storage.update_entity(primary)
    self.storage.delete_entity(secondary.id)
    self.storage.reindex_entity(primary)
    for relation in secondary_relations:
        for entity_id in (relation.from_entity_id, relation.to_entity_id):
            if entity_id not in {primary.id, secondary.id}:
                related = self.storage.get_entity(entity_id)
                if related is not None:
                    self.storage.reindex_entity(related)
    return primary

def resolve_governance_candidate(
    self,
    candidate_id: str,
    resolution: GovernanceResolution,
    resolved_by: str = "user",
) -> GovernanceCandidate:
    return self.governance_service.resolve_candidate(
        candidate_id,
        resolution=resolution,
        resolved_by=resolved_by,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python -m pytest tests/test_engine.py::TestGovernance -q`  
Expected: `PASS`

## Task 4: Add Diagnostics and CLI Surface

**Files:**
- Modify: `engram/models/health.py`
- Modify: `engram/quality/diagnostics.py`
- Modify: `engram/cli/app.py`
- Modify: `engram/engine.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Write the failing diagnostics and CLI tests**

```python
def test_health_report_flags_governance_backlog(engine):
    engine.create_entity("Simon Kim")
    engine.create_entity("S. Kim")
    secondary = engine.get_entity("S. Kim")
    secondary.aliases = ["Simon Kim"]
    engine.storage.update_entity(secondary)
    engine.generate_governance_candidates()

    report = engine.health_report()

    assert any(loop.kind.value == "entity_governance" for loop in report.open_loops)


def test_governance_cli_run_and_resolve(tmp_path):
    db = tmp_path / "memory.db"
    main(["--db", str(db), "create", "Simon Kim"])
    main(["--db", str(db), "create", "S. Kim"])
    main(["--db", str(db), "update-alias", "S. Kim", "Simon Kim"])
    main(["--db", str(db), "governance-run"])
    rows = json.loads(run_cli_json(db, "governance-list"))
    candidate_id = rows[0]["id"]
    main(["--db", str(db), "governance-resolve", candidate_id, "approve"])
    resolved = json.loads(run_cli_json(db, "governance-show", candidate_id))
    assert resolved["status"] == "applied"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_quality/test_diagnostics.py::TestGovernanceDiagnostics tests/test_cli/test_app.py::TestCLIGovernance -q`  
Expected: `FAIL` because diagnostics kind and CLI commands do not exist.

- [ ] **Step 3: Implement diagnostics and CLI**

```python
class LoopKind(str, Enum):
    ENTITY_GOVERNANCE = "entity_governance"
```

```python
p = sub.add_parser("governance-run", help="Generate governance candidates")
p = sub.add_parser("governance-list", help="List governance candidates")
p = sub.add_parser("governance-show", help="Show one governance candidate")
p = sub.add_parser("governance-resolve", help="Approve or reject a governance candidate")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python -m pytest tests/test_quality/test_diagnostics.py::TestGovernanceDiagnostics tests/test_cli/test_app.py::TestCLIGovernance -q`  
Expected: `PASS`

## Task 5: Full Regression

**Files:**
- Modify: `docs/README.md`
- Test: `tests/test_storage/test_migrations.py`
- Test: `tests/test_governance/test_service.py`
- Test: `tests/test_engine.py`
- Test: `tests/test_quality/test_diagnostics.py`
- Test: `tests/test_cli/test_app.py`

- [ ] **Step 1: Add docs index links**

```markdown
| [2026-04-16-entity-governance-design.md](./superpowers/specs/2026-04-16-entity-governance-design.md) | entity governance design |
| [2026-04-16-entity-governance.md](./superpowers/plans/2026-04-16-entity-governance.md) | entity governance implementation plan |
```

- [ ] **Step 2: Run focused regression**

Run: `python -m pytest tests/test_storage/test_migrations.py tests/test_governance/test_service.py tests/test_engine.py tests/test_quality/test_diagnostics.py tests/test_cli/test_app.py -q`  
Expected: `PASS`

- [ ] **Step 3: Run full suite**

Run: `python -m pytest tests -q`  
Expected: `PASS`
