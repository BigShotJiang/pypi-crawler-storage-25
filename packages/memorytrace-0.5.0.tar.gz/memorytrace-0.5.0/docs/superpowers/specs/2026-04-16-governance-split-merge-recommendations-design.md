# Split Governance and Merge Recommendation Design

## Goal

Extend the existing entity-governance loop with reviewable split candidates and add a computed merge recommendation view so Engram can flag likely over-merged entities and surface actionable merge work without introducing another persisted recommendation backlog.

This iteration closes the remaining practical gap between the governance backlog and the recommendation layer:
- persisted `split` governance candidates
- computed `merge_recommendation` views derived from open merge candidates

## Scope

In scope:
- add `split` to `GovernanceCandidateType`
- generate conservative split candidates from conflicting entity state and heterogeneous fact patterns
- persist split candidates in the existing `governance_candidates` table
- allow users to inspect and resolve split candidates
- expose computed `merge_recommendation` rows through the existing recommendation surface
- add CLI support to filter governance backlog and recommendations by the new types

Out of scope for this iteration:
- automatic split execution
- automatic merge approval
- `follow_up_task` recommendations
- embedding- or fuzzy-similarity duplicate detection
- persisted recommendation backlog

## Approach Options

### 1. Computed split suggestions only

Detect split candidates on demand and never persist them.

Pros:
- smallest code change
- no model changes

Cons:
- no review backlog
- no diagnostics continuity
- inconsistent with how merge and alias governance already work

### 2. Persisted split candidates plus computed merge recommendations (recommended)

Keep governance actions in the governance backlog and keep recommendations as computed views.

Pros:
- consistent with current Engram architecture
- split review items stay auditable and deduped
- merge recommendations remain fresh and do not need lifecycle cleanup

Cons:
- adds one more governance candidate type
- recommendation serialization must expand

### 3. Persist both split and merge recommendations

Store split candidates and a separate merge-recommendation backlog.

Pros:
- strongest audit trail

Cons:
- duplicates information already present in open merge candidates
- recommendation rows would drift and require cleanup rules
- too much operational complexity for this phase

## Architecture

The recommended approach is option 2.

This phase keeps a clean boundary:

1. `EntityGovernanceService`
- still owns persisted review work
- now emits `split` candidates in addition to `merge` and `alias`
- resolves split candidates strictly as review outcomes, not as automated entity mutation

2. `RecommendationService`
- keeps recommendations computed at read time
- adds `merge_recommendation` derived from open merge candidates
- suppresses recommendation rows when retention or governance state already makes them redundant

3. engine plus CLI surface
- exposes the new governance type through existing governance commands
- exposes the new recommendation kind through existing recommendation commands

## Data Model

### Governance

Reuse the existing `governance_candidates` table.

Add one enum value:
- `split`

Split candidates use:
- `entity_id`: the entity suspected to contain mixed identity
- `related_entity_id`: `NULL`
- `proposed_alias`: `NULL`
- `details`: JSON payload describing why the split was suggested

Expected `details` keys:
- `entity_name`
- `conflicting_predicates`
- `conflicting_values`
- `supporting_fact_ids`
- `suggested_action`

### Recommendations

Reuse `RecommendationView` and add one enum value:
- `merge_recommendation`

Recommendation shape stays unchanged:
- `kind`
- `severity`
- `target_kind`
- `target_id`
- `title`
- `detail`
- `recommended_action`
- `evidence`
- `policy_conflicts`

For merge recommendations:
- `target_kind = "governance_candidate"`
- `target_id = <merge candidate id>`

## Split Candidate Detection

This phase deliberately uses conservative heuristics. A split candidate is generated only when an entity has evidence that strongly suggests multiple incompatible identities were collapsed into one.

Generate a split candidate when all are true:
- the entity has at least two current facts
- at least one monitored predicate has conflicting distinct values
- the conflicts are not already explained by normal multi-valued attributes

Monitored predicates in this phase:
- `role`
- `affiliation`
- `location`
- `email`

Conflict rules:
- compare current facts only
- normalize whitespace and lowercase before comparing
- ignore empty values
- require at least two distinct values for a monitored predicate

Noise control:
- do not generate split candidates for entities with fewer than two current facts
- do not generate split candidates from `attribute` predicate
- dedupe by fingerprint over `entity_id + conflicting predicate set + normalized value set`

This phase does not attempt graph clustering or relation-based entity decomposition.

## Split Resolution Semantics

Split candidates are review-only in this phase.

Approving a split candidate means:
- mark it `approved`
- immediately mark it `applied`
- do not mutate entities automatically

Why:
- a real split requires target naming, fact partitioning, and relation reassignment choices that cannot be done safely without another dedicated workflow
- Engram should not guess a second entity shape yet

Rejecting a split candidate means:
- mark it `rejected`
- keep the entity unchanged

This makes split governance immediately useful as backlog and diagnostics input without introducing unsafe automatic rewrites.

## Merge Recommendation Semantics

Generate a `merge_recommendation` when:
- a governance candidate is open
- candidate type is `merge`
- the candidate is not suppressed by policy or already represented by a stronger recommendation

Severity rules:
- `critical` when candidate score is `>= 0.95`
- `warning` otherwise

Evidence should include:
- candidate score
- rationale
- primary and secondary names
- relevant alias overlap

Policy interaction:
- if either entity is pinned, keep the recommendation but append `policy_conflicts = ["pin"]`
- `archive_only` does not suppress the recommendation because governance review is operational, not retrieval-facing

This phase intentionally keeps merge recommendations advisory only. Users still resolve the underlying governance candidate through `governance-resolve`.

## Engine and CLI Surface

### Engine

No new top-level engine methods are required.

Existing methods extend naturally:
- `generate_governance_candidates()` returns `split` candidates too
- `list_governance_candidates(candidate_type=...)` accepts `split`
- `list_recommendations(kind=...)` accepts `merge_recommendation`

### CLI

Extend existing commands:
- `governance-list --type split`
- `recommendations --kind merge_recommendation`

`governance-run` should emit split candidates together with merge and alias candidates.

`governance-resolve` should continue to accept `approve` and `reject` with split candidates handled through the review-only semantics above.

## Diagnostics

No new open-loop kind is needed.

Open split candidates already contribute to the existing `entity_governance` backlog metric. This phase relies on that shared bucket and avoids introducing a second governance loop kind prematurely.

## Error Handling

- split candidate generation is best-effort; one malformed entity should not abort the full scan
- resolving an already closed split candidate still errors, same as merge/alias
- approving a split candidate must not mutate data if the source entity disappears between generation and resolution; it should fail cleanly with `EntityNotFoundError`

## Testing

Minimum test coverage:
- split candidate detection for conflicting monitored facts
- no split candidate for benign single-value entities
- split candidates dedupe across reruns
- split candidate approve path reaches `applied` without mutating facts or relations
- merge recommendations appear for open merge candidates
- pinned entities still surface merge recommendations with `policy_conflicts`
- CLI filters support `split` and `merge_recommendation`

## Rollout Notes

This phase intentionally stops before full split execution and before follow-up task recommendations. It creates the review and recommendation surface first, so later phases can add richer execution flows without redesigning the governance and recommendation contracts.
