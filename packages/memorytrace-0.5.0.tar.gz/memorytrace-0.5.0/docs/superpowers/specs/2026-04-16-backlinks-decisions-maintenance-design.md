# Backlinks, Decisions, and Dream Cycle-lite Design

## Summary

This document defines a structured projection layer for three new capabilities in Engram:

1. `backlinks` built from entity references found in existing text-bearing sources
2. `decision distillation` built from session, debug, and selected note content
3. `Dream Cycle-lite` built as a persisted maintenance run over Engram health data

The design keeps Engram's current source-of-truth model intact:

- canonical memory stays in existing SQLite tables such as `entities`, `facts`, `notes`, `sessions`, `debug_*`
- new data is stored as rebuildable projections, not as replacement primary records
- projection failures must never roll back the main write path

## Goals

- Add entity-centric backlinks without adopting Markdown wiki-link syntax as a core data model.
- Add structured, queryable decisions that survive beyond raw notes and summaries.
- Add a persisted maintenance workflow that captures what Engram saw during a health run.
- Preserve Engram's existing engine-first, SQLite-first, quality-gated architecture.
- Keep all projections idempotent and rebuildable from source rows.

## Non-Goals

- No fuzzy or semantic entity matching in phase 1.
- No automatic source rewrites that insert wiki-links into notes or summaries.
- No background job system, scheduler, or daemon in phase 1.
- No LLM dependency for extraction in phase 1.
- No changes to the canonical meaning of `notes`, `facts`, `sessions`, or `debug` records.

## Current Context

Engram already has:

- structured storage in [engram/storage/sqlite_store.py](/C:/Users/qwaqw/Desktop/default/engram/storage/sqlite_store.py)
- health and open-loop diagnostics in [engram/quality/diagnostics.py](/C:/Users/qwaqw/Desktop/default/engram/quality/diagnostics.py)
- entity/session briefs in [engram/session/brief.py](/C:/Users/qwaqw/Desktop/default/engram/session/brief.py)
- intake, debug, snapshot, and MCP integration paths through [engram/engine.py](/C:/Users/qwaqw/Desktop/default/engram/engine.py) and [engram/cli/app.py](/C:/Users/qwaqw/Desktop/default/engram/cli/app.py)

The new work should extend those paths rather than introduce a second memory system.

## Design Principles

### 1. Projections, Not Replacement Storage

`reference_edges` and `decisions` are derived views over existing source rows. They can be deleted and rebuilt without data loss because the canonical source remains elsewhere.

### 2. Persist First, Project Second

Primary writes succeed before projection indexing begins. Projection indexing is best-effort within the same command execution, but it does not own transaction success for the primary write.

### 3. Source-Scoped Idempotency

Each source row is re-indexed via full replacement of its derived projections. Re-running indexing must not create duplicates.

### 4. Conservative Extraction

False positives are more damaging than missed matches in phase 1. Matching rules stay strict and explicit.

### 5. Full Rebuildability

Every projection table must be recoverable from existing canonical rows using explicit rebuild commands.

## Architecture Overview

Three new domains are introduced:

### References

Owns backlink generation from text-bearing sources. It produces `reference_edges` and powers entity backlink queries.

### Decisions

Owns decision extraction and normalization from session summaries, debug conclusions, and narrowly selected notes. It produces `decisions`.

### Maintenance

Owns persisted health runs. It stores `maintenance_runs` and `maintenance_run_items`, allowing historical review of what the system flagged at a point in time.

The engine remains the orchestrator:

- write data through existing storage and quality gates
- call projection services after canonical writes complete
- expose read APIs and CLI commands for backlinks, decisions, and maintenance runs

## Data Model

## `reference_edges`

Purpose: represent an entity mention found inside a specific source row.

Columns:

- `id TEXT PRIMARY KEY`
- `entity_id TEXT NOT NULL`
- `source_kind TEXT NOT NULL`
- `source_id TEXT NOT NULL`
- `snippet TEXT NOT NULL DEFAULT ''`
- `matched_text TEXT NOT NULL DEFAULT ''`
- `match_start INTEGER NOT NULL`
- `match_end INTEGER NOT NULL`
- `created_at TEXT NOT NULL`
- `indexed_at TEXT NOT NULL`

Indexes and constraints:

- `INDEX idx_reference_edges_entity ON reference_edges(entity_id, indexed_at DESC)`
- `INDEX idx_reference_edges_source ON reference_edges(source_kind, source_id)`
- `UNIQUE(entity_id, source_kind, source_id, match_start, match_end)`

Source kinds allowed in phase 1:

- `note`
- `session`
- `debug_session`
- `debug_hypothesis`
- `debug_evidence`

Why this shape:

- `source_kind + source_id` supports source-scoped replacement
- `match_start + match_end` distinguishes multiple mentions within the same source
- `snippet` avoids reloading full source text for common backlink rendering

## `decisions`

Purpose: represent a structured decision distilled from canonical sources.

Columns:

- `id TEXT PRIMARY KEY`
- `fingerprint TEXT NOT NULL`
- `title TEXT NOT NULL`
- `summary TEXT NOT NULL`
- `status TEXT NOT NULL CHECK(status IN ('active','superseded','draft'))`
- `confidence REAL NOT NULL`
- `source_kind TEXT NOT NULL`
- `source_id TEXT NOT NULL`
- `entity_id TEXT`
- `session_id TEXT`
- `created_at TEXT NOT NULL`
- `indexed_at TEXT NOT NULL`
- `superseded_by TEXT`

Indexes and constraints:

- `UNIQUE(fingerprint)`
- `INDEX idx_decisions_source ON decisions(source_kind, source_id)`
- `INDEX idx_decisions_status ON decisions(status, indexed_at DESC)`
- `INDEX idx_decisions_entity ON decisions(entity_id, indexed_at DESC)`

Source kinds allowed in phase 1:

- `session`
- `debug_session`
- `note`

Why this shape:

- `fingerprint` prevents duplicate decision rows across retries
- `source_kind + source_id` allows full replacement for a single source
- `entity_id` and `session_id` support briefing and audit use cases without changing canonical tables

## `maintenance_runs`

Purpose: persist a summary of one Dream Cycle-lite execution.

Columns:

- `id TEXT PRIMARY KEY`
- `started_at TEXT NOT NULL`
- `completed_at TEXT NOT NULL`
- `grade TEXT NOT NULL`
- `score_value REAL NOT NULL`
- `summary TEXT NOT NULL DEFAULT ''`
- `metadata TEXT NOT NULL DEFAULT '{}'`

Indexes:

- `INDEX idx_maintenance_runs_completed ON maintenance_runs(completed_at DESC)`

## `maintenance_run_items`

Purpose: persist the concrete open loops captured during one maintenance run.

Columns:

- `id TEXT PRIMARY KEY`
- `run_id TEXT NOT NULL REFERENCES maintenance_runs(id) ON DELETE CASCADE`
- `kind TEXT NOT NULL`
- `severity TEXT NOT NULL`
- `target_id TEXT`
- `entity_name TEXT`
- `title TEXT NOT NULL`
- `detail TEXT NOT NULL DEFAULT ''`
- `recommended_action TEXT`
- `created_at TEXT NOT NULL`

Indexes:

- `INDEX idx_maintenance_run_items_run ON maintenance_run_items(run_id)`
- `INDEX idx_maintenance_run_items_kind ON maintenance_run_items(kind, severity)`

Why a child table is required:

- run-level grade and summary alone are not enough for auditability
- historical comparison requires the concrete loop set, not only aggregate counts

## Source Ownership and Integrity Model

SQLite foreign keys cannot cleanly enforce polymorphic references across `note`, `session`, and `debug_*` sources. This design uses ownership rules instead:

- each projection row belongs to exactly one canonical source row
- the writer for that source is responsible for replace and cleanup
- all projection tables are rebuildable from canonical rows

Operational contract:

- reindexing one source first deletes all projection rows for that source
- deleting one source must delete all projection rows for that source
- entity rename or alias update does not mutate projection rows directly; it triggers a rebuild path

This keeps correctness achievable without pretending polymorphic FK guarantees exist.

## Write Path Contract

The canonical write path stays authoritative.

### Store

1. Existing Engram logic writes entities, facts, and note rows.
2. After note persistence succeeds, the engine calls `index_source("note", note_id)`.
3. Projection failures are recorded as operational signals but do not roll back the note or fact write.

### Intake Apply

1. Intake apply keeps its current quality-gated behavior.
2. Only successfully applied canonical writes are eligible for projection indexing.
3. Pending or rejected staging rows produce no `reference_edges` or `decisions`.

### Debug

After saving each canonical debug source:

- `debug_hypothesis` -> `index_source("debug_hypothesis", hypothesis_id)`
- `debug_evidence` -> `index_source("debug_evidence", evidence_id)`
- `debug_conclude` -> `index_source("debug_session", debug_session_id)`

### Session End

After `sessions.summary` is saved:

- `index_source("session", session_id)`

## Projection Indexing Contract

`index_source(source_kind, source_id)` performs:

1. load the canonical source text and context
2. replace references for that source
3. replace decisions for that source when the source kind supports decision extraction

Phase 1 behavior:

- references run for all supported source kinds
- decisions run only for `session`, `debug_session`, and selected `note` sources

Failure contract:

- projection indexing failure does not mark the canonical write as failed
- projection failures are surfaced through maintenance drift checks and optional session/debug events

## Extraction Rules

## References

Matching order:

1. canonical entity name exact match under normalized text comparison
2. alias exact match under normalized text comparison

Phase 1 exclusions:

- single-character names
- alias values in a stopword or reserved-word denylist
- overly generic tokens that cause noisy backlinks

Phase 1 explicitly does not support:

- fuzzy matching
- edit-distance matching
- semantic mention inference

Rationale:

- backlink trust matters more than raw recall in early iterations

## Decisions

Source coverage in phase 1:

- all `session.summary` values
- all `debug_session.conclusion` values
- notes only when they match decision-intent heuristics strongly enough

Decision rules use deterministic pattern matching for Korean and English phrases that imply commitment or resolution. Statements that remain speculative are excluded.

Included examples:

- `decided to`
- `we will`
- `agreed to`
- `결정`
- `하기로`
- `채택`
- `보류`

Excluded examples:

- `maybe`
- `might`
- `considering`
- `아마`
- `검토 중`
- `가능할 듯`

Status mapping in phase 1:

- clear commitment -> `active`
- explicit hold or provisional wording -> `draft`
- `superseded` is set only by later explicit logic, not by initial extraction

## Backlink Query Model

`backlinks(entity_name)` returns grouped source references for one entity.

Phase 1 fields exposed to callers:

- entity
- source kind
- source id
- snippet
- matched text
- indexed timestamp

Optional filters:

- source kind
- limit
- JSON vs text rendering

This is intentionally narrower than a full graph traversal product.

## Maintenance Model

Dream Cycle-lite is a persisted run over current health and projection state.

Phase 1 maintenance checks:

- unresolved conflicts
- missing source facts
- stale facts
- orphan entities
- projection drift

Projection drift means one of:

- a canonical source exists but no supported projection row exists after indexing should have happened
- a projection row exists but is older than the canonical source update in a way that indicates stale indexing

Each maintenance run:

1. computes a live `HealthReport`
2. augments it with projection drift checks
3. persists one `maintenance_runs` row
4. persists one `maintenance_run_items` row per open loop snapshot

## CLI Surface

Phase 1 commands:

- `engram-advanced backlinks "Entity Name"`
- `engram-advanced backlinks "Entity Name" --kind note`
- `engram-advanced backlinks "Entity Name" --json`
- `engram-advanced decisions`
- `engram-advanced decisions --entity "Entity Name"`
- `engram-advanced decisions --status active`
- `engram-advanced decision-show <decision_id>`
- `engram-advanced maintenance-run`
- `engram-advanced maintenance-list`
- `engram-advanced maintenance-show <run_id>`
- `engram-advanced rebuild-references`
- `engram-advanced rebuild-decisions`
- `engram-advanced rebuild-projections`

Phase 1 does not add write-oriented manual editing commands for decisions or references.

## Module Layout

New modules:

- `engram/models/reference.py`
- `engram/models/decision.py`
- `engram/models/maintenance.py`
- `engram/references/service.py`
- `engram/decisions/service.py`
- `engram/maintenance/service.py`

Likely modified modules:

- `engram/storage/base.py`
- `engram/storage/sqlite_store.py`
- `engram/storage/migrations.py`
- `engram/engine.py`
- `engram/cli/app.py`
- `engram/quality/diagnostics.py`
- `engram/snapshots/service.py`
- related tests under `tests/`

Responsibility split:

- storage owns persistence primitives and rebuild enumeration helpers
- services own extraction, replacement, and read models
- engine wires service calls into canonical write paths
- CLI only renders structured results

## Snapshot and Restore Expectations

Projection tables are part of the SQLite database and therefore part of snapshots automatically once schema support is added.

Required behavior:

- snapshot create captures projection rows
- snapshot restore preserves projection rows
- snapshot diff can continue to work without projection-specific semantics in phase 1

Non-goal for phase 1:

- no dedicated snapshot timeline view for decisions or backlinks yet

## Testing Strategy

### References

- entity name match creates expected backlinks
- alias match creates expected backlinks
- denylisted or too-short names do not create backlinks
- reindexing the same source replaces rows rather than duplicating them
- deleting a source clears its projection rows

### Decisions

- Korean and English decision phrases extract expected decision records
- speculative wording does not create decision rows
- reindexing one source replaces decisions for that source
- `debug_session` and `session` paths create decisions after canonical writes

### Maintenance

- `maintenance-run` creates one run and the expected child items
- projection drift creates actionable maintenance items
- run history is queryable after multiple runs

### Integration

- `store` then `backlinks` returns note backlinks
- `session end` then `decisions` returns session-derived decisions
- `debug conclude` then `decisions` returns debug-derived decisions
- rebuild commands recreate the same projection outcome from canonical rows
- snapshots preserve projection rows end to end

## Risks and Mitigations

### Risk: Noisy Backlinks

Cause:

- aliases or short names collide with common words

Mitigation:

- exact normalized matching only
- stopword denylist
- short-token exclusion

### Risk: Decision Over-Extraction

Cause:

- notes contain planning language that is not actually resolved

Mitigation:

- narrow source coverage in phase 1
- rule-first extraction
- conservative status mapping

### Risk: Projection Drift

Cause:

- post-write indexing can fail independently from canonical writes

Mitigation:

- rebuild commands
- persisted maintenance drift checks
- source-scoped replace semantics

### Risk: Write Latency Growth

Cause:

- too much indexing logic runs inline after every write

Mitigation:

- source-local indexing only
- no global scans on normal write paths
- rebuild commands handle full recovery scenarios

## Implementation Phasing

### Phase 1: References

- add schema and storage support for `reference_edges`
- add reference models and service
- add post-write note/session/debug indexing hooks
- add backlink query APIs and CLI
- add rebuild command

### Phase 2: Decisions

- add schema and storage support for `decisions`
- add decision models and service
- add source-scoped replace and fingerprint logic
- wire session/debug/note extraction into indexing
- add list/show CLI commands

### Phase 3: Dream Cycle-lite

- add schema and storage support for `maintenance_runs` and `maintenance_run_items`
- extend diagnostics with projection drift
- add maintenance run/list/show APIs and CLI

## Acceptance Criteria

- backlink queries return stable, non-duplicated results from indexed canonical sources
- decision extraction is idempotent under repeated indexing of the same source
- maintenance runs persist both summary and per-item results
- rebuild commands can reconstruct projection state from canonical rows
- canonical writes still succeed when projection indexing fails

## Rollout Guidance

Implementation should land in three independently testable slices matching the three phases. Each phase should preserve a green test suite before the next one starts. References should land first because both decisions and maintenance depend on projection infrastructure and rebuild semantics.
