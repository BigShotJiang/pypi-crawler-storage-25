# Context Search, Handoff, and Operations Review Design

## Goal

Introduce Engram-native interfaces for the three previously shortlisted capabilities that were selected as practically useful:

1. goal-aware retrieval
2. agent-to-agent context handoff
3. unified operational review

The key constraint for this phase is explicit:

- Engram must not reuse legacy external command or API names

This design therefore treats the problem as both a capability design and a surface-design problem. The system should gain the useful behavior, but expose it through Engram-specific commands, engine methods, SDK methods, and MCP tools.

## Scope

In scope:

- add an Engram-native contextual retrieval surface
- add an Engram-native context pack and context transfer surface
- add an Engram-native operations review surface that composes existing maintenance/health functionality
- keep current `search`, `maintenance-run`, `health-report`, `session-brief`, `jobs-run` behavior backward compatible
- define exact CLI, engine, SDK, and MCP names
- define tests that prove forbidden legacy aliases were not introduced

Out of scope:

- legacy external command compatibility
- channel JSON persistence
- task register / retrospective workflow
- wiki-link suggestion workflow
- new memory type expansion
- automatic task delegation outside Engram
- automatic entity splitting during handoff
- new durable tables for handoff history in phase 1

## Naming Constraints

### Disallowed names

The following legacy external names are explicitly forbidden in Engram user-facing surfaces:

- `agentic_search`
- `agent_inject`
- `agent_handoff`
- `dream`
- `channel_save`
- `channel_load`
- `channel_update`

No CLI alias, SDK alias, MCP tool, or engine convenience wrapper should expose these names.

### Required Engram-native names

| Capability | Engine / SDK | CLI | MCP |
|---|---|---|---|
| goal-aware retrieval | `search_context()` | `context-search` | `memory_context_search` |
| context bundle generation | `build_context_pack()` | `context-pack` | `memory_context_pack` |
| agent handoff | `transfer_context()` | `context-transfer` | `memory_context_transfer` |
| unified operational review | `run_operations_review()` | `operations-review` | `memory_operations_review` |

These names are intentionally explicit:

- `context` is the Engram concept, not `agentic`
- `transfer` is clearer than `handoff`
- `operations review` is an operational summary, not a metaphor like `dream`

## Approach Options

### 1. Mirror legacy external naming

Examples:

- `agentic_search`
- `agent_handoff`
- `agent_inject`
- `dream`

Pros:

- easiest mental mapping from the comparison document
- lowest translation cost for users already familiar with the prior reference implementation

Cons:

- violates the explicit user requirement
- imports external conceptual vocabulary into Engram
- makes future documentation harder because the systems look more compatible than they are
- encourages feature-copying instead of architecture-fitting

Verdict:

- reject

### 2. Hide everything behind existing commands only

Examples:

- extend `search` with more flags
- extend `maintenance-run` to do everything
- use `session-brief` as a pseudo handoff pack

Pros:

- smallest surface-area increase
- minimal user retraining

Cons:

- important new workflows remain hard to discover
- handoff semantics become implicit instead of first-class
- operator intent is less legible in CLI/MCP logs

Verdict:

- partially useful, but not enough

### 3. Add Engram-native wrapper surfaces over existing internals (recommended)

Add a small set of new top-level interfaces that compose the current engine capabilities instead of replacing them.

Pros:

- satisfies the naming constraint cleanly
- keeps old commands stable
- makes the three new workflows discoverable and testable
- fits Engram's current explicit naming style (`health-report`, `maintenance-run`, `session-brief`)

Cons:

- adds a few more public entry points
- requires output models for the new composite views

Verdict:

- recommended

## Architecture

This phase should stay additive.

The recommended shape is:

1. keep current storage schema untouched where possible
2. add orchestration services on top of existing `search`, `session`, `maintenance`, `references`, `decisions`, `freshness`, and `jobs`
3. add new view models for the composite outputs
4. expose the new workflows through CLI, SDK, and MCP with Engram-native names

### Proposed modules

- `engram/search/contextual.py`
  - new `ContextSearchService`
- `engram/session/transfer.py`
  - new `ContextPackBuilder`
- `engram/maintenance/review.py`
  - new `OperationsReviewService`
- `engram/models/context_pack.py`
  - new `ContextPack` and `ContextTransferResult`
- `engram/models/operations.py`
  - new `OperationsReview`

### Existing modules reused directly

- `engram/engine.py`
- `engram/search/reranker.py`
- `engram/session/working_memory.py`
- `engram/session/context.py`
- `engram/session/brief.py`
- `engram/references/service.py`
- `engram/decisions/service.py`
- `engram/freshness/service.py`
- `engram/maintenance/service.py`
- `engram/quality/diagnostics.py`
- `engram/jobs/service.py`
- `engram/cli/app.py`
- `engram/integrations/sdk.py`
- `engram/integrations/mcp_server.py`

## Capability 1: `search_context()` / `context-search`

### Problem

Current Engram retrieval is strong at base search and reranking, but it is still mostly a single-query search flow.

Engram already has:

- `search()` with FTS5, scope filtering, retention filtering, freshness penalties, and reranking
- `ReferenceService` backlinks and projection drift
- `DecisionService` extracted decision records
- `RetrievalContext.goal` and goal-aware type preferences in the reranker

What is missing is a first-class surface that intentionally assembles context around a user goal.

### Interface

Engine and SDK:

```python
search_context(
    query: str,
    *,
    goal: str = "general",
    session_id: str | None = None,
    scope_selection: ScopeSelection | None = None,
    expand_hops: int = 1,
    include_decisions: bool = True,
    include_references: bool = True,
    max_results: int = 5,
    max_related: int = 10,
) -> ContextSearchResult
```

CLI:

```bash
engram-advanced context-search "Galaxy CTO" --goal task_handoff --expand-hops 1
```

MCP:

- `memory_context_search`

### Output model

Create `ContextSearchResult` with:

- `query`
- `goal`
- `base_result: SearchResult`
- `related_entities: list[RelatedEntity]`
- `related_decisions: list[DecisionView]`
- `expansion_notes: list[str]`
- `warnings: list[str]`

This avoids overloading `SearchResult` while keeping backward compatibility for current `search()`.

### Retrieval flow

1. Build base `SearchOptions` and `RetrievalContext`.
2. Call existing `engine.search(...)` logic as the first-pass retrieval.
3. Collect the top entity IDs from the base result.
4. Expand context in a conservative order:
   - direct `Relation` neighbors
   - `ReferenceEdge` matches from source mentions
   - related `DecisionRecord` entries
5. Re-rank the related items using:
   - current `goal`
   - active session entities
   - scope compatibility
   - freshness penalties
6. Apply a related-item token budget after base search so expansion cannot silently exceed the requested context size.
7. Return a composite result with explicit expansion notes.

### Constraints

- `expand_hops=0` means base search only
- no graph expansion beyond `expand_hops=2` in phase 1
- no embedding dependency
- no second search backend
- no automatic write-back

### Why this fits Engram

This preserves Engram's existing storage and explanation model. The new capability is an orchestration layer over current components, not a replacement search engine.

## Capability 2: `build_context_pack()` and `transfer_context()`

### Problem

Current Engram sessions support carryover within one agent lineage, but not an explicit cross-agent transfer workflow.

Engram already has:

- `WorkingMemory`
- session summaries
- session events
- session metadata
- scope-aware sessions

The missing piece is a way to package those into a reusable handoff object and optionally open a target session with that context attached.

### Interface

Engine and SDK:

```python
build_context_pack(
    *,
    session_id: str,
    goal: str = "task_handoff",
    max_chars: int = 4000,
    scope_selection: ScopeSelection | None = None,
) -> ContextPack

transfer_context(
    *,
    from_session_id: str,
    to_agent_id: str,
    note: str = "",
    goal: str = "task_handoff",
    scope_selection: ScopeSelection | None = None,
) -> ContextTransferResult
```

CLI:

```bash
engram-advanced context-pack <session_id> --goal task_handoff
engram-advanced context-transfer <session_id> writer-agent --note "Continue draft assembly"
```

MCP:

- `memory_context_pack`
- `memory_context_transfer`

### Output models

`ContextPack`

- `source_session_id`
- `source_agent_id`
- `scope_id`
- `goal`
- `summary`
- `source_session_active`
- `active_entities: list[EntityRef]`
- `recent_queries`
- `supporting_decisions: list[DecisionView]`
- `open_loops: list[OpenLoop]`
- `rendered_text`

`ContextTransferResult`

- `pack: ContextPack`
- `target_session: Session`
- `transfer_note`

### Persistence strategy

Phase 1 should not add a new table.

Instead:

- store handoff metadata in the destination session's `metadata`
- log source-side and destination-side `SessionEvent`s
- derive `recent_queries` from masked `session_events`, not from raw `WorkingMemory.recent_queries`

Required session event types:

- `context_pack_created`
- `context_transferred`
- `context_received`

Required destination session metadata keys:

- `handoff_from_session_id`
- `handoff_from_agent_id`
- `handoff_note`
- `handoff_goal`

### Transfer flow

1. Load the source session.
2. Build a `ContextPack`.
3. Start a new session for `to_agent_id`.
4. Inherit `scope_id` from the source session unless an explicit scope override was provided.
5. Attach handoff metadata to the target session.
6. Log transfer events on both sessions.
7. Return the pack plus the new target session.

Behavior rules:

- active source sessions are allowed; the pack uses the live in-memory session state plus masked session events
- ended source sessions are allowed; the pack uses the stored session state
- if the target agent already has an active session in the current process, transfer must fail instead of creating a second active session
- explicit scope overrides may only narrow from the source scope lineage; widening to an unrelated scope is an error
- phase 1 assumes one trust domain and does not introduce a per-agent authorization model

### Required `SessionManager` extension

`start_session()` should be extended to optionally accept:

- `parent_session_id: object = _USE_RECENT_PARENT`
- `metadata: dict | None = None`
- `allow_parallel: bool = False`

This avoids unnatural post-save mutation and makes context transfer an explicit session-start path.

### Why this fits Engram

This design reuses durable sessions and auditable events instead of inventing separate `agents/*.json` state files. That matches Engram's SQLite-first architecture.

## Capability 3: `run_operations_review()` / `operations-review`

### Problem

Engram already has the underlying pieces for a single-entry maintenance cycle, but they are distributed:

- `health_check()`
- `health_report()`
- `run_maintenance()`
- `run_jobs()`
- `projection_drift()`
- recommendations

Operators and agents still need one explicit entry point that answers:

- what is unhealthy
- what was persisted
- what should be fixed next

### Interface

Engine and SDK:

```python
run_operations_review(
    *,
    max_open_loops: int = 50,
    stale_days: int | None = None,
    run_jobs: bool = False,
    job_limit: int = 20,
    lease_owner: str = "operations_review",
    include_projection_drift: bool = True,
    include_recommendations: bool = True,
) -> OperationsReview
```

CLI:

```bash
engram-advanced operations-review --run-jobs --job-limit 20
```

MCP:

- `memory_operations_review`

### Output model

`OperationsReview`

- `health_report: HealthReport`
- `maintenance_run: MaintenanceRunView`
- `job_result: JobRunSummary | None`
- `reference_drift: list[ProjectionDriftItem]`
- `decision_drift: list[ProjectionDriftItem]`
- `recommendations: list[RecommendationView]`
- `summary_lines: list[str]`

### Review flow

1. Generate `HealthReport`.
2. Persist a `MaintenanceRun` via existing `run_maintenance()`.
3. Optionally execute queued jobs via existing `run_jobs()`.
4. Collect `ReferenceService.projection_drift()` and `DecisionService.projection_drift()`.
5. Collect top recommendations.
6. Return a single composite view.

Important:

- `operations-review` is not read-only because step 2 persists a maintenance run on every execution

### Why not just reuse `maintenance-run`

`maintenance-run` should remain a narrowly-scoped persisted maintenance snapshot.

`operations-review` is broader:

- includes drift checks
- can run jobs
- includes recommendations
- is intended for operator or agent review

That separation keeps both commands clear.

## CLI, SDK, and MCP Design

### CLI additions

Add these commands to `engram/cli/app.py`:

- `context-search`
- `context-pack`
- `context-transfer`
- `operations-review`

These should be additive and should not change current semantics of:

- `search`
- `session-brief`
- `maintenance-run`
- `jobs-run`

### SDK additions

Add methods to `EngramSDK`:

- `search_context(...)`
- `build_context_pack(...)`
- `transfer_context(...)`
- `operations_review(...)`

### MCP additions

Add tools:

- `memory_context_search`
- `memory_context_pack`
- `memory_context_transfer`
- `memory_operations_review`

These should follow the current `memory_*` tool naming convention already used by `memory_search`, `memory_store`, and related tools.

## File Impact

### Create

- `engram/search/contextual.py`
- `engram/session/transfer.py`
- `engram/maintenance/review.py`
- `engram/models/context_pack.py`
- `engram/models/operations.py`
- `tests/test_search/test_contextual.py`
- `tests/test_session/test_transfer.py`
- `tests/test_maintenance/test_review.py`

### Modify

- `engram/engine.py`
- `engram/session/manager.py`
- `engram/integrations/sdk.py`
- `engram/integrations/mcp_server.py`
- `engram/cli/app.py`
- `engram/models/view.py` if view wrappers are reused
- `tests/test_engine.py`
- `tests/test_cli/test_app.py`
- `tests/test_integrations/test_mcp_server.py`

### No migration required in phase 1

This batch should avoid schema changes.

Reason:

- `sessions.metadata` already exists
- `session_events` already exists
- maintenance and recommendation persistence already exist

If implementation later discovers a real need for durable pack caching, that should be a separate schema proposal.

## Testing

Minimum required automated coverage:

### Context search

- contextual search returns the base result plus expanded related evidence
- contextual search respects scope filtering
- contextual search preserves freshness penalties
- goal-aware reranking changes result order when goal-specific preferences apply

### Context pack / transfer

- context pack includes session summary, active entities, and recent queries
- context pack never serializes raw unmasked working-memory queries
- context transfer creates a target session with inherited scope
- context transfer records both source and target session events
- context transfer writes handoff metadata into the target session
- context transfer rejects parallel active sessions for the target agent
- context transfer rejects scope widening

### Operations review

- operations review returns health report plus persisted maintenance run
- operations review optionally executes jobs
- operations review includes projection drift output
- operations review includes computed recommendations
- operations review tests assert the write-bearing maintenance side effect

### Surface tests

- CLI commands return structured output in `--json` mode
- SDK methods call the intended engine methods
- MCP tools serialize correctly
- MCP tools provide descriptive docstrings for tool help

### Naming regression tests

Add explicit negative tests to ensure these names do not exist:

- CLI: `agentic-search`, `agent-inject`, `agent-handoff`, `dream`
- SDK / engine convenience wrappers: same names
- MCP: `memory_agentic_search`, `memory_agent_handoff`, `memory_dream`

This is not cosmetic. The name boundary is a product requirement for this batch.

Additional error-path tests:

- invalid `expand_hops` values
- missing source session IDs
- attempting transfer into an already-active target agent session

## Rollout Notes

Phase 1 should ship in this order:

1. contextual search internals
2. context pack and transfer
3. operations review
4. CLI / SDK / MCP exposure
5. negative alias tests

This order is intentional:

- search and handoff produce the biggest user-facing gain
- operations review is mostly orchestration over existing modules
- alias tests should land before the batch is considered complete

## Decision Summary

The correct Engram move is not to clone legacy external verbs.

It is to preserve Engram's explicit, structured style and expose the adopted capabilities through four new surfaces:

- `context-search`
- `context-pack`
- `context-transfer`
- `operations-review`

That gives Engram the practical value identified in the comparison work while keeping the product vocabulary and implementation boundaries unmistakably its own.
