# Retention Policies and Recommendation Triggers Design

## Goal

Add a first-class retention policy layer and a computed recommendation layer so Engram can preserve important memory deliberately, hide archival content from default retrieval, and surface actionable recommendations from freshness and maintenance signals.

This iteration implements the first half of `Phase 6: Policy-based Retention + Recommendation Triggers`.

## Scope

In scope:
- persisted retention policies for supported targets
- policy CRUD through engine and CLI
- runtime enforcement of `archive_only` in default search and brief flows
- runtime enforcement of `never_summarize` in brief generation
- computed recommendations for stale decisions
- computed recommendations for unresolved open-loop escalation

Out of scope for this iteration:
- merge recommendations
- follow-up task recommendations
- policy-aware compaction execution
- automatic deletion or archival of records
- persisted recommendation backlog

## Approach Options

### 1. Read-time overlay only

Compute both policy effects and recommendations entirely at read time with no persisted policy records.

Pros:
- smallest change set
- no new schema

Cons:
- policies are not auditable or manageable
- impossible to distinguish intentional preservation from default behavior
- poor fit for a long-lived agent memory system

### 2. Persisted policies plus computed recommendations (recommended)

Persist retention policies in SQLite and compute recommendations from current freshness, governance, and maintenance signals at read time.

Pros:
- policies are durable and explicit
- recommendations stay adaptive and do not go stale in storage
- matches Engram's existing model of persisted state plus computed views

Cons:
- adds a new table and service layer
- recommendation views need consistent serialization across CLI and SDK

### 3. Persist both policies and recommendations

Store retention rules and recommendation rows together as backlogs.

Pros:
- strongest audit trail

Cons:
- recommendation rows would become stale quickly
- introduces lifecycle cleanup before the recommendation model is mature
- too much operational complexity for the first retention phase

## Architecture

The recommended approach is option 2.

This phase introduces two distinct layers:

1. `RetentionService`
- owns persisted policy CRUD
- answers target-level policy lookups
- provides policy guards to search, brief, and recommendation flows

2. `RecommendationService`
- computes recommendation views from current state
- uses freshness, governance, maintenance, and policy signals together
- does not persist output in this phase

Policies always win over recommendations. For example:
- a pinned target still shows freshness warnings but must not be recommended for archival
- a `never_summarize` target remains available as supporting evidence but is excluded from summary generation

## Data Model

Create a new table `retention_policies`:
- `id`
- `target_kind` (`entity`, `fact`, `decision`, `note`, `session`)
- `target_id`
- `policy_type` (`pin`, `ttl`, `archive_only`, `never_summarize`)
- `value`
- `reason`
- `created_at`
- `updated_at`

Constraints:
- `UNIQUE(target_kind, target_id, policy_type)`
- `value` is nullable
- `ttl` stores an ISO datetime string in `value`
- other policy types use `NULL` in `value`

Create `engram/models/retention.py` with:
- `RetentionPolicyType`
- `RetentionTargetKind`
- `RetentionPolicy`
- `RecommendationKind`
- `RecommendationSeverity`
- `RecommendationView`

## Policy Semantics

### `pin`

Meaning:
- preserve the target intentionally
- suppress archive-style recommendations against that target

It does **not**:
- suppress freshness warnings
- override stale penalties
- force ranking boosts

### `ttl`

Meaning:
- declare a policy horizon for when the target should be reconsidered for archival or review

It does **not**:
- delete data automatically
- retract or expire facts directly

Expired `ttl` contributes to recommendation generation in later phases. In this phase it is stored and exposed, but only the stale decision and open-loop recommendations are implemented.

### `archive_only`

Meaning:
- the target should be hidden from default retrieval and brief summarization
- it remains available through explicit inspection flows

This phase applies it to:
- search hits
- supporting hits in entity and session briefs

This phase does not yet apply it to:
- snapshot search
- MCP-specific retrieval output

### `never_summarize`

Meaning:
- the target can still exist in memory and supporting evidence
- but brief and summary text must not compress it into generated summary sections

This phase applies it to:
- entity brief top facts
- session brief supporting summarization

It does not remove the target from exact inspection APIs.

## Recommendation Model

Recommendations are computed views with this shape:
- `kind`
- `severity`
- `target_kind`
- `target_id`
- `title`
- `detail`
- `recommended_action`
- `evidence`
- `policy_conflicts`

This phase implements two kinds:

### `stale_decision`

Generated when:
- a decision is stale or verification overdue
- no open verification request already covers it
- the decision is not pinned

Typical action:
- re-verify, supersede, or archive after review

### `open_loop_escalation`

Generated when:
- a maintenance open loop remains unresolved for longer than a threshold
- or the same loop kind recurs repeatedly in recent maintenance runs
- no policy explicitly suppresses that recommendation class

Typical action:
- escalate from warning to critical review

The recommendation view must carry evidence references that explain why it was emitted.

## Runtime Integration

### Search

Default search excludes `archive_only` targets from result hits.

This filter applies after retrieval and before final serialization so:
- ranking internals stay simple
- explicit future flags can opt archived content back in

`pin` does not remove freshness penalties.

### Briefs

Entity and session briefs must:
- exclude `archive_only` supporting hits by default
- exclude `never_summarize` targets from summary-building passes
- still allow protected targets to appear as structured supporting evidence when explicitly fetched

### Health and Maintenance

`RecommendationService` consumes:
- stale decision signal from freshness
- open loops from diagnostics
- recent maintenance runs
- retention policies

Maintenance and health remain the source of raw signals. Recommendations are derived from those signals and do not replace them.

## Engine and CLI Surface

Engine methods:
- `set_retention_policy(...) -> RetentionPolicy`
- `clear_retention_policy(...) -> bool`
- `list_retention_policies(...) -> list[RetentionPolicy]`
- `list_recommendations(...) -> list[RecommendationView]`
- `get_recommendation(...) -> RecommendationView | None`

CLI commands:
- `retention-set`
- `retention-list`
- `retention-clear`
- `recommendations`
- `recommendation-show`

`retention-set` supports:
- `engram retention-set fact <id> pin`
- `engram retention-set decision <id> ttl --value 2026-05-01T00:00:00`
- `engram retention-set entity <id> archive_only`
- `engram retention-set note <id> never_summarize`

## Error Handling

Retention writes are strict:
- invalid target kind errors
- invalid policy type errors
- malformed `ttl` values error

Recommendations are best-effort:
- recommendation calculation must not break search, briefs, or maintenance views
- missing evidence should degrade the recommendation detail, not abort the request

## Testing

Minimum coverage:
- migration adds `retention_policies`
- policy upsert and clear behavior
- `ttl` persistence and parsing
- `archive_only` excludes search hits by default
- `never_summarize` excludes protected items from brief summaries
- stale decision recommendation appears when expected
- pinned stale decisions suppress archive-style recommendation output
- open-loop escalation appears for unresolved recurring loops
- CLI policy and recommendation commands serialize correctly

## Rollout Notes

This phase intentionally stops before merge recommendations and follow-up task generation. The goal is to establish stable policy semantics and advisory recommendation views without adding another persisted backlog layer too early.
