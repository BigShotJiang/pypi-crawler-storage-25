# Entity Governance Design

## Goal

Add a first-class entity governance loop so Engram can detect likely duplicate entities, persist reviewable merge and alias candidates, and apply approved actions through the existing structured memory engine.

This iteration focuses on the minimum workflow that closes the loop:
- detect duplicate candidates
- persist them as reviewable governance records
- approve or reject candidates
- execute approved merge or alias actions safely

## Scope

This iteration implements the first half of `Phase 5: Entity Governance`.

In scope:
- persisted governance candidate records
- duplicate entity detection based on normalized names and aliases
- merge candidates that can be approved or rejected
- alias candidates that can be approved or rejected
- CLI and engine APIs to list, inspect, and resolve candidates
- diagnostics visibility for governance backlog

Out of scope for this iteration:
- split candidate generation
- automatic merge execution without review
- recommendation triggers built on governance signals
- retention policy interaction
- fuzzy or embedding-based duplicate detection

## Approach Options

### 1. Read-time duplicate suggestions only

Detect duplicates in memory when a CLI command runs, but do not persist review items.

Pros:
- smallest change set
- no schema changes

Cons:
- no review backlog
- no approval audit trail
- no diagnostics integration

### 2. Persisted governance candidates (recommended)

Store governance candidates in SQLite, dedupe them by candidate fingerprint, and resolve them through explicit approve or reject actions.

Pros:
- one shared workflow across CLI, engine, and maintenance
- safe review gate before merge execution
- leaves room for richer candidate types later

Cons:
- requires schema, model, and service additions
- more operational code than ephemeral suggestions

### 3. Immediate auto-merge for high-confidence pairs

Merge entities automatically when normalized names match strongly.

Pros:
- lowest operator effort

Cons:
- too risky for agent memory
- hard to explain or audit
- bad fit for Engram's defensive write philosophy

## Architecture

The recommended approach is option 2.

Entity governance becomes a persisted review workflow with three pieces:

1. `EntityGovernanceService`
- detects candidates from current entities
- writes or refreshes persisted candidate rows
- resolves approved or rejected candidates

2. `governance_candidates` table
- canonical backlog of entity review work
- stores candidate type, status, score, and target entity IDs

3. engine plus CLI surface
- users can generate candidates
- inspect them
- approve or reject them

Approved merge candidates call the existing merge behavior, but through entity IDs internally so candidate execution does not depend on stale names.

Approved alias candidates add a reviewed alias to the target entity and reindex it.

## Data Model

Create a new table `governance_candidates`:
- `id`
- `candidate_type` (`merge`, `alias`)
- `status` (`open`, `approved`, `rejected`, `applied`, `cancelled`)
- `entity_id`
- `related_entity_id`
- `proposed_alias`
- `score`
- `fingerprint`
- `rationale`
- `details` JSON text
- `created_at`
- `updated_at`
- `resolved_at` nullable
- `resolved_by` nullable

Rules:
- merge candidates require `entity_id` and `related_entity_id`
- alias candidates require `entity_id` and `proposed_alias`
- `fingerprint` is unique so re-runs refresh the same logical candidate instead of duplicating backlog

Create `engram/models/governance.py` with:
- `GovernanceCandidateType`
- `GovernanceCandidateStatus`
- `GovernanceResolution`
- `GovernanceCandidate`

## Candidate Detection

This phase deliberately uses conservative rules.

### Merge candidate rules

Generate a merge candidate when all are true:
- entity types match
- normalized names are equal, or one normalized alias matches the other normalized name
- entities are distinct IDs

Normalization:
- lowercase
- trim surrounding whitespace
- collapse internal whitespace
- remove `.`, `,`, `_`, `-`

This iteration does not attempt approximate token similarity. That belongs in a later recommendation phase.

### Alias candidate rules

Generate an alias candidate when:
- a secondary entity name is a short-form or alternate spelling that should live on the primary entity
- approving merge would preserve the secondary name as an alias on the primary entity

In practice, every open merge candidate also implies an alias consequence. This phase persists alias candidates separately only when the alias can be applied without merge:
- proposed alias is not already present
- proposed alias is not equal to the primary name

## Execution Semantics

### Approving a merge candidate

When a merge candidate is approved:
- resolve the candidate as `approved`
- execute a merge by entity IDs
- set candidate status to `applied`
- resolve any sibling alias candidate that became redundant as `cancelled`

Merge execution must:
- transfer facts
- transfer relations
- rebind reference edges
- rebind decisions
- preserve secondary name and aliases on the primary entity
- reindex primary and affected related entities

### Approving an alias candidate

When an alias candidate is approved:
- append alias to target entity if absent
- update and reindex entity
- set candidate status to `applied`

### Rejecting a candidate

Rejecting sets:
- `status = rejected`
- `resolved_at = now`
- `resolved_by = caller`

Re-running detection should not reopen a rejected candidate with the same fingerprint in this phase.

## Storage Changes

SQLite storage needs helpers for:
- creating or upserting governance candidates
- listing candidates by status and type
- fetching one candidate
- resolving candidate status
- rebinding references and decisions from one entity ID to another
- merging by entity IDs safely

The existing `merge_entities(primary_name, secondary_name)` engine API stays for compatibility, but internally it should delegate to an ID-safe merge path.

## Engine and CLI Surface

Engine methods:
- `generate_governance_candidates(limit: int = 100) -> list[GovernanceCandidate]`
- `list_governance_candidates(status: GovernanceCandidateStatus | None = None, candidate_type: GovernanceCandidateType | None = None, limit: int = 50) -> list[GovernanceCandidate]`
- `get_governance_candidate(candidate_id: str) -> GovernanceCandidate | None`
- `resolve_governance_candidate(candidate_id: str, resolution: GovernanceResolution, resolved_by: str = "user") -> GovernanceCandidate`

CLI commands:
- `governance-run`
- `governance-list`
- `governance-show`
- `governance-resolve`

`governance-resolve` accepts:
- `approve`
- `reject`

## Diagnostics Integration

Add one new open-loop kind:
- `entity_governance`

Diagnostics should emit a governance backlog loop when open governance candidates exist.

This is intentionally coarse in this phase. Recommendation triggers come later.

## Error Handling

Governance generation is best-effort:
- one bad entity pair should not abort the full scan
- malformed candidates are skipped

Resolution is strict:
- approving a missing candidate errors
- approving an already applied candidate errors
- approving a merge where one entity no longer exists errors

## Testing

Minimum test coverage:
- migration adds governance table
- candidate generation finds duplicate entities
- candidate dedupe on rerun
- approving merge rebinds facts, references, and decisions
- approving alias updates aliases without duplication
- governance backlog appears in diagnostics
- CLI run, list, show, and resolve flows work

## Rollout Notes

This design intentionally stops before split candidates and fuzzy matching. The system first needs a stable, reviewable governance loop. Later phases can increase recall once the approval workflow and audit trail exist.
