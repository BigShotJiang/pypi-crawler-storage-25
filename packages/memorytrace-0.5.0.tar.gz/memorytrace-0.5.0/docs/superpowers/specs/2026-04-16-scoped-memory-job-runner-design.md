# Scoped Memory and Job Runner Design

## Summary

This batch adds two structural layers on top of the current projection-enabled Engram engine:

1. a first-class namespace model for scoped memory across writes, retrieval, briefs, projections, and agent handoff
2. a SQLite-backed asynchronous job runner for projection indexing, maintenance, and future verification workflows

The design keeps canonical memory in the existing tables. Scope becomes explicit metadata on canonical rows, while long-running or rebuildable work moves into persisted jobs instead of being executed inline on the write path.

## Scope

This batch includes:

- first-class scope records with hierarchy
- scope attachment on canonical text-bearing rows and facts
- scope-aware search, briefs, backlinks, decisions, and maintenance reads
- scope-aware write APIs for `store`, `add_fact`, `intake`, `debug_*`, and `end_session`
- persisted jobs for projection indexing and maintenance work
- a job runner service and CLI commands for inspection and execution
- search/brief explanation updates when scope filtering changes result visibility

This batch excludes:

- freshness or verification queues beyond generic job primitives
- entity governance workflows
- retention policies
- recommendation triggers
- automatic distributed workers or external queue backends

## Design Goals

1. Scope must be explicit enough to prevent cross-project or cross-agent leakage during retrieval.
2. Writes must remain durable even if projection or maintenance work cannot complete immediately.
3. The system must keep its SQLite-first, rebuildable-projection model.
4. The batch must leave clean extension points for freshness, governance, and retention phases.

## Architecture

### 1. Scope Layer

Add a `memory_scopes` table and a small scope model:

- `global`
- `workspace`
- `project`
- `channel`
- `task`
- `agent`

Every scope has one optional parent scope. This gives Engram a simple containment tree without requiring arbitrary graph traversal.

Canonical rows gain an optional `scope_id`:

- `facts.scope_id`
- `notes.scope_id`
- `sessions.scope_id`
- `debug_sessions.scope_id`
- `debug_hypotheses.scope_id`
- `debug_evidence.scope_id`

Rows without a scope remain readable as global data. Rows with a scope are only considered in a read path when:

- the active scope matches exactly
- an ancestor scope is explicitly included
- the caller requested global fallback

Entities remain global rows. Scope filtering happens through facts, notes, summaries, and debug artifacts, not by duplicating entities per scope.

### 2. Scope Resolution

Introduce a `ScopeRef` read/write model with:

- `scope_id`
- `kind`
- `name`
- `parent_scope_id`
- `path`
- `metadata`

Add a `ScopeSelection` query model with:

- `primary_scope_id`
- `include_ancestors`
- `include_global`
- `fallback_scope_ids`

`SearchOptions.context` and brief-building paths accept `ScopeSelection`. The engine resolves it to a concrete allowed scope set before querying or post-filtering.

### 3. Search and Brief Semantics

Current FTS5 indexing is entity-aggregated, so this batch does not rebuild the entire search index by scope. Instead:

- base BM25 retrieval stays global
- scoped post-filtering removes facts and hits with no allowed scoped evidence
- reranking adds scope penalties and boosts before final pruning
- explanations record whether a hit survived due to exact scope match, ancestor fallback, or global fallback

This keeps migration complexity manageable while making scope enforcement visible and testable.

### 4. Job Layer

Add a `jobs` table and `JobRunnerService`.

Job types in this batch:

- `index_source`
- `rebuild_references`
- `rebuild_decisions`
- `rebuild_projections`
- `maintenance_run`

Each job stores:

- `id`
- `job_type`
- `status`
- `payload`
- `attempts`
- `max_attempts`
- `available_at`
- `leased_at`
- `lease_owner`
- `last_error`
- `created_at`
- `updated_at`
- `completed_at`

Statuses:

- `queued`
- `running`
- `completed`
- `failed`
- `dead_letter`

The runner is in-process and explicitly invoked through engine APIs or CLI. There is no daemon in this batch.

### 5. Write Path Changes

Canonical writes still happen first. After a successful primary write:

- projection work is enqueued as jobs
- the write returns success even if the enqueue target later fails to execute

This applies to:

- `store()` note writes
- `add_fact()`
- `end_session()`
- `debug_hypothesis()`
- `debug_evidence()`
- `debug_conclude()`
- `intake_apply()`

This batch intentionally stops calling projection indexing inline from write paths.

### 6. Read Path Changes

Read paths remain synchronous.

- `search()` resolves scope and filters facts/hits
- `brief()` and `session_brief()` request scoped supporting hits
- `backlinks()` filters reference rows by source scope
- `list_decisions()` and `get_decision()` filter by decision source scope
- `run_maintenance()` can run inline or be enqueued
- `health_report()` surfaces queued/failed projection jobs as operational drift

## Data Model

### `memory_scopes`

- `id TEXT PRIMARY KEY`
- `kind TEXT NOT NULL CHECK(kind IN ('global','workspace','project','channel','task','agent'))`
- `name TEXT NOT NULL`
- `parent_scope_id TEXT REFERENCES memory_scopes(id) ON DELETE SET NULL`
- `path TEXT NOT NULL`
- `status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived'))`
- `metadata TEXT NOT NULL DEFAULT '{}'`
- `created_at TEXT NOT NULL`
- `updated_at TEXT NOT NULL`

Indexes:

- unique `(kind, path)`
- `idx_memory_scopes_parent(parent_scope_id)`

### Canonical row scope columns

Add nullable `scope_id TEXT` to:

- `facts`
- `notes`
- `sessions`
- `debug_sessions`
- `debug_hypotheses`
- `debug_evidence`

Indexes:

- `idx_facts_scope(scope_id, created_at DESC)`
- `idx_notes_scope(scope_id, created_at DESC)`
- `idx_sessions_scope(scope_id, started_at DESC)`
- `idx_debug_sessions_scope(scope_id, created_at DESC)`
- `idx_debug_hypotheses_scope(scope_id, created_at DESC)`
- `idx_debug_evidence_scope(scope_id, created_at DESC)`

### `jobs`

- `id TEXT PRIMARY KEY`
- `job_type TEXT NOT NULL`
- `status TEXT NOT NULL CHECK(status IN ('queued','running','completed','failed','dead_letter'))`
- `payload TEXT NOT NULL DEFAULT '{}'`
- `attempts INTEGER NOT NULL DEFAULT 0`
- `max_attempts INTEGER NOT NULL DEFAULT 3`
- `available_at TEXT NOT NULL`
- `leased_at TEXT`
- `lease_owner TEXT`
- `last_error TEXT`
- `created_at TEXT NOT NULL`
- `updated_at TEXT NOT NULL`
- `completed_at TEXT`

Indexes:

- `idx_jobs_status_available(status, available_at)`
- `idx_jobs_type_status(job_type, status, available_at)`

## Engine Surface

New engine APIs:

- `create_scope(kind, name, parent_scope_id=None, metadata=None)`
- `list_scopes(kind=None, parent_scope_id=None, include_archived=False)`
- `get_scope(scope_id)`
- `search(..., scope_selection=None)`
- `brief(..., scope_selection=None)`
- `session_brief(..., scope_selection=None)`
- `run_jobs(limit=20, lease_owner='cli')`
- `list_jobs(status=None, job_type=None, limit=50)`
- `get_job(job_id)`
- `enqueue_job(job_type, payload, available_at=None)`

Write APIs gain optional `scope_id`:

- `store(..., scope_id=None)`
- `add_fact(..., scope_id=None)`
- `intake(..., scope_id=None)`
- `debug_start(..., scope_id=None)`

`end_session()` derives scope from the active session if present.

## CLI Surface

New commands:

- `scope-create`
- `scope-list`
- `scope-show`
- `jobs-list`
- `jobs-run`
- `job-show`

Scope-aware flags:

- `--scope <scope-id>` on `store`, `search`, `brief`, `session-brief`, `intake`, and `debug-start`
- `--include-ancestors`
- `--include-global`

## Failure Handling

1. Missing or invalid scope IDs fail fast on write entry.
2. Job enqueue failure is surfaced as an error because it means the write cannot declare its follow-up work.
3. Job execution failure never corrupts canonical rows; the runner records `last_error` and retries.
4. Scope resolution failure on read falls back only when `include_global=True`; otherwise the result is empty, not broadened silently.

## Diagnostics

Add operational loops for:

- queued jobs older than a threshold
- failed jobs
- dead-letter jobs
- scope-mismatched projection rows when a scoped source has global derived rows or vice versa

These become part of health and persisted maintenance runs.

## Testing Strategy

Coverage for this batch must include:

- migration of `memory_scopes`, scope columns, and `jobs`
- scope creation, hierarchy resolution, and path uniqueness
- scoped writes for notes, facts, sessions, debug rows, and intake
- scoped search post-filtering and explanation factors
- scoped brief supporting hits
- backlinks and decisions filtered by source scope
- enqueue-on-write behavior for projection work
- job leasing, retry, completion, and dead-letter behavior
- CLI coverage for scope and jobs commands
- full regression suite

## Success Criteria

Batch 1 is complete when:

- Engram can create and list scopes
- canonical writes can attach a scope
- search and briefs can honor scope selection
- projection work is scheduled through persisted jobs
- queued and failed jobs are visible in diagnostics and maintenance
- the full test suite remains green
