# Freshness and Verification Workflow Design

## Goal

Add a first-class freshness lifecycle to Engram so facts and decisions can become due, stale, queued for revalidation, and explained consistently across search, decision lookup, health reporting, and maintenance runs.

This design treats freshness as a separate axis from truth status. A fact can remain `unverified` or `verified` as a knowledge claim while independently being `fresh`, `pending`, or `stale` from a verification perspective.

## Scope

This iteration implements `Phase 4: Freshness / Verification Workflow`.

In scope:
- fact freshness metadata
- decision freshness metadata
- persisted verification request queue
- verify-on-read deduped request creation
- freshness penalties and warnings in read paths
- maintenance / health visibility for stale items and verification backlog
- minimal CLI to inspect and resolve verification work

Out of scope for this iteration:
- duplicate cluster detection and merge governance
- alias approval workflows
- retention policies such as `pin` / `ttl` / `archive_only`
- recommendation triggers built on top of freshness/governance signals

Those remain follow-on work for `Phase 5` and `Phase 6`, but this design leaves extension points for them.

## Approach Options

### 1. Read-time stale penalty only

Compute staleness from `created_at` during search and health checks, but do not persist verification state or requests.

Pros:
- smallest change set
- no new schema beyond optional score factors

Cons:
- no actionable backlog
- no dedupe for verify-on-read
- no shared state for governance or recommendations

### 2. Freshness metadata + verification queue (recommended)

Persist freshness state on facts and decisions, plus a canonical verification request queue that read paths and maintenance use together.

Pros:
- one shared state model across search, decisions, maintenance, and future governance
- verify-on-read becomes dedupable and observable
- recommendation and retention systems can reuse the same queue and freshness flags later

Cons:
- requires schema and model changes
- slightly more operational code than a pure read-time overlay

### 3. Fully automated source revalidation jobs

Persist requests and immediately drive them through background workers that attempt to revalidate from original sources.

Pros:
- strongest long-term automation story

Cons:
- too large for this phase
- depends on source adapters and trust policies that do not exist yet

## Architecture

The recommended approach is option 2.

Freshness becomes a first-class persisted layer made of:
- freshness metadata on `facts`
- freshness metadata on `decisions`
- a `verification_requests` table as the canonical backlog
- a `FreshnessService` that owns due/stale transitions, deduped request creation, and resolution

Search, briefs, and decision views remain read-first and explanation-rich:
- reads do not fail if freshness logic fails
- stale or pending items lower ranking and add warnings
- verify-on-read creates backlog entries best-effort and only once per target

Maintenance and health reporting consume the same backlog state:
- stale facts and stale decisions are visible as open loops
- queued verification work shows up as a separate backlog metric

## Data Model

### Fact freshness fields

Add these columns to `facts`:
- `verification_status TEXT NOT NULL DEFAULT 'unknown'`
- `last_verified_at TEXT`
- `verification_due_at TEXT`

Allowed `verification_status` values:
- `unknown`
- `pending`
- `verified`
- `stale`

Interpretation:
- `unknown`: no explicit freshness decision yet
- `pending`: a verification request is currently open
- `verified`: explicitly verified and not yet due
- `stale`: due or explicitly marked stale; should incur penalties and show up in maintenance

`FactStatus` continues to express truth-state:
- `unverified`
- `verified`
- `conflicted`
- `expired`
- `retracted`

These two axes must not be collapsed into one field.

### Decision freshness fields

Add the same freshness fields to `decisions`:
- `verification_status TEXT NOT NULL DEFAULT 'unknown'`
- `last_verified_at TEXT`
- `verification_due_at TEXT`

`DecisionStatus` remains:
- `active`
- `superseded`
- `draft`

Freshness downgrade does not mutate `DecisionStatus` in this phase. Instead:
- stale decisions surface warnings
- stale decisions can be queued for verification
- recommendations in later phases can choose whether to demote or archive them

### Verification request model

Add a new table `verification_requests`:
- `id`
- `target_kind` (`fact`, `decision`)
- `target_id`
- `entity_id` nullable
- `scope_id` nullable
- `reason`
- `status` (`open`, `resolved`, `cancelled`)
- `requested_by`
- `resolution` nullable (`verified`, `stale`, `retracted`, `superseded`)
- `detail` default `''`
- `requested_at`
- `resolved_at` nullable
- `metadata` JSON text

Add a unique index so there can be only one open request per target:
- `UNIQUE(target_kind, target_id, status)` enforced for `status = 'open'` through service-level dedupe

This request table is the user-facing backlog. It is intentionally separate from background `jobs`.

### New models

Create `engram/models/verification.py` with:
- `VerificationStatus`
- `VerificationRequestStatus`
- `VerificationResolution`
- `VerificationRequest`
- `FreshnessAssessment`

`FreshnessAssessment` is a runtime helper that answers:
- is this target due?
- is it stale?
- should it incur a ranking penalty?
- should a verify-on-read request be opened?

## Freshness Policy

Facts use memory-type-aware due dates.

When a fact is created or verified:
- `verification_due_at` is set using `DecayPolicy.stale_cutoff_days(memory_type)`
- `last_verified_at` is set only on explicit verification

Decisions use a simpler fixed policy:
- `active`: due in 30 days
- `draft`: due in 14 days
- `superseded`: no active freshness tracking

This is intentionally conservative and can be promoted to config later.

## Service Design

Create `engram/freshness/service.py` with one `FreshnessService`.

Core responsibilities:
- assess current freshness for facts and decisions
- create deduped verification requests
- transition facts and decisions between `unknown/pending/verified/stale`
- resolve requests and update target freshness metadata
- expose backlog queries for diagnostics and CLI

Required methods:
- `assess_fact(fact: Fact) -> FreshnessAssessment`
- `assess_decision(decision: DecisionRecord) -> FreshnessAssessment`
- `ensure_fact_request(fact: Fact, reason: str, requested_by: str) -> VerificationRequest | None`
- `ensure_decision_request(decision: DecisionRecord, reason: str, requested_by: str) -> VerificationRequest | None`
- `list_requests(status: VerificationRequestStatus | None = None, target_kind: str | None = None, limit: int = 50) -> list[VerificationRequest]`
- `get_request(request_id: str) -> VerificationRequest | None`
- `resolve_request(request_id: str, resolution: VerificationResolution, detail: str = "") -> VerificationRequest`
- `mark_fact_verified(fact_id: str) -> Fact`
- `mark_decision_verified(decision_id: str) -> DecisionRecord`

Resolution effects:
- `verified`
  - target `verification_status = verified`
  - `last_verified_at = now`
  - `verification_due_at = next due date`
- `stale`
  - target `verification_status = stale`
- `retracted`
  - facts only: also set `FactStatus.RETRACTED`
- `superseded`
  - decisions only: set `DecisionStatus.SUPERSEDED`

## Read Path Integration

### Search

`MemoryEngine.search()` keeps the current flow:
- retrieval
- scope filtering
- reranking
- explanation building

Freshness hooks in at two points:

1. before reranking:
- assess each supporting fact
- apply `freshness_penalty` if the best evidence is `pending` or `stale`

2. after reranking:
- if a fact is due or stale, best-effort `ensure_fact_request(..., reason='verify_on_read')`
- add warnings to the explanation bundle

Penalty guidance:
- pending fact: `-0.10`
- stale fact: `-0.30`

### Briefs

`entity_brief()` and `session_brief()` already depend on supporting search hits.

They inherit the same freshness behavior:
- stale supporting hits keep their warnings
- verify-on-read request creation remains deduped

### Decisions

`get_decision()` and `list_decisions()` gain freshness-aware views:
- stale decisions add explanation warnings
- due decisions can trigger `ensure_decision_request(..., reason='decision_read')`

This phase does not rerank decisions aggressively; it only surfaces warnings and backlog state.

## Diagnostics and Maintenance

Extend `LoopKind` with:
- `VERIFICATION_BACKLOG`
- `STALE_DECISION`

Add diagnostics:
- `verification_backlog_count`
- `stale_decision_count`

Open loops:
- open verification requests -> `VERIFICATION_BACKLOG`
- facts whose `verification_due_at < now` and status is stale/pending -> existing `STALE_FACT` loop
- decisions whose due date passed -> `STALE_DECISION`

Maintenance runs persist these items just like the current conflict/projection loops.

## CLI Surface

Add:
- `verification-list`
- `verification-show <request_id>`
- `verification-request fact <fact_id>`
- `verification-request decision <decision_id>`
- `verification-resolve <request_id> <verified|stale|retracted|superseded>`

Also extend:
- `search --scope-id` already exists and remains compatible
- `decision-show` JSON/text should surface freshness warnings through explanation
- `maintenance-show` should show verification backlog items naturally via existing views

## Failure Handling

Read paths remain best-effort:
- if freshness assessment fails, the search/brief/decision result still returns
- explanation warnings may be incomplete, but the read path must not error

Queue dedupe rules:
- opening the same request twice is a no-op
- resolving a non-open request is an error

## Testing Strategy

Minimum required coverage:

1. migration tests
- new columns on `facts`
- new columns on `decisions`
- `verification_requests` table creation

2. service tests
- deduped request creation
- resolve request updates target freshness metadata
- future due dates are computed correctly

3. read-path tests
- stale facts incur ranking penalties
- verify-on-read opens only one request
- stale decision explanation includes warnings

4. diagnostics tests
- backlog metric appears when requests are open
- stale decision loop appears when due date passes

5. CLI tests
- `verification-list`
- `verification-request`
- `verification-resolve`

## Integration With Later Phases

This design intentionally prepares `Phase 5` and `Phase 6`:

- `Entity Governance`
  can emit merge/split verification requests into the same backlog model
- `Retention / Recommendations`
  can reuse freshness and backlog signals to recommend archive, follow-up, or escalation

No governance or retention policies are implemented in this phase.
