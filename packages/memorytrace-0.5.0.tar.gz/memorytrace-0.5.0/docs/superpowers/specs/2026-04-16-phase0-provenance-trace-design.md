# Phase 0 and Provenance Trace Design

## Summary

This design introduces the next explanation layer for Engram after projection and reranking phase 1.

The goal is not to add another search-only field. The goal is to establish one shared explanation contract that can be reused by:

- search results
- entity briefs
- session briefs
- decision lookup
- backlinks
- maintenance views

This phase also adds an evaluation baseline so explanation quality can be regression-tested instead of judged informally.

## Scope

This design includes:

- a shared explanation model
- explanation wiring for search, briefs, decisions, backlinks, and maintenance views
- evaluation fixtures and golden scenarios for explanation behavior
- serialization parity across CLI, SDK, and MCP-style structured responses

This design excludes:

- persistent provenance storage
- graph traversal provenance
- namespace-aware explanations
- freshness penalties
- entity governance explanations
- background jobs

## Design Principles

1. Explanation is a read-time contract, not a new source of truth.
2. Canonical storage stays in facts, relations, notes, sessions, debug data, and existing projections.
3. Explanation failure must not break the primary result path.
4. The same explanation shape should be reusable across all agent-facing interfaces.
5. Phase 0 must define regression fixtures before deeper explanation logic expands.

## Architecture

### 1. Shared Explanation Contract

Create a new model module:

- `engram/models/explanation.py`

It owns the shared explanation types:

- `EvidenceRef`
- `ExplanationFactor`
- `ProvenanceTrace`
- `ExplanationBundle`

These models are runtime response objects. They are not stored in SQLite.

### 2. Explanation Builder

Create a small assembly layer:

- `engram/explanations/builder.py`

Responsibilities:

- combine retrieval trace and reranking factors
- attach evidence references
- attach warnings when explanation is partial or degraded
- produce one `ExplanationBundle`

This keeps explanation composition out of `engine.py`, `brief.py`, and CLI formatters.

### 3. Adapters

Add thin adapters rather than expanding unrelated services:

- `SearchExplanationAdapter`
- `BriefExplanationAdapter`
- `ProjectionExplanationAdapter`

They translate current search and projection outputs into the shared explanation contract.

## Data Model

### `EvidenceRef`

Represents one structured object that supports a result.

Fields:

- `kind`
- `id`
- `label`
- `snippet`
- `entity_id`
- `source_kind`
- `source_id`

Supported `kind` values in this phase:

- `fact`
- `decision`
- `relation`
- `note`
- `reference_edge`
- `session`
- `debug_session`
- `maintenance_item`

### `ExplanationFactor`

Represents one scoring or filtering influence.

Fields:

- `name`
- `stage`
- `delta`
- `reason`

Supported `stage` values:

- `retrieval`
- `rerank`
- `post_filter`

### `ProvenanceTrace`

Represents the base retrieval or lookup path before final packaging.

Fields:

- `retriever`
- `query`
- `base_score`
- `snippet`
- `matched_fact_ids`
- `reasons`

`reasons` remains a lightweight list of text-level retrieval explanations.

### `ExplanationBundle`

Represents the final reusable explanation payload.

Fields:

- `summary`
- `trace`
- `factors`
- `evidence`
- `warnings`

Rules:

- `summary` is a short human-readable sentence
- `trace` may be `None` for non-search views
- `factors` may be empty
- `evidence` may be empty but should not be `None`
- `warnings` is used when explanation is partial or degraded

## Interface Changes

### Search

Update `SearchHit`:

- keep existing fields for backward compatibility in this phase
- add `explanation: ExplanationBundle`

Compatibility policy:

- `base_score`, `ranking_factors`, and `provenance` remain during this phase
- `explanation` becomes the preferred contract
- later phases may deprecate the legacy fields after downstream adoption

### Briefs

Update `SupportingHit`:

- add `explanation: ExplanationBundle`

Brief behavior:

- `EntityBrief.supporting_hits`
- `SessionBrief.supporting_hits`

continue to exist, but each hit now carries one structured explanation bundle instead of separate loose explanation fragments.

### Decisions

Do not change the stored `DecisionRecord`.

Instead add a read model:

- `DecisionView`

Fields:

- `decision`
- `explanation`

This avoids a schema change while still giving lookups a unified explanation surface.

### Backlinks

Backlink rows remain storage-driven dictionaries for now, but engine-level backlink responses gain:

- source snippet
- matched text
- `explanation`

The explanation should identify:

- why this entity was matched
- which source row was involved
- whether the match came from canonical name or alias

### Maintenance

Do not alter persisted `MaintenanceRunItem`.

When showing a maintenance run or rendering open loops, attach:

- `explanation`

The explanation should clarify:

- why the loop was opened
- which canonical or projection evidence triggered it
- whether the explanation is direct or inferred

## Data Flow

### Search Flow

1. base retriever returns hits with retrieval trace
2. reranker adds factors
3. explanation builder assembles one bundle
4. engine returns `SearchHit.explanation`

### Brief Flow

1. brief builder gathers supporting hits
2. each supporting hit is converted into a shared explanation bundle
3. brief response exposes explanation-rich supporting hits

### Decision and Backlink Flow

1. canonical or projection rows are loaded
2. projection adapter derives evidence refs
3. explanation builder assembles a bundle without requiring a search trace

### Maintenance Flow

1. maintenance item or open loop is loaded
2. diagnostics metadata is mapped into evidence refs and warnings
3. response is returned with explanation attached

## Error Handling

Explanation generation must be best-effort.

Rules:

- primary search, brief, decision, backlink, and maintenance responses must still return if explanation assembly partially fails
- degraded explanation must surface through `warnings`
- empty explanation objects are allowed only if accompanied by an explicit warning
- no explanation path may mutate canonical storage

## Phase 0 Evaluation Baseline

Add explanation-specific fixtures and golden assertions before broader rollout.

### Fixture Groups

1. `retrieval_golden_scenarios`
- exact fact match
- active entity boost
- preferred type boost
- note-supported retrieval

2. `brief_explanation_scenarios`
- entity brief supporting hit explanations
- session brief supporting hit explanations

3. `projection_explanation_scenarios`
- decision lookup explanation
- backlink explanation
- maintenance item explanation

4. `serialization_parity_scenarios`
- `to_dict()`
- CLI JSON output
- MCP-compatible structured response payloads

### Assertion Style

Tests should assert:

- explanation exists
- expected factor names are present when applicable
- expected evidence kinds are present
- degraded states produce warnings instead of hard failure

These fixtures are not performance benchmarks. They are regression guards for explanation correctness and interface consistency.

## Testing Strategy

Required coverage for this phase:

- model serialization for explanation types
- search explanation assembly
- brief explanation assembly
- decision/backlink/maintenance explanation adapters
- degraded explanation warning behavior
- CLI JSON parity
- full regression suite

## Success Criteria

This phase is complete when:

- a shared explanation contract exists in one dedicated model module
- search results expose `explanation`
- supporting brief hits expose `explanation`
- decision, backlink, and maintenance read paths can return explanation bundles
- explanation regressions are covered by golden scenarios
- legacy search explanation fields remain backward-compatible during rollout
