# Projection and Reranking Phase 1 Design

## Summary

This phase closes the gap between Engram's current engine and the already-drafted capability set by implementing two missing layers:

1. a projection layer for `backlinks`, `decisions`, persisted `maintenance runs`, and `projection drift`
2. a reranking layer for goal-aware retrieval, brief support hits, and search explanations

The implementation extends the existing SQLite-first architecture. Canonical memory remains in `entities`, `facts`, `notes`, `sessions`, and `debug_*`. New tables are rebuildable projections or operational history, not replacement storage.

## Scope

Phase 1 includes:

- `reference_edges`
- `decisions`
- `maintenance_runs`
- `maintenance_run_items`
- `projection_drift` health loops
- post-write indexing for `note`, `session`, `debug_session`, `debug_hypothesis`, and `debug_evidence`
- engine APIs for backlinks, decisions, maintenance runs, and projection rebuild
- advanced CLI commands for those APIs
- goal-aware reranking with structured explanations
- brief-level `supporting_hits`

Phase 1 excludes:

- background jobs
- namespace policy
- entity governance workflows
- freshness verification queues
- semantic reference matching
- write-side manual editing of decisions or references

## Architecture

### 1. Projection Layer

The projection layer derives read-optimized views from canonical rows.

- `ReferenceService` owns `reference_edges`
- `DecisionService` owns `decisions`
- `MaintenanceService` owns `maintenance_runs` and `maintenance_run_items`

Each projection is source-scoped and idempotent. Re-indexing a single source deletes that source's derived rows and rebuilds them from canonical text.

### 2. Post-Write Indexing

The canonical write path stays authoritative.

- `store()` indexes the note row after it is persisted
- `end_session()` indexes the session summary after it is saved
- debug session lifecycle methods index hypotheses, evidence, and conclusions after canonical writes

Projection failures do not roll back canonical writes. They surface through diagnostics as projection drift.

### 3. Goal-Aware Retrieval

`FTS5Search` remains the base retriever. A new `RerankingService` consumes a structured `RetrievalContext` and enriches `SearchHit` with:

- `base_score`
- `ranking_factors`
- `provenance`

`MemoryEngine.search()` invokes reranking after base retrieval and before session-side effects are recorded.

### 4. Brief Integration

Entity and session briefs gain optional `supporting_hits` so the same reranked evidence used in search can be reused by agent-facing context assembly.

## Data Model

### `reference_edges`

- `id TEXT PRIMARY KEY`
- `entity_id TEXT NOT NULL`
- `source_kind TEXT NOT NULL`
- `source_id TEXT NOT NULL`
- `snippet TEXT NOT NULL DEFAULT ''`
- `matched_text TEXT NOT NULL DEFAULT ''`
- `match_start INTEGER NOT NULL`
- `match_end INTEGER NOT NULL`
- `created_at TEXT NOT NULL`
- `indexed_at TEXT NOT NULL`

Indexes:

- `idx_reference_edges_entity(entity_id, indexed_at DESC)`
- `idx_reference_edges_source(source_kind, source_id)`
- unique on `(entity_id, source_kind, source_id, match_start, match_end)`

### `decisions`

- `id TEXT PRIMARY KEY`
- `fingerprint TEXT NOT NULL`
- `title TEXT NOT NULL`
- `summary TEXT NOT NULL`
- `status TEXT NOT NULL CHECK(status IN ('active','superseded','draft'))`
- `confidence REAL NOT NULL`
- `source_kind TEXT NOT NULL`
- `source_id TEXT NOT NULL`
- `entity_id TEXT`
- `session_id TEXT`
- `created_at TEXT NOT NULL`
- `indexed_at TEXT NOT NULL`
- `superseded_by TEXT`

Indexes:

- unique `fingerprint`
- `idx_decisions_source(source_kind, source_id)`
- `idx_decisions_status(status, indexed_at DESC)`
- `idx_decisions_entity(entity_id, indexed_at DESC)`

### `maintenance_runs`

- `id TEXT PRIMARY KEY`
- `started_at TEXT NOT NULL`
- `completed_at TEXT NOT NULL`
- `grade TEXT NOT NULL`
- `score_value REAL NOT NULL`
- `summary TEXT NOT NULL DEFAULT ''`
- `metadata TEXT NOT NULL DEFAULT '{}'`

### `maintenance_run_items`

- `id TEXT PRIMARY KEY`
- `run_id TEXT NOT NULL REFERENCES maintenance_runs(id) ON DELETE CASCADE`
- `kind TEXT NOT NULL`
- `severity TEXT NOT NULL`
- `target_id TEXT`
- `entity_name TEXT`
- `title TEXT NOT NULL`
- `detail TEXT NOT NULL DEFAULT ''`
- `recommended_action TEXT`
- `created_at TEXT NOT NULL`

## Engine and CLI Surface

Engine additions:

- `backlinks(name, source_kind=None)`
- `list_decisions(entity_name=None, status=None, limit=20)`
- `get_decision(decision_id)`
- `run_maintenance()`
- `list_maintenance_runs(limit=20)`
- `get_maintenance_run(run_id)`
- `rebuild_references()`
- `rebuild_decisions()`
- `rebuild_projections()`

CLI additions:

- `backlinks`
- `decisions`
- `decision-show`
- `maintenance-run`
- `maintenance-list`
- `maintenance-show`
- `rebuild-references`
- `rebuild-decisions`
- `rebuild-projections`

These belong under the existing advanced CLI command set rather than introducing another entrypoint.

## Matching and Extraction Rules

### References

- exact and normalized entity-name matching only
- alias matching allowed
- denylisted short names and generic tokens are skipped
- snippets are stored, full source text remains canonical elsewhere

### Decisions

- extracted from `session.summary`, `debug_session.conclusion`, and selected notes
- rule-based detection only
- confidence must stay above a conservative threshold
- repeated indexing of one source performs source-scoped replacement

## Diagnostics

`projection_drift` is added as a new open-loop kind. It covers cases where:

- a source row should have a projection but none exists
- indexed rows are stale relative to canonical source timestamps
- rebuild commands detect replaceable corruption

The standard health report remains live. `run_maintenance()` persists a point-in-time copy of those open loops.

## Testing Strategy

The implementation must cover:

- migration and schema creation
- reference extraction and rebuild idempotency
- decision extraction and source-scoped replacement
- maintenance run persistence
- projection drift diagnostics
- search reranking behavior
- brief support hit rendering
- CLI command coverage
- full regression suite

## Success Criteria

Phase 1 is complete when:

- the new tables migrate on top of existing databases
- backlinks and decisions are queryable through engine and CLI
- maintenance runs are persisted and inspectable
- health diagnostics can surface projection drift
- search responses include reranking explanations
- briefs expose supporting hits
- the full test suite stays green
