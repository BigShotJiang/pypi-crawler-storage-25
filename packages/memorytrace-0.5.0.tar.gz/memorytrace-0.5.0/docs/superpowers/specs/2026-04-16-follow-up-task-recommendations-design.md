# Follow-up Task Recommendation Design

## Goal

Add a final computed recommendation kind, `follow_up_task`, so Engram can turn aged verification requests, stale governance backlog, and high-signal open loops into explicit next-work items without introducing a persisted task system.

This closes the last unimplemented roadmap recommendation type while keeping the current recommendation architecture intact.

## Scope

In scope:
- add `follow_up_task` to `RecommendationKind`
- compute follow-up recommendations from open verification requests
- compute follow-up recommendations from open governance candidates
- compute follow-up recommendations from actionable open loops
- expose the new kind through existing engine and CLI recommendation surfaces

Out of scope:
- persisted task backlog
- automatic task creation
- task completion workflow
- policy-aware compaction execution
- automatic delete or archival

## Approach Options

### 1. Computed follow-up recommendation only (recommended)

Derive follow-up work from existing verification, governance, and diagnostics state.

Pros:
- no schema change
- recommendations stay current
- fits the existing `RecommendationService` design

Cons:
- no audit trail of task acceptance
- not a full task system

### 2. Persisted recommendation backlog

Store follow-up tasks in SQLite as their own backlog table.

Pros:
- stronger audit trail

Cons:
- requires dedupe, cleanup, and reopen rules
- recommendations become stale as source state changes

### 3. Real task subsystem

Introduce a first-class `tasks` model and make recommendation generation create tasks.

Pros:
- strongest long-term workflow

Cons:
- exceeds the roadmap phase
- changes the product boundary from recommendation to task management

## Architecture

The recommended approach is option 1.

`RecommendationService` remains the single place that computes advisory work items. `follow_up_task` becomes another computed view, alongside:
- `stale_decision`
- `open_loop_escalation`
- `merge_recommendation`

The recommendation output still points at the original object that requires work. It does not create a new stored task.

## Data Model

No new tables are introduced.

Add one enum value:
- `RecommendationKind.FOLLOW_UP_TASK`

`RecommendationView` remains unchanged:
- `kind`
- `severity`
- `target_kind`
- `target_id`
- `title`
- `detail`
- `recommended_action`
- `evidence`
- `policy_conflicts`

## Source Rules

### 1. Verification request follow-up

Generate a `follow_up_task` when:
- verification request status is `open`
- request age is at least 3 days

Severity:
- `warning` when age is 3 to 6 days
- `critical` when age is 7 days or more

Target:
- `target_kind = "verification_request"`
- `target_id = <verification request id>`

Recommended action:
- `engram verification-show <id>`

Evidence should include:
- request age in days
- request reason
- target kind and target id
- requester

### 2. Governance candidate follow-up

Generate a `follow_up_task` when:
- governance candidate status is `open`
- candidate type is `merge` or `split`
- candidate score is at least `0.90`, or candidate age is at least 3 days

Severity:
- `critical` when score is at least `0.95` or age is 7 days or more
- `warning` otherwise

Target:
- `target_kind = "governance_candidate"`
- `target_id = <candidate id>`

Recommended action:
- `engram governance-show <id>`

Evidence should include:
- candidate type
- candidate score
- candidate rationale
- candidate age in days

### 3. Open-loop follow-up

Generate a `follow_up_task` when:
- current diagnostics still contain the open loop
- the loop has a non-empty `recommended_action`
- the loop is not already represented by a verification-request or governance-candidate follow-up
- loop severity is `critical`, or loop age is at least 7 days

Target:
- `target_kind = "open_loop"`
- `target_id = loop.target_id or loop.title`

Recommended action:
- reuse `loop.recommended_action`

Evidence should include:
- loop kind
- loop severity
- loop age when available

## Suppression and Dedupe

Rules:
- within `follow_up_task`, dedupe by `target_kind + target_id`
- resolved or cancelled verification/governance rows never emit follow-up recommendations
- open-loop follow-up is skipped when the loop is already naturally owned by an open verification request or open governance candidate

Policy semantics:
- `pin` does not suppress follow-up work
- when the underlying fact, decision, or entity is pinned, add `"pin"` to `policy_conflicts`
- `archive_only` does not suppress follow-up work because this recommendation is operational, not retrieval-facing

## Engine and CLI Surface

No new engine methods are needed.

Existing methods extend:
- `list_recommendations(kind=...)` accepts `follow_up_task`
- `get_recommendation(...)` resolves `follow_up_task` rows too

CLI:
- `recommendations --kind follow_up_task`
- `recommendation-show <id>`

## Error Handling

- if a referenced entity, fact, or decision disappears while computing follow-up recommendations, the row is skipped
- missing age metadata degrades severity selection but must not fail recommendation listing
- recommendation generation must never break search, brief, maintenance, or CLI flows

## Testing

Minimum coverage:
- open verification request older than 3 days emits `follow_up_task`
- resolved verification request does not emit `follow_up_task`
- open merge or split governance candidate emits `follow_up_task`
- old or critical open loop with a recommended action emits `follow_up_task`
- CLI accepts `follow_up_task` kind filter
- duplicate source signals do not generate duplicate `follow_up_task` rows

## Rollout Notes

This phase intentionally stops before real task objects. The goal is to complete the recommendation roadmap while preserving the current design principle: persisted state for durable memory, computed views for dynamic operational guidance.
