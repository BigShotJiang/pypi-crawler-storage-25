# Engram Quickstart

## 1. 설치

```bash
pip install memorytrace
engram init
engram status
```

소스 체크아웃에서 바로 개발 중이면 다음도 가능하다.

```bash
pip install -e .
python -m engram status
```

`python mem ...`는 이 저장소 안에서만 동작하는 하위 호환 wrapper다.
설치형 사용 문서에서는 `engram`을 기준으로 본다.

## 2. 기본 저장과 검색

```bash
engram save "Minseong Jeong is the CTO of Galaxy Corp."
engram save "Galaxy Corp is a robotics company based in Seoul."

engram find "CTO"
engram who "Minseong Jeong"
```

## 3. 수동 사실 추가와 노트 조회

```bash
engram remember "Minseong Jeong" "Interested in AI and robotics"
engram all
engram recent 5
engram notes "robotics"
```

## 4. 삭제와 내보내기

```bash
engram forget "Temporary Entity"
engram export
```

## 5. Advanced CLI

`engram-advanced`는 JSON 출력, 필터, 커스텀 DB 경로, MCP 서버 같은 구조화 옵션용이다.

```bash
engram-advanced --db ~/.engram/memory.db search "Galaxy" --max-results 5 --min-confidence 0.5
engram-advanced --json get "Minseong Jeong"
engram-advanced --json health
engram-advanced reindex
```

## 6. Python SDK

```python
from engram.integrations.sdk import EngramSDK

with EngramSDK() as sdk:
    sdk.start_session("my-app")
    sdk.store("Minseong Jeong is the CTO of Galaxy Corp.")
    sdk.add_fact("Minseong Jeong", "Interested in AI and robotics")

    result = sdk.search("Galaxy")
    print(result.to_agent_context())

    entity = sdk.get_entity("Minseong Jeong")
    facts = sdk.get_facts("Minseong Jeong")

    sdk.end_session("Reviewed Galaxy Corp profile")
```

`sdk.remember()`는 없다. 수동 사실 추가는 `sdk.add_fact()`를 사용한다.

## 7. 같은 기능의 다른 진입점

- `engram ...`
- `python -m engram ...`
- `engram-advanced ...`
- `python -m engram.cli.app ...`

소스 체크아웃 안에서는 `python mem ...`도 가능하지만, 공식 설치 경로는 아니다.
