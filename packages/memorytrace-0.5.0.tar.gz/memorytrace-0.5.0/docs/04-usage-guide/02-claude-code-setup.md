# Claude Code / Codex에서 Engram 연결하기

## 1. 설치와 확인

가장 간단한 설치:

```bash
pip install memorytrace
engram status
```

로컬 체크아웃에서 개발 중이면:

```bash
pip install -e .
python -m engram status
```

필요하면 `ENGRAM_BASE_DIR` 환경변수로 저장 위치를 바꿀 수 있다.

## 2. 슬래시 커맨드 파일 만들기

`~/.claude/commands/` 아래에 다음 파일을 둔다.

### `memory-save.md`

````markdown
Save information to Engram persistent memory.

Run this command:
```bash
engram save "$ARGUMENTS"
```

After running, tell the user what entities and facts were saved.
````

### `memory-find.md`

````markdown
Search Engram memory for relevant information.

Run this command:
```bash
engram find "$ARGUMENTS"
```

Present the search results clearly.
````

### `memory-who.md`

````markdown
Look up everything known about a person or organization.

Run this command:
```bash
engram who "$ARGUMENTS"
```

Present the entity details and facts.
````

### `memory-remember.md`

````markdown
Manually remember a fact about someone.
Format: "Name" "Fact"

Run this command:
```bash
engram remember $ARGUMENTS
```

Confirm what was remembered.
````

### `memory-status.md`

````markdown
Check Engram memory health.

Run this command:
```bash
engram status
```
````

### `memory-context.md`

````markdown
Load previous conversation context from Engram memory.

Run this command:
```bash
python -c "
from pathlib import Path
import json
from engram.config import EngramConfig
from engram.engine import MemoryEngine

engine = MemoryEngine(EngramConfig(base_dir=Path.home() / '.engram'))
try:
    ctx = engine.get_session_context('claude-code')
    print(json.dumps(ctx, ensure_ascii=False, indent=2))
finally:
    engine.close()
"
```

Use the context to inform the current conversation.
````

## 3. 사용 예시

```text
/memory-save Minseong Jeong is the CTO of Galaxy Corp
/memory-find Galaxy Corp
/memory-who Minseong Jeong
/memory-remember "Minseong Jeong" "Interested in AI and robotics"
/memory-status
/memory-context
```

## 4. 고급 옵션이 필요할 때

JSON 출력, 커스텀 DB 경로, MCP 서버 같은 구조화 옵션이 필요하면 `engram-advanced`를 쓴다.

예시:

```bash
engram-advanced --db ~/.engram/memory.db --json search "Galaxy Corp"
engram-advanced --json health
```

`~/engram/mem` 같은 repo-local 경로에 의존하는 방식은 더 이상 권장하지 않는다.
설치형 환경에서는 `engram` 또는 `python -m engram`을 기준으로 설정한다.
