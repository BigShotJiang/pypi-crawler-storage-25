# 4. 디렉토리 구조 및 주요 파일

## 소스 코드 구조

```
기존-도구/
├── assets/                              # 배너 이미지
│   ├── 기존-도구-architecture.svg        # 아키텍처 다이어그램 (SVG)
│   ├── 기존-도구-banner.jpg              # 리포지토리 배너
│   ├── 기존-도구-banner.png
│   ├── 기존-도구-banner.webp
│   └── 기존-도구-hero.jpg               # 히어로 이미지
│
├── docs/
│   ├── hero.jpg                         # 문서용 이미지
│   └── hero.webp
│
├── scripts/
│   └── generate-banner.py               # 순수 Python PNG 배너 생성기
│
├── src/기존-도구/                        # 메인 패키지
│   ├── __init__.py                      # 버전 문자열 ("0.1.0")
│   ├── cli.py                           # CLI 인자 파서 + 명령 디스패처
│   ├── core.py                          # 전체 비즈니스 로직 (~1500줄)
│   ├── stopwords.json                   # 검색 토큰화용 불용어 사전
│   └── templates/
│       ├── RESOLVER.md                  # 콘텐츠 분류 결정 트리 (한국어)
│       └── TEMPLATES.md                 # 엔티티/조직/의사결정 페이지 템플릿 (한국어)
│
├── tests/
│   ├── __init__.py
│   └── test_기존-도구.py                 # 51개 pytest 테스트
│
├── pyproject.toml                       # Python 패키징 설정
├── setup.py                             # 레거시 패키징 폴백
├── CONTRIBUTING.md                      # 기여 가이드
├── IMPROVEMENT_IDEAS.md                 # 경쟁사 분석 + 로드맵
├── LICENSE                              # MIT 라이선스
└── README.md                            # 프로젝트 소개
```

## 주요 파일 상세

### `src/기존-도구/core.py` - 핵심 엔진

프로젝트의 심장부. 단일 `기존도구` 클래스에 54개 메서드가 포함되어 있다 (~1500줄).

**주요 메서드 그룹:**
- **엔티티 관리**: `track()`, `update()`, `list_entities()`, `promote()`
- **추출/탐지**: `extract()`, `extract_conversations()`, `detect()`, `_detect_regex()`
- **검색**: `search()`, `agentic_search()`, `query()`, `lookup()`
- **분석**: `brief()`, `retro()`, `distill_decisions()`, `open_loops()`
- **유지보수**: `dream()`, `decay()`, `dedup()`, `index()`, `diff()`
- **세션**: `log_event()`, `summarize()`
- **유틸리티**: `_slugify()`, `_tokenize()`, `_compute_idf()`

### `src/기존-도구/cli.py` - CLI 래퍼

얇은 CLI 래퍼로, `argparse`를 사용해 30+ 서브커맨드를 정의하고 `기존도구` 인스턴스의 해당 메서드로 디스패치한다.

```python
def main():
    parser = argparse.ArgumentParser(description="기존도구 - AI Agent Memory")
    subparsers = parser.add_subparsers(dest="command")
    # 30+ 서브커맨드 정의...
    args = parser.parse_args()
    mk = 기존도구()
    # 명령 디스패치
```

### `src/기존-도구/templates/TEMPLATES.md` - 페이지 템플릿

한국어로 작성된 엔티티 페이지 구조 정의:
- **인물 템플릿**: Executive Summary, State (역할/소속), Key Points, Timeline
- **조직 템플릿**: 조직 개요, 핵심 멤버, 주요 프로젝트
- **의사결정 템플릿**: 배경, 선택지, 결정, 근거

**Compiled Truth + Timeline 이중 레이어 구조**와 출처 표기 규칙(`[Source: who, channel, date]`)이 여기에 정의되어 있다.

### `src/기존-도구/templates/RESOLVER.md` - 분류 결정 트리

정보 유형별 라우팅 규칙을 정의한 한국어 문서:
- 인물 정보 → `entities/`
- 의사결정 → `decisions/`
- 독창적 사고 → `originals/`
- 작업 항목 → `tasks/`
- MECE 원칙과 중복 감지 규칙 포함

### `src/기존-도구/stopwords.json` - 불용어 사전

검색 토큰화 시 제거할 불용어 목록. BM25 스코어링의 정확도를 높이기 위해 사용된다.

### `tests/test_기존-도구.py` - 테스트 스위트

51개 pytest 테스트로 구성:
- 초기화 테스트
- 엔티티 CRUD 테스트
- 검색 정확도 테스트
- NER 탐지 테스트
- Dream Cycle 검사 테스트
- Cognify 파이프라인 테스트

### `scripts/generate-banner.py` - 배너 생성기

주목할 만한 파일. 외부 이미지 라이브러리(Pillow 등) 없이 순수 Python으로 PNG를 생성한다:
- `zlib` 압축
- CRC32 체크섬
- 내장 5x7 비트맵 폰트
- PNG 바이너리 포맷 직접 구현

## 런타임 생성 디렉토리 (memory/)

`기존-도구 init` 실행 시 생성되는 구조:

```
memory/
├── entities/           # 컴파일된 엔티티 페이지
├── live-notes/         # 실시간 추적 페이지
├── decisions/          # 의사결정 기록
├── originals/          # 독창적 사고/프레임워크
├── inbox/              # 미분류 항목 (Cognify 대기)
├── tasks/              # 작업 추적
├── meetings/           # 미팅 브리프 및 노트
├── sessions/           # 세션 이벤트 로그 (JSONL)
├── fact-registry.md    # 교차 도메인 팩트 인덱스 (자동 생성)
├── RESOLVER.md         # 분류 결정 트리 (복사본)
└── TEMPLATES.md        # 페이지 템플릿 (복사본)
```

기본 경로는 현재 작업 디렉토리의 `./memory/`이며, `ENGRAM_BASE_DIR` 환경 변수로 재정의 가능하다.
