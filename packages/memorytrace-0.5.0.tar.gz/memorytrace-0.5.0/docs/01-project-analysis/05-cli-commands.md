# 5. 현재 CLI 명령어 정리

## 공식 진입점

| 진입점 | 설명 |
|--------|------|
| `engram` | 기본 simple CLI |
| `python -m engram` | `engram`과 동일한 simple CLI |
| `engram-advanced` | 구조화 옵션 중심 CLI |
| `python -m engram.cli.app` | `engram-advanced`와 동일한 advanced CLI |
| `python mem` | 이 저장소 안에서만 쓰는 하위 호환 wrapper, 패키지 설치 시 함께 설치되지는 않음 |

## Simple CLI: `engram`

기본 저장, 검색, 조회, 노트 관리에 적합하다.

| 명령 | 설명 | 예시 |
|------|------|------|
| `init` | 기본 DB 초기화 | `engram init` |
| `save "text"` | 텍스트에서 엔티티와 사실을 추출해 저장 | `engram save "Alice leads the robotics team"` |
| `find "query"` | 엔티티와 노트를 함께 검색 | `engram find "robotics"` |
| `who "name"` | 특정 엔티티 상세 조회 | `engram who "Alice"` |
| `remember "name" "fact"` | 수동으로 사실 추가 | `engram remember "Alice" "Works on humanoid robots"` |
| `all` | 엔티티 목록 조회 | `engram all` |
| `recent [N]` | 최근 노트 조회 | `engram recent 10` |
| `notes "query" [--full]` | 노트만 검색 | `engram notes "meeting" --full` |
| `delete-note "keyword" [--confirm]` | 매칭되는 노트 삭제 | `engram delete-note "temporary" --confirm` |
| `cleanup [--dry-run]` | 오래된 노트 정리 | `engram cleanup --dry-run` |
| `status` | 상태 점검 | `engram status` |
| `forget "name"` | 엔티티 삭제 | `engram forget "Temporary Entity"` |
| `export` | Markdown 내보내기 | `engram export` |
| `json find|who|all ...` | simple CLI JSON 출력 | `engram json find "robotics"` |

별칭:

- `engram search`는 `engram find`와 같다.
- `engram get`은 `engram who`와 같다.
- `engram list`는 `engram all`과 같다.

## Advanced CLI: `engram-advanced`

필터링, JSON 출력, DB 경로 지정, MCP 서버 실행이 필요할 때 쓴다.

| 명령 | 설명 | 예시 |
|------|------|------|
| `init` | DB 초기화 | `engram-advanced --db ~/.engram/memory.db init` |
| `store` | 텍스트 저장 | `engram-advanced store "Alice leads robotics"` |
| `search` | 옵션 기반 검색 | `engram-advanced search "robotics" --max-results 5` |
| `get` | 엔티티 상세 조회 | `engram-advanced get "Alice"` |
| `list` | 엔티티 목록 조회 | `engram-advanced list --type person --limit 20` |
| `add-fact` | 사실 추가 | `engram-advanced add-fact "Alice" "Works in Seoul" --predicate location` |
| `create` | 엔티티 생성 | `engram-advanced create "Galaxy Corp" --type organization` |
| `conflicts` | 충돌 목록 조회 | `engram-advanced conflicts` |
| `resolve` | 충돌 해결 | `engram-advanced resolve <id> accept_new` |
| `health` | 헬스 체크 | `engram-advanced --json health` |
| `export` | Markdown 내보내기 | `engram-advanced export` |
| `reindex` | 검색 인덱스 재생성 | `engram-advanced reindex` |
| `serve --transport stdio` | MCP 서버 실행 | `engram-advanced serve --transport stdio` |

주요 전역 옵션:

- `--db`: DB 파일 경로 지정
- `--json`: JSON 출력
- `--quiet`: 불필요한 출력 최소화
- `--verbose`: 예외 상세 출력

## 환경 설정

| 항목 | 설명 |
|------|------|
| `ENGRAM_BASE_DIR` | simple CLI 기본 저장 위치 변경 |
| `ENGRAM_NOTE_PREVIEW` | simple CLI note 미리보기 길이 조정 |
| `PYTHONIOENCODING=utf-8` | Windows에서 직접 Python 엔트리포인트를 호출할 때 유용 |

Windows에서는 패키지 엔트리포인트 `engram`, `engram-advanced`가 stdout/stderr를 UTF-8로 재설정한다.
