# 9. 설치 및 환경 설정 가이드

## 요구 사항

- Python 3.9+
- SQLite/FTS5 사용 가능 환경
- Windows, macOS, Linux 지원

## 설치 방법

### 1. 기본 설치

```bash
pip install memorytrace
```

### 2. 선택 기능 포함 설치

```bash
pip install "memorytrace[llm]"
pip install "memorytrace[semantic]"
pip install "memorytrace[mcp]"
pip install "memorytrace[full]"
```

### 3. 소스에서 개발 설치

```bash
git clone https://github.com/aop60003/default.git
cd default
pip install -e ".[dev]"
```

## 빠른 동작 확인

### simple CLI

```bash
engram init
engram save "Alice leads the robotics team"
engram find "robotics"
engram who "Alice"
engram status
```

### advanced CLI

```bash
engram-advanced --db ~/.engram/memory.db init
engram-advanced --json health
engram-advanced search "robotics" --max-results 5
```

### Python SDK

```python
from engram.integrations.sdk import EngramSDK

with EngramSDK() as sdk:
    sdk.store("Alice leads the robotics team")
    sdk.add_fact("Alice", "Works in Seoul")
    result = sdk.search("robotics")
    print(result.to_agent_context())
```

## 저장 위치와 환경 변수

### 기본 저장 위치

- simple CLI 기본 경로: `~/.engram/`
- 주요 파일: `~/.engram/memory.db`
- Markdown export: `~/.engram/readable/`

### 환경 변수

| 변수 | 설명 |
|------|------|
| `ENGRAM_BASE_DIR` | simple CLI 기본 저장 경로 변경 |
| `ENGRAM_NOTE_PREVIEW` | note 미리보기 길이 조절 |

예시:

```bash
export ENGRAM_BASE_DIR="/path/to/custom/engram"
engram init
```

advanced CLI는 `--db`로 직접 DB 파일을 지정할 수 있다.

```bash
engram-advanced --db /path/to/custom/engram/memory.db health
```

## MCP 서버 사용

MCP 서버는 선택 기능이다.

```bash
pip install "memorytrace[mcp]"
engram-advanced serve --transport stdio
```

현재 지원 transport는 `stdio`만이다.

## Windows 메모

- 패키지 엔트리포인트 `engram`, `engram-advanced`는 stdout/stderr를 UTF-8로 재설정한다.
- 직접 `python -m engram` 또는 `python -m engram.cli.app`를 호출할 때 문제가 있으면 `PYTHONIOENCODING=utf-8`를 설정한다.

```powershell
$env:PYTHONIOENCODING = "utf-8"
python -m engram status
```

## 개발 환경 점검

```bash
python -m pytest tests -q
```

소스 체크아웃 안에서는 `python -m engram`과 `python mem` 둘 다 쓸 수 있지만, 공식 문서와 패키지 기준 진입점은 `engram`이다.

## 문제 해결

### `engram` 명령을 찾을 수 없음

- 가상환경이 활성화되어 있는지 확인
- 필요하면 `python -m engram status`로 동일 기능 확인

### 커스텀 DB를 쓰고 싶음

- simple CLI: `ENGRAM_BASE_DIR`
- advanced CLI: `--db /path/to/memory.db`

### JSON 출력이 필요함

- `engram-advanced --json ...`
- 또는 `engram json find|who|all ...`
