# 23. Engram Next Capabilities Roadmap (2026-04-16)

## 목적

이 문서는 현재 Engram이 이미 갖춘 기능 위에서, 다음으로 어떤 기능을 어떤 순서로 추가해야 하는지 정리한 후속 로드맵이다.

전제는 명확하다.

- `backlinks`
- `decisions`
- `maintenance run`
- `projection drift`
- `goal-aware retrieval / reranking`

위 기능이 이미 반영되었거나 곧 반영된다고 가정한다.  
즉, 이 문서는 "기본기를 만들자"가 아니라 **구조화된 agent memory engine을 다음 단계로 밀어 올리는 순서**를 정의한다.

## 핵심 방향

이번 단계에서 중요한 것은 기능 수가 아니다. 다음 세 가지를 더 강하게 만드는 것이다.

1. 검색 결과가 왜 나왔는지 설명 가능해야 한다.
2. 메모리가 어느 범위에 속하는지 명확해야 한다.
3. 시간이 지나도 메모리가 덜 오염되고, 운영자가 복구 가능해야 한다.

같은 문제를 푼다고 해도 Engram은 아래 결과에서 더 좋아야 한다.

- 더 설명 가능한 retrieval
- 더 안전한 scope 관리
- 더 엄격한 freshness / verification
- 더 강한 entity governance
- 더 안정적인 projection 운영

## 우선순위 원칙

### 1. 표면 기능보다 엔진 품질을 먼저 올린다

사람이 보는 CLI 명령을 늘리는 것보다, 같은 명령이 더 정확하고 더 신뢰 가능하게 동작하도록 만드는 편이 우선이다.

### 2. write-time 품질 게이트를 lifecycle 품질 관리로 확장한다

지금 Engram은 "저장할 때 조심하는 시스템"에 가깝다. 다음 단계는 "시간이 지나도 계속 건강한 시스템"으로 가는 것이다.

### 3. 추론 가능성보다 운영 가능성을 같이 챙긴다

retrieval이 똑똑해지는 것만으로는 부족하다. 왜 그렇게 되었는지, 잘못됐을 때 어떻게 복구할지까지 설계돼야 한다.

## 순차 로드맵

## Phase 0. Evaluation Baseline Hardening

### 목표

이후 phase들이 실제로 Engram을 더 좋게 만들었는지 측정할 수 있는 기준선을 만든다.

### 범위

- retrieval golden scenarios
- handoff quality scenarios
- maintenance noise ratio
- projection rebuild smoke scenarios
- entity merge / stale memory regression fixture 초안

### 왜 먼저 해야 하는가

앞으로 추가될 기능은 대부분 "체감상 좋아 보이는" 영역이다. 계측이 없으면 품질 향상을 주장할 근거가 약하다.

### 완료 기준

- retrieval 시나리오 최소 8개
- handoff 시나리오 최소 4개
- maintenance 시나리오 최소 4개
- 이후 phase가 재사용할 fixture / helper가 준비됨

## Phase 1. Provenance Trace

### 목표

모든 중요한 retrieval / brief / decision 결과에 대해 "왜 이 결과가 나왔는지"를 구조적으로 설명할 수 있게 만든다.

### 범위

- `SearchHit` 수준 provenance trace
- reranking factor explanation 강화
- result를 구성한 fact / decision / relation / source 참조 연결
- brief에서 supporting hit뿐 아니라 supporting provenance 노출
- CLI / SDK / MCP에서 공통 소비 가능한 포맷

### 기대 효과

- 검색 결과 디버깅이 쉬워진다.
- retrieval 품질 튜닝이 쉬워진다.
- agent가 잘못된 컨텍스트를 받았을 때 원인을 추적할 수 있다.

### 완료 기준

- 상위 검색 결과마다 provenance block이 존재
- brief와 decision lookup도 같은 provenance 구조를 재사용
- 테스트에서 "왜 이 결과가 위로 올라왔는지"를 assertion 가능

## Phase 2. Scoped Memory / Namespace Policy

### 목표

메모리를 `global / workspace / project / channel / task / agent` 단위로 구분하고, 검색과 brief가 이 스코프를 반영하도록 만든다.

### 범위

- namespace / scope 모델 추가
- search 우선순위에 scope 반영
- write path에서 source scope 부착
- `context_pack()` 계열 출력에 scope summary 포함
- cross-scope fallback 규칙 정의

### 왜 지금 필요한가

agent context가 강해질수록 스코프 오염이 가장 큰 문제로 올라온다. 같은 이름의 entity라도 task와 workspace가 다르면 의미가 달라질 수 있다.

### 완료 기준

- 동일 query라도 active scope에 따라 다른 결과가 나온다
- 잘못된 workspace 메모리가 상위로 올라오는 빈도가 눈에 띄게 줄어든다
- channel/task/agent 메모리 설계와 충돌하지 않는다

## Phase 3. Async Projection / Job Runner

### 목표

projection rebuild, revalidation, maintenance, governance성 작업을 메인 write path 밖으로 분리할 수 있는 운영 계층을 만든다.

### 범위

- lightweight job queue / runner
- projection rebuild job
- maintenance job
- revalidation job placeholder
- failed job retry / dead-letter 성격의 최소 기록

### 왜 이 단계가 선행되어야 하는가

freshness workflow와 entity governance는 메인 write path에서 동기 처리하기엔 무겁다. 여기서 운영 계층을 먼저 깔아야 이후 단계가 안전하다.

### 완료 기준

- main write path는 기존처럼 빠르게 끝난다
- projection / maintenance성 무거운 작업이 background job으로 이동한다
- 실패 job을 다시 돌릴 수 있다

## Phase 4. Freshness / Verification Workflow

### 목표

메모리가 오래되었거나 신뢰도가 낮아졌을 때 자동으로 감지하고, 읽기 시점과 운영 시점 모두에서 재검증 루프를 돌릴 수 있게 만든다.

### 범위

- stale memory queue
- verify-on-read 정책
- fact revalidation request
- decision freshness downgrade
- source recency / confidence 기반 penalty

### 기대 효과

- 오래된 정보를 계속 상위로 보여주는 문제가 줄어든다
- maintenance가 단순 진단에서 재검증 워크플로로 올라간다
- applicability conditions와 잘 결합된다

### 완료 기준

- stale fact / decision을 시스템적으로 식별 가능
- read path에서 stale penalty가 작동
- maintenance report에 verification backlog가 포함됨

## Phase 5. Entity Governance

### 목표

entity 중복, alias 충돌, 잘못된 분리/병합을 구조적으로 관리하는 계층을 만든다.

### 범위

- duplicate entity cluster 탐지
- merge candidate 제안
- split candidate 제안
- alias 승인 / 거부 흐름
- merge 후 reference / decision / relation relink

### 왜 필요한가

Engram이 커질수록 가장 위험한 오염원은 retrieval보다 entity fragmentation이다. 이걸 잡지 못하면 graph와 provenance 품질이 같이 무너진다.

### 완료 기준

- duplicate cluster를 정기적으로 찾을 수 있다
- merge가 fact / relation / reference / decision까지 일관되게 반영된다
- alias 변경이 projection과 검색 품질에 안전하게 연결된다

## Phase 6. Policy-based Retention + Recommendation Triggers

### 목표

메모리를 단순히 저장하는 것이 아니라, 남겨야 할 것과 줄여야 할 것을 정책으로 관리하고, 운영자에게 다음 조치를 추천할 수 있게 만든다.

### 범위

- `pin`, `ttl`, `archive_only`, `never_summarize` 같은 retention policy
- merge recommendation
- stale decision recommendation
- follow-up task recommendation
- unresolved open-loop escalation

### 기대 효과

- 장기 메모리 오염을 더 줄일 수 있다
- maintenance가 더 action-oriented 해진다
- 사용자가 직접 모든 정리 작업을 기억하지 않아도 된다

### 완료 기준

- retention policy가 search / maintenance / compaction에 반영된다
- recommendation이 최소 3종 이상 구조적으로 생성된다
- false positive가 과도하게 높지 않다

## 단계별 의존성

1. `Phase 0`은 나머지 단계의 측정 기반이다.
2. `Phase 1`은 retrieval 계열 품질 개선의 설명 가능성 기반이다.
3. `Phase 2`는 agent memory가 커질수록 먼저 필요한 스코프 안전장치다.
4. `Phase 3`은 이후 무거운 운영 기능을 안전하게 받치는 기반이다.
5. `Phase 4`는 stale / verification lifecycle을 만든다.
6. `Phase 5`는 graph 품질을 구조적으로 지킨다.
7. `Phase 6`은 장기 운영 최적화 단계다.

## 최종 정리

다음 단계에서 Engram이 더 구현해야 할 핵심은 "기능을 많이 붙이는 것"이 아니다.

- 결과를 더 잘 설명하게 만들고
- 메모리 범위를 더 엄격하게 관리하고
- 시간이 지나도 더 덜 오염되게 만들고
- 운영자가 더 쉽게 복구하고 정리할 수 있게 만드는 것

우선순위만 압축하면 이렇다.

1. `Provenance Trace`
2. `Scoped Memory / Namespace Policy`
3. `Async Projection / Job Runner`
4. `Freshness / Verification Workflow`
5. `Entity Governance`
6. `Policy-based Retention + Recommendation Triggers`

이 순서가 Engram을 단순한 memory feature 집합이 아니라, **설명 가능하고 운영 가능한 agent memory system**으로 끌어올리는 가장 현실적인 다음 단계다.
