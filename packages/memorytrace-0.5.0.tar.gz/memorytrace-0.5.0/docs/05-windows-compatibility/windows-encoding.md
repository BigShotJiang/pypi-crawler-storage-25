# Windows 호환성 가이드

## jq 설치 (필수)

모든 Claude Code hooks가 jq에 의존한다. 미설치 시 hooks가 조용히 스킵되어 engram 자동 저장/로드가 동작하지 않는다.

```bash
# Windows (Git Bash / PowerShell)
winget install jqlang.jq

# 설치 후 셸 재시작 필요 (PATH 반영)
jq --version  # jq-1.8.1 확인
```

설치 후 `jq`가 PATH에 잡히지 않으면 WinGet 설치 경로를 확인:
```
%LOCALAPPDATA%\Microsoft\WinGet\Packages\jqlang.jq_Microsoft.Winget.Source_8wekyb3d8bbwe\jq.exe
```

## 인코딩 문제

Windows의 기본 콘솔 인코딩은 `cp949` (한국어) 또는 `cp1252` (영어)이다.
Python의 `print()`는 `sys.stdout.encoding`을 따르므로, UTF-8 문자(em dash `—`, 한글 일부 조합 등)가 포함된 출력에서 `UnicodeEncodeError`가 발생한다.

### 에러 예시

```
UnicodeEncodeError: 'cp949' codec can't encode character '\u2014' in position 11: illegal multibyte sequence
```

이 에러는 `engram` CLI의 help 텍스트에 포함된 em dash 문자에서 발생했다.

## 영향 범위

| 구성요소 | 영향 | 상태 |
|---------|------|------|
| `engram` CLI (`simple.py`) | `print()` 출력 시 크래시 | 수정됨 - `cli_entry()`에서 stdout/stderr를 UTF-8로 reconfigure |
| Claude Code hooks | `engram` 호출 시 크래시 | 수정됨 - `export PYTHONIOENCODING=utf-8` 추가 |
| 다른 hooks (lint 등) | Python 미사용, 영향 없음 | 해당 없음 |

## 수정 내용

### 1. Engram CLI 소스 코드 (`engram/cli/simple.py`)

`cli_entry()` 함수에서 `sys.stdout`과 `sys.stderr`를 UTF-8로 강제 설정:

```python
def cli_entry():
    import io
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    elif hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    # stderr도 동일하게 처리
    sys.exit(main())
```

- `reconfigure()`: Python 3.7+ 지원. 기존 버퍼를 재사용하므로 효율적
- `TextIOWrapper` fallback: `reconfigure`가 없는 환경 대비
- `errors="replace"`: 인코딩 불가 문자를 `?`로 대체 (크래시 방지)

### 2. Hooks (`session-memory-load.sh`, `stop-memory-save.sh`)

셸 스크립트에서 engram 호출 전에 환경변수 설정:

```bash
export PYTHONIOENCODING=utf-8
```

이 환경변수는 Python 프로세스 시작 시 stdout/stderr 인코딩을 결정한다.

## 새 프로젝트 적용 시 체크리스트

- [ ] `engram` CLI를 Windows에서 실행할 경우, 수정된 버전 설치
- [ ] `.claude/hooks/`의 engram 관련 hooks에 `export PYTHONIOENCODING=utf-8` 포함 확인
- [ ] Windows 전역 설정으로 해결하려면: 시스템 환경변수에 `PYTHONIOENCODING=utf-8` 추가

## 대안: 시스템 레벨 해결

Windows 시스템 전체에서 Python UTF-8 모드를 활성화하는 방법:

### 방법 1: 환경변수 (권장)
```
시스템 속성 > 환경 변수 > 시스템 변수 > 새로 만들기
변수 이름: PYTHONUTF8
변수 값: 1
```

### 방법 2: Windows 10 1903+ UTF-8 코드페이지
```
설정 > 시간 및 언어 > 언어 > 관리 언어 설정 > 시스템 로캘 변경
> "Beta: 세계 언어 지원을 위해 Unicode UTF-8 사용" 체크
```

주의: 방법 2는 일부 레거시 프로그램에 영향을 줄 수 있다.
