"""Markdown exporter — one-way DB → Markdown for human readability."""

from __future__ import annotations

import re
from pathlib import Path

from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.relation import Relation


def _slugify(name: str) -> str:
    """Convert entity name to filesystem-safe slug."""
    slug = name.lower().strip()
    slug = re.sub(r'[^\w\s\u3040-\u9FFF\uAC00-\uD7AF-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = slug.strip('-')
    return slug[:80] if slug else "unnamed"


class MarkdownExporter:
    """One-way export: DB → Markdown files. Never reads from Markdown.

    Generates human-readable Markdown files from structured DB data.
    These files are for viewing only — the DB is the source of truth.
    """

    def __init__(self, export_dir: Path):
        self.export_dir = Path(export_dir)
        self.export_dir.mkdir(parents=True, exist_ok=True)

    def export_entity(
        self,
        entity: Entity,
        facts: list[Fact],
        relations: list[Relation],
    ) -> Path:
        """Generate a Markdown file for a single entity."""
        md = self._render_entity(entity, facts, relations)
        filename = f"{_slugify(entity.name)}.md"
        filepath = self.export_dir / filename
        filepath.write_text(md, encoding="utf-8")
        return filepath

    def export_all(
        self,
        entities: list[tuple[Entity, list[Fact], list[Relation]]],
    ) -> int:
        """Export all entities. Returns count of files written."""
        count = 0
        for entity, facts, relations in entities:
            self.export_entity(entity, facts, relations)
            count += 1
        return count

    def _render_entity(
        self,
        entity: Entity,
        facts: list[Fact],
        relations: list[Relation],
    ) -> str:
        """Render entity data as Markdown."""
        lines: list[str] = []

        # Title
        lines.append(f"# {entity.name}")
        lines.append("")

        # Summary
        if entity.summary:
            lines.append(f"> {entity.summary}")
            lines.append("")

        # State
        state = entity.state.to_dict()
        if state:
            lines.append("## State")
            for key, value in state.items():
                if key == "custom" and isinstance(value, dict):
                    for ck, cv in value.items():
                        lines.append(f"- **{ck}**: {cv}")
                else:
                    lines.append(f"- **{key.title()}**: {value}")
            lines.append("")

        # Metadata
        lines.append("## Metadata")
        lines.append(f"- **Type**: {entity.entity_type}")
        lines.append(f"- **Tier**: {entity.tier.value}")
        lines.append(f"- **Updated**: {entity.updated_at.strftime('%Y-%m-%d %H:%M') if entity.updated_at else 'N/A'}")
        if entity.aliases:
            lines.append(f"- **Aliases**: {', '.join(entity.aliases)}")
        lines.append("")

        # Relations
        if relations:
            lines.append("## Relations")
            for rel in relations:
                if rel.from_entity_id == entity.id:
                    lines.append(f"- {rel.relation_type} → `{rel.to_entity_id}`")
                else:
                    lines.append(f"- ← {rel.relation_type} from `{rel.from_entity_id}`")
            lines.append("")

        # Facts (current)
        current_facts = [f for f in facts if f.is_current]
        if current_facts:
            lines.append("## Key Facts")
            for fact in current_facts:
                conf_label = self._confidence_label(fact.confidence)
                source_info = f"{fact.source.type.value}"
                if fact.source.author:
                    source_info += f", {fact.source.author}"
                lines.append(
                    f"- {fact.raw_text} "
                    f"[{conf_label}] "
                    f"[Source: {source_info}]"
                )
            lines.append("")

        # Timeline (all facts, chronological)
        if facts:
            lines.append("---")
            lines.append("")
            lines.append("## Timeline")
            sorted_facts = sorted(facts, key=lambda f: f.created_at, reverse=True)
            for fact in sorted_facts:
                date_str = fact.created_at.strftime('%Y-%m-%d')
                status_icon = "✓" if fact.is_current else "✗"
                lines.append(f"- [{status_icon}] **{date_str}** | {fact.raw_text}")
            lines.append("")

        return "\n".join(lines)

    def _confidence_label(self, confidence: float) -> str:
        if confidence >= 0.8:
            return "HIGH"
        elif confidence >= 0.5:
            return "MED"
        elif confidence >= 0.3:
            return "LOW"
        else:
            return "UNVERIFIED"
