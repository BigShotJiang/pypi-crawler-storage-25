"""Schema versioning and migration support."""

from __future__ import annotations

import sqlite3

CURRENT_VERSION = 13


def get_schema_version(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute(
            "SELECT value FROM _meta WHERE key = 'schema_version'"
        ).fetchone()
        return int(row[0]) if row else 0
    except sqlite3.OperationalError:
        return 0


def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r[1] == column for r in rows)


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table,),
    ).fetchone()
    return row is not None


def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
    """Phase 2 feature 4: per-fact memory_type column.

    SQLite ``ALTER TABLE ADD COLUMN`` is cheap (no table rewrite) and safe to
    run on a populated DB. All existing facts default to ``episodic``.
    """
    if not _column_exists(conn, "facts", "memory_type"):
        conn.execute(
            "ALTER TABLE facts ADD COLUMN memory_type TEXT NOT NULL DEFAULT 'episodic'"
        )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_facts_memory_type ON facts(memory_type)"
    )


def _migrate_v2_to_v3(conn: sqlite3.Connection) -> None:
    """Add indexes that support scoped pending-conflict lookups."""
    if not _table_exists(conn, "conflicts"):
        return
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_conflicts_existing_pending
        ON conflicts(existing_fact_id, resolved_at)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_conflicts_new_pending
        ON conflicts(new_fact_id, resolved_at)
        """
    )


def _migrate_v3_to_v4(conn: sqlite3.Connection) -> None:
    """Auto-close orphan conflicts when a fact is retracted or expired.

    SQLite cannot add foreign keys to existing tables, so we use a trigger
    to resolve conflicts when either of its referenced facts leaves the
    ``current`` set. This prevents orphan conflict rows from accumulating
    when facts are superseded/expired without going through
    ``delete_entity`` (which already handles cleanup manually).
    """
    if not _table_exists(conn, "conflicts"):
        return
    conn.execute(
        """
        CREATE TRIGGER IF NOT EXISTS trg_close_conflicts_on_fact_status
        AFTER UPDATE OF status ON facts
        WHEN NEW.status IN ('retracted', 'expired')
        BEGIN
            UPDATE conflicts
               SET resolution = 'auto_fact_status_change',
                   resolved_at = datetime('now'),
                   resolved_by = 'trigger'
             WHERE resolved_at IS NULL
               AND (existing_fact_id = NEW.id OR new_fact_id = NEW.id);
        END
        """
    )


def _migrate_v4_to_v5(conn: sqlite3.Connection) -> None:
    """Add ``text_hash`` column to notes for fast duplicate detection.

    ``_find_duplicate_note`` was doing ``WHERE LOWER(TRIM(text)) = ?`` which
    is a full table scan. With a pre-computed hash + index the lookup becomes
    an index seek.
    """
    if not _table_exists(conn, "notes"):
        return
    if not _column_exists(conn, "notes", "text_hash"):
        conn.execute("ALTER TABLE notes ADD COLUMN text_hash TEXT DEFAULT ''")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_notes_text_hash ON notes(text_hash)")
    # Backfill existing notes in batches to avoid OOM on large databases.
    import hashlib
    batch_size = 500
    while True:
        rows = conn.execute(
            "SELECT id, text FROM notes WHERE text_hash = '' OR text_hash IS NULL LIMIT ?",
            (batch_size,),
        ).fetchall()
        if not rows:
            break
        for row in rows:
            normalized = (row[1] or "").strip().lower()
            h = hashlib.sha256(normalized.encode("utf-8", errors="replace")).hexdigest()[:16]
            conn.execute("UPDATE notes SET text_hash = ? WHERE id = ?", (h, row[0]))


def _migrate_v5_to_v6(conn: sqlite3.Connection) -> None:
    """Add projection tables and persisted maintenance history."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS reference_edges (
            id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL,
            source_kind TEXT NOT NULL,
            source_id TEXT NOT NULL,
            snippet TEXT NOT NULL DEFAULT '',
            matched_text TEXT NOT NULL DEFAULT '',
            match_start INTEGER NOT NULL,
            match_end INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            indexed_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_reference_edges_entity
            ON reference_edges(entity_id, indexed_at DESC);
        CREATE INDEX IF NOT EXISTS idx_reference_edges_source
            ON reference_edges(source_kind, source_id);
        CREATE UNIQUE INDEX IF NOT EXISTS uq_reference_edges_source_span
            ON reference_edges(entity_id, source_kind, source_id, match_start, match_end);

        CREATE TABLE IF NOT EXISTS decisions (
            id TEXT PRIMARY KEY,
            fingerprint TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('active','superseded','draft')),
            confidence REAL NOT NULL,
            source_kind TEXT NOT NULL,
            source_id TEXT NOT NULL,
            entity_id TEXT,
            session_id TEXT,
            created_at TEXT NOT NULL,
            indexed_at TEXT NOT NULL,
            superseded_by TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_decisions_fingerprint
            ON decisions(fingerprint);
        CREATE INDEX IF NOT EXISTS idx_decisions_source
            ON decisions(source_kind, source_id);
        CREATE INDEX IF NOT EXISTS idx_decisions_status
            ON decisions(status, indexed_at DESC);
        CREATE INDEX IF NOT EXISTS idx_decisions_entity
            ON decisions(entity_id, indexed_at DESC);

        CREATE TABLE IF NOT EXISTS maintenance_runs (
            id TEXT PRIMARY KEY,
            started_at TEXT NOT NULL,
            completed_at TEXT NOT NULL,
            grade TEXT NOT NULL,
            score_value REAL NOT NULL,
            summary TEXT NOT NULL DEFAULT '',
            metadata TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_maintenance_runs_completed
            ON maintenance_runs(completed_at DESC);

        CREATE TABLE IF NOT EXISTS maintenance_run_items (
            id TEXT PRIMARY KEY,
            run_id TEXT NOT NULL REFERENCES maintenance_runs(id) ON DELETE CASCADE,
            kind TEXT NOT NULL,
            severity TEXT NOT NULL,
            target_id TEXT,
            entity_name TEXT,
            title TEXT NOT NULL,
            detail TEXT NOT NULL DEFAULT '',
            recommended_action TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_maintenance_run_items_run
            ON maintenance_run_items(run_id);
        CREATE INDEX IF NOT EXISTS idx_maintenance_run_items_kind
            ON maintenance_run_items(kind, severity);
        """
    )


def _migrate_v6_to_v7(conn: sqlite3.Connection) -> None:
    """Add scope metadata and persisted job queue tables."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS memory_scopes (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL
                CHECK(kind IN ('global','workspace','project','channel','task','agent')),
            name TEXT NOT NULL,
            path TEXT NOT NULL,
            parent_scope_id TEXT REFERENCES memory_scopes(id) ON DELETE SET NULL,
            status TEXT NOT NULL DEFAULT 'active'
                CHECK(status IN ('active','archived')),
            metadata TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_memory_scopes_kind_path
            ON memory_scopes(kind, path);
        CREATE INDEX IF NOT EXISTS idx_memory_scopes_parent
            ON memory_scopes(parent_scope_id);

        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            job_type TEXT NOT NULL,
            status TEXT NOT NULL
                CHECK(status IN ('queued','running','completed','failed','dead_letter')),
            payload TEXT NOT NULL DEFAULT '{}',
            attempts INTEGER NOT NULL DEFAULT 0,
            max_attempts INTEGER NOT NULL DEFAULT 3,
            available_at TEXT NOT NULL,
            leased_at TEXT,
            lease_owner TEXT,
            last_error TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            completed_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_status_available
            ON jobs(status, available_at);
        CREATE INDEX IF NOT EXISTS idx_jobs_type_status
            ON jobs(job_type, status, available_at);
        """
    )
    for table in (
        "facts",
        "notes",
        "sessions",
        "debug_sessions",
        "debug_hypotheses",
        "debug_evidence",
    ):
        if _table_exists(conn, table) and not _column_exists(conn, table, "scope_id"):
            conn.execute(f"ALTER TABLE {table} ADD COLUMN scope_id TEXT")
    index_specs = [
        ("idx_facts_scope", "facts", "scope_id, created_at DESC"),
        ("idx_notes_scope", "notes", "scope_id, created_at DESC"),
        ("idx_sessions_scope", "sessions", "scope_id, started_at DESC"),
        ("idx_debug_sessions_scope", "debug_sessions", "scope_id, started_at DESC"),
        ("idx_debug_hypotheses_scope", "debug_hypotheses", "scope_id, created_at DESC"),
        ("idx_debug_evidence_scope", "debug_evidence", "scope_id, created_at DESC"),
    ]
    for idx_name, table, columns in index_specs:
        if _table_exists(conn, table):
            conn.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {table}({columns})")


def _migrate_v7_to_v8(conn: sqlite3.Connection) -> None:
    """Add freshness metadata and persisted verification backlog."""
    freshness_columns = (
        ("facts", "verification_status", "TEXT NOT NULL DEFAULT 'unknown'"),
        ("facts", "last_verified_at", "TEXT"),
        ("facts", "verification_due_at", "TEXT"),
        ("decisions", "verification_status", "TEXT NOT NULL DEFAULT 'unknown'"),
        ("decisions", "last_verified_at", "TEXT"),
        ("decisions", "verification_due_at", "TEXT"),
    )
    for table, column, ddl in freshness_columns:
        if _table_exists(conn, table) and not _column_exists(conn, table, column):
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS verification_requests (
            id TEXT PRIMARY KEY,
            target_kind TEXT NOT NULL
                CHECK(target_kind IN ('fact','decision')),
            target_id TEXT NOT NULL,
            entity_id TEXT,
            scope_id TEXT,
            reason TEXT NOT NULL,
            status TEXT NOT NULL
                CHECK(status IN ('open','resolved','cancelled')),
            requested_by TEXT NOT NULL,
            resolution TEXT
                CHECK(resolution IS NULL OR resolution IN ('verified','stale','retracted','superseded')),
            detail TEXT NOT NULL DEFAULT '',
            requested_at TEXT NOT NULL,
            resolved_at TEXT,
            metadata TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_verification_requests_status
            ON verification_requests(status, requested_at DESC);
        CREATE INDEX IF NOT EXISTS idx_verification_requests_target
            ON verification_requests(target_kind, target_id, status);
        """
    )


def _migrate_v8_to_v9(conn: sqlite3.Connection) -> None:
    """Add persisted entity governance candidate backlog."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS governance_candidates (
            id TEXT PRIMARY KEY,
            candidate_type TEXT NOT NULL
                CHECK(candidate_type IN ('merge','alias')),
            status TEXT NOT NULL
                CHECK(status IN ('open','approved','rejected','applied','cancelled')),
            entity_id TEXT NOT NULL,
            related_entity_id TEXT,
            proposed_alias TEXT,
            score REAL NOT NULL DEFAULT 0.0,
            fingerprint TEXT NOT NULL,
            rationale TEXT NOT NULL DEFAULT '',
            details TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            resolved_at TEXT,
            resolved_by TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_governance_candidates_fingerprint
            ON governance_candidates(fingerprint);
        CREATE INDEX IF NOT EXISTS idx_governance_candidates_status
            ON governance_candidates(status, updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_governance_candidates_entity
            ON governance_candidates(entity_id, status, updated_at DESC);
        """
    )


def _migrate_v9_to_v10(conn: sqlite3.Connection) -> None:
    """Add persisted retention policies."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS retention_policies (
            id TEXT PRIMARY KEY,
            target_kind TEXT NOT NULL
                CHECK(target_kind IN ('entity','fact','decision','note','session')),
            target_id TEXT NOT NULL,
            policy_type TEXT NOT NULL
                CHECK(policy_type IN ('pin','ttl','archive_only','never_summarize')),
            value TEXT,
            reason TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_retention_policies_target_type
            ON retention_policies(target_kind, target_id, policy_type);
        CREATE INDEX IF NOT EXISTS idx_retention_policies_target
            ON retention_policies(target_kind, target_id);
        """
    )


def _migrate_v10_to_v11(conn: sqlite3.Connection) -> None:
    """Expand governance candidate support to include split review rows."""
    if not _table_exists(conn, "governance_candidates"):
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS governance_candidates (
                id TEXT PRIMARY KEY,
                candidate_type TEXT NOT NULL
                    CHECK(candidate_type IN ('merge','alias','split')),
                status TEXT NOT NULL
                    CHECK(status IN ('open','approved','rejected','applied','cancelled')),
                entity_id TEXT NOT NULL,
                related_entity_id TEXT,
                proposed_alias TEXT,
                score REAL NOT NULL DEFAULT 0.0,
                fingerprint TEXT NOT NULL,
                rationale TEXT NOT NULL DEFAULT '',
                details TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                resolved_at TEXT,
                resolved_by TEXT
            );
            CREATE UNIQUE INDEX IF NOT EXISTS uq_governance_candidates_fingerprint
                ON governance_candidates(fingerprint);
            CREATE INDEX IF NOT EXISTS idx_governance_candidates_status
                ON governance_candidates(status, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_governance_candidates_entity
                ON governance_candidates(entity_id, status, updated_at DESC);
            """
        )
        return

    conn.executescript(
        """
        ALTER TABLE governance_candidates RENAME TO governance_candidates_v10;
        CREATE TABLE governance_candidates (
            id TEXT PRIMARY KEY,
            candidate_type TEXT NOT NULL
                CHECK(candidate_type IN ('merge','alias','split')),
            status TEXT NOT NULL
                CHECK(status IN ('open','approved','rejected','applied','cancelled')),
            entity_id TEXT NOT NULL,
            related_entity_id TEXT,
            proposed_alias TEXT,
            score REAL NOT NULL DEFAULT 0.0,
            fingerprint TEXT NOT NULL,
            rationale TEXT NOT NULL DEFAULT '',
            details TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            resolved_at TEXT,
            resolved_by TEXT
        );
        INSERT INTO governance_candidates (
            id,
            candidate_type,
            status,
            entity_id,
            related_entity_id,
            proposed_alias,
            score,
            fingerprint,
            rationale,
            details,
            created_at,
            updated_at,
            resolved_at,
            resolved_by
        )
        SELECT
            id,
            candidate_type,
            status,
            entity_id,
            related_entity_id,
            proposed_alias,
            score,
            fingerprint,
            rationale,
            details,
            created_at,
            updated_at,
            resolved_at,
            resolved_by
        FROM governance_candidates_v10;
        DROP TABLE governance_candidates_v10;
        CREATE UNIQUE INDEX IF NOT EXISTS uq_governance_candidates_fingerprint
            ON governance_candidates(fingerprint);
        CREATE INDEX IF NOT EXISTS idx_governance_candidates_status
            ON governance_candidates(status, updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_governance_candidates_entity
            ON governance_candidates(entity_id, status, updated_at DESC);
        """
    )


def _migrate_v11_to_v12(conn: sqlite3.Connection) -> None:
    """Add structured applicability metadata to facts."""
    applicability_columns = (
        ("applies_if", "TEXT NOT NULL DEFAULT '[]'"),
        ("except_if", "TEXT NOT NULL DEFAULT '[]'"),
    )
    for column, ddl in applicability_columns:
        if _table_exists(conn, "facts") and not _column_exists(conn, "facts", column):
            conn.execute(f"ALTER TABLE facts ADD COLUMN {column} {ddl}")


def _migrate_v12_to_v13(conn: sqlite3.Connection) -> None:
    """Add explicit scope provenance to session events."""
    if _table_exists(conn, "session_events") and not _column_exists(conn, "session_events", "scope_id"):
        conn.execute("ALTER TABLE session_events ADD COLUMN scope_id TEXT")
    if _table_exists(conn, "session_events"):
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_session_events_session
            ON session_events(session_id, timestamp DESC, id DESC)
            """
        )


def migrate(conn: sqlite3.Connection) -> None:
    """Run any pending migrations."""
    version = get_schema_version(conn)
    if version >= CURRENT_VERSION:
        return
    if version < 2:
        _migrate_v1_to_v2(conn)
    if version < 3:
        _migrate_v2_to_v3(conn)
    if version < 4:
        _migrate_v3_to_v4(conn)
    if version < 5:
        _migrate_v4_to_v5(conn)
    if version < 6:
        _migrate_v5_to_v6(conn)
    if version < 7:
        _migrate_v6_to_v7(conn)
    if version < 8:
        _migrate_v7_to_v8(conn)
    if version < 9:
        _migrate_v8_to_v9(conn)
    if version < 10:
        _migrate_v9_to_v10(conn)
    if version < 11:
        _migrate_v10_to_v11(conn)
    if version < 12:
        _migrate_v11_to_v12(conn)
    if version < 13:
        _migrate_v12_to_v13(conn)
    conn.execute(
        "INSERT OR REPLACE INTO _meta (key, value) VALUES (?, ?)",
        ("schema_version", str(CURRENT_VERSION)),
    )
    conn.commit()
