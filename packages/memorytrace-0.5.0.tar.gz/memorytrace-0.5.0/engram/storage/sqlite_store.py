"""SQLite + FTS5 storage backend — the heart of Engram."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from engram.exceptions import EntityAlreadyExistsError, EntityNotFoundError, StorageError
from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact, FactApplicability, FactStatus
from engram.models.governance import (
    GovernanceCandidate,
    GovernanceCandidateStatus,
    GovernanceCandidateType,
)
from engram.models.maintenance import MaintenanceRun, MaintenanceRunItem
from engram.models.memory_type import MemoryType
from engram.models.reference import ReferenceEdge
from engram.models.relation import Relation
from engram.models.job import JobRecord
from engram.models.retention import RetentionPolicy, RetentionPolicyType, RetentionTargetKind
from engram.models.scope import MemoryScope
from engram.models.session import Session, SessionEvent
from engram.models.source import Source, SourceType
from engram.models.verification import (
    VerificationRequest,
    VerificationRequestStatus,
    VerificationResolution,
    VerificationStatus,
)

SCHEMA_VERSION = "1"

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS _meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    entity_type TEXT NOT NULL DEFAULT 'person',
    tier TEXT NOT NULL DEFAULT 'recall' CHECK(tier IN ('core','recall','archival')),
    summary TEXT DEFAULT '',
    aliases TEXT DEFAULT '[]',
    state TEXT DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    access_count INTEGER DEFAULT 0,
    last_accessed TEXT
);

CREATE TABLE IF NOT EXISTS facts (
    id TEXT PRIMARY KEY,
    entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    subject TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object TEXT NOT NULL,
    raw_text TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_author TEXT DEFAULT '',
    source_channel TEXT DEFAULT '',
    source_timestamp TEXT,
    source_url TEXT,
    source_session_id TEXT,
    source_confidence REAL DEFAULT 1.0,
    scope_id TEXT,
    confidence REAL NOT NULL DEFAULT 0.5,
    status TEXT NOT NULL DEFAULT 'unverified',
    verification_status TEXT NOT NULL DEFAULT 'unknown',
    last_verified_at TEXT,
    verification_due_at TEXT,
    memory_type TEXT NOT NULL DEFAULT 'episodic',
    valid_from TEXT,
    valid_to TEXT,
    applies_if TEXT NOT NULL DEFAULT '[]',
    except_if TEXT NOT NULL DEFAULT '[]',
    superseded_by TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relations (
    id TEXT PRIMARY KEY,
    from_entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    to_entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    relation_type TEXT NOT NULL,
    metadata TEXT DEFAULT '{}',
    valid_from TEXT,
    valid_to TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    parent_session_id TEXT,
    entities_accessed TEXT DEFAULT '[]',
    entities_modified TEXT DEFAULT '[]',
    facts_added TEXT DEFAULT '[]',
    summary TEXT,
    metadata TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS session_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(session_id),
    event_type TEXT NOT NULL,
    target TEXT,
    scope_id TEXT,
    detail TEXT DEFAULT '{}',
    timestamp TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS conflicts (
    id TEXT PRIMARY KEY,
    existing_fact_id TEXT,
    new_fact_id TEXT,
    conflict_type TEXT NOT NULL,
    suggested_resolution TEXT,
    created_at TEXT NOT NULL DEFAULT '',
    resolved_at TEXT,
    resolved_by TEXT,
    resolution TEXT
);

CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name);
CREATE INDEX IF NOT EXISTS idx_entities_tier ON entities(tier);
CREATE INDEX IF NOT EXISTS idx_facts_entity ON facts(entity_id);
CREATE INDEX IF NOT EXISTS idx_facts_status ON facts(status);
CREATE INDEX IF NOT EXISTS idx_facts_predicate ON facts(entity_id, predicate);
CREATE INDEX IF NOT EXISTS idx_conflicts_existing_pending
    ON conflicts(existing_fact_id, resolved_at);
CREATE INDEX IF NOT EXISTS idx_conflicts_new_pending
    ON conflicts(new_fact_id, resolved_at);
CREATE INDEX IF NOT EXISTS idx_relations_from ON relations(from_entity_id);
CREATE INDEX IF NOT EXISTS idx_relations_to ON relations(to_entity_id);
CREATE INDEX IF NOT EXISTS idx_sessions_agent ON sessions(agent_id, started_at);
CREATE INDEX IF NOT EXISTS idx_session_events_session
    ON session_events(session_id, timestamp DESC, id DESC);

CREATE TABLE IF NOT EXISTS snapshots (
    id TEXT PRIMARY KEY,
    label TEXT,
    description TEXT,
    created_at TEXT NOT NULL,
    schema_version TEXT NOT NULL DEFAULT '',
    entity_count INTEGER NOT NULL DEFAULT 0,
    fact_count INTEGER NOT NULL DEFAULT 0,
    note_count INTEGER NOT NULL DEFAULT 0,
    file_path TEXT NOT NULL,
    compressed_size INTEGER NOT NULL DEFAULT 0,
    uncompressed_size INTEGER NOT NULL DEFAULT 0,
    metadata TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_snapshots_created
    ON snapshots(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_snapshots_label
    ON snapshots(label);

CREATE TABLE IF NOT EXISTS debug_sessions (
    id TEXT PRIMARY KEY,
    bug_description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK(status IN ('open','resolved','abandoned')),
    conclusion TEXT,
    related_session_id TEXT,
    started_at TEXT NOT NULL,
    closed_at TEXT,
    metadata TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS debug_hypotheses (
    id TEXT PRIMARY KEY,
    debug_session_id TEXT NOT NULL
        REFERENCES debug_sessions(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK(status IN ('open','confirmed','rejected','abandoned')),
    rejection_reason TEXT,
    confidence REAL DEFAULT 0.5,
    created_at TEXT NOT NULL,
    closed_at TEXT
);

CREATE TABLE IF NOT EXISTS debug_evidence (
    id TEXT PRIMARY KEY,
    hypothesis_id TEXT NOT NULL
        REFERENCES debug_hypotheses(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    result TEXT NOT NULL
        CHECK(result IN ('supports','contradicts','neutral')),
    kind TEXT NOT NULL DEFAULT 'observation',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_debug_sessions_status
    ON debug_sessions(status, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_debug_hypotheses_session
    ON debug_hypotheses(debug_session_id);
CREATE INDEX IF NOT EXISTS idx_debug_evidence_hypothesis
    ON debug_evidence(hypothesis_id);

CREATE TABLE IF NOT EXISTS staging_batches (
    id TEXT PRIMARY KEY,
    raw_text TEXT NOT NULL,
    source_type TEXT NOT NULL DEFAULT 'user_input',
    source_author TEXT DEFAULT '',
    source_channel TEXT DEFAULT '',
    session_id TEXT,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending','applied','rejected','mixed')),
    metadata TEXT DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS staging_candidates (
    id TEXT PRIMARY KEY,
    batch_id TEXT NOT NULL REFERENCES staging_batches(id) ON DELETE CASCADE,
    candidate_type TEXT NOT NULL
        CHECK(candidate_type IN ('entity','fact','relation')),
    payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending','applied','rejected','skipped')),
    applied_target_id TEXT,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_staging_batches_status
    ON staging_batches(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_staging_candidates_batch
    ON staging_candidates(batch_id);
CREATE INDEX IF NOT EXISTS idx_staging_candidates_status
    ON staging_candidates(status);

CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    source_type TEXT DEFAULT 'user_input',
    session_id TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_created ON notes(created_at);

CREATE TABLE IF NOT EXISTS reference_edges (
    id TEXT PRIMARY KEY,
    entity_id TEXT NOT NULL,
    source_kind TEXT NOT NULL,
    source_id TEXT NOT NULL,
    snippet TEXT NOT NULL DEFAULT '',
    matched_text TEXT NOT NULL DEFAULT '',
    match_start INTEGER NOT NULL,
    match_end INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    indexed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reference_edges_entity
    ON reference_edges(entity_id, indexed_at DESC);
CREATE INDEX IF NOT EXISTS idx_reference_edges_source
    ON reference_edges(source_kind, source_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_reference_edges_source_span
    ON reference_edges(entity_id, source_kind, source_id, match_start, match_end);

CREATE TABLE IF NOT EXISTS decisions (
    id TEXT PRIMARY KEY,
    fingerprint TEXT NOT NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('active','superseded','draft')),
    confidence REAL NOT NULL,
    source_kind TEXT NOT NULL,
    source_id TEXT NOT NULL,
    entity_id TEXT,
    session_id TEXT,
    created_at TEXT NOT NULL,
    indexed_at TEXT NOT NULL,
    superseded_by TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_decisions_fingerprint
    ON decisions(fingerprint);
CREATE INDEX IF NOT EXISTS idx_decisions_source
    ON decisions(source_kind, source_id);
CREATE INDEX IF NOT EXISTS idx_decisions_status
    ON decisions(status, indexed_at DESC);
CREATE INDEX IF NOT EXISTS idx_decisions_entity
    ON decisions(entity_id, indexed_at DESC);

CREATE TABLE IF NOT EXISTS maintenance_runs (
    id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    completed_at TEXT NOT NULL,
    grade TEXT NOT NULL,
    score_value REAL NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    metadata TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_maintenance_runs_completed
    ON maintenance_runs(completed_at DESC);

CREATE TABLE IF NOT EXISTS maintenance_run_items (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES maintenance_runs(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    severity TEXT NOT NULL,
    target_id TEXT,
    entity_name TEXT,
    title TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '',
    recommended_action TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_maintenance_run_items_run
    ON maintenance_run_items(run_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_run_items_kind
    ON maintenance_run_items(kind, severity);

CREATE TABLE IF NOT EXISTS governance_candidates (
    id TEXT PRIMARY KEY,
    candidate_type TEXT NOT NULL
        CHECK(candidate_type IN ('merge','alias','split')),
    status TEXT NOT NULL
        CHECK(status IN ('open','approved','rejected','applied','cancelled')),
    entity_id TEXT NOT NULL,
    related_entity_id TEXT,
    proposed_alias TEXT,
    score REAL NOT NULL DEFAULT 0.0,
    fingerprint TEXT NOT NULL,
    rationale TEXT NOT NULL DEFAULT '',
    details TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    resolved_at TEXT,
    resolved_by TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_governance_candidates_fingerprint
    ON governance_candidates(fingerprint);
CREATE INDEX IF NOT EXISTS idx_governance_candidates_status
    ON governance_candidates(status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_governance_candidates_entity
    ON governance_candidates(entity_id, status, updated_at DESC);

CREATE TABLE IF NOT EXISTS retention_policies (
    id TEXT PRIMARY KEY,
    target_kind TEXT NOT NULL
        CHECK(target_kind IN ('entity','fact','decision','note','session')),
    target_id TEXT NOT NULL,
    policy_type TEXT NOT NULL
        CHECK(policy_type IN ('pin','ttl','archive_only','never_summarize')),
    value TEXT,
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_retention_policies_target_type
    ON retention_policies(target_kind, target_id, policy_type);
CREATE INDEX IF NOT EXISTS idx_retention_policies_target
    ON retention_policies(target_kind, target_id);
"""

_FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    entity_id,
    entity_name,
    entity_type,
    fact_text,
    state_text,
    summary,
    tokenize='unicode61 remove_diacritics 2'
);
CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(
    note_id,
    text,
    tokenize='unicode61 remove_diacritics 2'
);
"""


def _dt_to_str(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _str_to_dt(s: Optional[str]) -> Optional[datetime]:
    return datetime.fromisoformat(s) if s else None


class SQLiteStorage:
    """SQLite + FTS5 storage backend with WAL mode and atomic writes."""

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path).resolve()
        self._local = threading.local()

    @property
    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = self._create_connection()
        return self._local.conn

    def _create_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.row_factory = sqlite3.Row
        return conn

    def initialize(self) -> None:
        """Create tables and FTS index if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        is_new = not self.db_path.exists()
        conn = self._conn
        conn.executescript(_SCHEMA_SQL)
        conn.executescript(_FTS_SQL)
        # Set schema version if not exists
        conn.execute(
            "INSERT OR IGNORE INTO _meta (key, value) VALUES (?, ?)",
            ("schema_version", SCHEMA_VERSION),
        )
        conn.commit()
        # Run pending schema migrations
        from engram.storage.migrations import migrate
        migrate(conn)
        # Restrict DB file permissions to owner only (0o600)
        if is_new and self.db_path.exists():
            try:
                os.chmod(self.db_path, 0o600)
            except OSError:
                pass  # Windows or restricted filesystem

    def close(self) -> None:
        if hasattr(self._local, "conn") and self._local.conn is not None:
            self._local.conn.close()
            self._local.conn = None

    # ── Entity CRUD ──

    def create_entity(self, entity: Entity) -> Entity:
        now = datetime.now()
        entity.created_at = now
        entity.updated_at = now
        try:
            self._conn.execute(
                """INSERT INTO entities
                   (id, name, entity_type, tier, summary, aliases, state, created_at, updated_at, access_count, last_accessed)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    entity.id, entity.name, entity.entity_type, entity.tier.value,
                    entity.summary, json.dumps(entity.aliases, ensure_ascii=False),
                    json.dumps(entity.state.to_dict(), ensure_ascii=False),
                    _dt_to_str(entity.created_at), _dt_to_str(entity.updated_at),
                    entity.access_count, _dt_to_str(entity.last_accessed),
                ),
            )
            # Add to FTS index
            self._index_entity(entity)
            self._conn.commit()
        except sqlite3.IntegrityError:
            self._conn.rollback()
            raise EntityAlreadyExistsError(f"Entity '{entity.name}' already exists")
        except Exception:
            self._conn.rollback()
            raise
        return entity

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        row = self._conn.execute(
            "SELECT * FROM entities WHERE id = ?", (entity_id,)
        ).fetchone()
        return self._row_to_entity(row) if row else None

    def get_entity_by_name(self, name: str) -> Optional[Entity]:
        # Primary name lookup
        row = self._conn.execute(
            "SELECT * FROM entities WHERE name = ? COLLATE NOCASE", (name,)
        ).fetchone()
        if row:
            return self._row_to_entity(row)
        # Alias lookup (search within JSON array)
        row = self._conn.execute(
            "SELECT * FROM entities WHERE aliases LIKE ? COLLATE NOCASE",
            (f'%"{name}"%',),
        ).fetchone()
        return self._row_to_entity(row) if row else None

    def update_entity(self, entity: Entity) -> Entity:
        entity.updated_at = datetime.now()
        try:
            self._conn.execute(
                """UPDATE entities SET
                   name=?, entity_type=?, tier=?, summary=?, aliases=?, state=?,
                   updated_at=?, access_count=?, last_accessed=?
                   WHERE id=?""",
                (
                    entity.name, entity.entity_type, entity.tier.value,
                    entity.summary, json.dumps(entity.aliases, ensure_ascii=False),
                    json.dumps(entity.state.to_dict(), ensure_ascii=False),
                    _dt_to_str(entity.updated_at), entity.access_count,
                    _dt_to_str(entity.last_accessed), entity.id,
                ),
            )
            self.reindex_entity(entity)
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise
        return entity

    def delete_entity(self, entity_id: str) -> bool:
        try:
            # Close out any pending conflicts whose facts belong to this
            # entity BEFORE the CASCADE deletes the facts. Otherwise
            # ``conflicts`` (no FK) keeps orphan rows pointing at fact IDs
            # that no longer exist, and ``get_pending_conflicts`` returns
            # them forever.
            now = datetime.now().isoformat()
            self._conn.execute(
                """UPDATE conflicts
                   SET resolution = 'entity_deleted',
                       resolved_at = ?,
                       resolved_by = 'auto_delete_entity'
                   WHERE resolved_at IS NULL
                     AND (
                       existing_fact_id IN (SELECT id FROM facts WHERE entity_id = ?)
                       OR new_fact_id IN (SELECT id FROM facts WHERE entity_id = ?)
                     )""",
                (now, entity_id, entity_id),
            )
            cursor = self._conn.execute("DELETE FROM entities WHERE id = ?", (entity_id,))
            self._conn.execute(
                "DELETE FROM memory_fts WHERE entity_id = ?", (entity_id,)
            )
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception:
            self._conn.rollback()
            raise

    def touch_entity(self, entity_id: str) -> None:
        """Increment access_count without triggering FTS reindex."""
        self._conn.execute(
            "UPDATE entities SET access_count = access_count + 1, last_accessed = ? WHERE id = ?",
            (datetime.now().isoformat(), entity_id),
        )
        self._conn.commit()

    def list_entities(
        self,
        tier: Optional[Tier] = None,
        entity_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Entity]:
        query = "SELECT * FROM entities WHERE 1=1"
        params: list = []
        if tier:
            query += " AND tier = ?"
            params.append(tier.value)
        if entity_type:
            query += " AND entity_type = ?"
            params.append(entity_type)
        query += " ORDER BY updated_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_entity(r) for r in rows]

    # ── Fact CRUD ──

    def add_fact(self, fact: Fact, reindex: bool = True) -> Fact:
        fact.created_at = datetime.now()
        try:
            self._conn.execute(
                """INSERT INTO facts
                   (id, entity_id, subject, predicate, object, raw_text,
                    source_type, source_author, source_channel, source_timestamp,
                    source_url, source_session_id, source_confidence,
                    scope_id, confidence, status, verification_status,
                    last_verified_at, verification_due_at, memory_type,
                    valid_from, valid_to, applies_if, except_if,
                    superseded_by, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    fact.id, fact.entity_id, fact.subject, fact.predicate, fact.object,
                    fact.raw_text, fact.source.type.value, fact.source.author,
                    fact.source.channel, _dt_to_str(fact.source.timestamp),
                    fact.source.url, fact.source.session_id,
                    fact.source.confidence, fact.scope_id, fact.confidence, fact.status.value,
                    fact.verification_status.value,
                    _dt_to_str(fact.last_verified_at),
                    _dt_to_str(fact.verification_due_at),
                    fact.memory_type.value,
                    _dt_to_str(fact.valid_from), _dt_to_str(fact.valid_to),
                    json.dumps(fact.applicability.applies_if, ensure_ascii=False),
                    json.dumps(fact.applicability.except_if, ensure_ascii=False),
                    fact.superseded_by, _dt_to_str(fact.created_at),
                ),
            )
        except sqlite3.IntegrityError as e:
            self._conn.rollback()
            raise StorageError(f"Failed to add fact: {e}") from e
        except Exception:
            self._conn.rollback()
            raise
        # Update FTS index with new fact text (skippable for batch operations)
        if reindex:
            try:
                entity = self.get_entity(fact.entity_id)
                if entity:
                    self.reindex_entity(entity)
            except Exception:
                self._conn.rollback()
                raise
        self._conn.commit()
        return fact

    def get_facts(
        self, entity_id: str, status: Optional[FactStatus] = None
    ) -> list[Fact]:
        if status:
            rows = self._conn.execute(
                "SELECT * FROM facts WHERE entity_id = ? AND status = ? ORDER BY created_at DESC",
                (entity_id, status.value),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM facts WHERE entity_id = ? ORDER BY created_at DESC",
                (entity_id,),
            ).fetchall()
        return [self._row_to_fact(r) for r in rows]

    def get_current_facts(self, entity_id: str) -> list[Fact]:
        rows = self._conn.execute(
            """SELECT * FROM facts
               WHERE entity_id = ? AND valid_to IS NULL AND superseded_by IS NULL
               AND status NOT IN ('expired', 'retracted')
               ORDER BY created_at DESC""",
            (entity_id,),
        ).fetchall()
        return [self._row_to_fact(r) for r in rows]

    def list_current_fact_scopes(
        self,
        entity_ids: list[str],
    ) -> dict[str, set[Optional[str]]]:
        unique_ids = [entity_id for entity_id in dict.fromkeys(entity_ids) if entity_id]
        if not unique_ids:
            return {}
        placeholders = ",".join("?" for _ in unique_ids)
        rows = self._conn.execute(
            f"""SELECT entity_id, scope_id FROM facts
                WHERE entity_id IN ({placeholders})
                  AND valid_to IS NULL
                  AND superseded_by IS NULL
                  AND status NOT IN ('expired', 'retracted')""",
            unique_ids,
        ).fetchall()
        scope_map: dict[str, set[Optional[str]]] = {}
        for row in rows:
            scope_map.setdefault(row["entity_id"], set()).add(row["scope_id"])
        return scope_map

    def update_fact(self, fact: Fact) -> Fact:
        # memory_type is only mutable through reclassify() — the ordinary
        # UPDATE path leaves it alone so we don't accidentally demote an
        # IDENTITY fact to EPISODIC when retracting it.
        self._conn.execute(
            """UPDATE facts SET
               subject=?, predicate=?, object=?, raw_text=?,
               confidence=?, status=?, verification_status=?,
               last_verified_at=?, verification_due_at=?, valid_from=?, valid_to=?,
               applies_if=?, except_if=?, superseded_by=?
               WHERE id=?""",
            (
                fact.subject, fact.predicate, fact.object, fact.raw_text,
                fact.confidence, fact.status.value,
                fact.verification_status.value,
                _dt_to_str(fact.last_verified_at),
                _dt_to_str(fact.verification_due_at),
                _dt_to_str(fact.valid_from), _dt_to_str(fact.valid_to),
                json.dumps(fact.applicability.applies_if, ensure_ascii=False),
                json.dumps(fact.applicability.except_if, ensure_ascii=False),
                fact.superseded_by, fact.id,
            ),
        )
        self._conn.commit()
        return fact

    # ── Relations ──

    def add_relation(self, relation: Relation) -> Relation:
        relation.created_at = datetime.now()
        self._conn.execute(
            """INSERT INTO relations
               (id, from_entity_id, to_entity_id, relation_type, metadata,
                valid_from, valid_to, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                relation.id, relation.from_entity_id, relation.to_entity_id,
                relation.relation_type,
                json.dumps(relation.metadata, ensure_ascii=False),
                _dt_to_str(relation.valid_from), _dt_to_str(relation.valid_to),
                _dt_to_str(relation.created_at),
            ),
        )
        self._conn.commit()
        return relation

    def get_relations(self, entity_id: str, direction: str = "both") -> list[Relation]:
        if direction == "outgoing":
            rows = self._conn.execute(
                "SELECT * FROM relations WHERE from_entity_id = ?", (entity_id,)
            ).fetchall()
        elif direction == "incoming":
            rows = self._conn.execute(
                "SELECT * FROM relations WHERE to_entity_id = ?", (entity_id,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM relations WHERE from_entity_id = ? OR to_entity_id = ?",
                (entity_id, entity_id),
            ).fetchall()
        return [self._row_to_relation(r) for r in rows]

    # ── Sessions ──

    def save_session(self, session: Session) -> None:
        self._conn.execute(
            """INSERT OR REPLACE INTO sessions
               (session_id, agent_id, started_at, ended_at, parent_session_id,
                scope_id, entities_accessed, entities_modified, facts_added, summary, metadata)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                session.session_id, session.agent_id,
                _dt_to_str(session.started_at), _dt_to_str(session.ended_at),
                session.parent_session_id,
                session.scope_id,
                json.dumps(session.entities_accessed),
                json.dumps(session.entities_modified),
                json.dumps(session.facts_added),
                session.summary,
                json.dumps(session.metadata, ensure_ascii=False),
            ),
        )
        self._conn.commit()

    def get_session(self, session_id: str) -> Optional[Session]:
        row = self._conn.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
        return self._row_to_session(row) if row else None

    def get_recent_sessions(self, agent_id: str, limit: int = 5) -> list[Session]:
        rows = self._conn.execute(
            "SELECT * FROM sessions WHERE agent_id = ? ORDER BY started_at DESC LIMIT ?",
            (agent_id, limit),
        ).fetchall()
        return [self._row_to_session(r) for r in rows]

    def add_session_event(self, event: SessionEvent) -> None:
        self._conn.execute(
            """INSERT INTO session_events (session_id, event_type, target, scope_id, detail, timestamp)
               VALUES (?,?,?,?,?,?)""",
            (
                event.session_id, event.event_type, event.target, event.scope_id,
                json.dumps(event.detail, ensure_ascii=False),
                _dt_to_str(event.timestamp),
            ),
        )
        self._conn.commit()

    # ── Conflicts ──

    def add_conflict(self, conflict: dict) -> None:
        # Validate required keys
        if "id" not in conflict or "conflict_type" not in conflict:
            raise StorageError("Conflict dict must contain 'id' and 'conflict_type' keys")
        self._conn.execute(
            """INSERT INTO conflicts
               (id, existing_fact_id, new_fact_id, conflict_type, suggested_resolution, created_at)
               VALUES (?,?,?,?,?,?)""",
            (
                conflict["id"], conflict.get("existing_fact_id"),
                conflict.get("new_fact_id"), conflict["conflict_type"],
                conflict.get("suggested_resolution"),
                _dt_to_str(datetime.now()),
            ),
        )
        self._conn.commit()

    def get_conflict(self, conflict_id: str) -> Optional[dict]:
        """Return a single conflict by ID, or None."""
        row = self._conn.execute(
            "SELECT * FROM conflicts WHERE id = ?", (conflict_id,)
        ).fetchone()
        return dict(row) if row else None

    def get_pending_conflicts(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM conflicts WHERE resolved_at IS NULL"
        ).fetchall()
        return [dict(r) for r in rows]

    def resolve_conflict(self, conflict_id: str, resolution: str, resolved_by: str) -> None:
        self._conn.execute(
            """UPDATE conflicts SET resolution=?, resolved_at=?, resolved_by=? WHERE id=?""",
            (resolution, _dt_to_str(datetime.now()), resolved_by, conflict_id),
        )
        self._conn.commit()

    # ── Fact bulk operations (used by merge/resolve) ──

    def transfer_facts(self, from_entity_id: str, to_entity_id: str, new_subject: str) -> None:
        """Reassign all facts from one entity to another."""
        self._conn.execute(
            "UPDATE facts SET entity_id = ?, subject = ? WHERE entity_id = ?",
            (to_entity_id, new_subject, from_entity_id),
        )

    def transfer_relations(self, from_entity_id: str, to_entity_id: str) -> None:
        """Reassign all relations referencing ``from_entity_id`` to ``to_entity_id``.

        Removes duplicates and self-referential relations that result from
        the reassignment.
        """
        # Remove duplicate outgoing relations
        self._conn.execute(
            """DELETE FROM relations WHERE id IN (
                SELECT s.id FROM relations s
                INNER JOIN relations p
                    ON p.from_entity_id = ?
                   AND p.to_entity_id = s.to_entity_id
                   AND p.relation_type = s.relation_type
                   AND p.valid_to IS NULL
                   AND s.valid_to IS NULL
                WHERE s.from_entity_id = ?
            )""",
            (to_entity_id, from_entity_id),
        )
        # Remove duplicate incoming relations
        self._conn.execute(
            """DELETE FROM relations WHERE id IN (
                SELECT s.id FROM relations s
                INNER JOIN relations p
                    ON p.to_entity_id = ?
                   AND p.from_entity_id = s.from_entity_id
                   AND p.relation_type = s.relation_type
                   AND p.valid_to IS NULL
                   AND s.valid_to IS NULL
                WHERE s.to_entity_id = ?
            )""",
            (to_entity_id, from_entity_id),
        )
        # Transfer remaining
        self._conn.execute(
            "UPDATE relations SET from_entity_id = ? WHERE from_entity_id = ?",
            (to_entity_id, from_entity_id),
        )
        self._conn.execute(
            "UPDATE relations SET to_entity_id = ? WHERE to_entity_id = ?",
            (to_entity_id, from_entity_id),
        )
        # Clean up self-referential relations
        self._conn.execute(
            "DELETE FROM relations WHERE from_entity_id = ? AND to_entity_id = ?",
            (to_entity_id, to_entity_id),
        )

    def update_fact_status(self, fact_id: str, status: str, superseded_by: Optional[str] = None) -> None:
        """Update a fact's status (and optionally superseded_by) by ID."""
        if superseded_by is not None:
            self._conn.execute(
                "UPDATE facts SET status = ?, superseded_by = ? WHERE id = ?",
                (status, superseded_by, fact_id),
            )
        else:
            self._conn.execute(
                "UPDATE facts SET status = ? WHERE id = ?",
                (status, fact_id),
            )

    def update_fact_status_if(self, fact_id: str, new_status: str, only_if_status: str) -> None:
        """Update status only if the fact currently has ``only_if_status``."""
        self._conn.execute(
            "UPDATE facts SET status = ? WHERE id = ? AND status = ?",
            (new_status, fact_id, only_if_status),
        )

    def get_fact_entity_id(self, fact_id: str) -> Optional[str]:
        """Return the entity_id for a fact, or None if not found."""
        row = self._conn.execute(
            "SELECT entity_id FROM facts WHERE id = ?", (fact_id,)
        ).fetchone()
        return row["entity_id"] if row else None

    def get_fact(self, fact_id: str) -> Optional[Fact]:
        row = self._conn.execute(
            "SELECT * FROM facts WHERE id = ?",
            (fact_id,),
        ).fetchone()
        return self._row_to_fact(row) if row else None

    def commit(self) -> None:
        """Explicit commit for multi-step operations."""
        self._conn.commit()

    def get_all_facts_for_reclassify(
        self, entity_id: Optional[str] = None
    ) -> list[dict]:
        """Return minimal fact data for memory-type reclassification."""
        query = "SELECT id, predicate, raw_text, memory_type FROM facts WHERE 1=1"
        params: list = []
        if entity_id is not None:
            query += " AND entity_id = ?"
            params.append(entity_id)
        rows = self._conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def update_fact_memory_type(self, fact_id: str, memory_type: str) -> None:
        """Update only the memory_type column for a fact."""
        self._conn.execute(
            "UPDATE facts SET memory_type = ? WHERE id = ?",
            (memory_type, fact_id),
        )

    def update_fact_freshness(
        self,
        fact_id: str,
        *,
        verification_status: str,
        last_verified_at: Optional[str] = None,
        verification_due_at: Optional[str] = None,
    ) -> None:
        self._conn.execute(
            """UPDATE facts
               SET verification_status = ?,
                   last_verified_at = ?,
                   verification_due_at = ?
               WHERE id = ?""",
            (
                verification_status,
                last_verified_at,
                verification_due_at,
                fact_id,
            ),
        )
        self._conn.commit()

    # ── Notes ──

    @staticmethod
    def _note_text_hash(text: str) -> str:
        """Compute a short hash for deduplication (index-friendly)."""
        import hashlib
        normalized = text.strip().lower()
        return hashlib.sha256(normalized.encode("utf-8", errors="replace")).hexdigest()[:16]

    def add_note(
        self,
        note_id: str,
        text: str,
        source_type: str = "user_input",
        session_id: Optional[str] = None,
        scope_id: Optional[str] = None,
        deduplicate: bool = True,
    ) -> tuple[str, bool]:
        """Store a raw text note and index it for search. Returns (note_id, is_new)."""
        if not text or not text.strip():
            return note_id, False
        if len(text) > 100_000:
            text = text[:100_000]
        text_hash = self._note_text_hash(text)
        if deduplicate:
            existing = self._find_duplicate_note(text, text_hash)
            if existing:
                return existing["id"], False
        now = datetime.now().isoformat()
        try:
            self._conn.execute(
                "INSERT INTO notes (id, text, source_type, session_id, scope_id, created_at, text_hash) VALUES (?,?,?,?,?,?,?)",
                (note_id, text, source_type, session_id, scope_id, now, text_hash),
            )
            self._conn.execute(
                "INSERT INTO notes_fts (note_id, text) VALUES (?,?)",
                (note_id, text),
            )
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise
        return note_id, True

    def _find_duplicate_note(self, text: str, text_hash: Optional[str] = None) -> Optional[dict]:
        """Find an existing note with identical text using the indexed hash.

        Falls back to a full-text comparison when the hash column hasn't been
        backfilled yet (pre-v5 databases).
        """
        if text_hash is None:
            text_hash = self._note_text_hash(text)
        row = self._conn.execute(
            "SELECT * FROM notes WHERE text_hash = ? LIMIT 1",
            (text_hash,),
        ).fetchone()
        if row is not None:
            # Hash match — verify full text to rule out collisions.
            if row["text"].strip().lower() == text.strip().lower():
                return dict(row)
        return None

    def _delete_notes_by_ids(self, ids: list[str]) -> int:
        """Delete notes and their FTS entries by IDs. Returns actual count deleted."""
        if not ids:
            return 0
        try:
            placeholders = ",".join("?" for _ in ids)
            self._conn.execute(
                f"DELETE FROM notes_fts WHERE note_id IN ({placeholders})", ids
            )
            cursor = self._conn.execute(
                f"DELETE FROM notes WHERE id IN ({placeholders})", ids
            )
            deleted = cursor.rowcount
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise
        return deleted

    def delete_notes_by_keyword(self, keyword: str, limit: int = 10) -> list[dict]:
        """Find and delete notes matching keyword. Returns deleted notes."""
        matches = self.search_notes(keyword, limit=limit)
        if not matches:
            matches = self.search_notes_like(keyword, limit=limit)
        if not matches:
            return []
        self._delete_notes_by_ids([n["id"] for n in matches])
        return matches

    def count_old_notes(self, before_date: str) -> int:
        """Count notes older than before_date without loading text."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM notes WHERE created_at < ?", (before_date,)
        ).fetchone()
        return row[0] if row else 0

    def delete_old_notes(self, before_date: str) -> int:
        """Delete notes older than before_date (ISO format). Returns count."""
        rows = self._conn.execute(
            "SELECT id FROM notes WHERE created_at < ?", (before_date,)
        ).fetchall()
        if not rows:
            return 0
        return self._delete_notes_by_ids([r["id"] for r in rows])

    def search_notes(self, query: str, limit: int = 10) -> list[dict]:
        """Search raw notes using FTS5."""
        from engram.search.tokenizer import build_fts5_query
        fts_query = build_fts5_query(query)
        if not fts_query or fts_query == '""':
            return []
        try:
            rows = self._conn.execute(
                """SELECT n.*, bm25(notes_fts) AS rank
                   FROM notes_fts nf
                   JOIN notes n ON n.id = nf.note_id
                   WHERE notes_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (fts_query, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.OperationalError:
            return []

    def search_notes_like(self, query: str, limit: int = 10) -> list[dict]:
        """Fallback LIKE search on notes when FTS fails."""
        escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        rows = self._conn.execute(
            "SELECT * FROM notes WHERE text LIKE ? ESCAPE '\\' ORDER BY created_at DESC LIMIT ?",
            (f"%{escaped}%", limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_recent_notes(self, limit: int = 20) -> list[dict]:
        """Get most recent notes chronologically."""
        rows = self._conn.execute(
            "SELECT * FROM notes ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_note(self, note_id: str) -> Optional[dict]:
        row = self._conn.execute(
            "SELECT * FROM notes WHERE id = ?",
            (note_id,),
        ).fetchone()
        return dict(row) if row else None

    # Projection tables

    def replace_reference_edges(
        self,
        source_kind: str,
        source_id: str,
        edges: list[ReferenceEdge],
    ) -> None:
        self._conn.execute(
            "DELETE FROM reference_edges WHERE source_kind = ? AND source_id = ?",
            (source_kind, source_id),
        )
        for edge in edges:
            self._conn.execute(
                """INSERT INTO reference_edges
                   (id, entity_id, source_kind, source_id, snippet, matched_text,
                    match_start, match_end, created_at, indexed_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    edge.id,
                    edge.entity_id,
                    edge.source_kind,
                    edge.source_id,
                    edge.snippet,
                    edge.matched_text,
                    edge.match_start,
                    edge.match_end,
                    _dt_to_str(edge.created_at),
                    _dt_to_str(edge.indexed_at),
                ),
            )
        self._conn.commit()

    def list_reference_edges(
        self,
        entity_id: str,
        source_kind: Optional[str] = None,
        limit: int = 50,
    ) -> list[ReferenceEdge]:
        sql = (
            "SELECT * FROM reference_edges WHERE entity_id = ?"
        )
        params: list = [entity_id]
        if source_kind:
            sql += " AND source_kind = ?"
            params.append(source_kind)
        sql += " ORDER BY indexed_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_reference_edge(row) for row in rows]

    def count_reference_edges_for_source(self, source_kind: str, source_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM reference_edges WHERE source_kind = ? AND source_id = ?",
            (source_kind, source_id),
        ).fetchone()
        return row[0] if row else 0

    def replace_decisions(
        self,
        source_kind: str,
        source_id: str,
        decisions: list[DecisionRecord],
    ) -> None:
        self._conn.execute(
            "DELETE FROM decisions WHERE source_kind = ? AND source_id = ?",
            (source_kind, source_id),
        )
        for decision in decisions:
            self._conn.execute(
                """INSERT INTO decisions
                   (id, fingerprint, title, summary, status, confidence,
                   source_kind, source_id, entity_id, session_id,
                    verification_status, last_verified_at, verification_due_at,
                    created_at, indexed_at, superseded_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    decision.id,
                    decision.fingerprint,
                    decision.title,
                    decision.summary,
                    decision.status.value,
                    decision.confidence,
                    decision.source_kind,
                    decision.source_id,
                    decision.entity_id,
                    decision.session_id,
                    decision.verification_status.value,
                    _dt_to_str(decision.last_verified_at),
                    _dt_to_str(decision.verification_due_at),
                    _dt_to_str(decision.created_at),
                    _dt_to_str(decision.indexed_at),
                    decision.superseded_by,
                ),
            )
        self._conn.commit()

    def list_decisions(
        self,
        entity_id: Optional[str] = None,
        status: Optional[DecisionStatus] = None,
        limit: int = 20,
    ) -> list[DecisionRecord]:
        sql = "SELECT * FROM decisions WHERE 1=1"
        params: list = []
        if entity_id is not None:
            sql += " AND entity_id = ?"
            params.append(entity_id)
        if status is not None:
            sql += " AND status = ?"
            params.append(status.value)
        sql += " ORDER BY indexed_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_decision(row) for row in rows]

    def get_decision(self, decision_id: str) -> Optional[DecisionRecord]:
        row = self._conn.execute(
            "SELECT * FROM decisions WHERE id = ?",
            (decision_id,),
        ).fetchone()
        return self._row_to_decision(row) if row else None

    def transfer_reference_edges(self, from_entity_id: str, to_entity_id: str) -> None:
        self._conn.execute(
            "UPDATE reference_edges SET entity_id = ? WHERE entity_id = ?",
            (to_entity_id, from_entity_id),
        )

    def transfer_decisions(self, from_entity_id: str, to_entity_id: str) -> None:
        self._conn.execute(
            "UPDATE decisions SET entity_id = ? WHERE entity_id = ?",
            (to_entity_id, from_entity_id),
        )

    def upsert_governance_candidate(self, candidate: GovernanceCandidate) -> GovernanceCandidate:
        candidate.updated_at = datetime.now()
        self._conn.execute(
            """
            INSERT INTO governance_candidates (
                id, candidate_type, status, entity_id, related_entity_id,
                proposed_alias, score, fingerprint, rationale, details,
                created_at, updated_at, resolved_at, resolved_by
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(fingerprint) DO UPDATE SET
                score = excluded.score,
                rationale = excluded.rationale,
                details = excluded.details,
                updated_at = excluded.updated_at
            """,
            (
                candidate.id,
                candidate.candidate_type.value,
                candidate.status.value,
                candidate.entity_id,
                candidate.related_entity_id,
                candidate.proposed_alias,
                candidate.score,
                candidate.fingerprint,
                candidate.rationale,
                json.dumps(candidate.details, ensure_ascii=False),
                _dt_to_str(candidate.created_at),
                _dt_to_str(candidate.updated_at),
                _dt_to_str(candidate.resolved_at),
                candidate.resolved_by,
            ),
        )
        self._conn.commit()
        row = self._conn.execute(
            "SELECT * FROM governance_candidates WHERE fingerprint = ?",
            (candidate.fingerprint,),
        ).fetchone()
        return self._row_to_governance_candidate(row)

    def list_governance_candidates(
        self,
        *,
        status: GovernanceCandidateStatus | None = None,
        candidate_type: GovernanceCandidateType | None = None,
        limit: int = 50,
    ) -> list[GovernanceCandidate]:
        query = "SELECT * FROM governance_candidates WHERE 1=1"
        params: list[object] = []
        if status is not None:
            query += " AND status = ?"
            params.append(status.value)
        if candidate_type is not None:
            query += " AND candidate_type = ?"
            params.append(candidate_type.value)
        query += " ORDER BY score DESC, updated_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_governance_candidate(row) for row in rows]

    def get_governance_candidate(self, candidate_id: str) -> Optional[GovernanceCandidate]:
        row = self._conn.execute(
            "SELECT * FROM governance_candidates WHERE id = ?",
            (candidate_id,),
        ).fetchone()
        return self._row_to_governance_candidate(row) if row else None

    def resolve_governance_candidate(
        self,
        candidate_id: str,
        *,
        status: GovernanceCandidateStatus,
        resolved_by: str,
    ) -> GovernanceCandidate:
        now = datetime.now()
        self._conn.execute(
            """
            UPDATE governance_candidates
               SET status = ?,
                   updated_at = ?,
                   resolved_at = ?,
                   resolved_by = ?
             WHERE id = ?
            """,
            (
                status.value,
                _dt_to_str(now),
                _dt_to_str(now),
                resolved_by,
                candidate_id,
            ),
        )
        self._conn.commit()
        row = self._conn.execute(
            "SELECT * FROM governance_candidates WHERE id = ?",
            (candidate_id,),
        ).fetchone()
        return self._row_to_governance_candidate(row)

    def count_governance_candidates(
        self,
        *,
        status: GovernanceCandidateStatus | None = None,
    ) -> int:
        if status is None:
            row = self._conn.execute("SELECT COUNT(*) FROM governance_candidates").fetchone()
        else:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM governance_candidates WHERE status = ?",
                (status.value,),
            ).fetchone()
        return int(row[0]) if row else 0

    def update_decision(self, decision: DecisionRecord) -> DecisionRecord:
        self._conn.execute(
            """UPDATE decisions
               SET title = ?, summary = ?, status = ?, confidence = ?,
                   entity_id = ?, session_id = ?, superseded_by = ?,
                   verification_status = ?, last_verified_at = ?, verification_due_at = ?
               WHERE id = ?""",
            (
                decision.title,
                decision.summary,
                decision.status.value,
                decision.confidence,
                decision.entity_id,
                decision.session_id,
                decision.superseded_by,
                decision.verification_status.value,
                _dt_to_str(decision.last_verified_at),
                _dt_to_str(decision.verification_due_at),
                decision.id,
            ),
        )
        self._conn.commit()
        return decision

    def update_decision_freshness(
        self,
        decision_id: str,
        *,
        verification_status: str,
        last_verified_at: Optional[str] = None,
        verification_due_at: Optional[str] = None,
    ) -> None:
        self._conn.execute(
            """UPDATE decisions
               SET verification_status = ?,
                   last_verified_at = ?,
                   verification_due_at = ?
               WHERE id = ?""",
            (
                verification_status,
                last_verified_at,
                verification_due_at,
                decision_id,
            ),
        )
        self._conn.commit()

    def count_decisions_for_source(self, source_kind: str, source_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM decisions WHERE source_kind = ? AND source_id = ?",
            (source_kind, source_id),
        ).fetchone()
        return row[0] if row else 0

    def create_verification_request(
        self,
        request: VerificationRequest,
    ) -> VerificationRequest:
        self._conn.execute(
            """INSERT INTO verification_requests
               (id, target_kind, target_id, entity_id, scope_id, reason,
                status, requested_by, resolution, detail, requested_at,
                resolved_at, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                request.id,
                request.target_kind,
                request.target_id,
                request.entity_id,
                request.scope_id,
                request.reason,
                request.status.value,
                request.requested_by,
                request.resolution.value if request.resolution is not None else None,
                request.detail,
                _dt_to_str(request.requested_at),
                _dt_to_str(request.resolved_at),
                json.dumps(request.metadata, ensure_ascii=False),
            ),
        )
        self._conn.commit()
        return request

    def find_open_verification_request(
        self,
        target_kind: str,
        target_id: str,
    ) -> Optional[VerificationRequest]:
        row = self._conn.execute(
            """SELECT * FROM verification_requests
               WHERE target_kind = ? AND target_id = ? AND status = 'open'
               ORDER BY requested_at DESC
               LIMIT 1""",
            (target_kind, target_id),
        ).fetchone()
        return self._row_to_verification_request(row) if row else None

    def get_verification_request(self, request_id: str) -> Optional[VerificationRequest]:
        row = self._conn.execute(
            "SELECT * FROM verification_requests WHERE id = ?",
            (request_id,),
        ).fetchone()
        return self._row_to_verification_request(row) if row else None

    def list_verification_requests(
        self,
        *,
        status: Optional[VerificationRequestStatus] = None,
        target_kind: Optional[str] = None,
        limit: int = 50,
    ) -> list[VerificationRequest]:
        sql = "SELECT * FROM verification_requests WHERE 1=1"
        params: list = []
        if status is not None:
            sql += " AND status = ?"
            params.append(status.value)
        if target_kind is not None:
            sql += " AND target_kind = ?"
            params.append(target_kind)
        sql += " ORDER BY requested_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_verification_request(row) for row in rows]

    def update_verification_request(
        self,
        request: VerificationRequest,
    ) -> VerificationRequest:
        self._conn.execute(
            """UPDATE verification_requests
               SET entity_id = ?, scope_id = ?, reason = ?, status = ?,
                   requested_by = ?, resolution = ?, detail = ?,
                   requested_at = ?, resolved_at = ?, metadata = ?
               WHERE id = ?""",
            (
                request.entity_id,
                request.scope_id,
                request.reason,
                request.status.value,
                request.requested_by,
                request.resolution.value if request.resolution is not None else None,
                request.detail,
                _dt_to_str(request.requested_at),
                _dt_to_str(request.resolved_at),
                json.dumps(request.metadata, ensure_ascii=False),
                request.id,
            ),
        )
        self._conn.commit()
        return request

    def save_maintenance_run(self, run: MaintenanceRun) -> MaintenanceRun:
        self._conn.execute(
            """INSERT INTO maintenance_runs
               (id, started_at, completed_at, grade, score_value, summary, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                run.id,
                _dt_to_str(run.started_at),
                _dt_to_str(run.completed_at),
                run.grade,
                run.score_value,
                run.summary,
                json.dumps(run.metadata, ensure_ascii=False),
            ),
        )
        for item in run.items:
            self._conn.execute(
                """INSERT INTO maintenance_run_items
                   (id, run_id, kind, severity, target_id, entity_name,
                    title, detail, recommended_action, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    item.id,
                    run.id,
                    item.kind,
                    item.severity,
                    item.target_id,
                    item.entity_name,
                    item.title,
                    item.detail,
                    item.recommended_action,
                    _dt_to_str(item.created_at),
                ),
            )
        self._conn.commit()
        return run

    def list_maintenance_runs(self, limit: int = 20) -> list[MaintenanceRun]:
        rows = self._conn.execute(
            "SELECT * FROM maintenance_runs ORDER BY completed_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._row_to_maintenance_run(row, include_items=False) for row in rows]

    def get_maintenance_run(self, run_id: str) -> Optional[MaintenanceRun]:
        row = self._conn.execute(
            "SELECT * FROM maintenance_runs WHERE id = ?",
            (run_id,),
        ).fetchone()
        return self._row_to_maintenance_run(row, include_items=True) if row else None

    def upsert_retention_policy(self, policy: RetentionPolicy) -> RetentionPolicy:
        existing = self.get_retention_policy(
            policy.target_kind.value,
            policy.target_id,
            policy.policy_type.value,
        )
        if existing is not None:
            policy.id = existing.id
            policy.created_at = existing.created_at
        policy.updated_at = datetime.now()
        self._conn.execute(
            """
            INSERT INTO retention_policies (
                id, target_kind, target_id, policy_type, value, reason, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(target_kind, target_id, policy_type) DO UPDATE SET
                value = excluded.value,
                reason = excluded.reason,
                updated_at = excluded.updated_at
            """,
            (
                policy.id,
                policy.target_kind.value,
                policy.target_id,
                policy.policy_type.value,
                policy.value,
                policy.reason,
                _dt_to_str(policy.created_at),
                _dt_to_str(policy.updated_at),
            ),
        )
        self._conn.commit()
        return policy

    def get_session_events(self, session_id: str, limit: int = 50) -> list[SessionEvent]:
        rows = self._conn.execute(
            """SELECT * FROM session_events
               WHERE session_id = ?
               ORDER BY timestamp DESC, id DESC
               LIMIT ?""",
            (session_id, limit),
        ).fetchall()
        return [self._row_to_session_event(row) for row in rows]

    def clear_retention_policy(self, target_kind: str, target_id: str, policy_type: str) -> bool:
        cursor = self._conn.execute(
            """
            DELETE FROM retention_policies
            WHERE target_kind = ? AND target_id = ? AND policy_type = ?
            """,
            (target_kind, target_id, policy_type),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def get_retention_policy(
        self,
        target_kind: str,
        target_id: str,
        policy_type: str,
    ) -> Optional[RetentionPolicy]:
        row = self._conn.execute(
            """
            SELECT * FROM retention_policies
            WHERE target_kind = ? AND target_id = ? AND policy_type = ?
            """,
            (target_kind, target_id, policy_type),
        ).fetchone()
        return self._row_to_retention_policy(row) if row else None

    def get_retention_policies_for_target(
        self,
        target_kind: str,
        target_id: str,
    ) -> list[RetentionPolicy]:
        rows = self._conn.execute(
            """
            SELECT * FROM retention_policies
            WHERE target_kind = ? AND target_id = ?
            ORDER BY updated_at DESC
            """,
            (target_kind, target_id),
        ).fetchall()
        return [self._row_to_retention_policy(row) for row in rows]

    def list_retention_policies(
        self,
        *,
        target_kind: Optional[str] = None,
        target_id: Optional[str] = None,
        policy_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[RetentionPolicy]:
        sql = "SELECT * FROM retention_policies WHERE 1=1"
        params: list[object] = []
        if target_kind is not None:
            sql += " AND target_kind = ?"
            params.append(target_kind)
        if target_id is not None:
            sql += " AND target_id = ?"
            params.append(target_id)
        if policy_type is not None:
            sql += " AND policy_type = ?"
            params.append(policy_type)
        sql += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_retention_policy(row) for row in rows]

    # ── Stats ──

    def entity_count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM entities").fetchone()
        return row[0] if row else 0

    def fact_count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM facts").fetchone()
        return row[0] if row else 0

    def note_count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM notes").fetchone()
        return row[0] if row else 0

    # Scope and jobs

    def create_scope(self, scope: MemoryScope) -> MemoryScope:
        self._conn.execute(
            """INSERT INTO memory_scopes
               (id, kind, name, path, parent_scope_id, status, metadata, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                scope.id,
                scope.kind,
                scope.name,
                scope.path,
                scope.parent_scope_id,
                scope.status,
                json.dumps(scope.metadata, ensure_ascii=False),
                _dt_to_str(scope.created_at),
                _dt_to_str(scope.updated_at),
            ),
        )
        self._conn.commit()
        return scope

    def find_scope_by_kind_path(self, kind: str, path: str) -> Optional[MemoryScope]:
        row = self._conn.execute(
            "SELECT * FROM memory_scopes WHERE kind = ? AND path = ?",
            (kind, path),
        ).fetchone()
        return self._row_to_scope(row) if row else None

    def get_scope(self, scope_id: str | None) -> Optional[MemoryScope]:
        if not scope_id:
            return None
        row = self._conn.execute(
            "SELECT * FROM memory_scopes WHERE id = ?",
            (scope_id,),
        ).fetchone()
        return self._row_to_scope(row) if row else None

    def list_scopes(
        self,
        *,
        kind: Optional[str] = None,
        parent_scope_id: Optional[str] = None,
        include_archived: bool = False,
    ) -> list[MemoryScope]:
        sql = "SELECT * FROM memory_scopes WHERE 1=1"
        params: list = []
        if kind is not None:
            sql += " AND kind = ?"
            params.append(kind)
        if parent_scope_id is not None:
            sql += " AND parent_scope_id = ?"
            params.append(parent_scope_id)
        if not include_archived:
            sql += " AND status = 'active'"
        sql += " ORDER BY path ASC"
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_scope(row) for row in rows]

    def list_scope_ancestor_ids(self, scope_id: str) -> list[str]:
        scope = self.get_scope(scope_id)
        out: list[str] = []
        while scope is not None and scope.parent_scope_id:
            scope = self.get_scope(scope.parent_scope_id)
            if scope is not None:
                out.append(scope.id)
        return out

    def create_job(self, job: JobRecord) -> JobRecord:
        self._conn.execute(
            """INSERT INTO jobs
               (id, job_type, status, payload, attempts, max_attempts, available_at,
                leased_at, lease_owner, last_error, created_at, updated_at, completed_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                job.id,
                job.job_type,
                job.status,
                json.dumps(job.payload, ensure_ascii=False),
                job.attempts,
                job.max_attempts,
                _dt_to_str(job.available_at),
                _dt_to_str(job.leased_at),
                job.lease_owner,
                job.last_error,
                _dt_to_str(job.created_at),
                _dt_to_str(job.updated_at),
                _dt_to_str(job.completed_at),
            ),
        )
        self._conn.commit()
        return job

    def get_job(self, job_id: str) -> Optional[JobRecord]:
        row = self._conn.execute(
            "SELECT * FROM jobs WHERE id = ?",
            (job_id,),
        ).fetchone()
        return self._row_to_job(row) if row else None

    def list_jobs(
        self,
        *,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
        limit: int = 50,
    ) -> list[JobRecord]:
        sql = "SELECT * FROM jobs WHERE 1=1"
        params: list = []
        if status is not None:
            sql += " AND status = ?"
            params.append(status)
        if job_type is not None:
            sql += " AND job_type = ?"
            params.append(job_type)
        sql += " ORDER BY available_at ASC, created_at ASC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_job(row) for row in rows]

    def lease_jobs(self, *, limit: int, lease_owner: str) -> list[JobRecord]:
        now = datetime.now()
        rows = self._conn.execute(
            """SELECT * FROM jobs
               WHERE status = 'queued'
                 AND available_at <= ?
               ORDER BY available_at ASC, created_at ASC
               LIMIT ?""",
            (_dt_to_str(now), limit),
        ).fetchall()
        leased: list[JobRecord] = []
        for row in rows:
            job = self._row_to_job(row)
            job.status = "running"
            job.lease_owner = lease_owner
            job.leased_at = now
            job.updated_at = now
            leased.append(self.update_job(job))
        return leased

    def update_job(self, job: JobRecord) -> JobRecord:
        self._conn.execute(
            """UPDATE jobs
               SET status = ?, payload = ?, attempts = ?, max_attempts = ?, available_at = ?,
                   leased_at = ?, lease_owner = ?, last_error = ?, updated_at = ?, completed_at = ?
               WHERE id = ?""",
            (
                job.status,
                json.dumps(job.payload, ensure_ascii=False),
                job.attempts,
                job.max_attempts,
                _dt_to_str(job.available_at),
                _dt_to_str(job.leased_at),
                job.lease_owner,
                job.last_error,
                _dt_to_str(job.updated_at),
                _dt_to_str(job.completed_at),
                job.id,
            ),
        )
        self._conn.commit()
        return job

    # ── FTS Indexing ──

    def _index_entity(self, entity: Entity, facts: Optional[list[Fact]] = None) -> None:
        if facts is None:
            facts = self.get_current_facts(entity.id)
        # Only index top 50 most recent/confident facts to prevent FTS bloat
        relevant = sorted(facts, key=lambda f: (f.confidence, f.created_at or datetime.min), reverse=True)[:50]
        fact_texts = " ".join(f.raw_text for f in relevant)

        # Include relation targets so searching "Hashed" also finds "Simon Kim (CEO_OF Hashed)"
        relations = self.get_relations(entity.id)
        relation_parts: list[str] = []
        for r in relations[:20]:
            other_id = r.to_entity_id if r.from_entity_id == entity.id else r.from_entity_id
            other = self.get_entity(other_id)
            if other:
                relation_parts.append(f"{r.relation_type} {other.name}")
        if relation_parts:
            fact_texts = f"{fact_texts} {' '.join(relation_parts)}"

        state_text = " ".join(f"{k}: {v}" for k, v in entity.state.to_dict().items() if isinstance(v, str))
        # Include aliases in searchable text
        alias_text = " ".join(entity.aliases) if entity.aliases else ""
        if alias_text:
            fact_texts = f"{fact_texts} {alias_text}"

        self._conn.execute(
            "INSERT INTO memory_fts (entity_id, entity_name, entity_type, fact_text, state_text, summary) VALUES (?,?,?,?,?,?)",
            (entity.id, entity.name, entity.entity_type, fact_texts, state_text, entity.summary),
        )

    def reindex_entity(self, entity: Entity) -> None:
        self._conn.execute("DELETE FROM memory_fts WHERE entity_id = ?", (entity.id,))
        facts = self.get_current_facts(entity.id)
        self._index_entity(entity, facts)

    def reindex_all(self) -> int:
        self._conn.execute("DELETE FROM memory_fts")
        count = 0
        offset = 0
        batch_size = 500
        while True:
            batch = self.list_entities(limit=batch_size, offset=offset)
            if not batch:
                break
            for entity in batch:
                self._index_entity(entity)
            count += len(batch)
            offset += batch_size
        self._conn.commit()
        return count

    # ── Row → Model Conversion ──

    def _row_to_entity(self, row: sqlite3.Row) -> Entity:
        state_data = json.loads(row["state"]) if row["state"] else {}
        return Entity(
            id=row["id"],
            name=row["name"],
            entity_type=row["entity_type"],
            tier=Tier(row["tier"]),
            summary=row["summary"] or "",
            aliases=json.loads(row["aliases"]) if row["aliases"] else [],
            state=EntityState.from_dict(state_data),
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            updated_at=_str_to_dt(row["updated_at"]) or datetime.now(),
            access_count=row["access_count"] or 0,
            last_accessed=_str_to_dt(row["last_accessed"]),
        )

    def _row_to_fact(self, row: sqlite3.Row) -> Fact:
        return Fact(
            id=row["id"],
            entity_id=row["entity_id"],
            subject=row["subject"],
            predicate=row["predicate"],
            object=row["object"],
            raw_text=row["raw_text"],
            source=Source(
                type=SourceType(row["source_type"]),
                author=row["source_author"] or "",
                channel=row["source_channel"] or "",
                timestamp=_str_to_dt(row["source_timestamp"]) or datetime.now(),
                confidence=row["source_confidence"] if row["source_confidence"] is not None else 1.0,
                url=row["source_url"],
                session_id=row["source_session_id"],
            ),
            scope_id=row["scope_id"] if "scope_id" in row.keys() else None,
            confidence=row["confidence"],
            status=FactStatus(row["status"]),
            verification_status=VerificationStatus(
                row["verification_status"]
                if "verification_status" in row.keys() and row["verification_status"]
                else "unknown"
            ),
            last_verified_at=(
                _str_to_dt(row["last_verified_at"])
                if "last_verified_at" in row.keys()
                else None
            ),
            verification_due_at=(
                _str_to_dt(row["verification_due_at"])
                if "verification_due_at" in row.keys()
                else None
            ),
            memory_type=MemoryType(
                row["memory_type"] if "memory_type" in row.keys() and row["memory_type"] else "episodic"
            ),
            valid_from=_str_to_dt(row["valid_from"]),
            valid_to=_str_to_dt(row["valid_to"]),
            applicability=FactApplicability(
                applies_if=(
                    json.loads(row["applies_if"])
                    if "applies_if" in row.keys() and row["applies_if"]
                    else []
                ),
                except_if=(
                    json.loads(row["except_if"])
                    if "except_if" in row.keys() and row["except_if"]
                    else []
                ),
            ),
            superseded_by=row["superseded_by"],
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )

    def _row_to_relation(self, row: sqlite3.Row) -> Relation:
        return Relation(
            id=row["id"],
            from_entity_id=row["from_entity_id"],
            to_entity_id=row["to_entity_id"],
            relation_type=row["relation_type"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
            valid_from=_str_to_dt(row["valid_from"]),
            valid_to=_str_to_dt(row["valid_to"]),
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )

    def _row_to_session(self, row: sqlite3.Row) -> Session:
        return Session(
            session_id=row["session_id"],
            agent_id=row["agent_id"],
            started_at=_str_to_dt(row["started_at"]) or datetime.now(),
            ended_at=_str_to_dt(row["ended_at"]),
            parent_session_id=row["parent_session_id"],
            scope_id=row["scope_id"] if "scope_id" in row.keys() else None,
            entities_accessed=json.loads(row["entities_accessed"]) if row["entities_accessed"] else [],
            entities_modified=json.loads(row["entities_modified"]) if row["entities_modified"] else [],
            facts_added=json.loads(row["facts_added"]) if row["facts_added"] else [],
            summary=row["summary"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
        )

    def _row_to_session_event(self, row: sqlite3.Row) -> SessionEvent:
        return SessionEvent(
            id=row["id"],
            session_id=row["session_id"],
            event_type=row["event_type"],
            target=row["target"] or "",
            scope_id=row["scope_id"] if "scope_id" in row.keys() else None,
            detail=json.loads(row["detail"]) if row["detail"] else {},
            timestamp=_str_to_dt(row["timestamp"]) or datetime.now(),
        )

    def _row_to_reference_edge(self, row: sqlite3.Row) -> ReferenceEdge:
        return ReferenceEdge(
            id=row["id"],
            entity_id=row["entity_id"],
            source_kind=row["source_kind"],
            source_id=row["source_id"],
            snippet=row["snippet"] or "",
            matched_text=row["matched_text"] or "",
            match_start=row["match_start"],
            match_end=row["match_end"],
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            indexed_at=_str_to_dt(row["indexed_at"]) or datetime.now(),
        )

    def _row_to_decision(self, row: sqlite3.Row) -> DecisionRecord:
        return DecisionRecord(
            id=row["id"],
            fingerprint=row["fingerprint"],
            title=row["title"],
            summary=row["summary"],
            status=DecisionStatus(row["status"]),
            confidence=row["confidence"],
            source_kind=row["source_kind"],
            source_id=row["source_id"],
            entity_id=row["entity_id"],
            session_id=row["session_id"],
            verification_status=VerificationStatus(
                row["verification_status"]
                if "verification_status" in row.keys() and row["verification_status"]
                else "unknown"
            ),
            last_verified_at=(
                _str_to_dt(row["last_verified_at"])
                if "last_verified_at" in row.keys()
                else None
            ),
            verification_due_at=(
                _str_to_dt(row["verification_due_at"])
                if "verification_due_at" in row.keys()
                else None
            ),
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            indexed_at=_str_to_dt(row["indexed_at"]) or datetime.now(),
            superseded_by=row["superseded_by"],
        )

    def _row_to_governance_candidate(self, row: sqlite3.Row) -> GovernanceCandidate:
        return GovernanceCandidate(
            id=row["id"],
            candidate_type=GovernanceCandidateType(row["candidate_type"]),
            status=GovernanceCandidateStatus(row["status"]),
            entity_id=row["entity_id"],
            related_entity_id=row["related_entity_id"],
            proposed_alias=row["proposed_alias"],
            score=float(row["score"]),
            fingerprint=row["fingerprint"],
            rationale=row["rationale"] or "",
            details=json.loads(row["details"]) if row["details"] else {},
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            updated_at=_str_to_dt(row["updated_at"]) or datetime.now(),
            resolved_at=_str_to_dt(row["resolved_at"]),
            resolved_by=row["resolved_by"],
        )

    def _row_to_verification_request(self, row: sqlite3.Row) -> VerificationRequest:
        return VerificationRequest(
            id=row["id"],
            target_kind=row["target_kind"],
            target_id=row["target_id"],
            entity_id=row["entity_id"],
            scope_id=row["scope_id"],
            reason=row["reason"],
            status=VerificationRequestStatus(row["status"]),
            requested_by=row["requested_by"],
            resolution=(
                VerificationResolution(row["resolution"])
                if row["resolution"] is not None
                else None
            ),
            detail=row["detail"] or "",
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
            requested_at=_str_to_dt(row["requested_at"]) or datetime.now(),
            resolved_at=_str_to_dt(row["resolved_at"]),
        )

    def _row_to_maintenance_run(
        self,
        row: sqlite3.Row,
        *,
        include_items: bool,
    ) -> MaintenanceRun:
        run = MaintenanceRun(
            id=row["id"],
            started_at=_str_to_dt(row["started_at"]) or datetime.now(),
            completed_at=_str_to_dt(row["completed_at"]) or datetime.now(),
            grade=row["grade"],
            score_value=row["score_value"],
            summary=row["summary"] or "",
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
        )
        if include_items:
            item_rows = self._conn.execute(
                "SELECT * FROM maintenance_run_items WHERE run_id = ? ORDER BY created_at ASC",
                (run.id,),
            ).fetchall()
            run.items = [self._row_to_maintenance_run_item(item_row) for item_row in item_rows]
        return run

    def _row_to_maintenance_run_item(self, row: sqlite3.Row) -> MaintenanceRunItem:
        return MaintenanceRunItem(
            id=row["id"],
            run_id=row["run_id"],
            kind=row["kind"],
            severity=row["severity"],
            target_id=row["target_id"],
            entity_name=row["entity_name"],
            title=row["title"],
            detail=row["detail"] or "",
            recommended_action=row["recommended_action"],
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )

    def _row_to_retention_policy(self, row: sqlite3.Row) -> RetentionPolicy:
        return RetentionPolicy(
            id=row["id"],
            target_kind=RetentionTargetKind(row["target_kind"]),
            target_id=row["target_id"],
            policy_type=RetentionPolicyType(row["policy_type"]),
            value=row["value"],
            reason=row["reason"] or "",
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            updated_at=_str_to_dt(row["updated_at"]) or datetime.now(),
        )

    def _row_to_scope(self, row: sqlite3.Row) -> MemoryScope:
        return MemoryScope(
            id=row["id"],
            kind=row["kind"],
            name=row["name"],
            path=row["path"],
            parent_scope_id=row["parent_scope_id"],
            status=row["status"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            updated_at=_str_to_dt(row["updated_at"]) or datetime.now(),
        )

    def _row_to_job(self, row: sqlite3.Row) -> JobRecord:
        return JobRecord(
            id=row["id"],
            job_type=row["job_type"],
            status=row["status"],
            payload=json.loads(row["payload"]) if row["payload"] else {},
            attempts=row["attempts"],
            max_attempts=row["max_attempts"],
            available_at=_str_to_dt(row["available_at"]) or datetime.now(),
            leased_at=_str_to_dt(row["leased_at"]),
            lease_owner=row["lease_owner"],
            last_error=row["last_error"],
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            updated_at=_str_to_dt(row["updated_at"]) or datetime.now(),
            completed_at=_str_to_dt(row["completed_at"]),
        )
