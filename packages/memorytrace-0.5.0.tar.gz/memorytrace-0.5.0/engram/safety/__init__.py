"""Cross-cutting safety helpers used by both the CLI and the engine."""

from engram.safety.paths import (
    MAX_INTAKE_FILE_BYTES,
    SENSITIVE_PATH_SUBSTRINGS,
    SENSITIVE_PATH_SUFFIXES,
    ensure_safe_write_target,
    read_text_safely,
)

__all__ = [
    "MAX_INTAKE_FILE_BYTES",
    "SENSITIVE_PATH_SUBSTRINGS",
    "SENSITIVE_PATH_SUFFIXES",
    "ensure_safe_write_target",
    "read_text_safely",
]
