"""Shared path-safety policy for read (intake --from-file) and write
(snapshot restore) capabilities.

Keeping the blocklist in one place means the read path and the write path
can't drift; both surfaces are equally dangerous under prompt injection.
"""

from __future__ import annotations

from pathlib import Path


# Common secret locations / filename roots. Substring-matched against the
# resolved, lowercased path with forward slashes.
SENSITIVE_PATH_SUBSTRINGS: tuple[str, ...] = (
    # Unix system secrets
    "/etc/passwd",
    "/etc/shadow",
    "/etc/sudoers",
    # Per-user secret stores
    "/.ssh/",
    "/.aws/",
    "/.gnupg/",
    "/.gpg/",
    "/.netrc",
    "/.kube/",
    "/.docker/config",
    "/.env",
    # Common private-key filename roots
    "/id_rsa",
    "/id_dsa",
    "/id_ecdsa",
    "/id_ed25519",
    # Shell startup files — writing here is a classic persistence vector
    "/.bashrc",
    "/.bash_profile",
    "/.zshrc",
    "/.profile",
    # SSH trust anchors
    "/authorized_keys",
    "/known_hosts",
)

SENSITIVE_PATH_SUFFIXES: tuple[str, ...] = (
    ".pem",
    ".key",
    ".p12",
    ".pfx",
    ".asc",
    ".kdbx",
    ".jks",
)

# 1 MiB — intake is for human text, restores for reasonable DB sizes.
MAX_INTAKE_FILE_BYTES = 1 * 1024 * 1024


def _matches_sensitive(path: Path) -> tuple[bool, str]:
    """Return (matches, reason) for the blocklist check."""
    norm = str(path).replace("\\", "/").lower()
    for pat in SENSITIVE_PATH_SUBSTRINGS:
        if pat in norm:
            return True, f"matches sensitive path pattern '{pat}'"
    for suf in SENSITIVE_PATH_SUFFIXES:
        if norm.endswith(suf):
            return True, f"extension '{suf}' commonly holds secrets"
    return False, ""


def read_text_safely(
    path_str: str,
    allow_unsafe: bool,
    max_bytes: int = MAX_INTAKE_FILE_BYTES,
) -> str:
    """Read a text file with intake-grade safety checks.

    Raises:
        FileNotFoundError: missing or non-regular file.
        PermissionError: path matches a sensitive pattern and ``allow_unsafe``
            is False.
        ValueError: file is too large or not valid UTF-8.
    """
    p = Path(path_str).expanduser().resolve()
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"File not found: {p}")

    if not allow_unsafe:
        matches, reason = _matches_sensitive(p)
        if matches:
            raise PermissionError(
                f"Refusing to read {p}: {reason}. "
                f"Re-run with --unsafe-path if this is intentional."
            )

    size = p.stat().st_size
    if size > max_bytes:
        raise ValueError(
            f"File {p} is {size:,} bytes (max {max_bytes:,}). "
            f"Use store or split the input."
        )

    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise ValueError(
            f"File {p} is not valid UTF-8 ({e.reason}). Text documents only."
        ) from None


def ensure_safe_write_target(
    path_str: str,
    allow_unsafe: bool,
    refuse_existing: bool = True,
) -> Path:
    """Validate a path that the caller intends to WRITE to.

    Mirrors the read-side policy so prompt-injection attacks can't use
    restore-like features to drop files into ~/.ssh/authorized_keys or
    overwrite shell startup scripts.

    Raises:
        FileExistsError: target exists and ``refuse_existing`` is True.
        PermissionError: path matches a sensitive pattern and ``allow_unsafe``
            is False.
    """
    p = Path(path_str).expanduser().resolve()
    if refuse_existing and p.exists():
        raise FileExistsError(f"Refusing to overwrite {p}")

    if not allow_unsafe:
        matches, reason = _matches_sensitive(p)
        if matches:
            raise PermissionError(
                f"Refusing to write to {p}: {reason}. "
                f"Pass allow_unsafe=True / --unsafe-path if this is intentional."
            )

    return p
