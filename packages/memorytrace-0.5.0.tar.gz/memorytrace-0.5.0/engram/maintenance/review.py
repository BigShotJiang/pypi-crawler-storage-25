"""Operations review orchestration."""

from __future__ import annotations

from typing import Callable

from engram.decisions.service import DecisionService
from engram.models.health import HealthReport
from engram.models.maintenance import MaintenanceRun
from engram.models.operations import JobRunSummary, OperationsReview, ProjectionDriftItem
from engram.models.view import MaintenanceRunView
from engram.recommendations.service import RecommendationService
from engram.references.service import ReferenceService


class OperationsReviewService:
    """Aggregate health, persisted maintenance, drift, jobs, and recommendations."""

    def __init__(
        self,
        *,
        health_report_fn: Callable[..., HealthReport],
        maintenance_run_fn: Callable[..., MaintenanceRun],
        maintenance_view_fn: Callable[[str], MaintenanceRunView | None],
        run_jobs_fn: Callable[..., dict],
        reference_service: ReferenceService,
        decision_service: DecisionService,
        recommendation_service: RecommendationService,
    ) -> None:
        self.health_report_fn = health_report_fn
        self.maintenance_run_fn = maintenance_run_fn
        self.maintenance_view_fn = maintenance_view_fn
        self.run_jobs_fn = run_jobs_fn
        self.reference_service = reference_service
        self.decision_service = decision_service
        self.recommendation_service = recommendation_service

    def run(
        self,
        *,
        max_open_loops: int = 50,
        stale_days: int | None = None,
        run_jobs: bool = False,
        job_limit: int = 20,
        lease_owner: str = "operations_review",
        include_projection_drift: bool = True,
        include_recommendations: bool = True,
    ) -> OperationsReview:
        health_report = self.health_report_fn(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )
        # Pass the already-computed health_report into the maintenance run
        # so diagnostics is not executed a second time.
        persisted = self.maintenance_run_fn(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
            health_report=health_report,
        )
        maintenance_view = self.maintenance_view_fn(persisted.id)
        raw_job_result = (
            self.run_jobs_fn(limit=job_limit, lease_owner=lease_owner)
            if run_jobs
            else None
        )
        job_result = JobRunSummary.from_dict(raw_job_result) if raw_job_result else None
        reference_drift = (
            [
                ProjectionDriftItem.from_dict(row)
                for row in self.reference_service.projection_drift(limit=max_open_loops)
            ]
            if include_projection_drift
            else []
        )
        decision_drift = (
            [
                ProjectionDriftItem.from_dict(row)
                for row in self.decision_service.projection_drift(limit=max_open_loops)
            ]
            if include_projection_drift
            else []
        )
        recommendations = (
            self.recommendation_service.list_recommendations(
                limit=10,
                max_open_loops=max_open_loops,
                stale_days=stale_days,
            )
            if include_recommendations
            else []
        )
        summary_lines = [
            f"open_loops={len(health_report.open_loops)}",
            f"maintenance_grade={maintenance_view.run.grade if maintenance_view else 'unknown'}",
            (f"jobs_completed={job_result.completed}" if job_result else "jobs_completed=skipped"),
            f"reference_drift={len(reference_drift)}",
            f"decision_drift={len(decision_drift)}",
            f"recommendations={len(recommendations)}",
        ]
        return OperationsReview(
            health_report=health_report,
            maintenance_run=maintenance_view,
            job_result=job_result,
            reference_drift=reference_drift,
            decision_drift=decision_drift,
            recommendations=recommendations,
            summary_lines=summary_lines,
        )
