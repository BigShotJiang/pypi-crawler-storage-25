"""Persisted maintenance-run service."""

from __future__ import annotations

from datetime import datetime

from engram.models.health import HealthReport
from engram.models.maintenance import MaintenanceRun, MaintenanceRunItem
from engram.quality.diagnostics import Diagnostics
from engram.storage.sqlite_store import SQLiteStorage


class MaintenanceService:
    """Persist health-report snapshots as maintenance runs."""

    def __init__(self, storage: SQLiteStorage, diagnostics: Diagnostics) -> None:
        self.storage = storage
        self.diagnostics = diagnostics

    def run(
        self,
        max_open_loops: int = 50,
        stale_days: int | None = None,
        health_report: HealthReport | None = None,
    ) -> MaintenanceRun:
        started_at = datetime.now()
        report = health_report or self.diagnostics.run(
            max_open_loops=max_open_loops, stale_days=stale_days,
        )
        run = MaintenanceRun(
            started_at=started_at,
            completed_at=datetime.now(),
            grade=report.grade,
            score_value=report.score_value,
            summary=f"{len(report.open_loops)} open loops captured",
            metadata={
                "entity_count": report.entity_count,
                "fact_count": report.fact_count,
                "metric_count": len(report.metrics),
            },
        )
        run.items = [
            MaintenanceRunItem(
                run_id=run.id,
                kind=loop.kind.value,
                severity=loop.severity.value,
                target_id=loop.target_id,
                entity_name=loop.entity_name,
                title=loop.title,
                detail=loop.detail,
                recommended_action=loop.recommended_action,
                created_at=loop.created_at or run.completed_at,
            )
            for loop in report.open_loops
        ]
        return self.storage.save_maintenance_run(run)

    def list_runs(self, limit: int = 20) -> list[MaintenanceRun]:
        return self.storage.list_maintenance_runs(limit=limit)

    def get_run(self, run_id: str) -> MaintenanceRun | None:
        return self.storage.get_maintenance_run(run_id)
