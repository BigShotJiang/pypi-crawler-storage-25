"""Persisted maintenance package."""
