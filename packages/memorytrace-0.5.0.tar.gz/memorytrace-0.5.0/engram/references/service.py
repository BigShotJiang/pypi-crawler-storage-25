"""Reference projection service for backlinks."""

from __future__ import annotations

import re
from datetime import datetime

from engram.models.reference import ReferenceEdge
from engram.storage.sqlite_store import SQLiteStorage


class ReferenceService:
    """Extract and persist source-scoped entity mentions."""

    _SOURCE_QUERIES = {
        "note": "SELECT id AS source_id, text AS text FROM notes",
        "session": "SELECT session_id AS source_id, summary AS text FROM sessions WHERE summary IS NOT NULL AND summary != ''",
        "debug_session": "SELECT id AS source_id, conclusion AS text FROM debug_sessions WHERE conclusion IS NOT NULL AND conclusion != ''",
        "debug_hypothesis": "SELECT id AS source_id, text AS text FROM debug_hypotheses",
        "debug_evidence": "SELECT id AS source_id, text AS text FROM debug_evidence",
    }

    def __init__(self, storage: SQLiteStorage) -> None:
        self.storage = storage

    def backlinks(self, name: str, source_kind: str | None = None, limit: int = 50) -> list[dict]:
        entity = self.storage.get_entity_by_name(name)
        if entity is None:
            return []
        edges = self.storage.list_reference_edges(entity.id, source_kind=source_kind, limit=limit)
        return [edge.to_dict() for edge in edges]

    def index_source(self, source_kind: str, source_id: str) -> list[ReferenceEdge]:
        text = self._load_source_text(source_kind, source_id)
        if not text:
            self.storage.replace_reference_edges(source_kind, source_id, [])
            return []
        edges = self._extract_edges(source_kind, source_id, text)
        self.storage.replace_reference_edges(source_kind, source_id, edges)
        return edges

    def rebuild_all(self) -> int:
        total = 0
        # Pre-load entities once instead of per-source to avoid O(N*M) DB reads.
        entities = self.storage.list_entities(limit=10000)
        conn = self.storage._conn
        for source_kind, sql in self._SOURCE_QUERIES.items():
            rows = conn.execute(sql).fetchall()
            for row in rows:
                text = (row["text"] if row and "text" in row.keys() else "") or ""
                edges = self._extract_edges(source_kind, row["source_id"], text, entities=entities)
                self.storage.replace_reference_edges(source_kind, row["source_id"], edges)
                total += 1
        return total

    def projection_drift(self, limit: int = 20) -> list[dict]:
        """Return sources that should have reference edges but currently do not."""
        drifts: list[dict] = []
        conn = self.storage._conn
        for source_kind, sql in self._SOURCE_QUERIES.items():
            rows = conn.execute(sql).fetchall()
            for row in rows:
                text = (row["text"] or "").strip()
                if not text:
                    continue
                if not self._extract_edges(source_kind, row["source_id"], text):
                    continue
                if self.storage.count_reference_edges_for_source(source_kind, row["source_id"]) > 0:
                    continue
                drifts.append(
                    {
                        "source_kind": source_kind,
                        "source_id": row["source_id"],
                        "title": f"Missing references for {source_kind} {row['source_id']}",
                        "detail": text[:120],
                    }
                )
                if len(drifts) >= limit:
                    return drifts
        return drifts

    def match_entity_ids(self, text: str) -> list[str]:
        seen: list[str] = []
        for edge in self._extract_edges("preview", "preview", text):
            if edge.entity_id not in seen:
                seen.append(edge.entity_id)
        return seen

    def _load_source_text(self, source_kind: str, source_id: str) -> str:
        conn = self.storage._conn
        if source_kind == "note":
            row = conn.execute("SELECT text FROM notes WHERE id = ?", (source_id,)).fetchone()
        elif source_kind == "session":
            row = conn.execute("SELECT summary AS text FROM sessions WHERE session_id = ?", (source_id,)).fetchone()
        elif source_kind == "debug_session":
            row = conn.execute("SELECT conclusion AS text FROM debug_sessions WHERE id = ?", (source_id,)).fetchone()
        elif source_kind == "debug_hypothesis":
            row = conn.execute("SELECT text FROM debug_hypotheses WHERE id = ?", (source_id,)).fetchone()
        elif source_kind == "debug_evidence":
            row = conn.execute("SELECT text FROM debug_evidence WHERE id = ?", (source_id,)).fetchone()
        else:
            raise ValueError(f"Unsupported source_kind: {source_kind}")
        return (row["text"] if row and "text" in row.keys() else "") or ""

    def _extract_edges(
        self,
        source_kind: str,
        source_id: str,
        text: str,
        entities: list | None = None,
    ) -> list[ReferenceEdge]:
        lowered = text.lower()
        now = datetime.now()
        edges: list[ReferenceEdge] = []
        taken: set[tuple[str, int, int]] = set()
        if entities is None:
            entities = self.storage.list_entities(limit=10000)
        for entity in entities:
            candidates = [entity.name, *entity.aliases]
            for candidate in candidates:
                token = (candidate or "").strip()
                # Skip very short tokens unless they are uppercase acronyms
                # or contain CJK/Hangul characters (2-char Korean names are valid).
                if len(token) < 3 and not token.isupper():
                    has_cjk = any('\uAC00' <= ch <= '\uD7AF' or '\u4E00' <= ch <= '\u9FFF' for ch in token)
                    if not has_cjk:
                        continue
                escaped = re.escape(token.lower())
                pattern = re.compile(rf"(?<!\w){escaped}(?!\w)")
                for match in pattern.finditer(lowered):
                    key = (entity.id, match.start(), match.end())
                    if key in taken:
                        continue
                    taken.add(key)
                    snippet_start = max(0, match.start() - 40)
                    snippet_end = min(len(text), match.end() + 40)
                    snippet = text[snippet_start:snippet_end].replace("\n", " ").strip()
                    edges.append(
                        ReferenceEdge(
                            entity_id=entity.id,
                            source_kind=source_kind,
                            source_id=source_id,
                            snippet=snippet,
                            matched_text=text[match.start():match.end()],
                            match_start=match.start(),
                            match_end=match.end(),
                            created_at=now,
                            indexed_at=now,
                        )
                    )
        return edges
