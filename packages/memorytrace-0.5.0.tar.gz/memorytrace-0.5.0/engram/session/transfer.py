"""Context pack assembly and transfer helpers."""

from __future__ import annotations

from engram.models.brief import EntityRef, SessionBrief
from engram.models.context_pack import ContextPack
from engram.models.decision import DecisionRecord
from engram.models.explanation import ExplanationBundle
from engram.models.health import HealthReport, OpenLoop
from engram.models.session import Session
from engram.models.view import DecisionView
from engram.quality.diagnostics import Diagnostics
from engram.storage.base import StorageBackend


class ContextPackBuilder:
    """Build reusable handoff packs from an existing session view."""

    def __init__(
        self,
        storage: StorageBackend,
        diagnostics: Diagnostics,
    ) -> None:
        self.storage = storage
        self.diagnostics = diagnostics

    def build(
        self,
        *,
        session: Session,
        goal: str,
        max_chars: int,
        session_brief: SessionBrief,
        health_report: HealthReport | None = None,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
        include_session_text: bool = True,
        summary_override: str | None = None,
        recent_queries_override: list[str] | None = None,
        derive_summary: bool = False,
    ) -> ContextPack:
        touched_entities = self._dedupe_entities(
            [
                *session_brief.entities_modified,
                *session_brief.entities_accessed,
            ]
        )
        active_entities = list(
            session_brief.active_working_memory
            or session_brief.entities_modified[:8]
            or session_brief.entities_accessed[:8]
        )
        if allowed_scope_ids is not None:
            scope_map = self.storage.list_current_fact_scopes(
                [row.entity_id for row in [*touched_entities, *active_entities]]
            )
            scope_cache: dict[str, bool] = {}
            touched_entities = self._filter_entities_for_scope(
                touched_entities,
                allowed_scope_ids,
                include_global=include_global,
                cache=scope_cache,
                scope_map=scope_map,
            )
            active_entities = self._filter_entities_for_scope(
                active_entities,
                allowed_scope_ids,
                include_global=include_global,
                cache=scope_cache,
                scope_map=scope_map,
            )
        entity_ids = [row.entity_id for row in touched_entities]
        recent_queries = (
            list(recent_queries_override[:5])
            if recent_queries_override is not None
            else (list(session_brief.recent_queries[:5]) if include_session_text else [])
        )
        decisions = self._supporting_decisions(
            session,
            entity_ids,
            allowed_scope_ids=allowed_scope_ids,
            include_global=include_global,
        )
        open_loops = self._open_loops(
            entity_ids,
            active_entities,
            health_report=health_report,
        )
        summary = (
            summary_override
            if summary_override is not None
            else ((session.summary or "") if include_session_text else "")
        )
        if derive_summary and not summary:
            summary = self._derive_summary(
                active_entities=active_entities,
                recent_queries=recent_queries,
                decisions=decisions,
            )
        rendered = self._render_text(
            summary=summary,
            active_entities=active_entities,
            recent_queries=recent_queries,
            decisions=decisions,
            open_loops=open_loops,
            max_chars=max_chars,
        )
        return ContextPack(
            source_session_id=session.session_id,
            source_agent_id=session.agent_id,
            scope_id=session.scope_id,
            goal=goal,
            summary=summary,
            source_session_active=session.is_active,
            active_entities=active_entities,
            recent_queries=recent_queries,
            supporting_decisions=decisions,
            open_loops=open_loops,
            rendered_text=rendered,
        )

    def _supporting_decisions(
        self,
        session: Session,
        entity_ids: list[str],
        *,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
    ) -> list[DecisionView]:
        rows: list[DecisionView] = []
        seen: set[str] = set()
        session_scope_cache: dict[str, str | None] = {}
        for eid in entity_ids[:5]:
            for decision in self.storage.list_decisions(entity_id=eid, limit=10):
                if decision.id in seen:
                    continue
                if not self._decision_in_scope(
                    session,
                    decision,
                    allowed_scope_ids=allowed_scope_ids,
                    include_global=include_global,
                    session_scope_cache=session_scope_cache,
                ):
                    continue
                seen.add(decision.id)
                rows.append(
                    DecisionView(
                        decision=decision,
                        explanation=ExplanationBundle(
                            summary="Decision supports this handoff.",
                        ),
                    )
                )
                if len(rows) >= 5:
                    return rows
        return rows

    def _derive_summary(
        self,
        *,
        active_entities: list[EntityRef],
        recent_queries: list[str],
        decisions: list[DecisionView],
    ) -> str:
        decision_topics = [
            row.decision.title or row.decision.summary
            for row in decisions[:2]
            if row.decision.title or row.decision.summary
        ]
        if decision_topics:
            return "; ".join(decision_topics)
        if active_entities and recent_queries:
            entity_names = ", ".join(row.name for row in active_entities[:3])
            query_text = ", ".join(recent_queries[:2])
            return f"Discussed {entity_names} around {query_text}."
        if active_entities:
            entity_names = ", ".join(row.name for row in active_entities[:3])
            return f"Discussed {entity_names}."
        if recent_queries:
            return "Focused on " + ", ".join(recent_queries[:2]) + "."
        return ""

    def _open_loops(
        self,
        entity_ids: list[str],
        active_entities: list[EntityRef],
        *,
        health_report: HealthReport | None = None,
    ) -> list[OpenLoop]:
        if not entity_ids and not active_entities:
            return []
        active_names = {row.name for row in active_entities}
        report = health_report or self.diagnostics.run(max_open_loops=20)
        rows: list[OpenLoop] = []
        for loop in report.open_loops:
            if loop.target_id in entity_ids or (loop.entity_name and loop.entity_name in active_names):
                rows.append(loop)
            if len(rows) >= 5:
                break
        return rows

    def _filter_entities_for_scope(
        self,
        entities: list[EntityRef],
        allowed_scope_ids: set[str],
        *,
        include_global: bool = False,
        cache: dict[str, bool] | None = None,
        scope_map: dict[str, set[str | None]] | None = None,
    ) -> list[EntityRef]:
        entity_scope_cache = cache if cache is not None else {}
        current_scope_map = scope_map if scope_map is not None else {}
        rows: list[EntityRef] = []
        for entity in entities:
            if entity.entity_id not in entity_scope_cache:
                entity_scope_cache[entity.entity_id] = any(
                    self._scope_allows(scope_id, allowed_scope_ids, include_global)
                    for scope_id in current_scope_map.get(entity.entity_id, set())
                )
            if entity_scope_cache[entity.entity_id]:
                rows.append(entity)
        return rows

    def _dedupe_entities(self, entities: list[EntityRef]) -> list[EntityRef]:
        seen: set[str] = set()
        rows: list[EntityRef] = []
        for entity in entities:
            if entity.entity_id in seen:
                continue
            seen.add(entity.entity_id)
            rows.append(entity)
        return rows

    def _render_text(
        self,
        *,
        summary: str,
        active_entities: list[EntityRef],
        recent_queries: list[str],
        decisions: list[DecisionView],
        open_loops: list[OpenLoop],
        max_chars: int,
    ) -> str:
        sections = [
            f"Summary: {summary or 'No session summary.'}",
            "Active entities: "
            + (", ".join(row.name for row in active_entities) if active_entities else "None"),
            "Recent queries: " + (", ".join(recent_queries) if recent_queries else "None"),
            (
                "Supporting decisions: "
                + "; ".join(row.decision.title for row in decisions)
                if decisions
                else "Supporting decisions: None"
            ),
            (
                "Open loops: " + "; ".join(row.title for row in open_loops)
                if open_loops
                else "Open loops: None"
            ),
        ]
        text = "\n".join(sections)
        if max_chars > 0 and len(text) > max_chars:
            return text[:max_chars]
        return text

    def _decision_in_scope(
        self,
        session: Session,
        decision: DecisionRecord,
        *,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
        session_scope_cache: dict[str, str | None] | None = None,
    ) -> bool:
        if allowed_scope_ids is not None:
            if not decision.session_id:
                return False
            cache = session_scope_cache if session_scope_cache is not None else {}
            if decision.session_id not in cache:
                decision_session = self.storage.get_session(decision.session_id)
                cache[decision.session_id] = (
                    decision_session.scope_id if decision_session else None
                )
            return self._scope_allows(
                cache[decision.session_id],
                allowed_scope_ids,
                include_global,
            )
        if session.scope_id is None:
            return True
        if decision.session_id == session.session_id:
            return True
        if not decision.session_id:
            return False
        decision_session = self.storage.get_session(decision.session_id)
        if decision_session is None:
            return False
        return decision_session.scope_id == session.scope_id

    @staticmethod
    def _scope_allows(
        scope_id: str | None,
        allowed_scope_ids: set[str],
        include_global: bool,
    ) -> bool:
        if scope_id is None:
            return include_global
        return scope_id in allowed_scope_ids
