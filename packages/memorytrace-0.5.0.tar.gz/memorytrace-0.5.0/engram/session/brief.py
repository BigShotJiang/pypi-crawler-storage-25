"""BriefBuilder — composes EntityBrief / SessionBrief from storage.

Design:
- Read-only against the storage backend. No side effects.
- Keeps all the JOIN-like logic (relations → names, conflicts → fact texts,
  sessions → entity IDs) out of the engine so the engine stays a thin
  orchestrator.
- Sorting / truncation rules are explicit and testable.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §1.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from engram.models.brief import (
    ConflictInfo,
    EntityBrief,
    EntityRef,
    FactRef,
    NoteInfo,
    RelatedEntity,
    SessionBrief,
    SessionRef,
)
from engram.models.fact import Fact
from engram.models.session import Session
from engram.session.context import list_masked_session_queries
from engram.session.working_memory import WorkingMemory
from engram.storage.base import StorageBackend


def _rank_facts(facts: list[Fact]) -> list[Fact]:
    """Sort facts by (confidence DESC, created_at DESC)."""
    return sorted(
        facts,
        key=lambda f: (f.confidence, f.created_at),
        reverse=True,
    )


class BriefBuilder:
    """Builds EntityBrief / SessionBrief objects from storage."""

    def __init__(self, storage: StorageBackend) -> None:
        self.storage = storage

    # ── Entity Brief ──

    def entity_brief(
        self,
        name: str,
        top_facts: int = 10,
        recent_notes: int = 5,
        recent_sessions: int = 3,
    ) -> Optional[EntityBrief]:
        """Build a brief for the entity named ``name``. Returns None if missing."""
        entity = self.storage.get_entity_by_name(name)
        if entity is None:
            return None

        # Top facts: current only, ranked by confidence then recency.
        all_current = self.storage.get_current_facts(entity.id)
        ranked = _rank_facts(all_current)
        top = ranked[:top_facts] if top_facts > 0 else ranked

        # Related entities: resolve relation targets to names.
        related = self._build_related(entity.id)

        # Recent notes: FTS-based. Notes don't have an entity_id column in the
        # schema, so we use the full-text index with the entity's canonical name.
        notes = self._find_notes_for_entity(entity.name, limit=recent_notes)

        # Recent sessions that touched this entity.
        sessions = self._find_sessions_touching_entity(
            entity.id, limit=recent_sessions
        )

        # Unresolved conflicts on any fact owned by this entity.
        conflicts = self._find_conflicts_for_entity(entity.id)

        return EntityBrief(
            entity=entity,
            top_facts=top,
            related_entities=related,
            recent_notes=notes,
            recent_sessions=sessions,
            unresolved_conflicts=conflicts,
            generated_at=datetime.now(),
        )

    def _build_related(self, entity_id: str) -> list[RelatedEntity]:
        """Resolve neighbor entities with a single batch SELECT.

        The previous revision fetched ``get_entity(other_id)`` once per
        relation — N+1 behaviour that dominates entity-brief latency for
        well-connected entities.
        """
        relations = self.storage.get_relations(entity_id)
        if not relations:
            return []

        # Pair each relation with the "other" endpoint and its direction.
        endpoints: list[tuple[str, str, str]] = []  # (other_id, direction, relation_type)
        for rel in relations:
            if rel.from_entity_id == entity_id:
                endpoints.append((rel.to_entity_id, "outgoing", rel.relation_type))
            else:
                endpoints.append((rel.from_entity_id, "incoming", rel.relation_type))

        conn = getattr(self.storage, "_conn", None)
        unique_ids = list({e[0] for e in endpoints})
        lookup: dict[str, dict] = {}
        if conn is not None and unique_ids:
            placeholders = ",".join("?" for _ in unique_ids)
            rows = conn.execute(
                f"SELECT id, name, entity_type FROM entities WHERE id IN ({placeholders})",
                unique_ids,
            ).fetchall()
            lookup = {r["id"]: r for r in rows}

        out: list[RelatedEntity] = []
        for other_id, direction, rel_type in endpoints:
            row = lookup.get(other_id)
            if row is None:
                continue
            out.append(
                RelatedEntity(
                    entity_id=row["id"],
                    name=row["name"],
                    entity_type=row["entity_type"],
                    relation_type=rel_type,
                    direction=direction,
                )
            )
        return out

    def _find_notes_for_entity(self, name: str, limit: int) -> list[NoteInfo]:
        if limit <= 0 or not name:
            return []
        search_fn = getattr(self.storage, "search_notes", None)
        like_fn = getattr(self.storage, "search_notes_like", None)
        raw: list[dict] = []
        if callable(search_fn):
            try:
                raw = list(search_fn(name, limit=limit) or [])
            except Exception:
                raw = []
        if not raw and callable(like_fn):
            try:
                raw = list(like_fn(name, limit=limit) or [])
            except Exception:
                raw = []
        out: list[NoteInfo] = []
        for row in raw[:limit]:
            created_at_raw = row.get("created_at")
            try:
                created_at = (
                    datetime.fromisoformat(created_at_raw)
                    if created_at_raw
                    else datetime.now()
                )
            except (TypeError, ValueError):
                created_at = datetime.now()
            out.append(
                NoteInfo(
                    note_id=row.get("id", ""),
                    text=row.get("text", ""),
                    created_at=created_at,
                    source_type=row.get("source_type", "user_input"),
                )
            )
        return out

    def _find_sessions_touching_entity(
        self, entity_id: str, limit: int
    ) -> list[SessionRef]:
        if limit <= 0:
            return []
        # Pull the most recent sessions across all agents via raw SQL because
        # StorageBackend.get_recent_sessions requires an agent_id.
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            return []
        pattern = f'%"{entity_id}"%'
        try:
            rows = conn.execute(
                """
                SELECT session_id, agent_id, started_at, ended_at, summary
                FROM sessions
                WHERE entities_accessed LIKE ?
                   OR entities_modified LIKE ?
                ORDER BY started_at DESC
                LIMIT ?
                """,
                (pattern, pattern, limit),
            ).fetchall()
        except Exception:
            return []
        out: list[SessionRef] = []
        for row in rows:
            started_raw = row["started_at"] if "started_at" in row.keys() else None
            ended_raw = row["ended_at"] if "ended_at" in row.keys() else None
            try:
                started_at = (
                    datetime.fromisoformat(started_raw)
                    if started_raw
                    else datetime.now()
                )
            except (TypeError, ValueError):
                started_at = datetime.now()
            ended_at: Optional[datetime]
            if ended_raw:
                try:
                    ended_at = datetime.fromisoformat(ended_raw)
                except (TypeError, ValueError):
                    ended_at = None
            else:
                ended_at = None
            out.append(
                SessionRef(
                    session_id=row["session_id"],
                    agent_id=row["agent_id"],
                    started_at=started_at,
                    ended_at=ended_at,
                    summary=row["summary"] if "summary" in row.keys() else None,
                )
            )
        return out

    def _find_conflicts_for_entity(self, entity_id: str) -> list[ConflictInfo]:
        pending = self._pending_conflicts_for_entity(entity_id)
        if not pending:
            return []
        fact_lookup = self._batch_lookup_facts(pending)
        return [
            self._build_conflict_info(
                c,
                fact_lookup.get(c.get("existing_fact_id") or ""),
                fact_lookup.get(c.get("new_fact_id") or ""),
            )
            for c in pending
        ]

    def _pending_conflicts_for_entity(self, entity_id: str) -> list[dict]:
        """Return unresolved conflicts touching ``entity_id`` only."""
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            pending = self.storage.get_pending_conflicts()
            if not pending:
                return []
            fact_lookup = self._batch_lookup_facts(pending)
            return [
                c for c in pending
                if (
                    fact_lookup.get(c.get("existing_fact_id") or "", {}).get("entity_id")
                    == entity_id
                )
                or (
                    fact_lookup.get(c.get("new_fact_id") or "", {}).get("entity_id")
                    == entity_id
                )
            ]
        rows = conn.execute(
            """
            SELECT DISTINCT c.*
            FROM conflicts c
            LEFT JOIN facts ef ON ef.id = c.existing_fact_id
            LEFT JOIN facts nf ON nf.id = c.new_fact_id
            WHERE c.resolved_at IS NULL
              AND (ef.entity_id = ? OR nf.entity_id = ?)
            """,
            (entity_id, entity_id),
        ).fetchall()
        return [dict(r) for r in rows]

    def _batch_lookup_facts(self, conflicts: list[dict]) -> dict[str, dict]:
        """Return ``{fact_id: row}`` for every fact referenced by the
        conflicts list, resolved in one SELECT.

        Keys that don't exist in the facts table are simply absent from the
        returned mapping — callers treat missing as "dangling reference".
        """
        fact_ids: set[str] = set()
        for c in conflicts:
            for key in ("existing_fact_id", "new_fact_id"):
                fid = c.get(key)
                if fid:
                    fact_ids.add(fid)
        if not fact_ids:
            return {}
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            return {}
        placeholders = ",".join("?" for _ in fact_ids)
        rows = conn.execute(
            f"SELECT id, entity_id, raw_text FROM facts WHERE id IN ({placeholders})",
            list(fact_ids),
        ).fetchall()
        return {r["id"]: r for r in rows}

    def _build_conflict_info(
        self, c: dict, existing, new
    ) -> ConflictInfo:
        created_at_raw = c.get("created_at")
        try:
            created_at = (
                datetime.fromisoformat(created_at_raw)
                if created_at_raw
                else None
            )
        except (TypeError, ValueError):
            created_at = None
        return ConflictInfo(
            conflict_id=c["id"],
            conflict_type=c.get("conflict_type", ""),
            suggested_resolution=c.get("suggested_resolution"),
            existing_fact_text=existing["raw_text"] if existing else None,
            new_fact_text=new["raw_text"] if new else None,
            created_at=created_at,
        )

    # ── Session Brief ──

    def session_brief(
        self,
        session_id: str,
        working_memory: Optional[WorkingMemory] = None,
        active_session: Optional[Session] = None,
    ) -> Optional[SessionBrief]:
        """Build a brief for the given session ID. Returns None if missing.

        If ``active_session`` is provided it takes precedence over the stored
        copy. This matters because ``SessionManager`` keeps live session state
        (entities_modified, facts_added, …) in memory and only flushes it on
        ``end_session``. Passing the active session lets us brief an ongoing
        conversation without losing any of that in-flight state.
        """
        session = active_session or self.storage.get_session(session_id)
        if session is None:
            return None

        modified = self._resolve_entity_refs(session.entities_modified)
        accessed = self._resolve_entity_refs(session.entities_accessed)
        facts = self._resolve_fact_refs(session.facts_added)

        active_wm: list[EntityRef] = []
        recent_queries = list_masked_session_queries(
            self.storage,
            session.session_id,
            limit=5,
        )
        if working_memory is not None:
            active_wm = self._resolve_entity_refs(
                working_memory.get_active_entity_ids()
            )

        open_conflicts = self._conflicts_for_session(session)

        return SessionBrief(
            session=session,
            entities_modified=modified,
            entities_accessed=accessed,
            facts_added=facts,
            active_working_memory=active_wm,
            recent_queries=recent_queries,
            open_conflicts=open_conflicts,
            generated_at=datetime.now(),
        )

    def _resolve_entity_refs(self, entity_ids: list[str]) -> list[EntityRef]:
        """Batch-resolve entity IDs to compact refs in input order, O(1) queries."""
        if not entity_ids:
            return []
        # Preserve caller order while de-duplicating.
        unique_ids = list(dict.fromkeys(entity_ids))
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            return []
        placeholders = ",".join("?" for _ in unique_ids)
        rows = conn.execute(
            f"SELECT id, name, entity_type FROM entities WHERE id IN ({placeholders})",
            unique_ids,
        ).fetchall()
        lookup = {r["id"]: r for r in rows}
        out: list[EntityRef] = []
        for eid in unique_ids:
            row = lookup.get(eid)
            if row is None:
                continue
            out.append(
                EntityRef(
                    entity_id=row["id"],
                    name=row["name"],
                    entity_type=row["entity_type"],
                )
            )
        return out

    def _resolve_fact_refs(self, fact_ids: list[str]) -> list[FactRef]:
        """Batch-resolve fact IDs in input order, O(1) queries."""
        if not fact_ids:
            return []
        unique_ids = list(dict.fromkeys(fact_ids))
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            return []
        placeholders = ",".join("?" for _ in unique_ids)
        rows = conn.execute(
            f"""SELECT f.id, f.subject, f.predicate, f.raw_text, f.confidence
                FROM facts f WHERE f.id IN ({placeholders})""",
            unique_ids,
        ).fetchall()
        lookup = {r["id"]: r for r in rows}
        out: list[FactRef] = []
        for fid in unique_ids:
            row = lookup.get(fid)
            if row is None:
                continue
            out.append(
                FactRef(
                    fact_id=row["id"],
                    entity_name=row["subject"],
                    predicate=row["predicate"],
                    text=row["raw_text"],
                    confidence=float(row["confidence"] or 0.0),
                )
            )
        return out

    def _conflicts_for_session(self, session: Session) -> list[ConflictInfo]:
        """Return conflicts where any involved fact was added in this session."""
        fact_ids = list(dict.fromkeys(session.facts_added))
        if not fact_ids:
            return []
        matching = self._pending_conflicts_for_fact_ids(fact_ids)
        if not matching:
            return []

        fact_lookup = self._batch_lookup_facts(matching)
        return [
            self._build_conflict_info(
                c,
                fact_lookup.get(c.get("existing_fact_id") or ""),
                fact_lookup.get(c.get("new_fact_id") or ""),
            )
            for c in matching
        ]

    def _pending_conflicts_for_fact_ids(self, fact_ids: list[str]) -> list[dict]:
        """Return unresolved conflicts whose endpoints intersect ``fact_ids``."""
        if not fact_ids:
            return []
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            return [
                c for c in self.storage.get_pending_conflicts()
                if c.get("existing_fact_id") in fact_ids
                or c.get("new_fact_id") in fact_ids
            ]
        placeholders = ",".join("?" for _ in fact_ids)
        rows = conn.execute(
            f"""
            SELECT c.*
            FROM conflicts c
            WHERE c.resolved_at IS NULL
              AND (
                c.existing_fact_id IN ({placeholders})
                OR c.new_fact_id IN ({placeholders})
              )
            """,
            fact_ids + fact_ids,
        ).fetchall()
        return [dict(r) for r in rows]
