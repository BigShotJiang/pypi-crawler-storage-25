"""Context carryover between sessions — resolves IDs to names, aggregates history."""

from __future__ import annotations

from collections import Counter
from typing import Optional

from engram.storage.base import StorageBackend


def list_masked_session_queries(
    storage: StorageBackend,
    session_id: str,
    *,
    limit: int = 5,
    allowed_scope_ids: set[str] | None = None,
    include_global: bool = False,
) -> list[str]:
    """Return recent persisted query targets for a session, newest first."""
    rows: list[str] = []
    seen: set[str] = set()
    for event in storage.get_session_events(session_id, limit=50):
        if allowed_scope_ids is not None and not _event_matches_scope(
            event,
            allowed_scope_ids=allowed_scope_ids,
            include_global=include_global,
        ):
            continue
        if event.event_type not in {"search", "notes_searched"}:
            continue
        if not event.target:
            continue
        if event.target in seen:
            continue
        seen.add(event.target)
        rows.append(event.target)
        if len(rows) >= limit:
            break
    return rows


def _event_matches_scope(
    event,
    *,
    allowed_scope_ids: set[str],
    include_global: bool,
) -> bool:
    allowed = event.detail.get("allowed_scope_ids")
    if not isinstance(allowed, list) or not allowed:
        return False
    event_scope_ids = {scope_id for scope_id in allowed if isinstance(scope_id, str) and scope_id}
    if not event_scope_ids:
        return False
    if not event_scope_ids.issubset(allowed_scope_ids):
        return False
    if bool(event.detail.get("include_global")) and not include_global:
        return False
    return True


def build_session_context(storage: StorageBackend, agent_id: str, session_limit: int = 5) -> dict:
    """Build a rich context summary for the start of a new session.

    Looks at the last N sessions (not just 1) to aggregate knowledge.
    Resolves entity IDs to human-readable names.
    """
    recent = storage.get_recent_sessions(agent_id, limit=session_limit)

    context: dict = {
        "entity_count": storage.entity_count(),
        "fact_count": storage.fact_count(),
        "pending_conflicts": len(storage.get_pending_conflicts()),
    }

    if not recent:
        context["previous_summary"] = ""
        context["previous_entities"] = []
        context["recent_topics"] = []
        context["sessions_reviewed"] = 0
        return context

    # Last completed session's summary
    last_completed = None
    for s in recent:
        if s.ended_at:
            last_completed = s
            break

    context["previous_summary"] = last_completed.summary if last_completed and last_completed.summary else ""

    # Aggregate entity access across recent sessions — resolve IDs to names
    entity_access_count: Counter = Counter()
    for s in recent:
        if s.ended_at:
            for eid in s.entities_accessed:
                entity_access_count[eid] += 1

    # Resolve top entity IDs to names
    top_entity_ids = [eid for eid, _ in entity_access_count.most_common(15)]
    resolved_entities: list[dict] = []
    resolved_entity_ids: list[str] = []
    for eid in top_entity_ids:
        entity = storage.get_entity(eid)
        if entity:
            resolved_entity_ids.append(eid)
            resolved_entities.append({
                "name": entity.name,
                "type": entity.entity_type,
                "access_count": entity_access_count[eid],
            })

    context["previous_entities"] = [e["name"] for e in resolved_entities]
    context["recent_entity_details"] = resolved_entities

    # Include top facts for the most important entities (actual knowledge, not just names)
    key_facts: list[dict] = []
    for eid, entity_info in zip(resolved_entity_ids[:5], resolved_entities[:5]):
        facts = storage.get_current_facts(eid)
        top_facts = sorted(facts, key=lambda f: f.confidence, reverse=True)[:3]
        for f in top_facts:
            key_facts.append({
                "entity": entity_info["name"],
                "fact": f.raw_text,
                "confidence": f.confidence,
            })
    context["key_facts"] = key_facts

    # Collect recent topics from session summaries
    recent_topics: list[str] = []
    for s in recent:
        if s.ended_at and s.summary:
            recent_topics.append(s.summary)
    context["recent_topics"] = recent_topics[:5]
    context["sessions_reviewed"] = len([s for s in recent if s.ended_at])

    return context
