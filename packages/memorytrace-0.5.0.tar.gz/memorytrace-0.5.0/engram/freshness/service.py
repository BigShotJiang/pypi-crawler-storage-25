"""Freshness lifecycle and verification backlog service."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.fact import Fact, FactStatus
from engram.models.verification import (
    FreshnessAssessment,
    VerificationRequest,
    VerificationRequestStatus,
    VerificationResolution,
    VerificationStatus,
)
from engram.quality.decay_policy import DecayPolicy
from engram.storage.sqlite_store import SQLiteStorage


class FreshnessService:
    """Own due-date assessment and verification request lifecycle."""

    def __init__(
        self,
        storage: SQLiteStorage,
        decay_policy: Optional[DecayPolicy] = None,
    ) -> None:
        self.storage = storage
        self.decay_policy = decay_policy or DecayPolicy()

    def assess_fact(self, fact: Fact) -> FreshnessAssessment:
        due_at = fact.verification_due_at or self._fact_due_at(fact)
        due = due_at is not None and due_at <= datetime.now()
        if fact.verification_status is VerificationStatus.PENDING:
            return FreshnessAssessment(
                status=VerificationStatus.PENDING,
                due=due,
                stale=due,
                penalty=-0.10,
                reason="fact has an open verification request",
                warning="Fact is waiting for verification.",
                should_open_request=False,
            )
        if fact.verification_status is VerificationStatus.STALE or due:
            return FreshnessAssessment(
                status=VerificationStatus.STALE,
                due=due,
                stale=True,
                penalty=-0.30,
                reason="fact verification is stale",
                warning="Fact is stale and should be re-verified.",
                should_open_request=True,
            )
        if fact.verification_status is VerificationStatus.VERIFIED:
            return FreshnessAssessment(
                status=VerificationStatus.VERIFIED,
                due=due,
            )
        return FreshnessAssessment(
            status=VerificationStatus.UNKNOWN,
            due=due,
            stale=due,
            penalty=-0.30 if due else 0.0,
            reason="fact freshness is unknown" if due else "",
            warning="Fact has not been verified recently." if due else "",
            should_open_request=due,
        )

    def assess_decision(self, decision: DecisionRecord) -> FreshnessAssessment:
        due_at = decision.verification_due_at or self._decision_due_at(decision)
        due = due_at is not None and due_at <= datetime.now()
        if decision.verification_status is VerificationStatus.PENDING:
            return FreshnessAssessment(
                status=VerificationStatus.PENDING,
                due=due,
                stale=due,
                penalty=0.0,
                reason="decision has an open verification request",
                warning="Decision is waiting for verification.",
                should_open_request=False,
            )
        if decision.verification_status is VerificationStatus.STALE or due:
            return FreshnessAssessment(
                status=VerificationStatus.STALE,
                due=due,
                stale=True,
                penalty=0.0,
                reason="decision verification is stale",
                warning="Decision is stale and should be reviewed.",
                should_open_request=True,
            )
        if decision.verification_status is VerificationStatus.VERIFIED:
            return FreshnessAssessment(status=VerificationStatus.VERIFIED, due=due)
        return FreshnessAssessment(
            status=VerificationStatus.UNKNOWN,
            due=due,
            stale=due,
            warning="Decision has not been verified recently." if due else "",
            should_open_request=due,
        )

    def ensure_fact_request(
        self,
        fact: Fact,
        *,
        reason: str,
        requested_by: str,
    ) -> VerificationRequest:
        existing = self.storage.find_open_verification_request("fact", fact.id)
        if existing is not None:
            return existing
        request = VerificationRequest(
            target_kind="fact",
            target_id=fact.id,
            entity_id=fact.entity_id,
            scope_id=fact.scope_id,
            reason=reason,
            requested_by=requested_by,
        )
        self.storage.create_verification_request(request)
        self.storage.update_fact_freshness(
            fact.id,
            verification_status=VerificationStatus.PENDING.value,
            last_verified_at=(
                fact.last_verified_at.isoformat() if fact.last_verified_at else None
            ),
            verification_due_at=self._fact_due_at(fact).isoformat(),
        )
        return request

    def ensure_decision_request(
        self,
        decision: DecisionRecord,
        *,
        reason: str,
        requested_by: str,
    ) -> VerificationRequest:
        existing = self.storage.find_open_verification_request("decision", decision.id)
        if existing is not None:
            return existing
        request = VerificationRequest(
            target_kind="decision",
            target_id=decision.id,
            entity_id=decision.entity_id,
            scope_id=self._decision_scope_id(decision),
            reason=reason,
            requested_by=requested_by,
        )
        self.storage.create_verification_request(request)
        due_at = self._decision_due_at(decision)
        self.storage.update_decision_freshness(
            decision.id,
            verification_status=VerificationStatus.PENDING.value,
            last_verified_at=(
                decision.last_verified_at.isoformat()
                if decision.last_verified_at
                else None
            ),
            verification_due_at=due_at.isoformat() if due_at is not None else None,
        )
        return request

    def list_requests(
        self,
        *,
        status: Optional[VerificationRequestStatus] = None,
        target_kind: Optional[str] = None,
        limit: int = 50,
    ) -> list[VerificationRequest]:
        return self.storage.list_verification_requests(
            status=status,
            target_kind=target_kind,
            limit=limit,
        )

    def get_request(self, request_id: str) -> Optional[VerificationRequest]:
        return self.storage.get_verification_request(request_id)

    def resolve_request(
        self,
        request_id: str,
        resolution: VerificationResolution,
        detail: str = "",
    ) -> VerificationRequest:
        request = self.storage.get_verification_request(request_id)
        if request is None:
            raise ValueError(f"Verification request '{request_id}' not found")
        if request.status is not VerificationRequestStatus.OPEN:
            raise ValueError(f"Verification request '{request_id}' is not open")

        if request.target_kind == "fact":
            self._resolve_fact_request(request, resolution)
        elif request.target_kind == "decision":
            self._resolve_decision_request(request, resolution)
        else:
            raise ValueError(f"Unsupported verification target '{request.target_kind}'")

        request.status = VerificationRequestStatus.RESOLVED
        request.resolution = resolution
        request.detail = detail
        request.resolved_at = datetime.now()
        return self.storage.update_verification_request(request)

    def mark_fact_verified(self, fact_id: str) -> Fact:
        fact = self.storage.get_fact(fact_id)
        if fact is None:
            raise ValueError(f"Fact '{fact_id}' not found")
        now = datetime.now()
        fact.verification_status = VerificationStatus.VERIFIED
        fact.last_verified_at = now
        fact.verification_due_at = self._fact_due_at(fact, reference_time=now)
        return self.storage.update_fact(fact)

    def mark_decision_verified(self, decision_id: str) -> DecisionRecord:
        decision = self.storage.get_decision(decision_id)
        if decision is None:
            raise ValueError(f"Decision '{decision_id}' not found")
        now = datetime.now()
        decision.verification_status = VerificationStatus.VERIFIED
        decision.last_verified_at = now
        decision.verification_due_at = self._decision_due_at(decision, reference_time=now)
        return self.storage.update_decision(decision)

    def _resolve_fact_request(
        self,
        request: VerificationRequest,
        resolution: VerificationResolution,
    ) -> None:
        fact = self.storage.get_fact(request.target_id)
        if fact is None:
            raise ValueError(f"Fact '{request.target_id}' not found")
        now = datetime.now()
        if resolution is VerificationResolution.VERIFIED:
            fact.verification_status = VerificationStatus.VERIFIED
            fact.last_verified_at = now
            fact.verification_due_at = self._fact_due_at(fact, reference_time=now)
        elif resolution is VerificationResolution.STALE:
            fact.verification_status = VerificationStatus.STALE
        elif resolution is VerificationResolution.RETRACTED:
            fact.verification_status = VerificationStatus.STALE
            fact.status = FactStatus.RETRACTED
        else:
            raise ValueError(f"Unsupported fact resolution '{resolution.value}'")
        self.storage.update_fact(fact)

    def _resolve_decision_request(
        self,
        request: VerificationRequest,
        resolution: VerificationResolution,
    ) -> None:
        decision = self.storage.get_decision(request.target_id)
        if decision is None:
            raise ValueError(f"Decision '{request.target_id}' not found")
        now = datetime.now()
        if resolution is VerificationResolution.VERIFIED:
            decision.verification_status = VerificationStatus.VERIFIED
            decision.last_verified_at = now
            decision.verification_due_at = self._decision_due_at(
                decision,
                reference_time=now,
            )
        elif resolution is VerificationResolution.STALE:
            decision.verification_status = VerificationStatus.STALE
        elif resolution is VerificationResolution.SUPERSEDED:
            decision.verification_status = VerificationStatus.STALE
            decision.status = DecisionStatus.SUPERSEDED
            decision.verification_due_at = None
        else:
            raise ValueError(f"Unsupported decision resolution '{resolution.value}'")
        self.storage.update_decision(decision)

    def _fact_due_at(
        self,
        fact: Fact,
        *,
        reference_time: Optional[datetime] = None,
    ) -> datetime:
        reference = reference_time or fact.last_verified_at or fact.created_at
        return reference + timedelta(
            days=self.decay_policy.stale_cutoff_days(fact.memory_type)
        )

    def _decision_due_at(
        self,
        decision: DecisionRecord,
        *,
        reference_time: Optional[datetime] = None,
    ) -> Optional[datetime]:
        if decision.status is DecisionStatus.SUPERSEDED:
            return None
        days = 30 if decision.status is DecisionStatus.ACTIVE else 14
        reference = reference_time or decision.last_verified_at or decision.created_at
        return reference + timedelta(days=days)

    def _decision_scope_id(self, decision: DecisionRecord) -> Optional[str]:
        if decision.session_id is None:
            return None
        session = self.storage.get_session(decision.session_id)
        return session.scope_id if session is not None else None

