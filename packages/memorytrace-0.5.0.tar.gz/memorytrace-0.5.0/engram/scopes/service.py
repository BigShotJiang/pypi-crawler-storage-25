"""Namespace resolution and lifecycle helpers."""

from __future__ import annotations

from datetime import datetime

from engram.models.scope import MemoryScope, ResolvedScope, ScopeSelection
from engram.storage.sqlite_store import SQLiteStorage


class ScopeService:
    """Manage hierarchical memory scopes."""

    def __init__(self, storage: SQLiteStorage):
        self.storage = storage

    def create(
        self,
        kind: str,
        name: str,
        parent_scope_id: str | None = None,
        metadata: dict | None = None,
    ) -> MemoryScope:
        if "/" in name:
            raise ValueError("Scope name must not contain '/'")
        parent = self.storage.get_scope(parent_scope_id) if parent_scope_id else None
        path = f"{parent.path}/{name}" if parent else name
        if self.storage.find_scope_by_kind_path(kind, path) is not None:
            raise ValueError(f"Scope {kind}:{path} already exists")
        now = datetime.now()
        scope = MemoryScope(
            kind=kind,
            name=name,
            path=path,
            parent_scope_id=parent_scope_id,
            metadata=dict(metadata or {}),
            created_at=now,
            updated_at=now,
        )
        return self.storage.create_scope(scope)

    def get(self, scope_id: str) -> MemoryScope | None:
        return self.storage.get_scope(scope_id)

    def list(
        self,
        *,
        kind: str | None = None,
        parent_scope_id: str | None = None,
        include_archived: bool = False,
    ) -> list[MemoryScope]:
        return self.storage.list_scopes(
            kind=kind,
            parent_scope_id=parent_scope_id,
            include_archived=include_archived,
        )

    def resolve_selection(
        self,
        selection: ScopeSelection | None,
    ) -> ResolvedScope:
        if selection is None or selection.primary_scope_id is None:
            return ResolvedScope(primary_scope_id=None, allowed_scope_ids=[])
        allowed = [selection.primary_scope_id]
        if selection.include_ancestors:
            allowed.extend(self.storage.list_scope_ancestor_ids(selection.primary_scope_id))
        allowed.extend(selection.fallback_scope_ids)
        if selection.include_global:
            global_scope = self.storage.find_scope_by_kind_path("global", "global")
            if global_scope is not None:
                allowed.append(global_scope.id)
        deduped = list(dict.fromkeys(scope_id for scope_id in allowed if scope_id))
        return ResolvedScope(
            primary_scope_id=selection.primary_scope_id,
            allowed_scope_ids=deduped,
        )
