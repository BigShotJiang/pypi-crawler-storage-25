"""CLI interface for Engram."""
