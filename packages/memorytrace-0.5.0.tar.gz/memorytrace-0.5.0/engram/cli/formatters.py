"""Human-readable output formatters for CLI."""

from __future__ import annotations

from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.search import SearchResult
from engram.engine import StoreResult


def format_entity(entity: Entity, facts: list[Fact] = None) -> str:
    """Format an entity for CLI display."""
    lines = [f"  {entity.name} [{entity.entity_type}] (tier: {entity.tier.value})"]
    if entity.state.role:
        lines.append(f"    Role: {entity.state.role}")
    if entity.state.affiliation:
        lines.append(f"    Affiliation: {entity.state.affiliation}")
    if entity.summary:
        lines.append(f"    Summary: {entity.summary}")
    if facts:
        lines.append(f"    Facts: {len(facts)}")
        for f in facts[:5]:
            conf = f"[{f.confidence:.0%}]"
            lines.append(f"      - {f.raw_text} {conf}")
    return "\n".join(lines)


def format_entity_list(entities: list[Entity]) -> str:
    """Format a list of entities for CLI display."""
    if not entities:
        return "  No entities found."
    lines = []
    for e in entities:
        tier_tag = f"[{e.tier.value}]"
        type_tag = f"({e.entity_type})"
        lines.append(f"  {e.name} {type_tag} {tier_tag}")
    return "\n".join(lines)


def format_search_result(result: SearchResult) -> str:
    """Format search results for CLI display."""
    if not result.hits:
        return f"  No results for '{result.query}'."

    lines = [f"  Found {result.total_count} result(s) for '{result.query}' ({result.search_time_ms:.1f}ms)"]
    lines.append("")
    for i, hit in enumerate(result.hits, 1):
        score = f"[{hit.relevance_score:.2f}]"
        lines.append(f"  {i}. {hit.entity.name} ({hit.entity.entity_type}) {score}")
        if hit.snippet:
            lines.append(f"     {hit.snippet[:120]}")
        if hit.facts:
            for f in hit.facts[:3]:
                lines.append(f"     - {f.raw_text}")
        lines.append("")
    return "\n".join(lines)


def format_store_result(result: StoreResult) -> str:
    """Format store operation result for CLI display."""
    parts = []
    if result.entities_created:
        names = ", ".join(e.name for e in result.entities_created)
        parts.append(f"  Created {len(result.entities_created)} entity(s): {names}")
    if result.entities_updated:
        names = ", ".join(e.name for e in result.entities_updated)
        parts.append(f"  Updated {len(result.entities_updated)} entity(s): {names}")
    if result.facts_added:
        parts.append(f"  Added {len(result.facts_added)} fact(s)")
    if result.facts_quarantined:
        parts.append(f"  Quarantined {len(result.facts_quarantined)} fact(s) (low confidence)")
    if result.facts_conflicted:
        parts.append(f"  Conflicted {len(result.facts_conflicted)} fact(s)")
    if result.relations_added:
        parts.append(f"  Added {len(result.relations_added)} relation(s)")

    if not parts:
        return "  No entities or facts extracted."
    return "\n".join(parts)


def format_health(health: dict) -> str:
    """Format health check result."""
    lines = [
        f"  Entities: {health['entity_count']}",
        f"  Facts: {health['fact_count']}",
        f"  Pending conflicts: {health['pending_conflicts']}",
        f"  Status: {health['status']}",
    ]
    return "\n".join(lines)
