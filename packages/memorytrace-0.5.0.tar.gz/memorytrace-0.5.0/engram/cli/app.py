"""CLI entry point for Engram."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.decision import DecisionStatus
from engram.models.entity import Tier
from engram.models.governance import GovernanceCandidateStatus, GovernanceCandidateType, GovernanceResolution
from engram.models.retention import RetentionPolicyType, RetentionTargetKind
from engram.models.search import SearchOptions
from engram.models.scope import ScopeSelection
from engram.models.source import Source, SourceType
from engram.models.verification import VerificationRequestStatus
from engram.safety.paths import read_text_safely as _read_intake_file_impl


def _read_intake_file(path_str: str, allow_unsafe: bool) -> str:
    """Thin shim kept so existing tests keep importing from engram.cli.app.

    The real policy now lives in :mod:`engram.safety.paths` so the restore
    side of the snapshot feature can share it.
    """
    return _read_intake_file_impl(path_str, allow_unsafe=allow_unsafe)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="engram",
        description="Engram — AI agent memory system",
    )
    parser.add_argument("--db", default=None, help="Database path")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--quiet", action="store_true", help="Suppress non-essential output")
    parser.add_argument("--verbose", action="store_true", help="Show detailed error info")

    sub = parser.add_subparsers(dest="command")

    # init
    sub.add_parser("init", help="Initialize memory database")

    _source_choices = ["user_input", "direct_speech", "document", "api", "web", "agent_inference"]

    # store
    p = sub.add_parser("store", help="Extract and store information from text")
    p.add_argument("text", nargs="?", help="Text to process (or read from stdin)")
    p.add_argument("--source-type", default="user_input", choices=_source_choices, help="Source type")
    p.add_argument("--confidence", type=float, default=1.0, help="Source confidence")
    p.add_argument("--author", default="", help="Source author")
    p.add_argument("--scope-id", default=None, help="Attach stored memory to a scope ID")

    # search
    p = sub.add_parser("search", help="Search memory")
    p.add_argument("query", help="Search query")
    p.add_argument("--max-results", type=int, default=10)
    p.add_argument("--max-tokens", type=int, default=500)
    p.add_argument("--min-confidence", type=float, default=0.0)
    p.add_argument("--type", dest="entity_type", default="")
    p.add_argument("--tier", default="")
    p.add_argument(
        "--context-tag",
        action="append",
        default=[],
        help="Filter facts by applicability tag (repeatable)",
    )
    p.add_argument("--scope-id", default=None, help="Restrict search to a scope ID")

    # context-search
    p = sub.add_parser("context-search", help="Search memory plus related context")
    p.add_argument("query", help="Search query")
    p.add_argument("--goal", default="general")
    p.add_argument(
        "--plan-query",
        action="store_true",
        help="Split compound queries into focused fragments before expansion",
    )
    p.add_argument(
        "--context-tag",
        action="append",
        default=[],
        help="Filter facts by applicability tag (repeatable)",
    )
    p.add_argument("--expand-hops", type=int, default=1)
    p.add_argument("--max-results", type=int, default=5)
    p.add_argument("--max-related", type=int, default=10)
    p.add_argument("--max-tokens", type=int, default=800)
    p.add_argument("--scope-id", default=None, help="Restrict search to a scope ID")

    # query-plan
    p = sub.add_parser("query-plan", help="Build an Engram query plan for a compound lookup")
    p.add_argument("query", help="Search query")

    # context-pack
    p = sub.add_parser("context-pack", help="Build a reusable context pack from a session")
    p.add_argument("session_id")
    p.add_argument("--goal", default="task_handoff")
    p.add_argument("--max-chars", type=int, default=4000)

    # context-transfer
    p = sub.add_parser("context-transfer", help="Create a target session from a source-session handoff")
    p.add_argument("session_id")
    p.add_argument("to_agent_id")
    p.add_argument("--note", default="")
    p.add_argument("--goal", default="task_handoff")
    p.add_argument("--scope-id", default=None, help="Optionally narrow the inherited scope")

    # get
    p = sub.add_parser("get", help="Get entity details")
    p.add_argument("name", help="Entity name")

    # list
    p = sub.add_parser("list", help="List entities")
    p.add_argument("--type", dest="entity_type", default="")
    p.add_argument("--tier", default="")
    p.add_argument("--limit", type=int, default=50)

    # add-fact
    p = sub.add_parser("add-fact", help="Add a fact to an entity")
    p.add_argument("entity", help="Entity name")
    p.add_argument("fact", help="Fact text")
    p.add_argument("--predicate", default="attribute")
    p.add_argument("--source-type", default="user_input", choices=_source_choices)
    p.add_argument("--confidence", type=float, default=1.0)
    p.add_argument(
        "--applies-if",
        action="append",
        default=[],
        help="Applicability tag required for this fact (repeatable)",
    )
    p.add_argument(
        "--except-if",
        action="append",
        default=[],
        help="Applicability tag that excludes this fact (repeatable)",
    )

    # create
    p = sub.add_parser("create", help="Create a new entity")
    p.add_argument("name", help="Entity name")
    p.add_argument("--type", dest="entity_type", default="person")
    p.add_argument("--tier", default="recall")
    p.add_argument("--summary", default="")

    # conflicts
    sub.add_parser("conflicts", help="Show pending conflicts")

    # resolve
    p = sub.add_parser("resolve", help="Resolve a conflict")
    p.add_argument("conflict_id", help="Conflict ID")
    p.add_argument("resolution", choices=["accept_new", "keep_old", "merge"])

    # brief
    p = sub.add_parser("brief", help="Build a compact context brief for an entity")
    p.add_argument("name", help="Entity name")
    p.add_argument("--top-facts", type=int, default=10, help="Max facts to include")
    p.add_argument("--recent-notes", type=int, default=5, help="Max notes to include")
    p.add_argument("--recent-sessions", type=int, default=3, help="Max sessions to include")
    p.add_argument("--max-chars", type=int, default=4000, help="Soft char cap for text rendering")
    p.add_argument("--scope-id", default=None, help="Restrict supporting search to a scope ID")

    # session-brief
    p = sub.add_parser("session-brief", help="Build a brief for a session")
    p.add_argument("session_id", help="Session ID")
    p.add_argument("--max-chars", type=int, default=4000, help="Soft char cap for text rendering")
    p.add_argument("--scope-id", default=None, help="Restrict supporting search to a scope ID")

    # health
    sub.add_parser("health", help="Run health checks")

    # health-report
    p = sub.add_parser("health-report", help="Full health report with open loops")
    p.add_argument("--max-loops", type=int, default=50)
    p.add_argument("--stale-days", type=int, default=None)
    p.add_argument("--max-chars", type=int, default=4000)

    # intake
    p = sub.add_parser(
        "intake",
        help="Extract candidates into staging (dry-run by default; main DB untouched)",
    )
    p.add_argument("text", nargs="?", help="Text to triage (or read from stdin)")
    p.add_argument("--from-file", default=None, help="Read text from file")
    p.add_argument(
        "--unsafe-path",
        action="store_true",
        help=(
            "Skip the sensitive-path blocklist for --from-file. Required when "
            "the file sits under paths like ~/.ssh or has a .pem/.key extension."
        ),
    )
    p.add_argument(
        "--source-type", default="user_input", choices=_source_choices,
    )
    p.add_argument("--author", default="")
    p.add_argument(
        "--apply",
        action="store_true",
        help="Immediately apply all candidates after staging",
    )

    # intake-list
    p = sub.add_parser("intake-list", help="List recent intake batches")
    p.add_argument("--status", default=None, choices=["pending", "applied", "rejected", "mixed"])
    p.add_argument("--limit", type=int, default=20)

    # intake-show
    p = sub.add_parser("intake-show", help="Show a batch and its candidates")
    p.add_argument("batch_id")

    # intake-apply
    p = sub.add_parser("intake-apply", help="Apply pending candidates through quality gate")
    p.add_argument("batch_id")
    p.add_argument(
        "--candidate",
        action="append",
        default=None,
        help="Restrict to specific candidate IDs (repeatable)",
    )

    # intake-reject
    p = sub.add_parser("intake-reject", help="Reject candidates (whole batch by default)")
    p.add_argument("batch_id")
    p.add_argument(
        "--candidate",
        action="append",
        default=None,
        help="Restrict to specific candidate IDs (repeatable)",
    )

    # snapshot-create
    p = sub.add_parser(
        "snapshot-create",
        help="Take a compressed point-in-time backup of the live DB",
    )
    p.add_argument("--label", default=None)
    p.add_argument("--description", default=None)

    # snapshot-list
    p = sub.add_parser("snapshot-list", help="List snapshots (most recent first)")
    p.add_argument("--limit", type=int, default=50)

    # snapshot-show
    p = sub.add_parser("snapshot-show", help="Show a snapshot manifest")
    p.add_argument("snapshot_id")

    # snapshot-delete
    p = sub.add_parser("snapshot-delete", help="Delete a snapshot (file + manifest row)")
    p.add_argument("snapshot_id")

    # snapshot-diff
    p = sub.add_parser("snapshot-diff", help="Diff two snapshots (A → B)")
    p.add_argument("a_id")
    p.add_argument("b_id")

    # snapshot-search
    p = sub.add_parser(
        "snapshot-search",
        help="Run a search against a snapshot — time travel",
    )
    p.add_argument("snapshot_id")
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=10)

    # snapshot-entity
    p = sub.add_parser(
        "snapshot-entity",
        help="Fetch an entity as of a snapshot (with current facts then)",
    )
    p.add_argument("snapshot_id")
    p.add_argument("name")

    # snapshot-restore
    p = sub.add_parser(
        "snapshot-restore",
        help="Decompress a snapshot to a target .db path (does NOT replace main DB)",
    )
    p.add_argument("snapshot_id")
    p.add_argument("target_path")
    p.add_argument(
        "--unsafe-path",
        action="store_true",
        help="Bypass the path-safety blocklist (needed to restore near secrets)",
    )

    # debug-start
    p = sub.add_parser("debug-start", help="Start a debug session (OBSERVE phase)")
    p.add_argument("description", help="Bug description")
    p.add_argument("--related-session", default=None, help="Link to an engram session ID")

    # debug-hypothesis
    p = sub.add_parser("debug-hypothesis", help="Add a hypothesis to a debug session")
    p.add_argument("debug_session_id")
    p.add_argument("text", help="Hypothesis text")
    p.add_argument("--confidence", type=float, default=0.5)

    # debug-evidence
    p = sub.add_parser("debug-evidence", help="Log evidence against a hypothesis")
    p.add_argument("hypothesis_id")
    p.add_argument("text", help="Observation text")
    p.add_argument(
        "--result",
        default="neutral",
        choices=["supports", "contradicts", "neutral"],
    )
    p.add_argument("--kind", default="observation")

    # debug-reject
    p = sub.add_parser("debug-reject", help="Reject a hypothesis with a reason")
    p.add_argument("hypothesis_id")
    p.add_argument("reason", help="Why it was rejected")

    # debug-confirm
    p = sub.add_parser("debug-confirm", help="Confirm a hypothesis")
    p.add_argument("hypothesis_id")

    # debug-conclude
    p = sub.add_parser("debug-conclude", help="Close a debug session")
    p.add_argument("debug_session_id")
    p.add_argument("conclusion", nargs="?", default=None)
    p.add_argument(
        "--status", default="resolved", choices=["resolved", "abandoned"]
    )

    # debug-list
    p = sub.add_parser("debug-list", help="List debug sessions")
    p.add_argument("--status", default=None, choices=["open", "resolved", "abandoned"])
    p.add_argument("--limit", type=int, default=20)

    # debug-show
    p = sub.add_parser("debug-show", help="Show a debug session with hypotheses and evidence")
    p.add_argument("debug_session_id")
    p.add_argument("--max-chars", type=int, default=6000)

    # debug-search
    p = sub.add_parser(
        "debug-search",
        help="Search past hypotheses — catch repeats of rejected theories",
    )
    p.add_argument("query", help="Substring pattern")
    p.add_argument("--status", default=None, choices=["open", "confirmed", "rejected", "abandoned"])
    p.add_argument("--limit", type=int, default=20)

    # open-loops
    p = sub.add_parser("open-loops", help="List actionable open loops")
    p.add_argument(
        "--kind",
        default=None,
        choices=["conflict", "stale_fact", "orphan_entity", "missing_source", "projection_drift"],
        help="Filter by open-loop kind",
    )
    p.add_argument("--max", type=int, default=50)

    # backlinks
    p = sub.add_parser("backlinks", help="List source references for an entity")
    p.add_argument("name")
    p.add_argument("--kind", default=None, choices=["note", "session", "debug_session", "debug_hypothesis", "debug_evidence"])
    p.add_argument("--limit", type=int, default=50)

    # decisions
    p = sub.add_parser("decisions", help="List structured decisions")
    p.add_argument("--entity", default=None)
    p.add_argument("--status", default=None, choices=["active", "superseded", "draft"])
    p.add_argument("--limit", type=int, default=20)

    # decision-show
    p = sub.add_parser("decision-show", help="Show one decision")
    p.add_argument("decision_id")

    # maintenance-run
    p = sub.add_parser("maintenance-run", help="Persist a maintenance snapshot")
    p.add_argument("--max-loops", type=int, default=50)
    p.add_argument("--stale-days", type=int, default=None)

    # operations-review
    p = sub.add_parser("operations-review", help="Persist maintenance and summarize current operations state")
    p.add_argument("--max-loops", type=int, default=50)
    p.add_argument("--stale-days", type=int, default=None)
    p.add_argument("--run-jobs", action="store_true")
    p.add_argument("--job-limit", type=int, default=20)

    # maintenance-list
    p = sub.add_parser("maintenance-list", help="List persisted maintenance runs")
    p.add_argument("--limit", type=int, default=20)

    # maintenance-show
    p = sub.add_parser("maintenance-show", help="Show one persisted maintenance run")
    p.add_argument("run_id")

    # verification
    p = sub.add_parser("verification-list", help="List verification requests")
    p.add_argument("--status", choices=["open", "resolved", "cancelled"], default=None)
    p.add_argument("--target-kind", choices=["fact", "decision"], default=None)
    p.add_argument("--limit", type=int, default=50)

    p = sub.add_parser("verification-show", help="Show one verification request")
    p.add_argument("request_id")

    p = sub.add_parser("verification-request", help="Open a verification request")
    p.add_argument("target_kind", choices=["fact", "decision"])
    p.add_argument("target_id")
    p.add_argument("--reason", default="manual")

    p = sub.add_parser("verification-resolve", help="Resolve a verification request")
    p.add_argument("request_id")
    p.add_argument("resolution", choices=["verified", "stale", "retracted", "superseded"])
    p.add_argument("--detail", default="")

    # governance
    p = sub.add_parser("governance-run", help="Generate entity governance candidates")
    p.add_argument("--limit", type=int, default=100)

    p = sub.add_parser("governance-list", help="List governance candidates")
    p.add_argument("--status", choices=["open", "approved", "rejected", "applied", "cancelled"], default=None)
    p.add_argument("--type", dest="candidate_type", choices=["merge", "alias", "split"], default=None)
    p.add_argument("--limit", type=int, default=50)

    p = sub.add_parser("governance-show", help="Show one governance candidate")
    p.add_argument("candidate_id")

    p = sub.add_parser("governance-resolve", help="Approve or reject a governance candidate")
    p.add_argument("candidate_id")
    p.add_argument("resolution", choices=["approve", "reject"])

    # scopes
    p = sub.add_parser("scope-create", help="Create a memory scope")
    p.add_argument("kind")
    p.add_argument("name")
    p.add_argument("--parent-scope-id", default=None)

    p = sub.add_parser("scope-list", help="List memory scopes")
    p.add_argument("--kind", default=None)
    p.add_argument("--parent-scope-id", default=None)
    p.add_argument("--include-archived", action="store_true")

    p = sub.add_parser("scope-show", help="Show one scope")
    p.add_argument("scope_id")

    # jobs
    p = sub.add_parser("jobs-list", help="List background jobs")
    p.add_argument("--status", default=None)
    p.add_argument("--type", dest="job_type", default=None)
    p.add_argument("--limit", type=int, default=20)

    p = sub.add_parser("job-show", help="Show one background job")
    p.add_argument("job_id")

    p = sub.add_parser("jobs-run", help="Lease and execute queued jobs")
    p.add_argument("--limit", type=int, default=20)

    # retention
    p = sub.add_parser("retention-set", help="Set a retention policy on a target")
    p.add_argument("target_kind", choices=["entity", "fact", "decision", "note", "session"])
    p.add_argument("target_id")
    p.add_argument("policy_type", choices=["pin", "ttl", "archive_only", "never_summarize"])
    p.add_argument("--value", default=None)
    p.add_argument("--reason", default="")

    p = sub.add_parser("retention-list", help="List retention policies")
    p.add_argument("--target-kind", choices=["entity", "fact", "decision", "note", "session"], default=None)
    p.add_argument("--target-id", default=None)
    p.add_argument("--policy-type", choices=["pin", "ttl", "archive_only", "never_summarize"], default=None)
    p.add_argument("--limit", type=int, default=100)

    p = sub.add_parser("retention-clear", help="Clear a retention policy")
    p.add_argument("target_kind", choices=["entity", "fact", "decision", "note", "session"])
    p.add_argument("target_id")
    p.add_argument("policy_type", choices=["pin", "ttl", "archive_only", "never_summarize"])

    # recommendations
    p = sub.add_parser("recommendations", help="List computed recommendations")
    p.add_argument("--kind", choices=["stale_decision", "open_loop_escalation", "merge_recommendation", "follow_up_task"], default=None)
    p.add_argument("--limit", type=int, default=50)

    p = sub.add_parser("recommendation-show", help="Show one computed recommendation")
    p.add_argument("recommendation_id")

    # projection rebuilds
    sub.add_parser("rebuild-references", help="Rebuild backlinks projection")
    sub.add_parser("rebuild-decisions", help="Rebuild decisions projection")
    sub.add_parser("rebuild-projections", help="Rebuild all projection tables")

    # export
    p = sub.add_parser("export", help="Export to Markdown")
    p.add_argument("--dir", default=None, help="Export directory")

    # reindex
    sub.add_parser("reindex", help="Rebuild search index")

    # reclassify
    p = sub.add_parser("reclassify", help="Re-run memory-type classifier over facts")
    p.add_argument("entity", nargs="?", default=None, help="Limit to one entity (default: all)")
    p.add_argument(
        "--all-facts",
        action="store_true",
        help="Overwrite existing non-default classifications too",
    )

    # serve
    p = sub.add_parser("serve", help="Start MCP server")
    p.add_argument("--transport", default="stdio", choices=["stdio"])
    p.add_argument("--port", type=int, default=8080)

    return parser


def _make_engine(args) -> MemoryEngine:
    """Create engine from CLI args."""
    config = EngramConfig()
    if args.db:
        db_path = Path(args.db).expanduser().resolve()
        config.base_dir = db_path.parent
        config.db_name = db_path.name
    return MemoryEngine(config)


def _scope_selection_from_id(scope_id: Optional[str]) -> Optional[ScopeSelection]:
    if not scope_id:
        return None
    return ScopeSelection(primary_scope_id=scope_id)


def _dt_to_str(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


def _scope_to_dict(scope) -> dict:
    return {
        "id": scope.id,
        "kind": scope.kind,
        "name": scope.name,
        "path": scope.path,
        "parent_scope_id": scope.parent_scope_id,
        "status": scope.status,
        "metadata": scope.metadata,
        "created_at": _dt_to_str(scope.created_at),
        "updated_at": _dt_to_str(scope.updated_at),
    }


def _job_to_dict(job) -> dict:
    return {
        "id": job.id,
        "job_type": job.job_type,
        "status": job.status,
        "payload": job.payload,
        "attempts": job.attempts,
        "max_attempts": job.max_attempts,
        "available_at": _dt_to_str(job.available_at),
        "leased_at": _dt_to_str(job.leased_at),
        "lease_owner": job.lease_owner,
        "last_error": job.last_error,
        "created_at": _dt_to_str(job.created_at),
        "updated_at": _dt_to_str(job.updated_at),
        "completed_at": _dt_to_str(job.completed_at),
    }


def _verification_request_to_dict(request) -> dict:
    return request.to_dict()


def _governance_candidate_to_dict(candidate) -> dict:
    return candidate.to_dict()


def main(argv: Optional[list[str]] = None) -> int:
    """Main CLI entry point. Returns exit code."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    from engram.cli.formatters import (
        format_entity,
        format_entity_list,
        format_search_result,
        format_store_result,
        format_health,
    )

    engine = None
    try:
        engine = _make_engine(args)

        if args.command == "init":
            if not args.quiet:
                print(f"Memory initialized at {engine.config.db_path}")
            return 0

        elif args.command == "store":
            max_input = 1024 * 1024  # 1MB limit for stdin
            text = args.text or sys.stdin.read(max_input)
            source = Source(
                type=SourceType(args.source_type),
                confidence=args.confidence,
                author=args.author,
                channel="cli",
            )
            result = engine.store(text, source=source, scope_id=args.scope_id)
            if args.json:
                print(result.to_json())
            else:
                print(format_store_result(result))

        elif args.command == "search":
            options = SearchOptions(
                query=args.query,
                max_results=args.max_results,
                max_tokens=args.max_tokens,
                min_confidence=args.min_confidence,
            )
            if args.entity_type:
                options.entity_types = [args.entity_type]
            if args.tier:
                options.tiers = [args.tier]
            options.context_tags = list(args.context_tag)
            result = engine.search(
                args.query,
                options,
                scope_selection=_scope_selection_from_id(args.scope_id),
            )
            if args.json:
                print(result.to_json())
            else:
                print(format_search_result(result))

        elif args.command == "context-search":
            result = engine.search_context(
                args.query,
                goal=args.goal,
                plan_query=args.plan_query,
                context_tags=list(args.context_tag),
                scope_selection=_scope_selection_from_id(args.scope_id),
                expand_hops=args.expand_hops,
                max_results=args.max_results,
                max_related=args.max_related,
                max_tokens=args.max_tokens,
            )
            if args.json:
                print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(result.base_result.to_agent_context(max_tokens=args.max_tokens))
                if result.related_entities:
                    print("Related:")
                    for row in result.related_entities:
                        print(f"  - {row.name} ({row.relation_type})")

        elif args.command == "query-plan":
            plan = engine.build_query_plan(args.query)
            if args.json:
                print(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2))
            else:
                if not plan.fragments:
                    print("No query expansion needed.")
                else:
                    print(f"Original: {plan.original_query}")
                    for fragment in plan.fragments:
                        print(f"  - {fragment}")

        elif args.command == "context-pack":
            pack = engine.build_context_pack(
                session_id=args.session_id,
                goal=args.goal,
                max_chars=args.max_chars,
            )
            if args.json:
                print(json.dumps(pack.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(pack.rendered_text)

        elif args.command == "context-transfer":
            scope_selection = (
                ScopeSelection(
                    primary_scope_id=args.scope_id,
                    include_ancestors=False,
                    include_global=False,
                )
                if args.scope_id
                else None
            )
            result = engine.transfer_context(
                from_session_id=args.session_id,
                to_agent_id=args.to_agent_id,
                note=args.note,
                goal=args.goal,
                scope_selection=scope_selection,
            )
            if args.json:
                print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(result.pack.rendered_text)
                print(f"Target session: {result.target_session.session_id}")

        elif args.command == "get":
            entity = engine.get_entity(args.name)
            if entity:
                facts = engine.get_facts(args.name)
                if args.json:
                    print(json.dumps({
                        "name": entity.name,
                        "type": entity.entity_type,
                        "tier": entity.tier.value,
                        "summary": entity.summary,
                        "facts": [{"text": f.raw_text, "confidence": f.confidence} for f in facts],
                    }, ensure_ascii=False, indent=2))
                else:
                    print(format_entity(entity, facts))
            else:
                print(f"  Entity '{args.name}' not found.", file=sys.stderr)
                engine.close()
                return 1

        elif args.command == "list":
            tier = Tier(args.tier) if args.tier else None
            entities = engine.list_entities(
                tier=tier,
                entity_type=args.entity_type or None,
                limit=args.limit,
            )
            if args.json:
                print(json.dumps([
                    {"name": e.name, "type": e.entity_type, "tier": e.tier.value}
                    for e in entities
                ], ensure_ascii=False, indent=2))
            else:
                print(format_entity_list(entities))

        elif args.command == "add-fact":
            source = Source(
                type=SourceType(args.source_type),
                confidence=args.confidence,
                channel="cli",
            )
            result = engine.add_fact(
                args.entity,
                args.fact,
                predicate=args.predicate,
                source=source,
                applies_if=list(args.applies_if),
                except_if=list(args.except_if),
            )
            if args.json:
                print(json.dumps({"action": result.action.value, "confidence": result.confidence}, indent=2))
            else:
                print(f"  Result: {result.action.value} (confidence: {result.confidence:.2f})")

        elif args.command == "create":
            tier = Tier(args.tier)
            entity = engine.create_entity(args.name, entity_type=args.entity_type, tier=tier, summary=args.summary)
            if args.json:
                print(json.dumps({"id": entity.id, "name": entity.name}, ensure_ascii=False, indent=2))
            else:
                print(f"  Created: {entity.name} ({entity.entity_type}, {entity.tier.value})")

        elif args.command == "conflicts":
            conflicts = engine.storage.get_pending_conflicts()
            if args.json:
                print(json.dumps(conflicts, ensure_ascii=False, indent=2))
            else:
                if not conflicts:
                    print("  No pending conflicts.")
                else:
                    for c in conflicts:
                        print(f"  [{c['id'][:8]}] {c['conflict_type']} — {c.get('suggested_resolution', 'N/A')}")

        elif args.command == "resolve":
            engine.resolve_conflict(args.conflict_id, args.resolution)
            print(f"  Conflict {args.conflict_id[:8]} resolved: {args.resolution}")

        elif args.command == "brief":
            brief = engine.entity_brief(
                args.name,
                top_facts=args.top_facts,
                recent_notes=args.recent_notes,
                recent_sessions=args.recent_sessions,
                scope_selection=_scope_selection_from_id(args.scope_id),
            )
            if brief is None:
                print(f"  Entity '{args.name}' not found.", file=sys.stderr)
                engine.close()
                return 1
            if args.json:
                print(json.dumps(brief.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(brief.to_agent_context(max_chars=args.max_chars))

        elif args.command == "session-brief":
            brief = engine.session_brief(
                args.session_id,
                scope_selection=_scope_selection_from_id(args.scope_id),
            )
            if brief is None:
                print(f"  Session '{args.session_id}' not found.", file=sys.stderr)
                engine.close()
                return 1
            if args.json:
                print(json.dumps(brief.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(brief.to_agent_context(max_chars=args.max_chars))

        elif args.command == "health":
            health = engine.health_check()
            if args.json:
                print(json.dumps(health, indent=2))
            else:
                print(format_health(health))

        elif args.command == "health-report":
            report = engine.health_report(
                max_open_loops=args.max_loops,
                stale_days=args.stale_days,
            )
            if args.json:
                print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(report.to_agent_context(max_chars=args.max_chars))

        elif args.command == "intake":
            from engram.models.intake import BatchStatus  # local import to avoid unused elsewhere
            if args.from_file:
                text = _read_intake_file(
                    args.from_file, allow_unsafe=bool(args.unsafe_path)
                )
            else:
                max_input = 1024 * 1024
                text = args.text or sys.stdin.read(max_input)
            source = Source(
                type=SourceType(args.source_type),
                author=args.author,
                channel="intake",
            )
            batch = engine.intake(text, source=source)

            if args.apply:
                result = engine.apply_intake(batch.id)
                batch = engine.get_intake(batch.id) or batch
                if args.json:
                    print(
                        json.dumps(
                            {"batch": batch.to_dict(), "apply": result.to_dict()},
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                else:
                    print(batch.to_agent_context())
                    print()
                    print(
                        f"  Applied: {len(result.applied)} · "
                        f"Rejected: {len(result.rejected)} · "
                        f"Skipped: {len(result.skipped)}"
                    )
            else:
                if args.json:
                    print(json.dumps(batch.to_dict(), ensure_ascii=False, indent=2))
                else:
                    print(batch.to_agent_context())
                    print()
                    print(f"  Batch staged: {batch.id}")
                    print("  Review with: engram-advanced intake-show " + batch.id)
                    print("  Apply with:  engram-advanced intake-apply " + batch.id)

        elif args.command == "intake-list":
            from engram.models.intake import BatchStatus
            status = BatchStatus(args.status) if args.status else None
            batches = engine.list_intakes(status=status, limit=args.limit)
            if args.json:
                print(
                    json.dumps(
                        [b.to_dict() for b in batches], ensure_ascii=False, indent=2
                    )
                )
            else:
                if not batches:
                    print("  No intake batches.")
                else:
                    for b in batches:
                        print(
                            f"  [{b.id[:8]}] {b.status.value:<8} "
                            f"({len(b.candidates)} candidates) "
                            f"{b.created_at.isoformat(timespec='minutes')}"
                        )

        elif args.command == "intake-show":
            batch = engine.get_intake(args.batch_id)
            if batch is None:
                print(f"  Batch '{args.batch_id}' not found.", file=sys.stderr)
                engine.close()
                return 1
            if args.json:
                print(json.dumps(batch.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(batch.to_agent_context())

        elif args.command == "intake-apply":
            result = engine.apply_intake(args.batch_id, candidate_ids=args.candidate)
            if args.json:
                print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(
                    f"  Applied: {len(result.applied)} · "
                    f"Rejected: {len(result.rejected)} · "
                    f"Skipped: {len(result.skipped)}"
                )
                if result.facts_quarantined:
                    print(f"  Facts quarantined: {result.facts_quarantined}")
                if result.facts_conflicted:
                    print(f"  Facts flagged as conflicts: {result.facts_conflicted}")

        elif args.command == "intake-reject":
            batch = engine.reject_intake(args.batch_id, candidate_ids=args.candidate)
            if args.json:
                print(json.dumps(batch.to_dict(), ensure_ascii=False, indent=2))
            else:
                counts = batch.counts_by_status()
                print(f"  Batch {batch.id[:8]} status: {batch.status.value}")
                for k, v in sorted(counts.items()):
                    print(f"    {k}: {v}")

        elif args.command == "snapshot-create":
            snap = engine.create_snapshot(
                label=args.label, description=args.description
            )
            if args.json:
                print(json.dumps(snap.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(snap.to_agent_context())

        elif args.command == "snapshot-list":
            snaps = engine.list_snapshots(limit=args.limit)
            if args.json:
                print(
                    json.dumps(
                        [s.to_dict() for s in snaps],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not snaps:
                    print("  No snapshots.")
                for s in snaps:
                    label = s.label or "—"
                    print(
                        f"  [{s.id[:8]}] {s.created_at.isoformat(timespec='seconds')} "
                        f"· {label:<20} · {s.entity_count}e/{s.fact_count}f "
                        f"· {s.compressed_size:,}B"
                    )

        elif args.command == "snapshot-show":
            snap = engine.get_snapshot(args.snapshot_id)
            if snap is None:
                print(f"  Snapshot '{args.snapshot_id}' not found.", file=sys.stderr)
                engine.close()
                return 1
            if args.json:
                print(json.dumps(snap.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(snap.to_agent_context())

        elif args.command == "snapshot-delete":
            ok = engine.delete_snapshot(args.snapshot_id)
            if not ok:
                print(f"  Snapshot '{args.snapshot_id}' not found.", file=sys.stderr)
                engine.close()
                return 1
            print(f"  Deleted snapshot {args.snapshot_id[:8]}")

        elif args.command == "snapshot-diff":
            diff = engine.diff_snapshots(args.a_id, args.b_id)
            if args.json:
                print(json.dumps(diff.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(diff.to_agent_context())

        elif args.command == "snapshot-search":
            hits = engine.search_snapshot(
                args.snapshot_id, args.query, limit=args.limit
            )
            if args.json:
                print(json.dumps(hits, ensure_ascii=False, indent=2))
            else:
                if not hits:
                    print("  No hits.")
                for hit in hits:
                    name = hit.get("entity_name", "?")
                    etype = hit.get("entity_type", "?")
                    rank = hit.get("rank", 0.0)
                    print(f"  {name} ({etype}) · rank={rank:.3f}")

        elif args.command == "snapshot-entity":
            data = engine.get_entity_at_snapshot(args.snapshot_id, args.name)
            if data is None:
                print(
                    f"  Entity '{args.name}' not found in snapshot.",
                    file=sys.stderr,
                )
                engine.close()
                return 1
            if args.json:
                print(json.dumps(data, ensure_ascii=False, indent=2))
            else:
                entity = data["entity"]
                print(f"## Entity at snapshot: {entity['name']}")
                print(f"Type: {entity['entity_type']} · Tier: {entity['tier']}")
                if entity.get("summary"):
                    print()
                    print(entity["summary"])
                if data["facts"]:
                    print()
                    print("### Facts")
                    for f in data["facts"]:
                        print(
                            f"- {f['raw_text']} (confidence: {f['confidence']:.2f}, "
                            f"status: {f['status']})"
                        )

        elif args.command == "snapshot-restore":
            path = engine.restore_snapshot(
                args.snapshot_id,
                args.target_path,
                allow_unsafe_path=bool(args.unsafe_path),
            )
            print(f"  Restored snapshot to: {path}")

        elif args.command == "debug-start":
            session = engine.debug_start(
                args.description,
                related_session_id=args.related_session,
            )
            if args.json:
                print(json.dumps(session.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Debug session started: {session.id}")
                print(f"  Bug: {session.bug_description}")

        elif args.command == "debug-hypothesis":
            hyp = engine.debug_hypothesis(
                args.debug_session_id, args.text, confidence=args.confidence
            )
            if args.json:
                print(json.dumps(hyp.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Hypothesis added: {hyp.id}")

        elif args.command == "debug-evidence":
            from engram.models.debug import EvidenceResult as _EvRes
            ev = engine.debug_evidence(
                args.hypothesis_id,
                args.text,
                result=_EvRes(args.result),
                kind=args.kind,
            )
            if args.json:
                print(json.dumps(ev.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Evidence added: {ev.id} ({ev.result.value})")

        elif args.command == "debug-reject":
            hyp = engine.debug_reject(args.hypothesis_id, args.reason)
            if args.json:
                print(json.dumps(hyp.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Rejected hypothesis {hyp.id[:8]}: {hyp.rejection_reason}")

        elif args.command == "debug-confirm":
            hyp = engine.debug_confirm(args.hypothesis_id)
            if args.json:
                print(json.dumps(hyp.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Confirmed hypothesis {hyp.id[:8]}")

        elif args.command == "debug-conclude":
            from engram.models.debug import DebugSessionStatus as _DSt
            session = engine.debug_conclude(
                args.debug_session_id,
                conclusion=args.conclusion,
                status=_DSt(args.status),
            )
            if args.json:
                print(json.dumps(session.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Session {session.id[:8]} concluded: {session.status.value}")
                if session.conclusion:
                    print(f"  Conclusion: {session.conclusion}")

        elif args.command == "debug-list":
            from engram.models.debug import DebugSessionStatus as _DSt
            status = _DSt(args.status) if args.status else None
            sessions = engine.list_debug_sessions(status=status, limit=args.limit)
            if args.json:
                print(
                    json.dumps(
                        [s.to_dict() for s in sessions],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not sessions:
                    print("  No debug sessions.")
                for s in sessions:
                    counts = s.counts_by_hypothesis_status()
                    count_str = (
                        ", ".join(f"{k}={v}" for k, v in sorted(counts.items()))
                        or "no hypotheses"
                    )
                    print(
                        f"  [{s.id[:8]}] {s.status.value:<10} — {s.bug_description[:60]}"
                    )
                    print(f"    {count_str}")

        elif args.command == "debug-show":
            session = engine.get_debug_session(args.debug_session_id)
            if session is None:
                print(f"  Debug session '{args.debug_session_id}' not found.", file=sys.stderr)
                engine.close()
                return 1
            if args.json:
                print(json.dumps(session.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(session.to_agent_context(max_chars=args.max_chars))

        elif args.command == "debug-search":
            from engram.models.debug import HypothesisStatus as _HSt
            statuses = [_HSt(args.status)] if args.status else None
            hyps = engine.search_debug_hypotheses(
                args.query, limit=args.limit, statuses=statuses
            )
            if args.json:
                print(
                    json.dumps(
                        [h.to_dict() for h in hyps], ensure_ascii=False, indent=2
                    )
                )
            else:
                if not hyps:
                    print("  No matching hypotheses.")
                for h in hyps:
                    marker = {
                        "open": "·",
                        "confirmed": "✓",
                        "rejected": "✕",
                        "abandoned": "○",
                    }.get(h.status.value, "·")
                    print(f"  {marker} [{h.id[:8]}] {h.text}")
                    if h.status.value == "rejected" and h.rejection_reason:
                        print(f"      → rejected: {h.rejection_reason}")

        elif args.command == "open-loops":
            from engram.models.health import LoopKind
            report = engine.health_report(max_open_loops=args.max)
            loops = report.open_loops
            if args.kind:
                loops = report.loops_by_kind(LoopKind(args.kind))
            if args.json:
                print(
                    json.dumps(
                        [l.to_dict() for l in loops[: args.max]],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not loops:
                    print("  No open loops.")
                else:
                    for l in loops[: args.max]:
                        line = f"  [{l.severity.value:8s}] {l.kind.value:15s} {l.title}"
                        print(line)
                        if l.recommended_action:
                            print(f"      → {l.recommended_action}")

        elif args.command == "backlinks":
            rows = engine.backlinks(args.name, source_kind=args.kind, limit=args.limit)
            if args.json:
                print(json.dumps(rows, ensure_ascii=False, indent=2))
            else:
                if not rows:
                    print("  No backlinks.")
                else:
                    for row in rows:
                        print(f"  [{row['source_kind']}] {row['snippet']}")

        elif args.command == "decisions":
            status = DecisionStatus(args.status) if args.status else None
            rows = engine.list_decisions(entity_name=args.entity, status=status, limit=args.limit)
            if args.json:
                print(json.dumps([row.to_dict() for row in rows], ensure_ascii=False, indent=2))
            else:
                if not rows:
                    print("  No decisions.")
                else:
                    for row in rows:
                        print(f"  [{row.status.value}] {row.title}")

        elif args.command == "decision-show":
            row = engine.get_decision(args.decision_id)
            if row is None:
                print(f"  Decision '{args.decision_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(row.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  [{row.decision.status.value}] {row.decision.title}")
                print(f"  {row.decision.summary}")

        elif args.command == "maintenance-run":
            run = engine.run_maintenance(max_open_loops=args.max_loops, stale_days=args.stale_days)
            if args.json:
                print(json.dumps(run.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Maintenance run {run.id[:8]} stored: grade {run.grade}, score {run.score_value:.1f}")

        elif args.command == "operations-review":
            review = engine.run_operations_review(
                max_open_loops=args.max_loops,
                stale_days=args.stale_days,
                run_jobs=bool(args.run_jobs),
                job_limit=args.job_limit,
            )
            if args.json:
                print(json.dumps(review.to_dict(), ensure_ascii=False, indent=2))
            else:
                for line in review.summary_lines:
                    print(f"  {line}")

        elif args.command == "maintenance-list":
            runs = engine.list_maintenance_runs(limit=args.limit)
            if args.json:
                print(json.dumps([run.to_dict() for run in runs], ensure_ascii=False, indent=2))
            else:
                if not runs:
                    print("  No maintenance runs.")
                else:
                    for run in runs:
                        print(f"  [{run.id[:8]}] {run.completed_at.isoformat()} grade={run.grade} score={run.score_value:.1f}")

        elif args.command == "maintenance-show":
            run = engine.get_maintenance_run(args.run_id)
            if run is None:
                print(f"  Maintenance run '{args.run_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(run.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(
                    f"  [{run.run.id[:8]}] {run.run.completed_at.isoformat()} "
                    f"grade={run.run.grade} score={run.run.score_value:.1f}"
                )
                for item_view in run.items:
                    item = item_view.item
                    print(f"    - [{item.severity}] {item.kind}: {item.title}")

        elif args.command == "verification-list":
            status = (
                VerificationRequestStatus(args.status)
                if args.status
                else None
            )
            rows = engine.list_verification_requests(
                status=status,
                target_kind=args.target_kind,
                limit=args.limit,
            )
            if args.json:
                print(
                    json.dumps(
                        [_verification_request_to_dict(row) for row in rows],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not rows:
                    print("  No verification requests.")
                else:
                    for row in rows:
                        print(f"  [{row.status.value}] {row.target_kind}:{row.target_id}")

        elif args.command == "verification-show":
            row = engine.get_verification_request(args.request_id)
            if row is None:
                print(f"  Verification request '{args.request_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(_verification_request_to_dict(row), ensure_ascii=False, indent=2))
            else:
                print(f"  [{row.status.value}] {row.target_kind}:{row.target_id}")
                print(f"  reason={row.reason}")

        elif args.command == "verification-request":
            if args.target_kind == "fact":
                row = engine.request_fact_verification(
                    args.target_id,
                    reason=args.reason,
                    requested_by="cli",
                )
            else:
                row = engine.request_decision_verification(
                    args.target_id,
                    reason=args.reason,
                    requested_by="cli",
                )
            if args.json:
                print(json.dumps(_verification_request_to_dict(row), ensure_ascii=False, indent=2))
            else:
                print(f"  Opened verification request {row.id} for {row.target_kind}:{row.target_id}")

        elif args.command == "verification-resolve":
            row = engine.resolve_verification_request(
                args.request_id,
                args.resolution,
                detail=args.detail,
            )
            if args.json:
                print(json.dumps(_verification_request_to_dict(row), ensure_ascii=False, indent=2))
            else:
                print(f"  Resolved verification request {row.id} as {row.resolution.value if row.resolution else ''}")

        elif args.command == "governance-run":
            rows = engine.generate_governance_candidates(limit=args.limit)
            if args.json:
                print(json.dumps([_governance_candidate_to_dict(row) for row in rows], ensure_ascii=False, indent=2))
            else:
                print(f"  Generated {len(rows)} governance candidates.")

        elif args.command == "governance-list":
            status = GovernanceCandidateStatus(args.status) if args.status else None
            candidate_type = GovernanceCandidateType(args.candidate_type) if args.candidate_type else None
            rows = engine.list_governance_candidates(
                status=status,
                candidate_type=candidate_type,
                limit=args.limit,
            )
            if args.json:
                print(json.dumps([_governance_candidate_to_dict(row) for row in rows], ensure_ascii=False, indent=2))
            else:
                if not rows:
                    print("  No governance candidates.")
                else:
                    for row in rows:
                        print(f"  [{row.status.value}] {row.candidate_type.value} ({row.id[:8]})")

        elif args.command == "governance-show":
            row = engine.get_governance_candidate(args.candidate_id)
            if row is None:
                print(f"  Governance candidate '{args.candidate_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(_governance_candidate_to_dict(row), ensure_ascii=False, indent=2))
            else:
                print(f"  [{row.status.value}] {row.candidate_type.value}")
                print(f"  id={row.id}")
                print(f"  rationale={row.rationale}")

        elif args.command == "governance-resolve":
            row = engine.resolve_governance_candidate(
                args.candidate_id,
                GovernanceResolution(args.resolution),
                resolved_by="cli",
            )
            if args.json:
                print(json.dumps(_governance_candidate_to_dict(row), ensure_ascii=False, indent=2))
            else:
                print(f"  Resolved governance candidate {row.id} as {row.status.value}")

        elif args.command == "scope-create":
            scope = engine.create_scope(
                args.kind,
                args.name,
                parent_scope_id=args.parent_scope_id,
            )
            if args.json:
                print(json.dumps(_scope_to_dict(scope), ensure_ascii=False, indent=2))
            else:
                print(f"  Created scope {scope.kind}:{scope.path} ({scope.id})")

        elif args.command == "scope-list":
            scopes = engine.list_scopes(
                kind=args.kind,
                parent_scope_id=args.parent_scope_id,
                include_archived=bool(args.include_archived),
            )
            if args.json:
                print(
                    json.dumps(
                        [_scope_to_dict(scope) for scope in scopes],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not scopes:
                    print("  No scopes.")
                else:
                    for scope in scopes:
                        print(f"  [{scope.kind}] {scope.path} ({scope.id})")

        elif args.command == "scope-show":
            scope = engine.get_scope(args.scope_id)
            if scope is None:
                print(f"  Scope '{args.scope_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(_scope_to_dict(scope), ensure_ascii=False, indent=2))
            else:
                print(f"  [{scope.kind}] {scope.path}")
                print(f"  id={scope.id}")

        elif args.command == "jobs-list":
            jobs = engine.list_jobs(
                status=args.status,
                job_type=args.job_type,
                limit=args.limit,
            )
            if args.json:
                print(
                    json.dumps(
                        [_job_to_dict(job) for job in jobs],
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            else:
                if not jobs:
                    print("  No jobs.")
                else:
                    for job in jobs:
                        print(f"  [{job.status}] {job.job_type} ({job.id[:8]})")

        elif args.command == "job-show":
            job = engine.get_job(args.job_id)
            if job is None:
                print(f"  Job '{args.job_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(_job_to_dict(job), ensure_ascii=False, indent=2))
            else:
                print(f"  [{job.status}] {job.job_type}")
                print(f"  id={job.id}")
                if job.last_error:
                    print(f"  error={job.last_error}")

        elif args.command == "jobs-run":
            result = engine.run_jobs(limit=args.limit, lease_owner="cli")
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(
                    f"  leased={result['leased']} completed={result['completed']} "
                    f"failed={result['failed']}"
                )

        elif args.command == "retention-set":
            policy = engine.set_retention_policy(
                RetentionTargetKind(args.target_kind),
                args.target_id,
                RetentionPolicyType(args.policy_type),
                value=args.value,
                reason=args.reason,
            )
            if args.json:
                print(json.dumps(policy.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  Set {policy.policy_type.value} on {policy.target_kind.value}:{policy.target_id}")

        elif args.command == "retention-list":
            target_kind = RetentionTargetKind(args.target_kind) if args.target_kind else None
            policy_type = RetentionPolicyType(args.policy_type) if args.policy_type else None
            rows = engine.list_retention_policies(
                target_kind=target_kind,
                target_id=args.target_id,
                policy_type=policy_type,
                limit=args.limit,
            )
            if args.json:
                print(json.dumps([row.to_dict() for row in rows], ensure_ascii=False, indent=2))
            else:
                if not rows:
                    print("  No retention policies.")
                else:
                    for row in rows:
                        print(f"  [{row.policy_type.value}] {row.target_kind.value}:{row.target_id}")

        elif args.command == "retention-clear":
            cleared = engine.clear_retention_policy(
                RetentionTargetKind(args.target_kind),
                args.target_id,
                RetentionPolicyType(args.policy_type),
            )
            if args.json:
                print(json.dumps({"cleared": cleared}, ensure_ascii=False, indent=2))
            else:
                print("  Cleared." if cleared else "  No matching policy.")

        elif args.command == "recommendations":
            rows = engine.list_recommendations(kind=args.kind, limit=args.limit)
            if args.json:
                print(json.dumps([row.to_dict() for row in rows], ensure_ascii=False, indent=2))
            else:
                if not rows:
                    print("  No recommendations.")
                else:
                    for row in rows:
                        print(f"  [{row.severity.value}] {row.title}")

        elif args.command == "recommendation-show":
            row = engine.get_recommendation(args.recommendation_id)
            if row is None:
                print(f"  Recommendation '{args.recommendation_id}' not found.", file=sys.stderr)
                return 1
            if args.json:
                print(json.dumps(row.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"  [{row.severity.value}] {row.title}")
                if row.detail:
                    print(f"  {row.detail}")

        elif args.command == "rebuild-references":
            count = engine.rebuild_references()
            print(f"  Rebuilt references for {count} sources.")

        elif args.command == "rebuild-decisions":
            count = engine.rebuild_decisions()
            print(f"  Rebuilt decisions for {count} sources.")

        elif args.command == "rebuild-projections":
            stats = engine.rebuild_projections()
            if args.json:
                print(json.dumps(stats, ensure_ascii=False, indent=2))
            else:
                print(f"  Rebuilt references={stats['references']} decisions={stats['decisions']}")

        elif args.command == "export":
            if args.dir:
                engine.config.export_dir_name = args.dir
            count = engine.export_markdown()
            print(f"  Exported {count} entities to {engine.config.export_dir}")

        elif args.command == "reindex":
            count = engine.reindex()
            print(f"  Reindexed {count} entities.")

        elif args.command == "reclassify":
            stats = engine.reclassify_facts(
                entity_name=args.entity,
                only_default=not args.all_facts,
            )
            if args.json:
                print(json.dumps(stats, ensure_ascii=False, indent=2))
            else:
                print(
                    f"  Scanned: {stats['scanned']} · Updated: {stats['updated']}"
                )
                for t, n in sorted(stats["by_type"].items()):
                    print(f"    {t}: {n}")

        elif args.command == "serve":
            _run_mcp_server(args)
            return 0

        return 0

    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if hasattr(args, "verbose") and args.verbose:
            import traceback
            traceback.print_exc()
        return 1
    finally:
        if engine is not None:
            engine.close()


def _run_mcp_server(args) -> None:
    """Start MCP server (requires mcp package)."""
    try:
        from engram.integrations.mcp_server import run_server
        run_server(transport=args.transport, port=args.port)
    except ImportError:
        print("MCP server requires 'mcp' package. Install with: pip install memorytrace[mcp]", file=sys.stderr)
        sys.exit(1)


def cli_entry() -> None:
    """Entry point for setuptools console_scripts (expects no return value)."""
    # Windows cp949 encoding fix — prevent UnicodeEncodeError on non-ASCII output
    import io
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    elif hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    elif hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    sys.exit(main())


if __name__ == "__main__":
    cli_entry()
