#!/usr/bin/env python3
"""Engram — simple CLI interface.

Usage:
    engram init
    engram save "Minseong Jeong is the Space King of Galaxy Corp"
    engram find "Space King"
    engram who "Minseong Jeong"
    engram remember "Minseong Jeong" "Loves AI and space"
    engram all
    engram status
    engram forget "Old Entity"
    engram export
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from engram.config import EngramConfig
from engram.engine import MemoryEngine

_DB_DIR = Path(os.environ.get("ENGRAM_BASE_DIR", str(Path.home() / ".engram")))
_engine = None
try:
    MAX_NOTE_PREVIEW = int(os.environ.get("ENGRAM_NOTE_PREVIEW", "300"))
except (ValueError, TypeError):
    MAX_NOTE_PREVIEW = 300


def _get_engine() -> MemoryEngine:
    global _engine
    if _engine is None:
        _engine = MemoryEngine(EngramConfig(base_dir=_DB_DIR))
    return _engine


def _print_help():
    print("""
  engram — AI agent memory system

  Commands:
    engram init                          Initialize memory
    engram save "text"                   Extract & store information
    engram find "query"                  Search memory
    engram who "name"                    Look up entity
    engram remember "name" "fact"        Manually add a fact
    engram all                           List all entities
    engram recent [N]                    Show N most recent notes (default 10)
    engram notes "query" [--full]        Search notes only (skip entities)
    engram delete-note "keyword"         Find & delete matching notes
    engram cleanup [--dry-run]           Clean up old notes (90+ days)
    engram status                        Health check
    engram forget "name"                 Delete entity
    engram export                        Export to Markdown

  Examples:
    engram save "Minseong Jeong is the Space King of Galaxy Corp"
    engram find "Space King"
    engram who "Minseong Jeong"
    engram remember "정민성" "AI 전문가이다"

  Install:
    pip install git+https://github.com/aop60003/default.git
""")


def main() -> int:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        _print_help()
        return 0

    cmd = args[0]
    rest = " ".join(args[1:]) if len(args) > 1 else ""

    try:
        engine = _get_engine()

        # ── init ──
        if cmd == "init":
            print(f"  Memory initialized at {engine.config.db_path}")

        # ── save ──
        elif cmd == "save":
            if not rest:
                print("  Usage: engram save \"text to remember\"")
                return 1
            result = engine.store(rest)
            if result.note_is_new:
                print(f"  Note saved ({len(rest)} chars)")
            else:
                print(f"  Note already exists (duplicate skipped)")
            created = [e.name for e in result.entities_created]
            updated = [e.name for e in result.entities_updated]
            if created:
                print(f"  Entities new: {', '.join(created)}")
            if updated:
                print(f"  Entities updated: {', '.join(updated)}")
            if result.facts_added:
                print(f"  Learned {len(result.facts_added)} fact(s)")

        # ── find ──
        elif cmd in ("find", "search"):
            full = "--full" in args
            query = " ".join(a for a in args[1:] if a != "--full")
            if not query:
                print("  Usage: engram find \"search query\" [--full]")
                return 1
            result = engine.search(query)
            has_any = False
            if result.hits:
                has_any = True
                for h in result.hits:
                    print(f"  {h.entity.name} ({h.entity.entity_type})")
                    if h.entity.summary:
                        print(f"    {h.entity.summary}")
                    for f in h.facts[:3]:
                        print(f"    - {f.raw_text}")
            if hasattr(result, 'notes') and result.notes:
                has_any = True
                for n in result.notes:
                    t = n['text']
                    if full:
                        print(f"  [Note] {t}")
                    else:
                        print(f"  [Note] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")
            if not has_any:
                print(f"  Nothing found for \"{query}\"")

        # ── who ──
        elif cmd in ("who", "get"):
            if not rest:
                print("  Usage: engram who \"entity name\"")
                return 1
            entity = engine.get_entity(rest)
            if not entity:
                print(f"  \"{rest}\" not found.")
                return 1
            print(f"  {entity.name} [{entity.entity_type}]")
            if entity.summary:
                print(f"  {entity.summary}")
            if entity.state.role:
                print(f"  Role: {entity.state.role}")
            if entity.state.affiliation:
                print(f"  At: {entity.state.affiliation}")
            if entity.aliases:
                print(f"  Also known as: {', '.join(entity.aliases)}")
            facts = engine.get_facts(rest)
            if facts:
                print(f"  Facts ({len(facts)}):")
                for f in facts:
                    print(f"    - {f.raw_text}")

        # ── remember ──
        elif cmd == "remember":
            # Parse: remember "Name" "Fact"
            parts = _parse_quoted_args(args[1:])
            if len(parts) < 2:
                print('  Usage: engram remember "Name" "Fact to remember"')
                return 1
            name, fact = parts[0], " ".join(parts[1:])
            if not engine.get_entity(name):
                engine.create_entity(name)
                print(f"  Created: {name}")
            result = engine.add_fact(name, fact)
            print(f"  Remembered ({result.confidence:.0%} confidence)")

        # ── all / list ──
        elif cmd in ("all", "list"):
            entities = engine.list_entities(limit=50)
            if not entities:
                print("  No memories yet. Try: engram save \"some info\"")
            else:
                print(f"  {len(entities)} entities:")
                for e in entities:
                    line = f"    {e.name} ({e.entity_type})"
                    if e.summary:
                        line += f" — {e.summary[:50]}"
                    print(line)

        # ── recent ──
        elif cmd == "recent":
            limit = int(rest) if rest.isdigit() else 10
            notes = engine.storage.get_recent_notes(limit=limit)
            if not notes:
                print("  No notes yet. Try: engram save \"some info\"")
            else:
                for n in notes:
                    ts = n["created_at"][:16].replace("T", " ")
                    t = n["text"]
                    print(f"  [{ts}] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")

        # ── delete-note ──
        elif cmd == "delete-note":
            # Parse --confirm flag from args before joining keyword
            confirm = "--confirm" in args
            keyword_parts = [a for a in args[1:] if a != "--confirm"]
            keyword = " ".join(keyword_parts).strip()
            if not keyword:
                print('  Usage: engram delete-note "keyword" [--confirm]')
                return 1
            matches = engine.storage.search_notes(keyword)
            if not matches:
                matches = engine.storage.search_notes_like(keyword)
            if not matches:
                print(f'  No notes found matching "{keyword}"')
                return 0
            if not confirm:
                print(f"  Found {len(matches)} note(s) matching \"{keyword}\":")
                for n in matches:
                    ts = n["created_at"][:16].replace("T", " ")
                    t = n["text"]
                    print(f"    [{ts}] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")
                print(f"\n  To delete, run: engram delete-note \"{keyword}\" --confirm")
            else:
                deleted = engine.storage.delete_notes_by_keyword(keyword)
                print(f"  Deleted {len(deleted)} note(s).")

        # ── cleanup ──
        elif cmd == "cleanup":
            from datetime import datetime, timedelta
            dry_run = "--dry-run" in args
            days = 90
            cutoff = (datetime.now() - timedelta(days=days)).isoformat()
            old_count = engine.storage.count_old_notes(cutoff)
            if dry_run:
                print(f"  Would delete {old_count} notes older than {days} days")
                h = engine.health_check()
                print(f"  Current: {h['entity_count']} entities, {h['fact_count']} facts, {h['note_count']} notes")
            else:
                deleted = engine.storage.delete_old_notes(cutoff)
                print(f"  Cleaned up {deleted} old notes (>{days} days)")

        # ── notes (note-only search) ──
        elif cmd == "notes":
            full = "--full" in args
            query = " ".join(a for a in args[1:] if a != "--full")
            if not query:
                print('  Usage: engram notes "search query" [--full]')
                return 1
            matches = engine.storage.search_notes(query)
            if not matches:
                matches = engine.storage.search_notes_like(query)
            if not matches:
                print(f'  No notes found for "{query}"')
            else:
                for n in matches:
                    ts = n["created_at"][:16].replace("T", " ")
                    t = n["text"]
                    if full:
                        print(f"  [{ts}] {t}")
                    else:
                        print(f"  [{ts}] {t[:MAX_NOTE_PREVIEW]}{'...' if len(t) > MAX_NOTE_PREVIEW else ''}")

        # ── status ──
        elif cmd == "status":
            h = engine.health_check()
            print(f"  Entities: {h['entity_count']}")
            print(f"  Facts:    {h['fact_count']}")
            print(f"  Notes:    {h['note_count']}")
            print(f"  Conflicts: {h['pending_conflicts']}")
            print(f"  Status:   {h['status']}")
            print(f"  DB: {engine.config.db_path}")

        # ── forget ──
        elif cmd == "forget":
            if not rest:
                print("  Usage: engram forget \"entity name\"")
                return 1
            if engine.delete_entity(rest):
                print(f"  Forgot: {rest}")
            else:
                print(f"  \"{rest}\" not found.")

        # ── export ──
        elif cmd == "export":
            count = engine.export_markdown()
            print(f"  Exported {count} entities to {engine.config.export_dir}")

        # ── json ──
        elif cmd == "json":
            # engram json find "query" / engram json who "name"
            if len(args) < 3:
                print("  Usage: engram json find/who/all \"query\"")
                return 1
            subcmd = args[1]
            subrest = " ".join(args[2:])
            if subcmd == "find":
                result = engine.search(subrest)
                print(result.to_json())
            elif subcmd == "who":
                entity = engine.get_entity(subrest)
                if entity:
                    facts = engine.get_facts(subrest)
                    print(json.dumps({
                        "name": entity.name, "type": entity.entity_type,
                        "tier": entity.tier.value, "summary": entity.summary,
                        "role": entity.state.role, "affiliation": entity.state.affiliation,
                        "facts": [{"text": f.raw_text, "confidence": f.confidence} for f in facts],
                    }, ensure_ascii=False, indent=2))
                else:
                    print(json.dumps({"error": f"'{subrest}' not found"}, indent=2))
            elif subcmd == "all":
                entities = engine.list_entities(limit=100)
                print(json.dumps([
                    {"name": e.name, "type": e.entity_type, "tier": e.tier.value}
                    for e in entities
                ], ensure_ascii=False, indent=2))

        else:
            print(f"  Unknown command: {cmd}")
            _print_help()
            return 1

    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"  Error: {e}", file=sys.stderr)
        return 1
    finally:
        if _engine:
            _engine.close()

    return 0


def _parse_quoted_args(args: list) -> list[str]:
    """Parse arguments respecting quotes: 'Name' 'Fact here' → ['Name', 'Fact here']"""
    joined = " ".join(args)
    parts = []
    current = ""
    in_quote = False
    quote_char = ""
    for ch in joined:
        if ch in ('"', "'") and not in_quote:
            in_quote = True
            quote_char = ch
        elif ch == quote_char and in_quote:
            in_quote = False
            if current:
                parts.append(current)
                current = ""
        elif ch == " " and not in_quote and current:
            parts.append(current)
            current = ""
        elif ch != " " or in_quote:
            current += ch
    if current:
        parts.append(current)
    return parts


def cli_entry():
    # Windows cp949 encoding fix
    import io
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    elif hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    elif hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    sys.exit(main())

if __name__ == "__main__":
    cli_entry()
