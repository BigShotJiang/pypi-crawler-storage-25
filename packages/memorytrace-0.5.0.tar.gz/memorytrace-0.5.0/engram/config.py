"""Engram configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class EngramConfig:
    """Central configuration for the Engram memory system."""

    # Storage
    base_dir: Path = field(default_factory=lambda: Path.home() / ".engram")
    db_name: str = "memory.db"
    enable_markdown_export: bool = True
    export_dir_name: str = "readable"
    snapshots_dir_name: str = "snapshots"

    # Search
    search_backend: str = "fts5"  # "fts5" | "semantic" | "hybrid"
    max_search_results: int = 20
    default_token_budget: int = 500
    fts5_tokenizer: str = "unicode61 remove_diacritics 2"

    # Extraction
    extractor_backend: str = "regex"  # "regex" | "llm"
    llm_provider: Optional[str] = None  # "anthropic" | "openai"
    llm_model: Optional[str] = None

    # Quality
    min_confidence: float = 0.3
    auto_resolve_threshold: float = 0.3  # trust diff for auto-supersede
    enable_pii_detection: bool = True

    # Session
    default_agent_id: str = "default"

    # Maintenance
    thin_page_threshold: int = 300  # bytes
    decay_days: int = 90
    compact_days: int = 180

    @property
    def db_path(self) -> Path:
        return self.base_dir / self.db_name

    @property
    def export_dir(self) -> Path:
        return self.base_dir / self.export_dir_name

    @property
    def snapshots_dir(self) -> Path:
        return self.base_dir / self.snapshots_dir_name

    def ensure_dirs(self) -> None:
        """Create required directories if they don't exist."""
        self.base_dir.mkdir(parents=True, exist_ok=True)
        if self.enable_markdown_export:
            self.export_dir.mkdir(parents=True, exist_ok=True)

    @classmethod
    def from_dict(cls, data: dict) -> EngramConfig:
        config = cls()
        if "base_dir" in data:
            config.base_dir = Path(data["base_dir"]).expanduser().resolve()
        for key in (
            "db_name", "enable_markdown_export", "export_dir_name",
            "search_backend", "max_search_results", "default_token_budget",
            "extractor_backend", "llm_provider", "llm_model",
            "min_confidence", "auto_resolve_threshold", "enable_pii_detection",
            "default_agent_id", "thin_page_threshold", "decay_days", "compact_days",
        ):
            if key in data:
                setattr(config, key, data[key])
        return config
