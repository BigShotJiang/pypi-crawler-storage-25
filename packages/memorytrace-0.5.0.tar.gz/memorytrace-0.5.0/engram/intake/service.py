"""IntakeService — extract → stage → review → apply.

The service writes proposed entities / facts / relations into the
``staging_batches`` and ``staging_candidates`` tables instead of the main
tables. Applying a batch (or a subset of its candidates) runs the same
:class:`QualityGate` that ``store`` uses, then commits accepted writes.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §3.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Iterable, Optional

from engram.extraction.base import Extractor
from engram.exceptions import EntityAlreadyExistsError
from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.intake import (
    BatchStatus,
    CandidateStatus,
    CandidateType,
    IntakeApplyResult,
    IntakeBatch,
    IntakeCandidate,
)
from engram.models.quality import Action
from engram.models.relation import Relation
from engram.models.source import Source, SourceType
from engram.quality.gate import QualityGate
from engram.session.manager import SessionManager
from engram.storage.sqlite_store import SQLiteStorage
from engram.storage.base import StorageBackend


def _dt_to_str(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _str_to_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


class IntakeService:
    """Handles the full intake lifecycle: extract → stage → apply."""

    def __init__(
        self,
        storage: SQLiteStorage,
        extractor: Extractor,
        quality_gate: QualityGate,
        session_mgr: SessionManager,
    ) -> None:
        self.storage = storage
        self.extractor = extractor
        self.quality_gate = quality_gate
        self.session_mgr = session_mgr
        # Reuse the quality gate's PII detector so intake staging is protected
        # by the same policy as direct store() writes. Without this, raw_text
        # and candidate payloads would land in the staging tables before the
        # gate gets a chance to mask them, so rejected batches would leak
        # SSN/credit-card/API-key content indefinitely.
        self._pii_detector = (
            getattr(quality_gate, "pii_detector", None)
            if quality_gate is not None
            else None
        )
        self._enable_pii = (
            bool(getattr(quality_gate, "enable_pii", True))
            if quality_gate is not None
            else True
        )

    def _mask(self, text: Optional[str]) -> Optional[str]:
        """Apply the configured PII policy to a single string.

        No-op when PII detection is disabled, when no detector is available
        (e.g. tests injecting a stub gate), or when the input has no matches.
        """
        if not text or not self._enable_pii or self._pii_detector is None:
            return text
        matches = self._pii_detector.scan(text)
        if not matches:
            return text
        return self._pii_detector.mask(text, matches)

    # ── Create ──

    def intake(
        self,
        text: str,
        source: Optional[Source] = None,
        session_id: Optional[str] = None,
    ) -> IntakeBatch:
        """Extract candidates from ``text`` into a new staging batch.

        Main tables are untouched. Returns the created batch with its
        candidates so the caller can review and decide what to apply.

        Raw text and every candidate's text field is PII-masked before
        persistence so the staging tables never hold unredacted secrets,
        even for batches that are later rejected.
        """
        if not text or not text.strip():
            raise ValueError("intake requires non-empty text")

        source = source or Source(type=SourceType.USER_INPUT)
        batch_id = str(uuid.uuid4())
        now = datetime.now()

        # Mask the full input once. Extraction then runs on the masked text —
        # otherwise names of patterns we redact (e.g. "contact alice@x.com")
        # would still surface in extracted entity names.
        safe_text = self._mask(text) or ""

        # Extract entities, facts, relations in dry-run fashion (no DB writes).
        extracted_entities = self.extractor.extract_entities(safe_text)
        extracted_facts = self.extractor.extract_facts(safe_text, extracted_entities)
        extracted_relations = self.extractor.extract_relations(
            safe_text, extracted_entities
        )

        # Map entity id → (possibly re-masked) name for relation resolution.
        id_to_name = {e.id: self._mask(e.name) or e.name for e in extracted_entities}

        candidates: list[IntakeCandidate] = []

        for entity in extracted_entities:
            masked_name = self._mask(entity.name) or entity.name
            payload = {
                "name": masked_name,
                "entity_type": entity.entity_type,
                "tier": entity.tier.value,
                "summary": self._mask(entity.summary) or "",
                "aliases": [self._mask(a) or a for a in entity.aliases],
                "state": entity.state.to_dict(),
            }
            candidates.append(
                IntakeCandidate(
                    id=str(uuid.uuid4()),
                    batch_id=batch_id,
                    candidate_type=CandidateType.ENTITY,
                    payload=payload,
                    created_at=now,
                )
            )

        for fact in extracted_facts:
            payload = {
                "subject": self._mask(fact.subject) or fact.subject,
                "entity_name": id_to_name.get(fact.entity_id, fact.subject),
                "predicate": fact.predicate,
                "object": self._mask(fact.object) or "",
                "raw_text": self._mask(fact.raw_text) or "",
                "confidence": fact.confidence,
            }
            candidates.append(
                IntakeCandidate(
                    id=str(uuid.uuid4()),
                    batch_id=batch_id,
                    candidate_type=CandidateType.FACT,
                    payload=payload,
                    created_at=now,
                )
            )

        for rel in extracted_relations:
            payload = {
                "from_name": id_to_name.get(rel.from_entity_id, ""),
                "to_name": id_to_name.get(rel.to_entity_id, ""),
                "relation_type": rel.relation_type,
                "metadata": dict(rel.metadata or {}),
            }
            candidates.append(
                IntakeCandidate(
                    id=str(uuid.uuid4()),
                    batch_id=batch_id,
                    candidate_type=CandidateType.RELATION,
                    payload=payload,
                    created_at=now,
                )
            )

        batch = IntakeBatch(
            id=batch_id,
            raw_text=safe_text,
            source_type=source.type.value,
            source_author=source.author or "",
            source_channel=source.channel or "",
            session_id=session_id,
            status=BatchStatus.PENDING,
            created_at=now,
            candidates=candidates,
        )

        self._persist_batch(batch)
        return batch

    # ── Read ──

    def list_batches(
        self,
        status: Optional[BatchStatus] = None,
        limit: int = 50,
    ) -> list[IntakeBatch]:
        conn = self.storage._conn
        query = "SELECT * FROM staging_batches"
        params: list = []
        if status is not None:
            query += " WHERE status = ?"
            params.append(status.value)
        # ROWID DESC is a deterministic tie-breaker when two batches were
        # staged in the same millisecond (common on Windows where
        # datetime.now() has ~15 ms resolution). Without it, SQLite may
        # return ties in either direction and CLI output flaps.
        query += " ORDER BY created_at DESC, ROWID DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        batches = [self._row_to_batch(row) for row in rows]
        candidates_by_batch = self._candidates_for_batches([b.id for b in batches])
        for batch in batches:
            batch.candidates = candidates_by_batch.get(batch.id, [])
        return batches

    def get_batch(self, batch_id: str) -> Optional[IntakeBatch]:
        conn = self.storage._conn
        row = conn.execute(
            "SELECT * FROM staging_batches WHERE id = ?", (batch_id,)
        ).fetchone()
        if row is None:
            return None
        batch = self._row_to_batch(row)
        batch.candidates = self._candidates_for_batches([batch.id]).get(batch.id, [])
        return batch

    def get_candidate(self, candidate_id: str) -> Optional[IntakeCandidate]:
        conn = self.storage._conn
        row = conn.execute(
            "SELECT * FROM staging_candidates WHERE id = ?", (candidate_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_candidate(row)

    # ── Write / Lifecycle ──

    def reject(
        self,
        batch_id: str,
        candidate_ids: Optional[Iterable[str]] = None,
    ) -> IntakeBatch:
        """Mark candidates (or the whole batch) as rejected."""
        batch = self.get_batch(batch_id)
        if batch is None:
            raise ValueError(f"Batch {batch_id} not found")

        targets = self._resolve_candidate_ids(batch, candidate_ids)
        conn = self.storage._conn
        for cand in targets:
            if cand.status != CandidateStatus.PENDING:
                continue
            conn.execute(
                "UPDATE staging_candidates SET status = ?, notes = ? WHERE id = ?",
                (CandidateStatus.REJECTED.value, "rejected", cand.id),
            )
        conn.commit()

        self._recompute_batch_status(batch_id)
        return self.get_batch(batch_id)

    def apply(
        self,
        batch_id: str,
        candidate_ids: Optional[Iterable[str]] = None,
    ) -> IntakeApplyResult:
        """Apply pending candidates to main tables through the quality gate."""
        batch = self.get_batch(batch_id)
        if batch is None:
            raise ValueError(f"Batch {batch_id} not found")

        targets = self._resolve_candidate_ids(batch, candidate_ids)
        # Only pending candidates can be applied.
        targets = [c for c in targets if c.status == CandidateStatus.PENDING]

        source = Source(
            type=SourceType(batch.source_type),
            author=batch.source_author,
            channel=batch.source_channel or "intake",
            session_id=batch.session_id,
        )

        # Process in order: entities → facts → relations, so downstream
        # candidates can reference entities created earlier in the same apply.
        entity_targets = [c for c in targets if c.candidate_type == CandidateType.ENTITY]
        fact_targets = [c for c in targets if c.candidate_type == CandidateType.FACT]
        relation_targets = [
            c for c in targets if c.candidate_type == CandidateType.RELATION
        ]

        result = IntakeApplyResult(batch_id=batch_id)

        entity_name_to_id: dict[str, str] = {}

        for cand in entity_targets:
            entity_id = self._apply_entity_candidate(cand)
            if entity_id is None:
                result.skipped.append(cand)
                self._update_candidate(
                    cand.id,
                    CandidateStatus.SKIPPED,
                    notes="no-op",
                    commit=False,
                )
                continue
            entity_name_to_id[cand.payload.get("name", "")] = entity_id
            cand.status = CandidateStatus.APPLIED
            cand.applied_target_id = entity_id
            self._update_candidate(
                cand.id,
                CandidateStatus.APPLIED,
                entity_id,
                commit=False,
            )
            result.applied.append(cand)

        for cand in fact_targets:
            outcome = self._apply_fact_candidate(cand, source, batch.session_id)
            if outcome is None:
                result.skipped.append(cand)
                self._update_candidate(
                    cand.id,
                    CandidateStatus.SKIPPED,
                    notes="entity-missing",
                    commit=False,
                )
                continue
            fact_id, action = outcome
            if action == Action.REJECT:
                # Gate rejected the fact — it was NEVER written to storage,
                # so the in-memory ``fact_id`` doesn't exist in the facts
                # table. Do not record it as ``applied_target_id`` or
                # downstream readers (UI, reports) would chase a dangling
                # reference.
                cand.applied_target_id = None
                result.rejected.append(cand)
                self._update_candidate(
                    cand.id,
                    CandidateStatus.REJECTED,
                    applied_target_id=None,
                    notes="gate-reject",
                    commit=False,
                )
            else:
                cand.applied_target_id = fact_id
                cand.status = CandidateStatus.APPLIED
                self._update_candidate(
                    cand.id,
                    CandidateStatus.APPLIED,
                    fact_id,
                    notes=action.value,
                    commit=False,
                )
                result.applied.append(cand)
                if action == Action.QUARANTINE:
                    result.facts_quarantined += 1
                elif action == Action.FLAG_CONFLICT:
                    result.facts_conflicted += 1

        for cand in relation_targets:
            rel_id = self._apply_relation_candidate(cand, entity_name_to_id)
            if rel_id is None:
                result.skipped.append(cand)
                self._update_candidate(
                    cand.id,
                    CandidateStatus.SKIPPED,
                    notes="endpoint-missing",
                    commit=False,
                )
                continue
            cand.status = CandidateStatus.APPLIED
            cand.applied_target_id = rel_id
            self._update_candidate(
                cand.id,
                CandidateStatus.APPLIED,
                rel_id,
                commit=False,
            )
            result.applied.append(cand)

        self._recompute_batch_status(batch_id, commit=False)
        self.storage._conn.commit()
        return result

    # ── Internal helpers ──

    def _apply_entity_candidate(self, cand: IntakeCandidate) -> Optional[str]:
        payload = cand.payload or {}
        name = payload.get("name", "").strip()
        if not name:
            return None
        existing = self.storage.get_entity_by_name(name)
        if existing is not None:
            return existing.id
        try:
            tier = Tier(payload.get("tier") or "recall")
        except ValueError:
            tier = Tier.RECALL
        entity = Entity(
            name=name,
            entity_type=payload.get("entity_type", "person"),
            tier=tier,
            summary=payload.get("summary", "") or "",
            aliases=list(payload.get("aliases") or []),
            state=EntityState.from_dict(payload.get("state") or {}),
        )
        try:
            self.storage.create_entity(entity)
        except EntityAlreadyExistsError:
            reread = self.storage.get_entity_by_name(name)
            return reread.id if reread else None
        return entity.id

    def _apply_fact_candidate(
        self,
        cand: IntakeCandidate,
        source: Source,
        session_id: Optional[str],
    ) -> Optional[tuple[str, Action]]:
        payload = cand.payload or {}
        name = (
            payload.get("entity_name")
            or payload.get("subject")
            or ""
        ).strip()
        if not name:
            return None
        entity = self.storage.get_entity_by_name(name)
        if entity is None:
            return None
        fact = Fact(
            entity_id=entity.id,
            subject=entity.name,
            predicate=payload.get("predicate", "attribute"),
            object=payload.get("object", ""),
            raw_text=payload.get("raw_text", payload.get("object", "")),
            source=source,
            confidence=float(payload.get("confidence", 0.5)),
        )
        validation = self.quality_gate.validate(fact, extraction_method="intake")
        action = validation.action
        if action == Action.REJECT:
            return fact.id, action
        self.storage.add_fact(fact)
        if session_id:
            self.session_mgr.record_fact_added(session_id, fact.id)
            self.session_mgr.record_entity_modified(session_id, entity.id)
        if action == Action.FLAG_CONFLICT:
            for conflict in validation.conflicts:
                self.storage.add_conflict(
                    {
                        "id": conflict.conflict_id,
                        "existing_fact_id": (
                            conflict.existing_fact.id if conflict.existing_fact else None
                        ),
                        "new_fact_id": fact.id,
                        "conflict_type": conflict.conflict_type,
                        "suggested_resolution": conflict.suggested_resolution,
                    }
                )
        elif action == Action.ACCEPT:
            for retracted_fact in validation.auto_resolved_facts:
                self.storage.update_fact(retracted_fact)
        return fact.id, action

    def _apply_relation_candidate(
        self,
        cand: IntakeCandidate,
        name_to_id: dict[str, str],
    ) -> Optional[str]:
        payload = cand.payload or {}
        from_name = (payload.get("from_name") or "").strip()
        to_name = (payload.get("to_name") or "").strip()
        if not from_name or not to_name:
            return None
        from_id = name_to_id.get(from_name)
        if not from_id:
            entity = self.storage.get_entity_by_name(from_name)
            if entity is None:
                return None
            from_id = entity.id
        to_id = name_to_id.get(to_name)
        if not to_id:
            entity = self.storage.get_entity_by_name(to_name)
            if entity is None:
                return None
            to_id = entity.id
        relation_type = payload.get("relation_type", "related")
        # Dedup: facts pass through QualityGate.is_duplicate; relations don't.
        # Without this check, applying two batches with the same relation
        # wording produces duplicate rows and pollutes subsequent diffs /
        # briefs. Treat a duplicate as a skip rather than an error so
        # batch apply semantics stay simple.
        existing = self.storage._conn.execute(
            """SELECT id FROM relations
               WHERE from_entity_id = ?
                 AND to_entity_id = ?
                 AND relation_type = ?
                 AND valid_to IS NULL""",
            (from_id, to_id, relation_type),
        ).fetchone()
        if existing is not None:
            return None
        relation = Relation(
            from_entity_id=from_id,
            to_entity_id=to_id,
            relation_type=relation_type,
            metadata=dict(payload.get("metadata") or {}),
        )
        self.storage.add_relation(relation)
        return relation.id

    def _resolve_candidate_ids(
        self,
        batch: IntakeBatch,
        candidate_ids: Optional[Iterable[str]],
    ) -> list[IntakeCandidate]:
        if candidate_ids is None:
            return list(batch.candidates)
        id_set = {cid for cid in candidate_ids}
        matched = [c for c in batch.candidates if c.id in id_set]
        missing = id_set - {c.id for c in matched}
        if missing:
            raise ValueError(
                f"Unknown candidate IDs for batch {batch.id}: {sorted(missing)}"
            )
        return matched

    def _update_candidate(
        self,
        candidate_id: str,
        status: CandidateStatus,
        applied_target_id: Optional[str] = None,
        notes: str = "",
        commit: bool = True,
    ) -> None:
        conn = self.storage._conn
        conn.execute(
            """UPDATE staging_candidates
               SET status = ?, applied_target_id = ?, notes = ?
               WHERE id = ?""",
            (status.value, applied_target_id, notes, candidate_id),
        )
        if commit:
            conn.commit()

    def _recompute_batch_status(self, batch_id: str, commit: bool = True) -> None:
        conn = self.storage._conn
        rows = conn.execute(
            "SELECT status, COUNT(*) AS c FROM staging_candidates WHERE batch_id = ? GROUP BY status",
            (batch_id,),
        ).fetchall()
        counts = {row["status"]: row["c"] for row in rows}
        total = sum(counts.values()) or 1
        pending = counts.get("pending", 0)
        applied = counts.get("applied", 0)
        rejected = counts.get("rejected", 0)
        skipped = counts.get("skipped", 0)

        if pending == total:
            new_status = BatchStatus.PENDING
        elif pending > 0:
            new_status = BatchStatus.MIXED
        elif applied > 0 and rejected == 0:
            # Applied + any number of skipped is still a clean apply —
            # skipped means "no action needed" (entity already existed,
            # relation endpoint missing etc.), which is a success outcome.
            new_status = BatchStatus.APPLIED
        elif applied == 0 and rejected == 0 and skipped > 0:
            # All candidates turned into no-ops. Semantically the batch
            # succeeded — nothing changed but nothing failed. Without this
            # branch the batch ended up in MIXED which implied partial
            # failure.
            new_status = BatchStatus.APPLIED
        elif rejected > 0 and applied == 0 and skipped == 0:
            new_status = BatchStatus.REJECTED
        else:
            new_status = BatchStatus.MIXED

        conn.execute(
            "UPDATE staging_batches SET status = ? WHERE id = ?",
            (new_status.value, batch_id),
        )
        if commit:
            conn.commit()

    def _persist_batch(self, batch: IntakeBatch) -> None:
        conn = self.storage._conn
        conn.execute(
            """INSERT INTO staging_batches
                 (id, raw_text, source_type, source_author, source_channel,
                  session_id, status, metadata, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                batch.id,
                batch.raw_text,
                batch.source_type,
                batch.source_author,
                batch.source_channel,
                batch.session_id,
                batch.status.value,
                json.dumps(batch.metadata, ensure_ascii=False),
                _dt_to_str(batch.created_at),
            ),
        )
        for cand in batch.candidates:
            conn.execute(
                """INSERT INTO staging_candidates
                    (id, batch_id, candidate_type, payload, status,
                     applied_target_id, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    cand.id,
                    cand.batch_id,
                    cand.candidate_type.value,
                    json.dumps(cand.payload, ensure_ascii=False),
                    cand.status.value,
                    cand.applied_target_id,
                    cand.notes,
                    _dt_to_str(cand.created_at),
                ),
            )
        conn.commit()

    def _candidates_for_batches(
        self, batch_ids: list[str]
    ) -> dict[str, list[IntakeCandidate]]:
        if not batch_ids:
            return {}
        placeholders = ",".join("?" for _ in batch_ids)
        rows = self.storage._conn.execute(
            f"""SELECT * FROM staging_candidates
                WHERE batch_id IN ({placeholders})
                ORDER BY batch_id ASC, created_at ASC""",
            batch_ids,
        ).fetchall()
        grouped = {batch_id: [] for batch_id in batch_ids}
        for row in rows:
            grouped.setdefault(row["batch_id"], []).append(self._row_to_candidate(row))
        return grouped

    def _row_to_batch(self, row) -> IntakeBatch:
        metadata_raw = row["metadata"] if "metadata" in row.keys() else "{}"
        try:
            metadata = json.loads(metadata_raw) if metadata_raw else {}
        except json.JSONDecodeError:
            metadata = {}

        batch = IntakeBatch(
            id=row["id"],
            raw_text=row["raw_text"],
            source_type=row["source_type"],
            source_author=row["source_author"] or "",
            source_channel=row["source_channel"] or "",
            session_id=row["session_id"],
            status=BatchStatus(row["status"]),
            metadata=metadata,
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )
        return batch

    def _row_to_candidate(self, row) -> IntakeCandidate:
        payload_raw = row["payload"]
        try:
            payload = json.loads(payload_raw) if payload_raw else {}
        except json.JSONDecodeError:
            payload = {}
        return IntakeCandidate(
            id=row["id"],
            batch_id=row["batch_id"],
            candidate_type=CandidateType(row["candidate_type"]),
            payload=payload,
            status=CandidateStatus(row["status"]),
            applied_target_id=row["applied_target_id"],
            notes=row["notes"] or "",
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )
