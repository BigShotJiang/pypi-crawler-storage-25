"""Computed recommendation views derived from current state."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta
from typing import Optional

from engram.models.governance import GovernanceCandidateStatus, GovernanceCandidateType
from engram.models.health import LoopKind, LoopSeverity
from engram.models.retention import (
    RecommendationKind,
    RecommendationSeverity,
    RecommendationView,
    RetentionTargetKind,
)
from engram.models.verification import VerificationStatus
from engram.models.verification import VerificationRequestStatus
from engram.quality.diagnostics import Diagnostics
from engram.retention.service import RetentionService
from engram.storage.sqlite_store import SQLiteStorage


class RecommendationService:
    def __init__(
        self,
        storage: SQLiteStorage,
        retention_service: RetentionService,
        diagnostics: Diagnostics,
    ) -> None:
        self.storage = storage
        self.retention_service = retention_service
        self.diagnostics = diagnostics

    def list_recommendations(
        self,
        *,
        kind: str | None = None,
        limit: int = 50,
        max_open_loops: int = 50,
        stale_days: int | None = None,
    ) -> list[RecommendationView]:
        rows = [
            *self._stale_decision_recommendations(limit=limit),
            *self._open_loop_escalations(limit=limit, max_open_loops=max_open_loops, stale_days=stale_days),
            *self._merge_recommendations(limit=limit),
            *self._follow_up_task_recommendations(
                limit=limit,
                max_open_loops=max_open_loops,
                stale_days=stale_days,
            ),
        ]
        if kind is not None:
            rows = [row for row in rows if row.kind.value == kind]
        severity_order = {
            RecommendationSeverity.CRITICAL: 0,
            RecommendationSeverity.WARNING: 1,
        }
        rows.sort(key=lambda row: (severity_order[row.severity], row.title))
        return rows[:limit]

    def get_recommendation(
        self,
        recommendation_id: str,
        *,
        max_open_loops: int = 50,
        stale_days: int | None = None,
    ) -> Optional[RecommendationView]:
        for row in self.list_recommendations(
            limit=200,
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        ):
            if row.id == recommendation_id:
                return row
        return None

    def _stale_decision_recommendations(self, *, limit: int) -> list[RecommendationView]:
        rows: list[RecommendationView] = []
        for decision in self.storage.list_decisions(limit=max(limit * 4, 100)):
            if decision.status.value == "superseded":
                continue
            due = (
                decision.verification_due_at is not None
                and decision.verification_due_at <= datetime.now()
            )
            if (
                decision.verification_status is not VerificationStatus.STALE
                and not due
            ):
                continue
            if self.storage.find_open_verification_request("decision", decision.id) is not None:
                continue
            if self.retention_service.is_pinned(RetentionTargetKind.DECISION, decision.id):
                continue
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.STALE_DECISION,
                    severity=RecommendationSeverity.WARNING,
                    target_kind="decision",
                    target_id=decision.id,
                    title=f"Review stale decision: {decision.title}",
                    detail=decision.summary,
                    recommended_action=f"engram verification-request decision {decision.id} --reason stale_recommendation",
                    evidence=[
                        {
                            "verification_status": decision.verification_status.value,
                            "verification_due_at": (
                                decision.verification_due_at.isoformat()
                                if decision.verification_due_at
                                else None
                            ),
                            "source_kind": decision.source_kind,
                            "source_id": decision.source_id,
                        }
                    ],
                )
            )
            if len(rows) >= limit:
                break
        return rows

    def _open_loop_escalations(
        self,
        *,
        limit: int,
        max_open_loops: int,
        stale_days: int | None,
    ) -> list[RecommendationView]:
        recent_runs = [
            self.storage.get_maintenance_run(run.id)
            for run in self.storage.list_maintenance_runs(limit=5)
        ]
        current_report = self.diagnostics.run(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )
        loop_counts: Counter[tuple[str, str]] = Counter()
        latest_meta: dict[tuple[str, str], dict] = {}

        for run in recent_runs:
            if run is None:
                continue
            for item in run.items:
                key = (item.kind, item.target_id or item.title)
                loop_counts[key] += 1
                latest_meta[key] = {
                    "kind": item.kind,
                    "target_id": item.target_id or item.title,
                    "title": item.title,
                    "detail": item.detail,
                    "recommended_action": item.recommended_action or "Review recurring maintenance issue.",
                }

        rows: list[RecommendationView] = []
        for key, count in loop_counts.items():
            if count < 2:
                continue
            meta = latest_meta[key]
            severity = (
                RecommendationSeverity.CRITICAL
                if count >= 3
                else RecommendationSeverity.WARNING
            )
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.OPEN_LOOP_ESCALATION,
                    severity=severity,
                    target_kind="open_loop",
                    target_id=meta["target_id"],
                    title=f"Escalate recurring open loop: {meta['title']}",
                    detail=meta["detail"],
                    recommended_action=meta["recommended_action"],
                    evidence=[
                        {
                            "kind": meta["kind"],
                            "repeat_count": count,
                            "current_open_loops": len(current_report.open_loops),
                        }
                    ],
                )
            )
            if len(rows) >= limit:
                break
        seen_ids = {row.id for row in rows}
        age_cutoff = datetime.now() - timedelta(days=7)
        for loop in current_report.open_loops:
            if len(rows) >= limit:
                break
            if loop.created_at is None or loop.created_at > age_cutoff:
                continue
            row = RecommendationView(
                kind=RecommendationKind.OPEN_LOOP_ESCALATION,
                severity=RecommendationSeverity.WARNING,
                target_kind="open_loop",
                target_id=loop.target_id or loop.title,
                title=f"Escalate aging open loop: {loop.title}",
                detail=loop.detail,
                recommended_action=loop.recommended_action or "Review recurring maintenance issue.",
                evidence=[
                    {
                        "kind": loop.kind.value,
                        "created_at": loop.created_at.isoformat(),
                        "current_open_loops": len(current_report.open_loops),
                    }
                ],
            )
            if row.id in seen_ids:
                continue
            rows.append(row)
            seen_ids.add(row.id)
        return rows

    def _merge_recommendations(self, *, limit: int) -> list[RecommendationView]:
        rows: list[RecommendationView] = []
        candidates = self.storage.list_governance_candidates(
            status=GovernanceCandidateStatus.OPEN,
            candidate_type=GovernanceCandidateType.MERGE,
            limit=max(limit * 4, 100),
        )
        for candidate in candidates:
            policy_conflicts: list[str] = []
            if self.retention_service.is_pinned(RetentionTargetKind.ENTITY, candidate.entity_id):
                policy_conflicts.append("pin")
            if (
                candidate.related_entity_id
                and self.retention_service.is_pinned(
                    RetentionTargetKind.ENTITY,
                    candidate.related_entity_id,
                )
            ):
                policy_conflicts.append("pin")
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.MERGE_RECOMMENDATION,
                    severity=(
                        RecommendationSeverity.CRITICAL
                        if candidate.score >= 0.95
                        else RecommendationSeverity.WARNING
                    ),
                    target_kind="governance_candidate",
                    target_id=candidate.id,
                    title=(
                        "Review merge candidate: "
                        f"{candidate.details.get('primary_name', candidate.entity_id)}"
                    ),
                    detail=candidate.rationale,
                    recommended_action=f"engram governance-resolve {candidate.id} approve",
                    evidence=[
                        {
                            "candidate_type": candidate.candidate_type.value,
                            "score": candidate.score,
                            "entity_id": candidate.entity_id,
                            "related_entity_id": candidate.related_entity_id,
                            "details": candidate.details,
                        }
                    ],
                    policy_conflicts=sorted(set(policy_conflicts)),
                )
            )
            if len(rows) >= limit:
                break
        return rows

    def _follow_up_task_recommendations(
        self,
        *,
        limit: int,
        max_open_loops: int,
        stale_days: int | None,
    ) -> list[RecommendationView]:
        rows: list[RecommendationView] = []
        seen: set[tuple[str, str]] = set()
        now = datetime.now()

        verification_rows = self.storage.list_verification_requests(
            status=VerificationRequestStatus.OPEN,
            limit=max(limit * 4, 100),
        )
        for request in verification_rows:
            age_days = max((now - request.requested_at).days, 0)
            if age_days < 3:
                continue
            policy_conflicts: list[str] = []
            target_kind = request.target_kind.lower()
            if target_kind in {"fact", "decision"} and self.retention_service.is_pinned(
                RetentionTargetKind(target_kind),
                request.target_id,
            ):
                policy_conflicts.append("pin")
            if request.entity_id and self.retention_service.is_pinned(
                RetentionTargetKind.ENTITY,
                request.entity_id,
            ):
                policy_conflicts.append("pin")
            key = ("verification_request", request.id)
            if key in seen:
                continue
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.FOLLOW_UP_TASK,
                    severity=(
                        RecommendationSeverity.CRITICAL
                        if age_days >= 7
                        else RecommendationSeverity.WARNING
                    ),
                    target_kind="verification_request",
                    target_id=request.id,
                    title=f"Follow up verification request: {request.target_kind}:{request.target_id}",
                    detail=request.reason,
                    recommended_action=f"engram verification-show {request.id}",
                    evidence=[
                        {
                            "request_age_days": age_days,
                            "request_reason": request.reason,
                            "request_target_kind": request.target_kind,
                            "request_target_id": request.target_id,
                            "requested_by": request.requested_by,
                        }
                    ],
                    policy_conflicts=sorted(set(policy_conflicts)),
                )
            )
            seen.add(key)
            if len(rows) >= limit:
                return rows

        governance_rows = self.storage.list_governance_candidates(
            status=GovernanceCandidateStatus.OPEN,
            limit=max(limit * 4, 100),
        )
        for candidate in governance_rows:
            if candidate.candidate_type not in {
                GovernanceCandidateType.MERGE,
                GovernanceCandidateType.SPLIT,
            }:
                continue
            age_days = max((now - candidate.created_at).days, 0)
            if candidate.score < 0.90 and age_days < 3:
                continue
            policy_conflicts: list[str] = []
            if self.retention_service.is_pinned(RetentionTargetKind.ENTITY, candidate.entity_id):
                policy_conflicts.append("pin")
            if (
                candidate.related_entity_id
                and self.retention_service.is_pinned(
                    RetentionTargetKind.ENTITY,
                    candidate.related_entity_id,
                )
            ):
                policy_conflicts.append("pin")
            key = ("governance_candidate", candidate.id)
            if key in seen:
                continue
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.FOLLOW_UP_TASK,
                    severity=(
                        RecommendationSeverity.CRITICAL
                        if candidate.score >= 0.95 or age_days >= 7
                        else RecommendationSeverity.WARNING
                    ),
                    target_kind="governance_candidate",
                    target_id=candidate.id,
                    title=f"Follow up governance candidate: {candidate.candidate_type.value}",
                    detail=candidate.rationale,
                    recommended_action=f"engram governance-show {candidate.id}",
                    evidence=[
                        {
                            "candidate_type": candidate.candidate_type.value,
                            "candidate_score": candidate.score,
                            "candidate_age_days": age_days,
                            "entity_id": candidate.entity_id,
                            "related_entity_id": candidate.related_entity_id,
                        }
                    ],
                    policy_conflicts=sorted(set(policy_conflicts)),
                )
            )
            seen.add(key)
            if len(rows) >= limit:
                return rows

        recent_runs = [
            self.storage.get_maintenance_run(run.id)
            for run in self.storage.list_maintenance_runs(limit=5)
        ]
        loop_counts: Counter[tuple[str, str]] = Counter()
        for run in recent_runs:
            if run is None:
                continue
            for item in run.items:
                key = (item.kind, item.target_id or item.title)
                loop_counts[key] += 1

        current_report = self.diagnostics.run(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )
        for loop in current_report.open_loops:
            if not loop.recommended_action:
                continue
            if loop.kind in {LoopKind.VERIFICATION_BACKLOG, LoopKind.ENTITY_GOVERNANCE}:
                continue
            age_days = None
            if loop.created_at is not None:
                age_days = max((now - loop.created_at).days, 0)
            repeat_count = loop_counts.get((loop.kind.value, loop.target_id or loop.title), 0)
            if (
                loop.severity is not LoopSeverity.CRITICAL
                and repeat_count < 2
                and (age_days is None or age_days < 7)
            ):
                continue
            target_id = loop.target_id or loop.title
            key = ("open_loop", target_id)
            if key in seen:
                continue
            evidence = [
                {
                    "loop_kind": loop.kind.value,
                    "loop_severity": loop.severity.value,
                    "loop_age_days": age_days,
                    "repeat_count": repeat_count,
                }
            ]
            rows.append(
                RecommendationView(
                    kind=RecommendationKind.FOLLOW_UP_TASK,
                    severity=(
                        RecommendationSeverity.CRITICAL
                        if loop.severity is LoopSeverity.CRITICAL
                        else RecommendationSeverity.WARNING
                    ),
                    target_kind="open_loop",
                    target_id=target_id,
                    title=f"Follow up open loop: {loop.title}",
                    detail=loop.detail,
                    recommended_action=loop.recommended_action,
                    evidence=evidence,
                )
            )
            seen.add(key)
            if len(rows) >= limit:
                return rows

        return rows
