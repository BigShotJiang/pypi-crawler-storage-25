"""Rule-based extractor — NER + fact extraction + relation extraction."""

from __future__ import annotations

import copy
import re
from typing import Optional

from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.relation import Relation
from engram.models.source import Source
from engram.extraction.ner.english import extract_english_entities
from engram.extraction.ner.korean import extract_korean_entities
from engram.extraction.ner.cjk import extract_cjk_entities


# Fact extraction patterns: "Subject <verb> Object"
_FACT_PATTERNS = [
    # English: "X is/was the Y of Z"
    re.compile(
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+'
        r'(?:is|was|serves?\s+as|became|joined|founded|leads?|runs?|heads?)\s+'
        r'(?:the\s+)?(.{1,200}?)(?:\.|,|;|$)',
        re.MULTILINE,
    ),
    # English: "X, the Y of Z"
    re.compile(
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+),\s+'
        r'(?:the\s+)?(\w[\w\s]{0,200}?)(?:\.|,|;|$)',
        re.MULTILINE,
    ),
]

# Relation patterns
_RELATION_PATTERNS = [
    # "X is the CEO of Y" → X -[CEO_OF]-> Y
    re.compile(
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+'
        r'(?:is|was)\s+(?:the\s+)?'
        r'(CEO|CTO|CFO|COO|founder|co-founder|president|director|head|member|partner)\s+'
        r'(?:of|at)\s+'
        r'([A-Z][\w\s]*?)(?:\.|,|;|$)',
        re.IGNORECASE | re.MULTILINE,
    ),
    # "X works at/for Y"
    re.compile(
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+'
        r'(?:works?\s+(?:at|for)|joined|left)\s+'
        r'([A-Z][\w\s]*?)(?:\.|,|;|$)',
        re.MULTILINE,
    ),
]

# Predicate normalization
_ROLE_KEYWORDS = frozenset({
    "ceo", "cto", "cfo", "coo", "founder", "co-founder",
    "president", "director", "head", "member", "partner",
    "manager", "lead", "engineer", "scientist", "analyst",
})


class RegexExtractor:
    """Rule-based entity, fact, and relation extraction.

    Improvements over the earlier extractor baseline:
    - Context-aware entity type classification
    - Dictionary-based Korean NER (not "any 2-4 hangul chars")
    - Deduplication at extraction time
    - Confidence scoring per pattern
    """

    def __init__(self, default_source: Optional[Source] = None):
        self.default_source = default_source or Source()

    def extract_entities(self, text: str) -> list[Entity]:
        """Extract named entities from text across all supported languages."""
        entities: list[Entity] = []
        seen: set[str] = set()

        # English NER
        for e in extract_english_entities(text):
            key = e.name.lower()
            if key not in seen:
                seen.add(key)
                entities.append(e)

        # Korean NER
        for e in extract_korean_entities(text):
            key = e.name.lower()
            if key not in seen:
                seen.add(key)
                entities.append(e)

        # CJK NER
        for e in extract_cjk_entities(text):
            key = e.name.lower()
            if key not in seen:
                seen.add(key)
                entities.append(e)

        return entities

    def extract_facts(self, text: str, entities: list[Entity]) -> list[Fact]:
        """Extract facts from text, grounded against known entities."""
        facts: list[Fact] = []
        entity_names = {e.name.lower(): e for e in entities}

        for pattern in _FACT_PATTERNS:
            for m in pattern.finditer(text):
                subject_text = m.group(1).strip()
                object_text = m.group(2).strip()

                # Ground subject to known entity
                subject_key = subject_text.lower()
                entity = entity_names.get(subject_key)
                if not entity:
                    continue

                # Determine predicate
                predicate = self._classify_predicate(object_text)

                # Truncate overly long objects
                if len(object_text) > 200:
                    object_text = object_text[:200]

                # Copy source to avoid shared mutable reference
                fact_source = copy.copy(self.default_source)
                facts.append(Fact(
                    entity_id=entity.id,
                    subject=entity.name,
                    predicate=predicate,
                    object=object_text,
                    raw_text=m.group(0).strip(),
                    source=fact_source,
                    confidence=0.5,  # Will be recomputed by quality gate
                ))

        return facts

    def extract_relations(self, text: str, entities: list[Entity]) -> list[Relation]:
        """Extract directed relations between entities."""
        relations: list[Relation] = []
        entity_names = {e.name.lower(): e for e in entities}

        for pattern in _RELATION_PATTERNS:
            for m in pattern.finditer(text):
                groups = m.groups()
                if len(groups) == 3:
                    # Pattern: X is ROLE of Y
                    subject = groups[0].strip()
                    role = groups[1].strip().upper()
                    obj = groups[2].strip()
                    relation_type = f"{role}_OF"
                elif len(groups) == 2:
                    # Pattern: X works at Y
                    subject = groups[0].strip()
                    obj = groups[1].strip()
                    relation_type = "WORKS_AT"
                else:
                    continue

                # Ground to known entities
                from_entity = entity_names.get(subject.lower())
                to_entity = entity_names.get(obj.lower())

                if from_entity and to_entity:
                    relations.append(Relation(
                        from_entity_id=from_entity.id,
                        to_entity_id=to_entity.id,
                        relation_type=relation_type,
                    ))

        return relations

    def _classify_predicate(self, object_text: str) -> str:
        """Determine the predicate type from the object text."""
        lower = object_text.lower()
        for keyword in _ROLE_KEYWORDS:
            if keyword in lower:
                return "role"
        if any(w in lower for w in ("founded", "started", "created", "launched")):
            return "action"
        if any(w in lower for w in ("based in", "located", "lives in", "moved to")):
            return "location"
        if any(w in lower for w in ("invested", "fund", "raised", "capital")):
            return "investment"
        return "attribute"
