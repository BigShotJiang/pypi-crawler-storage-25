"""CJK (Chinese/Japanese) named entity recognition — basic fallback."""

from __future__ import annotations

import re

from engram.models.entity import Entity

# Common Chinese surnames (top ~50)
_CHINESE_SURNAMES = frozenset({
    "王", "李", "张", "刘", "陈", "杨", "黄", "赵", "吴", "周",
    "徐", "孙", "马", "朱", "胡", "郭", "林", "何", "高", "罗",
    "郑", "梁", "谢", "宋", "唐", "韩", "曹", "许", "邓", "萧",
    "冯", "曾", "程", "蔡", "彭", "潘", "袁", "于", "董", "余",
    "苏", "叶", "吕", "魏", "蒋", "田", "杜", "丁", "沈", "姜",
})

# Common Japanese surnames (top ~50)
_JAPANESE_SURNAMES = frozenset({
    "佐藤", "鈴木", "高橋", "田中", "伊藤", "渡辺", "山本", "中村",
    "小林", "加藤", "吉田", "山田", "佐々木", "松本", "井上", "木村",
    "林", "斎藤", "清水", "山崎", "池田", "橋本", "阿部", "石川",
    "山下", "中島", "前田", "藤田", "小川", "後藤", "岡田", "長谷川",
    "村上", "近藤", "石井", "遠藤", "坂本", "青木", "藤井", "西村",
    "福田", "太田", "三浦", "藤原", "松田", "岡本", "中川", "中野",
})

# Chinese name: surname(1) + given(1-2) = 2-3 chars
_CN_NAME_PATTERN = re.compile(r'([\u4E00-\u9FFF])([\u4E00-\u9FFF]{1,2})')

# Japanese name: surname(1-3 chars) + given(1-3 chars)
_JP_SURNAME_PATTERN = re.compile(
    '(' + '|'.join(re.escape(s) for s in _JAPANESE_SURNAMES) + r')([\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]{1,3})'
)


def extract_cjk_entities(text: str) -> list[Entity]:
    """Extract Chinese and Japanese named entities from text.

    Basic approach:
    - Chinese: surname dictionary (1 char) + given name (1-2 chars)
    - Japanese: surname dictionary (1-3 chars) + given name (1-3 chars)
    """
    entities: list[Entity] = []
    seen: set[str] = set()

    # Chinese names
    for m in _CN_NAME_PATTERN.finditer(text):
        surname = m.group(1)
        if surname in _CHINESE_SURNAMES:
            name = m.group(0)
            if name not in seen:
                seen.add(name)
                entities.append(Entity(name=name, entity_type="person"))

    # Japanese names
    for m in _JP_SURNAME_PATTERN.finditer(text):
        name = m.group(0)
        if name not in seen:
            seen.add(name)
            entities.append(Entity(name=name, entity_type="person"))

    return entities
