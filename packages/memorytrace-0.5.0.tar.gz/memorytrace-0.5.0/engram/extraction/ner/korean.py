"""Korean named entity recognition — context-based approach.

Previous approach: detect all "surname + 2-3 syllables" then blocklist false positives.
Problem: Korean has thousands of common words starting with surname characters. Endless blocklist.

New approach: require POSITIVE EVIDENCE that a word is a person name.
  1. Name + honorific/title pattern: "김민수 목사님", "박지영 대표"
  2. Name introduction pattern: "김민수라는 사람"
  3. 2-syllable name + particle: "이준은" (top-10 surname, not common noun)
  4. Bare 3-syllable with TOP-10 surname: only the most common surnames, only 3-syllable
  5. Organization keywords: 주식회사, 재단, 대학 etc.
"""

from __future__ import annotations

import re

from engram.models.entity import Entity

# Top 10 Korean surnames (covers ~65% of Korean people)
# Only these are trusted for "bare name" detection (3-syllable, no context needed)
_TOP_SURNAMES = frozenset({
    "김", "이", "박", "최", "정", "강", "조", "윤", "장", "임",
})

# All known Korean surnames — require nearby honorific/title to detect
_ALL_SURNAMES = _TOP_SURNAMES | frozenset({
    "한", "오", "서", "신", "권", "황", "안", "송", "류", "전",
    "홍", "고", "문", "양", "손", "배", "백", "허", "유", "남",
    "심", "노", "하", "곽", "성", "차", "주", "우", "구", "민",
    "진", "나", "지", "엄", "채", "원", "천", "방", "공", "현",
    "함", "변", "염", "석", "선", "설", "마", "길", "연", "위",
    "표", "명", "기", "반", "라", "왕", "금", "옥", "육", "추",
    "탁", "도", "감", "봉", "모", "맹", "제", "빈", "판", "피",
    "섭", "어", "음", "사", "가", "복", "태", "목", "형", "편",
    "승", "뇌", "범", "상", "갈", "예", "경", "럼", "온", "소",
})

# Korean organization keywords
_KR_ORG_KEYWORDS = frozenset({
    "주식회사", "재단", "협회", "학회", "그룹", "홀딩스", "파트너스",
    "캐피탈", "벤처스", "랩", "랩스", "연구소", "대학교", "대학",
    "병원", "은행", "증권", "보험", "카드",
})

# Honorifics/titles that confirm a preceding word is a person name
_HONORIFICS = (
    "씨", "님", "선생", "교수", "박사", "대표", "사장", "이사",
    "부장", "과장", "차장", "팀장", "실장", "원장", "학장", "총장",
    "목사", "신부", "스님", "장로", "집사", "권사",
    "의원", "판사", "검사", "변호사", "회계사",
)

# Korean particles (조사)
_KR_PARTICLES = tuple(sorted(
    ("은", "는", "이", "가", "을", "를", "의", "에", "와", "과",
     "도", "만", "으로", "로", "에서", "부터", "까지", "라고",
     "에게", "한테", "께서"),
    key=len, reverse=True,
))

# Organization pattern
_KR_ORG_PATTERN = re.compile(
    r'((?:[가-힣A-Za-z]{1,15})\s*(?:'
    + '|'.join(sorted(_KR_ORG_KEYWORDS, key=len, reverse=True))
    + r'))'
)

# Name + honorific/title pattern
# Matches: "김민수 목사", "박지영 대표님", "이철수씨", "홍길동 선생님"
_NAME_WITH_TITLE = re.compile(
    r'([가-힣]{2,4})\s*('
    + '|'.join(sorted(_HONORIFICS, key=len, reverse=True))
    + r')'
)

# Name introduction pattern: "~라는 사람/분"
_NAME_INTRO = re.compile(
    r'([가-힣]{2,4})(?:이)?(?:라는|란)\s*(?:사람|분|친구|동료|지인)'
)

# 2-syllable name + particle pattern (for detecting short names like 이준, 김봄)
_TWO_SYLLABLE_NAME_WITH_PARTICLE = re.compile(
    r'([가-힣]{2})(?:은|는|이|가|을|를|과|와|도|에게|한테)'
)

# Structural suffixes — words ending with these indicate institutions/roles, not names
_STRUCTURAL_SUFFIXES = ("교", "사", "부", "원", "관", "당", "회", "국", "청", "실")

# Common 2-syllable nouns that start with top surnames — must not be detected as names
_COMMON_TWO_SYLLABLE_NOUNS = frozenset({
    "이슈", "이후", "이전", "이상", "이하", "이미", "이번",
    "이름", "이동", "이용", "이해", "이유",
    "김치",
    "박스",
    "최근", "최대", "최소", "최초",
    "정말", "정도", "정리", "정보", "정신", "정확", "정상",
    "강도", "강화", "강남", "강력", "강의",
    "조건", "조치", "조금", "조각", "조합",
    "장면", "장비", "장점", "장기",
    "임무", "임시",
    "윤리",
})


def extract_korean_entities(text: str) -> list[Entity]:
    """Extract Korean named entities using context-based approach.

    Only detects names when there is positive evidence:
    1. Organizations: keyword-based (always reliable)
    2. Name + honorific/title: "김민수 목사님" -> high confidence
    3. Name introduction: "김민수라는 사람" -> high confidence
    4. 2-syllable name + particle: "이준은" -> top-10 surname + not common noun
    5. Bare 3-syllable + top-10 surname: conservative fallback
    """
    entities: list[Entity] = []
    seen: set[str] = set()

    def _add(name: str, entity_type: str = "person") -> None:
        key = name.lower()
        if key not in seen and len(name) >= 2:
            seen.add(key)
            entities.append(Entity(name=name, entity_type=entity_type))

    # 1. Organizations with keywords
    for m in _KR_ORG_PATTERN.finditer(text):
        org_name = m.group(0).strip()
        _add(org_name, "organization")

    # 2. Name + honorific/title (high confidence, all surnames)
    for m in _NAME_WITH_TITLE.finditer(text):
        candidate = _strip_particles(m.group(1))
        if 2 <= len(candidate) <= 4 and candidate[0] in _ALL_SURNAMES:
            _add(candidate)

    # 3. Name introduction pattern (high confidence, all surnames)
    for m in _NAME_INTRO.finditer(text):
        candidate = _strip_particles(m.group(1))
        if 2 <= len(candidate) <= 4 and candidate[0] in _ALL_SURNAMES:
            _add(candidate)

    # 4. 2-syllable names with particle context (top-10 surnames only)
    for m in _TWO_SYLLABLE_NAME_WITH_PARTICLE.finditer(text):
        candidate = m.group(1)
        if len(candidate) != 2:
            continue
        if candidate[0] not in _TOP_SURNAMES:
            continue
        if candidate in _COMMON_TWO_SYLLABLE_NOUNS:
            continue
        if candidate[-1] in _STRUCTURAL_SUFFIXES:
            continue
        _add(candidate)

    # 5. Bare 3-syllable names (conservative: top-10 surnames only)
    # Also reject words ending with structural suffixes (교/사/부/원/관/당 etc.)
    # These indicate institutions/roles, not given names.
    for word in re.findall(r'[가-힣]+', text):
        name = _strip_particles(word)
        if len(name) != 3:
            continue
        if name[0] not in _TOP_SURNAMES:
            continue
        if name[-1] in _STRUCTURAL_SUFFIXES:
            continue
        _add(name)

    return entities


def _strip_particles(word: str) -> str:
    """Strip trailing Korean particles (조사) from a word."""
    for particle in _KR_PARTICLES:
        if word.endswith(particle) and len(word) > len(particle):
            return word[:-len(particle)]
    return word
