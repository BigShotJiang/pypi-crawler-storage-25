"""DebugService — lifecycle for debug sessions, hypotheses, and evidence.

All writes go through here so the engine stays a thin facade. Queries use
the storage backend's raw SQLite connection for simplicity; if other
backends ever land we can lift these methods into the Protocol.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §5.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from engram.exceptions import StorageError
from engram.models.debug import (
    DebugSession,
    DebugSessionStatus,
    Evidence,
    EvidenceResult,
    Hypothesis,
    HypothesisStatus,
)
from engram.quality.pii import mask_if_needed
from engram.quality.gate import QualityGate
from engram.storage.sqlite_store import SQLiteStorage


def _dt_to_str(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _str_to_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


class DebugService:
    """Owns debug_sessions / debug_hypotheses / debug_evidence.

    Every user-authored text field (``bug_description``, ``hypothesis.text``,
    ``evidence.text``, ``rejection_reason``, ``conclusion``) is run through
    the quality gate's PII policy before persistence. Debugging surfaces
    routinely capture stack traces and env dumps that embed secrets; without
    this step those would live forever in the debug tables.
    """

    def __init__(
        self,
        storage: SQLiteStorage,
        quality_gate: Optional[QualityGate] = None,
    ) -> None:
        self.storage = storage
        self._pii_detector = (
            getattr(quality_gate, "pii_detector", None)
            if quality_gate is not None
            else None
        )
        self._enable_pii = (
            bool(getattr(quality_gate, "enable_pii", True))
            if quality_gate is not None
            else True
        )

    def _mask(self, text: Optional[str]) -> Optional[str]:
        return mask_if_needed(self._pii_detector, text, enabled=self._enable_pii)

    # ── Session lifecycle ──

    def start_session(
        self,
        bug_description: str,
        related_session_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> DebugSession:
        if not bug_description or not bug_description.strip():
            raise ValueError("bug_description is required")
        # Mask before persisting — a bug report that embeds an auth token
        # from a failed request must not live verbatim in the DB.
        cleaned = self._mask(bug_description.strip()) or bug_description.strip()
        session = DebugSession(
            id=str(uuid.uuid4()),
            bug_description=cleaned,
            status=DebugSessionStatus.OPEN,
            related_session_id=related_session_id,
            started_at=datetime.now(),
            metadata=dict(metadata or {}),
        )
        conn = self.storage._conn
        conn.execute(
            """INSERT INTO debug_sessions
                (id, bug_description, status, conclusion, related_session_id,
                 started_at, closed_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session.id,
                session.bug_description,
                session.status.value,
                session.conclusion,
                session.related_session_id,
                _dt_to_str(session.started_at),
                _dt_to_str(session.closed_at),
                json.dumps(session.metadata, ensure_ascii=False),
            ),
        )
        conn.commit()
        return session

    def conclude(
        self,
        debug_session_id: str,
        conclusion: Optional[str] = None,
        status: DebugSessionStatus = DebugSessionStatus.RESOLVED,
    ) -> DebugSession:
        if status == DebugSessionStatus.OPEN:
            raise ValueError("cannot conclude a session into OPEN state")
        session = self.get_session(debug_session_id)
        if session is None:
            raise ValueError(f"Debug session {debug_session_id} not found")
        if session.status != DebugSessionStatus.OPEN:
            # Refuse to silently clobber a prior conclusion — the original
            # outcome is the authoritative audit record. Callers that need
            # to change their mind should delete/reopen explicitly.
            raise ValueError(
                f"Debug session {debug_session_id} already concluded with "
                f"status '{session.status.value}'"
            )
        closed_at = datetime.now()
        # Conclusions often reference the root cause verbatim ("fixed by
        # rotating token sk-..."), so mask here too.
        cleaned_conclusion = self._mask(conclusion)
        conn = self.storage._conn
        conn.execute(
            """UPDATE debug_sessions
               SET status = ?, conclusion = ?, closed_at = ?
               WHERE id = ?""",
            (
                status.value,
                cleaned_conclusion,
                _dt_to_str(closed_at),
                debug_session_id,
            ),
        )
        # Cascade abandon on any still-open hypotheses so the session is
        # internally consistent.
        conn.execute(
            """UPDATE debug_hypotheses
               SET status = 'abandoned', closed_at = ?
               WHERE debug_session_id = ? AND status = 'open'""",
            (_dt_to_str(closed_at), debug_session_id),
        )
        conn.commit()
        return self.get_session(debug_session_id)

    # ── Hypotheses ──

    def add_hypothesis(
        self,
        debug_session_id: str,
        text: str,
        confidence: float = 0.5,
    ) -> Hypothesis:
        if not text or not text.strip():
            raise ValueError("hypothesis text is required")
        session = self.get_session(debug_session_id, include_children=False)
        if session is None:
            raise ValueError(f"Debug session {debug_session_id} not found")
        if session.status != DebugSessionStatus.OPEN:
            raise ValueError(
                f"Cannot add hypotheses to a {session.status.value} session"
            )
        cleaned = self._mask(text.strip()) or text.strip()
        hyp = Hypothesis(
            id=str(uuid.uuid4()),
            debug_session_id=debug_session_id,
            text=cleaned,
            status=HypothesisStatus.OPEN,
            confidence=max(0.0, min(1.0, confidence)),
            created_at=datetime.now(),
        )
        conn = self.storage._conn
        conn.execute(
            """INSERT INTO debug_hypotheses
                (id, debug_session_id, text, status, rejection_reason,
                 confidence, created_at, closed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                hyp.id,
                hyp.debug_session_id,
                hyp.text,
                hyp.status.value,
                hyp.rejection_reason,
                hyp.confidence,
                _dt_to_str(hyp.created_at),
                _dt_to_str(hyp.closed_at),
            ),
        )
        conn.commit()
        return hyp

    def reject_hypothesis(
        self, hypothesis_id: str, reason: str
    ) -> Hypothesis:
        if not reason or not reason.strip():
            raise ValueError("rejection reason is required")
        hyp = self.get_hypothesis(hypothesis_id)
        if hyp is None:
            raise ValueError(f"Hypothesis {hypothesis_id} not found")
        if hyp.status != HypothesisStatus.OPEN:
            # Closed hypotheses keep their original outcome. Re-rejecting
            # would clobber the audit trail of why it closed the first time.
            raise ValueError(
                f"Hypothesis {hypothesis_id} is already {hyp.status.value}"
            )
        closed_at = datetime.now()
        cleaned_reason = self._mask(reason.strip()) or reason.strip()
        conn = self.storage._conn
        conn.execute(
            """UPDATE debug_hypotheses
               SET status = 'rejected', rejection_reason = ?, closed_at = ?
               WHERE id = ?""",
            (cleaned_reason, _dt_to_str(closed_at), hypothesis_id),
        )
        conn.commit()
        return self.get_hypothesis(hypothesis_id)

    def confirm_hypothesis(self, hypothesis_id: str) -> Hypothesis:
        hyp = self.get_hypothesis(hypothesis_id)
        if hyp is None:
            raise ValueError(f"Hypothesis {hypothesis_id} not found")
        if hyp.status != HypothesisStatus.OPEN:
            raise ValueError(
                f"Hypothesis {hypothesis_id} is already {hyp.status.value}"
            )
        closed_at = datetime.now()
        conn = self.storage._conn
        conn.execute(
            """UPDATE debug_hypotheses
               SET status = 'confirmed', closed_at = ?
               WHERE id = ?""",
            (_dt_to_str(closed_at), hypothesis_id),
        )
        conn.commit()
        return self.get_hypothesis(hypothesis_id)

    # ── Evidence ──

    def add_evidence(
        self,
        hypothesis_id: str,
        text: str,
        result: EvidenceResult = EvidenceResult.NEUTRAL,
        kind: str = "observation",
    ) -> Evidence:
        if not text or not text.strip():
            raise ValueError("evidence text is required")
        hyp = self.get_hypothesis(hypothesis_id)
        if hyp is None:
            raise ValueError(f"Hypothesis {hypothesis_id} not found")
        # Evidence is the highest-risk surface — stack traces, log excerpts,
        # and env dumps frequently embed tokens. Mask before persisting.
        cleaned = self._mask(text.strip()) or text.strip()
        evidence = Evidence(
            id=str(uuid.uuid4()),
            hypothesis_id=hypothesis_id,
            text=cleaned,
            result=result,
            kind=kind,
            created_at=datetime.now(),
        )
        conn = self.storage._conn
        conn.execute(
            """INSERT INTO debug_evidence
                (id, hypothesis_id, text, result, kind, created_at)
                VALUES (?, ?, ?, ?, ?, ?)""",
            (
                evidence.id,
                evidence.hypothesis_id,
                evidence.text,
                evidence.result.value,
                evidence.kind,
                _dt_to_str(evidence.created_at),
            ),
        )
        conn.commit()
        return evidence

    # ── Read ──

    def get_session(
        self, debug_session_id: str, include_children: bool = True
    ) -> Optional[DebugSession]:
        conn = self.storage._conn
        row = conn.execute(
            "SELECT * FROM debug_sessions WHERE id = ?", (debug_session_id,)
        ).fetchone()
        if row is None:
            return None
        session = self._row_to_session(row)
        if include_children:
            session.hypotheses = self._hypotheses_for_session(session.id)
        return session

    def get_hypothesis(
        self, hypothesis_id: str, include_evidence: bool = True
    ) -> Optional[Hypothesis]:
        conn = self.storage._conn
        row = conn.execute(
            "SELECT * FROM debug_hypotheses WHERE id = ?", (hypothesis_id,)
        ).fetchone()
        if row is None:
            return None
        hyp = self._row_to_hypothesis(row)
        if include_evidence:
            hyp.evidence = self._evidence_for_hypothesis(hyp.id)
        return hyp

    def list_sessions(
        self,
        status: Optional[DebugSessionStatus] = None,
        limit: int = 20,
    ) -> list[DebugSession]:
        conn = self.storage._conn
        query = "SELECT * FROM debug_sessions"
        params: list = []
        if status is not None:
            query += " WHERE status = ?"
            params.append(status.value)
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        sessions = [self._row_to_session(r) for r in rows]
        hypotheses_by_session = self._hypotheses_for_sessions([s.id for s in sessions])
        for s in sessions:
            s.hypotheses = hypotheses_by_session.get(s.id, [])
        return sessions

    def search_hypotheses(
        self,
        query: str,
        limit: int = 20,
        statuses: Optional[list[HypothesisStatus]] = None,
    ) -> list[Hypothesis]:
        """Case-insensitive substring search over hypothesis text.

        Useful for "has anyone tried X already?" — a rejected hypothesis
        surfaced by this query is the whole point of the feature.
        """
        conn = self.storage._conn
        needle = f"%{(query or '').strip()}%"
        sql = "SELECT * FROM debug_hypotheses WHERE text LIKE ? COLLATE NOCASE"
        params: list = [needle]
        if statuses:
            placeholders = ",".join("?" for _ in statuses)
            sql += f" AND status IN ({placeholders})"
            params.extend(s.value for s in statuses)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        hyps = [self._row_to_hypothesis(r) for r in rows]
        evidence_by_hypothesis = self._evidence_for_hypotheses([h.id for h in hyps])
        for h in hyps:
            h.evidence = evidence_by_hypothesis.get(h.id, [])
        return hyps

    # ── Row helpers ──

    def _hypotheses_for_session(self, session_id: str) -> list[Hypothesis]:
        return self._hypotheses_for_sessions([session_id]).get(session_id, [])

    def _hypotheses_for_sessions(
        self, session_ids: list[str]
    ) -> dict[str, list[Hypothesis]]:
        if not session_ids:
            return {}
        conn = self.storage._conn
        placeholders = ",".join("?" for _ in session_ids)
        rows = conn.execute(
            f"""SELECT * FROM debug_hypotheses
                WHERE debug_session_id IN ({placeholders})
                ORDER BY debug_session_id ASC, created_at ASC""",
            session_ids,
        ).fetchall()
        hyps = [self._row_to_hypothesis(r) for r in rows]
        evidence_by_hypothesis = self._evidence_for_hypotheses([h.id for h in hyps])
        grouped = {session_id: [] for session_id in session_ids}
        for h in hyps:
            h.evidence = evidence_by_hypothesis.get(h.id, [])
            grouped.setdefault(h.debug_session_id, []).append(h)
        return grouped

    def _evidence_for_hypothesis(self, hypothesis_id: str) -> list[Evidence]:
        return self._evidence_for_hypotheses([hypothesis_id]).get(hypothesis_id, [])

    def _evidence_for_hypotheses(
        self, hypothesis_ids: list[str]
    ) -> dict[str, list[Evidence]]:
        if not hypothesis_ids:
            return {}
        conn = self.storage._conn
        placeholders = ",".join("?" for _ in hypothesis_ids)
        rows = conn.execute(
            f"""SELECT * FROM debug_evidence
                WHERE hypothesis_id IN ({placeholders})
                ORDER BY hypothesis_id ASC, created_at ASC""",
            hypothesis_ids,
        ).fetchall()
        grouped = {hypothesis_id: [] for hypothesis_id in hypothesis_ids}
        for row in rows:
            grouped.setdefault(row["hypothesis_id"], []).append(
                self._row_to_evidence(row)
            )
        return grouped

    def _row_to_session(self, row) -> DebugSession:
        metadata_raw = row["metadata"] if "metadata" in row.keys() else "{}"
        try:
            metadata = json.loads(metadata_raw) if metadata_raw else {}
        except json.JSONDecodeError:
            metadata = {}
        return DebugSession(
            id=row["id"],
            bug_description=row["bug_description"],
            status=DebugSessionStatus(row["status"]),
            conclusion=row["conclusion"],
            related_session_id=row["related_session_id"],
            started_at=_str_to_dt(row["started_at"]) or datetime.now(),
            closed_at=_str_to_dt(row["closed_at"]),
            metadata=metadata,
        )

    def _row_to_hypothesis(self, row) -> Hypothesis:
        return Hypothesis(
            id=row["id"],
            debug_session_id=row["debug_session_id"],
            text=row["text"],
            status=HypothesisStatus(row["status"]),
            rejection_reason=row["rejection_reason"],
            confidence=float(row["confidence"] or 0.0),
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            closed_at=_str_to_dt(row["closed_at"]),
        )

    def _row_to_evidence(self, row) -> Evidence:
        return Evidence(
            id=row["id"],
            hypothesis_id=row["hypothesis_id"],
            text=row["text"],
            result=EvidenceResult(row["result"]),
            kind=row["kind"] or "observation",
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
        )
