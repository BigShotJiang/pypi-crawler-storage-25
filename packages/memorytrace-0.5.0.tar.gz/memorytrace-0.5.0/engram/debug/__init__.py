"""Debug-as-memory — OBSERVE / HYPOTHESIZE / EXPERIMENT / CONCLUDE."""

from engram.debug.service import DebugService

__all__ = ["DebugService"]
