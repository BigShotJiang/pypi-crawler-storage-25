"""Persisted in-process job runner."""

from __future__ import annotations

from datetime import datetime

from engram.models.job import JobRecord
from engram.storage.sqlite_store import SQLiteStorage


class JobRunnerService:
    """Create, lease, and transition persisted jobs."""

    def __init__(self, storage: SQLiteStorage):
        self.storage = storage

    def enqueue(
        self,
        job_type: str,
        payload: dict,
        *,
        max_attempts: int = 3,
    ) -> JobRecord:
        now = datetime.now()
        job = JobRecord(
            job_type=job_type,
            status="queued",
            payload=dict(payload),
            max_attempts=max_attempts,
            available_at=now,
            created_at=now,
            updated_at=now,
        )
        return self.storage.create_job(job)

    def get(self, job_id: str) -> JobRecord | None:
        return self.storage.get_job(job_id)

    def list(
        self,
        *,
        status: str | None = None,
        job_type: str | None = None,
        limit: int = 50,
    ) -> list[JobRecord]:
        return self.storage.list_jobs(status=status, job_type=job_type, limit=limit)

    def lease(self, *, limit: int, lease_owner: str) -> list[JobRecord]:
        return self.storage.lease_jobs(limit=limit, lease_owner=lease_owner)

    def mark_failed(self, job_id: str, error: str) -> JobRecord:
        job = self.storage.get_job(job_id)
        if job is None:
            raise ValueError(f"Job {job_id} not found")
        job.attempts += 1
        job.last_error = error
        job.updated_at = datetime.now()
        if job.attempts >= job.max_attempts:
            job.status = "dead_letter"
        else:
            # Re-queue for retry instead of leaving in a terminal "failed" state.
            job.status = "queued"
            job.leased_at = None
            job.lease_owner = None
        return self.storage.update_job(job)
