"""MemoryEngine — the main orchestrator that composes all modules.

This is the single public entry point for the Engram memory system.
No print() calls — all output is via structured return values.
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from engram.config import EngramConfig
from engram.exceptions import EntityAlreadyExistsError, EntityNotFoundError, SessionError
from engram.explanations.builder import ExplanationBuilder
from engram.freshness.service import FreshnessService
from engram.governance.service import EntityGovernanceService
from engram.models.entity import Entity, Tier
from engram.models.fact import Fact, FactApplicability, FactStatus
from engram.models.governance import GovernanceCandidateStatus, GovernanceCandidateType, GovernanceResolution
from engram.models.quality import Action, ValidationResult
from engram.models.retention import RecommendationView, RetentionPolicy, RetentionPolicyType, RetentionTargetKind
from engram.models.relation import Relation
from engram.models.search import (
    QueryPlan,
    RankingFactor,
    RetrievalContext,
    SearchHit,
    SearchOptions,
    SearchResult,
)
from engram.models.session import Session
from engram.models.scope import ScopeSelection
from engram.models.source import Source, SourceType
from engram.debug.service import DebugService
from engram.decisions.service import DecisionService
from engram.intake.service import IntakeService
from engram.jobs.service import JobRunnerService
from engram.maintenance.review import OperationsReviewService
from engram.maintenance.service import MaintenanceService
from engram.models.brief import EntityBrief, SessionBrief, SupportingHit
from engram.models.context_pack import ContextPack, ContextTransferResult
from engram.models.decision import DecisionRecord, DecisionStatus
from engram.models.debug import (
    DebugSession,
    DebugSessionStatus,
    Evidence,
    EvidenceResult,
    Hypothesis,
    HypothesisStatus,
)
from engram.models.health import HealthReport
from engram.models.intake import BatchStatus, IntakeApplyResult, IntakeBatch
from engram.models.maintenance import MaintenanceRun
from engram.models.memory_type import MemoryType, classify_fact
from engram.models.operations import OperationsReview
from engram.models.reference import ReferenceEdge
from engram.models.snapshot import Snapshot, SnapshotDiff
from engram.models.view import (
    ContextSearchResult,
    DecisionView,
    MaintenanceItemView,
    MaintenanceRunView,
)
from engram.models.verification import VerificationRequestStatus, VerificationResolution
from engram.quality.decay_policy import DecayPolicy
from engram.quality.diagnostics import Diagnostics
from engram.quality.gate import QualityGate
from engram.quality.pii import mask_if_needed
from engram.references.service import ReferenceService
from engram.recommendations.service import RecommendationService
from engram.retention.service import RetentionService
from engram.scopes.service import ScopeService
from engram.snapshots.service import SnapshotService
from engram.search.contextual import ContextSearchService
from engram.search.fts5_search import FTS5Search
from engram.search.planner import QueryPlanner
from engram.search.reranker import RerankingService
from engram.session.brief import BriefBuilder
from engram.session.context import build_session_context, list_masked_session_queries
from engram.session.manager import SessionManager, _USE_RECENT_PARENT
from engram.session.transfer import ContextPackBuilder
from engram.session.working_memory import WorkingMemory
from engram.storage.sqlite_store import SQLiteStorage


@dataclass
class StoreResult:
    """Result of a store operation."""
    entities_created: list[Entity] = field(default_factory=list)
    entities_updated: list[Entity] = field(default_factory=list)
    facts_added: list[Fact] = field(default_factory=list)
    facts_quarantined: list[Fact] = field(default_factory=list)
    facts_conflicted: list[Fact] = field(default_factory=list)
    relations_added: list[Relation] = field(default_factory=list)
    validations: list[ValidationResult] = field(default_factory=list)
    note_is_new: bool = True

    def to_dict(self) -> dict:
        return {
            "entities_created": [{"name": e.name, "type": e.entity_type} for e in self.entities_created],
            "entities_updated": [{"name": e.name, "type": e.entity_type} for e in self.entities_updated],
            "facts_added": [
                {"subject": f.subject, "predicate": f.predicate, "object": f.object}
                for f in self.facts_added
            ],
            "facts_quarantined": len(self.facts_quarantined),
            "facts_conflicted": len(self.facts_conflicted),
            "relations_added": [
                {"type": r.relation_type} for r in self.relations_added
            ],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class MemoryEngine:
    """Main entry point. Composes storage, search, extraction, quality, sessions.

    Design principles:
    - No print() — all output via structured return values
    - All writes go through quality gate
    - Session tracking for every operation
    """

    def __init__(self, config: Optional[EngramConfig] = None):
        self.config = config or EngramConfig()
        self.config.ensure_dirs()

        # Core components
        self.storage = SQLiteStorage(self.config.db_path)
        self.storage.initialize()
        self.search_engine = self._build_search_engine()
        self.quality_gate = QualityGate(self.config, self.storage)
        # Wire the PII detector into SessionManager so log_event() masks
        # target / detail strings before hitting session_events.
        self.session_mgr = SessionManager(
            self.storage,
            pii_detector=getattr(self.quality_gate, "pii_detector", None),
            enable_pii=bool(getattr(self.quality_gate, "enable_pii", True)),
        )
        # Per-type exponential decay; tweak via config.decay_policy in the
        # future. For now the defaults match docs §4.
        self.decay_policy: DecayPolicy = DecayPolicy()
        self.reference_service = ReferenceService(self.storage)
        self.decision_service = DecisionService(
            self.storage,
            reference_service=self.reference_service,
        )
        self.retention_service = RetentionService(self.storage)
        self.scope_service = ScopeService(self.storage)
        self.job_runner = JobRunnerService(self.storage)
        self.freshness_service = FreshnessService(self.storage, self.decay_policy)
        self.governance_service = EntityGovernanceService(self.storage)
        self.reranking_service = RerankingService(self.storage)
        self.query_planner = QueryPlanner()
        self.explanation_builder = ExplanationBuilder()
        self._diagnostics = Diagnostics(self.storage, self.config)
        self.recommendation_service = RecommendationService(
            self.storage,
            retention_service=self.retention_service,
            diagnostics=self._diagnostics,
        )

        # Optional markdown exporter
        self._md_exporter = None
        if self.config.enable_markdown_export:
            from engram.storage.markdown_export import MarkdownExporter
            self._md_exporter = MarkdownExporter(self.config.export_dir)

        # Extractor (lazy-loaded based on config)
        self._extractor = None

        # Working memory per session
        self._working_memories: dict[str, WorkingMemory] = {}

    @property
    def extractor(self):
        if self._extractor is None:
            self._extractor = self._build_extractor()
        return self._extractor

    def _mask_text(self, text: Optional[str]) -> Optional[str]:
        """Apply the quality gate's PII policy to a single string.

        Returned text is safe to persist into any text-bearing column
        (notes, session_events.target, debug.*) — secret-like patterns
        (SSN, API keys, emails, credit cards, KR phone, RRN) are replaced
        with ``[REDACTED]``.
        """
        return mask_if_needed(
            getattr(self.quality_gate, "pii_detector", None),
            text,
            enabled=bool(getattr(self.quality_gate, "enable_pii", True)),
        )

    def _build_retrieval_context(
        self,
        session_id: Optional[str],
        options: SearchOptions,
    ):
        context = options.context
        if context is None:
            from engram.models.search import RetrievalContext

            context = RetrievalContext()
            options.context = context
        if session_id:
            context.session_id = session_id
            wm = self._working_memories.get(session_id)
            if wm is not None:
                context.active_entity_ids = list(wm.get_active_entity_ids())
                context.recent_entity_ids = list(wm.get_active_entity_ids())
        return context

    def _scope_allows(
        self,
        scope_id: Optional[str],
        selection: Optional[ScopeSelection],
        allowed_scope_ids: set[str],
    ) -> bool:
        if selection is None or selection.primary_scope_id is None:
            return True
        if scope_id is None:
            return selection.include_global
        return scope_id in allowed_scope_ids

    def _filter_search_result_by_scope(
        self,
        result: SearchResult,
        scope_selection: Optional[ScopeSelection],
    ) -> SearchResult:
        if scope_selection is None or scope_selection.primary_scope_id is None:
            return result
        resolved = self.scope_service.resolve_selection(scope_selection)
        allowed_scope_ids = set(resolved.allowed_scope_ids)
        filtered_hits = []
        for hit in result.hits:
            allowed_facts = [
                fact
                for fact in hit.facts
                if self._scope_allows(fact.scope_id, scope_selection, allowed_scope_ids)
            ]
            if not allowed_facts:
                continue
            hit.facts = allowed_facts
            hit.snippet = allowed_facts[0].raw_text
            hit.ranking_factors.append(
                RankingFactor(
                    "scope_match",
                    0.0,
                    "hit contains evidence within the selected scope",
                )
            )
            filtered_hits.append(hit)
        result.hits = filtered_hits
        result.notes = [
            note
            for note in result.notes
            if self._scope_allows(note.get("scope_id"), scope_selection, allowed_scope_ids)
        ]
        result.total_count = len(result.hits)
        return result

    def _session_event_scope_metadata(
        self,
        scope_selection: Optional[ScopeSelection],
    ) -> tuple[str | None, dict]:
        if scope_selection is None or scope_selection.primary_scope_id is None:
            return None, {}
        resolved = self.scope_service.resolve_selection(scope_selection)
        return scope_selection.primary_scope_id, {
            "allowed_scope_ids": list(resolved.allowed_scope_ids),
            "include_global": bool(scope_selection.include_global),
        }

    @staticmethod
    def _to_supporting_hits(result, limit: int = 3) -> list[SupportingHit]:
        hits: list[SupportingHit] = []
        for hit in result.hits[:limit]:
            hits.append(
                SupportingHit(
                    entity_id=hit.entity.id,
                    entity_name=hit.entity.name,
                    entity_type=hit.entity.entity_type,
                    relevance_score=hit.relevance_score,
                    snippet=hit.snippet,
                    explanation=hit.explanation,
                )
            )
        return hits

    def _apply_retention_to_search_result(
        self,
        result: SearchResult,
        options: SearchOptions,
    ) -> SearchResult:
        if options.include_archived:
            return result
        filtered_hits = []
        for hit in result.hits:
            if self.retention_service.is_archive_only(RetentionTargetKind.ENTITY, hit.entity.id):
                continue
            original_facts = list(hit.facts)
            allowed_facts = [
                fact
                for fact in hit.facts
                if not self.retention_service.is_archive_only(RetentionTargetKind.FACT, fact.id)
            ]
            if original_facts and not allowed_facts:
                continue
            if allowed_facts:
                hit.facts = allowed_facts
                hit.snippet = allowed_facts[0].raw_text
            filtered_hits.append(hit)
        result.hits = filtered_hits
        result.notes = [
            note
            for note in result.notes
            if not self.retention_service.is_archive_only(
                RetentionTargetKind.NOTE,
                note.get("id", ""),
            )
        ]
        result.total_count = len(result.hits)
        return result

    @staticmethod
    def _refresh_search_hit(hit: SearchHit) -> None:
        if hit.facts:
            hit.snippet = hit.facts[0].raw_text
        entry_text = f"{hit.entity.name} {hit.snippet} {' '.join(f.raw_text for f in hit.facts[:3])}"
        hit.token_count = len(entry_text.strip()) // 4

    def _refresh_search_result(self, result: SearchResult) -> SearchResult:
        total_tokens = 0
        for hit in result.hits:
            self._refresh_search_hit(hit)
            total_tokens += hit.token_count
        result.total_tokens = total_tokens
        result.total_count = len(result.hits)
        return result

    def _apply_applicability_to_search_result(
        self,
        result: SearchResult,
        options: SearchOptions,
    ) -> SearchResult:
        if not options.context_tags:
            return result

        filtered_hits: list[SearchHit] = []
        for hit in result.hits:
            original_facts = list(hit.facts)
            allowed_facts = [
                fact
                for fact in original_facts
                if fact.applicability.allows(options.context_tags)
            ]
            if original_facts and not allowed_facts:
                continue
            if allowed_facts:
                hit.facts = allowed_facts
                hit.ranking_factors.append(
                    RankingFactor(
                        "context_tag_match",
                        0.0,
                        "fact applicability matched the requested context tags",
                    )
                )
            filtered_hits.append(hit)
        result.hits = filtered_hits
        return self._refresh_search_result(result)

    def _merge_query_plan_results(
        self,
        query: str,
        primary: SearchResult,
        supplemental: list[tuple[str, SearchResult]],
        *,
        max_results: int,
        max_tokens: int,
    ) -> SearchResult:
        merged_hits: dict[str, SearchHit] = {
            hit.entity.id: copy.deepcopy(hit)
            for hit in primary.hits
        }
        for fragment, result in supplemental:
            for hit in result.hits:
                factor = RankingFactor(
                    "query_plan_match",
                    0.05,
                    f"matched query-plan fragment '{fragment}'",
                )
                existing = merged_hits.get(hit.entity.id)
                if existing is None:
                    merged = copy.deepcopy(hit)
                    merged.ranking_factors.append(factor)
                    merged.relevance_score += factor.delta
                    merged.base_score = max(merged.base_score, merged.relevance_score)
                    merged_hits[hit.entity.id] = merged
                    continue

                known_fact_ids = {fact.id for fact in existing.facts}
                existing.facts.extend(
                    copy.deepcopy(fact)
                    for fact in hit.facts
                    if fact.id not in known_fact_ids
                )
                if hit.relevance_score > existing.relevance_score:
                    existing.relevance_score = hit.relevance_score
                    existing.base_score = max(existing.base_score, hit.base_score)
                    if hit.snippet:
                        existing.snippet = hit.snippet
                existing.ranking_factors.append(factor)
                existing.relevance_score += factor.delta

        ordered_hits = sorted(
            merged_hits.values(),
            key=lambda row: row.relevance_score,
            reverse=True,
        )
        final_hits: list[SearchHit] = []
        total_tokens = 0
        for hit in ordered_hits:
            self._refresh_search_hit(hit)
            if max_tokens > 0 and total_tokens + hit.token_count > max_tokens:
                continue
            final_hits.append(hit)
            total_tokens += hit.token_count
            if len(final_hits) >= max_results:
                break
        return SearchResult(
            query=query,
            hits=final_hits,
            total_count=len(merged_hits),
            search_time_ms=round(
                primary.search_time_ms
                + sum(row.search_time_ms for _fragment, row in supplemental),
                2,
            ),
            total_tokens=total_tokens,
            notes=list(primary.notes),
        )

    def _apply_retention_to_entity_brief(self, brief: EntityBrief) -> EntityBrief:
        brief.top_facts = [
            fact
            for fact in brief.top_facts
            if not self.retention_service.is_archive_only(RetentionTargetKind.FACT, fact.id)
            and not self.retention_service.is_never_summarize(RetentionTargetKind.FACT, fact.id)
        ]
        brief.recent_notes = [
            note
            for note in brief.recent_notes
            if not self.retention_service.is_archive_only(RetentionTargetKind.NOTE, note.note_id)
            and not self.retention_service.is_never_summarize(RetentionTargetKind.NOTE, note.note_id)
        ]
        return brief

    def _apply_retention_to_session_brief(self, brief: SessionBrief) -> SessionBrief:
        brief.facts_added = [
            fact
            for fact in brief.facts_added
            if not self.retention_service.is_archive_only(RetentionTargetKind.FACT, fact.fact_id)
            and not self.retention_service.is_never_summarize(RetentionTargetKind.FACT, fact.fact_id)
        ]
        return brief

    def _index_source(self, source_kind: str, source_id: str) -> None:
        self.reference_service.index_source(source_kind, source_id)
        self.decision_service.index_source(source_kind, source_id)

    def close(self) -> None:
        """Close all connections."""
        self.storage.close()
        self.search_engine.close()

    def _build_search_index_text(self, entity: Entity) -> str:
        """Build index text for secondary search backends."""
        current_facts = self.storage.get_current_facts(entity.id)
        fact_text = " ".join(f.raw_text for f in current_facts[:50])
        return f"{entity.name} {entity.summary} {fact_text}".strip()

    def _update_secondary_search_index(
        self,
        entity_ids: list[str] | set[str] | tuple[str, ...],
    ) -> None:
        """Update semantic or hybrid indexes when enabled."""
        index_entity = getattr(self.search_engine, "index_entity", None)
        if index_entity is None:
            return

        for entity_id in dict.fromkeys(entity_ids):
            entity = self.storage.get_entity(entity_id)
            if entity is None:
                continue
            index_entity(entity.id, self._build_search_index_text(entity))

    def _remove_from_secondary_search_index(
        self,
        entity_ids: list[str] | set[str] | tuple[str, ...],
    ) -> None:
        remove_from_index = getattr(self.search_engine, "remove_from_index", None)
        if remove_from_index is None:
            return

        for entity_id in dict.fromkeys(entity_ids):
            remove_from_index(entity_id)

    # ── Read Operations ──

    def search(
        self,
        query: str,
        options: Optional[SearchOptions] = None,
        session_id: Optional[str] = None,
        scope_selection: Optional[ScopeSelection] = None,
    ) -> SearchResult:
        """Search memory with BM25 retrieval plus optional reranking."""
        if options is None:
            options = SearchOptions(query=query)
        else:
            options.query = query
        context = self._build_retrieval_context(session_id, options)
        result = self.search_engine.search(options)
        result = self._filter_search_result_by_scope(result, scope_selection)
        result = self._apply_retention_to_search_result(result, options)
        result = self._apply_applicability_to_search_result(result, options)
        hit_warnings: dict[str, list[str]] = {}
        for hit in result.hits:
            hit.base_score = hit.base_score or hit.relevance_score
            warnings: list[str] = []
            penalty = 0.0
            penalty_reason = ""
            for fact in hit.facts:
                assessment = self.freshness_service.assess_fact(fact)
                if assessment.warning:
                    warnings.append(assessment.warning)
                if assessment.should_open_request:
                    self.freshness_service.ensure_fact_request(
                        fact,
                        reason="verify_on_read",
                        requested_by="search",
                    )
                if assessment.penalty < penalty:
                    penalty = assessment.penalty
                    penalty_reason = assessment.reason
            if penalty:
                hit.base_score += penalty
                hit.relevance_score = hit.base_score
                hit.ranking_factors.append(
                    RankingFactor(
                        "freshness_penalty",
                        penalty,
                        penalty_reason or "freshness reduced confidence",
                    )
                )
            if warnings:
                hit_warnings[hit.entity.id] = warnings
        result = self.reranking_service.rerank(result, context)
        for hit in result.hits:
            explanation = self.explanation_builder.from_search_hit(query, hit)
            explanation.warnings.extend(hit_warnings.get(hit.entity.id, []))
            hit.explanation = explanation

        wm = self._working_memories.get(session_id) if session_id else None
        if wm is not None:
            wm.add_query(query)

        # Record accessed entities in the session
        if session_id and result.hits:
            for hit in result.hits:
                self.session_mgr.record_entity_access(session_id, hit.entity.id)

        # Always search raw notes alongside entity results
        note_hits = self.storage.search_notes(query)
        if not note_hits:
            note_hits = self.storage.search_notes_like(query)
        event_scope_id, event_scope_detail = self._session_event_scope_metadata(
            scope_selection
        )
        if note_hits:
            if scope_selection is not None and scope_selection.primary_scope_id is not None:
                resolved = self.scope_service.resolve_selection(scope_selection)
                allowed_scope_ids = set(resolved.allowed_scope_ids)
                note_hits = [
                    note
                    for note in note_hits
                    if self._scope_allows(note.get("scope_id"), scope_selection, allowed_scope_ids)
                ]
            result.notes = [
                {
                    "id": n["id"],
                    "text": n["text"],
                    "created_at": n["created_at"],
                    "scope_id": n.get("scope_id"),
                }
                for n in note_hits[:10]
            ]
            result = self._apply_retention_to_search_result(result, options)
            if session_id:
                # Mask the query before it lands in session_events — if the
                # user searches for their own PII (e.g. to find a record),
                # the event log must not retain a plaintext copy.
                self.session_mgr.log_event(
                    session_id,
                    event_type="notes_searched",
                    target=self._mask_text(query) or query,
                    detail={
                        "note_count": len(result.notes),
                        **event_scope_detail,
                    },
                    scope_id=event_scope_id,
                )

        if session_id:
            self.session_mgr.log_event(
                session_id,
                event_type="search",
                target=query,
                detail={
                    "hit_count": len(result.hits),
                    "note_count": len(result.notes),
                    **event_scope_detail,
                },
                scope_id=event_scope_id,
            )

        return result

    def get_entity(self, name: str, session_id: Optional[str] = None) -> Optional[Entity]:
        """Look up an entity by name. Increments access_count."""
        entity = self.storage.get_entity_by_name(name)
        if entity:
            self._touch_entity(entity)
            if session_id:
                self.session_mgr.record_entity_access(session_id, entity.id)
        return entity

    def _touch_entity(self, entity: Entity) -> None:
        """Increment access_count without triggering FTS reindex."""
        from datetime import datetime
        self.storage.touch_entity(entity.id)
        entity.access_count += 1
        entity.last_accessed = datetime.now()

    def get_entity_by_id(self, entity_id: str) -> Optional[Entity]:
        """Look up an entity by ID."""
        return self.storage.get_entity(entity_id)

    def get_facts(self, entity_name: str, current_only: bool = True, session_id: Optional[str] = None) -> list[Fact]:
        """Get facts for an entity by name."""
        entity = self.storage.get_entity_by_name(entity_name)
        if not entity:
            return []
        if session_id:
            self.session_mgr.record_entity_access(session_id, entity.id)
        if current_only:
            return self.storage.get_current_facts(entity.id)
        return self.storage.get_facts(entity.id)

    def list_entities(
        self,
        tier: Optional[Tier] = None,
        entity_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[Entity]:
        """List entities with optional filters."""
        return self.storage.list_entities(tier=tier, entity_type=entity_type, limit=limit)

    def get_relations(self, entity_name: str) -> list[Relation]:
        """Get relations for an entity."""
        entity = self.storage.get_entity_by_name(entity_name)
        if not entity:
            return []
        return self.storage.get_relations(entity.id)

    # ── Write Operations (through quality gate) ──

    def _sync_entity_state(self, fact: Fact, entity: Entity) -> None:
        """Sync entity state fields from a fact's predicate/object.

        Updates entity.state.role, entity.state.location, or
        entity.state.affiliation when the fact has a matching predicate
        and the field is not yet set.
        """
        state_updated = False
        if fact.predicate == "role" and not entity.state.role:
            entity.state.role = fact.object
            state_updated = True
        elif fact.predicate == "location" and not entity.state.location:
            entity.state.location = fact.object
            state_updated = True
        elif fact.predicate == "affiliation" and not entity.state.affiliation:
            entity.state.affiliation = fact.object
            state_updated = True
        elif fact.predicate == "email" and not entity.state.email:
            entity.state.email = fact.object
            state_updated = True
        if state_updated:
            self.storage.update_entity(entity)

    def store(
        self,
        text: str,
        source: Optional[Source] = None,
        session_id: Optional[str] = None,
        scope_id: Optional[str] = None,
    ) -> StoreResult:
        """Extract entities, facts, and relations from text and store them.

        All facts pass through the quality gate before storage.

        Raw input is PII-masked at the very top so every downstream sink —
        extractor (so an email never lands in ``entity.name``), quality gate,
        the notes table, and any session event derived from this call —
        sees a redacted string. Without this, the notes table would keep a
        cleartext copy of sensitive input that leaks back via search.
        """
        if not text or not text.strip():
            return StoreResult()

        # Mask at entry. Everything below uses ``text`` — including
        # ``add_note`` — so PII never reaches any persistent column.
        text = self._mask_text(text) or text

        source = source or Source(type=SourceType.USER_INPUT)
        result = StoreResult()

        # Step 1: Extract entities
        ext = self.extractor
        extracted_entities = ext.extract_entities(text)

        # Step 2: Create or update entities in storage
        all_entities: list[Entity] = []
        for entity in extracted_entities:
            existing = self.storage.get_entity_by_name(entity.name)
            if existing:
                result.entities_updated.append(existing)
                entity.id = existing.id
                all_entities.append(existing)
                if session_id:
                    self.session_mgr.record_entity_modified(session_id, existing.id)
            else:
                try:
                    self.storage.create_entity(entity)
                    result.entities_created.append(entity)
                    all_entities.append(entity)
                    if session_id:
                        self.session_mgr.record_entity_modified(session_id, entity.id)
                except EntityAlreadyExistsError:
                    # TOCTOU: another thread created it between our check and create
                    existing = self.storage.get_entity_by_name(entity.name)
                    if existing:
                        result.entities_updated.append(existing)
                        entity.id = existing.id
                        all_entities.append(existing)
                    else:
                        all_entities.append(entity)

        # Step 3: Extract and validate facts (with deferred reindex)
        extracted_facts = ext.extract_facts(text, all_entities)
        entities_to_reindex: set[str] = set()

        for fact in extracted_facts:
            fact_source = copy.copy(source)
            if fact_source.session_id is None and session_id:
                fact_source.session_id = session_id
            fact.source = fact_source
            fact.scope_id = scope_id

            validation = self.quality_gate.validate(fact, extraction_method="regex")
            result.validations.append(validation)

            if validation.action == Action.REJECT:
                continue

            if validation.action == Action.ACCEPT:
                self.storage.add_fact(fact, reindex=False)
                result.facts_added.append(fact)
                entities_to_reindex.add(fact.entity_id)
                if session_id:
                    self.session_mgr.record_fact_added(session_id, fact.id)
                # Apply deferred retractions from auto-resolved conflicts
                for retracted_fact in validation.auto_resolved_facts:
                    self.storage.update_fact(retracted_fact)
                    entities_to_reindex.add(retracted_fact.entity_id)
            elif validation.action == Action.QUARANTINE:
                self.storage.add_fact(fact, reindex=False)
                result.facts_quarantined.append(fact)
                entities_to_reindex.add(fact.entity_id)
            elif validation.action == Action.FLAG_CONFLICT:
                self.storage.add_fact(fact, reindex=False)
                result.facts_conflicted.append(fact)
                entities_to_reindex.add(fact.entity_id)
                for conflict in validation.conflicts:
                    self.storage.add_conflict({
                        "id": conflict.conflict_id,
                        "existing_fact_id": conflict.existing_fact.id if conflict.existing_fact else None,
                        "new_fact_id": fact.id,
                        "conflict_type": conflict.conflict_type,
                        "suggested_resolution": conflict.suggested_resolution,
                    })

        # Step 3.5: Sync entity state from accepted facts
        for fact in result.facts_added:
            entity = next((e for e in all_entities if e.id == fact.entity_id), None)
            if not entity:
                continue
            self._sync_entity_state(fact, entity)

        # Step 3.6: Deferred reindex (once per entity, not per fact)
        for eid in entities_to_reindex:
            entity = self.storage.get_entity(eid)
            if entity:
                self.storage.reindex_entity(entity)
        if entities_to_reindex:
            self.storage.commit()
            self._update_secondary_search_index(entities_to_reindex)

        # Step 4: Extract and store relations
        extracted_relations = ext.extract_relations(text, all_entities)
        relation_entity_ids: set[str] = set()
        for relation in extracted_relations:
            self.storage.add_relation(relation)
            result.relations_added.append(relation)
            relation_entity_ids.add(relation.from_entity_id)
            relation_entity_ids.add(relation.to_entity_id)

        # Step 4.1: Reindex entities involved in new relations (FTS includes relation text)
        # Exclude entities already reindexed in Step 3.6 to avoid redundant work
        new_reindex_ids = relation_entity_ids - entities_to_reindex
        if new_reindex_ids:
            for eid in new_reindex_ids:
                entity = self.storage.get_entity(eid)
                if entity:
                    self.storage.reindex_entity(entity)
            self.storage.commit()
            self._update_secondary_search_index(new_reindex_ids)

        created_only_ids = {
            entity.id for entity in result.entities_created
            if entity.id not in entities_to_reindex and entity.id not in new_reindex_ids
        }
        if created_only_ids:
            self._update_secondary_search_index(created_only_ids)

        # Step 4.5: Update working memory
        wm = self._working_memories.get(session_id) if session_id else None
        if wm:
            for entity in all_entities:
                wm.touch_entity(entity.id)

        # Step 5: Export to Markdown if enabled
        if self._md_exporter:
            for entity in result.entities_created + result.entities_updated:
                e = self.storage.get_entity_by_name(entity.name) or entity
                facts = self.storage.get_facts(e.id)
                rels = self.storage.get_relations(e.id)
                self._md_exporter.export_entity(e, facts, rels)

        # Step 6: Always store raw text as a searchable note
        import uuid
        note_id = str(uuid.uuid4())
        active_scope_id = scope_id
        if active_scope_id is None and session_id:
            active_session = self.session_mgr.get_active_session(session_id)
            if active_session is not None:
                active_scope_id = active_session.scope_id
        _note_id, note_is_new = self.storage.add_note(
            note_id,
            text,
            source.type.value,
            session_id,
            scope_id=active_scope_id,
        )
        result.note_is_new = note_is_new
        if note_is_new:
            self.job_runner.enqueue(
                "index_source",
                {
                    "source_kind": "note",
                    "source_id": _note_id,
                    "scope_id": active_scope_id,
                },
            )
            self._index_source("note", _note_id)

        return result

    def add_fact(
        self,
        entity_name: str,
        fact_text: str,
        predicate: str = "attribute",
        source: Optional[Source] = None,
        session_id: Optional[str] = None,
        applies_if: Optional[list[str]] = None,
        except_if: Optional[list[str]] = None,
    ) -> ValidationResult:
        """Add a single fact to an entity, through quality gate."""
        entity = self.storage.get_entity_by_name(entity_name)
        if not entity:
            raise EntityNotFoundError(f"Entity '{entity_name}' not found")

        source = source or Source(type=SourceType.USER_INPUT)
        session = None
        if session_id:
            session = (
                self.session_mgr.get_active_session(session_id)
                or self.storage.get_session(session_id)
            )
            if session is None:
                raise SessionError(f"Session '{session_id}' not found")
            if source.session_id is None:
                source = copy.copy(source)
                source.session_id = session_id
        fact = Fact(
            entity_id=entity.id,
            subject=entity.name,
            predicate=predicate,
            object=fact_text,
            raw_text=fact_text,
            source=source,
            scope_id=session.scope_id if session else None,
            applicability=FactApplicability(
                applies_if=applies_if or [],
                except_if=except_if or [],
            ),
        )

        validation = self.quality_gate.validate(fact, extraction_method="manual")

        if validation.action in (Action.ACCEPT, Action.QUARANTINE, Action.FLAG_CONFLICT):
            self.storage.add_fact(fact)
            if session_id:
                self.session_mgr.record_fact_added(session_id, fact.id)
                self.session_mgr.record_entity_modified(session_id, entity.id)
            self._update_secondary_search_index([entity.id])

        if validation.action == Action.ACCEPT:
            self._sync_entity_state(fact, entity)
            # Apply deferred retractions from auto-resolved conflicts
            for retracted_fact in validation.auto_resolved_facts:
                self.storage.update_fact(retracted_fact)

        if validation.action == Action.FLAG_CONFLICT:
            for conflict in validation.conflicts:
                self.storage.add_conflict({
                    "id": conflict.conflict_id,
                    "existing_fact_id": conflict.existing_fact.id if conflict.existing_fact else None,
                    "new_fact_id": fact.id,
                    "conflict_type": conflict.conflict_type,
                    "suggested_resolution": conflict.suggested_resolution,
                })

        return validation

    def create_entity(
        self,
        name: str,
        entity_type: str = "person",
        tier: Tier = Tier.RECALL,
        summary: str = "",
    ) -> Entity:
        """Manually create an entity."""
        entity = Entity(
            name=self._mask_text(name) or name,
            entity_type=entity_type,
            tier=tier,
            summary=self._mask_text(summary) or summary,
        )
        self.storage.create_entity(entity)
        self._update_secondary_search_index([entity.id])
        return entity

    def delete_entity(self, name: str) -> bool:
        """Delete an entity by name."""
        entity = self.storage.get_entity_by_name(name)
        if not entity:
            return False
        deleted = self.storage.delete_entity(entity.id)
        if deleted:
            self._remove_from_secondary_search_index([entity.id])
        return deleted

    def merge_entities(self, primary_name: str, secondary_name: str) -> Entity:
        """Merge secondary entity into primary. All facts, relations, aliases transfer."""
        primary = self.storage.get_entity_by_name(primary_name)
        secondary = self.storage.get_entity_by_name(secondary_name)
        if not primary:
            raise EntityNotFoundError(f"Entity '{primary_name}' not found")
        if not secondary:
            raise EntityNotFoundError(f"Entity '{secondary_name}' not found")
        return self.merge_entities_by_id(primary.id, secondary.id)

    def merge_entities_by_id(self, primary_id: str, secondary_id: str) -> Entity:
        """Merge secondary entity into primary. All facts, relations, aliases transfer."""
        primary = self.storage.get_entity(primary_id)
        secondary = self.storage.get_entity(secondary_id)
        if not primary:
            raise EntityNotFoundError(f"Entity '{primary_id}' not found")
        if not secondary:
            raise EntityNotFoundError(f"Entity '{secondary_id}' not found")
        if primary.id == secondary.id:
            return primary

        # Collect entities that had relations with the secondary entity BEFORE
        # transfer, so we can reindex them after the merge completes.
        secondary_relations = self.storage.get_relations(secondary.id)

        # Transfer facts and relations via storage methods
        self.storage.transfer_facts(secondary.id, primary.id, primary.name)
        self.storage.transfer_relations(secondary.id, primary.id)
        self.storage.transfer_reference_edges(secondary.id, primary.id)
        self.storage.transfer_decisions(secondary.id, primary.id)
        # Add aliases
        if secondary.name not in primary.aliases:
            primary.aliases.append(secondary.name)
        for alias in secondary.aliases:
            if alias not in primary.aliases:
                primary.aliases.append(alias)
        # Merge state (secondary fills gaps). All structured fields
        # participate — previous revisions only merged role/affiliation/
        # location and silently dropped email and custom entries from the
        # secondary entity.
        if not primary.state.role and secondary.state.role:
            primary.state.role = secondary.state.role
        if not primary.state.affiliation and secondary.state.affiliation:
            primary.state.affiliation = secondary.state.affiliation
        if not primary.state.location and secondary.state.location:
            primary.state.location = secondary.state.location
        if not primary.state.email and secondary.state.email:
            primary.state.email = secondary.state.email
        # ``custom`` is a dict; fill keys that primary doesn't already own
        # so user-supplied values survive the merge without clobbering.
        if secondary.state.custom:
            for key, value in secondary.state.custom.items():
                if key not in primary.state.custom:
                    primary.state.custom[key] = value
        related_entity_ids: set[str] = set()
        for rel in secondary_relations:
            if rel.from_entity_id != secondary.id and rel.from_entity_id != primary.id:
                related_entity_ids.add(rel.from_entity_id)
            if rel.to_entity_id != secondary.id and rel.to_entity_id != primary.id:
                related_entity_ids.add(rel.to_entity_id)

        self.storage.update_entity(primary)
        self.storage.delete_entity(secondary.id)
        self._remove_from_secondary_search_index([secondary.id])

        # Reindex primary and all entities that had relations with the secondary
        self.storage.reindex_entity(primary)
        for eid in related_entity_ids:
            related = self.storage.get_entity(eid)
            if related:
                self.storage.reindex_entity(related)
        self.storage.commit()
        self._update_secondary_search_index([primary.id, *related_entity_ids])

        return primary

    def generate_governance_candidates(self, limit: int = 100):
        return self.governance_service.generate_candidates(limit=limit)

    def list_governance_candidates(
        self,
        *,
        status: GovernanceCandidateStatus | None = None,
        candidate_type: GovernanceCandidateType | None = None,
        limit: int = 50,
    ):
        return self.governance_service.list_candidates(
            status=status,
            candidate_type=candidate_type,
            limit=limit,
        )

    def get_governance_candidate(self, candidate_id: str):
        return self.governance_service.get_candidate(candidate_id)

    def resolve_governance_candidate(
        self,
        candidate_id: str,
        resolution: GovernanceResolution,
        resolved_by: str = "user",
    ):
        return self.governance_service.resolve_candidate(
            candidate_id,
            resolution=resolution,
            resolved_by=resolved_by,
            merge_fn=self.merge_entities_by_id,
        )

    def resolve_conflict(self, conflict_id: str, resolution: str, resolved_by: str = "user") -> None:
        """Resolve a pending conflict and update the losing fact's status."""
        # Get conflict details before resolving
        conflict = self.storage.get_conflict(conflict_id)

        self.storage.resolve_conflict(conflict_id, resolution, resolved_by)

        # Update fact statuses based on resolution
        if conflict:
            if resolution == "accept_new" and conflict.get("existing_fact_id"):
                self.storage.update_fact_status(
                    conflict["existing_fact_id"], "retracted",
                    superseded_by=conflict.get("new_fact_id"),
                )
                # Mark the winning (new) fact as current — remove conflicted status
                if conflict.get("new_fact_id"):
                    self.storage.update_fact_status_if(
                        conflict["new_fact_id"], "unverified", only_if_status="conflicted",
                    )
                self.storage.commit()
            elif resolution == "keep_old" and conflict.get("new_fact_id"):
                self.storage.update_fact_status(conflict["new_fact_id"], "retracted")
                self.storage.commit()
            elif resolution == "merge":
                # Both facts are valid — mark both as current (unverified)
                if conflict.get("existing_fact_id"):
                    self.storage.update_fact_status_if(
                        conflict["existing_fact_id"], "unverified", only_if_status="conflicted",
                    )
                if conflict.get("new_fact_id"):
                    self.storage.update_fact_status_if(
                        conflict["new_fact_id"], "unverified", only_if_status="conflicted",
                    )
                self.storage.commit()

            # After resolving, resync entity state from current facts
            fact_id = conflict.get("new_fact_id") or conflict.get("existing_fact_id")
            if fact_id:
                entity_id = self.storage.get_fact_entity_id(fact_id)
                if entity_id:
                    entity = self.storage.get_entity(entity_id)
                    if entity:
                        self._rebuild_entity_state(entity)

    def _rebuild_entity_state(self, entity: Entity) -> None:
        """Clear entity state fields and rebuild from current facts."""
        entity.state.role = None
        entity.state.location = None
        entity.state.affiliation = None
        entity.state.email = None

        current_facts = self.storage.get_current_facts(entity.id)
        for fact in current_facts:
            if fact.predicate == "role" and not entity.state.role:
                entity.state.role = fact.object
            elif fact.predicate == "location" and not entity.state.location:
                entity.state.location = fact.object
            elif fact.predicate == "affiliation" and not entity.state.affiliation:
                entity.state.affiliation = fact.object
            elif fact.predicate == "email" and not entity.state.email:
                entity.state.email = fact.object

        self.storage.update_entity(entity)

    # ── Session Operations ──

    def start_session(
        self,
        agent_id: str = "default",
        scope_id: Optional[str] = None,
        *,
        parent_session_id: object = _USE_RECENT_PARENT,
        metadata: Optional[dict] = None,
        allow_parallel: bool = False,
    ) -> Session:
        """Start a new memory session."""
        kwargs: dict = {
            "scope_id": scope_id,
            "metadata": metadata,
            "allow_parallel": allow_parallel,
        }
        if parent_session_id is not _USE_RECENT_PARENT:
            kwargs["parent_session_id"] = parent_session_id
        session = self.session_mgr.start_session(agent_id, **kwargs)
        self._working_memories[session.session_id] = WorkingMemory(session)
        return session

    def end_session(self, session_id: str, summary: Optional[str] = None) -> Session:
        """End a session. Runs light maintenance on modified entities."""
        wm = self._working_memories.pop(session_id, None)
        session = self.session_mgr.end_session(session_id, summary)

        # Light maintenance: compact entities that were heavily modified this session.
        # Exceptions must NOT abort session end, but we record them as a
        # ``compact_error`` session event so the failure is debuggable later
        # instead of being silently swallowed.
        if session.entities_modified:
            for eid in session.entities_modified[:10]:
                try:
                    current_facts = self.storage.get_current_facts(eid)
                    entity = self.storage.get_entity(eid)
                    if entity and len(current_facts) > 15:
                        self.compact_entity(entity.name)
                except Exception as exc:  # noqa: BLE001 — intentional broad catch
                    try:
                        self.session_mgr.log_event(
                            session_id,
                            event_type="compact_error",
                            target=eid,
                            detail={"error_type": type(exc).__name__, "message": str(exc)},
                        )
                    except Exception:
                        # Session already ended / storage partially torn down —
                        # swallow this too. The original exception is the
                        # one that matters, but we never bubble up.
                        pass

        if session.summary:
            self.job_runner.enqueue(
                "index_source",
                {
                    "source_kind": "session",
                    "source_id": session.session_id,
                    "scope_id": session.scope_id,
                },
            )
            self._index_source("session", session.session_id)

        return session

    def create_scope(
        self,
        kind: str,
        name: str,
        parent_scope_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ):
        return self.scope_service.create(
            kind,
            name,
            parent_scope_id=parent_scope_id,
            metadata=metadata,
        )

    def get_scope(self, scope_id: str):
        return self.scope_service.get(scope_id)

    def list_scopes(
        self,
        *,
        kind: Optional[str] = None,
        parent_scope_id: Optional[str] = None,
        include_archived: bool = False,
    ):
        return self.scope_service.list(
            kind=kind,
            parent_scope_id=parent_scope_id,
            include_archived=include_archived,
        )

    def enqueue_job(
        self,
        job_type: str,
        payload: dict,
        *,
        max_attempts: int = 3,
    ):
        return self.job_runner.enqueue(
            job_type,
            payload,
            max_attempts=max_attempts,
        )

    def get_job(self, job_id: str):
        return self.job_runner.get(job_id)

    def list_jobs(
        self,
        *,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
        limit: int = 50,
    ):
        return self.job_runner.list(status=status, job_type=job_type, limit=limit)

    def _execute_job(self, job) -> None:
        if job.job_type == "index_source":
            source_kind = job.payload["source_kind"]
            source_id = job.payload["source_id"]
            self._index_source(source_kind, source_id)
            return
        if job.job_type == "rebuild_references":
            self.rebuild_references()
            return
        if job.job_type == "rebuild_decisions":
            self.rebuild_decisions()
            return
        if job.job_type == "rebuild_projections":
            self.rebuild_projections()
            return
        if job.job_type == "maintenance_run":
            self.run_maintenance(
                max_open_loops=job.payload.get("max_open_loops", 50),
                stale_days=job.payload.get("stale_days"),
            )
            return
        raise ValueError(f"Unsupported job type: {job.job_type}")

    def run_jobs(self, *, limit: int = 20, lease_owner: str = "engine") -> dict:
        leased = self.job_runner.lease(limit=limit, lease_owner=lease_owner)
        completed = 0
        failed = 0
        for job in leased:
            try:
                self._execute_job(job)
                job.status = "completed"
                job.last_error = None
                job.completed_at = datetime.now()
                job.updated_at = job.completed_at
                self.storage.update_job(job)
                completed += 1
            except Exception as exc:
                self.job_runner.mark_failed(job.id, str(exc))
                failed += 1
        return {
            "leased": len(leased),
            "completed": completed,
            "failed": failed,
        }

    def list_verification_requests(
        self,
        *,
        status: Optional[VerificationRequestStatus] = None,
        target_kind: Optional[str] = None,
        limit: int = 50,
    ):
        return self.freshness_service.list_requests(
            status=status,
            target_kind=target_kind,
            limit=limit,
        )

    def get_verification_request(self, request_id: str):
        return self.freshness_service.get_request(request_id)

    def request_fact_verification(
        self,
        fact_id: str,
        *,
        reason: str = "manual",
        requested_by: str = "manual",
    ):
        fact = self.storage.get_fact(fact_id)
        if fact is None:
            raise EntityNotFoundError(f"Fact '{fact_id}' not found")
        return self.freshness_service.ensure_fact_request(
            fact,
            reason=reason,
            requested_by=requested_by,
        )

    def request_decision_verification(
        self,
        decision_id: str,
        *,
        reason: str = "manual",
        requested_by: str = "manual",
    ):
        decision = self.storage.get_decision(decision_id)
        if decision is None:
            raise EntityNotFoundError(f"Decision '{decision_id}' not found")
        return self.freshness_service.ensure_decision_request(
            decision,
            reason=reason,
            requested_by=requested_by,
        )

    def resolve_verification_request(
        self,
        request_id: str,
        resolution: VerificationResolution | str,
        *,
        detail: str = "",
    ):
        enum_value = (
            resolution
            if isinstance(resolution, VerificationResolution)
            else VerificationResolution(resolution)
        )
        return self.freshness_service.resolve_request(
            request_id,
            enum_value,
            detail=detail,
        )

    def get_session_context(self, agent_id: str) -> dict:
        """Get context for starting a new session."""
        return build_session_context(self.storage, agent_id)

    def build_query_plan(self, query: str) -> QueryPlan:
        """Build a deterministic query plan for compound lookups."""
        return self.query_planner.build(query)

    def search_context(
        self,
        query: str,
        *,
        goal: str = "general",
        session_id: Optional[str] = None,
        scope_selection: Optional[ScopeSelection] = None,
        plan_query: bool = False,
        context_tags: Optional[list[str]] = None,
        expand_hops: int = 1,
        include_decisions: bool = True,
        include_references: bool = True,
        max_results: int = 5,
        max_related: int = 10,
        max_tokens: int = 800,
    ) -> ContextSearchResult:
        if expand_hops < 0 or expand_hops > 2:
            raise ValueError("expand_hops must be between 0 and 2")

        wm = self._working_memories.get(session_id) if session_id else None
        active = self.session_mgr.get_active_session(session_id) if session_id else None
        recent_entity_ids = list((active.entities_accessed or [])[-5:]) if active else []
        context = RetrievalContext(
            goal=goal,
            session_id=session_id,
            active_entity_ids=wm.get_active_entity_ids() if wm else [],
            recent_entity_ids=recent_entity_ids,
            include_explanations=True,
        )
        options = SearchOptions(
            query=query,
            max_results=max_results,
            max_tokens=max_tokens,
            context_tags=context_tags or [],
            context=context,
        )
        base_result = self.search(
            query,
            options,
            session_id=session_id,
            scope_selection=scope_selection,
        )
        query_plan = self.build_query_plan(query) if plan_query else None
        if query_plan is not None and query_plan.should_expand:
            supplemental_results: list[tuple[str, SearchResult]] = []
            for fragment in query_plan.fragments:
                fragment_result = self.search(
                    fragment,
                    SearchOptions(
                        query=fragment,
                        max_results=max_results,
                        max_tokens=max_tokens,
                        context_tags=context_tags or [],
                        context=context,
                    ),
                    session_id=None,
                    scope_selection=scope_selection,
                )
                supplemental_results.append((fragment, fragment_result))
            base_result = self._merge_query_plan_results(
                query,
                base_result,
                supplemental_results,
                max_results=max_results,
                max_tokens=max_tokens,
            )
            base_result = self.reranking_service.rerank(base_result, context)
            for hit in base_result.hits:
                warnings = list(hit.explanation.warnings)
                hit.explanation = self.explanation_builder.from_search_hit(query, hit)
                for warning in warnings:
                    if warning not in hit.explanation.warnings:
                        hit.explanation.warnings.append(warning)
        allowed_scope_ids = None
        if scope_selection is not None and scope_selection.primary_scope_id is not None:
            resolved = self.scope_service.resolve_selection(scope_selection)
            allowed_scope_ids = set(resolved.allowed_scope_ids)
        remaining_tokens = max(max_tokens - base_result.total_tokens, 0)
        service = ContextSearchService(
            self.storage,
            self.reference_service,
            self.reranking_service,
            self.freshness_service,
        )
        return service.expand(
            query=query,
            goal=goal,
            base_result=base_result,
            query_plan=query_plan,
            context=context,
            expand_hops=expand_hops,
            max_related=max_related,
            related_token_budget=remaining_tokens,
            include_decisions=include_decisions,
            include_references=include_references,
            allowed_scope_ids=allowed_scope_ids,
            include_global=bool(scope_selection.include_global) if scope_selection is not None else False,
        )

    # ── Brief Operations (read-only, composed views) ──

    def entity_brief(
        self,
        name: str,
        top_facts: int = 10,
        recent_notes: int = 5,
        recent_sessions: int = 3,
        session_id: Optional[str] = None,
        scope_selection: Optional[ScopeSelection] = None,
    ) -> Optional[EntityBrief]:
        """Build an :class:`EntityBrief` — a compact pack of everything we know
        about ``name``: state, top facts, relations, recent notes, recent
        sessions, and unresolved conflicts.

        Returns ``None`` if the entity doesn't exist. Increments access count
        on the entity just like :meth:`get_entity`.
        """
        builder = BriefBuilder(self.storage)
        brief = builder.entity_brief(
            name,
            top_facts=top_facts,
            recent_notes=recent_notes,
            recent_sessions=recent_sessions,
        )
        if brief is None:
            return None
        # Keep access_count behavior consistent with get_entity().
        self._touch_entity(brief.entity)
        brief = self._apply_retention_to_entity_brief(brief)
        if session_id:
            self.session_mgr.record_entity_access(session_id, brief.entity.id)
        support = self.search(
            name,
            SearchOptions(
                query=name,
                max_results=3,
                max_tokens=300,
            ),
            scope_selection=scope_selection,
        )
        brief.supporting_hits = self._to_supporting_hits(support)
        return brief

    def session_brief(
        self,
        session_id: str,
        scope_selection: Optional[ScopeSelection] = None,
    ) -> Optional[SessionBrief]:
        """Build a :class:`SessionBrief` — what the given session has touched.

        Returns ``None`` if the session doesn't exist.

        Prefers the in-memory active session (kept by :class:`SessionManager`)
        over the stored copy, so that in-flight modifications are visible
        before ``end_session`` flushes them.
        """
        builder = BriefBuilder(self.storage)
        wm = self._working_memories.get(session_id)
        active = self.session_mgr.get_active_session(session_id)
        brief = builder.session_brief(
            session_id, working_memory=wm, active_session=active
        )
        if brief is not None:
            brief = self._apply_retention_to_session_brief(brief)
            entity_terms = [ref.name for ref in (brief.entities_modified + brief.entities_accessed)[:3]]
            support_query = (
                brief.session.summary
                or " ".join(entity_terms)
                or " ".join(brief.recent_queries[:3])
                or brief.session.agent_id
            )
            support = self.search(
                support_query,
                SearchOptions(
                    query=support_query,
                    max_results=3,
                    max_tokens=300,
                ),
                scope_selection=scope_selection,
            )
            brief.supporting_hits = self._to_supporting_hits(support)
        return brief

    def build_context_pack(
        self,
        *,
        session_id: str,
        goal: str = "task_handoff",
        max_chars: int = 4000,
        scope_selection: Optional[ScopeSelection] = None,
        health_report: Optional[HealthReport] = None,
    ) -> ContextPack:
        session = self.session_mgr.get_active_session(session_id) or self.storage.get_session(session_id)
        if session is None:
            raise ValueError(f"Session '{session_id}' not found")
        effective_scope_id = session.scope_id
        if scope_selection is not None and scope_selection.primary_scope_id is not None:
            effective_scope_id = self._resolve_transfer_scope(
                source_scope_id=session.scope_id,
                requested_scope_id=scope_selection.primary_scope_id,
            )
        builder = BriefBuilder(self.storage)
        brief = builder.session_brief(
            session_id,
            working_memory=self._working_memories.get(session_id),
            active_session=self.session_mgr.get_active_session(session_id),
        )
        if brief is None:
            raise ValueError(f"Session '{session_id}' not found")
        pack_builder = ContextPackBuilder(
            self.storage,
            self._diagnostics,
        )
        allowed_scope_ids = None
        include_session_text = True
        recent_queries_override = None
        derive_summary = False
        if scope_selection is not None and scope_selection.primary_scope_id is not None:
            resolved = self.scope_service.resolve_selection(scope_selection)
            allowed_scope_ids = set(resolved.allowed_scope_ids)
            include_session_text = False
            recent_queries_override = list_masked_session_queries(
                self.storage,
                session_id,
                limit=5,
                allowed_scope_ids=allowed_scope_ids,
                include_global=bool(scope_selection.include_global),
            )
            derive_summary = True
        pack = pack_builder.build(
            session=session,
            goal=goal,
            max_chars=max_chars,
            session_brief=brief,
            health_report=health_report,
            allowed_scope_ids=allowed_scope_ids,
            include_global=bool(scope_selection.include_global) if scope_selection is not None else False,
            include_session_text=include_session_text,
            recent_queries_override=recent_queries_override,
            derive_summary=derive_summary,
        )
        pack.scope_id = effective_scope_id
        return pack

    def transfer_context(
        self,
        *,
        from_session_id: str,
        to_agent_id: str,
        note: str = "",
        goal: str = "task_handoff",
        scope_selection: Optional[ScopeSelection] = None,
    ) -> ContextTransferResult:
        source_session = (
            self.session_mgr.get_active_session(from_session_id)
            or self.storage.get_session(from_session_id)
        )
        if source_session is None:
            raise ValueError(f"Session '{from_session_id}' not found")

        target_scope_id = source_session.scope_id
        if scope_selection is not None and scope_selection.primary_scope_id is not None:
            target_scope_id = self._resolve_transfer_scope(
                source_scope_id=source_session.scope_id,
                requested_scope_id=scope_selection.primary_scope_id,
            )

        pack = self.build_context_pack(
            session_id=from_session_id,
            goal=goal,
            scope_selection=scope_selection,
        )
        masked_note = self.session_mgr.mask_text(note)
        target_session = self.start_session(
            to_agent_id,
            scope_id=target_scope_id,
            parent_session_id=from_session_id,
            metadata={
                "handoff_from_session_id": from_session_id,
                "handoff_from_agent_id": source_session.agent_id,
                "handoff_note": masked_note,
                "handoff_goal": goal,
            },
        )
        target_wm = self._working_memories.get(target_session.session_id)
        if target_wm is not None:
            for row in pack.active_entities:
                target_wm.touch_entity(row.entity_id)
            for query in reversed(pack.recent_queries):
                target_wm.add_query(query)

        self.session_mgr.log_event(
            from_session_id,
            "context_transferred",
            target=target_session.session_id,
            detail={"to_agent_id": to_agent_id, "goal": goal},
        )
        self.session_mgr.log_event(
            target_session.session_id,
            "context_received",
            target=from_session_id,
            detail={"from_agent_id": source_session.agent_id, "goal": goal},
        )
        return ContextTransferResult(
            pack=pack,
            target_session=target_session,
            transfer_note=masked_note,
        )

    # ── Maintenance ──

    def health_check(self) -> dict:
        """Run health checks on the memory system."""
        pending = self.storage.get_pending_conflicts()
        return {
            "entity_count": self.storage.entity_count(),
            "fact_count": self.storage.fact_count(),
            "note_count": self.storage.note_count(),
            "pending_conflicts": len(pending),
            "status": "healthy" if len(pending) == 0 else "needs_attention",
        }

    def health_report(
        self,
        max_open_loops: int = 50,
        stale_days: Optional[int] = None,
    ) -> HealthReport:
        """Produce a rich :class:`HealthReport` with metrics and open loops.

        This is the richer counterpart to :meth:`health_check` — it returns
        graded metrics plus actionable items (conflicts, stale facts,
        orphaned entities, and facts missing source attribution).
        """
        return self._diagnostics.run(max_open_loops=max_open_loops, stale_days=stale_days)

    def _resolve_transfer_scope(
        self,
        *,
        source_scope_id: str | None,
        requested_scope_id: str,
    ) -> str:
        if source_scope_id is None:
            raise ValueError("transfer_context must not assign a scope to an unscoped source session")
        if requested_scope_id == source_scope_id:
            return requested_scope_id
        ancestor_ids = self.storage.list_scope_ancestor_ids(requested_scope_id)
        if source_scope_id not in ancestor_ids:
            raise ValueError("transfer_context must not widen scope outside the source lineage")
        return requested_scope_id

    def _maintenance_service(self) -> MaintenanceService:
        return MaintenanceService(self.storage, self._diagnostics)

    def run_maintenance(
        self,
        max_open_loops: int = 50,
        stale_days: Optional[int] = None,
        health_report: Optional[HealthReport] = None,
    ) -> MaintenanceRun:
        return self._maintenance_service().run(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
            health_report=health_report,
        )

    def list_maintenance_runs(self, limit: int = 20) -> list[MaintenanceRun]:
        return self._maintenance_service().list_runs(limit=limit)

    def get_maintenance_run(self, run_id: str) -> Optional[MaintenanceRunView]:
        run = self._maintenance_service().get_run(run_id)
        if run is None:
            return None
        items = [
            MaintenanceItemView(
                item=item,
                explanation=self.explanation_builder.for_maintenance_item(item),
            )
            for item in run.items
        ]
        return MaintenanceRunView(run=run, items=items)

    def run_operations_review(
        self,
        *,
        max_open_loops: int = 50,
        stale_days: int | None = None,
        run_jobs: bool = False,
        job_limit: int = 20,
        lease_owner: str = "operations_review",
        include_projection_drift: bool = True,
        include_recommendations: bool = True,
    ) -> OperationsReview:
        service = OperationsReviewService(
            health_report_fn=self.health_report,
            maintenance_run_fn=self.run_maintenance,
            maintenance_view_fn=self.get_maintenance_run,
            run_jobs_fn=self.run_jobs,
            reference_service=self.reference_service,
            decision_service=self.decision_service,
            recommendation_service=self.recommendation_service,
        )
        return service.run(
            max_open_loops=max_open_loops,
            stale_days=stale_days,
            run_jobs=run_jobs,
            job_limit=job_limit,
            lease_owner=lease_owner,
            include_projection_drift=include_projection_drift,
            include_recommendations=include_recommendations,
        )

    def backlinks(
        self,
        name: str,
        source_kind: Optional[str] = None,
        limit: int = 50,
    ) -> list[dict]:
        rows = self.reference_service.backlinks(name, source_kind=source_kind, limit=limit)
        enriched: list[dict] = []
        for row in rows:
            enriched.append(
                {
                    **row,
                    "explanation": self.explanation_builder.for_backlink(name, row).to_dict(),
                }
            )
        return enriched

    def list_decisions(
        self,
        entity_name: Optional[str] = None,
        status: Optional[DecisionStatus] = None,
        limit: int = 20,
    ) -> list[DecisionRecord]:
        rows = self.decision_service.list_decisions(
            entity_name=entity_name,
            status=status,
            limit=limit,
        )
        for row in rows:
            assessment = self.freshness_service.assess_decision(row)
            if assessment.should_open_request:
                self.freshness_service.ensure_decision_request(
                    row,
                    reason="decision_read",
                    requested_by="decision_list",
                )
        return rows

    def set_retention_policy(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
        policy_type: RetentionPolicyType | str,
        *,
        value: str | None = None,
        reason: str = "",
    ) -> RetentionPolicy:
        return self.retention_service.set_policy(
            target_kind=target_kind,
            target_id=target_id,
            policy_type=policy_type,
            value=value,
            reason=reason,
        )

    def clear_retention_policy(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
        policy_type: RetentionPolicyType | str,
    ) -> bool:
        return self.retention_service.clear_policy(target_kind, target_id, policy_type)

    def list_retention_policies(
        self,
        *,
        target_kind: RetentionTargetKind | str | None = None,
        target_id: str | None = None,
        policy_type: RetentionPolicyType | str | None = None,
        limit: int = 100,
    ) -> list[RetentionPolicy]:
        return self.retention_service.list_policies(
            target_kind=target_kind,
            target_id=target_id,
            policy_type=policy_type,
            limit=limit,
        )

    def list_recommendations(
        self,
        *,
        kind: str | None = None,
        limit: int = 50,
        max_open_loops: int = 50,
        stale_days: int | None = None,
    ) -> list[RecommendationView]:
        return self.recommendation_service.list_recommendations(
            kind=kind,
            limit=limit,
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )

    def get_recommendation(
        self,
        recommendation_id: str,
        *,
        max_open_loops: int = 50,
        stale_days: int | None = None,
    ) -> RecommendationView | None:
        return self.recommendation_service.get_recommendation(
            recommendation_id,
            max_open_loops=max_open_loops,
            stale_days=stale_days,
        )

    def get_decision(self, decision_id: str) -> Optional[DecisionView]:
        row = self.decision_service.get_decision(decision_id)
        if row is None:
            return None
        assessment = self.freshness_service.assess_decision(row)
        if assessment.should_open_request:
            self.freshness_service.ensure_decision_request(
                row,
                reason="decision_read",
                requested_by="decision_show",
            )
        explanation = self.explanation_builder.for_decision(row)
        if assessment.warning:
            explanation.warnings.append(assessment.warning)
        return DecisionView(
            decision=row,
            explanation=explanation,
        )

    def rebuild_references(self) -> int:
        return self.reference_service.rebuild_all()

    def rebuild_decisions(self) -> int:
        return self.decision_service.rebuild_all()

    def rebuild_projections(self) -> dict:
        return {
            "references": self.rebuild_references(),
            "decisions": self.rebuild_decisions(),
        }

    # ── Snapshots / Time Travel ──

    def _snapshot_service(self) -> SnapshotService:
        return SnapshotService(self.storage, self.config.snapshots_dir)

    def create_snapshot(
        self,
        label: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Snapshot:
        """Take a compressed point-in-time backup of the live DB."""
        return self._snapshot_service().create(
            label=label, description=description, metadata=metadata
        )

    def list_snapshots(self, limit: int = 50) -> list[Snapshot]:
        return self._snapshot_service().list(limit=limit)

    def get_snapshot(self, snapshot_id: str) -> Optional[Snapshot]:
        return self._snapshot_service().get(snapshot_id)

    def delete_snapshot(self, snapshot_id: str) -> bool:
        return self._snapshot_service().delete(snapshot_id)

    def diff_snapshots(self, a_id: str, b_id: str) -> SnapshotDiff:
        return self._snapshot_service().diff(a_id, b_id)

    def search_snapshot(
        self, snapshot_id: str, query: str, limit: int = 10
    ) -> list[dict]:
        """Search a snapshot's FTS5 index — "what did I know at that point?"."""
        return self._snapshot_service().search_at(snapshot_id, query, limit=limit)

    def get_entity_at_snapshot(
        self, snapshot_id: str, name: str
    ) -> Optional[dict]:
        """Return an entity (+ current facts + relations) as of the snapshot."""
        return self._snapshot_service().get_entity_at(snapshot_id, name)

    def restore_snapshot(
        self,
        snapshot_id: str,
        target_path,
        allow_unsafe_path: bool = False,
    ) -> Path:
        from pathlib import Path as _Path
        return self._snapshot_service().restore(
            snapshot_id,
            _Path(target_path),
            allow_unsafe_path=allow_unsafe_path,
        )

    # ── Debug-as-Memory ──

    def _debug_service(self) -> DebugService:
        return DebugService(self.storage, self.quality_gate)

    def debug_start(
        self,
        bug_description: str,
        related_session_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> DebugSession:
        return self._debug_service().start_session(
            bug_description, related_session_id, metadata
        )

    def debug_hypothesis(
        self,
        debug_session_id: str,
        text: str,
        confidence: float = 0.5,
    ) -> Hypothesis:
        hypothesis = self._debug_service().add_hypothesis(
            debug_session_id, text, confidence=confidence
        )
        self._index_source("debug_hypothesis", hypothesis.id)
        return hypothesis

    def debug_evidence(
        self,
        hypothesis_id: str,
        text: str,
        result: EvidenceResult = EvidenceResult.NEUTRAL,
        kind: str = "observation",
    ) -> Evidence:
        evidence = self._debug_service().add_evidence(
            hypothesis_id, text, result=result, kind=kind
        )
        self._index_source("debug_evidence", evidence.id)
        return evidence

    def debug_reject(self, hypothesis_id: str, reason: str) -> Hypothesis:
        return self._debug_service().reject_hypothesis(hypothesis_id, reason)

    def debug_confirm(self, hypothesis_id: str) -> Hypothesis:
        return self._debug_service().confirm_hypothesis(hypothesis_id)

    def debug_conclude(
        self,
        debug_session_id: str,
        conclusion: Optional[str] = None,
        status: DebugSessionStatus = DebugSessionStatus.RESOLVED,
    ) -> DebugSession:
        session = self._debug_service().conclude(debug_session_id, conclusion, status)
        if session.conclusion:
            self._index_source("debug_session", session.id)
        return session

    def get_debug_session(self, debug_session_id: str) -> Optional[DebugSession]:
        return self._debug_service().get_session(debug_session_id)

    def list_debug_sessions(
        self,
        status: Optional[DebugSessionStatus] = None,
        limit: int = 20,
    ) -> list[DebugSession]:
        return self._debug_service().list_sessions(status, limit)

    def search_debug_hypotheses(
        self,
        query: str,
        limit: int = 20,
        statuses: Optional[list[HypothesisStatus]] = None,
    ) -> list[Hypothesis]:
        return self._debug_service().search_hypotheses(
            query, limit=limit, statuses=statuses
        )

    # ── Memory Type Classification ──

    def reclassify_facts(
        self,
        entity_name: Optional[str] = None,
        only_default: bool = True,
    ) -> dict:
        """Re-run the predicate-based classifier over stored facts.

        ``only_default=True`` (the default) touches only facts that still
        carry the ``EPISODIC`` placeholder, so hand-curated types survive.
        Pass ``only_default=False`` to overwrite every fact — use with care.

        ``entity_name`` restricts the scan to a single entity; otherwise all
        entities are processed.
        """
        eid = None
        if entity_name is not None:
            entity = self.storage.get_entity_by_name(entity_name)
            if entity is None:
                return {"scanned": 0, "updated": 0, "by_type": {}}
            eid = entity.id

        rows = self.storage.get_all_facts_for_reclassify(entity_id=eid)

        scanned = 0
        updated = 0
        by_type: dict[str, int] = {}

        for row in rows:
            scanned += 1
            current = row["memory_type"] or MemoryType.EPISODIC.value
            if only_default and current != MemoryType.EPISODIC.value:
                continue
            new_type = classify_fact(row["predicate"] or "", row["raw_text"] or "")
            if new_type.value == current:
                continue
            self.storage.update_fact_memory_type(row["id"], new_type.value)
            updated += 1
            by_type[new_type.value] = by_type.get(new_type.value, 0) + 1

        self.storage.commit()
        return {
            "scanned": scanned,
            "updated": updated,
            "by_type": by_type,
        }

    # ── Intake / Cognify Staging ──

    def _intake_service(self) -> IntakeService:
        return IntakeService(
            storage=self.storage,
            extractor=self.extractor,
            quality_gate=self.quality_gate,
            session_mgr=self.session_mgr,
        )

    def intake(
        self,
        text: str,
        source: Optional[Source] = None,
        session_id: Optional[str] = None,
    ) -> IntakeBatch:
        """Run extraction against ``text`` and write candidates to staging.

        Main tables are not touched — review the returned batch, then call
        :meth:`apply_intake` to commit (or :meth:`reject_intake` to drop).
        """
        return self._intake_service().intake(text, source=source, session_id=session_id)

    def list_intakes(
        self,
        status: Optional[BatchStatus] = None,
        limit: int = 50,
    ) -> list[IntakeBatch]:
        return self._intake_service().list_batches(status=status, limit=limit)

    def get_intake(self, batch_id: str) -> Optional[IntakeBatch]:
        return self._intake_service().get_batch(batch_id)

    def reject_intake(
        self,
        batch_id: str,
        candidate_ids: Optional[list[str]] = None,
    ) -> IntakeBatch:
        return self._intake_service().reject(batch_id, candidate_ids)

    def apply_intake(
        self,
        batch_id: str,
        candidate_ids: Optional[list[str]] = None,
    ) -> IntakeApplyResult:
        """Apply pending candidates in the batch through the quality gate."""
        result = self._intake_service().apply(batch_id, candidate_ids)

        # Keep secondary search indexes consistent with the main tables.
        entity_ids: set[str] = set()
        for cand in result.applied:
            target = cand.applied_target_id
            if target:
                entity_ids.add(target)
        # applied_target_id for entity candidates is the entity id; for facts
        # it's the fact id. Map fact ids back to their entities.
        refined: set[str] = set()
        for eid_or_fid in entity_ids:
            mapped = self.storage.get_fact_entity_id(eid_or_fid)
            if mapped is not None:
                refined.add(mapped)
            else:
                refined.add(eid_or_fid)
        if refined:
            # Reindex each affected entity so FTS stays in sync.
            for eid in refined:
                entity = self.storage.get_entity(eid)
                if entity is not None:
                    self.storage.reindex_entity(entity)
            self.storage.commit()
            self._update_secondary_search_index(refined)

        return result

    def export_markdown(self) -> int:
        """Export all entities to Markdown."""
        from engram.storage.markdown_export import MarkdownExporter
        if not self._md_exporter or self._md_exporter.export_dir != self.config.export_dir:
            self._md_exporter = MarkdownExporter(self.config.export_dir)

        count = 0
        offset = 0
        batch_size = 500
        while True:
            batch = self.storage.list_entities(limit=batch_size, offset=offset)
            if not batch:
                break
            data = []
            for entity in batch:
                facts = self.storage.get_facts(entity.id)
                rels = self.storage.get_relations(entity.id)
                data.append((entity, facts, rels))
            count += self._md_exporter.export_all(data)
            offset += batch_size
        return count

    def reindex(self) -> int:
        """Rebuild the search index."""
        count = self.storage.reindex_all()

        clear_index = getattr(self.search_engine, "clear_index", None)
        if clear_index is not None:
            clear_index()

        if getattr(self.search_engine, "index_entity", None) is not None:
            offset = 0
            batch_size = 500
            while True:
                batch = self.storage.list_entities(limit=batch_size, offset=offset)
                if not batch:
                    break
                self._update_secondary_search_index([entity.id for entity in batch])
                offset += batch_size

        return count

    def compact_entity(self, entity_name: str) -> dict:
        """Compact an entity's facts: keep best per predicate, update summary.

        This is the core "learning" operation — transforms accumulated facts
        into synthesized knowledge.
        """
        entity = self.storage.get_entity_by_name(entity_name)
        if not entity:
            raise EntityNotFoundError(f"Entity '{entity_name}' not found")

        all_facts = self.storage.get_facts(entity.id)
        current = [f for f in all_facts if f.is_current]

        # Group by predicate, keep highest-confidence per predicate
        from collections import defaultdict
        by_predicate: dict[str, list[Fact]] = defaultdict(list)
        for f in current:
            by_predicate[f.predicate].append(f)

        kept = 0
        superseded = 0
        for predicate, facts in by_predicate.items():
            if len(facts) <= 1:
                kept += 1
                continue
            # Sort by confidence desc, then recency
            from datetime import datetime as _dt
            ranked = sorted(facts, key=lambda f: (f.confidence, f.created_at or _dt.min), reverse=True)
            kept += 1  # keep the best
            for old_fact in ranked[1:]:
                old_fact.supersede(ranked[0].id)
                self.storage.update_fact(old_fact)
                superseded += 1

        # Auto-generate summary from remaining current facts
        remaining = self.storage.get_current_facts(entity.id)
        summary_parts = []
        for f in remaining[:10]:
            summary_parts.append(f.raw_text)
        if summary_parts:
            entity.summary = ". ".join(summary_parts[:5])
            if not entity.summary.endswith("."):
                entity.summary += "."
            self.storage.update_entity(entity)

        return {
            "entity": entity_name,
            "facts_kept": kept,
            "facts_superseded": superseded,
            "new_summary": entity.summary,
        }

    def maintenance(self) -> dict:
        """Run maintenance: decay stale facts, compact heavy entities, clean old sessions."""
        from engram.quality.decay import find_stale_facts

        results: dict = {"stale_facts": 0, "compacted_entities": 0, "cleaned_sessions": 0}

        # Process all entities in batches to avoid loading everything at once.
        batch_size = 500
        offset = 0
        compact_targets: list[str] = []

        while True:
            batch = self.storage.list_entities(limit=batch_size, offset=offset)
            if not batch:
                break

            # 1. Find and flag stale facts using per-type half-lives.
            for entity in batch:
                facts = self.storage.get_current_facts(entity.id)
                stale = find_stale_facts(
                    facts,
                    days=self.config.decay_days,
                    policy=self.decay_policy,
                )
                for f in stale:
                    f.status = FactStatus.EXPIRED
                    self.storage.update_fact(f)
                    results["stale_facts"] += 1
                # 2. Collect entities needing compaction (> 20 current facts)
                current = [f for f in facts if f.is_current]
                if len(current) > 20:
                    compact_targets.append(entity.name)

            offset += batch_size

        # 2b. Compact collected entities
        for name in compact_targets:
            self.compact_entity(name)
            results["compacted_entities"] += 1

        # 3. Auto-resolve old conflicts (> 30 days)
        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(days=30)
        cutoff_str = cutoff.isoformat()
        pending = self.storage.get_pending_conflicts()
        for conflict in pending:
            # Only auto-resolve conflicts older than 30 days
            created_at = conflict.get("created_at", "")
            if not created_at or created_at > cutoff_str:
                continue
            # Auto-resolve based on suggested_resolution
            if conflict.get("suggested_resolution") == "supersede":
                self.resolve_conflict(
                    conflict["id"], "accept_new", "auto_maintenance"
                )

        return results

    # ── Private ──

    def _build_search_engine(self):
        """Build search engine based on config.search_backend.

        Falls back to FTS5 if semantic dependencies are missing.
        """
        if self.config.search_backend == "hybrid":
            try:
                from engram.search.hybrid import HybridSearch
                from engram.search.semantic import SemanticSearch
                import openai as _openai_probe  # noqa: F401 — fail fast if openai missing
                fts = FTS5Search(self.config.db_path)
                semantic = SemanticSearch(self.config.db_path)
                return HybridSearch(fts=fts, semantic=semantic)
            except ImportError:
                return FTS5Search(self.config.db_path)
        elif self.config.search_backend == "semantic":
            try:
                from engram.search.semantic import SemanticSearch
                import openai as _openai_probe  # noqa: F401 — fail fast if openai missing
                return SemanticSearch(self.config.db_path)
            except ImportError:
                return FTS5Search(self.config.db_path)
        else:
            return FTS5Search(self.config.db_path)

    def _build_extractor(self):
        """Build extractor based on config."""
        if self.config.extractor_backend == "llm":
            try:
                from engram.extraction.llm_extractor import LLMExtractor
                return LLMExtractor(
                    provider=self.config.llm_provider or "anthropic",
                    model=self.config.llm_model,
                )
            except ImportError:
                pass  # Fall back to regex
        from engram.extraction.regex_extractor import RegexExtractor
        return RegexExtractor()
