"""Debug-hypothesis models — capture the OBSERVE → HYPOTHESIZE → EXPERIMENT →
CONCLUDE flow so rejected approaches become searchable memory instead of
evaporating when the terminal closes.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §5.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class DebugSessionStatus(str, Enum):
    OPEN = "open"
    RESOLVED = "resolved"
    ABANDONED = "abandoned"


class HypothesisStatus(str, Enum):
    OPEN = "open"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    ABANDONED = "abandoned"


class EvidenceResult(str, Enum):
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    NEUTRAL = "neutral"


@dataclass
class Evidence:
    """A single observation attached to a hypothesis."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    hypothesis_id: str = ""
    text: str = ""
    result: EvidenceResult = EvidenceResult.NEUTRAL
    kind: str = "observation"
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "hypothesis_id": self.hypothesis_id,
            "text": self.text,
            "result": self.result.value,
            "kind": self.kind,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class Hypothesis:
    """A proposed explanation under investigation."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    debug_session_id: str = ""
    text: str = ""
    status: HypothesisStatus = HypothesisStatus.OPEN
    rejection_reason: Optional[str] = None
    confidence: float = 0.5
    created_at: datetime = field(default_factory=datetime.now)
    closed_at: Optional[datetime] = None
    evidence: list[Evidence] = field(default_factory=list)

    @property
    def support_count(self) -> int:
        return sum(1 for e in self.evidence if e.result == EvidenceResult.SUPPORTS)

    @property
    def contradict_count(self) -> int:
        return sum(1 for e in self.evidence if e.result == EvidenceResult.CONTRADICTS)

    @property
    def is_closed(self) -> bool:
        return self.status in (HypothesisStatus.CONFIRMED, HypothesisStatus.REJECTED, HypothesisStatus.ABANDONED)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "debug_session_id": self.debug_session_id,
            "text": self.text,
            "status": self.status.value,
            "rejection_reason": self.rejection_reason,
            "confidence": self.confidence,
            "created_at": self.created_at.isoformat(),
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
            "evidence": [e.to_dict() for e in self.evidence],
            "support_count": self.support_count,
            "contradict_count": self.contradict_count,
        }


@dataclass
class DebugSession:
    """One bug / investigation envelope grouping hypotheses."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    bug_description: str = ""
    status: DebugSessionStatus = DebugSessionStatus.OPEN
    conclusion: Optional[str] = None
    related_session_id: Optional[str] = None
    started_at: datetime = field(default_factory=datetime.now)
    closed_at: Optional[datetime] = None
    metadata: dict = field(default_factory=dict)
    hypotheses: list[Hypothesis] = field(default_factory=list)

    @property
    def is_open(self) -> bool:
        return self.status == DebugSessionStatus.OPEN

    def counts_by_hypothesis_status(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for h in self.hypotheses:
            out[h.status.value] = out.get(h.status.value, 0) + 1
        return out

    def open_hypotheses(self) -> list[Hypothesis]:
        return [h for h in self.hypotheses if h.status == HypothesisStatus.OPEN]

    def confirmed_hypotheses(self) -> list[Hypothesis]:
        return [h for h in self.hypotheses if h.status == HypothesisStatus.CONFIRMED]

    def rejected_hypotheses(self) -> list[Hypothesis]:
        return [h for h in self.hypotheses if h.status == HypothesisStatus.REJECTED]

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "bug_description": self.bug_description,
            "status": self.status.value,
            "conclusion": self.conclusion,
            "related_session_id": self.related_session_id,
            "started_at": self.started_at.isoformat(),
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
            "metadata": dict(self.metadata),
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "hypothesis_counts": self.counts_by_hypothesis_status(),
        }

    def to_agent_context(self, max_chars: int = 4000) -> str:
        parts: list[str] = []
        parts.append(f"## Debug Session: {self.id[:8]} ({self.status.value})")
        parts.append(f"Bug: {self.bug_description}")
        if self.conclusion:
            parts.append("")
            parts.append(f"Conclusion: {self.conclusion}")

        counts = self.counts_by_hypothesis_status()
        if counts:
            parts.append("")
            parts.append(
                "Hypothesis counts: "
                + ", ".join(f"{k}={v}" for k, v in sorted(counts.items()))
            )

        if self.hypotheses:
            parts.append("")
            parts.append("### Hypotheses")
            for h in self.hypotheses:
                marker = {
                    "open": "·",
                    "confirmed": "✓",
                    "rejected": "✕",
                    "abandoned": "○",
                }.get(h.status.value, "·")
                parts.append(f"- {marker} [{h.id[:8]}] {h.text}")
                parts.append(
                    f"    supports={h.support_count} · contradicts={h.contradict_count}"
                )
                if h.status == HypothesisStatus.REJECTED and h.rejection_reason:
                    parts.append(f"    rejected: {h.rejection_reason}")
                for ev in h.evidence:
                    result_symbol = {
                        "supports": "+",
                        "contradicts": "-",
                        "neutral": "=",
                    }.get(ev.result.value, "=")
                    snippet = ev.text.strip().replace("\n", " ")
                    if len(snippet) > 140:
                        snippet = snippet[:140].rstrip() + "…"
                    parts.append(f"    {result_symbol} {snippet}")

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        return text
