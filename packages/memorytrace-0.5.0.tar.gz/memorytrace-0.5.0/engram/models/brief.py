"""Brief data models for compact agent-facing summaries."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from engram.models.entity import Entity
from engram.models.explanation import ExplanationBundle
from engram.models.fact import Fact
from engram.models.session import Session


@dataclass
class ConflictInfo:
    """A lightweight, display-oriented view of a pending conflict."""

    conflict_id: str
    conflict_type: str
    suggested_resolution: Optional[str] = None
    existing_fact_text: Optional[str] = None
    new_fact_text: Optional[str] = None
    created_at: Optional[datetime] = None

    def to_dict(self) -> dict:
        return {
            "conflict_id": self.conflict_id,
            "conflict_type": self.conflict_type,
            "suggested_resolution": self.suggested_resolution,
            "existing_fact_text": self.existing_fact_text,
            "new_fact_text": self.new_fact_text,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


@dataclass
class NoteInfo:
    """A note snippet associated with an entity or session."""

    note_id: str
    text: str
    created_at: datetime
    source_type: str = "user_input"

    def to_dict(self, preview_chars: int = 200) -> dict:
        text = self.text
        if preview_chars > 0 and len(text) > preview_chars:
            text = text[:preview_chars].rstrip() + "..."
        return {
            "note_id": self.note_id,
            "text": text,
            "created_at": self.created_at.isoformat(),
            "source_type": self.source_type,
        }


@dataclass
class RelatedEntity:
    """A neighbor entity connected by a relation."""

    entity_id: str
    name: str
    entity_type: str
    relation_type: str
    direction: str

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "entity_type": self.entity_type,
            "relation_type": self.relation_type,
            "direction": self.direction,
        }


@dataclass
class SessionRef:
    """Compact reference to a session that touched an entity."""

    session_id: str
    agent_id: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    summary: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "summary": self.summary,
        }


@dataclass
class SupportingHit:
    """A lightweight reranked search hit embedded into a brief."""

    entity_id: str
    entity_name: str
    entity_type: str
    relevance_score: float
    snippet: str = ""
    explanation: ExplanationBundle = field(
        default_factory=lambda: ExplanationBundle(summary="")
    )

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "entity_name": self.entity_name,
            "entity_type": self.entity_type,
            "relevance_score": self.relevance_score,
            "snippet": self.snippet,
            "explanation": self.explanation.to_dict(),
        }


@dataclass
class EntityBrief:
    """Full context pack for a single entity."""

    entity: Entity
    top_facts: list[Fact] = field(default_factory=list)
    related_entities: list[RelatedEntity] = field(default_factory=list)
    recent_notes: list[NoteInfo] = field(default_factory=list)
    recent_sessions: list[SessionRef] = field(default_factory=list)
    unresolved_conflicts: list[ConflictInfo] = field(default_factory=list)
    supporting_hits: list[SupportingHit] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "entity": {
                "id": self.entity.id,
                "name": self.entity.name,
                "type": self.entity.entity_type,
                "tier": self.entity.tier.value,
                "summary": self.entity.summary,
                "aliases": list(self.entity.aliases),
                "state": self.entity.state.to_dict(),
                "access_count": self.entity.access_count,
                "last_accessed": (
                    self.entity.last_accessed.isoformat()
                    if self.entity.last_accessed
                    else None
                ),
            },
            "top_facts": [
                {
                    "id": f.id,
                    "predicate": f.predicate,
                    "object": f.object,
                    "text": f.raw_text,
                    "confidence": f.confidence,
                    "status": f.status.value,
                    "memory_type": f.memory_type.value,
                    "created_at": f.created_at.isoformat(),
                }
                for f in self.top_facts
            ],
            "related_entities": [r.to_dict() for r in self.related_entities],
            "recent_notes": [n.to_dict() for n in self.recent_notes],
            "recent_sessions": [s.to_dict() for s in self.recent_sessions],
            "unresolved_conflicts": [c.to_dict() for c in self.unresolved_conflicts],
            "supporting_hits": [h.to_dict() for h in self.supporting_hits],
            "generated_at": self.generated_at.isoformat(),
        }

    def to_agent_context(self, max_chars: int = 4000) -> str:
        parts: list[str] = []
        e = self.entity

        parts.append(f"## Entity: {e.name}")
        meta = f"Type: {e.entity_type} | Tier: {e.tier.value}"
        if e.access_count:
            meta += f" | Access count: {e.access_count}"
        parts.append(meta)
        if e.aliases:
            parts.append("Aliases: " + ", ".join(e.aliases))
        if e.summary:
            parts.append("")
            parts.append(e.summary)

        state = e.state.to_dict()
        state_without_custom = {k: v for k, v in state.items() if k != "custom"}
        if state_without_custom:
            parts.append("")
            parts.append("### State")
            for key, value in state_without_custom.items():
                parts.append(f"- {key}: {value}")

        if self.top_facts:
            parts.append("")
            parts.append("### Top Facts")
            for fact in self.top_facts:
                parts.append(
                    f"- {fact.raw_text} (confidence: {fact.confidence:.2f}, status: {fact.status.value})"
                )

        if self.related_entities:
            parts.append("")
            parts.append("### Related Entities")
            for related in self.related_entities:
                arrow = "->" if related.direction == "outgoing" else "<-"
                parts.append(
                    f"- {arrow} {related.name} ({related.entity_type}) via {related.relation_type}"
                )

        if self.recent_notes:
            parts.append("")
            parts.append("### Recent Notes")
            for note in self.recent_notes:
                snippet = note.text.strip().replace("\n", " ")
                if len(snippet) > 180:
                    snippet = snippet[:180].rstrip() + "..."
                parts.append(f"- [{note.created_at.date().isoformat()}] {snippet}")

        if self.recent_sessions:
            parts.append("")
            parts.append("### Recent Sessions")
            for session in self.recent_sessions:
                label = session.summary or f"session {session.session_id[:8]}"
                parts.append(f"- [{session.started_at.date().isoformat()}] {label}")

        if self.unresolved_conflicts:
            parts.append("")
            parts.append("### Unresolved Conflicts")
            for conflict in self.unresolved_conflicts:
                desc = conflict.suggested_resolution or "needs review"
                parts.append(
                    f"- [{conflict.conflict_id[:8]}] {conflict.conflict_type} -> {desc}"
                )

        if self.supporting_hits:
            parts.append("")
            parts.append("### Supporting Hits")
            for hit in self.supporting_hits[:3]:
                line = f"- {hit.entity_name} ({hit.entity_type})"
                if hit.snippet:
                    line += f": {hit.snippet}"
                parts.append(line)

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 3].rstrip() + "..."
        return text


@dataclass
class FactRef:
    """Compact reference to a fact emitted during a session."""

    fact_id: str
    entity_name: str
    predicate: str
    text: str
    confidence: float

    def to_dict(self) -> dict:
        return {
            "fact_id": self.fact_id,
            "entity_name": self.entity_name,
            "predicate": self.predicate,
            "text": self.text,
            "confidence": self.confidence,
        }


@dataclass
class EntityRef:
    """Compact reference to an entity touched during a session."""

    entity_id: str
    name: str
    entity_type: str

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "entity_type": self.entity_type,
        }


@dataclass
class SessionBrief:
    """Full context pack for a single session."""

    session: Session
    entities_modified: list[EntityRef] = field(default_factory=list)
    entities_accessed: list[EntityRef] = field(default_factory=list)
    facts_added: list[FactRef] = field(default_factory=list)
    active_working_memory: list[EntityRef] = field(default_factory=list)
    recent_queries: list[str] = field(default_factory=list)
    open_conflicts: list[ConflictInfo] = field(default_factory=list)
    supporting_hits: list[SupportingHit] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "session": {
                "session_id": self.session.session_id,
                "agent_id": self.session.agent_id,
                "started_at": self.session.started_at.isoformat(),
                "ended_at": (
                    self.session.ended_at.isoformat()
                    if self.session.ended_at
                    else None
                ),
                "is_active": self.session.is_active,
                "duration_minutes": self.session.duration_minutes,
                "summary": self.session.summary,
            },
            "entities_modified": [r.to_dict() for r in self.entities_modified],
            "entities_accessed": [r.to_dict() for r in self.entities_accessed],
            "facts_added": [r.to_dict() for r in self.facts_added],
            "active_working_memory": [r.to_dict() for r in self.active_working_memory],
            "recent_queries": list(self.recent_queries),
            "open_conflicts": [c.to_dict() for c in self.open_conflicts],
            "supporting_hits": [h.to_dict() for h in self.supporting_hits],
            "generated_at": self.generated_at.isoformat(),
        }

    def to_agent_context(self, max_chars: int = 4000) -> str:
        parts: list[str] = []
        session = self.session

        parts.append(f"## Session: {session.session_id[:8]}")
        meta = f"Agent: {session.agent_id}"
        meta += " | Active" if session.is_active else " | Ended"
        if session.duration_minutes is not None:
            meta += f" | Duration: {session.duration_minutes} min"
        parts.append(meta)

        if session.summary:
            parts.append("")
            parts.append(session.summary)

        if self.entities_modified:
            parts.append("")
            parts.append("### Entities Modified")
            for ref in self.entities_modified:
                parts.append(f"- {ref.name} ({ref.entity_type})")

        if self.entities_accessed:
            parts.append("")
            parts.append("### Entities Accessed")
            for ref in self.entities_accessed:
                parts.append(f"- {ref.name} ({ref.entity_type})")

        if self.facts_added:
            parts.append("")
            parts.append("### Facts Added")
            for fact in self.facts_added:
                parts.append(
                    f"- {fact.entity_name}: {fact.text} (confidence: {fact.confidence:.2f})"
                )

        if self.active_working_memory:
            parts.append("")
            parts.append("### Working Memory")
            parts.append("Active: " + ", ".join(ref.name for ref in self.active_working_memory))

        if self.recent_queries:
            queries = [query for query in self.recent_queries if query][:5]
            if queries:
                parts.append("")
                parts.append("Recent queries: " + ", ".join(f'"{query}"' for query in queries))

        if self.open_conflicts:
            parts.append("")
            parts.append("### Open Conflicts")
            for conflict in self.open_conflicts:
                desc = conflict.suggested_resolution or "needs review"
                parts.append(
                    f"- [{conflict.conflict_id[:8]}] {conflict.conflict_type} -> {desc}"
                )

        if self.supporting_hits:
            parts.append("")
            parts.append("### Supporting Hits")
            for hit in self.supporting_hits[:3]:
                line = f"- {hit.entity_name} ({hit.entity_type})"
                if hit.snippet:
                    line += f": {hit.snippet}"
                parts.append(line)

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 3].rstrip() + "..."
        return text
