"""Shared explanation models for agent-facing read paths."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ProvenanceReason:
    """One lightweight retrieval or lookup reason."""

    kind: str
    detail: str

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "detail": self.detail,
        }


@dataclass
class ProvenanceTrace:
    """Base retrieval or lookup path before final explanation packaging."""

    retriever: str
    query: str = ""
    base_score: float = 0.0
    snippet: str = ""
    matched_fact_ids: list[str] = field(default_factory=list)
    reasons: list[ProvenanceReason] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "retriever": self.retriever,
            "query": self.query,
            "base_score": self.base_score,
            "snippet": self.snippet,
            "matched_fact_ids": list(self.matched_fact_ids),
            "reasons": [reason.to_dict() for reason in self.reasons],
        }


@dataclass
class ExplanationFactor:
    """One retrieval, reranking, or post-filter explanation factor."""

    name: str
    stage: str
    delta: float
    reason: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "stage": self.stage,
            "delta": self.delta,
            "reason": self.reason,
        }


@dataclass
class EvidenceRef:
    """One structured object that supports a result."""

    kind: str
    id: str
    label: str
    snippet: str = ""
    entity_id: Optional[str] = None
    source_kind: Optional[str] = None
    source_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "id": self.id,
            "label": self.label,
            "snippet": self.snippet,
            "entity_id": self.entity_id,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
        }


@dataclass
class ExplanationBundle:
    """Final explanation contract reused across read paths."""

    summary: str
    trace: Optional[ProvenanceTrace] = None
    factors: list[ExplanationFactor] = field(default_factory=list)
    evidence: list[EvidenceRef] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "trace": self.trace.to_dict() if self.trace else None,
            "factors": [factor.to_dict() for factor in self.factors],
            "evidence": [evidence.to_dict() for evidence in self.evidence],
            "warnings": list(self.warnings),
        }
