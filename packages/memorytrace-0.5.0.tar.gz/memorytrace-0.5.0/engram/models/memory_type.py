"""Memory-type taxonomy — decide how fast a fact should decay.

Starts with the minimum viable set from
docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §4:

- ``IDENTITY`` — biographical / structural facts (role, affiliation, …)
- ``PREFERENCE`` — likes, dislikes, favourites, stable tastes
- ``EPISODIC`` — one-off events, observations, activities (default)
- ``TRANSIENT`` — short-lived, volatile state ("currently in a meeting")

Keeping the set small is deliberate. Four buckets are enough to express
"don't forget identity" vs "age out yesterday's mood" without creating
a classification problem that needs an LLM to solve.
"""

from __future__ import annotations

from enum import Enum


class MemoryType(str, Enum):
    IDENTITY = "identity"
    PREFERENCE = "preference"
    EPISODIC = "episodic"
    TRANSIENT = "transient"


# Predicate → type keyword sets. Compared case-insensitively as substring
# matches so synonyms like "affiliated_with", "preferred_language", or
# "current_role" still route to the right bucket.
_IDENTITY_KEYWORDS = (
    "role",
    "affiliation",
    "affiliated",
    "location",
    "email",
    "name",
    "alias",
    "title",
    "position",
    "born",
    "birthdate",
    "nationality",
    "gender",
    "pronouns",
    "employer",
    "company",
    "organization",
    "department",
)

_PREFERENCE_KEYWORDS = (
    "prefer",
    "like",
    "likes",
    "dislike",
    "favorite",
    "favourite",
    "hobby",
    "interest",
    "taste",
    "style",
    "choice",
    "preferred",
)

_TRANSIENT_KEYWORDS = (
    "currently",
    "now",
    "today",
    "temporary",
    "mood",
    "right_now",
    "this_hour",
    "this_week",
    "in_progress",
    "ongoing",
)


def classify_predicate(predicate: str) -> MemoryType:
    """Map a predicate to a :class:`MemoryType`.

    Returns :attr:`MemoryType.EPISODIC` when no keyword matches — that's the
    safe default for "something happened" style facts.
    """
    if not predicate:
        return MemoryType.EPISODIC
    needle = predicate.lower().strip()
    for kw in _IDENTITY_KEYWORDS:
        if kw in needle:
            return MemoryType.IDENTITY
    for kw in _PREFERENCE_KEYWORDS:
        if kw in needle:
            return MemoryType.PREFERENCE
    for kw in _TRANSIENT_KEYWORDS:
        if kw in needle:
            return MemoryType.TRANSIENT
    return MemoryType.EPISODIC


def _text_has_keyword(text: str, keyword: str) -> bool:
    """Check if ``keyword`` appears in ``text`` as a whole word or compound part.

    Short keywords (<=5 chars) like "name", "like", "title" require word
    boundaries to avoid false positives on common English words. Longer
    keywords like "affiliation" or "nationality" are unlikely to match
    spuriously, so plain substring matching is kept.
    """
    if len(keyword) <= 5:
        import re
        return bool(re.search(r'\b' + re.escape(keyword) + r'\b', text))
    return keyword in text


def classify_fact(predicate: str, raw_text: str = "") -> MemoryType:
    """Classify a fact using its predicate first, then hints from raw text."""
    via_pred = classify_predicate(predicate)
    if via_pred != MemoryType.EPISODIC:
        return via_pred
    needle = (raw_text or "").lower()
    for kw in _TRANSIENT_KEYWORDS:
        if _text_has_keyword(needle, kw):
            return MemoryType.TRANSIENT
    for kw in _PREFERENCE_KEYWORDS:
        if _text_has_keyword(needle, kw):
            return MemoryType.PREFERENCE
    for kw in _IDENTITY_KEYWORDS:
        if _text_has_keyword(needle, kw):
            return MemoryType.IDENTITY
    return MemoryType.EPISODIC
