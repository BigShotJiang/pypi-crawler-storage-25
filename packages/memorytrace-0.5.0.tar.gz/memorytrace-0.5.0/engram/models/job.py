"""Persisted asynchronous job models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class JobRecord:
    """One persisted background job."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    job_type: str = ""
    status: str = "queued"
    payload: dict = field(default_factory=dict)
    attempts: int = 0
    max_attempts: int = 3
    available_at: datetime = field(default_factory=datetime.now)
    leased_at: datetime | None = None
    lease_owner: str | None = None
    last_error: str | None = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    completed_at: datetime | None = None
