"""Entity data models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class Tier(str, Enum):
    CORE = "core"
    RECALL = "recall"
    ARCHIVAL = "archival"


@dataclass
class EntityState:
    """Structured key-value attributes of an entity."""

    role: Optional[str] = None
    affiliation: Optional[str] = None
    location: Optional[str] = None
    email: Optional[str] = None
    custom: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.role is not None:
            result["role"] = self.role
        if self.affiliation is not None:
            result["affiliation"] = self.affiliation
        if self.location is not None:
            result["location"] = self.location
        if self.email is not None:
            result["email"] = self.email
        if self.custom:
            result["custom"] = self.custom
        return result

    @classmethod
    def from_dict(cls, data: dict) -> EntityState:
        return cls(
            role=data.get("role"),
            affiliation=data.get("affiliation"),
            location=data.get("location"),
            email=data.get("email"),
            custom=data.get("custom", {}),
        )


@dataclass
class Entity:
    """A tracked entity: person, organization, project, or concept."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    entity_type: str = "person"
    state: EntityState = field(default_factory=EntityState)
    tier: Tier = Tier.RECALL
    summary: str = ""
    aliases: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    last_accessed: Optional[datetime] = None

    def touch(self) -> None:
        """Record an access."""
        self.access_count += 1
        self.last_accessed = datetime.now()
