"""Intake / Cognify staging models — safe triage of raw input.

Rather than letting ``store(text)`` push unreviewed extractions directly into
the main tables, the intake pipeline writes candidates to dedicated staging
tables first. A human (or agent) then applies or rejects each candidate.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §3.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class CandidateType(str, Enum):
    ENTITY = "entity"
    FACT = "fact"
    RELATION = "relation"


class CandidateStatus(str, Enum):
    PENDING = "pending"
    APPLIED = "applied"
    REJECTED = "rejected"
    SKIPPED = "skipped"  # applied but produced no change (e.g., duplicate)


class BatchStatus(str, Enum):
    PENDING = "pending"
    APPLIED = "applied"
    REJECTED = "rejected"
    MIXED = "mixed"


@dataclass
class IntakeCandidate:
    """A single proposed write extracted from raw input."""

    id: str
    batch_id: str
    candidate_type: CandidateType
    payload: dict
    status: CandidateStatus = CandidateStatus.PENDING
    applied_target_id: Optional[str] = None
    notes: str = ""
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "batch_id": self.batch_id,
            "candidate_type": self.candidate_type.value,
            "payload": self.payload,
            "status": self.status.value,
            "applied_target_id": self.applied_target_id,
            "notes": self.notes,
            "created_at": self.created_at.isoformat(),
        }

    def describe(self) -> str:
        """Human-readable one-line summary of the candidate."""
        if self.candidate_type == CandidateType.ENTITY:
            name = self.payload.get("name", "?")
            etype = self.payload.get("entity_type", "entity")
            return f"entity: {name} ({etype})"
        if self.candidate_type == CandidateType.FACT:
            subject = self.payload.get("subject", "?")
            text = self.payload.get("raw_text") or self.payload.get("object", "")
            return f"fact: {subject} — {text}"
        if self.candidate_type == CandidateType.RELATION:
            frm = self.payload.get("from_name", "?")
            to = self.payload.get("to_name", "?")
            rtype = self.payload.get("relation_type", "related")
            return f"relation: {frm} —{rtype}→ {to}"
        return f"{self.candidate_type.value}: {self.payload}"


@dataclass
class IntakeBatch:
    """A batch of candidates derived from a single intake submission."""

    id: str
    raw_text: str
    source_type: str = "user_input"
    source_author: str = ""
    source_channel: str = ""
    session_id: Optional[str] = None
    status: BatchStatus = BatchStatus.PENDING
    metadata: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    candidates: list[IntakeCandidate] = field(default_factory=list)

    def counts_by_type(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for c in self.candidates:
            out[c.candidate_type.value] = out.get(c.candidate_type.value, 0) + 1
        return out

    def counts_by_status(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for c in self.candidates:
            out[c.status.value] = out.get(c.status.value, 0) + 1
        return out

    def pending_candidates(self) -> list[IntakeCandidate]:
        return [c for c in self.candidates if c.status == CandidateStatus.PENDING]

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "raw_text_preview": (
                self.raw_text[:500] + "…" if len(self.raw_text) > 500 else self.raw_text
            ),
            "source_type": self.source_type,
            "source_author": self.source_author,
            "source_channel": self.source_channel,
            "session_id": self.session_id,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "counts_by_type": self.counts_by_type(),
            "counts_by_status": self.counts_by_status(),
            "candidates": [c.to_dict() for c in self.candidates],
        }

    def to_agent_context(self, max_chars: int = 4000) -> str:
        parts: list[str] = []
        parts.append(f"## Intake Batch: {self.id[:8]} ({self.status.value})")
        preview = self.raw_text.strip().replace("\n", " ")
        if len(preview) > 180:
            preview = preview[:180].rstrip() + "…"
        parts.append(f"Source: {self.source_type} · {len(self.candidates)} candidates")
        if preview:
            parts.append("")
            parts.append(f"> {preview}")

        by_type = self.counts_by_type()
        if by_type:
            parts.append("")
            parts.append(
                "Counts: "
                + ", ".join(f"{k}={v}" for k, v in sorted(by_type.items()))
            )

        if self.candidates:
            parts.append("")
            parts.append("### Candidates")
            for c in self.candidates:
                marker = {
                    "pending": "·",
                    "applied": "✓",
                    "rejected": "✕",
                    "skipped": "○",
                }.get(c.status.value, "·")
                parts.append(f"- {marker} [{c.id[:8]}] {c.describe()}")

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        return text


@dataclass
class IntakeApplyResult:
    """Outcome of an apply operation against a staging batch."""

    batch_id: str
    applied: list[IntakeCandidate] = field(default_factory=list)
    rejected: list[IntakeCandidate] = field(default_factory=list)
    skipped: list[IntakeCandidate] = field(default_factory=list)
    facts_quarantined: int = 0
    facts_conflicted: int = 0

    def to_dict(self) -> dict:
        return {
            "batch_id": self.batch_id,
            "applied_count": len(self.applied),
            "rejected_count": len(self.rejected),
            "skipped_count": len(self.skipped),
            "facts_quarantined": self.facts_quarantined,
            "facts_conflicted": self.facts_conflicted,
            "applied": [c.to_dict() for c in self.applied],
            "rejected": [c.to_dict() for c in self.rejected],
            "skipped": [c.to_dict() for c in self.skipped],
        }
