"""Freshness and verification workflow models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class VerificationStatus(str, Enum):
    UNKNOWN = "unknown"
    PENDING = "pending"
    VERIFIED = "verified"
    STALE = "stale"


class VerificationRequestStatus(str, Enum):
    OPEN = "open"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"


class VerificationResolution(str, Enum):
    VERIFIED = "verified"
    STALE = "stale"
    RETRACTED = "retracted"
    SUPERSEDED = "superseded"


@dataclass
class VerificationRequest:
    """A queued verification task for a fact or decision."""

    target_kind: str
    target_id: str
    reason: str
    requested_by: str
    entity_id: Optional[str] = None
    scope_id: Optional[str] = None
    status: VerificationRequestStatus = VerificationRequestStatus.OPEN
    resolution: Optional[VerificationResolution] = None
    detail: str = ""
    metadata: dict = field(default_factory=dict)
    requested_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "target_kind": self.target_kind,
            "target_id": self.target_id,
            "entity_id": self.entity_id,
            "scope_id": self.scope_id,
            "reason": self.reason,
            "status": self.status.value,
            "requested_by": self.requested_by,
            "resolution": self.resolution.value if self.resolution is not None else None,
            "detail": self.detail,
            "metadata": dict(self.metadata),
            "requested_at": self.requested_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


@dataclass
class FreshnessAssessment:
    """Runtime freshness result used by read paths and diagnostics."""

    status: VerificationStatus
    due: bool = False
    stale: bool = False
    penalty: float = 0.0
    reason: str = ""
    warning: str = ""
    should_open_request: bool = False
