"""Search-related data models."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from engram.models.entity import Entity
from engram.models.explanation import ExplanationBundle, ProvenanceReason, ProvenanceTrace
from engram.models.fact import Fact


@dataclass
class RetrievalContext:
    """Explicit search intent and scope signals used for reranking."""

    goal: str = "general"
    session_id: Optional[str] = None
    active_entity_ids: list[str] = field(default_factory=list)
    recent_entity_ids: list[str] = field(default_factory=list)
    preferred_entity_ids: list[str] = field(default_factory=list)
    preferred_entity_types: list[str] = field(default_factory=list)
    preferred_tiers: list[str] = field(default_factory=list)
    include_explanations: bool = False


@dataclass
class RankingFactor:
    """One additive reranking explanation."""

    name: str
    delta: float
    reason: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "delta": self.delta,
            "reason": self.reason,
        }


@dataclass
class SearchOptions:
    """Options for a memory search query."""

    query: str = ""
    max_results: int = 10
    max_tokens: int = 500  # token budget for agent context
    min_confidence: float = 0.0
    entity_types: list[str] = field(default_factory=list)
    tiers: list[str] = field(default_factory=list)
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    include_archived: bool = False
    context_tags: list[str] = field(default_factory=list)
    context: Optional[RetrievalContext] = None


@dataclass
class QueryPlan:
    """Plan for expanding a compound search into focused fragments."""

    original_query: str
    fragments: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    should_expand: bool = False

    def to_dict(self) -> dict:
        return {
            "original_query": self.original_query,
            "fragments": list(self.fragments),
            "reasons": list(self.reasons),
            "should_expand": self.should_expand,
        }


@dataclass
class SearchHit:
    """A single search result."""

    entity: Entity
    facts: list[Fact] = field(default_factory=list)
    relevance_score: float = 0.0
    base_score: float = 0.0
    snippet: str = ""
    token_count: int = 0
    ranking_factors: list[RankingFactor] = field(default_factory=list)
    provenance: ProvenanceTrace = field(
        default_factory=lambda: ProvenanceTrace(retriever="fts5_bm25")
    )
    explanation: ExplanationBundle = field(
        default_factory=lambda: ExplanationBundle(summary="")
    )


@dataclass
class SearchResult:
    """Complete search response."""

    query: str = ""
    hits: list[SearchHit] = field(default_factory=list)
    total_count: int = 0
    search_time_ms: float = 0.0
    total_tokens: int = 0
    notes: list[dict] = field(default_factory=list)

    def to_agent_context(self, max_tokens: int = 500) -> str:
        """Serialize to compact text for LLM context injection."""
        if not self.hits and not self.notes:
            return f"No results found for '{self.query}'."

        parts: list[str] = []
        tokens_used = 0

        for hit in self.hits:
            entry = f"[{hit.entity.name}] ({hit.entity.entity_type})"
            if hit.entity.state.role:
                entry += f" Role: {hit.entity.state.role}"
            if hit.entity.state.affiliation:
                entry += f" @ {hit.entity.state.affiliation}"
            if hit.snippet:
                entry += f" | {hit.snippet}"
            # Rough token estimate: 1 token ≈ 4 chars
            entry_tokens = len(entry) // 4
            if tokens_used + entry_tokens > max_tokens:
                if not parts:
                    # Always include at least the first hit (name+type, truncated)
                    truncated = entry[:max_tokens * 4]
                    parts.append(truncated)
                    tokens_used += len(truncated) // 4
                continue
            parts.append(entry)
            tokens_used += entry_tokens

        for note in self.notes:
            entry = f"[Note] {note['text'][:200]}"
            entry_tokens = len(entry) // 4
            if tokens_used + entry_tokens > max_tokens:
                break
            parts.append(entry)
            tokens_used += entry_tokens

        return "\n".join(parts)

    def to_dict(self) -> dict:
        """Structured dict for MCP/SDK responses."""
        return {
            "query": self.query,
            "total_count": self.total_count,
            "search_time_ms": self.search_time_ms,
            "hits": [
                {
                    "entity_name": h.entity.name,
                    "entity_type": h.entity.entity_type,
                    "base_score": h.base_score,
                    "relevance_score": h.relevance_score,
                    "snippet": h.snippet,
                    "ranking_factors": [factor.to_dict() for factor in h.ranking_factors],
                    "provenance": h.provenance.to_dict(),
                    "explanation": h.explanation.to_dict(),
                    "facts": [
                        {
                            "text": f.raw_text,
                            "confidence": f.confidence,
                            "status": f.status.value,
                            "applicability": f.applicability.to_dict(),
                        }
                        for f in h.facts
                    ],
                }
                for h in self.hits
            ],
            "notes": self.notes,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)
