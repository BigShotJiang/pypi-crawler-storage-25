"""Decision projection models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from engram.models.verification import VerificationStatus


class DecisionStatus(str, Enum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    DRAFT = "draft"


@dataclass
class DecisionRecord:
    """A structured decision distilled from canonical source text."""

    title: str
    summary: str
    status: DecisionStatus
    confidence: float
    source_kind: str
    source_id: str
    fingerprint: str
    entity_id: Optional[str] = None
    session_id: Optional[str] = None
    superseded_by: Optional[str] = None
    verification_status: VerificationStatus = VerificationStatus.UNKNOWN
    last_verified_at: Optional[datetime] = None
    verification_due_at: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)
    indexed_at: datetime = field(default_factory=datetime.now)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "fingerprint": self.fingerprint,
            "title": self.title,
            "summary": self.summary,
            "status": self.status.value,
            "confidence": self.confidence,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "entity_id": self.entity_id,
            "session_id": self.session_id,
            "superseded_by": self.superseded_by,
            "verification_status": self.verification_status.value,
            "last_verified_at": (
                self.last_verified_at.isoformat() if self.last_verified_at else None
            ),
            "verification_due_at": (
                self.verification_due_at.isoformat()
                if self.verification_due_at
                else None
            ),
            "created_at": self.created_at.isoformat(),
            "indexed_at": self.indexed_at.isoformat(),
        }
