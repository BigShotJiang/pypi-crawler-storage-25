"""Operations review models."""

from __future__ import annotations

from dataclasses import dataclass, field

from engram.models.health import HealthReport
from engram.models.retention import RecommendationView
from engram.models.view import MaintenanceRunView


@dataclass
class ProjectionDriftItem:
    source_kind: str
    source_id: str
    title: str
    detail: str

    @classmethod
    def from_dict(cls, payload: dict) -> "ProjectionDriftItem":
        return cls(
            source_kind=payload.get("source_kind", ""),
            source_id=payload.get("source_id", ""),
            title=payload.get("title", ""),
            detail=payload.get("detail", ""),
        )

    def to_dict(self) -> dict:
        return {
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "title": self.title,
            "detail": self.detail,
        }


@dataclass
class JobRunSummary:
    leased: int = 0
    completed: int = 0
    failed: int = 0

    @classmethod
    def from_dict(cls, payload: dict) -> "JobRunSummary":
        return cls(
            leased=int(payload.get("leased", 0)),
            completed=int(payload.get("completed", 0)),
            failed=int(payload.get("failed", 0)),
        )

    def to_dict(self) -> dict:
        return {
            "leased": self.leased,
            "completed": self.completed,
            "failed": self.failed,
        }


@dataclass
class OperationsReview:
    health_report: HealthReport | None = None
    maintenance_run: MaintenanceRunView | None = None
    job_result: JobRunSummary | None = None
    reference_drift: list[ProjectionDriftItem] = field(default_factory=list)
    decision_drift: list[ProjectionDriftItem] = field(default_factory=list)
    recommendations: list[RecommendationView] = field(default_factory=list)
    summary_lines: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "health_report": self.health_report.to_dict() if self.health_report else None,
            "maintenance_run": self.maintenance_run.to_dict() if self.maintenance_run else None,
            "job_result": self.job_result.to_dict() if self.job_result else None,
            "reference_drift": [row.to_dict() for row in self.reference_drift],
            "decision_drift": [row.to_dict() for row in self.decision_drift],
            "recommendations": [row.to_dict() for row in self.recommendations],
            "summary_lines": list(self.summary_lines),
        }
