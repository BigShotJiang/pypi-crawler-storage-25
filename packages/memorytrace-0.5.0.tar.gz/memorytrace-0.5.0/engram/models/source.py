"""Source and provenance models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class SourceType(str, Enum):
    DIRECT_SPEECH = "direct_speech"
    DOCUMENT = "document"
    API = "api"
    WEB = "web"
    AGENT_INFERENCE = "agent_inference"
    USER_INPUT = "user_input"


# Base trust scores per source type — single source of truth.
# Also used by engram.quality.confidence.
SOURCE_BASE_TRUST: dict[SourceType, float] = {
    SourceType.DIRECT_SPEECH: 0.95,
    SourceType.DOCUMENT: 0.85,
    SourceType.USER_INPUT: 0.90,
    SourceType.API: 0.80,
    SourceType.WEB: 0.60,
    SourceType.AGENT_INFERENCE: 0.40,
}


@dataclass
class Source:
    """Provenance metadata for a fact."""

    type: SourceType = SourceType.USER_INPUT
    author: str = ""
    channel: str = ""  # meeting, email, slack, cli, mcp
    timestamp: datetime = field(default_factory=datetime.now)
    confidence: float = 1.0  # submitter's own confidence (0.0–1.0)
    url: Optional[str] = None
    session_id: Optional[str] = None

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, self.confidence))

    @property
    def trust_score(self) -> float:
        """Combined trust: base score for source type × submitter confidence."""
        base = SOURCE_BASE_TRUST.get(self.type, 0.5)
        return base * self.confidence

    def to_dict(self) -> dict:
        return {
            "type": self.type.value,
            "author": self.author,
            "channel": self.channel,
            "timestamp": self.timestamp.isoformat(),
            "confidence": self.confidence,
            "url": self.url,
            "session_id": self.session_id,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Source:
        return cls(
            type=SourceType(data.get("type", "user_input")),
            author=data.get("author", ""),
            channel=data.get("channel", ""),
            timestamp=datetime.fromisoformat(data["timestamp"]) if data.get("timestamp") else datetime.now(),
            confidence=data.get("confidence", 1.0),
            url=data.get("url"),
            session_id=data.get("session_id"),
        )
