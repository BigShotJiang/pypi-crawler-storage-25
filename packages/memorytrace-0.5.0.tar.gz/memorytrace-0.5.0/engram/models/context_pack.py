"""Context pack models for session transfer."""

from __future__ import annotations

from dataclasses import dataclass, field

from engram.models.brief import EntityRef
from engram.models.health import OpenLoop
from engram.models.session import Session
from engram.models.view import DecisionView


@dataclass
class ContextPack:
    source_session_id: str
    source_agent_id: str
    scope_id: str | None
    goal: str
    summary: str
    source_session_active: bool = False
    active_entities: list[EntityRef] = field(default_factory=list)
    recent_queries: list[str] = field(default_factory=list)
    supporting_decisions: list[DecisionView] = field(default_factory=list)
    open_loops: list[OpenLoop] = field(default_factory=list)
    rendered_text: str = ""

    def to_dict(self) -> dict:
        return {
            "source_session_id": self.source_session_id,
            "source_agent_id": self.source_agent_id,
            "scope_id": self.scope_id,
            "goal": self.goal,
            "summary": self.summary,
            "source_session_active": self.source_session_active,
            "active_entities": [row.to_dict() for row in self.active_entities],
            "recent_queries": list(self.recent_queries),
            "supporting_decisions": [row.to_dict() for row in self.supporting_decisions],
            "open_loops": [row.to_dict() for row in self.open_loops],
            "rendered_text": self.rendered_text,
        }


@dataclass
class ContextTransferResult:
    pack: ContextPack
    target_session: Session
    transfer_note: str = ""

    def to_dict(self) -> dict:
        return {
            "pack": self.pack.to_dict(),
            "target_session": {
                "session_id": self.target_session.session_id,
                "agent_id": self.target_session.agent_id,
                "scope_id": self.target_session.scope_id,
                "parent_session_id": self.target_session.parent_session_id,
                "metadata": dict(self.target_session.metadata or {}),
            },
            "transfer_note": self.transfer_note,
        }
