"""Persisted maintenance-run models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class MaintenanceRunItem:
    """One open loop captured during a persisted maintenance run."""

    run_id: str
    kind: str
    severity: str
    title: str
    detail: str = ""
    target_id: Optional[str] = None
    entity_name: Optional[str] = None
    recommended_action: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "run_id": self.run_id,
            "kind": self.kind,
            "severity": self.severity,
            "title": self.title,
            "detail": self.detail,
            "target_id": self.target_id,
            "entity_name": self.entity_name,
            "recommended_action": self.recommended_action,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class MaintenanceRun:
    """A persisted copy of one maintenance execution."""

    grade: str
    score_value: float
    summary: str = ""
    metadata: dict = field(default_factory=dict)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: datetime = field(default_factory=datetime.now)
    items: list[MaintenanceRunItem] = field(default_factory=list)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "grade": self.grade,
            "score_value": self.score_value,
            "summary": self.summary,
            "metadata": dict(self.metadata),
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat(),
            "items": [item.to_dict() for item in self.items],
        }
