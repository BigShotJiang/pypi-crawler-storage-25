"""Snapshot / Time-Travel models.

A snapshot is a compressed point-in-time copy of the whole Engram database.
It captures entities, facts, relations, notes, sessions, debug state, intake
batches — everything the backup API can see. A manifest row in the live DB
tracks each snapshot's metadata so it can be listed, diffed, or reopened
without unpacking first.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §6.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Snapshot:
    """Manifest entry for a single point-in-time backup."""

    id: str
    label: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    schema_version: str = ""
    entity_count: int = 0
    fact_count: int = 0
    note_count: int = 0
    file_path: str = ""  # stored relative to the snapshots dir
    compressed_size: int = 0
    uncompressed_size: int = 0
    metadata: dict = field(default_factory=dict)

    @property
    def compression_ratio(self) -> float:
        if self.uncompressed_size <= 0:
            return 0.0
        return round(self.compressed_size / self.uncompressed_size, 3)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "label": self.label,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "schema_version": self.schema_version,
            "entity_count": self.entity_count,
            "fact_count": self.fact_count,
            "note_count": self.note_count,
            "file_path": self.file_path,
            "compressed_size": self.compressed_size,
            "uncompressed_size": self.uncompressed_size,
            "compression_ratio": self.compression_ratio,
            "metadata": dict(self.metadata),
        }

    def to_agent_context(self, max_chars: int = 1500) -> str:
        parts: list[str] = []
        parts.append(f"## Snapshot {self.id[:8]}")
        header = f"Created: {self.created_at.isoformat(timespec='seconds')}"
        if self.label:
            header += f" · Label: {self.label}"
        parts.append(header)
        if self.description:
            parts.append("")
            parts.append(self.description)
        parts.append("")
        parts.append(
            f"Entities: {self.entity_count} · Facts: {self.fact_count} · Notes: {self.note_count}"
        )
        parts.append(
            f"Size: {self.compressed_size:,} bytes (compressed) / "
            f"{self.uncompressed_size:,} bytes (raw) · ratio={self.compression_ratio:.2f}"
        )
        parts.append(f"Schema: v{self.schema_version}")
        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        return text


@dataclass
class SnapshotDiff:
    """Difference between two snapshots, in whole-entity terms.

    Fact-level changes are reported only as net counts because full
    fact-level diffs would explode in size for realistic workloads.
    ``modified_entities`` catches the cases where it matters: the entity is
    still there but something under it (state, aliases, or any of its
    facts) changed between the two snapshots.
    """

    snapshot_a: Snapshot
    snapshot_b: Snapshot
    entities_added: list[str] = field(default_factory=list)
    entities_removed: list[str] = field(default_factory=list)
    entities_modified: list[str] = field(default_factory=list)
    facts_delta: int = 0
    notes_delta: int = 0
    generated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "a": self.snapshot_a.to_dict(),
            "b": self.snapshot_b.to_dict(),
            "entities_added": list(self.entities_added),
            "entities_removed": list(self.entities_removed),
            "entities_modified": list(self.entities_modified),
            "facts_delta": self.facts_delta,
            "notes_delta": self.notes_delta,
            "generated_at": self.generated_at.isoformat(),
        }

    def to_agent_context(self, max_chars: int = 3000) -> str:
        parts: list[str] = []
        parts.append(
            f"## Snapshot diff: {self.snapshot_a.id[:8]} → {self.snapshot_b.id[:8]}"
        )
        parts.append(
            f"A: {self.snapshot_a.created_at.isoformat(timespec='seconds')}"
            f" ({self.snapshot_a.entity_count} entities / {self.snapshot_a.fact_count} facts)"
        )
        parts.append(
            f"B: {self.snapshot_b.created_at.isoformat(timespec='seconds')}"
            f" ({self.snapshot_b.entity_count} entities / {self.snapshot_b.fact_count} facts)"
        )
        parts.append("")
        parts.append(
            f"Net: facts_delta={self.facts_delta:+d} · notes_delta={self.notes_delta:+d}"
        )

        def _section(title: str, names: list[str]) -> None:
            if not names:
                return
            parts.append("")
            parts.append(f"### {title} ({len(names)})")
            for n in names[:50]:
                parts.append(f"- {n}")
            if len(names) > 50:
                parts.append(f"- … {len(names) - 50} more")

        _section("Entities added", self.entities_added)
        _section("Entities removed", self.entities_removed)
        _section("Entities modified", self.entities_modified)

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        return text
