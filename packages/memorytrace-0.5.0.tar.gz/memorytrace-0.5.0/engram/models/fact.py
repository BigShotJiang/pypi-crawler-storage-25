"""Fact data models with temporal dimension."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from engram.models.memory_type import MemoryType
from engram.models.source import Source
from engram.models.verification import VerificationStatus


class FactStatus(str, Enum):
    UNVERIFIED = "unverified"
    VERIFIED = "verified"
    CONFLICTED = "conflicted"
    EXPIRED = "expired"
    RETRACTED = "retracted"


def _normalize_tags(values: list[str] | tuple[str, ...] | None) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for value in values or []:
        tag = value.strip().lower()
        if not tag or tag in seen:
            continue
        normalized.append(tag)
        seen.add(tag)
    return normalized


@dataclass
class FactApplicability:
    """Structured usage constraints for a fact."""

    applies_if: list[str] = field(default_factory=list)
    except_if: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.applies_if = _normalize_tags(self.applies_if)
        self.except_if = _normalize_tags(self.except_if)

    def allows(self, context_tags: list[str] | tuple[str, ...] | None) -> bool:
        normalized_tags = set(_normalize_tags(context_tags))
        if not normalized_tags:
            return True
        if self.except_if and normalized_tags.intersection(self.except_if):
            return False
        if self.applies_if and not normalized_tags.intersection(self.applies_if):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "applies_if": list(self.applies_if),
            "except_if": list(self.except_if),
        }


@dataclass
class Fact:
    """A single piece of knowledge about an entity, with provenance and temporal bounds."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entity_id: str = ""
    subject: str = ""
    predicate: str = ""
    object: str = ""
    raw_text: str = ""
    source: Source = field(default_factory=Source)
    scope_id: Optional[str] = None
    confidence: float = 0.5
    status: FactStatus = FactStatus.UNVERIFIED
    verification_status: VerificationStatus = VerificationStatus.UNKNOWN
    last_verified_at: Optional[datetime] = None
    verification_due_at: Optional[datetime] = None
    memory_type: MemoryType = MemoryType.EPISODIC
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None  # None = currently valid
    applicability: FactApplicability = field(default_factory=FactApplicability)
    superseded_by: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, self.confidence))

    @property
    def is_current(self) -> bool:
        """Whether this fact is currently valid (not expired or superseded)."""
        if self.valid_to is not None:
            return False
        if self.superseded_by is not None:
            return False
        if self.status in (FactStatus.EXPIRED, FactStatus.RETRACTED):
            return False
        return True

    def supersede(self, new_fact_id: str) -> None:
        """Mark this fact as superseded by another."""
        self.superseded_by = new_fact_id
        self.valid_to = datetime.now()
        self.status = FactStatus.RETRACTED
