"""Retention policy and computed recommendation models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class RetentionTargetKind(str, Enum):
    ENTITY = "entity"
    FACT = "fact"
    DECISION = "decision"
    NOTE = "note"
    SESSION = "session"


class RetentionPolicyType(str, Enum):
    PIN = "pin"
    TTL = "ttl"
    ARCHIVE_ONLY = "archive_only"
    NEVER_SUMMARIZE = "never_summarize"


@dataclass
class RetentionPolicy:
    target_kind: RetentionTargetKind
    target_id: str
    policy_type: RetentionPolicyType
    value: Optional[str] = None
    reason: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "target_kind": self.target_kind.value,
            "target_id": self.target_id,
            "policy_type": self.policy_type.value,
            "value": self.value,
            "reason": self.reason,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


class RecommendationKind(str, Enum):
    STALE_DECISION = "stale_decision"
    OPEN_LOOP_ESCALATION = "open_loop_escalation"
    MERGE_RECOMMENDATION = "merge_recommendation"
    FOLLOW_UP_TASK = "follow_up_task"


class RecommendationSeverity(str, Enum):
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class RecommendationView:
    kind: RecommendationKind
    severity: RecommendationSeverity
    target_kind: str
    target_id: str
    title: str
    detail: str
    recommended_action: str
    evidence: list[dict] = field(default_factory=list)
    policy_conflicts: list[str] = field(default_factory=list)

    @property
    def id(self) -> str:
        return f"{self.kind.value}:{self.target_kind}:{self.target_id}"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "kind": self.kind.value,
            "severity": self.severity.value,
            "target_kind": self.target_kind,
            "target_id": self.target_id,
            "title": self.title,
            "detail": self.detail,
            "recommended_action": self.recommended_action,
            "evidence": list(self.evidence),
            "policy_conflicts": list(self.policy_conflicts),
        }
