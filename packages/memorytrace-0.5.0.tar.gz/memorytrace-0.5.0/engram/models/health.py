"""Health report data models — actionable diagnostics, not just counts.

A :class:`HealthReport` bundles metrics (percentages / counts with thresholds)
and open loops (concrete items the user should act on). It replaces the bare
counts returned by ``MemoryEngine.health_check()`` for callers that want an
operational view.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §2.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class HealthStatus(str, Enum):
    OK = "ok"
    WARN = "warn"
    CRIT = "crit"


class LoopSeverity(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


class LoopKind(str, Enum):
    CONFLICT = "conflict"
    STALE_FACT = "stale_fact"
    STALE_DECISION = "stale_decision"
    ORPHAN_ENTITY = "orphan_entity"
    MISSING_SOURCE = "missing_source"
    PROJECTION_DRIFT = "projection_drift"
    VERIFICATION_BACKLOG = "verification_backlog"
    ENTITY_GOVERNANCE = "entity_governance"


@dataclass
class HealthMetric:
    """A single measured quality signal."""

    name: str
    value: float
    unit: str  # "%", "count", ...
    status: HealthStatus = HealthStatus.OK
    threshold_warn: Optional[float] = None
    threshold_crit: Optional[float] = None
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "status": self.status.value,
            "threshold_warn": self.threshold_warn,
            "threshold_crit": self.threshold_crit,
            "description": self.description,
        }


@dataclass
class OpenLoop:
    """An actionable item surfaced by the diagnostics run."""

    kind: LoopKind
    severity: LoopSeverity
    title: str
    detail: str = ""
    target_id: Optional[str] = None  # conflict_id / entity_id / fact_id
    entity_name: Optional[str] = None
    recommended_action: Optional[str] = None
    created_at: Optional[datetime] = None

    def to_dict(self) -> dict:
        return {
            "kind": self.kind.value,
            "severity": self.severity.value,
            "title": self.title,
            "detail": self.detail,
            "target_id": self.target_id,
            "entity_name": self.entity_name,
            "recommended_action": self.recommended_action,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


@dataclass
class HealthReport:
    """Aggregated health signal: metrics + open loops + summary grade."""

    metrics: list[HealthMetric] = field(default_factory=list)
    open_loops: list[OpenLoop] = field(default_factory=list)
    score_value: float = 0.0  # 0–100
    grade: str = "D"  # A / B / C / D
    entity_count: int = 0
    fact_count: int = 0
    generated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "grade": self.grade,
            "score_value": self.score_value,
            "entity_count": self.entity_count,
            "fact_count": self.fact_count,
            "metrics": [m.to_dict() for m in self.metrics],
            "open_loops": [l.to_dict() for l in self.open_loops],
            "generated_at": self.generated_at.isoformat(),
        }

    def to_agent_context(self, max_loops: int = 10, max_chars: int = 4000) -> str:
        """Render a compact Markdown report."""
        parts: list[str] = []
        parts.append(f"## Engram Health: {self.grade} ({self.score_value:.1f}/100)")
        parts.append(
            f"Entities: {self.entity_count} · Facts: {self.fact_count}"
        )

        if self.metrics:
            parts.append("")
            parts.append("### Metrics")
            for m in self.metrics:
                marker = {"ok": "·", "warn": "!", "crit": "✕"}.get(m.status.value, "·")
                parts.append(
                    f"- {marker} {m.name}: {m.value:.1f}{m.unit} ({m.status.value})"
                )

        if self.open_loops:
            parts.append("")
            parts.append(f"### Open Loops ({len(self.open_loops)})")
            shown = self.open_loops[:max_loops]
            for l in shown:
                line = f"- [{l.severity.value}] {l.title}"
                if l.recommended_action:
                    line += f" → {l.recommended_action}"
                parts.append(line)
            if len(self.open_loops) > max_loops:
                parts.append(
                    f"- … {len(self.open_loops) - max_loops} more"
                )
        else:
            parts.append("")
            parts.append("### Open Loops")
            parts.append("- none")

        text = "\n".join(parts).strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        return text

    def loops_by_kind(self, kind: LoopKind) -> list[OpenLoop]:
        return [l for l in self.open_loops if l.kind == kind]
