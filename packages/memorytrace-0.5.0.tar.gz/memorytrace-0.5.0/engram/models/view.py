"""Read-only view wrappers that attach explanations."""

from __future__ import annotations

from dataclasses import dataclass, field

from engram.models.brief import RelatedEntity
from engram.models.decision import DecisionRecord
from engram.models.explanation import ExplanationBundle
from engram.models.maintenance import MaintenanceRun, MaintenanceRunItem
from engram.models.search import QueryPlan, SearchResult


@dataclass
class DecisionView:
    """Decision lookup payload with explanation."""

    decision: DecisionRecord
    explanation: ExplanationBundle

    def to_dict(self) -> dict:
        return {
            "decision": self.decision.to_dict(),
            "explanation": self.explanation.to_dict(),
        }


@dataclass
class MaintenanceItemView:
    """Maintenance item with explanation."""

    item: MaintenanceRunItem
    explanation: ExplanationBundle

    def to_dict(self) -> dict:
        return {
            "item": self.item.to_dict(),
            "explanation": self.explanation.to_dict(),
        }


@dataclass
class MaintenanceRunView:
    """Maintenance run view with explanation-rich items."""

    run: MaintenanceRun
    items: list[MaintenanceItemView] = field(default_factory=list)

    def to_dict(self) -> dict:
        run_payload = self.run.to_dict()
        run_payload.pop("items", None)
        return {
            "run": run_payload,
            "items": [item.to_dict() for item in self.items],
        }


@dataclass
class ContextSearchResult:
    """Composite result for base search plus conservative context expansion."""

    query: str
    goal: str
    base_result: SearchResult
    query_plan: QueryPlan | None = None
    related_entities: list[RelatedEntity] = field(default_factory=list)
    related_decisions: list[DecisionView] = field(default_factory=list)
    expansion_notes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "goal": self.goal,
            "base_result": self.base_result.to_dict(),
            "query_plan": self.query_plan.to_dict() if self.query_plan else None,
            "related_entities": [row.to_dict() for row in self.related_entities],
            "related_decisions": [row.to_dict() for row in self.related_decisions],
            "expansion_notes": list(self.expansion_notes),
            "warnings": list(self.warnings),
        }
