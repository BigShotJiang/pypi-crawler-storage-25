"""Reference projection models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ReferenceEdge:
    """A source-scoped entity mention used to power backlinks."""

    entity_id: str
    source_kind: str
    source_id: str
    snippet: str
    matched_text: str
    match_start: int
    match_end: int
    created_at: datetime = field(default_factory=datetime.now)
    indexed_at: datetime = field(default_factory=datetime.now)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "entity_id": self.entity_id,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "snippet": self.snippet,
            "matched_text": self.matched_text,
            "match_start": self.match_start,
            "match_end": self.match_end,
            "created_at": self.created_at.isoformat(),
            "indexed_at": self.indexed_at.isoformat(),
        }
