"""Relation model for directed entity graph edges."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Relation:
    """A directed relationship between two entities."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    from_entity_id: str = ""
    to_entity_id: str = ""
    relation_type: str = ""  # CEO_OF, INVESTED_IN, WORKS_WITH, MEMBER_OF, etc.
    metadata: dict = field(default_factory=dict)
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None  # None = currently valid
    created_at: datetime = field(default_factory=datetime.now)

    @property
    def is_current(self) -> bool:
        return self.valid_to is None
