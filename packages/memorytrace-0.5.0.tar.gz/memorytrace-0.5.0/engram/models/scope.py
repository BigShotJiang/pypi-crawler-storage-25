"""Scope models for namespace-aware memory selection."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class MemoryScope:
    """A named namespace that can own memory writes and reads."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    kind: str = "global"
    name: str = ""
    path: str = ""
    parent_scope_id: str | None = None
    status: str = "active"
    metadata: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


@dataclass
class ScopeSelection:
    """Read-time scope selection and fallback policy."""

    primary_scope_id: str | None = None
    include_ancestors: bool = False
    include_global: bool = True
    fallback_scope_ids: list[str] = field(default_factory=list)


@dataclass
class ResolvedScope:
    """Expanded scope IDs resolved from a selection."""

    primary_scope_id: str | None = None
    allowed_scope_ids: list[str] = field(default_factory=list)
