"""Entity governance data models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class GovernanceCandidateType(str, Enum):
    MERGE = "merge"
    ALIAS = "alias"
    SPLIT = "split"


class GovernanceCandidateStatus(str, Enum):
    OPEN = "open"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLIED = "applied"
    CANCELLED = "cancelled"


class GovernanceResolution(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"


@dataclass
class GovernanceCandidate:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    candidate_type: GovernanceCandidateType = GovernanceCandidateType.MERGE
    status: GovernanceCandidateStatus = GovernanceCandidateStatus.OPEN
    entity_id: str = ""
    related_entity_id: Optional[str] = None
    proposed_alias: Optional[str] = None
    score: float = 0.0
    fingerprint: str = ""
    rationale: str = ""
    details: dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "candidate_type": self.candidate_type.value,
            "status": self.status.value,
            "entity_id": self.entity_id,
            "related_entity_id": self.related_entity_id,
            "proposed_alias": self.proposed_alias,
            "score": self.score,
            "fingerprint": self.fingerprint,
            "rationale": self.rationale,
            "details": self.details,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }
