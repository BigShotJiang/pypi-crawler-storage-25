"""SnapshotService — create, list, diff, and query point-in-time backups.

Design notes
------------

* Backups use :py:meth:`sqlite3.Connection.backup`, which runs online and
  respects WAL mode. The source engine can keep serving queries during a
  backup; only short page-copy bursts block writers.
* Output is gzip-compressed (stdlib, zero extra deps). Level 6 is the
  default — good balance between speed and size for SQLite pages.
* The manifest lives in the main DB's ``snapshots`` table. The compressed
  bytes live on disk under ``<base_dir>/<snapshots_dir_name>/<id>.db.gz``.
  Manifest rows are authoritative; orphaned files are ignored.
* ``open_snapshot`` decompresses to a temp file, opens it read-only via
  ``file:...?mode=ro`` URI, yields the connection, and cleans up both the
  handle and the temp file on exit. On Windows the connection must close
  before the file can be unlinked — the context manager does that.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §6.
"""

from __future__ import annotations

import gzip
import json
import os
import shutil
import sqlite3
import tempfile
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional

from engram.models.snapshot import Snapshot, SnapshotDiff
from engram.safety.paths import ensure_safe_write_target
from engram.storage.sqlite_store import SQLiteStorage


_COMPRESSION_LEVEL = 6
_BACKUP_PAGES_PER_STEP = 64  # copy 64 pages at a time, yielding between steps


def _chmod_best_effort(path: Path, mode: int) -> None:
    """Apply POSIX mode bits, ignoring platforms (Windows, some FUSE mounts)
    that can't honour them. Matches :mod:`engram.storage.sqlite_store`'s
    hardening of the live DB."""
    try:
        os.chmod(path, mode)
    except OSError:
        pass


def _dt_to_str(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _str_to_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


class SnapshotService:
    """Manages the lifecycle of compressed point-in-time backups."""

    def __init__(self, storage: SQLiteStorage, snapshots_dir: Path) -> None:
        self.storage = storage
        self.snapshots_dir = Path(snapshots_dir)
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        # Snapshot files contain the whole DB — apply the same owner-only
        # hardening that SQLiteStorage uses on memory.db so a local
        # unprivileged user can't read the backups. Best-effort: Windows
        # and some filesystems ignore the mode bits.
        _chmod_best_effort(self.snapshots_dir, 0o700)

    # ── Create ──

    def create(
        self,
        label: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Snapshot:
        """Take a fresh snapshot of the live database."""
        snapshot_id = str(uuid.uuid4())
        relative_path = f"{snapshot_id}.db.gz"
        compressed_path = self.snapshots_dir / relative_path

        uncompressed_size = 0
        compressed_size = 0
        schema_version = self._read_schema_version()

        # 1. Dump the live DB into a temp file via the online backup API.
        tmp_fd, tmp_path_str = tempfile.mkstemp(
            prefix=f"engram-snap-{snapshot_id}-", suffix=".db"
        )
        os.close(tmp_fd)
        tmp_path = Path(tmp_path_str)
        dst_conn: Optional[sqlite3.Connection] = None
        try:
            dst_conn = sqlite3.connect(str(tmp_path))
            # pages=64 keeps each step short so the source can serve other
            # queries between steps.
            self.storage._conn.backup(dst_conn, pages=_BACKUP_PAGES_PER_STEP)
            dst_conn.close()
            dst_conn = None
            uncompressed_size = tmp_path.stat().st_size

            # 2. gzip-compress the dump into its final location.
            with open(tmp_path, "rb") as src_f, gzip.open(
                compressed_path, "wb", compresslevel=_COMPRESSION_LEVEL
            ) as dst_f:
                shutil.copyfileobj(src_f, dst_f)
            # Lock down the final file before it can be observed by other
            # users on the host. Doing this right after the gzip handle
            # closes avoids a window where the file is world-readable.
            _chmod_best_effort(compressed_path, 0o600)
            compressed_size = compressed_path.stat().st_size
        except Exception:
            # Clean up partial output on any failure.
            if dst_conn is not None:
                try:
                    dst_conn.close()
                except Exception:
                    pass
            try:
                if compressed_path.exists():
                    compressed_path.unlink()
            except OSError:
                pass
            raise
        finally:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass

        # 3. Count contents for display (cheap — just COUNT(*) queries).
        entity_count = self.storage.entity_count()
        fact_count = self.storage.fact_count()
        note_count = (
            self.storage.note_count()
            if hasattr(self.storage, "note_count")
            else 0
        )

        snapshot = Snapshot(
            id=snapshot_id,
            label=label,
            description=description,
            created_at=datetime.now(),
            schema_version=schema_version,
            entity_count=entity_count,
            fact_count=fact_count,
            note_count=note_count,
            file_path=relative_path,
            compressed_size=compressed_size,
            uncompressed_size=uncompressed_size,
            metadata=dict(metadata or {}),
        )
        self._persist_manifest(snapshot)
        return snapshot

    # ── Read ──

    def list(self, limit: int = 50) -> list[Snapshot]:
        rows = self.storage._conn.execute(
            """SELECT * FROM snapshots
               ORDER BY created_at DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        return [self._row_to_snapshot(r) for r in rows]

    def get(self, snapshot_id: str) -> Optional[Snapshot]:
        row = self.storage._conn.execute(
            "SELECT * FROM snapshots WHERE id = ?", (snapshot_id,)
        ).fetchone()
        return self._row_to_snapshot(row) if row else None

    # ── Delete ──

    def delete(self, snapshot_id: str) -> bool:
        snapshot = self.get(snapshot_id)
        if snapshot is None:
            return False
        try:
            full_path = self._resolve_snapshot_path(snapshot)
            if full_path.exists():
                full_path.unlink()
        except ValueError:
            # Path escapes snapshots_dir — refuse to touch the fs, but still
            # drop the manifest row so the poisoned entry is cleaned up.
            pass
        except OSError:
            # If we can't remove the file, still drop the manifest so the row
            # doesn't point at something we can't access. Orphan files are
            # harmless.
            pass
        self.storage._conn.execute(
            "DELETE FROM snapshots WHERE id = ?", (snapshot_id,)
        )
        self.storage._conn.commit()
        return True

    # ── Open / Restore ──

    @contextmanager
    def open_snapshot(self, snapshot_id: str) -> Iterator[sqlite3.Connection]:
        """Yield a read-only connection to a decompressed snapshot.

        The temp file is unlinked on exit. On Windows the OS doesn't let us
        delete an open file, so the connection is closed first.
        """
        snapshot = self.get(snapshot_id)
        if snapshot is None:
            raise ValueError(f"Snapshot {snapshot_id} not found")

        full_path = self._resolve_snapshot_path(snapshot)
        if not full_path.exists():
            raise FileNotFoundError(
                f"Snapshot file missing for {snapshot_id}: {full_path}"
            )

        tmp_fd, tmp_path_str = tempfile.mkstemp(
            prefix=f"engram-snap-open-{snapshot_id}-", suffix=".db"
        )
        os.close(tmp_fd)
        tmp_path = Path(tmp_path_str)

        conn: Optional[sqlite3.Connection] = None
        try:
            with gzip.open(full_path, "rb") as src_f, open(tmp_path, "wb") as dst_f:
                shutil.copyfileobj(src_f, dst_f)
            conn = sqlite3.connect(
                f"file:{tmp_path}?mode=ro", uri=True
            )
            conn.row_factory = sqlite3.Row
            yield conn
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass

    def restore(
        self,
        snapshot_id: str,
        target_path: Path,
        allow_unsafe_path: bool = False,
    ) -> Path:
        """Decompress a snapshot to ``target_path`` and return the path.

        Applies the same path-safety policy as ``intake --from-file`` so
        prompt-injected agents can't use restore as a "write arbitrary
        files" primitive (e.g. dropping bytes into ``~/.ssh/authorized_keys``
        or overwriting ``~/.bashrc``). The live DB is left untouched;
        restoring in-place is a manual step (swap files while Engram is
        closed).
        """
        snapshot = self.get(snapshot_id)
        if snapshot is None:
            raise ValueError(f"Snapshot {snapshot_id} not found")

        resolved_target = ensure_safe_write_target(
            str(target_path), allow_unsafe=allow_unsafe_path
        )

        resolved_target.parent.mkdir(parents=True, exist_ok=True)
        full_path = self._resolve_snapshot_path(snapshot)
        with gzip.open(full_path, "rb") as src_f, open(resolved_target, "wb") as dst_f:
            shutil.copyfileobj(src_f, dst_f)
        # A restored DB still contains everything — treat it like the live DB
        # and keep it owner-only by default.
        _chmod_best_effort(resolved_target, 0o600)
        return resolved_target

    # ── Diff ──

    def diff(self, a_id: str, b_id: str) -> SnapshotDiff:
        a = self.get(a_id)
        b = self.get(b_id)
        if a is None:
            raise ValueError(f"Snapshot {a_id} not found")
        if b is None:
            raise ValueError(f"Snapshot {b_id} not found")

        with self.open_snapshot(a_id) as conn_a, self.open_snapshot(
            b_id
        ) as conn_b:
            a_entities = self._entity_signatures(conn_a)
            b_entities = self._entity_signatures(conn_b)
            a_fact_total = self._scalar(conn_a, "SELECT COUNT(*) FROM facts")
            b_fact_total = self._scalar(conn_b, "SELECT COUNT(*) FROM facts")
            a_note_total = self._scalar_or_zero(conn_a, "SELECT COUNT(*) FROM notes")
            b_note_total = self._scalar_or_zero(conn_b, "SELECT COUNT(*) FROM notes")

        added_ids = set(b_entities) - set(a_entities)
        removed_ids = set(a_entities) - set(b_entities)
        common_ids = set(a_entities) & set(b_entities)
        modified_ids = [
            eid
            for eid in common_ids
            if a_entities[eid]["sig"] != b_entities[eid]["sig"]
        ]

        entities_added = sorted(b_entities[i]["name"] for i in added_ids)
        entities_removed = sorted(a_entities[i]["name"] for i in removed_ids)
        entities_modified = sorted(b_entities[i]["name"] for i in modified_ids)

        return SnapshotDiff(
            snapshot_a=a,
            snapshot_b=b,
            entities_added=entities_added,
            entities_removed=entities_removed,
            entities_modified=entities_modified,
            facts_delta=b_fact_total - a_fact_total,
            notes_delta=b_note_total - a_note_total,
            generated_at=datetime.now(),
        )

    # ── Historical queries ──

    def search_at(
        self,
        snapshot_id: str,
        query: str,
        limit: int = 10,
    ) -> list[dict]:
        """Run an FTS5 query against the snapshot as it existed then."""
        needle = self._escape_fts5(query)
        if not needle:
            return []
        with self.open_snapshot(snapshot_id) as conn:
            rows = conn.execute(
                """SELECT entity_id, entity_name, entity_type, summary,
                          bm25(memory_fts) AS rank
                   FROM memory_fts
                   WHERE memory_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (needle, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_entity_at(self, snapshot_id: str, name: str) -> Optional[dict]:
        """Return ``{entity, facts, relations}`` for ``name`` as of the snapshot.

        Resolves both the canonical ``name`` column and the ``aliases`` JSON
        list the same way :meth:`engram.storage.sqlite_store.SQLiteStorage.get_entity_by_name`
        does on the live DB — asymmetric behavior would surprise callers who
        switch between live and snapshot lookups.
        """
        with self.open_snapshot(snapshot_id) as conn:
            row = conn.execute(
                "SELECT * FROM entities WHERE name = ? COLLATE NOCASE",
                (name,),
            ).fetchone()
            if row is None:
                # Alias fallback: entities.aliases is a JSON array string. A
                # LIKE against the quoted form matches exact alias entries
                # without false-positives on substrings of other names.
                row = conn.execute(
                    "SELECT * FROM entities WHERE aliases LIKE ? COLLATE NOCASE",
                    (f'%"{name}"%',),
                ).fetchone()
            if row is None:
                return None
            entity_id = row["id"]
            entity_dict = dict(row)
            fact_rows = conn.execute(
                """SELECT id, predicate, object, raw_text, confidence, status, created_at
                   FROM facts
                   WHERE entity_id = ?
                     AND valid_to IS NULL AND superseded_by IS NULL
                     AND status NOT IN ('expired','retracted')
                   ORDER BY created_at DESC""",
                (entity_id,),
            ).fetchall()
            relation_rows = conn.execute(
                """SELECT id, from_entity_id, to_entity_id, relation_type
                   FROM relations
                   WHERE from_entity_id = ? OR to_entity_id = ?""",
                (entity_id, entity_id),
            ).fetchall()
            return {
                "entity": entity_dict,
                "facts": [dict(r) for r in fact_rows],
                "relations": [dict(r) for r in relation_rows],
            }

    # ── Internal helpers ──

    def _resolve_snapshot_path(self, snapshot: Snapshot) -> Path:
        """Compute the absolute path of a snapshot blob, refusing to leave
        ``snapshots_dir``.

        Even though we're the only writer of ``file_path`` today, a future
        manifest import / external tool could poison the column with a
        traversal string like ``../../etc/passwd``. Validating here means
        delete/open/restore never touch files outside the snapshots dir.
        """
        base = self.snapshots_dir.resolve()
        candidate = (self.snapshots_dir / snapshot.file_path).resolve()
        try:
            candidate.relative_to(base)
        except ValueError:
            raise ValueError(
                f"Snapshot {snapshot.id}: file_path '{snapshot.file_path}' "
                f"escapes snapshots dir {base}"
            )
        return candidate

    def _entity_signatures(self, conn: sqlite3.Connection) -> dict[str, dict]:
        """Build {entity_id: {name, sig}} where sig changes if anything
        meaningful about that entity changed (state / aliases / current
        facts)."""
        rows = conn.execute(
            """SELECT e.id AS id,
                      e.name AS name,
                      e.updated_at AS updated_at,
                      e.state AS state,
                      e.aliases AS aliases,
                      COUNT(f.id) AS cur_fact_count
               FROM entities e
               LEFT JOIN facts f
                 ON f.entity_id = e.id
                AND f.valid_to IS NULL
                AND f.superseded_by IS NULL
                AND f.status NOT IN ('expired','retracted')
               GROUP BY e.id, e.name, e.updated_at, e.state, e.aliases"""
        ).fetchall()
        out: dict[str, dict] = {}
        for r in rows:
            sig = (
                r["updated_at"] or "",
                r["state"] or "",
                r["aliases"] or "",
                r["cur_fact_count"] or 0,
            )
            out[r["id"]] = {"name": r["name"], "sig": sig}
        return out

    def _scalar(self, conn: sqlite3.Connection, sql: str) -> int:
        row = conn.execute(sql).fetchone()
        return int(row[0]) if row else 0

    def _scalar_or_zero(self, conn: sqlite3.Connection, sql: str) -> int:
        try:
            return self._scalar(conn, sql)
        except sqlite3.OperationalError:
            return 0

    def _escape_fts5(self, query: str) -> str:
        """Escape a user query for FTS5 using the shared tokenizer.

        Delegates to :func:`engram.search.tokenizer.build_fts5_query` so
        snapshot searches and live searches share the same escaping policy.
        """
        from engram.search.tokenizer import build_fts5_query
        result = build_fts5_query(query)
        return "" if result == '""' else result

    def _read_schema_version(self) -> str:
        try:
            row = self.storage._conn.execute(
                "SELECT value FROM _meta WHERE key = 'schema_version'"
            ).fetchone()
            return row[0] if row else ""
        except sqlite3.OperationalError:
            return ""

    def _persist_manifest(self, snapshot: Snapshot) -> None:
        self.storage._conn.execute(
            """INSERT INTO snapshots
                (id, label, description, created_at, schema_version,
                 entity_count, fact_count, note_count,
                 file_path, compressed_size, uncompressed_size, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                snapshot.id,
                snapshot.label,
                snapshot.description,
                _dt_to_str(snapshot.created_at),
                snapshot.schema_version,
                snapshot.entity_count,
                snapshot.fact_count,
                snapshot.note_count,
                snapshot.file_path,
                snapshot.compressed_size,
                snapshot.uncompressed_size,
                json.dumps(snapshot.metadata, ensure_ascii=False),
            ),
        )
        self.storage._conn.commit()

    def _row_to_snapshot(self, row) -> Snapshot:
        metadata_raw = row["metadata"] if "metadata" in row.keys() else "{}"
        try:
            metadata = json.loads(metadata_raw) if metadata_raw else {}
        except json.JSONDecodeError:
            metadata = {}
        return Snapshot(
            id=row["id"],
            label=row["label"],
            description=row["description"],
            created_at=_str_to_dt(row["created_at"]) or datetime.now(),
            schema_version=row["schema_version"] or "",
            entity_count=int(row["entity_count"] or 0),
            fact_count=int(row["fact_count"] or 0),
            note_count=int(row["note_count"] or 0),
            file_path=row["file_path"] or "",
            compressed_size=int(row["compressed_size"] or 0),
            uncompressed_size=int(row["uncompressed_size"] or 0),
            metadata=metadata,
        )
