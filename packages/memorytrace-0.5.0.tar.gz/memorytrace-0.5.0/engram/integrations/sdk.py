"""Programmatic Python SDK — clean wrapper around MemoryEngine.

Usage:
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    sdk.store("Simon Kim is the CEO of Hashed.")
    results = sdk.search("CEO")
    sdk.close()
"""

from __future__ import annotations

from typing import Optional

from engram.config import EngramConfig
from engram.engine import MemoryEngine, StoreResult
from engram.models.entity import Entity, Tier
from engram.models.quality import ValidationResult
from engram.models.search import SearchOptions, SearchResult
from engram.models.session import Session
from engram.models.source import Source, SourceType


class EngramSDK:
    """High-level SDK for programmatic access to Engram.

    Provides a clean API without CLI concerns.
    All methods return structured objects — no print().
    """

    def __init__(self, config: Optional[EngramConfig] = None):
        self.engine = MemoryEngine(config)
        self._current_session: Optional[Session] = None

    def close(self) -> None:
        try:
            if self._current_session:
                self.end_session()
        finally:
            self.engine.close()

    def __enter__(self) -> EngramSDK:
        return self

    def __exit__(self, *args) -> None:
        self.close()

    # ── Session ──

    def start_session(self, agent_id: str = "sdk") -> Session:
        self._current_session = self.engine.start_session(agent_id)
        return self._current_session

    def search_context(
        self,
        query: str,
        *,
        goal: str = "general",
        plan_query: bool = False,
        context_tags: Optional[list[str]] = None,
        max_results: int = 5,
        max_related: int = 10,
        max_tokens: int = 800,
    ):
        return self.engine.search_context(
            query,
            goal=goal,
            session_id=self.session_id,
            plan_query=plan_query,
            context_tags=context_tags,
            max_results=max_results,
            max_related=max_related,
            max_tokens=max_tokens,
        )

    def build_context_pack(
        self,
        *,
        session_id: str,
        goal: str = "task_handoff",
        max_chars: int = 4000,
    ):
        return self.engine.build_context_pack(
            session_id=session_id,
            goal=goal,
            max_chars=max_chars,
        )

    def transfer_context(
        self,
        *,
        from_session_id: str,
        to_agent_id: str,
        note: str = "",
        goal: str = "task_handoff",
        scope_selection=None,
    ):
        return self.engine.transfer_context(
            from_session_id=from_session_id,
            to_agent_id=to_agent_id,
            note=note,
            goal=goal,
            scope_selection=scope_selection,
        )

    def operations_review(
        self,
        *,
        run_jobs: bool = False,
        job_limit: int = 20,
    ):
        return self.engine.run_operations_review(
            run_jobs=run_jobs,
            job_limit=job_limit,
        )

    def end_session(self, summary: Optional[str] = None) -> Optional[Session]:
        if self._current_session:
            session = self.engine.end_session(self._current_session.session_id, summary)
            self._current_session = None
            return session
        return None

    @property
    def session_id(self) -> Optional[str]:
        return self._current_session.session_id if self._current_session else None

    # ── Store & Retrieve ──

    def store(
        self,
        text: str,
        source_type: str = "user_input",
        confidence: float = 1.0,
        author: str = "",
    ) -> StoreResult:
        source = Source(
            type=SourceType(source_type),
            confidence=confidence,
            author=author,
            channel="sdk",
        )
        return self.engine.store(text, source=source, session_id=self.session_id)

    def search(
        self,
        query: str,
        max_results: int = 10,
        max_tokens: int = 500,
        min_confidence: float = 0.0,
        context_tags: Optional[list[str]] = None,
    ) -> SearchResult:
        options = SearchOptions(
            query=query,
            max_results=max_results,
            max_tokens=max_tokens,
            min_confidence=min_confidence,
            context_tags=context_tags or [],
        )
        return self.engine.search(query, options, session_id=self.session_id)

    def build_query_plan(self, query: str):
        return self.engine.build_query_plan(query)

    def get_entity(self, name: str) -> Optional[Entity]:
        return self.engine.get_entity(name, session_id=self.session_id)

    def get_facts(self, entity_name: str) -> list:
        return self.engine.get_facts(entity_name, session_id=self.session_id)

    def add_fact(
        self,
        entity_name: str,
        fact_text: str,
        predicate: str = "attribute",
        source_type: str = "user_input",
        confidence: float = 1.0,
        applies_if: Optional[list[str]] = None,
        except_if: Optional[list[str]] = None,
    ) -> ValidationResult:
        source = Source(type=SourceType(source_type), confidence=confidence, channel="sdk")
        return self.engine.add_fact(
            entity_name, fact_text, predicate=predicate,
            source=source, session_id=self.session_id,
            applies_if=applies_if,
            except_if=except_if,
        )

    def create_entity(
        self,
        name: str,
        entity_type: str = "person",
        tier: str = "recall",
        summary: str = "",
    ) -> Entity:
        return self.engine.create_entity(name, entity_type, Tier(tier), summary)

    def list_entities(self, entity_type: str = "", tier: str = "", limit: int = 100) -> list[Entity]:
        return self.engine.list_entities(
            tier=Tier(tier) if tier else None,
            entity_type=entity_type or None,
            limit=limit,
        )

    # ── Context ──

    def get_context(self, agent_id: str = "sdk") -> dict:
        return self.engine.get_session_context(agent_id)

    def health(self) -> dict:
        return self.engine.health_check()

    # ── Tool Schemas (for OpenAI function calling) ──

    @staticmethod
    def get_tool_schemas() -> list[dict]:
        """Return OpenAI-format function calling schemas for all tools."""
        return [
            {
                "type": "function",
                "function": {
                    "name": "memory_search",
                    "description": "Search persistent memory for relevant context",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query"},
                            "max_results": {"type": "integer", "default": 5},
                            "max_tokens": {"type": "integer", "default": 500},
                            "context_tags": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Optional applicability tags used to filter facts",
                            },
                            "session_id": {"type": "string", "description": "Optional session ID for tracking"},
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_store",
                    "description": "Store new factual information in memory",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "Content to store"},
                            "source_type": {"type": "string", "default": "agent_inference"},
                            "confidence": {"type": "number", "default": 0.7},
                            "session_id": {"type": "string", "description": "Optional session ID for tracking"},
                        },
                        "required": ["content"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_get_entity",
                    "description": "Get all info about a specific entity",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Entity name"},
                            "session_id": {"type": "string", "description": "Optional session ID for tracking"},
                        },
                        "required": ["name"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_query_plan",
                    "description": "Build an Engram query plan for a compound memory lookup",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Compound search query"},
                        },
                        "required": ["query"],
                    },
                },
            },
        ]
