"""MCP server for Engram — Claude Code / Codex integration.

Requires: pip install memorytrace[mcp]

Usage:
    python -m engram.integrations.mcp_server

    Or via CLI:
    engram serve
"""

from __future__ import annotations

import atexit
import json
import sys
from typing import Optional

from engram.engine import MemoryEngine
from engram.models.search import SearchOptions
from engram.models.scope import ScopeSelection
from engram.models.source import Source, SourceType

# Lazy engine instance (created on first tool call)
_engine: Optional[MemoryEngine] = None


def _get_engine() -> MemoryEngine:
    global _engine
    if _engine is None:
        _engine = MemoryEngine()
        atexit.register(_engine.close)
    return _engine


def _safe_source_type(value: str) -> SourceType:
    """Parse source type string, falling back to agent_inference."""
    try:
        return SourceType(value)
    except ValueError:
        return SourceType.AGENT_INFERENCE


def run_server(transport: str = "stdio", port: int = 8080) -> None:
    """Start the MCP server."""
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
    except ImportError:
        print("MCP package not installed. Run: pip install memorytrace[mcp]", file=sys.stderr)
        sys.exit(1)

    app = Server("engram")

    @app.tool()
    async def memory_search(
        query: str,
        max_results: int = 5,
        max_tokens: int = 500,
        min_confidence: float = 0.0,
        context_tags: list[str] | None = None,
        session_id: str = "",
    ) -> str:
        """Search persistent memory for relevant context about people, organizations, or past decisions.

        Use when the user mentions someone/something discussed before,
        or references "last time", "before", "we discussed".

        Args:
            query: Natural language search query
            max_results: Maximum entities to return
            max_tokens: Token budget for response
            min_confidence: Minimum fact confidence (0.0-1.0)
            context_tags: Optional applicability tags that facts must satisfy
            session_id: Optional session ID for working memory boost
        """
        engine = _get_engine()
        options = SearchOptions(
            query=query,
            max_results=max_results,
            max_tokens=max_tokens,
            min_confidence=min_confidence,
            context_tags=context_tags or [],
        )
        result = engine.search(query, options, session_id=session_id or None)
        return result.to_agent_context(max_tokens=max_tokens)

    @app.tool()
    async def memory_context_search(
        query: str,
        goal: str = "general",
        plan_query: bool = False,
        context_tags: list[str] | None = None,
        max_results: int = 5,
        max_related: int = 10,
        max_tokens: int = 800,
        session_id: str = "",
    ) -> str:
        """Search memory plus related context for a goal-oriented lookup or handoff.

        Returns the base search result along with typed relation and decision expansions.

        Args:
            query: Natural language search query
            goal: Retrieval goal such as general, task_handoff, or debugging
            plan_query: Whether to build an Engram query plan for compound lookups
            context_tags: Optional applicability tags used to filter facts
            max_results: Maximum base hits to return
            max_related: Maximum expanded related items to include
            max_tokens: Token budget across the base result and expansions
            session_id: Optional session ID for working-memory aware reranking
        """
        engine = _get_engine()
        result = engine.search_context(
            query,
            goal=goal,
            plan_query=plan_query,
            context_tags=context_tags,
            session_id=session_id or None,
            max_results=max_results,
            max_related=max_related,
            max_tokens=max_tokens,
        )
        return json.dumps(result.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_query_plan(query: str) -> str:
        """Build an Engram query plan for a compound memory lookup."""
        engine = _get_engine()
        plan = engine.build_query_plan(query)
        return json.dumps(plan.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_context_pack(
        session_id: str,
        goal: str = "task_handoff",
        max_chars: int = 4000,
    ) -> str:
        """Build a reusable, masked context pack from one source session.

        Packages the session summary, active entities, recent queries (PII-masked),
        supporting decisions, and relevant open loops into a single transferable object.

        Args:
            session_id: Source session to package (active or ended)
            goal: Retrieval goal that shapes decision selection (e.g. task_handoff)
            max_chars: Maximum character length for the rendered text section
        """
        engine = _get_engine()
        pack = engine.build_context_pack(
            session_id=session_id,
            goal=goal,
            max_chars=max_chars,
        )
        return json.dumps(pack.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_context_transfer(
        from_session_id: str,
        to_agent_id: str,
        note: str = "",
        goal: str = "task_handoff",
        scope_id: str = "",
    ) -> str:
        """Transfer context from a source session to a new target-agent session.

        Builds a context pack, opens a fresh session for the target agent, seeds its
        working memory, and logs auditable transfer events on both sides.  Scope can
        only be narrowed, never widened beyond the source session lineage.

        Args:
            from_session_id: Source session to transfer from
            to_agent_id: Agent that will receive the new session
            note: Free-text handoff note (PII-masked before storage)
            goal: Retrieval goal for the context pack
            scope_id: Optional scope override (must be within source lineage)
        """
        engine = _get_engine()
        result = engine.transfer_context(
            from_session_id=from_session_id,
            to_agent_id=to_agent_id,
            note=note,
            goal=goal,
            scope_selection=(
                ScopeSelection(
                    primary_scope_id=scope_id,
                    include_ancestors=False,
                    include_global=False,
                )
                if scope_id
                else None
            ),
        )
        return json.dumps(result.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_operations_review(
        run_jobs: bool = False,
        job_limit: int = 20,
    ) -> str:
        """Run a composite operations review: health report, maintenance, drift, and recommendations.

        Always persists a maintenance run (write side-effect).  Optionally executes
        queued background jobs.  Returns a single summary covering system health,
        projection drift, and actionable recommendations.

        Args:
            run_jobs: Whether to lease and execute queued jobs during this review
            job_limit: Maximum number of jobs to execute when run_jobs is True
        """
        engine = _get_engine()
        review = engine.run_operations_review(
            run_jobs=run_jobs,
            job_limit=job_limit,
        )
        return json.dumps(review.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_store(
        content: str,
        source_type: str = "agent_inference",
        confidence: float = 0.7,
        session_id: str = "",
    ) -> str:
        """Store new factual information in persistent memory.

        Use when new facts about people/orgs/projects are shared.
        Do NOT store: greetings, opinions, or speculative statements.

        Args:
            content: Factual content to store
            source_type: One of: direct_speech, document, api, web, agent_inference, user_input
            confidence: How confident (0.0-1.0)
            session_id: Optional session ID for tracking modifications
        """
        engine = _get_engine()
        source = Source(
            type=_safe_source_type(source_type),
            confidence=confidence,
            channel="mcp",
        )
        result = engine.store(content, source=source, session_id=session_id or None)
        return json.dumps(result.to_dict(), ensure_ascii=False)

    @app.tool()
    async def memory_get_entity(name: str, session_id: str = "") -> str:
        """Get all known information about a specific entity.

        Args:
            name: Entity name to look up
            session_id: Optional session ID for access tracking
        """
        engine = _get_engine()
        entity = engine.get_entity(name, session_id=session_id or None)
        if not entity:
            return f"No entity found with name '{name}'."
        facts = engine.get_facts(name)
        lines = [
            f"Name: {entity.name}",
            f"Type: {entity.entity_type}",
            f"Tier: {entity.tier.value}",
        ]
        if entity.summary:
            lines.append(f"Summary: {entity.summary}")
        if entity.state.role:
            lines.append(f"Role: {entity.state.role}")
        if entity.state.affiliation:
            lines.append(f"Affiliation: {entity.state.affiliation}")
        if facts:
            lines.append(f"Facts ({len(facts)}):")
            for f in facts[:10]:
                lines.append(f"  - {f.raw_text} [{f.confidence:.0%}]")
        return "\n".join(lines)

    @app.tool()
    async def memory_list_entities(
        entity_type: str = "",
        tier: str = "",
        limit: int = 20,
    ) -> str:
        """List known entities with optional filters.

        Args:
            entity_type: Filter by type (person, organization, project, concept)
            tier: Filter by tier (core, recall, archival)
            limit: Max entries to return
        """
        engine = _get_engine()
        from engram.models.entity import Tier
        entities = engine.list_entities(
            tier=Tier(tier) if tier else None,
            entity_type=entity_type or None,
            limit=limit,
        )
        if not entities:
            return "No entities found."
        lines = []
        for e in entities:
            lines.append(f"- {e.name} ({e.entity_type}, {e.tier.value})")
        return "\n".join(lines)

    @app.tool()
    async def memory_session_start(agent_id: str = "claude-code") -> str:
        """Start a new memory session. Call at the beginning of a conversation.

        Args:
            agent_id: Identifier for the calling agent
        """
        engine = _get_engine()
        session = engine.start_session(agent_id)
        context = engine.get_session_context(agent_id)
        return json.dumps({
            "session_id": session.session_id,
            "entity_count": context["entity_count"],
            "previous_summary": context.get("previous_summary", ""),
        }, ensure_ascii=False)

    @app.tool()
    async def memory_session_end(session_id: str, summary: str = "") -> str:
        """End the current memory session.

        Args:
            session_id: Session ID to end
            summary: Brief summary of what was discussed
        """
        engine = _get_engine()
        session = engine.end_session(session_id, summary=summary or None)
        return f"Session ended. Duration: {session.duration_minutes or 0}min."

    @app.tool()
    async def memory_resolve_conflict(conflict_id: str, resolution: str) -> str:
        """Resolve a data conflict in memory.

        Args:
            conflict_id: Conflict ID to resolve
            resolution: One of: accept_new, keep_old, merge
        """
        engine = _get_engine()
        engine.resolve_conflict(conflict_id, resolution)
        return f"Conflict {conflict_id[:8]} resolved: {resolution}"

    # Run server
    if transport == "stdio":
        import asyncio
        asyncio.run(stdio_server(app))
    else:
        print(f"Transport '{transport}' not yet supported.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    run_server()
