"""Quality gate — pipeline orchestrator for write validation."""

from __future__ import annotations

from datetime import datetime

from engram.config import EngramConfig
from engram.models.fact import Fact, FactStatus
from engram.models.memory_type import MemoryType, classify_fact
from engram.models.quality import Action, ConflictInfo, ValidationResult
from engram.quality.confidence import compute_confidence
from engram.quality.conflict import ConflictDetector
from engram.quality.pii import PIIDetector
from engram.storage.base import StorageBackend


class QualityGate:
    """Pipeline: confidence → PII masking → conflict detection → accept/reject/quarantine.

    Every write operation passes through this gate before reaching storage.
    """

    def __init__(self, config: EngramConfig, storage: StorageBackend):
        self.config = config
        self.storage = storage
        self.conflict_detector = ConflictDetector(storage, auto_resolve_threshold=config.auto_resolve_threshold)
        self.pii_detector = PIIDetector()
        self.min_confidence = config.min_confidence
        self.auto_resolve_threshold = config.auto_resolve_threshold
        self.enable_pii = config.enable_pii_detection

    def validate(
        self,
        fact: Fact,
        extraction_method: str = "manual",
    ) -> ValidationResult:
        """Run the full quality gate pipeline on a fact.

        Returns ValidationResult with action:
        - ACCEPT: fact is good, store it
        - QUARANTINE: low confidence, store as unverified
        - FLAG_CONFLICT: conflicts with existing data
        - REJECT: should not be stored (e.g., all PII with no substance)
        """

        # Step 1: Compute confidence
        computed_conf = compute_confidence(
            source_type=fact.source.type,
            source_confidence=fact.source.confidence,
            extraction_method=extraction_method,
        )
        fact.confidence = computed_conf

        # Step 1.5: Auto-classify memory_type when the caller left the default.
        # Explicit assignments by the caller are respected.
        if fact.memory_type == MemoryType.EPISODIC:
            fact.memory_type = classify_fact(fact.predicate, fact.raw_text)

        # Step 2: PII detection and masking
        pii_matches = []
        masked_text = None
        if self.enable_pii and fact.raw_text:
            pii_matches = self.pii_detector.scan(fact.raw_text)
            if pii_matches:
                masked_text = self.pii_detector.mask(fact.raw_text, pii_matches)
                fact.raw_text = masked_text
                # Also mask subject/object if they contain PII
                if self.pii_detector.has_pii(fact.object):
                    fact.object = self.pii_detector.mask(fact.object)
                if self.pii_detector.has_pii(fact.subject):
                    fact.subject = self.pii_detector.mask(fact.subject)

        # Step 3: Confidence threshold check
        if computed_conf < self.min_confidence:
            fact.status = FactStatus.UNVERIFIED
            return ValidationResult(
                action=Action.QUARANTINE,
                reason=f"Confidence {computed_conf:.2f} below threshold {self.min_confidence:.2f}",
                confidence=computed_conf,
                pii_matches=pii_matches,
                masked_text=masked_text,
            )

        # Load current facts once for both duplicate and conflict checks.
        existing_facts = (
            self.storage.get_current_facts(fact.entity_id) if fact.entity_id else None
        )

        # Step 3.5: Duplicate detection
        if fact.entity_id and self.conflict_detector.is_duplicate(fact, existing=existing_facts):
            return ValidationResult(
                action=Action.REJECT,
                reason="Duplicate fact already exists",
                confidence=computed_conf,
                pii_matches=pii_matches,
                masked_text=masked_text,
            )

        # Step 4: Conflict detection
        if fact.entity_id:
            conflicts = self.conflict_detector.find_conflicts(fact, existing=existing_facts)
            if conflicts:
                # Check if we can auto-resolve
                auto_resolved_facts = self._try_auto_resolve(conflicts)
                if auto_resolved_facts is None:
                    fact.status = FactStatus.CONFLICTED
                    return ValidationResult(
                        action=Action.FLAG_CONFLICT,
                        reason=f"Conflicts with {len(conflicts)} existing fact(s)",
                        confidence=computed_conf,
                        conflicts=conflicts,
                        pii_matches=pii_matches,
                        masked_text=masked_text,
                    )

                # Auto-resolved: return pending retractions for caller to apply after storing
                return ValidationResult(
                    action=Action.ACCEPT,
                    reason="Passed all quality checks (auto-resolved conflicts)",
                    confidence=computed_conf,
                    pii_matches=pii_matches,
                    masked_text=masked_text,
                    auto_resolved_facts=auto_resolved_facts,
                )

        # Step 5: Accept
        return ValidationResult(
            action=Action.ACCEPT,
            reason="Passed all quality checks",
            confidence=computed_conf,
            pii_matches=pii_matches,
            masked_text=masked_text,
        )

    def _try_auto_resolve(self, conflicts: list[ConflictInfo]) -> list[Fact] | None:
        """Attempt to auto-resolve conflicts if trust difference is large enough.

        Returns a list of facts with in-memory retraction changes applied
        (status=RETRACTED, superseded_by, valid_to) for the caller to persist
        AFTER successfully storing the new fact. Returns None if not all
        conflicts could be auto-resolved.
        """
        pending_retractions: list[Fact] = []
        for conflict in conflicts:
            if conflict.suggested_resolution == "supersede":
                # Mutate in-memory only — caller will persist after storing new fact
                old_fact = conflict.existing_fact
                old_fact.status = FactStatus.RETRACTED
                old_fact.superseded_by = conflict.new_fact.id
                old_fact.valid_to = datetime.now()
                pending_retractions.append(old_fact)
            else:
                return None
        return pending_retractions
