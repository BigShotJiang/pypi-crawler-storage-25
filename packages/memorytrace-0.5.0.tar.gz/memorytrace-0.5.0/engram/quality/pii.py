"""PII (Personally Identifiable Information) detection and masking."""

from __future__ import annotations

import re
from typing import Optional

from engram.models.quality import PIIMatch

# PII detection patterns
_PII_PATTERNS: dict[str, re.Pattern] = {
    "credit_card": re.compile(
        r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'
    ),
    "ssn": re.compile(
        r'\b\d{3}-\d{2}-\d{4}\b'
    ),
    "api_key": re.compile(
        r'\b(?:sk-|ak-|AKIA|ghp_|gho_|github_pat_)[A-Za-z0-9_\-]{20,}\b'
    ),
    "email": re.compile(
        r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'
    ),
    "phone_kr": re.compile(
        r'\b0\d{1,2}-\d{3,4}-\d{4}\b'
    ),
    "phone_intl": re.compile(
        r'\+\d{1,3}[-\s]?\d{1,4}[-\s]?\d{3,4}[-\s]?\d{4}\b'
    ),
    "rrn": re.compile(
        # Korean Resident Registration Number (주민등록번호)
        r'\b\d{6}[-\s]?[1-4]\d{6}\b'
    ),
}

_REDACTED = "[REDACTED]"


def _luhn_check(digits: str) -> bool:
    """Validate a digit string using the Luhn algorithm."""
    if not digits or not digits.isdigit():
        return False
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def mask_if_needed(
    detector: Optional["PIIDetector"],
    text: Optional[str],
    enabled: bool = True,
) -> Optional[str]:
    """Return ``text`` with PII replaced when a detector is available.

    Cheap no-op when ``text`` is empty, the feature is disabled, or no
    detector is configured. Designed to be called from any write-sink
    (engine, intake, debug, session events) that needs the same policy as
    :class:`engram.quality.gate.QualityGate` without re-implementing the
    scan-then-mask dance three times.
    """
    if not text or not enabled or detector is None:
        return text
    matches = detector.scan(text)
    if not matches:
        return text
    return detector.mask(text, matches)


class PIIDetector:
    """Detects and masks PII in text."""

    def scan(self, text: str) -> list[PIIMatch]:
        """Scan text for PII patterns. Returns list of matches."""
        matches: list[PIIMatch] = []
        for pii_type, pattern in _PII_PATTERNS.items():
            for m in pattern.finditer(text):
                # Validate credit card candidates with the Luhn algorithm
                # to avoid masking arbitrary 16-digit numbers.
                if pii_type == "credit_card":
                    digits = re.sub(r'[\s\-]', '', m.group())
                    if not _luhn_check(digits):
                        continue
                # Store only type and length, not the original PII value
                original_display = f"[{pii_type}:{len(m.group())}chars]"
                matches.append(PIIMatch(
                    pii_type=pii_type,
                    start=m.start(),
                    end=m.end(),
                    original=original_display,
                ))
        # Sort by position (reverse for safe replacement)
        matches.sort(key=lambda x: x.start)
        return matches

    def mask(self, text: str, matches: Optional[list[PIIMatch]] = None) -> str:
        """Replace PII occurrences with [REDACTED].

        If matches not provided, scans first.
        """
        if matches is None:
            matches = self.scan(text)
        if not matches:
            return text

        # Replace from end to start to preserve positions
        result = text
        for m in sorted(matches, key=lambda x: x.start, reverse=True):
            result = result[:m.start] + _REDACTED + result[m.end:]
        return result

    def has_pii(self, text: str) -> bool:
        """Quick check: does text contain any PII?"""
        for pattern in _PII_PATTERNS.values():
            if pattern.search(text):
                return True
        return False
