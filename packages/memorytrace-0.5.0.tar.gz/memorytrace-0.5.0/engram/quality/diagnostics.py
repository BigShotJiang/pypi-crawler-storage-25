"""Diagnostics — turn raw DB state into actionable metrics and open loops.

Pure, read-only over the storage backend. No side effects, no mutations.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §2.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from engram.config import EngramConfig
from engram.models.fact import FactStatus
from engram.models.governance import GovernanceCandidateStatus
from engram.models.verification import VerificationRequestStatus, VerificationStatus
from engram.models.health import (
    HealthMetric,
    HealthReport,
    HealthStatus,
    LoopKind,
    LoopSeverity,
    OpenLoop,
)
from engram.decisions.service import DecisionService
from engram.references.service import ReferenceService
from engram.storage.base import StorageBackend


# Status weights for the aggregate score: ok = 1.0, warn = 0.5, crit = 0.0.
_STATUS_WEIGHT = {
    HealthStatus.OK: 1.0,
    HealthStatus.WARN: 0.5,
    HealthStatus.CRIT: 0.0,
}


def _grade_from_score(score: float) -> str:
    if score >= 90:
        return "A"
    if score >= 75:
        return "B"
    if score >= 60:
        return "C"
    return "D"


class Diagnostics:
    """Builds :class:`HealthReport` instances from storage state."""

    def __init__(
        self,
        storage: StorageBackend,
        config: Optional[EngramConfig] = None,
    ) -> None:
        self.storage = storage
        self.config = config or EngramConfig()

    def run(
        self,
        max_open_loops: int = 50,
        stale_days: Optional[int] = None,
    ) -> HealthReport:
        """Compute metrics, open loops, and a grade.

        ``max_open_loops`` caps how many loops the report carries; the raw
        counts still feed the metrics so the grade isn't distorted.

        ``stale_days`` overrides :attr:`EngramConfig.decay_days` for the
        stale-fact check.
        """
        stale_days = stale_days if stale_days is not None else self.config.decay_days

        entity_count = self.storage.entity_count()
        fact_count = self.storage.fact_count()
        pending = self.storage.get_pending_conflicts()

        metrics: list[HealthMetric] = []
        loops: list[OpenLoop] = []

        # ── Metric 1: pending conflicts ──
        conflict_metric, conflict_loops = self._pending_conflicts(
            pending, max_loops=max_open_loops
        )
        metrics.append(conflict_metric)
        loops.extend(conflict_loops)

        # ── Metric 2 & 3: source coverage + missing-source loops ──
        source_metric, missing_source_loops = self._source_coverage(
            max_loops=max_open_loops
        )
        metrics.append(source_metric)
        loops.extend(missing_source_loops)

        # ── Metric 4: stale facts ──
        stale_metric, stale_loops = self._stale_facts(
            stale_days=stale_days, max_loops=max_open_loops
        )
        metrics.append(stale_metric)
        loops.extend(stale_loops)

        # ── Metric 5: orphan entities ──
        verification_metric, verification_loops = self._verification_backlog(
            max_loops=max_open_loops
        )
        metrics.append(verification_metric)
        loops.extend(verification_loops)

        stale_decision_metric, stale_decision_loops = self._stale_decisions(
            max_loops=max_open_loops
        )
        metrics.append(stale_decision_metric)
        loops.extend(stale_decision_loops)

        governance_metric, governance_loops = self._entity_governance(
            max_loops=max_open_loops
        )
        metrics.append(governance_metric)
        loops.extend(governance_loops)

        orphan_metric, orphan_loops = self._orphan_entities(
            entity_count=entity_count, max_loops=max_open_loops
        )
        metrics.append(orphan_metric)
        loops.extend(orphan_loops)

        # Metric 6: projection drift
        projection_metric, projection_loops = self._projection_drift(
            max_loops=max_open_loops
        )
        metrics.append(projection_metric)
        loops.extend(projection_loops)

        score_value = self._compute_score(metrics)
        grade = _grade_from_score(score_value)

        # Sort loops: critical first, then warning, then info.
        severity_order = {
            LoopSeverity.CRITICAL: 0,
            LoopSeverity.WARNING: 1,
            LoopSeverity.INFO: 2,
        }
        loops.sort(key=lambda l: severity_order[l.severity])

        if len(loops) > max_open_loops:
            loops = loops[:max_open_loops]

        return HealthReport(
            metrics=metrics,
            open_loops=loops,
            score_value=score_value,
            grade=grade,
            entity_count=entity_count,
            fact_count=fact_count,
            generated_at=datetime.now(),
        )

    # ── Individual checks ──

    def _pending_conflicts(
        self, pending: list[dict], max_loops: int
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        count = len(pending)
        if count == 0:
            status = HealthStatus.OK
        elif count <= 3:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="pending_conflicts",
            value=float(count),
            unit="count",
            status=status,
            threshold_warn=1,
            threshold_crit=4,
            description="Facts with unresolved contradictions.",
        )

        loops: list[OpenLoop] = []
        for c in pending[:max_loops]:
            cid = c.get("id", "")
            conflict_type = c.get("conflict_type", "conflict")
            created_at_raw = c.get("created_at")
            try:
                created_at = (
                    datetime.fromisoformat(created_at_raw)
                    if created_at_raw
                    else None
                )
            except (TypeError, ValueError):
                created_at = None
            severity = LoopSeverity.CRITICAL if count >= 4 else LoopSeverity.WARNING
            loops.append(
                OpenLoop(
                    kind=LoopKind.CONFLICT,
                    severity=severity,
                    title=f"Unresolved {conflict_type}",
                    detail=c.get("suggested_resolution") or "",
                    target_id=cid,
                    recommended_action=f"engram-advanced resolve {cid} <accept_new|keep_old|merge>",
                    created_at=created_at,
                )
            )
        return metric, loops

    def _projection_drift(
        self,
        max_loops: int,
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            metric = HealthMetric(
                name="projection_drift",
                value=0.0,
                unit="count",
                status=HealthStatus.OK,
                description="Storage backend does not expose SQL; projection drift skipped.",
            )
            return metric, []

        reference_service = ReferenceService(self.storage)  # type: ignore[arg-type]
        decision_service = DecisionService(self.storage, reference_service=reference_service)  # type: ignore[arg-type]
        job_loops: list[dict] = []
        for status in ("failed", "dead_letter", "queued", "running"):
            remaining = max_loops - len(job_loops)
            if remaining <= 0:
                break
            for job in self.storage.list_jobs(status=status, limit=remaining):  # type: ignore[attr-defined]
                prefix = "Failed job" if status in {"failed", "dead_letter"} else "Queued job"
                detail = job.last_error or "Background work is still pending."
                job_loops.append(
                    {
                        "title": f"{prefix}: {job.job_type}",
                        "detail": detail,
                        "source_kind": "job",
                        "source_id": job.id,
                        "severity": (
                            LoopSeverity.CRITICAL
                            if status == "dead_letter"
                            else LoopSeverity.WARNING
                        ),
                    }
                )

        drifts = [
            *reference_service.projection_drift(limit=max_loops),
            *decision_service.projection_drift(limit=max_loops),
            *job_loops,
        ][:max_loops]

        count = len(drifts)
        if count == 0:
            status = HealthStatus.OK
        elif count <= 3:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="projection_drift",
            value=float(count),
            unit="count",
            status=status,
            threshold_warn=1,
            threshold_crit=4,
            description="Sources that appear indexable but have missing projection rows.",
        )
        loops = [
            OpenLoop(
                kind=LoopKind.PROJECTION_DRIFT,
                severity=drift.get(
                    "severity",
                    LoopSeverity.WARNING if count <= 3 else LoopSeverity.CRITICAL,
                ),
                title=drift["title"],
                detail=drift["detail"],
                target_id=f"{drift['source_kind']}:{drift['source_id']}",
                recommended_action="Run engram-advanced rebuild-projections",
            )
            for drift in drifts
        ]
        return metric, loops

    def _source_coverage(
        self, max_loops: int
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        """Compute % of current facts that carry a meaningful source attribution.

        A fact counts as attributed if it has a non-empty source_author OR a
        source_channel other than the bare CLI channel. Other channels (web,
        api, document, agent_inference) are considered attributed even when
        the author is blank.
        """
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            metric = HealthMetric(
                name="source_coverage",
                value=0.0,
                unit="%",
                status=HealthStatus.OK,
                description="Storage backend doesn't expose SQL — metric skipped.",
            )
            return metric, []

        current_filter = (
            "WHERE valid_to IS NULL "
            "AND superseded_by IS NULL "
            "AND status NOT IN ('expired','retracted')"
        )
        total_row = conn.execute(
            f"SELECT COUNT(*) AS c FROM facts {current_filter}"
        ).fetchone()
        total = total_row["c"] if total_row else 0

        if total == 0:
            metric = HealthMetric(
                name="source_coverage",
                value=100.0,
                unit="%",
                status=HealthStatus.OK,
                description="No current facts yet.",
            )
            return metric, []

        attributed_row = conn.execute(
            f"""SELECT COUNT(*) AS c FROM facts
                {current_filter}
                AND (
                    (source_author IS NOT NULL AND source_author != '')
                    OR (source_channel IS NOT NULL AND source_channel != '' AND source_channel != 'cli')
                    OR (source_url IS NOT NULL AND source_url != '')
                )"""
        ).fetchone()
        attributed = attributed_row["c"] if attributed_row else 0
        coverage = 100.0 * attributed / total

        if coverage >= 80:
            status = HealthStatus.OK
        elif coverage >= 60:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="source_coverage",
            value=coverage,
            unit="%",
            status=status,
            threshold_warn=80,
            threshold_crit=60,
            description="Share of current facts with an author/channel/url attribution.",
        )

        # Build open loops for a sample of missing-source facts (most recent first).
        loops: list[OpenLoop] = []
        rows = conn.execute(
            f"""SELECT f.id, f.entity_id, f.raw_text, e.name AS entity_name
                FROM facts f
                LEFT JOIN entities e ON e.id = f.entity_id
                {current_filter}
                AND (source_author IS NULL OR source_author = '')
                AND (source_channel IS NULL OR source_channel = '' OR source_channel = 'cli')
                AND (source_url IS NULL OR source_url = '')
                ORDER BY f.created_at DESC
                LIMIT ?""",
            (max_loops,),
        ).fetchall()
        for row in rows:
            text = (row["raw_text"] or "").strip()
            snippet = text if len(text) <= 120 else text[:120].rstrip() + "…"
            entity_name = row["entity_name"] if "entity_name" in row.keys() else None
            loops.append(
                OpenLoop(
                    kind=LoopKind.MISSING_SOURCE,
                    severity=LoopSeverity.INFO,
                    title=f"Fact missing source: {snippet}",
                    detail="Attribute an author, channel, or URL to this fact.",
                    target_id=row["id"],
                    entity_name=entity_name,
                    recommended_action="Re-ingest with --author / --source-type, or annotate manually.",
                )
            )
        return metric, loops

    def _stale_facts(
        self, stale_days: int, max_loops: int
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            metric = HealthMetric(
                name="stale_facts_ratio",
                value=0.0,
                unit="%",
                status=HealthStatus.OK,
            )
            return metric, []

        cutoff = (datetime.now() - timedelta(days=stale_days)).isoformat()
        current_filter = (
            "WHERE valid_to IS NULL "
            "AND superseded_by IS NULL "
            "AND status NOT IN ('expired','retracted')"
        )

        total_row = conn.execute(
            f"SELECT COUNT(*) AS c FROM facts {current_filter}"
        ).fetchone()
        total = total_row["c"] if total_row else 0
        if total == 0:
            metric = HealthMetric(
                name="stale_facts_ratio",
                value=0.0,
                unit="%",
                status=HealthStatus.OK,
                description="No current facts — nothing to age.",
            )
            return metric, []

        stale_rows = conn.execute(
            f"""SELECT f.id, f.entity_id, f.raw_text, f.created_at, e.name AS entity_name
                FROM facts f
                LEFT JOIN entities e ON e.id = f.entity_id
                {current_filter}
                AND f.created_at < ?
                ORDER BY f.created_at ASC
                LIMIT ?""",
            (cutoff, max_loops * 2),  # fetch extra for stable ordering; slice below
        ).fetchall()
        stale_total_row = conn.execute(
            f"""SELECT COUNT(*) AS c FROM facts
                {current_filter}
                AND created_at < ?""",
            (cutoff,),
        ).fetchone()
        stale_total = stale_total_row["c"] if stale_total_row else 0
        ratio = 100.0 * stale_total / total if total else 0.0

        if ratio <= 10:
            status = HealthStatus.OK
        elif ratio <= 30:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="stale_facts_ratio",
            value=ratio,
            unit="%",
            status=status,
            threshold_warn=10,
            threshold_crit=30,
            description=f"Share of current facts older than {stale_days} days.",
        )

        loops: list[OpenLoop] = []
        for row in stale_rows[:max_loops]:
            text = (row["raw_text"] or "").strip()
            snippet = text if len(text) <= 120 else text[:120].rstrip() + "…"
            created_at_raw = row["created_at"]
            try:
                created_at = (
                    datetime.fromisoformat(created_at_raw)
                    if created_at_raw
                    else None
                )
            except (TypeError, ValueError):
                created_at = None
            loops.append(
                OpenLoop(
                    kind=LoopKind.STALE_FACT,
                    severity=LoopSeverity.INFO,
                    title=f"Stale fact: {snippet}",
                    detail=f"Created {created_at_raw}. Consider re-verifying.",
                    target_id=row["id"],
                    entity_name=row["entity_name"] if "entity_name" in row.keys() else None,
                    recommended_action="Review and either retract, re-verify, or confirm.",
                    created_at=created_at,
                )
            )
        return metric, loops

    def _verification_backlog(
        self,
        max_loops: int,
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        open_requests = self.storage.list_verification_requests(  # type: ignore[attr-defined]
            status=VerificationRequestStatus.OPEN,
            limit=max_loops,
        )
        total = len(
            self.storage.list_verification_requests(  # type: ignore[attr-defined]
                status=VerificationRequestStatus.OPEN,
                limit=max(max_loops, 1000),
            )
        )

        if total == 0:
            status = HealthStatus.OK
        elif total <= 3:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="verification_backlog_count",
            value=float(total),
            unit="count",
            status=status,
            threshold_warn=1,
            threshold_crit=4,
            description="Open verification requests waiting for review.",
        )
        loops = [
            OpenLoop(
                kind=LoopKind.VERIFICATION_BACKLOG,
                severity=LoopSeverity.WARNING if total <= 3 else LoopSeverity.CRITICAL,
                title=f"Verification pending for {request.target_kind} {request.target_id[:8]}",
                detail=request.reason,
                target_id=request.id,
                recommended_action=f"engram verification-resolve {request.id} verified",
                created_at=request.requested_at,
            )
            for request in open_requests
        ]
        return metric, loops

    def _stale_decisions(
        self,
        max_loops: int,
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        conn = getattr(self.storage, "_conn", None)
        if conn is None:
            metric = HealthMetric(
                name="stale_decision_count",
                value=0.0,
                unit="count",
                status=HealthStatus.OK,
                description="Storage backend does not expose SQL; stale decisions skipped.",
            )
            return metric, []

        rows = conn.execute(
            """SELECT * FROM decisions
               WHERE status != 'superseded'
                 AND verification_status != 'pending'
                 AND (
                     verification_status = ?
                     OR (
                         verification_due_at IS NOT NULL
                         AND verification_due_at < ?
                     )
                 )
               ORDER BY indexed_at DESC
               LIMIT ?""",
            (
                VerificationStatus.STALE.value,
                datetime.now().isoformat(),
                max_loops,
            ),
        ).fetchall()
        count_row = conn.execute(
            """SELECT COUNT(*) AS c FROM decisions
               WHERE status != 'superseded'
                 AND verification_status != 'pending'
                 AND (
                     verification_status = ?
                     OR (
                         verification_due_at IS NOT NULL
                         AND verification_due_at < ?
                     )
                 )""",
            (
                VerificationStatus.STALE.value,
                datetime.now().isoformat(),
            ),
        ).fetchone()
        total = count_row["c"] if count_row else 0

        if total == 0:
            status = HealthStatus.OK
        elif total <= 3:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="stale_decision_count",
            value=float(total),
            unit="count",
            status=status,
            threshold_warn=1,
            threshold_crit=4,
            description="Decisions marked stale and waiting for review.",
        )
        loops: list[OpenLoop] = []
        for row in rows:
            try:
                created_at = (
                    datetime.fromisoformat(row["created_at"])
                    if row["created_at"]
                    else None
                )
            except (TypeError, ValueError):
                created_at = None
            loops.append(
                OpenLoop(
                    kind=LoopKind.STALE_DECISION,
                    severity=LoopSeverity.WARNING if total <= 3 else LoopSeverity.CRITICAL,
                    title=f"Stale decision: {row['title']}",
                    detail=row["summary"] or "",
                    target_id=row["id"],
                    recommended_action=f"engram decision-show {row['id']}",
                    created_at=created_at,
                )
            )
        return metric, loops

    def _entity_governance(
        self,
        max_loops: int,
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        rows = self.storage.list_governance_candidates(  # type: ignore[attr-defined]
            status=GovernanceCandidateStatus.OPEN,
            limit=max_loops,
        )
        total = self.storage.count_governance_candidates(  # type: ignore[attr-defined]
            status=GovernanceCandidateStatus.OPEN,
        )

        if total == 0:
            status = HealthStatus.OK
        elif total <= 3:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="entity_governance_backlog",
            value=float(total),
            unit="count",
            status=status,
            threshold_warn=1,
            threshold_crit=4,
            description="Open entity governance candidates waiting for review.",
        )
        loops = [
            OpenLoop(
                kind=LoopKind.ENTITY_GOVERNANCE,
                severity=LoopSeverity.WARNING if total <= 3 else LoopSeverity.CRITICAL,
                title=f"Review {candidate.candidate_type.value} candidate",
                detail=candidate.rationale,
                target_id=candidate.id,
                recommended_action=f"engram governance-resolve {candidate.id} approve",
                created_at=candidate.created_at,
            )
            for candidate in rows
        ]
        return metric, loops

    def _orphan_entities(
        self, entity_count: int, max_loops: int
    ) -> tuple[HealthMetric, list[OpenLoop]]:
        conn = getattr(self.storage, "_conn", None)
        if conn is None or entity_count == 0:
            metric = HealthMetric(
                name="orphan_entity_ratio",
                value=0.0,
                unit="%",
                status=HealthStatus.OK,
                description="No entities to check.",
            )
            return metric, []

        current_filter = (
            "valid_to IS NULL "
            "AND superseded_by IS NULL "
            "AND status NOT IN ('expired','retracted')"
        )
        rows = conn.execute(
            f"""SELECT e.id, e.name
                FROM entities e
                LEFT JOIN facts f
                    ON f.entity_id = e.id AND {current_filter}
                GROUP BY e.id, e.name
                HAVING COUNT(f.id) = 0
                ORDER BY e.updated_at ASC
                LIMIT ?""",
            (max_loops * 2,),
        ).fetchall()
        orphan_total_row = conn.execute(
            f"""SELECT COUNT(*) AS c FROM (
                SELECT e.id
                FROM entities e
                LEFT JOIN facts f
                    ON f.entity_id = e.id AND {current_filter}
                GROUP BY e.id
                HAVING COUNT(f.id) = 0
            )"""
        ).fetchone()
        orphan_total = orphan_total_row["c"] if orphan_total_row else 0
        ratio = 100.0 * orphan_total / entity_count if entity_count else 0.0

        if ratio <= 10:
            status = HealthStatus.OK
        elif ratio <= 25:
            status = HealthStatus.WARN
        else:
            status = HealthStatus.CRIT

        metric = HealthMetric(
            name="orphan_entity_ratio",
            value=ratio,
            unit="%",
            status=status,
            threshold_warn=10,
            threshold_crit=25,
            description="Share of entities with zero current facts.",
        )

        loops: list[OpenLoop] = []
        for row in rows[:max_loops]:
            loops.append(
                OpenLoop(
                    kind=LoopKind.ORPHAN_ENTITY,
                    severity=LoopSeverity.INFO,
                    title=f"Orphan entity: {row['name']}",
                    detail="Entity has no current facts.",
                    target_id=row["id"],
                    entity_name=row["name"],
                    recommended_action=f'engram-advanced add-fact "{row["name"]}" "<fact>" OR delete if unused.',
                )
            )
        return metric, loops

    # ── Aggregation ──

    def _compute_score(self, metrics: list[HealthMetric]) -> float:
        if not metrics:
            return 0.0
        total = sum(_STATUS_WEIGHT[m.status] for m in metrics)
        return round(100.0 * total / len(metrics), 1)
