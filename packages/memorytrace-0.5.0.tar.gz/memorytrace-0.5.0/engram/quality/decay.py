"""Time-based decay — identifies stale facts that need review.

The flat ``days`` threshold is kept for backward compatibility. New code
should pass a :class:`DecayPolicy` so each :class:`MemoryType` ages on its
own schedule (identity stays valid for a year, transient only for a week).
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from engram.models.fact import Fact
from engram.quality.decay_policy import DecayPolicy


def find_stale_facts(
    facts: list[Fact],
    days: int = 90,
    reference_time: Optional[datetime] = None,
    policy: Optional[DecayPolicy] = None,
) -> list[Fact]:
    """Find current facts older than the configured threshold.

    When ``policy`` is provided, per-type half-lives drive the decision so
    IDENTITY facts outlast EPISODIC ones automatically. Without a policy the
    historical flat ``days`` cutoff applies to every fact regardless of type.
    """
    now = reference_time or datetime.now()
    if policy is not None:
        return [f for f in facts if f.is_current and policy.is_stale(f, now)]
    cutoff = now - timedelta(days=days)
    return [f for f in facts if f.is_current and f.created_at < cutoff]
