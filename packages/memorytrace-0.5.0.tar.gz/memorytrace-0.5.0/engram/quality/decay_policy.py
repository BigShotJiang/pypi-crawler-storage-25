"""Differential decay — each MemoryType ages on its own schedule.

The policy converts (fact, reference_time) into

* a decay factor in ``[0.0, 1.0]`` — how much the fact still counts
* an effective confidence — ``fact.confidence * decay_factor``
* a boolean stale flag — true once a fact is older than ``stale_multiplier``
  half-lives

Half-lives are tuned from the shortlist's rule of thumb:

* ``IDENTITY``   365 days — "still confident after a year"
* ``PREFERENCE`` 180 days — tastes move slowly
* ``EPISODIC``    30 days — one-off observations fade within a month
* ``TRANSIENT``    7 days — volatile state expires fast

Callers should treat these as defaults; :class:`DecayPolicy` accepts an
override dict so tests and product tuning can change the curve without
editing core code.

See docs/03-improvement-plan/20-practical-feature-shortlist-2026-04-15.md §4.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from engram.models.fact import Fact
from engram.models.memory_type import MemoryType


DEFAULT_HALF_LIVES: dict[MemoryType, float] = {
    MemoryType.IDENTITY: 365.0,
    MemoryType.PREFERENCE: 180.0,
    MemoryType.EPISODIC: 30.0,
    MemoryType.TRANSIENT: 7.0,
}


@dataclass
class DecayPolicy:
    """Per-type exponential decay.

    ``decay_factor = 2 ** (-age_days / half_life(type))``.

    ``is_stale`` uses ``age_days > stale_multiplier * half_life`` — three
    half-lives by default, i.e. the fact has lost 87.5 % of its confidence.
    """

    half_lives: dict[MemoryType, float] = field(
        default_factory=lambda: dict(DEFAULT_HALF_LIVES)
    )
    stale_multiplier: float = 3.0

    def half_life(self, memory_type: MemoryType) -> float:
        return float(
            self.half_lives.get(memory_type, DEFAULT_HALF_LIVES[memory_type])
        )

    def _age_days(
        self, fact: Fact, reference_time: Optional[datetime] = None
    ) -> float:
        now = reference_time or datetime.now()
        delta = now - fact.created_at
        return max(0.0, delta.total_seconds() / 86400.0)

    def decay_factor(
        self, fact: Fact, reference_time: Optional[datetime] = None
    ) -> float:
        age = self._age_days(fact, reference_time)
        half = self.half_life(fact.memory_type)
        if half <= 0:
            return 0.0
        return float(math.pow(2.0, -age / half))

    def effective_confidence(
        self, fact: Fact, reference_time: Optional[datetime] = None
    ) -> float:
        return max(0.0, min(1.0, fact.confidence * self.decay_factor(fact, reference_time)))

    def is_stale(
        self, fact: Fact, reference_time: Optional[datetime] = None
    ) -> bool:
        age = self._age_days(fact, reference_time)
        half = self.half_life(fact.memory_type)
        if half <= 0:
            return True
        return age > half * self.stale_multiplier

    def stale_cutoff_days(self, memory_type: MemoryType) -> float:
        return self.half_life(memory_type) * self.stale_multiplier
