"""Build shared explanation bundles from Engram read models."""

from __future__ import annotations

from engram.models.explanation import (
    EvidenceRef,
    ExplanationBundle,
    ExplanationFactor,
    ProvenanceTrace,
)
from engram.models.maintenance import MaintenanceRunItem
from engram.models.search import SearchHit
from engram.models.decision import DecisionRecord


class ExplanationBuilder:
    """Assemble reusable explanation bundles."""

    def from_search_hit(self, query: str, hit: SearchHit) -> ExplanationBundle:
        factors = [
            ExplanationFactor(
                name=factor.name,
                stage="rerank",
                delta=factor.delta,
                reason=factor.reason,
            )
            for factor in hit.ranking_factors
        ]
        evidence = [
            EvidenceRef(
                kind="fact",
                id=fact.id,
                label=fact.raw_text,
                snippet=fact.raw_text,
                entity_id=fact.entity_id,
                source_kind=fact.source.type.value if fact.source else None,
                source_id=(
                    fact.source.url or fact.source.session_id or fact.source.channel
                )
                if fact.source
                else None,
            )
            for fact in hit.facts
        ]
        trace = ProvenanceTrace(
            retriever=hit.provenance.retriever,
            query=query,
            base_score=hit.base_score,
            snippet=hit.provenance.snippet,
            matched_fact_ids=list(hit.provenance.matched_fact_ids),
            reasons=list(hit.provenance.reasons),
        )
        return ExplanationBundle(
            summary=f"Retrieved {hit.entity.name} via {trace.retriever}.",
            trace=trace,
            factors=factors,
            evidence=evidence,
            warnings=[],
        )

    def for_decision(self, decision: DecisionRecord) -> ExplanationBundle:
        evidence = [
            EvidenceRef(
                kind="decision",
                id=decision.id,
                label=decision.title,
                snippet=decision.summary,
                entity_id=decision.entity_id,
                source_kind=decision.source_kind,
                source_id=decision.source_id,
            )
        ]
        return ExplanationBundle(
            summary=f"Decision extracted from {decision.source_kind}.",
            evidence=evidence,
            warnings=[],
        )

    def for_backlink(self, entity_name: str, row: dict) -> ExplanationBundle:
        evidence = [
            EvidenceRef(
                kind="reference_edge",
                id=row["id"],
                label=f"{entity_name} reference",
                snippet=row.get("snippet", ""),
                entity_id=row.get("entity_id"),
                source_kind=row.get("source_kind"),
                source_id=row.get("source_id"),
            )
        ]
        matched_text = row.get("matched_text", entity_name)
        return ExplanationBundle(
            summary=f"Matched {entity_name} in {row.get('source_kind', 'source')} via '{matched_text}'.",
            evidence=evidence,
            warnings=[],
        )

    def for_maintenance_item(self, item: MaintenanceRunItem) -> ExplanationBundle:
        evidence = [
            EvidenceRef(
                kind="maintenance_item",
                id=item.id,
                label=item.title,
                snippet=item.detail,
                entity_id=item.target_id,
            )
        ]
        return ExplanationBundle(
            summary=f"Maintenance flagged {item.kind}.",
            evidence=evidence,
            warnings=[],
        )
