"""Goal-aware reranking layer."""

from __future__ import annotations

from engram.models.entity import Entity
from engram.models.search import RankingFactor, RetrievalContext, SearchResult
from engram.storage.sqlite_store import SQLiteStorage


class RerankingService:
    """Apply explicit additive boosts based on retrieval context."""

    _GOAL_TYPE_PREFERENCES = {
        "meeting_prep": {"person": 0.25, "organization": 0.15},
        "task_handoff": {"person": 0.20, "project": 0.20},
        "debugging": {"service": 0.25, "project": 0.15},
    }

    def __init__(self, storage: SQLiteStorage) -> None:
        self.storage = storage

    def score_entity(
        self,
        entity: Entity,
        context: RetrievalContext | None,
        *,
        base_score: float = 0.0,
    ) -> tuple[float, list[RankingFactor]]:
        score = base_score
        factors: list[RankingFactor] = []
        if context is None:
            return round(score, 6), factors
        if entity.id in context.active_entity_ids:
            score += 0.6
            factors.append(RankingFactor("active_entity", 0.6, "entity is active in session"))
        if entity.id in context.recent_entity_ids:
            score += 0.2
            factors.append(RankingFactor("recent_entity", 0.2, "entity was recently accessed"))
        if entity.id in context.preferred_entity_ids:
            score += 0.4
            factors.append(RankingFactor("preferred_entity", 0.4, "entity was explicitly preferred"))
        if entity.entity_type in context.preferred_entity_types:
            score += 0.25
            factors.append(RankingFactor("preferred_type", 0.25, "entity type matches requested scope"))
        if entity.tier.value in context.preferred_tiers:
            score += 0.15
            factors.append(RankingFactor("preferred_tier", 0.15, "entity tier matches preferred tiers"))
        for entity_type, delta in self._GOAL_TYPE_PREFERENCES.get(context.goal, {}).items():
            if entity.entity_type == entity_type:
                score += delta
                factors.append(RankingFactor("goal_type", delta, f"context goal favors {entity_type}"))
        return round(score, 6), factors

    def rerank(self, result: SearchResult, context: RetrievalContext | None) -> SearchResult:
        if context is None or not result.hits:
            return result
        for hit in result.hits:
            hit.base_score = hit.base_score or hit.relevance_score
            score, new_factors = self.score_entity(
                hit.entity,
                context,
                base_score=hit.base_score,
            )
            if context.include_explanations:
                hit.ranking_factors = [*hit.ranking_factors, *new_factors]
            hit.relevance_score = score
        result.hits.sort(key=lambda hit: hit.relevance_score, reverse=True)
        return result
