"""Search backend protocol."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from engram.models.search import SearchOptions, SearchResult


@runtime_checkable
class SearchBackend(Protocol):
    """Abstract search interface — all search backends implement this.

    The ``search`` and ``close`` methods are required. Index-management
    methods (``index_entity``, ``remove_from_index``, ``reindex_all``)
    are optional because FTS5 delegates indexing to the storage layer.
    Callers that need indexing should use ``getattr`` to check availability.
    """

    def search(self, options: SearchOptions) -> SearchResult: ...

    def close(self) -> None: ...
