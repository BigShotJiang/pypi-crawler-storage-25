"""Unicode-aware tokenizer with CJK support."""

from __future__ import annotations

import re

# Common English stopwords (minimal set for search quality)
_ENGLISH_STOPWORDS = frozenset({
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "was", "are", "were", "be", "been",
    "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "could", "should", "may", "might", "shall", "can", "need", "must",
    "not", "no", "nor", "so", "if", "then", "than", "that", "this",
    "these", "those", "it", "its", "he", "she", "they", "we", "you",
    "i", "me", "my", "your", "his", "her", "our", "their", "who",
    "what", "which", "when", "where", "how", "why", "all", "each",
    "every", "both", "few", "more", "most", "some", "any", "such",
    "only", "own", "same", "very", "just", "about", "above", "after",
    "again", "also", "as", "because", "before", "between", "during",
    "into", "over", "through", "under", "until", "up", "while",
})

# Korean stopwords (particles, endings)
_KOREAN_STOPWORDS = frozenset({
    "은", "는", "이", "가", "을", "를", "에", "의", "로", "으로",
    "와", "과", "도", "만", "부터", "까지", "에서", "한", "할", "하는",
    "했다", "합니다", "있는", "있다", "없다", "되는", "된", "되다",
    "그", "저", "이것", "그것", "저것", "여기", "거기", "저기",
})

# Token pattern: word chars + CJK unified ideographs + Hangul
_TOKEN_PATTERN = re.compile(
    r'[a-zA-Z0-9_]+'           # ASCII words
    r'|[\uAC00-\uD7AF]+'       # Hangul syllables
    r'|[\u4E00-\u9FFF]+'        # CJK unified ideographs
    r'|[\u3040-\u309F\u30A0-\u30FF]+'  # Hiragana + Katakana
, re.UNICODE)


def tokenize(text: str, remove_stopwords: bool = True) -> list[str]:
    """Tokenize text into lowercase tokens with optional stopword removal.

    Handles English, Korean, Chinese, and Japanese text.
    """
    tokens = _TOKEN_PATTERN.findall(text.lower())
    if not remove_stopwords:
        return tokens
    return [
        t for t in tokens
        if t not in _ENGLISH_STOPWORDS and t not in _KOREAN_STOPWORDS and len(t) > 1
    ]


def escape_fts5_query(query: str) -> str:
    """Escape special FTS5 characters to prevent syntax errors.

    FTS5 special chars: * " ( ) : ^
    We wrap each token in double quotes to treat them as literals.
    """
    tokens = tokenize(query, remove_stopwords=False)
    if not tokens:
        return '""'
    # Quote each token to escape special chars, join with implicit AND
    escaped = []
    for token in tokens:
        # Remove any embedded double quotes
        clean = token.replace('"', '')
        if clean:
            escaped.append(f'"{clean}"')
    return " ".join(escaped) if escaped else '""'


def build_fts5_query(query: str) -> str:
    """Build an FTS5 query from natural language input.

    - Removes stopwords
    - Escapes special characters
    - Returns FTS5-compatible query string
    """
    tokens = tokenize(query, remove_stopwords=True)
    if not tokens:
        # Fall back to raw escaped query if all words were stopwords
        return escape_fts5_query(query)
    # Quote each token for safety
    return " ".join(f'"{t}"' for t in tokens)
