"""Deterministic query planning for compound memory lookups."""

from __future__ import annotations

import re

from engram.models.search import QueryPlan

_SPLIT_PATTERN = re.compile(
    r"\s*(?:,|/| and | & | 및 | 그리고 | plus | with )\s*",
    flags=re.IGNORECASE,
)


class QueryPlanner:
    """Build a conservative query plan from a natural-language search string."""

    def build(self, query: str) -> QueryPlan:
        normalized_query = " ".join(query.strip().split())
        if not normalized_query:
            return QueryPlan(original_query=query)

        fragments: list[str] = []
        seen: set[str] = set()
        for candidate in _SPLIT_PATTERN.split(normalized_query):
            fragment = " ".join(candidate.strip().split())
            lowered = fragment.lower()
            if len(fragment) < 3 or lowered in seen:
                continue
            fragments.append(fragment)
            seen.add(lowered)

        if len(fragments) <= 1:
            return QueryPlan(
                original_query=normalized_query,
                fragments=[],
                reasons=[],
                should_expand=False,
            )

        return QueryPlan(
            original_query=normalized_query,
            fragments=fragments,
            reasons=["split compound query into focused fragments"],
            should_expand=True,
        )
