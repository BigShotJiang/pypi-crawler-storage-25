"""Context expansion on top of base goal-aware retrieval."""

from __future__ import annotations

from engram.freshness.service import FreshnessService
from engram.models.decision import DecisionRecord
from engram.models.brief import RelatedEntity
from engram.models.explanation import ExplanationBundle
from engram.models.search import QueryPlan, RetrievalContext, SearchResult
from engram.models.view import ContextSearchResult, DecisionView
from engram.references.service import ReferenceService
from engram.search.reranker import RerankingService
from engram.storage.base import StorageBackend


class ContextSearchService:
    """Expand base search hits with nearby typed context."""

    def __init__(
        self,
        storage: StorageBackend,
        reference_service: ReferenceService,
        reranking_service: RerankingService,
        freshness_service: FreshnessService,
    ) -> None:
        self.storage = storage
        self.reference_service = reference_service
        self.reranking_service = reranking_service
        self.freshness_service = freshness_service

    def expand(
        self,
        *,
        query: str,
        goal: str,
        base_result: SearchResult,
        query_plan: QueryPlan | None,
        context: RetrievalContext,
        expand_hops: int,
        max_related: int,
        related_token_budget: int,
        include_decisions: bool,
        include_references: bool,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
    ) -> ContextSearchResult:
        if expand_hops == 0 or not base_result.hits:
            return ContextSearchResult(
                query=query,
                goal=goal,
                base_result=base_result,
                query_plan=query_plan,
            )

        seed_ids = [hit.entity.id for hit in base_result.hits]
        related_entities = self._related_entities(
            seed_ids,
            context=context,
            max_related=max_related,
            token_budget=related_token_budget,
            allowed_scope_ids=allowed_scope_ids,
            include_global=include_global,
        )
        decision_budget = max(related_token_budget // 2, 0)
        related_decisions = (
            self._related_decisions(
                seed_ids,
                limit=max_related,
                token_budget=decision_budget,
                allowed_scope_ids=allowed_scope_ids,
                include_global=include_global,
            )
            if include_decisions
            else []
        )

        notes: list[str] = []
        if related_entities:
            notes.append("expanded relation neighbors")
        if include_references and self._has_reference_support(seed_ids):
            # Phase 1: reference edges inform the expansion note but do not
            # yet add data to the result.  Full reference-based expansion is
            # planned for phase 2.
            notes.append("inspected reference edges")
        if related_decisions:
            notes.append("collected supporting decisions")
        if query_plan is not None and query_plan.should_expand:
            notes.append("applied query plan")

        return ContextSearchResult(
            query=query,
            goal=goal,
            base_result=base_result,
            query_plan=query_plan,
            related_entities=related_entities,
            related_decisions=related_decisions,
            expansion_notes=notes,
        )

    def _related_entities(
        self,
        seed_ids: list[str],
        *,
        context: RetrievalContext,
        max_related: int,
        token_budget: int,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
    ) -> list[RelatedEntity]:
        scored_rows: list[tuple[float, RelatedEntity]] = []
        seen: set[str] = set(seed_ids)
        entity_scope_cache: dict[str, bool] = {}
        relations_by_seed = {
            entity_id: self.storage.get_relations(entity_id)
            for entity_id in seed_ids
        }
        scope_map = self.storage.list_current_fact_scopes(
            [
                relation.to_entity_id
                if relation.from_entity_id == entity_id
                else relation.from_entity_id
                for entity_id, relations in relations_by_seed.items()
                for relation in relations
            ]
        ) if allowed_scope_ids is not None else {}

        for entity_id in seed_ids:
            for relation in relations_by_seed[entity_id]:
                candidate_id = (
                    relation.to_entity_id
                    if relation.from_entity_id == entity_id
                    else relation.from_entity_id
                )
                if candidate_id in seen:
                    continue
                if not self._entity_allowed(
                    candidate_id,
                    allowed_scope_ids,
                    include_global,
                    entity_scope_cache,
                    scope_map,
                ):
                    continue
                entity = self.storage.get_entity(candidate_id)
                if entity is None:
                    continue
                seen.add(candidate_id)
                score, _factors = self.reranking_service.score_entity(
                    entity,
                    context,
                    base_score=0.0,
                )
                scored_rows.append(
                    (
                        score,
                        RelatedEntity(
                            entity_id=entity.id,
                            name=entity.name,
                            entity_type=entity.entity_type,
                            relation_type=relation.relation_type,
                            direction=(
                                "outgoing"
                                if relation.from_entity_id == entity_id
                                else "incoming"
                            ),
                        ),
                    )
                )

        scored_rows.sort(key=lambda pair: pair[0], reverse=True)
        rows: list[RelatedEntity] = []
        tokens_used = 0
        for _score, row in scored_rows:
            estimate = max(1, len(row.name) // 4)
            if token_budget > 0 and tokens_used + estimate > token_budget:
                break
            rows.append(row)
            tokens_used += estimate
            if len(rows) >= max_related:
                break
        return rows

    def _related_decisions(
        self,
        seed_ids: list[str],
        *,
        limit: int,
        token_budget: int,
        allowed_scope_ids: set[str] | None = None,
        include_global: bool = False,
    ) -> list[DecisionView]:
        rows: list[DecisionView] = []
        seen: set[str] = set()
        tokens_used = 0
        session_scope_cache: dict[str, str | None] = {}

        for entity_id in seed_ids:
            for decision in self.storage.list_decisions(entity_id=entity_id, limit=max(limit * 2, 20)):
                if decision.id in seen:
                    continue
                if not self._decision_allowed(
                    decision,
                    allowed_scope_ids,
                    include_global,
                    session_scope_cache,
                ):
                    continue
                estimate = max(1, len(decision.title) // 4)
                if token_budget > 0 and tokens_used + estimate > token_budget:
                    return rows
                seen.add(decision.id)
                assessment = self.freshness_service.assess_decision(decision)
                rows.append(
                    DecisionView(
                        decision=decision,
                        explanation=ExplanationBundle(
                            summary=f"Decision linked to entity {entity_id}.",
                            warnings=[assessment.warning] if assessment.warning else [],
                        ),
                    )
                )
                tokens_used += estimate
                if len(rows) >= limit:
                    return rows
        return rows

    def _has_reference_support(self, seed_ids: list[str]) -> bool:
        for entity_id in seed_ids:
            if self.storage.list_reference_edges(entity_id, limit=1):
                return True
        return False

    def _decision_allowed(
        self,
        decision: DecisionRecord,
        allowed_scope_ids: set[str] | None,
        include_global: bool,
        session_scope_cache: dict[str, str | None],
    ) -> bool:
        if allowed_scope_ids is None:
            return True
        if not decision.session_id:
            return False
        if decision.session_id not in session_scope_cache:
            session = self.storage.get_session(decision.session_id)
            session_scope_cache[decision.session_id] = session.scope_id if session else None
        return self._scope_allows(
            session_scope_cache[decision.session_id],
            allowed_scope_ids,
            include_global,
        )

    def _entity_allowed(
        self,
        entity_id: str,
        allowed_scope_ids: set[str] | None,
        include_global: bool,
        entity_scope_cache: dict[str, bool],
        scope_map: dict[str, set[str | None]],
    ) -> bool:
        if allowed_scope_ids is None:
            return True
        if entity_id not in entity_scope_cache:
            entity_scope_cache[entity_id] = any(
                self._scope_allows(scope_id, allowed_scope_ids, include_global)
                for scope_id in scope_map.get(entity_id, set())
            )
        return entity_scope_cache[entity_id]

    @staticmethod
    def _scope_allows(
        scope_id: str | None,
        allowed_scope_ids: set[str],
        include_global: bool,
    ) -> bool:
        if scope_id is None:
            return include_global
        return scope_id in allowed_scope_ids
