"""Retention policy service."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from engram.models.retention import (
    RetentionPolicy,
    RetentionPolicyType,
    RetentionTargetKind,
)
from engram.storage.sqlite_store import SQLiteStorage


class RetentionService:
    def __init__(self, storage: SQLiteStorage) -> None:
        self.storage = storage

    def set_policy(
        self,
        *,
        target_kind: RetentionTargetKind | str,
        target_id: str,
        policy_type: RetentionPolicyType | str,
        value: Optional[str] = None,
        reason: str = "",
    ) -> RetentionPolicy:
        policy = RetentionPolicy(
            target_kind=(
                target_kind
                if isinstance(target_kind, RetentionTargetKind)
                else RetentionTargetKind(target_kind)
            ),
            target_id=target_id,
            policy_type=(
                policy_type
                if isinstance(policy_type, RetentionPolicyType)
                else RetentionPolicyType(policy_type)
            ),
            value=value,
            reason=reason,
        )
        return self.storage.upsert_retention_policy(policy)

    def clear_policy(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
        policy_type: RetentionPolicyType | str,
    ) -> bool:
        kind = target_kind if isinstance(target_kind, RetentionTargetKind) else RetentionTargetKind(target_kind)
        policy = policy_type if isinstance(policy_type, RetentionPolicyType) else RetentionPolicyType(policy_type)
        return self.storage.clear_retention_policy(kind.value, target_id, policy.value)

    def list_policies(
        self,
        *,
        target_kind: RetentionTargetKind | str | None = None,
        target_id: Optional[str] = None,
        policy_type: RetentionPolicyType | str | None = None,
        limit: int = 100,
    ) -> list[RetentionPolicy]:
        kind_value = None
        policy_value = None
        if target_kind is not None:
            kind_value = (
                target_kind.value
                if isinstance(target_kind, RetentionTargetKind)
                else RetentionTargetKind(target_kind).value
            )
        if policy_type is not None:
            policy_value = (
                policy_type.value
                if isinstance(policy_type, RetentionPolicyType)
                else RetentionPolicyType(policy_type).value
            )
        return self.storage.list_retention_policies(
            target_kind=kind_value,
            target_id=target_id,
            policy_type=policy_value,
            limit=limit,
        )

    def get_policies_for_target(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
    ) -> list[RetentionPolicy]:
        kind = target_kind if isinstance(target_kind, RetentionTargetKind) else RetentionTargetKind(target_kind)
        return self.storage.get_retention_policies_for_target(kind.value, target_id)

    def _has_policy(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
        policy_type: RetentionPolicyType,
    ) -> bool:
        kind = target_kind if isinstance(target_kind, RetentionTargetKind) else RetentionTargetKind(target_kind)
        policy = self.storage.get_retention_policy(kind.value, target_id, policy_type.value)
        return policy is not None

    def is_pinned(self, target_kind: RetentionTargetKind | str, target_id: str) -> bool:
        return self._has_policy(target_kind, target_id, RetentionPolicyType.PIN)

    def is_archive_only(self, target_kind: RetentionTargetKind | str, target_id: str) -> bool:
        return self._has_policy(target_kind, target_id, RetentionPolicyType.ARCHIVE_ONLY)

    def is_never_summarize(self, target_kind: RetentionTargetKind | str, target_id: str) -> bool:
        return self._has_policy(target_kind, target_id, RetentionPolicyType.NEVER_SUMMARIZE)

    def get_ttl(
        self,
        target_kind: RetentionTargetKind | str,
        target_id: str,
    ) -> Optional[datetime]:
        kind = target_kind if isinstance(target_kind, RetentionTargetKind) else RetentionTargetKind(target_kind)
        policy = self.storage.get_retention_policy(kind.value, target_id, RetentionPolicyType.TTL.value)
        if policy is None or not policy.value:
            return None
        return datetime.fromisoformat(policy.value)
