"""Decision projection service."""

from __future__ import annotations

import hashlib
import re
from datetime import datetime

from engram.models.decision import DecisionRecord, DecisionStatus
from engram.storage.sqlite_store import SQLiteStorage


class DecisionService:
    """Extract structured decisions from canonical source text."""

    _NOTE_SQL = "SELECT id AS source_id, text, session_id FROM notes"
    _SESSION_SQL = "SELECT session_id AS source_id, summary AS text FROM sessions WHERE summary IS NOT NULL AND summary != ''"
    _DEBUG_SQL = "SELECT id AS source_id, conclusion AS text FROM debug_sessions WHERE conclusion IS NOT NULL AND conclusion != ''"
    _SIGNAL_RE = re.compile(
        r"(?i)(decided to|we will|we decided|agreed to|plan is to|결정|하기로|채택|보류)"
    )

    def __init__(self, storage: SQLiteStorage, reference_service=None) -> None:
        self.storage = storage
        self.reference_service = reference_service

    def index_source(self, source_kind: str, source_id: str) -> list[DecisionRecord]:
        if source_kind not in {"note", "session", "debug_session"}:
            return []
        text, session_id = self._load_source(source_kind, source_id)
        decisions = self._extract_decisions(source_kind, source_id, text, session_id=session_id)
        self.storage.replace_decisions(source_kind, source_id, decisions)
        return decisions

    def list_decisions(
        self,
        entity_name: str | None = None,
        status: DecisionStatus | None = None,
        limit: int = 20,
    ) -> list[DecisionRecord]:
        entity_id = None
        if entity_name:
            entity = self.storage.get_entity_by_name(entity_name)
            if entity is None:
                return []
            entity_id = entity.id
        return self.storage.list_decisions(entity_id=entity_id, status=status, limit=limit)

    def get_decision(self, decision_id: str) -> DecisionRecord | None:
        return self.storage.get_decision(decision_id)

    def rebuild_all(self) -> int:
        conn = self.storage._conn
        total = 0
        for sql, source_kind in (
            (self._NOTE_SQL, "note"),
            (self._SESSION_SQL, "session"),
            (self._DEBUG_SQL, "debug_session"),
        ):
            rows = conn.execute(sql).fetchall()
            for row in rows:
                self.index_source(source_kind, row["source_id"])
                total += 1
        return total

    def projection_drift(self, limit: int = 20) -> list[dict]:
        drifts: list[dict] = []
        conn = self.storage._conn
        for sql, source_kind in (
            (self._NOTE_SQL, "note"),
            (self._SESSION_SQL, "session"),
            (self._DEBUG_SQL, "debug_session"),
        ):
            rows = conn.execute(sql).fetchall()
            for row in rows:
                text = (row["text"] or "").strip()
                if not text or not self._SIGNAL_RE.search(text):
                    continue
                if self.storage.count_decisions_for_source(source_kind, row["source_id"]) > 0:
                    continue
                drifts.append(
                    {
                        "source_kind": source_kind,
                        "source_id": row["source_id"],
                        "title": f"Missing decisions for {source_kind} {row['source_id']}",
                        "detail": text[:120],
                    }
                )
                if len(drifts) >= limit:
                    return drifts
        return drifts

    def _load_source(self, source_kind: str, source_id: str) -> tuple[str, str | None]:
        conn = self.storage._conn
        if source_kind == "note":
            row = conn.execute(
                "SELECT text, session_id FROM notes WHERE id = ?",
                (source_id,),
            ).fetchone()
            return ((row["text"] if row else "") or "", row["session_id"] if row else None)
        if source_kind == "session":
            row = conn.execute(
                "SELECT summary AS text, session_id FROM sessions WHERE session_id = ?",
                (source_id,),
            ).fetchone()
            return ((row["text"] if row else "") or "", row["session_id"] if row else source_id)
        if source_kind == "debug_session":
            row = conn.execute(
                "SELECT conclusion AS text FROM debug_sessions WHERE id = ?",
                (source_id,),
            ).fetchone()
            return ((row["text"] if row else "") or "", None)
        return "", None

    def _extract_decisions(
        self,
        source_kind: str,
        source_id: str,
        text: str,
        *,
        session_id: str | None,
    ) -> list[DecisionRecord]:
        text = (text or "").strip()
        if not text:
            return []
        sentences = [part.strip() for part in re.split(r"[.\n]+", text) if part.strip()]
        now = datetime.now()
        decisions: list[DecisionRecord] = []
        for sentence in sentences:
            if not self._SIGNAL_RE.search(sentence):
                continue
            lowered = sentence.lower()
            status = DecisionStatus.DRAFT if any(token in lowered for token in ("보류", "draft", "consider")) else DecisionStatus.ACTIVE
            confidence = 0.65 if status == DecisionStatus.DRAFT else 0.85
            entity_id = None
            if self.reference_service is not None:
                entity_ids = self.reference_service.match_entity_ids(sentence)
                if len(entity_ids) == 1:
                    entity_id = entity_ids[0]
            title = sentence[:80].strip()
            fingerprint = hashlib.sha256(
                f"{source_kind}|{source_id}|{title}|{sentence}".encode("utf-8", errors="replace")
            ).hexdigest()[:24]
            decisions.append(
                DecisionRecord(
                    title=title,
                    summary=sentence,
                    status=status,
                    confidence=confidence,
                    source_kind=source_kind,
                    source_id=source_id,
                    entity_id=entity_id,
                    session_id=session_id,
                    fingerprint=fingerprint,
                    created_at=now,
                    indexed_at=now,
                )
            )
        return decisions
