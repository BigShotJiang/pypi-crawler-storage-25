"""Decision projection package."""
