"""Allow running as `python -m engram`."""

from engram.cli.simple import cli_entry

if __name__ == "__main__":
    cli_entry()
