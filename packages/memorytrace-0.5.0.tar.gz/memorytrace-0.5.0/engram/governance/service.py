"""Entity governance candidate detection and resolution."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime

from engram.exceptions import EntityNotFoundError
from engram.models.entity import Entity
from engram.models.governance import (
    GovernanceCandidate,
    GovernanceCandidateStatus,
    GovernanceCandidateType,
    GovernanceResolution,
)
from engram.storage.sqlite_store import SQLiteStorage


class EntityGovernanceService:
    """Generate and resolve duplicate entity governance candidates."""

    def __init__(self, storage: SQLiteStorage) -> None:
        self.storage = storage

    def generate_candidates(self, limit: int = 100) -> list[GovernanceCandidate]:
        entities = self.storage.list_entities(limit=5000)
        generated: list[GovernanceCandidate] = []
        seen: set[str] = set()
        for index, primary in enumerate(entities):
            for secondary in entities[index + 1:]:
                pair = self._build_merge_candidate(primary, secondary)
                if pair is None or pair.fingerprint in seen:
                    continue
                seen.add(pair.fingerprint)
                generated.append(self.storage.upsert_governance_candidate(pair))
                alias = self.build_alias_candidate(primary, secondary.name)
                if alias is not None and alias.fingerprint not in seen:
                    seen.add(alias.fingerprint)
                    generated.append(self.storage.upsert_governance_candidate(alias))
                if len(generated) >= limit:
                    return generated[:limit]
        for entity in entities:
            split = self._build_split_candidate(entity)
            if split is None or split.fingerprint in seen:
                continue
            seen.add(split.fingerprint)
            generated.append(self.storage.upsert_governance_candidate(split))
            if len(generated) >= limit:
                return generated[:limit]
        return generated

    def list_candidates(
        self,
        *,
        status: GovernanceCandidateStatus | None = None,
        candidate_type: GovernanceCandidateType | None = None,
        limit: int = 50,
    ) -> list[GovernanceCandidate]:
        return self.storage.list_governance_candidates(
            status=status,
            candidate_type=candidate_type,
            limit=limit,
        )

    def get_candidate(self, candidate_id: str) -> GovernanceCandidate | None:
        return self.storage.get_governance_candidate(candidate_id)

    def build_alias_candidate(
        self,
        entity: Entity,
        alias: str,
        *,
        score: float = 0.7,
        rationale: str = "review alternate entity label",
    ) -> GovernanceCandidate | None:
        token = (alias or "").strip()
        if not token or token == entity.name or token in entity.aliases:
            return None
        now = datetime.now()
        fingerprint = hashlib.sha256(
            f"alias|{entity.id}|{self._normalize(token)}".encode("utf-8", errors="replace")
        ).hexdigest()[:24]
        return GovernanceCandidate(
            candidate_type=GovernanceCandidateType.ALIAS,
            status=GovernanceCandidateStatus.OPEN,
            entity_id=entity.id,
            proposed_alias=token,
            score=score,
            fingerprint=fingerprint,
            rationale=rationale,
            details={"entity_name": entity.name, "proposed_alias": token},
            created_at=now,
            updated_at=now,
        )

    def resolve_candidate(
        self,
        candidate_id: str,
        *,
        resolution: GovernanceResolution,
        resolved_by: str = "user",
        merge_fn=None,
    ) -> GovernanceCandidate:
        candidate = self.storage.get_governance_candidate(candidate_id)
        if candidate is None:
            raise EntityNotFoundError(f"Governance candidate '{candidate_id}' not found")
        if candidate.status not in {GovernanceCandidateStatus.OPEN, GovernanceCandidateStatus.APPROVED}:
            raise ValueError(f"Governance candidate '{candidate_id}' is already resolved")

        if resolution is GovernanceResolution.REJECT:
            return self.storage.resolve_governance_candidate(
                candidate_id,
                status=GovernanceCandidateStatus.REJECTED,
                resolved_by=resolved_by,
            )

        approved = self.storage.resolve_governance_candidate(
            candidate_id,
            status=GovernanceCandidateStatus.APPROVED,
            resolved_by=resolved_by,
        )
        if approved.candidate_type is GovernanceCandidateType.MERGE:
            if approved.related_entity_id is None:
                raise ValueError("Merge candidate missing related_entity_id")
            if merge_fn is None:
                raise ValueError("merge_fn is required to approve merge candidates")
            merge_fn(approved.entity_id, approved.related_entity_id)
            self._cancel_redundant_alias_candidates(approved, resolved_by=resolved_by)
        elif approved.candidate_type is GovernanceCandidateType.ALIAS:
            entity = self.storage.get_entity(approved.entity_id)
            if entity is None:
                raise EntityNotFoundError(f"Entity '{approved.entity_id}' not found")
            alias = (approved.proposed_alias or "").strip()
            if alias and alias not in entity.aliases and alias != entity.name:
                entity.aliases.append(alias)
                self.storage.update_entity(entity)
        elif approved.candidate_type is GovernanceCandidateType.SPLIT:
            entity = self.storage.get_entity(approved.entity_id)
            if entity is None:
                raise EntityNotFoundError(f"Entity '{approved.entity_id}' not found")
        return self.storage.resolve_governance_candidate(
            candidate_id,
            status=GovernanceCandidateStatus.APPLIED,
            resolved_by=resolved_by,
        )

    def _build_merge_candidate(
        self,
        first: Entity,
        second: Entity,
    ) -> GovernanceCandidate | None:
        if first.id == second.id or first.entity_type != second.entity_type:
            return None
        first_name = self._normalize(first.name)
        second_name = self._normalize(second.name)
        first_aliases = {self._normalize(alias) for alias in first.aliases if alias.strip()}
        second_aliases = {self._normalize(alias) for alias in second.aliases if alias.strip()}
        matched = False
        rationale = ""
        if first_name == second_name and first_name:
            matched = True
            rationale = "normalized names match exactly"
        elif first_name in second_aliases:
            matched = True
            rationale = "secondary alias matches primary name"
        elif second_name in first_aliases:
            matched = True
            rationale = "primary alias matches secondary name"
        if not matched:
            return None

        primary, secondary = sorted(
            (first, second),
            key=lambda item: (-len(self._normalize(item.name)), item.name.lower(), item.id),
        )
        score = 0.95 if self._normalize(primary.name) == self._normalize(secondary.name) else 0.85
        fingerprint = hashlib.sha256(
            f"merge|{primary.id}|{secondary.id}|{rationale}".encode("utf-8", errors="replace")
        ).hexdigest()[:24]
        now = datetime.now()
        return GovernanceCandidate(
            candidate_type=GovernanceCandidateType.MERGE,
            status=GovernanceCandidateStatus.OPEN,
            entity_id=primary.id,
            related_entity_id=secondary.id,
            score=score,
            fingerprint=fingerprint,
            rationale=rationale,
            details={
                "primary_name": primary.name,
                "secondary_name": secondary.name,
                "primary_aliases": json.dumps(primary.aliases, ensure_ascii=False),
                "secondary_aliases": json.dumps(secondary.aliases, ensure_ascii=False),
            },
            created_at=now,
            updated_at=now,
        )

    def _normalize(self, text: str) -> str:
        value = re.sub(r"[\s]+", " ", (text or "").strip().lower())
        return re.sub(r"[._,\-]", "", value)

    def _build_split_candidate(self, entity: Entity) -> GovernanceCandidate | None:
        monitored_predicates = ("role", "affiliation", "location", "email")
        current_facts = self.storage.get_current_facts(entity.id)
        if len(current_facts) < 2:
            return None

        conflicting_values: dict[str, list[str]] = {}
        supporting_fact_ids: set[str] = set()
        for predicate in monitored_predicates:
            normalized_to_raw: dict[str, str] = {}
            predicate_fact_ids: set[str] = set()
            for fact in current_facts:
                if fact.predicate != predicate:
                    continue
                normalized = self._normalize(fact.object)
                if not normalized:
                    continue
                normalized_to_raw.setdefault(normalized, fact.object)
                predicate_fact_ids.add(fact.id)
            if len(normalized_to_raw) >= 2:
                conflicting_values[predicate] = [
                    normalized_to_raw[key]
                    for key in sorted(normalized_to_raw)
                ]
                supporting_fact_ids.update(predicate_fact_ids)

        if not conflicting_values:
            return None

        fingerprint = hashlib.sha256(
            (
                f"split|{entity.id}|"
                f"{json.dumps(conflicting_values, sort_keys=True, ensure_ascii=False)}"
            ).encode("utf-8", errors="replace")
        ).hexdigest()[:24]
        now = datetime.now()
        score = min(0.8 + (0.05 * (len(conflicting_values) - 1)), 0.95)
        return GovernanceCandidate(
            candidate_type=GovernanceCandidateType.SPLIT,
            status=GovernanceCandidateStatus.OPEN,
            entity_id=entity.id,
            score=score,
            fingerprint=fingerprint,
            rationale="entity has conflicting monitored facts that may indicate mixed identity",
            details={
                "entity_name": entity.name,
                "conflicting_predicates": ",".join(sorted(conflicting_values)),
                "conflicting_values": json.dumps(
                    conflicting_values,
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "supporting_fact_ids": json.dumps(sorted(supporting_fact_ids)),
                "suggested_action": "review entity for manual split",
            },
            created_at=now,
            updated_at=now,
        )

    def _cancel_redundant_alias_candidates(
        self,
        merge_candidate: GovernanceCandidate,
        *,
        resolved_by: str,
    ) -> None:
        primary = self.storage.get_entity(merge_candidate.entity_id)
        if primary is None:
            return
        rows = self.storage.list_governance_candidates(limit=5000)
        for row in rows:
            if row.candidate_type is not GovernanceCandidateType.ALIAS:
                continue
            if row.status is not GovernanceCandidateStatus.OPEN:
                continue
            if row.entity_id != merge_candidate.entity_id:
                continue
            if (row.proposed_alias or "").strip() not in primary.aliases:
                continue
            self.storage.resolve_governance_candidate(
                row.id,
                status=GovernanceCandidateStatus.CANCELLED,
                resolved_by=resolved_by,
            )
