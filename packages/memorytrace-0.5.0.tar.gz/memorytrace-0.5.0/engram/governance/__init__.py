"""Entity governance workflows."""

from .service import EntityGovernanceService

__all__ = ["EntityGovernanceService"]
