"""AuditLogger — structured, immutable audit log for every pipeline request.

Each request gets a unique trace_id. Every pipeline stage records its outcome
into the AuditEntry. On completion, the full entry is emitted as structured
JSON to Python logging (and optionally to a file for SIEM/Splunk/ELK export).

faz has no agent identity; the only caller-attribution recorded is the
`transport` field (mcp/stdio | rest/local | cli).

Usage in the pipeline:
    audit = AuditLogger()
    entry = audit.create_entry(trace_id, transport="mcp/stdio")
    audit.record_auth(entry, method="TRANSPORT_TRUST", outcome="PASS")
    audit.record_safety(entry, rbac_outcome="PASS", table_access_decisions=[...])
    audit.emit(entry)
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .types import (
    ASTAudit,
    AuditEntry,
    AuthAudit,
    ExecutionAudit,
    InjectionAudit,
    RBACaudit,
    ResultAudit,
    TableAccessDecision,
)

logger = logging.getLogger("faz.audit")


class AuditLogger:
    """Structured audit logger — one entry per request, correlated by trace_id.

    Emits immutable JSON entries to:
      1. Python logging (always)
      2. Append-only file (if audit_file is configured, OR a `.faz/`
         directory exists in cwd → defaults to ``.faz/audit.jsonl``).

    The default ``.faz/audit.jsonl`` makes ``faz logs --follow`` work
    without any extra environment configuration after ``faz init``.
    Pass ``audit_file=""`` (empty string) to opt out entirely.
    """

    def __init__(self, *, audit_file: str | None = None) -> None:
        if audit_file is not None:
            # Empty string is an explicit "no file" opt-out; non-empty
            # string is the literal path the caller wants.
            self._audit_file = audit_file or None
        elif Path(".faz").is_dir():
            self._audit_file = str(Path(".faz") / "audit.jsonl")
        else:
            self._audit_file = None

    @staticmethod
    def new_trace_id() -> str:
        return f"req_{uuid.uuid4().hex[:12]}"

    @staticmethod
    def create_entry(
        trace_id: str,
        *,
        transport: str = "",
        source_ip: str = "",
    ) -> AuditEntry:
        entry = AuditEntry(
            trace_id=trace_id,
            transport=transport,
            source_ip=source_ip,
        )
        entry.set_timestamp()
        return entry

    # ------------------------------------------------------------------
    # Stage recorders
    # ------------------------------------------------------------------

    @staticmethod
    def record_auth(
        entry: AuditEntry,
        *,
        method: str = "JWT",
        outcome: str = "PASS",
        roles: list[str] | None = None,
        error: str = "",
        latency_ms: float = 0.0,
    ) -> None:
        entry.auth = AuthAudit(
            method=method,
            outcome=outcome,
            roles=roles or [],
            error=error,
        )
        entry.latency.auth_ms = latency_ms

    @staticmethod
    def record_safety(
        entry: AuditEntry,
        *,
        rbac_requested: list[str] | None = None,
        rbac_stripped: list[str] | None = None,
        rbac_outcome: str = "PASS",
        table_access_decisions: list[TableAccessDecision] | None = None,
        rbac_parse_error: str | None = None,
        ast_blocked: list[str] | None = None,
        ast_outcome: str = "PASS",
        injection_patterns: list[str] | None = None,
        injection_outcome: str = "PASS",
        latency_ms: float = 0.0,
    ) -> None:
        entry.rbac = RBACaudit(
            requested=rbac_requested or [],
            stripped=rbac_stripped or [],
            outcome=rbac_outcome,
            table_access_decisions=table_access_decisions or [],
            parse_error=rbac_parse_error,
        )
        entry.ast = ASTAudit(
            blocked_nodes=ast_blocked or [],
            outcome=ast_outcome,
        )
        entry.injection_scan = InjectionAudit(
            patterns_matched=injection_patterns or [],
            outcome=injection_outcome,
        )
        entry.latency.safety_ms = latency_ms

    @staticmethod
    def record_execution(
        entry: AuditEntry,
        *,
        sources_hit: list[str] | None = None,
        rows_loaded: dict[str, int] | None = None,
        merge_sql: str = "",
        merge_latency_ms: float = 0.0,
        iteration_count: int = 1,
        latency_ms: float = 0.0,
    ) -> None:
        entry.execution = ExecutionAudit(
            sources_hit=sources_hit or [],
            rows_loaded=rows_loaded or {},
            merge_sql=merge_sql,
            merge_latency_ms=merge_latency_ms,
            iteration_count=iteration_count,
        )
        entry.latency.execution_ms = latency_ms

    @staticmethod
    def record_result(
        entry: AuditEntry,
        *,
        rows_returned: int = 0,
        citations_attached: bool = False,
        error: str = "",
        latency_ms: float = 0.0,
    ) -> None:
        entry.result = ResultAudit(
            rows_returned=rows_returned,
            streamed_via="SSE",
            citations_attached=citations_attached,
            error=error,
        )
        entry.latency.response_ms = latency_ms

    @staticmethod
    def finalize(entry: AuditEntry) -> None:
        """Compute total latency from stage latencies."""
        lat = entry.latency
        lat.total_ms = (
            lat.auth_ms + lat.safety_ms + lat.execution_ms + lat.response_ms
        )

    # ------------------------------------------------------------------
    # Emit
    # ------------------------------------------------------------------

    def emit(self, entry: AuditEntry) -> dict[str, Any]:
        """Emit the audit entry as structured JSON. Returns the dict."""
        self.finalize(entry)
        data = asdict(entry)

        # Log as structured JSON
        logger.info(
            "AUDIT %s transport=%s total_ms=%.0f",
            entry.trace_id,
            entry.transport,
            entry.latency.total_ms,
            extra={"audit": data},
        )

        # Append to file if configured
        if self._audit_file:
            try:
                with open(self._audit_file, "a") as f:
                    f.write(json.dumps(data, default=str) + "\n")
            except OSError as e:
                logger.warning("Failed to write audit file: %s", e)

        return data
