"""``faz logs`` — pretty-print or tail the audit JSONL.

Default path is ``.faz/audit.jsonl`` (matching ``AuditLogger``'s
default when ``.faz/`` exists in cwd). ``--follow`` survives file
rotation by watching the inode.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import click


_DEFAULT_PATH = Path(".faz") / "audit.jsonl"


@click.command("logs")
@click.option(
    "--follow", "-f", is_flag=True,
    help="Tail the file: print new lines as they're appended.",
)
@click.option(
    "--path", "path_", default=str(_DEFAULT_PATH), show_default=True,
    help="Audit JSONL file. Override with FAZ_AUDIT_LOG when faz serve writes elsewhere.",
)
def logs_cmd(follow: bool, path_: str) -> None:
    """Tail or print the faz audit log."""
    path = Path(path_)

    if not path.exists():
        raise click.ClickException(
            f"no audit log at {path}. Run `faz init` to create .faz/, or "
            "set FAZ_AUDIT_LOG=<path> when starting `faz serve`."
        )

    if follow:
        _tail(path)
    else:
        with path.open() as fh:
            for line in fh:
                _print_line(line)


def _tail(path: Path) -> None:
    """`tail -F` semantics: print existing content, then watch for new lines.

    Survives rotation: if the file is replaced (different inode) we
    reopen it. Polling-based — fine for the volumes a single faz
    instance produces.
    """
    fh = path.open()
    inode = path.stat().st_ino
    # Print everything that's already there.
    for line in fh:
        _print_line(line)
    try:
        while True:
            line = fh.readline()
            if line:
                _print_line(line)
                continue
            time.sleep(0.25)
            try:
                new_inode = path.stat().st_ino
            except FileNotFoundError:
                # File was rotated away; wait for it to come back.
                continue
            if new_inode != inode:
                fh.close()
                fh = path.open()
                inode = new_inode
    except KeyboardInterrupt:
        click.echo("", err=True)
    finally:
        fh.close()


def _print_line(line: str) -> None:
    """Format one audit JSON entry as a compact human-readable row."""
    line = line.strip()
    if not line:
        return
    try:
        entry = json.loads(line)
    except json.JSONDecodeError:
        click.echo(line)  # malformed — pass through verbatim
        return

    trace = entry.get("trace_id", "?")
    transport = entry.get("transport", "?")
    rbac = entry.get("rbac", {}).get("outcome", "?")
    ast = entry.get("ast", {}).get("outcome", "?")
    inj = entry.get("injection_scan", {}).get("outcome", "?")
    rows = entry.get("result", {}).get("rows_returned", 0)
    error = entry.get("result", {}).get("error", "")
    total = entry.get("latency", {}).get("total_ms", 0)

    head = f"{trace}  [{transport:<10}]  rbac={rbac} ast={ast} inj={inj}  rows={rows}  total={total:.0f}ms"
    click.echo(head)
    if error:
        click.echo(f"    error: {error}")
