"""``faz test`` — exercise the safety pipeline against the user's live config.

Standalone: builds the faz runtime in-process (no ``faz serve`` needed)
and calls the handler functions directly. Pays the ~5-10s connector-init
cost once at startup.

Per DB, the test runs four probes whose expected outcome is **derived
from the policy**:

  1. **Reachable** — straight from ``handlers.list_databases``.
  2. **Read probe** — first discovered table, language-idiomatic
     ``SELECT``. Expected to pass when the policy grants R / RW / RA /
     RWA / A; expected to be blocked at ``RBAC_GATE`` otherwise.
     Skipped on vector DBs (a real vector search needs an embedding
     dimension we don't know).
  3. **Write probe** — INSERT-style request against synthetic name
     ``faz_synthetic_does_not_exist``. Expected to be blocked at
     ``RBAC_GATE`` when the policy doesn't permit writes; expected to
     be allowed by the safety pipeline (HandlerError with
     "table not found"-ish detail OR a successful envelope) when
     writes ARE permitted.
  4. **DDL probe** — DROP-style request against synthetic name.
     Blocked at ``RBAC_GATE`` / ``AST_CHECKER`` for any baseline below
     ``AccessMode.A``. When the baseline is ``A``, the safety pipeline
     lets DDL through (the connector then errors on the synthetic name).

**Safety story**: write + DDL probes target the synthetic name
``faz_synthetic_does_not_exist`` so even if the safety pipeline let
them through, no real user data is at risk:

  * For schema-on-read DBs (postgres / mysql / oracle / cassandra /
    es / opensearch / dynamodb), the connector errors with
    "table/index not found" — no mutation happens.
  * For schema-on-write DBs (**mongodb / couchdb**), if the user's
    policy permits writes, the connector WILL create an empty
    ``faz_synthetic_does_not_exist`` collection holding a single
    ``{"_faz_test": true}`` doc. This is the accepted side effect
    of having writes enabled. Drop the collection manually if you
    don't want it; it has no effect on faz operation.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

import click

from faz.api import handlers
from faz.api.handlers import HandlerError
from faz.api.schemas import SimpleQueryRequest
from faz.runtime import Runtime, build_runtime, resolve_config_path, shutdown_runtime
from faz.safety.types import ACCESS_MODE_ALLOWED, AccessMode


# `faz test` deliberately runs blocked probes — every one emits a
# WARN-level safety log ("RBAC Gate: every step denied..."). They're
# noise here because being blocked IS the test passing. Quiet them.
for _noisy in ("faz.safety.rbac_gate", "faz.safety.pipeline",
               "faz.safety.ast_checker", "faz.safety.injection_analyser"):
    logging.getLogger(_noisy).setLevel(logging.ERROR)


_SYNTH = "faz_synthetic_does_not_exist"


# Per-connector-type recipe.
#   read_q(t)  → SELECT-style query body for table `t`. None = skip read probe.
#   write_q    → INSERT-style query body. ALWAYS targets `_SYNTH`.
#   ddl_q      → DROP-style query body. ALWAYS targets `_SYNTH`.
_RECIPES: dict[str, dict[str, Any]] = {
    "postgresql":   {"language": "sql",
                     "read_q":  lambda t: f'SELECT * FROM "{t}" LIMIT 1',
                     "write_q": f"INSERT INTO {_SYNTH} (id) VALUES (1)",
                     "ddl_q":   f"DROP TABLE {_SYNTH}"},
    "mysql":        {"language": "sql",
                     "read_q":  lambda t: f"SELECT * FROM `{t}` LIMIT 1",
                     "write_q": f"INSERT INTO {_SYNTH} (id) VALUES (1)",
                     "ddl_q":   f"DROP TABLE {_SYNTH}"},
    "oracle":       {"language": "sql",
                     "read_q":  lambda t: f'SELECT * FROM "{t}" WHERE ROWNUM <= 1',
                     "write_q": f"INSERT INTO {_SYNTH} (id) VALUES (1)",
                     "ddl_q":   f"DROP TABLE {_SYNTH}"},
    "cassandra":    {"language": "sql",
                     "read_q":  lambda t: f"SELECT * FROM {t} LIMIT 1",
                     "write_q": f"INSERT INTO {_SYNTH} (id) VALUES (1)",
                     "ddl_q":   f"DROP TABLE {_SYNTH}"},
    "mongodb":      {"language": "mql",
                     "read_q":  lambda t: json.dumps(
                         {"operation": "find", "filter": {}, "limit": 1}),
                     "write_q": json.dumps(
                         {"operation": "insertOne", "collection": _SYNTH,
                          "document": {"_faz_test": True}}),
                     "ddl_q":   json.dumps(
                         {"operation": "dropCollection", "collection": _SYNTH})},
    "couchdb":      {"language": "couchdb",
                     "read_q":  lambda t: json.dumps(
                         {"operation": "find", "selector": {}, "limit": 1}),
                     "write_q": json.dumps(
                         {"operation": "insertOne", "collection": _SYNTH,
                          "document": {"_faz_test": True}}),
                     "ddl_q":   json.dumps(
                         {"operation": "dropCollection", "collection": _SYNTH})},
    "elasticsearch": {"language": "es_dsl",
                      "read_q": lambda t: json.dumps(
                          {"query": {"match_all": {}}, "size": 1}),
                      "write_q": json.dumps(
                          {"method": "POST", "path": f"/{_SYNTH}/_doc",
                           "body": {"_faz_test": True}}),
                      "ddl_q":  json.dumps(
                          {"method": "DELETE", "path": f"/{_SYNTH}"})},
    "opensearch":   {"language": "es_dsl",
                     "read_q":  lambda t: json.dumps(
                         {"query": {"match_all": {}}, "size": 1}),
                     "write_q": json.dumps(
                         {"method": "POST", "path": f"/{_SYNTH}/_doc",
                          "body": {"_faz_test": True}}),
                     "ddl_q":   json.dumps(
                         {"method": "DELETE", "path": f"/{_SYNTH}"})},
    "dynamodb":     {"language": "dynamo",
                     "read_q":  lambda t: json.dumps(
                         {"verb": "Scan", "TableName": t, "Limit": 1}),
                     "write_q": json.dumps(
                         {"verb": "PutItem", "TableName": _SYNTH,
                          "Item": {"id": {"S": "_faz_test"}}}),
                     "ddl_q":   json.dumps(
                         {"verb": "DeleteTable", "TableName": _SYNTH})},
    "neo4j":        {"language": "cypher",
                     "read_q":  lambda t: f"MATCH (n:{t}) RETURN n LIMIT 1",
                     "write_q": f"CREATE (n:{_SYNTH} {{id: 1}}) RETURN n",
                     "ddl_q":   f"DROP INDEX {_SYNTH}_idx"},
    # Vector — no read probe (needs an embedding dim).
    "weaviate":     {"language": "vector", "read_q": None,
                     "write_q": json.dumps({"intent": "upsert"}),
                     "ddl_q":   json.dumps({"intent": "delete_collection"})},
    "qdrant":       {"language": "vector", "read_q": None,
                     "write_q": json.dumps({"intent": "upsert"}),
                     "ddl_q":   json.dumps({"intent": "delete_collection"})},
    "milvus":       {"language": "vector", "read_q": None,
                     "write_q": json.dumps({"intent": "insert"}),
                     "ddl_q":   json.dumps({"intent": "drop_collection"})},
    "pinecone":     {"language": "vector", "read_q": None,
                     "write_q": json.dumps({"intent": "upsert"}),
                     "ddl_q":   json.dumps({"intent": "delete_index"})},
}


@click.command("test")
def test_cmd() -> None:
    """Exercise faz's safety pipeline against every configured database.

    Standalone — builds a runtime, runs the probes, shuts down. Doesn't
    need ``faz serve``. Probe outcomes are matched against the loaded
    permission policy (faz.yaml). Write/DDL probes target a synthetic
    ``faz_synthetic_does_not_exist`` name — see module docstring for
    the safety story.
    """
    exit_code = asyncio.run(_run())
    if exit_code:
        raise click.exceptions.Exit(code=exit_code)


async def _run() -> int:
    rt = await build_runtime(resolve_config_path())
    try:
        return await _run_probes(rt)
    finally:
        await shutdown_runtime(rt)


async def _run_probes(rt: Runtime) -> int:
    passes = fails = 0

    # Server-level probes — pass size large enough to fetch every DB in one
    # page so faz test sees the full configured set without iterating.
    db_envelope = await handlers.list_databases(
        rt.registry, page=1, size=len(rt.registry.configured_names) or 1,
    )
    databases = db_envelope.get("databases") or []
    _print_probe(
        "list_databases", True, f"{len(databases)} configured",
    )
    passes += 1

    click.echo()
    click.echo(f"Per-DB safety probes  ({len(databases)} configured)")

    for db in databases:
        name = db["name"]
        type_ = db.get("type", "")

        baseline = _lookup_baseline(rt, name)
        baseline_str = baseline.value if baseline else "<none>"
        click.echo(f"  {name} ({type_})  — policy: {baseline_str}")

        # 1. Reachable?
        ok = bool(db.get("reachable"))
        msg = (
            db.get("error") or db.get("schema_error") or "down"
            if not ok else f"{len(db.get('tables') or [])} tables"
        )
        _print_probe("reachable", ok, msg, indent="    ")
        passes, fails = _tally(ok, passes, fails)
        if not ok:
            continue

        recipe = _RECIPES.get(type_)
        if recipe is None:
            click.echo(f"    (no probes registered for type={type_!r}; skipping)")
            continue

        # 2. Read probe — REAL discovered table name.
        read_q: Callable[[str], str] | None = recipe["read_q"]
        if read_q is not None:
            tables = db.get("tables") or []
            if not tables:
                click.echo("    (no tables discovered; skipping read probe)")
            else:
                table_name = tables[0]["name"]
                read_allowed = _policy_allows(baseline, "SELECT")
                ok, detail = await _check_op(
                    rt, name, table_name, recipe["language"], read_q(table_name),
                    expected_allowed=read_allowed,
                )
                expectation = "allowed" if read_allowed else "blocked"
                _print_probe(
                    f"read on {table_name!r} ({expectation})",
                    ok, detail, indent="    ",
                )
                passes, fails = _tally(ok, passes, fails)

        # Some connectors (Cassandra) discover tables as
        # ``<keyspace>.<table>`` and reject writes that aren't
        # keyspace-qualified. Qualify the synthetic name with the same
        # prefix so write/DDL probes don't fail with "no keyspace
        # specified" before the connector even tries the operation.
        synth = _qualify_synth(_SYNTH, db.get("tables") or [])
        write_q = (
            recipe["write_q"].replace(_SYNTH, synth)
            if isinstance(recipe["write_q"], str) else recipe["write_q"]
        )
        ddl_q = (
            recipe["ddl_q"].replace(_SYNTH, synth)
            if isinstance(recipe["ddl_q"], str) else recipe["ddl_q"]
        )

        # 3. Write probe.
        write_allowed = _policy_allows(baseline, "INSERT")
        ok, detail = await _check_op(
            rt, name, synth, recipe["language"], write_q,
            expected_allowed=write_allowed,
        )
        expectation = "allowed" if write_allowed else "blocked"
        _print_probe(
            f"write {expectation} (target={synth})",
            ok, detail, indent="    ",
        )
        passes, fails = _tally(ok, passes, fails)

        # 4. DDL probe — synthetic name. Allowed under AccessMode.A;
        # blocked at RBAC_GATE / AST_CHECKER otherwise.
        ddl_allowed = baseline == AccessMode.A
        ok, detail = await _check_op(
            rt, name, synth, recipe["language"], ddl_q,
            expected_allowed=ddl_allowed,
            expected_stages={"RBAC_GATE", "AST_CHECKER"},
        )
        ddl_label = "allowed" if ddl_allowed else "blocked"
        _print_probe(
            f"DDL {ddl_label} (target={synth})", ok, detail, indent="    ",
        )
        passes, fails = _tally(ok, passes, fails)

    click.echo()
    click.echo(f"  {passes}/{passes + fails} probes passed.")
    return 1 if fails else 0


# ---------------------------------------------------------------------------
# Policy lookup
# ---------------------------------------------------------------------------


def _lookup_baseline(rt: Runtime, database: str) -> AccessMode | None:
    """Return the per-database baseline (table_name == "*") if any."""
    for p in rt.policy.permissions:
        if p.database_uri == database and p.table_name == "*":
            return p.access_level
    return None


def _policy_allows(level: AccessMode | None, op: str) -> bool:
    """True if `level` permits `op` (op ∈ SELECT / INSERT / UPDATE / DELETE / DDL)."""
    if level is None:
        return False
    return op in ACCESS_MODE_ALLOWED.get(level, set())


# ---------------------------------------------------------------------------
# Probe runner — calls handlers.query_simple in-process
# ---------------------------------------------------------------------------


async def _check_op(
    rt: Runtime, database: str, table: str, language: str, query: str,
    *, expected_allowed: bool,
    expected_stages: set[str] | None = None,
) -> tuple[bool, str]:
    """Run a probe through the in-process safety pipeline + connector.

    ``expected_allowed=True``:
      * Handler returns success → pass.
      * Handler raises HandlerError(500) with "not found"-ish detail →
        also pass (proves safety let it through; the connector caught
        the synthetic name).
      * Anything else → fail.

    ``expected_allowed=False``:
      * Handler raises HandlerError(403) with stage in
        ``expected_stages`` (default ``{RBAC_GATE}``) → pass.
      * Anything else → fail.
    """
    body = SimpleQueryRequest(
        database=database, table=table, language=language, query=query,
    )
    try:
        await handlers.query_simple(
            body,
            registry=rt.registry, policy=rt.policy, pipeline=rt.pipeline,
            engine=rt.engine, scratchpads=rt.scratchpads, audit=rt.audit,
            transport="cli",
        )
    except HandlerError as exc:
        return _interpret_handler_error(exc, expected_allowed, expected_stages)
    except Exception as exc:  # noqa: BLE001 — defensive
        return False, f"unexpected exception: {type(exc).__name__}: {exc}"

    # Handler returned success.
    if expected_allowed:
        return True, "allowed"
    return False, "expected blocked, got 200 OK"


def _interpret_handler_error(
    exc: HandlerError,
    expected_allowed: bool,
    expected_stages: set[str] | None,
) -> tuple[bool, str]:
    """Map a HandlerError to the (ok, detail) tuple the probe expects."""
    detail = exc.detail
    detail_text = (
        json.dumps(detail, default=str).lower()
        if isinstance(detail, (dict, list))
        else str(detail).lower()
    )
    # Some drivers (pymysql, cassandra-driver) ``str()`` their exception
    # args, which double- and triple-escapes apostrophes when the message
    # then gets json-serialized again upstream. Strip all backslashes so
    # the marker-substring scan doesn't miss "doesn't exist" because it
    # rendered as "doesn\\\\'t exist" four levels deep.
    detail_text = detail_text.replace("\\", "")

    if expected_allowed:
        # 500 with "table-not-found"-ish error means safety let it through;
        # the connector caught the synthetic name. Counts as pass.
        if exc.status_code == 500:
            for marker in ("not exist", "not found", "no such", "doesn't exist",
                           "unknown table", "no table", "undefined table",
                           "missing table", "unconfigured", "not a table",
                           # AWS DynamoDB
                           "resourcenotfoundexception",
                           # Cassandra (CQL): "unconfigured table" / "table … does not exist"
                           "unconfigured table", "does not exist"):
                if marker in detail_text:
                    return True, "allowed (connector caught synthetic name)"
            return False, f"500 but error didn't look like 'not found': {str(detail)[:160]}"
        return False, f"expected allowed, got HandlerError({exc.status_code}): {str(detail)[:160]}"

    # expected_allowed=False
    if expected_stages is None:
        expected_stages = {"RBAC_GATE"}
    if exc.status_code != 403:
        return False, f"expected 403, got {exc.status_code}"
    err = (detail or {}).get("error") if isinstance(detail, dict) else None
    stage = (err or {}).get("stage")
    if stage in expected_stages:
        return True, f"at {stage}"
    return False, f"blocked at {stage!r}, expected {sorted(expected_stages)}"


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _qualify_synth(synth: str, tables: list[dict[str, Any]]) -> str:
    """Prefix the synthetic name with a schema/keyspace if the discovered
    tables are namespace-qualified.

    Example: cassandra discovery returns ``acme.activity_log``; we
    qualify the synthetic ``faz_synthetic_does_not_exist`` to
    ``acme.faz_synthetic_does_not_exist`` so writes don't fail with
    "no keyspace specified". For postgres / mysql / etc. where
    discovery returns bare table names, the synthetic stays unqualified.
    """
    if not tables:
        return synth
    first = (tables[0] or {}).get("name", "")
    if "." in first:
        prefix = first.split(".", 1)[0]
        return f"{prefix}.{synth}"
    return synth


def _print_probe(label: str, ok: bool, detail: str, indent: str = "") -> None:
    marker = click.style("✓", fg="green") if ok else click.style("✗", fg="red")
    click.echo(f"{indent}{marker} {label}{(' — ' + detail) if detail else ''}")


def _tally(ok: bool, passes: int, fails: int) -> tuple[int, int]:
    return (passes + 1, fails) if ok else (passes, fails + 1)
