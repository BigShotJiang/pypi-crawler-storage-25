"""Neo4j Cypher access target extractor.

Cypher has no "tables" — its scope units are node labels and relationship
types. The extractor scans the query for:

  - Node patterns: `(var:Label)`, `(:Label)`, `(var:Label1:Label2)`
  - Relationship patterns: `[var:RELTYPE]`, `[:RELTYPE]`, `[var:R1|R2]`

Each label or relationship type emits an AccessTarget. The op is
determined per-clause:

  - MATCH / OPTIONAL MATCH / RETURN / WITH (read clauses)   → SELECT
  - CREATE / MERGE                                          → INSERT
  - SET / REMOVE                                            → UPDATE
  - DELETE / DETACH DELETE                                  → DELETE

Variable rebinding (DETACH DELETE p where p was matched as :Post) is
resolved by tracking variable→labels bindings during the parse.

APOC procs:
  - Allowlist of read-only namespaces: apoc.coll.*, apoc.text.*,
    apoc.convert.*, apoc.date.*, apoc.math.*, apoc.number.*,
    apoc.json.*, apoc.map.*, apoc.string.*
  - Anything else (apoc.cypher.runWrite, apoc.schema.*, apoc.create.*,
    apoc.do.*, apoc.refactor.*, apoc.export.*, apoc.import.*) → DDL.

Phase 1 implementation: regex-based pass + a small clause splitter. A real
parser is a Phase 7 hardening item.
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


# Match (var:Label) / (var:Label1:Label2) / (:Label).
# var is optional; labels can chain with `:`. Captures the whole label run.
_NODE_PATTERN = re.compile(
    r"\(\s*([A-Za-z_][\w]*)?\s*((?::[A-Za-z_][\w]*)+)\s*[^)]*\)",
)

# Native Cypher DDL — index / constraint / database / role / user mgmt.
# These are policy-independent: even ``AccessMode.A`` doesn't permit
# ``Op.DDL``, so RBACGate / AST_CHECKER will block once we mark the op.
_DDL_HEAD = re.compile(
    r"^\s*(?:CREATE|DROP|ALTER)\s+"
    r"(?:INDEX|CONSTRAINT|DATABASE|USER|ROLE|FULLTEXT|TEXT|RANGE|POINT|LOOKUP)\b",
    re.IGNORECASE,
)

# Match relationship pattern -[var:TYPE]- / -[:TYPE1|TYPE2]-.
_REL_PATTERN = re.compile(
    r"\[\s*([A-Za-z_][\w]*)?\s*((?::[A-Za-z_][\w|]*)+)\s*[^]]*\]",
)

# Variable→labels binding, populated as MATCH clauses are scanned.
# A variable can be bound to multiple labels (`(p:Post:Article)`).

# APOC read-only allowlist (matches procedure name prefix).
_APOC_READ_PREFIXES: tuple[str, ...] = (
    "apoc.coll.", "apoc.text.", "apoc.convert.", "apoc.date.",
    "apoc.math.", "apoc.number.", "apoc.json.", "apoc.map.", "apoc.string.",
    "apoc.util.",
)


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    if not raw_query or not raw_query.strip():
        return [_target(step, step.table or "", Op.SELECT)]

    query = _strip_comments(raw_query)

    # Schema DDL: ``CREATE INDEX``, ``DROP INDEX``, ``CREATE CONSTRAINT``,
    # ``DROP CONSTRAINT``, ``ALTER …``, ``CREATE DATABASE`` etc. These are
    # not parseable as MATCH-style clauses and would otherwise fall through
    # the clause walker as ``Op.SELECT``. Match the leading verb pair with
    # a case-insensitive regex so it survives whitespace / comments.
    if _DDL_HEAD.match(query):
        return [_target(step, step.table or "", Op.DDL)]

    # APOC scan — if any APOC proc is called outside the allowlist,
    # treat the whole call as DDL (admin-only).
    apoc_targets = _apoc_targets(step, query)
    if apoc_targets:
        return apoc_targets

    # Walk clauses left-to-right. Each clause produces an op and a set of
    # labels/rel-types either declared inline or referenced by variable.
    clauses = _split_clauses(query)

    # var → set of labels (collected from MATCH, CREATE, MERGE clauses)
    bindings: dict[str, set[str]] = {}

    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()

    def _add(label: str, op: Op) -> None:
        key = (step.database or "", label, op)
        if not label or key in seen:
            return
        seen.add(key)
        out.append(_target(step, label, op))

    for verb, body in clauses:
        op = _CLAUSE_OPS.get(verb)
        if op is None:
            continue

        # Scan node patterns in this clause.
        for m in _NODE_PATTERN.finditer(body):
            var, labels_run = m.group(1), m.group(2)
            labels = [l for l in labels_run.split(":") if l]
            if var:
                bindings.setdefault(var, set()).update(labels)
            for lbl in labels:
                _add(lbl, op)

        # Scan relationship patterns in this clause.
        for m in _REL_PATTERN.finditer(body):
            var, types_run = m.group(1), m.group(2)
            # Rel types can be alternates separated by `|`.
            types = [t for t in re.split(r"[:|]", types_run) if t]
            if var:
                bindings.setdefault(var, set()).update(types)
            for typ in types:
                _add(typ, op)

        # Bare variable references in DELETE / DETACH DELETE / SET / REMOVE:
        # `MATCH (p:Post) DETACH DELETE p`.
        for var in _bare_var_refs(body):
            for lbl in bindings.get(var, ()):
                _add(lbl, op)

    if not out:
        # Parse produced no targets — declared SELECT.
        out.append(_target(step, step.table or "", Op.SELECT))
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_CLAUSE_OPS: dict[str, Op] = {
    # Read clauses
    "MATCH": Op.SELECT,
    "OPTIONAL MATCH": Op.SELECT,
    "WITH": Op.SELECT,
    "RETURN": Op.SELECT,
    "UNWIND": Op.SELECT,
    "CALL": Op.SELECT,             # default; APOC scan above overrides for non-allowlisted
    # Write clauses
    "CREATE": Op.INSERT,
    "MERGE": Op.INSERT,
    "SET": Op.UPDATE,
    "REMOVE": Op.UPDATE,
    "DELETE": Op.DELETE,
    "DETACH DELETE": Op.DELETE,
    "FOREACH": Op.UPDATE,          # FOREACH may CREATE/SET/DELETE inside; conservative
}

# Order matters: longer phrases first so "DETACH DELETE" is split correctly
# before "DELETE".
_CLAUSE_KEYWORDS: tuple[str, ...] = (
    "OPTIONAL MATCH", "DETACH DELETE",
    "MATCH", "CREATE", "MERGE", "SET", "REMOVE", "DELETE",
    "RETURN", "WITH", "UNWIND", "CALL", "FOREACH",
)


def _split_clauses(query: str) -> list[tuple[str, str]]:
    """Split a Cypher query into (clause_keyword, clause_body) tuples.

    Naive but adequate for Phase 1: case-insensitive prefix scan.
    """
    text = query
    out: list[tuple[str, str]] = []

    # Build a regex that captures every clause boundary.
    pattern = re.compile(
        r"(?i)\b(" + "|".join(re.escape(k) for k in _CLAUSE_KEYWORDS) + r")\b"
    )

    matches = list(pattern.finditer(text))
    if not matches:
        return out

    for i, m in enumerate(matches):
        verb = m.group(1).upper().replace("  ", " ")
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        out.append((verb, text[start:end]))

    return out


def _strip_comments(query: str) -> str:
    """Remove // line comments and /* block */ comments."""
    query = re.sub(r"/\*.*?\*/", " ", query, flags=re.DOTALL)
    query = re.sub(r"//[^\n]*", " ", query)
    return query


def _bare_var_refs(body: str) -> list[str]:
    """Extract bare variable identifiers from a clause body.

    Used to resolve `DETACH DELETE p` where `p` was bound earlier. Returns
    a list of identifiers, deduplicated, in source order.
    """
    # Strip out node and relationship patterns first so labels inside them
    # don't show up as "bare" variables.
    clean = re.sub(r"\([^)]*\)", " ", body)
    clean = re.sub(r"\[[^\]]*\]", " ", clean)
    out: list[str] = []
    seen: set[str] = set()
    for m in re.finditer(r"\b([A-Za-z_][\w]*)\b", clean):
        ident = m.group(1)
        # Skip Cypher keywords / common helpers that aren't variables.
        if ident.upper() in _CYPHER_KEYWORDS:
            continue
        if ident not in seen:
            seen.add(ident)
            out.append(ident)
    return out


_CYPHER_KEYWORDS: set[str] = {
    "AS", "AND", "OR", "NOT", "IN", "IS", "NULL", "TRUE", "FALSE",
    "CASE", "WHEN", "THEN", "ELSE", "END", "BY", "ASC", "DESC",
    "LIMIT", "SKIP", "ORDER", "DISTINCT", "ON", "INTO", "FROM",
    "EXISTS", "WHERE", "STARTS", "ENDS", "CONTAINS",
}


def _apoc_targets(step: "IRStep", query: str) -> list[AccessTarget]:
    """If the query calls APOC, decide whether to allow or DDL-block.

    Returns a list of targets if a non-allowlisted APOC proc is called,
    indicating the whole query should be blocked. Returns [] if APOC is
    absent or only allowlisted procs are used (so the normal clause walk
    proceeds).
    """
    apoc_calls = re.findall(r"\bapoc\.[A-Za-z_][\w.]*", query, flags=re.IGNORECASE)
    if not apoc_calls:
        return []
    for call in apoc_calls:
        call_l = call.lower()
        if not any(call_l.startswith(p) for p in _APOC_READ_PREFIXES):
            return [_target(step, step.table or "apoc", Op.DDL)]
    return []


def _target(step: "IRStep", label: str, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=label,
        operation=op,
    )
