"""Elasticsearch / OpenSearch access target extractor.

Request shape (chosen for faz internal use; agents send this as `raw_query`):

    {"method": "POST",
     "path":   "/app_logs/_search",
     "body":   {...optional, parsed for _bulk/_msearch/_reindex...}}

Method + path mapping:
    /<index>/_search, /_msearch, /<index>/_count        → R per index
    /<index>/_doc, /<index>/_doc/{id},
        /<index>/_update, /<index>/_delete_by_query     → W per index
    /_bulk                                              → fan out per NDJSON line
    /_reindex                                           → R on src + W on dst
    /<index>/_template, /<index>/_settings (PUT),
        /<index>/_mapping (PUT), DELETE /<index>        → DDL

`_bulk` body is NDJSON: alternating action lines + (optional) source lines.
Each action header gives `{op: {_index: "..."}}` where op is one of
index/create/update/delete. Each gets its own AccessTarget.

`_msearch` body is NDJSON: alternating `{"index": "..."}` headers + body
lines. Each header → SELECT.

`_reindex` body is JSON: `{"source": {"index": "src"}, "dest": {"index": "dst"}}`.
Emits (src, SELECT) AND (dst, INSERT).
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


_DDL_ENDPOINTS: tuple[str, ...] = (
    "_template", "_index_template", "_settings", "_mapping",
    "_close", "_open", "_aliases",
)


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    if not raw_query or not raw_query.strip():
        return [_target(step, step.table or "", Op.SELECT)]

    try:
        body = json.loads(raw_query)
    except json.JSONDecodeError:
        return [_target(step, step.table or "", Op.DDL)]

    if not isinstance(body, dict):
        return [_target(step, step.table or "", Op.DDL)]

    method = (body.get("method") or "GET").upper()
    path = body.get("path") or ""
    inner = body.get("body")

    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()

    def _add(idx: str, op: Op) -> None:
        key = (step.database or "", idx or step.table or "", op)
        if key in seen:
            return
        seen.add(key)
        out.append(_target(step, idx, op))

    # Strip leading slash and split path.
    parts = [p for p in path.strip("/").split("/") if p]
    if not parts:
        # Root path — treat as cluster info read.
        _add(step.table or "_root", Op.SELECT)
        return out

    # Top-level endpoints (no index prefix).
    head = parts[0]
    if head == "_bulk":
        return _bulk(step, inner) or [_target(step, step.table or "", Op.SELECT)]
    if head == "_msearch":
        return _msearch(step, inner) or [_target(step, step.table or "", Op.SELECT)]
    if head == "_reindex":
        return _reindex(step, inner) or [_target(step, step.table or "", Op.DDL)]

    # Path begins with an index name (or comma-separated list).
    indexes_raw = parts[0]
    indexes = [i for i in indexes_raw.split(",") if i and not i.startswith("_")]
    rest = parts[1:]

    # If the index slot itself is a path-level operation (e.g. /_cat/indices),
    # treat as a SELECT cluster read.
    if not indexes:
        _add(step.table or "_cluster", Op.SELECT)
        return out

    endpoint = rest[0] if rest else ""

    # DELETE on a whole index → DDL.
    if not endpoint and method == "DELETE":
        for idx in indexes:
            _add(idx, Op.DDL)
        return out

    # Schema/template endpoints → DDL.
    if endpoint in _DDL_ENDPOINTS or any(p in _DDL_ENDPOINTS for p in rest):
        for idx in indexes:
            _add(idx, Op.DDL)
        return out

    # Per-endpoint op mapping.
    if endpoint in ("_search", "_count"):
        for idx in indexes:
            _add(idx, Op.SELECT)
        return out

    if endpoint in ("_doc", "_create", "_source"):
        # POST /idx/_doc → INSERT; PUT /idx/_doc/{id} → INSERT/UPDATE
        op = Op.UPDATE if (method == "PUT" and len(rest) >= 2) else Op.INSERT
        for idx in indexes:
            _add(idx, op)
        return out

    if endpoint == "_update" or endpoint == "_update_by_query":
        for idx in indexes:
            _add(idx, Op.UPDATE)
        return out

    if endpoint == "_delete_by_query":
        for idx in indexes:
            _add(idx, Op.DELETE)
        return out

    # No recognized endpoint — default by HTTP method.
    if method in ("GET", "HEAD"):
        for idx in indexes:
            _add(idx, Op.SELECT)
    elif method in ("POST", "PUT", "PATCH"):
        for idx in indexes:
            _add(idx, Op.INSERT)
    elif method == "DELETE":
        for idx in indexes:
            _add(idx, Op.DELETE)
    else:
        for idx in indexes:
            _add(idx, Op.DDL)
    return out


# ---------------------------------------------------------------------------
# Body-aware helpers
# ---------------------------------------------------------------------------


_BULK_ACTION_OPS: dict[str, Op] = {
    "index": Op.INSERT,    # idempotent insert (creates or replaces)
    "create": Op.INSERT,
    "update": Op.UPDATE,
    "delete": Op.DELETE,
}


def _bulk(step: "IRStep", inner: Any) -> list[AccessTarget]:
    """Parse NDJSON `_bulk` body and emit one target per action line."""
    if inner is None:
        return []
    text = inner if isinstance(inner, str) else json.dumps(inner)

    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(entry, dict):
            continue
        # Action line: single key {op: {_index: "..."}}.
        for action, meta in entry.items():
            op = _BULK_ACTION_OPS.get(action.lower())
            if op is None:
                continue
            idx = (meta or {}).get("_index") if isinstance(meta, dict) else None
            idx = idx or step.table or ""
            key = (step.database or "", idx, op)
            if key in seen:
                continue
            seen.add(key)
            out.append(_target(step, idx, op))
            break  # action lines have exactly one op key
    return out


def _msearch(step: "IRStep", inner: Any) -> list[AccessTarget]:
    """Parse NDJSON `_msearch` body. Header lines: {"index": "..."}."""
    if inner is None:
        return []
    text = inner if isinstance(inner, str) else json.dumps(inner)

    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()
    expect_header = True
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if expect_header and isinstance(entry, dict):
            idx = entry.get("index")
            if isinstance(idx, list):
                for i in idx:
                    if isinstance(i, str):
                        key = (step.database or "", i, Op.SELECT)
                        if key not in seen:
                            seen.add(key)
                            out.append(_target(step, i, Op.SELECT))
            elif isinstance(idx, str):
                key = (step.database or "", idx, Op.SELECT)
                if key not in seen:
                    seen.add(key)
                    out.append(_target(step, idx, Op.SELECT))
        expect_header = not expect_header
    return out


def _reindex(step: "IRStep", inner: Any) -> list[AccessTarget]:
    """Parse `_reindex` body: emit (src, SELECT) AND (dst, INSERT)."""
    if not isinstance(inner, dict):
        return []
    out: list[AccessTarget] = []

    src = (inner.get("source") or {}).get("index") if isinstance(inner.get("source"), dict) else None
    dst = (inner.get("dest") or {}).get("index") if isinstance(inner.get("dest"), dict) else None

    # source.index can be a string or list.
    if isinstance(src, str):
        out.append(_target(step, src, Op.SELECT))
    elif isinstance(src, list):
        for i in src:
            if isinstance(i, str):
                out.append(_target(step, i, Op.SELECT))
    if isinstance(dst, str):
        out.append(_target(step, dst, Op.INSERT))

    return out


def _target(step: "IRStep", idx: str | None, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=(idx or step.table or ""),
        operation=op,
    )
