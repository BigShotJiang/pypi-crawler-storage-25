"""SQL access target extractor.

Walks a SQL/CQL/PartiQL AST and emits one `AccessTarget` per touched table.
Covers postgres / mysql / oracle / cassandra (CQL) / dynamodb (PartiQL).

Rules:
  - Top-level statement determines the primary op (SELECT, INSERT, UPDATE,
    DELETE, MERGE, or DDL for CREATE/DROP/ALTER/TRUNCATE/GRANT/REVOKE).
  - INSERT INTO x SELECT FROM y → (x, INSERT) AND (y, SELECT). Each touched
    table gets its own op based on the role it plays in the statement.
  - JOIN target tables in a SELECT → all touched as SELECT (declared target
    is just one of several).
  - UPDATE/DELETE that pulls from another table (Postgres FROM/USING) →
    primary table gets W-op, joined tables get SELECT.
  - CQL `BATCH … APPLY BATCH` → fan out one target per inner statement.
  - Schema-qualified names (`public.users`, `db.schema.users`) → strip
    schema prefix; the table portion is always the *last* identifier.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import sqlglot
from sqlglot import expressions as exp

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


# Connector name → sqlglot dialect hint. Falls back to None (auto-detect).
# Cassandra is intentionally absent — sqlglot has no `cassandra` dialect, and
# CQL's SELECT/INSERT/UPDATE/DELETE shape parses cleanly under the default
# generic dialect (including keyspace-qualified names like `acme.activity_log`
# and the `LIMIT n` clause).
_DIALECT_BY_CONNECTOR: dict[str, str] = {
    "postgresql": "postgres",
    "postgres": "postgres",
    "mysql": "mysql",
    "oracle": "oracle",
    "dynamodb": "presto",  # PartiQL is closest to Presto in sqlglot
}


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    """Walk the SQL AST and emit one AccessTarget per touched table."""
    if not raw_query or not raw_query.strip():
        # No body — just the declared target, default to SELECT.
        return [_declared(step, Op.SELECT)]

    dialect = _DIALECT_BY_CONNECTOR.get(step.database.lower()) if step.database else None
    try:
        statements = sqlglot.parse(raw_query, dialect=dialect)
    except Exception as exc:  # parse error → fail closed
        logger.debug("sqlglot parse failed (dialect=%s): %s", dialect, exc)
        return [_declared(step, Op.DDL)]

    targets: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()

    for stmt in statements:
        if stmt is None:
            continue
        for t in _targets_for_statement(stmt, step):
            key = (t.database, t.table, t.operation)
            if key not in seen:
                seen.add(key)
                targets.append(t)

    if not targets:
        # Statement parsed but produced no recognizable targets — declared SELECT.
        return [_declared(step, Op.SELECT)]
    return targets


# ---------------------------------------------------------------------------
# Per-statement dispatch
# ---------------------------------------------------------------------------


def _targets_for_statement(stmt: exp.Expression, step: "IRStep") -> list[AccessTarget]:
    # DDL classes — block at AST_CHECKER, but emit DDL targets so RBAC also denies
    # for any caller below AccessMode.A.
    if isinstance(stmt, _DDL_CLASSES):
        return [
            _target(step, _table_name(t), Op.DDL)
            for t in stmt.find_all(exp.Table)
        ] or [_declared(step, Op.DDL)]

    # Multi-statement BATCH (CQL): fan out per inner statement.
    if hasattr(exp, "Batch") and isinstance(stmt, getattr(exp, "Batch", ())):
        out: list[AccessTarget] = []
        for inner in stmt.find_all(_DML_CLASSES):
            out.extend(_targets_for_statement(inner, step))
        return out

    # INSERT
    if isinstance(stmt, exp.Insert):
        out = []
        # Primary target: the INSERT INTO table.
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.INSERT))
        # SELECT subquery's tables: SELECT-op (e.g. INSERT INTO x SELECT FROM y).
        sub = stmt.find(exp.Select)
        if sub is not None:
            for t in sub.find_all(exp.Table):
                if t is not primary:
                    out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # UPDATE
    if isinstance(stmt, exp.Update):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.UPDATE))
        # Postgres `UPDATE x SET ... FROM y`: y joins as SELECT.
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # DELETE
    if isinstance(stmt, exp.Delete):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.DELETE))
        # Postgres `DELETE FROM x USING y`: y joins as SELECT.
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # MERGE (UPSERT)
    if isinstance(stmt, exp.Merge):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.UPDATE))
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # SELECT (and EXPLAIN-wrapped SELECT, CTE-wrapped SELECT, UNION, etc.)
    return [
        _target(step, _table_name(t), Op.SELECT)
        for t in stmt.find_all(exp.Table)
    ] or [_declared(step, Op.SELECT)]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_DDL_CLASSES: tuple[type, ...] = tuple(
    cls for cls in (
        getattr(exp, "Create", None),
        getattr(exp, "Drop", None),
        getattr(exp, "AlterTable", None),
        getattr(exp, "AlterColumn", None),
        getattr(exp, "TruncateTable", None),
        # GRANT/REVOKE may not exist in all sqlglot versions; catch-all below.
    )
    if cls is not None
)

_DML_CLASSES: tuple[type, ...] = tuple(
    cls for cls in (exp.Select, exp.Insert, exp.Update, exp.Delete, exp.Merge)
    if cls is not None
)


def _first_table(stmt: exp.Expression) -> exp.Table | None:
    """First Table node — the primary target of INSERT/UPDATE/DELETE/MERGE."""
    return stmt.find(exp.Table)


def _table_name(t: exp.Table) -> str:
    """Strip schema/db prefix; return the table identifier only."""
    if t is None:
        return ""
    # sqlglot Table.name returns the bare table portion. `.this` handles
    # quoted/unquoted identifier nodes.
    return (t.name or "").strip('"').strip('`')


def _target(step: "IRStep", table: str, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=table or (step.table or ""),
        operation=op,
    )


def _declared(step: "IRStep", op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=step.table or "",
        operation=op,
    )
