"""Stage 2 — AST Checker.

Defense-in-depth backstop for DDL. RBACGate is the primary gate: it
permits DDL only when the matching policy entry grants ``AccessMode.A``
(Admin). This stage re-checks every extracted ``AccessTarget`` and
blocks DDL targets whose policy is below A — so a future regression
that loosens RBAC can't silently let CREATE/DROP/ALTER through.

DDL examples per language:
  - SQL/CQL : CREATE / DROP / ALTER / TRUNCATE / GRANT / REVOKE
  - MQL     : dropCollection / createIndex / dropIndex / runCommand{eval}
  - ES_DSL  : _template / _settings PUT / DELETE /<index> / mapping mutation
  - Vector  : create_collection / delete_collection / empty-filter delete
  - Cypher  : CREATE INDEX / DROP INDEX / CREATE/DROP CONSTRAINT
              + APOC procs outside the read-only allowlist
  - Dynamo  : CreateTable / DeleteTable / UpdateTable

Implementation: re-uses the per-family access extractor. For each
DDL target, the policy is looked up (per-table override → per-database
baseline). DDL passes only if the granted level is ``AccessMode.A``;
otherwise the request is BLOCKED.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from faz.safety.access_extractors import extract_targets
from faz.safety.rbac_gate import _lookup
from faz.safety.types import (
    AccessMode,
    AccessTarget,
    Op,
    SecurityEvent,
    Severity,
    StageResult,
    StageVerdict,
)

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .base import SafetyStage

logger = logging.getLogger(__name__)


class ASTChecker(SafetyStage):
    """Stage 2: hard-block DDL across every language; defer DML to RBACGate."""

    def validate(
        self,
        ir: "IntermediateRepr",
        permissions: list["Permission"],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        events: list[SecurityEvent] = []
        blocked = False

        for step in ir.steps:
            raw = (raw_sql or {}).get(step.source) if raw_sql else None
            try:
                targets = extract_targets(step, raw)
            except Exception as exc:  # noqa: BLE001 — fail closed
                logger.warning(
                    "AST_CHECKER: extractor crashed on step %s: %s",
                    step.step_id or step.source, exc,
                )
                events.append(
                    SecurityEvent(
                        stage="AST_CHECKER",
                        severity=Severity.BLOCK,
                        message=f"Failed to parse query on {step.source}",
                        detail=str(exc)[:200],
                    )
                )
                blocked = True
                continue

            for t in targets:
                if t.operation != Op.DDL:
                    continue
                granted = _lookup(permissions, t.database, t.table)
                if granted == AccessMode.A:
                    # Admin policy permits DDL — RBAC already allowed it,
                    # AST_CHECKER defers.
                    continue
                events.append(_ddl_block_event(step, t))
                blocked = True

        if blocked:
            return StageResult(
                stage="AST_CHECKER",
                verdict=StageVerdict.BLOCK,
                events=events,
            )
        return StageResult(stage="AST_CHECKER", verdict=StageVerdict.PASS)


def _ddl_block_event(step, target: AccessTarget) -> SecurityEvent:
    return SecurityEvent(
        stage="AST_CHECKER",
        severity=Severity.BLOCK,
        message=(
            f"DDL is not permitted: {target.database}.{target.table} "
            "(CREATE / DROP / ALTER / TRUNCATE / schema mutation / etc.)"
        ),
        detail=(
            f"step={step.step_id or step.source} "
            f"database={target.database} table={target.table} "
            "DDL is hard-blocked at AST_CHECKER regardless of AccessMode. "
            "If you need schema changes, run them outside faz."
        ),
    )
