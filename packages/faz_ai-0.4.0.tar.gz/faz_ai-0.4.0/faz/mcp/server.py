"""faz MCP stdio server.

Spawned as a subprocess by Claude Desktop / Cursor / any MCP client. The
server exposes the same 4 capabilities the REST API does — calling into
:mod:`faz.api.handlers` directly, no HTTP loopback. The tool input
schemas come from the same Pydantic models that the REST endpoints
validate against (:mod:`faz.api.schemas`), so the agent-facing contract
is identical across surfaces.

Audit log entries from this surface have ``transport="mcp/stdio"``,
matching the existing ``"rest/local"`` convention from Phase 4.

Run from the CLI:

    faz mcp

Or from an MCP client config (see :mod:`faz.mcp.install`):

    {"command": "faz", "args": ["mcp"], "env": {"FAZ_CONFIG": "..."}}
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from faz.api import handlers
from faz.api.handlers import HandlerError
from faz.api.schemas import FederatedQueryRequest, SimpleQueryRequest
from faz.runtime import build_runtime, resolve_config_path, shutdown_runtime

logger = logging.getLogger("faz.mcp")


__all__ = ["serve", "main"]


_TRANSPORT = "mcp/stdio"


async def serve() -> None:
    """Build the runtime, register tools, run the stdio loop until disconnect."""
    rt = await build_runtime(resolve_config_path())
    server: Server = Server("faz")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="list_databases",
                description=(
                    "List configured databases (with reachability + table "
                    "/ column schema) one page at a time. Default page "
                    "size is 4 — call again with `page: 2` (etc.) until "
                    "`pagination.has_more` is false. The total page count "
                    "is in `pagination.total_pages`."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "page": {
                            "type": "integer",
                            "minimum": 1,
                            "default": 1,
                            "description": "1-indexed page number.",
                        },
                        "size": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 100,
                            "default": 4,
                            "description":
                                "Databases per page. Default 4 keeps "
                                "the response comfortably under typical "
                                "MCP content-length limits even when "
                                "one DB has many tables.",
                        },
                    },
                },
            ),
            Tool(
                name="describe_table",
                description=(
                    "Describe one table's columns, types, and row-count "
                    "estimate. Use after `list_databases` to drill in."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "database": {
                            "type": "string",
                            "description": "Connector name from faz.yaml.",
                        },
                        "table": {
                            "type": "string",
                            "description": "Table / collection / index / class / label.",
                        },
                    },
                    "required": ["database", "table"],
                },
            ),
            Tool(
                name="query_simple",
                description=(
                    "Run a single-database query under the 5-stage safety "
                    "pipeline. Reads return data; writes (INSERT/UPDATE/"
                    "DELETE) flow through when the policy permits "
                    "(e.g. R/RA/RWA/RW/A); DDL (CREATE/DROP/ALTER/"
                    "TRUNCATE/dropCollection/etc.) is hard-blocked "
                    "regardless of policy.\n\n"
                    "Format of `query` per language:\n"
                    "  • SQL (postgres/mysql/oracle/cassandra) — a "
                    "    plain SQL string.\n"
                    "  • MQL (mongodb) — JSON string with at least:\n"
                    "    `{\"operation\": \"<op>\", ...}` where <op> is "
                    "    one of find / findOne / aggregate / count / "
                    "    distinct / insertOne / insertMany / updateOne "
                    "    / updateMany / replaceOne / deleteOne / "
                    "    deleteMany. Reads use `filter` + `projection`; "
                    "    inserts use `document` (insertOne) or "
                    "    `documents` (insertMany); updates use "
                    "    `filter` + `update`; deletes use `filter`.\n"
                    "    Example: `{\"operation\":\"insertOne\","
                    "\"document\":{\"id\":21,\"name\":\"X\"}}`\n"
                    "  • CYPHER (neo4j) — Cypher string.\n"
                    "  • ES_DSL (elasticsearch/opensearch) — JSON "
                    "    `{\"method\":\"GET\",\"path\":\"/idx/_search\","
                    "\"body\":{...}}` for non-search ops, or just the "
                    "    body for `_search`.\n"
                    "  • DYNAMO (dynamodb) — JSON `{\"verb\":\"Scan\","
                    "\"TableName\":\"X\",...}`.\n"
                    "  • VECTOR (weaviate/qdrant/milvus/pinecone) — "
                    "    JSON `{\"intent\":\"...\",...}`.\n"
                    "  • COUCHDB — JSON like MQL.\n\n"
                    "If you omit `language`, faz infers it from the "
                    "connector type (mongodb → MQL, neo4j → CYPHER, "
                    "etc.)."
                ),
                inputSchema=SimpleQueryRequest.model_json_schema(),
            ),
            Tool(
                name="query",
                description=(
                    "Run a multi-database federated query. Each step in "
                    "`steps[]` runs against its own DB; per-step results "
                    "land in DuckDB tables s0/s1/... and the optional "
                    "`merge` SQL joins them in DuckDB."
                ),
                inputSchema=FederatedQueryRequest.model_json_schema(),
            ),
        ]

    # validate_input=False: the MCP SDK would otherwise enforce the
    # registered JSON schemas strictly (e.g. `language` enum is uppercase
    # only), but the underlying Pydantic models already do friendlier
    # validation with case-coercion. Keeping the schema as input *hint*
    # for the agent, but letting Pydantic do the real check, matches REST.
    @server.call_tool(validate_input=False)
    async def call_tool(name: str, arguments: dict | None) -> list[TextContent]:
        args = arguments or {}
        try:
            if name == "list_databases":
                result: Any = await handlers.list_databases(
                    rt.registry,
                    page=int(args.get("page", 1)),
                    size=int(args.get("size", 4)),
                )
            elif name == "describe_table":
                result = await handlers.describe_table(
                    args["database"], args["table"], rt.registry,
                )
            elif name == "query_simple":
                result = await handlers.query_simple(
                    SimpleQueryRequest(**args),
                    registry=rt.registry,
                    policy=rt.policy,
                    pipeline=rt.pipeline,
                    engine=rt.engine,
                    scratchpads=rt.scratchpads,
                    audit=rt.audit,
                    transport=_TRANSPORT,
                )
            elif name == "query":
                result = await handlers.query_federated(
                    FederatedQueryRequest(**args),
                    registry=rt.registry,
                    policy=rt.policy,
                    pipeline=rt.pipeline,
                    engine=rt.engine,
                    scratchpads=rt.scratchpads,
                    audit=rt.audit,
                    transport=_TRANSPORT,
                )
            else:
                result = {"status": "error", "error": f"unknown tool: {name!r}"}
        except HandlerError as exc:
            # Blocked / 404 / 503 — the detail is already an envelope or message
            # the LLM should see verbatim (suggestion field included).
            result = (
                exc.detail
                if isinstance(exc.detail, dict)
                else {"status": "error", "error": str(exc.detail)}
            )
        except Exception as exc:
            logger.exception("MCP tool %s crashed", name)
            result = {"status": "error", "error": str(exc)}

        return [TextContent(
            type="text",
            text=json.dumps(result, default=str, indent=2),
        )]

    try:
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())
    finally:
        await shutdown_runtime(rt)


def main() -> None:
    """Entry point used by `faz mcp` and the `[project.scripts]` shim."""
    asyncio.run(serve())


if __name__ == "__main__":
    main()
