"""
MySQL connector for faz.

Uses pymysql (synchronous) wrapped with run_in_executor for async compatibility.
This avoids the "Future attached to a different loop" errors that occur with
aiomysql when shared across pytest-asyncio module-scoped fixtures.

Schema discovery via information_schema.
Read-only enforcement via sqlparse AST analysis.
"""

import asyncio
import time
from typing import Any

import pymysql
import pymysql.cursors
import sqlparse
from sqlparse.tokens import DDL, DML, Keyword

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldDistribution,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    Relationship,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# DML operations that modify data — blocked in READ_ONLY mode
_BLOCKED_DML = {"INSERT", "UPDATE", "DELETE", "REPLACE", "MERGE", "UPSERT"}

# DDL operations — always blocked regardless of access mode
_BLOCKED_DDL = {"CREATE", "DROP", "ALTER", "TRUNCATE", "RENAME", "COMMENT"}


def _get_statement_type(sql: str) -> str:
    """
    Returns the uppercase first keyword of the SQL statement.
    Uses sqlparse token classification for reliability.
    """
    parsed = sqlparse.parse(sql.strip())
    if not parsed:
        return ""
    stmt = parsed[0]
    stmt_type = stmt.get_type()
    if stmt_type:
        return stmt_type.upper()
    # Fallback: scan tokens for first meaningful keyword
    for token in stmt.tokens:
        if token.ttype in (DML, DDL, Keyword):
            return token.normalized.upper()
    return ""


class MySQLConnector(BaseConnector):
    """
    Async-compatible MySQL connector using pymysql (sync) via run_in_executor.

    Supports:
    - Schema discovery across all user tables in the target database
    - Read-only enforcement (blocks DML/DDL when access_mode=READ_ONLY)
    - Parameterised query execution with row limits
    - Audit-ready: returns the exact executed query in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.MYSQL

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        # Connection parameters stored for per-operation connections
        self._conn_kwargs: dict[str, Any] = {}

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    def _new_conn(self) -> pymysql.connections.Connection:
        """Create a fresh pymysql connection."""
        return pymysql.connect(**self._conn_kwargs)

    async def connect(self) -> None:
        self._conn_kwargs = dict(
            host=self.config.host,
            port=self.config.port,
            user=self.config.username,
            password=self.config.password,
            database=self.config.database,
            autocommit=True,
            cursorclass=pymysql.cursors.DictCursor,
        )

        def _ping():
            conn = self._new_conn()
            conn.ping()
            conn.close()

        await self._run(_ping)
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def health_check(self) -> bool:
        if not self._connected:
            return False
        try:
            def _check():
                conn = self._new_conn()
                try:
                    with conn.cursor() as cur:
                        cur.execute("SELECT 1")
                finally:
                    conn.close()
            await self._run(_check)
            return True
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        assert self._connected, "Not connected"

        schema_query = """
            SELECT
                table_name,
                column_name,
                data_type,
                is_nullable,
                column_key
            FROM information_schema.columns
            WHERE table_schema = %s
            ORDER BY table_name, ordinal_position
        """

        row_count_query = """
            SELECT table_name, table_rows
            FROM information_schema.tables
            WHERE table_schema = %s
        """

        fk_query = """
            SELECT
                kcu.TABLE_NAME       AS from_table,
                kcu.COLUMN_NAME      AS from_column,
                kcu.REFERENCED_TABLE_NAME  AS to_table,
                kcu.REFERENCED_COLUMN_NAME AS to_column
            FROM information_schema.KEY_COLUMN_USAGE kcu
            WHERE kcu.TABLE_SCHEMA = %s
              AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
        """

        stats_query = """
            SELECT
                TABLE_NAME   AS table_name,
                COLUMN_NAME  AS column_name,
                CARDINALITY  AS cardinality
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = %s
        """

        def _fetch():
            conn = self._new_conn()
            try:
                with conn.cursor() as cur:
                    cur.execute(schema_query, (self.config.database,))
                    col_rows = [{k.lower(): v for k, v in r.items()} for r in cur.fetchall()]
                    cur.execute(row_count_query, (self.config.database,))
                    count_rows = [{k.lower(): v for k, v in r.items()} for r in cur.fetchall()]
                    cur.execute(fk_query, (self.config.database,))
                    fk_rows = [{k.lower(): v for k, v in r.items()} for r in cur.fetchall()]
                    cur.execute(stats_query, (self.config.database,))
                    stat_rows = [{k.lower(): v for k, v in r.items()} for r in cur.fetchall()]
                return col_rows, count_rows, fk_rows, stat_rows
            finally:
                conn.close()

        col_rows, count_rows, fk_rows, stat_rows = await self._run(_fetch)

        row_estimates = {r["table_name"]: (r["table_rows"] or 0) for r in count_rows}

        fk_columns: set[tuple[str, str]] = set()
        relationships: list[Relationship] = []
        for fk in fk_rows:
            fk_columns.add((fk["from_table"], fk["from_column"]))
            relationships.append(Relationship(
                from_table=fk["from_table"],
                from_field=fk["from_column"],
                to_table=fk["to_table"],
                to_field=fk["to_column"],
                rel_type="fk",
            ))

        stats_map: dict[tuple[str, str], FieldDistribution] = {}
        for st in stat_rows:
            stats_map[(st["table_name"], st["column_name"])] = FieldDistribution(
                distinct_count=int(st["cardinality"] or 0),
            )

        tables: dict[str, TableSchema] = {}
        for row in col_rows:
            tname = row["table_name"]
            if tname not in tables:
                tables[tname] = TableSchema(
                    name=tname,
                    row_count_estimate=row_estimates.get(tname, 0),
                )
            col_name = row["column_name"]
            tables[tname].fields.append(
                FieldSchema(
                    name=col_name,
                    data_type=row["data_type"],
                    nullable=row["is_nullable"] == "YES",
                    is_primary=row["column_key"] == "PRI",
                    is_foreign_key=(tname, col_name) in fk_columns,
                    distribution=stats_map.get((tname, col_name)),
                )
            )

        return SchemaMetadata(
            connector_type=ConnectorType.MYSQL,
            database=self.config.database,
            tables=list(tables.values()),
            relationships=relationships,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        sql = query.strip()
        if not sql:
            return ValidationResult(is_valid=False, error="Empty query")

        # Block multi-statement queries
        statements = [s for s in sqlparse.parse(sql) if str(s).strip()]
        if len(statements) > 1:
            return ValidationResult(
                is_valid=False,
                blocked_reason="Multi-statement queries are not permitted",
            )

        first_keyword = _get_statement_type(sql)

        if first_keyword in _BLOCKED_DDL:
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL operation '{first_keyword}' is not permitted",
            )

        # DML (INSERT/UPDATE/DELETE/REPLACE/MERGE/UPSERT) flows through —
        # RBAC owns per-table write decisions. The connector trusts that.
        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        assert self._connected, "Not connected"

        sql = query.raw_query.strip()
        # LIMIT injection is handled upstream by Guardrails (SELECTs only,
        # row cap from ``policy.safety.max_rows_per_query``). Writes pass
        # through untouched.

        validation = await self.validate_query(sql)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.MYSQL,
                database=self.config.database,
                error=validation.blocked_reason or validation.error,
                query_executed=sql,
            )

        start = time.monotonic()
        try:
            def _execute(q=sql):
                conn = self._new_conn()
                try:
                    with conn.cursor() as cur:
                        cur.execute(q)
                        # SELECT-style returns a description; INSERT/UPDATE/
                        # DELETE returns None. fetchall() is safe on the
                        # latter in PyMySQL but produces empty rows; we
                        # still want to surface rows_affected explicitly
                        # AND commit the write.
                        if cur.description is None:
                            affected = cur.rowcount
                            conn.commit()
                            return ("rowcount", affected)
                        return ("rows", cur.fetchall())
                finally:
                    conn.close()

            kind, payload = await self._run(_execute)
            elapsed_ms = (time.monotonic() - start) * 1000

            if kind == "rows":
                result_rows = [dict(row) for row in payload]
                columns = list(result_rows[0].keys()) if result_rows else []
            else:
                result_rows = [{"rows_affected": payload}]
                columns = ["rows_affected"]

            return QueryResult(
                connector_type=ConnectorType.MYSQL,
                database=self.config.database,
                columns=columns,
                rows=result_rows,
                total_count=len(result_rows),
                execution_time_ms=elapsed_ms,
                query_executed=sql,
            )

        except Exception as e:
            return QueryResult(
                connector_type=ConnectorType.MYSQL,
                database=self.config.database,
                error=str(e),
                query_executed=sql,
            )
