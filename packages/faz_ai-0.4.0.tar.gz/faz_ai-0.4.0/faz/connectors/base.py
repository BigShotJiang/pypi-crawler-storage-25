"""
Base connector interface for faz.
All database connectors must implement this interface.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ConnectorType(str, Enum):
    POSTGRESQL = "postgresql"
    MONGODB = "mongodb"
    DYNAMODB = "dynamodb"
    WEAVIATE = "weaviate"
    ELASTICSEARCH = "elasticsearch"
    NEO4J = "neo4j"
    QDRANT = "qdrant"
    MILVUS = "milvus"
    OPENSEARCH = "opensearch"
    CASSANDRA = "cassandra"
    MYSQL = "mysql"
    COUCHDB = "couchdb"
    ORACLE = "oracle"
    PINECONE = "pinecone"


class AccessMode(str, Enum):
    READ_ONLY = "read_only"
    READ_WRITE = "read_write"
    READ_APPEND = "read_append"


@dataclass
class ConnectionConfig:
    connector_type: ConnectorType
    host: str
    port: int
    database: str = ""
    name: str = ""          # routing key; defaults to connector_type.value if omitted
    username: str = ""
    password: str = ""
    access_mode: AccessMode = AccessMode.READ_ONLY
    ssl: bool = False
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class FieldDistribution:
    """Lightweight stats about a column's data distribution."""
    distinct_count: int = 0
    null_fraction: float = 0.0
    sample_values: list[Any] = field(default_factory=list)
    min_value: Any = None
    max_value: Any = None


@dataclass
class FieldSchema:
    name: str
    data_type: str
    nullable: bool = True
    is_primary: bool = False
    is_foreign_key: bool = False
    description: str = ""
    distribution: FieldDistribution | None = None


@dataclass
class Relationship:
    """A directed relationship between two fields (FK, ref, graph edge)."""
    from_table: str
    from_field: str
    to_table: str
    to_field: str
    rel_type: str = "fk"


@dataclass
class TableSchema:
    name: str
    fields: list[FieldSchema] = field(default_factory=list)
    row_count_estimate: int = 0
    description: str = ""


@dataclass
class SchemaMetadata:
    connector_type: ConnectorType
    database: str
    name: str = ""          # connector name (routing key); set by SchemaRegistry after discovery
    tables: list[TableSchema] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)

    def to_prompt_context(self) -> str:
        """Render schema as a compact string for LLM prompt injection."""
        label = self.name or self.connector_type.value
        lines = [f"Database: {self.database} (name={label}, type={self.connector_type.value})"]
        for table in self.tables:
            row_est = f"  (~{table.row_count_estimate} rows)" if table.row_count_estimate else ""
            lines.append(f"  Table/Collection: {table.name}{row_est}")
            for f in table.fields:
                parts = [f"    - {f.name}: {f.data_type}"]
                if f.is_primary:
                    parts.append("[PK]")
                if f.is_foreign_key:
                    parts.append("[FK]")
                if f.distribution:
                    d = f.distribution
                    dist_parts = []
                    if d.distinct_count:
                        dist_parts.append(f"distinct={d.distinct_count}")
                    if d.null_fraction > 0:
                        dist_parts.append(f"nulls={d.null_fraction:.0%}")
                    if d.sample_values:
                        samples = ", ".join(str(v) for v in d.sample_values[:3])
                        dist_parts.append(f"e.g. {samples}")
                    if dist_parts:
                        parts.append(f"({'; '.join(dist_parts)})")
                lines.append(" ".join(parts))

        if self.relationships:
            lines.append("  Relationships:")
            for r in self.relationships:
                lines.append(f"    {r.from_table}.{r.from_field} -> {r.to_table}.{r.to_field} [{r.rel_type}]")

        return "\n".join(lines)


@dataclass
class IntermediateQuery:
    """
    LLM-generated intermediate representation of a query.
    The connector translates this into native DB syntax.
    """
    natural_language: str
    target_connector: ConnectorType
    intent: str                          # e.g. "select", "aggregate", "search"
    tables: list[str] = field(default_factory=list)
    filters: dict[str, Any] = field(default_factory=dict)
    fields: list[str] = field(default_factory=list)
    limit: int = 100
    raw_query: str = ""                  # LLM-generated native query string (validated before use)
    connector_name: str = ""             # named-connector routing key (matches ConnectionConfig.name)


@dataclass
class QueryResult:
    connector_type: ConnectorType
    database: str
    rows: list[dict[str, Any]] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)
    total_count: int = 0
    error: str = ""
    execution_time_ms: float = 0.0
    query_executed: str = ""             # Final validated query that was run (for audit log)


@dataclass
class ValidationResult:
    is_valid: bool
    error: str = ""
    blocked_reason: str = ""             # e.g. "write operation blocked in read-only mode"


class BaseConnector(ABC):
    """
    Abstract base class for all faz database connectors.

    Lifecycle:
        1. connect()        - Establish connection
        2. discover_schema() - Introspect DB structure
        3. validate_query() - Safety check before execution
        4. execute()        - Run the query and return results
        5. disconnect()     - Clean up
    """

    def __init__(self, config: ConnectionConfig):
        self.config = config
        self._connected = False

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the database."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the database connection."""

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the database is reachable and healthy."""

    @abstractmethod
    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect the database and return its schema.
        Called on startup and periodically to detect schema drift.
        """

    @abstractmethod
    async def validate_query(self, query: str) -> ValidationResult:
        """
        Validate a query against access mode and safety rules before execution.
        Must block all write/DDL operations when access_mode is READ_ONLY.
        """

    @abstractmethod
    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Translate the IntermediateQuery to native syntax, validate, and execute.
        Must call validate_query() internally before execution.
        """

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *args):
        await self.disconnect()
