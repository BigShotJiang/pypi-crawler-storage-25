"""
Elasticsearch connector for faz.

Uses the official elasticsearch-py synchronous client wrapped in run_in_executor.
This avoids the aiohttp event-loop / Task-context issues that occur with the
async client when shared across pytest-asyncio module-scoped fixtures.

Schema discovery via _mapping API.
Read-only enforcement via HTTP method whitelisting (GET only).
"""

import asyncio
import json
import time
from typing import Any

from elasticsearch import Elasticsearch, ApiError

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Elasticsearch field types that map to readable labels
_ES_TYPE_MAP = {
    "text": "text (full-text)",
    "keyword": "keyword (exact)",
    "integer": "int",
    "long": "long",
    "float": "float",
    "double": "double",
    "boolean": "bool",
    "date": "date",
    "object": "object",
    "nested": "nested object",
    "geo_point": "geo_point",
    "dense_vector": "dense_vector",
}

# System indices to skip during schema discovery
_SYSTEM_INDEX_PREFIXES = (".", "kibana", "security", "fleet", "apm", "metrics-", "logs-", "traces-")


def _flatten_mappings(properties: dict, prefix: str = "") -> list[FieldSchema]:
    """Recursively flatten Elasticsearch mapping properties into FieldSchema list."""
    fields = []
    for name, config in properties.items():
        full_name = f"{prefix}.{name}" if prefix else name
        field_type = config.get("type", "object")
        readable_type = _ES_TYPE_MAP.get(field_type, field_type)
        fields.append(FieldSchema(name=full_name, data_type=readable_type))

        # Recurse into nested object properties
        if "properties" in config:
            fields.extend(_flatten_mappings(config["properties"], prefix=full_name))
    return fields


class ElasticsearchConnector(BaseConnector):
    """
    Elasticsearch connector using the synchronous client via run_in_executor.

    Supports:
    - Schema discovery via _mapping API across all user indices
    - Read-only enforcement: only GET /_search and GET /_count are permitted
    - Query execution via Search API with Query DSL (JSON)
    - Audit-ready: returns the serialised query body in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.ELASTICSEARCH

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: Elasticsearch | None = None

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    async def connect(self) -> None:
        scheme = "https" if self.config.ssl else "http"
        host = f"{scheme}://{self.config.host}:{self.config.port}"
        auth = (self.config.username, self.config.password) if self.config.username else None

        def _connect():
            client = Elasticsearch(
                hosts=[host],
                basic_auth=auth,
                verify_certs=self.config.ssl,
                request_timeout=30,
            )
            client.ping()
            return client

        self._client = await self._run(_connect)
        self._connected = True

    async def disconnect(self) -> None:
        if self._client:
            client = self._client
            await self._run(client.close)
            self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            client = self._client
            return await self._run(client.ping)
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        Fetch field mappings for all non-system indices via GET /_mapping.
        Each index is treated as a "table" with its mapped fields as columns.
        """
        assert self._client is not None, "Not connected"
        client = self._client

        def _fetch():
            stats_resp = client.indices.stats(index="*", metric="docs")
            doc_counts: dict[str, int] = {}
            for idx, idx_stats in stats_resp["indices"].items():
                doc_counts[idx] = idx_stats["primaries"]["docs"]["count"]
            mapping_resp = client.indices.get_mapping(index="*")
            return doc_counts, mapping_resp

        doc_counts, mapping_resp = await self._run(_fetch)

        tables: list[TableSchema] = []
        for index_name, mapping_data in mapping_resp.items():
            if any(index_name.startswith(p) for p in _SYSTEM_INDEX_PREFIXES):
                continue
            properties = mapping_data.get("mappings", {}).get("properties", {})
            fields = _flatten_mappings(properties)
            tables.append(TableSchema(
                name=index_name,
                fields=fields,
                row_count_estimate=doc_counts.get(index_name, 0),
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.ELASTICSEARCH,
            database=self.config.host,
            tables=tables,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        """Validate a Query-DSL JSON string.

        DML (index / update / delete / bulk) flows through; RBAC owns
        per-index decisions. The connector still hard-blocks DDL-shaped
        endpoints: ``_template`` / ``_settings PUT`` / mapping mutation /
        bare ``DELETE /<index>``.
        """
        if not query.strip():
            return ValidationResult(is_valid=False, error="Empty query body")
        try:
            body = json.loads(query)
        except json.JSONDecodeError as e:
            return ValidationResult(is_valid=False, error=f"Invalid JSON query: {e}")

        # If the agent wrapped the request as the {method, path, body}
        # envelope, hard-block DDL endpoints regardless of policy.
        if isinstance(body, dict) and body.get("path"):
            path = str(body["path"])
            method = (body.get("method") or "GET").upper()
            ddl_endpoints = ("_template", "_index_template", "_settings",
                             "_mapping", "_close", "_open", "_aliases")
            if any(seg in path for seg in ddl_endpoints):
                return ValidationResult(
                    is_valid=False,
                    blocked_reason=f"DDL endpoint detected in path '{path}'",
                )
            # Bare DELETE /<index> — drop-an-index DDL.
            parts = [p for p in path.strip("/").split("/") if p]
            if method == "DELETE" and len(parts) == 1:
                return ValidationResult(
                    is_valid=False,
                    blocked_reason=f"DELETE on bare index '{parts[0]}' is hard-blocked DDL",
                )
        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Query DSL search against one or more indices.

        IntermediateQuery fields used:
          - tables:     [index_name, ...] — indices to search
          - raw_query:  JSON string of the Query DSL body
          - fields:     _source fields to return (optional)
          - limit:      max hits to return (mapped to 'size')
        """
        assert self._client is not None, "Not connected"

        validation = await self.validate_query(query.raw_query)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=self.config.host,
                error=validation.blocked_reason or validation.error,
            )

        index = ",".join(query.tables) if query.tables else "*"
        limit = min(query.limit, 1000)

        try:
            query_body: dict[str, Any] = json.loads(query.raw_query)
        except json.JSONDecodeError as e:
            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=self.config.host,
                error=f"Invalid query JSON: {e}",
            )

        client = self._client

        # Wire-protocol envelope: ``{"method": "POST", "path": "/idx/_doc",
        # "body": {...}}``. Dispatch to the right ES client method based
        # on path parts. Falls through to a search when no envelope is
        # present (legacy body-only callers stay working).
        if "method" in query_body and "path" in query_body:
            return await self._dispatch_wire(query_body)

        # Legacy body-only search path.
        query_body["size"] = min(query_body.get("size", limit), limit)
        if query.fields:
            query_body["_source"] = query.fields
        audit_repr = json.dumps({"index": index, "body": query_body})

        start = time.monotonic()
        try:
            def _search():
                return client.search(index=index, body=query_body)

            response = await self._run(_search)
            elapsed_ms = (time.monotonic() - start) * 1000

            hits = response["hits"]["hits"]

            rows = []
            for hit in hits:
                row = {"_index": hit["_index"], "_id": hit["_id"], "_score": hit.get("_score")}
                row.update(hit.get("_source", {}))
                rows.append(row)

            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=self.config.host,
                columns=columns,
                rows=rows,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=audit_repr,
            )

        except ApiError as e:
            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=self.config.host,
                error=str(e),
                query_executed=audit_repr,
            )

    # ── Wire-protocol envelope dispatch ───────────────────────────────────

    async def _dispatch_wire(self, body: dict[str, Any]) -> QueryResult:
        """Route a ``{method, path, body}`` envelope to the ES client.

        Recognized paths (the same ones the ES_DSL access extractor
        understands so RBAC + execute stay aligned):

            /<idx>/_search       → search
            /<idx>/_count        → count
            /<idx>/_doc          → index (POST) / index with id (PUT)
            /<idx>/_doc/{id}     → index/get
            /<idx>/_update/{id}  → update
            /<idx>/_update_by_query → update_by_query
            /<idx>/_delete_by_query → delete_by_query
            /_bulk               → bulk (NDJSON body)

        Anything not in this list returns an error envelope. DDL paths
        are blocked at validate_query upstream.
        """
        method = (body.get("method") or "GET").upper()
        path = body.get("path") or ""
        inner = body.get("body")
        client = self._client
        host = self.config.host
        audit = json.dumps({"method": method, "path": path})

        parts = [p for p in path.strip("/").split("/") if p]
        idx = parts[0] if parts else ""
        endpoint = parts[1] if len(parts) >= 2 else ""
        doc_id = parts[2] if len(parts) >= 3 else ""

        start = time.monotonic()
        try:
            if endpoint == "_search":
                def _go():
                    return client.search(index=idx, body=inner or {})
                resp = await self._run(_go)
                hits = resp["hits"]["hits"]
                rows = [
                    {"_index": h.get("_index"), "_id": h.get("_id"),
                     "_score": h.get("_score"), **h.get("_source", {})}
                    for h in hits
                ]

            elif endpoint == "_count":
                def _go():
                    return client.count(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{"count": resp.get("count", 0)}]

            elif endpoint == "_doc":
                if doc_id:
                    if method == "GET":
                        def _go():
                            return client.get(index=idx, id=doc_id)
                        resp = await self._run(_go)
                        rows = [{
                            "_index": resp.get("_index"),
                            "_id": resp.get("_id"),
                            **resp.get("_source", {}),
                        }]
                    else:  # PUT/POST: index with id
                        def _go():
                            return client.index(index=idx, id=doc_id, body=inner or {})
                        resp = await self._run(_go)
                        rows = [{
                            "_id": resp.get("_id"), "_index": resp.get("_index"),
                            "result": resp.get("result"), "version": resp.get("_version"),
                        }]
                else:
                    # POST /idx/_doc → auto-id index.
                    def _go():
                        return client.index(index=idx, body=inner or {})
                    resp = await self._run(_go)
                    rows = [{
                        "_id": resp.get("_id"), "_index": resp.get("_index"),
                        "result": resp.get("result"), "version": resp.get("_version"),
                    }]

            elif endpoint == "_update" and doc_id:
                def _go():
                    return client.update(index=idx, id=doc_id, body=inner or {})
                resp = await self._run(_go)
                rows = [{
                    "_id": resp.get("_id"), "result": resp.get("result"),
                    "version": resp.get("_version"),
                }]

            elif endpoint == "_update_by_query":
                def _go():
                    return client.update_by_query(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{
                    "updated": resp.get("updated", 0),
                    "took": resp.get("took", 0),
                }]

            elif endpoint == "_delete_by_query":
                def _go():
                    return client.delete_by_query(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{
                    "deleted": resp.get("deleted", 0),
                    "took": resp.get("took", 0),
                }]

            elif method == "DELETE" and endpoint == "_doc" and doc_id:
                def _go():
                    return client.delete(index=idx, id=doc_id)
                resp = await self._run(_go)
                rows = [{
                    "_id": resp.get("_id"), "result": resp.get("result"),
                }]

            elif idx == "_bulk" or endpoint == "_bulk" or path.endswith("/_bulk"):
                # ``inner`` is the NDJSON body — ES client accepts it as a string.
                def _go():
                    return client.bulk(body=inner)
                resp = await self._run(_go)
                rows = [{
                    "took": resp.get("took", 0),
                    "errors": resp.get("errors", False),
                    "item_count": len(resp.get("items", [])),
                }]

            else:
                return QueryResult(
                    connector_type=ConnectorType.ELASTICSEARCH,
                    database=host,
                    error=(
                        f"Unsupported {method} {path}; recognized endpoints: "
                        "_search, _count, _doc, _update, _update_by_query, "
                        "_delete_by_query, _bulk"
                    ),
                    query_executed=audit,
                )

            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=host,
                columns=list(rows[0].keys()) if rows else [],
                rows=rows, total_count=len(rows),
                execution_time_ms=elapsed_ms, query_executed=audit,
            )

        except ApiError as e:
            return QueryResult(
                connector_type=ConnectorType.ELASTICSEARCH,
                database=host, error=str(e), query_executed=audit,
            )
