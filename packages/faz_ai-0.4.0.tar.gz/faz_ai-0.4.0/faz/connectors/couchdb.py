"""
CouchDB connector for faz.

Uses aiohttp for async REST API communication (default port 5984).
Schema discovery via _all_dbs and document sampling.
Read-only enforcement via intent-based validation.
"""

import json
import time
from typing import Any

import aiohttp

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# System databases to exclude from schema discovery
_SYSTEM_DBS = {"_users", "_replicator", "_global_changes"}

# Write operation keywords/intents to block
_BLOCKED_WRITE_INTENTS = {"create", "update", "delete", "bulk_docs"}

# CouchDB internal fields (still surfaced as FieldSchema but noted)
_INTERNAL_FIELDS = {"_id", "_rev"}


class CouchDBConnector(BaseConnector):
    """
    Async CouchDB connector using aiohttp REST API.

    Supports:
    - Schema discovery via _all_dbs + document sampling
    - Read-only enforcement (blocks write intents when access_mode=READ_ONLY)
    - Mango query execution (POST /{db}/_find)
    - _all_docs and _view query execution
    - Audit-ready: returns the exact URL executed in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.COUCHDB

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._base_url: str = ""
        self._auth: aiohttp.BasicAuth | None = None

    def _get_session(self) -> aiohttp.ClientSession:
        """Create a fresh ClientSession inside the current task's event loop."""
        return aiohttp.ClientSession(auth=self._auth)

    async def connect(self) -> None:
        self._base_url = f"http://{self.config.host}:{self.config.port}"
        self._auth = aiohttp.BasicAuth(
            login=self.config.username,
            password=self.config.password,
        )

        # Verify connectivity — check the target database or server root
        db = self.config.database
        async with self._get_session() as session:
            if db:
                async with session.get(f"{self._base_url}/{db}") as resp:
                    if resp.status not in (200, 404):
                        resp.raise_for_status()
            else:
                async with session.get(f"{self._base_url}/_all_dbs") as resp:
                    resp.raise_for_status()

        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def health_check(self) -> bool:
        if not self._connected:
            return False
        try:
            async with self._get_session() as session:
                async with session.get(f"{self._base_url}/_up") as resp:
                    return resp.status == 200
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        assert self._connected, "Not connected"

        async with self._get_session() as session:
            async with session.get(f"{self._base_url}/_all_dbs") as resp:
                resp.raise_for_status()
                all_dbs: list[str] = await resp.json()

            user_dbs = [db for db in all_dbs if db not in _SYSTEM_DBS]
            tables: list[TableSchema] = []

            for db in user_dbs:
                # Get document count
                async with session.get(f"{self._base_url}/{db}") as resp:
                    if resp.status != 200:
                        continue
                    db_info = await resp.json()
                doc_count = db_info.get("doc_count", 0)

                # Sample documents to infer field schema
                sample_url = f"{self._base_url}/{db}/_all_docs?include_docs=true&limit=50"
                async with session.get(sample_url) as resp:
                    if resp.status != 200:
                        tables.append(TableSchema(name=db, row_count_estimate=doc_count))
                        continue
                    sample_data = await resp.json()

                rows = sample_data.get("rows", [])
                field_map: dict[str, FieldSchema] = {}

                for row in rows:
                    doc = row.get("doc", {})
                    for key, val in doc.items():
                        if key not in field_map:
                            field_map[key] = FieldSchema(
                                name=key,
                                data_type=type(val).__name__,
                                nullable=True,
                                is_primary=(key == "_id"),
                            )

                # Ensure _id is always included
                if "_id" not in field_map:
                    field_map["_id"] = FieldSchema(
                        name="_id",
                        data_type="str",
                        nullable=False,
                        is_primary=True,
                    )

                tables.append(
                    TableSchema(
                        name=db,
                        fields=list(field_map.values()),
                        row_count_estimate=doc_count,
                    )
                )

        return SchemaMetadata(
            connector_type=ConnectorType.COUCHDB,
            database=self.config.database or (user_dbs[0] if user_dbs else self.config.host),
            tables=tables,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        """Validate a Mango / intent string.

        Phase 6 stance: writes (insert/update/delete/bulk_docs) flow
        through; RBAC_GATE upstream decides whether the policy permits
        them. The connector still hard-blocks DDL-shaped ops:
        creating/dropping databases, replicator, or design-doc-only
        ``runCommand``-style requests.
        """
        q = query.strip()
        if not q:
            return ValidationResult(is_valid=False, error="Empty query")

        ddl_ops = {
            "createdatabase", "deletedatabase", "dropdatabase",
            "createindex", "dropindex", "deleteindex",
            "replicate", "compact",
        }
        intent_lower = q.lower().replace("_", "")
        if intent_lower in ddl_ops:
            return ValidationResult(
                is_valid=False,
                blocked_reason=(
                    f"DDL operation '{intent_lower}' is hard-blocked at the "
                    "connector regardless of policy."
                ),
            )

        return ValidationResult(is_valid=True)

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Extract the operation + payload from raw_query JSON.

        Mirrors the mongodb connector's ``_parse_raw_query``: lifts
        ``operation`` into ``query.intent`` and stashes structured
        payloads (selector, document, documents, fields, id, rev,
        ddoc, view) into ``query.filters`` for ``execute()`` to read.
        """
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query

        op = parsed.get("operation", "").strip().lower().replace("_", "")
        if op:
            query.intent = op

        for key in ("selector", "fields", "document", "documents",
                    "id", "rev", "ddoc", "view"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]

        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        assert self._connected, "Not connected"

        # Lift raw_query → filters/intent before dispatching.
        query = self._parse_raw_query(query)

        db = query.tables[0] if query.tables else self.config.database
        intent = query.intent.lower().replace("_", "")
        limit = min(query.limit, 1000)
        filters = query.filters or {}

        validation = await self.validate_query(intent)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.COUCHDB,
                database=db,
                error=validation.blocked_reason or validation.error,
                query_executed=intent,
            )

        start = time.monotonic()

        try:
            async with self._get_session() as session:
                if intent == "find":
                    # POST /{db}/_find with Mango selector
                    selector = filters.get("selector", {})
                    fields = query.fields if query.fields else None
                    payload: dict[str, Any] = {"selector": selector, "limit": limit}
                    if fields:
                        payload["fields"] = fields

                    url = f"{self._base_url}/{db}/_find"
                    async with session.post(url, json=payload) as resp:
                        resp.raise_for_status()
                        data = await resp.json()

                    elapsed_ms = (time.monotonic() - start) * 1000
                    docs = data.get("docs", [])
                    columns = list(docs[0].keys()) if docs else []

                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB,
                        database=db,
                        columns=columns,
                        rows=docs,
                        total_count=len(docs),
                        execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

                elif intent == "view":
                    ddoc = filters.get("ddoc", "")
                    view = filters.get("view", "")
                    url = f"{self._base_url}/{db}/_design/{ddoc}/_view/{view}?limit={limit}"
                    async with session.get(url) as resp:
                        resp.raise_for_status()
                        data = await resp.json()

                    elapsed_ms = (time.monotonic() - start) * 1000
                    raw_rows = data.get("rows", [])
                    docs = [r.get("value", r) for r in raw_rows]
                    columns = list(docs[0].keys()) if docs else []

                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB,
                        database=db,
                        columns=columns,
                        rows=docs,
                        total_count=len(docs),
                        execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

                elif intent in ("insertone", "insert", "create"):
                    # POST /{db} (auto-id) or PUT /{db}/{id} (caller-supplied id).
                    doc = filters.get("document") or {}
                    if not isinstance(doc, dict):
                        return QueryResult(
                            connector_type=ConnectorType.COUCHDB, database=db,
                            error="insertOne requires `document` as a JSON object",
                        )
                    doc_id = filters.get("id") or doc.get("_id")
                    if doc_id:
                        url = f"{self._base_url}/{db}/{doc_id}"
                        async with session.put(url, json=doc) as resp:
                            resp.raise_for_status()
                            data = await resp.json()
                    else:
                        url = f"{self._base_url}/{db}"
                        async with session.post(url, json=doc) as resp:
                            resp.raise_for_status()
                            data = await resp.json()
                    elapsed_ms = (time.monotonic() - start) * 1000
                    rows = [{
                        "id": data.get("id"),
                        "rev": data.get("rev"),
                        "ok": data.get("ok", True),
                    }]
                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB, database=db,
                        columns=list(rows[0].keys()), rows=rows,
                        total_count=1, execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

                elif intent in ("updateone", "update", "replaceone"):
                    # PUT /{db}/{id} with the full new doc — CouchDB requires
                    # the existing _rev to be embedded in the doc body.
                    doc = filters.get("document") or {}
                    doc_id = filters.get("id") or doc.get("_id")
                    if not doc_id:
                        return QueryResult(
                            connector_type=ConnectorType.COUCHDB, database=db,
                            error="update requires `id` (or `document._id`)",
                        )
                    if not doc.get("_rev") and not filters.get("rev"):
                        return QueryResult(
                            connector_type=ConnectorType.COUCHDB, database=db,
                            error=("update requires the document's `_rev` "
                                   "(CouchDB MVCC); fetch it first via find/get"),
                        )
                    if filters.get("rev") and "_rev" not in doc:
                        doc["_rev"] = filters["rev"]
                    url = f"{self._base_url}/{db}/{doc_id}"
                    async with session.put(url, json=doc) as resp:
                        resp.raise_for_status()
                        data = await resp.json()
                    elapsed_ms = (time.monotonic() - start) * 1000
                    rows = [{
                        "id": data.get("id"),
                        "rev": data.get("rev"),
                        "ok": data.get("ok", True),
                    }]
                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB, database=db,
                        columns=list(rows[0].keys()), rows=rows,
                        total_count=1, execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

                elif intent in ("deleteone", "delete"):
                    # DELETE /{db}/{id}?rev={rev}
                    doc_id = filters.get("id")
                    rev = filters.get("rev")
                    if not doc_id or not rev:
                        return QueryResult(
                            connector_type=ConnectorType.COUCHDB, database=db,
                            error="delete requires both `id` and `rev`",
                        )
                    url = f"{self._base_url}/{db}/{doc_id}?rev={rev}"
                    async with session.delete(url) as resp:
                        resp.raise_for_status()
                        data = await resp.json()
                    elapsed_ms = (time.monotonic() - start) * 1000
                    rows = [{
                        "id": data.get("id"),
                        "rev": data.get("rev"),
                        "ok": data.get("ok", True),
                    }]
                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB, database=db,
                        columns=list(rows[0].keys()), rows=rows,
                        total_count=1, execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

                elif intent in ("bulkdocs", "insertmany", "bulkwrite"):
                    docs_in = filters.get("documents") or []
                    if not isinstance(docs_in, list):
                        return QueryResult(
                            connector_type=ConnectorType.COUCHDB, database=db,
                            error="bulkDocs requires `documents` as a JSON array",
                        )
                    url = f"{self._base_url}/{db}/_bulk_docs"
                    async with session.post(url, json={"docs": docs_in}) as resp:
                        resp.raise_for_status()
                        data = await resp.json()
                    elapsed_ms = (time.monotonic() - start) * 1000
                    rows = data if isinstance(data, list) else []
                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB, database=db,
                        columns=list(rows[0].keys()) if rows else [],
                        rows=rows, total_count=len(rows),
                        execution_time_ms=elapsed_ms, query_executed=url,
                    )

                else:
                    # all_docs (default)
                    url = f"{self._base_url}/{db}/_all_docs?include_docs=true&limit={limit}"
                    async with session.get(url) as resp:
                        resp.raise_for_status()
                        data = await resp.json()

                    elapsed_ms = (time.monotonic() - start) * 1000
                    raw_rows = data.get("rows", [])
                    docs = [r["doc"] for r in raw_rows if "doc" in r]
                    columns = list(docs[0].keys()) if docs else []

                    return QueryResult(
                        connector_type=ConnectorType.COUCHDB,
                        database=db,
                        columns=columns,
                        rows=docs,
                        total_count=len(docs),
                        execution_time_ms=elapsed_ms,
                        query_executed=url,
                    )

        except Exception as e:
            return QueryResult(
                connector_type=ConnectorType.COUCHDB,
                database=db,
                error=str(e),
                query_executed=intent,
            )
