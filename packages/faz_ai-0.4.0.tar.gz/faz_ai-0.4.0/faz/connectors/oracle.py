"""
Oracle connector for faz.

Uses python-oracledb in thin mode (no client libraries required).
Uses the synchronous oracledb driver wrapped with run_in_executor to avoid
"Future attached to a different loop" errors when the pool is shared across
pytest-asyncio module-scoped fixtures.

Schema discovery via ALL_TABLES, ALL_TAB_COLUMNS, ALL_CONSTRAINTS, ALL_CONS_COLUMNS.
Read-only enforcement via sqlparse AST analysis.
"""

import asyncio
import time

import oracledb
import sqlparse
from sqlparse.tokens import DDL, DML, Keyword

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldDistribution,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    Relationship,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# DML operations that modify data — blocked in READ_ONLY mode
_BLOCKED_DML = {"INSERT", "UPDATE", "DELETE", "MERGE", "UPSERT"}

# DDL operations — always blocked regardless of access mode
_BLOCKED_DDL = {"CREATE", "DROP", "ALTER", "TRUNCATE", "RENAME", "COMMENT"}


def _get_statement_type(sql: str) -> str:
    """
    Returns the uppercase first keyword of the SQL statement.
    Uses sqlparse token classification for reliability.
    """
    parsed = sqlparse.parse(sql.strip())
    if not parsed:
        return ""
    stmt = parsed[0]
    stmt_type = stmt.get_type()
    if stmt_type:
        return stmt_type.upper()
    for token in stmt.tokens:
        if token.ttype in (DML, DDL, Keyword):
            return token.normalized.upper()
    return ""


class OracleConnector(BaseConnector):
    """
    Async-compatible Oracle connector using the synchronous oracledb driver
    via run_in_executor.

    Supports:
    - Schema discovery via ALL_TABLES, ALL_TAB_COLUMNS, ALL_CONSTRAINTS
    - Read-only enforcement (blocks DML/DDL when access_mode=READ_ONLY)
    - Query execution with FETCH FIRST ... ROWS ONLY guardrail
    - Audit-ready: returns the exact executed query in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.ORACLE

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._pool: oracledb.ConnectionPool | None = None
        self._dsn: str = ""

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    def _new_conn(self) -> oracledb.Connection:
        """Acquire a connection from the sync pool."""
        return self._pool.acquire()

    async def connect(self) -> None:
        self._dsn = f"{self.config.host}:{self.config.port}/{self.config.database}"

        def _create_pool():
            pool = oracledb.create_pool(
                user=self.config.username,
                password=self.config.password,
                dsn=self._dsn,
                min=2,
                max=10,
            )
            # Verify connectivity
            with pool.acquire() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1 FROM DUAL")
            return pool

        self._pool = await self._run(_create_pool)
        self._connected = True

    async def disconnect(self) -> None:
        if self._pool:
            pool = self._pool

            def _close():
                pool.close()

            await self._run(_close)
            self._pool = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._pool:
            return False
        try:
            pool = self._pool

            def _check():
                with pool.acquire() as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT 1 FROM DUAL")
                        return cur.fetchone() is not None

            return await self._run(_check)
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        assert self._pool, "Not connected"

        table_query = """
            SELECT table_name
            FROM ALL_TABLES
            WHERE owner = :owner
            ORDER BY table_name
        """

        column_query = """
            SELECT column_name, data_type, nullable
            FROM ALL_TAB_COLUMNS
            WHERE owner = :owner AND table_name = :table_name
            ORDER BY column_id
        """

        pk_query = """
            SELECT acc.column_name
            FROM ALL_CONSTRAINTS ac
            JOIN ALL_CONS_COLUMNS acc
                ON ac.constraint_name = acc.constraint_name
                AND ac.owner = acc.owner
            WHERE ac.owner = :owner
              AND ac.table_name = :table_name
              AND ac.constraint_type = 'P'
        """

        fk_query = """
            SELECT
                ac.table_name        AS from_table,
                acc.column_name      AS from_column,
                rc.table_name        AS to_table,
                rcc.column_name      AS to_column
            FROM ALL_CONSTRAINTS ac
            JOIN ALL_CONS_COLUMNS acc
                ON ac.constraint_name = acc.constraint_name
                AND ac.owner = acc.owner
            JOIN ALL_CONSTRAINTS rc
                ON ac.r_constraint_name = rc.constraint_name
                AND ac.r_owner = rc.owner
            JOIN ALL_CONS_COLUMNS rcc
                ON rc.constraint_name = rcc.constraint_name
                AND rc.owner = rcc.owner
                AND acc.position = rcc.position
            WHERE ac.owner = :owner
              AND ac.constraint_type = 'R'
        """

        row_count_query = """
            SELECT table_name, num_rows
            FROM ALL_TABLES
            WHERE owner = :owner
        """

        stats_query = """
            SELECT table_name, column_name, num_distinct, num_nulls, sample_size
            FROM ALL_TAB_COL_STATISTICS
            WHERE owner = :owner
        """

        owner = self.config.username.upper()
        pool = self._pool

        def _fetch():
            with pool.acquire() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(table_query, owner=owner)
                    table_names = [r[0] for r in cursor.fetchall()]

                    # Row counts
                    cursor.execute(row_count_query, owner=owner)
                    row_estimates = {r[0]: (r[1] or 0) for r in cursor.fetchall()}

                    # FK relationships
                    cursor.execute(fk_query, owner=owner)
                    fk_rows = cursor.fetchall()

                    # Column statistics
                    cursor.execute(stats_query, owner=owner)
                    stat_rows = cursor.fetchall()

                    # Build FK lookup and relationships
                    fk_columns: set[tuple[str, str]] = set()
                    relationships: list[Relationship] = []
                    for from_table, from_col, to_table, to_col in fk_rows:
                        fk_columns.add((from_table, from_col))
                        relationships.append(Relationship(
                            from_table=from_table,
                            from_field=from_col,
                            to_table=to_table,
                            to_field=to_col,
                            rel_type="fk",
                        ))

                    # Build stats map
                    stats_map: dict[tuple[str, str], FieldDistribution] = {}
                    for tname, cname, num_distinct, num_nulls, sample_size in stat_rows:
                        null_frac = 0.0
                        if sample_size and sample_size > 0 and num_nulls is not None:
                            null_frac = num_nulls / sample_size
                        stats_map[(tname, cname)] = FieldDistribution(
                            distinct_count=int(num_distinct or 0),
                            null_fraction=null_frac,
                        )

                    # Build tables with PKs and enriched fields
                    tables: list[TableSchema] = []
                    for tname in table_names:
                        cursor.execute(column_query, owner=owner, table_name=tname)
                        col_rows = cursor.fetchall()

                        cursor.execute(pk_query, owner=owner, table_name=tname)
                        pk_columns = {r[0] for r in cursor.fetchall()}

                        fields = []
                        for col in col_rows:
                            col_name, data_type, nullable = col
                            fields.append(
                                FieldSchema(
                                    name=col_name,
                                    data_type=data_type,
                                    nullable=nullable == "Y",
                                    is_primary=col_name in pk_columns,
                                    is_foreign_key=(tname, col_name) in fk_columns,
                                    distribution=stats_map.get((tname, col_name)),
                                )
                            )

                        tables.append(TableSchema(
                            name=tname,
                            fields=fields,
                            row_count_estimate=row_estimates.get(tname, 0),
                        ))

            return tables, relationships

        tables, relationships = await self._run(_fetch)

        return SchemaMetadata(
            connector_type=ConnectorType.ORACLE,
            database=self.config.database,
            tables=tables,
            relationships=relationships,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        # Oracle statements may end with semicolons — strip before parsing
        sql = query.strip().rstrip(";").strip()
        if not sql:
            return ValidationResult(is_valid=False, error="Empty query")

        # Block multi-statement queries
        statements = [s for s in sqlparse.parse(sql) if str(s).strip()]
        if len(statements) > 1:
            return ValidationResult(
                is_valid=False,
                blocked_reason="Multi-statement queries are not permitted",
            )

        first_keyword = _get_statement_type(sql)

        if first_keyword in _BLOCKED_DDL:
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL operation '{first_keyword}' is not permitted",
            )

        # DML flows through — RBAC owns per-table decisions.
        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        assert self._pool, "Not connected"

        # Strip trailing semicolons (Oracle driver rejects them)
        sql = query.raw_query.strip().rstrip(";").strip()
        # Row-cap injection is handled upstream by Guardrails (SELECTs only,
        # rendered as ``FETCH FIRST n ROWS ONLY`` via sqlglot's Oracle
        # dialect using ``policy.safety.max_rows_per_query``). Writes
        # pass through untouched.

        validation = await self.validate_query(sql)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.ORACLE,
                database=self.config.database,
                error=validation.blocked_reason or validation.error,
                query_executed=sql,
            )

        pool = self._pool
        start = time.monotonic()
        try:
            def _execute(q=sql):
                with pool.acquire() as conn:
                    with conn.cursor() as cursor:
                        cursor.execute(q)
                        # Only SELECT-style statements have a description;
                        # INSERT/UPDATE/DELETE/MERGE return None and would
                        # raise DPY-1003 from fetchall().
                        if cursor.description is not None:
                            return ("rows", cursor.fetchall(), cursor.description)
                        # DML — commit and return affected-row count.
                        affected = cursor.rowcount
                        conn.commit()
                        return ("rowcount", affected, None)

            kind, payload, description = await self._run(_execute)
            elapsed_ms = (time.monotonic() - start) * 1000

            if kind == "rows":
                columns = [col[0] for col in description] if description else []
                result_rows = [dict(zip(columns, row)) for row in payload]
            else:
                columns = ["rows_affected"]
                result_rows = [{"rows_affected": payload}]

            return QueryResult(
                connector_type=ConnectorType.ORACLE,
                database=self.config.database,
                columns=columns,
                rows=result_rows,
                total_count=len(result_rows),
                execution_time_ms=elapsed_ms,
                query_executed=sql,
            )

        except Exception as e:
            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.ORACLE,
                database=self.config.database,
                error=str(e),
                execution_time_ms=elapsed_ms,
                query_executed=sql,
            )
