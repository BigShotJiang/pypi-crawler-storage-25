"""
Weaviate connector for faz.

Uses weaviate-client v4 (gRPC + HTTP).
Schema discovery via schema.get() API.
Supports both semantic (nearText) and structured (where filter / BM25) queries.
Read-only: schema mutations and object writes are never permitted.
"""

import json
import time
from typing import Any

import weaviate
import weaviate.classes as wvc
from weaviate.classes.query import MetadataQuery
from weaviate.exceptions import WeaviateQueryError

from .base import (
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Weaviate data types mapped to readable labels
_WEAVIATE_TYPE_MAP = {
    "text": "text",
    "text[]": "text[]",
    "int": "int",
    "int[]": "int[]",
    "number": "float",
    "number[]": "float[]",
    "boolean": "bool",
    "boolean[]": "bool[]",
    "date": "date",
    "date[]": "date[]",
    "uuid": "uuid",
    "object": "object",
    "object[]": "object[]",
    "blob": "blob",
    "geoCoordinates": "geo",
    "phoneNumber": "phone",
}

# Query modes supported
_QUERY_MODES = {
    # Reads
    "fetch", "bm25", "near_text", "near_vector", "hybrid", "select",
    # Writes (RBAC owns whether the policy permits these per class).
    "insert", "insertone", "insertmany", "upsert",
    "update", "updateone", "replace", "replaceone",
    "delete", "deleteone", "deletemany",
}
_DDL_MODES = {
    "create_collection", "createcollection",
    "delete_collection", "deletecollection",
    "drop_collection", "dropcollection",
    "alter_collection", "altercollection",
}


class WeaviateConnector(BaseConnector):
    """
    Async-compatible Weaviate connector using weaviate-client v4.

    Supports:
    - Schema discovery via schema API (classes → properties)
    - Semantic search (nearText), keyword search (BM25), hybrid, and fetch
    - Read-only by design: no object creation, update, or deletion
    - Audit-ready: serialised query parameters returned in QueryResult

    Query modes (set via IntermediateQuery.intent):
      - "fetch"       : Retrieve objects with optional where filter
      - "bm25"        : Keyword search via BM25
      - "near_text"   : Semantic search using text concepts
      - "near_vector" : Semantic search using a raw vector
      - "hybrid"      : Combined BM25 + vector search
    """

    CONNECTOR_TYPE = ConnectorType.WEAVIATE

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: weaviate.WeaviateClient | None = None

    async def connect(self) -> None:
        # weaviate-client v4 uses a synchronous connect but is thread-safe
        self._client = weaviate.connect_to_custom(
            http_host=self.config.host,
            http_port=self.config.port,
            http_secure=self.config.ssl,
            grpc_host=self.config.host,
            grpc_port=self.config.extra.get("grpc_port", 50051),
            grpc_secure=self.config.ssl,
            auth_credentials=(
                wvc.init.Auth.api_key(self.config.password)
                if self.config.password else None
            ),
        )
        self._client.connect()
        self._connected = True

    async def disconnect(self) -> None:
        if self._client:
            self._client.close()
            self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            return self._client.is_ready()
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        Fetch all Weaviate collections (classes) and their property definitions.
        Each collection maps to a TableSchema; each property maps to a FieldSchema.
        """
        assert self._client is not None, "Not connected"

        raw_schema = self._client.collections.list_all(simple=False)
        tables: list[TableSchema] = []

        for coll_name, coll_config in raw_schema.items():
            fields: list[FieldSchema] = []

            for prop in coll_config.properties:
                # data_type is a list in v4 (e.g. [DataType.TEXT])
                raw_types = prop.data_type
                if hasattr(raw_types, "value"):
                    # Single DataType enum
                    type_str = _WEAVIATE_TYPE_MAP.get(raw_types.value, raw_types.value)
                elif isinstance(raw_types, list):
                    type_str = " | ".join(
                        _WEAVIATE_TYPE_MAP.get(getattr(t, "value", str(t)), str(t))
                        for t in raw_types
                    )
                else:
                    type_str = str(raw_types)

                fields.append(FieldSchema(
                    name=prop.name,
                    data_type=type_str,
                    description=prop.description or "",
                ))

            # Get approximate object count
            try:
                collection = self._client.collections.get(coll_name)
                agg = collection.aggregate.over_all(total_count=True)
                count = agg.total_count or 0
            except Exception:
                count = 0

            tables.append(TableSchema(
                name=coll_name,
                fields=fields,
                row_count_estimate=count,
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.WEAVIATE,
            database=f"{self.config.host}:{self.config.port}",
            tables=tables,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        """Validate the requested mode.

        Reads + DML (insert/update/replace/delete) flow through; RBAC
        owns per-class decisions. Hard-block ``*_collection`` mode
        (DDL — schema mutations).
        """
        mode = query.strip().lower().replace("_", "")
        if mode in _DDL_MODES or any(mode == d.replace("_", "") for d in _DDL_MODES):
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL mode '{mode}' is hard-blocked at the connector regardless of policy.",
            )
        normalized = {m.replace("_", "") for m in _QUERY_MODES}
        if mode not in normalized:
            return ValidationResult(
                is_valid=False,
                error=f"Unknown query mode '{mode}'. Supported: {sorted(_QUERY_MODES)}",
            )
        return ValidationResult(is_valid=True)

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Lift intent + payload from raw_query JSON.

        Agents send ``{"intent":"upsert","properties":{...},"uuid":"..."}``
        or similar. We override ``query.intent`` and stash structured
        fields into ``query.filters`` so ``execute()`` can read them.
        """
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query

        intent = (
            parsed.get("intent") or parsed.get("operation")
            or parsed.get("mode") or ""
        ).strip().lower().replace("_", "")
        if intent:
            query.intent = intent

        for key in ("properties", "uuid", "uuids", "vector", "vectors",
                    "items", "where", "filter", "concepts", "certainty",
                    "query", "alpha", "ids", "id"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]
        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Weaviate query based on intent/mode.

        IntermediateQuery fields used:
          - intent:   one of "fetch", "bm25", "near_text", "near_vector", "hybrid"
          - tables:   [CollectionName]
          - fields:   properties to return (empty = return all)
          - limit:    max objects to return
          - filters:  mode-specific params (see below per intent)

        filters dict per intent:
          fetch:       {"where": <weaviate filter dict>}
          bm25:        {"query": "search terms", "properties": ["prop1", ...]}
          near_text:   {"concepts": ["concept1", ...], "certainty": 0.7}
          near_vector: {"vector": [...], "certainty": 0.7}
          hybrid:      {"query": "search terms", "alpha": 0.5}
        """
        assert self._client is not None, "Not connected"

        # Lift intent + payload from raw_query before dispatching.
        query = self._parse_raw_query(query)

        mode = query.intent.lower().replace("_", "")
        # Map generic "select" intent to Weaviate's "fetch" mode.
        if mode == "select":
            mode = "fetch"
        validation = await self.validate_query(mode)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.WEAVIATE,
                database=f"{self.config.host}:{self.config.port}",
                error=validation.error,
            )

        if not query.tables:
            return QueryResult(
                connector_type=ConnectorType.WEAVIATE,
                database=f"{self.config.host}:{self.config.port}",
                error="No collection specified",
            )

        coll_name = query.tables[0]
        limit = min(query.limit, 1000)
        return_props = query.fields if query.fields else None
        filters_cfg = query.filters

        start = time.monotonic()
        try:
            collection = self._client.collections.get(coll_name)
            query_repr: dict[str, Any] = {"mode": mode, "collection": coll_name}

            if mode == "fetch":
                where_filter = filters_cfg.get("where")
                result = collection.query.fetch_objects(
                    limit=limit,
                    return_properties=return_props,
                    filters=_build_where_filter(where_filter) if where_filter else None,
                )
                query_repr["where"] = where_filter

            elif mode == "bm25":
                bm25_query = filters_cfg.get("query", "")
                bm25_props = filters_cfg.get("properties")
                result = collection.query.bm25(
                    query=bm25_query,
                    query_properties=bm25_props,
                    limit=limit,
                    return_properties=return_props,
                )
                query_repr["query"] = bm25_query

            elif mode == "near_text":
                concepts = filters_cfg.get("concepts", [])
                certainty = filters_cfg.get("certainty", 0.7)
                result = collection.query.near_text(
                    query=concepts,
                    certainty=certainty,
                    limit=limit,
                    return_properties=return_props,
                    return_metadata=MetadataQuery(certainty=True, score=True),
                )
                query_repr.update({"concepts": concepts, "certainty": certainty})

            elif mode == "near_vector":
                vector = filters_cfg.get("vector", [])
                certainty = filters_cfg.get("certainty", 0.7)
                result = collection.query.near_vector(
                    near_vector=vector,
                    certainty=certainty,
                    limit=limit,
                    return_properties=return_props,
                    return_metadata=MetadataQuery(certainty=True, score=True),
                )
                query_repr["certainty"] = certainty

            elif mode == "hybrid":
                hybrid_query = filters_cfg.get("query", "")
                alpha = filters_cfg.get("alpha", 0.5)
                result = collection.query.hybrid(
                    query=hybrid_query,
                    alpha=alpha,
                    limit=limit,
                    return_properties=return_props,
                )
                query_repr.update({"query": hybrid_query, "alpha": alpha})

            elif mode in ("insert", "insertone", "upsert"):
                # collection.data.insert returns the new uuid as a string.
                props = filters_cfg.get("properties") or {}
                uuid_arg = filters_cfg.get("uuid")
                vec = filters_cfg.get("vector")
                kwargs: dict[str, Any] = {"properties": props}
                if uuid_arg:
                    kwargs["uuid"] = uuid_arg
                if vec is not None:
                    kwargs["vector"] = vec
                new_uuid = collection.data.insert(**kwargs)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"uuid": str(new_uuid), "result": "created"}]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": mode, "collection": coll_name}),
                )

            elif mode == "insertmany":
                items = filters_cfg.get("items") or filters_cfg.get("properties") or []
                if not isinstance(items, list):
                    return QueryResult(
                        connector_type=ConnectorType.WEAVIATE,
                        database=f"{self.config.host}:{self.config.port}",
                        error="insertMany requires `items` (or `properties`) as an array",
                    )
                bulk_result = collection.data.insert_many(items)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "inserted": getattr(bulk_result, "all_responses", None) and len(bulk_result.all_responses) or len(items),
                    "has_errors": getattr(bulk_result, "has_errors", False),
                }]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": "insertMany", "count": len(items)}),
                )

            elif mode in ("update", "updateone"):
                uuid_arg = filters_cfg.get("uuid")
                props = filters_cfg.get("properties") or {}
                if not uuid_arg:
                    return QueryResult(
                        connector_type=ConnectorType.WEAVIATE,
                        database=f"{self.config.host}:{self.config.port}",
                        error="update requires `uuid`",
                    )
                collection.data.update(uuid=uuid_arg, properties=props)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"uuid": str(uuid_arg), "result": "updated"}]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": "update", "uuid": str(uuid_arg)}),
                )

            elif mode in ("replace", "replaceone"):
                uuid_arg = filters_cfg.get("uuid")
                props = filters_cfg.get("properties") or {}
                if not uuid_arg:
                    return QueryResult(
                        connector_type=ConnectorType.WEAVIATE,
                        database=f"{self.config.host}:{self.config.port}",
                        error="replace requires `uuid`",
                    )
                collection.data.replace(uuid=uuid_arg, properties=props)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"uuid": str(uuid_arg), "result": "replaced"}]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": "replace", "uuid": str(uuid_arg)}),
                )

            elif mode in ("delete", "deleteone"):
                uuid_arg = filters_cfg.get("uuid")
                if not uuid_arg:
                    return QueryResult(
                        connector_type=ConnectorType.WEAVIATE,
                        database=f"{self.config.host}:{self.config.port}",
                        error="delete requires `uuid`",
                    )
                ok = collection.data.delete_by_id(uuid=uuid_arg)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"uuid": str(uuid_arg), "deleted": bool(ok)}]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": "delete", "uuid": str(uuid_arg)}),
                )

            elif mode == "deletemany":
                where = filters_cfg.get("where") or filters_cfg.get("filter")
                if not where:
                    return QueryResult(
                        connector_type=ConnectorType.WEAVIATE,
                        database=f"{self.config.host}:{self.config.port}",
                        error=("deleteMany requires `where` filter — empty filter "
                               "= mass-wipe, refused as an unintended DDL"),
                    )
                bulk_result = collection.data.delete_many(
                    where=_build_where_filter(where),
                )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "matches": getattr(bulk_result, "matches", 0),
                    "successful": getattr(bulk_result, "successful", 0),
                    "failed": getattr(bulk_result, "failed", 0),
                }]
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    columns=list(rows[0].keys()), rows=rows, total_count=1,
                    execution_time_ms=elapsed_ms,
                    query_executed=json.dumps({"mode": "deleteMany"}),
                )

            else:
                return QueryResult(
                    connector_type=ConnectorType.WEAVIATE,
                    database=f"{self.config.host}:{self.config.port}",
                    error=f"Unsupported mode: {mode}",
                )

            elapsed_ms = (time.monotonic() - start) * 1000

            rows = []
            for obj in result.objects:
                row = {"uuid": str(obj.uuid)}
                if obj.properties:
                    row.update({k: v for k, v in obj.properties.items()})
                if hasattr(obj, "metadata") and obj.metadata:
                    if obj.metadata.score is not None:
                        row["_score"] = obj.metadata.score
                    if obj.metadata.certainty is not None:
                        row["_certainty"] = obj.metadata.certainty
                rows.append(row)

            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.WEAVIATE,
                database=f"{self.config.host}:{self.config.port}",
                columns=columns,
                rows=rows,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=json.dumps(query_repr),
            )

        except WeaviateQueryError as e:
            return QueryResult(
                connector_type=ConnectorType.WEAVIATE,
                database=f"{self.config.host}:{self.config.port}",
                error=str(e),
            )


def _build_where_filter(where_dict: dict) -> Any:
    """
    Build a weaviate-client v4 Filter object from a plain dict.
    Expected format: {"path": ["property"], "operator": "Equal", "valueText": "foo"}
    """
    from weaviate.classes.query import Filter

    path = where_dict.get("path", [])
    operator = where_dict.get("operator", "Equal")
    prop = path[0] if path else ""

    op_map = {
        "Equal": lambda v: Filter.by_property(prop).equal(v),
        "NotEqual": lambda v: Filter.by_property(prop).not_equal(v),
        "GreaterThan": lambda v: Filter.by_property(prop).greater_than(v),
        "GreaterThanEqual": lambda v: Filter.by_property(prop).greater_or_equal(v),
        "LessThan": lambda v: Filter.by_property(prop).less_than(v),
        "LessThanEqual": lambda v: Filter.by_property(prop).less_or_equal(v),
        "Like": lambda v: Filter.by_property(prop).like(v),
        "ContainsAny": lambda v: Filter.by_property(prop).contains_any(v),
        "ContainsAll": lambda v: Filter.by_property(prop).contains_all(v),
    }

    value = (
        where_dict.get("valueText")
        or where_dict.get("valueInt")
        or where_dict.get("valueNumber")
        or where_dict.get("valueBoolean")
    )

    builder = op_map.get(operator)
    if builder and value is not None:
        return builder(value)
    return None
