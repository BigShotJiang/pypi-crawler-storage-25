"""
Neo4j connector for faz.

Uses the official neo4j synchronous driver (bolt protocol, port 7687) wrapped
with run_in_executor for async compatibility. This avoids the "Future attached
to a different loop" errors that occur with AsyncGraphDatabase when the driver
is shared across pytest-asyncio module-scoped fixtures.

Schema discovery via CALL db.labels() and CALL db.relationshipTypes().
Read-only enforcement: write clauses are blocked before execution.
"""

import asyncio
import time
from typing import Any

import neo4j
from neo4j import GraphDatabase
from neo4j.graph import Node, Relationship

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    Relationship as QBRelationship,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

CONNECTOR_TYPE = ConnectorType.NEO4J

# Clauses that mutate the graph — always blocked
_WRITE_CLAUSES = {"CREATE", "MERGE", "SET", "DELETE", "REMOVE", "DROP", "DETACH"}


def _neo4j_value_to_python(value: Any) -> Any:
    """Recursively convert neo4j driver types to plain Python objects."""
    if isinstance(value, Node):
        result = dict(value.items())
        result["_labels"] = list(value.labels)
        result["_element_id"] = value.element_id
        return result
    if isinstance(value, Relationship):
        result = dict(value.items())
        result["_type"] = value.type
        result["_element_id"] = value.element_id
        return result
    if isinstance(value, list):
        return [_neo4j_value_to_python(v) for v in value]
    if isinstance(value, dict):
        return {k: _neo4j_value_to_python(v) for k, v in value.items()}
    return value


def _record_to_dict(record: neo4j.Record) -> dict[str, Any]:
    """Convert a neo4j record to a plain Python dict."""
    return {key: _neo4j_value_to_python(record[key]) for key in record.keys()}


class Neo4jConnector(BaseConnector):
    """
    Async-compatible Neo4j connector using the synchronous bolt driver via run_in_executor.

    Supports:
    - Schema discovery via CALL db.labels() and CALL db.relationshipTypes()
    - Read-only enforcement: write clauses are blocked before execution
    - Node/Relationship serialisation to plain dicts
    - Audit-ready: validated query string returned in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.NEO4J

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._driver: neo4j.Driver | None = None

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    async def connect(self) -> None:
        uri = f"bolt://{self.config.host}:{self.config.port}"
        auth = (self.config.username, self.config.password)

        def _connect():
            driver = GraphDatabase.driver(uri, auth=auth)
            driver.verify_connectivity()
            return driver

        self._driver = await self._run(_connect)
        self._connected = True

    async def disconnect(self) -> None:
        if self._driver:
            driver = self._driver
            await self._run(driver.close)
            self._driver = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._driver:
            return False
        try:
            driver = self._driver

            def _check():
                with driver.session() as session:
                    result = session.run("RETURN 1 AS alive")
                    record = result.single()
                    return record is not None and record["alive"] == 1

            return await self._run(_check)
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect the Neo4j database:
        - Node labels → TableSchema (each label is a table)
        - Properties inferred from a sample node (LIMIT 1)
        - Relationship types appended as additional TableSchema entries
        """
        assert self._driver is not None, "Not connected"
        driver = self._driver

        def _fetch():
            tables: list[TableSchema] = []
            relationships: list[QBRelationship] = []

            with driver.session() as session:
                # --- Node labels ---
                labels_result = session.run("CALL db.labels() YIELD label RETURN label")
                labels = [record["label"] for record in labels_result]

                for label in labels:
                    # Sample a node for properties
                    sample_result = session.run(
                        f"MATCH (n:`{label}`) RETURN n LIMIT 1"
                    )
                    record = sample_result.single()

                    fields: list[FieldSchema] = []
                    if record is not None:
                        node: Node = record["n"]
                        for prop_name, prop_value in node.items():
                            fields.append(FieldSchema(
                                name=prop_name,
                                data_type=type(prop_value).__name__,
                            ))

                    # Estimate node count
                    count_result = session.run(
                        f"MATCH (n:`{label}`) RETURN count(n) AS cnt"
                    )
                    count_record = count_result.single()
                    row_count = count_record["cnt"] if count_record else 0

                    tables.append(TableSchema(
                        name=label,
                        fields=fields,
                        row_count_estimate=row_count,
                        description=f"Neo4j node label: {label}",
                    ))

                # --- Relationship types with direction ---
                rel_result = session.run(
                    "CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType"
                )
                rel_types = [record["relationshipType"] for record in rel_result]

                for rel_type in rel_types:
                    # Get relationship properties + direction (start/end labels)
                    sample_result = session.run(
                        f"MATCH (a)-[r:`{rel_type}`]->(b) "
                        f"RETURN r, labels(a) AS from_labels, labels(b) AS to_labels LIMIT 1"
                    )
                    record = sample_result.single()

                    fields = []
                    if record is not None:
                        rel: Relationship = record["r"]
                        for prop_name, prop_value in rel.items():
                            fields.append(FieldSchema(
                                name=prop_name,
                                data_type=type(prop_value).__name__,
                            ))

                        from_label = record["from_labels"][0] if record["from_labels"] else "?"
                        to_label = record["to_labels"][0] if record["to_labels"] else "?"

                        relationships.append(QBRelationship(
                            from_table=from_label,
                            from_field=rel_type,
                            to_table=to_label,
                            to_field=rel_type,
                            rel_type="edge",
                        ))

                    tables.append(TableSchema(
                        name=f"REL_{rel_type}",
                        fields=fields,
                        description=f"Neo4j relationship type: {rel_type}",
                    ))

            return tables, relationships

        tables, relationships = await self._run(_fetch)

        return SchemaMetadata(
            connector_type=ConnectorType.NEO4J,
            database=f"{self.config.host}:{self.config.port}",
            tables=tables,
            relationships=relationships,
        )

    async def validate_query(self, query: str) -> ValidationResult:
        """Validate a Cypher query.

        Cypher writes (CREATE / MERGE / SET / DELETE / DETACH DELETE /
        REMOVE) flow through — RBAC_GATE owns per-label write decisions
        in the faz safety pipeline. The connector still hard-blocks DDL
        (DROP INDEX / DROP CONSTRAINT / CREATE INDEX / CREATE
        CONSTRAINT / etc.) as a defense-in-depth backstop.
        """
        upper = query.strip().upper()
        tokens = upper.split()

        # Hard-block DDL (CREATE / DROP / ALTER on INDEX / CONSTRAINT /
        # DATABASE / USER / ROLE — schema-level operations Cypher exposes).
        ddl_objects = {
            "INDEX", "CONSTRAINT", "DATABASE", "USER", "ROLE",
            "FULLTEXT", "TEXT", "RANGE", "POINT", "LOOKUP",
        }
        for i, token in enumerate(tokens[:-1]):
            verb = token.rstrip("(,;)")
            obj = tokens[i + 1].rstrip("(,;)")
            if verb in {"CREATE", "DROP", "ALTER"} and obj in ddl_objects:
                return ValidationResult(
                    is_valid=False,
                    blocked_reason=(
                        f"Cypher DDL '{verb} {obj}' is hard-blocked at "
                        "the connector regardless of policy."
                    ),
                )

        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Cypher query from an IntermediateQuery.

        Steps:
          1. Validate the raw_query string.
          2. Append LIMIT clause if not present.
          3. Run via synchronous session in executor.
          4. Serialise records to list of dicts.
          5. Return QueryResult with audit fields.
        """
        assert self._driver is not None, "Not connected"

        database_label = f"{self.config.host}:{self.config.port}"
        cypher = query.raw_query.strip()

        # Validate
        validation = await self.validate_query(cypher)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.NEO4J,
                database=database_label,
                error=validation.error,
            )

        # LIMIT injection is handled upstream by Guardrails using the
        # configured ``safety.max_rows_per_query``. The connector
        # neither hardcodes a value nor mangles writes that have no
        # RETURN clause to attach LIMIT to.

        driver = self._driver
        start = time.monotonic()
        try:
            def _execute(q=cypher):
                with driver.session() as session:
                    result = session.run(q)
                    return [_record_to_dict(r) for r in result]

            records = await self._run(_execute)
            elapsed_ms = (time.monotonic() - start) * 1000
            columns = list(records[0].keys()) if records else []

            return QueryResult(
                connector_type=ConnectorType.NEO4J,
                database=database_label,
                rows=records,
                columns=columns,
                total_count=len(records),
                execution_time_ms=elapsed_ms,
                query_executed=cypher,
            )

        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.NEO4J,
                database=database_label,
                error=str(exc),
                execution_time_ms=elapsed_ms,
                query_executed=cypher,
            )
