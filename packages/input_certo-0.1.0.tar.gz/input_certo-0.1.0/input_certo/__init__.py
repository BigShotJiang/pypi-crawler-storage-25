from .inputs import input_num, input_maior, input_menor, input_intervalo, input_altura, input_peso, input_idade, input_str, input_tam, input_caractere
