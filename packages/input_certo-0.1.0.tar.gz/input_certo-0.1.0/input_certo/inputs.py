# ---------------------------------------
#      funções referentes a números
# ---------------------------------------

def input_num(msg: str, end: str =' ', tipo: str ='reais') -> float | int:
    '''
    Solicita a entrada de um número (int ou float) e repete o input até que não ocorra nenhum erro.

    Args:
        msg (str): Mensagem solicitando a entrada.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
        tipo (str, optional): Tipo do número solicitado. (Default: 'reais').
            Tipos:
            - 'int': Retornará um número inteiro. (Também é aceito 'inteiros' de forma parcial).
            - 'float': Retornará um número float. (Qualquer parâmetro que não for 'inteiros' retornará float).
    
    Returns:
        Número tipo int ou float.
    '''
    while True:
        try:
            num = input(f'{msg}{end}').replace(',', '.').strip()

            if not any(char.isdigit() for char in num):
                from text_to_num import text2num       # biblioteca para transformar números por extenso de string para inteiro
                num = text2num(num, 'pt')
            
            if (tipo.lower() in 'inteiros') and tipo:
                num = int(num)
            else:
                num = float(num)

        except ValueError:
            print_erro(f'Digite apenas números {tipo}.')

        else:
            break
    
    return num

def input_maior(msg: str, minimo: float, end: str =' ', tipo: str ='reais', dado: str ='o valor', unidade: str ='') -> float | int:
    '''
    Solicita uma entrada de um número mínimo (int ou float) e repete o input até que não ocorra nenhum erro e que o número esteja no mínimo solicitado.

    Args:
        msg (str): Mensagem solicitando a entrada.
        minimo (float): Valor mínimo que a entrada deve ter.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
        dado (str, optional): Qual é o dado solicitado. (Default: 'o valor').
        unidade (str, optional): Unidade de medida utilizada para o dado solicitado. (Default: '').
        tipo (str, optional): Tipo do número solicitado. (Default: 'reais').
            Tipos:
            - 'int': Retornará um número inteiro. (Também é aceito 'inteiros' de forma parcial).
            - 'float': Retornará um número float. (Qualquer parâmetro que não for 'inteiros' retornará float).
    
    Returns:
        Número (int ou float) com o valor mínimo solicitado.
    '''
    while True:
        num_maior = input_num(msg, end, tipo)

        if num_maior < minimo:
            print_erro(f'{dado.capitalize()} deve ser, no mínimo, {minimo}{unidade}.', tipo='aviso')
        else:
            break
    
    return num_maior

def input_menor(msg: str, maximo: float, end: str =' ', tipo: str ='reais', dado: str ='o valor', unidade: str ='') -> float | int:
    '''
    Solicita a entrada de um número com valor máximo (int ou float) e repete o input até que não ocorra nenhum erro e que o número esteja no máximo solicitado.

    Args:
        msg (str): Mensagem solicitando a entrada.
        maximo (float): Valor máximo que a entrada pode ter.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
        dado (str, optional): Qual é o dado solicitado. (Default: 'o valor').
        unidade (str, optional): Unidade de medida utilizada para o dado solicitado. (Default: '').
        tipo (str, optional): Tipo do número solicitado. (Default: 'reais').
            Tipos:
            - 'int': Retornará um número inteiro. (Também é aceito 'inteiros' de forma parcial).
            - 'float': Retornará um número float. (Qualquer parâmetro que não for 'inteiros' retornará float).
    
    Returns:
        Número (int ou float) com o valor mínimo solicitado.
    '''
    while True:
        num_menor = input_num(msg, end, tipo)

        if num_menor > maximo:
            print_erro(f'{dado.capitalize()} deve ser, no máximo, {maximo}{unidade}.', tipo='aviso')
        else:
            break

    return num_menor

def input_intervalo(msg: str, minimo: float, maximo: float, dado: str ='o valor', end: str =' ', tipo: str ='reais', unidade: str ='') -> float | int:
    '''
    Solicita a entrada de um número em um intervalo (int ou float) e repete o input até que não ocorra nenhum erro e que o número esteja no intervalo solicitado.

    Args:
        msg (str): Mensagem solicitando a entrada.
        minimo (float): Valor mínimo que a entrada deve ter.
        maximo (float): Valor máximo que a entrada pode ter.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
        dado (str, optional): Qual é o dado solicitado. (Default: 'o valor').
        unidade (str, optional): Unidade de medida utilizada para o dado solicitado. (Default: '').
        tipo (str, optional): Tipo do número solicitado. (Default: 'reais').
            Tipos:
            - 'int': Retornará um número inteiro. (Também é aceito 'inteiros' de forma parcial).
            - 'float': Retornará um número float. (Qualquer parâmetro que não for 'inteiros' retornará float).
    
    Returns:
        Número (int ou float) no intervalo solicitado.
    '''
    while True:
        num_intervalo = input_num(msg, end, tipo)

        if (num_intervalo < minimo) or (num_intervalo > maximo):
            if num_intervalo < minimo:
                if tipo in 'inteiros':
                    print_erro(f'{dado.capitalize()} deve ser, no mínimo, {minimo}{unidade}.', tipo='aviso')
                else:
                    print_erro(f'{dado.capitalize()} deve ser, no mínimo, {minimo:.2f}{unidade}.', tipo='aviso')
            
            if num_intervalo > maximo:
                if tipo in 'inteiros':
                    print_erro(f'{dado.capitalize()} deve ser, no máximo, {maximo}{unidade}.', tipo='aviso')
                else:
                    print_erro(f'{dado.capitalize()} deve ser, no máximo, {maximo:.2f}{unidade}.', tipo='aviso')
        else:
            break
    
    return num_intervalo

def input_altura(msg: str, end: str =' ') -> float:
    '''
    Solicita a entrada de uma altura em metros (float) e repete o input até que não ocorra nenhum erro e esteja dentro de limites físicos e biológicos conhecidos.

    Os recordes de pessoa mais alta e mais baixa registrados foram tirados de:

    Pessoas mais altas:
    https://en.wikipedia.org/wiki/List_of_tallest_people

    Pessoas mais baixas:
    https://en.wikipedia.org/wiki/List_of_the_verified_shortest_people

    Args:
        msg (str): Mensagem solicitando a entrada.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        Altura em metros (float).
    '''
    dados = coletar_dados()
    alturas = {'minima': dados['altura_minima'], 'maxima': dados['altura_maxima']}

    altura = input_intervalo(msg, alturas['minima'], alturas['maxima'], 'a altura', end, unidade='m')

    return altura

def input_peso(msg: str, end: str =' ') -> float:
    '''
    Solicita a entrada de um peso em quilogramas (float) e repete o input até que não ocorra nenhum erro e esteja dentro de limites físicos e biológicos conhecidos.

    Os recordes de pessoa mais pesadas e leves registrados foram tirados de:

    Pessoas mais pesadas:
    https://en.wikipedia.org/wiki/List_of_heaviest_people

    Pessoas mais leves:
    https://www.guinnessworldrecords.com/world-records/67485-lightest-person

    Args:
        msg (str): Mensagem solicitando a entrada.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        Altura em metros (float).
    '''

    dados = coletar_dados()
    pesos = {'minimo': dados['peso_minimo'], 'maximo': dados['peso_maximo']}    

    peso = input_intervalo(msg, pesos['minimo'], pesos['maximo'], 'o peso', end, unidade='kg')

    return peso

def input_idade(msg: str, end: str=' ') -> int:
    '''
    Solicita a entrada de uma idade em anos (int) e repete o input até que não ocorra nenhum erro e esteja dentro de limites de logenvidade conhecidos.

    Os recordes de supercentenários registrados foram tirados de:
        https://pt.wikipedia.org/wiki/Lista_das_pessoas_mais_velhas_do_mundo

    Args:
        msg (str): Mensagem solicitando a entrada.
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        (int) Idade em anos.
    '''
    dados = coletar_dados()
    idades = {'minimo': 0, 'maximo': dados['idade_maxima']}

    idade = input_intervalo(msg, idades['minimo'], idades['maximo'], 'a idade', end, 'int', ' anos')

    return idade


# ---------------------------------------
#      funções referentes a strings
# ---------------------------------------

def input_str(msg: str ='', end: str =' ') -> str:
    '''
    Solicita a entrada de uma string e aplica a função strip() para remover espaços no início e final da string.

    Args:
        msg (str, optional): Mensagem solicitando a entrada. (Default: '')
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        String sem espaços no início ou fim.
    '''
    string = str(input(f'{msg}{end}')).strip()

    return string

def input_tam(msg: str, maximo: int, minimo: int =1, end: str =' ') -> str:
    '''
    Solicita a entrada de uma string com tamanho específico e repete o input até que a string seja do tamanho solicitado. (O nome é pelo "tamanho" da string que será validada)

    Args:
        msg (str): Mensagem solicitando a entrada.
        maximo (int): Tamanho máximo que a string pode ter.
        minimo (int, optional): Tamanho mínimo que a string deve ter. (Default: 1)
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        String dentro do tamano solicitado.
    '''
    while True:
        string_tam = input_str(msg, end)

        if len(string_tam) < minimo:
            print_erro(f'A resposta deve ter mais que {minimo - 1} caracteres.', tipo='aviso')
        elif len(string_tam) > maximo:
            print_erro(f'A resposta deve ter menos que {maximo + 1} caracteres.', tipo='aviso')
        else:
            break

def input_caractere(msg: str, end: str =' ', especifico: str ='abcçdefghijklmnopqrstuvwxyz') -> str:
    '''
    Solicita a entrada de apenas um caractere e repete o input até que a string tenha apenas um caractere.

    Args:
        msg (str): Mensagem solicitando a entrada.
        especifico (str, optional): String que contenha todos os caracteres aceitos. (Default: 'abcdefghijklmnopqrstuvwxyz')
        end (str, optional): O que aparecerá após a mensagem. (Default: ' ').
    
    Returns:
        Caractere (string) que está contido dentro dos caracteres solicitados.
    '''
    while True:
        caracter = input_str(msg, end)
        
        if (caracter.lower() in especifico) and (len(caracter) == 1):
            break
        else:
            if not len(caracter) == 1:
                print_erro('A resposta deve possuir um caracter.', tipo='aviso')
            else:
                print_erro('Resposta inválida.', tipo='aviso')
    
    return caracter[0]


# ------------------------
#     outras funções
# ------------------------

def print_erro(msg, tipo='erro'):
    if tipo.lower() == 'aviso':
        cor = '33'
        tipo = tipo.capitalize()
    else:
        cor = '31'
        tipo = 'Erro'

    print(f'\033[1;{cor}m{tipo}: \033[0;{cor}m{msg} \nTente novamente:\033[m \n')

def coletar_dados():
    import json
    from importlib import resources

    try:
        with resources.files('input_certo').joinpath('recordes.json').open('r') as recordes:
            return json.load(recordes)
    except FileNotFoundError:
        return {"altura_minima": 0.55, "altura_maxima": 2.72, "peso_minimo": 2.1, "peso_maximo": 635, "idade_maxima": 122}
    
