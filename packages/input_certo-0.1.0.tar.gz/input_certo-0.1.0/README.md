# 👤📚 INPUT CERTO
Biblioteca para Python feita para evitar alguns erros recorrentes (causados pelo usuário ao ser solicitada uma entrada) em exercícios utilizando o terminal.

---

## 💻 Exemplo
Como utilizar uma função da biblioteca:
```
from input_certo import input_num

num = input_num('Digite um número inteiro:', tipo='int')
print(num)
```
Repetirá esse `input` no terminal até que a entrada seja um número do tipo passado por parâmetro, mostrando os erros.

**Saída:** Um número tipo `int`

---

## 🔩 Instalação
Para instalar a biblioteca utilizando `pip`, digite esse comando em seu terminal:

`pip install input_certo`

---

## 📖 Funções
Lista das funções disponíveis na biblioteca:
Função | Descrição | Paramêtros obrigatórios | Retorno
---|---|---|---
`input_num()` | Repete o `input` até que a entrada seja válida. | msg: `string` | `float` ou `int`
`input_maior()` | Repete o `input` até que a entrada seja maior que um valor mínimo. | msg: `string`, minimo: `float` | `float` ou `int`
`input_menor()` | Repete o `input` até que a entrada seja menor que um valor máximo. | msg: `string`, maximo: `float` | `float` ou `int`
`input_intervalo()` | Repete o `input` até que a entrada esteja em um intervalo de valores específicados. | msg: `string`, minimo: `float`, maximo: `float` | `float` ou `int`
`input_altura()` | Repete o `input` até que a entrada seja uma altura válida. | msg: `string` | `float` (metros)
`input_peso()` | Repete o `input` até que a entrada seja um peso válido. | msg: `string` | `float` (quilogramas)
`input_idade()` | Repete o `input` até que a entrada seja uma idade válida. | msg: `string` | `int` (anos)
`input_str()` | Solicita a entrada de uma `string` e retira espaços no início e fim. | Argumentos opcionais. | `string`
`input_tam()` | Repete o `input` até que a entrada seja uma `string` com tamanho em um intervalo especificado. | msg: `string`, maximo: `int` | `string`
`input_caractere()` | Repete o `input` até que a entrada seja um caractere apenas, que esteja dentro dos `caracteres` aceitos. | msg: `string` | `string` (apenas um caractere)

- [x] Aceita números escritos por extenso

---

## 🌐 Fontes
Algumas funções, como `input_altura()`, `input_peso()` e `input_idade()` utilizam dados externos para definir os mínimos e máximos plausíveis e respeitando limitações físicas e biológicas.

Para buscar essas informações, foram utilizadas essas fontes:

- [Pessoas mais Altas (Wikipédia)](https://en.wikipedia.org/wiki/List_of_tallest_people)

- [Pessoas mais Baixas (Wikipédia)](https://en.wikipedia.org/wiki/List_of_the_verified_shortest_people)

- [Pessoas mais Pesadas (Wikipédia)](https://en.wikipedia.org/wiki/List_of_heaviest_people)

- [Pessoa mais Leve (Guinness World Records)](https://www.guinnessworldrecords.com/world-records/67485-lightest-person)

- [Lista de Supercentenários (Wikipédia)](https://pt.wikipedia.org/wiki/Lista_das_pessoas_mais_velhas_do_mundo)

## 📜 Depedências
Ao instalar a biblioteca, também é preciso instalar as seguintes bibliotecas para total funcionamento (essas são instaladas automáticamente com `pip` ao instalar a biblioteca):

- `text2num`

---

Essa biblioteca ainda terá atualizações futuras...