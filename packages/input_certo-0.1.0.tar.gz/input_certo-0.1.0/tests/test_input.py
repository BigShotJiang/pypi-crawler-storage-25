from input_certo import *

if __name__ == '__main__':
    
    # funções para números

    num = input_num('Digite um número inteiro', end=': ', tipo='int')
    print(num, '\n')

    num_maior = input_maior('Digite um número positivo', end=': ', minimo=0, tipo='int')
    print(num_maior, '\n')

    num_menor = input_menor('Digite um menor que 1000', end=': ', maximo=1000, tipo='int')
    print(num_menor, '\n')

    num_intervalo = input_intervalo('Digite número entre 0 e 1000', end=': ', minimo=0, maximo=1000, tipo='int')
    print(num_intervalo, '\n')

    peso = input_peso('Digite seu peso (kg)', end=': ')
    print(peso, '\n')

    altura = input_altura('Digite sua altura (m)', end=': ')
    print(altura, '\n')

    idade = input_idade('Digite sua idade', end=': ')
    print(idade, '\n')

    # funções para strings

    string = input_str('Digite uma frase', end=': ')
    print(string, '\n')

    string_tam = input_tam('Digite string entre 5 e 10 caracteres:', minimo=5, maximo=10)
    print(string)

    caracter = input_caractere('Digite S ou N.', end=': ', especifico='sn')
    print(caracter)
