from .client import TikSync, TikSyncAPI

__version__ = "1.0.0"
__all__ = ["TikSync", "TikSyncAPI"]

_native = None
try:
    import tiksync_native as _native
except ImportError:
    pass
