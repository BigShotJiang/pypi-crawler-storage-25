import asyncio
import json
import logging
from typing import Callable, Optional
from urllib.parse import urlencode

import aiohttp

logger = logging.getLogger("tiksync")

API_URL = "https://api.tik-sync.com"


class TikSyncAPI:
    def __init__(self, api_key: str, api_url: str = API_URL):
        self.api_key = api_key
        self.api_url = api_url.rstrip("/")
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"x-api-key": self.api_key}
            )
        return self._session

    async def sign(self, unique_id: str) -> dict:
        session = await self._get_session()
        async with session.post(
            f"{self.api_url}/v1/sign",
            json={"uniqueId": unique_id},
        ) as resp:
            return await resp.json()

    async def health(self) -> dict:
        session = await self._get_session()
        async with session.get(f"{self.api_url}/v1/health") as resp:
            return await resp.json()

    async def usage(self) -> dict:
        session = await self._get_session()
        async with session.get(
            f"{self.api_url}/v1/usage",
        ) as resp:
            return await resp.json()

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()


class TikSync:
    def __init__(
        self,
        unique_id: str,
        api_key: str,
        api_url: str = API_URL,
        max_reconnect_attempts: int = 3,
        reconnect_delay: float = 5.0,
    ):
        if not api_key or not api_key.strip():
            raise ValueError(
                "\n\n"
                "  ╔══════════════════════════════════════════════════════════╗\n"
                "  ║  TikSync API key required                              ║\n"
                "  ║                                                        ║\n"
                "  ║  Get your free API key at:                             ║\n"
                "  ║  → https://tik-sync.com/sign-up                       ║\n"
                "  ║                                                        ║\n"
                "  ║  Then use: TikSync(unique_id, api_key='ts_...')        ║\n"
                "  ║                                                        ║\n"
                "  ║  Free tier: 1,000 requests/day, 10 WS connections     ║\n"
                "  ╚══════════════════════════════════════════════════════════╝\n"
            )
        self.unique_id = unique_id
        self.api_key = api_key.strip()
        self.api_url = api_url.rstrip("/")
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_delay = reconnect_delay
        self._listeners: dict[str, list[Callable]] = {}
        self._ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._running = False
        self._reconnect_count = 0
        self._native = None

        try:
            from tiksync import _native
            if _native:
                _native.init(api_key)
                self._native = _native
        except Exception:
            pass

    def on(self, event: str, callback: Callable):
        self._listeners.setdefault(event, []).append(callback)
        return self

    def _emit(self, event: str, data=None):
        for cb in self._listeners.get(event, []):
            if asyncio.iscoroutinefunction(cb):
                asyncio.ensure_future(cb(data))
            else:
                cb(data)

    async def connect(self):
        self._running = True
        self._reconnect_count = 0
        await self._connect_ws()

    async def _connect_ws(self):
        params = urlencode({"uniqueId": self.unique_id})
        ws_url = self.api_url.replace("https://", "wss://").replace("http://", "ws://")
        url = f"{ws_url}/v1/connect?{params}"

        headers = {}
        if self.api_key:
            headers["x-api-key"] = self.api_key
        if self._native:
            try:
                sec_headers = self._native.get_connect_headers()
                headers.update(sec_headers)
            except Exception:
                pass

        self._session = aiohttp.ClientSession()
        try:
            self._ws = await self._session.ws_connect(url, headers=headers)
            self._reconnect_count = 0
            logger.info("Connected to %s", self.unique_id)
            self._emit("connected", {"uniqueId": self.unique_id})

            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    try:
                        event = json.loads(msg.data)
                        event_type = event.get("type", "unknown")
                        self._emit(event_type, event.get("data", event))
                    except json.JSONDecodeError:
                        logger.warning("Invalid JSON: %s", msg.data[:100])
                elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                    break

        except Exception as e:
            logger.error("Connection error: %s", e)
            self._emit("error", e)

        finally:
            if self._session and not self._session.closed:
                await self._session.close()

        if self._running:
            await self._try_reconnect()

    async def _try_reconnect(self):
        if self._reconnect_count >= self.max_reconnect_attempts:
            logger.error("Max reconnection attempts reached")
            self._emit("disconnected", {"reason": "max_reconnect"})
            return

        self._reconnect_count += 1
        delay = self.reconnect_delay * self._reconnect_count
        logger.info("Reconnecting in %.1fs (attempt %d/%d)", delay, self._reconnect_count, self.max_reconnect_attempts)
        await asyncio.sleep(delay)
        await self._connect_ws()

    async def disconnect(self):
        self._running = False
        if self._ws and not self._ws.closed:
            await self._ws.close()
        if self._session and not self._session.closed:
            await self._session.close()
        self._emit("disconnected", {"reason": "manual"})
