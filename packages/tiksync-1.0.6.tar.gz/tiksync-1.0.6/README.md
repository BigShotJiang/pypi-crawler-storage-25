<p align="center">
  <img src="https://raw.githubusercontent.com/tiksync/.github/main/profile/logo-96.png" width="60" alt="TikSync" />
</p>

<h1 align="center">TikSync Python SDK</h1>

<p align="center">
  <strong>TikTok Live SDK for Python</strong> - Real-time chat, gifts, likes, follows & viewer events.<br>
  <a href="https://pypi.org/project/tiksync/"><img src="https://img.shields.io/pypi/v/tiksync.svg" alt="PyPI"></a>
  <a href="https://opensource.org/licenses/MIT"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="License: MIT"></a><br>
  <a href="https://tik-sync.com">Website</a> - <a href="https://tik-sync.com/docs">Documentation</a> - <a href="https://tik-sync.com/pricing">Pricing</a>
</p>

---

## Installation

```bash
pip install tiksync
```

## Quick Start

```python
from tiksync import TikSync

live = TikSync("username", api_key="your_api_key")

@live.on("chat")
def on_chat(data):
    print(f"[{data['uniqueId']}] {data['comment']}")

@live.on("gift")
def on_gift(data):
    print(f"{data['uniqueId']} sent {data['giftName']} x{data['repeatCount']}")

@live.on("follow")
def on_follow(data):
    print(f"{data['uniqueId']} followed!")

live.connect()
```

## Events

| Event | Description |
|-------|-------------|
| `connected` | Connected to stream |
| `chat` | Chat message received |
| `gift` | Gift received (with diamond count, streak info) |
| `like` | Likes received |
| `follow` | New follower |
| `share` | Stream shared |
| `member` | User joined the stream |
| `roomUser` | Viewer count update |
| `streamEnd` | Stream ended |
| `disconnected` | Disconnected |
| `error` | Connection error |

## Get Started

1. Sign up at [tik-sync.com](https://tik-sync.com)
2. Create a free API key in your dashboard
3. Install the SDK and start building

Free tier available. See [pricing](https://tik-sync.com/pricing) for details.

## License

MIT - Built by [0xwolfsync](https://tik-sync.com)
