from setuptools import setup, find_packages

setup(
    name="tiksync",
    version="1.0.6",
    description="TikSync — TikTok Live SDK for Python. Real-time chat, gifts, likes & viewer events.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="0xwolfsync",
    author_email="contact@tik-sync.com",
    url="https://tik-sync.com",
    project_urls={
        "Documentation": "https://tik-sync.com/docs",
        "Source": "https://github.com/tiksync/tiksync-python",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["aiohttp>=3.8"],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
    ],
    keywords=["tiktok", "tiktok-live", "websocket", "api", "sdk", "gifts", "chat"],
    license="MIT",
)
