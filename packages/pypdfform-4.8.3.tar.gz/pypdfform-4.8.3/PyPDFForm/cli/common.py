# -*- coding: utf-8 -*-
"""
This module provides shared helpers for PyPDFForm CLI commands.

It contains utilities for loading JSON command input, registering custom fonts
once per command invocation, and converting grouped JSON element definitions
into the objects expected by `PdfWrapper` methods.
"""

import json
from pathlib import Path
from typing import Annotated, Any, NoReturn

import typer
from jsonschema import ValidationError, validate

from .. import PdfWrapper
from ..lib.middleware.base import Widget

INPUT_PDF = Annotated[
    Path,
    typer.Argument(
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Input PDF path.",
    ),
]
REQUIRED_OUTPUT_PDF = Annotated[
    Path,
    typer.Option(
        "--output",
        "-o",
        file_okay=True,
        dir_okay=False,
        writable=True,
        resolve_path=True,
        help="Output PDF path.",
    ),
]
OPTIONAL_OUTPUT_PDF = Annotated[
    Path | None,
    typer.Option(
        "--output",
        "-o",
        file_okay=True,
        dir_okay=False,
        writable=True,
        resolve_path=True,
        help="Output PDF path. Overwrites the input when omitted.",
    ),
]
FIELD_NAME = Annotated[str, typer.Option("--field", help="Form field name.")]


def json_file_option(help_text: str):
    """
    Creates the common validated JSON file option.

    Args:
        help_text (str): Help text to display for the option.

    Returns:
        typer.Option: A configured `--file` / `-f` option for JSON file input.
    """
    return typer.Option(
        "--file",
        "-f",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help=help_text,
    )


def cli_bad_parameter(
    message: str,
    param_hint: str,
    cause: BaseException | None = None,
) -> NoReturn:
    """
    Raises a Typer input error with a stable CLI message.

    Args:
        message (str): Error message to display to the CLI user.
        param_hint (str): CLI parameter associated with the error.
        cause (BaseException, optional): Original exception that caused the CLI
            error. Defaults to None.

    Raises:
        typer.BadParameter: Raised with the provided message and parameter hint.
    """
    if cause is None:
        raise typer.BadParameter(message, param_hint=param_hint)

    raise typer.BadParameter(message, param_hint=param_hint) from cause


def _validation_error_path(exc: ValidationError) -> str:
    """
    Builds a dotted JSON path for a validation error.

    Args:
        exc (ValidationError): The JSON schema validation error.

    Returns:
        str: Dotted path for the failing instance location.
    """
    return ".".join(str(each) for each in exc.absolute_path)


def load_json_file(data: Path, schema: dict, param_hint: str) -> Any:
    """
    Loads a JSON CLI input file and validates it against a schema.

    Args:
        data (Path): JSON file path.
        schema (dict): JSON schema to validate against.
        param_hint (str): CLI parameter associated with the JSON file.

    Returns:
        Any: Parsed and validated JSON input.

    Raises:
        typer.BadParameter: Raised when the file cannot be loaded or validation
            fails.
    """
    try:
        with open(data, "r", encoding="utf-8") as f:
            input_data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        cli_bad_parameter(
            f"Invalid JSON file: {exc}",
            param_hint=param_hint,
            cause=exc,
        )

    try:
        validate(instance=input_data, schema=schema)
    except ValidationError as exc:
        error_path = _validation_error_path(exc)
        location = f" at {error_path}" if error_path else ""
        cli_bad_parameter(
            f"Invalid JSON file{location}: {exc.message}",
            param_hint=param_hint,
            cause=exc,
        )

    return input_data


def get_widget(wrapper: PdfWrapper, field: str, param_hint: str) -> Widget:
    """
    Look up a widget and report missing names as CLI input errors.

    Args:
        wrapper (PdfWrapper): PDF wrapper containing form widgets.
        field (str): Form field name to look up.
        param_hint (str): CLI parameter associated with the field name.

    Returns:
        Widget: The matching widget.

    Raises:
        typer.BadParameter: Raised when the widget name is not present.
    """
    try:
        return wrapper.widgets[field]
    except KeyError as exc:
        cli_bad_parameter(
            f"Form field '{field}' does not exist.",
            param_hint=param_hint,
            cause=exc,
        )


def handle_font_registration(
    obj: PdfWrapper, params: dict, registered_font: dict
) -> None:
    """
    Registers a custom font referenced by CLI input.

    CLI JSON files may provide a file path in a `font` parameter. This helper
    registers each unique font path on the supplied `PdfWrapper` once, assigns
    it a generated internal font name, and mutates `params["font"]` to that
    registered name so downstream field or element constructors can use it.

    Args:
        obj (PdfWrapper): The wrapper for the PDF currently being modified.
        params (dict): The element or widget parameters loaded from JSON. This
            dictionary is mutated when it contains a `font` key.
        registered_font (dict): Mapping of source font paths to generated
            `PdfWrapper` font names for the current command invocation.
    """
    if "font" in params:
        if params["font"] not in registered_font:
            font_name = f"new_font_{len(registered_font)}"
            obj.register_font(font_name, params["font"])
            registered_font[params["font"]] = font_name
        params["font"] = registered_font[params["font"]]


def create_elements_from_file(
    pdf: Path,
    data: Path,
    element_map: dict,
    schema: dict,
    method_name: str,
    ctx: typer.Context,
    param_hint: str,
    output: Path | None = None,
) -> None:
    """
    Creates PDF elements from grouped JSON definitions.

    The input JSON is expected to group element definitions by type, such as
    `text`, `image`, or `highlight`. Each group key is resolved through
    `element_map`, each item is constructed after optional font registration,
    and the resulting objects are passed to `method_name` on `PdfWrapper`.
    The modified PDF is written to `output` or back to the input path.

    Args:
        pdf (Path): The path to the input PDF file.
        data (Path): The path to the JSON file containing grouped element
            definitions.
        element_map (dict): Mapping from JSON group names to element classes or
            callables used to construct each object.
        schema (dict): JSON schema used to validate the grouped definitions.
        method_name (str): Name of the `PdfWrapper` method that accepts the
            constructed elements, such as `bulk_create_fields`, `draw`, or
            `annotate`.
        ctx (typer.Context): Typer context containing global wrapper options in
            `ctx.obj`.
        param_hint (str): CLI parameter associated with the JSON file.
        output (Path, optional): Path where the modified PDF should be saved. If
            omitted, the input PDF is overwritten. Defaults to None.
    """
    input_data = load_json_file(data, schema, param_hint)

    obj = PdfWrapper(str(pdf), **ctx.obj)
    ungrouped_input = []
    registered_font = {}
    for k, v in input_data.items():
        for each in v:
            handle_font_registration(obj, each, registered_font)
            ungrouped_input.append(element_map[k](**each))

    getattr(obj, method_name)(ungrouped_input).write(output or pdf)
