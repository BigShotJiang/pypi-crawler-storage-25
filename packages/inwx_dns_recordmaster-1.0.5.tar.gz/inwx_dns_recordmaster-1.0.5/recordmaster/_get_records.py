# SPDX-FileCopyrightText: 2024 Max Mehl <https://mehl.mx>
#
# SPDX-License-Identifier: GPL-3.0-only

"""Functions for handling local configuration files."""

import json
import logging
import sys
from pathlib import Path

import yaml
from INWX.Domrobot import ApiClient
from jsonschema import FormatChecker, validate
from jsonschema.exceptions import ValidationError

from ._api import inwx_api
from ._data import Domain, Record

RECORDS_SCHEMA = {
    "type": "object",
    "properties": {},  # we have no predefined properties
    "additionalProperties": {  # domain, can have any key name
        "type": "object",
        "properties": {  # --options key
            "--options": {
                "type": "object",
                "properties": {
                    "preserve_remote": {"type": "boolean"},
                    "ignore_types": {"type": "string"},
                },
                "additionalProperties": False,
            },
        },
        "additionalProperties": {  # subdomain, can have any key name
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {"type": "string"},
                    "content": {"type": "string"},
                    "ttl": {"type": "integer"},
                    "prio": {"type": "integer"},
                },
                "required": ["type", "content"],
                "additionalProperties": False,
            },
        },
    },
}


def find_valid_local_records_files(configdir: str) -> list[str]:
    """Get all local domain configuration files."""
    logging.debug("Gather locally configured domains from configuration directory '%s'", configdir)

    dcfg_files_abs = []

    for entry in Path(configdir).iterdir():
        filepath = str(entry.resolve())
        if filepath.endswith((".yaml", ".yml")):
            dcfg_files_abs.append(filepath)
        elif filepath.endswith((".sample", ".git")):
            pass
        else:
            logging.warning(
                "File '%s' does not match naming convention and will be ignored",
                filepath,
            )

    return dcfg_files_abs


def validate_config_schema(cfg: dict, schema: dict) -> None:
    """Validate the config against a JSON schema."""
    try:
        validate(instance=cfg, schema=schema, format_checker=FormatChecker())
    except ValidationError as e:
        logging.critical("Config validation failed: %s", e.message)
        raise ValueError(e) from None
    logging.debug("Config validated successfully against schema.")


def combine_local_records(records_files: list[str]) -> dict:
    """Combine all valid local records configuration files and put into one big dict."""
    local_records_config: dict = {}

    for recfile in records_files:
        with open(recfile, encoding="UTF-8") as ymlfile:
            try:
                logging.debug("Loading records file '%s'", recfile)
                ymldata = yaml.safe_load(ymlfile)
                validate_config_schema(ymldata, RECORDS_SCHEMA)
                local_records_config = local_records_config | ymldata
            except yaml.YAMLError:
                logging.exception("Loading configuration from '%s' failed", recfile)

    return local_records_config


def convert_dict_to_yaml(data: dict) -> str:
    """Convert a dict to YAML."""
    # sort data alphabetically, and make sure . will always be first
    data_sorted = {}
    for domain, records in data.items():
        records_sorted = dict(sorted(records.items(), key=lambda item: (item[0] != ".", item[0])))
        data_sorted[domain] = records_sorted

    # Dump as YAML
    return yaml.dump(data_sorted, sort_keys=False, allow_unicode=True)


def convert_local_records_to_data(domain: Domain, records: dict) -> None:
    """Read domain configuration with records from local file and put into dataclass."""
    # If no records present, create empty dict
    if records is None:
        records = {}

    # Read local domain config
    logging.debug("[%s] Reading local domain config: %s", domain.name, records)
    # Records for main domain are under the `.` key
    root_records = records.pop(".", {})
    # Read `--options` key
    domain.options = records.pop("--options", {})
    # All the other keys are supposed to be subdomains
    sub_records = {k: records[k] for k in set(records.keys())}

    # Adding root records
    for rec in root_records:
        record = Record()

        record.import_records(data=rec, remote=False, domain=domain.name)

        domain.local_records.append(record)

    # Adding subdomain records
    for subdomain, recs in sub_records.items():
        # The local configuration layout is a bit different from INWX' internal
        # data model, to make configuration files a bit shorter. We convert this
        # here.
        for rec in recs:
            record = Record()

            record.import_records(data=rec, remote=False, root=domain.name, domain=subdomain)

            domain.local_records.append(record)


def check_local_records_config(domain: str, records: list[Record]) -> None:
    """Find common errors in local records confiuration files."""
    # Find records with IDs
    local_ids = [rec for rec in records if rec.id is not None]
    if local_ids:
        logging.error(
            "[%s] You set IDs in your local configuration for the following "
            "records. This is forbidden. %s",
            domain,
            local_ids,
        )
        sys.exit(1)

    # Find local records whose name+type+content is equal
    duplicates = []
    seen = set()
    for rec in records:
        # Create a "signature" for each local record
        signature = (rec.type, rec.name, rec.content)
        # Signature has already been seen before -> duplicate
        if signature in seen:
            duplicates.append(rec)
        # Otherwise, note as "seen" for the first time
        else:
            seen.add(signature)

    if duplicates:
        logging.error(
            "[%s] These locally defined records carry the same type, name, and "
            "content as an earlier one. This is forbidden and would lead to "
            "strange results: %s",
            domain,
            duplicates,
        )
        sys.exit(1)

    # TTL and Prio no ints
    no_ints = [
        rec for rec in records if not isinstance(rec.ttl, int) or not isinstance(rec.prio, int)
    ]
    if no_ints:
        logging.error(
            "[%s] These locally defined records contain 'ttl' and/or 'prio' "
            "values that are not integers: %s",
            domain,
            no_ints,
        )
        sys.exit(1)


def derive_domain_options(domain: Domain, **global_options: str | bool) -> None:
    """
    Save valid options for domain in dataclass.

    If set locally, this overrides the global option.
    """
    for option, global_value in global_options.items():
        # If no local option is set, we use the global value
        if option not in domain.options:
            domain.options[option] = global_value
        # Inform when global option diverges from the local option
        elif global_value != domain.options[option]:
            logging.info(
                "[%s] In the domain configuration, the option '%s' is set to '%s' "
                "while the program is invoked with '%s'. The domain-specific "
                "option will override the global option.",
                domain.name,
                option,
                domain.options[option],
                global_value,
            )

    # ignore_types is typically a string, but we need in as listg in multiple
    # places. Do the conversion here
    domain.options["ignore_types"] = [s.strip() for s in domain.options["ignore_types"].split(",")]


def convert_remote_records_to_data(api: ApiClient, domain: Domain, api_response_file: str) -> None:
    """Request domain configuration with records from the remote (INWX) and put into dataclass."""
    # Load remote configuration from remote via API call, or from local file
    if not api_response_file:
        domain_remote = inwx_api(api, "nameserver.info", domain=domain.name)["resData"]
    else:
        with open(api_response_file, encoding="UTF-8") as jsonfile:
            domain_remote = json.load(jsonfile)

    domain.id = domain_remote["roId"]

    for rec in domain_remote["record"]:
        record = Record()

        record.import_records(data=rec, remote=True)

        domain.remote_records.append(record)

    # Update domain stats
    domain.stats.total_remote = len(domain.remote_records)
