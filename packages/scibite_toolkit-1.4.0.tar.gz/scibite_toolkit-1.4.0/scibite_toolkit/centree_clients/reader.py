"""
reader.py

CENtreeReaderClient provides read-only access to ontologies in a CENtree server.
Supports entity lookups, label-based queries, tree navigation, and metadata inspection.
"""

import logging
from logging import NullHandler
from .base import CENtreeClient
from typing import Optional, Union

# ── Logging config ──────────────────────────────────────────
logger = logging.getLogger("scibite_toolkit.centree_clients.reader")
logger.addHandler(NullHandler())
# ────────────────────────────────────────────────────────────


class CENtreeReaderClient(CENtreeClient):
    """
    A client class for read-only operations on CENtree ontologies.
    Provides methods to query ontology metadata, entities, and perform lookups.
    """
    def __init__(
        self,
        base_url: Optional[str] = None,
        bearer_token: Optional[str] = None,
        verify: Union[bool, str] = True,
        **kwargs,
    ):
        super().__init__(base_url=base_url, bearer_token=bearer_token, verify=verify, **kwargs)
        logger.debug("Initialized CENtreeReaderClient base_url=%s", self.base_url)

    # ── Search Methods ──────────────────────────────────────────

    def search(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
            boost_priority: Optional[str] = None,
    ) -> dict:
        """
        General search across ontologies.

        Parameters
        ----------
        query : str
            The search query string.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification. Available values : RELEVANCE, ASC
        boost_priority : str, optional
            Boost priority weighting. Available values : PREFIX, FUZZY, EXACT_CASE_INSENSITIVE.
            Default value : FUZZY

        Returns
        -------
        dict
            JSON response with structure: {"from": int, "total": int, "elements": list}

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort
        if boost_priority:
            params["boostPriority"] = boost_priority

        logger.debug("General search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    # Alias for clarity that search() searches classes
    search_classes = search

    def search_exact(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for exact matches across ontologies.

        Parameters
        ----------
        query : str
            The search term for exact match.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/classes/exact"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Exact search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_contains(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for terms containing the query string.

        Parameters
        ----------
        query : str
            The search term to find within labels.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/classes/contains"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Contains search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_starts_with(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for terms starting with the query string.

        Parameters
        ----------
        query : str
            The search term prefix.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/classes/startsWith"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Starts-with search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_ends_with(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for terms ending with the query string.

        Parameters
        ----------
        query : str
            The search term suffix.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/classes/endsWith"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Ends-with search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_instances(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
            boost_priority: Optional[str] = None,
    ) -> dict:
        """
        Search for ontology instances/individuals.

        Parameters
        ----------
        query : str
            The search query string.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.
        boost_priority : str, optional
            Boost priority weighting.

        Returns
        -------
        dict
            JSON response with paginated instance results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/instances"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort
        if boost_priority:
            params["boostPriority"] = boost_priority

        logger.debug("Instance search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_instances_exact(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for instances with exact label/identifier match.

        Parameters
        ----------
        query : str
            The search term for exact match.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated instance results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/instances/exact"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Exact instance search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_properties(
            self,
            query: str,
            property_type: Optional[Union[str, list[str]]] = None,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
            boost_priority: Optional[str] = None,
    ) -> dict:
        """
        Search for ontology properties/relations.

        Parameters
        ----------
        query : str
            The search query string.
        property_type : str or list of str, optional
            Filter by property type (e.g., "annotation", "object", "data").
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.
        boost_priority : str, optional
            Boost priority weighting.

        Returns
        -------
        dict
            JSON response with paginated property results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/properties"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if property_type:
            params["propertyType"] = ([property_type] if isinstance(property_type, str) else property_type)
        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort
        if boost_priority:
            params["boostPriority"] = boost_priority

        logger.debug("Property search query=%r propertyType=%r ontologies=%r",
                     query, params.get("propertyType"), params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_properties_exact(
            self,
            query: str,
            property_type: Optional[Union[str, list[str]]] = None,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for properties with exact match.

        Parameters
        ----------
        query : str
            The search term for exact match.
        property_type : str or list of str, optional
            Filter by property type (e.g., "annotation", "object", "data").
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated property results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/properties/exact"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if property_type:
            params["propertyType"] = ([property_type] if isinstance(property_type, str) else property_type)
        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Exact property search query=%r propertyType=%r ontologies=%r",
                     query, params.get("propertyType"), params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_ontologies(
            self,
            query: Optional[str] = None,
            type_filter: Optional[str] = None,
            page: int = 0,
            size: int = 10,
            sort_by_field: Optional[str] = None,
            sort_order: Optional[str] = None,
    ) -> dict:
        """
        Search for ontologies or list all ontologies.

        Parameters
        ----------
        query : str, optional
            Search query for ontology metadata. If not provided, lists all ontologies.
        type_filter : str, optional
            Filter by ontology type.
        page : int, default 0
            Page number (0-indexed).
        size : int, default 10
            Number of results per page.
        sort_by_field : str, optional
            Field to sort by.
        sort_order : str, optional
            Sort order ("ASC" or "DESC").

        Returns
        -------
        dict
            JSON response with ontology metadata.

        Raises
        ------
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        endpoint = "/api/search/ontologies"
        params: dict[str, Union[str, int]] = {
            "page": page,
            "size": size,
        }

        if query:
            params["q"] = query
        if type_filter:
            params["type"] = type_filter
        if sort_by_field:
            params["sortByField"] = sort_by_field
        if sort_order:
            params["sortOrder"] = sort_order

        logger.debug("Ontology search query=%r type=%r page=%d", query, type_filter, page)
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_exact_multiple(
            self,
            ontology_id: str,
            identifiers: list[str],
    ) -> dict:
        """
        Search for multiple identifiers at once within an ontology.

        Accepts short form IDs (``EFO:0000001``, ``EFO_0000001``) as well as
        full IRIs.  Returns a single ``resultList`` containing all matched
        entities — unmatched identifiers are silently omitted.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to search within (e.g. ``"efo"``).
        identifiers : list of str
            List of identifiers to look up.  Accepts short form IDs
            (``"EFO:0000001"``, ``"EFO_0000001"``) or full IRIs.

        Returns
        -------
        dict
            Response with a ``resultList`` key containing one dict per matched
            entity.  Each entity dict includes at minimum:

            - ``id`` (str): Internal CENtree hash ID (for use in edit operations).
            - ``primaryID`` (str): Full IRI of the class.
            - ``primaryLabel`` (str): Main label.
            - ``synonyms`` (list[str]): Synonym labels.
            - ``shortFormIDs`` (list[str]): Short-form identifiers (CURIEs).
            - ``entityType`` (str): Entity type, e.g. ``"class"``.
            - ``annotationProperties`` (dict): Annotation property values.
            - ``propertyValues`` (list[dict]): Property values with tags.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `identifiers` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> results = client.search_exact_multiple("efo", ["EFO:0000001", "EFO_0000002"])
        >>> for entity in results["resultList"]:
        ...     print(entity["primaryID"], entity["primaryLabel"])
        ...     print(entity["id"])  # hash ID for edit operations
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not identifiers or not isinstance(identifiers, list):
            raise ValueError("identifiers must be a non-empty list")

        endpoint = f"/api/search/{ontology_id}/exactMultiple"
        params = {"identifiers": identifiers}

        logger.debug("Exact multiple search ontology=%r count=%d", ontology_id, len(identifiers))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_obsolete(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for obsolete/deprecated classes.

        Parameters
        ----------
        query : str
            The search query string.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated obsolete class results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/obsolete"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Obsolete search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def search_obsolete_exact(
            self,
            query: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
            from_: int = 0,
            size: int = 10,
            sort: Optional[str] = None,
    ) -> dict:
        """
        Search for obsolete/deprecated classes with exact match.

        Parameters
        ----------
        query : str
            The search term for exact match.
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results per page.
        sort : str, optional
            Sort specification.

        Returns
        -------
        dict
            JSON response with paginated obsolete class results.

        Raises
        ------
        ValueError
            If `query` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not query:
            raise ValueError("query is required")

        endpoint = "/api/search/obsolete/exact"
        params: dict[str, Union[str, int, list[str]]] = {
            "q": query,
            "from": from_,
            "size": size,
        }

        if ontology_list:
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)
        if sort:
            params["sort"] = sort

        logger.debug("Exact obsolete search query=%r ontologies=%r", query, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    # ── Export Methods ──────────────────────────────────────────

    def export_owl(
            self,
            ontology_id: str,
            owl_format: str = "RDFXML",
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in OWL/RDF format (asynchronous).

        This triggers an asynchronous export job. Use the returned job ID to monitor
        progress and retrieve the file once complete.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        owl_format : str, default "RDFXML"
            Export format. Options: "OBO", "RDFXML", "OWLXML", "OWLFUNC", "N3",
            "TURTLE", "JSONLD", "MOS".
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `owl_format` is invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="...", bearer_token="...")
        >>> job = client.export_owl("efo", owl_format="TURTLE")
        >>> job_id = job["job"]["id"]
        >>> # Poll job status and download when complete
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        valid_formats = {"OBO", "RDFXML", "OWLXML", "OWLFUNC", "N3", "TURTLE", "JSONLD", "MOS"}
        if owl_format not in valid_formats:
            raise ValueError(f"owl_format must be one of {valid_formats}")

        endpoint = f"/api/ontologies/{ontology_id}/export"
        params = {
            "owlFormat": owl_format,
            "withJobDetails": str(with_job_details).lower(),
        }

        logger.debug("Exporting ontology %r in format %r (async)", ontology_id, owl_format)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_owl_sync(
            self,
            ontology_id: str,
            owl_format: str = "RDFXML",
            tag_name: Optional[str] = None,
    ) -> str:
        """
        Export an ontology in OWL/RDF format (synchronous).

        Returns the exported content directly without creating a background job.
        Suitable for smaller ontologies or when immediate response is needed.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        owl_format : str, default "RDFXML"
            Export format. Options: "OBO", "RDFXML", "OWLXML", "OWLFUNC", "N3",
            "TURTLE", "JSONLD", "MOS".
        tag_name : str, optional
            Optional snapshot tag name to export.

        Returns
        -------
        str
            Exported content or file reference.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `owl_format` is invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        valid_formats = {"OBO", "RDFXML", "OWLXML", "OWLFUNC", "N3", "TURTLE", "JSONLD", "MOS"}
        if owl_format not in valid_formats:
            raise ValueError(f"owl_format must be one of {valid_formats}")

        endpoint = f"/api/ontologies/{ontology_id}/export/sync"
        params = {"owlFormat": owl_format}
        if tag_name:
            params["tagName"] = tag_name

        logger.debug("Exporting ontology %r in format %r (sync)", ontology_id, owl_format)
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def export_skos(
            self,
            ontology_id: str,
            skos_format: str = "RDFXML",
            skos_xl: bool = False,
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in SKOS format (asynchronous).

        Converts the ontology to SKOS (Simple Knowledge Organization System) or SKOS-XL
        format and exports it in the specified RDF serialization.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        skos_format : str, default "RDFXML"
            RDF serialization format. Options: "RDFXML", "N3", "NTRIPLES", "TURTLE",
            "RDFXML_ABBREV".
        skos_xl : bool, default False
            Use SKOS-XL (extended label) format instead of simple SKOS.
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `skos_format` is invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="...", bearer_token="...")
        >>> job = client.export_skos("efo", skos_format="TURTLE", skos_xl=True)
        >>> job_id = job["job"]["id"]
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        valid_formats = {"RDFXML", "N3", "NTRIPLES", "TURTLE", "RDFXML_ABBREV"}
        if skos_format not in valid_formats:
            raise ValueError(f"skos_format must be one of {valid_formats}")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsSkos"
        params = {
            "skosFormat": skos_format,
            "skosXL": str(skos_xl).lower(),
            "withJobDetails": str(with_job_details).lower(),
        }

        logger.debug("Exporting ontology %r as SKOS%s in format %r",
                     ontology_id, "-XL" if skos_xl else "", skos_format)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_qtt(
            self,
            ontology_id: str,
            metadata_columns: list[str],
            qtt_template_export: bool = False,
            generate_ids: bool = False,
            number_of_generated_ids: int = 0,
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in QTT (Quick Term Template) flat file format.

        QTT is a tabular CSV-based format used for bulk ontology operations and
        spreadsheet-based maintenance.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        metadata_columns : list of str
            Array of metadata column IRIs to include in the export.
            Call `get_qtt_column_options()` to retrieve available column options.
        qtt_template_export : bool, default False
            Export an empty template instead of actual data.
        generate_ids : bool, default False
            Generate new IDs for entities.
        number_of_generated_ids : int, default 0
            Number of IDs to generate (if generate_ids is True).
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `metadata_columns` is not a list.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="...", bearer_token="...")
        >>> columns = ["http://www.w3.org/2000/01/rdf-schema#label",
        ...            "http://www.w3.org/2004/02/skos/core#definition"]
        >>> job = client.export_qtt("efo", metadata_columns=columns)
        >>> job_id = job["job"]["id"]
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not isinstance(metadata_columns, list):
            raise ValueError("metadata_columns must be a list")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsQttFlatFile"
        params = {
            "qttTemplateExport": str(qtt_template_export).lower(),
            "generateIds": str(generate_ids).lower(),
            "numberOfGeneratedIds": number_of_generated_ids,
            "withJobDetails": str(with_job_details).lower(),
        }

        logger.debug("Exporting ontology %r as QTT with %d columns",
                     ontology_id, len(metadata_columns))
        resp = self.request("POST", endpoint, params=params, json=metadata_columns)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_termite_aug(
            self,
            ontology_id: str,
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in Termite AUG format.

        Termite AUG format is used with SciBite Termite Named Entity Recognition (NER) engine.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsTermiteAugFile"
        params = {"withJobDetails": str(with_job_details).lower()}

        logger.debug("Exporting ontology %r as Termite AUG", ontology_id)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_termite_vocab(
            self,
            ontology_id: str,
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in Termite VOCAB format.

        Termite VOCAB format is used for text mining and NER applications with SciBite Termite.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsTermiteVocabFile"
        params = {"withJobDetails": str(with_job_details).lower()}

        logger.debug("Exporting ontology %r as Termite VOCAB", ontology_id)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_termite_skos(
            self,
            ontology_id: str,
            include_properties: Optional[list[str]] = None,
            skos_format: str = "TURTLE",
            termite_skos_format: str = "TERMITE_SKOS",
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology in Termite SKOS format.

        Advanced Termite integration with SKOS-based vocabularies, supporting custom
        properties and multiple SKOS variants.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        include_properties : list of str, optional
            Custom property IRIs to include in Termite metadata.
        skos_format : str, default "TURTLE"
            RDF serialization format. Options: "RDFXML", "N3", "NTRIPLES", "TURTLE",
            "RDFXML_ABBREV".
        termite_skos_format : str, default "TERMITE_SKOS"
            Termite SKOS variant. Options: "TERMITE_SKOS_AUG", "TERMITE_SKOS".
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or format options are invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        valid_skos_formats = {"RDFXML", "N3", "NTRIPLES", "TURTLE", "RDFXML_ABBREV"}
        if skos_format not in valid_skos_formats:
            raise ValueError(f"skos_format must be one of {valid_skos_formats}")

        valid_termite_formats = {"TERMITE_SKOS_AUG", "TERMITE_SKOS"}
        if termite_skos_format not in valid_termite_formats:
            raise ValueError(f"termite_skos_format must be one of {valid_termite_formats}")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsTermiteSkos"
        params: dict[str, Union[str, list[str]]] = {
            "skosFormat": skos_format,
            "termiteSkosFormat": termite_skos_format,
            "withJobDetails": str(with_job_details).lower(),
        }

        if include_properties:
            params["includePropertiesForTermite"] = include_properties

        logger.debug("Exporting ontology %r as Termite SKOS (%s)", ontology_id, termite_skos_format)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def export_vocab_flat_file(
            self,
            ontology_id: str,
            file_type: str = "CSV",
            delimiter: str = ",",
            with_job_details: bool = False,
    ) -> dict:
        """
        Export an ontology as a flat CSV or TSV file.

        Exports in a simple spreadsheet-compatible format for quick analysis and sharing.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to export.
        file_type : str, default "CSV"
            File type. Options: "CSV", "TSV", "NOT_SUPPLIED".
        delimiter : str, default ","
            Custom delimiter (e.g., use "\\t" for tab-separated values).
        with_job_details : bool, default False
            Return detailed job information in response.

        Returns
        -------
        dict
            JobSubmitResponse with job details including job ID for monitoring.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `file_type` is invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> # Export as CSV
        >>> client.export_vocab_flat_file("efo", file_type="CSV")
        >>> # Export as TSV
        >>> client.export_vocab_flat_file("efo", file_type="TSV", delimiter="\\t")
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        valid_types = {"CSV", "TSV", "NOT_SUPPLIED"}
        if file_type not in valid_types:
            raise ValueError(f"file_type must be one of {valid_types}")

        endpoint = f"/api/ontologies/{ontology_id}/exportAsVocabFlatFile"
        params = {
            "fileType": file_type,
            "delimiter": delimiter,
            "withJobDetails": str(with_job_details).lower(),
        }

        logger.debug("Exporting ontology %r as %s flat file", ontology_id, file_type)
        resp = self.request("GET", endpoint, params=params)
        if with_job_details:
            return self.json_or_raise(resp)
        else:
            resp.raise_for_status()
            return {"message": resp.text}

    def download_file(self, file_name: str) -> bytes:
        """
        Download an exported ontology file.

        After an asynchronous export job completes, use this method to retrieve
        the generated file.

        Parameters
        ----------
        file_name : str
            Name of the file to download (typically from job completion response).

        Returns
        -------
        bytes
            Binary file content.

        Raises
        ------
        ValueError
            If `file_name` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="...", bearer_token="...")
        >>> job = client.export_owl("efo", owl_format="TURTLE")
        >>> # Wait for job to complete...
        >>> file_name = job["job"]["completionMessage"]  # or from job status check
        >>> content = client.download_file(file_name)
        >>> with open("efo.ttl", "wb") as f:
        ...     f.write(content)
        """
        if not file_name:
            raise ValueError("file_name is required")

        endpoint = f"/api/ontologies/download/{file_name}"

        logger.debug("Downloading file %r", file_name)
        resp = self.request("GET", endpoint)
        resp.raise_for_status()
        return resp.content

    # ── Other Methods ──────────────────────────────────────────

    def get_loaded_bool(self, ontology_id: str) -> bool:
        """
        Check whether an ontology is loaded.

        Args:
            ontology_id: The ontology identifier.

        Returns:
            True if loaded, False if not.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")

        endpoint = f"/api/ontologies/{ontology_id}/loaded"
        resp = self.request("GET", endpoint)

        text = resp.text.strip().lower()
        if text == "true":
            return True
        elif text == "false":
            return False
        else:
            raise ValueError(f"Unexpected response from {endpoint}: {resp.text!r}")

    def get_classes_by_exact_label(self, ontology_id: str, label: str) -> list[dict]:
        """
        Retrieve ontology classes with an exact label match.

        Parameters
        ----------
        ontology_id : str
            Ontology ID to search within (e.g., "efo").
        label : str
            The exact label to match.

        Returns
        -------
        list[dict]
            List of matching entities (often length 0 or 1).

        Raises
        ------
        ValueError
            If `ontology_id` or `label` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not label:
            raise ValueError("label is required")

        endpoint = f"/api/search/{ontology_id}/exactLabel"
        params = {"label": label}

        logger.debug("Searching for exact label %r in ontology %r", label, ontology_id)
        resp = self.request("GET", endpoint, params=params)
        return self.json_or_raise(resp)

    def get_classes_by_primary_id(
            self,
            class_primary_id: str,
            ontology_list: Optional[Union[str, list[str]]] = None,
    ) -> dict:
        """
        Get classes whose *primary ID* exactly matches the supplied string.

        Parameters
        ----------
        class_primary_id : str
            The primary ID to get (required).
        ontology_list : str or list of str, optional
            One or more ontology IDs to filter on.

        Returns
        -------
        dict
            JSON response from the endpoint.

        Raises
        ------
        ValueError
            If `class_primary_id` is empty.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not class_primary_id:
            raise ValueError("class_primary_id is required")

        endpoint = "/api/search/primaryId"
        params: dict[str, Union[str, list[str]]] = {"q": class_primary_id}

        if ontology_list:
            # Accept a single ontology or a list; requests will encode lists as repeated params
            params["ontology"] = ([ontology_list] if isinstance(ontology_list, str) else ontology_list)

        logger.debug("Primary ID search %r (ontologies=%r)", class_primary_id, params.get("ontology"))
        resp = self.request("GET", endpoint, params=params)  # will raise if raise_for_status=True
        return self.json_or_raise(resp)

    def get_class_details(
            self,
            ontology_id: str,
            class_primary_id: Optional[str] = None,
            *,
            class_id: Optional[str] = None,
            id_type: Optional[str] = None,
    ) -> Optional[dict]:
        """
        Retrieve detailed information about a specific class.

        Exactly one of ``class_primary_id`` or ``class_id`` must be provided.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to search within (e.g., ``"MONDO"``, ``"DOID"``).
        class_primary_id : str, optional
            **Deprecated preferred path — accepts full IRIs only.**  Pass the
            full IRI of the class (e.g.
            ``"http://purl.obolibrary.org/obo/MONDO_0005015"``).  Provided for
            backward compatibility; no resolution is performed.  Mutually
            exclusive with ``class_id``.
        class_id : str, optional
            The class identifier.  Accepts all three CENtree identifier types;
            use ``id_type`` to declare which one is being supplied or leave
            ``id_type=None`` for auto-detection.  Mutually exclusive with
            ``class_primary_id``.
        id_type : {'hash', 'iri', 'short_form', None}, optional
            Only used when ``class_id`` is provided.  Explicitly declares the
            identifier type to bypass auto-detection:

            - ``None`` *(default)* — auto-detect: values starting with
              ``http://`` or ``https://`` are treated as full IRIs; everything
              else is treated as a short form ID.
            - ``'iri'`` — treat as a full IRI and skip resolution entirely.
            - ``'short_form'`` — treat as a short form ID (e.g.
              ``"EFO_0000001"`` or ``"EFO:0000001"``) and resolve to a full
              IRI via :meth:`search_exact_multiple`.
            - ``'hash'`` — treat as a CENtree internal hash ID (the ``id``
              field on any class response) and look up via
              :meth:`get_class_by_hash_id`.  Use this when you already have a
              hash, or when the ontology uses hash-like strings as its short
              form IDs.

        Returns
        -------
        dict or None
            A dictionary containing detailed class information if found, with keys including:
                - ``id``: Internal CENtree hash ID (for use in edit operations)
                - ``primaryID``: The full IRI of the class
                - ``primaryLabel``: The main label/name
                - ``synonyms``: List of synonyms
                - ``textualDefinitions``: List of definitions
                - ``superClasses``: Parent classes
                - ``shortFormIDs``: Short-form identifiers (CURIEs)
                - ``entityType``: Type of entity
                - ``propertyValues``: List of annotation property values (includes tags)
                - ``objectPropertyValues``: List of object property values (relationships)
                - ``annotationProperties``: Dict of annotation properties
                - ``relationalProperties``: Dict of relational properties
                - ``partOf``, ``derivesFrom``, ``developsFrom``: Relationship lists
                - ``equivalences``, ``mappings``: Equivalence and mapping information

            When ``id_type='hash'``, the response also includes ``version`` (int).

            Returns ``None`` if the class is not found.

        Raises
        ------
        ValueError
            If ``ontology_id`` is empty, neither or both identifier parameters
            are provided, or if ``id_type`` is not one of the allowed values.
        requests.HTTPError
            If the HTTP request fails.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="https://centree.example.com", bearer_token="...")
        >>> # Legacy: full IRI via class_primary_id (backward compat)
        >>> details = client.get_class_details("MONDO", "http://purl.obolibrary.org/obo/MONDO_0005015")
        >>> # New: any identifier type via class_id
        >>> details = client.get_class_details("MONDO", class_id="MONDO_0005015")
        >>> details = client.get_class_details("MONDO", class_id="MONDO:0005015", id_type="short_form")
        >>> details = client.get_class_details("efo", class_id=hash_id, id_type="hash")
        >>> if details:
        ...     print(details["primaryLabel"])
        ...     print(details["id"])  # hash ID needed for edit operations
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if class_primary_id is None and class_id is None:
            raise ValueError("one of class_primary_id or class_id is required")
        if class_primary_id is not None and class_id is not None:
            raise ValueError("only one of class_primary_id or class_id may be provided")
        if class_primary_id is not None and not class_primary_id.strip():
            raise ValueError("class_primary_id must not be empty or whitespace")
        if class_id is not None and not class_id.strip():
            raise ValueError("class_id must not be empty or whitespace")

        _VALID_ID_TYPES = {"hash", "iri", "short_form", None}
        if id_type not in _VALID_ID_TYPES:
            raise ValueError(f"id_type must be one of {_VALID_ID_TYPES}")

        # ── Legacy path: class_primary_id is always a full IRI ──────────
        if class_primary_id is not None:
            identifier = class_primary_id
            effective_id_type = "iri"
        else:
            identifier = class_id
            effective_id_type = id_type

        # ── Hash ID: delegate directly to get_class_by_hash_id ──────────
        if effective_id_type == "hash":
            return self.get_class_by_hash_id(ontology_id, identifier)

        # ── Determine whether to resolve short form → full IRI ───────────
        needs_resolution = (
            effective_id_type == "short_form"
            or (effective_id_type is None and not identifier.startswith(("http://", "https://")))
        )

        if needs_resolution:
            logger.debug(
                "Short form ID %r supplied; resolving to full IRI in ontology %r",
                identifier, ontology_id,
            )
            resolution = self.search_exact_multiple(ontology_id, [identifier])
            result_list = resolution.get("resultList", [])
            if not result_list:
                logger.debug(
                    "Short form ID %r not found in ontology %r",
                    identifier, ontology_id,
                )
                return None
            identifier = result_list[0].get("primaryID", identifier)
            logger.debug("Resolved to full IRI %r", identifier)

        # ── Full IRI lookup via /primaryIds ──────────────────────────────
        endpoint = f"/api/search/{ontology_id}/primaryIds"

        logger.debug(
            "Fetching class details for %r in ontology %r",
            identifier, ontology_id
        )
        resp = self.request("POST", endpoint, json=[identifier])
        results = self.json_or_raise(resp)

        if not results or identifier not in results:
            logger.debug("Class %r not found in ontology %r", identifier, ontology_id)
            return None

        return results[identifier]

    def get_class_by_hash_id(
            self,
            ontology_id: str,
            hash_id: str,
    ) -> Optional[dict]:
        """
        Retrieve detailed information about a class using its internal hash ID.

        Uses the ``GET /api/ontologies/{ontologyId}/classes/{classId}`` endpoint,
        which accepts the CENtree internal hash ID (the ``id`` field returned by
        :meth:`get_class_details` and :meth:`search_exact_multiple`).

        Unlike :meth:`get_class_details`, this method does not require the full IRI
        or short form ID — it looks up the class directly by its hash. The response
        also includes a ``version`` field useful for edit conflict detection.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to search within (e.g., ``"efo"``).
        hash_id : str
            The internal CENtree hash ID of the class (e.g. ``"a1b2c3d4e5f6..."``).
            Obtain this from the ``id`` field of any class lookup response.

        Returns
        -------
        dict or None
            A dictionary containing detailed class information if found, with keys including:

            - ``id`` (str): The hash ID.
            - ``primaryID`` (str): Full IRI of the class.
            - ``primaryLabel`` (str): Main label.
            - ``version`` (int): Current version number (useful for edit operations).
            - ``synonyms`` (list[str]): Synonym labels.
            - ``textualDefinitions`` (list[str]): Textual definitions.
            - ``shortFormIDs`` (list[str]): Short-form identifiers (CURIEs).
            - ``superClasses`` (list[str]): Parent class IRIs.
            - ``propertyValues`` (list[dict]): Property values with tags.
            - ``objectPropertyValues`` (list[dict]): Object property values.
            - ``annotationProperties`` (dict): Annotation property values.
            - ``relationalProperties`` (dict): Relational property values.
            - ``partOf``, ``derivesFrom``, ``developsFrom``: Relationship lists.
            - ``equivalences``, ``mappings``: Equivalence and mapping information.

            Returns ``None`` if the class is not found (404 response).

        Raises
        ------
        ValueError
            If ``ontology_id`` or ``hash_id`` is empty.
        requests.HTTPError
            If the HTTP request fails (non-404 errors).

        Examples
        --------
        >>> details = client.get_class_details("efo", class_id="EFO_0000001")
        >>> hash_id = details["id"]
        >>> full_details = client.get_class_by_hash_id("efo", hash_id)
        >>> print(full_details["version"])  # current version number
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not hash_id:
            raise ValueError("hash_id is required")

        endpoint = f"/api/ontologies/{ontology_id}/classes/{hash_id}"

        logger.debug("Fetching class by hash ID %r in ontology %r", hash_id, ontology_id)
        resp = self.request("GET", endpoint)

        if resp.status_code == 404:
            return None

        return self.json_or_raise(resp)

    def get_classes_details(
            self,
            ontology_id: str,
            class_primary_ids: list[str],
    ) -> dict[str, dict]:
        """
        Retrieve detailed information about multiple classes by their primary IDs.

        This method uses the ``/api/search/{ontology}/primaryIds`` endpoint which
        returns richer information than ``get_classes_by_primary_id``, including
        property values, object property values, annotation properties, and
        relational properties.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to search within (e.g., "MONDO", "DOID", "EFO").
        class_primary_ids : list[str]
            List of full IRIs/URIs of the classes to retrieve.

        Returns
        -------
        dict[str, dict]
            A dictionary keyed by primary ID, where each value contains detailed
            class information. Classes not found will not be present in the result.
            See :meth:`get_class_details` for the structure of each class dict.

        Raises
        ------
        ValueError
            If ``ontology_id`` is empty or ``class_primary_ids`` is empty.
        requests.HTTPError
            If the HTTP request fails.

        Examples
        --------
        >>> client = CENtreeReaderClient(base_url="https://centree.example.com", bearer_token="...")
        >>> ids = [
        ...     "http://purl.obolibrary.org/obo/MONDO_0005015",
        ...     "http://purl.obolibrary.org/obo/MONDO_0005148"
        ... ]
        >>> results = client.get_classes_details("MONDO", ids)
        >>> for primary_id, details in results.items():
        ...     print(primary_id, details["primaryLabel"])
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not class_primary_ids:
            raise ValueError("class_primary_ids is required and must not be empty")

        endpoint = f"/api/search/{ontology_id}/primaryIds"

        logger.debug(
            "Fetching details for %d class(es) in ontology %r",
            len(class_primary_ids), ontology_id
        )
        resp = self.request("POST", endpoint, json=class_primary_ids)
        return self.json_or_raise(resp)

    def get_class_property_values(
            self,
            ontology_id: str,
            iri: str,
            property_iri: str,
            value: Optional[str] = None,
            *,
            class_id: Optional[str] = None,
            id_type: Optional[str] = None,
    ) -> Optional[list[dict]]:
        """Return property value entries for a class, optionally filtered to a specific value.

        Looks up the class via :meth:`get_class_details`, then filters the
        ``"propertyValues"`` list by ``property_iri`` and optionally by ``value``.
        The returned dicts can be passed directly to
        :meth:`~scibite_toolkit.centree_clients.editor.CENtreeEditorClient.replace_class_property_value`
        or
        :meth:`~scibite_toolkit.centree_clients.editor.CENtreeEditorClient.remove_class_property_value`
        as ``old_value`` / ``old_tags``.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        iri : str
            Class identifier — full IRI, short form ID (e.g. ``"EFO_0000001"``), or
            hash ID. Passed to :meth:`get_class_details` as ``class_id`` unless
            ``class_id`` is also supplied, in which case ``iri`` is ignored and
            ``class_id`` is used instead. Kept for backward-compat convenience so
            callers can pass a positional IRI directly.
        property_iri : str
            The property IRI to filter by
            (e.g. ``"http://www.w3.org/2004/02/skos/core#altLabel"``).
        value : str, optional
            If provided, return only the entry whose ``"value"`` matches exactly.
            If omitted, return all entries for ``property_iri``.
        class_id : str, optional
            Alternative class identifier — takes precedence over the positional ``iri``
            argument when both are supplied. Useful when you already have a hash ID.
        id_type : str, optional
            Passed through to :meth:`get_class_details`. One of ``"hash"``,
            ``"iri"``, ``"short_form"``, or ``None`` for auto-detection.

        Returns
        -------
        list[dict] or None
            - If ``value`` is given: a list containing the single matching entry, or
              an empty list if not found.
            - If ``value`` is omitted: a list of all entries for ``property_iri``
              (may be empty).
            - ``None`` if the class itself is not found.

            Each entry has at minimum ``"iri"`` and ``"value"`` keys, and a ``"tags"``
            key when language tags or other metadata are present.

        Raises
        ------
        ValueError
            If ``ontology_id`` or ``property_iri`` is empty.
        requests.HTTPError
            If the HTTP request fails.

        Examples
        --------
        Fetch all ``altLabel`` values for a class::

            ALT_LABEL = "http://www.w3.org/2004/02/skos/core#altLabel"
            entries = reader.get_class_property_values("onto", "MY_CLASS_0001", ALT_LABEL)
            # [{"iri": "...", "value": "synonym one", "tags": [...]}, ...]

        Fetch the exact entry you want to replace, then pass it to the editor::

            pv = reader.get_class_property_values("onto", "MY_CLASS_0001", ALT_LABEL, value="old synonym")
            if pv:
                editor.replace_class_property_value(
                    "onto", entity_id, ALT_LABEL,
                    old_value=pv[0]["value"], new_value="corrected synonym",
                    old_tags=pv[0].get("tags"),
                )
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not property_iri:
            raise ValueError("property_iri is required")

        lookup_id = class_id if class_id is not None else iri
        details = self.get_class_details(
            ontology_id,
            class_id=lookup_id,
            id_type=id_type,
        )

        if details is None:
            return None

        entries = [p for p in details.get("propertyValues", []) if p.get("iri") == property_iri]

        if value is not None:
            entries = [p for p in entries if p.get("value") == value]

        return entries

    def get_class_property_value(
            self,
            ontology_id: str,
            iri: str,
            property_iri: str,
            value: str,
            *,
            class_id: Optional[str] = None,
            id_type: Optional[str] = None,
    ) -> Optional[dict]:
        """Return a single property value entry for a class, or ``None`` if not found.

        Convenience wrapper around :meth:`get_class_property_values` that returns
        the first matching entry directly instead of a list. Useful when you already
        know the value and just need the full dict (including ``tags``) to pass to
        :meth:`~scibite_toolkit.centree_clients.editor.CENtreeEditorClient.replace_class_property_value`
        or
        :meth:`~scibite_toolkit.centree_clients.editor.CENtreeEditorClient.remove_class_property_value`.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        iri : str
            Class identifier (full IRI, short form ID, or hash ID). See
            :meth:`get_class_property_values` for details.
        property_iri : str
            The property IRI to match
            (e.g. ``"http://www.w3.org/2004/02/skos/core#altLabel"``).
        value : str
            The exact property value to find.
        class_id : str, optional
            Alternative class identifier; takes precedence over ``iri`` when supplied.
        id_type : str, optional
            Passed through to :meth:`get_class_details`.

        Returns
        -------
        dict or None
            The matching property value dict (with ``iri``, ``value``, and optionally
            ``tags``), or ``None`` if the class or value is not found.

        Raises
        ------
        ValueError
            If ``ontology_id``, ``property_iri``, or ``value`` is empty.
        requests.HTTPError
            If the HTTP request fails.

        Examples
        --------
        ::

            ALT_LABEL = "http://www.w3.org/2004/02/skos/core#altLabel"
            pv = reader.get_class_property_value("onto", "MY_CLASS_0001", ALT_LABEL, "old synonym")
            if pv:
                editor.replace_class_property_value(
                    "onto", entity_id, ALT_LABEL,
                    old_value=pv["value"], new_value="corrected synonym",
                    old_tags=pv.get("tags"),
                )
        """
        if not value:
            raise ValueError("value is required")
        entries = self.get_class_property_values(
            ontology_id, iri, property_iri, value,
            class_id=class_id, id_type=id_type
        )
        if entries is None or len(entries) == 0:
            return None
        return entries[0]

    def get_root_entities(
            self,
            ontology_id: str,
            entity_type: str = "classes",
            from_: int = 0,
            size: int = 10,
            transaction_id: Optional[str] = None,
            childcount: bool = False,
            full_response: bool = False,
    ) -> Union[list[dict], dict]:
        """
        Retrieve root entities of a given type in an ontology.

        Parameters
        ----------
        ontology_id : str
            The ontology ID (e.g., "efo").
        entity_type : {"classes","properties","instances"}, default "classes"
            Entity type to fetch roots for.
        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Number of results to return.
        transaction_id : str, optional
            If provided, include uncommitted changes from this transaction.
        childcount : bool, default False
            Whether to include child-count information in results.
        full_response : bool, default False
            If True, return the full JSON response (with pagination metadata);
            otherwise return a list of entity dicts.

        Returns
        -------
        list[dict] | dict
            Root entity dicts (default) or full JSON if `full_response=True`.

        Raises
        ------
        ValueError
            If `ontology_id` is empty or `entity_type` is invalid.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        allowed = {"classes", "properties", "instances"}
        if entity_type not in allowed:
            raise ValueError(f"entity_type must be one of {sorted(allowed)}")

        endpoint = f"/api/tree/{ontology_id}/{entity_type}/roots"
        params = {
            "from": from_,
            "size": size,
            "childcount": str(childcount).lower(),
        }
        if transaction_id:
            params["transactionId"] = transaction_id

        logger.debug("Fetching root %s from ontology %r (from=%d, size=%d, childcount=%s)",
                     entity_type, ontology_id, from_, size, childcount)

        resp = self.request("GET", endpoint, params=params)
        data = self.json_or_raise(resp)

        if full_response:
            return data
        return [el.get("value", el) for el in data.get("elements", [])]

    def get_paths_from_root(
            self,
            ontology_id: str,
            class_primary_id: str,
            children_relation_max_size: int = 50,
            maximum_number_of_paths: int = 100,
            *,
            as_: str = "ids",  # 'ids' | 'labels' | 'objects'
            include_fake_root: bool = False,
    ) -> list[list[Union[str, dict]]]:
        """
        Return paths from the synthetic 'THING' root to a class.

        Parameters
        ----------
        ontology_id : str
            Ontology ID (e.g., "efo").
        class_primary_id : str
            Primary ID of the target class (e.g., "http://www.ebi.ac.uk/efo/EFO_0000001" or "EFO_0000001").
        children_relation_max_size : int, default 50
            Limit breadth when exploring children.
        maximum_number_of_paths : int, default 100
            Maximum number of distinct paths to return.
        as_ : {'ids','labels','objects'}, default 'ids'
            Shape of each path segment:
              - 'ids'    → use `value.primaryID`.
              - 'labels' → use `value.primaryLabel`.
              - 'objects'→ return the raw `value` dicts.
        include_fake_root : bool, default False
            If False, drop the synthetic 'THING' node from returned paths.

        Returns
        -------
        list[list[Union[str, dict]]]
            A list of root→…→target paths. Each path is a list in the order encountered.

        Raises
        ------
        ValueError
            If required parameters are missing.
        requests.HTTPError
            If the HTTP request is unsuccessful.
        """
        if not ontology_id:
            raise ValueError("ontology_id is required")
        if not class_primary_id:
            raise ValueError("class_primary_id is required")
        if as_ not in {"ids", "labels", "objects"}:
            raise ValueError("as_ must be one of {'ids','labels','objects'}")

        endpoint = f"/api/ontologies/{ontology_id}/classes/paths-from-root"
        params = {
            "classPrimaryId": class_primary_id,
            "childrenRelationMaxSize": int(children_relation_max_size),
            "maximumNumberOfPaths": int(maximum_number_of_paths),
        }

        resp = self.request("GET", endpoint, params=params)
        tree = self.json_or_raise(resp)  # shape: {"value": {...}, "leaves": [...]}

        def pick(v: Optional[dict], as_: str) -> Optional[Union[str, dict]]:
            if not isinstance(v, dict):  # value may be None
                return None
            if as_ == "objects":
                return v
            if as_ == "labels":
                return v.get("primaryLabel")
            # default 'ids'
            return v.get("primaryID")

        paths: list[list[Union[str, dict]]] = []

        def dfs(node: dict, acc: list[Union[str, dict]]) -> None:
            # Some server versions can return nodes with value=None
            value = node.get("value")
            leaves = node.get("leaves") or []

            added = False
            picked = pick(value, as_)
            if picked is not None:
                acc.append(picked)
                added = True

            if not leaves:
                # Only record a path if we actually added a node
                if added:
                    paths.append(acc.copy())
            else:
                for child in leaves:
                    if isinstance(child, dict):
                        dfs(child, acc)

            if added:
                acc.pop()

        dfs(tree, [])

        if not include_fake_root and paths:
            # drop the first hop (synthetic 'THING') if it’s present
            def drop_fake(p: list[Union[str, dict]]) -> list[Union[str, dict]]:
                return p[1:] if len(p) and (
                            p[0] == "THING" or (isinstance(p[0], dict) and p[0].get("primaryID") == "THING")) else p

            paths = [drop_fake(p) for p in paths]

        return paths

    # ── Advanced Search Methods ──────────────────────────────────────────

    def advanced_search_status(self) -> bool:
        """
        Check whether the CENtree advanced search index is ready.

        Should be called before issuing advanced search queries. Returns ``True``
        when the index is ready and ``False`` when indexing is still in progress.

        Returns
        -------
        bool
            ``True`` if the advanced search index is ready, ``False`` otherwise.

        Raises
        ------
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Requires
        --------
        CENtree >= 3.3.0

        Examples
        --------
        >>> if not client.advanced_search_status():
        ...     raise RuntimeError("Advanced search index is not ready")
        """
        resp = self.request("GET", "/api/search/advanced/status")
        resp.raise_for_status()
        return resp.text.strip().lower() == "true"

    def advanced_search(
            self,
            query: dict,
            from_: int = 0,
            size: int = 10,
            inner_hits: bool = False,
            check_status: bool = False,
    ) -> dict:
        """
        Execute an advanced structured search across ontology entities.

        Accepts an ``AdvSearchQuery`` dict and returns a paginated result set.
        All four top-level fields of the query are required.

        Parameters
        ----------
        query : dict
            An ``AdvSearchQuery`` dict with the following required fields:

            - ``ontologyIds`` (list[str]): One or more ontology IDs to search.
            - ``entityType`` (str): One of ``"classes"``, ``"instances"``, ``"properties"``.
            - ``op`` (str): How conditions are combined — ``"AND"`` or ``"OR"``.
            - ``conditions`` (list[dict]): One or more condition objects.

            Each condition must have a ``conditionType`` field. Supported types:

            **AdvSearchAnnotationPropertyCondition** — filter by annotation property::

                {
                    "conditionType": "AdvSearchAnnotationPropertyCondition",
                    "predicate": "HAS",  # or "HAS_NOT"
                    "propertyIRI": "http://www.w3.org/2004/02/skos/core#altLabel",
                    "values": {
                        "matchType": "CONTAINS",  # EXACT | CONTAINS | STARTS_WITH | ENDS_WITH | EMPTY | NOT_EMPTY
                        "op": "OR",
                        "values": ["kinase", "inhibitor"]
                    }
                }

            **AdvSearchRelationalPropertyCondition** — filter by object/relational property::

                {
                    "conditionType": "AdvSearchRelationalPropertyCondition",
                    "predicate": "HAS",
                    "propertyIRI": "http://www.w3.org/2000/01/rdf-schema#subClassOf",
                    "values": {"matchType": "EXACT", "op": "OR", "values": ["CHEBI:23367"]}
                }

            **AdvSearchIDCondition** — filter by entity ID (*not yet implemented on server*)::

                {
                    "conditionType": "AdvSearchIDCondition",
                    "search": "CHEBI:123",
                    "matchType": "STARTS_WITH"
                }

            **AdvSearchTagCondition** — filter by tag (e.g. language tag)::

                {
                    "conditionType": "AdvSearchTagCondition",
                    "predicate": "HAS",
                    "tagIRI": "http://www.w3.org/XML/1998/namespace/en"
                }

            **AdvSearchDateCondition** — filter by creation/modification date (*not yet implemented on server*)::

                {
                    "conditionType": "AdvSearchDateCondition",
                    "starts": "2024-01-01T00:00:00Z",
                    "ends": "2024-12-31T23:59:59Z"
                }

        from_ : int, default 0
            Pagination offset.
        size : int, default 10
            Page size.
        inner_hits : bool, default False
            Include inner hit detail in results.
        check_status : bool, default False
            If ``True``, call :meth:`advanced_search_status` before executing the
            search and raise ``RuntimeError`` if the index is not ready.

        Returns
        -------
        dict
            Paginated result set (``PageJSONBean``) with keys ``from``, ``total``,
            ``elements``.

        Raises
        ------
        ValueError
            If ``query`` is missing required fields.
        RuntimeError
            If ``check_status=True`` and the advanced search index is not ready.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Requires
        --------
        CENtree >= 3.3.0

        Examples
        --------
        >>> query = {
        ...     "ontologyIds": ["efo"],
        ...     "entityType": "classes",
        ...     "op": "AND",
        ...     "conditions": [
        ...         {
        ...             "conditionType": "AdvSearchAnnotationPropertyCondition",
        ...             "predicate": "HAS",
        ...             "propertyIRI": "http://www.w3.org/2004/02/skos/core#altLabel",
        ...             "values": {"matchType": "CONTAINS", "op": "OR", "values": ["cancer"]}
        ...         }
        ...     ]
        ... }
        >>> results = client.advanced_search(query, size=20)
        >>> print(results["total"])
        """
        required = {"ontologyIds", "entityType", "op", "conditions"}
        missing = required - set(query.keys())
        if missing:
            raise ValueError(f"query is missing required fields: {missing}")

        if check_status and not self.advanced_search_status():
            raise RuntimeError("Advanced search index is not ready. Try again later or check the server logs.")

        params = {
            "from": from_,
            "size": size,
            "innerHits": str(inner_hits).lower(),
        }

        logger.debug(
            "Advanced search ontologies=%r entityType=%r op=%r conditions=%d from=%d size=%d",
            query.get("ontologyIds"), query.get("entityType"), query.get("op"),
            len(query.get("conditions", [])), from_, size,
        )
        resp = self.request("POST", "/api/search/advanced", params=params, json=query)
        return self.json_or_raise(resp)

    def advanced_search_export(
            self,
            query: dict,
            delimiter: str = ",",
            check_status: bool = False,
    ) -> str:
        """
        Export the full advanced search result set as a CSV file (asynchronous).

        Submits the search query and returns a job ID. Poll the job endpoint
        (e.g. via the editor client's job polling) to check completion and
        retrieve the download URL.

        Parameters
        ----------
        query : dict
            An ``AdvSearchQuery`` dict. See :meth:`advanced_search` for the
            full structure and supported condition types.
        delimiter : str, default ","
            CSV column delimiter. Use ``"\\t"`` for tab-separated output.
        check_status : bool, default False
            If ``True``, call :meth:`advanced_search_status` before submitting the
            export and raise ``RuntimeError`` if the index is not ready.

        Returns
        -------
        str
            Job ID string for polling via the jobs endpoint.

        Raises
        ------
        ValueError
            If ``query`` is missing required fields.
        RuntimeError
            If ``check_status=True`` and the advanced search index is not ready.
        requests.HTTPError
            If the HTTP request is unsuccessful.

        Requires
        --------
        CENtree >= 3.3.0

        Examples
        --------
        >>> job_id = client.advanced_search_export(query, delimiter=",")
        >>> # Poll until complete, then download
        >>> job_status = editor_client.get_job_status(job_id)
        """
        required = {"ontologyIds", "entityType", "op", "conditions"}
        missing = required - set(query.keys())
        if missing:
            raise ValueError(f"query is missing required fields: {missing}")

        if check_status and not self.advanced_search_status():
            raise RuntimeError("Advanced search index is not ready. Try again later or check the server logs.")

        params = {"delimiter": delimiter}

        logger.debug(
            "Advanced search export ontologies=%r entityType=%r delimiter=%r",
            query.get("ontologyIds"), query.get("entityType"), delimiter,
        )
        resp = self.request("POST", "/api/search/advanced/export", params=params, json=query)
        data = self.json_or_raise(resp)
        if not isinstance(data, dict):
            raise ValueError(
                "advanced_search_export response did not contain a valid job.id: "
                f"expected dict, got {type(data).__name__}"
            )

        job = data.get("job")
        if not isinstance(job, dict) or "id" not in job or job["id"] is None:
            raise ValueError(
                "advanced_search_export response did not contain a valid job.id: "
                f"{data!r}"
            )

        return str(job["id"])
