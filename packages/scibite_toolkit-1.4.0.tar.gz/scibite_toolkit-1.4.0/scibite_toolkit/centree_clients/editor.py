"""
editor.py

CENtreeEditorClient: A client for performing ontology editing operations via the CENtree API.

This includes capabilities for creating new ontology classes, instances, and properties,
as well as managing transaction IDs for change tracking.

Classes:
- CENtreeEditorClient: Supports editing operations on ontologies (create, update, transaction management).
"""

import logging
from logging import NullHandler
from typing import Optional, Any, Union
import time
import requests
from .base import CENtreeClient
from .reader import CENtreeReaderClient
from .exceptions import OntologyAlreadyExistsError, OntologyNotFoundError
from .helpers import ontology_exists

# ── Logging config ──────────────────────────────────────────
logger = logging.getLogger("scibite_toolkit.centree_clients.editor")
logger.addHandler(NullHandler())
# ────────────────────────────────────────────────────────────


class CENtreeEditorClient(CENtreeClient):
    """Client for editing ontologies in CENtree.

    Extends the base `CENtreeClient` with capabilities for managing ontology
    transactions, including caching transaction IDs locally for each ontology.

    Note:
        - Transaction ID caching is in-memory only and not persisted.
    """
    def __init__(self, base_url: Optional[str] = None, bearer_token: Optional[str] = None, verify: bool = True, allow_insecure: bool = False):
        super().__init__(base_url=base_url, bearer_token=bearer_token, verify=verify, allow_insecure=allow_insecure)
        self._cached_transaction_ids: dict[str, str] = {}
        logger.debug("Initialized CENtreeEditorClient base_url=%s verify=%s", self.base_url, verify)

    # ---------------------------------- #
    # -------- CACHE MANAGEMENT -------- #
    # ---------------------------------- #

    def get_cached_transaction_id(self, ontology_id: str) -> Optional[str]:
        """Retrieves the cached transaction ID for a given ontology.

        Args:
            ontology_id (str): The ontology identifier.

        Returns:
            Optional[str]: The cached transaction ID, or None if no transaction is cached.

        Raises:
            ValueError: If `ontology_id` is an empty string.

        Logs:
            DEBUG: Whether the transaction cache was a HIT or MISS.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string")
        tx = self._cached_transaction_ids.get(ontology_id)
        logger.debug("Transaction cache %s for ontology=%s", "HIT" if tx else "MISS", ontology_id)
        return tx

    def set_cached_transaction_id(self, ontology_id: str, transaction_id: str):
        """Sets or overwrites the cached transaction ID for a given ontology.

        Args:
            ontology_id (str): The ontology identifier.
            transaction_id (str): The transaction ID to cache.

        Returns:
            Optional[str]: The previous transaction ID, if one existed; otherwise None.

        Raises:
            ValueError: If `ontology_id` or `transaction_id` is an empty string.

        Logs:
            DEBUG: Whether a previous transaction ID existed.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string")
        if not transaction_id:
            raise ValueError("transaction_id must be a non-empty string")
        prev = self._cached_transaction_ids.get(ontology_id)
        self._cached_transaction_ids[ontology_id] = transaction_id
        logger.debug("Cached transaction_id for ontology=%s (had_prev=%s)", ontology_id, prev is not None)
        return prev

    def clear_cached_transaction_id(self, ontology_id: str):
        """Removes the cached transaction ID for a given ontology.

        Args:
            ontology_id (str): The ontology identifier.

        Returns:
            bool: True if a transaction ID was removed; False if none existed.

        Raises:
            ValueError: If `ontology_id` is an empty string.

        Logs:
            DEBUG: Whether a cached ID existed and was cleared.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string")
        removed = self._cached_transaction_ids.pop(ontology_id, None) is not None
        logger.debug("Cleared transaction_id for ontology=%s (existed=%s)", ontology_id, removed)
        return removed

    def clear_all_cached_transaction_ids(self) -> int:
        """Clears all cached transaction IDs across all ontologies.

        Returns:
            int: The number of transaction IDs that were removed.

        Logs:
            DEBUG: Total number of cleared entries.
        """
        n = len(self._cached_transaction_ids)
        self._cached_transaction_ids.clear()
        logger.debug("Cleared all transaction_ids (count=%d)", n)
        return n

    # -------------------------------- #
    # -------- INPUT / OUTPUT -------- #
    # -------------------------------- #

    def upload_file(self, file_path: str) -> dict:
        """
        Upload a source file to CENtree for ontology creation.

        Args:
            file_path (str): Path to the local ontology file to be uploaded.

        Returns:
            dict: The parsed JSON response from the server.

        Raises:
            ValueError: If base_url is not set.
            HTTPError: If the upload fails.
        """
        if not self.base_url:
            raise ValueError("Base URL is not set.")

        with open(file_path, 'rb') as file:
            files = {'file': file}
            response = self.request(
                "POST",
                "/api/ontology/uploadFile",
                files=files
            )

        if response.status_code != 201:
            response.raise_for_status()

        return response.json()

    def get_builder_rules(
            self,
            ontology_id: str,
            *,
            populate_labels: bool = True,
    ) -> list[dict]:
        """
        Retrieve the current builder rules for an application ontology.

        Parameters
        ----------
        ontology_id : str
            The ontology ID (e.g. ``"CATTLE_DISEASE_DEMO"``).
        populate_labels : bool, optional
            When ``True`` (default), each rule entry includes the human-readable
            class label alongside the ``primaryId``. When ``False``, only IRIs
            are returned.

        Returns
        -------
        list[dict]
            A list of ``SourceOntologyVM`` rule objects as returned by the API.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-200 response.
        """
        endpoint = f"/api/ontologies/{ontology_id}/ontologyMetadataRules"
        params = {"populateLabels": str(populate_labels).lower()}
        logger.info("Fetching builder rules for ontology '%s'", ontology_id)
        response = self.request("GET", endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def export_builder_rules(
            self,
            ontology_id: str,
    ) -> str:
        """
        Export the builder rules for an application ontology as a JSON string.

        The returned string can be saved to disk and later re-uploaded via
        :meth:`upload_builder_rules`, making it straightforward to snapshot,
        transfer, or programmatically modify builder rules.

        Parameters
        ----------
        ontology_id : str
            The ontology ID (e.g. ``"CATTLE_DISEASE_DEMO"``).

        Returns
        -------
        str
            The raw builder-rules JSON payload as a string.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-200 response.
        """
        endpoint = f"/api/ontologies/{ontology_id}/exportOntologyRules"
        logger.info("Exporting builder rules for ontology '%s'", ontology_id)
        response = self.request("GET", endpoint)
        response.raise_for_status()
        return response.text

    def upload_builder_rules(
            self,
            ontology_id: str,
            rules: str,
    ) -> str:
        """
        Upload builder rules into an empty, unloaded application ontology.

        The ``rules`` argument should be a JSON string as produced by
        :meth:`export_builder_rules` (or the CENtree export endpoint). The
        ontology must be empty and unloaded before calling this method — the
        typical workflow is to create a fresh ontology, then upload rules to
        configure it before rebuilding.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to upload rules into.
        rules : str
            Builder-rules JSON string to upload. Use :meth:`export_builder_rules`
            to obtain this from an existing ontology.

        Returns
        -------
        str
            The raw response text from the server (usually a confirmation message).

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        endpoint = f"/api/ontology/{ontology_id}/uploadOntologyRulesFile"
        logger.info("Uploading builder rules for ontology '%s'", ontology_id)
        files = {"file": ("rules.json", rules.encode(), "application/json")}
        response = self.request("POST", endpoint, files=files)
        response.raise_for_status()
        return response.text

    def update_builder_rules(
            self,
            ontology_id: str,
            source_ontology_set: list[dict],
            *,
            save_only: bool = True,
            with_job_details: bool = False,
    ) -> Any:
        """
        Update the builder rules on an existing (loaded) ontology.

        This wraps ``PUT /api/ontology/{ontologyId}``, which is
        the same endpoint the CENtree UI calls when rules are modified via the
        metadata editor. The current ontology metadata is fetched automatically
        from ``GET /api/ontologies/{ontologyId}/ontologyMetadataSummary`` so the
        full ``OntologyMetadataVM`` payload can be constructed without requiring
        the caller to supply it.

        When ``save_only=True`` (default) the rules are persisted but the
        ontology is **not** rebuilt. To trigger a rebuild, call
        :meth:`replay_ontology` afterwards.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to update (e.g. ``"CATTLE_DISEASE_DEMO"``).
        source_ontology_set : list[dict]
            The complete, updated list of source ontology rule objects. Obtain
            the current list with :meth:`get_builder_rules`, modify it, then
            pass the modified list here.
        save_only : bool, optional
            When ``True`` (default), persists the rule change without triggering
            a rebuild. Set to ``False`` to trigger a full reload/reindex job.
        with_job_details : bool, optional
            When ``True``, the server returns a ``JobSubmitResponse`` dict instead
            of a plain string. Only relevant when ``save_only=False``.

        Returns
        -------
        str or dict
            Server response — a confirmation string when ``save_only=True``, or
            a job response dict when ``save_only=False`` and ``with_job_details=True``.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        # Fetch current metadata to build a valid OntologyMetadataVM payload
        summary_resp = self.request(
            "GET", f"/api/ontologies/{ontology_id}/ontologyMetadataSummary"
        )
        summary_resp.raise_for_status()
        summary = summary_resp.json()
        bean = summary.get("ontologyMetadataJSONBean", {})

        payload: dict[str, Any] = {
            # Required fields (OntologyMetadataVM)
            "ontologyId":        summary.get("ontologyId", ontology_id),
            "shortDisplayName":  bean.get("ontologyShortDisplayName", ontology_id),
            "longDisplayName":   bean.get("ontologyLongDisplayName", ontology_id),
            "baseUri":           summary.get("baseUri", ""),
            # Optional fields populated from summary / bean
            "version":           summary.get("version"),
            "idPrefix":          summary.get("idPrefix"),
            "idStartNumber":     summary.get("idStartNumber"),
            "idNumberDigits":    summary.get("idNumberDigits"),
            "idType":            summary.get("idType"),
            "description":       bean.get("description"),
            "ontologyUri":       bean.get("uri"),
            "ontologyType":      bean.get("ontologyType"),
            "inferred":          bean.get("inferred"),
            "allowReverseMappings":             bean.get("allowReverseMappings"),
            "allowReverseMappingFromOntologies": bean.get("allowReverseMappingFromOntologies"),
            "validateOntology":  bean.get("validateOntology"),
            "importCustomDatatypes": bean.get("importCustomDatatypes"),
            "ontologyInstances": bean.get("ontologyInstances"),
            "showDataProperties": bean.get("showDataProperties"),
            "allowDeletes":      bean.get("allowDeletes"),
            "useLang":           bean.get("useLang"),
            "defaultLangTag":    bean.get("defaultLangTag"),
            "ontologyFileWebLocation": bean.get("ontologyFileWebLocation"),
            "allLabelProperties":       bean.get("allLabelProperties", []),
            "synonymProperties":        bean.get("synonymProperties", []),
            "mappingProperties":        bean.get("mappingProperties", []),
            "partonomyProperties":      bean.get("partonomyProperties", []),
            "derivesFromProperties":    bean.get("derivesFromProperties", []),
            "developsFromProperties":   bean.get("developsFromProperties", []),
            "hierarchicalProperties":   bean.get("hierarchicalProperties", []),
            "textualDefinitionProperties": bean.get("textualDefinitionProperties", []),
            "obsoleteSubClassProperties": bean.get("obsoleteSubClassProperties", []),
            "obsoleteAnnotationPropertyKeyValue": bean.get("obsoleteAnnotationPropertyKeyValue", []),
            "annotationProperties":     bean.get("annotationProperties", []),
            "relationalProperties":     bean.get("relationalProperties", []),
            "keywords":                 bean.get("keywords", []),
            "qtt_Prefixes":             bean.get("qtt_Prefixes", []),
            "ontologyMetadataProperties": bean.get("ontologyMetadataProperties", []),
            "idStrategies":             bean.get("idStrategies", []),
            "sourceOntologySet": source_ontology_set,
        }
        # Drop None values — the API may reject unexpected nulls for typed fields
        payload = {k: v for k, v in payload.items() if v is not None}
        payload["sourceOntologySet"] = source_ontology_set  # always include

        params: dict[str, Any] = {
            "isSaveOnly": str(save_only).lower(),
            "withJobDetails": str(with_job_details).lower(),
        }

        logger.info(
            "Updating builder rules for ontology '%s' (save_only=%s, %d source(s))",
            ontology_id, save_only, len(source_ontology_set),
        )
        response = self.request("PUT", f"/api/ontology/{ontology_id}", json=payload, params=params)
        response.raise_for_status()

        try:
            return response.json()
        except Exception:
            return response.text

    # --------------------------------- #
    # -------- FAKE ROOTS ------------- #
    # --------------------------------- #

    def get_fake_roots(self, ontology_id: str) -> list[dict]:
        """
        Return all fake roots defined for an ontology.

        Wraps ``GET /api/ontology/{ontologyId}/fakeRoots``.

        Parameters
        ----------
        ontology_id : str
            The ontology ID (e.g. ``"CATTLE_DISEASE_DEMO"``).

        Returns
        -------
        list[dict]
            List of ``OntologyFakeRoot`` objects, each with ``id``,
            ``ontologyId``, ``primaryLabel``, and ``primaryId``.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        logger.info("Getting fake roots for ontology '%s'", ontology_id)
        response = self.request("GET", f"/api/ontology/{ontology_id}/fakeRoots")
        response.raise_for_status()
        return response.json()

    def get_fake_root(self, ontology_id: str, fake_root_id: int) -> dict:
        """
        Return a single fake root by its numeric ID.

        Wraps ``GET /api/ontology/{ontologyId}/fakeRoot/{fakeRootId}``.

        Parameters
        ----------
        ontology_id : str
            The ontology ID (e.g. ``"CATTLE_DISEASE_DEMO"``).
        fake_root_id : int
            The numeric fake root ID returned by :meth:`get_fake_roots` or
            :meth:`create_fake_root`.

        Returns
        -------
        dict
            ``OntologyFakeRoot`` object with ``id``, ``ontologyId``,
            ``primaryLabel``, and ``primaryId``.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        logger.info(
            "Getting fake root %d for ontology '%s'", fake_root_id, ontology_id
        )
        response = self.request(
            "GET", f"/api/ontology/{ontology_id}/fakeRoot/{fake_root_id}"
        )
        response.raise_for_status()
        return response.json()

    def create_fake_root(
        self,
        ontology_id: str,
        primary_label: str,
        *,
        primary_id: Optional[str] = None,
        base_uri: Optional[str] = None,
        id_prefix: Optional[str] = None,
        id_start_number: Optional[int] = None,
        id_number_digits: Optional[int] = None,
        id_type: Optional[str] = None,
    ) -> dict:
        """
        Create a new fake root for an ontology.

        Fake roots are virtual parent classes used in builder rules to anchor
        imported source ontology terms under a specific class in the target
        ontology. Create a fake root first, then reference its ``id`` in the
        ``ontologyFakeRootId`` field of a builder rule's
        ``includeRootClassSet`` entry.

        Wraps ``PUT /api/ontology/fakeRoot``.

        Parameters
        ----------
        ontology_id : str
            The ontology ID the fake root belongs to (e.g.
            ``"CATTLE_DISEASE_DEMO"``).
        primary_label : str
            Human-readable label for the fake root class (e.g. ``"Viral"``).
        primary_id : str, optional
            The full IRI of an existing class to use as the fake root anchor.
            If provided, the fake root will represent that class. Typically
            this is the IRI of a class already committed to the ontology.
        base_uri : str, optional
            Base URI used for auto-generated class IRIs (only needed when
            ``primary_id`` is not supplied and IDs are auto-generated).
        id_prefix : str, optional
            Prefix for auto-generated short-form IDs.
        id_start_number : int, optional
            Starting number for auto-generated IDs.
        id_number_digits : int, optional
            Number of digits (zero-padded) for auto-generated IDs.
        id_type : str, optional
            ID generation strategy (e.g. ``"NUMERIC"``).

        Returns
        -------
        dict
            The created ``OntologyFakeRoot`` object, including its server-
            assigned ``id`` (use this in builder rule ``ontologyFakeRootId``
            fields).

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        body: dict[str, Any] = {
            "ontologyId": ontology_id,
            "primaryLabel": primary_label,
        }
        if primary_id is not None:
            body["primaryId"] = primary_id
        if base_uri is not None:
            body["baseUri"] = base_uri
        if id_prefix is not None:
            body["idPrefix"] = id_prefix
        if id_start_number is not None:
            body["idStartNumber"] = id_start_number
        if id_number_digits is not None:
            body["idNumberDigits"] = id_number_digits
        if id_type is not None:
            body["idType"] = id_type

        logger.info(
            "Creating fake root '%s' for ontology '%s'", primary_label, ontology_id
        )
        response = self.request("PUT", "/api/ontology/fakeRoot", json=body)
        response.raise_for_status()
        return response.json()

    # ------------------------------------ #
    # -------- ONTOLOGY LIFECYCLE -------- #
    # ------------------------------------ #

    def create_ontology_new(
            self,
            payload: dict,
            wait_until_loaded: bool = False,
            timeout: int = 60
    ) -> Union[dict, str]:
        """
        Create a new ontology in CENtree using the provided payload.

        Args:
            payload (dict): Dictionary representing ontology metadata and configuration.
            wait_until_loaded (bool): Whether to poll until the ontology is fully loaded.
            timeout (int): Max time in seconds to wait for loading confirmation.

        Returns:
            Union[dict, str]: JSON response from the server if successful, or response
                              text if not in JSON. This is only returned if the
                              ontology is created and, if waiting, loads successfully.

        Raises:
            OntologyAlreadyExistsError: If the ontology already exists and is loaded.
            requests.HTTPError: If the initial creation request fails (e.g., non-201 status).
            TimeoutError: If `wait_until_loaded` is True and the ontology
                is not searchable within the `timeout` period.
        """
        if not self.base_url:
            raise ValueError("Base URL is not set.")

        ontology_id = payload.get("ontologyId")
        if not ontology_id:
            raise ValueError("Payload must include 'ontologyId'.")

        existence_url = f"/api/ontologies/{ontology_id}/loaded"
        existence_resp = self.request("GET", existence_url)

        if existence_resp.status_code == 200 and existence_resp.text.strip().lower() == "true":
            logger.info("Ontology '%s' already exists and is loaded. Skipping creation.", ontology_id)
            raise OntologyAlreadyExistsError(f"Ontology '{ontology_id}' already exists and is loaded.")

        logger.info("Creating ontology '%s'…", ontology_id)
        create_resp = self.request("POST", "/api/ontology", json=payload)

        if create_resp.status_code != 201:
            logger.error("Ontology creation failed: %s %s", create_resp.status_code, create_resp.text)
            create_resp.raise_for_status()

        logger.info("Ontology creation request accepted.")

        if wait_until_loaded:
            logger.info("Waiting for ontology '%s' to be fully available (indexed)...", ontology_id)
            start = time.time()
            while time.time() - start < timeout:
                try:
                    check_resp = self.request(
                        "GET",
                        f"/api/search/{ontology_id}/exactLabel",
                        params={"label": "Thing"},
                        suppress_warning=True
                    )
                    if check_resp.status_code == 200:
                        logger.info("Ontology '%s' is now fully available and searchable.", ontology_id)
                        break
                except requests.HTTPError as e:
                    if e.response.status_code == 400:
                        pass  # Search index not ready yet — expected
                    else:
                        logger.warning("Unexpected error during polling: %s", e)
                time.sleep(2)
            else:
                logger.warning("Timeout waiting for ontology '%s' to be indexed in search.", ontology_id)
                raise TimeoutError(
                    f"Timeout waiting for ontology '{ontology_id}' to be indexed after {timeout}s."
                )

        content_type = create_resp.headers.get("Content-Type", "")
        if "application/json" in content_type:
            logger.info("Ontology creation successful with JSON response.")
            return create_resp.json()
        else:
            logger.info("Ontology creation returned non-JSON response.")
            return create_resp.text

    def merge_ontology(
            self,
            ontology_id: str,
            file_url: str,
            *,
            new_version: str = "latestLoadedVersion",
            file_merging_strategy: str = "AS_FILE",
            wait_until_loaded: bool = False,
            timeout: int = 300,
            poll_interval: int = 5
    ) -> Union[dict, str]:
        """
        Merge a new file into an existing ontology and optionally wait for completion.

        Args:
            ontology_id (str): The ontology ID to merge into.
            file_url (str): The URL of the uploaded file to merge.
            new_version (str): The new version identifier.
            file_merging_strategy (str): One of AS_FILE, AS_EDITS_MERGE, AS_EDITS_REPLACE,
                                         AS_EDITS_MERGE_SUGGEST, AS_EDITS_REPLACE_SUGGEST.
            wait_until_loaded (bool): If True, poll until the merge job completes.
            timeout (int): Max total wait time in seconds.
            poll_interval (int): How often to poll job status in seconds.

        Returns:
            dict: If not waiting, the initial job creation response.
                  If waiting, the final job status JSON from the completed job.

        Raises:
            requests.HTTPError: If the initial merge request fails (e.g., non-202 status).
            TimeoutError: If `wait_until_loaded` is True and the merge job
                does not complete within the `timeout` period.
        """
        params = {
            "fileUrl": file_url,
            "newVersion": new_version,
            "fileMergingStrategy": file_merging_strategy,
            "withJobDetails": "true"
        }

        logger.info("Merging file into ontology '%s' with strategy '%s'…", ontology_id, file_merging_strategy)
        response = self.request("POST", f"/api/ontology/{ontology_id}/merge", params=params)

        if response.status_code != 202:
            logger.error("Ontology merge failed: %s %s", response.status_code, response.text)
            response.raise_for_status()

        json_response = response.json()
        job_id = json_response.get("job", {}).get("id")
        logger.info("Ontology merge job accepted: %s", job_id)

        if wait_until_loaded and job_id:
            logger.info("Polling job status for job ID '%s'…", job_id)
            start = time.time()
            while time.time() - start < timeout:
                try:
                    job_status_resp = self.request("GET", f"/api/jobs/{job_id}")
                    if job_status_resp.status_code == 200:
                        job_data = job_status_resp.json()
                        status = job_data.get("status")
                        logger.info("Job status: %s — %s", status, job_data.get("progress", "").strip())

                        if status in ("Succeeded", "Failed", "Cancelled", "Interrupted"):
                            logger.info("Job %s completed with status: %s", job_id, status)
                            return job_data
                    else:
                        logger.warning("Unexpected job status response: %s", job_status_resp.status_code)

                except requests.RequestException as e:
                    logger.warning("Exception while polling job: %s", str(e))

                time.sleep(poll_interval)

            logger.warning("Timeout exceeded while waiting for merge job '%s' to finish", job_id)
            raise TimeoutError(
                f"Timeout waiting for merge job {job_id} to complete after {timeout}s."
            )

        # If not waiting, just return the initial response
        return json_response

    def build_application_ontology(
            self,
            payload: dict,
            wait_until_loaded: bool = False,
            timeout: int = 60
    ) -> dict:
        """
        Build an application ontology in CENtree.

        Args:
            payload (dict): Ontology creation payload. Must include 'ontologyId' and 'sourceOntologySet'.
            wait_until_loaded (bool): If True, poll until the ontology is indexed in search.
            timeout (int): Maximum time in seconds to wait for indexing confirmation.

        Returns:
            dict: JSON response from the server.

        Raises:
            HTTPError: If the request fails.
        """
        if not self.base_url:
            raise ValueError("Base URL is not set.")

        ontology_id = payload.get("ontologyId")
        if not ontology_id:
            raise ValueError("Payload must include 'ontologyId'.")

        logger.info("Initiating build of application ontology '%s' …", ontology_id)
        response = self.request("POST", "/api/ontology/build", json=payload)

        logger.debug("Build request status: %s, body: %s", response.status_code, response.text)

        try:
            build_response = response.json()
        except (ValueError, requests.exceptions.JSONDecodeError):
            build_response = {"message": response.text.strip()}

        if wait_until_loaded:
            logger.info("Waiting for ontology '%s' to be fully available (indexed)...", ontology_id)
            start = time.time()
            while time.time() - start < timeout:
                try:
                    check_resp = self.request(
                        "GET",
                        f"/api/search/{ontology_id}/exactLabel",
                        params={"label": "Thing"},
                        suppress_warning=True
                    )
                    if check_resp.status_code == 200:
                        logger.info("Ontology '%s' is now fully available and searchable.", ontology_id)
                        break
                except requests.HTTPError as e:
                    if e.response.status_code == 400:
                        continue  # Index not ready yet — expected
                    else:
                        logger.warning("Unexpected error during polling: %s", e)
                time.sleep(2)
            else:
                logger.warning("Timeout waiting for ontology '%s' to be indexed in search.", ontology_id)

        return build_response

    def cleanup_default_root_class(
            self,
            ontology_id: str,
            reader: Optional[CENtreeReaderClient] = None
    ) -> bool:
        """
        Removes the default root class ('Thing') from the given ontology if it exists.

        Args:
            ontology_id (str): Ontology from which to remove the root class.
            reader (Optional[CENtreeReaderClient]): Reader client to look up entity ID.

        Returns:
            bool: True if the class was found and deleted, False otherwise.

        Raises:
            OntologyNotFoundError: If the ontology is not found.
            Other exceptions from delete_entity() or commit_transaction().
        """
        if reader is None:
            reader = CENtreeReaderClient(
                base_url=self.base_url,
                bearer_token=self.bearer_token,
                verify=self.verify
            )

        try:
            results = reader.get_classes_by_exact_label(ontology_id, "Thing")
        except OntologyNotFoundError as e:
            logger.error("Ontology '%s' not found: %s", ontology_id, e)
            raise
        except Exception as e:
            logger.error("Unexpected error while retrieving class 'Thing': %s", e)
            raise

        if not results:
            logger.info("No default root class 'Thing' found in ontology '%s'.", ontology_id)
            return False

        entity_id = results[0].get("id")
        if not entity_id:
            logger.warning("Entity for 'Thing' has no ID — skipping delete.")
            return False

        logger.info("Deleting default root class 'Thing' with ID %s", entity_id)

        try:
            self.delete_entity(ontology_id=ontology_id, entity_type="classes", entity_id=entity_id)
        except Exception as e:
            logger.error("Failed to delete 'Thing': %s", e)
            raise

        logger.info("Transaction updated: Deleted 'Thing' class from ontology '%s'", ontology_id)

        try:
            self.commit_transaction(ontology_id)
        except Exception as e:
            logger.error("Failed to commit transaction: %s", e)
            raise

        logger.info("Committed deletion of 'Thing'.")

        return True

    def delete_ontology(
            self,
            ontology_id: str,
            *,
            delete_metadata_entry: bool = True,
            delete_stored_files: bool = True,
            wait_until_deleted: bool = False,
            timeout: int = 60
    ) -> dict:
        """
        Delete an ontology from CENtree.

        Args:
            ontology_id (str): The ID of the ontology to delete.
            delete_metadata_entry (bool): Whether to delete the metadata entry.
            delete_stored_files (bool): Whether to delete uploaded source files.
            wait_until_deleted (bool): If True, poll until the ontology is fully removed.
            timeout (int): Maximum time in seconds to wait for confirmation.

        Returns:
            dict: A confirmation message on successful deletion.

        Raises:
            TimeoutError: If `wait_until_deleted` is True and the ontology
                is not confirmed deleted within the `timeout` period.
        """
        if not ontology_exists(self, ontology_id):
            logger.info("Ontology '%s' does not exist. Skipping deletion.", ontology_id)
            return {"message": f"Ontology '{ontology_id}' does not exist."}

        endpoint = f"/api/ontology/{ontology_id}"
        params = {
            "deleteMetadataEntry": str(delete_metadata_entry).lower(),
            "deleteStoredFiles": str(delete_stored_files).lower(),
        }

        logger.info("Deleting ontology '%s'…", ontology_id)
        resp = self.request("DELETE", endpoint, params=params)

        if resp.status_code not in (200, 202):
            logger.error("Ontology deletion failed: %s %s", resp.status_code, resp.text)
            resp.raise_for_status()

        logger.info("Deletion request accepted for ontology '%s'.", ontology_id)

        if wait_until_deleted:
            logger.info("Waiting for ontology '%s' to be fully deleted …", ontology_id)
            start = time.time()
            while time.time() - start < timeout:
                if not ontology_exists(self, ontology_id):
                    logger.info("Ontology '%s' confirmed deleted.", ontology_id)
                    return {"message": f"Ontology '{ontology_id}' deleted."}
                time.sleep(2)
            else:
                logger.warning("Timeout waiting for ontology '%s' to be fully deleted.", ontology_id)
                # Raise an exception to signal failure
                raise TimeoutError(
                    f"Timeout waiting for ontology '{ontology_id}' to be fully deleted after {timeout}s."
                )
        else:
            return {"message": f"Deletion of '{ontology_id}' initiated"}

    def replay_ontology(
            self,
            ontology_id: str,
            *,
            with_job_details: bool = False,
    ) -> Any:
        """
        Rebuild an ontology by replaying its saved builder rules (reload with edits).

        Wraps ``POST /api/ontology/{ontologyId}/replay``. Use this after calling
        :meth:`update_builder_rules` with ``save_only=True`` to apply the saved
        rule changes and rebuild the ontology.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to replay (e.g. ``"CATTLE_DISEASE_DEMO"``).
        with_job_details : bool, optional
            When ``True``, the server returns a ``JobSubmitResponse`` dict
            (status 202) instead of a plain string (status 200).

        Returns
        -------
        str or dict
            A confirmation string, or a ``JobSubmitResponse`` dict when
            ``with_job_details=True``.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        params: dict[str, Any] = {"withJobDetails": str(with_job_details).lower()}
        logger.info("Replaying ontology '%s' (with_job_details=%s)", ontology_id, with_job_details)
        response = self.request("POST", f"/api/ontology/{ontology_id}/replay", params=params)
        response.raise_for_status()
        try:
            return response.json()
        except Exception:
            return response.text

    def reindex_ontology(
            self,
            ontology_id: str,
            *,
            with_job_details: bool = False,
    ) -> Any:
        """
        Reindex an ontology, forcing a full reload and reindex job.

        Wraps ``POST /api/ontology/{ontologyId}/reindex``. Unlike
        :meth:`replay_ontology` (which replays edit history), this forces a
        complete reload from source files and rebuilds the search index.

        Parameters
        ----------
        ontology_id : str
            The ontology ID to reindex (e.g. ``"CATTLE_DISEASE_DEMO"``).
        with_job_details : bool, optional
            When ``True``, the server returns a ``JobSubmitResponse`` dict
            (status 202) instead of a plain string (status 200).

        Returns
        -------
        str or dict
            A confirmation string, or a ``JobSubmitResponse`` dict when
            ``with_job_details=True``.

        Raises
        ------
        requests.HTTPError
            If the server returns a non-2xx response.
        """
        params: dict[str, Any] = {"withJobDetails": str(with_job_details).lower()}
        logger.info("Reindexing ontology '%s' (with_job_details=%s)", ontology_id, with_job_details)
        response = self.request("POST", f"/api/ontology/{ontology_id}/reindex", params=params)
        response.raise_for_status()
        try:
            return response.json()
        except Exception:
            return response.text

    # ---------------------------------- #
    # -------- CLASS OPERATIONS -------- #
    # ---------------------------------- #

    def create_class(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience wrapper around :meth:`create_entity` for creating a new class.

        Note: ``super_entity`` must be a **full IRI** (e.g.
        ``"http://purl.obolibrary.org/obo/MONDO_0024913"``), not a short-form ID.
        """
        return self.create_entity(
            ontology_id=ontology_id,
            entity_type="classes",
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            transaction_id=transaction_id,
            annotated=annotated
        )

    def suggest_class(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None,
            clear_transaction: bool = True
    ) -> dict[str, Any]:
        """Create a class and immediately submit the transaction as a suggestion.

        .. warning::
            If a transaction is already cached for this ontology (e.g. from a previous
            ``create_class`` or ``bulk_add_classes`` call), the new class is added to
            that existing transaction and the **entire** transaction is suggested — not
            just this class. Clear the cache first with
            :meth:`clear_cached_transaction_id` if you want an isolated suggestion.
        """
        result = self.create_class(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.suggest_transaction(ontology_id, transaction_id=tx_id, message=message, clear_transaction=clear_transaction)

    def commit_class(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Create a class and immediately commit the transaction.

        .. warning::
            If a transaction is already cached for this ontology (e.g. from a previous
            ``create_class`` or ``bulk_add_classes`` call), the new class is added to
            that existing transaction and the **entire** transaction is committed — not
            just this class. Clear the cache first with
            :meth:`clear_cached_transaction_id` if you want an isolated commit.
        """
        result = self.create_class(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.commit_transaction(
            ontology_id=ontology_id,
            transaction_id=tx_id,
            create_reverse_mappings=create_reverse_mappings,
            validation_checksum=validation_checksum,
            clear_transaction=clear_transaction,
            message=message
        )

    def bulk_add_classes(self, ontology_id: str, classes: Union[list[str], list[dict]]) -> dict:
        """
        Add multiple classes to a specified ontology in bulk.

        Args:
            ontology_id (str): The ontology ID to which classes will be added.
            classes (list[str] | list[dict]): Either a list of label strings (e.g. ``["Cat", "Dog"]``),
                or a list of class payload dicts. When passing dicts, valid keys are:

                - ``label`` *(str, required)* — primary label for the class
                - ``subClassOf`` *(str, optional)* — primary ID of the parent class
                - ``description`` *(str, optional)* — class description
                - ``primaryId`` *(str, optional)* — full IRI to use as primary ID; auto-generated if omitted
                - ``shortIds`` *(list[str], optional)* — short-form IDs (CURIEs); required if ``primaryId`` is supplied
                - ``transactionId`` *(str, optional)* — group edits into an existing transaction;
                  only the first ``transactionId`` in the list is used (others are ignored)

                Note: use ``"subClassOf"`` (not ``"superEntity"``) for the parent — this differs
                from the single-entity :meth:`create_entity` API.

        Returns:
            dict: {
                "transactionId": str,
                "createdClasses": list[dict]
            }
        """
        if classes:
            if all(isinstance(item, str) for item in classes):
                classes = [{"label": label} for label in classes]
            elif not all(isinstance(item, dict) for item in classes):
                raise ValueError(
                    "classes must be a list of strings or a list of dicts; "
                    "mixed or unsupported item types are not allowed"
                )

        endpoint = f"/api/ontologies/{ontology_id}/classes/bulk"
        logger.info("Adding %d class(es) to ontology '%s' …", len(classes), ontology_id)

        try:
            response = self.request("PUT", endpoint, json=classes)
            response.raise_for_status()
        except Exception as e:
            logger.error("Bulk class creation failed: %s", e)
            raise

        data = response.json()
        transaction_id = data[0].get("transactionId") if data else None

        if transaction_id:
            self.set_cached_transaction_id(ontology_id, transaction_id)
            logger.info("Transaction ID '%s' cached for ontology '%s'.", transaction_id, ontology_id)
        else:
            logger.warning("No transaction ID found in response — nothing cached.")

        return {
            "transactionId": transaction_id,
            "createdClasses": data
        }

    # ------------------------------------ #
    # -------- INSTANCE OPERATIONS ------- #
    # ------------------------------------ #

    def create_instance(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience method for creating a new instance entity."""
        return self.create_entity(
            ontology_id=ontology_id,
            entity_type="instances",
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            transaction_id=transaction_id,
            annotated=annotated
        )

    def suggest_instance(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None,
            clear_transaction: bool = True
    ) -> dict[str, Any]:
        """Create an instance and immediately submit the transaction as a suggestion.

        .. warning::
            If a transaction is already cached for this ontology, the new instance is
            added to that existing transaction and the **entire** transaction is suggested.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated suggestion.
        """
        result = self.create_instance(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.suggest_transaction(ontology_id, transaction_id=tx_id, message=message, clear_transaction=clear_transaction)

    def commit_instance(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Create an instance and immediately commit the transaction.

        .. warning::
            If a transaction is already cached for this ontology, the new instance is
            added to that existing transaction and the **entire** transaction is committed.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated commit.
        """
        result = self.create_instance(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.commit_transaction(
            ontology_id=ontology_id,
            transaction_id=tx_id,
            create_reverse_mappings=create_reverse_mappings,
            validation_checksum=validation_checksum,
            clear_transaction=clear_transaction,
            message=message
        )

    # -------------------------------------- #
    # -------- PROPERTY OPERATIONS --------- #
    # -------------------------------------- #

    def create_annotation_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience method for creating a new OWL annotation property."""
        return self.create_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            transaction_id=transaction_id,
            property_type="annotationProperty",
            annotated=annotated
        )

    def suggest_annotation_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None,
            clear_transaction: bool = True
    ) -> dict[str, Any]:
        """Create an annotation property and immediately submit the transaction as a suggestion.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is suggested.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated suggestion.
        """
        result = self.create_annotation_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.suggest_transaction(ontology_id, transaction_id=tx_id, message=message, clear_transaction=clear_transaction)

    def commit_annotation_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Create an annotation property and immediately commit the transaction.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is committed.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated commit.
        """
        result = self.create_annotation_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.commit_transaction(
            ontology_id=ontology_id,
            transaction_id=tx_id,
            create_reverse_mappings=create_reverse_mappings,
            validation_checksum=validation_checksum,
            clear_transaction=clear_transaction,
            message=message
        )

    def create_object_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience method for creating a new OWL object property."""
        return self.create_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            transaction_id=transaction_id,
            property_type="objectProperty",
            annotated=annotated
        )

    def suggest_object_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None,
            clear_transaction: bool = True
    ) -> dict[str, Any]:
        """Create an object property and immediately submit the transaction as a suggestion.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is suggested.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated suggestion.
        """
        result = self.create_object_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.suggest_transaction(ontology_id, transaction_id=tx_id, message=message, clear_transaction=clear_transaction)

    def commit_object_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Create an object property and immediately commit the transaction.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is committed.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated commit.
        """
        result = self.create_object_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.commit_transaction(
            ontology_id=ontology_id,
            transaction_id=tx_id,
            create_reverse_mappings=create_reverse_mappings,
            validation_checksum=validation_checksum,
            clear_transaction=clear_transaction,
            message=message
        )

    def create_data_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience method for creating a new OWL datatype property."""
        return self.create_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            transaction_id=transaction_id,
            property_type="dataProperty",
            annotated=annotated
        )

    def suggest_data_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None,
            clear_transaction: bool = True
    ) -> dict[str, Any]:
        """Create a datatype property and immediately submit the transaction as a suggestion.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is suggested.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated suggestion.
        """
        result = self.create_data_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.suggest_transaction(ontology_id, transaction_id=tx_id, message=message, clear_transaction=clear_transaction)

    def commit_data_property(
            self,
            ontology_id: str,
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            annotated: bool = False,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Create a datatype property and immediately commit the transaction.

        .. warning::
            If a transaction is already cached for this ontology, the new property is
            added to that existing transaction and the **entire** transaction is committed.
            Clear the cache first with :meth:`clear_cached_transaction_id` if you want
            an isolated commit.
        """
        result = self.create_data_property(
            ontology_id=ontology_id,
            primary_label=primary_label,
            super_entity=super_entity,
            primary_id=primary_id,
            short_ids=short_ids,
            description=description,
            annotated=annotated
        )
        tx_id = result.get("transactionId")
        return self.commit_transaction(
            ontology_id=ontology_id,
            transaction_id=tx_id,
            create_reverse_mappings=create_reverse_mappings,
            validation_checksum=validation_checksum,
            clear_transaction=clear_transaction,
            message=message
        )

    # ----------------------------------- #
    # -------- ENTITY OPERATIONS -------- #
    # ----------------------------------- #

    def create_entity(
            self,
            ontology_id: str,
            entity_type: str,  # "classes", "instances", or "properties"
            primary_label: str,
            *,
            super_entity: Optional[str] = None,
            primary_id: Optional[str] = None,
            short_ids: Optional[list[str]] = None,
            description: Optional[str] = None,
            transaction_id: Optional[str] = None,
            property_type: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Create a new entity (class, instance, or property) in the ontology.

            Args:
                ontology_id (str): The ontology ID to add the entity to.
                entity_type (str): One of ``"classes"``, ``"instances"``, or ``"properties"``.
                primary_label (str): The label for the new entity.
                super_entity (Optional[str]): Full IRI of the parent entity (e.g.
                    ``"http://purl.obolibrary.org/obo/MONDO_0024913"``). Short-form IDs such as
                    ``"MONDO_0024913"`` are **not** accepted by the API and will result in a 400 error.
                primary_id (Optional[str]): Full URI to use as ``primaryId`` for the new entity.
                short_ids (Optional[list[str]]): Short-form IDs (CURIEs) to associate.
                description (Optional[str]): Description or definition for the entity.
                transaction_id (Optional[str]): Transaction ID to use. If omitted, uses the cached
                    transaction ID for this ontology (if present).
                property_type (Optional[str]): Required when ``entity_type == "properties"``.
                    Valid values are:

                    - ``"annotationProperty"`` — OWL annotation property (e.g. for labels, comments, cross-references)
                    - ``"objectProperty"`` — OWL object property (relates individuals to individuals)
                    - ``"dataProperty"`` — OWL datatype property (relates individuals to literal values)
                annotated (bool): If ``True``, request annotated metadata in the response.

            Returns:
                dict[str, Any]: A dictionary with at least:
                    - ``"transactionId"`` (str or None): Transaction ID returned by the server (and cached if present).
                    - ``"createdEntity"`` (dict): The created entity object if provided by the API, otherwise the raw response.

            Raises:
                ValueError: If required parameters are missing, or if ``entity_type`` is invalid,
                    or if ``property_type`` is missing for a property entity,
                    or if ``short_ids`` are missing when ``primary_id`` is provided.
                Exception: If the HTTP request fails.

            Notes:
                - When the response includes a ``transactionId``, it is cached via
                  :meth:`set_cached_transaction_id`.
                - Logging:
                  * INFO when initiating entity creation and when caching a transaction ID.
                  * WARNING if no transaction ID is present in the response.
                  * ERROR if the request fails.
            """
        if not all([ontology_id, entity_type, primary_label]):
            raise ValueError("ontology_id, entity_type, and primary_label are required.")

        allowed = {"classes", "instances", "properties"}
        if entity_type not in allowed:
            raise ValueError(f"entity_type must be one of {sorted(allowed)}")

        if entity_type == "properties" and not property_type:
            raise ValueError("property_type is required when entity_type == 'properties'.")

        if primary_id and not short_ids:
            raise ValueError("short_ids must be provided when primary_id is specified.")

        # Use cached transaction if one is not explicitly supplied.
        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)

        path = f"/api/ontologies/{ontology_id}/{entity_type}/new"
        params = {"annotated": str(annotated).lower()}
        payload: dict[str, Any] = {
            "primaryLabel": primary_label,
        }

        if transaction_id:
            payload["transactionId"] = transaction_id
        if super_entity:
            payload["superEntity"] = super_entity
        if primary_id:
            payload["primaryId"] = primary_id
        if short_ids:
            payload["shortIds"] = short_ids
        if description:
            payload["description"] = description
        if entity_type == "properties":
            payload["propertyType"] = property_type  # validated above

        logger.debug(
            "Creating new %s '%s' under '%s' in ontology '%s' (annotated=%s)",
            entity_type, primary_label, super_entity, ontology_id, annotated
        )

        try:
            response = self.request("PUT", path, json=payload, params=params)
            response.raise_for_status()
        except Exception as e:
            logger.error("Entity creation failed: %s", e)
            raise

        data = response.json()
        tx = data.get("transactionId")

        if tx:
            self.set_cached_transaction_id(ontology_id, tx)
            logger.debug("Transaction ID %s cached for ontology %s", tx, ontology_id)
        else:
            logger.warning("No transaction ID found in response; nothing cached.")

        return {
            "transactionId": tx,
            "createdEntity": data.get("createdEntity", data),
        }

    def edit_entity(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            *,
            new_property_value: Optional[dict] = None,
            old_property_value: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            as_primary_label: bool = False,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """
        Edit a property on a class, instance, or property in the ontology.

        Args:
            ontology_id (str): Ontology ID.
            entity_type (str): One of "classes", "instances", or "properties".
            entity_id (str): The internal CENtree hash ID of the entity (the ``"id"`` field
                returned by :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_details`
                or :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_by_hash_id`).
                This is **not** the short form ID or full IRI.
            new_property_value (dict, optional): New property value to apply.
                To delete a property, set this to None. The dict should contain:
                - ``iri`` (str, required): The property IRI (e.g., "http://www.w3.org/2004/02/skos/core#altLabel").
                - ``value`` (str, required): The property value.
                - ``tags`` (list[dict], optional): List of tag objects for language tags or other metadata.
                  Each tag should have: ``type``, ``value``, ``isLiteral``, ``iri``.
                - ``primaryId`` (str, optional): Primary ID if applicable.
            old_property_value (dict, optional): Old value to replace (None if adding a new property).
                **Important**: When replacing or deleting a property that has tags (e.g., language tags),
                you must include the complete ``tags`` array in ``old_property_value`` to match
                the existing property exactly. Example for a property with a language tag::

                    {
                        "iri": "http://www.w3.org/2004/02/skos/core#altLabel",
                        "value": "precision and recall",
                        "tags": [
                            {
                                "type": "LANG",
                                "value": "en",
                                "isLiteral": True,
                                "iri": "http://www.w3.org/XML/1998/namespace/"
                            }
                        ]
                    }

            transaction_id (str, optional): Transaction ID to use; otherwise, uses cached one.
            as_primary_label (bool): Whether this property becomes the primary label.
            annotated (bool): If True, return annotated metadata.
            message (str, optional): Optional message or reason for the edit.

        Returns:
            dict[str, Any]: JSON response from the server, including transactionId.

        Raises:
            ValueError: If required fields are missing or invalid.
            HTTPError: If the request fails.
        """
        if not all([ontology_id, entity_type, entity_id]):
            raise ValueError("ontology_id, entity_type, and entity_id are required.")

        if entity_type not in {"classes", "instances", "properties"}:
            raise ValueError("entity_type must be one of 'classes', 'instances', or 'properties'.")

        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)

        path = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/editEntity"
        params = {"annotated": str(annotated).lower()}

        payload: dict[str, Any] = {
            "asPrimaryLabel": as_primary_label,
        }

        # Include newPropertyValue explicitly (None means delete the property)
        payload["newPropertyValue"] = new_property_value

        if old_property_value is not None:
            payload["oldPropertyValue"] = old_property_value
        if transaction_id:
            payload["transactionId"] = transaction_id
        if message:
            payload["message"] = message

        logger.debug(
            "Editing %s entity '%s' in ontology '%s' (annotated=%s)",
            entity_type, entity_id, ontology_id, annotated
        )

        try:
            response = self.request("POST", path, json=payload, params=params)
            response.raise_for_status()
        except Exception as e:
            logger.error("Entity edit failed: %s", e)
            raise

        data = response.json()
        tx = data.get("transactionId")

        if tx:
            self.set_cached_transaction_id(ontology_id, tx)
            logger.debug("Transaction ID %s cached for ontology %s", tx, ontology_id)
        else:
            logger.warning("No transaction ID found in response; nothing cached.")

        return data

    def edit_class(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            new_property_value: Optional[dict] = None,
            old_property_value: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            as_primary_label: bool = False,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Convenience wrapper for editing a class entity. See :meth:`edit_entity` for full parameter docs."""
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            new_property_value=new_property_value,
            old_property_value=old_property_value,
            transaction_id=transaction_id,
            as_primary_label=as_primary_label,
            annotated=annotated,
            message=message
        )

    def edit_instance(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            new_property_value: Optional[dict] = None,
            old_property_value: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            as_primary_label: bool = False,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Convenience wrapper for editing an instance entity. See :meth:`edit_entity` for full parameter docs."""
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type="instances",
            entity_id=entity_id,
            new_property_value=new_property_value,
            old_property_value=old_property_value,
            transaction_id=transaction_id,
            as_primary_label=as_primary_label,
            annotated=annotated,
            message=message
        )

    def edit_property(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            new_property_value: Optional[dict] = None,
            old_property_value: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            as_primary_label: bool = False,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Convenience wrapper for editing a property entity. See :meth:`edit_entity` for full parameter docs."""
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            entity_id=entity_id,
            new_property_value=new_property_value,
            old_property_value=old_property_value,
            transaction_id=transaction_id,
            as_primary_label=as_primary_label,
            annotated=annotated,
            message=message
        )

    # ----------------------------------------------- #
    # -------- PROPERTY VALUE OPERATIONS ------------- #
    # ----------------------------------------------- #

    def add_property_value(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            iri: str,
            value: str,
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Add a new property value to an entity.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of ``"classes"``, ``"instances"``, or ``"properties"``.
        entity_id : str
            The internal CENtree hash ID of the entity.
        iri : str
            The property IRI (e.g. ``"http://www.w3.org/2004/02/skos/core#altLabel"``).
        value : str
            The value to add.
        tags : list[dict], optional
            Language tags or other metadata. Each dict should have ``type``, ``value``,
            ``isLiteral``, and ``iri`` keys.
        transaction_id : str, optional
            Transaction ID to use; falls back to the cached ID for this ontology.
        annotated : bool
            If ``True``, request annotated metadata in the response.
        message : str, optional
            Optional reason for the edit.

        Returns
        -------
        dict
            Server response including ``transactionId``.
        """
        new_pv: dict[str, Any] = {
            "iri": iri,
            "value": value,
            "tags": tags if tags is not None else [],
            "primaryId": iri,
        }
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type=entity_type,
            entity_id=entity_id,
            new_property_value=new_pv,
            old_property_value=None,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    def bulk_add_property_values(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            iri: str,
            values: list[str],
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Add multiple property values to a single entity in one transaction.

        Calls :meth:`add_property_value` once per value. All calls share the same
        transaction — the ID from the first response is cached and reused automatically
        for subsequent calls, so no explicit ``transaction_id`` plumbing is needed.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of ``"classes"``, ``"instances"``, or ``"properties"``.
        entity_id : str
            The internal CENtree hash ID of the entity.
        iri : str
            The property IRI to use for every value
            (e.g. ``"http://www.w3.org/2004/02/skos/core#altLabel"`` for synonyms).
        values : list[str]
            List of string values to add.
        tags : list[dict], optional
            Tags applied to every value (e.g. a language tag). Each dict should have
            ``type``, ``value``, ``isLiteral``, and ``iri`` keys.
        transaction_id : str, optional
            Transaction ID for the first call; subsequent calls reuse the cached ID.
        annotated : bool
            If ``True``, request annotated metadata in the response.
        message : str, optional
            Optional reason for the edit, applied to every call.

        Returns
        -------
        list[dict]
            List of server responses, one per value.
        """
        results = []
        for value in values:
            result = self.add_property_value(
                ontology_id=ontology_id,
                entity_type=entity_type,
                entity_id=entity_id,
                iri=iri,
                value=value,
                tags=tags,
                transaction_id=transaction_id,
                annotated=annotated,
                message=message,
            )
            results.append(result)
            # After the first call the transaction ID is cached; clear the explicit
            # reference so subsequent calls pick it up from the cache.
            transaction_id = None
        return results

    def replace_property_value(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            iri: str,
            old_value: str,
            new_value: str,
            *,
            old_tags: Optional[list[dict]] = None,
            new_tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Replace an existing property value on an entity.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of ``"classes"``, ``"instances"``, or ``"properties"``.
        entity_id : str
            The internal CENtree hash ID of the entity.
        iri : str
            The property IRI.
        old_value : str
            The current value to replace. Must match exactly (including tags if present).
        new_value : str
            The replacement value.
        old_tags : list[dict], optional
            Tags on the existing value. Required if the existing value has language tags
            or other metadata — omitting them will cause the match to fail server-side.
        new_tags : list[dict], optional
            Tags to attach to the new value.
        transaction_id : str, optional
            Transaction ID to use; falls back to the cached ID for this ontology.
        annotated : bool
            If ``True``, request annotated metadata in the response.
        message : str, optional
            Optional reason for the edit.

        Returns
        -------
        dict
            Server response including ``transactionId``.

        Notes
        -----
        To obtain the correct ``old_value`` and ``old_tags`` for an existing property,
        use :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_details`
        and inspect the ``"propertyValues"`` list on the response. Each entry has the
        ``iri``, ``value``, and ``tags`` fields needed here::

            details = reader.get_class_details(ontology_id, class_id="MY_CLASS_0001")
            entity_id = details["id"]
            pv = next(p for p in details["propertyValues"] if p["iri"] == iri)
            client.replace_class_property_value(
                ontology_id, entity_id, iri,
                old_value=pv["value"], new_value="new value",
                old_tags=pv.get("tags"),
            )
        """
        old_pv: dict[str, Any] = {"iri": iri, "value": old_value}
        if old_tags:
            old_pv["tags"] = old_tags
        new_pv: dict[str, Any] = {"iri": iri, "value": new_value}
        if new_tags:
            new_pv["tags"] = new_tags
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type=entity_type,
            entity_id=entity_id,
            new_property_value=new_pv,
            old_property_value=old_pv,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    def remove_property_value(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            iri: str,
            value: str,
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Remove an existing property value from an entity.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of ``"classes"``, ``"instances"``, or ``"properties"``.
        entity_id : str
            The internal CENtree hash ID of the entity.
        iri : str
            The property IRI.
        value : str
            The value to remove. Must match exactly (including tags if present).
        tags : list[dict], optional
            Tags on the existing value. Required if the value has language tags or other
            metadata — omitting them will cause the match to fail server-side.
        transaction_id : str, optional
            Transaction ID to use; falls back to the cached ID for this ontology.
        annotated : bool
            If ``True``, request annotated metadata in the response.
        message : str, optional
            Optional reason for the edit.

        Returns
        -------
        dict
            Server response including ``transactionId``.

        Notes
        -----
        To obtain the correct ``value`` and ``tags`` for an existing property,
        use :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_details`
        and inspect the ``"propertyValues"`` list on the response. Each entry has the
        ``iri``, ``value``, and ``tags`` fields needed here::

            details = reader.get_class_details(ontology_id, class_id="MY_CLASS_0001")
            entity_id = details["id"]
            pv = next(p for p in details["propertyValues"] if p["iri"] == iri)
            client.remove_class_property_value(
                ontology_id, entity_id, iri,
                value=pv["value"], tags=pv.get("tags"),
            )
        """
        old_pv: dict[str, Any] = {"iri": iri, "value": value}
        if tags:
            old_pv["tags"] = tags
        return self.edit_entity(
            ontology_id=ontology_id,
            entity_type=entity_type,
            entity_id=entity_id,
            new_property_value=None,
            old_property_value=old_pv,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    # ---- class-specific shortcuts ---- #

    def add_class_property_value(
            self,
            ontology_id: str,
            entity_id: str,
            iri: str,
            value: str,
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Add a new property value to a class. See :meth:`add_property_value` for full parameter docs."""
        return self.add_property_value(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            iri=iri,
            value=value,
            tags=tags,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    def bulk_add_class_property_values(
            self,
            ontology_id: str,
            entity_id: str,
            iri: str,
            values: list[str],
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Add multiple property values to a class. See :meth:`bulk_add_property_values` for full parameter docs."""
        return self.bulk_add_property_values(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            iri=iri,
            values=values,
            tags=tags,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message,
        )

    def replace_class_property_value(
            self,
            ontology_id: str,
            entity_id: str,
            iri: str,
            old_value: str,
            new_value: str,
            *,
            old_tags: Optional[list[dict]] = None,
            new_tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Replace a property value on a class. See :meth:`replace_property_value` for full parameter docs."""
        return self.replace_property_value(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            iri=iri,
            old_value=old_value,
            new_value=new_value,
            old_tags=old_tags,
            new_tags=new_tags,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    def remove_class_property_value(
            self,
            ontology_id: str,
            entity_id: str,
            iri: str,
            value: str,
            *,
            tags: Optional[list[dict]] = None,
            transaction_id: Optional[str] = None,
            annotated: bool = False,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Remove a property value from a class. See :meth:`remove_property_value` for full parameter docs."""
        return self.remove_property_value(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            iri=iri,
            value=value,
            tags=tags,
            transaction_id=transaction_id,
            annotated=annotated,
            message=message
        )

    def obsolete_entity(
            self,
            ontology_id: str,
            entity_type: str,  # "classes", "instances", or "properties"
            entity_id: str,
            *,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False,
    ) -> dict[str, Any]:
        """Obsolete an existing entity (class, instance, or property) in the ontology.

        Args:
            ontology_id (str): The ontology ID containing the entity.
            entity_type (str): One of ``"classes"``, ``"instances"``, or ``"properties"``.
            entity_id (str): The internal CENtree hash ID of the entity (the ``"id"`` field
                returned by :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_details`
                or :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_by_hash_id`).
                This is **not** the short form ID or full IRI.
            transaction_id (Optional[str]): Transaction ID to use. If omitted, uses the cached
                transaction ID for this ontology (if present).
            message (Optional[str]): Message or reason for obsoleting the entity.
            annotated (bool): If ``True``, request annotated metadata in the response.

        Returns:
            dict[str, Any]: A dictionary with at least:
                - ``"transactionId"`` (str or None): Transaction ID returned by the server (and cached if present).
                - ``"obsoletedEntity"`` (dict): The obsoleted entity object if provided by the API, otherwise the raw response.

        Raises:
            ValueError: If required parameters are missing, or if ``entity_type`` is invalid.
            Exception: If the HTTP request fails.

        Notes:
            - When the response includes a ``transactionId``, it is cached via
              :meth:`set_cached_transaction_id`.
            - Logging:
              * INFO when initiating the obsoletion and when caching a transaction ID.
              * WARNING if no transaction ID is present in the response.
              * ERROR if the request fails.
        """
        if not all([ontology_id, entity_type, entity_id]):
            raise ValueError("ontology_id, entity_type, and entity_id are required.")

        allowed = {"classes", "instances", "properties"}
        if entity_type not in allowed:
            raise ValueError(f"entity_type must be one of {sorted(allowed)}")

        # Use cached transaction if one is not explicitly supplied.
        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)

        path = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/obsoleteEntity"
        params = {"annotated": str(annotated).lower()}

        # Build payload only if we have something to send
        payload: dict[str, Any] = {}
        if message:
            payload["message"] = message
        if transaction_id:
            payload["transactionId"] = transaction_id

        logger.debug(
            "Obsoleting %s '%s' in ontology '%s' (annotated=%s)",
            entity_type, entity_id, ontology_id, annotated
        )

        try:
            response = self.request("POST", path, json=(payload or {}), params=params)
            response.raise_for_status()  # API returns 201 on success
        except Exception as e:
            logger.error("Obsolete entity failed: %s", e)
            raise

        data = response.json()
        tx = data.get("transactionId")

        if tx:
            self.set_cached_transaction_id(ontology_id, tx)
            logger.debug("Transaction ID %s cached for ontology %s", tx, ontology_id)
        else:
            logger.warning("No transaction ID found in response; nothing cached.")

        return {
            "transactionId": tx,
            "obsoletedEntity": data.get("obsoletedEntity", data),
        }

    def obsolete_class(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience wrapper for obsoleting a class entity. See :meth:`obsolete_entity` for full parameter docs."""
        return self.obsolete_entity(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated
        )

    def obsolete_instance(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience wrapper for obsoleting an instance entity. See :meth:`obsolete_entity` for full parameter docs."""
        return self.obsolete_entity(
            ontology_id=ontology_id,
            entity_type="instances",
            entity_id=entity_id,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated
        )

    def obsolete_property(
            self,
            ontology_id: str,
            entity_id: str,
            *,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False
    ) -> dict[str, Any]:
        """Convenience wrapper for obsoleting a property entity. See :meth:`obsolete_entity` for full parameter docs."""
        return self.obsolete_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            entity_id=entity_id,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated
        )

    def delete_entity(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict:
        """
        Delete an entity (class, instance, or property) in an ontology.

        If no transaction ID is provided and no cached one exists, a new transaction will be created and cached.

        Args:
            ontology_id (str): The ontology ID.
            entity_type (str): The type of the entity ('classes', 'instances', or 'properties').
            entity_id (str): The internal CENtree hash ID of the entity (the ``"id"`` field
                returned by :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_details`
                or :meth:`~scibite_toolkit.centree_clients.reader.CENtreeReaderClient.get_class_by_hash_id`).
                This is **not** the short form ID or full IRI.
            transaction_id (str, optional): A transaction ID to use.
            annotated (bool): Whether to mark the edit as annotated.

        Returns:
            dict: Response from the API including transaction and confirmation.

        Raises:
            ValueError: If the entity_type is invalid.
            HTTPError: If the API call fails.
        """
        if entity_type not in {"classes", "instances", "properties"}:
            raise ValueError("entity_type must be one of: 'classes', 'instances', or 'properties'")
        if not ontology_id:
            raise ValueError("ontology_id is required.")
        if not entity_id:
            raise ValueError("entity_id is required.")

        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)
        endpoint = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/deleteEntity"
        params = {"annotated": str(annotated).lower()}
        if transaction_id:
            params["transactionId"] = transaction_id

        logger.info(
            "Requesting deletion of %s '%s' from ontology '%s' with params %s",
            entity_type, entity_id, ontology_id, params
        )

        try:
            response = self.request("POST", endpoint, json={}, params=params)
            response.raise_for_status()
        except Exception as e:
            logger.error("Entity deletion failed: %s", e)
            raise

        data = response.json()
        new_tid = data.get("transactionId")
        if new_tid:
            self.set_cached_transaction_id(ontology_id, new_tid)

        logger.info("Successfully submitted deletion for entity '%s'.", entity_id)
        return data

    def merge_entity(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            entity_id_to_merge: str,
            merge_strategy: str,
            *,
            new_label: Optional[str] = None,
            properties_to_exclude: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False,
            annotation_source: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Merge one entity into another within an ontology.

        The entity identified by ``entity_id`` is the merge *target* (the one that
        survives). ``entity_id_to_merge`` is absorbed into it according to
        ``merge_strategy``.

        Parameters
        ----------
        ontology_id : str
            The ontology ID containing both entities.
        entity_type : str
            One of ``"classes"``, ``"instances"``, or ``"properties"``.
        entity_id : str
            CENtree internal hash ID of the *target* entity (the one to keep).
        entity_id_to_merge : str
            CENtree internal hash ID of the entity to be absorbed.
        merge_strategy : str
            What to do with ``entity_id_to_merge`` after merging. One of:

            * ``"DELETE"`` — permanently delete the merged entity.
            * ``"OBSOLETE"`` — mark it as obsolete (soft deprecation).
            * ``"CREATETERM"`` — retain it as a term pointing to the target.
        new_label : str, optional
            Override the label of the resulting merged entity.
        properties_to_exclude : dict, optional
            Map of property IRIs to values that should not be copied across
            during the merge.
        transaction_id : str, optional
            Transaction ID to group this edit with others. If omitted, the
            cached transaction ID for this ontology is used.
        message : str, optional
            Reason or description recorded with this edit.
        annotated : bool
            If ``True``, request annotated metadata in the response.
        annotation_source : str, optional
            Source annotation to attach when ``annotated`` is ``True``.

        Returns
        -------
        dict
            Raw API response.

        Raises
        ------
        ValueError
            If required parameters are missing or ``entity_type`` / ``merge_strategy``
            is invalid.
        requests.HTTPError
            If the HTTP request fails.

        Requires
        --------
        CENtree >= 3.1.0
        """
        allowed_types = {"classes", "instances", "properties"}
        if entity_type not in allowed_types:
            raise ValueError(f"entity_type must be one of {sorted(allowed_types)}")

        allowed_strategies = {"DELETE", "OBSOLETE", "CREATETERM"}
        if merge_strategy not in allowed_strategies:
            raise ValueError(f"merge_strategy must be one of {sorted(allowed_strategies)}")

        if not all([ontology_id, entity_id, entity_id_to_merge]):
            raise ValueError("ontology_id, entity_id, and entity_id_to_merge are required.")

        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)

        path = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/mergeEntity"
        params: dict[str, Any] = {"annotated": str(annotated).lower()}
        if annotation_source:
            params["annotationSource"] = annotation_source

        payload: dict[str, Any] = {
            "entityIdToMerge": entity_id_to_merge,
            "entityMergeStrategy": merge_strategy,
        }
        if new_label:
            payload["newLabel"] = new_label
        if properties_to_exclude:
            payload["propertiesToExclude"] = properties_to_exclude
        if message:
            payload["message"] = message
        if transaction_id:
            payload["transactionId"] = transaction_id

        logger.debug(
            "Merging %s '%s' into '%s' in ontology '%s' (strategy=%s)",
            entity_type, entity_id_to_merge, entity_id, ontology_id, merge_strategy,
        )

        try:
            response = self.request("POST", path, json=payload, params=params)
            response.raise_for_status()
        except Exception as e:
            logger.error("Merge entity failed: %s", e)
            raise

        data = response.json()
        # The API may return a list (same pattern as commit_class) or a dict
        first = data[0] if isinstance(data, list) else data
        tx = first.get("transactionId")
        if tx:
            self.set_cached_transaction_id(ontology_id, tx)
            logger.debug("Transaction ID %s cached for ontology %s", tx, ontology_id)
        else:
            logger.warning("No transaction ID found in merge response; nothing cached.")

        return data

    def merge_class(
            self,
            ontology_id: str,
            entity_id: str,
            entity_id_to_merge: str,
            merge_strategy: str,
            *,
            new_label: Optional[str] = None,
            properties_to_exclude: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False,
            annotation_source: Optional[str] = None,
    ) -> dict[str, Any]:
        """Convenience wrapper for merging two classes. See :meth:`merge_entity` for full parameter docs."""
        return self.merge_entity(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            entity_id_to_merge=entity_id_to_merge,
            merge_strategy=merge_strategy,
            new_label=new_label,
            properties_to_exclude=properties_to_exclude,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated,
            annotation_source=annotation_source,
        )

    def merge_instance(
            self,
            ontology_id: str,
            entity_id: str,
            entity_id_to_merge: str,
            merge_strategy: str,
            *,
            new_label: Optional[str] = None,
            properties_to_exclude: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False,
            annotation_source: Optional[str] = None,
    ) -> dict[str, Any]:
        """Convenience wrapper for merging two instances. See :meth:`merge_entity` for full parameter docs."""
        return self.merge_entity(
            ontology_id=ontology_id,
            entity_type="instances",
            entity_id=entity_id,
            entity_id_to_merge=entity_id_to_merge,
            merge_strategy=merge_strategy,
            new_label=new_label,
            properties_to_exclude=properties_to_exclude,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated,
            annotation_source=annotation_source,
        )

    def merge_property(
            self,
            ontology_id: str,
            entity_id: str,
            entity_id_to_merge: str,
            merge_strategy: str,
            *,
            new_label: Optional[str] = None,
            properties_to_exclude: Optional[dict] = None,
            transaction_id: Optional[str] = None,
            message: Optional[str] = None,
            annotated: bool = False,
            annotation_source: Optional[str] = None,
    ) -> dict[str, Any]:
        """Convenience wrapper for merging two properties. See :meth:`merge_entity` for full parameter docs."""
        return self.merge_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            entity_id=entity_id,
            entity_id_to_merge=entity_id_to_merge,
            merge_strategy=merge_strategy,
            new_label=new_label,
            properties_to_exclude=properties_to_exclude,
            transaction_id=transaction_id,
            message=message,
            annotated=annotated,
            annotation_source=annotation_source,
        )

    def delete_class(
            self,
            ontology_id: str,
            entity_id: str,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict:
        """Convenience wrapper for deleting a class entity. See :meth:`delete_entity` for full parameter docs."""
        return self.delete_entity(
            ontology_id=ontology_id,
            entity_type="classes",
            entity_id=entity_id,
            transaction_id=transaction_id,
            annotated=annotated
        )

    def delete_instance(
            self,
            ontology_id: str,
            entity_id: str,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict:
        """Convenience wrapper for deleting an instance entity. See :meth:`delete_entity` for full parameter docs."""
        return self.delete_entity(
            ontology_id=ontology_id,
            entity_type="instances",
            entity_id=entity_id,
            transaction_id=transaction_id,
            annotated=annotated
        )

    def delete_property(
            self,
            ontology_id: str,
            entity_id: str,
            transaction_id: Optional[str] = None,
            annotated: bool = False
    ) -> dict:
        """Convenience wrapper for deleting a property entity. See :meth:`delete_entity` for full parameter docs."""
        return self.delete_entity(
            ontology_id=ontology_id,
            entity_type="properties",
            entity_id=entity_id,
            transaction_id=transaction_id,
            annotated=annotated
        )

    # ---------------------------------------- #
    # -------- TRANSACTION MANAGEMENT -------- #
    # ---------------------------------------- #

    def suggest_transaction(
            self,
            ontology_id: str,
            transaction_id: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """
        Submit a transaction as a suggestion for review.

        Args:
            ontology_id (str): The ontology ID.
            transaction_id (str, optional): Transaction ID to submit. If not provided, uses cached one.
            clear_transaction (bool): Whether to clear the cached transaction ID after submission. Defaults to True.
            message (str, optional): Optional message to include with the suggestion.

        Returns:
            dict: JSON response from the server.

        Raises:
            ValueError: If no transaction ID is provided or cached.
            HTTPError: If the API request fails.
        """
        if not self.base_url:
            raise ValueError("Base URL is not set.")
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)
        if not transaction_id:
            raise ValueError(f"No transaction ID provided or cached for ontology '{ontology_id}'.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/transactions/{transaction_id}/suggest"
        logger.debug("Submitting suggestion for transaction '%s' in ontology '%s'…", transaction_id, ontology_id)

        payload = {"message": message} if message else None

        try:
            response = self.request("POST", endpoint, json=payload)
            response.raise_for_status()
        except Exception as e:
            logger.error("Failed to suggest transaction: %s", e)
            raise

        logger.debug("✓ Transaction '%s' successfully suggested.", transaction_id)

        if clear_transaction:
            self.clear_cached_transaction_id(ontology_id)

        return response.json()

    def commit_transaction(
            self,
            ontology_id: str,
            transaction_id: Optional[str] = None,
            create_reverse_mappings: bool = False,
            validation_checksum: Optional[str] = None,
            clear_transaction: bool = True,
            message: Optional[str] = None
    ) -> dict[str, Any]:
        """Commit a transaction for the given ontology.

        Args:
            ontology_id (str): The ontology ID.
            transaction_id (str, optional): The transaction ID to commit. If not provided, uses the cached ID.
            create_reverse_mappings (bool): Whether to automatically create reverse mappings during commit.
            validation_checksum (str, optional): A checksum to validate the transaction state before commit.
            clear_transaction (bool): Whether to clear the cached transaction ID after commit. Defaults to True.

        Returns:
            dict[str, Any]: The response returned by the commit endpoint.

        Raises:
            ValueError: If `ontology_id` is empty or no transaction ID is provided or cached.
            HTTPError: If the commit request fails.

        Notes:
            - If `clear_transaction` is True (default), the transaction will be removed from the in-memory cache after a successful commit.
            - Logging:
                * INFO when committing and when commit is successful.
                * ERROR if the commit fails.
        """
        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)
        if not transaction_id:
            raise ValueError(f"No transaction ID provided or cached for ontology '{ontology_id}'.")
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/transactions/{transaction_id}/commit"
        payload = {"createReverseMappings": create_reverse_mappings}
        if validation_checksum:
            payload["validationChecksum"] = validation_checksum
        if message:
            payload["message"] = message

        logger.info("Committing transaction '%s' for ontology '%s'…", transaction_id, ontology_id)

        try:
            response = self.request("POST", endpoint, json=payload)
            response.raise_for_status()
        except Exception as e:
            logger.error("Failed to commit transaction '%s': %s", transaction_id, e)
            raise

        logger.info("✓ Transaction '%s' committed successfully.", transaction_id)

        if clear_transaction:
            self.clear_cached_transaction_id(ontology_id)

        return response.json()

    def delete_transaction(
            self,
            ontology_id: str,
            transaction_id: Optional[str] = None,
            clear_transaction: bool = True
    ) -> bool:
        """
        Delete a transaction from the ontology.

        Args:
            ontology_id (str): The ontology ID.
            transaction_id (str, optional): The transaction ID to delete. If not provided, uses cached ID.
            clear_transaction (bool): Whether to clear the cached transaction ID after deletion. Defaults to True.

        Returns:
            bool: True if deletion was confirmed by the server, False otherwise.

        Raises:
            ValueError: If no transaction ID is provided or cached.
            HTTPError: If the request fails.
        """
        transaction_id = transaction_id or self.get_cached_transaction_id(ontology_id)
        if not transaction_id:
            raise ValueError(f"No transaction ID provided or cached for ontology '{ontology_id}'.")

        endpoint = f"/api/ontologies/{ontology_id}/transactions/{transaction_id}"

        logger.info("Deleting transaction '%s' from ontology '%s'…", transaction_id, ontology_id)

        try:
            response = self.request("DELETE", endpoint)
            response.raise_for_status()
            response_text = response.text.strip()
            if response.status_code == 200 and response_text == "Successfully discarded local edits":
                logger.info("✓ Transaction '%s' deleted successfully.", transaction_id)
                if clear_transaction:
                    self.clear_cached_transaction_id(ontology_id)
                return True
            else:
                logger.warning(
                    "Unexpected response when deleting transaction: status=%s, text=%r",
                    response.status_code, response_text
                )
                return False
        except Exception as e:
            logger.error("Failed to delete transaction '%s': %s", transaction_id, e)
            raise

    def get_uncommitted_transactions(
            self,
            ontology_id: str,
            user_login: Optional[str] = None,
            from_: int = 0,
            size: int = 100,
            sort: str = "asc",
            stale_transactions_included: bool = True,
            exclude_suggestions: bool = True
    ) -> dict[str, Any]:
        """
        Retrieve uncommitted transactions for a given ontology and user.

        Args:
            ontology_id (str): The ontology ID to query.
            user_login (str, optional): User login to query transactions for.
                If not provided, the authenticated user's login is used.
            from_ (int): Pagination start index (default: 0).
            size (int): Number of transactions to retrieve (default: 100).
            sort (str): 'asc' or 'desc' based on transaction date (default: 'asc').
            stale_transactions_included (bool): Whether to include stale transactions (default: True).
            exclude_suggestions (bool): Whether to exclude suggested transactions (default: True).

        Returns:
            dict[str, Any]: A dictionary containing total, from, and elements (transactions).

        Raises:
            HTTPError: If the request fails.
            ValueError: If ontology_id is not provided or invalid.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be provided.")

        user_login = user_login or self.get_username()
        endpoint = f"/api/ontologies/{ontology_id}/transactions/{user_login}/uncommitted"

        params = {
            "from": from_,
            "size": size,
            "sort": sort,
            "staleTransactionsIncluded": str(stale_transactions_included).lower(),
            "excludeSuggestions": str(exclude_suggestions).lower(),
        }

        logger.info(
            "Fetching uncommitted transactions for ontology='%s', user='%s', from=%d, size=%d, sort=%s",
            ontology_id, user_login, from_, size, sort
        )

        try:
            response = self.request("GET", endpoint, params=params)
            response.raise_for_status()
            logger.info("✓ Uncommitted transactions retrieved successfully.")
            return response.json()
        except Exception as e:
            logger.error("Failed to retrieve uncommitted transactions: %s", e)
            raise

    def get_suggestions(
            self,
            ontology_id: Optional[str] = None,
            user_login: Optional[str] = None,
            status: Optional[str] = None,
            page: int = 0,
            size: int = 10,
            sort: str = "asc",
    ) -> dict[str, Any]:
        """
        Retrieve pending edit suggestions, optionally filtered by ontology, user, and status.

        Wraps ``GET /api/ontologies/suggestions``.

        Parameters
        ----------
        ontology_id : str, optional
            Filter suggestions to this ontology. If not provided, suggestions
            for all ontologies are returned.
        user_login : str, optional
            Filter suggestions submitted by this user login. If not provided,
            suggestions from all users are returned.
        status : str, optional
            Filter by suggestion status. One of ``"OPEN"``, ``"APPROVED"``,
            ``"REJECTED"``, or ``"CANCELLED"``. If not provided, all statuses
            are returned.
        page : int, optional
            Page number (0-indexed). Default is 0.
        size : int, optional
            Number of results per page. Default is 10.
        sort : str, optional
            Sort order by creation date, ``"asc"`` or ``"desc"``. Default is ``"asc"``.

        Returns
        -------
        dict
            Paginated response containing:

            - ``content``: List of suggestion objects, each with:
                - ``transactionId``: Transaction ID for this suggestion.
                - ``userLogin``: Login of the user who submitted the suggestion.
                - ``userFullName``: Full name of the submitter.
                - ``ontologyId``: Ontology this suggestion belongs to.
                - ``creationDate``: ISO 8601 creation timestamp.
                - ``status``: Current status (``OPEN``, ``APPROVED``, etc.).
                - ``description``: Human-readable description/message.
                - ``size``: Number of edits in the suggestion.
                - ``ontologyEditSuggestionActionVMList``: List of individual edit actions.
            - ``totalElements``: Total number of matching suggestions.
            - ``totalPages``: Total number of pages.
            - ``number``: Current page number.

        Raises
        ------
        ValueError
            If ``status`` is not one of the accepted values.
        HTTPError
            If the request fails.

        Requires
        --------
        CENtree >= 3.0.0

        Examples
        --------
        >>> suggestions = editor.get_suggestions(ontology_id="MY_ONTOLOGY", status="OPEN")
        >>> for s in suggestions["content"]:
        ...     print(s["transactionId"], s["description"])
        """
        valid_statuses = {"OPEN", "APPROVED", "REJECTED", "CANCELLED"}
        if status is not None and status not in valid_statuses:
            raise ValueError(f"status must be one of {sorted(valid_statuses)}, got {status!r}")

        params: dict[str, Any] = {"page": page, "size": size, "sort": sort}
        if ontology_id:
            params["ontologyId"] = ontology_id
        if user_login:
            params["user"] = user_login
        if status:
            params["status"] = status

        logger.info(
            "Fetching suggestions (ontology=%s, user=%s, status=%s, page=%d, size=%d)",
            ontology_id, user_login, status, page, size,
        )

        try:
            response = self.request("GET", "/api/ontologies/suggestions", params=params)
            response.raise_for_status()
            logger.info("✓ Suggestions retrieved successfully.")
            return response.json()
        except Exception as e:
            logger.error("Failed to retrieve suggestions: %s", e)
            raise

    # -------------------------------- #
    # -------- EDIT HISTORY ---------- #
    # -------------------------------- #

    def get_edits(
            self,
            ontology_id: str,
            from_date: Optional[str] = None,
            page: int = 0,
            size: int = 100
    ) -> dict[str, Any]:
        """
        Get all edits for an ontology.

        Returns paginated edit history for the entire ontology, including
        classes, properties, and instances.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        from_date : str, optional
            Filter edits from this date (ISO 8601 format, e.g., '2020-01-01T00:00:00Z').
            Without this parameter, only recent edits may be returned.
        page : int, optional
            Page number (0-indexed). Default is 0.
        size : int, optional
            Number of results per page. Default is 100.

        Returns
        -------
        dict
            Paginated response containing:
            - content: List of edit records
            - totalElements: Total number of edits
            - totalPages: Total number of pages
            - number: Current page number

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.

        Examples
        --------
        >>> edits = client.get_edits("my_ontology", from_date="2024-01-01T00:00:00Z")
        >>> for edit in edits["content"]:
        ...     print(edit["id"], edit["ontologyEditActionSet"])
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits"
        params = {"page": page, "size": size}
        if from_date:
            params["fromDate"] = from_date

        logger.debug("Fetching edits for ontology='%s', page=%d, size=%d", ontology_id, page, size)

        response = self.request("GET", endpoint, params=params)
        response.raise_for_status()

        logger.debug("✓ Retrieved edits for ontology '%s'.", ontology_id)
        return response.json()

    def get_committed_edits(
            self,
            ontology_id: str,
            from_date: Optional[str] = None,
            page: int = 0,
            size: int = 100
    ) -> dict[str, Any]:
        """
        Get committed edits for an ontology.

        Returns only committed (not pending) edits, useful for audit trails.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        from_date : str, optional
            Filter edits from this date (ISO 8601 format).
        page : int, optional
            Page number (0-indexed). Default is 0.
        size : int, optional
            Number of results per page. Default is 100.

        Returns
        -------
        dict
            Paginated response containing committed edit records.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/committed"
        params = {"page": page, "size": size}
        if from_date:
            params["fromDate"] = from_date

        logger.debug("Fetching committed edits for ontology='%s'", ontology_id)

        response = self.request("GET", endpoint, params=params)
        response.raise_for_status()

        logger.debug("✓ Retrieved committed edits for ontology '%s'.", ontology_id)
        return response.json()

    def get_entity_edits(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str
    ) -> dict[str, Any]:
        """
        Get edit history for a specific entity.

        Returns the complete edit history for a class, property, or instance.
        The entity_id must be the internal hash ID, not the short form ID.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of: 'classes', 'properties', 'instances'.
        entity_id : str
            The internal hash ID of the entity (e.g., '5313c7b729e9...').

        Returns
        -------
        dict
            Edit history containing:
            - editsHistory: List of committed edits (most recent first)
            - currentEdits: List of pending/uncommitted edits
            - newClass: Present if this is a newly created entity

        Raises
        ------
        ValueError
            If any required parameter is empty or entity_type is invalid.
        requests.HTTPError
            If the API request fails.

        Examples
        --------
        >>> history = client.get_entity_edits("my_ontology", "classes", "5313c7b729e9...")
        >>> for edit in history["editsHistory"]:
        ...     print(f"Edit {edit['id']}: {edit['ontologyEditActionSet']}")
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not entity_id:
            raise ValueError("entity_id must be a non-empty string.")
        if entity_type not in ("classes", "properties", "instances"):
            raise ValueError("entity_type must be one of: 'classes', 'properties', 'instances'.")

        endpoint = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/edits"

        logger.debug("Fetching edit history for %s/%s in ontology='%s'", entity_type, entity_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        logger.debug("✓ Retrieved edit history for entity '%s'.", entity_id)
        return response.json()

    def get_class_edits(self, ontology_id: str, class_id: str) -> dict[str, Any]:
        """
        Get edit history for a specific class.

        Convenience method that calls get_entity_edits with entity_type='classes'.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        class_id : str
            The internal hash ID of the class.

        Returns
        -------
        dict
            Edit history for the class.

        See Also
        --------
        get_entity_edits : Generic method for any entity type.
        """
        return self.get_entity_edits(ontology_id, "classes", class_id)

    def get_edit(self, ontology_id: str, edit_id: int) -> dict[str, Any]:
        """
        Get details for a specific edit.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        edit_id : int
            The unique edit identifier.

        Returns
        -------
        dict
            The edit record containing full details of the change.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails or edit not found.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/{edit_id}"

        logger.debug("Fetching edit %d for ontology='%s'", edit_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        logger.debug("✓ Retrieved edit %d.", edit_id)
        return response.json()

    def get_transaction_edits(self, transaction_id: str) -> list[dict[str, Any]]:
        """
        Get all edits belonging to a specific transaction.

        Parameters
        ----------
        transaction_id : str
            The transaction UUID.

        Returns
        -------
        list[dict]
            List of edit records in the transaction.

        Raises
        ------
        ValueError
            If transaction_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not transaction_id:
            raise ValueError("transaction_id must be a non-empty string.")

        endpoint = f"/api/ontologies/edits/transactions/{transaction_id}"

        logger.debug("Fetching edits for transaction='%s'", transaction_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        logger.debug("✓ Retrieved edits for transaction '%s'.", transaction_id)
        return response.json()

    # -------------------------------- #
    # -------- EDIT COMPARISON ------- #
    # -------------------------------- #

    def compare_edit_with_previous(self, ontology_id: str, edit_id: int) -> dict[str, Any]:
        """
        Compare an edit with the previous version of the entity.

        Shows what changed in this edit compared to the previous state.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        edit_id : int
            The edit identifier to compare.

        Returns
        -------
        dict
            Comparison result showing differences.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/{edit_id}/compareWithPrevious"

        logger.debug("Comparing edit %d with previous for ontology='%s'", edit_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        return response.json()

    def compare_edit_with_current(self, ontology_id: str, edit_id: int) -> dict[str, Any]:
        """
        Compare an edit with the current state of the entity.

        Useful for seeing how much has changed since a particular edit.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        edit_id : int
            The edit identifier to compare.

        Returns
        -------
        dict
            Comparison result showing differences from current state.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/{edit_id}/compareWithCurrent"

        logger.debug("Comparing edit %d with current for ontology='%s'", edit_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        return response.json()

    def compare_edit_with_original(self, ontology_id: str, edit_id: int) -> dict[str, Any]:
        """
        Compare an edit with the original state of the entity.

        Shows all changes since the entity was created.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        edit_id : int
            The edit identifier to compare.

        Returns
        -------
        dict
            Comparison result showing differences from original state.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/{edit_id}/compareWithOriginal"

        logger.debug("Comparing edit %d with original for ontology='%s'", edit_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        return response.json()

    def compare_edit_with_previous_commit(self, ontology_id: str, edit_id: int) -> dict[str, Any]:
        """
        Compare an edit with the previous committed version.

        Useful when reviewing uncommitted changes.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        edit_id : int
            The edit identifier to compare.

        Returns
        -------
        dict
            Comparison result showing differences from last commit.

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/{edit_id}/compareWithPreviousCommit"

        logger.debug("Comparing edit %d with previous commit for ontology='%s'", edit_id, ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        return response.json()

    # -------------------------------- #
    # -------- UNDO / RESTORE -------- #
    # -------------------------------- #

    def undo_transaction(
            self,
            ontology_id: str,
            transaction_id: str,
            commit: bool = True,
            annotated: bool = False
    ) -> list[dict[str, Any]]:
        """
        Undo an entire transaction.

        Reverts all changes made in the specified transaction.

        .. warning::

            Transaction undo only works if ALL entities in the transaction are
            at their most recent version. If any entity has been modified since,
            the undo will fail with a versioning conflict.

            For entity creation transactions, the API records the undo but the
            entities are NOT actually removed. Use ``undo_entity_creation()``
            instead to delete newly created entities.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        transaction_id : str
            The transaction UUID to undo.
        commit : bool, optional
            Whether to immediately commit the undo. Default is True.
        annotated : bool, optional
            Include edit annotations in response. Default is False.

        Returns
        -------
        list[dict]
            List of edit records created by the undo operation.

        Raises
        ------
        ValueError
            If ontology_id or transaction_id is empty.
        requests.HTTPError
            If the API request fails (e.g., versioning conflict).

        See Also
        --------
        restore_entity_version : Restore a specific entity to any previous state.
        undo_entity_creation : Delete a newly created entity.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not transaction_id:
            raise ValueError("transaction_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/transactions/{transaction_id}/undo"
        params = {
            "commit": str(commit).lower(),
            "annotated": str(annotated).lower()
        }

        logger.info("Undoing transaction '%s' for ontology='%s' (commit=%s)", transaction_id, ontology_id, commit)

        response = self.request("POST", endpoint, params=params)
        response.raise_for_status()

        logger.info("✓ Transaction '%s' undone successfully.", transaction_id)
        return response.json()

    def restore_entity_version(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str,
            edit_id: int
    ) -> dict[str, Any]:
        """
        Restore an entity to a previous version.

        This is the recommended way to revert an entity to any previous state.
        Unlike transaction undo, this can jump to any editId in the entity's
        history, regardless of how many changes have been made since.

        The restore creates and commits a new transaction automatically.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of: 'classes', 'properties', 'instances'.
        entity_id : str
            The internal hash ID of the entity.
        edit_id : int
            The edit ID to restore to (from edit history).

        Returns
        -------
        dict
            The edit record for the restore operation.

        Raises
        ------
        ValueError
            If any required parameter is empty or entity_type is invalid.
        requests.HTTPError
            If the API request fails.

        Examples
        --------
        >>> # Get edit history to find the editId to restore to
        >>> history = client.get_class_edits("my_ontology", "abc123...")
        >>> target_edit_id = history["editsHistory"][2]["id"]  # e.g., third-oldest edit
        >>> client.restore_entity_version("my_ontology", "classes", "abc123...", target_edit_id)

        See Also
        --------
        get_entity_edits : Get edit history to find the edit_id.
        undo_transaction : Undo an entire transaction (more restrictive).
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not entity_id:
            raise ValueError("entity_id must be a non-empty string.")
        if entity_type not in ("classes", "properties", "instances"):
            raise ValueError("entity_type must be one of: 'classes', 'properties', 'instances'.")

        endpoint = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/edits/{edit_id}/restore"

        logger.info(
            "Restoring %s/%s to edit %d in ontology='%s'",
            entity_type, entity_id, edit_id, ontology_id
        )

        response = self.request("POST", endpoint)
        response.raise_for_status()

        logger.info("✓ Entity restored to edit %d.", edit_id)
        return response.json()

    def restore_class_version(
            self,
            ontology_id: str,
            class_id: str,
            edit_id: int
    ) -> dict[str, Any]:
        """
        Restore a class to a previous version.

        Convenience method that calls restore_entity_version with entity_type='classes'.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        class_id : str
            The internal hash ID of the class.
        edit_id : int
            The edit ID to restore to.

        Returns
        -------
        dict
            The edit record for the restore operation.

        See Also
        --------
        restore_entity_version : Generic method for any entity type.
        """
        return self.restore_entity_version(ontology_id, "classes", class_id, edit_id)

    def undo_entity_creation(
            self,
            ontology_id: str,
            entity_type: str,
            entity_id: str
    ) -> dict[str, Any]:
        """
        Delete a newly created entity.

        This is the correct endpoint to fully delete a newly created entity.
        Unlike transaction undo, this actually removes the entity from the ontology.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        entity_type : str
            One of: 'classes', 'properties', 'instances'.
        entity_id : str
            The internal hash ID of the entity.

        Returns
        -------
        dict
            The edit record confirming the deletion (includes UNDO_COMMIT,
            DELETE, and COMMIT actions).

        Raises
        ------
        ValueError
            If any required parameter is empty or entity_type is invalid.
        requests.HTTPError
            If the API request fails.

        See Also
        --------
        undo_class_creation : Convenience method for classes.
        delete_entity : Delete an entity (adds to transaction, needs commit).
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not entity_id:
            raise ValueError("entity_id must be a non-empty string.")
        if entity_type not in ("classes", "properties", "instances"):
            raise ValueError("entity_type must be one of: 'classes', 'properties', 'instances'.")

        endpoint = f"/api/ontologies/{ontology_id}/{entity_type}/{entity_id}/undoCreationOfEntity"

        logger.info("Undoing creation of %s/%s in ontology='%s'", entity_type, entity_id, ontology_id)

        response = self.request("POST", endpoint)
        response.raise_for_status()

        logger.info("✓ Entity creation undone (entity deleted).")
        return response.json()

    def undo_class_creation(self, ontology_id: str, class_id: str) -> dict[str, Any]:
        """
        Delete a newly created class.

        Convenience method that calls undo_entity_creation with entity_type='classes'.
        This is the correct way to fully remove a class that was created via the API.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        class_id : str
            The internal hash ID of the class.

        Returns
        -------
        dict
            The edit record confirming the deletion.

        See Also
        --------
        undo_entity_creation : Generic method for any entity type.
        """
        return self.undo_entity_creation(ontology_id, "classes", class_id)

    # -------------------------------- #
    # ----- SUGGESTION WORKFLOW ------ #
    # -------------------------------- #

    def reject_suggestion(
            self,
            ontology_id: str,
            transaction_id: str,
            message: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """
        Reject a suggested transaction.

        Only available to users with approval permissions.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        transaction_id : str
            The transaction UUID of the suggestion.
        message : str, optional
            Reason for rejection.

        Returns
        -------
        list[dict]
            List of edit records for the rejected suggestion.

        Raises
        ------
        ValueError
            If ontology_id or transaction_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not transaction_id:
            raise ValueError("transaction_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/transactions/{transaction_id}/reject"
        payload = {"message": message} if message else None

        logger.info("Rejecting suggestion '%s' for ontology='%s'", transaction_id, ontology_id)

        response = self.request("POST", endpoint, json=payload)
        response.raise_for_status()

        logger.info("✓ Suggestion '%s' rejected.", transaction_id)
        return response.json()

    def cancel_suggestion(
            self,
            ontology_id: str,
            transaction_id: str,
            message: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """
        Cancel/discard a pending suggestion.

        Can be done by the original submitter or an approver.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.
        transaction_id : str
            The transaction UUID of the suggestion.
        message : str, optional
            Optional cancellation message.

        Returns
        -------
        list[dict]
            List of edit records for the cancelled suggestion.

        Raises
        ------
        ValueError
            If ontology_id or transaction_id is empty.
        requests.HTTPError
            If the API request fails.
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")
        if not transaction_id:
            raise ValueError("transaction_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/edits/transactions/{transaction_id}/cancel"
        payload = {"message": message} if message else None

        logger.info("Cancelling suggestion '%s' for ontology='%s'", transaction_id, ontology_id)

        response = self.request("POST", endpoint, json=payload)
        response.raise_for_status()

        logger.info("✓ Suggestion '%s' cancelled.", transaction_id)
        return response.json()

    # -------------------------------- #
    # -------- EDIT EXPORT ----------- #
    # -------------------------------- #

    def export_edits_owl(self, ontology_id: str) -> str:
        """
        Export all edits as an OWL file (ZIP).

        Returns a filename that can be downloaded via the download endpoint.
        The OWL export contains the current state of all entities in RDF/XML format.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.

        Returns
        -------
        str
            The filename of the generated ZIP file (use download_file() to retrieve).

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.

        Examples
        --------
        >>> filename = client.export_edits_owl("my_ontology")
        >>> client.download_file(filename, "/path/to/save/edits.zip")
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/exportEdits"

        logger.info("Exporting edits as OWL for ontology='%s'", ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        filename = response.text.strip()
        logger.info("✓ Edits exported to: %s", filename)
        return filename

    def export_edits_json(self, ontology_id: str) -> str:
        """
        Export all edits as a JSON file (ZIP).

        Returns a download path for the generated ZIP file.
        The JSON export contains the full version history of all entities.

        Parameters
        ----------
        ontology_id : str
            The ontology identifier.

        Returns
        -------
        str
            The download path for the ZIP file (use download_file() to retrieve).

        Raises
        ------
        ValueError
            If ontology_id is empty.
        requests.HTTPError
            If the API request fails.

        Examples
        --------
        >>> download_path = client.export_edits_json("my_ontology")
        >>> # download_path is like '/api/ontologies/download/my_ontology-edits-json....zip'
        >>> filename = download_path.split('/')[-1]
        >>> client.download_file(filename, "/path/to/save/edits.zip")
        """
        if not ontology_id:
            raise ValueError("ontology_id must be a non-empty string.")

        endpoint = f"/api/ontologies/{ontology_id}/exportEditsAsJsonFile"

        logger.info("Exporting edits as JSON for ontology='%s'", ontology_id)

        response = self.request("GET", endpoint)
        response.raise_for_status()

        download_path = response.text.strip()
        logger.info("✓ Edits exported to: %s", download_path)
        return download_path
