"""
模板加载器
"""

import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List


class TemplateLoader:
    """模板加载器"""
    
    def __init__(self):
        self.builtin_dir = Path(__file__).parent / "builtin"
        self.custom_dir = Path(__file__).parent / "custom"
    
    def list_templates(self) -> List[Dict[str, str]]:
        """列出所有模板"""
        templates = []
        
        # 加载内置模板
        if self.builtin_dir.exists():
            for template_file in self.builtin_dir.glob("*.yaml"):
                with open(template_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                templates.append({
                    "name": template_file.stem,
                    "title": data.get("name", template_file.stem),
                    "type": data.get("type", "service"),
                    "description": data.get("description", ""),
                    "source": "builtin"
                })
        
        # 加载自定义模板
        if self.custom_dir.exists():
            for template_file in self.custom_dir.glob("*.yaml"):
                with open(template_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                templates.append({
                    "name": template_file.stem,
                    "title": data.get("name", template_file.stem),
                    "type": data.get("type", "service"),
                    "description": data.get("description", ""),
                    "source": "custom"
                })
        
        return templates
    
    def load_template(self, name: str) -> Optional[Dict[str, Any]]:
        """加载指定模板"""
        # 先尝试内置模板
        builtin_path = self.builtin_dir / f"{name}.yaml"
        if builtin_path.exists():
            with open(builtin_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        
        # 再尝试自定义模板
        custom_path = self.custom_dir / f"{name}.yaml"
        if custom_path.exists():
            with open(custom_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        
        return None
    
    def save_custom_template(self, name: str, data: Dict[str, Any]) -> bool:
        """保存自定义模板"""
        custom_path = self.custom_dir / f"{name}.yaml"
        try:
            with open(custom_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
            return True
        except Exception as e:
            print(f"保存失败: {e}")
            return False
    
    def delete_custom_template(self, name: str) -> bool:
        """删除自定义模板"""
        custom_path = self.custom_dir / f"{name}.yaml"
        if custom_path.exists():
            custom_path.unlink()
            return True
        return False


# 全局实例
_loader = TemplateLoader()


def load_template(name: str) -> Optional[Dict[str, Any]]:
    """加载模板"""
    return _loader.load_template(name)


def list_templates() -> List[Dict[str, str]]:
    """列出所有模板"""
    return _loader.list_templates()


def save_custom_template(name: str, data: Dict[str, Any]) -> bool:
    """保存自定义模板"""
    return _loader.save_custom_template(name, data)


def delete_custom_template(name: str) -> bool:
    """删除自定义模板"""
    return _loader.delete_custom_template(name)
