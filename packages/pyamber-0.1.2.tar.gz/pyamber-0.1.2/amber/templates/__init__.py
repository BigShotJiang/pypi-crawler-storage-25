"""
Templates module - 场景模板加载
"""

from amber.templates.loader import TemplateLoader, load_template, list_templates

__all__ = ["TemplateLoader", "load_template", "list_templates"]
