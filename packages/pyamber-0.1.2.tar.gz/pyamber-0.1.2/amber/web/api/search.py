"""
搜索API
"""

from fastapi import APIRouter, Query
from typing import List, Optional
from pathlib import Path
import yaml

router = APIRouter()


@router.get("/")
async def search(
    q: str = Query("", description="搜索关键词"),
    type: Optional[str] = Query(None, description="人格类型"),
    limit: int = Query(20, ge=1, le=100)
):
    """搜索人格"""
    personas_dir = Path("./data/personas")
    
    if not personas_dir.exists():
        return {"results": [], "total": 0}
    
    results = []
    
    for persona_dir in personas_dir.iterdir():
        if not persona_dir.is_dir():
            continue
        
        amber_file = persona_dir / f"{persona_dir.name}.amber"
        if not amber_file.exists():
            continue
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        name = persona_dir.name
        description = data.get("identity", {}).get("description", "")
        ptype = data.get("personality_type", {}).get("type", "unknown")
        
        # 过滤类型
        if type and ptype != type:
            continue
        
        # 关键词匹配
        if q:
            if q.lower() not in name.lower() and q.lower() not in description.lower():
                continue
        
        results.append({
            "name": name,
            "type": ptype,
            "description": description[:200],
            "creator": data.get("signature", {}).get("creator_id", "unknown")
        })
    
    return {
        "results": results[:limit],
        "total": len(results)
    }
