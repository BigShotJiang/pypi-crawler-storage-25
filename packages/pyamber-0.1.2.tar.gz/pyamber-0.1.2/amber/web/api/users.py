"""
用户API
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import json
from pathlib import Path

router = APIRouter()


class UserCreate(BaseModel):
    """创建用户请求"""
    username: str
    email: str
    password: str


class UserResponse(BaseModel):
    """用户响应"""
    id: str
    username: str
    email: str
    created_at: str
    reputation_score: int


@router.post("/register")
async def register(request: UserCreate):
    """用户注册"""
    users_file = Path("./data/db/users.json")
    users_file.parent.mkdir(parents=True, exist_ok=True)
    
    users = {}
    if users_file.exists():
        with open(users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
    
    if request.username in users:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    import hashlib
    password_hash = hashlib.sha256(request.password.encode()).hexdigest()
    
    user_id = hashlib.md5(request.username.encode()).hexdigest()[:16]
    
    users[request.username] = {
        "id": user_id,
        "username": request.username,
        "email": request.email,
        "password_hash": password_hash,
        "created_at": datetime.now().isoformat(),
        "reputation_score": 0
    }
    
    with open(users_file, 'w', encoding='utf-8') as f:
        json.dump(users, f, ensure_ascii=False, indent=2)
    
    return {"success": True, "user_id": user_id}


@router.get("/{username}", response_model=UserResponse)
async def get_user(username: str):
    """获取用户信息"""
    users_file = Path("./data/db/users.json")
    
    if not users_file.exists():
        raise HTTPException(status_code=404, detail="User not found")
    
    with open(users_file, 'r', encoding='utf-8') as f:
        users = json.load(f)
    
    if username not in users:
        raise HTTPException(status_code=404, detail="User not found")
    
    user = users[username]
    
    return UserResponse(
        id=user["id"],
        username=user["username"],
        email=user["email"],
        created_at=user["created_at"],
        reputation_score=user.get("reputation_score", 0)
    )
