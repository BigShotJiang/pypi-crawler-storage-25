"""
下载API
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path

router = APIRouter()


@router.get("/{name}")
async def download_persona(name: str):
    """下载人格"""
    amber_file = Path(f"./data/personas/{name}/{name}.amber")
    
    if not amber_file.exists():
        raise HTTPException(status_code=404, detail="Persona not found")
    
    return FileResponse(
        path=amber_file,
        filename=f"{name}.amber",
        media_type="application/x-yaml"
    )


@router.get("/{name}/full")
async def download_full(name: str):
    """下载完整备份（含记忆）"""
    full_file = Path(f"./data/personas/{name}/{name}.amber_full")
    
    if not full_file.exists():
        # 创建完整备份
        from amber.formats.full_format import save_full
        from amber.formats.amber_format import load_amber
        from amber.formats.memory_format import load_memory
        
        params = load_amber(str(amber_file))
        memory = load_memory(str(Path(f"./data/personas/{name}/{name}.memory")))
        
        if params and memory:
            save_full(params, memory, str(full_file))
    
    if not full_file.exists():
        raise HTTPException(status_code=404, detail="Backup not found")
    
    return FileResponse(
        path=full_file,
        filename=f"{name}.amber_full",
        media_type="application/octet-stream"
    )
