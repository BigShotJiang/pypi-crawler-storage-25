"""
人格CRUD API
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from pathlib import Path
import yaml
import os
from datetime import datetime

router = APIRouter()


class PersonaCreate(BaseModel):
    """创建人格请求"""
    name: str
    description: str
    personality_type: str = "independent"
    service_ratio: float = 0.5


class DynamicQuestionnaireCreate(BaseModel):
    """动态问卷创建人格请求（新版）"""
    name: str
    answers: Dict[str, Any]
    personality_type: str = "auto"


class PersonaResponse(BaseModel):
    """人格响应"""
    name: str
    type: str
    description: str
    download_count: int
    fork_count: int
    creator: str


@router.get("/", response_model=List[PersonaResponse])
async def list_personas(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    type: Optional[str] = None
):
    """列出人格"""
    personas_dir = Path("./data/personas")
    
    if not personas_dir.exists():
        return []
    
    result = []
    for persona_dir in personas_dir.iterdir():
        if not persona_dir.is_dir():
            continue
        
        amber_file = persona_dir / f"{persona_dir.name}.amber"
        if not amber_file.exists():
            continue
        
        try:
            with open(amber_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except Exception:
            continue
        
        ptype = data.get("personality_type", {}).get("type", "unknown")
        if type and ptype != type:
            continue
        
        result.append(PersonaResponse(
            name=persona_dir.name,
            type=ptype,
            description=data.get("identity", {}).get("description", ""),
            download_count=0,
            fork_count=0,
            creator=data.get("signature", {}).get("creator_id", "unknown")
        ))
    
    return result[skip:skip+limit]


@router.get("/{name}")
async def get_persona(name: str):
    """获取人格详情"""
    amber_file = Path(f"./data/personas/{name}/{name}.amber")
    
    if not amber_file.exists():
        raise HTTPException(status_code=404, detail="Persona not found")
    
    try:
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load persona: {e}")
    
    return data


@router.post("/")
async def create_persona(request: PersonaCreate):
    """快速创建人格"""
    from amber.create.smart_create import smart_create
    
    try:
        result = smart_create(
            request.description,
            request.personality_type,
            request.service_ratio,
            interactive=False
        )
        
        if result:
            return {"success": True, "name": result["name"]}
        else:
            raise HTTPException(status_code=500, detail="Creation failed")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/create-with-dynamic-questionnaire")
async def create_with_dynamic_questionnaire(request: DynamicQuestionnaireCreate):
    """通过动态问卷创建人格（新版 - 推荐）"""
    from amber.create.dynamic_questionnaire import DynamicParameterMapper
    from amber.formats.amber_format import save_amber
    from amber.formats.memory_format import create_empty_memory, save_memory as save_memory_file
    from amber.create.validators import sanitize_params
    
    try:
        answers = request.answers
        name = request.name or answers.get("name", "新人格")
        
        # 映射参数
        mapper = DynamicParameterMapper()
        params = mapper.map(answers)
        
        # 覆盖名称
        params["identity"]["name"] = name
        params["identity"]["description"] = f"通过Web动态问卷创建的{params['personality_type']['type']}人格"
        
        # 处理自动类型推断
        if request.personality_type == "auto":
            # 保持映射器推断的类型
            pass
        elif request.personality_type in ["independent", "service", "mixed"]:
            params["personality_type"]["type"] = request.personality_type
            if request.personality_type == "service":
                params["personality_type"]["service_ratio"] = 1.0
            elif request.personality_type == "independent":
                params["personality_type"]["service_ratio"] = 0.0
            else:
                params["personality_type"]["service_ratio"] = 0.5
        
        # 添加元数据
        params["version"] = "2.0"
        params["created_at"] = datetime.now().isoformat()
        params["metadata"] = {
            "creation_mode": "dynamic_questionnaire_v2",
            "original_answers": {k: v for k, v in answers.items() if k != "name"}
        }
        
        # 添加签名
        if "signature" not in params:
            params["signature"] = {}
        params["signature"]["creator_id"] = "web_user"
        params["signature"]["created_at"] = datetime.now().isoformat()
        params["signature"]["license"] = "CC-BY-NC-ND-4.0"
        
        # 清理参数
        params = sanitize_params(params)
        
        # 保存文件
        data_dir = Path(f"./data/personas/{name}")
        data_dir.mkdir(parents=True, exist_ok=True)
        
        amber_path = data_dir / f"{name}.amber"
        save_amber(params, str(amber_path))
        
        memory = create_empty_memory(params["version"], params["personality_type"]["type"])
        memory_path = data_dir / f"{name}.memory"
        save_memory_file(memory, str(memory_path))
        
        return {
            "success": True,
            "name": name,
            "personality_type": params["personality_type"]["type"],
            "role": params.get("identity", {}).get("role", ""),
            "persona": params
        }
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/questionnaire/schema")
async def get_questionnaire_schema():
    """获取动态问卷 Schema（新版）"""
    from pathlib import Path
    import json
    
    schema_path = Path(__file__).parent.parent.parent / "schemas" / "questionnaire_schema.json"
    
    if schema_path.exists():
        try:
            with open(schema_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    
    # Fallback schema
    return {
        "version": "2.0",
        "title": "人格创造问卷",
        "description": "请用第三人称描述这个角色（他/她/它）",
        "questions": [
            {
                "id": "name",
                "text": "这个角色的名字是？",
                "type": "string",
                "required": True
            },
            {
                "id": "role_type",
                "text": "这个角色的身份是？",
                "type": "select",
                "options": [
                    {"value": "friend", "label": "朋友/伴侣/家人"},
                    {"value": "service", "label": "服务者"},
                    {"value": "character", "label": "虚构角色"}
                ],
                "required": True
            },
            {
                "id": "personality_traits",
                "text": "他/她的核心性格特质",
                "type": "multi_select",
                "options": [
                    {"value": "gentle", "label": "温柔体贴"},
                    {"value": "cheerful", "label": "活泼开朗"},
                    {"value": "professional", "label": "专业严谨"}
                ],
                "max_selections": 2
            },
            {
                "id": "talk_volume",
                "text": "他/她喜欢说话吗？",
                "type": "scale",
                "min": 0,
                "max": 10,
                "default": 5
            }
        ]
    }


@router.delete("/{name}")
async def delete_persona(name: str):
    """删除人格"""
    import shutil
    persona_dir = Path(f"./data/personas/{name}")
    
    if not persona_dir.exists():
        raise HTTPException(status_code=404, detail="Persona not found")
    
    shutil.rmtree(persona_dir)
    
    return {"success": True}