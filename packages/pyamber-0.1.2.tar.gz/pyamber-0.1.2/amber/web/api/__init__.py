"""
API路由
"""

from amber.web.api.personas import router as personas_router
from amber.web.api.users import router as users_router
from amber.web.api.search import router as search_router
from amber.web.api.download import router as download_router

__all__ = ["personas_router", "users_router", "search_router", "download_router"]
