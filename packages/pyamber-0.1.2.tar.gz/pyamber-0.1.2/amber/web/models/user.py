"""
User model
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class User:
    """用户模型"""
    id: str
    username: str
    email: str
    password_hash: str
    created_at: datetime
    reputation_score: int = 0
    is_active: bool = True
    
    @classmethod
    def from_dict(cls, data: dict) -> "User":
        return cls(
            id=data["id"],
            username=data["username"],
            email=data["email"],
            password_hash=data["password_hash"],
            created_at=datetime.fromisoformat(data["created_at"]),
            reputation_score=data.get("reputation_score", 0),
            is_active=data.get("is_active", True)
        )
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "password_hash": self.password_hash,
            "created_at": self.created_at.isoformat(),
            "reputation_score": self.reputation_score,
            "is_active": self.is_active
        }
