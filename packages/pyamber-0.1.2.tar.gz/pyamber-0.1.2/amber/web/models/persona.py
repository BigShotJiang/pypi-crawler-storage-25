"""
Persona model
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class Persona:
    """人格模型"""
    name: str
    creator_id: str
    personality_type: str
    version: str
    description: str
    created_at: datetime
    download_count: int = 0
    fork_count: int = 0
    is_public: bool = True
    
    @classmethod
    def from_dict(cls, data: dict) -> "Persona":
        return cls(
            name=data["name"],
            creator_id=data["creator_id"],
            personality_type=data["personality_type"],
            version=data["version"],
            description=data["description"],
            created_at=datetime.fromisoformat(data["created_at"]),
            download_count=data.get("download_count", 0),
            fork_count=data.get("fork_count", 0),
            is_public=data.get("is_public", True)
        )
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "creator_id": self.creator_id,
            "personality_type": self.personality_type,
            "version": self.version,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "download_count": self.download_count,
            "fork_count": self.fork_count,
            "is_public": self.is_public
        }
