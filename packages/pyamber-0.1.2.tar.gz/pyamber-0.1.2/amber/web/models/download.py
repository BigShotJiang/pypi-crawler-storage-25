"""
Download record model
"""

from dataclasses import dataclass
from datetime import datetime


@dataclass
class DownloadRecord:
    """下载记录模型"""
    id: str
    persona_name: str
    user_id: str
    downloaded_at: datetime
    
    @classmethod
    def from_dict(cls, data: dict) -> "DownloadRecord":
        return cls(
            id=data["id"],
            persona_name=data["persona_name"],
            user_id=data["user_id"],
            downloaded_at=datetime.fromisoformat(data["downloaded_at"])
        )
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "persona_name": self.persona_name,
            "user_id": self.user_id,
            "downloaded_at": self.downloaded_at.isoformat()
        }
