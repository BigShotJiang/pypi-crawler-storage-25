"""
Web module - Web服务（第四期）
"""

from amber.web.app import create_app, app

__all__ = ["create_app", "app"]
