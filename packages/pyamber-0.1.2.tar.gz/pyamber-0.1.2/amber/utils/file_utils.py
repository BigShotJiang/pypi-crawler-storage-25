"""
文件路径处理
"""

import os
import json
import yaml
from pathlib import Path
from typing import Any, Optional


def ensure_dir(path: str) -> bool:
    """确保目录存在"""
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
        return True
    except Exception:
        return False


def read_file(filepath: str, encoding: str = 'utf-8') -> Optional[str]:
    """读取文件内容"""
    try:
        with open(filepath, 'r', encoding=encoding) as f:
            return f.read()
    except Exception:
        return None


def write_file(filepath: str, content: str, encoding: str = 'utf-8') -> bool:
    """写入文件内容"""
    try:
        ensure_dir(str(Path(filepath).parent))
        with open(filepath, 'w', encoding=encoding) as f:
            f.write(content)
        return True
    except Exception:
        return False


def read_json(filepath: str) -> Optional[Any]:
    """读取JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def write_json(filepath: str, data: Any) -> bool:
    """写入JSON文件"""
    try:
        ensure_dir(str(Path(filepath).parent))
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def read_yaml(filepath: str) -> Optional[Any]:
    """读取YAML文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception:
        return None


def write_yaml(filepath: str, data: Any) -> bool:
    """写入YAML文件"""
    try:
        ensure_dir(str(Path(filepath).parent))
        with open(filepath, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
        return True
    except Exception:
        return False


def get_file_size(filepath: str) -> int:
    """获取文件大小（字节）"""
    try:
        return Path(filepath).stat().st_size
    except Exception:
        return 0


def file_exists(filepath: str) -> bool:
    """检查文件是否存在"""
    return Path(filepath).exists()
