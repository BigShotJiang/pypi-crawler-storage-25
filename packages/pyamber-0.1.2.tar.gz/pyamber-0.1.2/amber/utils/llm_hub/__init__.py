"""
LLM Hub - 统一的LLM调用模块
"""

from .version import __version__, __author__, __license__
from .client import LLMClient
from .enums import Provider, ModelType
from .exceptions import (
    LLMHubError, ConfigError, ProviderError, 
    RateLimitError, TokenLimitError
)
from .config import LLMConfig
from .models import Message, Conversation, Role
from .models import Response, StreamResponse, StreamChunk, StreamEventType


def get_token_counter(provider, **kwargs):
    """获取Token计数器"""
    from .providers import get_token_counter as _get_token_counter
    return _get_token_counter(provider, **kwargs)


__all__ = [
    "__version__", "__author__", "__license__",
    "LLMClient",
    "LLMConfig",
    "Provider",
    "ModelType",
    "Message",
    "Conversation",
    "Role",
    "Response",
    "StreamResponse",
    "StreamChunk",
    "StreamEventType",
    "get_token_counter",
    "LLMHubError",
    "ConfigError",
    "ProviderError",
    "RateLimitError",
    "TokenLimitError",
]