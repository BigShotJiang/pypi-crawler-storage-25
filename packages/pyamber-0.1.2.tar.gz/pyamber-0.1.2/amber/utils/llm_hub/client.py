"""LLM客户端"""

from typing import Optional, Dict, Any, Union, List, Generator
import threading
from contextlib import contextmanager

from .exceptions import RateLimitError
from .config import LLMConfig
from .models.message import Conversation, Message
from .models.response import Response, StreamResponse
from .providers import create_provider
from .providers.base import BaseTokenCounter
from .utils.rate_limiter import RateLimiter


class LLMClient:
    """统一的LLM客户端"""
    
    def __init__(self, config: Optional[LLMConfig] = None, enable_rate_limit: bool = True):
        self.config = config or LLMConfig()
        self._provider = None
        self._token_counter = None
        self._rate_limiter = RateLimiter(
            calls_per_minute=self.config.rate_limit_calls_per_minute,
            burst_limit=self.config.rate_limit_burst
        ) if enable_rate_limit and self.config.enable_rate_limit else None
        self._lock = threading.RLock()
        self._init_provider()
    
    def _init_provider(self):
        with self._lock:
            self._provider = create_provider(
                self.config.provider,
                self.config.to_dict(include_sensitive=True)
            )
    
    def _get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            with self._lock:
                if self._token_counter is None:
                    self._token_counter = self._provider.get_token_counter()
        return self._token_counter
    
    def update_config(self, **kwargs):
        with self._lock:
            for key, value in kwargs.items():
                if hasattr(self.config, key):
                    setattr(self.config, key, value)
            self._init_provider()
            self._token_counter = None
    
    @contextmanager
    def _rate_limit_context(self):
        """速率限制上下文管理器"""
        if self._rate_limiter:
            if not self._rate_limiter.wait_and_acquire():
                raise RateLimitError("Rate limit exceeded")
        yield
    
    # ========== 主要API ==========
    
    def chat(
        self,
        messages: Union[List[Dict], Conversation, str],
        **kwargs
    ) -> Union[Response, StreamResponse]:
        """对话接口"""
        with self._rate_limit_context():
            conversation = self._normalize_messages(messages)
            return self._provider.chat(conversation, **kwargs)
    
    def _normalize_messages(self, messages):
        if isinstance(messages, str):
            conv = Conversation()
            conv.add_user(messages)
            return conv
        elif isinstance(messages, list):
            conv = Conversation()
            for msg in messages:
                if isinstance(msg, dict):
                    conv.add(Message(**msg))
                elif isinstance(msg, Message):
                    conv.add(msg)
            return conv
        elif isinstance(messages, Conversation):
            return messages
        raise TypeError(f"Unsupported messages type: {type(messages)}")
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        with self._rate_limit_context():
            return self._provider.complete(prompt, **kwargs)
    
    def stream_chat(self, messages: Union[List[Dict], Conversation, str], **kwargs) -> Generator:
        """流式对话"""
        kwargs["stream"] = True
        response = self.chat(messages, **kwargs)
        if isinstance(response, StreamResponse):
            yield from response
        else:
            from .models.response import StreamChunk, StreamEventType
            yield StreamChunk(
                type=StreamEventType.CONTENT,
                content=response.content,
                delta=response.content
            )
    
    # ========== Token计数 ==========
    
    def count_tokens(self, text: str) -> int:
        return self._get_token_counter().count(text)
    
    def truncate_to_tokens(self, text: str, max_tokens: int, suffix: str = "...") -> str:
        return self._get_token_counter().truncate(text, max_tokens, suffix)
    
    # ========== 其他 ==========
    
    def health_check(self) -> bool:
        try:
            return self._provider.health_check()
        except Exception:
            return False
    
    def get_rate_limit_stats(self) -> Dict:
        if self._rate_limiter:
            return self._rate_limiter.get_stats()
        return {"enabled": False}