"""响应模型"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Generator
from enum import Enum


class StreamEventType(Enum):
    THINKING = "thinking"
    CONTENT = "content"
    DONE = "done"


@dataclass
class StreamChunk:
    type: StreamEventType
    content: str = ""
    delta: str = ""
    accumulated: str = ""
    
    def __str__(self):
        return self.content


class StreamResponse:
    def __init__(self, generator: Generator):
        self.generator = generator
    
    def __iter__(self):
        return self.generator
    
    def collect(self) -> str:
        result = ""
        for chunk in self.generator:
            if chunk.type == StreamEventType.CONTENT:
                result += chunk.content
        return result


@dataclass
class Response:
    content: str = ""
    thinking: str = ""
    model: str = ""
    usage: Optional[Dict[str, int]] = None
    finish_reason: Optional[str] = None
    raw: Optional[Dict] = None
    
    def __str__(self):
        return self.content