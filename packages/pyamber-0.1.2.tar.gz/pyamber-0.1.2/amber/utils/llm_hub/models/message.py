"""消息模型"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum


class Role(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


@dataclass
class Message:
    role: str
    content: str
    name: Optional[str] = None
    
    @classmethod
    def system(cls, content: str) -> "Message":
        return cls(role="system", content=content)
    
    @classmethod
    def user(cls, content: str) -> "Message":
        return cls(role="user", content=content)
    
    @classmethod
    def assistant(cls, content: str) -> "Message":
        return cls(role="assistant", content=content)
    
    def to_dict(self) -> Dict:
        result = {"role": self.role, "content": self.content}
        if self.name:
            result["name"] = self.name
        return result


@dataclass
class Conversation:
    messages: List[Message] = field(default_factory=list)
    system_prompt: Optional[str] = None
    
    def add(self, message: Message):
        self.messages.append(message)
    
    def add_user(self, content: str):
        self.add(Message.user(content))
    
    def add_assistant(self, content: str):
        self.add(Message.assistant(content))
    
    def add_system(self, content: str):
        self.system_prompt = content
    
    def get_messages(self) -> List[Dict]:
        messages = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.extend([m.to_dict() for m in self.messages])
        return messages
    
    def clear(self):
        self.messages.clear()
    
    def __len__(self):
        return len(self.messages)