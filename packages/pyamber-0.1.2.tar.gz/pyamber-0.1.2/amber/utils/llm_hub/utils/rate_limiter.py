"""速率限制器"""

import time
import threading
from typing import Dict
from collections import deque


class RateLimiter:
    def __init__(self, calls_per_minute: int = 60, burst_limit: int = 10):
        self.calls_per_minute = calls_per_minute
        self.burst_limit = burst_limit
        self._calls = deque()
        self._burst_count = 0
        self._lock = threading.RLock()
        self._last_reset = time.time()
    
    def acquire(self) -> bool:
        with self._lock:
            now = time.time()
            while self._calls and now - self._calls[0] > 60:
                self._calls.popleft()
            if now - self._last_reset >= 1.0:
                self._burst_count = 0
                self._last_reset = now
            if len(self._calls) >= self.calls_per_minute:
                return False
            if self._burst_count >= self.burst_limit:
                return False
            self._calls.append(now)
            self._burst_count += 1
            return True
    
    def wait_and_acquire(self, timeout: float = 30.0) -> bool:
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.acquire():
                return True
            time.sleep(0.1)
        return False
    
    def get_stats(self) -> Dict:
        with self._lock:
            now = time.time()
            while self._calls and now - self._calls[0] > 60:
                self._calls.popleft()
            return {
                "calls_last_minute": len(self._calls),
                "burst_count": self._burst_count,
                "limit_per_minute": self.calls_per_minute,
                "burst_limit": self.burst_limit
            }
