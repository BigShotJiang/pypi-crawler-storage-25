"""流式缓冲区"""

import threading


class BoundedStreamBuffer:
    def __init__(self, max_chars: int = 100000):
        self.max_chars = max_chars
        self._buffer = ""
        self._lock = threading.Lock()
        self._truncation_occurred = False
    
    def append(self, text: str) -> str:
        with self._lock:
            self._buffer += text
            overflow = ""
            if len(self._buffer) > self.max_chars:
                overflow = self._buffer[self.max_chars:]
                self._buffer = self._buffer[:self.max_chars]
                self._truncation_occurred = True
            return overflow
    
    def get(self) -> str:
        with self._lock:
            return self._buffer
    
    def clear(self):
        with self._lock:
            self._buffer = ""
            self._truncation_occurred = False
    
    def was_truncated(self) -> bool:
        return self._truncation_occurred
    
    def __len__(self) -> int:
        return len(self._buffer)


class StreamingResponseCollector:
    def __init__(self, max_content_chars: int = 100000, max_thinking_chars: int = 50000):
        self.content_buffer = BoundedStreamBuffer(max_content_chars)
        self.thinking_buffer = BoundedStreamBuffer(max_thinking_chars)
    
    def add_thinking(self, text: str):
        self.thinking_buffer.append(text)
    
    def add_content(self, text: str):
        self.content_buffer.append(text)
    
    def get_content(self) -> str:
        return self.content_buffer.get()
    
    def get_thinking(self) -> str:
        return self.thinking_buffer.get()
    
    def clear(self):
        self.content_buffer.clear()
        self.thinking_buffer.clear()
    
    def get_stats(self) -> dict:
        return {
            "content_chars": len(self.content_buffer),
            "thinking_chars": len(self.thinking_buffer),
        }
