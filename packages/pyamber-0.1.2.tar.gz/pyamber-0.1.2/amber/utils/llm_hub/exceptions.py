"""自定义异常"""

class LLMHubError(Exception):
    pass

class ConfigError(LLMHubError):
    pass

class ProviderError(LLMHubError):
    pass

class RateLimitError(LLMHubError):
    pass

class TokenLimitError(LLMHubError):
    pass