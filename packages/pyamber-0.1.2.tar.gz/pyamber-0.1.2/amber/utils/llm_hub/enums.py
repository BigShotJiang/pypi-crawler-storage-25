"""枚举定义"""

from enum import Enum


class Provider(Enum):
    """LLM提供商"""
    # 云端API
    DEEPSEEK = "deepseek"
    OPENAI = "openai"
    KIMI = "kimi"
    KIMI_INTL = "kimi_intl"
    OPENROUTER = "openrouter"
    ANTHROPIC = "anthropic"
    GOOGLE_GEMINI = "gemini"
    
    # 国产AI
    QWEN = "qwen"
    GLM = "glm"
    ERNIE = "ernie"
    
    # 本地部署
    OLLAMA = "ollama"
    
    @classmethod
    def from_string(cls, value: str):
        for member in cls:
            if member.value == value.lower():
                return member
        raise ValueError(f"Unknown provider: {value}")
    
    def is_local(self) -> bool:
        return self in [self.OLLAMA]
    
    def is_cloud(self) -> bool:
        return not self.is_local()


class ModelType(Enum):
    CHAT = "chat"
    COMPLETION = "completion"
    EMBEDDING = "embedding"