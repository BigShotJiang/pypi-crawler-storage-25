"""提供商基类"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Union, Optional

from ..models.message import Conversation
from ..models.response import Response, StreamResponse


class BaseTokenCounter(ABC):
    @abstractmethod
    def count(self, text: str) -> int:
        pass
    
    def count_messages(self, messages: List[Dict[str, str]]) -> int:
        total = 0
        for msg in messages:
            total += self.count(msg.get("content", ""))
            total += 4
        total += 2
        return total
    
    def truncate(self, text: str, max_tokens: int, suffix: str = "...") -> str:
        if self.count(text) <= max_tokens:
            return text
        
        left, right = 0, len(text)
        while left < right:
            mid = (left + right + 1) // 2
            if self.count(text[:mid]) <= max_tokens - self.count(suffix):
                left = mid
            else:
                right = mid - 1
        
        return text[:left] + suffix


class FallbackTokenCounter(BaseTokenCounter):
    def count(self, text: str) -> int:
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return max(1, chinese + int(english * 0.75))


class BaseProvider(ABC):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.debug = config.get("debug", False)
        self._token_counter = None
    
    @abstractmethod
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        pass
    
    @abstractmethod
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        pass
    
    @abstractmethod
    def health_check(self) -> bool:
        pass
    
    @abstractmethod
    def get_token_counter(self) -> BaseTokenCounter:
        pass