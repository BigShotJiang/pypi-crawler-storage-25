"""Anthropic Claude提供商"""

import requests
from typing import Dict, Any, List, Union

from ..providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from ..models.message import Conversation
from ..models.response import Response


class AnthropicTokenCounter(FallbackTokenCounter):
    pass


class AnthropicProvider(BaseProvider):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "claude-3-sonnet-20240229")
        self.api_url = config.get("api_url", "https://api.anthropic.com/v1")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = AnthropicTokenCounter()
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
    
    def _convert_messages(self, messages: List[Dict]) -> tuple:
        system_prompt = None
        converted = []
        
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                converted.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
        
        return system_prompt, converted
    
    def chat(self, conversation: Conversation, **kwargs) -> Response:
        messages = conversation.get_messages()
        system_prompt, converted_messages = self._convert_messages(messages)
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": converted_messages,
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        response = requests.post(
            f"{self.api_url}/messages",
            json=payload,
            headers=self._get_headers(),
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        response.close()
        
        content = data.get("content", [{}])[0].get("text", "")
        usage = data.get("usage", {})
        
        return Response(
            content=content,
            model=self.model,
            usage={
                "prompt_tokens": usage.get("input_tokens", 0),
                "completion_tokens": usage.get("output_tokens", 0),
                "total_tokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0)
            },
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Response:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.api_url}/models", headers=self._get_headers(), timeout=10)
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False
