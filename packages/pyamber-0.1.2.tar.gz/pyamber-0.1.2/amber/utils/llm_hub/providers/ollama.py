"""Ollama提供商"""

import json
import requests
from typing import Dict, Any, List, Generator, Union

from .base import BaseProvider, BaseTokenCounter
from ..models.message import Conversation
from ..models.response import Response, StreamResponse, StreamChunk, StreamEventType


class OllamaTokenCounter(BaseTokenCounter):
    def __init__(self, base_url: str, model: str):
        self.base_url = base_url
        self.model = model
    
    def count(self, text: str) -> int:
        try:
            response = requests.post(
                f"{self.base_url}/api/tokenize",
                json={"model": self.model, "text": text},
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                tokens = data.get('tokens', [])
                return len(tokens) if tokens else 1
        except Exception:
            pass
        
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return max(1, chinese + int(english * 1.3))


class OllamaProvider(BaseProvider):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("ollama_url", config.get("api_url", "http://localhost:11434"))
        self.model = config.get("model", "llama3.2")
        self.api_url = f"{self.base_url}/api"
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = OllamaTokenCounter(self.base_url, self.model)
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {"Content-Type": "application/json"}
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        converted_messages = []
        for msg in messages:
            converted_messages.append({"role": msg["role"], "content": msg["content"]})
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": converted_messages,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/chat",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return Response(
                content=data.get("message", {}).get("content", ""),
                model=self.model,
                usage=data.get("usage"),
                raw=data
            )
    
    def _stream_chat(self, response) -> Generator:
        accumulated = ""
        for line in response.iter_lines():
            if not line:
                continue
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            try:
                data = json.loads(line)
                if "message" in data and "content" in data["message"]:
                    content = data["message"]["content"]
                    if content:
                        accumulated += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated
                        )
                if data.get("done", False):
                    yield StreamChunk(type=StreamEventType.DONE, accumulated=accumulated)
                    break
            except json.JSONDecodeError:
                continue
        response.close()
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}", timeout=5)
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False