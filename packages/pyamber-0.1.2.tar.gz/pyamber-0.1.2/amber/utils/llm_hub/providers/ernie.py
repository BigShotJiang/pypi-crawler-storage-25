"""百度文心提供商"""

import json
import requests
import time
from typing import Dict, Any, List, Union

from ..providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from ..models.message import Conversation
from ..models.response import Response


class ErnieTokenCounter(FallbackTokenCounter):
    pass


class ErnieProvider(BaseProvider):
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.secret_key = config.get("secret_key")
        self.model = config.get("model", "ernie-3.5-8k")
        self._access_token = None
        self._token_expire = 0
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = ErnieTokenCounter()
        return self._token_counter
    
    def _get_access_token(self) -> str:
        if self._access_token and time.time() < self._token_expire:
            return self._access_token
        
        url = "https://aip.baidubce.com/oauth/2.0/token"
        params = {
            "grant_type": "client_credentials",
            "client_id": self.api_key,
            "client_secret": self.secret_key
        }
        
        response = requests.post(url, params=params, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        self._access_token = data.get("access_token")
        expires_in = data.get("expires_in", 2592000)
        self._token_expire = time.time() + expires_in - 3600
        
        return self._access_token
    
    def _get_api_url(self) -> str:
        token = self._get_access_token()
        return f"https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/{self.model}?access_token={token}"
    
    def chat(self, conversation: Conversation, **kwargs) -> Response:
        messages = conversation.get_messages()
        
        system_prompt = None
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                user_messages.append(msg)
        
        payload = {
            "messages": user_messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        response = requests.post(
            self._get_api_url(),
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        response.close()
        
        return Response(
            content=data.get("result", ""),
            model=self.model,
            usage=data.get("usage"),
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Response:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            self._get_access_token()
            return True
        except Exception:
            return False
