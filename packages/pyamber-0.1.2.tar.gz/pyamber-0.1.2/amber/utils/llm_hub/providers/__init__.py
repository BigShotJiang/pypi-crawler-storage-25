"""LLM提供商模块"""

from typing import Dict, Any, Union

from ..enums import Provider
from ..exceptions import ProviderError
from .base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from .openai_compatible import OpenAICompatibleProvider, OpenAITokenCounter
from .deepseek import DeepSeekProvider, DeepSeekTokenCounter
from .qwen import QwenProvider, QwenTokenCounter
from .glm import GLMProvider, GLMTokenCounter
from .ernie import ErnieProvider, ErnieTokenCounter
from .anthropic import AnthropicProvider, AnthropicTokenCounter
from .ollama import OllamaProvider, OllamaTokenCounter


def _get_provider_class(provider: Provider):
    mapping = {
        Provider.OPENAI: OpenAICompatibleProvider,
        Provider.DEEPSEEK: DeepSeekProvider,
        Provider.KIMI: OpenAICompatibleProvider,
        Provider.KIMI_INTL: OpenAICompatibleProvider,
        Provider.OPENROUTER: OpenAICompatibleProvider,
        Provider.ANTHROPIC: AnthropicProvider,
        Provider.GOOGLE_GEMINI: OpenAICompatibleProvider,
        Provider.QWEN: QwenProvider,
        Provider.GLM: GLMProvider,
        Provider.ERNIE: ErnieProvider,
        Provider.OLLAMA: OllamaProvider,
    }
    return mapping.get(provider)


def _get_default_url(provider: Provider) -> str:
    urls = {
        Provider.OPENAI: "https://api.openai.com/v1",
        Provider.DEEPSEEK: "https://api.deepseek.com/v1",
        Provider.KIMI: "https://api.moonshot.cn/v1",
        Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
        Provider.OPENROUTER: "https://openrouter.ai/api/v1",
        Provider.ANTHROPIC: "https://api.anthropic.com/v1",
        Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
        Provider.QWEN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        Provider.GLM: "https://open.bigmodel.cn/api/paas/v4",
        Provider.ERNIE: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop",
    }
    return urls.get(provider, "")


def create_provider(provider: Provider, config: dict) -> BaseProvider:
    provider_class = _get_provider_class(provider)
    if not provider_class:
        raise ProviderError(f"Unknown provider: {provider}")
    
    config_copy = config.copy()
    
    if provider.is_cloud() and not config_copy.get("api_url"):
        config_copy["api_url"] = _get_default_url(provider)
    
    return provider_class(config_copy)


def get_token_counter(provider: Union[Provider, str], **kwargs) -> BaseTokenCounter:
    if isinstance(provider, str):
        provider = Provider.from_string(provider)
    
    temp_config = {"provider": provider, **kwargs}
    temp_provider = create_provider(provider, temp_config)
    return temp_provider.get_token_counter()


__all__ = [
    "BaseProvider", "BaseTokenCounter", "FallbackTokenCounter",
    "OpenAICompatibleProvider", "OpenAITokenCounter",
    "DeepSeekProvider", "DeepSeekTokenCounter",
    "QwenProvider", "QwenTokenCounter",
    "GLMProvider", "GLMTokenCounter",
    "ErnieProvider", "ErnieTokenCounter",
    "AnthropicProvider", "AnthropicTokenCounter",
    "OllamaProvider", "OllamaTokenCounter",
    "create_provider", "get_token_counter",
]