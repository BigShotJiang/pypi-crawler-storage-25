"""通义千问提供商"""

import json
import requests
from typing import Dict, Any, List, Generator, Union

from ..providers.base import BaseProvider, BaseTokenCounter
from ..models.message import Conversation
from ..models.response import Response, StreamResponse, StreamChunk, StreamEventType


class QwenTokenCounter(BaseTokenCounter):
    def __init__(self):
        self._encoder = None
        self._init_encoder()
    
    def _init_encoder(self):
        try:
            import tiktoken
            self._encoder = tiktoken.get_encoding("cl100k_base")
        except ImportError:
            self._encoder = None
    
    def count(self, text: str) -> int:
        if self._encoder:
            try:
                return len(self._encoder.encode(text))
            except Exception:
                pass
        
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese + int(english * 0.75) + 2


class QwenProvider(BaseProvider):
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "qwen-turbo")
        self.api_url = config.get("api_url", "https://dashscope.aliyuncs.com/compatible-mode/v1")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = QwenTokenCounter()
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "stream": stream
        }
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return self._parse_response(data)
    
    def _stream_chat(self, response) -> Generator:
        accumulated = ""
        for line in response.iter_lines():
            if not line:
                continue
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            if line.startswith("data: "):
                line = line[6:]
            if line == "[DONE]":
                yield StreamChunk(type=StreamEventType.DONE, accumulated=accumulated)
                break
            try:
                data = json.loads(line)
                choices = data.get("choices", [])
                if choices:
                    delta = choices[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        accumulated += content
                        yield StreamChunk(type=StreamEventType.CONTENT, content=content, delta=content, accumulated=accumulated)
            except json.JSONDecodeError:
                continue
        response.close()
    
    def _parse_response(self, data: Dict) -> Response:
        choices = data.get("choices", [])
        content = choices[0].get("message", {}).get("content", "") if choices else ""
        return Response(
            content=content,
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choices[0].get("finish_reason") if choices else None,
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.api_url}/models", headers=self._get_headers(), timeout=10)
            success = response.status_code != 401
            response.close()
            return success
        except Exception:
            return False
