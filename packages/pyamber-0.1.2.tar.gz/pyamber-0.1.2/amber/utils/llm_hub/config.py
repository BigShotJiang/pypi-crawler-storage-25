"""配置管理"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Union
import json
import os
from pathlib import Path

from .enums import Provider
from .exceptions import ConfigError


@dataclass
class LLMConfig:
    """LLM配置"""
    
    provider: Provider = Provider.OPENAI
    model: str = "gpt-3.5-turbo"
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    
    temperature: float = 0.7
    max_tokens: int = 2000
    top_p: float = 0.95
    
    timeout: int = 60
    max_retries: int = 3
    
    stream: bool = False
    debug: bool = False
    
    # 速率限制
    enable_rate_limit: bool = True
    rate_limit_calls_per_minute: int = 60
    rate_limit_burst: int = 10
    
    def __post_init__(self):
        if isinstance(self.provider, str):
            self.provider = Provider.from_string(self.provider)
    
    def get_api_url(self) -> str:
        if self.api_base:
            return self.api_base
        
        urls = {
            Provider.OPENAI: "https://api.openai.com/v1",
            Provider.DEEPSEEK: "https://api.deepseek.com/v1",
            Provider.KIMI: "https://api.moonshot.cn/v1",
            Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
            Provider.OPENROUTER: "https://openrouter.ai/api/v1",
            Provider.ANTHROPIC: "https://api.anthropic.com/v1",
            Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
            Provider.QWEN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
            Provider.GLM: "https://open.bigmodel.cn/api/paas/v4",
            Provider.ERNIE: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop",
        }
        return urls.get(self.provider, "")
    
    def to_dict(self, include_sensitive: bool = False) -> Dict:
        result = {
            "provider": self.provider.value,
            "model": self.model,
            "api_base": self.api_base,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "stream": self.stream,
            "debug": self.debug,
        }
        if include_sensitive:
            result["api_key"] = self.api_key
        return result
    
    @classmethod
    def from_dict(cls, data: Dict) -> "LLMConfig":
        data = data.copy()
        if "provider" in data and isinstance(data["provider"], str):
            data["provider"] = Provider.from_string(data["provider"])
        return cls(**data)
    
    @classmethod
    def from_file(cls, path: str) -> "LLMConfig":
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return cls.from_dict(data)
    
    @classmethod
    def from_env(cls) -> "LLMConfig":
        """从环境变量加载配置"""
        config_dict = {}
        env_mappings = {
            "LLM_PROVIDER": "provider",
            "LLM_MODEL": "model",
            "LLM_API_KEY": "api_key",
            "LLM_API_BASE": "api_base",
            "LLM_TEMPERATURE": "temperature",
            "LLM_MAX_TOKENS": "max_tokens",
            "LLM_TIMEOUT": "timeout",
            "LLM_DEBUG": "debug",
            "LLM_STREAM": "stream",
        }
        
        for env_var, config_key in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                if config_key in ["temperature"]:
                    try:
                        value = float(value)
                    except ValueError:
                        pass
                elif config_key in ["max_tokens", "timeout"]:
                    try:
                        value = int(value)
                    except ValueError:
                        pass
                elif config_key in ["debug", "stream"]:
                    value = value.lower() in ["true", "1", "yes", "on"]
                config_dict[config_key] = value
        
        return cls.from_dict(config_dict) if config_dict else cls()
    
    def save(self, path: str):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(include_sensitive=False), f, ensure_ascii=False, indent=2)


def create_default_config(provider: Union[str, Provider] = "openai", **overrides) -> LLMConfig:
    config_dict = {
        "provider": provider,
        "model": "gpt-3.5-turbo" if provider == "openai" else f"{provider}-chat",
        "temperature": 0.7,
        "max_tokens": 2000,
        **overrides
    }
    return LLMConfig.from_dict(config_dict)