__version__ = "1.0.0"
__author__ = "Amber"
__license__ = "GPL-3.0"