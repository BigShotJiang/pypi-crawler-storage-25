"""
全局常量定义
"""

# 版本
VERSION = "0.1.2"

# 人格类型
PERSONALITY_TYPES = {
    "independent": "独立人格",
    "service": "服务型人格",
    "mixed": "混合人格"
}

# 情绪维度
EMOTION_DIMENSIONS = ["pleasure", "activation", "trust"]

# 默认属性
DEFAULT_STATS = {
    "int": 1.0,
    "eq": 1.0,
    "con": 1.0
}

# 默认情绪
DEFAULT_EMOTION = {
    "pleasure": 0.3,
    "activation": 0.5,
    "trust": 0.4
}

# 沉默类型
SILENCE_TYPES = {
    "angry": "生气时的沉默",
    "sad": "难过时的沉默",
    "thinking": "思考时的沉默",
    "reject": "拒绝回答的沉默",
    "tired": "疲惫时的沉默"
}

# 学习速率
LEARNING_RATES = {
    "independent": {
        "max_change_per_interaction": 0.05,
        "trust_decay_multiplier": 1.5
    },
    "service": {
        "max_change_per_interaction": 0.10,
        "trust_decay_multiplier": 1.0
    }
}

# 边界策略
BOUNDARY_STRATEGIES = ["reject", "silence", "redirect"]

# 记忆限制
MEMORY_LIMITS = {
    "max_facts": 500,
    "max_emotional_traces": 100,
    "retention_days": 90,
    "min_strength": 0.3
}

# 文件扩展名
FILE_EXTENSIONS = {
    "amber": ".amber",
    "memory": ".memory",
    "full": ".amber_full"
}

# 默认数据目录
DEFAULT_DATA_DIR = "./data"

# 默认人格目录
DEFAULT_PERSONAS_DIR = "./data/personas"
