"""
时间处理（时间戳/格式化）
"""

from datetime import datetime, timezone
from typing import Optional


def get_timestamp() -> float:
    """获取当前时间戳"""
    return datetime.now().timestamp()


def get_iso_timestamp() -> str:
    """获取ISO格式时间戳"""
    return datetime.now().isoformat()


def format_datetime(dt: datetime, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """格式化日期时间"""
    return dt.strftime(format_str)


def parse_datetime(dt_str: str, format_str: str = "%Y-%m-%d %H:%M:%S") -> datetime:
    """解析日期时间字符串"""
    return datetime.strptime(dt_str, format_str)


def parse_iso_datetime(iso_str: str) -> datetime:
    """解析ISO格式日期时间"""
    return datetime.fromisoformat(iso_str)


def days_since(date_str: str) -> int:
    """计算距离指定日期过去的天数"""
    date = parse_iso_datetime(date_str)
    delta = datetime.now() - date
    return delta.days


def hours_since(date_str: str) -> float:
    """计算距离指定日期过去的小时数"""
    date = parse_iso_datetime(date_str)
    delta = datetime.now() - date
    return delta.total_seconds() / 3600
