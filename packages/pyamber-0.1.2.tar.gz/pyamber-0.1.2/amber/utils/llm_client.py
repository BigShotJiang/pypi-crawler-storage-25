"""
LLM客户端 
"""

import os
from typing import List, Dict, Any, Optional

from .llm_hub import LLMClient as HubClient, LLMConfig, Provider
from .llm_hub.models import Conversation, Message


class LLMClient:
    """Amber LLM客户端"""
    
    _instance: Optional["LLMClient"] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init()
        return cls._instance
    
    def _init(self):
        """初始化"""
        provider = os.environ.get("AMBER_LLM_PROVIDER", "deepseek")
        api_key = os.environ.get("AMBER_LLM_API_KEY", "")
        api_base = os.environ.get("AMBER_LLM_API_BASE", "")
        model = os.environ.get("AMBER_LLM_MODEL", "deepseek-chat")
        
        provider_map = {
            "deepseek": Provider.DEEPSEEK,
            "openai": Provider.OPENAI,
            "kimi": Provider.KIMI,
            "qwen": Provider.QWEN,
            "glm": Provider.GLM,
            "ollama": Provider.OLLAMA,
        }
        
        config = LLMConfig(
            provider=provider_map.get(provider.lower(), Provider.DEEPSEEK),
            model=model,
            api_key=api_key,
            api_base=api_base or None,
            temperature=0.7,
            max_tokens=2000,
            stream=False,
        )
        
        self._client = HubClient(config)
    
    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """同步对话"""
        conv = Conversation()
        for msg in messages:
            conv.add(Message(role=msg["role"], content=msg["content"]))
        
        kwargs["stream"] = False
        if "max_tokens" not in kwargs:
            kwargs["max_tokens"] = 500
        
        response = self._client.chat(conv, **kwargs)
        return response.content
    
    def chat_stream(self, messages: List[Dict[str, str]], **kwargs):
        """流式对话"""
        conv = Conversation()
        for msg in messages:
            conv.add(Message(role=msg["role"], content=msg["content"]))
        
        kwargs["stream"] = True
        response = self._client.chat(conv, **kwargs)
        
        from .llm_hub.models.response import StreamEventType
        
        for chunk in response:
            yield chunk
    
    def is_available(self) -> bool:
        """检查是否可用"""
        if not self._client:
            return False
        try:
            self.chat([{"role": "user", "content": "OK"}], max_tokens=50)
            return True
        except Exception:
            return False


def get_client() -> LLMClient:
    """获取客户端单例"""
    return LLMClient()


def get_llm_client() -> LLMClient:
    """兼容旧名称"""
    return get_client()