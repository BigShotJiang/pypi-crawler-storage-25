"""
哈希计算（MD5/SHA256）
"""

import hashlib
from typing import Union, Any
import json


def compute_md5(data: Union[str, bytes, dict]) -> str:
    """
    计算MD5哈希
    
    Args:
        data: 要计算哈希的数据
        
    Returns:
        32位十六进制字符串
    """
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True)
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    return hashlib.md5(data).hexdigest()


def compute_sha256(data: Union[str, bytes, dict]) -> str:
    """
    计算SHA256哈希
    
    Args:
        data: 要计算哈希的数据
        
    Returns:
        64位十六进制字符串
    """
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True)
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    return hashlib.sha256(data).hexdigest()


def compute_file_md5(filepath: str) -> str:
    """计算文件的MD5"""
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def compute_file_sha256(filepath: str) -> str:
    """计算文件的SHA256"""
    hash_sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()
