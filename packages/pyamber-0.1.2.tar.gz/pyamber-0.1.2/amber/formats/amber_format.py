"""
.amber 文件读写（参数层）
"""

import yaml
import json
from typing import Dict, Any, Optional
from pathlib import Path
from datetime import datetime


class AmberFormat:
    """参数层格式处理器"""
    
    VERSION = "1.0"
    
    @classmethod
    def validate(cls, data: Dict[str, Any]) -> bool:
        """验证数据格式"""
        required = ["version", "identity", "stats", "emotion"]
        for field in required:
            if field not in data:
                return False
        return True
    
    @classmethod
    def dump(cls, data: Dict[str, Any], filepath: str) -> bool:
        """写入文件"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
            return True
        except Exception as e:
            print(f"保存失败: {e}")
            return False
    
    @classmethod
    def load(cls, filepath: str) -> Optional[Dict[str, Any]]:
        """加载文件"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"加载失败: {e}")
            return None
    
    @classmethod
    def create_default(cls, name: str) -> Dict[str, Any]:
        """创建默认参数"""
        return {
            "version": cls.VERSION,
            "created_at": datetime.now().isoformat(),
            "identity": {
                "name": name,
                "role": "未知",
                "age": 25,
                "description": f"{name} 是一个人格",
                "gender": "neutral"
            },
            "personality_type": {
                "type": "independent",
                "service_ratio": 0.0
            },
            "stats": {
                "int": 1.0,
                "eq": 1.0,
                "con": 1.0
            },
            "emotion": {
                "base": {
                    "pleasure": 0.3,
                    "activation": 0.5,
                    "trust": 0.4
                },
                "sensitivity": {
                    "pleasure": 1.0,
                    "trust": 1.0
                }
            },
            "topics": {
                "like": [],
                "dislike": [],
                "neutral": "transfer"
            },
            "speech": {
                "style": "normal",
                "catchphrases": [],
                "min_length": 10,
                "max_length": 90,
                "temperature": 0.7
            },
            "boundaries": {
                "reject_when": [],
                "silence_when": [],
                "topic_blacklist": []
            },
            "memory_schema": {
                "max_facts": 500,
                "retention_days": 30,
                "forget_rate": 0.05
            },
            "signature": {
                "creator_id": "anonymous",
                "created_at": datetime.now().isoformat(),
                "license": "CC-BY-NC-ND-4.0"
            }
        }


def load_amber(filepath: str) -> Optional[Dict[str, Any]]:
    """加载 .amber 文件"""
    return AmberFormat.load(filepath)


def save_amber(data: Dict[str, Any], filepath: str) -> bool:
    """保存 .amber 文件"""
    return AmberFormat.dump(data, filepath)


def create_default_amber(name: str) -> Dict[str, Any]:
    """创建默认参数"""
    return AmberFormat.create_default(name)
