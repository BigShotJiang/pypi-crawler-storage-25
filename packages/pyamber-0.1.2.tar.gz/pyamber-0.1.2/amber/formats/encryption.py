#!/usr/bin/env python3
"""
记忆层加密
"""

import base64
import hashlib
from typing import Optional, Tuple


class MemoryEncryption:
    """记忆加密器"""
    
    @staticmethod
    def _derive_key(password: str, salt: bytes = None) -> Tuple[bytes, bytes]:
        """从密码派生密钥"""
        if salt is None:
            salt = hashlib.sha256(password.encode()).digest()[:16]
        
        # 使用 hashlib 的 PBKDF2（不依赖cryptography的新版本）
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode(),
            salt,
            100000,
            32
        )
        
        return base64.urlsafe_b64encode(key), salt
    
    @staticmethod
    def encrypt(data: str, password: str) -> str:
        """
        加密数据
        
        Args:
            data: 要加密的数据
            password: 密码
            
        Returns:
            base64编码的加密数据
        """
        from cryptography.fernet import Fernet
        
        key, salt = MemoryEncryption._derive_key(password)
        fernet = Fernet(key)
        
        encrypted = fernet.encrypt(data.encode())
        
        # 组合 salt + encrypted
        result = base64.b64encode(salt + encrypted).decode()
        
        return result
    
    @staticmethod
    def decrypt(encrypted_data: str, password: str) -> str:
        """
        解密数据
        
        Args:
            encrypted_data: 加密的数据
            password: 密码
            
        Returns:
            解密后的数据
        """
        from cryptography.fernet import Fernet
        
        decoded = base64.b64decode(encrypted_data)
        
        salt = decoded[:16]
        encrypted = decoded[16:]
        
        key, _ = MemoryEncryption._derive_key(password, salt)
        fernet = Fernet(key)
        
        decrypted = fernet.decrypt(encrypted)
        
        return decrypted.decode()


def encrypt_memory(data: str, password: str) -> str:
    """加密记忆数据"""
    return MemoryEncryption.encrypt(data, password)


def decrypt_memory(encrypted_data: str, password: str) -> str:
    """解密记忆数据"""
    return MemoryEncryption.decrypt(encrypted_data, password)