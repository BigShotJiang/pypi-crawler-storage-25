"""
.amber_full 文件读写（完整备份）
"""

import yaml
import hashlib
from typing import Dict, Any, Optional, Tuple
from datetime import datetime


class FullFormat:
    """完整备份格式处理器"""
    
    VERSION = "1.0"
    MAGIC_HEADER = b"AMBER_FULL"
    
    @classmethod
    def dump(cls, params: Dict[str, Any], memory: Dict[str, Any], filepath: str, 
             encrypt: bool = False, password: str = None) -> bool:
        """
        保存完整备份
        
        Args:
            params: 参数层数据
            memory: 记忆层数据
            filepath: 保存路径
            encrypt: 是否加密
            password: 加密密码
        """
        full_data = {
            "version": cls.VERSION,
            "exported_at": datetime.now().isoformat(),
            "params": params,
            "memory": memory,
            "checksum": cls._calculate_checksum(params, memory)
        }
        
        data = yaml.dump(full_data, allow_unicode=True, default_flow_style=False)
        
        if encrypt and password:
            from amber.formats.encryption import encrypt_memory
            data = encrypt_memory(data, password)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(data if isinstance(data, str) else data.decode())
            return True
        except Exception as e:
            print(f"保存失败: {e}")
            return False
    
    @classmethod
    def load(cls, filepath: str, password: str = None) -> Optional[Tuple[Dict[str, Any], Dict[str, Any]]]:
        """
        加载完整备份
        
        Returns:
            (params, memory) 或 None
        """
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 尝试解密
            if password:
                from amber.formats.encryption import decrypt_memory
                content = decrypt_memory(content, password)
            
            full_data = yaml.safe_load(content)
            
            # 验证校验和
            if not cls._verify_checksum(full_data):
                print("校验和验证失败，文件可能已损坏")
                return None
            
            return full_data.get("params"), full_data.get("memory")
            
        except Exception as e:
            print(f"加载失败: {e}")
            return None
    
    @classmethod
    def _calculate_checksum(cls, params: Dict, memory: Dict) -> str:
        """计算校验和"""
        import json
        content = json.dumps(params, sort_keys=True) + json.dumps(memory, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()
    
    @classmethod
    def _verify_checksum(cls, full_data: Dict) -> bool:
        """验证校验和"""
        stored = full_data.get("checksum")
        if not stored:
            return False
        
        calculated = cls._calculate_checksum(full_data.get("params", {}), full_data.get("memory", {}))
        return stored == calculated


def save_full(params: Dict[str, Any], memory: Dict[str, Any], filepath: str,
              encrypt: bool = False, password: str = None) -> bool:
    """保存完整备份"""
    return FullFormat.dump(params, memory, filepath, encrypt, password)


def load_full(filepath: str, password: str = None) -> Optional[Tuple[Dict[str, Any], Dict[str, Any]]]:
    """加载完整备份"""
    return FullFormat.load(filepath, password)
