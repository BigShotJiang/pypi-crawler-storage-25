"""
数据schema定义和验证
"""

from typing import Dict, Any, List, Tuple

SCHEMA_VERSION = "1.0"


class SchemaValidator:
    """Schema验证器"""
    
    # 参数层schema
    AMBER_SCHEMA = {
        "version": {"type": str, "required": True},
        "identity": {"type": dict, "required": True},
        "personality_type": {"type": dict, "required": False},
        "stats": {"type": dict, "required": True},
        "emotion": {"type": dict, "required": True},
        "speech": {"type": dict, "required": True},
        "boundaries": {"type": dict, "required": False},
        "memory_schema": {"type": dict, "required": False},
        "signature": {"type": dict, "required": False},
    }
    
    # 记忆层schema
    MEMORY_SCHEMA = {
        "version": {"type": str, "required": True},
        "params_version": {"type": str, "required": True},
        "created_at": {"type": str, "required": True},
        "last_updated": {"type": str, "required": True},
        "total_interactions": {"type": int, "required": True},
        "facts": {"type": list, "required": True},
        "emotional_traces": {"type": list, "required": True},
        "current_emotion": {"type": dict, "required": True},
    }
    
    @classmethod
    def validate_amber(cls, data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """验证参数层"""
        errors = []
        
        for field, rules in cls.AMBER_SCHEMA.items():
            if rules.get("required") and field not in data:
                errors.append(f"缺少必需字段: {field}")
        
        return len(errors) == 0, errors
    
    @classmethod
    def validate_memory(cls, data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """验证记忆层"""
        errors = []
        
        for field, rules in cls.MEMORY_SCHEMA.items():
            if rules.get("required") and field not in data:
                errors.append(f"缺少必需字段: {field}")
        
        return len(errors) == 0, errors


def validate_schema(data: Dict[str, Any], schema_type: str) -> Tuple[bool, List[str]]:
    """验证schema"""
    validator = SchemaValidator()
    
    if schema_type == "amber":
        return validator.validate_amber(data)
    elif schema_type == "memory":
        return validator.validate_memory(data)
    else:
        return False, [f"未知schema类型: {schema_type}"]
