"""
.memory 文件读写（记忆层）
"""

import yaml
from typing import Dict, Any, Optional, List
from pathlib import Path
from datetime import datetime


class MemoryFormat:
    """记忆层格式处理器"""
    
    VERSION = "1.0"
    
    @classmethod
    def validate(cls, data: Dict[str, Any]) -> bool:
        """验证数据格式"""
        required = ["version", "created_at", "total_interactions", "facts"]
        for field in required:
            if field not in data:
                return False
        return True
    
    @classmethod
    def dump(cls, data: Dict[str, Any], filepath: str) -> bool:
        """写入文件"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
            return True
        except Exception as e:
            print(f"保存失败: {e}")
            return False
    
    @classmethod
    def load(cls, filepath: str) -> Optional[Dict[str, Any]]:
        """加载文件"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"加载失败: {e}")
            return None
    
    @classmethod
    def create_empty(cls, params_version: str = "1.0", personality_type: str = "independent") -> Dict[str, Any]:
        """创建空白记忆层"""
        return {
            "version": cls.VERSION,
            "params_version": params_version,
            "personality_type": personality_type,
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
            "total_interactions": 0,
            "facts": [],
            "emotional_traces": [],
            "tendency": {},
            "current_emotion": {
                "pleasure": 0.3,
                "activation": 0.5,
                "trust": 0.4,
                "last_updated": datetime.now().isoformat()
            },
            "user_profile": {
                "name": "用户",
                "interests": [],
                "demeanor": "unknown",
                "known_since": datetime.now().isoformat()
            },
            "forgetting": {
                "last_pruned": datetime.now().isoformat(),
                "pruned_count": 0,
                "auto_prune_enabled": True,
                "half_life_days": 90,
                "min_strength": 0.3
            }
        }
    
    @classmethod
    def add_fact(cls, memory: Dict[str, Any], content: str, emotion_tag: Dict[str, float] = None) -> Dict[str, Any]:
        """添加事实记忆"""
        import hashlib
        
        fact_id = hashlib.md5(f"{content}{datetime.now().isoformat()}".encode()).hexdigest()[:8]
        
        fact = {
            "id": f"fact_{fact_id}",
            "content": content,
            "strength": 0.8,
            "created_at": datetime.now().isoformat(),
            "last_accessed": datetime.now().isoformat(),
            "emotion_tag": emotion_tag or {"pleasure": 0.0, "trust": 0.0}
        }
        
        if "facts" not in memory:
            memory["facts"] = []
        
        memory["facts"].append(fact)
        memory["last_updated"] = datetime.now().isoformat()
        
        return memory
    
    @classmethod
    def add_emotional_trace(cls, memory: Dict[str, Any], event: str, pleasure: float, trust: float):
        """添加情绪痕迹"""
        trace = {
            "date": datetime.now().isoformat(),
            "event": event,
            "pleasure": pleasure,
            "trust": trust
        }
        
        if "emotional_traces" not in memory:
            memory["emotional_traces"] = []
        
        memory["emotional_traces"].append(trace)
        
        # 限制痕迹数量
        if len(memory["emotional_traces"]) > 100:
            memory["emotional_traces"] = memory["emotional_traces"][-100:]
        
        return memory


def load_memory(filepath: str) -> Optional[Dict[str, Any]]:
    """加载 .memory 文件"""
    return MemoryFormat.load(filepath)


def save_memory(data: Dict[str, Any], filepath: str) -> bool:
    """保存 .memory 文件"""
    return MemoryFormat.dump(data, filepath)


def create_empty_memory(params_version: str = "1.0", personality_type: str = "independent") -> Dict[str, Any]:
    """创建空白记忆层"""
    return MemoryFormat.create_empty(params_version, personality_type)


def add_fact_to_memory(memory: Dict[str, Any], content: str, emotion_tag: Dict[str, float] = None) -> Dict[str, Any]:
    """向记忆添加事实"""
    return MemoryFormat.add_fact(memory, content, emotion_tag)


def add_emotional_trace(memory: Dict[str, Any], event: str, pleasure: float, trust: float) -> Dict[str, Any]:
    """添加情绪痕迹"""
    return MemoryFormat.add_emotional_trace(memory, event, pleasure, trust)
