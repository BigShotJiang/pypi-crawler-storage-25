"""
人格文件版本迁移
"""

from typing import Dict, Any, Optional, Callable
from datetime import datetime


class MigrationManager:
    """迁移管理器"""
    
    def __init__(self):
        self.migrations: Dict[str, Dict[str, Callable]] = {}
        self._register_migrations()
    
    def _register_migrations(self):
        """注册迁移函数"""
        # 1.0 -> 1.1 迁移
        self.migrations["1.0"] = {
            "1.1": self._migrate_1_0_to_1_1
        }
        
        # 1.1 -> 1.2 迁移
        self.migrations["1.1"] = {
            "1.2": self._migrate_1_1_to_1_2
        }
    
    def _migrate_1_0_to_1_1(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """从1.0迁移到1.1"""
        # 添加新字段
        if "evolution" not in data:
            data["evolution"] = {
                "baseline_drift_rate": 0.001,
                "trait_change_rate": 0.0001,
                "adaptation_enabled": True
            }
        
        # 添加贡献者列表
        if "contributors" not in data:
            data["contributors"] = []
        
        data["version"] = "1.1"
        data["migrated_at"] = datetime.now().isoformat()
        
        return data
    
    def _migrate_1_1_to_1_2(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """从1.1迁移到1.2"""
        # 添加水印
        if "watermark" not in data:
            data["watermark"] = {
                "visible": "",
                "invisible": "",
                "steganographic": ""
            }
        
        data["version"] = "1.2"
        data["migrated_at"] = datetime.now().isoformat()
        
        return data
    
    def migrate(self, data: Dict[str, Any], target_version: str) -> Dict[str, Any]:
        """执行迁移"""
        current_version = data.get("version", "1.0")
        
        if current_version == target_version:
            return data
        
        # 逐步迁移
        version_chain = self._get_version_chain(current_version, target_version)
        
        for from_ver, to_ver in version_chain:
            if from_ver in self.migrations and to_ver in self.migrations[from_ver]:
                data = self.migrations[from_ver][to_ver](data)
                print(f"迁移: {from_ver} -> {to_ver}")
        
        return data
    
    def _get_version_chain(self, from_ver: str, to_ver: str) -> list:
        """获取版本链"""
        versions = ["1.0", "1.1", "1.2", "1.3", "1.4", "1.5"]
        
        try:
            from_idx = versions.index(from_ver)
            to_idx = versions.index(to_ver)
        except ValueError:
            return []
        
        if from_idx >= to_idx:
            return []
        
        return [(versions[i], versions[i+1]) for i in range(from_idx, to_idx)]


def migrate(data: Dict[str, Any], target_version: str) -> Dict[str, Any]:
    """迁移数据到目标版本"""
    manager = MigrationManager()
    return manager.migrate(data, target_version)
