"""
CLI package for Amber
"""

from amber.cli.main import cli

__all__ = ["cli"]
