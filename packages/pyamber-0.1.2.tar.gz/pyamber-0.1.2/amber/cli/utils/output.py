"""
CLI输出格式化
"""

import click


def print_table(headers, rows):
    """打印表格"""
    # 计算列宽
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))
    
    # 打印表头
    header_line = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    click.echo(header_line)
    click.echo("-" * len(header_line))
    
    # 打印数据行
    for row in rows:
        line = " | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row))
        click.echo(line)


def print_success(message):
    """打印成功消息"""
    click.echo(f"✅ {message}")


def print_error(message):
    """打印错误消息"""
    click.echo(f"❌ {message}")


def print_warning(message):
    """打印警告消息"""
    click.echo(f"⚠️ {message}")


def print_info(message):
    """打印信息"""
    click.echo(f"ℹ️ {message}")
