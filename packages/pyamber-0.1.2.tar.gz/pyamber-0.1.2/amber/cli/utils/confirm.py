"""
用户确认交互
"""

import click


def confirm_action(message, default=False):
    """
    确认用户操作
    
    Args:
        message: 确认消息
        default: 默认值
        
    Returns:
        bool: 用户是否确认
    """
    return click.confirm(message, default=default)


def confirm_delete(name):
    """确认删除"""
    return confirm_action(f"确认删除 '{name}'？", default=False)


def confirm_overwrite(name):
    """确认覆盖"""
    return confirm_action(f"'{name}' 已存在，是否覆盖？", default=False)
