"""
输入验证器
"""

import re


def validate_name(name):
    """
    验证人格名称
    
    Args:
        name: 名称字符串
        
    Returns:
        bool: 是否有效
    """
    if not name or len(name) > 50:
        return False
    # 只允许字母、数字、中文、下划线
    pattern = r'^[\w一-鿿]+$'
    return bool(re.match(pattern, name))


def validate_version(version):
    """
    验证版本号格式 (x.y.z)
    
    Args:
        version: 版本字符串
        
    Returns:
        bool: 是否有效
    """
    pattern = r'^\d+\.\d+\.\d+$'
    return bool(re.match(pattern, version))


def validate_service_ratio(ratio):
    """
    验证服务比例 (0-1)
    
    Args:
        ratio: 比例值
        
    Returns:
        bool: 是否有效
    """
    try:
        r = float(ratio)
        return 0 <= r <= 1
    except:
        return False
