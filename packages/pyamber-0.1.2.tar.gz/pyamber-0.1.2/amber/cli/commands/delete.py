"""
amber delete 命令实现
"""

import click
import shutil
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--keep-memory", is_flag=True, help="只删除参数层，保留记忆")
def delete(name, keep_memory):
    """删除人格"""
    data_dir = Path(f"./data/personas/{name}")
    
    if not data_dir.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    if keep_memory:
        # 只删除 .amber 文件
        amber_file = data_dir / f"{name}.amber"
        if amber_file.exists():
            amber_file.unlink()
            click.echo(f"✅ 已删除参数层，记忆层保留")
    else:
        # 删除整个目录
        if click.confirm(f"确认删除人格 '{name}' 及其所有记忆？"):
            shutil.rmtree(data_dir)
            click.echo(f"✅ 人格 '{name}' 已删除")
