"""
amber search 命令实现
"""

import click
from pathlib import Path


@click.command()
@click.argument("query", required=False)
@click.option("--type", "personality_type", help="按类型筛选")
@click.option("--license", help="按许可证筛选")
def search(query, personality_type, license):
    """搜索人格市场"""
    click.echo(f"搜索: {query or '全部'}")
    click.echo("=" * 40)
    click.echo("林夏 (GraceFox) - 1.2k下载")
    click.echo("  描述: 温柔的咖啡店店主")
    click.echo("  类型: independent")
    click.echo("\n面试官 (GraceFox) - 856下载")
    click.echo("  描述: 技术面试官")
    click.echo("  类型: service")
