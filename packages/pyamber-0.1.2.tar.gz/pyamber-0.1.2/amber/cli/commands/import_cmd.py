"""
amber import 命令实现
"""

import click
import yaml
from pathlib import Path
from datetime import datetime


@click.command()
@click.argument("source")
@click.option("--inherit-mood", is_flag=True, help="继承情绪基调")
def import_persona(source, inherit_mood):
    """导入人格"""
    source_path = Path(source)
    
    if not source_path.exists():
        click.echo(f"❌ 文件 '{source}' 不存在")
        return
    
    with open(source_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    # 判断是完整备份还是单文件
    if 'params' in data and 'memory' in data:
        params = data['params']
        memory = data['memory'] if inherit_mood else None
        name = params.get('identity', {}).get('name', 'imported')
    else:
        params = data
        memory = None
        name = params.get('identity', {}).get('name', source_path.stem)
    
    # 创建目录
    target_dir = Path(f"./data/personas/{name}")
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # 保存参数层
    with open(target_dir / f"{name}.amber", 'w', encoding='utf-8') as f:
        yaml.dump(params, f, allow_unicode=True, default_flow_style=False)
    
    # 保存或创建记忆层
    if memory:
        with open(target_dir / f"{name}.memory", 'w', encoding='utf-8') as f:
            yaml.dump(memory, f, allow_unicode=True, default_flow_style=False)
    else:
        # 创建空白记忆
        memory_data = {
            'version': '1.0',
            'params_version': params.get('version', '1.0'),
            'created_at': datetime.now().isoformat(),
            'total_interactions': 0,
            'facts': [],
            'current_emotion': {'pleasure': 0.3, 'activation': 0.5, 'trust': 0.4}
        }
        with open(target_dir / f"{name}.memory", 'w', encoding='utf-8') as f:
            yaml.dump(memory_data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 导入成功: {name}")
    click.echo(f"   运行: amber run {name}")
