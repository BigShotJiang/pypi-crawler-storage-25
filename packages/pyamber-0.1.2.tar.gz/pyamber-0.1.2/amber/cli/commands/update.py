"""
amber update 命令实现
"""

import click
import yaml
from pathlib import Path
from datetime import datetime


@click.command()
@click.argument("name")
@click.option("--to-version", required=True, help="目标版本")
@click.option("--reset-memory", is_flag=True, help="重置记忆")
@click.option("--dry-run", is_flag=True, help="预览变更")
def update(name, to_version, reset_memory, dry_run):
    """升级人格"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    old_version = data.get('version', '1.0')
    
    if dry_run:
        click.echo(f"预览升级: {old_version} → {to_version}")
        click.echo("  变更内容:")
        click.echo("    - 版本号更新")
        if reset_memory:
            click.echo("    - 重置记忆层")
        return
    
    # 更新版本
    data['version'] = to_version
    data['updated_at'] = datetime.now().isoformat()
    
    # 保存参数层
    with open(amber_file, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    # 处理记忆层
    if reset_memory:
        memory_file = data_dir / f"{name}.memory"
        if memory_file.exists():
            memory_file.unlink()
            click.echo("记忆层已重置")
    
    click.echo(f"✅ 升级到版本 {to_version}")
