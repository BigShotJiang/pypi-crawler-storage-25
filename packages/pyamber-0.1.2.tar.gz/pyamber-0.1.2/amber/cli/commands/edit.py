"""
amber edit 命令实现 - 支持自然语言微调
"""

import click
import yaml
from pathlib import Path
from amber.utils.llm_client import get_client


@click.command()
@click.argument("name")
@click.option("--set", "set_param", help="设置参数，格式: key=value")
@click.option("--describe", help="自然语言描述修改")
def edit(name, set_param, describe):
    """
    编辑人格参数
    
    示例:
        amber edit 林夏 --set speech.style=cheerful
        amber edit 林夏 --describe "让她更活泼一点"
    """
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    modified = False
    
    if set_param:
        parts = set_param.split('=')
        if len(parts) == 2:
            key, value = parts
            keys = key.split('.')
            target = data
            for k in keys[:-1]:
                if k not in target:
                    target[k] = {}
                target = target[k]
            
            try:
                if '.' in value:
                    value = float(value)
                elif value.isdigit():
                    value = int(value)
                elif value.lower() == 'true':
                    value = True
                elif value.lower() == 'false':
                    value = False
            except:
                pass
            
            target[keys[-1]] = value
            click.echo(f"✅ 已设置 {key} = {value}")
            modified = True
    
    if describe:
        click.echo(f"🤖 自然语言微调: {describe}")
        
        llm = get_client()
        if llm.is_available():
            try:
                current = {
                    "stats": data.get("stats", {}),
                    "speech": data.get("speech", {}),
                    "emotion": data.get("emotion", {}).get("base", {})
                }
                
                prompt = f"""根据用户要求修改人格参数。

当前参数: {current}
用户要求: {describe}

返回修改后的参数JSON，只返回需要修改的字段。"""

                response = llm.chat([
                    {"role": "system", "content": "你是人格参数调整专家。只返回JSON。"},
                    {"role": "user", "content": prompt}
                ], temperature=0.5, max_tokens=500)
                
                import json, re
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    adjustments = json.loads(json_match.group())
                    for key, value in adjustments.items():
                        if isinstance(value, dict) and key in data:
                            data[key].update(value)
                        else:
                            data[key] = value
                        click.echo(f"   ✓ 已调整: {key}")
                    modified = True
                else:
                    click.echo("   ⚠️ 无法解析AI响应")
            except Exception as e:
                click.echo(f"   ❌ AI微调失败: {e}")
        else:
            click.echo("   ⚠️ LLM不可用，请设置环境变量")
    
    if modified:
        version = data.get("version", "1.0")
        parts = version.split('.')
        parts[-1] = str(int(parts[-1]) + 1)
        data["version"] = '.'.join(parts)
        data["updated_at"] = __import__('datetime').datetime.now().isoformat()
        
        with open(amber_file, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
        
        click.echo(f"\n✅ 人格 '{name}' 已更新")
    else:
        click.echo("未进行任何修改")