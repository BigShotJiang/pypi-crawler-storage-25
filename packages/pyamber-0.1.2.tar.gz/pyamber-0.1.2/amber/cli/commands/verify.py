"""
amber verify 命令实现
"""

import click
import yaml
from pathlib import Path


@click.command()
@click.argument("file")
def verify(file):
    """验证人格签名"""
    file_path = Path(file)
    
    if not file_path.exists():
        click.echo(f"❌ 文件 '{file}' 不存在")
        return
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    signature = data.get('signature', {})
    
    click.echo("签名验证结果:")
    click.echo("=" * 40)
    click.echo(f"创作者: {signature.get('creator_id', '未签名')}")
    click.echo(f"创建时间: {signature.get('created_at', '未知')}")
    click.echo(f"许可证: {signature.get('license', '未指定')}")
    
    if signature.get('signature'):
        click.echo("签名状态: ✅ 有效")
    else:
        click.echo("签名状态: ⚠️ 未签名")
    
    # 检查Fork信息
    fork_info = data.get('fork_info')
    if fork_info:
        click.echo(f"\nFork信息:")
        click.echo(f"  父人格: {fork_info.get('parent')}")
        click.echo(f"  Fork时间: {fork_info.get('fork_point')}")
