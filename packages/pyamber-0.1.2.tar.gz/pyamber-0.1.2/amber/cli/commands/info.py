"""
amber info 命令实现
"""

import click
import os
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--show-memory", is_flag=True, help="显示记忆层信息")
@click.option("--show-type", is_flag=True, help="显示类型详情")
@click.option("--show-progress", is_flag=True, help="显示进步报告")
@click.option("--show-license", is_flag=True, help="显示许可证")
def info(name, show_memory, show_type, show_progress, show_license):
    """显示人格详细信息"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    click.echo(f"人格: {name}")
    click.echo("=" * 40)
    
    # 基础信息
    identity = data.get("identity", {})
    click.echo(f"角色: {identity.get('role', '未知')}")
    click.echo(f"年龄: {identity.get('age', '未知')}")
    click.echo(f"描述: {identity.get('description', '无')}")
    
    if show_type:
        ptype = data.get("personality_type", {})
        click.echo(f"人格类型: {ptype.get('type', 'unknown')}")
        if ptype.get('type') == 'mixed':
            click.echo(f"服务比例: {ptype.get('service_ratio', 0.5)}")
    
    # 属性
    stats = data.get("stats", {})
    click.echo(f"智商: {stats.get('int', 1.0)}")
    click.echo(f"情商: {stats.get('eq', 1.0)}")
    click.echo(f"体质: {stats.get('con', 1.0)}")
    
    if show_license:
        signature = data.get("signature", {})
        click.echo(f"许可证: {signature.get('license', '未知')}")
        click.echo(f"创作者: {signature.get('creator_id', '未知')}")
    
    if show_memory:
        memory_file = data_dir / f"{name}.memory"
        if memory_file.exists():
            click.echo("\n记忆层信息:")
            with open(memory_file, 'r', encoding='utf-8') as f:
                memory = yaml.safe_load(f)
            click.echo(f"  交互次数: {memory.get('total_interactions', 0)}")
            click.echo(f"  事实记忆: {len(memory.get('facts', []))}条")
            click.echo(f"  最后更新: {memory.get('last_updated', '未知')}")
    
    if show_progress:
        memory_file = data_dir / f"{name}.memory"
        if memory_file.exists():
            with open(memory_file, 'r', encoding='utf-8') as f:
                memory = yaml.safe_load(f)
            progress = memory.get('progress_report', {})
            if progress:
                click.echo("\n进步报告:")
                click.echo(f"  会话次数: {progress.get('sessions', 0)}")
                for dim, value in progress.get('dimensions', {}).items():
                    click.echo(f"  {dim}: {value.get('start', 0)} → {value.get('current', 0)}")
