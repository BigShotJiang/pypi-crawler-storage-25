"""
amber release 命令实现
"""

import click
import yaml
from pathlib import Path
from datetime import datetime


@click.command()
@click.argument("name")
@click.option("--version", required=True, help="版本号")
@click.option("--message", help="发布说明")
def release(name, version, message):
    """发布新版本"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    old_version = data.get('version', '1.0')
    data['version'] = version
    data['released_at'] = datetime.now().isoformat()
    
    # 记录版本历史
    if 'version_history' not in data:
        data['version_history'] = []
    data['version_history'].append({
        'version': version,
        'from_version': old_version,
        'released_at': datetime.now().isoformat(),
        'message': message or ''
    })
    
    with open(amber_file, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 发布版本 {version}")
