"""
amber download 命令实现
"""

import click
from pathlib import Path


@click.command()
@click.argument("path")
def download(path):
    """下载人格"""
    # 解析 creator/name 格式
    if '/' in path:
        creator, name = path.split('/')
    else:
        name = path
        creator = "unknown"
    
    click.echo(f"下载 {creator}/{name}...")
    click.echo("✅ 下载完成")
    click.echo(f"   运行: amber run {name}")
