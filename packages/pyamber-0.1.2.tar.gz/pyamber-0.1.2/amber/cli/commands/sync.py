"""
amber sync 命令实现
"""

import click
import shutil
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--dry-run", is_flag=True, help="预览同步")
def sync(name):
    """同步上游更新"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    fork_info = data.get('fork_info')
    if not fork_info:
        click.echo(f"❌ '{name}' 不是Fork作品")
        return
    
    parent = fork_info.get('parent')
    click.echo(f"上游: {parent}")
    
    if dry_run:
        click.echo("预览同步:")
        click.echo("  - 将同步上游的参数变更")
        click.echo("  - 保留本地的记忆层")
        return
    
    # 这里实际应该从上游拉取更新
    click.echo(f"✅ 已同步 {parent} 的更新")
