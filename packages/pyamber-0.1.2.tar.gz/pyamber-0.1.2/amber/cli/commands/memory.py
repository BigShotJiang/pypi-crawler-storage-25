"""
amber memory 命令组实现
"""

import click
import yaml
from pathlib import Path


@click.group()
def memory():
    """记忆管理"""
    pass


@memory.command()
@click.argument("name")
@click.option("--details", is_flag=True, help="显示详细信息")
@click.option("--progress", is_flag=True, help="显示进步报告")
def show(name, details, progress):
    """显示记忆统计"""
    memory_file = Path(f"./data/personas/{name}/{name}.memory")
    
    if not memory_file.exists():
        click.echo(f"❌ 人格 '{name}' 无记忆层")
        return
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        memory = yaml.safe_load(f)
    
    click.echo(f"记忆统计 - {name}")
    click.echo("=" * 40)
    click.echo(f"交互次数: {memory.get('total_interactions', 0)}")
    click.echo(f"事实记忆: {len(memory.get('facts', []))}条")
    click.echo(f"情绪痕迹: {len(memory.get('emotional_traces', []))}条")
    
    current = memory.get('current_emotion', {})
    click.echo(f"当前情绪: 愉悦={current.get('pleasure', 0):.2f}, "
               f"激活={current.get('activation', 0):.2f}, "
               f"信任={current.get('trust', 0):.2f}")
    
    if progress:
        pr = memory.get('progress_report', {})
        if pr:
            click.echo("\n进步报告:")
            for dim, value in pr.get('dimensions', {}).items():
                start = value.get('start', 0)
                curr = value.get('current', 0)
                change = curr - start
                arrow = "↑" if change > 0 else "↓" if change < 0 else "→"
                click.echo(f"  {dim}: {start} {arrow} {curr} ({change:+.0f})")


@memory.command()
@click.argument("name")
@click.option("--keep-trust", is_flag=True, help="保留信任度")
def clear(name, keep_trust):
    """清空记忆"""
    from datetime import datetime
    
    memory_file = Path(f"./data/personas/{name}/{name}.memory")
    
    if not memory_file.exists():
        click.echo(f"❌ 人格 '{name}' 无记忆层")
        return
    
    if not click.confirm(f"确认清空 {name} 的所有记忆吗？"):
        return
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        memory = yaml.safe_load(f)
    
    trust = memory.get('current_emotion', {}).get('trust', 0.4) if keep_trust else 0.4
    
    # 重置记忆
    memory['facts'] = []
    memory['emotional_traces'] = []
    memory['total_interactions'] = 0
    memory['last_updated'] = datetime.now().isoformat()
    memory['current_emotion'] = {'pleasure': 0.3, 'activation': 0.5, 'trust': trust}
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        yaml.dump(memory, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 记忆已清空")


@memory.command()
@click.argument("name")
@click.option("--format", "output_format", type=click.Choice(["json", "yaml"]), default="json")
@click.option("--encrypt", is_flag=True, help="加密导出")
def export(name, output_format, encrypt):
    """导出记忆"""
    memory_file = Path(f"./data/personas/{name}/{name}.memory")
    
    if not memory_file.exists():
        click.echo(f"❌ 人格 '{name}' 无记忆层")
        return
    
    with open(memory_file, 'r', encoding='utf-8') as f:
        memory = yaml.safe_load(f)
    
    if output_format == "json":
        import json
        output = json.dumps(memory, ensure_ascii=False, indent=2)
    else:
        output = yaml.dump(memory, allow_unicode=True)
    
    # 保存文件
    output_file = f"{name}_memory_export.{output_format}"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(output)
    
    click.echo(f"✅ 导出到 {output_file}")
