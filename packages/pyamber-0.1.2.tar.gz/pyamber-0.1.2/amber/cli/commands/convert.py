"""
amber convert 命令实现
"""

import click
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--to-type", type=click.Choice(["independent", "service", "mixed"]), required=True)
@click.option("--service-ratio", type=float, default=0.5)
@click.option("--dry-run", is_flag=True, help="预览变更")
def convert(name, to_type, service_ratio, dry_run):
    """转换人格类型"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    old_type = data.get('personality_type', {}).get('type', 'independent')
    
    if dry_run:
        click.echo(f"预览转换: {old_type} → {to_type}")
        click.echo("  将修改:")
        click.echo("    - personality_type.type")
        if to_type == 'mixed':
            click.echo(f"    - personality_type.service_ratio = {service_ratio}")
        return
    
    if not click.confirm(f"确认将 '{name}' 从 {old_type} 转换为 {to_type}？"):
        return
    
    # 修改类型
    if 'personality_type' not in data:
        data['personality_type'] = {}
    data['personality_type']['type'] = to_type
    if to_type == 'mixed':
        data['personality_type']['service_ratio'] = service_ratio
    
    # 保存
    with open(amber_file, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 已转换为 {to_type} 类型")
