"""
amber export 命令实现
"""

import click
import shutil
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--public-only", is_flag=True, help="只导出参数层")
@click.option("--memory-only", is_flag=True, help="只导出记忆层")
@click.option("--full", is_flag=True, help="完整导出")
@click.option("--save-as", required=True, help="保存路径")
def export(name, public_only, memory_only, full, save_as):
    """导出人格"""
    data_dir = Path(f"./data/personas/{name}")
    
    if not data_dir.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    if public_only:
        src = data_dir / f"{name}.amber"
        dst = Path(save_as)
        shutil.copy(src, dst)
        click.echo(f"✅ 导出参数层到 {save_as}")
    elif memory_only:
        src = data_dir / f"{name}.memory"
        dst = Path(save_as)
        shutil.copy(src, dst)
        click.echo(f"✅ 导出记忆层到 {save_as}")
    elif full:
        # 创建完整备份
        import yaml
        with open(data_dir / f"{name}.amber", 'r', encoding='utf-8') as f:
            params = yaml.safe_load(f)
        with open(data_dir / f"{name}.memory", 'r', encoding='utf-8') as f:
            memory = yaml.safe_load(f)
        
        full_data = {
            'version': '1.0',
            'params': params,
            'memory': memory,
            'exported_at': __import__('datetime').datetime.now().isoformat()
        }
        
        with open(save_as, 'w', encoding='utf-8') as f:
            yaml.dump(full_data, f, allow_unicode=True)
        
        click.echo(f"✅ 完整导出到 {save_as}")
