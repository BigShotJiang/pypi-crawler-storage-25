"""
amber pr 命令组实现
"""

import click


@click.group()
def pr():
    """Pull Request 管理"""
    pass


@pr.command()
@click.argument("source")
@click.option("--target", required=True, help="目标人格")
@click.option("--message", help="PR描述")
def create(source, target, message):
    """创建改进请求"""
    click.echo(f"创建 PR: {source} → {target}")
    click.echo(f"描述: {message or '无'}")
    click.echo("✅ PR已提交")


@pr.command()
def list():
    """列出PR"""
    click.echo("PR列表:")
    click.echo("  #42: 林夏_改进版 → 林夏 (待审核)")
    click.echo("  #41: 面试官_v2 → 面试官 (已合并)")


@pr.command()
@click.argument("pr_id")
def show(pr_id):
    """显示PR详情"""
    click.echo(f"PR #{pr_id} 详情:")
    click.echo("  来源: 林夏_改进版")
    click.echo("  目标: 林夏")
    click.echo("  状态: 待审核")
    click.echo("  变更: 增加口头禅")


@pr.command()
@click.argument("pr_id")
@click.option("--message", help="合并信息")
def merge(pr_id, message):
    """合并PR"""
    click.echo(f"合并 PR #{pr_id}")
    click.echo(f"信息: {message or '无'}")
    click.echo("✅ 已合并")


@pr.command()
@click.argument("pr_id")
@click.option("--reason", help="拒绝原因")
def reject(pr_id, reason):
    """拒绝PR"""
    click.echo(f"拒绝 PR #{pr_id}")
    click.echo(f"原因: {reason or '无'}")


@pr.command()
@click.argument("pr_id")
@click.option("--message", required=True)
def comment(pr_id, message):
    """评论PR"""
    click.echo(f"评论 PR #{pr_id}: {message}")
