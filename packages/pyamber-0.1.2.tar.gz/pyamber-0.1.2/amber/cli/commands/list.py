"""
amber list 命令实现
"""

import click
import os
from pathlib import Path


@click.command()
@click.option("--show-type", is_flag=True, help="显示类型")
@click.option("--show-license", is_flag=True, help="显示许可证")
def list_personas(show_type, show_license):
    """列出所有人格"""
    data_dir = Path("./data/personas")
    
    if not data_dir.exists():
        click.echo("暂无任何人格")
        return
    
    personas = []
    for persona_dir in data_dir.iterdir():
        if persona_dir.is_dir():
            amber_file = persona_dir / f"{persona_dir.name}.amber"
            if amber_file.exists():
                personas.append(persona_dir.name)
    
    if not personas:
        click.echo("暂无任何人格")
        return
    
    click.echo(f"找到 {len(personas)} 个人格:")
    click.echo("-" * 30)
    
    for name in personas:
        if show_type or show_license:
            # 读取元数据
            import yaml
            amber_file = data_dir / name / f"{name}.amber"
            with open(amber_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            type_str = data.get("personality_type", {}).get("type", "unknown")
            license_str = data.get("signature", {}).get("license", "unknown")
            
            parts = [name]
            if show_type:
                parts.append(f"[{type_str}]")
            if show_license:
                parts.append(f"({license_str})")
            click.echo(" ".join(parts))
        else:
            click.echo(f"  {name}")
