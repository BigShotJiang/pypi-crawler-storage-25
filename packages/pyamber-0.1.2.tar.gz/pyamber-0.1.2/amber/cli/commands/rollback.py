"""
amber rollback 命令实现
"""

import click
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--to-version", required=True, help="目标版本")
def rollback(name, to_version):
    """回滚到指定版本"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    # 查找版本历史
    history = data.get('version_history', [])
    target = None
    for h in history:
        if h['version'] == to_version:
            target = h
            break
    
    if not target:
        click.echo(f"❌ 版本 {to_version} 不存在")
        return
    
    old_version = data.get('version')
    data['version'] = to_version
    
    with open(amber_file, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 回滚 {old_version} → {to_version}")
