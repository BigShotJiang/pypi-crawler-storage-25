"""
amber templates 命令实现
"""

import click


@click.group()
def templates():
    """模板管理"""
    pass


@templates.command()
def list():
    """列出所有模板"""
    click.echo("可用模板:")
    click.echo("  interviewer      - 技术面试官")
    click.echo("  english_teacher  - 英语老师")
    click.echo("  career_coach     - 职业导师")
    click.echo("  therapist        - 倾听者")
    click.echo("  tutor            - 学科辅导")
    click.echo("  customer_service - 客服")


@templates.command()
@click.argument("name")
def show(name):
    """显示模板详情"""
    templates_data = {
        "interviewer": {
            "name": "技术面试官",
            "type": "service",
            "description": "专业的软件技术面试官，会追问细节"
        },
        "english_teacher": {
            "name": "英语老师",
            "type": "service", 
            "description": "耐心的英语陪练，纠正语法错误"
        }
    }
    
    if name in templates_data:
        data = templates_data[name]
        click.echo(f"模板: {name}")
        click.echo(f"名称: {data['name']}")
        click.echo(f"类型: {data['type']}")
        click.echo(f"描述: {data['description']}")
    else:
        click.echo(f"❌ 模板 '{name}' 不存在")
