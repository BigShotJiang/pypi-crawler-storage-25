"""
amber run 命令实现 - 运行人格对话
"""

import click
from amber.core.persona import Persona
from amber.utils.llm_client import get_client


@click.command()
@click.argument("name")
@click.option("--once", help="单次交互")
@click.option("--memory", help="指定记忆层文件")
@click.option("--memory-new", is_flag=True, help="创建空白记忆层")
@click.option("--forget-everything", is_flag=True, help="重置所有记忆")
@click.option("--mode", type=click.Choice(["normal", "interview", "practice"]), 
              default="normal", help="运行模式")
@click.option("--debug", is_flag=True, help="调试模式")
@click.option("--llm", is_flag=True, help="使用LLM生成回复")
def run(name, once, memory, memory_new, forget_everything, mode, debug, llm):
    """
    运行人格对话

    示例:
        amber run 林夏
        amber run 面试官 --mode interview
        amber run 林夏 --llm
    """
    try:
        # 加载人格
        persona = Persona.load(name)
        
        # 检查LLM
        llm_client = None
        if llm:
            llm_client = get_client()
            if not llm_client.is_available():
                click.echo("⚠️ LLM不可用，使用内置模式")
                llm_client = None
            else:
                click.echo("🤖 LLM增强模式已启用")
        
        # 处理记忆重置
        if forget_everything:
            if click.confirm(f"确认清空 '{name}' 的所有记忆吗？"):
                click.echo("记忆已清空")
        
        # 对话标题
        click.echo(f"\n正在与 {name} 对话... (输入 'exit' 退出, 'save' 保存, 'llm' 切换模式)")
        click.echo("-" * 50)
        
        use_llm = llm_client is not None
        
        while True:
            try:
                user_input = input("\n你: ").strip()
                
                if user_input.lower() == "exit":
                    break
                elif user_input.lower() == "save":
                    persona.save()
                    click.echo("✅ 已保存")
                    continue
                elif user_input.lower() == "llm":
                    if llm_client:
                        use_llm = not use_llm
                        click.echo(f"🤖 LLM模式: {'开启' if use_llm else '关闭'}")
                    else:
                        click.echo("⚠️ LLM不可用，无法切换")
                    continue
                elif not user_input:
                    continue
                
                if use_llm and llm_client:
                    # LLM增强模式
                    emotion = persona.get_emotion()
                    memories = persona.memory_manager.retrieve(user_input)
                    
                    # 构建提示
                    memory_context = ""
                    if memories:
                        memory_context = "\n相关记忆:\n" + "\n".join([f"- {m.get('content', '')[:50]}" for m in memories[:3]])
                    
                    prompt = f"""你是{name}，根据当前状态回复用户。

情绪: 愉悦={emotion.get('pleasure',0):.2f} 信任={emotion.get('trust',0.5):.2f}
{memory_context}
用户: {user_input}

回复要自然、简短，符合角色性格。"""

                    response = llm_client.chat([
                        {"role": "system", "content": f"你是{name}。回复简短自然。"},
                        {"role": "user", "content": prompt}
                    ], temperature=0.8, max_tokens=200)
                    
                    # 记录交互
                    persona.memory_manager.add_interaction(user_input, response, emotion)
                    persona.interaction_count += 1
                    click.echo(f"{name}: {response}")
                else:
                    # 内置引擎模式
                    response = persona.interact(user_input)
                    
                    if response.should_speak:
                        click.echo(f"{name}: {response.text}")
                    else:
                        import time
                        time.sleep(response.get_silence_seconds())
                        click.echo(f"{name}: ...")
                
                if debug:
                    emotion = persona.get_emotion()
                    click.echo(f"[DEBUG] 情绪: 愉悦={emotion['pleasure']:.2f}, 信任={emotion['trust']:.2f}")
                    
            except KeyboardInterrupt:
                click.echo("\n对话结束")
                break
        
        # 保存
        persona.save()
        click.echo(f"\n✅ 人格 '{name}' 已保存")
        
    except Exception as e:
        click.echo(f"❌ 错误: {e}")
        if debug:
            import traceback
            traceback.print_exc()