"""
amber lineage 命令实现
"""

import click
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
def lineage(name):
    """查看创作链"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    click.echo("人格创作链:")
    click.echo("=" * 40)
    
    # 显示当前人格
    creator = data.get('signature', {}).get('creator_id', '未知')
    click.echo(f"{name} ({creator})")
    
    # 显示父人格
    fork_info = data.get('fork_info')
    if fork_info:
        parent = fork_info.get('parent')
        click.echo(f"    ↑ Fork from")
        click.echo(f"{parent}")
    
    # 显示贡献者
    contributors = data.get('contributors', [])
    if contributors:
        click.echo("\n贡献者:")
        for c in contributors:
            click.echo(f"  - {c.get('id')}: {c.get('contribution')}")
