"""
amber create 命令实现 - 支持四种模式 + 指定名称
"""

import click
from pathlib import Path

from amber.create.smart_create import smart_create
from amber.create.quick_create import quick_create
from amber.create.expert_create import expert_create
from amber.create.dynamic_questionnaire import create_with_dynamic_questionnaire


@click.command()
@click.argument("description", required=False)
@click.option("--name", help="指定人格名称（可选，不指定则自动生成）")
@click.option("--type", "personality_type", type=click.Choice(["independent", "service", "mixed"]), 
              default="independent", help="人格类型")
@click.option("--service-ratio", type=float, default=0.5, help="服务比例 (0-1, 仅mixed类型)")
@click.option("--quick", is_flag=True, help="快速模式：纯AI脑补，不显示问卷")
@click.option("--dynamic", is_flag=True, help="动态问卷模式：智能跳题，第三人称视角（推荐）")
@click.option("--expert", is_flag=True, help="专家模式：显示完整25题基础问卷（旧版）")
@click.option("--interactive", is_flag=True, help="智能模式：基础问卷+AI问题+自定义补充（旧版）")
@click.option("--template", help="使用模板创建")
@click.option("--license", default="CC-BY-NC-ND-4.0", help="许可证")
@click.option("--save-as", help="保存文件名（仅兼容旧版）")
@click.option("--auto-rename", is_flag=True, help="如果名称已存在，自动添加数字后缀")
def create(description, name, personality_type, service_ratio, quick, 
           dynamic, expert, interactive, template, license, save_as, auto_rename):
    """
    创建人格 - 四种模式
    
    智能模式 (默认): 基础问卷 + AI生成25个针对性问题 + 用户自定义补充（旧版）
    快速模式 (--quick): 纯AI脑补，不显示任何问题
    专家模式 (--expert): 只显示25题基础问卷（旧版）
    动态问卷 (--dynamic): 智能跳题，第三人称视角（推荐）
    
    示例:
        amber create "傲娇的高中生"                          # 智能模式（旧版）
        amber create --dynamic                              # 动态问卷模式（推荐）
        amber create --dynamic --name 林夕                  # 动态问卷模式并指定名称
        amber create "温柔的咖啡师" --quick --name 小暖      # 快速模式并指定名称
        amber create "温柔咖啡师" --quick                   # 快速模式
        amber create --expert                               # 专家模式
        amber create --template interviewer                 # 使用模板
    """
    
    # 处理模板
    if template:
        click.echo(f"使用模板: {template}")
        from amber.templates.loader import load_template
        template_data = load_template(template)
        if template_data:
            description = template_data.get("description", "")
            personality_type = template_data.get("type", personality_type)
    
    # 处理保存名称（兼容旧版 save-as）
    final_name = name or save_as
    
    # 确定使用哪种创建模式
    if dynamic:
        click.echo("🎯 动态问卷模式 - 智能跳题，第三人称视角")
        if final_name:
            click.echo(f"   指定名称: {final_name}")
        
        result = create_with_dynamic_questionnaire(
            description=description,
            personality_type=personality_type,
            interactive=True
        )
        
        # 如果指定了名称且创建成功，重命名
        if result and final_name and result.get("name") != final_name:
            from amber.create.quick_create import rename_persona
            old_name = result["name"]
            if rename_persona(old_name, final_name):
                result["name"] = final_name
                click.echo(f"   ✅ 已重命名为: {final_name}")
    
    elif expert:
        click.echo("🎯 专家模式 - 只显示25题基础问卷（旧版）")
        result = expert_create()
    
    elif quick:
        click.echo("⚡ 快速模式 - AI直接脑补")
        result = quick_create(
            description=description,
            personality_type=personality_type,
            service_ratio=service_ratio,
            name=final_name,
            auto_rename=auto_rename
        )
    
    else:
        click.echo("🧠 智能模式 - 基础问卷 + AI问题 + 自定义补充（旧版）")
        result = smart_create(
            description=description,
            personality_type=personality_type,
            service_ratio=service_ratio,
            interactive=True,
            name=final_name
        )
    
    if result:
        name = result.get("name", "新人格")
        ptype = result.get("params", {}).get("personality_type", {}).get("type", personality_type)
        click.echo(f"\n✅ 人格 '{name}' 创建成功！")
        click.echo(f"   类型: {ptype}")
        click.echo(f"   运行: amber run {name}")
    else:
        click.echo("❌ 创建失败")