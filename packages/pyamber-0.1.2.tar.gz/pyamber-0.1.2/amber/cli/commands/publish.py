"""
amber publish 命令实现
"""

import click
import yaml
from pathlib import Path


@click.command()
@click.argument("name")
@click.option("--license", help="许可证")
@click.option("--price", default="free", help="价格")
def publish(name, license, price):
    """发布到市场"""
    data_dir = Path(f"./data/personas/{name}")
    amber_file = data_dir / f"{name}.amber"
    
    if not amber_file.exists():
        click.echo(f"❌ 人格 '{name}' 不存在")
        return
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    if license:
        if 'signature' not in data:
            data['signature'] = {}
        data['signature']['license'] = license
        with open(amber_file, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ 发布 '{name}' 到市场")
    click.echo(f"   许可证: {license or '原有'}")
    click.echo(f"   价格: {price}")
