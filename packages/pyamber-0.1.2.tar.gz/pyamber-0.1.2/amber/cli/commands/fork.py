"""
amber fork 命令实现
"""

import click
import shutil
import yaml
from pathlib import Path
from datetime import datetime


@click.command()
@click.argument("source")
@click.option("--as", "new_name", required=True, help="新人格名称")
@click.option("--license", help="新人格许可证")
def fork(source, new_name, license):
    """
    Fork人格
    
    示例:
        amber fork 林夏 --as 林夏_温柔版
    """
    source_dir = Path(f"./data/personas/{source}")
    source_file = source_dir / f"{source}.amber"
    
    if not source_file.exists():
        click.echo(f"❌ 源人格 '{source}' 不存在")
        return
    
    target_dir = Path(f"./data/personas/{new_name}")
    if target_dir.exists():
        click.echo(f"❌ 人格 '{new_name}' 已存在")
        return
    
    # 创建目标目录
    target_dir.mkdir(parents=True)
    
    # 复制参数层
    target_file = target_dir / f"{new_name}.amber"
    shutil.copy(source_file, target_file)
    
    # 修改Fork信息
    with open(target_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    # 添加Fork信息
    data['fork_info'] = {
        'parent': source,
        'parent_version': data.get('version', '1.0'),
        'fork_point': datetime.now().isoformat(),
        'changes': []
    }
    
    # 修改创作者信息
    if 'signature' not in data:
        data['signature'] = {}
    data['signature']['derived_from'] = source
    data['signature']['creator_id'] = "匿名用户"
    
    if license:
        data['signature']['license'] = license
    
    # 修改名称
    if 'identity' not in data:
        data['identity'] = {}
    data['identity']['name'] = new_name
    
    with open(target_file, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    
    # 创建空白记忆层
    memory_file = target_dir / f"{new_name}.memory"
    memory_data = {
        'version': '1.0',
        'params_version': '1.0',
        'created_at': datetime.now().isoformat(),
        'last_updated': datetime.now().isoformat(),
        'total_interactions': 0,
        'facts': [],
        'emotional_traces': [],
        'current_emotion': {'pleasure': 0.3, 'activation': 0.5, 'trust': 0.4}
    }
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        yaml.dump(memory_data, f, allow_unicode=True, default_flow_style=False)
    
    click.echo(f"✅ Fork成功: {source} → {new_name}")
    click.echo(f"   运行: amber run {new_name}")
