"""
参数验证器
"""

from typing import Dict, Any, List, Tuple


def sanitize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """清理和修正参数"""
    
    # 确保 stats 在范围内
    if "stats" in params:
        for stat in ["int", "eq", "con"]:
            if stat in params["stats"]:
                params["stats"][stat] = max(0.3, min(1.5, params["stats"][stat]))
    
    # 确保 emotion 在范围内
    if "emotion" in params:
        if "base" in params["emotion"]:
            for dim in ["pleasure", "activation", "trust"]:
                if dim in params["emotion"]["base"]:
                    params["emotion"]["base"][dim] = max(0.0, min(1.0, params["emotion"]["base"][dim]))
        
        if "sensitivity" in params["emotion"]:
            for sens in ["pleasure", "trust"]:
                if sens in params["emotion"]["sensitivity"]:
                    params["emotion"]["sensitivity"][sens] = max(0.3, min(1.5, params["emotion"]["sensitivity"][sens]))
        
        if "trust_recovery_rate" in params["emotion"]:
            params["emotion"]["trust_recovery_rate"] = max(0.1, min(1.0, params["emotion"]["trust_recovery_rate"]))
        if "trust_decay_rate" in params["emotion"]:
            params["emotion"]["trust_decay_rate"] = max(0.05, min(0.5, params["emotion"]["trust_decay_rate"]))
    
    # 确保 speech 在范围内
    if "speech" in params:
        if "temperature" in params["speech"]:
            params["speech"]["temperature"] = max(0.0, min(2.0, params["speech"]["temperature"]))
        if "min_length" in params["speech"]:
            params["speech"]["min_length"] = max(1, min(50, params["speech"]["min_length"]))
        if "max_length" in params["speech"]:
            params["speech"]["max_length"] = max(10, min(500, params["speech"]["max_length"]))
    
    return params


def validate_params(params: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """验证参数"""
    errors = []
    
    required_fields = ["identity", "stats", "emotion", "speech"]
    for field in required_fields:
        if field not in params:
            errors.append(f"缺少必需字段: {field}")
    
    if "identity" in params and "name" not in params["identity"]:
        errors.append("identity.name 是必需的")
    
    if "personality_type" in params:
        ptype = params["personality_type"].get("type", "")
        if ptype not in ["independent", "service", "mixed"]:
            errors.append(f"personality_type.type 必须是 independent/service/mixed，当前: {ptype}")
        
        service_ratio = params["personality_type"].get("service_ratio", 0)
        if not (0 <= service_ratio <= 1):
            errors.append(f"personality_type.service_ratio 必须在 0-1 之间，当前: {service_ratio}")
    
    if "stats" in params:
        for stat, value in params["stats"].items():
            if stat in ["int", "eq", "con"]:
                if not (0.3 <= value <= 1.5):
                    errors.append(f"stats.{stat} 应在 0.3-1.5 之间，当前值: {value}")
    
    if "emotion" in params and "base" in params["emotion"]:
        for dim, value in params["emotion"]["base"].items():
            if dim in ["pleasure", "activation", "trust"]:
                if not (0.0 <= value <= 1.0):
                    errors.append(f"emotion.base.{dim} 应在 0.0-1.0 之间，当前值: {value}")
    
    if "speech" in params and "temperature" in params["speech"]:
        temp = params["speech"]["temperature"]
        if not (0.0 <= temp <= 2.0):
            errors.append(f"speech.temperature 应在 0.0-2.0 之间，当前值: {temp}")
    
    return len(errors) == 0, errors