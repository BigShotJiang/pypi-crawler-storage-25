"""
专家创建 - 已迁移到动态问卷
"""

from typing import Dict, Any, Optional
from datetime import datetime
import os

from amber.create.dynamic_questionnaire import create_with_dynamic_questionnaire
from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory as save_memory_file


def expert_create(personality_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    专家模式创建 - 已迁移到动态问卷系统
    
    注意: 旧版25题问卷已被动态问卷替代，此函数调用新版动态问卷
    
    Args:
        personality_type: 人格类型（可选）
        
    Returns:
        创建结果
    """
    print("\n🎯 专家模式 - 动态问卷（替代旧版25题）")
    print("=" * 50)
    print("提示: 新版问卷支持智能跳题，问题更少更精准")
    print("=" * 50)
    
    # 使用动态问卷
    result = create_with_dynamic_questionnaire(
        description=None,
        personality_type=personality_type,
        interactive=True
    )
    
    return result


def generate_expert_name(answers: Dict[str, str]) -> str:
    """根据答案生成名称（兼容旧版）"""
    role = answers.get("role", "")
    
    if role == "服务人员":
        return "小助手"
    elif role == "白领":
        return "职场伙伴"
    elif role == "学生":
        return "同学"
    elif role == "艺术家":
        return "艺艺"
    elif role == "咖啡店店主":
        return "林夏"
    elif role == "面试官":
        return "张老师"
    elif role == "老师":
        return "王老师"
    else:
        return "新人格"