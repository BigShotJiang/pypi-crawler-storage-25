"""
智能创建 - AI生成针对性问题 + 基础问卷 + 用户自定义补充
"""

import os
import json
import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory as save_memory_file
from amber.utils.llm_client import get_client
from amber.create.quick_create import check_persona_exists, get_unique_name


def smart_create(description: str,
                 personality_type: str = "independent",
                 service_ratio: float = 0.5,
                 interactive: bool = True,
                 name: str = None,
                 auto_rename: bool = True) -> Optional[Dict[str, Any]]:
    """
    智能创建人格 - AI生成针对性问题，用户填写问卷
    
    模式:
        interactive=True: 显示基础问卷 + AI生成问题 + 用户自定义补充
        interactive=False: 纯AI脑补，不显示任何问题
    
    Args:
        description: 用户描述
        personality_type: 人格类型
        service_ratio: 服务比例
        interactive: 是否交互模式
        name: 指定人格名称（可选）
        auto_rename: 如果名称已存在，是否自动添加数字后缀
    """
    print(f"\n🔍 分析描述: {description}")
    
    llm = get_client()
    
    # 快速模式：纯AI脑补，不显示问卷
    if not interactive:
        print("⚡ 快速模式：AI直接脑补人格...")
        return _ai_only_create(description, personality_type, service_ratio, llm, name, auto_rename)
    
    # 智能模式：生成问题让用户填写
    print("📝 智能模式：生成针对性问题...")
    
    # 1. 加载基础问卷（使用动态问卷）
    from amber.create.dynamic_questionnaire import DynamicQuestionnaire
    base_q = DynamicQuestionnaire()
    
    # 2. AI生成25个针对性问题
    ai_questions = []
    if llm.is_available():
        print("🤖 AI正在生成针对性问题...")
        try:
            ai_questions = _generate_ai_questions(llm, description)
            print(f"   ✓ 生成了 {len(ai_questions)} 个针对性问题")
        except Exception as e:
            print(f"   ⚠️ AI问题生成失败: {e}")
    
    # 3. 用户自定义补充问题
    custom_questions = []
    print("\n💬 你可以补充自定义问题（输入空行结束）:")
    while True:
        custom = input("补充问题: ").strip()
        if not custom:
            break
        custom_questions.append(custom)
    
    # 4. 收集所有答案
    all_answers = {}
    
    # 4.1 基础问卷
    print("\n" + "=" * 60)
    print("📋 第一部分：基础信息")
    print("=" * 60)
    base_answers = base_q.run(interactive=True)
    all_answers.update(base_answers)
    
    # 4.2 AI生成问题
    if ai_questions:
        print("\n" + "=" * 60)
        print("🧠 第二部分：AI根据你的描述生成的问题")
        print("=" * 60)
        for i, q_text in enumerate(ai_questions, 1):
            print(f"\n[{i}/{len(ai_questions)}]")
            print(f"问题: {q_text}")
            answer = input("回答: ").strip()
            all_answers[f"ai_{i}"] = answer
    
    # 4.3 用户自定义问题
    if custom_questions:
        print("\n" + "=" * 60)
        print("💡 第三部分：你补充的问题")
        print("=" * 60)
        for i, q_text in enumerate(custom_questions, 1):
            print(f"\n[{i}/{len(custom_questions)}]")
            print(f"问题: {q_text}")
            answer = input("回答: ").strip()
            all_answers[f"custom_{i}"] = answer
    
    # 5. 生成名称
    final_name = _resolve_name(name, description, llm, all_answers, auto_rename)
    
    # 6. 映射为基础参数
    params = _map_answers_to_params(all_answers)
    
    # 7. 设置人格类型
    if personality_type == "mixed":
        params["personality_type"] = {
            "type": "mixed",
            "service_ratio": service_ratio
        }
    else:
        params["personality_type"] = {
            "type": personality_type,
            "service_ratio": 0.0 if personality_type == "independent" else 1.0
        }
    
    # 8. 设置名称和描述
    params["identity"]["name"] = final_name
    params["identity"]["description"] = description
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "smart",
        "original_description": description,
        "llm_assisted": llm.is_available(),
        "ai_questions_count": len(ai_questions),
        "custom_questions_count": len(custom_questions),
        "ai_answers": {k: v for k, v in all_answers.items() if k.startswith("ai_")},
        "custom_answers": {k: v for k, v in all_answers.items() if k.startswith("custom_")}
    }
    
    # 9. 添加签名
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 10. 保存
    data_dir = f"./data/personas/{final_name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{final_name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], personality_type)
    memory_path = os.path.join(data_dir, f"{final_name}.memory")
    save_memory_file(memory, memory_path)
    
    print(f"\n✅ 人格 '{final_name}' 创建成功!")
    print(f"   类型: {personality_type}")
    print(f"   运行: amber run {final_name}")
    
    return {"name": final_name, "params": params}


def _ai_only_create(description: str, personality_type: str, 
                    service_ratio: float, llm, name: str = None,
                    auto_rename: bool = True) -> Dict[str, Any]:
    """纯AI脑补模式 - 不显示任何问题"""
    
    if llm.is_available():
        print("🤖 AI正在脑补人格细节...")
        try:
            llm_params = _llm_generate_full_params(llm, description)
            print("   ✓ AI脑补完成")
            params = _merge_with_default_params(llm_params)
        except Exception as e:
            print(f"   ⚠️ AI脑补失败: {e}，使用默认参数")
            params = _get_default_params()
    else:
        print("   ⚠️ LLM不可用，使用默认参数")
        params = _get_default_params()
    
    # 生成名称
    final_name = _resolve_name(name, description, llm, {}, auto_rename)
    
    # 设置参数
    params["identity"]["name"] = final_name
    params["identity"]["description"] = description
    params["personality_type"] = {
        "type": personality_type,
        "service_ratio": 0.0 if personality_type == "independent" else 1.0
    }
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "ai_only",
        "original_description": description,
        "llm_assisted": llm.is_available()
    }
    
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 保存
    data_dir = f"./data/personas/{final_name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{final_name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], personality_type)
    memory_path = os.path.join(data_dir, f"{final_name}.memory")
    save_memory_file(memory, memory_path)
    
    print(f"\n✅ 人格 '{final_name}' 创建成功!")
    print(f"   类型: {personality_type}")
    print(f"   运行: amber run {final_name}")
    
    return {"name": final_name, "params": params}


def _resolve_name(name: Optional[str], description: str, llm, answers: Dict, 
                  auto_rename: bool = True) -> str:
    """
    解析最终名称
    
    Args:
        name: 指定的名称
        description: 描述
        llm: LLM客户端
        answers: 问卷答案
        auto_rename: 是否自动处理重名
    """
    # 1. 优先使用指定的名称
    if name:
        base_name = name
    else:
        # 2. 尝试从描述中提取名称
        extracted = _extract_name_from_description(description)
        if extracted:
            base_name = extracted
        else:
            # 3. AI建议名称
            suggested = _suggest_name(llm, description, answers) if llm.is_available() else None
            if suggested:
                base_name = suggested
            else:
                # 4. 使用备用名称生成
                base_name = _generate_name_from_description(description)
            
            # 5. 用户确认名称（交互模式）
            if llm.is_available() or True:  # 交互模式下让用户确认
                user_name = input(f"\n📝 建议名称: {base_name}\n请输入名称（回车使用建议）: ").strip()
                if user_name:
                    base_name = user_name
    
    # 6. 处理重名
    if auto_rename and check_persona_exists(base_name):
        final_name = get_unique_name(base_name)
        print(f"   ⚠️ 名称 '{base_name}' 已存在，自动重命名为: {final_name}")
        return final_name
    
    return base_name


def _extract_name_from_description(description: str) -> Optional[str]:
    """从描述中提取中文名称"""
    # 匹配常见的中文名字模式（2-3个字）
    name_pattern = r'[\u4e00-\u9fa5]{2,3}'
    matches = re.findall(name_pattern, description)
    
    # 排除常见的非名字词汇
    exclude_words = [
        "温柔", "活泼", "开朗", "阳光", "热情", "乐于助人", 
        "喜欢", "说话", "语气词", "可爱", "小迷糊", "咖啡", 
        "面试", "英语", "老师", "傲娇", "助手", "客服", "学姐",
        "学长", "同学", "朋友", "女孩", "男生", "女生",
        "咖啡店", "奶茶店", "便利店"
    ]
    
    for match in matches:
        if match not in exclude_words and len(match) >= 2:
            return match
    
    return None


def _generate_ai_questions(llm, description: str) -> List[str]:
    """AI生成25个针对性问题（返回字符串列表）"""
    prompt = f"""根据以下人格描述，生成25个针对性问题，用于深入了解这个人格。

描述: {description}

要求:
1. 问题要针对这个特定角色，不要通用问题
2. 每个问题应该能揭示角色的独特性格
3. 问题格式: 简单的问句

返回格式（JSON数组）:
["问题1", "问题2", ...]

只返回JSON数组，不要其他内容。"""

    try:
        response = llm.chat([
            {"role": "system", "content": "你是人格设计师。生成针对性的问题。"},
            {"role": "user", "content": prompt}
        ], temperature=0.7, max_tokens=1500)
        
        json_match = re.search(r'\[.*\]', response, re.DOTALL)
        if json_match:
            questions = json.loads(json_match.group())
            return questions[:25]
    except Exception:
        pass
    return []


def _llm_generate_full_params(llm, description: str) -> Dict:
    """AI直接生成完整人格参数（脑补模式）"""
    prompt = f"""根据以下人格描述，生成完整的人格参数。

描述: {description}

返回JSON格式:
{{
    "identity": {{"role": "角色", "age": 年龄}},
    "stats": {{"int": 智商0.3-1.5, "eq": 情商0.3-1.5, "con": 体质0.3-1.5}},
    "emotion": {{"base": {{"pleasure": 0-1, "activation": 0-1, "trust": 0-1}}}},
    "speech": {{"style": "风格", "temperature": 0-2, "catchphrases": ["口头禅"]}},
    "boundaries": {{"topic_blacklist": ["禁忌话题"]}}
}}

只返回JSON。"""

    try:
        response = llm.chat([
            {"role": "system", "content": "你是人格参数专家。"},
            {"role": "user", "content": prompt}
        ], temperature=0.5, max_tokens=1000)
        
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
    except Exception:
        pass
    return {}


def _merge_with_default_params(llm_params: Dict) -> Dict:
    """合并AI生成的参数和默认参数"""
    default = _get_default_params()
    
    if "identity" in llm_params:
        default["identity"].update(llm_params["identity"])
    if "stats" in llm_params:
        default["stats"].update(llm_params["stats"])
    if "emotion" in llm_params:
        if "base" in llm_params["emotion"]:
            default["emotion"]["base"].update(llm_params["emotion"]["base"])
        if "sensitivity" in llm_params["emotion"]:
            default["emotion"]["sensitivity"].update(llm_params["emotion"]["sensitivity"])
    if "speech" in llm_params:
        default["speech"].update(llm_params["speech"])
    if "boundaries" in llm_params:
        default["boundaries"].update(llm_params["boundaries"])
    
    return default


def _get_default_params() -> Dict:
    """默认参数"""
    return {
        "identity": {"role": "未知", "age": 25},
        "stats": {"int": 1.0, "eq": 1.0, "con": 1.0},
        "emotion": {
            "base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4},
            "sensitivity": {"pleasure": 1.0, "trust": 1.0}
        },
        "speech": {"style": "normal", "temperature": 0.7, "catchphrases": []},
        "boundaries": {"topic_blacklist": []}
    }


def _map_answers_to_params(answers: Dict) -> Dict:
    """将问卷答案映射为参数"""
    params = _get_default_params()
    
    # 年龄映射
    age_map = {"18-22": 20, "23-27": 25, "28-35": 30, "36-45": 40, "45+": 50}
    if "age" in answers:
        params["identity"]["age"] = age_map.get(answers["age"], 25)
    
    # 角色
    if "role" in answers:
        params["identity"]["role"] = answers["role"]
    
    # 性别
    gender_map = {"男性": "male", "女性": "female", "中性": "neutral", "其他": "other"}
    if "gender" in answers:
        params["identity"]["gender"] = gender_map.get(answers["gender"], "neutral")
    
    # 社交倾向影响激活度
    social_map = {"极度外向": 0.3, "外向": 0.15, "中间": 0, "内向": -0.15, "极度内向": -0.3}
    if "social" in answers:
        delta = social_map.get(answers["social"], 0)
        params["emotion"]["base"]["activation"] = max(0.0, min(1.0, 0.5 + delta))
    
    # 共情影响 EQ
    empathy_map = {"很强": 0.3, "较强": 0.15, "普通": 0, "较弱": -0.15, "很弱": -0.3}
    if "empathy" in answers:
        delta = empathy_map.get(answers["empathy"], 0)
        params["stats"]["eq"] = max(0.3, min(1.5, 1.0 + delta))
    
    # 话量影响说话长度
    volume_map = {
        "话痨": {"min": 30, "max": 200, "temp": 0.9},
        "话多": {"min": 20, "max": 150, "temp": 0.8},
        "适中": {"min": 10, "max": 90, "temp": 0.7},
        "话少": {"min": 5, "max": 50, "temp": 0.6},
        "沉默寡言": {"min": 3, "max": 30, "temp": 0.5}
    }
    if "talk_volume" in answers and answers["talk_volume"] in volume_map:
        v = volume_map[answers["talk_volume"]]
        params["speech"]["min_length"] = v["min"]
        params["speech"]["max_length"] = v["max"]
        params["speech"]["temperature"] = v["temp"]
    
    # 用词风格
    style_map = {"文雅": 0.5, "日常": 0.7, "随意": 0.9, "专业": 0.6}
    if "word_style" in answers and answers["word_style"] in style_map:
        params["speech"]["temperature"] = style_map[answers["word_style"]]
    
    # 口头禅
    if "catchphrases" in answers and answers["catchphrases"]:
        params["speech"]["catchphrases"] = [p.strip() for p in answers["catchphrases"].split(",") if p.strip()]
    
    # 性格特质映射
    trait_map = {
        "gentle": {"eq": 1.2, "pleasure": 0.4},
        "tsundere": {"eq": 0.8, "trust": 0.3},
        "cheerful": {"eq": 1.1, "pleasure": 0.5},
        "cold": {"eq": 0.6, "pleasure": 0.1},
        "professional": {"int": 1.3},
        "humorous": {"temperature": 0.9},
        "serious": {"temperature": 0.5, "eq": 0.7},
        "warm": {"eq": 1.2, "pleasure": 0.45}
    }
    
    traits = answers.get("personality_traits", [])
    if isinstance(traits, list):
        for trait in traits:
            if trait in trait_map:
                mapping = trait_map[trait]
                if "eq" in mapping:
                    params["stats"]["eq"] = max(0.3, min(1.5, params["stats"]["eq"] + mapping["eq"] - 1.0))
                if "int" in mapping:
                    params["stats"]["int"] = max(0.3, min(1.5, params["stats"]["int"] + mapping["int"] - 1.0))
                if "pleasure" in mapping:
                    params["emotion"]["base"]["pleasure"] = mapping["pleasure"]
                if "trust" in mapping:
                    params["emotion"]["base"]["trust"] = mapping["trust"]
                if "temperature" in mapping:
                    params["speech"]["temperature"] = mapping["temperature"]
    
    return params


def _suggest_name(llm, description: str, answers: Dict) -> str:
    """建议名称"""
    prompt = f"为以下人格建议一个2-3字的中文名:\n{description}\n只返回名字:"
    
    try:
        response = llm.chat([
            {"role": "user", "content": prompt}
        ], temperature=0.7, max_tokens=20)
        name = response.strip()
        if 2 <= len(name) <= 4:
            return name
    except Exception:
        pass
    return ""


def _generate_name_from_description(description: str) -> str:
    """从描述生成名称"""
    name_map = {
        "咖啡": "林夏", "温柔": "小暖", "面试": "张老师",
        "英语": "MsWang", "傲娇": "浅浅", "助手": "小助",
        "客服": "小安", "老师": "王老师", "学生": "同学",
        "学姐": "林夕", "学长": "学长", "活泼": "小阳"
    }
    for keyword, name in name_map.items():
        if keyword in description:
            return name
    return "新人格"


def _extract_role(description: str) -> str:
    """从描述提取角色（供测试使用）"""
    if "咖啡" in description or "店主" in description:
        return "咖啡店店主"
    if "面试" in description:
        return "面试官"
    if "老师" in description:
        return "老师"
    if "客服" in description:
        return "客服"
    if "学姐" in description:
        return "学姐"
    if "学长" in description:
        return "学长"
    return "未知"