"""
动态问卷引擎 - 支持条件跳题和角色导向（第三人称）
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

# 在文件开头导入所需的格式化函数
from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory as save_memory_file


@dataclass
class Question:
    """问题定义"""
    id: str
    text: str
    qtype: str
    perspective: str = "third_person"
    options: List[Dict] = field(default_factory=list)
    condition: Optional[str] = None
    required: bool = False
    min: int = 0
    max: int = 10
    labels: Dict[str, str] = field(default_factory=dict)
    placeholder: str = ""
    max_selections: int = 3
    default: Any = None


class DynamicQuestionnaire:
    """动态跳题问卷"""
    
    def __init__(self, schema_path: Optional[str] = None):
        if schema_path is None:
            schema_path = Path(__file__).parent.parent / "schemas" / "questionnaire_schema.json"
        
        # 如果 schema 文件不存在，使用内置默认
        if not Path(schema_path).exists():
            self.schema = self._get_default_schema()
        else:
            with open(schema_path, 'r', encoding='utf-8') as f:
                self.schema = json.load(f)
        
        self.questions = self._parse_questions()
        self.answers: Dict[str, Any] = {}
        self._condition_cache: Dict[str, bool] = {}
    
    def _get_default_schema(self) -> Dict:
        """获取默认 schema"""
        return {
            "version": "2.0",
            "title": "人格创造问卷",
            "description": "请用第三人称描述这个角色（他/她/它）",
            "questions": [
                {
                    "id": "name",
                    "text": "这个角色的名字是？",
                    "type": "string",
                    "required": True
                },
                {
                    "id": "role_type",
                    "text": "这个角色的身份是？",
                    "type": "select",
                    "options": [
                        {"value": "friend", "label": "朋友/伴侣/家人"},
                        {"value": "service", "label": "服务者（客服/助手/老师/面试官）"},
                        {"value": "character", "label": "虚构角色/游戏角色"}
                    ],
                    "required": True
                },
                {
                    "id": "service_context",
                    "text": "他/她主要提供什么服务？",
                    "type": "select",
                    "condition": "role_type == 'service'",
                    "options": [
                        {"value": "customer_service", "label": "客服咨询"},
                        {"value": "teacher", "label": "教学/辅导"},
                        {"value": "interviewer", "label": "面试/评估"},
                        {"value": "coach", "label": "职业/生活指导"},
                        {"value": "companion", "label": "陪伴/倾听"}
                    ]
                },
                {
                    "id": "intimacy",
                    "text": "他/她与用户的关系亲密程度？",
                    "type": "scale",
                    "condition": "role_type == 'friend'",
                    "min": 0,
                    "max": 10,
                    "labels": {"0": "陌生人", "5": "普通朋友", "10": "家人/恋人"}
                },
                {
                    "id": "personality_traits",
                    "text": "他/她的核心性格特质（选2-3个）",
                    "type": "multi_select",
                    "options": [
                        {"value": "gentle", "label": "温柔体贴"},
                        {"value": "tsundere", "label": "傲娇/口是心非"},
                        {"value": "cheerful", "label": "活泼开朗"},
                        {"value": "cold", "label": "高冷/冷淡"},
                        {"value": "professional", "label": "专业严谨"},
                        {"value": "humorous", "label": "幽默风趣"},
                        {"value": "serious", "label": "严肃认真"},
                        {"value": "warm", "label": "热情温暖"}
                    ],
                    "max_selections": 3
                },
                {
                    "id": "emotional_style",
                    "text": "他/她表达情绪的方式？",
                    "type": "select",
                    "options": [
                        {"value": "expressive", "label": "外放直接"},
                        {"value": "moderate", "label": "适中"},
                        {"value": "reserved", "label": "内敛含蓄"},
                        {"value": "repressed", "label": "压抑沉默"}
                    ]
                },
                {
                    "id": "talk_volume",
                    "text": "他/她喜欢说话吗？",
                    "type": "scale",
                    "min": 0,
                    "max": 10,
                    "labels": {"0": "沉默寡言", "5": "话量适中", "10": "话痨/话多"},
                    "default": 5
                },
                {
                    "id": "empathy",
                    "text": "他/她能够理解他人的感受吗？",
                    "type": "scale",
                    "min": 0,
                    "max": 10,
                    "labels": {"0": "完全不在意", "5": "一般", "10": "非常善解人意"},
                    "default": 5
                },
                {
                    "id": "boundary_strictness",
                    "text": "他/她对话题的开放程度？",
                    "type": "scale",
                    "min": 0,
                    "max": 10,
                    "labels": {"0": "百无禁忌", "5": "一般", "10": "非常保守有底线"},
                    "default": 5
                },
                {
                    "id": "forgiveness_speed",
                    "text": "他/她被冒犯后原谅对方的速度？",
                    "type": "scale",
                    "min": 0,
                    "max": 10,
                    "labels": {"0": "永不原谅", "5": "一般", "10": "瞬间原谅"},
                    "default": 5
                },
                {
                    "id": "catchphrases",
                    "text": "他/她的口头禅（可选，多个用逗号分隔）",
                    "type": "string",
                    "placeholder": "例如：那个...、原来如此、哼！"
                },
                {
                    "id": "special_features",
                    "text": "需要开启哪些特殊功能？",
                    "type": "multi_select",
                    "options": [
                        {"value": "progress_report", "label": "进步报告（服务型专属）"},
                        {"value": "adaptive_difficulty", "label": "自适应难度"},
                        {"value": "silence", "label": "沉默机制（独立人格）"}
                    ]
                }
            ]
        }
    
    def _parse_questions(self) -> List[Question]:
        """解析问题列表"""
        questions = []
        for q_data in self.schema.get("questions", []):
            q = Question(
                id=q_data["id"],
                text=q_data["text"],
                qtype=q_data["type"],
                perspective=q_data.get("perspective", "third_person"),
                options=q_data.get("options", []),
                condition=q_data.get("condition"),
                required=q_data.get("required", False),
                min=q_data.get("min", 0),
                max=q_data.get("max", 10),
                labels=q_data.get("labels", {}),
                placeholder=q_data.get("placeholder", ""),
                max_selections=q_data.get("max_selections", 3),
                default=q_data.get("default")
            )
            questions.append(q)
        return questions
    
    def _should_show(self, question: Question) -> bool:
        """判断问题是否应该显示"""
        if not question.condition:
            return True
        
        if question.id not in self._condition_cache:
            self._condition_cache[question.id] = self._evaluate_condition(
                question.condition, self.answers
            )
        
        return self._condition_cache[question.id]
    
    def _evaluate_condition(self, condition: str, answers: Dict) -> bool:
        """安全评估条件表达式"""
        try:
            if "==" in condition:
                var, val = condition.split("==")
                var = var.strip()
                val = val.strip().strip("'")
                return str(answers.get(var)) == val
            elif "!=" in condition:
                var, val = condition.split("!=")
                var = var.strip()
                val = val.strip().strip("'")
                return str(answers.get(var)) != val
            elif "&&" in condition:
                parts = condition.split("&&")
                return all(self._evaluate_condition(p.strip(), answers) for p in parts)
            elif "||" in condition:
                parts = condition.split("||")
                return any(self._evaluate_condition(p.strip(), answers) for p in parts)
        except Exception:
            pass
        return True
    
    def get_next_question(self, current_id: Optional[str] = None) -> Optional[Question]:
        """获取下一个应该显示的问题"""
        start_index = 0
        if current_id:
            for i, q in enumerate(self.questions):
                if q.id == current_id:
                    start_index = i + 1
                    break
        
        for i in range(start_index, len(self.questions)):
            q = self.questions[i]
            if self._should_show(q):
                return q
        
        return None
    
    def _transform_perspective(self, text: str) -> str:
        """转换视角：第三人称"""
        replacements = [
            ("你", "他/她"),
            ("你的", "他/她的"),
            ("你自己", "他/她自己"),
        ]
        for old, new in replacements:
            text = text.replace(old, new)
        return text
    
    def ask_question(self, question: Question, interactive: bool = True) -> Any:
        """提问并获取答案"""
        if not interactive:
            return self._get_default_answer(question)
        
        text = self._transform_perspective(question.text)
        print(f"\n📌 {text}")
        
        if question.qtype == "select":
            for i, opt in enumerate(question.options, 1):
                label = opt.get('label', opt.get('value', opt))
                print(f"   {i}. {label}")
            
            while True:
                try:
                    choice = input("请选择 (1-{}): ".format(len(question.options))).strip()
                    if not choice and not question.required:
                        return None
                    if not choice and question.default:
                        return question.default
                    idx = int(choice) - 1
                    if 0 <= idx < len(question.options):
                        return question.options[idx]["value"]
                    print(f"   ❌ 请输入 1-{len(question.options)}")
                except ValueError:
                    print("   ❌ 请输入数字")
        
        elif question.qtype == "multi_select":
            print("   💡 多选，输入序号（用逗号分隔），回车跳过")
            for i, opt in enumerate(question.options, 1):
                label = opt.get('label', opt.get('value', opt))
                print(f"   {i}. {label}")
            
            while True:
                choice = input("选择: ").strip()
                if not choice:
                    return []
                
                try:
                    indices = [int(x.strip()) for x in choice.split(",")]
                    selected = []
                    for idx in indices:
                        if 1 <= idx <= len(question.options):
                            selected.append(question.options[idx-1]["value"])
                    if len(selected) <= question.max_selections:
                        return selected
                    print(f"   ❌ 最多选择 {question.max_selections} 个")
                except ValueError:
                    print("   ❌ 请输入数字，用逗号分隔")
        
        elif question.qtype == "scale":
            print(f"   📊 范围 {question.min}-{question.max}")
            if question.labels:
                print(f"   {question.min}={question.labels.get(str(question.min), '')}  →  {question.max}={question.labels.get(str(question.max), '')}")
            
            default_msg = f" (默认: {question.default})" if question.default else ""
            
            while True:
                try:
                    val = input(f"评分{default_msg}: ").strip()
                    if not val and question.default is not None:
                        return question.default
                    if not val and not question.required:
                        return (question.min + question.max) // 2
                    val = int(val)
                    if question.min <= val <= question.max:
                        return val
                    print(f"   ❌ 请输入 {question.min}-{question.max}")
                except ValueError:
                    print("   ❌ 请输入数字")
        
        else:  # string
            placeholder = f" (例如: {question.placeholder})" if question.placeholder else ""
            while True:
                answer = input(f"回答{placeholder}: ").strip()
                if not answer and not question.required:
                    return ""
                return answer
    
    def _get_default_answer(self, question: Question) -> Any:
        """获取默认答案"""
        if question.default is not None:
            return question.default
        
        if question.qtype == "select":
            return question.options[0]["value"] if question.options else None
        elif question.qtype == "multi_select":
            return []
        elif question.qtype == "scale":
            return (question.min + question.max) // 2
        else:
            return ""
    
    def run(self, interactive: bool = True) -> Dict[str, Any]:
        """运行完整问卷"""
        print("\n" + "=" * 55)
        print(f"  {self.schema.get('title', '人格创建问卷')}")
        print(f"  {self.schema.get('description', '')}")
        print("=" * 55)
        
        current_q = self.get_next_question()
        answers = {}
        
        while current_q:
            answer = self.ask_question(current_q, interactive)
            if answer is not None:
                answers[current_q.id] = answer
                self.answers = answers.copy()
                self._condition_cache.clear()
            
            current_q = self.get_next_question(current_q.id)
        
        return answers


class DynamicParameterMapper:
    """新版参数映射器 - 基于角色导向（第三人称）"""
    
    def __init__(self):
        self._init_mappings()
    
    def _init_mappings(self):
        """初始化映射规则"""
        self.trait_mappings = {
            "gentle": {"stats": {"eq": 1.2}, "emotion": {"base": {"pleasure": 0.4}}},
            "tsundere": {"stats": {"eq": 0.8}, "emotion": {"base": {"trust": 0.3}}, "speech": {"style": "tsundere"}},
            "cheerful": {"stats": {"eq": 1.1}, "emotion": {"base": {"pleasure": 0.5, "activation": 0.6}}},
            "cold": {"stats": {"eq": 0.6}, "emotion": {"base": {"pleasure": 0.1}}, "speech": {"style": "cold"}},
            "professional": {"stats": {"int": 1.3}, "speech": {"style": "professional"}},
            "humorous": {"speech": {"temperature": 0.9}},
            "serious": {"speech": {"temperature": 0.5}, "stats": {"eq": 0.7}},
            "warm": {"stats": {"eq": 1.2}, "emotion": {"base": {"pleasure": 0.45}}},
        }
        
        self.emotion_mappings = {
            "expressive": {"emotion": {"sensitivity": {"pleasure": 1.2}}},
            "moderate": {},
            "reserved": {"emotion": {"sensitivity": {"pleasure": 0.7}}},
            "repressed": {"emotion": {"sensitivity": {"pleasure": 0.5}}, "silence": {"frequency": 1}},
        }
        
        self.role_mappings = {
            "service": {"personality_type": "service", "service_ratio": 1.0},
            "friend": {"personality_type": "independent", "service_ratio": 0.0},
            "character": {"personality_type": "independent", "service_ratio": 0.0},
        }
        
        self.service_context_mappings = {
            "customer_service": {"speech": {"style": "polite"}, "stats": {"eq": 1.2}},
            "teacher": {"speech": {"style": "patient"}, "stats": {"int": 1.2}},
            "interviewer": {"speech": {"style": "professional"}, "stats": {"int": 1.3, "eq": 0.8}},
            "coach": {"speech": {"style": "supportive"}, "stats": {"int": 1.1, "eq": 1.2}},
            "companion": {"speech": {"style": "gentle"}, "stats": {"eq": 1.3}},
        }
    
    def map(self, answers: Dict[str, Any]) -> Dict[str, Any]:
        """将答案映射为人格参数"""
        params = self._create_base_params()
        
        # 1. 角色类型
        role_type = answers.get("role_type", "friend")
        if role_type in self.role_mappings:
            mapping = self.role_mappings[role_type]
            params["personality_type"]["type"] = mapping["personality_type"]
            params["personality_type"]["service_ratio"] = mapping["service_ratio"]
        
        # 2. 性格特质 - 直接覆盖参数值
        traits = answers.get("personality_traits", [])
        for trait in traits:
            if trait in self.trait_mappings:
                mapping = self.trait_mappings[trait]
                # 应用 stats 修改（直接覆盖）
                if "stats" in mapping:
                    if "eq" in mapping["stats"]:
                        params["stats"]["eq"] = mapping["stats"]["eq"]
                    if "int" in mapping["stats"]:
                        params["stats"]["int"] = mapping["stats"]["int"]
                # 应用 emotion base 修改
                if "emotion" in mapping and "base" in mapping["emotion"]:
                    for dim, val in mapping["emotion"]["base"].items():
                        params["emotion"]["base"][dim] = val
                # 应用 speech 修改
                if "speech" in mapping:
                    for k, v in mapping["speech"].items():
                        params["speech"][k] = v
        
        # 3. 情绪表达
        emotion_style = answers.get("emotional_style")
        if emotion_style and emotion_style in self.emotion_mappings:
            mapping = self.emotion_mappings[emotion_style]
            if "emotion" in mapping and "sensitivity" in mapping["emotion"]:
                for k, v in mapping["emotion"]["sensitivity"].items():
                    params["emotion"]["sensitivity"][k] = v
            if "silence" in mapping:
                for k, v in mapping["silence"].items():
                    params["silence"][k] = v
        
        # 4. 话量映射
        talk_volume = answers.get("talk_volume", 5)
        volume_mappings = {
            (0, 3): {"speech": {"min_length": 5, "max_length": 40}, "silence": {"frequency": 2}},
            (4, 6): {"speech": {"min_length": 10, "max_length": 80}},
            (7, 10): {"speech": {"min_length": 20, "max_length": 150}, "silence": {"frequency": -1}},
        }
        for (low, high), mapping in volume_mappings.items():
            if low <= talk_volume <= high:
                if "speech" in mapping:
                    for k, v in mapping["speech"].items():
                        params["speech"][k] = v
                if "silence" in mapping:
                    for k, v in mapping["silence"].items():
                        params["silence"][k] = v
                break
        
        # 5. 共情映射
        empathy = answers.get("empathy", 5)
        empathy_mappings = {
            (0, 3): {"stats": {"eq": 0.6}, "emotion": {"sensitivity": {"trust": 0.5}}},
            (4, 6): {"stats": {"eq": 1.0}},
            (7, 10): {"stats": {"eq": 1.3}, "emotion": {"sensitivity": {"trust": 1.2}}},
        }
        for (low, high), mapping in empathy_mappings.items():
            if low <= empathy <= high:
                if "stats" in mapping and "eq" in mapping["stats"]:
                    params["stats"]["eq"] = mapping["stats"]["eq"]
                if "emotion" in mapping and "sensitivity" in mapping["emotion"]:
                    for k, v in mapping["emotion"]["sensitivity"].items():
                        params["emotion"]["sensitivity"][k] = v
                break
        
        # 6. 边界严格度映射
        boundary = answers.get("boundary_strictness", 5)
        boundary_mappings = {
            (0, 3): {"boundaries": {"topic_blacklist": []}},
            (4, 6): {"boundaries": {"topic_blacklist": ["医疗建议", "法律咨询"]}},
            (7, 10): {"boundaries": {"topic_blacklist": ["医疗建议", "法律咨询", "政治", "宗教"]}},
        }
        for (low, high), mapping in boundary_mappings.items():
            if low <= boundary <= high:
                if "boundaries" in mapping:
                    for k, v in mapping["boundaries"].items():
                        params["boundaries"][k] = v
                break
        
        # 7. 原谅速度映射
        forgiveness = answers.get("forgiveness_speed", 5)
        forgiveness_mappings = {
            (0, 3): {"emotion": {"trust_recovery_rate": 0.2, "trust_decay_rate": 0.3}},
            (4, 6): {"emotion": {"trust_recovery_rate": 0.5}},
            (7, 10): {"emotion": {"trust_recovery_rate": 0.8}},
        }
        for (low, high), mapping in forgiveness_mappings.items():
            if low <= forgiveness <= high:
                if "emotion" in mapping:
                    for k, v in mapping["emotion"].items():
                        params["emotion"][k] = v
                break
        
        # 8. 服务场景
        service_ctx = answers.get("service_context")
        if service_ctx and service_ctx in self.service_context_mappings:
            mapping = self.service_context_mappings[service_ctx]
            if "speech" in mapping:
                for k, v in mapping["speech"].items():
                    params["speech"][k] = v
            if "stats" in mapping:
                for k, v in mapping["stats"].items():
                    params["stats"][k] = v
        
        # 9. 特殊功能
        special = answers.get("special_features", [])
        if "progress_report" in special:
            params["features"] = params.get("features", {})
            params["features"]["progress_report"] = True
        if "adaptive_difficulty" in special:
            params["features"] = params.get("features", {})
            params["features"]["adaptive_difficulty"] = True
        if "silence" in special:
            params["features"] = params.get("features", {})
            params["features"]["silence_enabled"] = True
        
        # 10. 亲密关系影响信任度
        intimacy = answers.get("intimacy")
        if intimacy is not None:
            params["emotion"]["base"]["trust"] = 0.3 + (intimacy / 10) * 0.5
        
        # 11. 设置名称和描述
        params["identity"]["name"] = answers.get("name", "新人格")
        params["identity"]["description"] = f"通过动态问卷创建的{params['personality_type']['type']}人格"
        
        # 12. 口头禅
        catchphrases = answers.get("catchphrases", "")
        if catchphrases:
            params["speech"]["catchphrases"] = [c.strip() for c in catchphrases.split(",") if c.strip()]
        
        return sanitize_params(params)
    
    def _create_base_params(self) -> Dict[str, Any]:
        """创建基础参数模板"""
        return {
            "version": "2.0",
            "created_at": datetime.now().isoformat(),
            "identity": {
                "name": "",
                "description": "",
                "age": 25,
                "gender": "neutral"
            },
            "personality_type": {
                "type": "independent",
                "service_ratio": 0.0
            },
            "stats": {
                "int": 1.0,
                "eq": 1.0,
                "con": 1.0
            },
            "emotion": {
                "base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4},
                "sensitivity": {"pleasure": 1.0, "trust": 1.0},
                "trust_recovery_rate": 0.5,
                "trust_decay_rate": 0.1
            },
            "speech": {
                "style": "normal",
                "min_length": 10,
                "max_length": 90,
                "temperature": 0.7,
                "catchphrases": []
            },
            "boundaries": {
                "reject_when": [],
                "silence_when": [],
                "topic_blacklist": []
            },
            "silence": {
                "frequency": 0
            },
            "features": {}
        }


def sanitize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """清理和修正参数 - 只修正超出范围的值，范围内的值保持不变"""
    
    # 处理 stats - 只修正超出 [0.3, 1.5] 范围的值
    if "stats" in params:
        for stat in ["int", "eq", "con"]:
            if stat in params["stats"]:
                value = params["stats"][stat]
                if value < 0.3:
                    params["stats"][stat] = 0.3
                elif value > 1.5:
                    params["stats"][stat] = 1.5
                # 范围内的值（如 0.8, 1.2）保持不变
    
    # 处理 emotion.base - 只修正超出 [0.0, 1.0] 范围的值
    if "emotion" in params:
        if "base" in params["emotion"]:
            for dim in ["pleasure", "activation", "trust"]:
                if dim in params["emotion"]["base"]:
                    value = params["emotion"]["base"][dim]
                    if value < 0.0:
                        params["emotion"]["base"][dim] = 0.0
                    elif value > 1.0:
                        params["emotion"]["base"][dim] = 1.0
        
        # 处理 emotion.sensitivity - 只修正超出 [0.3, 1.5] 范围的值
        if "sensitivity" in params["emotion"]:
            for sens in ["pleasure", "trust"]:
                if sens in params["emotion"]["sensitivity"]:
                    value = params["emotion"]["sensitivity"][sens]
                    if value < 0.3:
                        params["emotion"]["sensitivity"][sens] = 0.3
                    elif value > 1.5:
                        params["emotion"]["sensitivity"][sens] = 1.5
        
        # 处理 emotion.trust_recovery_rate - 只修正超出 [0.1, 1.0] 范围的值
        if "trust_recovery_rate" in params["emotion"]:
            value = params["emotion"]["trust_recovery_rate"]
            if value < 0.1:
                params["emotion"]["trust_recovery_rate"] = 0.1
            elif value > 1.0:
                params["emotion"]["trust_recovery_rate"] = 1.0
        
        # 处理 emotion.trust_decay_rate - 只修正超出 [0.05, 0.5] 范围的值
        if "trust_decay_rate" in params["emotion"]:
            value = params["emotion"]["trust_decay_rate"]
            if value < 0.05:
                params["emotion"]["trust_decay_rate"] = 0.05
            elif value > 0.5:
                params["emotion"]["trust_decay_rate"] = 0.5
    
    # 处理 speech - 只修正超出范围的值
    if "speech" in params:
        # temperature 范围 [0.0, 2.0]
        if "temperature" in params["speech"]:
            temp = params["speech"]["temperature"]
            if temp < 0.0:
                params["speech"]["temperature"] = 0.0
            elif temp > 2.0:
                params["speech"]["temperature"] = 2.0
        
        # min_length 范围 [1, 50]
        if "min_length" in params["speech"]:
            val = params["speech"]["min_length"]
            if val < 1:
                params["speech"]["min_length"] = 1
            elif val > 50:
                params["speech"]["min_length"] = 50
        
        # max_length 范围 [10, 500]
        if "max_length" in params["speech"]:
            val = params["speech"]["max_length"]
            if val < 10:
                params["speech"]["max_length"] = 10
            elif val > 500:
                params["speech"]["max_length"] = 500
    
    return params


def create_with_dynamic_questionnaire(
    description: str = None,
    personality_type: str = None,
    interactive: bool = True
) -> Optional[Dict[str, Any]]:
    """
    使用动态问卷创建人格
    
    Args:
        description: 预设描述（会预填部分答案，暂未实现）
        personality_type: 预设人格类型
        interactive: 是否交互式问卷
    """
    # 运行问卷
    q = DynamicQuestionnaire()
    answers = q.run(interactive=interactive)
    
    if not answers or not answers.get("name"):
        print("❌ 未完成问卷")
        return None
    
    # 映射参数
    mapper = DynamicParameterMapper()
    params = mapper.map(answers)
    
    # 覆盖人格类型（如果指定）
    if personality_type and personality_type in ["independent", "service", "mixed"]:
        params["personality_type"]["type"] = personality_type
        if personality_type == "service":
            params["personality_type"]["service_ratio"] = 1.0
        elif personality_type == "independent":
            params["personality_type"]["service_ratio"] = 0.0
        else:
            params["personality_type"]["service_ratio"] = 0.5
    
    # 添加元数据
    params["metadata"] = {
        "creation_mode": "dynamic_questionnaire_v2",
        "description": description or "",
        "original_answers": {k: v for k, v in answers.items() if k != "name"}
    }
    
    # 添加签名
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 清理参数
    params = sanitize_params(params)
    
    # 保存
    name = answers.get("name", "新人格")
    data_dir = f"./data/personas/{name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], params["personality_type"]["type"])
    memory_path = os.path.join(data_dir, f"{name}.memory")
    save_memory_file(memory, memory_path)
    
    print(f"\n✅ 人格 '{name}' 创建成功!")
    print(f"   类型: {params['personality_type']['type']}")
    print(f"   运行: amber run {name}")
    
    return {"name": name, "params": params}


# 导出别名供测试 mock 使用
save_memory = save_memory_file