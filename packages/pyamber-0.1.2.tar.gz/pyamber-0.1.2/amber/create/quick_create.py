"""
快速创建 - 纯AI推断，无需确认
"""

import re
from typing import Dict, Any, Optional
from datetime import datetime
import os
from pathlib import Path

from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory as save_memory_file
from amber.create.validators import sanitize_params


# 导出别名供测试 mock 使用
save_memory = save_memory_file


def check_persona_exists(name: str, data_dir: str = "./data/personas") -> bool:
    """
    检查人格是否已存在
    
    Args:
        name: 人格名称
        data_dir: 数据目录
        
    Returns:
        True 如果存在，False 如果不存在
    """
    persona_dir = Path(data_dir) / name
    amber_file = persona_dir / f"{name}.amber"
    return amber_file.exists()


def get_unique_name(base_name: str, data_dir: str = "./data/personas") -> str:
    """
    获取唯一的人格名称（如果已存在则添加数字后缀）
    
    Args:
        base_name: 基础名称
        data_dir: 数据目录
        
    Returns:
        唯一的人格名称
    """
    if not check_persona_exists(base_name, data_dir):
        return base_name
    
    counter = 1
    while True:
        new_name = f"{base_name}_{counter}"
        if not check_persona_exists(new_name, data_dir):
            return new_name
        counter += 1


def rename_persona(old_name: str, new_name: str, data_dir: str = "./data/personas") -> bool:
    """
    重命名人格
    
    Args:
        old_name: 旧名称
        new_name: 新名称
        data_dir: 数据目录
        
    Returns:
        是否成功
    """
    import yaml
    import shutil
    
    old_dir = Path(data_dir) / old_name
    new_dir = Path(data_dir) / new_name
    
    if not old_dir.exists():
        print(f"❌ 人格 '{old_name}' 不存在")
        return False
    
    if new_dir.exists():
        print(f"❌ 人格 '{new_name}' 已存在")
        return False
    
    try:
        # 重命名目录
        old_dir.rename(new_dir)
        
        # 重命名内部文件
        amber_file = new_dir / f"{old_name}.amber"
        memory_file = new_dir / f"{old_name}.memory"
        
        if amber_file.exists():
            amber_file.rename(new_dir / f"{new_name}.amber")
        if memory_file.exists():
            memory_file.rename(new_dir / f"{new_name}.memory")
        
        # 修改参数文件中的名称
        new_amber_file = new_dir / f"{new_name}.amber"
        if new_amber_file.exists():
            with open(new_amber_file, 'r', encoding='utf-8') as f:
                params = yaml.safe_load(f)
            params["identity"]["name"] = new_name
            with open(new_amber_file, 'w', encoding='utf-8') as f:
                yaml.dump(params, f, allow_unicode=True, default_flow_style=False)
        
        print(f"✅ 人格已重命名: {old_name} → {new_name}")
        return True
        
    except Exception as e:
        print(f"❌ 重命名失败: {e}")
        return False


def generate_quick_name(description: str, preferred_name: str = None) -> str:
    """
    快速生成名称
    
    Args:
        description: 描述文本
        preferred_name: 优先使用的名称
        
    Returns:
        生成的名称
    """
    # 优先使用指定的名称
    if preferred_name:
        return preferred_name
    
    # 先检查关键词匹配（优先级更高）
    name_map = {
        "咖啡": "林夏",
        "温柔": "小暖", 
        "面试": "张老师",
        "英语": "Ms. Wang",
        "老师": "王老师",
        "傲娇": "浅浅",
        "助手": "小助",
        "客服": "客服小安",
    }
    
    for keyword, name in name_map.items():
        if keyword in description:
            return name
    
    # 常见姓氏列表
    common_surnames = [
        "林", "李", "王", "张", "刘", "陈", "杨", "赵", "黄", "周",
        "吴", "徐", "孙", "马", "朱", "胡", "郭", "何", "高", "郑",
        "罗", "梁", "谢", "宋", "唐", "邓", "肖", "冯", "韩", "曹",
        "彭", "曾", "蔡", "魏", "苏", "卢", "蒋", "余", "杜", "戴"
    ]
    
    # 先尝试匹配有常见姓氏的2-3字词（更像真实人名）
    for surname in common_surnames:
        pattern = rf'{surname}[\u4e00-\u9fa5]{{1,2}}'
        matches = re.findall(pattern, description)
        if matches:
            return matches[0]
    
    # 然后尝试匹配2-3字的中文词，排除常见的非名字词
    name_pattern = r'[\u4e00-\u9fa5]{2,3}'
    matches = re.findall(name_pattern, description)
    
    # 常见的非名字词汇（排除集）
    exclude_words = {
        # 性格描述
        "温柔", "活泼", "开朗", "阳光", "热情", "乐于助人", 
        "喜欢", "说话", "语气词", "可爱", "小迷糊", "懂事",
        "快乐", "开心", "美丽", "漂亮", "聪明", "幽默",
        "严肃", "认真", "负责", "耐心", "体贴", "真诚",
        # 职业/身份
        "面试", "英语", "老师", "傲娇", "助手", "客服",
        "咖啡店", "奶茶店", "便利店", "小吃店", "餐厅",
        "学姐", "学长", "同学", "朋友", "女孩", "男生", "女生",
        "老板", "员工", "经理", "主管", "总监",
        # 无意义词
        "一个", "这个", "那个", "什么", "怎么", "为什么",
        "可以", "能够", "应该", "需要", "想要", "希望",
        "未知描", "新人格", "默认名", "无名氏", "测试用",
        "描述", "角色", "人物", "名称", "名字", "叫做",
        "称为", "名叫", "名为", "即是", "就是", "作为",
    }
    
    for match in matches:
        # 检查是否是有效的名字
        if match in exclude_words:
            continue
        # 检查是否以常见非名字词结尾
        if match.endswith(("描述", "角色", "人物", "名称", "名字")):
            continue
        # 检查是否以常见后缀开头
        if match.startswith(("一个", "这个", "那个")):
            continue
        return match
    
    return "新人格"


def generate_quick_params(description: str, 
                          personality_type: str,
                          service_ratio: float) -> Dict[str, Any]:
    """快速生成参数"""
    
    params = {
        "identity": {
            "name": "",
            "description": description,
            "age": 25,
            "gender": "neutral"
        },
        "personality_type": {
            "type": personality_type,
            "service_ratio": service_ratio if personality_type == "mixed" else (0.0 if personality_type == "independent" else 1.0)
        },
        "stats": {
            "int": 1.0,
            "eq": 1.0,
            "con": 1.0
        },
        "emotion": {
            "base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4},
            "sensitivity": {"pleasure": 1.0, "trust": 1.0}
        },
        "speech": {
            "style": "normal",
            "min_length": 10,
            "max_length": 90,
            "temperature": 0.7,
            "catchphrases": []
        },
        "boundaries": {
            "reject_when": ["被连续否定3次"],
            "silence_when": ["被凶", "被问隐私"],
            "topic_blacklist": ["医疗建议", "法律咨询"]
        }
    }
    
    # 根据描述调整参数
    if "温柔" in description:
        params["stats"]["eq"] = 1.2
        params["emotion"]["base"]["pleasure"] = 0.4
        params["speech"]["temperature"] = 0.6
    
    if "傲娇" in description:
        params["stats"]["eq"] = 0.8
        params["emotion"]["base"]["pleasure"] = 0.2
        params["speech"]["style"] = "tsundere"
        params["boundaries"]["silence_when"].append("被夸")
    
    if "面试" in description:
        params["stats"]["int"] = 1.3
        params["stats"]["eq"] = 0.8
        params["speech"]["style"] = "professional"
        params["speech"]["temperature"] = 0.6
        params["boundaries"]["topic_blacklist"] = ["闲聊", "天气"]
    
    if "英语" in description or "老师" in description:
        params["stats"]["int"] = 1.2
        params["stats"]["eq"] = 1.1
        params["speech"]["style"] = "patient"
        params["speech"]["temperature"] = 0.65
    
    if "客服" in description:
        params["stats"]["eq"] = 1.2
        params["speech"]["style"] = "polite"
        params["speech"]["temperature"] = 0.6
    
    if "导师" in description or "教练" in description:
        params["stats"]["int"] = 1.15
        params["stats"]["eq"] = 1.2
        params["speech"]["style"] = "supportive"
    
    # 活泼开朗相关调整
    if "活泼" in description or "开朗" in description:
        params["stats"]["eq"] = 1.1
        params["emotion"]["base"]["pleasure"] = 0.5
        params["emotion"]["base"]["activation"] = 0.6
        params["speech"]["temperature"] = 0.8
    
    return params


def quick_create(description: str, 
                 personality_type: str = "independent",
                 service_ratio: float = 0.5,
                 name: str = None,
                 auto_rename: bool = True) -> Optional[Dict[str, Any]]:
    """
    快速创建人格 - 5秒生成
    
    Args:
        description: 用户描述
        personality_type: 人格类型
        service_ratio: 服务比例
        name: 指定人格名称（可选）
        auto_rename: 如果名称已存在，是否自动添加数字后缀
        
    Returns:
        创建结果
    """
    print(f"⚡ 快速生成中...")
    
    # 生成名称
    base_name = generate_quick_name(description, name)
    
    # 检查名称是否已存在
    if check_persona_exists(base_name):
        print(f"⚠️ 人格 '{base_name}' 已存在")
        if auto_rename:
            final_name = get_unique_name(base_name)
            print(f"   自动重命名为: {final_name}")
        else:
            user_input = input(f"是否覆盖？(y/n，输入新名称直接回车): ").strip()
            if user_input.lower() == 'y':
                final_name = base_name
                # 删除已存在的人格
                import shutil
                shutil.rmtree(f"./data/personas/{base_name}")
                print(f"   已覆盖原人格")
            elif user_input:
                final_name = user_input
            else:
                print("❌ 创建取消")
                return None
    else:
        final_name = base_name
    
    # 基于描述快速生成参数
    params = generate_quick_params(description, personality_type, service_ratio)
    params["identity"]["name"] = final_name
    
    # 添加元数据
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "quick",
        "original_description": description
    }
    
    # 添加签名
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 清理参数
    params = sanitize_params(params)
    
    # 保存
    data_dir = f"./data/personas/{final_name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{final_name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], personality_type)
    memory_path = os.path.join(data_dir, f"{final_name}.memory")
    save_memory_file(memory, memory_path)
    
    print(f"✅ 人格 '{final_name}' 创建成功! (快速模式)")
    
    return {"name": final_name, "params": params}