"""
数字签名（生成/验证）
"""

import hashlib
import json
import base64
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.serialization import load_pem_private_key, load_pem_public_key


class SignatureManager:
    """签名管理器"""
    
    @staticmethod
    def sign(data: Dict[str, Any], private_key_pem: str) -> str:
        """
        对数据进行签名
        
        Args:
            data: 要签名的数据
            private_key_pem: PEM格式的私钥
            
        Returns:
            Base64编码的签名
        """
        # 计算数据哈希
        data_str = json.dumps(data, sort_keys=True)
        data_hash = hashlib.sha256(data_str.encode()).digest()
        
        # 加载私钥
        private_key = load_pem_private_key(private_key_pem.encode(), password=None)
        
        # 签名
        signature = private_key.sign(
            data_hash,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        
        return base64.b64encode(signature).decode()
    
    @staticmethod
    def verify(data: Dict[str, Any], signature: str, public_key_pem: str) -> bool:
        """
        验证签名
        
        Args:
            data: 原始数据
            signature: Base64编码的签名
            public_key_pem: PEM格式的公钥
            
        Returns:
            是否有效
        """
        try:
            # 计算数据哈希
            data_str = json.dumps(data, sort_keys=True)
            data_hash = hashlib.sha256(data_str.encode()).digest()
            
            # 加载公钥
            public_key = load_pem_public_key(public_key_pem.encode())
            
            # 验证签名
            public_key.verify(
                base64.b64decode(signature),
                data_hash,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            return True
        except Exception:
            return False
    
    @staticmethod
    def add_signature_to_persona(persona_data: Dict[str, Any], 
                                  creator_id: str,
                                  private_key_pem: str) -> Dict[str, Any]:
        """
        为人格添加签名
        
        Args:
            persona_data: 人格数据
            creator_id: 创作者ID
            private_key_pem: 私钥
            
        Returns:
            添加签名后的人格数据
        """
        # 创建签名数据（不包含签名本身）
        data_to_sign = {
            "creator_id": creator_id,
            "created_at": persona_data.get("created_at", datetime.now().isoformat()),
            "name": persona_data.get("identity", {}).get("name"),
            "version": persona_data.get("version", "1.0")
        }
        
        signature = SignatureManager.sign(data_to_sign, private_key_pem)
        
        if "signature" not in persona_data:
            persona_data["signature"] = {}
        
        persona_data["signature"]["creator_id"] = creator_id
        persona_data["signature"]["signature"] = signature
        persona_data["signature"]["signed_at"] = datetime.now().isoformat()
        
        return persona_data


def sign_persona(persona_data: Dict[str, Any], creator_id: str, private_key_pem: str) -> Dict[str, Any]:
    """为人格添加签名"""
    return SignatureManager.add_signature_to_persona(persona_data, creator_id, private_key_pem)


def verify_signature(persona_data: Dict[str, Any], public_key_pem: str) -> bool:
    """验证人格签名"""
    signature = persona_data.get("signature", {}).get("signature")
    creator_id = persona_data.get("signature", {}).get("creator_id")
    
    if not signature or not creator_id:
        return False
    
    data_to_verify = {
        "creator_id": creator_id,
        "created_at": persona_data.get("signature", {}).get("signed_at"),
        "name": persona_data.get("identity", {}).get("name"),
        "version": persona_data.get("version", "1.0")
    }
    
    return SignatureManager.verify(data_to_verify, signature, public_key_pem)
