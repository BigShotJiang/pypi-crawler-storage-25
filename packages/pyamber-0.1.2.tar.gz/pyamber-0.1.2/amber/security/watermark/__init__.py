"""
Watermark module - 水印系统
"""

from amber.security.watermark.visible import VisibleWatermark
from amber.security.watermark.invisible import InvisibleWatermark
from amber.security.watermark.steganographic import SteganographicWatermark

__all__ = [
    "VisibleWatermark",
    "InvisibleWatermark",
    "SteganographicWatermark",
]
