"""
可见水印
"""

from typing import Dict, Any


class VisibleWatermark:
    """可见水印 - 直接添加到人格描述中"""
    
    @staticmethod
    def add(data: Dict[str, Any], creator_id: str) -> Dict[str, Any]:
        """
        添加可见水印
        
        Args:
            data: 人格数据
            creator_id: 创作者ID
            
        Returns:
            添加水印后的数据
        """
        watermark_text = f"Created by {creator_id}"
        
        # 添加到描述中
        if "identity" not in data:
            data["identity"] = {}
        
        original_desc = data["identity"].get("description", "")
        data["identity"]["description"] = f"{watermark_text}\n{original_desc}"
        
        # 记录水印
        if "watermark" not in data:
            data["watermark"] = {}
        data["watermark"]["visible"] = watermark_text
        
        return data
    
    @staticmethod
    def extract(data: Dict[str, Any]) -> str:
        """提取可见水印"""
        watermark = data.get("watermark", {}).get("visible", "")
        if watermark:
            return watermark
        
        # 从描述中查找
        desc = data.get("identity", {}).get("description", "")
        if desc.startswith("Created by "):
            lines = desc.split('\n')
            if lines:
                return lines[0]
        
        return ""
    
    @staticmethod
    def remove(data: Dict[str, Any]) -> Dict[str, Any]:
        """移除可见水印（不推荐，用于测试）"""
        if "watermark" in data:
            data["watermark"].pop("visible", None)
        
        desc = data.get("identity", {}).get("description", "")
        if desc.startswith("Created by "):
            lines = desc.split('\n')
            if len(lines) > 1:
                data["identity"]["description"] = '\n'.join(lines[1:])
        
        return data
