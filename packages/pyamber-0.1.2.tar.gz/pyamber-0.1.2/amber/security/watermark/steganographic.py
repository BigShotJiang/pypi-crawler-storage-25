"""
隐写水印（参数微小偏差）
"""

from typing import Dict, Any, List
import hashlib


class SteganographicWatermark:
    """隐写水印 - 嵌入到参数微小偏差中"""
    
    @staticmethod
    def add(data: Dict[str, Any], creator_id: str) -> Dict[str, Any]:
        """
        添加隐写水印
        
        Args:
            data: 人格数据
            creator_id: 创作者ID
            
        Returns:
            添加水印后的数据
        """
        # 生成水印特征
        watermark_hash = hashlib.sha256(f"{creator_id}_stego".encode()).hexdigest()
        
        # 将水印嵌入到参数中（微小偏差）
        if "stats" in data:
            # 在第四位小数嵌入水印信息
            for key in ["int", "eq", "con"]:
                if key in data["stats"]:
                    original = data["stats"][key]
                    # 添加微小偏差（0.0001 - 0.0009）
                    deviation = (int(watermark_hash[0:2], 16) % 9 + 1) / 10000
                    data["stats"][key] = original + deviation
        
        if "watermark" not in data:
            data["watermark"] = {}
        data["watermark"]["steganographic"] = {
            "hash": watermark_hash[:16],
            "embedded_at": None
        }
        
        return data
    
    @staticmethod
    def extract(data: Dict[str, Any]) -> Dict[str, Any]:
        """提取隐写水印"""
        return data.get("watermark", {}).get("steganographic", {})
    
    @staticmethod
    def detect(data: Dict[str, Any]) -> bool:
        """检测是否存在隐写水印"""
        return "steganographic" in data.get("watermark", {})
    
    @staticmethod
    def get_deviation(data: Dict[str, Any], key: str) -> float:
        """获取参数的偏差值"""
        if "stats" not in data or key not in data["stats"]:
            return 0.0
        
        value = data["stats"][key]
        # 提取小数部分
        fractional = value - int(value)
        # 获取第五位小数
        deviation = round((fractional * 10000) % 10) / 100000
        
        return deviation
