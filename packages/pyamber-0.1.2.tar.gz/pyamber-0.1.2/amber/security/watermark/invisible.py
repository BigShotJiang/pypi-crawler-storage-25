"""
不可见水印（元数据）
"""

from typing import Dict, Any
import hashlib


class InvisibleWatermark:
    """不可见水印 - 存储在元数据中"""
    
    @staticmethod
    def add(data: Dict[str, Any], creator_id: str, timestamp: str = None) -> Dict[str, Any]:
        """
        添加不可见水印
        
        Args:
            data: 人格数据
            creator_id: 创作者ID
            timestamp: 时间戳
            
        Returns:
            添加水印后的数据
        """
        import datetime
        if not timestamp:
            timestamp = datetime.datetime.now().isoformat()
        
        watermark_data = {
            "creator_id": creator_id,
            "created_at": timestamp,
            "watermark_id": hashlib.md5(f"{creator_id}{timestamp}".encode()).hexdigest()[:16]
        }
        
        if "watermark" not in data:
            data["watermark"] = {}
        
        data["watermark"]["invisible"] = watermark_data
        
        return data
    
    @staticmethod
    def extract(data: Dict[str, Any]) -> Dict[str, Any]:
        """提取不可见水印"""
        return data.get("watermark", {}).get("invisible", {})
    
    @staticmethod
    def verify(data: Dict[str, Any], expected_creator: str) -> bool:
        """验证水印"""
        watermark = InvisibleWatermark.extract(data)
        return watermark.get("creator_id") == expected_creator
