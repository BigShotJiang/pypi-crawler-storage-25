"""
举报系统
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional


class Reporter:
    """举报管理器"""
    
    REPORT_FILE = "./data/reports.json"
    
    @classmethod
    def report(cls, target: str, reporter: str, reason: str, 
               evidence: str = "") -> int:
        """
        提交举报
        
        Args:
            target: 被举报人格
            reporter: 举报人
            reason: 举报原因
            evidence: 证据描述
            
        Returns:
            举报ID
        """
        reports = cls._load_reports()
        
        report_id = len(reports) + 1
        
        report = {
            "id": report_id,
            "target": target,
            "reporter": reporter,
            "reason": reason,
            "evidence": evidence,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "resolved_at": None,
            "resolution": None
        }
        
        reports.append(report)
        cls._save_reports(reports)
        
        print(f"✅ 举报已提交，ID: {report_id}")
        return report_id
    
    @classmethod
    def resolve(cls, report_id: int, resolver: str, 
                resolution: str, action: str) -> bool:
        """
        处理举报
        
        Args:
            report_id: 举报ID
            resolver: 处理人
            resolution: 处理结果
            action: 采取的行动
            
        Returns:
            是否成功
        """
        reports = cls._load_reports()
        
        for report in reports:
            if report.get("id") == report_id:
                report["status"] = "resolved"
                report["resolved_at"] = datetime.now().isoformat()
                report["resolver"] = resolver
                report["resolution"] = resolution
                report["action"] = action
                
                cls._save_reports(reports)
                print(f"✅ 举报 #{report_id} 已处理")
                
                # 如果确认侵权，执行下架
                if action == "remove":
                    cls._remove_persona(report["target"])
                
                return True
        
        return False
    
    @classmethod
    def _load_reports(cls) -> List[Dict]:
        """加载举报记录"""
        if not Path(cls.REPORT_FILE).exists():
            return []
        
        with open(cls.REPORT_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @classmethod
    def _save_reports(cls, reports: List[Dict]):
        """保存举报记录"""
        Path("./data").mkdir(exist_ok=True)
        with open(cls.REPORT_FILE, 'w', encoding='utf-8') as f:
            json.dump(reports, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def _remove_persona(cls, name: str):
        """下架人格"""
        import shutil
        persona_dir = Path(f"./data/personas/{name}")
        
        if persona_dir.exists():
            # 移动到隔离区
            quarantine_dir = Path("./data/quarantine")
            quarantine_dir.mkdir(exist_ok=True)
            shutil.move(str(persona_dir), str(quarantine_dir / f"{name}_{datetime.now().strftime('%Y%m%d')}"))
            print(f"📦 人格 '{name}' 已下架并移入隔离区")


def report_infringement(target: str, reporter: str, reason: str, evidence: str = "") -> int:
    """举报侵权"""
    return Reporter.report(target, reporter, reason, evidence)


def resolve_report(report_id: int, resolver: str, resolution: str, action: str) -> bool:
    """处理举报"""
    return Reporter.resolve(report_id, resolver, resolution, action)
