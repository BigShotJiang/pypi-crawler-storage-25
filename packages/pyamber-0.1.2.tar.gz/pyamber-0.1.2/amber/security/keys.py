"""
密钥对管理（生成/存储/加载）
"""

import os
from pathlib import Path
from typing import Tuple, Optional
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization


class KeyManager:
    """密钥管理器"""
    
    DEFAULT_KEY_DIR = os.path.expanduser("~/.amber/keys")
    
    @classmethod
    def generate_key_pair(cls, key_name: str = "default", 
                          key_size: int = 2048,
                          password: Optional[str] = None) -> Tuple[str, str]:
        """
        生成RSA密钥对
        
        Args:
            key_name: 密钥名称
            key_size: 密钥大小
            password: 私钥密码（可选）
            
        Returns:
            (公钥PEM, 私钥PEM)
        """
        # 生成私钥
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size
        )
        
        # 生成公钥
        public_key = private_key.public_key()
        
        # 序列化私钥
        encryption = serialization.BestAvailableEncryption(password.encode()) if password else serialization.NoEncryption()
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=encryption
        )
        
        # 序列化公钥
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return public_pem.decode(), private_pem.decode()
    
    @classmethod
    def save_key_pair(cls, key_name: str, public_pem: str, private_pem: str):
        """保存密钥对"""
        key_dir = Path(cls.DEFAULT_KEY_DIR)
        key_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存公钥
        public_path = key_dir / f"{key_name}.pub"
        with open(public_path, 'w') as f:
            f.write(public_pem)
        
        # 保存私钥（权限限制）
        private_path = key_dir / f"{key_name}.key"
        with open(private_path, 'w') as f:
            f.write(private_pem)
        os.chmod(private_path, 0o600)
        
        print(f"✅ 密钥对已保存: {key_dir}/{key_name}")
    
    @classmethod
    def load_public_key(cls, key_name: str = "default") -> Optional[str]:
        """加载公钥"""
        key_path = Path(cls.DEFAULT_KEY_DIR) / f"{key_name}.pub"
        if not key_path.exists():
            return None
        
        with open(key_path, 'r') as f:
            return f.read()
    
    @classmethod
    def load_private_key(cls, key_name: str = "default") -> Optional[str]:
        """加载私钥"""
        key_path = Path(cls.DEFAULT_KEY_DIR) / f"{key_name}.key"
        if not key_path.exists():
            return None
        
        with open(key_path, 'r') as f:
            return f.read()


def generate_key_pair(key_name: str = "default", password: Optional[str] = None) -> Tuple[str, str]:
    """生成密钥对"""
    return KeyManager.generate_key_pair(key_name, password=password)


def save_key_pair(key_name: str, public_pem: str, private_pem: str):
    """保存密钥对"""
    KeyManager.save_key_pair(key_name, public_pem, private_pem)
