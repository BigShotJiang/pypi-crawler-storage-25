"""
声誉系统
"""

import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional


class ReputationSystem:
    """声誉系统"""
    
    REPUTATION_FILE = "./data/reputations.json"
    
    # 评分规则
    RULES = {
        "upload_original": 10,
        "upload_original_verified": 20,
        "persona_downloaded": 1,
        "persona_forked": 2,
        "pr_merged": 5,
        "report_filed": -1,
        "confirmed_infringement": -50,
        "multiple_infringement": -100,
    }
    
    @classmethod
    def get_score(cls, user_id: str) -> int:
        """获取用户声誉分数"""
        reputations = cls._load_reputations()
        
        if user_id not in reputations:
            return 0
        
        return reputations[user_id].get("score", 0)
    
    @classmethod
    def update_score(cls, user_id: str, action: str, amount: int = None) -> int:
        """
        更新声誉分数
        
        Args:
            user_id: 用户ID
            action: 操作类型
            amount: 自定义分数（可选）
            
        Returns:
            新分数
        """
        reputations = cls._load_reputations()
        
        if user_id not in reputations:
            reputations[user_id] = {
                "score": 0,
                "history": [],
                "created_at": datetime.now().isoformat()
            }
        
        delta = amount or cls.RULES.get(action, 0)
        reputations[user_id]["score"] += delta
        reputations[user_id]["history"].append({
            "action": action,
            "delta": delta,
            "timestamp": datetime.now().isoformat()
        })
        
        # 限制范围
        reputations[user_id]["score"] = max(-100, min(1000, reputations[user_id]["score"]))
        
        cls._save_reputations(reputations)
        
        return reputations[user_id]["score"]
    
    @classmethod
    def get_level(cls, user_id: str) -> str:
        """获取声誉等级"""
        score = cls.get_score(user_id)
        
        if score >= 100:
            return "大师"
        elif score >= 50:
            return "专家"
        elif score >= 20:
            return "资深"
        elif score >= 0:
            return "普通"
        elif score >= -50:
            return "警告"
        else:
            return "受限"
    
    @classmethod
    def is_banned(cls, user_id: str) -> bool:
        """是否被禁止"""
        score = cls.get_score(user_id)
        return score <= -100
    
    @classmethod
    def _load_reputations(cls) -> Dict:
        """加载声誉数据"""
        if not Path(cls.REPUTATION_FILE).exists():
            return {}
        
        with open(cls.REPUTATION_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @classmethod
    def _save_reputations(cls, reputations: Dict):
        """保存声誉数据"""
        Path("./data").mkdir(exist_ok=True)
        with open(cls.REPUTATION_FILE, 'w', encoding='utf-8') as f:
            json.dump(reputations, f, ensure_ascii=False, indent=2)


def get_reputation_score(user_id: str) -> int:
    """获取声誉分数"""
    return ReputationSystem.get_score(user_id)


def update_reputation(user_id: str, action: str) -> int:
    """更新声誉"""
    return ReputationSystem.update_score(user_id, action)
