"""
Security module - 安全与版权保护
"""

from amber.security.signature import SignatureManager, sign_persona, verify_signature
from amber.security.keys import KeyManager, generate_key_pair
from amber.security.watermark.visible import VisibleWatermark
from amber.security.watermark.invisible import InvisibleWatermark
from amber.security.watermark.steganographic import SteganographicWatermark
from amber.security.detector import PlagiarismDetector, detect_plagiarism
from amber.security.reporter import Reporter, report_infringement
from amber.security.reputation import ReputationSystem

__all__ = [
    "SignatureManager",
    "sign_persona",
    "verify_signature",
    "KeyManager",
    "generate_key_pair",
    "VisibleWatermark",
    "InvisibleWatermark",
    "SteganographicWatermark",
    "PlagiarismDetector",
    "detect_plagiarism",
    "Reporter",
    "report_infringement",
    "ReputationSystem",
]
