"""
盗版检测（相似度/特征提取）
"""

import yaml
import json
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
from difflib import SequenceMatcher


class PlagiarismDetector:
    """盗版检测器"""
    
    @staticmethod
    def compare(persona1_path: str, persona2_path: str) -> float:
        """
        比较两个人格的相似度
        
        Args:
            persona1_path: 第一个人格路径
            persona2_path: 第二个人格路径
            
        Returns:
            相似度 (0-1)
        """
        data1 = PlagiarismDetector._load_persona(persona1_path)
        data2 = PlagiarismDetector._load_persona(persona2_path)
        
        if not data1 or not data2:
            return 0.0
        
        weights = {
            "identity": 0.2,
            "stats": 0.2,
            "speech": 0.2,
            "boundaries": 0.2,
            "emotion": 0.2
        }
        
        total_similarity = 0.0
        
        for field, weight in weights.items():
            sim = PlagiarismDetector._compare_field(data1.get(field, {}), data2.get(field, {}))
            total_similarity += sim * weight
        
        return total_similarity
    
    @staticmethod
    def _load_persona(path: str) -> Optional[Dict]:
        """加载人格数据"""
        path_obj = Path(path)
        
        if path_obj.is_dir():
            amber_file = path_obj / f"{path_obj.name}.amber"
            if amber_file.exists():
                with open(amber_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
        elif path_obj.exists():
            with open(path_obj, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        
        return None
    
    @staticmethod
    def _compare_field(field1: Dict, field2: Dict) -> float:
        """比较字段"""
        if not field1 and not field2:
            return 1.0
        if not field1 or not field2:
            return 0.0
        
        str1 = json.dumps(field1, sort_keys=True)
        str2 = json.dumps(field2, sort_keys=True)
        
        return SequenceMatcher(None, str1, str2).ratio()
    
    @staticmethod
    def find_similar(source: str, threshold: float = 0.8) -> List[Tuple[str, float]]:
        """
        查找相似人格
        
        Args:
            source: 源人格
            threshold: 相似度阈值
            
        Returns:
            相似人格列表
        """
        results = []
        personas_dir = Path("./data/personas")
        
        if not personas_dir.exists():
            return results
        
        source_data = PlagiarismDetector._load_persona(source)
        if not source_data:
            return results
        
        for persona_dir in personas_dir.iterdir():
            if not persona_dir.is_dir() or persona_dir.name == source:
                continue
            
            target_data = PlagiarismDetector._load_persona(persona_dir.name)
            if not target_data:
                continue
            
            similarity = PlagiarismDetector._compare_field(source_data, target_data)
            
            if similarity >= threshold:
                results.append((persona_dir.name, similarity))
        
        return sorted(results, key=lambda x: x[1], reverse=True)


def detect_plagiarism(source: str, target: str) -> float:
    """检测盗版相似度"""
    return PlagiarismDetector.compare(source, target)


def find_similar_personas(source: str, threshold: float = 0.8) -> List[Tuple[str, float]]:
    """查找相似人格"""
    return PlagiarismDetector.find_similar(source, threshold)
