"""
服务型人格情绪引擎
"""

from typing import Dict, Any
from amber.core.emotion.engine import EmotionEngine


class ServiceEmotionEngine(EmotionEngine):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.trust_recovery_rate = config.get("trust_recovery_rate", 0.08)
    
    def update(self, effect: Dict[str, float]):
        super().update(effect)
        if effect.get("trust", 0) > 0:
            self.state["trust"] += effect["trust"] * self.trust_recovery_rate
        self.state["trust"] = max(0.2, min(1.0, self.state["trust"]))
    
    def get_service_quality(self) -> str:
        trust = self.state["trust"]
        if trust >= 0.8:
            return "优秀"
        elif trust >= 0.6:
            return "良好"
        elif trust >= 0.4:
            return "一般"
        else:
            return "需改进"
