"""
混合人格情绪引擎
"""

from typing import Dict, Any
from amber.core.emotion.engine import EmotionEngine


class MixedEmotionEngine(EmotionEngine):
    def __init__(self, config: Dict[str, Any], service_ratio: float = 0.5):
        super().__init__(config)
        self.service_ratio = max(0.0, min(1.0, service_ratio))
    
    def update(self, effect: Dict[str, float]):
        adjusted_effect = {k: v * (1 - self.service_ratio * 0.5) for k, v in effect.items()}
        super().update(adjusted_effect)
        if effect.get("trust", 0) < 0:
            self.state["trust"] += effect["trust"] * 0.03 * (1 - self.service_ratio)
        self.state["trust"] = max(0.1, min(1.0, self.state["trust"]))
    
    @property
    def is_service_dominant(self) -> bool:
        return self.service_ratio > 0.5
