"""
情绪触发事件定义
"""

from typing import Dict, Any, List, Tuple


class EmotionTriggers:
    TRIGGERS = {
        "praise": {"pleasure": 0.15, "trust": 0.05, "activation": 0.05},
        "criticism": {"pleasure": -0.2, "trust": -0.1, "activation": 0.1},
        "broken_promise": {"pleasure": -0.25, "trust": -0.2, "activation": -0.05},
        "gift": {"pleasure": 0.2, "trust": 0.1, "activation": 0.1},
        "apology": {"pleasure": 0.05, "trust": 0.08, "activation": -0.05},
        "help": {"pleasure": 0.1, "trust": 0.12, "activation": 0.02},
        "ignore": {"pleasure": -0.1, "trust": -0.05, "activation": -0.1},
        "comfort": {"pleasure": 0.12, "trust": 0.08, "activation": -0.05},
    }
    
    KEYWORDS = {
        "praise": ["好", "棒", "厉害", "优秀", "聪明", "温柔", "可爱"],
        "criticism": ["差", "烂", "笨", "蠢", "讨厌", "烦"],
        "apology": ["抱歉", "对不起", "原谅", "错了"],
        "gift": ["送", "礼物", "给你", "买了"],
        "help": ["帮", "协助", "支持"],
        "ignore": ["不理", "无视", "冷漠"],
        "comfort": ["别难过", "加油", "没事的"],
    }
    
    @classmethod
    def detect(cls, user_input: str) -> List[Tuple[str, Dict[str, float]]]:
        triggers = []
        for trigger, keywords in cls.KEYWORDS.items():
            for keyword in keywords:
                if keyword in user_input:
                    triggers.append((trigger, cls.TRIGGERS.get(trigger, {})))
                    break
        return triggers
    
    @classmethod
    def get_effect(cls, user_input: str) -> Dict[str, float]:
        total_effect = {"pleasure": 0.0, "activation": 0.0, "trust": 0.0}
        for trigger, effect in cls.detect(user_input):
            for key, value in effect.items():
                total_effect[key] += value
        return total_effect
