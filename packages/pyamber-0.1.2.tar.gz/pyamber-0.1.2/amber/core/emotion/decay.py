"""
情绪自然衰减算法
"""

from typing import Dict, Any
from datetime import datetime, timedelta


class EmotionDecay:
    def __init__(self, config: Dict[str, Any]):
        self.decay_rate = config.get("decay_rate", 0.01)
        self.update_interval = timedelta(seconds=config.get("update_interval_seconds", 3600))
    
    def apply_decay(self, emotion_state: Dict[str, float], last_update: datetime) -> Dict[str, float]:
        now = datetime.now()
        if now - last_update < self.update_interval:
            return emotion_state
        
        elapsed_hours = (now - last_update).total_seconds() / 3600
        decay_factor = 1 - (self.decay_rate * elapsed_hours)
        decay_factor = max(0.5, min(1.0, decay_factor))
        
        result = emotion_state.copy()
        result["activation"] = max(0.0, result["activation"] * decay_factor)
        result["pleasure"] = result["pleasure"] * (1 - self.decay_rate * elapsed_hours * 0.3)
        result["pleasure"] = max(-1.0, min(1.0, result["pleasure"]))
        
        return result
