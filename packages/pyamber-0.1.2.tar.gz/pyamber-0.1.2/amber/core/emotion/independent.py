"""
独立人格情绪引擎
"""

from typing import Dict, Any
from amber.core.emotion.engine import EmotionEngine


class IndependentEmotionEngine(EmotionEngine):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.trust_decay_rate = config.get("trust_decay_rate", 0.05)
        self.trust_recovery_rate = config.get("trust_recovery_rate", 0.02)
    
    def update(self, effect: Dict[str, float]):
        super().update(effect)
        if effect.get("trust", 0) < 0:
            self.state["trust"] += effect["trust"] * self.trust_decay_rate
        elif effect.get("trust", 0) > 0:
            self.state["trust"] += effect["trust"] * self.trust_recovery_rate
        self.state["trust"] = max(0.0, min(1.0, self.state["trust"]))
    
    def get_trust_level(self) -> str:
        trust = self.state["trust"]
        if trust >= 0.7:
            return "信赖"
        elif trust >= 0.4:
            return "友好"
        elif trust >= 0.2:
            return "普通"
        else:
            return "疏远"
