"""
Emotion module - 情绪引擎
"""

from amber.core.emotion.engine import EmotionEngine
from amber.core.emotion.independent import IndependentEmotionEngine
from amber.core.emotion.service import ServiceEmotionEngine
from amber.core.emotion.mixed import MixedEmotionEngine
from amber.core.emotion.decay import EmotionDecay
from amber.core.emotion.triggers import EmotionTriggers

__all__ = [
    "EmotionEngine",
    "IndependentEmotionEngine",
    "ServiceEmotionEngine",
    "MixedEmotionEngine",
    "EmotionDecay",
    "EmotionTriggers",
]
