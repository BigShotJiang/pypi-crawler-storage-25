"""
情绪引擎基类
"""

from typing import Dict, Any
from datetime import datetime


class EmotionEngine:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.base = config.get("base", {"pleasure": 0.3, "activation": 0.5, "trust": 0.4})
        self.sensitivity = config.get("sensitivity", {"pleasure": 1.0, "trust": 1.0})
        self.state = self.base.copy()
        self.last_update = datetime.now()
    
    def update(self, effect: Dict[str, float]):
        for key in ["pleasure", "activation", "trust"]:
            if key in effect:
                sensitivity = self.sensitivity.get(key, 1.0)
                delta = effect[key] * sensitivity
                self.state[key] = max(-1.0, min(1.0, self.state[key] + delta))
        self.last_update = datetime.now()
    
    def get_state(self) -> Dict[str, float]:
        return self.state.copy()
    
    def decay(self, factor: float = 0.01):
        self.state["activation"] = max(0.0, self.state["activation"] - factor)
        self.state["pleasure"] = self.state["pleasure"] * (1 - factor * 0.5)
    
    def reset(self):
        self.state = self.base.copy()
