"""
Core module - 人格运行核心
"""

from amber.core.persona import Persona
from amber.core.response import Response

__all__ = ["Persona", "Response"]
