"""
记忆检索（按强度/时间/相关性）
"""

from typing import List, Dict, Any
from datetime import datetime


class MemoryRetrieval:
    def retrieve(self, facts: List[Dict], query: str, limit: int = 5) -> List[Dict]:
        scored = []
        query_lower = query.lower()
        
        for fact in facts:
            score = 0
            content_lower = fact["content"].lower()
            if query_lower in content_lower:
                score += 0.5
            for word in query_lower.split():
                if word in content_lower:
                    score += 0.2
            
            score += fact["strength"] * 0.3
            
            recency_score = self._get_recency_score(fact["last_accessed"])
            score += recency_score * 0.2
            
            scored.append((fact, score))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        return [f for f, _ in scored[:limit]]
    
    def _get_recency_score(self, last_accessed: str) -> float:
        try:
            last = datetime.fromisoformat(last_accessed)
            days = (datetime.now() - last).days
            return max(0.0, 1.0 - days / 30)
        except:
            return 0.5
    
    def retrieve_by_emotion(self, facts: List[Dict], pleasure_threshold: float = 0.3) -> List[Dict]:
        result = []
        for fact in facts:
            if fact.get("emotion_tag", {}).get("pleasure", 0) > pleasure_threshold:
                result.append(fact)
        return result
