"""
情绪层（EmotionalTrace）
"""

from typing import Dict, Any, List
from datetime import datetime


class EmotionalTrace:
    def __init__(self, traces: List[Dict] = None, max_traces: int = 100):
        self.traces = traces or []
        self.max_traces = max_traces
    
    def add(self, event: str, pleasure: float, trust: float):
        trace = {
            "date": datetime.now().isoformat(),
            "event": event,
            "pleasure": pleasure,
            "trust": trust
        }
        self.traces.append(trace)
        
        if len(self.traces) > self.max_traces:
            self.traces = self.traces[-self.max_traces:]
    
    def get_recent(self, count: int = 10) -> List[Dict]:
        return self.traces[-count:]
    
    def get_average_mood(self, days: int = 7) -> float:
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        recent = [t for t in self.traces if datetime.fromisoformat(t["date"]) > cutoff]
        if not recent:
            return 0.0
        return sum(t["pleasure"] for t in recent) / len(recent)
    
    def get_trust_trend(self) -> float:
        if len(self.traces) < 5:
            return 0.0
        recent = self.traces[-10:]
        if len(recent) < 2:
            return 0.0
        old_avg = sum(t["trust"] for t in recent[:5]) / 5
        new_avg = sum(t["trust"] for t in recent[-5:]) / 5
        return new_avg - old_avg
