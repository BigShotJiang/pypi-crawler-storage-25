"""
事实层（Fact记忆）
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import hashlib


class FactMemory:
    def __init__(self, facts: Optional[List[Dict]] = None, max_facts: int = 500):
        self.facts = facts or []
        self.max_facts = max_facts
    
    def add(self, content: str, emotion_tag: Optional[Dict[str, float]] = None):
        fact_id = hashlib.md5(f"{content}{datetime.now().isoformat()}".encode()).hexdigest()[:8]
        fact = {
            "id": f"fact_{fact_id}",
            "content": content,
            "strength": 0.8,
            "created_at": datetime.now().isoformat(),
            "last_accessed": datetime.now().isoformat(),
            "emotion_tag": emotion_tag or {"pleasure": 0.0, "trust": 0.0}
        }
        self.facts.append(fact)
        
        if len(self.facts) > self.max_facts:
            self.facts.sort(key=lambda x: (x["strength"], x["last_accessed"]))
            self.facts = self.facts[-self.max_facts:]
    
    def get_all(self) -> List[Dict]:
        return self.facts.copy()
    
    def update_strength(self, fact_id: str, delta: float):
        for fact in self.facts:
            if fact["id"] == fact_id:
                fact["strength"] = max(0.1, min(1.0, fact["strength"] + delta))
                fact["last_accessed"] = datetime.now().isoformat()
                break
    
    def prune(self, min_strength: float = 0.3):
        self.facts = [f for f in self.facts if f["strength"] >= min_strength]
