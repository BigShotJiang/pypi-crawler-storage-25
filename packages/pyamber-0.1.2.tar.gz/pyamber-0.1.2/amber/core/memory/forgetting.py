"""
遗忘算法（时间衰减/容量限制）
"""

from typing import List, Dict, Any
from datetime import datetime, timedelta


class ForgettingMechanism:
    def __init__(self, config: Dict[str, Any]):
        self.half_life_days = config.get("half_life_days", 90)
        self.min_strength = config.get("min_strength", 0.3)
        self.auto_prune = config.get("auto_prune_enabled", True)
    
    def apply(self, facts: List[Dict], emotional_traces: List[Dict]):
        now = datetime.now()
        
        for fact in facts:
            created = datetime.fromisoformat(fact["created_at"])
            days_passed = (now - created).days
            if days_passed > 0:
                decay = 0.5 ** (days_passed / self.half_life_days)
                fact["strength"] = max(0.1, fact["strength"] * decay)
        
        if self.auto_prune:
            facts[:] = [f for f in facts if f["strength"] >= self.min_strength]
        
        cutoff = datetime.now() - timedelta(days=self.half_life_days * 2)
        emotional_traces[:] = [
            t for t in emotional_traces
            if datetime.fromisoformat(t["date"]) > cutoff
        ]
    
    def should_forget(self, fact: Dict) -> bool:
        return fact["strength"] < self.min_strength
