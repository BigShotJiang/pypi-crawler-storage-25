"""
进步报告（服务型人格专用）
"""

from typing import Dict, Any, List
from datetime import datetime


class ProgressReport:
    @classmethod
    def generate(cls, memory_manager) -> Dict[str, Any]:
        dimensions = cls._calculate_dimensions(memory_manager)
        weaknesses = cls._identify_weaknesses(memory_manager)
        
        return {
            "sessions": memory_manager.total_interactions // 10,
            "first_session": cls._get_first_session(memory_manager),
            "last_session": datetime.now().isoformat(),
            "dimensions": dimensions,
            "weaknesses": weaknesses,
            "suggestions": cls._generate_suggestions(weaknesses)
        }
    
    @classmethod
    def _calculate_dimensions(cls, memory_manager) -> Dict[str, Dict[str, int]]:
        facts = memory_manager.facts
        traces = memory_manager.emotional_traces
        
        positive_count = sum(1 for t in traces if t.get("pleasure", 0) > 0.2)
        total = max(len(traces), 1)
        positive_ratio = positive_count / total
        
        return {
            "engagement": {"start": 30, "current": int(50 * positive_ratio + 30)},
            "trust": {"start": 40, "current": int(40 + 10 * positive_ratio)},
            "satisfaction": {"start": 50, "current": int(50 + 20 * positive_ratio)}
        }
    
    @classmethod
    def _identify_weaknesses(cls, memory_manager) -> Dict[str, Dict[str, int]]:
        traces = memory_manager.emotional_traces[-20:]
        negative_count = sum(1 for t in traces if t.get("pleasure", 0) < -0.1)
        
        if negative_count > 5:
            return {"communication": {"start": 60, "current": max(40, 60 - negative_count * 2)}}
        return {}
    
    @classmethod
    def _get_first_session(cls, memory_manager) -> str:
        if memory_manager.emotional_traces:
            return memory_manager.emotional_traces[0].get("date", datetime.now().isoformat())
        return datetime.now().isoformat()
    
    @classmethod
    def _generate_suggestions(cls, weaknesses: Dict) -> List[str]:
        suggestions = []
        if "communication" in weaknesses:
            suggestions.append("尝试更清晰的表达")
        return suggestions
