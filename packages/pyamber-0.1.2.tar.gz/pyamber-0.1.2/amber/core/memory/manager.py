"""
记忆管理器主类
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
from amber.core.memory.fact import FactMemory
from amber.core.memory.emotional import EmotionalTrace
from amber.core.memory.tendency import TendencyLayer
from amber.core.memory.forgetting import ForgettingMechanism
from amber.core.memory.retrieval import MemoryRetrieval


class MemoryManager:
    def __init__(self, config: Dict[str, Any], initial_memory: Optional[Dict[str, Any]] = None):
        self.config = config
        self.max_facts = config.get("max_facts", 500)
        
        if initial_memory:
            self.facts = initial_memory.get("facts", [])
            self.emotional_traces = initial_memory.get("emotional_traces", [])
            self.tendency = initial_memory.get("tendency", {})
            self.total_interactions = initial_memory.get("total_interactions", 0)
            self.user_profile = initial_memory.get("user_profile", {})
        else:
            self.facts = []
            self.emotional_traces = []
            self.tendency = {}
            self.total_interactions = 0
            self.user_profile = {}
        
        self.fact_memory = FactMemory(self.facts, self.max_facts)
        self.emotional_memory = EmotionalTrace(self.emotional_traces)
        self.tendency_layer = TendencyLayer(self.tendency)
        self.forgetting = ForgettingMechanism(config)
        self.retrieval = MemoryRetrieval()
    
    def add_fact(self, content: str, emotion_tag: Optional[Dict[str, float]] = None):
        self.fact_memory.add(content, emotion_tag)
        self.facts = self.fact_memory.facts
    
    def get_facts(self) -> List[Dict]:
        return self.fact_memory.get_all()
    
    def get_all_facts(self) -> List[Dict]:
        return self.get_facts()
    
    def add_emotional_trace(self, event: str, pleasure: float, trust: float):
        self.emotional_memory.add(event, pleasure, trust)
        self.tendency_layer.update(event, pleasure, trust)
        self.emotional_traces = self.emotional_memory.traces
    
    def add_interaction(self, user_input: str, response: str, emotion: Dict[str, float]):
        self.total_interactions += 1
        self.add_fact(f"用户说: {user_input[:50]}", {"pleasure": emotion.get("pleasure", 0), "trust": emotion.get("trust", 0)})
        self.add_emotional_trace("interaction", emotion.get("pleasure", 0), emotion.get("trust", 0))
    
    def retrieve(self, query: str) -> List[Dict[str, Any]]:
        memories = self.retrieval.retrieve(self.facts, query)
        self.forgetting.apply(self.facts, self.emotional_traces)
        return memories
    
    def update_user_profile(self, key: str, value: Any):
        self.user_profile[key] = value
    
    def get_progress_report(self) -> Optional[Dict[str, Any]]:
        from amber.core.memory.progress import ProgressReport
        return ProgressReport.generate(self)
    
    def export(self) -> Dict[str, Any]:
        return {
            "facts": self.facts,
            "emotional_traces": self.emotional_traces,
            "tendency": self.tendency,
            "total_interactions": self.total_interactions,
            "user_profile": self.user_profile,
            "last_updated": datetime.now().isoformat()
        }
