"""
倾向层（Tendency）
"""

from typing import Dict, Any


class TendencyLayer:
    def __init__(self, tendency: Dict[str, Any] = None):
        self.tendency = tendency or {
            "positive_count": 0,
            "negative_count": 0,
            "trust_trend": "stable",
            "last_impression": "neutral"
        }
    
    def update(self, event: str, pleasure: float, trust: float):
        if pleasure > 0.2:
            self.tendency["positive_count"] += 1
        elif pleasure < -0.2:
            self.tendency["negative_count"] += 1
        
        total = self.tendency["positive_count"] + self.tendency["negative_count"]
        if total > 10:
            ratio = self.tendency["positive_count"] / total
            if ratio > 0.6:
                self.tendency["last_impression"] = "positive"
            elif ratio < 0.4:
                self.tendency["last_impression"] = "negative"
            else:
                self.tendency["last_impression"] = "mixed"
    
    def get_trust_adjustment(self) -> float:
        if self.tendency["last_impression"] == "positive":
            return 0.05
        elif self.tendency["last_impression"] == "negative":
            return -0.05
        return 0.0
    
    def get_summary(self) -> Dict[str, Any]:
        return self.tendency.copy()
