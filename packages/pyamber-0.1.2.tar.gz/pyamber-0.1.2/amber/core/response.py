"""
Response类 - 交互输出封装
"""

from typing import Dict, Any, Optional


class Response:
    def __init__(self, should_speak: bool, text: Optional[str] = None,
                 silence_duration_ms: int = 0, reason: Optional[str] = None,
                 emotion: Optional[Dict[str, float]] = None):
        self.should_speak = should_speak
        self.text = text or ""
        self.silence_duration_ms = silence_duration_ms
        self.reason = reason
        self.emotion = emotion or {"pleasure": 0.0, "activation": 0.5, "trust": 0.5}
    
    def is_silence(self) -> bool:
        return not self.should_speak
    
    def get_silence_seconds(self) -> float:
        return self.silence_duration_ms / 1000.0
    
    def __str__(self) -> str:
        if self.should_speak:
            return self.text
        return f"[沉默 {self.get_silence_seconds()}秒]"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "should_speak": self.should_speak,
            "text": self.text,
            "silence_duration_ms": self.silence_duration_ms,
            "reason": self.reason,
            "emotion": self.emotion
        }
