"""
黑名单管理
"""

from typing import List


class BlacklistManager:
    def __init__(self, blacklist: List[str]):
        self.blacklist = [item.lower() for item in blacklist]
    
    def match_any(self, text: str) -> bool:
        text_lower = text.lower()
        for item in self.blacklist:
            if item in text_lower:
                return True
        return False
    
    def add(self, item: str):
        self.blacklist.append(item.lower())
    
    def remove(self, item: str):
        item_lower = item.lower()
        if item_lower in self.blacklist:
            self.blacklist.remove(item_lower)
    
    def has_items(self) -> bool:
        return len(self.blacklist) > 0
