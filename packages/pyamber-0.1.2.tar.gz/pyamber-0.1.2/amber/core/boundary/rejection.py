"""
拒绝策略（拒绝/沉默/转移）
"""

from typing import Dict, Any
import random


class RejectionHandler:
    RESPONSES = {
        "reject": [
            "这个话题我不想聊。",
            "我们换个话题吧。",
            "这个我不太想说。"
        ],
        "redirect": [
            "聊点别的吧。",
            "你对什么感兴趣？",
            "今天天气不错。"
        ]
    }
    
    @classmethod
    def get_response(cls, strategy: str) -> str:
        if strategy == "silence":
            return ""
        responses = cls.RESPONSES.get(strategy, cls.RESPONSES["reject"])
        return random.choice(responses)
    
    @classmethod
    def should_silence(cls, context: Dict[str, Any]) -> bool:
        return context.get("strategy") == "silence"
