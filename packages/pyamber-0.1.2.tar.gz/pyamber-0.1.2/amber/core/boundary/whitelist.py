"""
白名单管理
"""

from typing import List


class WhitelistManager:
    def __init__(self, whitelist: List[str]):
        self.whitelist = [item.lower() for item in whitelist]
    
    def match_any(self, text: str) -> bool:
        if not self.whitelist:
            return True
        text_lower = text.lower()
        for item in self.whitelist:
            if item in text_lower:
                return True
        return False
    
    def add(self, item: str):
        self.whitelist.append(item.lower())
    
    def remove(self, item: str):
        item_lower = item.lower()
        if item_lower in self.whitelist:
            self.whitelist.remove(item_lower)
    
    def has_items(self) -> bool:
        return len(self.whitelist) > 0
