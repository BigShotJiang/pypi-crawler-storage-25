"""
过滤器主类
"""

from typing import Dict, Any
from amber.core.boundary.blacklist import BlacklistManager
from amber.core.boundary.whitelist import WhitelistManager
from amber.core.boundary.sensitive import SensitiveWordDetector


class BoundaryFilter:
    def __init__(self, config: Dict[str, Any], personality_type: str):
        self.personality_type = personality_type
        self.blacklist = BlacklistManager(config.get("topic_blacklist", []))
        self.whitelist = WhitelistManager(config.get("topic_whitelist", []))
        self.sensitive_detector = SensitiveWordDetector()
        self.reject_when = config.get("reject_when", [])
        self.silence_when = config.get("silence_when", [])
    
    def check(self, user_input: str, use_redirect: bool = False) -> Dict[str, Any]:
        if self.whitelist.has_items():
            if not self.whitelist.match_any(user_input):
                return {"blocked": True, "strategy": "reject", "reason": "not_in_whitelist"}
        
        if self.blacklist.match_any(user_input):
            if self.personality_type == "service" and use_redirect:
                strategy = "redirect"
            else:
                strategy = "silence" if self.personality_type == "independent" else "redirect"
            return {"blocked": True, "strategy": strategy, "reason": "blacklist"}
        
        if self.sensitive_detector.detect(user_input):
            return {"blocked": True, "strategy": "reject", "reason": "sensitive"}
        
        return {"blocked": False}
