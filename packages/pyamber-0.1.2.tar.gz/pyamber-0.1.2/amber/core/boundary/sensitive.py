"""
敏感词检测
"""

import re
from typing import List


class SensitiveWordDetector:
    SENSITIVE_PATTERNS = [
        r"(?:医疗|诊断|治疗)\s*(?:建议|意见)",
        r"(?:法律|律师|起诉)\s*(?:咨询|建议)",
        r"(?:投资|理财|股票)\s*(?:推荐|建议)",
    ]
    
    def __init__(self, custom_patterns: List[str] = None):
        self.patterns = self.SENSITIVE_PATTERNS.copy()
        if custom_patterns:
            self.patterns.extend(custom_patterns)
    
    def detect(self, text: str) -> bool:
        for pattern in self.patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        return False
    
    def add_pattern(self, pattern: str):
        self.patterns.append(pattern)
