"""
沉默类型定义
"""

from enum import Enum


class SilenceReason(Enum):
    ANGRY = "angry"
    SAD = "sad"
    THINKING = "thinking"
    REJECT = "reject"
    TIRED = "tired"


class SilenceType:
    TYPE_CONFIG = {
        SilenceReason.ANGRY: {"min_ms": 1000, "max_ms": 3000, "name": "生气时的沉默"},
        SilenceReason.SAD: {"min_ms": 3000, "max_ms": 8000, "name": "难过时的沉默"},
        SilenceReason.THINKING: {"min_ms": 1500, "max_ms": 4000, "name": "思考时的沉默"},
        SilenceReason.REJECT: {"min_ms": 0, "max_ms": 0, "name": "拒绝回答的沉默"},
        SilenceReason.TIRED: {"min_ms": 2000, "max_ms": 5000, "name": "疲惫时的沉默"},
    }
    
    @classmethod
    def get_config(cls, reason: SilenceReason) -> dict:
        return cls.TYPE_CONFIG.get(reason, {"min_ms": 1000, "max_ms": 3000})
