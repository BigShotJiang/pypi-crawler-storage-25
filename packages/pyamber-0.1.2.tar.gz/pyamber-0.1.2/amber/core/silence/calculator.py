"""
沉默时长计算器
"""

import random
from typing import Dict
from amber.core.silence.types import SilenceReason, SilenceType


class SilenceDurationCalculator:
    def calculate(self, reason: SilenceReason, emotion: Dict[str, float]) -> int:
        config = SilenceType.get_config(reason)
        min_ms = config["min_ms"]
        max_ms = config["max_ms"]
        
        if min_ms == max_ms:
            return min_ms
        
        base_duration = random.randint(min_ms, max_ms)
        
        if reason == SilenceReason.SAD:
            sadness = max(0, -emotion.get("pleasure", 0))
            base_duration = int(base_duration * (1 + sadness * 0.5))
        
        if reason == SilenceReason.THINKING:
            activation = emotion.get("activation", 0.5)
            base_duration = int(base_duration * (1.5 - activation))
        
        return min(max_ms, max(min_ms, base_duration))
