"""
Silence module - 沉默系统
"""

from amber.core.silence.engine import SilenceEngine
from amber.core.silence.types import SilenceType, SilenceReason
from amber.core.silence.calculator import SilenceDurationCalculator
from amber.core.silence.triggers import SilenceTrigger

__all__ = [
    "SilenceEngine",
    "SilenceType",
    "SilenceReason",
    "SilenceDurationCalculator",
    "SilenceTrigger",
]
