"""
沉默引擎
"""

from typing import Dict, Any
from amber.core.silence.types import SilenceReason
from amber.core.silence.calculator import SilenceDurationCalculator
from amber.core.silence.triggers import SilenceTrigger


class SilenceEngine:
    def __init__(self, config: Dict[str, Any], personality_type: str):
        self.config = config
        self.personality_type = personality_type
        self.calculator = SilenceDurationCalculator()
        self.trigger = SilenceTrigger()
    
    def should_silence(self, emotion: Dict[str, float], user_input: str) -> Dict[str, Any]:
        if self.personality_type == "service":
            return {"should_silence": False, "duration_ms": 0, "reason": None}
        
        reason = self.trigger.check(emotion, user_input)
        if reason is None:
            return {"should_silence": False, "duration_ms": 0, "reason": None}
        
        duration = self.calculator.calculate(reason, emotion)
        return {"should_silence": True, "duration_ms": duration, "reason": reason.value}
    
    def _calculate_duration(self, reason: str) -> int:
        if reason == "angry":
            return 2000
        elif reason == "sad":
            return 5000
        elif reason == "thinking":
            return 2500
        elif reason == "tired":
            return 3500
        elif reason == "reject":
            return 0
        return 3000
