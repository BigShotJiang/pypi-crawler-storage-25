"""
沉默触发条件
"""

from typing import Dict, Optional
from amber.core.silence.types import SilenceReason


class SilenceTrigger:
    def check(self, emotion: Dict[str, float], user_input: str) -> Optional[SilenceReason]:
        if emotion.get("pleasure", 0) < -0.5:
            return SilenceReason.ANGRY
        
        if emotion.get("pleasure", 0) < -0.7:
            return SilenceReason.SAD
        
        if "?" in user_input and emotion.get("activation", 0.5) < 0.3:
            return SilenceReason.THINKING
        
        negative_words = ["滚", "闭嘴", "烦死了", "讨厌"]
        for word in negative_words:
            if word in user_input:
                return SilenceReason.REJECT
        
        if emotion.get("activation", 0.5) < 0.2:
            return SilenceReason.TIRED
        
        return None
