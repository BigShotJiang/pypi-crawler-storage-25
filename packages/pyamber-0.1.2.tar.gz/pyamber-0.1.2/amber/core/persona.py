"""
Persona主类 - 人格加载、保存、交互入口
"""

import os
import random
import yaml
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path

from amber.core.response import Response
from amber.core.emotion.engine import EmotionEngine
from amber.core.emotion.independent import IndependentEmotionEngine
from amber.core.emotion.service import ServiceEmotionEngine
from amber.core.memory.manager import MemoryManager
from amber.core.boundary.filter import BoundaryFilter
from amber.core.silence.engine import SilenceEngine
from amber.core.evolution.engine import EvolutionEngine
from amber.formats.amber_format import load_amber, save_amber
from amber.formats.memory_format import load_memory, save_memory


class Persona:
    def __init__(self, name: str, params: Dict[str, Any],
                 memory: Optional[Dict[str, Any]] = None,
                 data_dir: Optional[str] = None):
        self.name = name
        self.params = params
        self.data_dir = data_dir or f"./data/personas/{name}"
        
        if params is None:
            params = {}
        self.personality_type = params.get("personality_type", {}).get("type", "independent")
        
        self._init_emotion_engine()
        self._init_memory_manager(memory)
        self._init_boundary_filter()
        self._init_silence_engine()
        self._init_evolution_engine()
        self.interaction_count = 0
    
    def _init_emotion_engine(self):
        emotion_config = self.params.get("emotion", {})
        if self.personality_type == "independent":
            self.emotion_engine = IndependentEmotionEngine(emotion_config)
        elif self.personality_type == "service":
            self.emotion_engine = ServiceEmotionEngine(emotion_config)
        else:
            from amber.core.emotion.mixed import MixedEmotionEngine
            self.emotion_engine = MixedEmotionEngine(emotion_config, 0.5)
    
    def _init_memory_manager(self, memory: Optional[Dict[str, Any]]):
        memory_config = self.params.get("memory_schema", {})
        self.memory_manager = MemoryManager(memory_config, memory)
    
    def _init_boundary_filter(self):
        boundary_config = self.params.get("boundaries", {})
        self.boundary_filter = BoundaryFilter(boundary_config, self.personality_type)
    
    def _init_silence_engine(self):
        silence_config = self.params.get("silence", {})
        self.silence_engine = SilenceEngine(silence_config, self.personality_type)
    
    def _init_evolution_engine(self):
        evolution_config = self.params.get("evolution", {})
        self.evolution_engine = EvolutionEngine(evolution_config, self.personality_type)
    
    def interact(self, user_input: str) -> Response:
        self.interaction_count += 1
        boundary_result = self.boundary_filter.check(user_input)
        if boundary_result["blocked"]:
            return self._handle_boundary_block(boundary_result)
        
        emotion_effect = self._analyze_emotion_effect(user_input)
        self.emotion_engine.update(emotion_effect)
        current_emotion = self.emotion_engine.get_state()
        silence_result = self.silence_engine.should_silence(current_emotion, user_input)
        
        if silence_result["should_silence"]:
            return Response(should_speak=False, silence_duration_ms=silence_result["duration_ms"],
                           reason=silence_result["reason"], emotion=current_emotion)
        
        relevant_memories = self.memory_manager.retrieve(user_input)
        response_text = self._generate_response(user_input, current_emotion, relevant_memories)
        self.memory_manager.add_interaction(user_input, response_text, current_emotion)
        
        if self.interaction_count % 10 == 0:
            self.evolution_engine.update(self.emotion_engine, self.memory_manager)
        
        return Response(should_speak=True, text=response_text, emotion=current_emotion)
    
    def _handle_boundary_block(self, boundary_result: Dict[str, Any]) -> Response:
        strategy = boundary_result.get("strategy", "reject")
        current_emotion = self.emotion_engine.get_state()
        if strategy == "silence":
            return Response(should_speak=False, silence_duration_ms=3000,
                           reason="boundary_silence", emotion=current_emotion)
        elif strategy == "reject":
            return Response(should_speak=True, text="这个话题我不想聊。", emotion=current_emotion)
        else:
            return Response(should_speak=True, text="我们换个话题吧。", emotion=current_emotion)
    
    def _analyze_emotion_effect(self, user_input: str) -> Dict[str, float]:
        effect = {"pleasure": 0.0, "activation": 0.0, "trust": 0.0}
        positive_words = ["喜欢", "好", "棒", "厉害", "温柔", "可爱", "聪明"]
        negative_words = ["讨厌", "烦", "烂", "差劲", "笨", "蠢", "滚"]
        active_words = ["哈哈", "激动", "兴奋", "开心", "耶"]
        passive_words = ["唉", "累了", "疲惫", "无聊"]
        
        for word in positive_words:
            if word in user_input:
                effect["pleasure"] += 0.1
                effect["trust"] += 0.05
        for word in negative_words:
            if word in user_input:
                effect["pleasure"] -= 0.15
                effect["trust"] -= 0.1
        for word in active_words:
            if word in user_input:
                effect["activation"] += 0.1
        for word in passive_words:
            if word in user_input:
                effect["activation"] -= 0.1
        
        for key in effect:
            effect[key] = max(-0.3, min(0.3, effect[key]))
        return effect
    
    def _generate_response(self, user_input: str, emotion: Dict[str, float], memories: List) -> str:
        pleasure = emotion.get("pleasure", 0.0)
        if pleasure > 0.3:
            templates = ["嗯~", "好的呢", "可以呀"]
        elif pleasure < -0.2:
            templates = ["...", "哦", "随便"]
        else:
            templates = ["嗯", "好的", "行"]
        base_response = random.choice(templates)
        if memories:
            memory = memories[0]
            if memory.get("emotion_tag", {}).get("pleasure", 0) > 0.3:
                base_response += " 我记得你喜欢这个。"
        return base_response
    
    def update_memory(self, key: str, value: Any):
        self.memory_manager.update_user_profile(key, value)
    
    def get_emotion(self) -> Dict[str, float]:
        return self.emotion_engine.get_state()
    
    def get_progress_report(self) -> Optional[Dict[str, Any]]:
        if self.personality_type == "service":
            return self.memory_manager.get_progress_report()
        return None
    
    def save(self):
        """保存人格"""
        os.makedirs(self.data_dir, exist_ok=True)
        
        amber_path = os.path.join(self.data_dir, f"{self.name}.amber")
        save_amber(self.params, amber_path)
        
        memory_path = os.path.join(self.data_dir, f"{self.name}.memory")
        memory_data = self.memory_manager.export()
        save_memory(memory_data, memory_path)
        
        print(f"✅ 人格 '{self.name}' 已保存")
    
    @classmethod
    def load(cls, name: str, data_dir: Optional[str] = None) -> "Persona":
        data_dir = data_dir or f"./data/personas/{name}"
        amber_path = os.path.join(data_dir, f"{name}.amber")
        memory_path = os.path.join(data_dir, f"{name}.memory")
        
        params = load_amber(amber_path)
        if params is None:
            raise FileNotFoundError(f"人格文件不存在: {amber_path}")
        
        memory = None
        if os.path.exists(memory_path):
            memory = load_memory(memory_path)
        
        return cls(name, params, memory, data_dir)
    
    def __repr__(self) -> str:
        return f"<Persona(name='{self.name}', type='{self.personality_type}')>"
