"""
人格特质渐变
"""


class TraitEvolution:
    def __init__(self, change_rate: float = 0.0001):
        self.change_rate = change_rate
        self.update_count = 0
    
    def update(self, emotion_engine, trust_trend: float):
        self.update_count += 1
        if self.update_count >= 500:
            self.update_count = 0
            if trust_trend > 0.1:
                emotion_engine.sensitivity["trust"] = min(
                    1.5, emotion_engine.sensitivity["trust"] + self.change_rate
                )
            elif trust_trend < -0.1:
                emotion_engine.sensitivity["trust"] = max(
                    0.5, emotion_engine.sensitivity["trust"] - self.change_rate
                )
