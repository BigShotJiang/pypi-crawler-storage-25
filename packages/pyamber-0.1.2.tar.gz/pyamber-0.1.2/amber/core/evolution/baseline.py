"""
长期情绪基线漂移
"""


class BaselineDrift:
    def __init__(self, drift_rate: float = 0.001):
        self.drift_rate = drift_rate
        self.drift_count = 0
    
    def apply(self, emotion_engine) -> bool:
        self.drift_count += 1
        if self.drift_count >= 100:
            self.drift_count = 0
            current = emotion_engine.get_state()
            new_pleasure = current["pleasure"] * (1 - self.drift_rate * 0.5)
            emotion_engine.state["pleasure"] = max(-1.0, min(1.0, new_pleasure))
            return True
        return False
