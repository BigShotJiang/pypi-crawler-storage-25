"""
Evolution module - 时间演化
"""

from amber.core.evolution.engine import EvolutionEngine
from amber.core.evolution.baseline import BaselineDrift
from amber.core.evolution.traits import TraitEvolution
from amber.core.evolution.trust_trend import TrustTrendAnalysis
from amber.core.evolution.adaptation import AdaptationStrategy

__all__ = [
    "EvolutionEngine",
    "BaselineDrift",
    "TraitEvolution",
    "TrustTrendAnalysis",
    "AdaptationStrategy",
]
