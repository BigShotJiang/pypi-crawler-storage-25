"""
信任度长期趋势
"""

from typing import Any


class TrustTrendAnalysis:
    def analyze(self, memory_manager) -> float:
        traces = memory_manager.emotional_traces
        if len(traces) < 10:
            return 0.0
        
        recent = traces[-10:]
        old_avg = sum(t.get("trust", 0) for t in traces[:10]) / 10
        new_avg = sum(t.get("trust", 0) for t in recent) / 10
        
        return new_avg - old_avg
