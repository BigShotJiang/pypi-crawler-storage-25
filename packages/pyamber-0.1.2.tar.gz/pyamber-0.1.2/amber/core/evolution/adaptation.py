"""
自适应策略（调整行为参数）
"""

from typing import Any


class AdaptationStrategy:
    def apply(self, emotion_engine, memory_manager):
        traces = memory_manager.emotional_traces[-20:]
        if len(traces) < 10:
            return
        
        negative_ratio = sum(1 for t in traces if t.get("pleasure", 0) < -0.2) / len(traces)
        
        if negative_ratio > 0.5:
            emotion_engine.sensitivity["trust"] = max(
                0.5, emotion_engine.sensitivity["trust"] - 0.01
            )
        elif negative_ratio < 0.2:
            emotion_engine.sensitivity["pleasure"] = min(
                1.2, emotion_engine.sensitivity["pleasure"] + 0.005
            )
