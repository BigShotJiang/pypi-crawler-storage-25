"""
演化引擎
"""

from typing import Any
from amber.core.evolution.baseline import BaselineDrift
from amber.core.evolution.traits import TraitEvolution
from amber.core.evolution.trust_trend import TrustTrendAnalysis
from amber.core.evolution.adaptation import AdaptationStrategy


class EvolutionEngine:
    def __init__(self, config: dict, personality_type: str):
        self.config = config
        self.personality_type = personality_type
        self.baseline_drift = BaselineDrift(config.get("baseline_drift_rate", 0.001))
        self.trait_evolution = TraitEvolution(config.get("trait_change_rate", 0.0001))
        self.trust_analysis = TrustTrendAnalysis()
        self.adaptation = AdaptationStrategy()
    
    def update(self, emotion_engine, memory_manager):
        if self.personality_type == "service":
            return
        
        emotion_state = emotion_engine.get_state()
        self.baseline_drift.apply(emotion_engine)
        
        trust_trend = self.trust_analysis.analyze(memory_manager)
        self.trait_evolution.update(emotion_engine, trust_trend)
        
        if self.config.get("adaptation_enabled", True):
            self.adaptation.apply(emotion_engine, memory_manager)
