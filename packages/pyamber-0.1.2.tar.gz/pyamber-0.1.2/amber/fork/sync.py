"""
上游同步
"""

import yaml
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional


class SyncManager:
    """同步管理器"""
    
    @staticmethod
    def sync_upstream(name: str, dry_run: bool = False) -> bool:
        """
        同步上游更新
        
        Args:
            name: 人格名称
            dry_run: 是否预览
            
        Returns:
            是否成功
        """
        # 获取Fork信息
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            print(f"❌ 人格 '{name}' 不存在")
            return False
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        fork_info = data.get("fork_info")
        if not fork_info:
            print(f"❌ '{name}' 不是Fork作品")
            return False
        
        parent = fork_info.get("parent")
        parent_file = Path(f"./data/personas/{parent}/{parent}.amber")
        
        if not parent_file.exists():
            print(f"❌ 上游人格 '{parent}' 不存在")
            return False
        
        with open(parent_file, 'r', encoding='utf-8') as f:
            parent_data = yaml.safe_load(f)
        
        if dry_run:
            print("预览同步:")
            print(f"  上游版本: {parent_data.get('version')}")
            print(f"  当前版本: {data.get('version')}")
            print("  将同步: speech风格, 边界规则")
            return True
        
        # 执行同步
        changes = SyncManager._merge_upstream(data, parent_data)
        
        if changes:
            data["version"] = parent_data.get("version")
            data["synced_at"] = datetime.now().isoformat()
            data["synced_from"] = parent
            data["sync_changes"] = changes
            
            # 保存
            with open(amber_file, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
            
            print(f"✅ 同步完成，更新了: {', '.join(changes)}")
        else:
            print("✅ 已是最新版本")
        
        return True
    
    @staticmethod
    def _merge_upstream(current: Dict, upstream: Dict) -> list:
        """合并上游更新"""
        changes = []
        
        # 同步speech风格
        if "speech" in upstream and "speech" not in current:
            current["speech"] = upstream["speech"]
            changes.append("speech")
        
        # 同步边界规则
        if "boundaries" in upstream:
            if "boundaries" not in current:
                current["boundaries"] = {}
            
            for key in ["reject_when", "silence_when", "topic_blacklist"]:
                if key in upstream["boundaries"]:
                    current["boundaries"][key] = upstream["boundaries"][key].copy()
                    changes.append(f"boundaries.{key}")
        
        return changes
    
    @staticmethod
    def get_upstream(name: str) -> Optional[str]:
        """获取上游人格名称"""
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            return None
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        fork_info = data.get("fork_info")
        if fork_info:
            return fork_info.get("parent")
        
        return None


def sync_upstream(name: str, dry_run: bool = False) -> bool:
    """同步上游"""
    return SyncManager.sync_upstream(name, dry_run)


def get_upstream(name: str) -> Optional[str]:
    """获取上游"""
    return SyncManager.get_upstream(name)
