"""
PR管理（创建/状态/列表/合并）
"""

import json
import yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional


class PullRequest:
    """Pull Request 数据类"""
    
    def __init__(self, pr_id: int, source: str, target: str, 
                 title: str, description: str, status: str,
                 creator: str, created_at: str):
        self.id = pr_id
        self.source = source
        self.target = target
        self.title = title
        self.description = description
        self.status = status  # pending, approved, merged, rejected
        self.creator = creator
        self.created_at = created_at
        self.merged_at = None
        self.comments = []
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "source": self.source,
            "target": self.target,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "creator": self.creator,
            "created_at": self.created_at,
            "merged_at": self.merged_at,
            "comments": self.comments
        }


class PullRequestManager:
    """PR管理器"""
    
    PR_FILE = "./data/prs.json"
    
    @classmethod
    def _load_prs(cls) -> List[Dict]:
        """加载所有PR"""
        if not Path(cls.PR_FILE).exists():
            return []
        
        with open(cls.PR_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @classmethod
    def _save_prs(cls, prs: List[Dict]):
        """保存PR"""
        Path("./data").mkdir(exist_ok=True)
        with open(cls.PR_FILE, 'w', encoding='utf-8') as f:
            json.dump(prs, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def create(cls, source: str, target: str, title: str, 
               description: str, creator: str) -> Optional[int]:
        """
        创建PR
        
        Args:
            source: 源人格
            target: 目标人格
            title: PR标题
            description: 描述
            creator: 创建者
            
        Returns:
            PR ID
        """
        prs = cls._load_prs()
        
        pr_id = len(prs) + 1
        
        pr = {
            "id": pr_id,
            "source": source,
            "target": target,
            "title": title,
            "description": description,
            "status": "pending",
            "creator": creator,
            "created_at": datetime.now().isoformat(),
            "merged_at": None,
            "comments": []
        }
        
        prs.append(pr)
        cls._save_prs(prs)
        
        print(f"✅ PR #{pr_id} 创建成功")
        return pr_id
    
    @classmethod
    def list_prs(cls, status: str = None) -> List[Dict]:
        """列出PR"""
        prs = cls._load_prs()
        
        if status:
            return [p for p in prs if p.get("status") == status]
        return prs
    
    @classmethod
    def get_pr(cls, pr_id: int) -> Optional[Dict]:
        """获取PR详情"""
        prs = cls._load_prs()
        for pr in prs:
            if pr.get("id") == pr_id:
                return pr
        return None
    
    @classmethod
    def merge(cls, pr_id: int, merger: str, message: str = "") -> bool:
        """合并PR"""
        prs = cls._load_prs()
        
        for i, pr in enumerate(prs):
            if pr.get("id") == pr_id:
                if pr.get("status") != "pending":
                    print(f"❌ PR #{pr_id} 状态为 {pr['status']}，无法合并")
                    return False
                
                # 执行合并
                result = cls._execute_merge(pr["source"], pr["target"])
                
                if result:
                    pr["status"] = "merged"
                    pr["merged_at"] = datetime.now().isoformat()
                    pr["merged_by"] = merger
                    pr["merge_message"] = message
                    cls._save_prs(prs)
                    print(f"✅ PR #{pr_id} 已合并")
                    return True
                
                return False
        
        print(f"❌ PR #{pr_id} 不存在")
        return False
    
    @classmethod
    def reject(cls, pr_id: int, reason: str) -> bool:
        """拒绝PR"""
        prs = cls._load_prs()
        
        for i, pr in enumerate(prs):
            if pr.get("id") == pr_id:
                if pr.get("status") != "pending":
                    print(f"❌ PR #{pr_id} 状态为 {pr['status']}，无法拒绝")
                    return False
                
                pr["status"] = "rejected"
                pr["reject_reason"] = reason
                cls._save_prs(prs)
                print(f"✅ PR #{pr_id} 已拒绝")
                return True
        
        return False
    
    @classmethod
    def add_comment(cls, pr_id: int, comment: str, author: str) -> bool:
        """添加评论"""
        prs = cls._load_prs()
        
        for i, pr in enumerate(prs):
            if pr.get("id") == pr_id:
                if "comments" not in pr:
                    pr["comments"] = []
                
                pr["comments"].append({
                    "author": author,
                    "content": comment,
                    "created_at": datetime.now().isoformat()
                })
                
                cls._save_prs(prs)
                print(f"✅ 评论已添加到 PR #{pr_id}")
                return True
        
        return False
    
    @classmethod
    def _execute_merge(cls, source: str, target: str) -> bool:
        """执行合并操作"""
        source_file = Path(f"./data/personas/{source}/{source}.amber")
        target_file = Path(f"./data/personas/{target}/{target}.amber")
        
        if not source_file.exists() or not target_file.exists():
            return False
        
        with open(source_file, 'r', encoding='utf-8') as f:
            source_data = yaml.safe_load(f)
        
        with open(target_file, 'r', encoding='utf-8') as f:
            target_data = yaml.safe_load(f)
        
        # 合并说话风格
        if "speech" in source_data and "speech" in target_data:
            if "catchphrases" in source_data["speech"]:
                target_data["speech"]["catchphrases"].extend(source_data["speech"]["catchphrases"])
        
        # 更新版本
        target_data["version"] = f"{float(target_data.get('version', '1.0')) + 0.1:.1f}"
        target_data["merged_at"] = datetime.now().isoformat()
        target_data["merged_from"] = source
        
        # 添加贡献者
        if "contributors" not in target_data:
            target_data["contributors"] = []
        target_data["contributors"].append({
            "id": "PR Contributor",
            "contribution": f"Merged from {source}",
            "merged_at": datetime.now().isoformat()
        })
        
        # 保存
        with open(target_file, 'w', encoding='utf-8') as f:
            yaml.dump(target_data, f, allow_unicode=True, default_flow_style=False)
        
        return True
