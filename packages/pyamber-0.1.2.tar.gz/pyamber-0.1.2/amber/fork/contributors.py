"""
贡献者记录管理
"""

import yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional


class ContributorsManager:
    """贡献者管理器"""
    
    @staticmethod
    def add_contributor(name: str, contributor_id: str, 
                        contribution: str, role: str = "contributor") -> bool:
        """
        添加贡献者
        
        Args:
            name: 人格名称
            contributor_id: 贡献者ID
            contribution: 贡献描述
            role: 角色
            
        Returns:
            是否成功
        """
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            print(f"❌ 人格 '{name}' 不存在")
            return False
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        if "contributors" not in data:
            data["contributors"] = []
        
        # 检查是否已存在
        for c in data["contributors"]:
            if c.get("id") == contributor_id:
                print(f"贡献者 {contributor_id} 已存在")
                return False
        
        data["contributors"].append({
            "id": contributor_id,
            "role": role,
            "contribution": contribution,
            "added_at": datetime.now().isoformat()
        })
        
        with open(amber_file, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
        
        print(f"✅ 贡献者 {contributor_id} 已添加到 '{name}'")
        return True
    
    @staticmethod
    def list_contributors(name: str) -> List[Dict[str, Any]]:
        """列出贡献者"""
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            return []
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        return data.get("contributors", [])
    
    @staticmethod
    def get_original_creator(name: str) -> Optional[str]:
        """获取原始创作者"""
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            return None
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        # 检查Fork信息
        fork_info = data.get("fork_info")
        if fork_info:
            # 递归查找原始创作者
            parent = fork_info.get("parent")
            if parent:
                return ContributorsManager.get_original_creator(parent)
        
        # 返回签名中的创作者
        return data.get("signature", {}).get("creator_id", "unknown")


def add_contributor(name: str, contributor_id: str, contribution: str, role: str = "contributor") -> bool:
    """添加贡献者"""
    return ContributorsManager.add_contributor(name, contributor_id, contribution, role)


def list_contributors(name: str) -> List[Dict[str, Any]]:
    """列出贡献者"""
    return ContributorsManager.list_contributors(name)


def get_original_creator(name: str) -> Optional[str]:
    """获取原始创作者"""
    return ContributorsManager.get_original_creator(name)
