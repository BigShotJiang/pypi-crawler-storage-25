"""
Fork module - Git风格协作
"""

from amber.fork.git_ops import fork_persona, ForkOperator
from amber.fork.lineage import get_lineage, get_family_tree, LineageTracker
from amber.fork.pull_request import PullRequest, PullRequestManager
from amber.fork.contributors import ContributorsManager, add_contributor
from amber.fork.license import LicenseValidator, validate_license_compatibility
from amber.fork.sync import sync_upstream, SyncManager

__all__ = [
    "fork_persona",
    "ForkOperator",
    "get_lineage",
    "get_family_tree",
    "LineageTracker",
    "PullRequest",
    "PullRequestManager",
    "ContributorsManager",
    "add_contributor",
    "LicenseValidator",
    "validate_license_compatibility",
    "sync_upstream",
    "SyncManager",
]
