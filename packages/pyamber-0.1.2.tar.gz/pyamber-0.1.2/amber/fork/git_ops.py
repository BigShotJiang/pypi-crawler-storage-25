"""
Fork操作主逻辑
"""

import shutil
import yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional


class ForkOperator:
    """Fork操作器"""
    
    @staticmethod
    def fork(source: str, target: str, 
             license: Optional[str] = None,
             creator_id: str = "anonymous") -> bool:
        """
        Fork人格
        
        Args:
            source: 源人格名称
            target: 目标人格名称
            license: 新许可证
            creator_id: 创作者ID
            
        Returns:
            是否成功
        """
        source_dir = Path(f"./data/personas/{source}")
        source_file = source_dir / f"{source}.amber"
        
        if not source_file.exists():
            print(f"❌ 源人格 '{source}' 不存在")
            return False
        
        target_dir = Path(f"./data/personas/{target}")
        if target_dir.exists():
            print(f"❌ 目标人格 '{target}' 已存在")
            return False
        
        # 创建目标目录
        target_dir.mkdir(parents=True)
        
        # 复制参数层
        target_file = target_dir / f"{target}.amber"
        shutil.copy(source_file, target_file)
        
        # 修改Fork信息
        with open(target_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        # 添加Fork信息
        data['fork_info'] = {
            'parent': source,
            'parent_version': data.get('version', '1.0'),
            'fork_point': datetime.now().isoformat(),
            'changes': []
        }
        
        # 修改创作者信息
        if 'signature' not in data:
            data['signature'] = {}
        data['signature']['derived_from'] = source
        data['signature']['creator_id'] = creator_id
        data['signature']['forked_at'] = datetime.now().isoformat()
        
        if license:
            data['signature']['license'] = license
        
        # 修改名称
        if 'identity' not in data:
            data['identity'] = {}
        data['identity']['name'] = target
        
        # 添加贡献者
        if 'contributors' not in data:
            data['contributors'] = []
        data['contributors'].append({
            'id': creator_id,
            'role': 'fork_creator',
            'contribution': f'Fork from {source}',
            'forked_at': datetime.now().isoformat()
        })
        
        with open(target_file, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
        
        # 创建空白记忆层
        from amber.formats.memory_format import create_empty_memory
        memory = create_empty_memory(data.get('version', '1.0'), 
                                      data.get('personality_type', {}).get('type', 'independent'))
        
        memory_file = target_dir / f"{target}.memory"
        with open(memory_file, 'w', encoding='utf-8') as f:
            yaml.dump(memory, f, allow_unicode=True, default_flow_style=False)
        
        print(f"✅ Fork成功: {source} → {target}")
        return True


def fork_persona(source: str, target: str, 
                 license: Optional[str] = None,
                 creator_id: str = "anonymous") -> bool:
    """Fork人格"""
    return ForkOperator.fork(source, target, license, creator_id)
