"""
创作链追踪
"""

import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional


class LineageTracker:
    """创作链追踪器"""
    
    @staticmethod
    def get_lineage(name: str) -> List[Dict[str, Any]]:
        """
        获取创作链（向上追溯）
        
        Args:
            name: 人格名称
            
        Returns:
            创作链列表，从原始到当前
        """
        lineage = []
        current = name
        
        while True:
            data = LineageTracker._load_persona_data(current)
            if not data:
                break
            
            creator = data.get('signature', {}).get('creator_id', 'unknown')
            lineage.append({
                'name': current,
                'creator': creator,
                'version': data.get('version', '1.0'),
                'fork_info': data.get('fork_info')
            })
            
            # 查找父人格
            fork_info = data.get('fork_info')
            if not fork_info:
                break
            
            current = fork_info.get('parent')
            if not current:
                break
        
        return lineage
    
    @staticmethod
    def get_family_tree(root: str) -> Dict[str, Any]:
        """
        获取家族树（向下追溯）
        
        Args:
            root: 根人格名称
            
        Returns:
            家族树结构
        """
        tree = {
            'name': root,
            'children': []
        }
        
        # 扫描所有人格
        personas_dir = Path("./data/personas")
        if not personas_dir.exists():
            return tree
        
        for persona_dir in personas_dir.iterdir():
            if not persona_dir.is_dir():
                continue
            
            data = LineageTracker._load_persona_data(persona_dir.name)
            if not data:
                continue
            
            fork_info = data.get('fork_info')
            if fork_info and fork_info.get('parent') == root:
                tree['children'].append(LineageTracker.get_family_tree(persona_dir.name))
        
        return tree
    
    @staticmethod
    def _load_persona_data(name: str) -> Optional[Dict]:
        """加载人格数据"""
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        if not amber_file.exists():
            return None
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    @staticmethod
    def print_lineage(name: str):
        """打印创作链"""
        lineage = LineageTracker.get_lineage(name)
        
        print("人格创作链:")
        print("=" * 40)
        
        for i, item in enumerate(reversed(lineage)):
            indent = "    " * i
            arrow = "↑" if i > 0 else ""
            print(f"{indent}{arrow} {item['name']} ({item['creator']})")
        
        if len(lineage) > 1:
            print(f"\n总衍生层级: {len(lineage) - 1}")


def get_lineage(name: str) -> List[Dict[str, Any]]:
    """获取创作链"""
    return LineageTracker.get_lineage(name)


def get_family_tree(root: str) -> Dict[str, Any]:
    """获取家族树"""
    return LineageTracker.get_family_tree(root)


def print_lineage(name: str):
    """打印创作链"""
    LineageTracker.print_lineage(name)
