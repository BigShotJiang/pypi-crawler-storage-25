"""
许可证验证和继承
"""

import yaml
from pathlib import Path
from typing import Dict, Any, Optional, Tuple


class LicenseValidator:
    """许可证验证器"""
    
    # 许可证兼容性矩阵
    COMPATIBILITY = {
        "CC-BY": ["CC-BY", "CC-BY-SA"],
        "CC-BY-SA": ["CC-BY-SA"],
        "CC-BY-NC": ["CC-BY-NC", "CC-BY-NC-SA"],
        "CC-BY-NC-SA": ["CC-BY-NC-SA"],
        "CC-BY-ND": ["CC-BY-ND"],
        "CC-BY-NC-ND": ["CC-BY-NC-ND"],
        "GPL-3.0": ["GPL-3.0"],
        "MIT": ["MIT", "GPL-3.0"],
    }
    
    @classmethod
    def validate_fork(cls, source: str, target: str, target_license: str = None) -> Tuple[bool, str]:
        """
        验证Fork是否允许
        
        Args:
            source: 源人格
            target: 目标人格
            target_license: 目标许可证
            
        Returns:
            (是否允许, 信息)
        """
        source_license = cls._get_license(source)
        
        if not source_license:
            return True, "无许可证限制"
        
        # 检查ND限制（禁止修改）
        if "ND" in source_license and target_license != source_license:
            return False, f"源人格使用 {source_license} 许可证，禁止修改"
        
        # 检查NC限制（非商业）
        if "NC" in source_license and target_license == "commercial":
            return False, f"源人格使用 {source_license} 许可证，禁止商业使用"
        
        return True, "许可证兼容"
    
    @classmethod
    def _get_license(cls, name: str) -> Optional[str]:
        """获取人格许可证"""
        amber_file = Path(f"./data/personas/{name}/{name}.amber")
        
        if not amber_file.exists():
            return None
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        return data.get("signature", {}).get("license")
    
    @classmethod
    def is_modification_allowed(cls, name: str) -> bool:
        """是否允许修改"""
        license = cls._get_license(name)
        if not license:
            return True
        
        # 包含ND的许可证禁止修改
        return "ND" not in license


def validate_license_compatibility(source: str, target_license: str = None) -> Tuple[bool, str]:
    """验证许可证兼容性"""
    return LicenseValidator.validate_fork(source, "", target_license)


def is_modification_allowed(name: str) -> bool:
    """是否允许修改"""
    return LicenseValidator.is_modification_allowed(name)
