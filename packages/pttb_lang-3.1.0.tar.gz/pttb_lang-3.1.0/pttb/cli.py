import argparse
import sys
import os
import json
import time
import base64
import zlib
import shutil
import platform
import subprocess
from .lexer import tokenize
from .parser import Parser
from .interpreter import Interpreter

VERSION = "3.1.0"

class PTTBLogger:
    @staticmethod
    def splash(enterprise=False):
        if enterprise:
            print(f"""
\033[1;34m   PTTB ENTERPRISE SOLUTIONS \033[0;90m
   Version {VERSION} | Corporate Standard
   "Efficiency through Brazilian Engineering."\033[0m
""")
        else:
            print(f"""
\033[1;32m   ____  _________________ \033[1;33m  ____  _____ 
\033[1;32m  / __ \/_  __/_  __/ __ ) \033[1;33m / __ \/ ___/ 
\033[1;32m / /_/ / / /   / / / __  | \033[1;33m/ /_/ /\__ \  
\033[1;32m/ ____/ / /   / / / /_/ / \033[1;33m/ _, _/___/ /  
\033[1;32m/_/     /_/   /_/ /_____/ \033[1;33m/_/ |_|/____/   \033[0;90mv{VERSION}
\033[0;37m  "Onde o CLT vira Executivo."\033[0m
""")

def run_project(file_path=None, enterprise=False):
    target = file_path or "main.pttb"
    if not os.path.exists(target):
        print(f"File not found: {target}")
        return
    
    with open(target, "r") as f: code = f.read()
    module = os.path.basename(target)
    
    it = Interpreter(module=module)
    # Load headers
    if os.path.exists("./libs"):
        for f in os.listdir("./libs"):
            if f.endswith(".pttblib"):
                with open(os.path.join("./libs", f), "r") as lf:
                    it.interpret(Parser(tokenize(lf.read(), module=f), module=f).parse())
                    
    it.interpret(Parser(tokenize(code, module=module), module=module).parse())

def run():
    parser = argparse.ArgumentParser(description="PTTB Core v3.0")
    parser.add_argument("command", choices=["run", "init", "doctor", "version", "ide"], nargs="?")
    parser.add_argument("file", nargs="?")
    parser.add_argument("--enterprise", action="store_true", help="Ativa o modo corporativo profissional")
    
    args = parser.parse_args()
    PTTBLogger.splash(args.enterprise)
    
    if args.command == "init":
        with open("pttjam.yaml", "w") as f: f.write("projeto: EnterpriseApp\nmode: enterprise\n")
        print("✓ Projeto Enterprise inicializado.")
    elif args.command == "doctor":
        print("🔍 Analisando ecossistema do projeto...")
        has_windev = False
        if os.path.exists("./libs"):
            if "WinDevPTTBRKit.pttblib" in os.listdir("./libs"):
                has_windev = True
        
        print("✨ Gerando/Atualizando configuracoes de Comunidade e Compilador...")
        
        with open("Community.yaml", "w") as f:
            f.write("# PTTB Community Access\naccess_level: public\nauto_update: true\nrepos:\n  - https://hub.pttb.io/v1\n")
            
        with open("CompilerInstructions.yaml", "w") as f:
            f.write("# Advanced Compiler & Runtime Instructions\n")
            f.write("instructions:\n")
            f.write("  - {AddNewInstruction: <:readappyaml>, maxram: <:xb1>} # (1gb)\n")
            f.write("  - {AddNewInstruction: <:community_access>, maxram: <:xb0_5>} # (512mb)\n")
            f.write("optimization_level: ultra\n")
            f.write("security_checks: enabled\n")

        if has_windev:
            print("✨ WinDevPTTBRKit detectado!")
            with open("WinKitConf.yaml", "w") as f:
                f.write("# WinDevPTTBRKit Configuration\nkit_version: 1.1.0\nui_mode: hybrid\nenable_gpu: true\n")
            
            with open("App.yaml", "w") as f:
                f.write("# Application Manifest\nexecutable_name: PTTBApp.exe\nrequest_admin: true\nicon: app.ico\nprevent_debug: true\n")
            
        print("✓ Community.yaml criado.")
        print("✓ CompilerInstructions.yaml atualizado.")
        print("✓ Ambiente de desenvolvimento pronto para o mercado.")

    elif args.command == "run" or args.command is None:
        run_project(args.file, args.enterprise)
    elif args.command == "version":
        print(f"PTTB v{VERSION}")
    elif args.command == "ide":
        print("Instalando extensao VS Code...")
    else:
        parser.print_help()

if __name__ == "__main__":
    run()
