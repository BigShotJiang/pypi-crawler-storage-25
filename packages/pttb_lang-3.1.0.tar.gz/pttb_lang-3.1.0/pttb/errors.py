import sys
import os

class PTTBError(Exception):
    def __init__(self, code, message, line=None, module="Principal"):
        self.code = code
        self.message = message
        self.line = line
        self.module = module
        super().__init__(f"{code}: {message}")

    def __str__(self):
        line_info = f" na linha {self.line}" if self.line else ""
        mod_info = f" [\033[1;33mModulo: {self.module}\033[0m]"
        
        use_colors = sys.stdout.isatty() and os.name != 'nt' or os.environ.get('TERM')
        
        prefix = f"\033[91m[ERRO {self.code}]\033[0m" if use_colors else f"[ERRO {self.code}]"
        
        return f"{prefix}{mod_info} {self.message}{line_info}"

def signal_error(code, message, line=None, module="Principal"):
    print(PTTBError(code, message, line, module))
    sys.exit(1)
