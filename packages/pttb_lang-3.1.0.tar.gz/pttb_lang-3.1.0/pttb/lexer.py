import re
from .errors import signal_error

TOKEN_TYPES = [
    ('COMMENT_MULTI', r'/\*.*?\*/'),
    ('COMMENT_SINGLE', r'//.*'),
    ('STRING',   r'("[^"]*"|\'[^\']*\')'),
    ('NUMBER',   r'\d+(\.\d+)?'),
    ('BOOLEAN',  r'\b(verdadeiro|falso|true|false)\b'),
    ('DEFINIR',  r'\b(definir|declarar|variavel|let|var)\b'),
    ('RETORNAR', r'\b(retornar|devolver|return)\b'),
    ('TENTA',    r'\b(tentaA_Sorte|try|tentar)\b'),
    ('SE_DEU_RUIM', r'\b(seDeuRuim|catch|casoErro)\b'),
    ('FUNCAO',   r'\b(funcaoCLT|funcao|function|metodo)\b'),
    ('SE',       r'\b(sePixAceitou|se|if)\b'),
    ('SENAO',    r'\b(sePixNegou|senao|else)\b'),
    ('ENQUANTO', r'\b(enquantoFilaNaoAnda|enquanto|while)\b'),
    ('PARA_CADA', r'\b(praCadaDesgraca|paraCada|foreach|for)\b'),
    ('ATE_QUE',  r'\b(ateoPixCair|ate|until)\b'),
    ('EM',       r'\b(em|in)\b'),
    ('MANDA_MSG', r'\b(mandaMsg|imprimir|log|print|exibir)\b'),
    ('PEDE_INPUT', r'\b(pedeInputNoZap|entrada|input|ler)\b'),
    ('ESPERA',   r'\b(esperaFilaDoCaixa|esperar|sleep|delay)\b'),
    ('LISTA',    r'\b(caixaDePaesDeQueijo|lista|array|vector)\b'),
    ('MAPA',     r'\b(inventarioDoZAP|mapa|dicionario|dict|object)\b'),
    ('ID',       r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ('ASSIGN',   r'='),
    ('PLUS',     r'\+'),
    ('MINUS',    r'-'),
    ('MUL',      r'\*'),
    ('DIV',      r'/'),
    ('LPAREN',   r'\('),
    ('RPAREN',   r'\)'),
    ('LBRACE',   r'\{'),
    ('RBRACE',   r'\}'),
    ('LBRACKET', r'\['),
    ('RBRACKET', r'\]'),
    ('COMMA',    r','),
    ('DOT',      r'\.'),
    ('COLON',    r':'),
    ('LE',       r'<='),
    ('GE',       r'>='),
    ('LT',       r'<'),
    ('GT',       r'>'),
    ('EQ',       r'=='),
    ('NE',       r'!='),
    ('MODULO',   r'%'),
    ('NEWLINE',  r'\n'),
    ('SKIP',     r'[ \t]+'),
    ('MISMATCH', r'.'),
]

class Token:
    def __init__(self, type, value, line, column):
        self.type = type
        self.value = value
        self.line = line
        self.column = column

def tokenize(code, module="Principal"):
    tokens = []
    line_num = 1
    line_start = 0
    
    pos = 0
    while pos < len(code):
        match = None
        for token_type, pattern in TOKEN_TYPES:
            regex = re.compile(pattern, re.DOTALL if 'MULTI' in token_type else 0)
            match = regex.match(code, pos)
            if match:
                kind = token_type
                value = match.group()
                
                if kind == 'NEWLINE':
                    line_num += 1
                    line_start = pos + len(value)
                elif kind == 'SKIP' or kind == 'COMMENT_SINGLE' or kind == 'COMMENT_MULTI':
                    if kind == 'COMMENT_MULTI':
                        line_num += value.count('\n')
                    pass
                elif kind == 'MISMATCH':
                    signal_error("PTTB-002", f"Caractere invalido: '{value}'", line_num, module)
                else:
                    col = pos - line_start
                    if kind == 'NUMBER':
                        val = float(value) if '.' in value else int(value)
                    elif kind == 'STRING':
                        val = value[1:-1]
                    else:
                        val = value
                    tokens.append(Token(kind, val, line_num, col))
                
                pos = match.end()
                break
        
        if not match:
            # This should theoretically not happen if MISMATCH is '.'
            signal_error("PTTB-002", f"Falha fatal no Lexer em: {code[pos:pos+10]}", line_num, module)
            break
            
    return tokens
