from .lexer import Token
from .ast import *
from .errors import signal_error

class Parser:
    def __init__(self, tokens, module="Principal"):
        self.tokens = tokens
        self.module = module
        self.pos = 0

    def current_token(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def consume(self, expected_type=None):
        token = self.current_token()
        if token is None:
            signal_error("PTTB-001", "Fim inesperado do código", line=None, module=self.module)
        if expected_type and token.type != expected_type:
            signal_error("PTTB-001", f"Esperado {expected_type}, mas encontrou {token.type}", token.line, self.module)
        self.pos += 1
        return token

    def parse(self):
        statements = []
        while self.current_token() is not None:
            statements.append(self.parse_statement())
        return Program(statements)

    def parse_statement(self):
        token = self.current_token()
        if token.type == 'DEFINIR':
            return self.parse_var_declaration()
        elif token.type == 'FUNCAO':
            return self.parse_function_declaration()
        elif token.type == 'RETORNAR':
            self.consume('RETORNAR')
            expr = self.parse_expression()
            return ReturnStatement(expr)
        elif token.type == 'TENTA':
            return self.parse_try_catch()
        elif token.type == 'SE':
            return self.parse_if_statement()
        elif token.type == 'ENQUANTO':
            return self.parse_while_loop()
        elif token.type == 'PARA_CADA':
            return self.parse_for_each()
        elif token.type == 'ATE_QUE':
            return self.parse_repeat_until()
        elif token.type == 'MANDA_MSG':
            return self.parse_print_statement()
        elif token.type == 'ESPERA':
            return self.parse_sleep_statement()
        else:
            return self.parse_assignment_or_expr()

    def peek_type(self):
        if self.pos + 1 < len(self.tokens):
            return self.tokens[self.pos + 1].type
        return None

    def parse_var_declaration(self):
        self.consume('DEFINIR')
        name = self.consume('ID').value
        self.consume('ASSIGN')
        value = self.parse_expression()
        return VarDeclaration(name, value)

    def parse_assignment_or_expr(self):
        expr = self.parse_expression()
        if self.current_token() and self.current_token().type == 'ASSIGN':
            self.consume('ASSIGN')
            value = self.parse_expression()
            if isinstance(expr, Identifier):
                return VarAssignment(expr.name, value)
            elif isinstance(expr, IndexAccess):
                return IndexAssignment(expr.obj, expr.index, value)
            elif isinstance(expr, MemberAccess):
                return MemberAssignment(expr.obj, expr.property_name, value)
            else:
                signal_error("PTTB-001", "Atribuição inválida. Tem certeza que é um lanche válido?", getattr(expr, 'line', None))
        return expr

    def parse_function_declaration(self):
        self.consume('FUNCAO')
        name = self.consume('ID').value
        self.consume('LPAREN')
        params = []
        if self.current_token().type != 'RPAREN':
            params.append(self.consume('ID').value)
            while self.current_token().type == 'COMMA':
                self.consume('COMMA')
                params.append(self.consume('ID').value)
        self.consume('RPAREN')
        self.consume('LBRACE')
        body = []
        while self.current_token().type != 'RBRACE':
            body.append(self.parse_statement())
        self.consume('RBRACE')
        return FunctionDeclaration(name, params, body)

    def parse_if_statement(self):
        self.consume('SE')
        self.consume('LPAREN')
        condition = self.parse_expression()
        self.consume('RPAREN')
        self.consume('LBRACE')
        then_branch = []
        while self.current_token().type != 'RBRACE':
            then_branch.append(self.parse_statement())
        self.consume('RBRACE')
        
        else_branch = None
        if self.current_token() and self.current_token().type == 'SENAO':
            self.consume('SENAO')
            if self.current_token().type == 'LBRACE':
                self.consume('LBRACE')
                else_branch = []
                while self.current_token().type != 'RBRACE':
                    else_branch.append(self.parse_statement())
                self.consume('RBRACE')
                
        return IfStatement(condition, then_branch, else_branch)

    def parse_while_loop(self):
        self.consume('ENQUANTO')
        self.consume('LPAREN')
        condition = self.parse_expression()
        self.consume('RPAREN')
        self.consume('LBRACE')
        body = []
        while self.current_token().type != 'RBRACE':
            body.append(self.parse_statement())
        self.consume('RBRACE')
        return WhileLoop(condition, body)

    def parse_for_each(self):
        self.consume('PARA_CADA')
        var_name = self.consume('ID').value
        self.consume('EM')
        collection = self.parse_expression()
        self.consume('LBRACE')
        body = []
        while self.current_token().type != 'RBRACE':
            body.append(self.parse_statement())
        self.consume('RBRACE')
        return ForEachLoop(var_name, collection, body)

    def parse_repeat_until(self):
        self.consume('ATE_QUE')
        self.consume('LPAREN')
        condition = self.parse_expression()
        self.consume('RPAREN')
        self.consume('LBRACE')
        body = []
        while self.current_token().type != 'RBRACE':
            body.append(self.parse_statement())
        self.consume('RBRACE')
        return RepeatUntilLoop(condition, body)

    def parse_try_catch(self):
        self.consume('TENTA')
        self.consume('LBRACE')
        try_block = []
        while self.current_token().type != 'RBRACE':
            try_block.append(self.parse_statement())
        self.consume('RBRACE')
        
        self.consume('SE_DEU_RUIM')
        self.consume('LBRACE')
        catch_block = []
        while self.current_token().type != 'RBRACE':
            catch_block.append(self.parse_statement())
        self.consume('RBRACE')
        return TryCatchStatement(try_block, catch_block)

    def parse_print_statement(self):
        self.consume('MANDA_MSG')
        self.consume('LPAREN')
        expr = self.parse_expression()
        self.consume('RPAREN')
        return PrintStatement(expr)

    def parse_sleep_statement(self):
        self.consume('ESPERA')
        self.consume('LPAREN')
        expr = self.parse_expression()
        self.consume('RPAREN')
        return SleepStatement(expr)

    def parse_expression(self):
        return self.parse_comparison()

    def parse_comparison(self):
        node = self.parse_arithmetic()
        while self.current_token() and self.current_token().type in ('LE', 'GE', 'LT', 'GT', 'EQ', 'NE'):
            op = self.consume().type
            right = self.parse_arithmetic()
            node = BinaryOp(node, op, right)
        return node

    def parse_arithmetic(self):
        node = self.parse_term()
        while self.current_token() and self.current_token().type in ('PLUS', 'MINUS'):
            op = self.consume().type
            right = self.parse_term()
            node = BinaryOp(node, op, right)
        return node

    def parse_term(self):
        node = self.parse_factor()
        while self.current_token() and self.current_token().type in ('MUL', 'DIV'):
            op = self.consume().type
            right = self.parse_factor()
            node = BinaryOp(node, op, right)
        return node

    def parse_factor(self):
        token = self.current_token()
        node = None

        if token.type == 'NUMBER':
            self.consume()
            node = Literal(token.value)
        elif token.type == 'STRING':
            self.consume()
            node = Literal(token.value)
        elif token.type == 'BOOLEAN':
            self.consume()
            node = Literal(True if token.value == 'verdadeiro' else False)
        elif token.type == 'PEDE_INPUT':
            self.consume('PEDE_INPUT')
            self.consume('LPAREN')
            prompt = self.parse_expression()
            self.consume('RPAREN')
            node = InputExpression(prompt)
        elif token.type == 'LISTA':
            self.consume('LISTA')
            self.consume('LBRACKET')
            elements = []
            if self.current_token().type != 'RBRACKET':
                elements.append(self.parse_expression())
                while self.current_token().type == 'COMMA':
                    self.consume('COMMA')
                    elements.append(self.parse_expression())
            self.consume('RBRACKET')
            node = ListLiteral(elements)
        elif token.type == 'MAPA':
            self.consume('MAPA')
            self.consume('LBRACE')
            pairs = []
            if self.current_token().type != 'RBRACE':
                key = self.parse_expression()
                self.consume('COLON')
                value = self.parse_expression()
                pairs.append((key, value))
                while self.current_token().type == 'COMMA':
                    self.consume('COMMA')
                    key = self.parse_expression()
                    self.consume('COLON')
                    value = self.parse_expression()
                    pairs.append((key, value))
            self.consume('RBRACE')
            node = MapLiteral(pairs)
        elif token.type == 'ID':
            name = self.consume().value
            node = Identifier(name)
        elif token.type == 'LPAREN':
            self.consume('LPAREN')
            node = self.parse_expression()
            self.consume('RPAREN')
        elif token.type == 'MINUS':
            self.consume('MINUS')
            node = UnaryOp('MINUS', self.parse_factor())
        else:
            signal_error("PTTB-001", f"Início de expressão inesperado: {token.type}", token.line)

        # Parse postfix operators: [index], .prop, .method(args), (args)
        while self.current_token():
            if self.current_token().type == 'LBRACKET':
                self.consume('LBRACKET')
                index = self.parse_expression()
                self.consume('RBRACKET')
                node = IndexAccess(node, index)
            elif self.current_token().type == 'DOT':
                self.consume('DOT')
                prop = self.consume('ID').value
                node = MemberAccess(node, prop)
            elif self.current_token().type == 'LPAREN':
                self.consume('LPAREN')
                args = []
                if self.current_token().type != 'RPAREN':
                    args.append(self.parse_expression())
                    while self.current_token().type == 'COMMA':
                        self.consume('COMMA')
                        args.append(self.parse_expression())
                self.consume('RPAREN')
                
                # Check if it is a method call or function call
                if isinstance(node, MemberAccess):
                    node = MethodCall(node.obj, node.property_name, args)
                elif isinstance(node, Identifier):
                    node = FunctionCall(node.name, args)
                else:
                    # e.g., fn_list[0]() or obj.get_fn()()
                    # We can represent it as a FunctionCall on the arbitrary expr
                    # Let's adjust FunctionCall to take an expr if needed, 
                    # but for PTTB simplicity, let's just make FunctionCall take a name
                    # or extend it. Actually, I'll extend FunctionCall to take any expr.
                    node = FunctionCall(getattr(node, 'name', node), args)
            else:
                break

        return node
