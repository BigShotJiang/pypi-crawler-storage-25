from .errors import signal_error

class Environment:
    def __init__(self, parent=None):
        self.values = {}
        self.parent = parent

    def define(self, name, value):
        self.values[name] = value

    def assign(self, name, value):
        if name in self.values:
            self.values[name] = value
            return
        if self.parent:
            self.parent.assign(name, value)
            return
        signal_error("PTTB-101", f"Variável '{name}' não encontrada no inventário")

    def get(self, name):
        if name in self.values:
            return self.values[name]
        if self.parent:
            return self.parent.get(name)
        signal_error("PTTB-101", f"Variável '{name}' não encontrada no inventário")

class BuiltinFunction:
    def __init__(self, name, func):
        self.name = name
        self.func = func

    def call(self, interpreter, arguments):
        return self.func(interpreter, arguments)

class Function:
    def __init__(self, declaration, closure):
        self.declaration = declaration
        self.closure = closure

    def call(self, interpreter, arguments):
        env = Environment(self.closure)
        for i, param in enumerate(self.declaration.params):
            env.define(param, arguments[i])
        
        result = None
        for statement in self.declaration.body:
            result = interpreter.evaluate(statement, env)
        return result
