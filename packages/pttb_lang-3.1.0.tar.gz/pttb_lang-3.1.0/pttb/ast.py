class Node:
    pass

class Program(Node):
    def __init__(self, statements):
        self.statements = statements

class VarDeclaration(Node):
    def __init__(self, name, value):
        self.name = name
        self.value = value

class VarAssignment(Node):
    def __init__(self, name, value):
        self.name = name
        self.value = value

class IndexAssignment(Node):
    def __init__(self, obj, index, value):
        self.obj = obj
        self.index = index
        self.value = value

class MemberAssignment(Node):
    def __init__(self, obj, property_name, value):
        self.obj = obj
        self.property_name = property_name
        self.value = value

class FunctionDeclaration(Node):
    def __init__(self, name, params, body):
        self.name = name
        self.params = params
        self.body = body

class ReturnStatement(Node):
    def __init__(self, expr):
        self.expr = expr

class TryCatchStatement(Node):
    def __init__(self, try_block, catch_block):
        self.try_block = try_block
        self.catch_block = catch_block

class FunctionCall(Node):
    def __init__(self, name, args):
        self.name = name
        self.args = args

class MethodCall(Node):
    def __init__(self, obj, method_name, args):
        self.obj = obj
        self.method_name = method_name
        self.args = args

class IfStatement(Node):
    def __init__(self, condition, then_branch, else_branch=None):
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch

class WhileLoop(Node):
    def __init__(self, condition, body):
        self.condition = condition
        self.body = body

class ForEachLoop(Node):
    def __init__(self, var_name, collection, body):
        self.var_name = var_name
        self.collection = collection
        self.body = body

class RepeatUntilLoop(Node):
    def __init__(self, condition, body):
        self.condition = condition
        self.body = body

class BinaryOp(Node):
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

class UnaryOp(Node):
    def __init__(self, op, expr):
        self.op = op
        self.expr = expr

class Literal(Node):
    def __init__(self, value):
        self.value = value

class ListLiteral(Node):
    def __init__(self, elements):
        self.elements = elements

class MapLiteral(Node):
    def __init__(self, pairs):
        self.pairs = pairs

class Identifier(Node):
    def __init__(self, name):
        self.name = name

class IndexAccess(Node):
    def __init__(self, obj, index):
        self.obj = obj
        self.index = index

class MemberAccess(Node):
    def __init__(self, obj, property_name):
        self.obj = obj
        self.property_name = property_name

class PrintStatement(Node):
    def __init__(self, expr):
        self.expr = expr

class InputExpression(Node):
    def __init__(self, prompt_expr):
        self.prompt_expr = prompt_expr

class SleepStatement(Node):
    def __init__(self, duration_expr):
        self.duration_expr = duration_expr
