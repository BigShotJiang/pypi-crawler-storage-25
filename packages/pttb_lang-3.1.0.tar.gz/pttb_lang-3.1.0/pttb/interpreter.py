from .ast import *
from .runtime import Environment, Function, BuiltinFunction
from .errors import signal_error
import platform
import time
import math
import os

class PTTBReturn(Exception):
    def __init__(self, value): self.value = value

try: import tkinter as tk
except ImportError: tk = None

class Interpreter:
    def __init__(self, debug=False, module="Principal"):
        self.globals = Environment()
        self.debug = debug
        self.module = module
        self.os_name = platform.system().upper()
        self.keys_pressed = {}
        self.setup_builtins()

    def setup_builtins(self):
        def b_print(interp, args): 
            print(*(str(a) for a in args)); return None
        self.globals.define("imprimir", BuiltinFunction("imprimir", b_print))
        self.globals.define("log", BuiltinFunction("log", b_print))
        self.globals.define("print", BuiltinFunction("print", b_print))
        self.globals.define("mandaMsg", BuiltinFunction("mandaMsg", b_print))

        def b_info_clt(interp, args):
            import platform as pyplat
            import os as pyos
            return {
                "engine": "PTTB Enterprise v3.0",
                "os": pyplat.system(),
                "node": pyplat.node(),
                "home": pyos.path.expanduser("~")
            }
        self.globals.define("infoSistema", BuiltinFunction("infoSistema", b_info_clt))

        def b_npm_install(interp, args):
            if not args: return False
            pkg = args[0]
            print(f"[CLT] Instalando pacote NPM: {pkg}...")
            import subprocess
            res = subprocess.run(["npm", "install", pkg], capture_output=True)
            return res.returncode == 0
        self.globals.define("npmInstalar", BuiltinFunction("npmInstalar", b_npm_install))

        def b_node_exec(interp, args):
            if not args: return None
            code = args[0]
            import subprocess
            res = subprocess.run(["node", "-e", code], capture_output=True, text=True)
            return res.stdout.strip()
        self.globals.define("nodeExecutar", BuiltinFunction("nodeExecutar", b_node_exec))

        def b_clt_rescisao(interp, args):
            if len(args) < 2: return 0
            salario = float(args[0])
            meses = int(args[1])
            return salario * meses * 0.08 + (salario / 12 * meses) # Simplified FGTS + proportional
        self.globals.define("cltCalculaRescisao", BuiltinFunction("cltCalculaRescisao", b_clt_rescisao))

        def b_pega_ip(interp, args):
            import socket
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                ip = s.getsockname()[0]
                s.close()
                return ip
            except: return "127.0.0.1"
        self.globals.define("pegaIp", BuiltinFunction("pegaIp", b_pega_ip))

        def b_preview_async(interp, args):
            print("[PREVIEW] Rodando tarefa em background simulado...")
            return True
        self.globals.define("taskAsync", BuiltinFunction("taskAsync", b_preview_async))

        # WinDevPTTBRKit Core
        def b_new_win_form(interp, args):
            title = args[0] if len(args) > 0 else "PTTB Window"
            print(f"[WinDev] Criando nova janela: {title}")
            if tk:
                try:
                    root = tk.Tk()
                    root.title(title)
                    return root
                except Exception as e:
                    print(f"[WinDev-Aviso] Nao foi possivel abrir interface grafica: {e}")
            return {"type": "window", "title": title}
        self.globals.define("NewWinFormUI", BuiltinFunction("NewWinFormUI", b_new_win_form))

        def b_on_key_pressed(interp, args):
            callback = args[0]
            print("[WinDev] Evento OnKeyPressed registrado.")
            # Simulação ou integração real com hook de teclado se necessário
            return True
        self.globals.define("OnKeyPressed", BuiltinFunction("OnKeyPressed", b_on_key_pressed))

        def b_new_tween(interp, args):
            obj, target, duration = args[0], args[1], args[2]
            print(f"[WinDev] Iniciando Tween Animation para {duration}s")
            return {"tweening": True, "target": target}
        self.globals.define("NewTweenAnimation", BuiltinFunction("NewTweenAnimation", b_new_tween))

        def b_on_tween(interp, args):
            callback = args[0]
            print("[WinDev] Evento OnTweenAnimation registrado.")
            return True
        self.globals.define("OnTweenAnimation", BuiltinFunction("OnTweenAnimation", b_on_tween))

        def b_write_text(interp, args):
            text = args[0]
            print(f"[WinDev] Escrevendo na tela: {text}")
            return True
        self.globals.define("WriteText", BuiltinFunction("WriteText", b_write_text))

        def b_read_text(interp, args):
            print("[WinDev] Lendo texto da interface...")
            return "Conteudo simulado"
        self.globals.define("OnText", BuiltinFunction("OnText", b_read_text))

        def b_write_file_wd(interp, args):
            path, content = args[0], args[1]
            with open(path, "w") as f: f.write(content)
            return True
        self.globals.define("WriteFile", BuiltinFunction("WriteFile", b_write_file_wd))

        def b_read_file_wd(interp, args):
            path = args[0]
            if os.path.exists(path):
                with open(path, "r") as f: return f.read()
            return ""
        self.globals.define("ReadFile", BuiltinFunction("ReadFile", b_read_file_wd))

        def b_on_activated(interp, args):
            callback = args[0]
            print("[WinDev] Evento OnActivated registrado.")
            return True
        self.globals.define("OnActivated", BuiltinFunction("OnActivated", b_on_activated))

        # Advanced UI Controls
        def b_new_button(interp, args):
            parent, text, callback = args[0], args[1], args[2]
            print(f"[WinDev] Criando Botao: '{text}'")
            return {"type": "button", "text": text}
        self.globals.define("NewButtonUI", BuiltinFunction("NewButtonUI", b_new_button))

        def b_set_style(interp, args):
            obj, style_dict = args[0], args[1]
            print(f"[WinDev] Aplicando estilo ao objeto: {style_dict}")
            return True
        self.globals.define("SetControlStyle", BuiltinFunction("SetControlStyle", b_set_style))

        # System & Multimedia
        def b_show_msg(interp, args):
            title, msg = args[0], args[1]
            print(f"[WinDev-Box] {title}: {msg}")
            return True
        self.globals.define("ShowMessageBox", BuiltinFunction("ShowMessageBox", b_show_msg))

        def b_play_sound(interp, args):
            path = args[0]
            print(f"[WinDev-Audio] Reproduzindo: {path}")
            return True
        self.globals.define("PlaySound", BuiltinFunction("PlaySound", b_play_sound))

        # Advanced Network & System
        def b_download(interp, args):
            url, dest = args[0], args[1]
            print(f"[WinDev-Net] Baixando {url} para {dest}...")
            return True
        self.globals.define("DownloadFile", BuiltinFunction("DownloadFile", b_download))

        def b_get_processes(interp, args):
            print("[WinDev-Sys] Listando processos ativos...")
            return ["pttb.exe", "node.exe", "python.exe"]
        self.globals.define("GetProcessInfo", BuiltinFunction("GetProcessInfo", b_get_processes))

        def b_get_metrics(interp, args):
            return {"width": 1920, "height": 1080, "dpi": 96}
        self.globals.define("GetSystemMetrics", BuiltinFunction("GetSystemMetrics", b_get_metrics))

        # Dynamic Compiler Instructions
        def b_add_comp_inst(interp, args):
            inst, ram = args[0], args[1]
            line = f"  - {{AddNewInstruction: <:{inst}>, maxram: <:{ram}>}}"
            path = "CompilerInstructions.yaml"
            content = ""
            if os.path.exists(path):
                with open(path, "r") as f: content = f.read()
            else:
                content = "# Compiler & Runtime Instructions\ninstructions:\n"
            
            if line not in content:
                if "instructions:" not in content:
                    content += "instructions:\n"
                # Insert after instructions: header
                lines = content.split("\n")
                for i, l in enumerate(lines):
                    if "instructions:" in l:
                        lines.insert(i+1, line)
                        break
                with open(path, "w") as f: f.write("\n".join(lines))
                print(f"[Compiler] Instrucao adicionada: {inst}")
            return True
        self.globals.define("AdicionarInstrucaoCompilador", BuiltinFunction("AdicionarInstrucaoCompilador", b_add_comp_inst))

        def b_rem_comp_inst(interp, args):
            inst = args[0]
            path = "CompilerInstructions.yaml"
            if not os.path.exists(path): return False
            with open(path, "r") as f: lines = f.readlines()
            new_lines = [l for l in lines if f"<:{inst}>" not in l]
            with open(path, "w") as f: f.writelines(new_lines)
            print(f"[Compiler] Instrucao removida: {inst}")
            return True
        self.globals.define("RemoverInstrucaoCompilador", BuiltinFunction("RemoverInstrucaoCompilador", b_rem_comp_inst))

        # Community & Sharing Features
        def b_community_download(interp, args):
            pkg_name = args[0]
            print(f"[Comunidade] Buscando pacote '{pkg_name}' no PTTB-Hub...")
            # Simulando download
            return True
        self.globals.define("comunidadeBaixar", BuiltinFunction("comunidadeBaixar", b_community_download))

        def b_community_share(interp, args):
            print("[Comunidade] Codigo compartilhado com sucesso no Mural de Avisos!")
            return "https://pttb.io/share/xyz123"
        self.globals.define("comunidadeCompartilhar", BuiltinFunction("comunidadeCompartilhar", b_community_share))

        # New CLT/Enterprise Features
        def b_clt_pj(interp, args):
            salario = float(args[0])
            # Simplified: PJ needs to be ~1.5x - 1.8x CLT to compensate
            return salario * 1.65
        self.globals.define("cltViraPJ", BuiltinFunction("cltViraPJ", b_clt_pj))

        def b_bate_ponto(interp, args):
            from datetime import datetime
            now = datetime.now().strftime("%H:%M:%S")
            with open("ponto.txt", "a") as f:
                f.write(f"Ponto batido as: {now}\n")
            print(f"[Empresa] Ponto batido! Horario: {now}")
            return True
        self.globals.define("batePonto", BuiltinFunction("batePonto", b_bate_ponto))

        self.globals.define("mandaMsg", BuiltinFunction("mandaMsg", b_print))

    def interpret(self, program):
        try:
            for statement in program.statements: self.evaluate(statement, self.globals)
        except PTTBReturn: pass
        except Exception as e:
            if not isinstance(e, SystemExit):
                signal_error("PTTB-999", f"Critical Failure: {str(e)}", module=self.module)

    def evaluate(self, node, env):
        t = type(node)
        if t == Literal: return node.value
        if t == Identifier: return env.get(node.name)
        if t == BinaryOp:
            left, right = self.evaluate(node.left, env), self.evaluate(node.right, env)
            op = node.op
            if op == 'PLUS': return left + right if not isinstance(left, (str, float, int)) or not isinstance(right, (str, float, int)) else (left + right if not isinstance(left, str) and not isinstance(right, str) else str(left) + str(right))
            if op == 'MINUS': return left - right
            if op == 'MUL': return left * right
            if op == 'DIV': return left / right
            if op == 'LT': return left < right
            if op == 'GT': return left > right
            if op == 'EQ': return left == right
        
        if t == VarDeclaration:
            val = self.evaluate(node.value, env)
            env.define(node.name, val)
            return val
        
        if t == VarAssignment:
            val = self.evaluate(node.value, env)
            env.assign(node.name, val)
            return val

        if t == FunctionDeclaration:
            f = Function(node, env)
            env.define(node.name, f)
            return f

        if t == ReturnStatement:
            raise PTTBReturn(self.evaluate(node.expr, env))

        if t == FunctionCall:
            func = env.get(node.name) if isinstance(node.name, str) else self.evaluate(node.name, env)
            args = [self.evaluate(arg, env) for arg in node.args]
            if isinstance(func, BuiltinFunction): return func.call(self, args)
            new_env = Environment(func.closure)
            for i, p in enumerate(func.declaration.params): 
                if i < len(args): new_env.define(p, args[i])
            try:
                res = None
                for s in func.declaration.body: res = self.evaluate(s, new_env)
                return res
            except PTTBReturn as r: return r.value

        if t == IfStatement:
            if self.evaluate(node.condition, env):
                for s in node.then_branch: self.evaluate(s, env)
            elif node.else_branch:
                for s in node.else_branch: self.evaluate(s, env)
        
        if t == WhileLoop:
            while self.evaluate(node.condition, env):
                for s in node.body: self.evaluate(s, env)

        if t == PrintStatement:
            val = self.evaluate(node.expr, env)
            print(val)

        if t == MemberAccess:
            target = self.evaluate(node.obj, env)
            if isinstance(target, dict): return target.get(node.property_name)
            return getattr(target, node.property_name, None)

        return None
