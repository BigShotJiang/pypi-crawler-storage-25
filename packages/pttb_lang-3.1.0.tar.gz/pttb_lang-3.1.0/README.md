# PTTB - Português Técnico do Brasil 🇧🇷 (v2.13.0)

[![PyPI Version](https://img.shields.io/pypi/v/pttb-lang.svg)](https://pypi.org/project/pttb-lang/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**PTTB** é o motor de execução brasileiro de alta performance. Uma linguagem de programação que traduz a realidade do desenvolvedor CLT para um runtime poderoso, cross-platform e focado em produtividade.

> "Porque o seu código deve ser tão claro quanto um café forte na segunda de manhã."

---

## 🚀 Por que PTTB?

O PTTB não é apenas um "wrapper" de Python; é um ecossistema completo com:
- **Velocidade Nitro:** Processamento de milhares de iterações em segundos.
- **Gerenciador de Pacotes PTPC:** Instalação ultra-rápida via hidratação de headers.
- **Segurança Nativa:** Proteção contra debuggers e injeção de código suspeito.
- **Pronto para a Comunidade:** Ferramentas para publicar e compartilhar seus próprios módulos.

---

## 🛠️ Instalação Profissional

```bash
# Instale o motor oficial
pip install pttb-lang

# Configure seu ambiente de desenvolvimento (VS Code)
pttb ide
```

---

## 📖 Guia Rápido de Sobrevivência (Sintaxe)

### Variáveis e Coleções
```pttb
definir saldo = 1500.00
definir compras = caixaDePaesDeQueijo ["Coxinha", "Kibe", "Café"]
definir perfil = inventarioDoZAP { "cargo": "Dev Senior", "senioridade": "CLT" }
```

### Controle de Fluxo Brasileiro
```pttb
// O clássico IF/ELSE
sePixAceitou (saldo >= 50.0) {
    mandaMsg("Almoço garantido!")
} sePixNegou {
    mandaMsg("Fila do bandejão...")
}

// Loops de Repetição
enquantoFilaNaoAnda (x < 100) { x = x + 1 }
praCadaDesgraca lanche em compras { mandaMsg("Lanche: " + lanche) }
```

### Funções e Erros (A Sorte do Dev)
```pttb
funcaoCLT calcularImposto(valor) {
    tentaA_Sorte {
        retornar valor * 0.27
    } seDeuRuim {
        mandaMsg("Erro no cálculo do Leão!")
        retornar 0
    }
}
```

---

## 🛡️ Segurança e AntiCheat
Proteja sua aplicação com o pacote oficial `pttb-anticheat`:
```pttb
vigiarHackers() // Detecta debuggers e bloqueia injeção de DLLs automaticamente
```

---

## 📦 Comandos da CLI (Ecossistema JAM)

| Comando | Descrição |
| :--- | :--- |
| `pttb init` | Cria um novo projeto com arquitetura profissional. |
| `pttb ide` | Instala o realce de sintaxe oficial no seu VS Code. |
| `pttb run` | Executa o ponto de entrada (`main.pttb`) do projeto. |
| `pttb build` | Gera executáveis (.exe, .dmg, .bin) para distribuição. |
| `pttb publish` | Compacta e prepara um módulo para compartilhamento. |
| `pttb doctor` | Analisa a saúde do seu ambiente PTTB local. |

---

## 🏢 Arquitetura do Projeto
Ao rodar `pttb init`, você terá:
- **`pttjam.yaml`**: Manifesto central de dependências e metadados.
- **`ProjectAuthMark.ptmn`**: Arquivo binário de cache para builds instantâneos.
- **`ThirdSoftWare.yaml`**: Configuração de interoperação com Lua e JS.
- **`libs/`**: Onde residem seus headers `.pttblib`.

---

## 🤝 Contribua com a Nação PTTB
Desenvolvido por brasileiros, para brasileiros. Sinta-se à vontade para expandir a Standard Lib ou sugerir novas palavras-chave temáticas!

*Powered by PTTB Engine - A revolução brasileira no mundo da programação.*
