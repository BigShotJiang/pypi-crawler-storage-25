"""Helpers de renderização do CLI: refresh, frame único, live animado.

Mantém a única `Console` global para todos os comandos (importável daqui
ou via __main__.console , mesmo objeto).
"""
import time

from rich.align import Align
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from . import client, notifications, telemetry
from .config import GREET_FILE
from .session import cache, load_cache
from .ui import empty_pet, panel


console = Console()


# Estilos por tipo de toast , combinam com notifications.Toast.render().
_UNLOCK_STYLES: dict[str, dict[str, str]] = {
    "unlock":           {"color": "bright_magenta", "verb": "DESBLOQUEADO"},
    "stage_up":         {"color": "bright_cyan",    "verb": "EVOLUIU"},
    "level_up":         {"color": "bright_yellow",  "verb": "LEVEL UP"},
    "streak_milestone": {"color": "bright_red",     "verb": "STREAK"},
}


def _unlock_frame(t: "notifications.Toast", step: int, total: int) -> Panel:
    """Monta um frame da animação cinemática de unlock.

    step ∈ [0, total). A intensidade do brilho cresce com `step`.
    """
    style = _UNLOCK_STYLES.get(t.kind, _UNLOCK_STYLES["unlock"])
    color = style["color"]
    verb = style["verb"]

    # Aura: caracteres "irradiando" do ícone, mais densos nos últimos frames.
    sparks = ["·", "✦", "✧", "★", "✦"]
    aura_char = sparks[min(step, len(sparks) - 1)]
    width = 3 + step * 2          # tamanho da linha de partículas
    aura = (aura_char + " ") * width
    aura = aura.strip()

    # Ícone gigante: dá foco ao símbolo do achievement.
    icon_line = f"[bold {color}]{t.icon}[/bold {color}]"

    # Verbo no penúltimo / último frame só (suspense → revelação).
    show_verb = step >= max(0, total - 3)
    verb_line = f"[bold {color}]{verb}[/bold {color}]" if show_verb else " "

    # Título aparece a partir do 3º frame.
    show_title = step >= 2
    title_line = (
        f"[bold]{t.title}[/bold]" if show_title else " "
    )

    # Detalhe só no último frame (recompensa quem esperou).
    show_detail = step >= total - 1 and t.detail
    detail_line = f"[dim]{t.detail}[/dim]" if show_detail else " "

    body = Text.from_markup(
        f"{aura}\n\n"
        f"{icon_line}\n\n"
        f"{verb_line}\n"
        f"{title_line}\n"
        f"{detail_line}\n\n"
        f"{aura}"
    )
    return Panel(
        Align.center(body),
        border_style=color,
        padding=(1, 4),
    )


def play_unlock_animation(t: "notifications.Toast",
                          duration: float = 1.5,
                          frames: int = 5) -> None:
    """Roda a sequência cinemática (5 frames, ~1.5s) e limpa antes do painel.

    Só faz sentido pra eventos "WOW" , unlocks, stage up, level up,
    streak milestone. No fim limpa a tela pra o painel apareça limpo.
    """
    if t.kind not in _UNLOCK_STYLES:
        return
    per_frame = max(0.05, duration / frames)
    try:
        console.clear()
        with Live(_unlock_frame(t, 0, frames),
                  console=console,
                  refresh_per_second=max(1.0, frames / max(duration, 0.1)),
                  screen=False, transient=True) as view:
            for step in range(frames):
                view.update(_unlock_frame(t, step, frames))
                time.sleep(per_frame)
    except KeyboardInterrupt:
        pass


def refresh() -> tuple[dict, dict, str | None, dict, list[notifications.Toast]]:
    """Sync com o servidor + atualiza cache local + detecta progresso.

    Returns:
        (pet, health, nick, streak, toasts) , toasts é a lista de mudanças
        notáveis desde o último refresh (achievement novo, stage up, etc.).
        Lista vazia se nada mudou ou é primeira run.
    """
    h = client.health()
    data = client.sync()
    prev = load_cache()  # snapshot anterior pra diff

    if data:
        pet = data["pet"]
        nick = data["user"].get("nick")
        streak = data["user"].get("streak") or {}
        # busca achievements pra detectar unlocks (1 request extra, ~5ms)
        achievements = client.my_achievements()
        snapshot = {
            "pet": pet, "nick": nick, "streak": streak,
            "achievements": achievements,
        }
        toasts = notifications.diff(prev, snapshot)
        for t in toasts:
            kind = getattr(t, "kind", None)
            if kind == "unlock":
                telemetry.track("first_unlock")
            elif kind == "stage_up":
                telemetry.track("stage_up")
        cache(snapshot)
        return pet, h, nick, streak, toasts

    # offline: cache puro, sem toasts (não dá pra confiar em diff sem server)
    cached = prev or {}
    return (cached.get("pet", empty_pet()), h, cached.get("nick"),
            cached.get("streak", {}), [])


def _print_toasts(toasts: list[notifications.Toast] | None) -> None:
    """Anima eventos "WOW" e imprime os demais como linha simples.

    Unlocks e stage-ups ganham animação cinemática (1.5s, tela limpa).
    Level-ups e streak milestones ficam como toast textual antes do painel.
    Pra unlocks, tenta buscar a frase cacheada do pet (1 chamada/code/user).
    """
    if not toasts:
        return
    cinematic_kinds = {"unlock", "stage_up"}
    for t in toasts:
        if t.kind in cinematic_kinds:
            shown = t
            if t.kind == "unlock" and t.code:
                phrase = client.unlock_phrase(t.code)
                if phrase:
                    shown = notifications.Toast(
                        kind=t.kind, icon=t.icon, title=t.title,
                        detail=phrase, code=t.code,
                    )
            play_unlock_animation(shown)
    text_toasts = [t for t in toasts if t.kind not in cinematic_kinds]
    for t in text_toasts:
        console.print(t.render())
    if text_toasts:
        console.print()


def show_static(pet, h, nick, msg=None, show_credits=False, streak=None,
                toasts=None):
    """Frame único , usado por comandos de ação."""
    _print_toasts(toasts)
    console.print(panel(pet, h, nick, message=msg, tick=2,
                        show_credits=show_credits, streak=streak))


def live_for(pet, h, nick, msg=None, seconds=2.5, fps=6.0,
             show_credits=False, streak=None, toasts=None):
    """Mostra o pet animado por alguns segundos."""
    _print_toasts(toasts)
    tick = 0
    end = time.time() + seconds
    try:
        with Live(panel(pet, h, nick, message=msg, tick=tick,
                        show_credits=show_credits, streak=streak),
                  console=console, refresh_per_second=fps, screen=False) as view:
            while time.time() < end:
                time.sleep(1.0 / fps)
                tick += 1
                view.update(panel(pet, h, nick, message=msg, tick=tick,
                                  show_credits=show_credits, streak=streak))
    except KeyboardInterrupt:
        pass


def invalidate_greet_cache() -> None:
    """Apaga o cache do greet pro próximo abrir do shell mostrar dados novos."""
    try:
        if GREET_FILE.exists():
            GREET_FILE.unlink()
    except OSError:
        pass
