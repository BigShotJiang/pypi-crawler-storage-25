"""Constantes e regras determinísticas do pet , uma fonte só de verdade.

Antes essas tabelas viviam soltas em ui.py. Agora qualquer módulo (render,
notifications, next_cmd) importa daqui.

Não tem lógica de I/O nem chamada de rede. Só dados e helpers puros.
"""
from __future__ import annotations


# Ordem cronológica dos estágios.
STAGE_AGE: list[str] = [
    "egg", "hatchling", "junior", "pleno",
    "senior", "staff", "tenx", "legend",
]

# Label bonitinho pra UI. Espelha o do server (achievements/profile).
STAGE_LABEL: dict[str, str] = {
    "egg":       "Ovo",
    "hatchling": "Hatchling",
    "junior":    "Junior Dev",
    "pleno":     "Pleno",
    "senior":    "Senior",
    "staff":     "Staff",
    "tenx":      "10x",
    "legend":    "Lenda",
}

# Emoji curtinho por estágio (1-char visual). Espelha STAGE_AGE.
STAGE_EMOJI: dict[str, str] = {
    "egg":       "🥚",
    "hatchling": "🐣",
    "junior":    "👶",
    "pleno":     "🧑",
    "senior":    "🧓",
    "staff":     "🧙",
    "tenx":      "🦸",
    "legend":    "👑",
}

# XP mínimo pra entrar em cada estágio. Tem que bater com a regra do server.
STAGE_THRESHOLD: dict[str, int] = {
    "egg":       0,
    "hatchling": 50,
    "junior":    200,
    "pleno":     1000,
    "senior":    3000,
    "staff":     8000,
    "tenx":      20000,
    "legend":    50000,
}

# Marcos de streak que merecem celebração (achievement já cobre 3/7/30
# mas reforçamos visualmente os intermediários e os longos).
STREAK_MILESTONES: frozenset[int] = frozenset({1, 3, 7, 14, 30, 60, 100, 365})


def next_stage(stage: str) -> str | None:
    """Retorna o nome do próximo estágio, ou None se já é lenda."""
    if stage not in STAGE_AGE:
        return None
    idx = STAGE_AGE.index(stage)
    if idx >= len(STAGE_AGE) - 1:
        return None
    return STAGE_AGE[idx + 1]


def xp_to_next(xp: int, stage: str) -> int | None:
    """Quantos XP faltam pra próxima evolução. None se já é lenda."""
    nxt = next_stage(stage)
    if nxt is None:
        return None
    return max(0, STAGE_THRESHOLD[nxt] - xp)


def next_streak_milestone(days: int) -> int | None:
    """Próximo marco de streak ainda não atingido, ou None se passou de tudo."""
    return next((m for m in sorted(STREAK_MILESTONES) if m > days), None)
