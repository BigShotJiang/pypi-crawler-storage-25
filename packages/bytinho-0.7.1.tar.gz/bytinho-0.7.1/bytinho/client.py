import httpx

from .config import SERVER_URL
from .session import user_id


def _h() -> dict:
    return {"X-Bytinho-User": user_id(), "User-Agent": "bytinho-cli"}


def ws_url() -> str:
    base = SERVER_URL.replace("http://", "ws://").replace("https://", "wss://")
    return f"{base}/ws/chat?u={user_id()}"


def health() -> dict:
    try:
        with httpx.Client(timeout=3.0) as c:
            r = c.get(f"{SERVER_URL}/health", headers=_h())
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return {"status": "offline", "brain": "offline", "chat_online": 0}


def sync() -> dict | None:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/sync", headers=_h())
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return None


def action(name: str, **kw) -> dict | None:
    body = {"action": name, **kw}
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/pet/action", headers=_h(), json=body)
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return None


def commit_react(meta: dict) -> str | None:
    """Pede 1 linha do brain reagindo ao commit recém-feito.

    Timeout curto: melhor não printar nada do que segurar o terminal do dev.
    """
    try:
        with httpx.Client(timeout=8.0) as c:
            r = c.post(
                f"{SERVER_URL}/api/pet/commit-react",
                headers=_h(), json=meta,
            )
            if r.status_code == 200:
                d = r.json()
                if d.get("ok") and d.get("reply"):
                    return d["reply"]
    except httpx.HTTPError:
        pass
    return None


def sync_history(commits: list[dict]) -> dict | None:
    try:
        with httpx.Client(timeout=30.0) as c:
            r = c.post(
                f"{SERVER_URL}/api/pet/sync-history",
                headers=_h(),
                json={"commits": commits},
            )
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return None


def talk(message: str) -> dict | None:
    from .prefs import get_catchphrase
    payload: dict = {"message": message}
    cp = get_catchphrase()
    if cp:
        payload["catchphrase"] = cp
    try:
        with httpx.Client(timeout=15.0) as c:
            r = c.post(f"{SERVER_URL}/api/pet/talk", headers=_h(), json=payload)
            if r.status_code == 200:
                return r.json()
            if r.status_code == 429:
                return {"reply": "ufa, falei demais hoje 😅", "ok": False}
            if r.status_code == 500:
                # provavelmente pet ainda não existe , pede sync e tenta de novo
                sync()
                r2 = c.post(f"{SERVER_URL}/api/pet/talk", headers=_h(), json=payload)
                if r2.status_code == 200:
                    return r2.json()
    except httpx.HTTPError:
        pass
    return None


def set_nick(nick: str) -> tuple[bool, str]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/user/nick", headers=_h(), json={"nick": nick})
            if r.status_code == 200:
                return True, "ok"
            try:
                return False, r.json().get("detail", "erro")
            except ValueError:
                return False, f"erro {r.status_code}"
    except httpx.HTTPError as ex:
        return False, str(ex)


def rename_pet(name: str) -> tuple[bool, str]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/pet/rename", headers=_h(), json={"name": name})
            if r.status_code == 200:
                return True, "ok"
            try:
                return False, r.json().get("detail", "erro")
            except ValueError:
                return False, f"erro {r.status_code}"
    except httpx.HTTPError as ex:
        return False, str(ex)


def report_user(nick: str, reason: str = "") -> tuple[bool, str]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/user/report", headers=_h(),
                       json={"nick": nick, "reason": reason})
            if r.status_code == 200:
                return True, "ok"
            try:
                return False, r.json().get("detail", "erro")
            except ValueError:
                return False, f"erro {r.status_code}"
    except httpx.HTTPError as ex:
        return False, str(ex)


def ranking() -> list[dict]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.get(f"{SERVER_URL}/api/ranking", headers=_h())
            if r.status_code == 200:
                return r.json().get("top", [])
    except httpx.HTTPError:
        pass
    return []


def my_achievements() -> list[dict]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.get(f"{SERVER_URL}/api/me/achievements", headers=_h())
            if r.status_code == 200:
                return r.json().get("achievements", [])
    except httpx.HTTPError:
        pass
    return []


def unlock_phrase(code: str) -> str | None:
    """Frase do pet pra um achievement (cacheada server-side por user×code).

    None em qualquer falha , a animação ainda funciona com o desc original.
    """
    try:
        with httpx.Client(timeout=8.0) as c:
            r = c.get(
                f"{SERVER_URL}/api/me/achievements/{code}/phrase", headers=_h(),
            )
            if r.status_code == 200:
                p = r.json().get("phrase")
                return p if isinstance(p, str) and p else None
    except httpx.HTTPError:
        pass
    return None


def closet() -> dict | None:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.get(f"{SERVER_URL}/api/me/closet", headers=_h())
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return None


def equip_hat(code: str) -> tuple[bool, str]:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(
                f"{SERVER_URL}/api/me/closet/equip",
                headers=_h(), json={"code": code},
            )
            if r.status_code == 200:
                return True, code
            try:
                return False, r.json().get("detail", "erro")
            except ValueError:
                return False, f"erro {r.status_code}"
    except httpx.HTTPError as ex:
        return False, str(ex)


def unequip_hat() -> bool:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.post(f"{SERVER_URL}/api/me/closet/unequip", headers=_h())
            return r.status_code == 200
    except httpx.HTTPError:
        return False


def profile(nick: str) -> dict | None:
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.get(f"{SERVER_URL}/api/u/{nick}")
            if r.status_code == 200:
                return r.json()
    except httpx.HTTPError:
        pass
    return None
