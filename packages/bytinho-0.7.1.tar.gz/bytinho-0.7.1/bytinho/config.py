import os
from pathlib import Path

from platformdirs import user_data_dir

SERVER_URL = os.environ.get("BYTINHO_SERVER", "https://bytinho.com").rstrip("/")

DATA_DIR = Path(user_data_dir("bytinho", appauthor=False))
DATA_DIR.mkdir(parents=True, exist_ok=True)

STATE_FILE = DATA_DIR / "state.json"
USER_FILE  = DATA_DIR / "user.json"
GREET_FILE = DATA_DIR / "greet.json"  # cache pro shell prompt (TTL curto)
PREFS_FILE = DATA_DIR / "prefs.json"  # preferências locais (skin, etc.)


def supports_emoji() -> bool:
    """Heurística simples: UTF-8 + não ser cmd.exe legacy."""
    if os.environ.get("BYTINHO_NO_EMOJI"):
        return False
    enc = (os.environ.get("LC_ALL") or os.environ.get("LANG") or "").lower()
    if "utf" in enc:
        return True
    # Windows Terminal / VS Code definem WT_SESSION ou TERM_PROGRAM
    if os.environ.get("WT_SESSION") or os.environ.get("TERM_PROGRAM"):
        return True
    return False


EMOJI = supports_emoji()


def e(emoji: str, fallback: str) -> str:
    return emoji if EMOJI else fallback
