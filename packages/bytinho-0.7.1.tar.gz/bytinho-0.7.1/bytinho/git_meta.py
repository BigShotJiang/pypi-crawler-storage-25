"""Extrai metadados do último commit local. Roda no PC do user, só envia
agregados (sem código, sem nomes de arquivo)."""
import re
import subprocess
from datetime import datetime


# extensão → nome curto de linguagem. Lista enxuta: cobre 95% dos commits
# de devs reais sem virar enciclopédia.
_LANG_BY_EXT = {
    "py": "python", "js": "js", "jsx": "js", "ts": "ts", "tsx": "ts",
    "rs": "rust", "go": "go", "java": "java", "kt": "kotlin", "swift": "swift",
    "c": "c", "h": "c", "cpp": "cpp", "cc": "cpp", "cs": "csharp",
    "rb": "ruby", "php": "php", "lua": "lua", "ex": "elixir", "exs": "elixir",
    "html": "html", "css": "css", "scss": "css", "vue": "vue", "svelte": "svelte",
    "sql": "sql", "sh": "shell", "bash": "shell", "zsh": "shell",
    "yml": "yaml", "yaml": "yaml", "toml": "toml", "json": "json",
    "md": "markdown", "rst": "doc",
    "dockerfile": "docker", "tf": "terraform",
}

_PREFIX_RE = re.compile(
    r"^(feat|fix|refactor|chore|docs|test|perf|style|build|ci|revert)"
    r"(\([^)]+\))?!?:",
    re.IGNORECASE,
)


def _git(*args: str) -> str:
    try:
        out = subprocess.check_output(
            ["git", *args], stderr=subprocess.DEVNULL, timeout=2,
        )
        return out.decode("utf-8", errors="replace").strip()
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return ""


def _classify(path: str) -> str | None:
    name = path.lower().rsplit("/", 1)[-1]
    if name == "dockerfile":
        return "docker"
    ext = name.rsplit(".", 1)[-1] if "." in name else ""
    return _LANG_BY_EXT.get(ext)


def _kind(message: str) -> str:
    m = _PREFIX_RE.match(message.strip())
    return m.group(1).lower() if m else "other"


def collect() -> dict | None:
    """Lê o último commit. Retorna None se não está num repo git."""
    sha = _git("rev-parse", "HEAD")
    if not sha:
        return None

    message = _git("log", "-1", "--pretty=%s")[:200]
    branch  = _git("rev-parse", "--abbrev-ref", "HEAD")[:60]

    # diff stats: "+N -M" por arquivo. numstat dá tabs.
    stats = _git("show", "--numstat", "--format=", "HEAD")
    added = removed = 0
    paths: list[str] = []
    for line in stats.splitlines():
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        a, r, p = parts
        # "-" em binários
        if a.isdigit():
            added += int(a)
        if r.isdigit():
            removed += int(r)
        paths.append(p)

    langs = sorted({lang for p in paths if (lang := _classify(p))})

    return {
        "message":  message,
        "hour":     datetime.now().hour,
        "files":    len(paths),
        "lines_added":   added,
        "lines_removed": removed,
        "kind":     _kind(message),
        "branch":   branch,
        "languages": langs,
    }


def collect_history(days: int = 30, limit: int = 500) -> list[dict] | None:
    """Lê histórico recente. Retorna lista de commits (mesmo formato de collect)
    ou None se não é repo git. Mais antigo primeiro pra streak fazer sentido."""
    if not _git("rev-parse", "HEAD"):
        return None
    branch = _git("rev-parse", "--abbrev-ref", "HEAD")[:60]
    raw = subprocess.run(
        ["git", "log", f"--since={days} days ago", f"--max-count={limit}",
         "--no-merges", "--numstat", "--pretty=format:COMMIT%x09%H%x09%ct%x09%s"],
        capture_output=True, timeout=10,
    )
    text = raw.stdout.decode("utf-8", errors="replace")
    if not text.strip():
        return []

    out: list[dict] = []
    cur: dict | None = None
    paths: list[str] = []
    for line in text.splitlines():
        if line.startswith("COMMIT\t"):
            if cur:
                cur["files"]     = len(paths)
                cur["languages"] = sorted({lang for p in paths if (lang := _classify(p))})
                out.append(cur)
            try:
                _, sha, ts, msg = line.split("\t", 3)
                ts_int = int(ts)
            except ValueError:
                cur, paths = None, []
                continue
            dt = datetime.fromtimestamp(ts_int)
            cur = {
                "sha":       sha,
                "message":   msg[:200],
                "hour":      dt.hour,
                "files":     0,
                "lines_added":   0,
                "lines_removed": 0,
                "kind":      _kind(msg),
                "branch":    branch,
                "languages": [],
                "ts":        ts_int,
            }
            paths = []
        elif line.strip() and cur is not None:
            parts = line.split("\t")
            if len(parts) != 3:
                continue
            a, r, p = parts
            if a.isdigit():
                cur["lines_added"] += int(a)
            if r.isdigit():
                cur["lines_removed"] += int(r)
            paths.append(p)
    if cur:
        cur["files"]     = len(paths)
        cur["languages"] = sorted({lang for p in paths if (lang := _classify(p))})
        out.append(cur)

    out.reverse()  # antigo → novo
    return out
