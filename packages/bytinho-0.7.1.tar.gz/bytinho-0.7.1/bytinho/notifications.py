"""Sistema de notificações , detecta progressão entre sessions.

Ideia: a cada refresh, comparamos o snapshot atual do server com o que
guardamos no cache. Se algo novo apareceu (achievement, stage up, milestone
de streak, level up), devolvemos uma lista de toasts pra UI mostrar com
destaque ANTES da animação do pet , esse é o momento "wow".

Não persiste nada por conta própria , quem chama é responsável por
salvar o snapshot novo no cache depois de exibir.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .pet_logic import STAGE_LABEL, STREAK_MILESTONES

ToastKind = Literal["unlock", "stage_up", "streak_milestone", "level_up"]


@dataclass(frozen=True)
class Toast:
    """Um evento notável a ser exibido com destaque."""
    kind: ToastKind
    icon: str
    title: str
    detail: str = ""
    code: str = ""  # achievement code (preenchido só em kind="unlock")

    def render(self) -> str:
        """Linha rica pra Rich (com markup) , pronta pra console.print."""
        color = {
            "unlock":           "bright_magenta",
            "stage_up":         "bright_cyan",
            "streak_milestone": "bright_red",
            "level_up":         "bright_yellow",
        }[self.kind]
        line = f"[bold {color}]{self.icon}  {self.title}[/bold {color}]"
        if self.detail:
            line += f"  [dim]{self.detail}[/dim]"
        return line


def diff(prev: dict | None, curr: dict) -> list[Toast]:
    """Detecta mudanças notáveis entre snapshot anterior e atual.

    Args:
        prev: snapshot anterior (cache local) ou None se primeira vez.
        curr: snapshot fresco vindo do server, formato:
            {"pet": {...}, "nick": str|None, "streak": {...},
             "achievements": [{"code","title","icon","desc"}, ...]}

    Returns:
        Lista de toasts ordenada por prioridade (unlock > stage_up >
        level_up > streak). Lista vazia se nada mudou ou se é primeira run.
    """
    # Primeira run (sem cache) , não geramos toasts. Não tem com o quê
    # comparar e seria estranho receber 18 unlocks de cara.
    if prev is None:
        return []

    toasts: list[Toast] = []
    pet_curr = curr.get("pet") or {}
    pet_prev = prev.get("pet") or {}

    # 1) achievements novos , o evento mais "WOW" possível
    prev_codes = {a.get("code") for a in prev.get("achievements", []) if a.get("code")}
    for ach in curr.get("achievements", []):
        code = ach.get("code")
        if code and code not in prev_codes:
            toasts.append(Toast(
                kind="unlock",
                icon=ach.get("icon", "🏆"),
                title=f"desbloqueou: {ach.get('title', code)}",
                detail=ach.get("desc", ""),
                code=code,
            ))

    # 2) stage up , Junior → Pleno é uma das maiores celebrações
    s_prev = pet_prev.get("stage")
    s_curr = pet_curr.get("stage")
    if s_prev and s_curr and s_prev != s_curr:
        new_label = STAGE_LABEL.get(s_curr, s_curr)
        old_label = STAGE_LABEL.get(s_prev, s_prev)
        toasts.append(Toast(
            kind="stage_up",
            icon="✨",
            title=f"evoluiu pra {new_label}!",
            detail=f"saiu de {old_label}",
        ))

    # 3) level up (incremento numérico, separado do stage)
    lvl_prev = pet_prev.get("level") or 0
    lvl_curr = pet_curr.get("level") or 0
    if lvl_curr > lvl_prev > 0:
        toasts.append(Toast(
            kind="level_up",
            icon="⬆️",
            title=f"subiu pra Lv.{lvl_curr}",
        ))

    # 4) streak milestone , só quando bate um número marcante
    days_curr = int((curr.get("streak") or {}).get("days") or 0)
    days_prev = int((prev.get("streak") or {}).get("days") or 0)
    if days_curr > days_prev and days_curr in STREAK_MILESTONES:
        toasts.append(Toast(
            kind="streak_milestone",
            icon="🔥",
            title=f"streak de {days_curr} dias!",
            detail="meu consagrado, segura essa fogueira",
        ))

    return toasts
