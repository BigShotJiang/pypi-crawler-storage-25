import json
import re
import uuid

from .config import STATE_FILE, USER_FILE


_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def is_first_run() -> bool:
    """True se o user_id ainda não foi gerado neste sistema."""
    return not USER_FILE.exists()


def user_id() -> str:
    if USER_FILE.exists():
        try:
            return json.loads(USER_FILE.read_text(encoding="utf-8"))["user_id"]
        except (KeyError, ValueError, OSError):
            pass
    uid = str(uuid.uuid4())
    USER_FILE.write_text(json.dumps({"user_id": uid}), encoding="utf-8")
    return uid


def set_user_id(uid: str) -> tuple[bool, str]:
    """Sobrescreve o user.json , usado por `bytinho import`."""
    uid = uid.strip().lower()
    if not _UUID_RE.match(uid):
        return False, "código inválido (esperado formato uuid)."
    try:
        USER_FILE.write_text(json.dumps({"user_id": uid}), encoding="utf-8")
        # invalida cache antigo
        if STATE_FILE.exists():
            STATE_FILE.unlink()
        return True, uid
    except OSError as ex:
        return False, str(ex)


def cache(snapshot: dict) -> None:
    try:
        STATE_FILE.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    except OSError:
        pass


def load_cache() -> dict | None:
    if not STATE_FILE.exists():
        return None
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return None
