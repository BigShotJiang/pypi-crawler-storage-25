import time

import typer

from . import client
from .render import (
    console,
    live_for as _live_for,
    refresh as _refresh,
)
from .session import is_first_run

app = typer.Typer(
    add_completion=False,
    help="Bytinho , um pet digital que vive no teu terminal.",
    no_args_is_help=False,
    invoke_without_command=True,
)


@app.callback()
def _default(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        if is_first_run():
            _welcome()
        pet, h, nick, streak, toasts = _refresh()
        _live_for(pet, h, nick, seconds=3.0, fps=6.0,
                  show_credits=True, streak=streak, toasts=toasts)


def _welcome() -> None:
    """Tela de boas-vindas no primeiro `bytinho` (antes do user.json existir).

    Fluxo:
      1) apresentação + escolhe nome do pet
      2) se cwd for repo git → oferece instalar o hook AGORA (Y/n)
      3) mostra próximos passos curtinhos
    """
    import subprocess

    from rich.panel import Panel
    from rich.prompt import Confirm, Prompt
    from rich.text import Text

    body = Text.from_markup(
        "\n[bold magenta]oi, eu sou um pet digital[/bold magenta] 👾\n\n"
        "Eu vou viver no teu terminal e crescer com cada [bold]git commit[/bold] que tu faz.\n"
        "Sem login, sem senha. Só um UUID anônimo que mora aqui no teu PC.\n",
    )
    console.print(Panel(body, title="bem-vindo", border_style="magenta"))

    # 1) Nome do pet
    try:
        pet_name = Prompt.ask(
            "[bold cyan]como queres me chamar?[/bold cyan]",
            default="Bytinho",
            console=console,
        ).strip()
    except (EOFError, KeyboardInterrupt):
        pet_name = "Bytinho"

    if pet_name and pet_name != "Bytinho":
        ok, msg = client.rename_pet(pet_name)
        if ok:
            console.print(f"[green]✓ prazer, sou o {pet_name}![/green]")
        else:
            console.print(f"[yellow]⚠ não rolou esse nome ({msg}), fico como Bytinho[/yellow]")

    # 1.5) Telemetria anônima , sempre ligada (zero PII, opt-out via --forget)
    from . import telemetry
    telemetry.track("install")
    telemetry.track("welcome_complete")

    # 2) Hook do git , o ponto crítico do onboarding
    in_repo = False
    try:
        subprocess.check_output(
            ["git", "rev-parse", "--git-dir"],
            stderr=subprocess.DEVNULL,
        )
        in_repo = True
    except Exception:
        in_repo = False

    if in_repo:
        console.print()
        console.print("[dim]percebi que tu tá num repo git , posso conectar:[/dim]")
        try:
            yes = Confirm.ask(
                "[bold cyan]instalo o hook agora? cada commit vira XP automático[/bold cyan]",
                default=True,
                console=console,
            )
        except (EOFError, KeyboardInterrupt):
            yes = False

        if yes:
            from .commands.dev import _install_hook_here
            ok, where = _install_hook_here()
            if ok:
                telemetry.track("hook_installed")
                console.print(f"[green]✓ tô conectado em[/green] {where}")
            else:
                console.print(
                    f"[yellow]⚠ não consegui ({where}), roda depois:[/yellow] "
                    "[cyan]bytinho install-hook[/cyan]"
                )
    else:
        console.print()
        console.print(
            "[dim]quando entrar num repo git, roda[/dim] "
            "[cyan]bytinho install-hook[/cyan] [dim]pra cada commit virar XP[/dim]"
        )

    # 3) Próximos passos enxutos
    console.print(
        "\n[dim]bons comandos pra começar:[/dim]\n"
        "  [cyan]bytinho nick <seu-apelido>[/cyan]   teu nome no ranking\n"
        "  [cyan]bytinho talk \"oi\"[/cyan]            conversa comigo\n"
        "  [cyan]bytinho next[/cyan]                  o que tu pode desbloquear hoje\n\n"
        "[dim]agora deixa eu te mostrar quem eu sou…[/dim]\n"
    )
    time.sleep(1.2)


from .commands.pet import register as _register_pet  # noqa: E402

_register_pet(app)


from .commands.identity import register as _register_identity  # noqa: E402

_register_identity(app)


from .commands.dev import register as _register_dev  # noqa: E402

_register_dev(app)


from .commands.social import register as _register_social  # noqa: E402

_register_social(app)


from .commands.card import register as _register_card  # noqa: E402
from .commands.chat import register as _register_chat  # noqa: E402
from .commands.closet import register as _register_closet  # noqa: E402
from .commands.meta import register as _register_meta  # noqa: E402
from .commands.next_cmd import register as _register_next  # noqa: E402
from .commands.skin import register as _register_skin  # noqa: E402
from .commands.telemetry_cmd import register as _register_telemetry  # noqa: E402

_register_card(app)
_register_chat(app)
_register_closet(app)
_register_meta(app)
_register_next(app)
_register_skin(app)
_register_telemetry(app)


if __name__ == "__main__":
    app()
