"""Telemetry opt-in , fire-and-forget event tracking.

Princípios:
- Opt-in. Default OFF até o user dizer Y no welcome. Sempre revogável.
- Fire-and-forget: nunca bloqueia. Nunca printa erro. Thread daemon + timeout 2s.
- Sem PII nova: só user_id (UUID que já existe), evento, ts, versão, OS.
- Eventos one-shot persistem flag local (não duplicar 'install' / 'first_commit').
"""
from __future__ import annotations

import json
import platform
import threading
from pathlib import Path

import httpx

from . import __version__
from .config import DATA_DIR, SERVER_URL
from .session import user_id


_FLAG_FILE = DATA_DIR / "telemetry.json"
_SENT_FILE = DATA_DIR / "telemetry_sent.json"

# Eventos one-shot , só mandamos uma vez na vida do usuário.
_ONE_SHOT = frozenset({
    "install", "welcome_complete", "hook_installed",
    "first_commit", "first_talk", "first_unlock", "first_share",
})


def _load_flag() -> dict:
    if not _FLAG_FILE.exists():
        return {"enabled": None}  # None = ainda não perguntamos
    try:
        return json.loads(_FLAG_FILE.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {"enabled": None}


def _save_flag(enabled: bool) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        _FLAG_FILE.write_text(
            json.dumps({"enabled": bool(enabled)}),
            encoding="utf-8",
        )
    except OSError:
        pass


def is_enabled() -> bool:
    """Telemetria sempre ON , só desliga se user explicitamente passar False.

    Default: True (sem perguntar). User pode override com `set_enabled(False)`
    via `bytinho telemetry --forget` ou direto.
    """
    return _load_flag().get("enabled") is not False


def has_decided() -> bool:
    """Mantido pra compat: sempre True agora (não tem mais prompt)."""
    return True


def set_enabled(enabled: bool) -> None:
    _save_flag(enabled)


def _load_sent() -> set[str]:
    if not _SENT_FILE.exists():
        return set()
    try:
        return set(json.loads(_SENT_FILE.read_text(encoding="utf-8")))
    except (ValueError, OSError):
        return set()


def _mark_sent(event: str) -> None:
    sent = _load_sent()
    sent.add(event)
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        _SENT_FILE.write_text(json.dumps(sorted(sent)), encoding="utf-8")
    except OSError:
        pass


def _detect_os() -> str:
    s = platform.system().lower()
    if s == "linux":
        # WSL aparece como Linux mas tem "microsoft" no kernel
        try:
            if "microsoft" in Path("/proc/version").read_text().lower():
                return "wsl"
        except OSError:
            pass
        return "linux"
    if s == "darwin":
        return "darwin"
    return "other"


def _send_async(payload: dict) -> None:
    """Roda numa thread daemon, timeout curto, swallow tudo."""
    def worker():
        try:
            with httpx.Client(timeout=2.0) as c:
                c.post(
                    f"{SERVER_URL}/api/telemetry/event",
                    headers={"X-Bytinho-User": user_id()},
                    json=payload,
                )
        except Exception:
            pass  # fire-and-forget, NUNCA quebra o CLI
    t = threading.Thread(target=worker, daemon=True)
    t.start()


def track(event: str) -> None:
    """Dispara um evento se telemetria está ON. No-op caso contrário.

    Para eventos one-shot, garante que só manda uma vez por máquina.
    """
    if not is_enabled():
        return
    if event in _ONE_SHOT:
        if event in _load_sent():
            return
        _mark_sent(event)
    payload = {
        "event": event,
        "cli_version": __version__,
        "os": _detect_os(),
    }
    _send_async(payload)


def forget_remote() -> bool:
    """Apaga todos os eventos do user no server. Pra `bytinho telemetry --forget`."""
    try:
        with httpx.Client(timeout=5.0) as c:
            r = c.delete(
                f"{SERVER_URL}/api/telemetry/me",
                headers={"X-Bytinho-User": user_id()},
            )
            return r.status_code in (200, 204)
    except httpx.HTTPError:
        return False
