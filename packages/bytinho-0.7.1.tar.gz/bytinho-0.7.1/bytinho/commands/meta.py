"""Comandos meta/utility: version, greet, streak, credits, donate, blob, doctor."""
import time
from datetime import datetime

import typer

from .. import __version__, client
from ..config import GREET_FILE
from ..render import console


def register(app: typer.Typer) -> None:
    @app.command()
    def version():
        console.print(f"Bytinho {__version__}")

    @app.command()
    def greet():
        """Saída curta de 1 linha (pra usar em shell rc).

        Cacheia em GREET_FILE por 5 min , abrir 30 terminais não enche o servidor.
        Mostra warning quando streak tá pra cair (>= 20h sem commit).
        """
        import json as _json

        TTL = 5 * 60
        now = time.time()
        payload: dict | None = None

        if GREET_FILE.exists():
            try:
                cached = _json.loads(GREET_FILE.read_text(encoding="utf-8"))
                if now - cached.get("ts", 0) < TTL:
                    payload = cached
            except (ValueError, OSError):
                pass

        if payload is None:
            data = client.sync()
            if not data:
                return
            pet  = data["pet"]
            user = data["user"]
            streak = user.get("streak") or {}
            payload = {
                "ts":        now,
                "pet":       pet,
                "nick":      user.get("nick"),
                "streak":    streak,
                "challenge": user.get("challenge"),
            }
            try:
                GREET_FILE.write_text(_json.dumps(payload), encoding="utf-8")
            except OSError:
                pass

        pet    = payload["pet"]
        nick   = payload.get("nick") or "anon"
        streak = payload.get("streak") or {}
        name   = pet.get("name") or "Bytinho"
        emoji  = pet.get("stage_emoji", "🐣")
        lvl    = pet.get("level", 1)
        days   = int(streak.get("days") or 0)
        active_today = bool(streak.get("active_today"))

        parts = [f"{emoji} {name}", f"Lv.{lvl}"]
        if days >= 1:
            parts.append(f"🔥 {days}d")

        hour_local = datetime.now().hour
        if days >= 1 and not active_today and hour_local >= 20:
            hours_left = max(1, 24 - hour_local)
            parts.append(f"[red]⚠ {hours_left}h pra perder o streak[/red]")
        elif pet.get("hunger", 100) < 30:
            parts.append("[red]faminto[/red]")
        elif pet.get("mood", 100) < 30:
            parts.append("[yellow]triste[/yellow]")
        elif pet.get("asleep"):
            parts.append("💤")

        console.print("  ".join(parts) + f"  [dim]· @{nick}[/dim]")

        ch = payload.get("challenge")
        if ch:
            prog     = int(ch.get("progress", 0))
            target   = int(ch.get("target", 1))
            done     = bool(ch.get("done"))
            days_l   = int(ch.get("days_left", 7))
            label    = ch.get("label", "")
            xp_rew   = int(ch.get("xp_reward", 50))
            show_ch  = done or prog > 0 or days_l <= 2
            if show_ch:
                if done:
                    console.print(f"  [green]✅ desafio completo: {label}  +{xp_rew} XP[/green]")
                else:
                    urgency = f"  [red]{days_l}d restantes[/red]" if days_l <= 2 else f"  [dim]{days_l}d restantes[/dim]"
                    console.print(f"  [cyan]⚔[/cyan]  {label}: [bold]{prog}/{target}[/bold]{urgency}")

    @app.command()
    def streak():
        """Mostra teu streak atual."""
        data = client.sync()
        if not data:
            console.print("[red]✗ The Core offline.[/red]")
            return
        s = data["user"].get("streak") or {}
        days = s.get("days", 0)
        best = s.get("best", 0)
        today = "✓ contou hoje" if s.get("active_today") else "[yellow]ainda não contou hoje[/yellow]"
        console.print()
        console.print(f"  🔥  [bold]{days}[/bold] dia(s) consecutivos")
        console.print(f"  🏅  recorde pessoal: [bold]{best}[/bold]")
        console.print(f"      {today}")
        if days < 10:
            bonus = int(min(days / 10.0, 1.0) * 100)
            console.print(f"  [dim]bônus atual de XP por commit: +{bonus}%  (max +100% em 10d)[/dim]")
        else:
            console.print(f"  [dim]bônus máximo de XP ativo: +100% 💪[/dim]")
        console.print()

    @app.command()
    def credits():
        console.print(
            "\n[bold magenta]Bytinho 💜[/bold magenta]\n"
            "  Criado por: [bold]Andryus[/bold]\n"
            "  Hospedado por: [bold]Qantara[/bold]\n"
            "  Mantido pela comunidade.\n"
        )

    @app.command()
    def donate():
        console.print(
            "\n[bold magenta]Apoie o Bytinho[/bold magenta]\n"
            "  PIX:  [cyan]support@bytinho.com[/cyan]\n"
            "\nObrigado por manter o servidor no ar 💜\n"
        )

    @app.command()
    def blob(
        preset: str = typer.Argument("default",
                                     help="Nome do preset (ou 'all' para listar todos)."),
        validate_only: bool = typer.Option(False, "--validate",
                                           help="Só roda o validador no catálogo, sem renderizar."),
    ):
        """Renderiza/valida blobs ASCII (sistema 13×8)."""
        from .. import blob as blobmod

        if validate_only:
            try:
                cat = blobmod.validate_catalog()
            except blobmod.BlobValidationError as e:
                console.print(f"[red]✗ blob inválido:[/red] {e}")
                raise typer.Exit(1)
            console.print(f"[green]✓ {len(cat)} presets válidos[/green] "
                          f"[dim](grade {blobmod.WIDTH}×{blobmod.HEIGHT})[/dim]")
            return

        if preset == "all":
            for name, b in blobmod.validate_catalog().items():
                console.print(f"\n[bold magenta]── {name} ──[/bold magenta]")
                for line in b:
                    console.print(f"  {line}")
            return

        if preset not in blobmod.PRESETS:
            names = ", ".join(blobmod.PRESETS.keys())
            console.print(f"[red]✗ preset desconhecido:[/red] {preset}")
            console.print(f"[dim]disponíveis: {names}, all[/dim]")
            raise typer.Exit(1)

        spec = blobmod.PRESETS[preset]
        blob_lines = blobmod.render(spec)
        console.print(f"\n[bold magenta]{preset}[/bold magenta] "
                      f"[dim]({spec.skin} · {spec.eyes}/{spec.mouth}/{spec.feet})[/dim]\n")
        for line in blob_lines:
            console.print(f"  {line}")
        console.print()

    @app.command()
    def doctor():
        """Diagnóstico: confere se tudo tá no lugar (server, hook, shell)."""
        import os
        import shutil
        import subprocess
        from pathlib import Path

        from ..config import SERVER_URL, USER_FILE
        from ..session import user_id

        ok = "[green]✓[/green]"
        warn = "[yellow]·[/yellow]"
        bad = "[red]✗[/red]"
        problems = 0

        console.print(f"\n[bold]Bytinho doctor[/bold] [dim]v{__version__}[/dim]\n")

        import sys
        pyver = sys.version_info
        if pyver >= (3, 10):
            console.print(f"  {ok} python {pyver.major}.{pyver.minor}")
        else:
            console.print(f"  {bad} python {pyver.major}.{pyver.minor} [red](precisa ≥ 3.10)[/red]")
            problems += 1

        if USER_FILE.exists():
            uid = user_id()
            console.print(f"  {ok} user uuid: [dim]{uid[:8]}…[/dim]  [dim]({USER_FILE})[/dim]")
        else:
            console.print(f"  {warn} user uuid ainda não criado [dim](roda `bytinho` uma vez)[/dim]")

        h = client.health()
        if h.get("status") == "ok":
            brain = h.get("brain", "?")
            chat = h.get("chat_online", 0)
            console.print(f"  {ok} server [dim]{SERVER_URL}[/dim]  brain={brain}  chat_online={chat}")
        else:
            console.print(f"  {bad} server offline [dim]({SERVER_URL})[/dim]")
            console.print(f"     [dim]checa https://{SERVER_URL.split('//')[-1]}/health no browser[/dim]")
            problems += 1

        git_bin = shutil.which("git")
        if git_bin:
            console.print(f"  {ok} git [dim]({git_bin})[/dim]")
        else:
            console.print(f"  {warn} git não encontrado [dim](hook não funciona sem git)[/dim]")

        cwd = Path.cwd()
        try:
            gitdir = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=cwd, capture_output=True, text=True, timeout=2,
            )
            if gitdir.returncode == 0:
                hook_path = Path(gitdir.stdout.strip()) / "hooks" / "post-commit"
                if not hook_path.is_absolute():
                    hook_path = cwd / hook_path
                if hook_path.exists() and "bytinho" in hook_path.read_text(errors="ignore"):
                    console.print(f"  {ok} post-commit hook ativo [dim](repo atual)[/dim]")
                else:
                    console.print(f"  {warn} post-commit hook não instalado neste repo")
                    console.print(f"     [dim]roda `bytinho install-hook` aqui dentro[/dim]")
            else:
                console.print(f"  {warn} cwd não é repo git [dim](pula check do hook)[/dim]")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        shell_rc = None
        home = Path.home()
        for rc in (home / ".zshrc", home / ".bashrc"):
            if rc.exists() and "bytinho greet" in rc.read_text(errors="ignore"):
                shell_rc = rc
                break
        if shell_rc:
            console.print(f"  {ok} shell greet em [dim]{shell_rc.name}[/dim]")
        else:
            console.print(f"  {warn} shell greet não instalado [dim](`bytinho setup` ativa no abrir do terminal)[/dim]")

        enc = (os.environ.get("LC_ALL") or os.environ.get("LANG") or "").lower()
        if "utf" in enc or os.environ.get("TERM_PROGRAM"):
            console.print(f"  {ok} terminal suporta emoji")
        else:
            console.print(f"  {warn} terminal pode não suportar emoji [dim]($LANG sem utf)[/dim]")

        console.print()
        if problems == 0:
            console.print("[green bold]tudo certo. bom commit aí 👾[/green bold]\n")
        else:
            console.print(f"[red bold]{problems} problema(s) sério(s).[/red bold] resolve antes de seguir.\n")
            raise typer.Exit(1)
