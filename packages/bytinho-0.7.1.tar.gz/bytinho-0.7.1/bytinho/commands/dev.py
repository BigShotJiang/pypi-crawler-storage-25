"""Comandos de desenvolvimento: code, sync-history, install-hook, setup, unsetup."""
import os
from pathlib import Path

import typer

from .. import client, telemetry
from ..render import console, live_for
from ..session import cache, load_cache
from ..ui import empty_pet
from .pet import _do


_HOOK_BODY = """#!/usr/bin/env bash
# bytinho post-commit hook , registra commit como XP + reação curta.
# Foreground com timeout 5s: mostra a linha do brain inline. Se o servidor
# tiver lento, mata sem afetar o commit (que já aconteceu).
timeout 5s bytinho code 1 --from-git --react --quiet 2>/dev/null
exit 0
"""

_GREET_MARK = "# >>> bytinho greet >>>"
_GREET_END  = "# <<< bytinho greet <<<"
_GREET_BLOCK = (
    f"\n{_GREET_MARK}\n"
    "command -v bytinho >/dev/null 2>&1 && bytinho greet 2>/dev/null\n"
    f"{_GREET_END}\n"
)


def _install_hook_here() -> tuple[bool, str]:
    """Instala o post-commit hook no repo do cwd.

    Reutilizado pelo welcome flow (auto-install se cwd for repo git) e pelo
    comando `bytinho install-hook`.

    Returns:
        (ok, mensagem) , se ok=True a mensagem é o path do hook,
        senão é o erro pra mostrar ao user.
    """
    import subprocess
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--git-dir"], stderr=subprocess.DEVNULL,
        ).decode().strip()
    except Exception:
        return False, "não tô num repositório git"
    hook = Path(out) / "hooks" / "post-commit"
    hook.parent.mkdir(parents=True, exist_ok=True)
    if hook.exists():
        cur = hook.read_text(errors="ignore")
        is_ours = "bytinho code" in cur and "post-commit" in cur
        has_react = "--react" in cur
        if is_ours and has_react:
            return True, str(hook) + " (já estava ok)"
        if is_ours:
            hook.with_suffix(".bak").write_text(cur)
            hook.write_text(_HOOK_BODY)
        else:
            hook.with_suffix(".bak").write_text(cur)
            hook.write_text(cur.rstrip() + "\n\n" + _HOOK_BODY)
    else:
        hook.write_text(_HOOK_BODY)
    hook.chmod(0o755)
    return True, str(hook)


def register(app: typer.Typer) -> None:
    @app.command()
    def code(
        commits: int = typer.Argument(1),
        message: str = typer.Option("", "--message", "-m"),
        hour:    int = typer.Option(-1, "--hour"),
        files:   int = typer.Option(0, "--files"),
        from_git: bool = typer.Option(
            False, "--from-git",
            help="Extrai todos os metadados do último commit (usado pelo hook).",
        ),
        react: bool = typer.Option(
            False, "--react",
            help="Imprime 1 linha de reação do brain (usado pelo hook).",
        ),
        quiet: bool = typer.Option(
            False, "--quiet", "-q",
            help="Saída mínima (1 linha por commit). Bom pro hook.",
        ),
    ):
        """Registra commits → XP."""
        from .. import git_meta
        from ..render import invalidate_greet_cache

        kw: dict = {"commits": commits}
        meta: dict | None = None
        if from_git:
            meta = git_meta.collect()
            if meta is None:
                console.print("[red]✗ não tô num repositório git.[/red]")
                raise typer.Exit(1)
            kw.update(meta)
        else:
            if message:
                kw["message"] = message
            if hour >= 0:
                kw["hour"] = hour
            if files > 0:
                kw["files"] = files

        if quiet:
            res = client.action("code", **kw)
            if res is None:
                return
            pet = res.get("pet") or {}
            cached = load_cache() or {}
            cache({"pet": pet, "nick": cached.get("nick"),
                   "streak": cached.get("streak")})
            msg = res.get("message", "")
            unlocked = res.get("unlocked") or []
            invalidate_greet_cache()
            telemetry.track("first_commit")
            telemetry.track("daily_active")
            console.print(f"[bold magenta]👾[/bold magenta] {msg}")
            if unlocked:
                tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
                console.print(f"  [bold]✨ desbloqueou:[/bold] {tags}")
            if react and meta:
                reply = client.commit_react(meta)
                if reply:
                    console.print(f"  [italic dim]💬 {reply}[/italic dim]")
            return

        _do("code", "💻", **kw)
        if react and meta:
            reply = client.commit_react(meta)
            if reply:
                console.print(f"[italic dim]💬 {reply}[/italic dim]")

    @app.command("sync-history")
    def sync_history_cmd(
        days: int = typer.Option(30, "--days", "-d", min=1, max=365),
    ):
        """Importa commits dos últimos N dias do repo atual (uma vez só)."""
        from .. import git_meta
        history = git_meta.collect_history(days=days)
        if history is None:
            console.print("[red]✗ não tô num repositório git.[/red]")
            raise typer.Exit(1)
        if not history:
            console.print(f"[yellow]nenhum commit nos últimos {days} dias.[/yellow]")
            return

        console.print(f"📦 enviando {len(history)} commits dos últimos {days} dias...")
        res = client.sync_history(history)
        if res is None:
            console.print("[red]✗ The Core offline.[/red]")
            raise typer.Exit(1)

        imported = res.get("imported", 0)
        skipped  = res.get("skipped", 0)
        xp       = res.get("xp_gain", 0)
        days_a   = res.get("active_days", 0)
        unlocked = res.get("unlocked") or []
        pet      = res.get("pet") or empty_pet()

        msg = (
            f"📥 +{imported} commits importados ({skipped} já existiam)\n"
            f"🔥 {days_a} dias ativos · +{xp} XP"
        )
        if unlocked:
            tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
            msg += f"\n[bold magenta]✨ desbloqueou:[/bold magenta] {tags}"

        h = client.health()
        cached = load_cache() or {}
        cache({"pet": pet, "nick": cached.get("nick")})
        live_for(pet, h, cached.get("nick"), msg=msg,
                 seconds=4.0 if unlocked else 3.0, fps=6.0)

    @app.command("install-hook")
    def install_hook():
        """Instala git post-commit hook no repo atual (commit = XP automático)."""
        ok, msg = _install_hook_here()
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        telemetry.track("hook_installed")
        console.print(f"[green]✓ hook instalado:[/green] {msg}")
        console.print("[dim]agora cada `git commit` rende XP + 1 linha do Bytinho 🔥[/dim]")

    @app.command()
    def setup():
        """Faz o Bytinho te cumprimentar toda vez que abrir um terminal."""
        home = Path.home()
        candidates = []
        shell = os.environ.get("SHELL", "")
        if "zsh" in shell:
            candidates.append(home / ".zshrc")
        if "bash" in shell or not candidates:
            candidates.append(home / ".bashrc")
        rc = next((p for p in candidates if p.exists()), candidates[0])
        cur = rc.read_text() if rc.exists() else ""
        if _GREET_MARK in cur:
            console.print(f"[yellow]· greet já instalado em {rc}[/yellow]")
            return
        rc.write_text(cur.rstrip() + "\n" + _GREET_BLOCK)
        console.print(f"[green]✓ greet instalado em[/green] {rc}")
        console.print("[dim]abre um terminal novo pra ver.[/dim]")

    @app.command()
    def unsetup():
        """Remove o greet do shell rc."""
        home = Path.home()
        removed = []
        for rc in (home / ".bashrc", home / ".zshrc"):
            if not rc.exists():
                continue
            cur = rc.read_text()
            if _GREET_MARK not in cur:
                continue
            before, _, rest = cur.partition(_GREET_MARK)
            _, _, after = rest.partition(_GREET_END)
            rc.write_text(before.rstrip() + "\n" + after.lstrip())
            removed.append(str(rc))
        if removed:
            console.print(f"[green]✓ removido de:[/green] {', '.join(removed)}")
        else:
            console.print("[yellow]· nada pra remover.[/yellow]")
