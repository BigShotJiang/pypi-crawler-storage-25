"""Comando `bytinho next` , mostra o que está mais perto de desbloquear.

Heurística simples client-side: pega o que falta pro próximo stage,
o próximo milestone de streak e até 3 achievements ainda não desbloqueados.
"""
from __future__ import annotations

import typer
from rich.panel import Panel
from rich.text import Text

from .. import client
from ..pet_logic import (
    STAGE_LABEL,
    next_stage,
    next_streak_milestone,
    xp_to_next,
)
from ..render import console


# Espelha CATALOG do server (achievements.py) , versões "achievables" só,
# ordenadas grosseiramente por dificuldade crescente.
_HINTS: dict[str, tuple[str, str]] = {
    "first_commit":     ("🌱", "faz o primeiro commit"),
    "early_bird":       ("🌅", "commit entre 5h e 7h"),
    "night_owl":        ("🦉", "commit entre 0h e 5h"),
    "weekend_warrior":  ("🛡️", "commit no sábado ou domingo"),
    "doc_lover":        ("📚", "1 commit que só toca arquivos .md"),
    "polyglot":         ("💬", "mande uma msg no chat global"),
    "polyglot_real":    ("🐍", "commits em 3+ linguagens diferentes"),
    "friday_shipper":   ("🌉", "feat: numa sexta-feira"),
    "streak_3":         ("🔥", "3 dias seguidos commitando"),
    "streak_7":         ("🔥", "7 dias seguidos"),
    "refactor_king":    ("🧹", "5 commits começando com refactor:"),
    "bug_hunter":       ("🐛", "10 commits começando com fix:"),
    "surgeon":          ("🎯", "10 commits cirúrgicos (<10 linhas)"),
    "big_bang":         ("💥", "1 commit com 500+ linhas"),
    "feature_factory":  ("🏭", "20 commits começando com feat:"),
    "streak_30":        ("🏆", "30 dias seguidos"),
}


def _next_stage_text(pet: dict) -> str | None:
    stage = pet.get("stage")
    xp = pet.get("xp", 0)
    nxt = next_stage(stage)
    if nxt is None:
        return None
    falta = xp_to_next(xp, stage) or 0
    label = STAGE_LABEL.get(nxt, nxt)
    if falta <= 0:
        return f"✨  prestes a virar [bold]{label}[/bold] (commit que sobe)"
    return f"✨  pra virar [bold]{label}[/bold]: faltam [bold]{falta} XP[/bold]"


def _next_streak_text(streak: dict | None) -> str | None:
    if not streak:
        return None
    days = int(streak.get("days") or 0)
    nxt = next_streak_milestone(days)
    if nxt is None:
        return None
    return f"🔥  faltam [bold]{nxt - days} dias[/bold] pra streak de {nxt}"


def _next_achievements(unlocked: list[dict]) -> list[str]:
    unlocked_codes = {a.get("code") for a in unlocked}
    rest = [(ic, hint) for code, (ic, hint) in _HINTS.items()
            if code not in unlocked_codes]
    return [f"{ic}  {hint}" for ic, hint in rest[:3]]


def register(app: typer.Typer) -> None:
    @app.command("next")
    def next_cmd():
        """Mostra o que tu pode desbloquear hoje."""
        data = client.sync()
        if not data:
            console.print("[red]✗ The Core offline. tenta de novo daqui pouco.[/red]")
            raise typer.Exit(1)
        pet = data["pet"]
        streak = data["user"].get("streak") or {}
        achs = client.my_achievements()

        lines: list[str] = []
        s = _next_stage_text(pet)
        if s:
            lines.append(s)
        st = _next_streak_text(streak)
        if st:
            lines.append(st)
        lines.extend(_next_achievements(achs))

        if not lines:
            body = Text.from_markup(
                "[dim]nada na mira agora. tu já é uma lenda mesmo.[/dim]"
            )
        else:
            body = Text.from_markup("\n".join(lines))

        console.print(Panel(
            body,
            title="🎯 perto de desbloquear",
            border_style="bright_magenta",
        ))
