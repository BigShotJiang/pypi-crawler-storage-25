"""Comandos básicos do pet: status, feed, play, sleep, wake."""
import typer

from .. import client
from ..render import console, live_for, refresh, show_static
from ..session import cache, load_cache
from ..ui import empty_pet


def _do(action_name: str, prefix: str, **kw) -> None:
    res = client.action(action_name, **kw)
    h = client.health()
    if res is None:
        cached = load_cache() or {}
        show_static(cached.get("pet", empty_pet()), h, cached.get("nick"),
                    msg="The Core offline , ação não registrada.")
        return
    pet = res["pet"]
    cached = load_cache() or {}
    nick = cached.get("nick")
    cache({"pet": pet, "nick": nick})

    unlocked = res.get("unlocked") or []
    base_msg = f"{prefix} {res.get('message','')}"
    if unlocked:
        tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
        base_msg += f"\n[bold magenta]✨ desbloqueou:[/bold magenta] {tags}"
    live_for(pet, h, nick, msg=base_msg, seconds=3.0 if unlocked else 2.5, fps=8.0)


def register(app: typer.Typer) -> None:
    @app.command()
    def status(
        static: bool = typer.Option(False, "--static", help="Sem animação."),
    ):
        """Mostra o Bytinho (animado por alguns segundos)."""
        pet, h, nick, streak, toasts = refresh()
        if static:
            show_static(pet, h, nick, show_credits=True, streak=streak,
                        toasts=toasts)
        else:
            live_for(pet, h, nick, seconds=3.0, fps=6.0, show_credits=True,
                     streak=streak, toasts=toasts)

    @app.command()
    def feed():
        """Alimenta o Bytinho."""
        _do("feed", "🍕")

    @app.command()
    def play():
        """Brinca com o Bytinho."""
        _do("play", "🎮")

    @app.command()
    def sleep():
        """Coloca o Bytinho pra dormir."""
        _do("sleep", "💤")

    @app.command()
    def wake():
        """Acorda o Bytinho."""
        _do("wake", "☀️")
