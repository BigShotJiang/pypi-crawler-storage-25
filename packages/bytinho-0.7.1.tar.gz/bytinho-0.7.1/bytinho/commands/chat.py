"""Comandos interativos: talk, live, chat (WebSocket)."""
import asyncio
import json
import time

import typer
from rich.live import Live

from .. import client
from ..render import console, live_for, refresh, show_static
from ..session import cache, load_cache
from ..ui import empty_pet, panel


def _fmt(m: dict) -> str:
    return (
        f"[cyan]{m.get('stage_emoji','🐣')} {m.get('nick','anon')}[/cyan] "
        f"[dim]lv.{m.get('level',1)}[/dim]: {m.get('text','')}"
    )


async def _chat_loop():
    import websockets
    from rich.panel import Panel as RPanel
    from rich.text import Text as RText

    msgs: list[str] = []
    online = 0
    top_achs: list[dict] = []

    def render():
        body = "\n".join(msgs[-20:]) or "[dim]ninguém falou ainda... seja o primeiro![/dim]"
        if top_achs:
            top_str = "  ".join(
                f"{a.get('icon','★')} [bold]{a.get('title','?')}[/bold] "
                f"[dim]({a.get('holders',0)})[/dim]"
                for a in top_achs[:3]
            )
            title = f"🏛  Praça do Core • {online} online  │  🏆 {top_str}"
        else:
            title = f"🏛  Praça do Core • {online} online"
        if online <= 1:
            subtitle = "[yellow]🔇 mutado , ninguém online[/yellow] [dim]• Ctrl+C pra sair[/dim]"
            border = "yellow"
        else:
            subtitle = "[dim]digite e Enter • Ctrl+C pra sair[/dim]"
            border = "magenta"
        return RPanel(
            RText.from_markup(body),
            title=title,
            subtitle=subtitle,
            border_style=border, padding=(1, 2),
        )

    try:
        async with websockets.connect(client.ws_url()) as ws:
            console.print(render())

            async def reader():
                nonlocal online
                async for raw in ws:
                    try: d = json.loads(raw)
                    except ValueError: continue
                    t = d.get("type")
                    if t == "history":
                        for m in d.get("messages", []): msgs.append(_fmt(m))
                    elif t == "msg":     msgs.append(_fmt(d["message"]))
                    elif t == "presence": online = d.get("online", 0)
                    elif t == "stats":
                        top_achs[:] = d.get("top_achievements", []) or []
                    elif t == "system":   msgs.append(f"[yellow]· {d.get('text','')}[/yellow]")
                    elif t == "ping":
                        # server heartbeat , responde sem ruído na UI
                        try:
                            await ws.send(json.dumps({"type": "pong"}))
                        except Exception:
                            return
                        continue
                    elif t == "pong":
                        continue
                    console.clear(); console.print(render())

            task = asyncio.create_task(reader())
            loop = asyncio.get_event_loop()
            try:
                while True:
                    txt = (await loop.run_in_executor(None, input, "> ")).strip()
                    if not txt: continue
                    if txt in ("/quit", "/sair", "/exit"): break
                    if online <= 1:
                        msgs.append("[yellow]· mutado , ninguém online pra ouvir 🌙[/yellow]")
                        console.clear(); console.print(render())
                        continue
                    await ws.send(json.dumps({"type": "msg", "text": txt}))
            finally:
                task.cancel()
    except Exception as ex:
        console.print(f"[red]erro: {ex}[/red]")


def register(app: typer.Typer) -> None:
    @app.command("talk")
    def talk_cmd(message: str = typer.Argument(...)):
        """Conversa com o Bytinho."""
        res = client.talk(message)
        h = client.health()
        if res is None:
            cached = load_cache() or {}
            show_static(cached.get("pet", empty_pet()), h, cached.get("nick"),
                        msg="The Core offline.")
            return
        pet = res.get("pet") or (load_cache() or {}).get("pet") or empty_pet()
        nick = (load_cache() or {}).get("nick")
        cache({"pet": pet, "nick": nick})
        live_for(pet, h, nick, msg=f"💬 {res.get('reply','...')}", seconds=4.0, fps=6.0)

    @app.command()
    def live(fps: float = typer.Option(6.0, help="Frames por segundo.")):
        """Modo vivo permanente , Bytinho respira, pisca e pensa."""
        pet, h, nick_, streak, _toasts = refresh()
        tick = 0
        last_sync = time.time()
        try:
            with Live(panel(pet, h, nick_, tick=tick, streak=streak), console=console,
                      refresh_per_second=fps, screen=False) as view:
                while True:
                    time.sleep(1.0 / max(fps, 1.0))
                    tick += 1
                    if time.time() - last_sync > 15:
                        pet, h, nick_, streak, _toasts = refresh()
                        last_sync = time.time()
                    view.update(panel(pet, h, nick_, tick=tick, streak=streak))
        except KeyboardInterrupt:
            console.print("\n[dim]até mais 👋[/dim]")

    @app.command()
    def chat():
        """Entra na Praça do Core (chat global)."""
        try:
            import websockets  # noqa: F401
        except ImportError:
            console.print("[red]falta o pacote websockets. pip install websockets[/red]")
            raise typer.Exit(1)
        asyncio.run(_chat_loop())
