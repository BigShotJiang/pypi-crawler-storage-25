"""Comandos sociais: report, share, install-badge, ranking, achievements."""
from pathlib import Path

import typer

from .. import client
from ..render import console
from ..session import load_cache


def _copy_to_clipboard(text: str) -> bool:
    """Tenta xclip, xsel, wl-copy, pbcopy. Retorna True se algum funcionou."""
    import shutil
    import subprocess as sp
    candidates = [
        (["xclip", "-selection", "clipboard"], "xclip"),
        (["wl-copy"],                          "wl-copy"),
        (["xsel", "--clipboard", "--input"],   "xsel"),
        (["pbcopy"],                           "pbcopy"),
    ]
    for cmd, name in candidates:
        if shutil.which(name):
            try:
                p = sp.Popen(cmd, stdin=sp.PIPE)
                p.communicate(text.encode("utf-8"), timeout=2)
                if p.returncode == 0:
                    return True
            except (sp.TimeoutExpired, OSError):
                continue
    return False


def _resolve_nick() -> str | None:
    cached = load_cache() or {}
    nick = cached.get("nick")
    if not nick:
        data = client.sync()
        if data:
            nick = data["user"].get("nick")
    return nick


def register(app: typer.Typer) -> None:
    @app.command()
    def report(
        target_nick: str = typer.Argument(..., help="Nick do user que tá zoando."),
        reason: str = typer.Argument("", help="Motivo (opcional)."),
    ):
        """Reporta alguém da Praça do Core (3 reports = mute automático)."""
        ok, msg = client.report_user(target_nick, reason)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ report enviado contra @{target_nick}[/green]")

    @app.command()
    def share(
        no_copy: bool = typer.Option(False, "--no-copy", help="Não copiar pra clipboard."),
        to: str = typer.Option(
            "", "--to", "-t",
            help="Destino direto: clipboard|twitter|file|card. Vazio = pergunta.",
        ),
        out: Path = typer.Option(
            None, "--out", "-o",
            help="Quando --to=file ou --to=card, caminho de saída.",
        ),
    ):
        """Compartilha teu perfil: clipboard / Twitter / arquivo / card PNG."""
        from ..config import SERVER_URL

        nick = _resolve_nick()
        if not nick:
            console.print(
                "[red]✗ você ainda não tem nick.[/red] "
                "rode [bold]bytinho nick <seu-nick>[/bold] primeiro."
            )
            raise typer.Exit(1)

        profile_url = f"{SERVER_URL}/u/{nick}"
        badge_url   = f"{SERVER_URL}/u/{nick}.svg"
        badge_md    = f"[![Bytinho]({badge_url})]({profile_url})"

        # cabeçalho sempre
        console.print()
        console.print(f"[bold magenta]🔗 Perfil público:[/bold magenta] {profile_url}")
        console.print(f"[dim]🖼  Badge SVG:[/dim]       {badge_url}")
        console.print()
        console.print("[bold]📋 Markdown pra README:[/bold]")
        console.print(f"[cyan]{badge_md}[/cyan]")
        console.print()

        # --no-copy mantém o comportamento legado: só mostra, não pergunta
        if no_copy and not to:
            return

        choice = (to or "").strip().lower()
        if not choice:
            console.print("[bold]onde quer compartilhar?[/bold]")
            console.print("  [cyan]1[/cyan]  copiar markdown pra clipboard  [dim](padrão)[/dim]")
            console.print("  [cyan]2[/cyan]  abrir Twitter/X com texto pronto")
            console.print("  [cyan]3[/cyan]  salvar markdown num arquivo")
            console.print("  [cyan]4[/cyan]  gerar card PNG ([dim]usa[/dim] [bold]bytinho card[/bold])")
            console.print("  [cyan]0[/cyan]  cancelar")
            try:
                pick = typer.prompt("escolha", default="1", show_default=False).strip()
            except (typer.Abort, KeyboardInterrupt, EOFError):
                console.print("[dim](cancelado)[/dim]")
                return
            choice = {
                "1": "clipboard", "c": "clipboard", "clipboard": "clipboard",
                "2": "twitter",   "t": "twitter",   "twitter": "twitter",   "x": "twitter",
                "3": "file",      "f": "file",      "file": "file",
                "4": "card",      "p": "card",      "card": "card",         "png": "card",
                "0": "cancel",
            }.get(pick.lower(), "clipboard")

        if choice == "cancel":
            console.print("[dim](cancelado)[/dim]")
            return

        if choice == "clipboard":
            if _copy_to_clipboard(badge_md):
                console.print("[green]✓ markdown copiado pra clipboard![/green]")
            else:
                console.print("[dim](sem clipboard disponível , copia manual aí)[/dim]")
            return

        if choice == "twitter":
            from urllib.parse import quote
            text = (
                f"meu pet dev tá vivo no terminal 🐣\n"
                f"acompanhe @ {profile_url}\n"
                f"#bytinho"
            )
            tweet_url = f"https://twitter.com/intent/tweet?text={quote(text)}"
            console.print(f"[bold cyan]🐦 link do tweet:[/bold cyan] {tweet_url}")
            try:
                import webbrowser
                webbrowser.open(tweet_url)
                console.print("[green]✓ abri no navegador.[/green]")
            except Exception:
                console.print("[dim](não consegui abrir o navegador , copia o link acima)[/dim]")
            return

        if choice == "file":
            target = out or Path("bytinho-share.md")
            target = Path(target).expanduser()
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (
                f"# Bytinho , @{nick}\n\n"
                f"{badge_md}\n\n"
                f"perfil: {profile_url}\n"
            )
            target.write_text(content, encoding="utf-8")
            console.print(f"[green]✓ salvo em[/green] [cyan]{target}[/cyan]")
            return

        if choice == "card":
            from platformdirs import user_cache_dir
            try:
                from ..card import render_card
            except ImportError:
                console.print(
                    "[red]✗ Pillow não instalado.[/red] "
                    "rode [bold]pip install Pillow[/bold]."
                )
                return
            profile = client.profile(nick)
            if not profile:
                console.print(f"[red]✗ perfil @{nick} não encontrado no server.[/red]")
                return
            target = out or Path(user_cache_dir("bytinho")) / f"card-{nick}.png"
            path = render_card(profile, Path(target))
            console.print(f"[green]✓ card salvo em[/green] [cyan]{path}[/cyan]")
            console.print(
                "[dim]arrasta no Twitter/Discord pra anexar como imagem.[/dim]"
            )
            return

        console.print(f"[red]✗ destino desconhecido: {choice}[/red]")

    @app.command("install-badge")
    def install_badge():
        """Insere a badge do Bytinho no README.md do repo atual e faz git commit."""
        import subprocess as sp

        nick = _resolve_nick()
        if not nick:
            console.print(
                "[red]✗ você ainda não tem nick.[/red] "
                "rode [bold]bytinho nick <seu-nick>[/bold] primeiro."
            )
            raise typer.Exit(1)

        try:
            r = sp.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True, text=True, timeout=5,
            )
            if r.returncode != 0:
                console.print("[red]✗ diretório atual não é um repo git.[/red]")
                raise typer.Exit(1)
            git_root = Path(r.stdout.strip())
        except (sp.TimeoutExpired, FileNotFoundError):
            console.print("[red]✗ git não encontrado.[/red]")
            raise typer.Exit(1)

        _BADGE_HOST = "https://bytinho.com"
        badge_md    = f"[![Bytinho]({_BADGE_HOST}/u/{nick}.svg)]({_BADGE_HOST}/u/{nick})"
        marker      = f"{_BADGE_HOST}/u/"

        readme = git_root / "README.md"
        if not readme.exists():
            readme.write_text(f"# {git_root.name}\n\n", encoding="utf-8")

        content = readme.read_text(encoding="utf-8")
        if marker in content:
            console.print(f"[yellow]badge já está no README.md[/yellow]")
            console.print(f"  [dim]{badge_md}[/dim]")
            return

        lines = content.splitlines(keepends=True)
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith("# "):
                insert_at = i + 1
                while insert_at < len(lines) and lines[insert_at].strip() == "":
                    insert_at += 1
                break
        lines.insert(insert_at, badge_md + "\n\n")
        readme.write_text("".join(lines), encoding="utf-8")

        try:
            sp.run(["git", "-C", str(git_root), "add", "README.md"],
                   timeout=5, check=True, capture_output=True)
            sp.run(
                ["git", "-C", str(git_root), "commit", "-m", "chore: add Bytinho badge"],
                timeout=5, check=True, capture_output=True,
            )
            console.print(f"[green]✓ badge adicionada e commitada no README.md![/green]")
        except sp.CalledProcessError:
            console.print(f"[yellow]✓ badge adicionada ao README.md[/yellow] [dim](faça git commit manual)[/dim]")
        console.print(f"  [dim]{badge_md}[/dim]")

    @app.command()
    def ranking(
        top: int = typer.Option(10, "--top", "-n", help="Quantos mostrar."),
    ):
        """Top da semana , quem mais commitou."""
        rows = client.ranking()
        if not rows:
            console.print("[dim]nenhum commit registrado essa semana ainda. seja o primeiro 👀[/dim]")
            return
        me = (load_cache() or {}).get("nick")
        medals = ["🥇", "🥈", "🥉"]
        console.print()
        console.print("[bold magenta]🏆  Ranking semanal , XP de commits[/bold magenta]")
        console.print()
        for i, r in enumerate(rows[:top]):
            prefix = medals[i] if i < 3 else f" {i+1:>2} "
            nick = r["nick"]
            line = (
                f"  {prefix}  [bold cyan]@{nick}[/bold cyan]"
                f"  [dim]·[/dim]  [bold]{r['xp_week']:>5}[/bold] XP semana"
                f"  [dim]·[/dim]  🔥 {r['streak']}d"
                f"  [dim]·[/dim]  {r['stage']}"
            )
            if me and nick == me:
                line += "  [green]← você[/green]"
            console.print(line)
        console.print()

    @app.command()
    def achievements(
        other: str = typer.Option("", "--user", "-u",
                                  help="Ver conquistas de outro nick (público)."),
    ):
        """Lista conquistas desbloqueadas."""
        if other:
            rows = client.profile(other)
            if rows is None:
                console.print(f"[red]✗ user @{other} não encontrado.[/red]")
                return
            achs = rows.get("achievements", [])
            title = f"@{other}"
        else:
            data = client.sync()
            if not data:
                console.print("[red]✗ The Core offline.[/red]")
                return
            achs = client.my_achievements()
            title = data["user"].get("nick") or "você"

        console.print()
        console.print(f"[bold magenta]🏅  Conquistas , {title}[/bold magenta]")
        console.print()
        if not achs:
            console.print("[dim]nenhuma ainda. faz um commit aí 👀[/dim]\n")
            return
        for a in achs:
            console.print(
                f"  {a['icon']}  [bold]{a['title']}[/bold]"
                f"   [dim]· {a['desc']}[/dim]"
            )
        console.print()
