<div align="center">

# 👾 bytinho

**Um Tamagotchi pra dev. Mora no terminal, come `git commit`.**

[![PyPI](https://img.shields.io/pypi/v/bytinho.svg?color=ff79c6)](https://pypi.org/project/bytinho/)
[![Python](https://img.shields.io/pypi/pyversions/bytinho.svg?color=8be9fd)](https://pypi.org/project/bytinho/)
[![MIT](https://img.shields.io/badge/license-MIT-50fa7b.svg)](https://github.com/andryus/bytinho/blob/main/LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/bytinho.svg?color=ffb86c)](https://pypi.org/project/bytinho/)
[![The Core](https://img.shields.io/website?url=https%3A%2F%2Fbytinho.com%2Fhealth&label=server&color=bd93f9)](https://bytinho.com/health)

</div>

---

```
        ___
       /   \
      /     \
     |   o   |        Bytinho de @você   Lv.4   240 XP
      \     /         🟢 online   🔥 7d streak
       \___/
   ~-~-~-~-~-~-

   🍕 ━━━━━━━━━━━━━━━━━━━━━━━━━━━╸━━━━
   🔋 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   😊 ━━━━━━━━━━━━━━━━━━━━━━━━━━━╸━━

   💬 Eita, sua fav é Rust com TOML kkk 🦀
```

Você commita todo dia. Por que não ter um companheiro te enchendo o saco
quando passa três dias sem aparecer?

---

## ⚡ Quick start

```bash
pipx install bytinho        # ou: pip install --user bytinho
bytinho nick seu-nick       # 1x: registra teu apelido
bytinho install-hook        # cada commit vira XP
bytinho                     # mostra teu pet
```

Pronto. Próximo `git commit` já alimenta o Bytinho.

> 💻 Linux · macOS · WSL · Python 3.10+
> 🔐 Sem login, sem senha. Só um UUID local em `~/.local/share/bytinho/`

---

## 🎮 Comandos

| Comando                | O que faz                                       |
| ---------------------- | ----------------------------------------------- |
| `bytinho`              | Pet animado, status atual                        |
| `bytinho talk "oi"`    | Conversa com contexto dos teus commits           |
| `bytinho streak`       | Dias seguidos commitando                         |
| `bytinho ranking`      | Top 10 da semana                                 |
| `bytinho achievements` | Conquistas desbloqueadas                         |
| `bytinho share`        | Markdown da badge pra colar no README            |
| `bytinho export`       | Backup do pet em JSON                            |
| `bytinho import`       | Restaura backup                                  |
| `bytinho install-hook` | Liga o hook de `git commit`                      |
| `bytinho remove-hook`  | Desliga                                          |
| `bytinho --help`       | Ver tudo                                         |

---

## 🔒 Privacidade

O hook lê o commit **na tua máquina** e manda **só agregados** pro servidor:

| Vai pro servidor                          | NÃO vai                          |
| ----------------------------------------- | -------------------------------- |
| Linguagem (`Rust`, `Python`...)           | ❌ Código fonte                  |
| Tipo (`feat:`, `fix:`, `chore:`...)       | ❌ Mensagem do commit            |
| Contagem de linhas (+/−)                  | ❌ Nome dos arquivos             |
| Hora UTC, dia da semana                   | ❌ Diff completo                 |
| SHA do commit (pra deduplicar)            | ❌ Branch privada / segredos     |

Se ainda assim te incomoda, `bytinho remove-hook` desliga em 1 segundo. O CLI
continua funcionando offline com o cache local.

---

## 🏆 Conquistas

20 conquistas. Algumas favoritas:

- 🌅 **Madrugador**: commit antes das 7h
- 🦉 **Coruja**: commit antes das 5h
- 🛡️ **Guerreiro de Fds**: commit no sábado/domingo
- 🐍 **Poliglota**: 3+ linguagens em commits
- 🐛 **Bug Hunter**: 10 commits de `fix:`
- 💥 **Big Bang**: commit com 500+ linhas
- 🎯 **Cirurgião**: 10 commits com menos de 10 linhas
- 🌉 **Friday Shipper**: `feat:` na sexta
- 🔥 **Streak Master**: 3 / 7 / 30 dias seguidos

E mais 11 escondidas. `bytinho achievements` mostra as tuas.

---

## 🎖️ Badge pro teu repo

```markdown
[![Bytinho](https://bytinho.com/u/seu-nick.svg)](https://bytinho.com/u/seu-nick)
```

Atualiza sozinho com teu XP, streak e stage atual.

---

## 🛠️ Como funciona

```
git commit
   ↓
hook (cli/bytinho/git_meta.py) extrai agregados
   ↓
POST /api/sync → bytinho.com
   ↓
servidor calcula XP, streak, conquistas, "soul"
   ↓
bytinho talk → resposta com contexto dos teus commits
```

O servidor (The Core) é fechado, mas o CLI é 100% open source. Lê o código
em [github.com/andryus/bytinho](https://github.com/andryus/bytinho).

---

## 🐛 Problemas?

- Hook não dispara? → `bytinho install-hook --force`
- Pet morreu/zerou? → `bytinho import backup.json` (se tiver export)
- Server offline? → CLI cacheia tudo, sincroniza quando voltar

Issues e PRs em [github.com/andryus/bytinho](https://github.com/andryus/bytinho/issues).

---

## 📜 Licença

[MIT](https://github.com/andryus/bytinho/blob/main/LICENSE) © Andryus / Qantara
