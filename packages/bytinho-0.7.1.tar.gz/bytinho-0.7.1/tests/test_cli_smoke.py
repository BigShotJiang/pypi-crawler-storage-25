"""Smoke tests do CLI: garantem que cada comando não explode.

Não testam comportamento profundo , só:
- exit_code == 0 (ou exit_code esperado)
- ausência de tracebacks
- presença de strings-âncora na saída

Pré-mockados via conftest: client.* (HTTP) + DATA_DIR (filesystem).
"""
from unittest.mock import MagicMock

import pytest


# ---------- meta -----------------------------------------------------------

def test_version(cli):
    runner, app = cli
    r = runner.invoke(app, ["version"])
    assert r.exit_code == 0
    assert "Bytinho" in r.output


def test_credits(cli):
    runner, app = cli
    r = runner.invoke(app, ["credits"])
    assert r.exit_code == 0


def test_donate(cli):
    runner, app = cli
    r = runner.invoke(app, ["donate"])
    assert r.exit_code == 0


def test_doctor(cli):
    runner, app = cli
    r = runner.invoke(app, ["doctor"])
    # doctor pode retornar !=0 se algum check falhar; mínimo: não estoura.
    assert r.exit_code in (0, 1)
    assert "Traceback" not in r.output


# ---------- pet básico -----------------------------------------------------

def test_status_static(cli):
    runner, app = cli
    r = runner.invoke(app, ["status", "--static"])
    assert r.exit_code == 0
    assert "Bytinho" in r.output


def test_streak(cli):
    runner, app = cli
    r = runner.invoke(app, ["streak"])
    assert r.exit_code == 0


# ---------- pet ações ------------------------------------------------------

def test_feed(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["feed"])
    assert r.exit_code == 0
    mock_client.action.assert_called_once()
    assert mock_client.action.call_args[0][0] == "feed"


def test_play(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["play"])
    assert r.exit_code == 0
    mock_client.action.assert_called_once_with("play")


def test_sleep(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["sleep"])
    assert r.exit_code == 0
    mock_client.action.assert_called_once_with("sleep")


def test_wake(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["wake"])
    assert r.exit_code == 0
    mock_client.action.assert_called_once_with("wake")


# ---------- identity -------------------------------------------------------

def test_nick_valido(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["nick", "andryus"])
    assert r.exit_code == 0
    mock_client.set_nick.assert_called_once_with("andryus")


def test_nick_falha(cli, mock_client):
    runner, app = cli
    mock_client.set_nick.return_value = (False, "Nick inválido")
    r = runner.invoke(app, ["nick", "ab"])
    # CLI imprime erro mas não dá raise , exit_code 0
    assert "Nick inválido" in r.output or "✗" in r.output


def test_rename(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["rename", "Floquinho"])
    assert r.exit_code == 0
    mock_client.rename_pet.assert_called_once_with("Floquinho")


def test_export_imprime_uuid(cli, isolated_data_dir):
    runner, app = cli
    r = runner.invoke(app, ["export"])
    assert r.exit_code == 0
    # Deve imprimir o UUID fixo do fixture
    assert "11111111" in r.output


def test_import_uuid_invalido(cli):
    runner, app = cli
    r = runner.invoke(app, ["import", "not-a-uuid"])
    assert "inválid" in r.output.lower() or "✗" in r.output


# ---------- chat / talk ----------------------------------------------------

def test_talk(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["talk", "oi"])
    assert r.exit_code == 0
    mock_client.talk.assert_called_once()


# ---------- social ---------------------------------------------------------

def test_ranking(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["ranking"])
    assert r.exit_code == 0
    mock_client.ranking.assert_called_once()


def test_achievements_vazio(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["achievements"])
    assert r.exit_code == 0


def test_report(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["report", "spammer", "spam de cripto"])
    assert r.exit_code == 0
    mock_client.report_user.assert_called_once()


# ---------- offline / resiliência -----------------------------------------

def test_status_offline_nao_estoura(cli, mock_client):
    """Se sync() retorna None (offline), CLI deve degradar com cache."""
    runner, app = cli
    mock_client.sync.return_value = None
    mock_client.health.return_value = {
        "status": "offline", "brain": "offline", "chat_online": 0,
    }
    r = runner.invoke(app, ["status", "--static"])
    assert r.exit_code == 0
    assert "Traceback" not in r.output


def test_feed_offline_mensagem_amigavel(cli, mock_client):
    runner, app = cli
    mock_client.action.return_value = None
    r = runner.invoke(app, ["feed"])
    assert r.exit_code == 0
    # Esperamos que tenha alguma menção de offline / falha (não tracebacks)
    assert "Traceback" not in r.output


# ---------- help -----------------------------------------------------------

@pytest.mark.parametrize("cmd", [
    "status", "feed", "play", "sleep", "wake",
    "nick", "rename", "talk", "ranking", "streak",
    "achievements", "version", "doctor", "report",
    "export", "import",
])
def test_help_para_cada_comando(cli, cmd):
    """Cada comando deve responder a --help sem estourar."""
    runner, app = cli
    r = runner.invoke(app, [cmd, "--help"])
    assert r.exit_code == 0
    assert "Usage" in r.output or "Uso" in r.output or cmd in r.output.lower()
