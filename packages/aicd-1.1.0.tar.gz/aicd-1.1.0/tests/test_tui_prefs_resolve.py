from __future__ import annotations

from pathlib import Path

import pytest

from aicd.tui_prefs import resolve_tui_assistant_markdown_chat


def test_resolve_assistant_markdown_env_overrides_prefs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    d = tmp_path / "data"
    d.mkdir(parents=True)
    p = d / "tui_prefs.json"
    p.write_text('{"assistant_markdown_chat": true}\n', encoding="utf-8")
    monkeypatch.setenv("AICD_TUI_ASSISTANT_MARKDOWN", "0")
    assert resolve_tui_assistant_markdown_chat(d) is False
    monkeypatch.setenv("AICD_TUI_ASSISTANT_MARKDOWN", "1")
    assert resolve_tui_assistant_markdown_chat(d) is True


def test_resolve_assistant_markdown_reads_prefs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    d = tmp_path / "data"
    d.mkdir(parents=True)
    monkeypatch.delenv("AICD_TUI_ASSISTANT_MARKDOWN", raising=False)
    assert resolve_tui_assistant_markdown_chat(d) is True
    (d / "tui_prefs.json").write_text(
        '{"assistant_markdown_chat": false}\n', encoding="utf-8"
    )
    assert resolve_tui_assistant_markdown_chat(d) is False
    (d / "tui_prefs.json").write_text(
        '{"assistant_markdown_chat": true}\n', encoding="utf-8"
    )
    assert resolve_tui_assistant_markdown_chat(d) is True
