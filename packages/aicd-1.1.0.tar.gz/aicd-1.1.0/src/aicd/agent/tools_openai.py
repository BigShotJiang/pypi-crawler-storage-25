from __future__ import annotations

from typing import Any

from aicd.tools.drawio_embed_export import drawio_export_png_allowed


def _core_openai_tools() -> list[dict[str, Any]]:
    return [
        _fn(
            "fs_list_dir",
            "List files in a directory",
            {"path": {"type": "string", "description": "Directory path"}},
            required=["path"],
        ),
        _fn(
            "fs_read_file",
            "Read a text file. **align_utf8=true** (default): try UTF-8 strictly first; if the bytes are not valid UTF-8, detect encoding via **charset_normalizer** (from file head), decode to Unicode for **text**, and return **source_encoding** / optional **language_guess** / **encoding_note** (legacy GBK/GB18030 etc.). "
            "Optional **byte_offset** (0-based) + **max_bytes** for range reads (non-UTF-8 files use head-based detection for the same on-disk encoding). "
            "**align_utf8** also trims incomplete UTF-8 at chunk edges when the file is UTF-8. **max_bytes** defaults to **paths.max_read_bytes** when omitted. **align_utf8=false**: strict UTF-8 only or **binary_preview_hex** on failure.",
            {
                "path": {"type": "string"},
                "max_bytes": {
                    "type": "integer",
                    "description": "Max bytes to read; from file start if no byte_offset, else from offset",
                },
                "byte_offset": {
                    "type": "integer",
                    "description": "0-based start byte; omit to read from beginning (legacy whole-file + truncate)",
                },
                "align_utf8": {
                    "type": "boolean",
                    "default": True,
                    "description": "Trim incomplete UTF-8 at start/end of chunk (recommended)",
                },
            },
            required=["path"],
        ),
        _fn(
            "fs_write_file",
            "Write text to a file",
            {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            required=["path", "content"],
        ),
        _fn(
            "fs_delete",
            "Delete file or directory",
            {
                "path": {"type": "string"},
                "dry_run": {"type": "boolean", "default": False},
            },
            required=["path"],
        ),
        _fn(
            "fs_mkdir",
            "Create directory",
            {"path": {"type": "string"}},
            required=["path"],
        ),
        _fn(
            "fs_move",
            "Move/rename path",
            {"from_path": {"type": "string"}, "to_path": {"type": "string"}},
            required=["from_path", "to_path"],
        ),
        _fn(
            "fs_glob",
            "Find files under directory matching glob pattern (e.g. *.py)",
            {"directory": {"type": "string"}, "pattern": {"type": "string"}},
            required=["directory", "pattern"],
        ),
        _fn(
            "fs_search_regex",
            "Search file contents with regex under a directory",
            {
                "directory": {"type": "string"},
                "regex": {"type": "string"},
                "glob_filter": {"type": "string", "default": "*"},
            },
            required=["directory", "regex"],
        ),
        _fn(
            "text_regex_replace",
            "Regex replace in UTF-8 text file",
            {
                "path": {"type": "string"},
                "pattern": {"type": "string"},
                "replacement": {"type": "string"},
                "count": {"type": "integer", "default": 0},
            },
            required=["path", "pattern", "replacement"],
        ),
        _fn(
            "text_patch_bytes_hex",
            "Patch binary file at offset with hex string (two hex chars = one byte)",
            {
                "path": {"type": "string"},
                "offset": {"type": "integer"},
                "hex_data": {"type": "string"},
            },
            required=["path", "offset", "hex_data"],
        ),
        _fn(
            "run_command",
            "Run shell command or direct argv. Windows: default runs via %ComSpec% cmd /d with UTF-8 code page 65001 "
            "(dir/copy/内置命令可用); optional shell=powershell|pwsh; or pass argv e.g. [\"git\",\"status\"] to skip shell. "
            "Unix: sh -c command. "
            "Avoid **`cd && python -c \"...\"`** on Windows in a single **command** string; use **argv** or **script_run**. "
            "On failure, the result may include **aicd_hint** (inline `-c` / quoting / **script_run** suggestion). "
            "Windows **findstr**: last file operands must be files/globs—**not** a bare folder name (else *Cannot open*); use `subdir\\\\*.*` + `/s` or **fs_search_regex** / **rg**. "
            "**Interactive installs (after user consent)**: prefer package-manager **non-interactive flags** (-y, --yes, winget accept switches). "
            "Also **noninteractive_env**=true for CI/pip/npm-friendly env defaults; **stdin_mode**=**auto_yes** sends periodic `y` for common [Y/n] prompts—**never** for secrets: on password prompts the run **fails** with **interactive_password_or_secret_prompt**; **ask the user**. "
            "**stdin_mode** **inherit** (default): subprocess stdin is **not** wired to the human typing in chat—**do not** use for **vim/less/REPL/multi-step wizards** needing a real TTY. Idle guard: if **omitted**, kills after **900s** without a **new stdout/stderr line** (set **output_idle_timeout_sec** higher, or **0** to disable). "
            "**stdin_mode** **devnull** gives subprocess EOF on stdin (fail fast on line-based prompts). "
            "**output_idle_timeout_sec**: line-buffered idle guard; **auto_yes** defaults to **600** when omitted; **inherit** defaults to **900**; **0** disables. Spinners without newlines may false-trigger—increase timeout or use non-interactive flags / log to file. "
            "**Do not** run **pytest / npm test / build / compile** unless the user explicitly asked to execute tests or build.",
            {
                "command": {
                    "type": "string",
                    "description": "One shell line (omit if using argv)",
                },
                "argv": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Executable + args, no shell (paths with spaces stay separate elements)",
                },
                "shell": {
                    "type": "string",
                    "enum": ["cmd", "powershell", "pwsh"],
                    "description": "Windows only: interpreter for command string",
                },
                "cwd": {"type": "string"},
                "timeout_sec": {"type": "number", "default": 600},
                "noninteractive_env": {
                    "type": "boolean",
                    "description": "Merge non-interactive env defaults (CI, DEBIAN_FRONTEND, PIP_NO_INPUT, NPM_CONFIG_YES, …)",
                },
                "stdin_mode": {
                    "type": "string",
                    "enum": ["inherit", "devnull", "auto_yes"],
                    "description": "inherit=default (see tool text: not a real user TTY; idle kill 900s default); devnull=EOF on stdin; auto_yes=Y/n pipe + idle 600s default",
                },
                "output_idle_timeout_sec": {
                    "type": "number",
                    "description": "Kill if no new stdout/stderr line for this long (s); auto_yes default 600 if omitted; inherit default 900 if omitted; 0=disable idle guard",
                },
            },
            required=[],
        ),
        _fn(
            "interactive_process",
            "**Multi-turn interactive subprocess (Linux / macOS / Windows)**. Use when **run_command** cannot complete the job because the program needs **several stdin responses** (menus, ``input()``, license prompts) and non-interactive flags are unavailable. "
            "**Not** a real TTY—**vim/ncurses/full-screen TUIs** may still break. Same **command/argv/shell/cwd** rules as **run_command**. "
            "Flow: **operation** **start** (optional **session_label** for a stable name) → **read** → **write** (from your plan or **after asking the user** in chat) → repeat → **terminate**. Use **list_sessions** when the user says **“the second one”** / **multiple** tasks—map **session_index** (1-based, creation order) or **session_label** to **write/read**. Selector priority if several fields present: **session_id** > **session_label** > **session_index**. "
            "**password_hint** in results: **never** auto-type passwords—ask the user or have them run the step locally. Prefer **noninteractive_env** + package **-y** flags when installs are allowed. "
            "Sessions are **scoped per agent/router** (main vs **task_ai** do not share). Idle auto-close: **agent.interactiveProcessIdleSec** in **config.yaml** (or **agent_settings_update**); **0**=off. **chat_new_session** clears main’s interactive table. "
            "Cap: few concurrent sessions; large captures truncate—redirect bulky logs to files under **ai_tmp** if needed.",
            {
                "operation": {
                    "type": "string",
                    "enum": ["start", "write", "read", "terminate", "status", "list_sessions"],
                    "description": "start=spawn; list_sessions=snapshot of active sessions; write/read/terminate/status need a selector",
                },
                "session_id": {
                    "type": "string",
                    "description": "UUID from start (optional if session_label or session_index set)",
                },
                "session_label": {
                    "type": "string",
                    "description": "On **start**: optional unique name; on **write/read/terminate/status**: select session by this label (unique among live sessions)",
                },
                "session_index": {
                    "type": "integer",
                    "description": "1-based index from list_sessions (creation order); alternative to session_id/label",
                },
                "command": {
                    "type": "string",
                    "description": "Same as run_command (omit if argv)",
                },
                "argv": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Executable + args, same as run_command",
                },
                "shell": {
                    "type": "string",
                    "enum": ["cmd", "powershell", "pwsh"],
                    "description": "Windows only, for command string",
                },
                "cwd": {"type": "string"},
                "env": {
                    "type": "object",
                    "description": "Extra env vars (merged); optional",
                },
                "noninteractive_env": {
                    "type": "boolean",
                    "description": "Merge same CI/pip/npm defaults as run_command when true",
                },
                "text": {
                    "type": "string",
                    "description": "Stdin payload for write (often a line or choice); UTF-8. Large payloads are chunked on the wire; total per call capped (~8 MiB server-side)",
                },
                "append_newline": {
                    "type": "boolean",
                    "default": True,
                    "description": "Append \\n after text for write (default true)",
                },
                "timeout_sec": {
                    "type": "number",
                    "default": 5,
                    "description": "Per-read wait for stdout/stderr chunks (capped at 600s server-side; not total wall for whole CLI)",
                },
                "max_bytes": {
                    "type": "integer",
                    "default": 65536,
                    "description": "Upper bound per stream read; capped server-side",
                },
                "stream": {
                    "type": "string",
                    "enum": ["both", "stdout", "stderr"],
                    "default": "both",
                    "description": "Which streams to read in one call",
                },
                "kill_subtree": {
                    "type": "boolean",
                    "description": "terminate: Windows default true via process tree kill; set false to try signal root only",
                },
            },
            required=["operation"],
        ),
        _fn(
            "http_request",
            "HTTP request (通用 API；正文通常为原始响应). "
            "浏览网页要正文、少用广告：优先 **web_fetch**（main_text）。GitHub REST：优先 **github_api**（自动 Base URL / Accept / token）。",
            {
                "method": {"type": "string"},
                "url": {"type": "string"},
                "json_body": {"type": "object"},
                "headers": {"type": "object"},
                "data": {"type": "string", "description": "Raw body (UTF-8); alternative to json_body"},
                "timeout_sec": {"type": "number", "default": 60},
            },
            required=["method", "url"],
        ),
        _fn(
            "http_download",
            "Download a URL into AICD_HOME cache (good for quick fetches). "
            "For saving under the workspace or very large files, prefer **task_shell** with curl/wget and a path under **ai_tmp**.",
            {"url": {"type": "string"}, "filename": {"type": "string"}},
            required=["url"],
        ),
        _fn(
            "web_fetch",
            "HTTP GET 网页或 JSON/text。**extract**=**main_text**（默认）时用 trafilatura 抽取正文、弱化导航/广告块；"
            "未安装时降级为简易去标签并返回 **install_suggestions**。**raw**=原文字节解码。"
            "User-Agent / 超时 / 响应截断见 **config.yaml** ``integrations.webFetch``。仅 **http(s)**。",
            {
                "url": {"type": "string"},
                "extract": {
                    "type": "string",
                    "enum": ["main_text", "raw"],
                    "default": "main_text",
                    "description": "main_text 仅对 HTML 做正文抽取；其它 Content-Type 与 raw 相同",
                },
                "timeout_sec": {"type": "number"},
                "max_response_bytes": {"type": "integer"},
                "max_text_chars": {
                    "type": "integer",
                    "description": "返回 text 最大字符（默认 500000）",
                },
                "follow_redirects": {"type": "boolean", "default": True},
            },
            required=["url"],
        ),
        _fn(
            "github_api",
            "调用 GitHub REST API：**path** 须以 ``/`` 开头（如 ``/repos/owner/repo``）。"
            "**token** 来自 ``config.yaml`` ``integrations.github.token`` 或环境变量 **GITHUB_TOKEN** / **GH_TOKEN**。"
            "**query** 为扁平键值（URL query）。成功时若有 JSON Content-Type 则 **json** 已解析，否则看 **text**。",
            {
                "method": {"type": "string", "default": "GET"},
                "path": {"type": "string"},
                "query": {"type": "object", "description": "Optional query parameters"},
                "json_body": {"type": "object"},
                "data": {"type": "string"},
                "timeout_sec": {"type": "number", "default": 60},
            },
            required=["path"],
        ),
        _fn(
            "github_repo_read",
            "读取 GitHub 仓库**源码或目录**（官方 REST **Contents API**），用于实现功能时参考第三方组件。"
            "**owner** / **repo** 必填；**path** 为空=列出根目录；**path** 为文件路径则返回 UTF-8 文本（大文件可能截断）。"
            "**ref** 为分支/tag/commit SHA。私有库需配置 **integrations.github.token** 或 **GITHUB_TOKEN**。"
            "更通用的 GitHub HTTP 仍用 **github_api**；搜索代码可用 **github_api** ``GET /search/code``。",
            {
                "owner": {"type": "string"},
                "repo": {"type": "string"},
                "path": {
                    "type": "string",
                    "description": "仓库内路径，如 src/foo.py 或 src（目录）；省略或空=根目录列表",
                },
                "ref": {
                    "type": "string",
                    "description": "分支或 tag 或 commit；省略则默认仓库默认分支",
                },
                "timeout_sec": {"type": "number"},
                "max_text_chars": {
                    "type": "integer",
                    "description": "单文件最大返回字符（默认 400000）",
                },
                "max_directory_entries": {"type": "integer", "default": 200},
            },
            required=["owner", "repo"],
        ),
        _fn(
            "site_bookmarks_list",
            "列出 HOME **站点收藏**（``AICD_HOME/data/site_bookmarks.yaml``）。"
            "只收录**网站级**入口（搜索引擎、门户、文档站根等），不收录单篇文章 URL。"
            "可选 **tag** / **query** 过滤；条目含 **content_summary_preview** 与标签，便于选型检索。",
            {
                "tag": {"type": "string"},
                "query": {"type": "string"},
            },
            required=[],
        ),
        _fn(
            "site_bookmarks_get",
            "读取单条站点收藏（**entry_id** 或 **canonical url**）。",
            {
                "entry_id": {"type": "string"},
                "url": {"type": "string"},
            },
            required=[],
        ),
        _fn(
            "site_bookmarks_add",
            "新增站点收藏：默认只接受**域名根** URL（``strict_site_root`` 默认 true）。"
            "``allow_single_path_segment`` 为 true 时允许单段路径门户（如 /docs）。"
            "``fetch_summary`` 默认 true：抓取首页生成 **content_summary**（非 LLM，正文摘录）。",
            {
                "url": {"type": "string"},
                "display_name": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "notes": {"type": "string"},
                "strict_site_root": {"type": "boolean", "default": True},
                "allow_single_path_segment": {"type": "boolean", "default": False},
                "fetch_summary": {"type": "boolean", "default": True},
                "timeout_sec": {"type": "number"},
                "max_response_bytes": {"type": "integer"},
            },
            required=["url"],
        ),
        _fn(
            "site_bookmarks_update",
            "按 **entry_id** 更新；**patch** 可含 display_name、tags、notes、content_summary、"
            "canonical_url（改址时需合法站点 URL）。**refetch_summary** 为 true 时重新抓取摘要。",
            {
                "entry_id": {"type": "string"},
                "patch": {"type": "object", "description": "可为空对象；与 refetch_summary 二选一非空"},
                "refetch_summary": {"type": "boolean", "default": False},
                "timeout_sec": {"type": "number"},
                "max_response_bytes": {"type": "integer"},
            },
            required=["entry_id"],
        ),
        _fn(
            "site_bookmarks_remove",
            "删除站点收藏（**entry_id** 或 **url** 其一）。",
            {
                "entry_id": {"type": "string"},
                "url": {"type": "string"},
            },
            required=[],
        ),
        _fn(
            "script_run",
            "Run a temporary script: kind=py|ps1|cmd|bash. "
            "For **py**, **AST parse** runs **before** executing—syntax errors return **`syntax_precheck`** (lineno/offset) without spawning the interpreter; "
            "broken scripts are still archived to **bak/** when **related_doc**/policy allows. "
            "The file is written with a normalized name ``YYYYMMDDTHHMMSSZ_<kind>_<related_doc>_<id>.<ext>``, executed, "
            "then **copied** to **`<AI output>/bak/`** (same basename) for audit/reuse—the copy under **AICD_HOME/tmp/scripts** is removed after a successful archive. "
            "Pass **related_doc** (e.g. manual_v2, output/library/foo/spec) so backups sort and grep by document context. "
            "**Do not** use **script_run** to execute **tests or full builds** unless the user explicitly requested running them.",
            {
                "kind": {"type": "string"},
                "source": {"type": "string"},
                "timeout_sec": {"type": "number", "default": 300},
                "related_doc": {
                    "type": "string",
                    "description": "Short label for the document or task (stem/path fragment); used in the backup filename",
                },
            },
            required=["kind", "source"],
        ),
        _fn(
            "task_shell",
            "Start a **non-AI** background shell task (same interpreter rules as run_command). "
            "Use for long downloads (curl/wget), unzip/tar, ripgrep/find over large trees, uploads—logs stream to the task panel. "
            "**Do not** queue **test suites or builds** unless the user explicitly asked to run them. "
            "Optional cwd; default is AI workspace. Returns **task_id**; use **task_list** / **task_result** when the user asks for status. "
            "**payload.shell_process** records **root_pid** (the shell wrapper, e.g. cmd.exe)—GUI apps you start from the command are its descendants. "
            "**Windows**: **task_cancel** ends the **entire process tree** (``taskkill /T /F``) so PyQt/Tk windows do not outlive the cancelled task. "
            "Redirect bulky output to a file under **ai_tmp** when appropriate. "
            "**Windows**: do not chain **`cd ... && python -c \"...\"`** in one line (CMD breaks quotes); use **script_run** (py) or **argv** + a **.py** file. "
            "Same **noninteractive_env** / **stdin_mode** / **output_idle_timeout_sec** as **run_command** (default **inherit** → **900s** output-idle guard unless overridden or **0**).",
            {
                "command": {"type": "string"},
                "cwd": {"type": "string"},
                "noninteractive_env": {
                    "type": "boolean",
                    "description": "Same as run_command",
                },
                "stdin_mode": {
                    "type": "string",
                    "enum": ["inherit", "devnull", "auto_yes"],
                    "description": "Same semantics as run_command; avoid inherit for TTY-heavy tools",
                },
                "output_idle_timeout_sec": {
                    "type": "number",
                    "description": "Same as run_command; 0 disables line-idle kill",
                },
            },
            required=["command"],
        ),
        _fn(
            "task_dummy",
            "Start dummy progress task for testing",
            {"steps": {"type": "integer", "default": 5}},
            required=[],
        ),
        _fn(
            "task_ai",
            "Start a **background AI sub-agent** (separate tool loop, sandbox cwd under HOME/tasks/<id>/workspace; "
            "scratch under **AI tmp/tasks/<task_id>/**). Nested calls from a running sub-agent auto-set **parent_id**. "
            "Optional **topic_slug** (lowercase a-z, digits, `_`, `-`) creates **output/deliverables/<slug>/** for user-visible artifacts. "
            "**read_only_paths**: extra absolute or workspace paths the sub-agent may read. **parent_handoff_expectation**: short note on what to return. "
            "**agent_workflow** (optional): **default** | **planner** | **executor** | **reviewer** | **full_cycle** — appends a **role block** to the sub-agent system prompt (decompose vs ship vs QA vs plan+execute+review in one task). Aliases: plan→planner, build→executor, review→reviewer, plan_execute_review→full_cycle. "
            "**agent_kind** (optional): **coder** | **doc** | **validator** | **maintainer** | **operator** (host/desktop ops) or a custom key from **agent_kind_upsert** — appends role-focused system text; default **coder**. "
            "**work_mode** (optional): **general** | **dev** | **script** | **pentest** | **ops** or custom — scene policy + tmp layout; "
            "omit to inherit **main session** work_mode for top-level **task_ai**, or **parent task** work_mode when nested. "
            "**llm_profile_name** (optional): named **llmProfiles** entry for this sub-agent; overrides **agent_kind** default profile. "
            "**display_title** / **purpose** / **estimated_steps** help the user read the task panel and **task_list.timeline**; sub-agents should call **task_progress** for human-readable steps. "
            "Main agent may spawn a **verification** sub-task after delivery (doc QA: tables, MD→DOCX/PDF, whitespace, punctuation; code: syntax—run tests/compile only if the user asked). "
            "Use **task_message_send** / **task_message_inbox** for structured parent/child updates.",
            {
                "instruction": {"type": "string"},
                "display_title": {
                    "type": "string",
                    "description": "Short label for the task list (defaults to first line of instruction)",
                },
                "purpose": {
                    "type": "string",
                    "description": "Why this sub-task exists (user-facing)",
                },
                "estimated_steps": {
                    "type": "integer",
                    "description": "Rough expected steps (1–10000) for planning; optional",
                },
                "topic_slug": {
                    "type": "string",
                    "description": "Optional folder segment under deliverables/ (validated safe characters)",
                },
                "read_only_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional paths the sub-agent may read (do not modify)",
                },
                "parent_handoff_expectation": {
                    "type": "string",
                    "description": "Short text: what the parent expects back (paths, format)",
                },
                "agent_workflow": {
                    "type": "string",
                    "description": "Sub-agent role: default | planner | executor | reviewer | full_cycle",
                },
                "agent_kind": {
                    "type": "string",
                    "description": "Agent type key (coder, doc, validator, maintainer, or custom)",
                },
                "work_mode": {
                    "type": "string",
                    "description": "Scene mode; omit: top-level inherits main session, nested inherits parent task",
                },
                "llm_profile_name": {
                    "type": "string",
                    "description": "Optional llmProfiles name for this sub-agent LLM client",
                },
            },
            required=["instruction"],
        ),
        _fn(
            "task_progress",
            "Update **payload.progress** for the current or given **task_id** so **task_list** / **task_result** / TUI show "
            "**step_index**, optional **step_total**, **current_focus** (what you are doing now), **note**. "
            "Call every few tool rounds on long jobs; split work with smaller **task_ai** if one job stalls. "
            "Nested **`task_ai`** may set **sync_to_parent**: true to also patch the **parent** task's **payload.children_progress** (per-child id digest) so the orchestrator sees substeps in **task_result.timeline** without polling every child.",
            {
                "step_index": {"type": "integer"},
                "step_total": {"type": "integer"},
                "current_focus": {"type": "string"},
                "note": {"type": "string"},
                "task_id": {"type": "string"},
                "sync_to_parent": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true and this task has parent_id, merge progress digest into parent's children_progress",
                },
            },
            required=["step_index"],
        ),
        _fn(
            "task_thread_stats",
            "Aggregate timing for tasks tied to **thread_root_id** (defaults to main chat **session_id** for top-level **task_ai**). "
            "Returns **reference_clock_utc**, **sum_duration_sec** (finished tasks), **wall_span_sec**, counts by status — plus "
            "**age_since_earliest_start_sec** / **age_since_latest_finish_sec** when those timestamps exist — use after a big user request completes.",
            {
                "thread_root_id": {
                    "type": "string",
                    "description": "Correlation id (usually chat session_id); omit in main chat to use current session",
                },
                "limit": {"type": "integer", "default": 250},
            },
            required=[],
        ),
        _fn(
            "task_message_send",
            "Post a structured message to another task's inbox (SQLite). "
            "A **running** sub-agent **polls** its inbox after each LLM burst: if new rows exist, it **continues** with them as user text (no new **task_ai** needed). "
            "**kind**: handoff | status | question | **alert** | artifact_index | **directive** | **lifecycle** (usually runtime-only). "
            "**to_task_id** may be **`main`** — resolves to the **main chat inbox** for this session's **thread_root_id** (nested: from task chain; main chat: current session). "
            "The main Agent also receives **lifecycle** automatically when **top-level** **task_ai** / **task_shell** / **dummy** finish (completed/failed/cancelled). "
            "**body**: small JSON — for **directive** prefer `{\"text\": \"...\"}` or `{\"instruction\": \"...\"}`. "
            "**from_task_id** defaults to current **task_ai** id; in **main chat** omit it — stored as **main-<session_id>**. "
            "Returns **resolved_to_task_id** (e.g. **main-inbox-<session>**). Optional **thread_root_id**; otherwise inherited.",
            {
                "to_task_id": {"type": "string"},
                "kind": {"type": "string"},
                "body": {"type": "object"},
                "from_task_id": {"type": "string"},
                "thread_root_id": {
                    "type": "string",
                    "description": "Optional correlation id (defaults from sender task payload)",
                },
            },
            required=["to_task_id", "kind"],
        ),
        _fn(
            "task_message_inbox",
            "List messages addressed **to** a task (newest batch by id). "
            "**to_task_id** defaults to the current task when inside **task_ai**.",
            {
                "to_task_id": {"type": "string"},
                "since_id": {"type": "integer", "default": 0},
                "limit": {"type": "integer", "default": 50},
            },
            required=[],
        ),
        _fn(
            "task_message_mark_read",
            "Mark task message rows as read (by DB id from **task_message_inbox**).",
            {"message_ids": {"type": "array", "items": {"type": "integer"}}},
            required=["message_ids"],
        ),
        _fn(
            "task_main_inbox",
            "Main chat only: list **task_message** rows for **main-inbox-<session>** (child **lifecycle** + upward **status**/**alert**/**question** sent with **to_task_id: main**). "
            "Use **since_message_id** for paging; default **mark_read** true. The runtime injects **unread** rows ( **read_at** null ) at each main-chat tool round as **【主收件箱】**; after injection they are marked read. "
            "Use **mark_read** false only to peek without consuming (otherwise the same rows may be auto-injected again until read).",
            {
                "since_message_id": {"type": "integer", "default": 0},
                "limit": {"type": "integer", "default": 50},
                "mark_read": {"type": "boolean", "default": True},
            },
            required=[],
        ),
        _fn(
            "task_session_children_digest",
            "Main chat only: list **top-level** background tasks for this session (**tasks.thread_root_id** = current **session_id**). "
            "Optional **since_updated_at** (ISO string): only tasks with **updated_at** greater than that — cheap delta check between heartbeats.",
            {
                "since_updated_at": {
                    "type": "string",
                    "description": "Optional ISO timestamp filter on tasks.updated_at",
                },
                "limit": {"type": "integer", "default": 40},
            },
            required=[],
        ),
        _fn(
            "task_scratch_cleanup",
            "Delete all files under **AI tmp/tasks/<task_id>/** only (never deliverables). "
            "**task_id** defaults to the current task when inside **task_ai**; recreates an empty scratch dir. "
            "**Never** use this if that scratch tree holds **`viz_export_html` / `viz_data_chart`** pages (**.html** + sibling **res/**) the user may reopen to edit charts—move or regenerate those under the durable **AI output root** first.",
            {"task_id": {"type": "string"}},
            required=[],
        ),
        _fn(
            "task_list",
            "List recent background tasks (shell / ai_agent / dummy): top-level **reference_clock_utc** plus per row **age_queued_sec**, "
            "**age_since_update_sec**, **age_running_sec** (running + **started_at**), **age_since_finished_sec** (**finished_at**), "
            "**running_now**, **created_at**/**updated_at**, **error**, **timeline** (**started_at**, **finished_at**, **duration_sec**, **progress**, "
            "**sub_agent_trace**, …). Use when the user asks for status or a long-running sub-agent seems stuck.",
            {"limit": {"type": "integer", "default": 30}},
            required=[],
        ),
        _fn(
            "task_cancel",
            "Cancel a running task by id",
            {"task_id": {"type": "string"}},
            required=["task_id"],
        ),
        _fn(
            "task_result",
            "Get one task by id: top-level **reference_clock_utc**, **age_*** fields (same meaning as **task_list**), status, running_now, "
            "full **payload**, **timeline**, result_summary, error, DB timestamps. "
            "Use after task_shell/task_ai or when the user asks for details on a task_id.",
            {"task_id": {"type": "string"}},
            required=["task_id"],
        ),
        _fn(
            "task_history_clear",
            "Wipe **all** persisted background tasks: SQLite **tasks** + **task_messages** (errors/summaries), "
            "on-disk **AICD_HOME/tasks/<id>/** workspaces, and **AI tmp/tasks/** scratch dirs. "
            "Cancels running **task_shell** / **task_ai** / **dummy** first. "
            "**Main chat only** — not inside **task_ai** workers. "
            "Use when the user explicitly wants to reset the task sidebar / remove stale failures. "
            "After clearing, **do not** restart the same multi-step or **task_ai** plan unless the user asks again — treat it as **abort**. "
            "Requires **confirm**: **true** (boolean).",
            {
                "confirm": {
                    "type": "boolean",
                    "description": "Must be JSON true (not a string) to proceed",
                }
            },
            required=["confirm"],
        ),
        _fn(
            "doc_convert_markdown",
            "Legacy: same as doc_extract with markdown + full document. Prefer doc_extract.",
            {
                "source_path": {"type": "string"},
                "output_dir": {"type": "string"},
            },
            required=["source_path", "output_dir"],
        ),
        _fn(
            "doc_normalize",
            "Normalize a document for analysis: write **normalized/** under **output_dir** plus **cache_manifest.json**. "
            "**.md/.html/.txt** are copied; binary/office types use **doc_extract**-class conversion to **markdown**; "
            "**.odt/.rtf/.epub/.org** use **pandoc** when available. **use_cache** skips work when **source_stat** + "
            "**extract_options** (pages, OCR, **docx_engine**, sheets, pandoc **via**) match the manifest. Prefer this before **document_outline** on corpora. "
            "**save_outline**: write **outlines/<stem>.json** (same shape as **document_outline**) and set **outline_path** in the manifest.",
            {
                "source_path": {"type": "string"},
                "output_dir": {"type": "string"},
                "use_cache": {"type": "boolean", "default": True},
                "force_refresh": {"type": "boolean", "default": False},
                "save_outline": {
                    "type": "boolean",
                    "default": False,
                    "description": "Write **outlines/*.json** next to cache; refresh on cache hit too",
                },
                "outline_max_heading_level": {
                    "type": "integer",
                    "default": 6,
                    "description": "1–6 when save_outline",
                },
                "page_start": {"type": "integer"},
                "page_end": {"type": "integer"},
                "use_ocr": {"type": "boolean", "default": False},
                "sheet_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "XLSX / XLS: built-in extract only; markitdown path uses full workbook",
                },
                "docx_engine": {
                    "type": "string",
                    "description": "DOCX only: mammoth (default) | pandoc (requires pandoc on PATH)",
                },
                "markdown_engine": {
                    "type": "string",
                    "description": "Optional markitdown for office/pdf → normalized markdown (pip install aicd[markitdown]). Supports PDF, DOCX/PPTX/XLSX, .xls; .doc/.ppt need LibreOffice headless pre-convert",
                },
                "markitdown_use_llm": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true with markdown_engine=markitdown, pass OpenAI-compatible client to MarkItDown (provider billing)",
                },
            },
            required=["source_path", "output_dir"],
        ),
        _fn(
            "doc_extract",
            "Extract PDF/DOCX/XLSX/PPTX or raster image to txt|html|markdown. "
            "**DOCX → plain text**: set **output_format** to **`txt`** (uses Mammoth + optional python-docx fallback). "
            "**Do not** use **script_run** to re-implement DOCX parsing (avoids bugs like wrong python-docx APIs). "
            "Images saved under output_dir/images_<source_stem>/; MD/HTML reference them by relative path. "
            "page_start/page_end: 1-based inclusive pages (PDF) or slides (PPTX), or sheet index range (XLSX) unless sheet_names set. "
            "use_ocr (PDF): Tesseract OCR on rendered pages (pip install pytesseract + install Tesseract-OCR).",
            {
                "source_path": {"type": "string"},
                "output_dir": {"type": "string"},
                "output_format": {
                    "type": "string",
                    "description": "markdown | html | txt",
                },
                "page_start": {"type": "integer"},
                "page_end": {"type": "integer"},
                "use_ocr": {"type": "boolean", "default": False},
                "sheet_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "XLSX only: explicit sheet names (overrides page range)",
                },
                "docx_engine": {
                    "type": "string",
                    "description": "DOCX + markdown only: mammoth (default) | pandoc (PATH)",
                },
                "markdown_engine": {
                    "type": "string",
                    "description": "Optional: markitdown when output_format=markdown for PDF/DOCX/PPTX/XLSX/.xls/.doc/.ppt (.doc/.ppt: LibreOffice + markitdown)",
                },
                "markitdown_use_llm": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true with markdown_engine=markitdown, enable MarkItDown LLM captions (OpenAI-compatible llm only)",
                },
            },
            required=["source_path", "output_dir"],
        ),
        _fn(
            "document_outline",
            "Build a heading index for a **markdown**, **HTML**, or plain **.txt** file: level, line number (1-based), title text, UTF-8 byte_offset at line start. "
            "Use before reading huge docs: shortlist sections; read a slice with **markdown_section_slice** (uses **heading_index** + outline JSON or on-the-fly outline) or **fs_read_file** with **byte_offset** + **max_bytes**. "
            "Default **save_to_tmp** writes JSON under **AI tmp/outlines/<stem>.json**. "
            "Optional **library_doc_slug** (same rules as **topic_slug**) also writes **`output/library/<slug>/outlines/<stem>.json`** under the AI output root for long-term reuse.",
            {
                "path": {"type": "string"},
                "max_heading_level": {
                    "type": "integer",
                    "default": 6,
                    "description": "Include headings from level 1 up to this (1–6)",
                },
                "save_to_tmp": {"type": "boolean", "default": True},
                "library_doc_slug": {
                    "type": "string",
                    "description": "Optional lowercase slug; persists outline JSON under output/library/<slug>/outlines/",
                },
            },
            required=["path"],
        ),
        _fn(
            "markdown_section_slice",
            "Read one section of a **.md/.html/.txt** file using **document_outline** UTF-8 **byte_offset** boundaries. "
            "Pass **heading_index** (0-based into **headings[]**) **or** explicit **start_byte**/**end_byte**. "
            "Optional **outline_path** loads a saved outline JSON; otherwise the outline is built on the fly. Uses **fs_read_file** range reads internally.",
            {
                "path": {"type": "string"},
                "outline_path": {
                    "type": "string",
                    "description": "Optional JSON from **document_outline**",
                },
                "heading_index": {"type": "integer"},
                "start_byte": {"type": "integer"},
                "end_byte": {"type": "integer"},
                "max_heading_level": {"type": "integer", "default": 6},
                "max_read_bytes": {
                    "type": "integer",
                    "description": "Cap bytes read even if section is larger",
                },
                "align_utf8": {"type": "boolean", "default": True},
            },
            required=["path"],
        ),
        _fn(
            "markdown_regex_scan",
            "Single-file **line-oriented** regex search with **snippet** (+/- **context_lines**); streams lines—suitable for large logs/Markdown. "
            "Patterns apply per line (not multiline across rows).",
            {
                "path": {"type": "string"},
                "pattern": {"type": "string"},
                "context_lines": {"type": "integer", "default": 2},
                "max_matches": {"type": "integer", "default": 100},
                "ignore_case": {"type": "boolean", "default": False},
                "encoding": {"type": "string", "default": "utf-8"},
            },
            required=["path", "pattern"],
        ),
        _fn(
            "markdown_chunk_split",
            "Split a large **.md/.html/.txt** (via **document_outline** semantics) into **chunks/*.md** + **chunks/index.json** under **output_dir**. "
            "**split_max_level** picks heading levels that start a chunk (default **3** → H1–H3). "
            "**max_chunk_bytes** UTF-8 byte cap per chunk when a section is oversized: **omit** to use **chat_session_info → context_adaptive.suggested_chunk_max_bytes** "
            "(derived from **model_context_window_tokens**; CJK ≈1 token/char pessimistic—avoid multi‑hundred‑KB chunks on 128K models). "
            "Call **chat_session_info** after **/llm** when you have both a 128K and a 1M profile.",
            {
                "path": {"type": "string"},
                "output_dir": {"type": "string"},
                "split_max_level": {"type": "integer", "default": 3},
                "max_chunk_bytes": {
                    "type": "integer",
                    "description": "UTF-8 byte cap per chunk; omit for adaptive default from current model context",
                },
                "excerpt_len": {"type": "integer", "default": 400},
                "encoding": {"type": "string", "default": "utf-8"},
            },
            required=["path", "output_dir"],
        ),
        _fn(
            "library_doc_project_init",
            "Create **`output/library/<doc_slug>/`** with standard subdirs (**apis**, **diagrams**, **outlines**, **markdown**, **chapters**, **resources**) "
            "and **`doc_project.json`** (tree + artifacts + resources manifest). Writes **`INDEX.md`** template. Paths under **`<workspace>/aicd/`.** "
            "Use before large doc authoring; pair with **library_doc_snapshot** before restructure.",
            {
                "doc_slug": {"type": "string", "description": "Same rules as topic_slug (lowercase slug)"},
                "title": {"type": "string", "description": "Human title; defaults to doc_slug"},
                "overwrite_manifest": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, replace existing doc_project.json",
                },
            },
            required=["doc_slug"],
        ),
        _fn(
            "library_doc_project_get",
            "Read **`doc_project.json`** for a library slug plus structure validation summary.",
            {"doc_slug": {"type": "string"}},
            required=["doc_slug"],
        ),
        _fn(
            "library_doc_project_patch",
            "Merge fields into **`doc_project.json`** (**title**, **assembly**, **style_profile_path**, **tree**, **artifacts** dict merge, **resources** append). "
            "Set **replace_resources** true to replace the resources array. Validates before write.",
            {
                "doc_slug": {"type": "string"},
                "updates": {
                    "type": "object",
                    "description": "Partial manifest; tree replaces entirely when present",
                },
                "replace_resources": {"type": "boolean", "default": False},
            },
            required=["doc_slug", "updates"],
        ),
        _fn(
            "library_doc_snapshot",
            "Copy **`output/library/<doc_slug>/`** to **`_snapshots/YYYYMMDDThhmmssZ/`** (excludes **node_modules**, **.git**; top-level **_snapshots** not nested). "
            "Optional **subpath** (relative) copies one file or directory only.",
            {
                "doc_slug": {"type": "string"},
                "subpath": {
                    "type": "string",
                    "description": "Optional relative path inside library (file or dir)",
                },
            },
            required=["doc_slug"],
        ),
        _fn(
            "doc_manifest_validate",
            "Validate **doc_project.json** schema, unique **node_id**s, path safety; optional path existence (**check_paths_exist**).",
            {
                "doc_slug": {"type": "string"},
                "check_paths_exist": {"type": "boolean", "default": True},
            },
            required=["doc_slug"],
        ),
        _fn(
            "doc_manifest_coverage_report",
            "Compare manifest **tree** leaves vs **content_paths**; list markdown files under **markdown/** not referenced; heading counts for orphans.",
            {
                "doc_slug": {"type": "string"},
                "scan_markdown_dir": {"type": "boolean", "default": True},
            },
            required=["doc_slug"],
        ),
        _fn(
            "library_resources_scan",
            "Scan **resources/**, **diagrams/**, and local **`![](...)`** links from **markdown/** and **chapters/**; write **`resources/index.json`**. "
            "Skips **_snapshots** unless **include_snapshots** is true.",
            {
                "doc_slug": {"type": "string"},
                "include_snapshots": {"type": "boolean", "default": False},
            },
            required=["doc_slug"],
        ),
        _fn(
            "doc_text_health_check",
            "UTF-8 decode + heuristic mojibake (**replacement** ratio) on workspace text files; pass **paths** array.",
            {
                "paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Files to check (policy-resolved)",
                },
            },
            required=["paths"],
        ),
        _fn(
            "doc_project_export",
            "Export one **library-relative** Markdown to **`output/deliverables/<topic_slug>/`**: **formats** may include **markdown** (copy with footer), **pdf** (PyMuPDF Story), **pdf_pandoc** (needs pandoc), **html**, **docx** (Pandoc → Word; needs pandoc). "
            "Optional **reference_docx_rel** (path under the same library) sets Pandoc **--reference-doc** for **docx** / **pdf_pandoc** styling. "
            "Appends **AICD** attribution + **UTC** timestamp. Writes **MANIFEST_<stamp>.md** listing outputs.",
            {
                "doc_slug": {"type": "string"},
                "topic_slug": {
                    "type": "string",
                    "description": "Deliverables folder segment (same rules as task topic_slug); default can match doc_slug",
                },
                "source_markdown_rel": {
                    "type": "string",
                    "description": "Path under output/library/<doc_slug>/ e.g. markdown/roll.md",
                },
                "formats": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "markdown | pdf | pdf_pandoc | html | docx",
                },
                "pandoc_extra_args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional Pandoc args (pdf_pandoc and docx)",
                },
                "reference_docx_rel": {
                    "type": "string",
                    "description": "Optional library-relative .docx for --reference-doc (docx export and pdf_pandoc)",
                },
            },
            required=["doc_slug", "topic_slug", "source_markdown_rel", "formats"],
        ),
        _fn(
            "merge_markdown_files",
            "Concatenate multiple **library-relative** Markdown/text files **in order** into one file under **`output/library/<doc_slug>/`** (e.g. **`markdown/roll_merged.md`**). "
            "Use after **ASSEMBLY.md** or a fixed chapter list; then **`doc_project_export`** with **`source_markdown_rel`** pointing at the merged file. "
            "Optional **annotate_sources** adds HTML comments before each part. **separator** defaults to blank lines.",
            {
                "doc_slug": {"type": "string"},
                "input_paths_rel": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ordered paths under the library e.g. [\"markdown/ch01.md\",\"markdown/ch02.md\"]",
                },
                "output_markdown_rel": {
                    "type": "string",
                    "description": "Destination .md path under the library",
                },
                "separator": {
                    "type": "string",
                    "description": "Inserted between files (default two newlines)",
                },
                "annotate_sources": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, prefix each chunk with <!-- merged-from: rel -->",
                },
            },
            required=["doc_slug", "input_paths_rel", "output_markdown_rel"],
        ),
        _fn(
            "doc_revision_diff_summary",
            "Heuristic compare two text files (often two **.md** revisions): length, line count, **SequenceMatcher** similarity, optional heading_count delta. "
            "Use before declaring 'no improvement' in revision loops.",
            {
                "path_before": {"type": "string"},
                "path_after": {"type": "string"},
            },
            required=["path_before", "path_after"],
        ),
        _fn(
            "library_doc_batch_quality_pass",
            "One-shot QA: **doc_manifest_validate** + **doc_manifest_coverage_report** + optional **library_resources_scan** + **doc_text_health_check** on all manifest **content_paths**.",
            {
                "doc_slug": {"type": "string"},
                "check_paths_exist": {"type": "boolean", "default": True},
                "run_text_health": {"type": "boolean", "default": True},
                "scan_resources": {"type": "boolean", "default": True},
            },
            required=["doc_slug"],
        ),
        _fn(
            "library_doc_node_resolve",
            "Look up **tree** node by **node_id**: **title**, **status**, **content_paths** with existence. For AI planning without pasting the full manifest.",
            {
                "doc_slug": {"type": "string"},
                "node_id": {"type": "string"},
            },
            required=["doc_slug", "node_id"],
        ),
        _fn(
            "vision_analyze_image",
            "Multimodal: send local image(s) to the vision-capable model — explain charts/diagrams, transcribe text in screenshots, "
            "describe slides. **Context**: providers typically charge on the order of **~2k–8k tokens per image** per call; prefer fewer images per round when the session is long. "
            "Images are **downscaled** for the API; the tool returns **per_image** with **source_*** (file pixels) and **sent_*** (pixels actually shown to the model). "
            "**For Word**: always **`docx_compose` `image`** using the **original file path** — never a re-encoded thumbnail. "
            "If you crop using bbox coordinates the model gives for the **shrunk** view, call **`image_crop`** on the **original** path with **bbox_reference_width**/**height** = that image's **sent_width**/**sent_height**. "
            "After **doc_extract**, use files under **images_<stem>/**. Optional **save_report** (default true). Config **llm.visionModel** overrides **model** for this tool only.",
            {
                "prompt": {
                    "type": "string",
                    "description": "What you need: e.g. list axes/series and trends; extract all visible text in Chinese; describe the architecture diagram. "
                    "To **replicate figure style** for new diagrams/Word exports, ask for: palette (hex), line thickness, node shape, font style, arrow/connector style, background—then map to Mermaid **theme**/**theme_variables** or Draw.io **fill_color**/**style**.",
                },
                "image_path": {
                    "type": "string",
                    "description": "Single image path (png/jpg/jpeg/webp/gif)",
                },
                "image_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Additional paths when analyzing multiple figures in one request",
                },
                "save_report": {
                    "type": "boolean",
                    "default": True,
                    "description": "Write analysis to ai_tmp_dir as .md for follow-up tool rounds",
                },
                "report_name": {
                    "type": "string",
                    "description": "Optional safe filename stem for the report (default: first image stem + timestamp)",
                },
            },
            required=["prompt"],
        ),
        _fn(
            "browser_cdp_navigate",
            "Headless browser: navigate to URL (Playwright Chromium CDP stack). "
            "Default uses **bundled Chromium** (`python -m playwright install chromium`). "
            "Optional **browser_channel** `chrome` / `msedge` / beta/canary variants uses the **installed** browser on Windows/macOS/Linux. "
            "**executable_path** overrides channel with an explicit browser binary.",
            {
                "url": {"type": "string"},
                "wait_until": {"type": "string", "default": "load"},
                "headless": {
                    "type": "boolean",
                    "default": True,
                    "description": "Set false to run with a visible window (debug; needs display on Linux)",
                },
                "browser_channel": {
                    "type": "string",
                    "description": "e.g. chrome, msedge, chrome-beta; omit for Playwright Chromium",
                },
                "executable_path": {
                    "type": "string",
                    "description": "Full path to browser executable; wins over browser_channel",
                },
            },
            required=["url"],
        ),
        _fn(
            "browser_cdp_automation",
            "One browser session for **Web UI** (Playwright). **steps**: ordered objects with **op** (goto, click, …). "
            "Default is a **fresh** context (often flagged by search/social sites). For **fewer bot checks**, prefer: "
            "(1) **headless=false** + **browser_channel** `chrome`/`msedge` (real browser binary); "
            "(2) **cdp_endpoint** `http://127.0.0.1:9222` after the user starts Chrome/Edge with `--remote-debugging-port=9222` "
            "(reuses cookies/logins — **disconnect only**, user's browser keeps running); "
            "(3) **user_data_dir** for `launch_persistent_context` (dedicated folder under workspace/AICD_HOME per path_policy). "
            "**cdp_endpoint** and **user_data_dir** are mutually exclusive. "
            "**content_snippet** / **screenshot** then **vision_analyze_image** as needed.",
            {
                "steps": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Sequential steps, each must include op",
                },
                "timeout_ms": {"type": "integer", "default": 60000},
                "headless": {"type": "boolean", "default": True},
                "viewport": {"type": "object", "description": "Optional width/height"},
                "slow_mo_ms": {"type": "integer", "description": "Optional ms delay between actions (debug)"},
                "browser_channel": {
                    "type": "string",
                    "description": "e.g. chrome, msedge; omit for Playwright Chromium",
                },
                "executable_path": {
                    "type": "string",
                    "description": "Full path to browser executable (overrides browser_channel)",
                },
                "cdp_endpoint": {
                    "type": "string",
                    "description": "Playwright connect_over_cdp URL, e.g. http://127.0.0.1:9222 (Chrome started with --remote-debugging-port)",
                },
                "user_data_dir": {
                    "type": "string",
                    "description": "Persistent profile directory (path_policy); launch_persistent_context for saved cookies in that profile",
                },
            },
            required=["steps"],
        ),
        _fn(
            "desktop_gui_automation",
            "**Native desktop GUI** (not browser). **Windows** / **Linux X11**: **list_windows** + **focus_window** + pixel ops. "
            "**macOS**: **list_windows** / **focus_window** are **not** supported—use **screenshot**, **click**/**type_text**/**hotkey** at screen coordinates (Accessibility for Terminal/Python). "
            "Ordered **steps** with **op**. "
            "**list_windows** {optional max} → titles + **window_id** + geometry; **focus_window** {window_id or title_contains}; "
            "**screenshot** {path .png, optional region left/top/width/height}; **click** / **double_click** {x,y screen pixels}; "
            "**move**, **drag**, **scroll** {clicks}; **type_text**; **press** {key}; **hotkey** {keys: [..]}; **wait_ms**; **pixel** {x,y} RGB. "
            "Where supported, use **list_windows** then **focus_window**, then click relative to **left/top** from list. "
            "Install **`pip install aicd[desktop]`** (pyautogui + mss). Linux: **`apt install wmctrl xdotool`** for window list/focus; "
            "**Wayland** may limit input/screenshot—prefer X11 session or compositor tools. "
            "On **headless Linux** (no DISPLAY/Wayland), the tool **degrades** immediately (`ok:false`, `degraded:true`); use **browser_cdp_automation** or file paths; **`AICD_DESKTOP_GUI_FORCE=1`** only if a GUI session truly exists. "
            "Pair **screenshot** with **vision_analyze_image** for visual verification.",
            {
                "steps": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Sequential desktop actions, each with op",
                },
            },
            required=["steps"],
        ),
        _fn(
            "desktop_open_url",
            "Open **http(s)** or **file:** URLs in the **system default browser** (user desktop). "
            "When the user asks to open a recommended page, search result, or local **HTML/Markdown preview** via browser, call this—"
            "**usually one call** when the path or URL is already in the thread (do not spawn **task_ai** or **browser_cdp_*** for a static local preview unless scripted UI is required). "
            "**file:** URLs must point to paths under the workspace / allowed_roots (same policy as fs_*). "
            "On **headless servers** or **SSH without DISPLAY**, this often returns **opened: false** without crashing—tell the user the URL/path.",
            {
                "url": {
                    "type": "string",
                    "description": "http(s)://... or file:///... (file paths subject to path policy)",
                },
            },
            required=["url"],
        ),
        _fn(
            "desktop_reveal_path",
            "Reveal a **file or folder** in the **OS file manager** (Explorer / Finder / xdg-open / nautilus --select when available). "
            "Use after generating deliverables so the user can see the artifact location. "
            "On **headless** environments this may fail gracefully—still report the absolute path in chat.",
            {
                "path": {
                    "type": "string",
                    "description": "File or directory (relative to AI workspace or absolute under allowed_roots)",
                },
            },
            required=["path"],
        ),
        _fn(
            "diagram_mermaid",
            "Return a Mermaid diagram text block for documentation",
            {
                "title": {"type": "string"},
                "mermaid_body": {"type": "string"},
            },
            required=["mermaid_body"],
        ),
        _fn(
            "diagram_mermaid_png",
            "Render **Mermaid** source to a **PNG** with headless Chromium (Playwright) and bundled **mermaid.min.js**. "
            "Use for **Word/PDF pipelines**: then **`docx_compose`** with an **image** block. "
            "Prefer **`viz_spec_validate`** (mermaid_body) first. "
            "To **match a reference document's figure style**, analyze 1–2 sample figures with **`vision_analyze_image`** "
            "(ask for colors, line weight, shapes, fonts, arrow style), then pass **`theme`** (e.g. default, neutral, dark, forest, base) "
            "and optional **`theme_variables`** (Mermaid `themeVariables`: primaryColor, primaryTextColor, lineColor, etc.). "
            "Uses **bundled** `res/mermaid.min.js` + Playwright Chromium — **no** diagrams.net; needs `python -m playwright install chromium` if browsers missing.",
            {
                "mermaid_body": {"type": "string"},
                "output_png_path": {"type": "string"},
                "theme": {
                    "type": "string",
                    "default": "neutral",
                    "description": "Mermaid built-in theme name",
                },
                "theme_variables": {
                    "type": "object",
                    "description": "Optional Mermaid themeVariables object (hex colors etc.)",
                },
                "scale": {
                    "type": "number",
                    "default": 3,
                    "description": "Playwright device pixel ratio 1–6 for sharper PNG (higher = larger file)",
                },
            },
            required=["mermaid_body", "output_png_path"],
        ),
        _fn(
            "diagram_graph_json",
            "Build a JSON graph structure (nodes with id/label, edges with source/target)",
            {
                "nodes": {
                    "type": "array",
                    "items": {"type": "object"},
                },
                "edges": {
                    "type": "array",
                    "items": {"type": "object"},
                },
            },
            required=["nodes", "edges"],
        ),
        _fn(
            "diagram_drawio_write",
            "Write a diagrams.net / Draw.io **.drawio** file (XML mxfile). "
            "**nodes**: {id, label, optional x,y,width,height,style,fill_color}. "
            "**edges**: {source,target} or {from,to}, optional label. "
            "Auto-layout grid if x/y omitted. Open in app.diagrams.net or VS Code Draw.io extension.",
            {
                "path": {"type": "string"},
                "nodes": {"type": "array", "items": {"type": "object"}},
                "edges": {"type": "array", "items": {"type": "object"}},
                "page_name": {"type": "string"},
                "diagram_id": {"type": "string"},
                "layout_cols": {"type": "integer", "default": 4},
            },
            required=["path", "nodes", "edges"],
        ),
        _fn(
            "diagram_drawio_summarize",
            "Parse an existing .drawio file and return vertex/edge previews (ids, labels, geometry) for editing.",
            {
                "path": {"type": "string"},
                "max_vertices": {"type": "integer", "default": 200},
                "max_edges": {"type": "integer", "default": 400},
            },
            required=["path"],
        ),
        _fn(
            "visio_flowchart_write",
            "Write a Microsoft Visio **.vsdx** flowchart from **nodes** and **edges** (requires PyPI package **`vsdx`**: **`pip install aicd[visio]`** or **`pip install \"vsdx>=0.6.1\"`**). "
            "**Never** `pip install python-visio` — that name is **not** a valid distribution for this tool. "
            "**Do not** use **`script_run`** to manually build `.vsdx` ZIP/XML (easy `FileNotFoundError` on `visio/_rels`); use **this tool** only. "
            "When the user **explicitly asks for Visio** (not only Mermaid/Draw.io), you **must** call this tool and **keep** the returned **.vsdx** under **`output/library/.../diagrams/`** or **deliverables**. "
            "**nodes**: `id`, `label`, optional `shape` or `kind` — `process` (rectangle), `decision` (rectangle with ◇ prefix), `terminator` (ellipse). Optional `x`,`y` in **inches** (Visio Pin); omit for grid (`layout_cols`). "
            "**edges**: `source`/`target` or `from`/`to`, optional `label` on connector. "
            "For **raster flowcharts**: first **`vision_analyze_image`** with a prompt that demands **JSON `nodes`/`edges`** (ids + labels + connectivity), then call this tool. "
            "For **text or mind-map style** descriptions: infer the same graph and write here — do **not** substitute PNG-only or `.drawio` when the user required **Visio**.",
            {
                "path": {"type": "string"},
                "nodes": {"type": "array", "items": {"type": "object"}},
                "edges": {"type": "array", "items": {"type": "object"}},
                "layout_cols": {"type": "integer", "default": 4},
            },
            required=["path", "nodes", "edges"],
        ),
        _fn(
            "visio_vsdx_summarize",
            "Read an existing **.vsdx** (first page): shape ids, visible text, x/y in inches, connector endpoints preview. "
            "Use before editing or to cross-check a diagram the user uploaded. Requires **`aicd[visio]`**.",
            {
                "path": {"type": "string"},
                "max_shapes": {"type": "integer", "default": 400},
            },
            required=["path"],
        ),
        *_diagram_drawio_export_png_tool_entries(),
        _fn(
            "image_crop",
            "Crop a raster image (PNG/JPEG/WebP/GIF) to a pixel rectangle; saves **PNG**. "
            "Coordinates are in **input_path** pixel space unless **bbox_reference_width**/**height** are set (both required together): "
            "then **left/top/width/height** are interpreted in that reference size (e.g. **vision_analyze_image** **sent_width**×**sent_height**) and mapped to the full image — use the **original** high-res file as **input_path**. "
            "For **`diagram_drawio_export_png`**, raise **scale** (up to 8) first for sharper source PNGs before cropping.",
            {
                "input_path": {"type": "string"},
                "output_path": {"type": "string"},
                "left": {"type": "integer"},
                "top": {"type": "integer"},
                "width": {"type": "integer"},
                "height": {"type": "integer"},
                "bbox_reference_width": {
                    "type": "integer",
                    "description": "Width of coordinate system for left/top/width/height (e.g. vision sent_width)",
                },
                "bbox_reference_height": {
                    "type": "integer",
                    "description": "Height of coordinate system (e.g. vision sent_height); must pair with bbox_reference_width",
                },
            },
            required=["input_path", "output_path", "left", "top", "width", "height"],
        ),
        _fn(
            "image_transform",
            "Unified **raster image** pipeline (Pillow + optional OpenCV): scale/crop/rotate/flip, brightness/contrast/saturation/sharpness, "
            "grayscale/invert/posterize/autocontrast/equalize, **paste_overlay** / **blend** / **concat_***, geometric **draw_*** and **draw_text**, "
            "**solid_canvas** (new blank RGBA), **tint** / **chroma_key** (HSV range → alpha), and OpenCV **edge_canny**, **gaussian_blur**, **bilateral**, "
            "**morphology**, **threshold** (binary/otsu/adaptive), **laplacian**, **sobel**, **grabcut_rect** (rectangular foreground cutout with alpha). "
            "Use for diagram post-processing, simple effect plates, and expressive static figures before **`docx_compose`**, Markdown, or exports. "
            "**operation** `help` returns `operations_help` + `known_operations` (no file IO). "
            "**solid_canvas** may omit **input_path** (output parent must be writable under workspace). "
            "OpenCV ops need `pip install aicd[opencv]` or `opencv-python-headless`. "
            "Params keys vary by operation (e.g. resize: width/height/mode; draw_rectangle: xyxy, outline, fill, width).",
            {
                "operation": {
                    "type": "string",
                    "description": "help | resize | crop | rotate | flip | brightness | contrast | saturation | sharpness | grayscale | invert | "
                    "posterize | autocontrast | equalize | paste_overlay | blend | concat_horizontal | concat_vertical | draw_rectangle | draw_ellipse | "
                    "draw_line | draw_polygon | draw_text | solid_canvas | chroma_key | tint | edge_canny | gaussian_blur | bilateral | morphology | "
                    "threshold | laplacian | sobel | grabcut_rect",
                },
                "input_path": {
                    "type": "string",
                    "description": "Source image path (optional for solid_canvas)",
                },
                "output_path": {"type": "string", "description": "Output .png or .jpg/.jpeg"},
                "params": {
                    "type": "object",
                    "description": "Operation-specific parameters; use operation=help to list shapes.",
                },
            },
            required=["operation"],
        ),
        _fn(
            "docx_compose",
            "Build or append a **Microsoft Word .docx** from structured blocks: **heading**, **paragraph**, **table**, **page_break**, **image**, **toc** (table of contents field). "
            "Optional **template_path** (**.docx** / **.dotx**): clone styles/page setup; **ignored** when **append** opens an existing output file. "
            "By default, **`\\n` / CRLF** in text become **real Word paragraphs** (Enter)—not **Shift+Enter** soft breaks (↓). "
            "Set block **`soft_line_breaks`: true** only when you intentionally need **w:br** inside one paragraph. "
            "For **Chinese body text (宋体)** and **black color**, set **default_east_asia_font** to **宋体** and **default_color_hex** to **000000** — "
            "the tool sets **w:eastAsia** on runs (reliable); avoid fragile **`script_run`** + `run.font` mistakes. "
            "**table**: **rows** = rectangular string matrix; optional **header_row**, **table_style** (default Table Grid), **caption**. "
            "**image** block: **path** must be an **existing** local **.png/.jpg/…** (from **`diagram_mermaid_png`**, **`diagram_drawio_export_png`**, or **`viz_html_to_png`** after **`viz_export_html`**). Draw.io **.drawio** / raw **.html** are **not** valid — use **`viz_html_to_png`** for chart HTML (**HTML+`res/`** stay on disk). "
            "Typical flow: write **.drawio** → **diagram_drawio_export_png** (ok) → **docx_compose** with **image** path; or **diagram_mermaid_png** → **docx_compose**. "
            "Paths resolve against AI workspace when relative.",
            {
                "path": {"type": "string", "description": "Output .docx path"},
                "append": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true and file exists, append blocks to the end",
                },
                "default_east_asia_font": {
                    "type": "string",
                    "description": "e.g. 宋体 — applies w:eastAsia to headings, paragraphs, tables (recommended for CN docs)",
                },
                "default_latin_font": {
                    "type": "string",
                    "description": "Optional w:ascii / hAnsi (often Times New Roman); defaults to same as east_asia if omitted",
                },
                "default_color_hex": {
                    "type": "string",
                    "description": "6 hex digits without #, e.g. 000000 for black",
                },
                "default_body_font_pt": {
                    "type": "number",
                    "description": "Body/table cell size in pt (default 10.5 when defaults are used)",
                },
                "style_profile_path": {
                    "type": "string",
                    "description": "Optional YAML/JSON (docx_defaults + notes) merged before explicit default_* args; "
                    "explicit tool args override the file. See **style_reference_scan** / examples.",
                },
                "template_path": {
                    "type": "string",
                    "description": "Optional existing .docx or .dotx to inherit styles and body; blocks append after template content unless you clear it elsewhere.",
                },
                "update_fields_on_open": {
                    "type": "boolean",
                    "description": "Optional override: force document **update fields on open** (w:updateFields). "
                    "When omitted, defaults to **true** if any **toc** block omits **update_fields_on_open** or sets it true.",
                },
                "blocks": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "type=heading|paragraph|table|page_break|image|toc|table_of_contents. "
                    "heading/paragraph/table/image: optional soft_line_breaks (default false = Enter paragraphs; true = Shift+Enter w:br). "
                    "heading/paragraph: optional space_before_pt, space_after_pt, line_spacing (multiple 0.5–5). "
                    "heading: text, level 1–9; optional font_size_pt, bold, center, alignment. "
                    "paragraph: text; optional center, alignment, font_size_pt, bold, color_hex, east_asia_font. "
                    "table: rows, optional header_row, repeat_header_row (default follow header_row), table_alignment, allow_autofit (auto false when column_width_cm set), "
                    "header_vertical_alignment, body_vertical_alignment, cell_margin_pt, cell_space_before_pt/after_pt, cell_line_spacing, "
                    "table_style, caption, header_font_size_pt, body_font_size_pt, "
                    "header_cell_alignment, body_cell_alignment, column_width_cm, cell_styles (same shape as rows). "
                    "image: path, optional width_cm, max_height_cm, caption. "
                    "toc/table_of_contents: Word TOC field (default min_level=1 max_level=3 → \\o \"1-3\", hyperlinks/hide web page nums/outline levels match Word dialog); "
                    "optional caption, caption_heading_level, placeholder, block-level update_fields_on_open; place **before** the headings to include. "
                    "page_break: {}.",
                },
            },
            required=["path", "blocks"],
        ),
        _fn(
            "docx_export_pdf",
            "Convert an existing **.docx** to **.pdf** (e.g. after **`docx_compose`**). "
            "**Default engine order**: LibreOffice **`soffice`** / **`libreoffice`** on PATH (or **`AICD_SOFFICE`** / **`SOFFICE_PATH`** to the executable), "
            "then on **Windows/macOS** optional **`docx2pdf`** (**`pip install aicd[pdf]`**) if **Microsoft Word** is installed. "
            "**prefer**: **`libreoffice`** | **`docx2pdf`** to force one backend. "
            "Omit **output_pdf_path** to write **`<same_stem>.pdf`** next to the .docx. "
            "When **ok** is **false**, the result includes **`install_suggestions`** (with optional **`shell_command`**) and **`next_step_for_agent`**: "
            "**ask the user** whether they want to install before running any command; use **`run_command`** only after explicit consent—do not install silently.",
            {
                "docx_path": {"type": "string", "description": "Source .docx (absolute or relative to AI workspace)"},
                "output_pdf_path": {
                    "type": "string",
                    "description": "Destination .pdf; default: same directory and stem as the .docx",
                },
                "prefer": {
                    "type": "string",
                    "description": "Optional: libreoffice | docx2pdf",
                },
            },
            required=["docx_path"],
        ),
        _fn(
            "markdown_to_pdf",
            "Convert **Markdown** to **.pdf**. "
            "**Default engine `pymupdf`**: MD→HTML (Python **markdown** + tables/fenced_code) then **PyMuPDF Story** layout — **no Pandoc/LaTeX**; "
            "**Images**: `![](path)` must be a **raster** (e.g. **`.png` / `.jpg`**) on disk; **not** `.html` chart pages. "
            "Raster layout: **width-first** to the text column, **max height ≈ one page body** (then scale down); tall or page-filling figures may get **page-break-before** so they are not shrunk to a sliver at the end of a page. "
            "If **`ok`**, check **`image_missing_srcs`** / **`image_markdown_refs_missing`** when figures disappear—usually wrong **`archive_path`** or path typos. "
            "Set **`archive_path`** to the directory PyMuPDF uses to resolve **relative** `src` (defaults: parent of **markdown_path**; "
            "if only **markdown_text**, default is **workspace cwd**, not PDF output folder—override when images are anchored elsewhere). "
            "Optional **`user_css`** overrides/extends built-in typography. **`paper`**: a4|letter|a3; **`margin_pt`**. "
            "**Engine `pandoc`**: requires **`pandoc`** on PATH; pass **markdown_path** or inline **markdown_text** (saved under **ai_tmp** automatically); "
            "optional **`pandoc_extra_args`** e.g. `[\"--pdf-engine=xelatex\",\"-V\",\"mainfont=Microsoft YaHei\"]` for CJK. "
            "**Word→PDF** for styled chapters: **`docx_compose`** (headings/tables/images) then **`docx_export_pdf`**. "
            "**Complex native PDF**: **`pdf_compose`** (**ReportLab**, `pip install aicd[pdf]`) with structured **blocks**. "
            "**PyMuPDF Story** tables: built-in CSS avoids black bars on table headers; **`<br>` inside table cells** from **nl2br** is stripped before layout to reduce broken grids; complex grid specs may still need **`docx`→PDF** or **`engine=pandoc`**. "
            "Optional **`source_markdown_snapshot_path`**: write a copy of the source **.md** used for this PDF (canonical content for later format-only tweaks).",
            {
                "output_pdf_path": {"type": "string"},
                "markdown_path": {
                    "type": "string",
                    "description": "Optional .md/.txt path; omit if using markdown_text",
                },
                "markdown_text": {
                    "type": "string",
                    "description": "Raw markdown when no file path",
                },
                "engine": {
                    "type": "string",
                    "default": "pymupdf",
                    "description": "pymupdf (built-in) | pandoc",
                },
                "archive_path": {
                    "type": "string",
                    "description": "Directory for resolving relative image paths in pymupdf engine",
                },
                "user_css": {"type": "string", "description": "Extra CSS merged with built-in Story stylesheet"},
                "paper": {"type": "string", "default": "a4"},
                "margin_pt": {"type": "number", "default": 36},
                "pandoc_extra_args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Extra pandoc CLI args when engine=pandoc",
                },
                "source_markdown_snapshot_path": {
                    "type": "string",
                    "description": "Optional path to save the exact Markdown used (same dir as PDF e.g. stem_source.md); keep as canonical source when adjusting CSS/engine later",
                },
            },
            required=["output_pdf_path"],
        ),
        _fn(
            "markdown_to_docx",
            "Convert **Markdown** to native **.docx** with **Pandoc** (must be on PATH). "
            "Preserves **headings, lists, tables, emphasis** better than pasting Markdown into **`docx_compose`** paragraphs. "
            "Optional **`reference_docx`**: Pandoc **`--reference-doc`** — use a Word template whose styles (including a table style named **Table**) match your org branding. "
            "**Images**: `![](path)` resolved relative to the **markdown file directory** (same as Pandoc **`cwd`**). "
            "For pixel-perfect layout or programmatic blocks, still use **`docx_compose`**.",
            {
                "output_docx_path": {"type": "string"},
                "markdown_path": {
                    "type": "string",
                    "description": "Optional .md/.txt path; omit if using markdown_text",
                },
                "markdown_text": {
                    "type": "string",
                    "description": "Raw Markdown when no file path (written under ai_tmp for pandoc)",
                },
                "reference_docx": {
                    "type": "string",
                    "description": "Optional Pandoc reference .docx (--reference-doc)",
                },
                "pandoc_extra_args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Extra pandoc args e.g. [\"--from=gfm\"]",
                },
            },
            required=["output_docx_path"],
        ),
        _fn(
            "pdf_compose",
            "Build a **.pdf** from structured **blocks** using **ReportLab** (install **`pip install aicd[pdf]`**). "
            "Use when you need precise layout, repeated sections, or logic beyond MD→PDF — or combine with **`script_run`** for custom Python that calls ReportLab. "
            "**blocks** `type`: **heading** (text, level 1–6), **paragraph** (text; optional font_size_pt, alignment left|center|right|justify, space_after_pt), "
            "**image** (path; optional width_cm, max_height_cm for tall figures, caption, hAlign), **table** (rows[][], optional header_row bool, col_widths fractional widths), **spacer** (height_pt), **page_break**. "
            "Optional **title** (cover line). **cjk_font_path**: TTF/OTF for Chinese/Japanese/Korean (otherwise Helvetica may not render CJK). "
            "**page_size** a4|letter|a3; **margin_cm**.",
            {
                "path": {"type": "string", "description": "Output .pdf path"},
                "title": {"type": "string"},
                "blocks": {"type": "array", "items": {"type": "object"}},
                "page_size": {"type": "string", "default": "a4"},
                "margin_cm": {"type": "number", "default": 2.0},
                "cjk_font_path": {
                    "type": "string",
                    "description": "Optional path to a TTF/OTF with CJK glyphs",
                },
            },
            required=["path", "blocks"],
        ),
        _fn(
            "style_reference_scan",
            "Scan a **file or directory** of user style references: **.md/.txt/.css/.html**, **.yaml/.json** style profiles, **images** (path + size). "
            "Returns **style_digest** (bounded text) for the model to follow when authoring content, plus **entries** metadata. "
            "Does not call vision APIs. Pair with **docx_compose** (**style_profile_path**) or **pptx_inspect_template** + **pptx_compose**.",
            {
                "path": {
                    "type": "string",
                    "description": "File or directory under the AI workspace (or absolute if policy allows)",
                },
                "max_files": {
                    "type": "integer",
                    "default": 48,
                    "description": "Cap scanned files (depth-limited walk for directories)",
                },
            },
            required=["path"],
        ),
        _fn(
            "xlsx_write_workbook",
            "Write or append an **.xlsx** workbook (**openpyxl**). Each sheet: **name**, optional **headers** row, **rows** (array of arrays). "
            "Optional **template_path** (**.xlsx** / **.xlsm** / **.xltx** / **.xltm**) seeds the workbook when **not** appending to an existing output file; "
            "sheets not listed in **sheets** are kept (e.g. cover page). **append** + existing output ignores **template_path**. "
            "Cell values may be literals; strings starting with **=** or objects **{\"formula\":\"=…\"}** write Excel formulas (not evaluated server-side). "
            "For **text** cells with line breaks, use **CRLF (`\\r\\n`)**; bare **`\\n`** is normalized on write. "
            "If **append** is true and the file exists, sheets are replaced by **name** when present or created.",
            {
                "path": {"type": "string", "description": "Output .xlsx path"},
                "append": {"type": "boolean", "default": False},
                "template_path": {
                    "type": "string",
                    "description": "Optional workbook to load as starting point when creating the output file",
                },
                "sheets": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Objects with name, optional headers[], rows[][]",
                },
            },
            required=["path", "sheets"],
        ),
        _fn(
            "xlsx_write_xlsxwriter",
            "Write a **new** **.xlsx** with **XlsxWriter** (optional **`pip install aicd[xlsxwriter]`**). "
            "String cells (**headers**, **rows**, **merge_ranges.text**): use **CRLF (`\\r\\n`)** for in-cell line breaks; **`\\n`** is normalized on write. "
            "**Does not replace** **openpyxl**: use **`xlsx_read_workbook`** / **`xlsx_patch_workbook`** / **`xlsx_write_workbook`** for read, patch, and simple writes. "
            "Use **this tool** when the user asks for **richer formatting**: **column_widths**, **freeze_panes** `{row,col}` (0-based), **header_format** `{bold, font_size, font_color, bg_color, border}`, "
            "**merge_ranges** `[{first_row, first_col, last_row, last_col, text?}]`, or faster bulk layout. "
            "Each sheet: **name**, optional **headers**, **rows** (same cell formula conventions as **xlsx_write_workbook**). "
            "**Always creates a fresh workbook** (no **append**).",
            {
                "path": {"type": "string", "description": "Output .xlsx path"},
                "sheets": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "name, rows, optional headers, column_widths, freeze_panes, header_format, merge_ranges",
                },
            },
            required=["path", "sheets"],
        ),
        _fn(
            "xlsx_read_workbook",
            "Read an **.xlsx** into JSON grids (**multi-sheet**). **value_mode**: **cached** (Excel-saved computed values via data_only), **raw** (formula strings), "
            "**both** (merge formula + cached). openpyxl does **not** calculate formulas—**cached** may be null if the workbook was never recalculated in Excel. "
            "Caps: **max_rows_per_sheet**, **max_cols_per_sheet**, **row_start** (1-based).",
            {
                "path": {"type": "string"},
                "sheet_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Subset of sheets; omit for all (up to internal cap)",
                },
                "value_mode": {
                    "type": "string",
                    "enum": ["cached", "raw", "both"],
                    "default": "cached",
                },
                "max_rows_per_sheet": {"type": "integer", "default": 2000},
                "max_cols_per_sheet": {"type": "integer", "default": 128},
                "row_start": {"type": "integer", "default": 1},
            },
            required=["path"],
        ),
        _fn(
            "xlsx_patch_workbook",
            "Edit an existing **.xlsx** in place: **cells**[] items with **sheet**, **row**, **col** (1-based), **value** (literal, **=formula** string, or **{\"formula\"}/{\"value\"}**). "
            "Optional **create_sheets** to add missing sheet names.",
            {
                "path": {"type": "string"},
                "create_sheets": {"type": "boolean", "default": False},
                "cells": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Each: sheet, row, col, value",
                },
            },
            required=["path", "cells"],
        ),
        _fn(
            "pptx_inspect_template",
            "Inspect a **.pptx** template: slide **layouts** with **placeholders** (idx/type) for **layout_index**, plus **shape_kind_examples** and notes on animations for **pptx_compose**.",
            {"path": {"type": "string", "description": "Existing .pptx (often a corporate template)"}},
            required=["path"],
        ),
        _fn(
            "pptx_compose",
            "Create a **.pptx** from a **blank** deck or a **template_path** (**.pptx** master/theme—use **pptx_inspect_template** first). Each slide: **layout_index** (from **pptx_inspect_template**), "
            "**title**, **bullets** (string list), optional **image_path** or **images**[] (raster **.png/.jpg/…** only; each item **image_path** + **image_*_in**; **image_height_in** optional). "
            "Use **CRLF (`\\r\\n`)** for line breaks inside **title**, **bullets**, **text_boxes**, **table** cells, and **speaker_notes**; bare **`\\n`** is normalized on write. "
            "**shapes**[]: **kind** = rectangle|rounded_rectangle|oval **or** any python-pptx **MSO_SHAPE** name (see **pptx_inspect_template** `shape_kind_examples`) + box inches + optional **fill_rgb**/**line_rgb** [R,G,B]. "
            "**table**{**data**, **table_*_in**}, **chart**{**chart_type** (column/bar/line/area clustered|stacked|stacked_100, doughnut, radar, …), **categories**, **series**; **pie**/**doughnut** = one series}, **text_boxes**[] (**text** or **lines**, box inches, optional **font_pt**, **bold**), **speaker_notes**, "
            "**slide_transition**{**effect** fade|cut|push|wipe|split|cover|uncover|random_bar, **speed**, **direction** l|r|u|d, **orient** for split}. "
            "Optional **title_font_pt**, **title_bold**, **title_color_rgb** [R,G,B]; **body_font_pt**, **body_bold**, **body_color_rgb** for the **bullets** body placeholder. "
            "**Per-shape entrance animations** are **not** available via python-pptx—use **slide_transition**, **template_path** with master animations, or edit in PowerPoint. "
            "Offline HTML figures: **`viz_html_to_png`** → PNG path; **keep** **.html** + **`res/`**. "
            "Relative paths resolve against the AI workspace.",
            {
                "path": {"type": "string", "description": "Output .pptx path"},
                "template_path": {
                    "type": "string",
                    "description": "Optional source .pptx to clone layouts/theme from",
                },
                "slides": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "layout_index, title, bullets; optional title_font_pt/bold/title_color_rgb, body_font_pt/bold/body_color_rgb; "
                    "image_*, images[], shapes[], table, chart, text_boxes, speaker_notes, slide_transition",
                },
            },
            required=["path", "slides"],
        ),
        _fn(
            "pptx_from_html_deck",
            "Recommended **polished PPTX** path: author one **offline .html per slide** (CSS for typography—think slide aspect ratio), ordered list in **slides**; "
            "tool rasterizes each page with fixed **viewport** (default **1280×720**, **full_page false**) via Playwright, then **full-bleed** pastes PNGs into **pptx_compose**. "
            "**Preserves sources**: every **.html** (and sibling **res/**) stays on disk; writes **`pptx_deck_source.json`** under **deck_root** listing html→png order so the user can **reorder, insert pages, restyle, re-run**. "
            "**slides**[]: string path **or** **{html_path, speaker_notes?}**. **deck_root**: directory for manifest + **`_pptx_export/png/`** (default: common parent of slide HTML paths). "
            "Optional **template_path** (.pptx); **layout_index** or auto-pick low-placeholder **blankish** layout. "
            "For **native placeholders** (title/bullets/charts) without pixel slides, still use **pptx_inspect_template** + **pptx_compose** alone.",
            {
                "path": {"type": "string", "description": "Output .pptx path"},
                "slides": {
                    "type": "array",
                    "description": "Each: html path string, or object {html_path, speaker_notes?}",
                    "items": {},
                },
                "deck_root": {
                    "type": "string",
                    "description": "Root for pptx_deck_source.json and _pptx_export/png/ (optional)",
                },
                "template_path": {
                    "type": "string",
                    "description": "Optional .pptx for slide size/theme; same as pptx_compose",
                },
                "layout_index": {
                    "type": "integer",
                    "description": "Optional slide layout index; omit to auto-pick minimal placeholders",
                },
                "viewport_width": {"type": "integer", "default": 1280},
                "viewport_height": {"type": "integer", "default": 720},
                "device_scale_factor": {"type": "number", "default": 2},
                "wait_after_load_ms": {"type": "integer", "default": 1200},
                "timeout_ms": {"type": "integer", "default": 120000},
                "manifest_filename": {
                    "type": "string",
                    "default": "pptx_deck_source.json",
                    "description": "Written under deck_root",
                },
                "png_subdir": {
                    "type": "string",
                    "default": "_pptx_export/png",
                    "description": "Under deck_root, regenerated PNGs",
                },
            },
            required=["path", "slides"],
        ),
        _fn(
            "code_outline_python",
            "Parse Python file and list top-level defs/classes",
            {"path": {"type": "string"}},
            required=["path"],
        ),
        _fn(
            "code_gen_tree_scan",
            "Optional **code generation tree** (symbol index tree for AI navigation—not a full AST): scan a file or directory. "
            "**Python**: precise **ast** hierarchy (module/class/function/async). **Go / JS / TS / JSX / TSX**: fast **heuristic** top-level outline "
            "(may false-positive in strings). **scan_profile**: **polyglot** (default) or **python_only**. "
            "Large repos: prefer **code_gen_tree_sync** + **code_gen_tree_query** instead of pasting all **nodes** in chat. "
            "Use when the task benefits (multi-file navigation, refactors, mapping modules); not required for tiny single-file edits.",
            {
                "path": {"type": "string", "description": "File or directory under workspace"},
                "recursive": {
                    "type": "boolean",
                    "default": True,
                    "description": "If path is a directory, include subfolders",
                },
                "max_files": {
                    "type": "integer",
                    "default": 120,
                    "description": "Max source files per scan (1–2000)",
                },
                "scan_profile": {
                    "type": "string",
                    "default": "polyglot",
                    "description": "polyglot | python_only (polyglot includes .go .js .ts .tsx .jsx .mjs .cjs)",
                },
            },
            required=["path"],
        ),
        _fn(
            "code_gen_tree_sync",
            "Build the same index as **code_gen_tree_scan** and persist. Two modes: (1) **use_versioned_store=true** (recommended): writes under "
            "`<workspace>/aicd/output/code_gen_tree/<topic_slug>/rev_XXXX/tree.json` and updates **manifest.json**; **index_revision** increments every sync—"
            "**always continue work from manifest latest** via **code_gen_tree_manifest**. (2) Legacy: set **output_json_path** when use_versioned_store=false. "
            "Re-sync after substantive code edits. Concurrent calls with the **same** **topic_slug** are **serialized** (threads + processes; **filelock** under the topic dir; timeout **AICD_CODE_GEN_TREE_LOCK_TIMEOUT_SEC**, default 600s); "
            "parallel **`task_ai`** should still **shard** scan roots / slugs or merge in a **parent** writer to avoid redundant full-repo rescans.",
            {
                "path": {"type": "string", "description": "File or directory to scan"},
                "use_versioned_store": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, use conventional layout + monotonic index_revision",
                },
                "topic_slug": {
                    "type": "string",
                    "description": "Slug for versioned store (default `default`); lowercase a-z0-9_-",
                },
                "output_json_path": {
                    "type": "string",
                    "description": "Required when use_versioned_store=false",
                },
                "recursive": {"type": "boolean", "default": True},
                "max_files": {"type": "integer", "default": 120},
                "scan_profile": {"type": "string", "default": "polyglot"},
            },
            required=["path"],
        ),
        _fn(
            "code_gen_tree_manifest",
            "Read **manifest.json** for a versioned code_gen_tree (**topic_slug**). Returns **latest_revision**, **latest_tree_path**, "
            "**scan_root**, and **absolute_tree_path** for follow-up. AI must prefer the **latest** revision unless the user pins an older one. "
            "If **attempt_repair** (default true), a broken manifest or missing **tree.json** may be rebuilt from **rev_*/tree.json** on disk (may set **manifest_issues**). "
            "Lock acquire uses **AICD_CODE_GEN_TREE_LOCK_TIMEOUT_SEC** (default 600s).",
            {
                "topic_slug": {"type": "string", "description": "Same slug passed to code_gen_tree_sync; omit or empty = default"},
                "attempt_repair": {
                    "type": "boolean",
                    "default": True,
                    "description": "Try to rebuild manifest from valid revision dirs when corrupt",
                },
            },
            required=[],
        ),
        _fn(
            "code_gen_tree_query",
            "Query a **saved** tree JSON without loading the whole artifact into chat. Source: **topic_slug** (latest from manifest) **or** **tree_json_path**. "
            "**action** stats | filter | children | subtree | regex. Use **stats** first on huge trees; **children**/**subtree** need **parent_id** (from prior query); "
            "**filter** supports qname_contains, file_contains, kinds[], source_langs[]; **regex** needs **qname_regex**. Caps **limit** (default 200).",
            {
                "action": {
                    "type": "string",
                    "description": "stats | filter | children | subtree | regex",
                },
                "topic_slug": {"type": "string"},
                "tree_json_path": {"type": "string"},
                "parent_id": {"type": "string"},
                "subtree_depth": {"type": "integer", "default": 12},
                "qname_contains": {"type": "string"},
                "file_contains": {"type": "string"},
                "kinds": {"type": "array", "items": {"type": "string"}},
                "source_langs": {"type": "array", "items": {"type": "string"}},
                "qname_regex": {"type": "string"},
                "limit": {"type": "integer", "default": 200},
                "offset": {"type": "integer", "default": 0},
                "include_docstrings": {"type": "boolean", "default": False},
                "attempt_repair": {
                    "type": "boolean",
                    "default": True,
                    "description": "When resolving topic_slug via manifest, try disk repair if manifest invalid",
                },
            },
            required=["action"],
        ),
        _fn(
            "ai_output_info",
            "Get AI output root and tmp paths (scratch/intermediate); workspace cwd is separate",
            {},
            required=[],
        ),
        _fn(
            "ai_ensure_layout",
            "Create AI output directory and tmp subdirectory if missing (first-use safe)",
            {},
            required=[],
        ),
        _fn(
            "ai_workspace_set",
            "Set or query the **main** AI workspace (canonical cwd for fs_* relative paths and default run_command cwd). "
            "When the user asks to switch the project/source directory from chat, you **must call this tool** — "
            "shell `cd` does **not** change Aicd's workspace. Equivalent to TUI **`/work <path>`** or **`/work new`** (new empty dir). "
            "**create_new**: JSON **true** to create **`workspace_YYYYMMDDHHMMSS`** under **AICD_HOME/workspaces** and switch to it "
            "(omit **path**). **path**: absolute or relative to **current** workspace; omit and **create_new** false to query only.",
            {
                "path": {"type": "string"},
                "create_new": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, create a new stamped workspace under HOME/workspaces and switch (ignores path)",
                },
            },
            required=[],
        ),
        _fn(
            "runtime_env_refresh",
            "Re-scan OS/terminal/Python/PATH and rewrite AICD_HOME/data/runtime_env.yaml (+ env_capabilities_summary). "
            "Call after the user installs CLI tools **or** after you run **`python -m pip install …`** (e.g. user said **帮我安装** missing **markdown** / **reportlab** / extras) so the next turn sees updated optional imports.",
            {},
            required=[],
        ),
        _fn(
            "runtime_clock",
            "Return the host **wall clock** in UTC (**utc_iso**, **unix_sec**). Use when you must anchor “now” before interpreting "
            "**task_list** / **task_result** / **task_thread_stats** fields (**reference_clock_utc**, **age_*** seconds) — do **not** invent elapsed times.",
            {},
            required=[],
        ),
        _fn(
            "agent_environment_digest",
            "Structured **self-check** for this Aicd process: OS/Python exe, **AI workspace cwd** vs probe **process.cwd**, "
            "**output/tmp** roots, **paths.aicd_home** / **paths.aicd_session_logs_dir**, **active_chat_session_id** (main-chat SQLite scope when present), "
            "**cli_highlights** (git/node/bash/playwright/tesseract/…), **python_modules_highlights**, "
            "**llm_config_surface** (proto/model + whether an API key is configured — **no secret values**), **agent_limits** (max tool rounds). "
            "Optional **refresh_first** runs the same probe as **runtime_env_refresh** before summarizing. "
            "**include_capabilities_text** appends a trimmed **`env_capabilities_summary.txt`** excerpt (avoid re-reading the full YAML in chat). "
            "Use when unsure about compilers, runtimes, or before assuming browser/OCR/desktop automation works.",
            {
                "refresh_first": {"type": "boolean", "default": False},
                "include_capabilities_text": {"type": "boolean", "default": False},
                "capabilities_max_chars": {"type": "integer", "default": 6000},
            },
            required=[],
        ),
        _fn(
            "aicd_session_logs",
            "List or tail **AICD_HOME/logs/*.log** (timestamped session diagnostics: startup, tool summaries). "
            "**op=list**: recent `.log` by mtime (**limit** 1–100); each row includes **is_this_process** vs this Aicd process. "
            "**op=read_tail**: tail window then **max_lines** — **this_process**: true reads the **current process** log file (overrides **latest**/**filename**); else **latest** or empty **filename** = newest `.log`, or **filename** = basename only. "
            "**line_contains**: case-insensitive substring filter (within tail window); **line_regex**: Python regex per line — **not both**. "
            "**max_lines** 10–2000, **max_bytes** from EOF 1k–500k. Prefer over **fs_read_file** for large logs; see **agent_environment_digest** **paths.aicd_session_logs_dir**.",
            {
                "op": {
                    "type": "string",
                    "enum": ["list", "read_tail"],
                    "description": "list | read_tail",
                },
                "limit": {"type": "integer", "default": 30},
                "this_process": {
                    "type": "boolean",
                    "default": False,
                    "description": "read_tail only: use SessionLogger path for this process",
                },
                "filename": {
                    "type": "string",
                    "description": "Basename only for read_tail; omit with latest=true or empty to use newest .log",
                },
                "latest": {"type": "boolean", "default": False},
                "line_contains": {
                    "type": "string",
                    "description": "read_tail: keep lines containing this substring (case-insensitive)",
                },
                "line_regex": {
                    "type": "string",
                    "description": "read_tail: keep lines matching this Python regex (mutually exclusive with line_contains)",
                },
                "max_lines": {"type": "integer", "default": 200},
                "max_bytes": {"type": "integer", "default": 120000},
            },
            required=["op"],
        ),
        _fn(
            "llm_profiles_list",
            "List **llmProfiles** (Name, Type/proto, ModelID, URL, context); **listing** is numbered text aligned with TUI **`/llm list`** / **`/llm use <n>`**.",
            {},
            required=[],
        ),
        _fn(
            "agent_kind_list",
            "List **agent_kind** registry rows (coder/doc/validator/maintainer + custom): key, display_name, category, **llm_profile_name**, prompt_block excerpt, builtin. "
            "**include_disabled** (default true): set false to only return enabled rows.",
            {
                "include_disabled": {
                    "type": "boolean",
                    "default": True,
                    "description": "If false, only rows with enabled=1",
                },
            },
            required=[],
        ),
        _fn(
            "agent_kind_upsert",
            "Create or update a custom **agent_kind** (builtin rows cannot change **builtin** flag). "
            "Optional **llm_profile_name** references **llmProfiles**; **prompt_block_id** links **prompt_block_upsert**.",
            {
                "key": {"type": "string"},
                "display_name": {"type": "string"},
                "category": {"type": "string"},
                "parent_key": {"type": "string"},
                "llm_profile_name": {"type": "string"},
                "prompt_block_id": {"type": "string"},
                "enabled": {"type": "boolean", "default": True},
                "meta": {"type": "object"},
            },
            required=["key"],
        ),
        _fn(
            "agent_kind_delete",
            "Disable (**soft delete**) a **non-builtin** agent_kind by key (sets enabled=0). "
            "**hard**=true performs physical DELETE (still rejects builtin rows).",
            {
                "key": {"type": "string"},
                "hard": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, DELETE row; default soft-disable",
                },
            },
            required=["key"],
        ),
        _fn(
            "work_mode_list",
            "List **work_mode** registry rows (general/dev/script/pentest/ops + custom) with optional llm_profile_name and policies. "
            "**include_disabled** (default true): set false for enabled rows only.",
            {
                "include_disabled": {
                    "type": "boolean",
                    "default": True,
                    "description": "If false, only rows with enabled=1",
                },
            },
            required=[],
        ),
        _fn(
            "work_mode_upsert",
            "Create or update a **work_mode** definition (scene policy + optional prompt_block_id, tmp_policy_json, policies_json).",
            {
                "key": {"type": "string"},
                "display_name": {"type": "string"},
                "llm_profile_name": {"type": "string"},
                "prompt_block_id": {"type": "string"},
                "tmp_policy_json": {"type": "string"},
                "policies_json": {"type": "object"},
                "enabled": {"type": "boolean", "default": True},
                "meta": {"type": "object"},
            },
            required=["key"],
        ),
        _fn(
            "work_mode_delete",
            "Soft-disable a **non-builtin** work_mode by key (enabled=0). **hard**=true DELETE row.",
            {
                "key": {"type": "string"},
                "hard": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, DELETE row; default soft-disable",
                },
            },
            required=["key"],
        ),
        _fn(
            "prompt_block_upsert",
            "Upsert a named **prompt_blocks** row (id, name, content, version) for linking from agent_kind_defs / work_mode_defs.",
            {
                "id": {"type": "string"},
                "name": {"type": "string"},
                "content": {"type": "string"},
                "version": {"type": "integer", "default": 1},
            },
            required=["id", "content"],
        ),
        _fn(
            "prompt_block_delete",
            "Delete a prompt block **id** if not referenced by defs.",
            {"id": {"type": "string"}},
            required=["id"],
        ),
        _fn(
            "llm_profile_activate",
            "Set **activeLlmProfile** by **1-based index** or **name**, persist, and hot-reload the LLM client (same as TUI **`/llm use`**).",
            {
                "name_or_index": {
                    "type": "string",
                    "description": "Profile name or 1-based index",
                },
                "persist": {"type": "boolean", "default": True},
            },
            required=["name_or_index"],
        ),
        _fn(
            "llm_profile_add",
            "Add a named LLM profile (**baseUrl**, **apiKey**, **modelId**, **type** = openai|ollama|dashscope). "
            "**supportsVision** (default true): set **false** for **text-only** endpoints so **vision_analyze_image** is rejected. "
            "**Ollama**: **`/api/show`** 探测窗宽仅在与 **contextWindowTokens** 未同时传入时使用；"
            "**手工指定的 contextWindowTokens 始终优先于探测值**（写入 profile 与 **modelContextTokens**）。"
            "其它协议：省略时默认 **contextWindowTokens**=128000。**activate** 立即选中该 profile。",
            {
                "name": {"type": "string"},
                "type": {"type": "string", "description": "proto slug: openai | ollama | dashscope"},
                "baseUrl": {"type": "string"},
                "apiKey": {"type": "string", "default": ""},
                "modelId": {"type": "string"},
                "contextWindowTokens": {
                    "type": "integer",
                    "description": "固定上下文窗（tokens）；若设置则**优先于** Ollama /api/show 等探测。省略时 Ollama 用探测或默认 128000。",
                },
                "supportsVision": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether **vision_analyze_image** (image_url multimodal) is allowed for this profile",
                },
                "visionModel": {
                    "type": "string",
                    "description": "Optional vision model id",
                },
                "activate": {"type": "boolean", "default": False},
                "persist": {"type": "boolean", "default": True},
            },
            required=["name", "type", "baseUrl", "modelId"],
        ),
        _fn(
            "llm_profile_update",
            "Patch fields on an existing profile (**target** = name or 1-based index). **patch** keys: name, type/proto, baseUrl/url, apiKey/key, modelId/model, supportsVision, visionModel, contextWindowTokens. "
            "**refreshOllamaContext=true**：仅当 patch 后 profile 的 **contextWindowTokens** 仍为未设置（null）时，"
            "才用 Ollama **`/api/show`** 回填；已有手工/表内值则不覆盖。",
            {
                "target": {"type": "string"},
                "patch": {"type": "object"},
                "refreshOllamaContext": {"type": "boolean", "default": False},
                "persist": {"type": "boolean", "default": True},
            },
            required=["target", "patch"],
        ),
        _fn(
            "llm_profile_delete",
            "Delete a profile (the last profile cannot be removed). If deleting the active profile, switches to another first.",
            {
                "name_or_index": {"type": "string"},
                "persist": {"type": "boolean", "default": True},
            },
            required=["name_or_index"],
        ),
        _fn(
            "llm_profile_duplicate",
            "Duplicate **source** profile (name or index) to **new_name**; optional **activate**.",
            {
                "source": {"type": "string"},
                "new_name": {"type": "string"},
                "activate": {"type": "boolean", "default": False},
                "persist": {"type": "boolean", "default": True},
            },
            required=["source", "new_name"],
        ),
        _fn(
            "agent_settings_update",
            "Update agent max tool rounds (main and sub-agent, each **1–500** capped), optional **idleHeartbeatSec** / **subAgentIdleHeartbeatSec** "
            "(seconds; **0** disables; positive values clamp to **5–3600** — main idle pulse vs sub-agent coordination when child tasks still run), "
            "optional **lifecycleCoalesceSec** (seconds; debounce **0–3** before TUI/GUI flushes synthetic main-chat continue after top-level task **lifecycle**), "
            "and/or LLM sampling (temperature, topP, frequencyPenalty, presencePenalty, "
            "maxOutputTokens, repetitionPenalty, extraBody for Ollama/vLLM extras). "
            "Optional **integrations**: **webFetch** (userAgent, maxResponseBytes, defaultTimeoutSec), **github** (apiBaseUrl, token, accept). "
            "Optional **llm.modelContextTokens**: map model id → context window (keys **default** / **\\*** fallback); "
            "**显式表值优先于** HTTP 探测；无表项时再用探测。 "
            "Optional **llmProfiles** (full list replace) and **activeLlmProfile** (string) for multi-endpoint configs — prefer **llm_profile_add** / **update** / **delete** / **duplicate** / **activate** / **llm_profiles_list** for CRUD. "
            "Optional **agent.contextBudgetTokens**, **chatHistoryMaxMessages**, **chatHistoryRecentFullRows** (rehydrate: keep this many **latest SQLite rows** as full messages; older rows compress to one user block — use **chat_history_get** / **chat_history_search** for detail). "
            "patch example: {\"llm\":{\"temperature\":0.3},\"agent\":{\"maxToolRounds\":32},\"integrations\":{\"github\":{\"token\":\"ghp_...\"}}}. "
            "persist=false keeps changes in-memory only for this session.",
            {
                "patch": {
                    "type": "object",
                    "description": "Optional { llm, agent, integrations }; omit to only read summary",
                },
                "persist": {"type": "boolean", "default": True},
            },
            required=[],
        ),
        _fn(
            "chat_session_info",
            "Current main-chat session id, message/summary counts (SQLite), context limits from config, "
            "**supports_vision** (from active **llmProfile**), "
            "and vision_image_token_budget_per_image (each image_url row counts this many tokens when trimming context).",
            {},
            required=[],
        ),
        _fn(
            "chat_new_session",
            "Start a new main chat session: new session_id on disk, clear in-memory context (older chat rows remain in SQLite). "
            "Use when the user asks for a fresh conversation without restarting the app.",
            {},
            required=[],
        ),
        _fn(
            "chat_history_list",
            "List recent chat rows (id, role, time, content preview, tool hints). Main session only.",
            {"limit": {"type": "integer", "default": 40}},
            required=[],
        ),
        _fn(
            "chat_history_search",
            "Search this session's SQLite chat rows by substring (default) or Python **regex** when use_regex=true. "
            "Regex mode scans only the latest **scan_limit** rows (default 2000). Returns previews; use **chat_history_get** for full text.",
            {
                "query": {"type": "string"},
                "use_regex": {"type": "boolean", "default": False},
                "limit": {"type": "integer", "default": 25},
                "scan_limit": {"type": "integer", "default": 2000},
            },
            required=["query"],
        ),
        _fn(
            "chat_history_get",
            "Fetch one stored message by id: full content, tool_calls JSON, tool_call_id/tool_name for tool rows.",
            {"message_id": {"type": "integer"}},
            required=["message_id"],
        ),
        _fn(
            "chat_save_summary",
            "Append a rolling summary for this session (use after user asks to condense history). "
            "Optional covers_up_to_message_id ties summary to last included DB message id.",
            {
                "content": {"type": "string"},
                "covers_up_to_message_id": {"type": "integer"},
            },
            required=["content"],
        ),
        _fn(
            "chat_summaries_list",
            "List saved session summaries (oldest first within limit).",
            {"limit": {"type": "integer", "default": 15}},
            required=[],
        ),
        _fn(
            "viz_list_bundled_assets",
            "List offline chart/mermaid/vis-network JS/CSS shipped in the package res/",
            {},
            required=[],
        ),
        _fn(
            "viz_copy_resources",
            "Copy bundled res/*.js and res/*.css into target_directory/res for offline HTML",
            {"target_directory": {"type": "string"}},
            required=["target_directory"],
        ),
        _fn(
            "viz_export_html",
            "Write an HTML file that uses local res/ (Chart.js, Mermaid, vis-network). "
            "Copies bundled assets to the same directory as the html as res/ unless copy_resources=false. "
            "**Keep** the written **.html** and sibling **res/** after export (user often reopens in a browser to tweak charts); prefer **html_path** under the AI output root or **output/deliverables/<slug>/**, not only in disposable tmp/scratch. "
            "If body_html empty, writes a built-in demo page. "
            "**No remote assets**: do not put **http(s)://** or **//** URLs in **body_html**, **extra_head**, or **extra_scripts** (scripts, stylesheets, images, fonts, iframes, CSS url(), srcset, base href). Download anything needed into **res/** or **output/deliverables/<slug>/_assets/** and reference relatively; bundled Chart/Mermaid/vis come from **copy_resources** (see **scripts/download_viz_res.py** in repo). "
            "Custom vis-network/Chart code must go in extra_scripts OR after the three res/*.js includes—never before them (else vis/Chart undefined). "
            "Tool result may include **html_embed_validation** when checks find issues (network refs, load order).",
            {
                "html_path": {"type": "string"},
                "title": {"type": "string"},
                "body_html": {"type": "string", "description": "Inner HTML; empty = demo"},
                "copy_resources": {"type": "boolean", "default": True},
                "include_demo_chart_vis_bootstrap": {
                    "type": "boolean",
                    "default": False,
                    "description": "When body_html is custom, set true only if body contains #aicd-chart-demo and #aicd-vis-network",
                },
                "extra_head": {"type": "string"},
                "extra_scripts": {"type": "string"},
            },
            required=["html_path"],
        ),
        _fn(
            "viz_data_chart",
            "Build offline HTML with Chart.js from labels and values (bar or line). "
            "Copies res/ next to the html file unless copy_resources=false. "
            "**No remote asset URLs** in output (same policy as **viz_export_html**). "
            "**Retain** the **.html** and **res/** (same rules as **viz_export_html**) so the user can reopen the page to adjust data or styling later.",
            {
                "html_path": {"type": "string"},
                "chart_type": {"type": "string", "description": "bar or line"},
                "labels": {"type": "array", "items": {"type": "string"}},
                "values": {"type": "array", "items": {"type": "number"}},
                "title": {"type": "string"},
                "dataset_label": {"type": "string"},
                "copy_resources": {"type": "boolean", "default": True},
            },
            required=["html_path", "labels", "values"],
        ),
        _fn(
            "viz_html_to_png",
            "Rasterize a local **offline** **.html** (e.g. from **`viz_export_html`** or **`viz_data_chart`**) to **.png** via Playwright. "
            "**Does not delete** the HTML file or sibling **`res/`**—keep them for the user to reopen in a browser. "
            "Use the returned **`png_path`** in **`docx_compose` `image`** or **`pptx_compose` `image_path`** (never pass `.html` to those tools). "
            "Optional **selector** (CSS) to screenshot one element (e.g. chart container); otherwise **full_page** screenshot. "
            "Increase **wait_after_load_ms** if Chart.js/Mermaid need time to paint. "
            "Optional **viewport_width** + **viewport_height** (both required together) set a fixed canvas—use with **full_page** false for **PPT-sized** captures (see **pptx_from_html_deck**).",
            {
                "html_path": {"type": "string", "description": "Existing .html under workspace (file:// load)"},
                "output_png_path": {"type": "string", "description": "Destination .png path"},
                "selector": {
                    "type": "string",
                    "description": "Optional CSS selector for element screenshot",
                },
                "full_page": {
                    "type": "boolean",
                    "default": True,
                    "description": "When no selector: capture full scrollable page",
                },
                "viewport_width": {
                    "type": "integer",
                    "description": "Optional; set together with viewport_height (fixed viewport before load)",
                },
                "viewport_height": {
                    "type": "integer",
                    "description": "Optional; set together with viewport_width",
                },
                "device_scale_factor": {"type": "number", "default": 2},
                "wait_after_load_ms": {
                    "type": "integer",
                    "default": 1200,
                    "description": "Extra wait after load for JS charts",
                },
                "timeout_ms": {"type": "integer", "default": 120000},
            },
            required=["html_path", "output_png_path"],
        ),
        _fn(
            "static_html_bundle",
            "Build an **offline** static **site bundle**: single-page TOC, multi-page site with **index.html** + **pages/**, "
            "or **deck.html** PPT-style slides (keyboard ←/→, viewport swipe, optional autoplay). "
            "Copies bundled Chart/Mermaid/vis **res/** into **output_dir** when **copy_chart_resources** is true (same policy as **viz_export_html**). "
            "Optional **data_payloads** writes **data/*.json** for relative `fetch` from pages (use `http://127.0.0.1` + http.server if `file://` blocks fetch). "
            "When **data_payloads** is used and **inject_data_fetch_demo** is true (default), the main entry page embeds a small **fetch** smoke block for the first JSON file. "
            "**mode**: **single_toc** (sections with id/title/body_html in **pages** or **sections**) | **multi_page** (**pages** with rel_path, title, body_html) | **slide_deck** (**slides** with body_html). "
            "Writes **site.json** manifest unless **write_site_manifest** false. **No http(s)://** in embedded HTML.",
            {
                "output_dir": {
                    "type": "string",
                    "description": "Site root directory (created/written under workspace policy)",
                },
                "mode": {
                    "type": "string",
                    "description": "single_toc | multi_page | slide_deck",
                },
                "site_title": {"type": "string"},
                "title": {
                    "type": "string",
                    "description": "Alias for site_title",
                },
                "pages": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "single_toc sections or multi_page entries",
                },
                "sections": {"type": "array", "items": {"type": "object"}},
                "slides": {"type": "array", "items": {"type": "object"}},
                "copy_chart_resources": {"type": "boolean", "default": True},
                "copy_resources": {
                    "type": "boolean",
                    "description": "Alias for copy_chart_resources",
                },
                "data_payloads": {"type": "object"},
                "transition": {
                    "type": "string",
                    "description": "slide_deck only: fade | slide | none",
                },
                "autoplay_ms": {"type": "integer"},
                "write_site_manifest": {"type": "boolean", "default": True},
                "inject_data_fetch_demo": {
                    "type": "boolean",
                    "default": True,
                    "description": "When data/*.json exists, inject inline fetch preview on the main HTML entry",
                },
                "site_tree_folder_links": {
                    "type": "boolean",
                    "default": True,
                    "description": "multi_page index: folder rows link to first page in that subtree (by sorted title)",
                },
                "site_tree_collapsible": {
                    "type": "boolean",
                    "default": True,
                    "description": "multi_page index: group folders as expandable <details> sections",
                },
                "subpage_navigation": {
                    "type": "boolean",
                    "default": True,
                    "description": "multi_page: breadcrumb + link back to index.html on each child page",
                },
            },
            required=["output_dir", "mode"],
        ),
        _fn(
            "html_bundle_smoke",
            "Playwright smoke test for a static bundle **entry_html**: load (``file://`` or **base_url** + path under **site_root**), "
            "collect **console** messages and **page** errors, write **screenshots** (for slide decks: **ArrowRight** after first frame). "
            "Prefer **base_url** (e.g. http://127.0.0.1:PORT/) when pages use **fetch** against **data/**. "
            "Optional **report_json_path** for a structured JSON summary.",
            {
                "entry_html": {"type": "string"},
                "site_root": {
                    "type": "string",
                    "description": "Bundle root for resolving relative URL when using base_url (default: parent of entry_html)",
                },
                "base_url": {
                    "type": "string",
                    "description": "Optional e.g. http://127.0.0.1:8765/ — trailing slash optional",
                },
                "screenshot_dir": {
                    "type": "string",
                    "description": "Directory for PNGs (default: ai_tmp/html_bundle_smoke)",
                },
                "report_json_path": {"type": "string"},
                "capture_deck_slides": {"type": "boolean", "default": True},
                "wait_after_load_ms": {"type": "integer", "default": 1000},
                "timeout_ms": {"type": "integer", "default": 120000},
            },
            required=["entry_html"],
        ),
        _fn(
            "viz_spec_validate",
            "Validate graph/chart/Mermaid/HTML structure before export. **operation**: "
            "**graph_json** (nodes[], edges[], optional normalize) — vis-style ids + from/to or source/target; "
            "**chartjs_config** (config object or config_json string) — Chart.js shape; "
            "**mermaid_body** (text) — no nested fences, diagram keyword; "
            "**html_viz** (html) — script load order vs new Chart / vis.Network / mermaid; "
            "**static_bundle** / **static_site** — scan **site_root** (or **path**) for index.html, deck.html, pages/**/*.html, **site.json**, res/ presence; "
            "**slide_deck** — validate **deck.html** and aicd-deck-root; "
            "**no remote URLs** (http(s)://, // in src/href/srcset/CSS url()). "
            "Returns issues list and optional normalized graph.",
            {
                "operation": {"type": "string"},
                "nodes": {"type": "array", "items": {"type": "object"}},
                "edges": {"type": "array", "items": {"type": "object"}},
                "normalize": {"type": "boolean", "default": True},
                "config": {"type": "object"},
                "config_json": {"type": "string"},
                "mermaid_body": {"type": "string"},
                "html": {"type": "string"},
                "text": {"type": "string"},
                "site_root": {
                    "type": "string",
                    "description": "For static_bundle / slide_deck: directory on disk",
                },
                "path": {"type": "string", "description": "Alias for site_root"},
            },
            required=["operation"],
        ),
        _fn(
            "script_syntax_check",
            "Syntax check: **kind** py|js|mjs|bash|sh|ps1|bat|cmd — pass **source** or workspace **path**. "
            "Python uses ast.parse; JS uses `node --check` if Node on PATH; bash uses `bash -n`; "
            "PowerShell uses Language.Parser (pwsh/powershell); BAT/CMD is heuristic only (balanced parens, %). "
            "Prefer this before shipping code; **execution** (tests/build) still requires explicit user consent in the chat.",
            {
                "kind": {"type": "string"},
                "language": {"type": "string", "description": "Alias of kind"},
                "source": {"type": "string"},
                "path": {"type": "string"},
            },
            required=[],
        ),
        _fn(
            "data_stats",
            "Aggregated stats: operation describe|histogram|correlation with values/x/y/bins fields",
            {
                "operation": {"type": "string"},
                "values": {"type": "array", "items": {"type": "number"}},
                "bins": {"type": "integer", "default": 10},
                "x": {"type": "array", "items": {"type": "number"}},
                "y": {"type": "array", "items": {"type": "number"}},
            },
            required=["operation"],
        ),
        _fn(
            "data_text",
            "In-memory text: operation regex_findall|regex_sub|normalize|split_lines",
            {
                "operation": {"type": "string"},
                "text": {"type": "string"},
                "pattern": {"type": "string"},
                "repl": {"type": "string"},
                "count": {"type": "integer", "default": 0},
                "max_matches": {"type": "integer"},
                "ignore_case": {"type": "boolean"},
                "multiline": {"type": "boolean"},
                "keepends": {"type": "boolean"},
            },
            required=["operation"],
        ),
        _fn(
            "data_time",
            "Time helpers: operation now_iso|elapsed_ms|log_record; optional append_jsonl_path for log_record",
            {
                "operation": {"type": "string"},
                "use_utc": {"type": "boolean", "default": True},
                "timezone": {"type": "string", "description": "IANA name, e.g. Asia/Shanghai"},
                "start_iso": {"type": "string"},
                "end_iso": {"type": "string"},
                "level": {"type": "string"},
                "message": {"type": "string"},
                "append_jsonl_path": {"type": "string"},
            },
            required=["operation"],
        ),
        _fn(
            "script_template",
            "Return executable skeleton source for shell=py|bash|cmd|ps1 (use script_run to execute)",
            {
                "shell": {"type": "string"},
                "intent": {"type": "string"},
            },
            required=["shell"],
        ),
        _fn(
            "data_crypto",
            "Crypto & encoding: **operation** = hash (algorithm md5|sha1|sha256|sha512), hash_md5, hmac_sha256, "
            "base64_encode/decode, random_hex, pbkdf2_hmac_sha256 (password, salt_hex, iterations), "
            "aes_gcm_encrypt/decrypt (key_hex 16/24/32 bytes, nonce_hex optional), aes_cbc_encrypt/decrypt (iv_hex), "
            "des_cbc_encrypt/decrypt (8-byte key+iv hex; weak), rsa_generate (bits), rsa_encrypt (public_pem)/rsa_decrypt (private_pem), "
            "ecc_generate (curve secp256r1|secp384r1|secp521r1), ecdsa_sign/ecdsa_verify (PEM keys), "
            "unix_passwd_list/unix_group_list/unix_getpwnam/unix_getgrnam (POSIX only; no shadow passwords). "
            "Pass plaintext as **text** or binary as **hex**; keys/nonces as **key_hex**/**nonce_hex**/**iv_hex**.",
            {
                "operation": {"type": "string"},
                "text": {"type": "string"},
                "hex": {"type": "string"},
                "message": {"type": "string"},
                "algorithm": {"type": "string"},
                "key_text": {"type": "string"},
                "key_hex": {"type": "string"},
                "base64": {"type": "string"},
                "byte_length": {"type": "integer"},
                "password": {"type": "string"},
                "salt_hex": {"type": "string"},
                "iterations": {"type": "integer"},
                "length_bytes": {"type": "integer"},
                "nonce_hex": {"type": "string"},
                "ciphertext_hex": {"type": "string"},
                "associated_data": {"type": "string"},
                "iv_hex": {"type": "string"},
                "bits": {"type": "integer"},
                "public_pem": {"type": "string"},
                "private_pem": {"type": "string"},
                "curve": {"type": "string"},
                "signature_hex": {"type": "string"},
                "name": {"type": "string"},
                "limit": {"type": "integer"},
            },
            required=["operation"],
        ),
        _fn(
            "data_format",
            "Structured text helpers: **operation** = json_parse|json_stringify|json_pretty|json_path_get (path dot notation), "
            "html_to_text|html_escape, xml_parse_flat|xml_find_tags (tag), "
            "structure_convert with **mode** list_to_dict (key_field) | sort_object_keys | transpose_records, "
            "text_find (substring or regex **pattern**). Use for analytics prep; huge payloads → write file under ai_tmp.",
            {
                "operation": {"type": "string"},
                "text": {"type": "string"},
                "html": {"type": "string"},
                "xml": {"type": "string"},
                "path": {"type": "string"},
                "value": {"type": "object"},
                "json_text": {
                    "type": "string",
                    "description": "Alternative to value: JSON array or object as a string for json_stringify",
                },
                "indent": {"type": "integer"},
                "tag": {"type": "string"},
                "mode": {"type": "string"},
                "key_field": {"type": "string"},
                "substring": {"type": "string"},
                "pattern": {"type": "string"},
                "max_hits": {"type": "integer"},
                "ignore_case": {"type": "boolean"},
                "multiline": {"type": "boolean"},
                "unescape_entities": {"type": "boolean"},
            },
            required=["operation"],
        ),
        _fn(
            "artifact_query",
            "Read **large on-disk artifacts** (e.g. **``_aicd_tool_result_spill``** JSON under **aicd/tmp/tool_spill/**) without loading the whole file into chat. "
            "**operation**: **meta** (size + head preview), **line_range** (**start_line**, **max_lines**), **regex_lines** (per-line **pattern**, like grep; **context_lines**, **max_matches**), "
            "**regex_multiline** (first **max_scan_bytes** as text; optional **multiline**/**dotall**), **json_path** (**json_path** dot path; whole file must stay under **max_json_bytes**), "
            "**xml_flat** (trusted XML, capped by **max_xml_bytes**). Combine with **fs_read_file** **byte_offset**/**max_bytes**, **markdown_regex_scan**, **markdown_section_slice**, **data_format** on slices.",
            {
                "path": {"type": "string", "description": "File under workspace / allowed_roots"},
                "operation": {
                    "type": "string",
                    "description": "meta | line_range | regex_lines | regex_multiline | json_path | xml_flat",
                },
                "pattern": {"type": "string"},
                "context_lines": {"type": "integer"},
                "max_matches": {"type": "integer"},
                "ignore_case": {"type": "boolean"},
                "max_scan_bytes": {"type": "integer"},
                "encoding": {"type": "string"},
                "multiline": {"type": "boolean"},
                "dotall": {"type": "boolean"},
                "json_path": {"type": "string"},
                "max_json_bytes": {"type": "integer"},
                "max_xml_bytes": {"type": "integer"},
                "start_line": {"type": "integer"},
                "max_lines": {"type": "integer"},
            },
            required=["path", "operation"],
        ),
        _fn(
            "workspace_metrics",
            "Measured counts on disk under the **AI workspace** (paths resolved like **fs_***). **Must use this tool** for **code line totals** and **document word/character counts** — **do not** estimate by reading fragments or hand-summing in chat. "
            "**operation** **code_lines**: **root** (directory), optional **extensions** (list or comma string; default common source suffixes), **exclude_dir_names** (extra names beyond `.git`/`node_modules`/…), **max_files** (default 5000), **max_file_bytes** (skip larger). Returns **by_extension**, **total_lines**, **total_non_blank_lines**. "
            "**operation** **document_words**: either **paths** (array of files) **or** **root** + **glob** (default `**/*`), optional **extensions** (default `.md/.txt/.rst/.adoc/.tex`), **include_html** for `.html/.htm` (strips tags), same caps. Returns **total_chars** / **total_chars_no_whitespace** (close to 字数 for CJK), **total_words_whitespace_units**, **per_file** (capped).",
            {
                "operation": {
                    "type": "string",
                    "description": "code_lines | document_words",
                },
                "root": {
                    "type": "string",
                    "description": "Directory to scan (required for code_lines; for document_words if paths omitted)",
                },
                "paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "document_words only: explicit files instead of root+glob",
                },
                "glob": {"type": "string", "description": "document_words: default **/* under root"},
                "extensions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Suffixes with or without leading dot; omit for tool defaults",
                },
                "exclude_dir_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Extra directory base names to prune while walking",
                },
                "include_html": {"type": "boolean", "default": False},
                "max_files": {"type": "integer"},
                "max_file_bytes": {"type": "integer"},
            },
            required=["operation"],
        ),
        _fn(
            "db_inspect",
            "Inspect DB when user gives connection info: ping|list_schemas|list_tables|describe_table|row_count. "
            "Engines: sqlite (path), postgresql (host,port,user,password,database), mysql (same). "
            "Optional connection.schema for PostgreSQL default schema.",
            {
                "operation": {"type": "string"},
                "connection": {
                    "type": "object",
                    "description": "engine: sqlite|postgresql|mysql; sqlite needs path; others need host,user,password,database,port optional",
                    "properties": {
                        "engine": {"type": "string"},
                        "path": {"type": "string"},
                        "host": {"type": "string"},
                        "port": {"type": "integer"},
                        "user": {"type": "string"},
                        "password": {"type": "string"},
                        "database": {"type": "string"},
                        "schema": {"type": "string"},
                        "sslmode": {"type": "string"},
                    },
                    "required": ["engine"],
                },
                "table": {"type": "string"},
                "schema": {"type": "string"},
            },
            required=["operation", "connection"],
        ),
        _fn(
            "db_query",
            "Run a single SQL statement. Default read_only=true (SELECT/WITH/SHOW/DESCRIBE/DESC/EXPLAIN only). "
            "For INSERT/UPDATE/DDL set read_only=false and write_confirm exactly EXECUTE_WRITE. "
            "PostgreSQL/MySQL need: pip install aicd[db]. Max rows capped.",
            {
                "sql": {"type": "string"},
                "read_only": {"type": "boolean", "default": True},
                "max_rows": {"type": "integer", "default": 500},
                "write_confirm": {
                    "type": "string",
                    "description": "Must be EXECUTE_WRITE when read_only is false",
                },
                "connection": {
                    "type": "object",
                    "properties": {
                        "engine": {"type": "string"},
                        "path": {"type": "string"},
                        "host": {"type": "string"},
                        "port": {"type": "integer"},
                        "user": {"type": "string"},
                        "password": {"type": "string"},
                        "database": {"type": "string"},
                        "schema": {"type": "string"},
                        "sslmode": {"type": "string"},
                    },
                    "required": ["engine"],
                },
            },
            required=["sql", "connection"],
        ),
    ]


def _fn(
    name: str,
    description: str,
    properties: dict[str, Any],
    *,
    required: list[str],
) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
    }


def _diagram_drawio_export_png_tool_entries() -> list[dict[str, Any]]:
    """默认不注册：需 ``AICD_ENABLE_DRAWIO_EXPORT_PNG=1``（见 drawio_embed_export）。"""
    if not drawio_export_png_allowed():
        return []
    return [
        _fn(
            "diagram_drawio_export_png",
            "Export **.drawio** → **PNG** (opt-in via **AICD_ENABLE_DRAWIO_EXPORT_PNG=1**). "
            "Default path: **Playwright** + **https://embed.diagrams.net** (outbound HTTPS). "
            "**Offline / no embed**: **AICD_DRAWIO_OFFLINE_ONLY=1** + **AICD_DRAWIO_CLI** = local draw.io **.exe** path. "
            "After **`diagram_drawio_write`**, run until **ok** then **`docx_compose`** **image**. "
            "If this tool is unavailable, use **`diagram_mermaid_png`** or manual PNG export.",
            {
                "drawio_path": {"type": "string"},
                "output_png_path": {"type": "string"},
                "scale": {
                    "type": "number",
                    "default": 3,
                    "description": "embed export scale 0.5–8 (higher = sharper, larger PNG); use ≥4 for print/Word",
                },
                "transparent": {
                    "type": "boolean",
                    "default": False,
                    "description": "Transparent PNG background",
                },
                "border": {
                    "type": "integer",
                    "default": 2,
                    "description": "Border padding in pixels around diagram bounds",
                },
                "timeout_ms": {
                    "type": "integer",
                    "default": 120000,
                    "description": "Max wait for embed load+export (ms)",
                },
            },
            required=["drawio_path", "output_png_path"],
        ),
    ]


def _plugin_management_tool_entries() -> list[dict[str, Any]]:
    return [
        _fn(
            "plugin_list",
            "List plugin catalog: id, display_name, name, description, version, enabled, load ok, plugin_tools names, log_dir.",
            {},
            required=[],
        ),
        _fn(
            "plugin_info",
            "Show one plugin checklist: manifest from disk (name, display_name, description, version, config), last load summary, log file names under plugins/<id>/logs/.",
            {"plugin_id": {"type": "string", "description": "Directory name under plugins/"}},
            required=["plugin_id"],
        ),
        _fn(
            "plugin_read_log",
            "Read tail of plugin error/ops log (logs/YYYY-MM-DD.log UTC). Empty content means no entries that day.",
            {
                "plugin_id": {"type": "string"},
                "day": {
                    "type": "string",
                    "description": "Optional YYYY-MM-DD; default today UTC",
                },
                "max_lines": {"type": "integer", "default": 200},
            },
            required=["plugin_id"],
        ),
        _fn(
            "plugin_validate",
            "Re-scan all plugins from disk and refresh registry (same as reload); returns summary.",
            {},
            required=[],
        ),
        _fn(
            "plugin_load",
            "Load HOME plugins without a full restart: **scope=all** reloads every candidate directory; "
            "**scope=listed** with **plugin_ids** loads only those ids (others unloaded). "
            "Use after **safe** or nested boot when **AICD_PLUGIN_POLICY** kept plugins off.",
            {
                "scope": {
                    "type": "string",
                    "enum": ["all", "listed"],
                    "description": "all = rescan all plugins; listed = only plugin_ids.",
                },
                "plugin_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Required when scope=listed; HOME/plugins/<id> folder names.",
                },
            },
            required=["scope"],
        ),
        _fn(
            "plugin_reload",
            "Reload plugins from disk and refresh tool handlers and prompts for the next LLM turn.",
            {},
            required=[],
        ),
        _fn(
            "plugin_set_enabled",
            "Enable or disable a plugin (writes plugin.yaml) then reload.",
            {
                "plugin_id": {"type": "string"},
                "enabled": {"type": "boolean"},
            },
            required=["plugin_id", "enabled"],
        ),
        _fn(
            "plugin_backup_now",
            "Create a tar.gz backup of one plugin under plugins/.backups/<id>/.",
            {"plugin_id": {"type": "string"}},
            required=["plugin_id"],
        ),
        _fn(
            "plugin_list_backups",
            "List tar.gz backups for a plugin.",
            {"plugin_id": {"type": "string"}},
            required=["plugin_id"],
        ),
        _fn(
            "plugin_restore_backup",
            "Restore plugin from a backup archive name (from plugin_list_backups). Current tree is backed up first if it exists.",
            {
                "plugin_id": {"type": "string"},
                "archive_name": {"type": "string", "description": "e.g. 20250101T120000Z.tar.gz"},
            },
            required=["plugin_id", "archive_name"],
        ),
    ]


def openai_tools(extra: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    core = _core_openai_tools()
    core.extend(_plugin_management_tool_entries())
    if extra:
        return [*core, *extra]
    return core
