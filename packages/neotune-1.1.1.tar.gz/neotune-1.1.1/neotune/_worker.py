"""
Internal worker script launched by NeoTune for multi-GPU training.

Usage (invoked automatically by NeoTune.train):
    accelerate launch --num_processes=N -m neotune._worker --work_dir /tmp/neotune_xxx
"""

import argparse
import json
import os

import torch
from datasets import load_from_disk
from dotenv import load_dotenv
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    Trainer,
    TrainingArguments,
)

from neotune.train import compute_metrics, preprocess_logits_for_metrics

load_dotenv()
_token = os.getenv("HF_TOKEN")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work_dir", type=str, required=True)
    args = parser.parse_args()

    work_dir = args.work_dir

    # Load config
    with open(os.path.join(work_dir, "config.json"), "r") as f:
        config = json.load(f)

    model_id = config["model_id"]
    hparams = config["hparams"]
    ds_config = config.get("ds_config")
    use_bf16 = config["use_bf16"]
    use_fp16 = config["use_fp16"]
    model_dtype_str = config["model_dtype"]

    model_dtype = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}[model_dtype_str]

    # Load datasets from disk
    splits = {}
    for split_name in ["train", "validation", "test"]:
        split_path = os.path.join(work_dir, f"dataset_{split_name}")
        if os.path.isdir(split_path):
            splits[split_name] = load_from_disk(split_path)

    # Tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True, token=_token)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Model + LoRA
    model = AutoModelForCausalLM.from_pretrained(
        model_id, torch_dtype=model_dtype, token=_token
    )
    model.gradient_checkpointing_enable()
    model.enable_input_require_grads()
    model.config.use_cache = False

    lora_cfg = LoraConfig(
        task_type="CAUSAL_LM",
        r=hparams["lora_r"],
        lora_alpha=hparams["lora_alpha"],
        lora_dropout=hparams["lora_dropout"],
        target_modules=hparams["lora_target_modules"],
        bias="none",
    )
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    output_dir = hparams["output_dir"]
    has_val = "validation" in splits

    training_args = TrainingArguments(
        output_dir=output_dir,
        per_device_train_batch_size=hparams["batch_size"],
        gradient_accumulation_steps=hparams["gradient_accumulation_steps"],
        learning_rate=hparams["learning_rate"],
        num_train_epochs=hparams["num_train_epochs"],
        warmup_ratio=hparams["warmup_ratio"],
        weight_decay=hparams["weight_decay"],
        logging_steps=hparams["logging_steps"],
        eval_strategy="steps" if has_val else "no",
        eval_steps=hparams["eval_steps"] if has_val else None,
        per_device_eval_batch_size=hparams["batch_size"],
        save_steps=hparams["save_steps"],
        save_total_limit=hparams["save_total_limit"],
        bf16=use_bf16,
        fp16=use_fp16,
        gradient_checkpointing=hparams["gradient_checkpointing"],
        deepspeed=ds_config,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=splits["train"],
        eval_dataset=splits.get("validation"),
        data_collator=DataCollatorForSeq2Seq(
            tokenizer, pad_to_multiple_of=8, return_tensors="pt", padding=True
        ),
        preprocess_logits_for_metrics=preprocess_logits_for_metrics,
        compute_metrics=compute_metrics,
    )
    trainer.train()

    results = {}
    if "test" in splits:
        print("Running final evaluation on test set...")
        results = trainer.evaluate(splits["test"])
        print(f"Test Results: {results}")

    if trainer.is_world_process_zero():
        os.makedirs(output_dir, exist_ok=True)
        trainer.model.save_pretrained(output_dir)
        tokenizer.save_pretrained(output_dir)

        # Write results for the parent process to read
        results_path = os.path.join(work_dir, "results.json")
        serializable = {k: float(v) if hasattr(v, "item") else v for k, v in results.items()}
        with open(results_path, "w") as f:
            json.dump(serializable, f)

        if hparams.get("hf_repo"):
            repo = hparams["hf_repo"]
            print(f"Pushing adapter to HuggingFace Hub: {repo}")
            trainer.model.push_to_hub(repo, token=_token)
            tokenizer.push_to_hub(repo, token=_token)


if __name__ == "__main__":
    main()
