import json
import os
import shutil
import subprocess
import sys
import tempfile
from copy import deepcopy
from typing import Union

import torch
from datasets import Dataset, DatasetDict
from dotenv import load_dotenv
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    Trainer,
    TrainingArguments,
)

from neotune.train import (
    compute_metrics,
    preprocess_logits_for_metrics,
    tokenize,
)

load_dotenv()
_token = os.getenv("HF_TOKEN")

DEFAULT_HYPERPARAMETERS = {
    # Training
    "learning_rate": 1e-4,
    "num_train_epochs": 3,
    "batch_size": 1,
    "gradient_accumulation_steps": 4,
    "warmup_ratio": 0.03,
    "weight_decay": 0.01,
    "bf16": True,
    "gradient_checkpointing": False,
    "logging_steps": 10,
    "eval_steps": 50,
    "save_steps": 100,
    "save_total_limit": 3,
    # LoRA
    "lora_r": 16,
    "lora_alpha": 32,
    "lora_dropout": 0.05,
    "lora_target_modules": "all-linear",
    # Output
    "output_dir": "./adapter-output",
    "hf_repo": None,
    # DeepSpeed
    "ds_config": None,
    # Data
    "max_len": 2048,
    "dataset_text_field": "text",
}

DEFAULT_DS_CONFIG = {
    "train_micro_batch_size_per_gpu": "auto",
    "gradient_accumulation_steps": "auto",
    "bf16": {"enabled": True},
    "zero_optimization": {
        "stage": 2,
        "overlap_comm": True,
        "contiguous_gradients": True,
    },
    "gradient_clipping": 1.0,
    "steps_per_print": 50,
    "optimizer": {
        "type": "AdamW",
        "params": {"lr": "auto", "betas": "auto", "eps": "auto", "weight_decay": "auto"},
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": "auto",
            "warmup_min_lr": "auto",
            "warmup_max_lr": "auto",
            "warmup_num_steps": "auto",
        },
    },
}


def _detect_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def _gpu_count() -> int:
    if not torch.cuda.is_available():
        return 0
    return torch.cuda.device_count()


def _resolve_dtype(device: str, hparams: dict):
    if device == "mps":
        return torch.float16, False, True   # dtype, bf16, fp16
    if hparams.get("bf16", True):
        return torch.bfloat16, True, False
    return torch.float32, False, False


def _resolve_ds_config(ds_config):
    if ds_config is None:
        if _gpu_count() > 1:
            return deepcopy(DEFAULT_DS_CONFIG)
        return None
    if ds_config is False:
        return None
    if isinstance(ds_config, dict):
        return ds_config
    if ds_config == "auto":
        return deepcopy(DEFAULT_DS_CONFIG)
    with open(ds_config, "r") as f:
        return json.load(f)


def _is_tokenized(dataset: Dataset) -> bool:
    cols = set(dataset.column_names)
    return "input_ids" in cols and "labels" in cols


def _is_distributed_env() -> bool:
    """Check if we're already inside a distributed launch (accelerate/torchrun)."""
    return "RANK" in os.environ or "LOCAL_RANK" in os.environ


class NeoTune:
    """
    High-level API for LoRA supervised fine-tuning.

    Automatically adapts to the compute environment:

    - **Single GPU / MPS / CPU** — trains in-process
    - **Multi-GPU (single node)** — launches distributed training
      via ``accelerate launch`` automatically

    Parameters
    ----------
    model : str
        HuggingFace model ID or local path
        (e.g. ``"google/gemma-3-4b-pt"``).

    datasets : dict[str, Dataset]
        Pre-built HuggingFace ``Dataset`` splits. Required key: ``"train"``.
        Optional keys: ``"validation"``, ``"test"``.

        Each dataset must contain **either**:

        * A text column (default ``"text"``) with fully-formatted
          prompt/response strings. NeoTune will tokenize it automatically.
        * ``input_ids``, ``attention_mask``, and ``labels`` columns —
          already tokenized and ready for training.

    hyperparameters : dict, optional
        Override any default. Supported keys:

        *Training:* ``learning_rate``, ``num_train_epochs``, ``batch_size``,
        ``gradient_accumulation_steps``, ``warmup_ratio``, ``weight_decay``,
        ``bf16``, ``gradient_checkpointing``, ``logging_steps``,
        ``eval_steps``, ``save_steps``, ``save_total_limit``

        *LoRA:* ``lora_r``, ``lora_alpha``, ``lora_dropout``,
        ``lora_target_modules``

        *Output:* ``output_dir``, ``hf_repo``

        *DeepSpeed:* ``ds_config`` (``None`` for auto, ``"auto"`` to force
        ZeRO-2, ``False`` to disable, a file path, or a dict)

        *Data:* ``max_len``, ``dataset_text_field``

    Example
    -------
    ::

        from neotune import NeoTune

        nt = NeoTune(
            model="google/gemma-3-4b-pt",
            datasets={"train": train_ds, "validation": val_ds},
            hyperparameters={"learning_rate": 2e-4, "num_train_epochs": 5},
        )
        results = nt.train()
    """

    def __init__(
        self,
        model: str,
        datasets: dict,
        hyperparameters: Union[dict, None] = None,
    ):
        self.model_id = model
        self.hparams = {**DEFAULT_HYPERPARAMETERS, **(hyperparameters or {})}
        self.device = _detect_device()
        self.num_gpus = _gpu_count()
        # DeepSpeed only works with CUDA
        if self.device != "cuda":
            self.ds_config = None
        else:
            self.ds_config = _resolve_ds_config(self.hparams.get("ds_config"))
        self._tokenizer = None
        self._splits = self._validate_datasets(datasets)

    def _validate_datasets(self, datasets: dict) -> dict:
        if isinstance(datasets, DatasetDict):
            datasets = dict(datasets)
        if "train" not in datasets:
            raise ValueError("datasets must include a 'train' key")
        for name, ds in datasets.items():
            if not isinstance(ds, Dataset):
                raise TypeError(
                    f"datasets['{name}'] must be a HuggingFace Dataset, "
                    f"got {type(ds).__name__}"
                )
        return datasets

    @property
    def tokenizer(self):
        if self._tokenizer is None:
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.model_id, use_fast=True, token=_token
            )
            if self._tokenizer.pad_token is None:
                self._tokenizer.pad_token = self._tokenizer.eos_token
        return self._tokenizer

    def _prepare_splits(self) -> dict:
        max_len = self.hparams["max_len"]
        text_field = self.hparams["dataset_text_field"]
        splits = {}
        for name, ds in self._splits.items():
            if _is_tokenized(ds):
                splits[name] = ds
            else:
                if text_field not in ds.column_names:
                    raise ValueError(
                        f"Dataset '{name}' must have a '{text_field}' column "
                        f"(for auto-tokenization) or 'input_ids'+'labels' "
                        f"columns (pre-tokenized). "
                        f"Found columns: {ds.column_names}"
                    )
                remove_cols = [c for c in ds.column_names if c != text_field]
                if text_field != "text":
                    ds = ds.rename_column(text_field, "text")
                ds_tok = ds.map(
                    lambda ex: tokenize(ex, self.tokenizer, max_len),
                    remove_columns=remove_cols + ["text"],
                )
                splits[name] = ds_tok
        return splits

    def _push_to_hub(self, model):
        repo = self.hparams["hf_repo"]
        print(f"Pushing adapter to HuggingFace Hub: {repo}")
        model.push_to_hub(repo, token=_token)
        self.tokenizer.push_to_hub(repo, token=_token)

    def _needs_distributed_launch(self) -> bool:
        """True if we have multiple GPUs and are NOT already in a distributed env."""
        return self.num_gpus > 1 and not _is_distributed_env()

    def _train_distributed(self, splits: dict) -> dict:
        """Save state to disk, launch accelerate, read results back."""
        work_dir = tempfile.mkdtemp(prefix="neotune_")
        try:
            # Save datasets to disk
            for name, ds in splits.items():
                ds.save_to_disk(os.path.join(work_dir, f"dataset_{name}"))

            # Resolve dtype info
            model_dtype, use_bf16, use_fp16 = _resolve_dtype(self.device, self.hparams)
            dtype_map = {torch.bfloat16: "bfloat16", torch.float16: "float16", torch.float32: "float32"}

            # Write config
            config = {
                "model_id": self.model_id,
                "hparams": self.hparams,
                "ds_config": self.ds_config,
                "use_bf16": use_bf16,
                "use_fp16": use_fp16,
                "model_dtype": dtype_map[model_dtype],
            }
            config_path = os.path.join(work_dir, "config.json")
            with open(config_path, "w") as f:
                json.dump(config, f)

            # Write DeepSpeed config to a file if needed
            if self.ds_config is not None:
                ds_config_path = os.path.join(work_dir, "ds_config.json")
                with open(ds_config_path, "w") as f:
                    json.dump(self.ds_config, f)
                config["ds_config"] = ds_config_path
                with open(config_path, "w") as f:
                    json.dump(config, f)

            # Build launch command
            cmd = [
                sys.executable, "-m", "accelerate.commands.launch",
                "--num_processes", str(self.num_gpus),
                "--mixed_precision", "bf16" if use_bf16 else ("fp16" if use_fp16 else "no"),
                "-m", "neotune._worker",
                "--work_dir", work_dir,
            ]

            print(f"Launching distributed training on {self.num_gpus} GPUs...")
            result = subprocess.run(
                cmd,
                env={**os.environ, "PYTHONPATH": os.getcwd()},
                check=True,
            )

            # Read results
            results_path = os.path.join(work_dir, "results.json")
            if os.path.isfile(results_path):
                with open(results_path, "r") as f:
                    return json.load(f)
            return {}

        finally:
            shutil.rmtree(work_dir, ignore_errors=True)

    def _train_single(self, splits: dict) -> dict:
        """In-process training for single GPU / MPS / CPU."""
        model_dtype, use_bf16, use_fp16 = _resolve_dtype(self.device, self.hparams)

        model = AutoModelForCausalLM.from_pretrained(
            self.model_id, torch_dtype=model_dtype, token=_token
        )
        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()
        model.config.use_cache = False

        lora_cfg = LoraConfig(
            task_type="CAUSAL_LM",
            r=self.hparams["lora_r"],
            lora_alpha=self.hparams["lora_alpha"],
            lora_dropout=self.hparams["lora_dropout"],
            target_modules=self.hparams["lora_target_modules"],
            bias="none",
        )
        model = get_peft_model(model, lora_cfg)
        model.print_trainable_parameters()

        output_dir = self.hparams["output_dir"]
        has_val = "validation" in splits

        training_args = TrainingArguments(
            output_dir=output_dir,
            per_device_train_batch_size=self.hparams["batch_size"],
            gradient_accumulation_steps=self.hparams["gradient_accumulation_steps"],
            learning_rate=self.hparams["learning_rate"],
            num_train_epochs=self.hparams["num_train_epochs"],
            warmup_ratio=self.hparams["warmup_ratio"],
            weight_decay=self.hparams["weight_decay"],
            logging_steps=self.hparams["logging_steps"],
            eval_strategy="steps" if has_val else "no",
            eval_steps=self.hparams["eval_steps"] if has_val else None,
            per_device_eval_batch_size=self.hparams["batch_size"],
            save_steps=self.hparams["save_steps"],
            save_total_limit=self.hparams["save_total_limit"],
            bf16=use_bf16,
            fp16=use_fp16,
            gradient_checkpointing=self.hparams["gradient_checkpointing"],
            deepspeed=self.ds_config,
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=splits["train"],
            eval_dataset=splits.get("validation"),
            data_collator=DataCollatorForSeq2Seq(
                self.tokenizer, pad_to_multiple_of=8, return_tensors="pt", padding=True
            ),
            preprocess_logits_for_metrics=preprocess_logits_for_metrics,
            compute_metrics=compute_metrics,
        )
        trainer.train()

        results = {}
        if "test" in splits:
            print("Running final evaluation on test set...")
            results = trainer.evaluate(splits["test"])
            print(f"Test Results: {results}")

        if trainer.is_world_process_zero():
            os.makedirs(output_dir, exist_ok=True)
            trainer.model.save_pretrained(output_dir)
            self.tokenizer.save_pretrained(output_dir)
            if self.hparams.get("hf_repo"):
                self._push_to_hub(trainer.model)

        return results

    def train(self) -> dict:
        """
        Fine-tune the model with LoRA and return evaluation metrics.

        Automatically uses distributed training when multiple GPUs are
        available. Returns test-set metrics if a ``"test"`` split was
        provided, otherwise an empty dict.
        """
        splits = self._prepare_splits()

        if self._needs_distributed_launch():
            return self._train_distributed(splits)
        return self._train_single(splits)


def finetune(
    model: str,
    datasets: dict,
    hyperparameters: Union[dict, None] = None,
) -> dict:
    """
    One-call fine-tuning: create a NeoTune instance and train immediately.

    Automatically detects the compute environment:

    - Single GPU / Apple Silicon / CPU — trains in-process
    - Multi-GPU (single node) — launches distributed training via accelerate

    Parameters
    ----------
    model : str
        HuggingFace model ID or local path.
    datasets : dict[str, Dataset]
        Dataset splits (must include ``"train"``).
    hyperparameters : dict, optional
        Override any default (see ``NeoTune`` for full list).

    Returns
    -------
    dict
        Test-set evaluation metrics (empty dict if no test split).
    """
    nt = NeoTune(model=model, datasets=datasets, hyperparameters=hyperparameters)
    return nt.train()
