"""Tests for session management."""

from datetime import datetime
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.gate import CoincidenceGate
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.llm import LLMProvider, LLMUnavailableError
from fractal_memory.models import (
    LifecycleStatus,
    Memory,
    RetrievalResult,
    Session,
    TaskStatus,
)
from fractal_memory.session import SessionManager
from fractal_memory.storage import Storage


def _make_memory(**kwargs) -> Memory:
    defaults = dict(
        id=uuid4(),
        domain="test",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="test summary",
        l3_full="test full",
        l4_raw="raw text",
        embedding=[0.1] * 384,
        embedding_model="test-model",
    )
    defaults.update(kwargs)
    return Memory(**defaults)


@pytest.fixture
async def session_mgr(storage, mock_llm, mock_embeddings, tmp_config):
    lifecycle = LifecycleManager(storage, tmp_config)
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    return SessionManager(storage, mock_llm, lifecycle, gate, tmp_config)


async def test_session_start(session_mgr, storage):
    ctx = await session_mgr.start("test")
    assert ctx.session.domain == "test"
    assert ctx.session.ended_at is None
    assert session_mgr.current_session is not None


async def test_bootstrap_loads_safety_critical(session_mgr, storage):
    mem = _make_memory(lifecycle=LifecycleStatus.SAFETY_CRITICAL)
    await storage.store_memory(mem)
    ctx = await session_mgr.start("test")
    assert any(m.id == mem.id for m in ctx.bootstrap_memories)


async def test_bootstrap_loads_last_summary(session_mgr, storage):
    s = Session(
        id=uuid4(),
        domain="test",
        started_at=datetime.utcnow(),
        ended_at=datetime.utcnow(),
        summary="previous session summary",
    )
    await storage.store_session(s)
    ctx = await session_mgr.start("test")
    assert ctx.last_summary == "previous session summary"


async def test_session_end_generates_summary(session_mgr, storage):
    await session_mgr.start("test")
    summary = await session_mgr.end()
    assert summary.summary is not None
    assert len(summary.summary) > 0
    assert session_mgr.current_session is None


async def test_session_end_no_active_session(session_mgr):
    with pytest.raises(RuntimeError, match="No active session"):
        await session_mgr.end()


async def test_session_end_hooks_called(session_mgr, storage):
    hook_called = []

    async def my_hook():
        hook_called.append(True)

    session_mgr.register_on_end_hook(my_hook)
    await session_mgr.start("test")
    await session_mgr.end()
    assert len(hook_called) == 1


async def test_session_end_llm_unavailable(storage, mock_embeddings, tmp_config):
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(side_effect=LLMUnavailableError("offline"))
    lifecycle = LifecycleManager(storage, tmp_config)
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    mgr = SessionManager(storage, llm, lifecycle, gate, tmp_config)
    await mgr.start("test")
    summary = await mgr.end()
    assert "test" in summary.summary
    assert "stored" in summary.summary


async def test_record_store_and_retrieval(session_mgr, storage):
    await session_mgr.start("test")
    mid = uuid4()
    await session_mgr.record_store(mid)
    result = RetrievalResult(
        l3_memories=[_make_memory()],
        l2_memories=[_make_memory()],
        l1_memories=[_make_memory()],
    )
    await session_mgr.record_retrieval("test query", result)
    summary = await session_mgr.end()
    assert summary.memories_stored == 1
    assert summary.memories_retrieved == 1


async def test_session_end_runs_pruning(storage, mock_llm, mock_embeddings, tmp_config):
    """session_end() runs lifecycle pruning."""
    from datetime import timedelta

    lifecycle = LifecycleManager(storage, tmp_config)
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    mgr = SessionManager(storage, mock_llm, lifecycle, gate, tmp_config)

    # Create an old probation memory and enough sessions to exceed TTL
    old_time = datetime.utcnow() - timedelta(days=30)
    mem = _make_memory(created_at=old_time, updated_at=old_time)
    await storage.store_memory(mem)

    for i in range(tmp_config.pruning_ttl_sessions + 1):
        s = Session(
            id=uuid4(),
            domain="test",
            started_at=old_time + timedelta(days=i + 1),
            ended_at=old_time + timedelta(days=i + 1, hours=1),
            summary=f"s{i}",
        )
        await storage.store_session(s)

    await mgr.start("test")
    await mgr.end()

    # Memory should have been pruned
    assert await storage.get_memory(mem.id) is None


async def test_session_end_expires_waiting_room(storage, mock_llm, mock_embeddings, tmp_config):
    """session_end() expires old waiting room entries."""
    from fractal_memory.models import WaitingRoomEntry

    lifecycle = LifecycleManager(storage, tmp_config)
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    mgr = SessionManager(storage, mock_llm, lifecycle, gate, tmp_config)

    # Add a waiting room entry past expiry threshold
    entry = WaitingRoomEntry(
        id=uuid4(),
        content="stale content",
        first_signal={"type": "novelty"},
        domain="test",
        created_at=datetime.utcnow(),
        sessions_elapsed=tmp_config.waiting_room_expiry_sessions + 1,
        embedding=[0.1] * 384,
    )
    await storage.store_waiting_room_entry(entry)

    await mgr.start("test")
    await mgr.end()

    # Entry should have been expired
    assert await storage.get_waiting_room_entry(entry.id) is None


# ---------------------------------------------------------------------------
# Issue #15: get_session_stats from summaries
# ---------------------------------------------------------------------------


async def test_get_session_stats_from_summaries(storage):
    """Issue #15: get_session_stats returns real data from session_summaries."""
    conn = storage._ensure_conn()
    now = datetime.utcnow().isoformat()
    for retrieve_count, store_count in [(5, 2), (10, 3), (15, 5)]:
        sid = str(uuid4())
        await conn.execute(
            """INSERT INTO session_summaries
               (session_id, started_at, ended_at, store_count, retrieve_count)
               VALUES (?, ?, ?, ?, ?)""",
            (sid, now, now, store_count, retrieve_count),
        )
    await conn.commit()

    stats = await storage.get_session_stats()
    assert stats["retrieval_total"] == 30
    assert stats["store_total"] == 10
    assert stats["session_count"] == 3


async def test_get_session_stats_empty_db(storage):
    """Issue #15: get_session_stats on fresh DB returns zeros."""
    stats = await storage.get_session_stats()
    assert stats["retrieval_total"] == 0
    assert stats["store_total"] == 0
    assert stats["session_count"] == 0
