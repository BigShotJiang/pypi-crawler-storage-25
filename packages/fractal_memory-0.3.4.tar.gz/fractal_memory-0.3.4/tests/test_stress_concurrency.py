"""Concurrency and stress tests for fractal-memory.

Tests database locking, concurrent store/retrieve, write contention,
and system stability under parallel operations.
Uses real SQLite storage. Embeddings use deterministic mock for speed.
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider
from fractal_memory.storage import Storage


# ── Fixtures ───────────────────────────────────────────────────────────

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Stress test session summary."
        return json.dumps({
            "l0_tag": "stress:test",
            "l1_label": "stress-test",
            "l2_summary": "A stress test memory.",
            "l3_full": "A stress test memory with full context.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def stress_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "stress_test.db",
        gate_signal_count=1,
        # Increase LLM limits for stress tests
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def stress_fm(stress_config: FractalConfig):
    fm = FractalMemory(stress_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def stress_storage(stress_config: FractalConfig):
    s = Storage(stress_config)
    await s.initialize()
    yield s
    await s.close()


# ── Concurrent stores ─────────────────────────────────────────────────

class TestConcurrentStores:
    @pytest.mark.asyncio
    async def test_50_concurrent_stores(self, stress_fm: FractalMemory):
        """50 concurrent store() calls should all succeed without DB errors."""
        await stress_fm.session_start("stress")

        async def _store(i: int):
            return await stress_fm.store(f"Concurrent store test memory number {i} with unique content")

        tasks = [_store(i) for i in range(50)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        successes = [r for r in results if r is not None and not isinstance(r, Exception)]
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Got {len(errors)} errors: {errors[:3]}"
        assert len(successes) == 50

        # Verify all 50 are actually in storage
        stats = await stress_fm.get_stats()
        assert stats["overall"]["total_memories"] >= 50

    @pytest.mark.asyncio
    async def test_100_sequential_stores(self, stress_fm: FractalMemory):
        """100 sequential stores should complete in under 30s."""
        await stress_fm.session_start("stress")

        start = time.perf_counter()
        for i in range(100):
            mem = await stress_fm.store(f"Sequential store {i}: topic about {i % 10}")
            assert mem is not None
        elapsed = time.perf_counter() - start

        assert elapsed < 30.0, f"100 stores took {elapsed:.1f}s (limit: 30s)"


# ── Concurrent retrieves ──────────────────────────────────────────────

class TestConcurrentRetrieves:
    @pytest.mark.asyncio
    async def test_50_concurrent_retrieves(self, stress_fm: FractalMemory):
        """50 concurrent retrieve() calls should all succeed."""
        await stress_fm.session_start("stress")

        # Seed with some memories first
        for i in range(20):
            await stress_fm.store(f"Pre-seeded memory about topic {i}")

        async def _retrieve(i: int):
            return await stress_fm.retrieve(f"Query about topic {i % 20}", domain="stress")

        tasks = [_retrieve(i) for i in range(50)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Got {len(errors)} retrieval errors: {errors[:3]}"
        successes = [r for r in results if not isinstance(r, Exception)]
        assert len(successes) == 50


# ── Mixed concurrent store + retrieve ─────────────────────────────────

class TestMixedConcurrency:
    @pytest.mark.asyncio
    async def test_concurrent_store_and_retrieve(self, stress_fm: FractalMemory):
        """Interleaved stores and retrieves should not deadlock or corrupt."""
        await stress_fm.session_start("stress")

        # Seed
        for i in range(10):
            await stress_fm.store(f"Base memory {i}")

        async def _store(i: int):
            return await stress_fm.store(f"Concurrent mixed store {i}")

        async def _retrieve(i: int):
            return await stress_fm.retrieve(f"mixed query {i}", domain="stress")

        store_tasks = [_store(i) for i in range(20)]
        retrieve_tasks = [_retrieve(i) for i in range(20)]
        all_tasks = store_tasks + retrieve_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Mixed concurrency errors: {errors[:3]}"


# ── Raw storage concurrency ───────────────────────────────────────────

class TestStorageConcurrency:
    @pytest.mark.asyncio
    async def test_100_concurrent_reads(self, stress_storage: Storage):
        """100 concurrent storage reads should succeed with WAL mode."""
        from datetime import datetime
        from uuid import uuid4
        from fractal_memory.models import Memory

        # Insert a memory
        mem_id = uuid4()
        mem = Memory(
            id=mem_id, domain="stress", created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(), context={},
            l0_tag="t", l1_label="l", l2_summary="s", l3_full="f", l4_raw="r",
            embedding=_deterministic_embed("test"), embedding_model="mock",
        )
        await stress_storage.store_memory(mem)

        async def _read():
            return await stress_storage.get_memory(mem_id)

        tasks = [_read() for _ in range(100)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Concurrent read errors: {errors[:3]}"
        assert all(r.id == mem_id for r in results if not isinstance(r, Exception))

    @pytest.mark.asyncio
    async def test_concurrent_writes_different_records(self, stress_storage: Storage):
        """50 concurrent writes of different records should all succeed."""
        from datetime import datetime
        from uuid import uuid4
        from fractal_memory.models import Memory

        async def _write(i: int):
            mem = Memory(
                id=uuid4(), domain="stress", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag=f"t{i}", l1_label=f"l{i}", l2_summary=f"s{i}",
                l3_full=f"f{i}", l4_raw=f"r{i}",
                embedding=_deterministic_embed(f"write-{i}"), embedding_model="mock",
            )
            await stress_storage.store_memory(mem)
            return mem.id

        tasks = [_write(i) for i in range(50)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Concurrent write errors: {errors[:3]}"

        count = await stress_storage.count_memories()
        assert count >= 50

    @pytest.mark.asyncio
    async def test_read_during_write_storm(self, stress_storage: Storage):
        """Reads should succeed while writes are happening."""
        from datetime import datetime
        from uuid import uuid4
        from fractal_memory.models import Memory

        # Seed one memory to read
        seed_id = uuid4()
        seed = Memory(
            id=seed_id, domain="stress", created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(), context={},
            l0_tag="seed", l1_label="seed", l2_summary="seed",
            l3_full="seed", l4_raw="seed",
            embedding=_deterministic_embed("seed"), embedding_model="mock",
        )
        await stress_storage.store_memory(seed)

        async def _write(i: int):
            mem = Memory(
                id=uuid4(), domain="stress", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag=f"storm{i}", l1_label=f"s{i}", l2_summary=f"s{i}",
                l3_full=f"f{i}", l4_raw=f"r{i}",
                embedding=_deterministic_embed(f"storm-{i}"), embedding_model="mock",
            )
            await stress_storage.store_memory(mem)

        async def _read():
            return await stress_storage.get_memory(seed_id)

        write_tasks = [_write(i) for i in range(30)]
        read_tasks = [_read() for _ in range(30)]
        all_tasks = write_tasks + read_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Read-during-write errors: {errors[:3]}"


# ── Session storm ─────────────────────────────────────────────────────

class TestSessionStorm:
    @pytest.mark.asyncio
    async def test_rapid_session_cycles(self, stress_config: FractalConfig):
        """10 rapid session start→store→retrieve→end cycles should not leak state."""
        fm = FractalMemory(stress_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            for i in range(10):
                await fm.session_start("stress")
                await fm.store(f"Session {i} memory about topic {i}", domain="stress")
                await fm.retrieve(f"topic {i}", domain="stress")
                summary = await fm.session_end()
                assert summary is not None
        finally:
            await fm.close()

        # Verify data persisted across all sessions
        # Note: some probation memories may be pruned by maintenance, which is correct
        fm2 = FractalMemory(stress_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm2.initialize()
        try:
            stats = await fm2.get_stats()
            assert stats["overall"]["total_memories"] >= 5, (
                f"At least some memories should survive: got {stats['overall']['total_memories']}"
            )
            assert stats["overall"]["total_sessions"] >= 10
        finally:
            await fm2.close()


# ── Timing / throughput ───────────────────────────────────────────────

class TestThroughput:
    @pytest.mark.asyncio
    async def test_store_throughput(self, stress_fm: FractalMemory):
        """Measure stores per second. Should sustain > 10 stores/sec."""
        await stress_fm.session_start("stress")

        start = time.perf_counter()
        count = 50
        for i in range(count):
            await stress_fm.store(f"Throughput test memory {i}")
        elapsed = time.perf_counter() - start

        rate = count / elapsed
        assert rate > 10, f"Store throughput {rate:.1f}/s (should be > 10/s)"

    @pytest.mark.asyncio
    async def test_retrieve_throughput(self, stress_fm: FractalMemory):
        """Measure retrieves per second with 100 memories. Should sustain > 2 retrieves/sec."""
        await stress_fm.session_start("stress")
        for i in range(100):
            await stress_fm.store(f"Throughput retrieve base memory {i} on topic {i % 20}")

        start = time.perf_counter()
        count = 30
        for i in range(count):
            await stress_fm.retrieve(f"throughput query {i}", domain="stress")
        elapsed = time.perf_counter() - start

        rate = count / elapsed
        assert rate > 2, f"Retrieve throughput {rate:.1f}/s (should be > 2/s)"
