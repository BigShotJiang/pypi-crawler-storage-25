"""End-to-end integration tests using mock LLM/embeddings."""

import pytest

from fractal_memory import FractalMemory, Signal
from fractal_memory.models import LifecycleStatus


async def test_store_and_retrieve(fractal_memory: FractalMemory):
    """Full store → retrieve round-trip."""
    ctx = await fractal_memory.session_start("test")
    mem = await fractal_memory.store(
        "User prefers Python for backend",
        domain="test",
        signals=[Signal.EXPLICIT_STORE],
    )
    assert mem is not None
    assert mem.domain == "test"

    result = await fractal_memory.retrieve("what language for backend?", domain="test")
    assert len(result.l3_memories) >= 1

    summary = await fractal_memory.session_end()
    assert summary.memories_stored == 1


async def test_session_lifecycle(fractal_memory: FractalMemory):
    """Session start → multiple stores → retrieve → end."""
    await fractal_memory.session_start("test")

    for i in range(5):
        await fractal_memory.store(f"Memory number {i}", domain="test")

    result = await fractal_memory.retrieve("memory", domain="test")
    assert len(result.l3_memories) >= 1

    summary = await fractal_memory.session_end()
    assert summary.memories_stored == 5
    assert summary.memories_retrieved == 1


async def test_multi_session_bootstrap(fractal_memory: FractalMemory):
    """Session 1 summary appears in session 2 bootstrap."""
    # Session 1
    await fractal_memory.session_start("test")
    await fractal_memory.store("Important fact", domain="test")
    await fractal_memory.session_end()

    # Session 2
    ctx = await fractal_memory.session_start("test")
    assert ctx.last_summary is not None
    assert len(ctx.last_summary) > 0
    await fractal_memory.session_end()


async def test_domain_isolation(fractal_memory: FractalMemory):
    """Memories in different domains don't leak."""
    await fractal_memory.session_start("alpha")
    await fractal_memory.store("Alpha memory", domain="alpha")
    await fractal_memory.store("Beta memory", domain="beta")

    result = await fractal_memory.retrieve("memory", domain="alpha")
    for m in result.l3_memories:
        assert m.domain == "alpha"
    await fractal_memory.session_end()


async def test_pin_and_unpin(fractal_memory: FractalMemory):
    await fractal_memory.session_start("test")
    mem = await fractal_memory.store("Important", domain="test")
    assert mem is not None

    await fractal_memory.pin(mem.id)
    fetched = await fractal_memory.get(mem.id)
    assert fetched.lifecycle == LifecycleStatus.PERMANENT

    await fractal_memory.unpin(mem.id)
    fetched = await fractal_memory.get(mem.id)
    assert fetched.lifecycle == LifecycleStatus.CONFIRMED
    await fractal_memory.session_end()


async def test_mark_critical(fractal_memory: FractalMemory):
    await fractal_memory.session_start("test")
    mem = await fractal_memory.store("NEVER delete production DB", domain="test")
    assert mem is not None

    await fractal_memory.mark_critical(mem.id)
    fetched = await fractal_memory.get(mem.id)
    assert fetched.lifecycle == LifecycleStatus.SAFETY_CRITICAL
    await fractal_memory.session_end()


async def test_delete_memory(fractal_memory: FractalMemory):
    await fractal_memory.session_start("test")
    mem = await fractal_memory.store("Temporary", domain="test")
    assert mem is not None

    deleted = await fractal_memory.delete(mem.id)
    assert deleted is True
    assert await fractal_memory.get(mem.id) is None
    await fractal_memory.session_end()


async def test_task_management(fractal_memory: FractalMemory):
    task = await fractal_memory.add_task("Fix the bug", priority=1)
    assert task.description == "Fix the bug"

    tasks = await fractal_memory.list_tasks()
    assert len(tasks) == 1

    await fractal_memory.complete_task(task.id)
    tasks = await fractal_memory.list_tasks()
    assert tasks[0].status.value == "completed"


async def test_list_domains(fractal_memory: FractalMemory):
    await fractal_memory.session_start("test")
    await fractal_memory.store("A", domain="alpha")
    await fractal_memory.store("B", domain="beta")
    domains = await fractal_memory.list_domains()
    assert len(domains) == 2
    names = {d.name for d in domains}
    assert "alpha" in names
    assert "beta" in names
    await fractal_memory.session_end()


async def test_store_gated_out_threshold_2(tmp_path):
    """With threshold=2 and only 1 signal, content is gated to waiting room."""
    from fractal_memory.config import FractalConfig

    config = FractalConfig(
        db_path=tmp_path / "test.db",
        gate_signal_count=2,
    )

    import json
    from unittest.mock import AsyncMock
    from fractal_memory.llm import LLMProvider
    from fractal_memory.embeddings import EmbeddingProvider
    import numpy as np

    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value=json.dumps({
        "l0_tag": "test:tag",
        "l1_label": "test-label",
        "l2_summary": "summary",
        "l3_full": "full",
    }))

    emb = AsyncMock(spec=EmbeddingProvider)

    async def _embed(text):
        rng = np.random.RandomState(hash(text) % 2**31)
        v = rng.randn(384).astype(np.float32)
        return (v / np.linalg.norm(v)).tolist()

    emb.embed = AsyncMock(side_effect=_embed)
    emb.model_name = "mock"
    emb.dimension = 384

    fm = FractalMemory(config, llm=llm, embeddings=emb)
    await fm.initialize()
    try:
        await fm.session_start(domain="test")
        result = await fm.store("test", domain="test", signals=[Signal.NOVELTY])
        assert result is None  # Gated out — only 1 signal, threshold is 2
    finally:
        await fm.close()


async def test_waiting_room_promotion_across_sessions(tmp_path):
    """Content in waiting room gets promoted when similar content arrives later."""
    from fractal_memory.config import FractalConfig
    import json
    import numpy as np
    from unittest.mock import AsyncMock
    from fractal_memory.llm import LLMProvider
    from fractal_memory.embeddings import EmbeddingProvider

    config = FractalConfig(
        db_path=tmp_path / "wr_test.db",
        gate_signal_count=2,  # threshold=2, so single signal goes to waiting room
    )

    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value=json.dumps({
        "l0_tag": "test:tag",
        "l1_label": "test-label",
        "l2_summary": "summary",
        "l3_full": "full context",
    }))

    # Use a fixed embedding so both stores match semantically
    fixed_vec = np.random.RandomState(42).randn(384).astype(np.float32)
    fixed_vec = (fixed_vec / np.linalg.norm(fixed_vec)).tolist()

    emb = AsyncMock(spec=EmbeddingProvider)
    emb.embed = AsyncMock(return_value=fixed_vec)
    emb.model_name = "mock"
    emb.dimension = 384

    fm = FractalMemory(config, llm=llm, embeddings=emb)
    await fm.initialize()
    try:
        # Session 1: store with 1 signal → goes to waiting room
        await fm.session_start("test")
        result1 = await fm.store("user prefers Python", domain="test", signals=[Signal.NOVELTY])
        assert result1 is None  # gated out to waiting room
        await fm.session_end()

        # Session 2: store similar content with 1 signal → matches waiting room entry → promoted
        await fm.session_start("test")
        result2 = await fm.store("user likes Python", domain="test", signals=[Signal.NOVELTY])
        assert result2 is not None  # promoted from waiting room
        assert result2.domain == "test"
        await fm.session_end()
    finally:
        await fm.close()


async def test_lifecycle_progression_across_sessions(fractal_memory: FractalMemory):
    """Memory progresses probation → confirmed over multiple retrievals."""
    await fractal_memory.session_start("test")
    mem = await fractal_memory.store("Important pattern", domain="test")
    assert mem is not None

    # Retrieve twice (confirmation_threshold=2)
    await fractal_memory.retrieve("pattern", domain="test")
    await fractal_memory.retrieve("Important", domain="test")
    await fractal_memory.session_end()

    fetched = await fractal_memory.get(mem.id)
    assert fetched.lifecycle == LifecycleStatus.CONFIRMED


async def test_buffer_persistence_within_session(fractal_memory: FractalMemory):
    """Recently stored memories remain in buffer across retrievals."""
    await fractal_memory.session_start("test")

    stored_ids = []
    for i in range(5):
        m = await fractal_memory.store(f"Memory {i}", domain="test")
        if m:
            stored_ids.append(m.id)

    # Retrieve something unrelated — buffer should still have recent stores
    result = await fractal_memory.retrieve("completely different topic", domain="test")

    # The just_written and recent buffers should still contain our stored memories
    buffer_ids = fractal_memory._buffer.get_buffer_ids()
    # At least some of the stored memories should be in the buffer
    overlap = set(stored_ids) & set(buffer_ids)
    assert len(overlap) >= 3  # just_written holds 3, overflow goes to recent

    await fractal_memory.session_end()


async def test_pressure_response_integration(fractal_memory: FractalMemory):
    """With many memories and tight budget, L3 count is reduced."""
    from fractal_memory.config import FractalConfig

    await fractal_memory.session_start("test")

    # Store many memories
    for i in range(30):
        await fractal_memory.store(f"Memory about topic {i} with details", domain="test")

    # Retrieve with a very tight budget
    result = await fractal_memory.retrieve("topic", domain="test", token_budget=10)
    # Pressure response should have kicked in
    # With budget=10 tokens, very few L3 memories can fit
    assert result.token_budget_total == 10

    await fractal_memory.session_end()
