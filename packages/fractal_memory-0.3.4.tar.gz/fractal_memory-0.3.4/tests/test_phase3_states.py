"""Tests for fractal_memory.states — SystemState / SystemStateManager (Phase 3)."""

from __future__ import annotations

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.states import SystemState, SystemStateManager


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(
        stress_miss_threshold=3,
        stress_correction_threshold=2,
        stress_recovery_successes=3,
        domain_sparse_memory_threshold=50,
        domain_sparse_session_threshold=10,
    )


@pytest.fixture
def sm(cfg: FractalConfig) -> SystemStateManager:
    return SystemStateManager(cfg)


# ---------------------------------------------------------------------------
# Initial state
# ---------------------------------------------------------------------------

def test_initial_state_is_flow(sm: SystemStateManager) -> None:
    assert sm.current_state == SystemState.FLOW


def test_current_state_str_is_string(sm: SystemStateManager) -> None:
    assert sm.current_state_str == "flow"


# ---------------------------------------------------------------------------
# STRESS triggers
# ---------------------------------------------------------------------------

def test_stress_triggered_by_consecutive_misses(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.STRESS


def test_stress_requires_exact_threshold(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold - 1):
        sm.on_failed_retrieval()
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.FLOW


def test_stress_triggered_by_corrections(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_correction_threshold):
        sm.on_correction()
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.STRESS


# ---------------------------------------------------------------------------
# CURIOSITY triggers
# ---------------------------------------------------------------------------

def test_curiosity_triggered_by_sparse_domain(sm: SystemStateManager, cfg: FractalConfig) -> None:
    # Both sparse: memory_count < 50, session_count < 10
    state = sm.evaluate({}, domain_memory_count=5, domain_session_count=2)
    assert state == SystemState.CURIOSITY


def test_curiosity_triggered_by_high_query_variance(sm: SystemStateManager) -> None:
    state = sm.evaluate({"query_variance": 0.8}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.CURIOSITY


def test_curiosity_not_triggered_by_sparse_memory_alone(sm: SystemStateManager, cfg: FractalConfig) -> None:
    # Only memory sparse, sessions above threshold → not CURIOSITY
    state = sm.evaluate({}, domain_memory_count=5, domain_session_count=15)
    assert state == SystemState.FLOW


def test_curiosity_not_triggered_by_sparse_sessions_alone(sm: SystemStateManager, cfg: FractalConfig) -> None:
    state = sm.evaluate({}, domain_memory_count=100, domain_session_count=2)
    assert state == SystemState.FLOW


# ---------------------------------------------------------------------------
# Precedence rules
# ---------------------------------------------------------------------------

def test_curiosity_wins_over_stress_in_sparse_domain(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    # Sparse domain — CURIOSITY should win
    state = sm.evaluate({}, domain_memory_count=5, domain_session_count=2)
    assert state == SystemState.CURIOSITY


def test_stress_wins_over_curiosity_in_mature_domain(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    # High query variance, but mature domain → STRESS wins
    state = sm.evaluate({"query_variance": 0.9}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.STRESS


# ---------------------------------------------------------------------------
# Recovery
# ---------------------------------------------------------------------------

def test_stress_recovery_after_successes(sm: SystemStateManager, cfg: FractalConfig) -> None:
    # Enter STRESS
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert sm.current_state == SystemState.STRESS

    # Recover
    for _ in range(cfg.stress_recovery_successes):
        sm.on_successful_retrieval()
    assert sm.current_state == SystemState.FLOW


def test_stress_not_recovered_before_threshold(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    sm.evaluate({}, domain_memory_count=200, domain_session_count=20)

    for _ in range(cfg.stress_recovery_successes - 1):
        sm.on_successful_retrieval()
    assert sm.current_state == SystemState.STRESS


def test_successful_retrieval_resets_miss_counter(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold - 1):
        sm.on_failed_retrieval()
    sm.on_successful_retrieval()
    # Should not be in stress since miss counter was reset
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.FLOW


# ---------------------------------------------------------------------------
# Parameter multipliers
# ---------------------------------------------------------------------------

def test_flow_multipliers_correct(sm: SystemStateManager) -> None:
    sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    mults = sm.get_parameter_multipliers()
    assert mults["gate_strictness"] == 1.3
    assert mults["activation_decay"] == 1.0
    assert mults["buffer_soft_cap"] == 1.0
    assert mults["pruning_ttl"] == 1.0
    assert mults["retrieval_breadth"] == 0.8
    assert mults["consolidation_aggression"] == 1.3


def test_stress_multipliers_correct(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    mults = sm.get_parameter_multipliers()
    assert mults["gate_strictness"] == 0.7
    assert mults["activation_decay"] == 0.6
    assert mults["buffer_soft_cap"] == 1.5
    assert mults["retrieval_breadth"] == 1.3
    assert mults["consolidation_aggression"] == 1.0


def test_curiosity_multipliers_correct(sm: SystemStateManager) -> None:
    sm.evaluate({}, domain_memory_count=5, domain_session_count=2)
    mults = sm.get_parameter_multipliers()
    assert mults["gate_strictness"] == 0.5
    assert mults["activation_decay"] == 0.8
    assert mults["pruning_ttl"] == 2.0
    assert mults["retrieval_breadth"] == 1.5
    assert mults["consolidation_aggression"] == 0.7


def test_all_multiplier_keys_present(sm: SystemStateManager) -> None:
    expected_keys = {
        "gate_strictness", "activation_decay", "buffer_soft_cap",
        "pruning_ttl", "retrieval_breadth", "consolidation_aggression",
    }
    mults = sm.get_parameter_multipliers()
    assert set(mults.keys()) == expected_keys


# ---------------------------------------------------------------------------
# Session reset
# ---------------------------------------------------------------------------

def test_reset_session_clears_corrections(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_correction_threshold - 1):
        sm.on_correction()
    sm.reset_session()
    # After reset, correction counter = 0 → not enough for STRESS
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    assert state == SystemState.FLOW


def test_reset_session_clears_miss_counter(sm: SystemStateManager, cfg: FractalConfig) -> None:
    for _ in range(cfg.stress_miss_threshold):
        sm.on_failed_retrieval()
    sm.reset_session()
    state = sm.evaluate({}, domain_memory_count=200, domain_session_count=20)
    # Miss counter resets across sessions (Issue #16) — back to FLOW
    assert state == SystemState.FLOW
