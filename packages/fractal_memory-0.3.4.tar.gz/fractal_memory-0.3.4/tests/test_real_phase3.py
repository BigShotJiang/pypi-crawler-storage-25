"""Phase 3 real integration tests — real storage, real subsystems, mock LLM only.

Tests apoptosis, dreaming, maintenance, and niche construction with real storage
and real association networks instead of mocks.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.apoptosis import ApoptosisManager
from fractal_memory.associations import AssociationNetwork
from fractal_memory.config import FractalConfig
from fractal_memory.dreaming import DreamingEngine
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.llm import LLMProvider
from fractal_memory.maintenance import MaintenanceScheduler
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.niche import NicheConstructor
from fractal_memory.scar import ScarTissueManager
from fractal_memory.storage import Storage
from fractal_memory.zoom import ZoomGenerator


# ── Helpers ────────────────────────────────────────────────────────────

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Phase 3 test summary."
        if "synthesize" in prompt.lower() or "recombine" in prompt.lower():
            return json.dumps({
                "synthesis": "A recombined memory from dreaming.",
                "coherence": 0.8,
            })
        if "decompose" in prompt.lower() or "fragment" in prompt.lower():
            return json.dumps({
                "fragments": [
                    {"text": "Fragment 1 from decomposition", "importance": 0.6},
                    {"text": "Fragment 2 from decomposition", "importance": 0.4},
                ],
            })
        return json.dumps({
            "l0_tag": "p3:test",
            "l1_label": "phase3-test",
            "l2_summary": "A phase 3 test memory.",
            "l3_full": "Phase 3 test memory with full context.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock(spec=EmbeddingProvider)

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def p3_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "phase3_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        # Lower thresholds for testability
        apoptosis_min_vitality=0.1,
        apoptosis_contradiction_limit=3,
        apoptosis_context_drift_threshold=0.3,
        scar_ttl_sessions=5,
    )


@pytest.fixture
async def p3_storage(p3_config: FractalConfig):
    s = Storage(p3_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
def mock_embeddings():
    return _make_mock_embeddings()


@pytest.fixture
def mock_llm():
    return _make_mock_llm()


def _make_memory(domain: str = "test", text: str = "test", **overrides) -> Memory:
    """Helper to create a Memory with sensible defaults."""
    now = datetime.utcnow()
    defaults = dict(
        id=uuid4(), domain=domain, created_at=now, updated_at=now,
        context={}, l0_tag="t", l1_label="l", l2_summary="s",
        l3_full="f", l4_raw=text,
        embedding=_deterministic_embed(text), embedding_model="mock",
        intensity=0.5,
    )
    defaults.update(overrides)
    return Memory(**defaults)


# ══════════════════════════════════════════════════════════════════════
# APOPTOSIS — real storage tests
# ══════════════════════════════════════════════════════════════════════

class TestApoptosisRealStorage:
    @pytest.mark.asyncio
    async def test_compute_vitality_from_real_data(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """Vitality should reflect actual retrieval density."""
        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        scars = ScarTissueManager(p3_storage, mock_embeddings, p3_config)
        apoptosis = ApoptosisManager(
            p3_storage, associations, scars, mock_embeddings, mock_llm, p3_config
        )

        # Store a memory with known retrieval count
        mem = _make_memory(retrieval_count=10, miss_count=2)
        await p3_storage.store_memory(mem)

        vitality = apoptosis.compute_vitality(mem)
        assert 0.0 <= vitality <= 1.0

    @pytest.mark.asyncio
    async def test_contradiction_ceiling_triggers_apoptosis(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """A memory corrected too many times should trigger apoptosis."""
        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        scars = ScarTissueManager(p3_storage, mock_embeddings, p3_config)
        apoptosis = ApoptosisManager(
            p3_storage, associations, scars, mock_embeddings, mock_llm, p3_config
        )

        # Memory corrected 5 times (above contradiction_limit=3)
        text = "a memory that was corrected many times"
        mem = _make_memory(text=text, reconsolidation_count=5)
        await p3_storage.store_memory(mem)

        # Use the memory's own embedding as context to avoid context_drift trigger
        context_emb = np.array(mem.embedding, dtype=np.float32)
        decision = await apoptosis.check_apoptosis(mem, context_emb)
        assert decision.should_apoptose, "Memory with 5 corrections should trigger apoptosis"
        assert "contradict" in decision.reason.lower()

    @pytest.mark.asyncio
    async def test_healthy_memory_survives_apoptosis_check(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """A healthy, frequently-retrieved memory should NOT be flagged."""
        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        scars = ScarTissueManager(p3_storage, mock_embeddings, p3_config)
        apoptosis = ApoptosisManager(
            p3_storage, associations, scars, mock_embeddings, mock_llm, p3_config
        )

        mem = _make_memory(
            text="healthy memory about Python",
            retrieval_count=50, miss_count=0,
            vitality=0.9, reconsolidation_count=0,
        )
        await p3_storage.store_memory(mem)

        # Use a context embedding close to the memory's own embedding
        context_emb = np.array(mem.embedding, dtype=np.float32)
        decision = await apoptosis.check_apoptosis(mem, context_emb)
        assert not decision.should_apoptose, "Healthy memory should survive"

    @pytest.mark.asyncio
    async def test_execute_apoptosis_removes_memory(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """Executing apoptosis should delete the memory from storage."""
        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        scars = ScarTissueManager(p3_storage, mock_embeddings, p3_config)
        zoom = ZoomGenerator(mock_llm)
        apoptosis = ApoptosisManager(
            p3_storage, associations, scars, mock_embeddings, mock_llm, p3_config,
            zoom=zoom,
        )

        mem = _make_memory(text="memory to delete via apoptosis")
        await p3_storage.store_memory(mem)

        report = await apoptosis.execute_apoptosis(mem, "obsolescence")
        assert report.memory_id == mem.id

        # Memory should be gone
        fetched = await p3_storage.get_memory(mem.id)
        assert fetched is None, "Memory should be deleted after apoptosis"

    @pytest.mark.asyncio
    async def test_batch_check_across_domain(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """batch_check should evaluate all memories in a domain."""
        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        scars = ScarTissueManager(p3_storage, mock_embeddings, p3_config)
        apoptosis = ApoptosisManager(
            p3_storage, associations, scars, mock_embeddings, mock_llm, p3_config
        )

        # Store a mix of healthy and unhealthy memories
        for i in range(5):
            healthy = _make_memory(
                domain="batch-test", text=f"batch context related healthy {i}",
                retrieval_count=20, vitality=0.8,
            )
            await p3_storage.store_memory(healthy)

        for i in range(3):
            unhealthy = _make_memory(
                domain="batch-test", text=f"batch context related unhealthy {i}",
                reconsolidation_count=10, vitality=0.01,
            )
            await p3_storage.store_memory(unhealthy)

        context_emb = np.array(_deterministic_embed("batch context related"), dtype=np.float32)
        decisions = await apoptosis.batch_check("batch-test", context_emb)
        # batch_check only returns decisions for memories that trigger apoptosis,
        # not all evaluated memories — so count may be < 8
        assert len(decisions) >= 1, "At least some memories should trigger apoptosis"
        assert all(d.should_apoptose for d in decisions), "All returned decisions should be apoptosis-positive"


# ══════════════════════════════════════════════════════════════════════
# DREAMING — real storage + associations
# ══════════════════════════════════════════════════════════════════════

class TestDreamingRealStorage:
    @pytest.mark.asyncio
    async def test_slow_wave_decays_real_edges(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """Slow-wave phase should actually decay edge weights in storage."""
        from fractal_memory.bandits import ContextualBandit

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        bandits = ContextualBandit(p3_config)
        dreaming = DreamingEngine(
            p3_storage, associations, mock_embeddings, mock_llm,
            bandits, p3_config,
        )

        # Create two memories and an association edge
        m1 = _make_memory(text="dream memory 1")
        m2 = _make_memory(text="dream memory 2")
        await p3_storage.store_memory(m1)
        await p3_storage.store_memory(m2)
        await p3_storage.store_association(m1.id, m2.id, weight=0.5)

        # Run slow-wave
        report = await dreaming._slow_wave()
        assert report.edges_decayed >= 0  # Should process edges without error

    @pytest.mark.asyncio
    async def test_dream_cycle_completes(
        self, p3_config, p3_storage, mock_embeddings, mock_llm
    ):
        """Full dream cycle should complete without errors."""
        from fractal_memory.bandits import ContextualBandit

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        bandits = ContextualBandit(p3_config)
        dreaming = DreamingEngine(
            p3_storage, associations, mock_embeddings, mock_llm,
            bandits, p3_config,
        )

        # Store some memories to dream about
        mem_ids = []
        for i in range(10):
            m = _make_memory(
                text=f"dreamable memory {i}",
                retrieval_count=i + 1,
            )
            await p3_storage.store_memory(m)
            mem_ids.append(m.id)

        # Add some edges
        for i in range(len(mem_ids) - 1):
            await p3_storage.store_association(mem_ids[i], mem_ids[i + 1], weight=0.3)

        report = await dreaming.dream_cycle(mem_ids[:5])
        assert report.slow_wave is not None
        assert report.rem is not None
        assert report.duration_seconds >= 0


# ══════════════════════════════════════════════════════════════════════
# NICHE CONSTRUCTION — real storage + associations
# ══════════════════════════════════════════════════════════════════════

class TestNicheRealStorage:
    @pytest.mark.asyncio
    async def test_co_retrieval_strengthens_edges(
        self, p3_config, p3_storage, mock_embeddings
    ):
        """Positive co-retrieval outcome should increase edge weight."""
        from fractal_memory.domains import DomainManager

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        domains = DomainManager(p3_storage, p3_config)
        niche = NicheConstructor(p3_storage, associations, domains, p3_config)

        # Create two memories with an edge
        m1 = _make_memory(domain="niche-test", text="niche mem 1")
        m2 = _make_memory(domain="niche-test", text="niche mem 2")
        await p3_storage.store_memory(m1)
        await p3_storage.store_memory(m2)
        await p3_storage.store_association(m1.id, m2.id, weight=0.3)

        # Positive co-retrieval
        await niche.on_co_retrieval_outcome(
            [m1.id, m2.id], "positive", "niche-test"
        )

        # Edge weight should have increased
        edges = await p3_storage.get_associations(m1.id)
        if edges:
            new_weight = edges[0][1] if isinstance(edges[0], tuple) else edges[0].weight
            assert new_weight >= 0.3, "Weight should not decrease on positive outcome"

    @pytest.mark.asyncio
    async def test_co_retrieval_weakens_on_negative(
        self, p3_config, p3_storage, mock_embeddings
    ):
        """Negative co-retrieval outcome should decrease or not increase edge weight."""
        from fractal_memory.domains import DomainManager

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        domains = DomainManager(p3_storage, p3_config)
        niche = NicheConstructor(p3_storage, associations, domains, p3_config)

        m1 = _make_memory(domain="niche-test", text="neg mem 1")
        m2 = _make_memory(domain="niche-test", text="neg mem 2")
        await p3_storage.store_memory(m1)
        await p3_storage.store_memory(m2)
        await p3_storage.store_association(m1.id, m2.id, weight=0.5)

        await niche.on_co_retrieval_outcome(
            [m1.id, m2.id], "negative", "niche-test"
        )

        edges = await p3_storage.get_associations(m1.id)
        if edges:
            new_weight = edges[0][1] if isinstance(edges[0], tuple) else edges[0].weight
            assert new_weight <= 0.5, "Weight should not increase on negative outcome"

    @pytest.mark.asyncio
    async def test_detect_domain_clusters(
        self, p3_config, p3_storage, mock_embeddings
    ):
        """Louvain detection should run without errors on a small graph."""
        from fractal_memory.domains import DomainManager

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        domains = DomainManager(p3_storage, p3_config)
        niche = NicheConstructor(p3_storage, associations, domains, p3_config)

        # Create a small cluster of memories
        mems = []
        for i in range(15):
            m = _make_memory(domain="cluster-test", text=f"cluster memory {i}")
            await p3_storage.store_memory(m)
            mems.append(m)

        # Create dense internal edges
        for i in range(len(mems)):
            for j in range(i + 1, min(i + 3, len(mems))):
                await p3_storage.store_association(
                    mems[i].id, mems[j].id, weight=0.6
                )

        proposals = await niche.detect_domain_clusters()
        # Should return a list (possibly empty if graph too small for Louvain)
        assert isinstance(proposals, list)

    @pytest.mark.asyncio
    async def test_niche_health_for_domain(
        self, p3_config, p3_storage, mock_embeddings
    ):
        """get_niche_health should return valid metrics."""
        from fractal_memory.domains import DomainManager

        associations = AssociationNetwork(p3_storage, mock_embeddings, p3_config)
        domains = DomainManager(p3_storage, p3_config)
        niche = NicheConstructor(p3_storage, associations, domains, p3_config)

        for i in range(5):
            m = _make_memory(domain="health-test", text=f"health mem {i}")
            await p3_storage.store_memory(m)

        health = await niche.get_niche_health("health-test")
        assert health.domain == "health-test"
        assert health.memory_count == 5


# ══════════════════════════════════════════════════════════════════════
# FULL PIPELINE — maintenance with real FractalMemory
# ══════════════════════════════════════════════════════════════════════

class TestMaintenancePipeline:
    @pytest.mark.asyncio
    async def test_session_end_triggers_maintenance(self, p3_config: FractalConfig):
        """session_end should run maintenance hooks without errors."""
        fm = FractalMemory(p3_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            await fm.session_start("test")
            for i in range(10):
                await fm.store(f"Maintenance pipeline test memory {i}")
            for i in range(5):
                await fm.retrieve(f"pipeline query {i}", domain="test")

            summary = await fm.session_end()
            assert summary is not None
        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_multi_session_maintenance_cycle(self, p3_config: FractalConfig):
        """Three sessions should trigger maintenance and not corrupt data."""
        fm = FractalMemory(p3_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            for session_num in range(3):
                await fm.session_start("test")
                for i in range(5):
                    await fm.store(
                        f"Session {session_num} memory {i}",
                    )
                await fm.retrieve("test query", domain="test")
                await fm.session_end()

            # Verify data integrity after 3 maintenance cycles
            await fm.session_start("test")
            stats = await fm.get_stats()
            assert stats["overall"]["total_memories"] >= 15
            assert stats["overall"]["total_sessions"] >= 3
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_health_report_after_operations(self, p3_config: FractalConfig):
        """health() should return a valid report after real operations."""
        fm = FractalMemory(p3_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            await fm.session_start("test")
            for i in range(10):
                await fm.store(f"Health report test memory {i}")
            for i in range(5):
                await fm.retrieve(f"health query {i}", domain="test")

            report = await fm.health()
            assert report is not None
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()
