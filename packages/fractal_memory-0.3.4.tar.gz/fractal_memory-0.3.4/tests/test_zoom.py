"""Tests for zoom level generation."""

import json
from unittest.mock import AsyncMock

import pytest

from fractal_memory.llm import LLMProvider, LLMUnavailableError
from fractal_memory.zoom import ZoomGenerator, ZoomLevels


@pytest.fixture
def zoom_gen(mock_llm):
    return ZoomGenerator(mock_llm)


async def test_successful_zoom_generation(zoom_gen):
    result = await zoom_gen.generate("User prefers Python for backend", domain="test")
    assert isinstance(result, ZoomLevels)
    assert result.l0_tag == "test:tag"
    assert result.l1_label == "test-memory-label"
    assert result.l2_summary == "A test memory summary for testing."
    assert result.l3_full == "A test memory with full context for testing purposes."


async def test_fallback_on_llm_unavailable():
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(side_effect=LLMUnavailableError("offline"))
    gen = ZoomGenerator(llm)
    result = await gen.generate("User prefers Python for backend", domain="test")
    assert isinstance(result, ZoomLevels)
    assert len(result.l0_tag) > 0
    assert len(result.l1_label) > 0
    assert len(result.l2_summary) > 0
    assert len(result.l3_full) > 0


async def test_fallback_on_malformed_json():
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value="this is not json at all")
    gen = ZoomGenerator(llm)
    result = await gen.generate("User prefers Python", domain="test")
    assert isinstance(result, ZoomLevels)
    # Should use fallback heuristic
    assert "user" in result.l1_label.lower() or "prefers" in result.l1_label.lower()


async def test_partial_json_uses_fallback_for_missing():
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value=json.dumps({
        "l0_tag": "pref:lang",
        "l1_label": "user-prefers-python",
    }))
    gen = ZoomGenerator(llm)
    result = await gen.generate("User prefers Python for backend", domain="test")
    assert result.l0_tag == "pref:lang"
    assert result.l1_label == "user-prefers-python"
    # l2, l3 should be filled by fallback
    assert len(result.l2_summary) > 0
    assert len(result.l3_full) > 0


async def test_markdown_fence_stripping():
    llm = AsyncMock(spec=LLMProvider)
    response = '```json\n{"l0_tag": "db:cfg", "l1_label": "db-config", "l2_summary": "summary", "l3_full": "full"}\n```'
    llm.complete = AsyncMock(return_value=response)
    gen = ZoomGenerator(llm)
    result = await gen.generate("Database config", domain="test")
    assert result.l0_tag == "db:cfg"


async def test_zoom_levels_named_tuple():
    z = ZoomLevels(l0_tag="a", l1_label="b", l2_summary="c", l3_full="d")
    assert z[0] == "a"
    assert z.l0_tag == "a"
    l0, l1, l2, l3 = z
    assert l0 == "a"


async def test_zoom_levels_respect_token_budget_hints():
    """Fallback zoom levels should respect approximate token budget constraints."""
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(side_effect=LLMUnavailableError("offline"))
    gen = ZoomGenerator(llm)

    long_text = "This is a very long memory text. " * 100  # ~700 words
    result = await gen.generate(long_text, domain="test")

    # L0 should be very short (~2 tokens)
    assert len(result.l0_tag.split()) <= 5
    # L1 should be ~10 words
    assert len(result.l1_label.split("-")) <= 15
    # L2 should be truncated (not the full text)
    assert len(result.l2_summary) <= 200
    # L3 should be truncated to ~500 chars
    assert len(result.l3_full) <= 600
