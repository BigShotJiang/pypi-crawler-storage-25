"""Lifecycle simulation — multi-session realistic usage: lifecycle promotion, graph growth, health.

Simulates realistic multi-session usage patterns to verify lifecycle transitions,
association graph growth, and health metrics behave correctly over time.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Lifecycle simulation session summary."
        return json.dumps({
            "l0_tag": "lifecycle:sim",
            "l1_label": "lifecycle-sim",
            "l2_summary": "Lifecycle simulation memory.",
            "l3_full": "Lifecycle simulation memory full context.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def lifecycle_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "lifecycle_sim.db",
        gate_signal_count=1,
        # Speed up lifecycle for testing
        confirmation_threshold=2,
        permanence_threshold=5,
        pruning_ttl_sessions=3,
        llm_max_calls_per_session=50000,
        enable_llm_judge=False,  # Skip to speed up session_end
    )


# ── Multi-session simulation ─────────────────────────────────────────


class TestLifecycleSimulation:
    @pytest.mark.asyncio
    async def test_10_session_lifecycle_progression(self, lifecycle_config: FractalConfig):
        """10 sessions with repeated retrieval should promote memories through lifecycle."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        stored_ids = []

        try:
            # Session 1: Store memories
            await fm.session_start("sim")
            for i in range(5):
                mem = await fm.store(f"Persistent memory {i} about topic alpha", domain="sim")
                if mem:
                    stored_ids.append(mem.id)
            await fm.session_end()

            # Sessions 2-10: Retrieve to promote lifecycle
            for session_num in range(2, 11):
                await fm.session_start("sim")
                # Retrieve each memory to bump retrieval_count
                for sid in stored_ids:
                    await fm.retrieve(f"topic alpha query {sid}", domain="sim")
                await fm.session_end()

            # Verify some memories got promoted
            promoted_count = 0
            for sid in stored_ids:
                mem = await fm.get(sid)
                if mem and mem.lifecycle != LifecycleStatus.PROBATION:
                    promoted_count += 1
            # With confirmation_threshold=2 and 9 retrieval sessions, at least some should promote
            assert promoted_count > 0, (
                f"Expected at least 1 promoted memory after 9 retrieval sessions "
                f"with confirmation_threshold=2, got {promoted_count}"
            )

        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_pruning_removes_unused_memories(self, lifecycle_config: FractalConfig):
        """Memories never retrieved should eventually be pruned."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            # Session 1: Store a memory
            await fm.session_start("prune-test")
            mem = await fm.store("Memory that will never be retrieved")
            assert mem is not None
            mem_id = mem.id
            await fm.session_end()

            # Run enough sessions to trigger pruning (pruning_ttl=3)
            for i in range(5):
                await fm.session_start("prune-test")
                await fm.store(f"Other memory {i}")  # Keep the session non-empty
                await fm.session_end()

            # The original memory might be pruned
            fetched = await fm.get(mem_id)
            # It may or may not be pruned — either way, no crash
            assert fetched is None or fetched.id == mem_id

        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_pin_prevents_pruning(self, lifecycle_config: FractalConfig):
        """Pinned memories should survive pruning."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            await fm.session_start("pin-test")
            mem = await fm.store("Memory that will be pinned")
            assert mem is not None
            await fm.pin(mem.id)
            await fm.session_end()

            # Run sessions to trigger pruning
            for i in range(5):
                await fm.session_start("pin-test")
                await fm.session_end()

            # Pinned memory should survive
            fetched = await fm.get(mem.id)
            assert fetched is not None
            assert fetched.lifecycle == LifecycleStatus.PERMANENT

        finally:
            await fm.close()


# ── Graph growth ─────────────────────────────────────────────────────


class TestGraphGrowth:
    @pytest.mark.asyncio
    async def test_associations_grow_with_co_retrieval(self, lifecycle_config: FractalConfig):
        """Co-retrieved memories should form association edges."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            await fm.session_start("graph-test")
            # Store several related memories
            for i in range(5):
                await fm.store(f"Related memory about Python programming topic {i}")

            # Retrieve to trigger co-retrieval associations
            for i in range(3):
                await fm.retrieve("Python programming", domain="graph-test")

            await fm.session_end()

            stats = await fm.get_stats()
            # Associations may or may not form depending on retrieval results
            assert "associations" in stats

        finally:
            await fm.close()


# ── Health report ────────────────────────────────────────────────────


class TestHealthAfterSimulation:
    @pytest.mark.asyncio
    async def test_health_report_after_sessions(self, lifecycle_config: FractalConfig):
        """Health report after multiple sessions should have valid values."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            for i in range(3):
                await fm.session_start("health-test")
                await fm.store(f"Health test memory {i}")
                await fm.retrieve("health query", domain="health-test")
                await fm.session_end()

            report = await fm.health()
            assert 0.0 <= report.retrieval_hit_rate <= 1.0
            assert report.scar_count >= 0
            assert report.chronic_memories_count >= 0
            assert report.system_state in ("flow", "stress", "curiosity")

        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_health_report_empty_system(self, lifecycle_config: FractalConfig):
        """Health report on empty system should return valid defaults."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            report = await fm.health()
            assert report.retrieval_hit_rate == 0.0
            assert report.scar_count == 0

        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_stats_after_simulation(self, lifecycle_config: FractalConfig):
        """get_stats() after simulation should return coherent numbers."""
        fm = FractalMemory(lifecycle_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            await fm.session_start("stats-test")
            for i in range(3):
                await fm.store(f"Stats memory {i}")
            await fm.session_end()

            stats = await fm.get_stats()
            assert stats["overall"]["total_memories"] >= 3
            assert stats["overall"]["total_sessions"] >= 1

        finally:
            await fm.close()
