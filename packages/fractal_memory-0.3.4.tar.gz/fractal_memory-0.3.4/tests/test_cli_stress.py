"""Comprehensive CLI stress tests — edge cases, error paths, boundary inputs for all 21 commands."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from click.testing import CliRunner

from fractal_memory.cli import cli


# ---------------------------------------------------------------------------
# Fake data classes (reused from test_phase3_cli pattern)
# ---------------------------------------------------------------------------


@dataclass
class _FakeMemory:
    id: uuid.UUID
    domain: str = "test"
    l0_tag: str = "concept"
    l1_label: str = "test label"
    l2_summary: str = "test summary text"
    l3_full: str = "full text content"
    lifecycle: str = "confirmed"
    intensity: float = 0.5
    vitality: float = 0.8
    chronic_score: float = 0.3
    retrieval_count: int = 5
    miss_count: int = 1
    created_at: datetime = None  # type: ignore[assignment]
    updated_at: datetime = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime(2025, 1, 1)
        if self.updated_at is None:
            self.updated_at = datetime(2025, 1, 2)


@dataclass
class _FakeLifecycleEnum:
    """Fake lifecycle with .value attribute."""
    value: str = "confirmed"


@dataclass
class _FakeExportMemory:
    """Memory with lifecycle as an object with .value."""
    id: uuid.UUID
    domain: str = "test"
    l0_tag: str = "concept"
    l1_label: str = "Export Label"
    l2_summary: str = "Export summary"
    l3_full: str = "Full export text"
    lifecycle: Any = None
    intensity: float = 0.5
    vitality: float = 0.8
    retrieval_count: int = 3
    created_at: datetime = None  # type: ignore[assignment]
    updated_at: datetime = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.lifecycle is None:
            self.lifecycle = _FakeLifecycleEnum()
        if self.created_at is None:
            self.created_at = datetime(2025, 1, 1)
        if self.updated_at is None:
            self.updated_at = datetime(2025, 1, 2)


@dataclass
class _FakeRetrievalResult:
    l3_memories: list[Any]
    l2_memories: list[Any]
    token_budget_used: int = 500
    token_budget_total: int = 1000


@dataclass
class _FakeSessionContext:
    session: Any
    bootstrap_memories: list[Any]


@dataclass
class _FakeSession:
    id: uuid.UUID


@dataclass
class _FakeHealthReport:
    system_state: str = "flow"
    retrieval_hit_rate: float = 0.85
    association_density: float = 2.3
    scar_count: int = 2
    morphogen_convergence: dict = None  # type: ignore[assignment]
    total_memories: dict = None  # type: ignore[assignment]
    cascade_warnings: list = None  # type: ignore[assignment]
    flagged_parameters: list = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.morphogen_convergence is None:
            self.morphogen_convergence = {"converged": True}
        if self.total_memories is None:
            self.total_memories = {"test": 50}
        if self.cascade_warnings is None:
            self.cascade_warnings = []
        if self.flagged_parameters is None:
            self.flagged_parameters = []


@dataclass
class _FakeExplanation:
    query: str = "test query"
    system_state: str = "flow"
    bandit_arm_selected: str = "balanced"
    retrieved_memories: list = None  # type: ignore[assignment]
    suppressed_memories: list = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.retrieved_memories is None:
            self.retrieved_memories = [{"id": "abc", "score": 0.9}]
        if self.suppressed_memories is None:
            self.suppressed_memories = []


@dataclass
class _FakeWarning:
    affected_system: str = "gate"
    recommended_action: str = "loosen_gate"


@dataclass
class _FakeDomain:
    name: str
    memory_count: int
    last_active: datetime


@dataclass
class _FakeMaintenanceReport:
    tier: str
    actions_taken: dict
    duration_seconds: float = 1.5
    health_snapshot: Any = None


@dataclass
class _FakeMorphogenState:
    information_richness: float = 0.5
    retrieval_pressure: float = 0.4
    domain_density: float = 0.6


@dataclass
class _FakeCurve:
    name: str = "gate_strictness"
    midpoint: float = 0.5
    steepness: float = 5.0

    def compute(self, ms: Any) -> float:
        return 0.65


# ---------------------------------------------------------------------------
# Mock factory
# ---------------------------------------------------------------------------


def _mock_fm() -> AsyncMock:
    """Create a mock FractalMemory instance with all needed methods."""
    fm = AsyncMock()
    fm.initialize = AsyncMock()
    fm.close = AsyncMock()

    mem = _FakeMemory(id=uuid.uuid4())
    fm.store = AsyncMock(return_value=mem)
    fm.retrieve = AsyncMock(return_value=_FakeRetrievalResult(
        l3_memories=[mem], l2_memories=[mem],
    ))

    sid = uuid.uuid4()
    fm.session_start = AsyncMock(return_value=_FakeSessionContext(
        session=_FakeSession(id=sid), bootstrap_memories=[],
    ))
    fm.session_end = AsyncMock()

    fm.health = AsyncMock(return_value=_FakeHealthReport())
    fm.explain_last = AsyncMock(return_value=_FakeExplanation())
    fm.list_domains = AsyncMock(return_value=[
        _FakeDomain(name="test", memory_count=50, last_active=datetime.now(UTC)),
    ])
    fm.pin = AsyncMock()
    fm.unpin = AsyncMock()

    fm._storage = AsyncMock()
    fm._storage.list_memories = AsyncMock(return_value=[mem])
    fm._storage.get_memory = AsyncMock(return_value=mem)
    fm._storage.delete_memory = AsyncMock()
    fm._storage.get_summary_stats = AsyncMock(return_value={
        "memories": 100, "domains": 3, "edges": 500,
        "scars": 5, "seams": 2, "sessions": 20,
    })

    fm._morphogens = None
    fm._bandits = None
    fm._maintenance = None
    return fm


def _patch_make_fm(mock_fm: AsyncMock):
    async def fake_make_fm(db: Any, domain: Any) -> tuple[Any, str]:
        return mock_fm, domain or "test"
    return patch("fractal_memory.cli._make_fm", side_effect=fake_make_fm)


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ===========================================================================
# Group 1: store command — edge cases
# ===========================================================================


class TestStoreEdgeCases:
    def test_store_empty_text(self, runner: CliRunner) -> None:
        """Empty string as argument — Click still passes it through."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", ""])
        assert result.exit_code == 0
        assert "Stored:" in result.output

    def test_store_very_long_text(self, runner: CliRunner) -> None:
        """10K character text should be accepted."""
        fm = _mock_fm()
        long_text = "x" * 10_000
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", long_text])
        assert result.exit_code == 0
        assert "Stored:" in result.output
        fm.store.assert_called_once()
        call_args = fm.store.call_args
        assert len(call_args[0][0]) == 10_000

    def test_store_unicode_text(self, runner: CliRunner) -> None:
        """Unicode and emoji in text."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "日本語テスト 🧠✨"])
        assert result.exit_code == 0
        assert "Stored:" in result.output

    def test_store_intensity_zero(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "text", "--intensity", "0.0"])
        assert result.exit_code == 0
        fm.store.assert_called_once()
        assert fm.store.call_args[1]["intensity"] == 0.0

    def test_store_intensity_one(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "text", "--intensity", "1.0"])
        assert result.exit_code == 0
        assert fm.store.call_args[1]["intensity"] == 1.0

    def test_store_intensity_out_of_range(self, runner: CliRunner) -> None:
        """Intensity 2.0 — CLI validates and rejects with error message."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "text", "--intensity", "2.0"])
        assert result.exit_code == 2
        assert "out of range" in result.output

    def test_store_intensity_negative(self, runner: CliRunner) -> None:
        """Negative intensity — CLI validates and rejects."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "text", "--intensity", "-0.5"])
        assert result.exit_code == 2
        assert "out of range" in result.output

    def test_store_with_global_domain(self, runner: CliRunner) -> None:
        """Global --domain on the CLI group is propagated to store."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["--domain", "global-dom", "store", "text"])
        assert result.exit_code == 0
        # session_start should get the global domain
        fm.session_start.assert_called_once_with("global-dom")

    def test_store_with_global_db(self, runner: CliRunner) -> None:
        """Global --db is passed into _make_fm."""
        fm = _mock_fm()
        with _patch_make_fm(fm) as mock_make:
            result = runner.invoke(cli, ["--db", "/tmp/test.db", "store", "text"])
        assert result.exit_code == 0
        # Verify _make_fm was called with db="/tmp/test.db"
        mock_make.assert_called()
        call_args = mock_make.call_args_list[0]
        assert call_args[0][0] == "/tmp/test.db"

    def test_store_exception_in_fm(self, runner: CliRunner) -> None:
        """fm.store raises — verify friendly error message is shown."""
        fm = _mock_fm()
        fm.store = AsyncMock(side_effect=RuntimeError("storage full"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["store", "text"])
        assert result.exit_code == 1
        assert "storage full" in result.output


# ===========================================================================
# Group 1 continued: retrieve command — edge cases
# ===========================================================================


class TestRetrieveEdgeCases:
    def test_retrieve_empty_query(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["retrieve", ""])
        assert result.exit_code == 0
        assert "L3" in result.output

    def test_retrieve_unicode_query(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["retrieve", "検索クエリ 🔍"])
        assert result.exit_code == 0
        assert "L3" in result.output

    def test_retrieve_zero_budget(self, runner: CliRunner) -> None:
        """Budget 0 should pass token_budget=None (use default)."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["retrieve", "q", "--budget", "0"])
        assert result.exit_code == 0
        assert fm.retrieve.call_args[1]["token_budget"] is None

    def test_retrieve_negative_budget(self, runner: CliRunner) -> None:
        """Negative budget treated like zero (passes None)."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["retrieve", "q", "--budget", "-1"])
        assert result.exit_code == 0
        assert fm.retrieve.call_args[1]["token_budget"] is None

    def test_retrieve_no_results(self, runner: CliRunner) -> None:
        """Empty retrieval results."""
        fm = _mock_fm()
        fm.retrieve = AsyncMock(return_value=_FakeRetrievalResult(
            l3_memories=[], l2_memories=[],
        ))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["retrieve", "nothing"])
        assert result.exit_code == 0
        assert "L3 (0)" in result.output
        assert "L2 (0)" in result.output


# ===========================================================================
# Group 2: session commands
# ===========================================================================


class TestSessionEdgeCases:
    def test_session_start_default_domain(self, runner: CliRunner) -> None:
        """No --domain falls back to cwd name (via _make_fm mock returns 'test')."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["session", "start"])
        assert result.exit_code == 0
        assert "Session started" in result.output

    def test_session_start_with_global_db(self, runner: CliRunner) -> None:
        """Global --db is propagated."""
        fm = _mock_fm()
        with _patch_make_fm(fm) as mock_make:
            result = runner.invoke(cli, ["--db", "/tmp/x.db", "session", "start"])
        assert result.exit_code == 0
        call_args = mock_make.call_args_list[0]
        assert call_args[0][0] == "/tmp/x.db"

    def test_session_start_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.session_start = AsyncMock(side_effect=RuntimeError("init failed"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["session", "start"])
        assert result.exit_code == 1
        assert "init failed" in result.output

    def test_session_end_exit_code_1(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["session", "end"])
        assert result.exit_code == 1

    def test_session_end_contains_guidance(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["session", "end"])
        assert "not supported" in result.output
        assert "MCP" in result.output


# ===========================================================================
# Group 3: inspect / delete / pin / unpin
# ===========================================================================


class TestInspectEdgeCases:
    def test_inspect_valid_uuid(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["inspect", mid])
        assert result.exit_code == 0
        for field in ["ID:", "Domain:", "Lifecycle:", "Intensity:", "L0:", "L1:", "L2:", "L3:"]:
            assert field in result.output

    def test_inspect_not_found(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_memory = AsyncMock(return_value=None)
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["inspect", mid])
        assert "not found" in result.output

    def test_inspect_invalid_uuid(self, runner: CliRunner) -> None:
        """Non-UUID string — friendly error with UUID format hint."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["inspect", "not-a-uuid"])
        assert result.exit_code == 2
        assert "Invalid UUID" in result.output


class TestDeleteEdgeCases:
    def test_delete_with_yes_flag(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["delete", mid, "--yes"])
        assert result.exit_code == 0
        assert "Deleted:" in result.output

    def test_delete_without_yes_flag(self, runner: CliRunner) -> None:
        """Without --yes, CliRunner defaults to 'N' (no input), so abort."""
        fm = _mock_fm()
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["delete", mid])
        assert result.exit_code != 0 or "Aborted" in result.output

    def test_delete_invalid_uuid(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["delete", "invalid-id", "--yes"])
        assert result.exit_code == 2
        assert "Invalid UUID" in result.output

    def test_delete_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.delete_memory = AsyncMock(side_effect=RuntimeError("DB locked"))
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["delete", mid, "--yes"])
        assert result.exit_code == 1
        assert "DB locked" in result.output


class TestPinUnpinEdgeCases:
    def test_pin_valid(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["pin", mid])
        assert result.exit_code == 0
        assert "Pinned:" in result.output

    def test_pin_invalid_uuid(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["pin", "bad-uuid"])
        assert result.exit_code == 2
        assert "Invalid UUID" in result.output

    def test_pin_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.pin = AsyncMock(side_effect=ValueError("not found"))
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["pin", mid])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_unpin_valid(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["unpin", mid])
        assert result.exit_code == 0
        assert "Unpinned:" in result.output

    def test_unpin_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.unpin = AsyncMock(side_effect=RuntimeError("fail"))
        mid = str(uuid.uuid4())
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["unpin", mid])
        assert result.exit_code == 1
        assert "fail" in result.output


# ===========================================================================
# Group 4: health / explain / stats / domains
# ===========================================================================


class TestHealthEdgeCases:
    def test_health_all_fields_present(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["health"])
        assert result.exit_code == 0
        for field in ["System state:", "hit rate:", "Association density:", "Scars:", "Morphogen converged:", "Total memories:"]:
            assert field in result.output

    def test_health_with_warnings_and_flags(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        report = _FakeHealthReport()
        report.cascade_warnings = [_FakeWarning(), _FakeWarning(affected_system="bandit", recommended_action="reset")]
        report.flagged_parameters = ["gate_strictness", "retrieval_k"]
        fm.health = AsyncMock(return_value=report)
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["health"])
        assert result.exit_code == 0
        assert "CASCADE WARNINGS: 2" in result.output
        assert "gate_strictness" in result.output
        assert "retrieval_k" in result.output

    def test_health_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.health = AsyncMock(side_effect=RuntimeError("db error"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["health"])
        assert result.exit_code == 1
        assert "db error" in result.output


class TestExplainEdgeCases:
    def test_explain_all_fields(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["explain"])
        assert result.exit_code == 0
        for field in ["Query:", "State:", "Arm:", "Retrieved:", "Suppressed:"]:
            assert field in result.output

    def test_explain_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.explain_last = AsyncMock(side_effect=RuntimeError("no session"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["explain"])
        assert result.exit_code == 1
        assert "no session" in result.output


class TestStatsEdgeCases:
    def test_stats_all_keys(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["stats"])
        assert result.exit_code == 0
        for key in ["memories", "domains", "edges", "scars", "seams", "sessions"]:
            assert key in result.output

    def test_stats_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_summary_stats = AsyncMock(side_effect=RuntimeError("db fail"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["stats"])
        assert result.exit_code == 1
        assert "db fail" in result.output


class TestDomainsEdgeCases:
    def test_domains_empty(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.list_domains = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["domains"])
        assert result.exit_code == 0
        # Header should still be present but no domain rows
        assert "Domain" in result.output

    def test_domains_multiple(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        now = datetime.now(UTC)
        fm.list_domains = AsyncMock(return_value=[
            _FakeDomain(name="alpha", memory_count=10, last_active=now),
            _FakeDomain(name="beta", memory_count=25, last_active=now),
            _FakeDomain(name="gamma", memory_count=0, last_active=now),
        ])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["domains"])
        assert result.exit_code == 0
        assert "alpha" in result.output
        assert "beta" in result.output
        assert "gamma" in result.output

    def test_domains_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm.list_domains = AsyncMock(side_effect=RuntimeError("domain fail"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["domains"])
        assert result.exit_code == 1
        assert "domain fail" in result.output


# ===========================================================================
# Group 5: memories command
# ===========================================================================


class TestMemoriesEdgeCases:
    def test_memories_default(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories"])
        assert result.exit_code == 0
        assert "L1 Label" in result.output

    def test_memories_with_lifecycle_filter(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories", "--lifecycle", "confirmed"])
        assert result.exit_code == 0
        fm._storage.list_memories.assert_called_once()
        assert fm._storage.list_memories.call_args[1]["lifecycle"] == "confirmed"

    def test_memories_with_limit(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories", "--limit", "5"])
        assert result.exit_code == 0
        assert fm._storage.list_memories.call_args[1]["limit"] == 5

    def test_memories_empty_result(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.list_memories = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories"])
        assert result.exit_code == 0
        # Header present but no data rows beyond the separator
        assert "L1 Label" in result.output

    def test_memories_with_domain(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories", "--domain", "specific-domain"])
        assert result.exit_code == 0
        assert fm._storage.list_memories.call_args[1]["domain"] == "specific-domain"

    def test_memories_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.list_memories = AsyncMock(side_effect=RuntimeError("db fail"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["memories"])
        assert result.exit_code == 1
        assert "db fail" in result.output


# ===========================================================================
# Group 6: morphogens / bandits
# ===========================================================================


class TestMorphogensEdgeCases:
    def test_morphogens_not_active_message(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._morphogens = None
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["morphogens"])
        assert result.exit_code == 0
        assert "Morphogenetic field not active" in result.output

    def test_morphogens_active_all_fields(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        morph = MagicMock()
        morph.last_morphogens = _FakeMorphogenState()
        morph.has_converged.return_value = True
        morph.curves = [
            _FakeCurve(name="gate_strictness"),
            _FakeCurve(name="novelty_boost", midpoint=0.3, steepness=8.0),
        ]
        fm._morphogens = morph
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["morphogens"])
        assert result.exit_code == 0
        assert "information_richness:" in result.output
        assert "retrieval_pressure:" in result.output
        assert "domain_density:" in result.output
        assert "Converged: True" in result.output
        assert "gate_strictness" in result.output
        assert "novelty_boost" in result.output

    def test_morphogens_no_last_state(self, runner: CliRunner) -> None:
        """last_morphogens is None — should still print Converged and curve headers."""
        fm = _mock_fm()
        morph = MagicMock()
        morph.last_morphogens = None
        morph.has_converged.return_value = False
        morph.curves = [_FakeCurve()]
        fm._morphogens = morph
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["morphogens"])
        assert result.exit_code == 0
        assert "Converged: False" in result.output
        # Morphogen values should NOT be printed since ms is None
        assert "information_richness:" not in result.output


class TestBanditsEdgeCases:
    def test_bandits_not_active_message(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._bandits = None
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["bandits"])
        assert result.exit_code == 0
        assert "Bandit not active" in result.output

    def test_bandits_active_all_arms(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        b = MagicMock()
        b.get_arm_stats.return_value = {
            "balanced": {"alpha": 5.0, "beta": 3.0, "mean_success": 0.625, "pulls": 8},
            "conservative": {"alpha": 2.0, "beta": 4.0, "mean_success": 0.333, "pulls": 6},
            "aggressive": {"alpha": 8.0, "beta": 1.0, "mean_success": 0.889, "pulls": 9},
        }
        b.current_arm = "aggressive"
        fm._bandits = b
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["bandits"])
        assert result.exit_code == 0
        assert "balanced" in result.output
        assert "conservative" in result.output
        assert "aggressive" in result.output

    def test_bandits_current_arm_shown(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        b = MagicMock()
        b.get_arm_stats.return_value = {
            "balanced": {"alpha": 5.0, "beta": 3.0, "mean_success": 0.625, "pulls": 8},
        }
        b.current_arm = "balanced"
        fm._bandits = b
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["bandits"])
        assert result.exit_code == 0
        assert "Current arm: balanced" in result.output


# ===========================================================================
# Group 7: maintenance
# ===========================================================================


class TestMaintenanceEdgeCases:
    def test_maintenance_daily_with_actions(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        sched = AsyncMock()
        sched.daily_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
            tier="daily", actions_taken={"pruned": 5, "weakened": 12},
        ))
        fm._maintenance = sched
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
        assert result.exit_code == 0
        assert "daily" in result.output
        assert "pruned: 5" in result.output
        assert "weakened: 12" in result.output

    def test_maintenance_weekly_with_actions(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        sched = AsyncMock()
        sched.weekly_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
            tier="weekly", actions_taken={"clusters": 3},
        ))
        fm._maintenance = sched
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "weekly"])
        assert result.exit_code == 0
        assert "weekly" in result.output
        assert "clusters: 3" in result.output

    def test_maintenance_monthly_with_actions(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        sched = AsyncMock()
        sched.monthly_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
            tier="monthly", actions_taken={"apoptosis": 10},
        ))
        fm._maintenance = sched
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "monthly"])
        assert result.exit_code == 0
        assert "monthly" in result.output

    def test_maintenance_not_active(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._maintenance = None
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
        assert result.exit_code == 0
        assert "not active" in result.output

    def test_maintenance_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        sched = AsyncMock()
        sched.daily_maintenance = AsyncMock(side_effect=RuntimeError("maintenance failed"))
        fm._maintenance = sched
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
        assert result.exit_code == 1
        assert "maintenance failed" in result.output

    def test_maintenance_empty_actions(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        sched = AsyncMock()
        sched.daily_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
            tier="daily", actions_taken={},
        ))
        fm._maintenance = sched
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
        assert result.exit_code == 0
        assert "daily" in result.output
        assert "Duration:" in result.output


# ===========================================================================
# Group 8: lint
# ===========================================================================


class _AsyncCursorCM:
    """Object that works both as `async with conn.execute(...)` and `await conn.execute(...)`."""

    def __init__(self, cursor: AsyncMock) -> None:
        self._cursor = cursor

    async def __aenter__(self) -> AsyncMock:
        return self._cursor

    async def __aexit__(self, *args: Any) -> None:
        pass

    def __await__(self):
        """Support bare `await conn.execute(...)`."""
        async def _noop():
            return self._cursor
        return _noop().__await__()


def _make_lint_fm(
    orphaned_rows: list | None = None,
    broken_next_rows: list | None = None,
    broken_prev_rows: list | None = None,
    missing_embeddings: int = 0,
    session_count: int = 10,
    stale_count: int = 0,
    perm_zero: int = 0,
) -> AsyncMock:
    """Create a mock FM with a mock connection for lint queries."""
    fm = _mock_fm()

    # Build a mock connection that responds to specific SQL queries
    conn = MagicMock()

    def _fake_execute(sql, params=None):
        """Return an async context manager with the right cursor based on the SQL query."""
        cursor = AsyncMock()

        sql_lower = sql.strip().lower()

        if "from associations a" in sql_lower:
            cursor.fetchall = AsyncMock(return_value=orphaned_rows or [])
        elif "chain_next" in sql_lower and "chain_next not in" in sql_lower:
            cursor.fetchall = AsyncMock(return_value=broken_next_rows or [])
        elif "chain_prev" in sql_lower and "chain_prev not in" in sql_lower:
            cursor.fetchall = AsyncMock(return_value=broken_prev_rows or [])
        elif "embedding is null" in sql_lower:
            cursor.fetchone = AsyncMock(return_value=(missing_embeddings,))
        elif "last_accessed is null" in sql_lower:
            cursor.fetchone = AsyncMock(return_value=(stale_count,))
        elif "lifecycle = 'permanent'" in sql_lower:
            cursor.fetchone = AsyncMock(return_value=(perm_zero,))
        elif "delete from associations" in sql_lower:
            # Non-context-manager call (bare await conn.execute)
            pass
        elif "update memories" in sql_lower:
            # Non-context-manager call (bare await conn.execute)
            pass
        else:
            cursor.fetchall = AsyncMock(return_value=[])
            cursor.fetchone = AsyncMock(return_value=(0,))

        return _AsyncCursorCM(cursor)

    conn.execute = _fake_execute
    conn.commit = AsyncMock()

    fm._storage._ensure_conn = MagicMock(return_value=conn)
    fm._storage.get_session_count = AsyncMock(return_value=session_count)

    return fm


class TestLintEdgeCases:
    def test_lint_healthy_db(self, runner: CliRunner) -> None:
        """No issues found."""
        fm = _make_lint_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "healthy" in result.output.lower() or "No issues found" in result.output

    def test_lint_orphaned_edges(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(orphaned_rows=[{"source_id": "a", "target_id": "b"}, {"source_id": "c", "target_id": "d"}])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "Orphaned edges: 2" in result.output

    def test_lint_broken_chains(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(broken_next_rows=[{"id": "x", "chain_next": "y"}])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "Broken chains: 1" in result.output

    def test_lint_missing_embeddings(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(missing_embeddings=7)
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "Missing embeddings: 7" in result.output

    def test_lint_stale_memories(self, runner: CliRunner) -> None:
        """Stale detection only triggers when sessions >= 30."""
        fm = _make_lint_fm(session_count=35, stale_count=4)
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "Stale memories: 4" in result.output

    def test_lint_lifecycle_anomalies(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(perm_zero=3)
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])
        assert result.exit_code == 0
        assert "Lifecycle anomalies: 3" in result.output

    def test_lint_fix_orphaned(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(orphaned_rows=[{"source_id": "a", "target_id": "b"}])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint", "--fix"])
        assert result.exit_code == 0
        assert "Deleted 1 orphaned edge(s)" in result.output

    def test_lint_fix_broken_chains(self, runner: CliRunner) -> None:
        fm = _make_lint_fm(
            broken_next_rows=[{"id": "x", "chain_next": "y"}],
            broken_prev_rows=[{"id": "z", "chain_prev": "w"}],
        )
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint", "--fix"])
        assert result.exit_code == 0
        assert "Cleared 2 broken chain pointer(s)" in result.output


# ===========================================================================
# Group 9: export
# ===========================================================================


class TestExportMemories:
    def test_export_memories_json(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mem = _FakeExportMemory(id=uuid.uuid4())
        fm._storage.get_memories_by_domain = AsyncMock(return_value=[mem])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 1
        assert "id" in data[0]
        assert "l1_label" in data[0]
        assert "lifecycle" in data[0]

    def test_export_memories_markdown(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mem = _FakeExportMemory(id=uuid.uuid4())
        fm._storage.get_memories_by_domain = AsyncMock(return_value=[mem])
        fm._storage.get_associations = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test", "--format", "markdown"])
        assert result.exit_code == 0
        assert "# Fractal Memory Export" in result.output
        assert "Export Label" in result.output
        assert "Total memories: 1" in result.output

    def test_export_memories_to_file(self, runner: CliRunner, tmp_path) -> None:
        fm = _mock_fm()
        mem = _FakeExportMemory(id=uuid.uuid4())
        fm._storage.get_memories_by_domain = AsyncMock(return_value=[mem])
        outfile = str(tmp_path / "export.json")
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test", "--output", outfile])
        assert result.exit_code == 0
        assert "Exported 1 memories" in result.output
        import pathlib
        content = pathlib.Path(outfile).read_text()
        data = json.loads(content)
        assert len(data) == 1

    def test_export_memories_empty(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_memories_by_domain = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data == []

    def test_export_memories_with_associations(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        mem = _FakeExportMemory(id=uuid.uuid4())
        target_id = uuid.uuid4()
        fm._storage.get_memories_by_domain = AsyncMock(return_value=[mem])
        fm._storage.get_associations = AsyncMock(return_value=[
            (str(target_id), 0.85, 0.7, "hebbian"),
        ])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test", "--format", "markdown"])
        assert result.exit_code == 0
        assert "### Associations" in result.output
        assert "weight: 0.850" in result.output

    def test_export_memories_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_memories_by_domain = AsyncMock(side_effect=RuntimeError("export fail"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "memories", "--domain", "test"])
        assert result.exit_code == 1
        assert "export fail" in result.output


class TestExportStats:
    def test_export_stats_json(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_summary_stats = AsyncMock(return_value={"memories": 100})
        fm._storage.get_lifecycle_counts = AsyncMock(return_value={"probation": 10, "confirmed": 80, "permanent": 10})
        fm._storage.list_domains_with_counts = AsyncMock(return_value={"test": 50, "dev": 50})
        fm._storage.get_edge_stats = AsyncMock(return_value={"total_edges": 200, "avg_weight": 0.5})
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "stats"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "summary" in data
        assert "lifecycle_distribution" in data
        assert "domains" in data
        assert "associations" in data

    def test_export_stats_exception(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_lifecycle_counts = AsyncMock(side_effect=RuntimeError("stats fail"))
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["export", "stats"])
        assert result.exit_code == 1
        assert "stats fail" in result.output


# ===========================================================================
# Group 10: audit
# ===========================================================================


class TestAuditSessions:
    def test_audit_sessions_happy_path(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_session_summaries = AsyncMock(return_value=[
            {
                "session_id": str(uuid.uuid4()),
                "ended_at": "2025-01-01T12:00:00",
                "store_count": 5,
                "retrieve_count": 10,
                "scar_count": 1,
                "merge_count": 2,
                "edge_count": 15,
            },
        ])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "sessions"])
        assert result.exit_code == 0
        assert "Session ID" in result.output

    def test_audit_sessions_empty(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_session_summaries = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "sessions"])
        assert result.exit_code == 0
        assert "No session summaries found" in result.output

    def test_audit_sessions_limit(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_session_summaries = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "sessions", "--limit", "5"])
        assert result.exit_code == 0
        fm._storage.get_session_summaries.assert_called_once_with(limit=5)


class TestAuditCorrections:
    def test_audit_corrections_happy_path(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_correction_events = AsyncMock(return_value=[
            {
                "occurred_at": "2025-01-01T12:00:00",
                "memory_id": str(uuid.uuid4()),
                "correction_text": "Updated label for clarity",
            },
        ])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "corrections"])
        assert result.exit_code == 0
        assert "When" in result.output
        assert "Updated label" in result.output

    def test_audit_corrections_empty(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_correction_events = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "corrections"])
        assert result.exit_code == 0
        assert "No correction events found" in result.output

    def test_audit_corrections_limit(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_correction_events = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "corrections", "--limit", "10"])
        assert result.exit_code == 0
        fm._storage.get_correction_events.assert_called_once_with(limit=10)


class TestAuditConsolidation:
    def test_audit_consolidation_happy_path(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_session_summaries = AsyncMock(return_value=[
            {
                "session_id": str(uuid.uuid4()),
                "ended_at": "2025-01-01T12:00:00",
                "merge_count": 3,
                "scar_count": 1,
                "edge_count": 20,
            },
        ])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "consolidation"])
        assert result.exit_code == 0
        assert "Last 5 sessions" in result.output
        assert "Merges:" in result.output

    def test_audit_consolidation_empty(self, runner: CliRunner) -> None:
        fm = _mock_fm()
        fm._storage.get_session_summaries = AsyncMock(return_value=[])
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["audit", "consolidation"])
        assert result.exit_code == 0
        assert "No session summaries found" in result.output


# ===========================================================================
# Group 11: global options & help
# ===========================================================================


class TestGlobalOptionsAndHelp:
    def test_cli_help_shows_all_commands(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        expected_commands = [
            "store", "retrieve", "session", "health", "explain", "domains",
            "memories", "inspect", "delete", "pin", "unpin", "morphogens",
            "bandits", "maintenance", "stats", "lint", "export", "audit",
        ]
        for cmd in expected_commands:
            assert cmd in result.output, f"Command '{cmd}' not found in --help output"

    def test_cli_unknown_command(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["nonexistent-cmd"])
        assert result.exit_code != 0

    def test_global_domain_propagates(self, runner: CliRunner) -> None:
        """fractal --domain X store 'text' uses domain X."""
        fm = _mock_fm()
        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["--domain", "custom-dom", "store", "text"])
        assert result.exit_code == 0
        fm.session_start.assert_called_once_with("custom-dom")
        assert fm.store.call_args[1]["domain"] == "custom-dom"

    def test_global_db_propagates(self, runner: CliRunner) -> None:
        """fractal --db /tmp/x.db store 'text' passes db to _make_fm."""
        fm = _mock_fm()
        with _patch_make_fm(fm) as mock_make:
            result = runner.invoke(cli, ["--db", "/tmp/x.db", "store", "text"])
        assert result.exit_code == 0
        call_args = mock_make.call_args_list[0]
        assert call_args[0][0] == "/tmp/x.db"


# ===========================================================================
# Group 12: Regression tests for bug fixes
# ===========================================================================


class TestBugFixRegressions:
    """Tests for specific bug fixes to prevent regressions."""

    def test_make_fm_init_failure_closes_fm(self, runner: CliRunner) -> None:
        """If fm.initialize() raises, fm.close() must be called before re-raising."""
        fm = AsyncMock()
        fm.initialize = AsyncMock(side_effect=RuntimeError("init failed"))
        fm.close = AsyncMock()

        async def fake_make_fm_broken(db: Any, domain: Any) -> tuple[Any, str]:
            # Simulate what _make_fm does internally — construct, init, close on failure
            from fractal_memory.cli import _make_fm
            raise RuntimeError("init failed")

        # Directly test _make_fm by patching FractalMemory class
        mock_fm_class = MagicMock()
        mock_instance = AsyncMock()
        mock_instance.initialize = AsyncMock(side_effect=RuntimeError("init failed"))
        mock_instance.close = AsyncMock()
        mock_fm_class.return_value = mock_instance

        with patch("fractal_memory.cli.FractalConfig"), \
             patch("fractal_memory.cli.load_config"), \
             patch("fractal_memory.FractalMemory", mock_fm_class):
            # Use the actual _make_fm via a CLI command that calls it
            result = runner.invoke(cli, ["store", "test"])

        # fm.close() should have been called because initialize() failed
        mock_instance.close.assert_awaited_once()
        # The command should fail
        assert result.exit_code != 0

    def test_run_passes_click_exception_through(self, runner: CliRunner) -> None:
        """_run must re-raise ClickException without wrapping it in another ClickException."""
        import click
        from fractal_memory.cli import _run

        async def raise_click_error() -> None:
            raise click.ClickException("specific error")

        with pytest.raises(click.ClickException) as exc_info:
            _run(raise_click_error())

        # The message should be exactly "specific error", not wrapped
        assert exc_info.value.format_message() == "specific error"

    def test_run_passes_exit_through(self, runner: CliRunner) -> None:
        """_run must re-raise click.exceptions.Exit without wrapping."""
        import click.exceptions
        from fractal_memory.cli import _run

        async def raise_exit() -> None:
            raise click.exceptions.Exit(0)

        with pytest.raises(click.exceptions.Exit):
            _run(raise_exit())

    def test_run_wraps_generic_exception(self, runner: CliRunner) -> None:
        """_run must convert generic exceptions to ClickException with the error message."""
        import click
        from fractal_memory.cli import _run

        async def raise_generic() -> None:
            raise ValueError("something broke")

        with pytest.raises(click.ClickException) as exc_info:
            _run(raise_generic())

        assert "something broke" in exc_info.value.format_message()

    def test_lint_missing_table_schema_error(self, runner: CliRunner) -> None:
        """Lint should show a user-friendly message when DB is missing expected tables."""
        fm = _mock_fm()

        # Make the connection's execute raise an OperationalError (missing table)
        def _bad_execute(sql: str, *args: Any) -> Any:
            raise Exception("no such table: associations")

        mock_conn = MagicMock()
        mock_conn.execute = _bad_execute
        fm._storage._ensure_conn = MagicMock(return_value=mock_conn)

        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])

        assert result.exit_code != 0
        assert "Lint failed" in result.output or "older schema" in result.output

    def test_lint_ensure_conn_failure(self, runner: CliRunner) -> None:
        """Lint should show a user-friendly message when _ensure_conn fails."""
        fm = _mock_fm()
        fm._storage._ensure_conn = MagicMock(side_effect=RuntimeError("DB locked"))

        with _patch_make_fm(fm):
            result = runner.invoke(cli, ["lint"])

        assert result.exit_code != 0
        assert "Cannot connect to database" in result.output
