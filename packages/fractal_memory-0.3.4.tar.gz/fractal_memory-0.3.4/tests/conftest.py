"""Shared fixtures for fractal-memory tests."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.llm import LLMProvider
from fractal_memory.storage import Storage


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


@pytest.fixture
def mock_llm():
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        # Return session summary for summarize prompts
        if "Summarize" in prompt or "summarize" in prompt:
            return "Test session summary: worked on testing features."
        # Default: return zoom levels JSON
        return json.dumps({
            "l0_tag": "test:tag",
            "l1_label": "test-memory-label",
            "l2_summary": "A test memory summary for testing.",
            "l3_full": "A test memory with full context for testing purposes.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


@pytest.fixture
def mock_embeddings():
    provider = AsyncMock(spec=EmbeddingProvider)

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def tmp_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "test_memory.db",
        gate_signal_count=1,  # Pioneer stage
    )


@pytest.fixture
async def storage(tmp_config: FractalConfig):
    s = Storage(tmp_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
async def fractal_memory(tmp_config, mock_llm, mock_embeddings):
    from fractal_memory import FractalMemory

    fm = FractalMemory(tmp_config, llm=mock_llm, embeddings=mock_embeddings)
    await fm.initialize()
    yield fm
    # End active session if one was started, so session_end hooks run in teardown
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()
