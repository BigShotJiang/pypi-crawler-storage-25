"""Tests for data models."""

from datetime import datetime
from uuid import uuid4

from fractal_memory.models import (
    ContextTags,
    DomainInfo,
    LifecycleStatus,
    Memory,
    RetrievalResult,
    Session,
    SessionContext,
    SessionSummary,
    Task,
    TaskStatus,
    WaitingRoomEntry,
)


def test_lifecycle_status_values():
    assert LifecycleStatus.PROBATION == "probation"
    assert LifecycleStatus.CONFIRMED == "confirmed"
    assert LifecycleStatus.PERMANENT == "permanent"
    assert LifecycleStatus.SAFETY_CRITICAL == "safety_critical"


def test_task_status_values():
    assert TaskStatus.ACTIVE == "active"
    assert TaskStatus.COMPLETED == "completed"
    assert TaskStatus.DEFERRED == "deferred"


def test_memory_creation_with_defaults():
    now = datetime.utcnow()
    mem = Memory(
        id=uuid4(),
        domain="test",
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="test summary",
        l3_full="test full",
        l4_raw="test raw",
        embedding=[0.1] * 384,
        embedding_model="test-model",
    )
    assert mem.intensity == 0.5
    assert mem.retrieval_count == 0
    assert mem.miss_count == 0
    assert mem.lifecycle == LifecycleStatus.PROBATION
    assert mem.chronic_score == 0.0
    assert mem.vitality == 1.0
    assert mem.reconsolidation_count == 0
    assert mem.origin == "organic"
    assert mem.trust_score == 1.0
    assert mem.last_accessed is None
    assert mem.contrast is None
    assert mem.chain_next is None
    assert mem.chain_prev is None


def test_memory_creation_all_fields():
    now = datetime.utcnow()
    chain_id = uuid4()
    mem = Memory(
        id=uuid4(),
        domain="test",
        created_at=now,
        updated_at=now,
        context={"project": "test-proj"},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="summary",
        l3_full="full",
        l4_raw="raw",
        embedding=[0.1] * 10,
        embedding_model="model",
        intensity=0.8,
        retrieval_count=5,
        miss_count=2,
        last_accessed=now,
        lifecycle=LifecycleStatus.CONFIRMED,
        chronic_score=0.6,
        contrast="not X",
        chain_next=chain_id,
        chain_prev=chain_id,
        vitality=0.9,
        reconsolidation_count=3,
        origin="imported",
        trust_score=0.8,
    )
    assert mem.intensity == 0.8
    assert mem.lifecycle == LifecycleStatus.CONFIRMED
    assert mem.chain_next == chain_id


def test_context_tags_partial():
    tags: ContextTags = {"project": "my-proj"}
    assert tags["project"] == "my-proj"
    assert "task" not in tags


def test_task_creation():
    task = Task(
        id=uuid4(),
        description="Do something",
        created_at=datetime.utcnow(),
    )
    assert task.status == TaskStatus.ACTIVE
    assert task.priority == 0
    assert task.related_memory_ids == []


def test_waiting_room_entry():
    entry = WaitingRoomEntry(
        id=uuid4(),
        content="test content",
        first_signal={"type": "explicit_store"},
        domain="test",
        created_at=datetime.utcnow(),
    )
    assert entry.sessions_elapsed == 0
    assert entry.embedding == []


def test_session_creation():
    s = Session(
        id=uuid4(),
        domain="test",
        started_at=datetime.utcnow(),
    )
    assert s.ended_at is None
    assert s.summary is None


def test_retrieval_result_defaults():
    r = RetrievalResult()
    assert r.l3_memories == []
    assert r.l2_memories == []
    assert r.l1_memories == []
    assert r.hints == []
    assert r.token_budget_used == 0


def test_session_context():
    s = Session(id=uuid4(), domain="test", started_at=datetime.utcnow())
    ctx = SessionContext(session=s)
    assert ctx.bootstrap_memories == []
    assert ctx.last_summary is None
    assert ctx.active_tasks == []


def test_session_summary():
    ss = SessionSummary(session_id=uuid4(), summary="test")
    assert ss.memories_stored == 0
    assert ss.memories_retrieved == 0
    assert ss.duration_seconds == 0.0


def test_domain_info():
    di = DomainInfo(name="test", memory_count=5, last_active=datetime.utcnow())
    assert di.name == "test"
    assert di.memory_count == 5
