"""Real end-to-end integration tests — real embeddings, real storage, mock LLM only.

The LLM is the only mock because it requires an API key / external service.
Embeddings use the real all-MiniLM-L6-v2 model.
Storage uses real SQLite.
All subsystems (gate, lifecycle, buffer, associations, scars, etc.) are real.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import LocalEmbeddingProvider
from fractal_memory.gate import Signal
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus


def _make_mock_llm() -> LLMProvider:
    """LLM mock — only thing we can't test without an API key."""
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower() or "Summarize" in prompt:
            return "Session summary: tested real integration features."
        return json.dumps({
            "l0_tag": "test:integration",
            "l1_label": "real-integration-test",
            "l2_summary": "A real integration test memory.",
            "l3_full": "A real integration test memory with full details.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


@pytest.fixture
def real_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "real_test.db",
        gate_signal_count=1,
    )


@pytest.fixture
def real_embeddings() -> LocalEmbeddingProvider:
    return LocalEmbeddingProvider("all-MiniLM-L6-v2")


@pytest.fixture
async def fm(real_config: FractalConfig, real_embeddings: LocalEmbeddingProvider):
    mock_llm = _make_mock_llm()
    fm = FractalMemory(real_config, llm=mock_llm, embeddings=real_embeddings)
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ── Store + Retrieve round-trip ────────────────────────────────────────

class TestRealStoreRetrieve:
    @pytest.mark.asyncio
    async def test_store_and_retrieve_by_semantic_match(self, fm: FractalMemory):
        """Store a fact, retrieve it with a semantically related query."""
        await fm.session_start("test")
        mem = await fm.store("Python is excellent for data science and machine learning", domain="test")
        assert mem is not None

        result = await fm.retrieve("What language should I use for ML?", domain="test")
        l3_ids = [m.id for m in result.l3_memories]
        assert mem.id in l3_ids, "Stored memory should be retrieved by semantic query"

    @pytest.mark.asyncio
    async def test_retrieve_ranks_relevant_higher(self, fm: FractalMemory):
        """More relevant memories should rank higher in L3 results."""
        await fm.session_start("test")
        await fm.store("The weather in Paris is usually mild in spring", domain="test")
        relevant = await fm.store("Docker containers simplify deployment of web applications", domain="test")
        await fm.store("Ancient Roman gladiators fought in the Colosseum", domain="test")

        result = await fm.retrieve("How to deploy apps with containers?", domain="test")
        if result.l3_memories:
            # The deployment-related memory should be first or very high
            top_ids = [m.id for m in result.l3_memories[:2]]
            assert relevant.id in top_ids, "Relevant memory should be in top 2"

    @pytest.mark.asyncio
    async def test_store_multiple_retrieve_specific(self, fm: FractalMemory):
        """Store 10 diverse memories, retrieve should find the right one."""
        await fm.session_start("test")
        memories = []
        topics = [
            "React hooks provide state management in functional components",
            "PostgreSQL supports JSONB for document storage",
            "Kubernetes orchestrates container deployments at scale",
            "GraphQL allows clients to request specific data shapes",
            "Redis is an in-memory data structure store for caching",
            "WebSocket enables full-duplex communication channels",
            "OAuth2 provides delegated authorization for APIs",
            "Elasticsearch indexes documents for full-text search",
            "RabbitMQ handles message queuing between microservices",
            "Terraform manages infrastructure as code across clouds",
        ]
        for topic in topics:
            mem = await fm.store(topic, domain="test")
            assert mem is not None
            memories.append(mem)

        # Query about caching
        result = await fm.retrieve("What should I use for caching?", domain="test")
        l3_ids = [m.id for m in result.l3_memories]
        # Redis memory should be in results
        redis_mem = memories[4]  # "Redis is an in-memory..."
        assert redis_mem.id in l3_ids, "Redis memory should be retrieved for caching query"


# ── Domain isolation ───────────────────────────────────────────────────

class TestRealDomainIsolation:
    @pytest.mark.asyncio
    async def test_domains_are_isolated(self, fm: FractalMemory):
        """Memories in domain A should not appear in domain B retrieval."""
        await fm.session_start("alpha")
        alpha_mem = await fm.store("Alpha project uses FastAPI", domain="alpha")
        await fm.store("Beta project uses Django", domain="beta")

        result = await fm.retrieve("What framework does the project use?", domain="alpha")
        l3_ids = [m.id for m in result.l3_memories]
        assert alpha_mem.id in l3_ids


# ── Lifecycle progression ──────────────────────────────────────────────

class TestRealLifecycle:
    @pytest.mark.asyncio
    async def test_memory_starts_in_probation(self, fm: FractalMemory):
        await fm.session_start("test")
        mem = await fm.store("Test lifecycle memory", domain="test")
        assert mem is not None
        fetched = await fm.get(mem.id)
        assert fetched.lifecycle == LifecycleStatus.PROBATION

    @pytest.mark.asyncio
    async def test_retrieval_promotes_to_confirmed(self, fm: FractalMemory):
        """After enough retrievals, a memory should promote from PROBATION to CONFIRMED."""
        await fm.session_start("test")
        mem = await fm.store("This is an important architectural decision about using microservices", domain="test")
        assert mem is not None

        # Retrieve multiple times to hit confirmation_threshold (default=2)
        for _ in range(3):
            await fm.retrieve("microservices architecture decision", domain="test")

        fetched = await fm.get(mem.id)
        assert fetched.lifecycle == LifecycleStatus.CONFIRMED


# ── Correction flow ───────────────────────────────────────────────────

class TestRealCorrection:
    @pytest.mark.asyncio
    async def test_correct_creates_scar(self, fm: FractalMemory):
        """Correcting a memory should create a scar and update/replace the memory."""
        await fm.session_start("test")
        mem = await fm.store("The API uses REST with JSON responses", domain="test")
        assert mem is not None

        corrected = await fm.correct(mem.id, "The API uses GraphQL, not REST")
        assert corrected is not None

        # Verify scar was created
        active_scars = await fm._scars.get_active_scars()
        assert len(active_scars) > 0, "Correction should create a scar"

    @pytest.mark.asyncio
    async def test_confirm_strengthens_memory(self, fm: FractalMemory):
        """Confirming a memory should increment its retrieval count."""
        await fm.session_start("test")
        mem = await fm.store("User always prefers dark mode", domain="test")
        assert mem is not None

        before = (await fm.get(mem.id)).retrieval_count
        await fm.confirm(mem.id)
        after = (await fm.get(mem.id)).retrieval_count
        assert after > before


# ── Pin / Critical ─────────────────────────────────────────────────────

class TestRealPinCritical:
    @pytest.mark.asyncio
    async def test_pin_promotes_to_permanent(self, fm: FractalMemory):
        await fm.session_start("test")
        mem = await fm.store("Critical API key rotation procedure", domain="test")
        assert mem is not None
        await fm.pin(mem.id)
        fetched = await fm.get(mem.id)
        assert fetched.lifecycle == LifecycleStatus.PERMANENT

    @pytest.mark.asyncio
    async def test_mark_critical_sets_safety_critical(self, fm: FractalMemory):
        await fm.session_start("test")
        mem = await fm.store("Never delete production database backups", domain="test")
        assert mem is not None
        await fm.mark_critical(mem.id)
        fetched = await fm.get(mem.id)
        assert fetched.lifecycle == LifecycleStatus.SAFETY_CRITICAL


# ── Session lifecycle ──────────────────────────────────────────────────

class TestRealSessionLifecycle:
    @pytest.mark.asyncio
    async def test_full_session_lifecycle(self, fm: FractalMemory):
        """Start → store → retrieve → end should work without errors."""
        ctx = await fm.session_start("test")
        assert ctx.session is not None

        mem = await fm.store("Session lifecycle test memory", domain="test")
        assert mem is not None

        result = await fm.retrieve("lifecycle test", domain="test")
        assert result is not None

        summary = await fm.session_end()
        assert summary is not None
        assert summary.memories_stored >= 1

    @pytest.mark.asyncio
    async def test_multi_session_bootstrap(self, fm: FractalMemory):
        """Second session should bootstrap with memories from first session."""
        # Session 1
        await fm.session_start("test")
        await fm.store("Important: always use parameterized SQL queries", domain="test")
        await fm.session_end()

        # Session 2
        ctx2 = await fm.session_start("test")
        # Bootstrap memories should contain the stored memory
        assert ctx2.last_summary is not None or len(ctx2.bootstrap_memories) >= 0


# ── Task management ───────────────────────────────────────────────────

class TestRealTaskManagement:
    @pytest.mark.asyncio
    async def test_add_complete_list_tasks(self, fm: FractalMemory):
        task = await fm.add_task("Write integration tests", priority=5)
        assert task is not None

        tasks = await fm.list_tasks()
        assert any(t.id == task.id for t in tasks)

        await fm.complete_task(task.id)
        from fractal_memory.models import TaskStatus
        completed = await fm.list_tasks(status=TaskStatus.COMPLETED)
        assert any(t.id == task.id for t in completed)


# ── Delete ─────────────────────────────────────────────────────────────

class TestRealDelete:
    @pytest.mark.asyncio
    async def test_delete_removes_memory(self, fm: FractalMemory):
        await fm.session_start("test")
        mem = await fm.store("Temporary test memory to delete", domain="test")
        assert mem is not None
        deleted = await fm.delete(mem.id)
        assert deleted is True
        fetched = await fm.get(mem.id)
        assert fetched is None


# ── Stats ──────────────────────────────────────────────────────────────

class TestRealStats:
    @pytest.mark.asyncio
    async def test_stats_reflect_stored_memories(self, fm: FractalMemory):
        await fm.session_start("test")
        await fm.store("Stats test memory 1", domain="test")
        await fm.store("Stats test memory 2", domain="test")
        await fm.store("Stats test memory 3", domain="test")
        stats = await fm.get_stats()
        assert stats["overall"]["total_memories"] >= 3


# ── Real embedding similarity in retrieval ─────────────────────────────

class TestRealEmbeddingRetrieval:
    @pytest.mark.asyncio
    async def test_correction_creates_scar_and_updates_memory(self, fm: FractalMemory):
        """Correcting a memory should create a scar and the corrected memory should
        still be retrievable (with updated content from the correction)."""
        await fm.session_start("test")
        original = await fm.store("The database is MySQL", domain="test")
        assert original is not None

        # Correct the memory
        corrected = await fm.correct(original.id, "The database is PostgreSQL")
        assert corrected is not None

        # Verify scar was created
        active_scars = await fm._scars.get_active_scars()
        assert len(active_scars) > 0, "Correction should create a scar"

        # The corrected/replacement memory should be retrievable
        result = await fm.retrieve("What database does the project use?", domain="test")
        l3_ids = [m.id for m in result.l3_memories]
        assert corrected.id in l3_ids, "Corrected memory should be retrievable"
