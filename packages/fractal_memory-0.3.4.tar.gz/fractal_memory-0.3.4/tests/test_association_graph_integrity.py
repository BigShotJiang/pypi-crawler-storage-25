"""Association graph integrity — no self-loops, no orphans, no duplicates, valid weights after mutations.

Tests the AssociationNetwork and underlying storage to verify graph invariants
are maintained through all mutation operations.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.associations import AssociationNetwork
from fractal_memory.config import FractalConfig
from fractal_memory.models import Memory
from fractal_memory.storage import Storage


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def graph_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "graph_test.db",
        gate_signal_count=1,
        edge_cap_per_node=5,
    )


@pytest.fixture
async def graph_storage(graph_config: FractalConfig):
    s = Storage(graph_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
async def graph_network(graph_storage: Storage, graph_config: FractalConfig):
    return AssociationNetwork(graph_storage, _make_mock_embeddings(), graph_config)


async def _store_test_memory(storage: Storage, label: str, domain: str = "test") -> Memory:
    """Helper to store a test memory and return it."""
    mem = Memory(
        id=uuid4(), domain=domain,
        created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
        context={},
        l0_tag=f"t:{label}", l1_label=label, l2_summary=f"Summary of {label}",
        l3_full=f"Full text of {label}", l4_raw=f"Raw {label}",
        embedding=_deterministic_embed(label),
        embedding_model="mock",
    )
    await storage.store_memory(mem)
    return mem


# ── No self-loops ────────────────────────────────────────────────────


class TestNoSelfLoops:
    @pytest.mark.asyncio
    async def test_co_retrieval_single_id_no_edge(self, graph_network: AssociationNetwork, graph_storage: Storage):
        """Co-retrieval with a single memory ID should not create a self-loop."""
        mem = await _store_test_memory(graph_storage, "solo")
        await graph_network.on_co_retrieval([mem.id], zoom_level=3)
        edges = await graph_storage.get_associations(mem.id)
        # Should have no edges at all
        for target_id, weight, trail_w, centroid in edges:
            assert target_id != mem.id, "Self-loop detected"

    @pytest.mark.asyncio
    async def test_direct_self_association_prevented(self, graph_storage: Storage):
        """Directly storing a self-association should be silently rejected."""
        mem_id = uuid4()
        # Try to create a self-loop directly — should be silently ignored
        await graph_storage.store_association(mem_id, mem_id, 0.5)
        edges = await graph_storage.get_all_associations()
        self_loops = [(s, t, w) for s, t, w in edges if s == t]
        assert len(self_loops) == 0, f"Self-loop was not prevented: {self_loops}"


# ── No duplicate edges ───────────────────────────────────────────────


class TestNoDuplicateEdges:
    @pytest.mark.asyncio
    async def test_co_retrieval_idempotent_edge_count(self, graph_network: AssociationNetwork, graph_storage: Storage):
        """Multiple co-retrievals should not create duplicate edges."""
        m1 = await _store_test_memory(graph_storage, "dup-a")
        m2 = await _store_test_memory(graph_storage, "dup-b")

        # Co-retrieve multiple times
        for _ in range(5):
            await graph_network.on_co_retrieval([m1.id, m2.id], zoom_level=3)

        edges = await graph_storage.get_associations(m1.id)
        target_ids = [t for t, w, tw, c in edges]
        # Should have exactly one edge to m2 (possibly bidirectional)
        assert target_ids.count(m2.id) <= 2, f"Duplicate edges: {target_ids}"

    @pytest.mark.asyncio
    async def test_store_association_upsert(self, graph_storage: Storage):
        """store_association should upsert, not create duplicates."""
        a = uuid4()
        b = uuid4()
        await graph_storage.store_association(a, b, 0.3)
        await graph_storage.store_association(a, b, 0.7)
        edges = await graph_storage.get_all_associations()
        matching = [(s, t, w) for s, t, w in edges if s == a and t == b]
        assert len(matching) == 1, f"Expected 1 edge, got {len(matching)}"
        assert matching[0][2] == pytest.approx(0.7)


# ── Valid weights ────────────────────────────────────────────────────


class TestValidWeights:
    @pytest.mark.asyncio
    async def test_weights_in_range(self, graph_network: AssociationNetwork, graph_storage: Storage):
        """All edge weights should be in [0, 1] after mutations."""
        mems = [await _store_test_memory(graph_storage, f"w-{i}") for i in range(4)]
        ids = [m.id for m in mems]

        # Trigger co-retrieval
        await graph_network.on_co_retrieval(ids, zoom_level=3)

        edges = await graph_storage.get_all_associations()
        for s, t, w in edges:
            assert 0.0 <= w <= 1.0, f"Edge weight out of range: {w} (edge {s}→{t})"

    @pytest.mark.asyncio
    async def test_weight_after_strengthen_trail(self, graph_network: AssociationNetwork, graph_storage: Storage):
        """Trail strengthening should keep weights valid."""
        m1 = await _store_test_memory(graph_storage, "trail-a")
        m2 = await _store_test_memory(graph_storage, "trail-b")

        await graph_network.on_co_retrieval([m1.id, m2.id], zoom_level=3)
        embedding = _deterministic_embed("trail context")
        await graph_network.strengthen_trail([m1.id, m2.id], embedding)

        edges = await graph_storage.get_associations(m1.id)
        for t, w, tw, c in edges:
            assert 0.0 <= w <= 1.0
            assert 0.0 <= tw <= 1.0


# ── Orphan detection ─────────────────────────────────────────────────


class TestOrphanEdges:
    @pytest.mark.asyncio
    async def test_delete_memory_cleans_edges(self, graph_storage: Storage):
        """Deleting a memory should remove all its association edges."""
        m1 = await _store_test_memory(graph_storage, "orphan-a")
        m2 = await _store_test_memory(graph_storage, "orphan-b")
        m3 = await _store_test_memory(graph_storage, "orphan-c")

        await graph_storage.store_association(m1.id, m2.id, 0.5)
        await graph_storage.store_association(m1.id, m3.id, 0.3)

        # Delete m1
        await graph_storage.delete_memory(m1.id)

        # No edges should reference m1
        all_edges = await graph_storage.get_all_associations()
        for s, t, w in all_edges:
            assert s != m1.id, f"Orphan edge source: {s}"
            assert t != m1.id, f"Orphan edge target: {t}"

    @pytest.mark.asyncio
    async def test_no_orphan_edges_after_bulk_delete(self, graph_storage: Storage):
        """Bulk deletion should not leave orphan edges."""
        mems = [await _store_test_memory(graph_storage, f"bulk-{i}") for i in range(5)]
        ids = [m.id for m in mems]

        # Create a mesh of edges
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                await graph_storage.store_association(ids[i], ids[j], 0.3)

        # Delete memories 0, 1, 2
        for mid in ids[:3]:
            await graph_storage.delete_memory(mid)

        # Check remaining edges
        edges = await graph_storage.get_all_associations()
        deleted_set = set(ids[:3])
        for s, t, w in edges:
            assert s not in deleted_set, f"Orphan source after delete: {s}"
            assert t not in deleted_set, f"Orphan target after delete: {t}"


# ── Edge cap enforcement ─────────────────────────────────────────────


class TestEdgeCap:
    @pytest.mark.asyncio
    async def test_edge_cap_enforced(self, graph_network: AssociationNetwork, graph_storage: Storage):
        """A node should not exceed edge_cap_per_node edges."""
        center = await _store_test_memory(graph_storage, "center")
        neighbors = [await _store_test_memory(graph_storage, f"neighbor-{i}") for i in range(10)]

        # Co-retrieve center with each neighbor
        for n in neighbors:
            await graph_network.on_co_retrieval([center.id, n.id], zoom_level=3)

        edge_count = await graph_storage.count_associations(center.id)
        # edge_cap_per_node = 5 — should not exceed
        assert edge_count <= 10, f"Edge count {edge_count} exceeds limit"
        # Note: edges are bidirectional so count may be up to 2x cap


# ── Weak edge pruning ────────────────────────────────────────────────


class TestWeakEdgePruning:
    @pytest.mark.asyncio
    async def test_delete_weak_associations(self, graph_storage: Storage):
        """delete_weak_associations should remove low-weight edges."""
        m1 = await _store_test_memory(graph_storage, "weak-a")
        m2 = await _store_test_memory(graph_storage, "weak-b")
        m3 = await _store_test_memory(graph_storage, "weak-c")

        await graph_storage.store_association(m1.id, m2.id, 0.005)  # Below min
        await graph_storage.store_association(m1.id, m3.id, 0.5)    # Above min

        deleted = await graph_storage.delete_weak_associations(0.01)
        assert deleted >= 1

        edges = await graph_storage.get_all_associations()
        for s, t, w in edges:
            assert w >= 0.01, f"Weak edge survived: weight={w}"

    @pytest.mark.asyncio
    async def test_weaken_unused_edges(self, graph_storage: Storage):
        """weaken_unused_edges should decay all edges."""
        m1 = await _store_test_memory(graph_storage, "decay-a")
        m2 = await _store_test_memory(graph_storage, "decay-b")
        await graph_storage.store_association(m1.id, m2.id, 0.5)

        updated = await graph_storage.weaken_unused_edges(decay=0.5)
        edges = await graph_storage.get_all_associations()
        for s, t, w in edges:
            if s == m1.id and t == m2.id:
                assert w < 0.5, f"Edge not decayed: {w}"


# ── Stats accuracy ───────────────────────────────────────────────────


class TestGraphStats:
    @pytest.mark.asyncio
    async def test_total_association_count(self, graph_storage: Storage):
        """get_total_association_count should match actual edges."""
        m1 = await _store_test_memory(graph_storage, "stat-a")
        m2 = await _store_test_memory(graph_storage, "stat-b")
        m3 = await _store_test_memory(graph_storage, "stat-c")

        await graph_storage.store_association(m1.id, m2.id, 0.5)
        await graph_storage.store_association(m2.id, m3.id, 0.3)

        total = await graph_storage.get_total_association_count()
        assert total == 2

    @pytest.mark.asyncio
    async def test_edge_stats(self, graph_storage: Storage):
        """get_edge_stats should return valid statistics."""
        m1 = await _store_test_memory(graph_storage, "estats-a")
        m2 = await _store_test_memory(graph_storage, "estats-b")
        await graph_storage.store_association(m1.id, m2.id, 0.6)

        stats = await graph_storage.get_edge_stats()
        assert stats["count"] >= 1
        assert 0.0 <= stats["mean_weight"] <= 1.0
        assert stats["max_weight"] >= 0.0
