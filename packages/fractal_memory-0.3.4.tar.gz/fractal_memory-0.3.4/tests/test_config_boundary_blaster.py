"""Config boundary blaster — extreme configs: gate=0, flush=0, dim=1, all-minimums pipeline.

Tests FractalConfig validation and ensures that extreme-but-valid configs
produce a working pipeline, while invalid configs are properly rejected.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Config boundary test session summary."
        return json.dumps({
            "l0_tag": "config:test",
            "l1_label": "config-test",
            "l2_summary": "Config boundary test.",
            "l3_full": "Config boundary test full.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


# ── Config validation tests ──────────────────────────────────────────


class TestConfigValidation:
    def test_gate_signal_count_zero_rejected(self):
        """gate_signal_count=0 should be rejected."""
        with pytest.raises(ValueError, match="gate_signal_count"):
            FractalConfig(gate_signal_count=0)

    def test_gate_signal_count_negative_rejected(self):
        """gate_signal_count=-1 should be rejected."""
        with pytest.raises(ValueError, match="gate_signal_count"):
            FractalConfig(gate_signal_count=-1)

    def test_gate_signal_count_six_rejected(self):
        """gate_signal_count=6 should be rejected (max is 5)."""
        with pytest.raises(ValueError, match="gate_signal_count"):
            FractalConfig(gate_signal_count=6)

    def test_memory_token_budget_zero_rejected(self):
        """memory_token_budget_pct=0 should be rejected."""
        with pytest.raises(ValueError, match="memory_token_budget_pct"):
            FractalConfig(memory_token_budget_pct=0.0)

    def test_weight_sum_mismatch_rejected(self):
        """Weights that don't sum to 1.0 should be rejected."""
        with pytest.raises(ValueError, match="sum to 1.0"):
            FractalConfig(scoring_cosine_weight=0.5, scoring_intensity_weight=0.3)

    def test_zoom_ordering_violated(self):
        """top_l3 > top_l2 should be rejected."""
        with pytest.raises(ValueError, match="Zoom level ordering"):
            FractalConfig(top_l3=20, top_l2=10, top_l1=5)

    def test_activity_flush_zero_rejected(self):
        """activity_flush_interval=0 should be rejected."""
        with pytest.raises(ValueError, match="activity_flush_interval"):
            FractalConfig(activity_flush_interval=0)

    def test_buffer_soft_cap_zero_valid(self):
        """buffer_soft_cap=0 should be valid (minimum is 0)."""
        cfg = FractalConfig(buffer_soft_cap=0, gate_signal_count=1)
        assert cfg.buffer_soft_cap == 0

    def test_pruning_ttl_zero_valid(self):
        """pruning_ttl_sessions=0 should be valid (aggressive pruning)."""
        cfg = FractalConfig(pruning_ttl_sessions=0, gate_signal_count=1)
        assert cfg.pruning_ttl_sessions == 0


# ── Extreme-but-valid configs ────────────────────────────────────────


class TestExtremeValidConfigs:
    @pytest.mark.asyncio
    async def test_minimum_everything_pipeline(self, tmp_path: Path):
        """Pipeline with all minimums should still work."""
        cfg = FractalConfig(
            db_path=tmp_path / "min_all.db",
            gate_signal_count=1,
            top_l3=1,
            top_l2=1,
            top_l1=1,
            buffer_soft_cap=0,
            pruning_ttl_sessions=0,
            memory_token_budget_pct=0.0001,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("min")
            mem = await fm.store("Minimum config memory")
            assert mem is not None
            result = await fm.retrieve("minimum query", domain="min")
            assert result is not None
            await fm.session_end()
        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_maximum_zoom_levels(self, tmp_path: Path):
        """Pipeline with maximum zoom levels should work."""
        cfg = FractalConfig(
            db_path=tmp_path / "max_zoom.db",
            gate_signal_count=1,
            top_l3=20,
            top_l2=100,
            top_l1=500,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("max-zoom")
            await fm.store("Max zoom config memory")
            result = await fm.retrieve("zoom query", domain="max-zoom")
            assert result is not None
        finally:
            if fm._session.current_session:
                await fm.session_end()
            await fm.close()

    @pytest.mark.asyncio
    async def test_max_gate_signal_count(self, tmp_path: Path):
        """gate_signal_count=5 should gate out all single-signal stores."""
        cfg = FractalConfig(
            db_path=tmp_path / "gate5.db",
            gate_signal_count=5,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("gate5")
            # Default store sends 1 signal → should be gated out
            mem = await fm.store("This should be gated out")
            assert mem is None, "Memory should be gated out with gate_signal_count=5"
        finally:
            if fm._session.current_session:
                await fm.session_end()
            await fm.close()

    @pytest.mark.asyncio
    async def test_flush_interval_one(self, tmp_path: Path):
        """activity_flush_interval=1 should flush on every op."""
        cfg = FractalConfig(
            db_path=tmp_path / "flush1.db",
            gate_signal_count=1,
            activity_flush_interval=1,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("flush")
            await fm.store("Flush interval 1 memory")
            # Should not crash — activity flushed on every store
            await fm.store("Another memory for flush test")
            await fm.session_end()
        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_tiny_token_budget(self, tmp_path: Path):
        """Very small token budget should still complete retrieval."""
        cfg = FractalConfig(
            db_path=tmp_path / "tiny_budget.db",
            gate_signal_count=1,
            memory_token_budget_pct=0.0001,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("tiny")
            for i in range(5):
                await fm.store(f"Memory {i} for tiny budget test")
            result = await fm.retrieve("tiny budget query", domain="tiny")
            assert result is not None
        finally:
            if fm._session.current_session:
                await fm.session_end()
            await fm.close()


# ── Memory token budget computation ──────────────────────────────────


class TestMemoryTokenBudget:
    def test_budget_computation(self):
        """memory_token_budget should be pct * context_window."""
        cfg = FractalConfig(
            gate_signal_count=1,
            memory_token_budget_pct=0.15,
            context_window_tokens=200_000,
        )
        assert cfg.memory_token_budget == 30_000

    def test_budget_tiny(self):
        """Very small budget should still be > 0."""
        cfg = FractalConfig(
            gate_signal_count=1,
            memory_token_budget_pct=0.0001,
            context_window_tokens=100_000,
        )
        assert cfg.memory_token_budget >= 1

    def test_budget_max(self):
        """Maximum budget should not exceed context window."""
        cfg = FractalConfig(
            gate_signal_count=1,
            memory_token_budget_pct=0.50,
            context_window_tokens=200_000,
        )
        assert cfg.memory_token_budget == 100_000


# ── Config property access ───────────────────────────────────────────


class TestConfigDefaults:
    def test_default_config_valid(self):
        """Default FractalConfig should pass all validation."""
        cfg = FractalConfig()
        assert cfg.gate_signal_count == 1
        assert cfg.embedding_dim == 384

    def test_frozen_config(self):
        """FractalConfig should be frozen (immutable)."""
        cfg = FractalConfig(gate_signal_count=1)
        with pytest.raises(AttributeError):
            cfg.gate_signal_count = 5  # type: ignore[misc]
