"""Tests for fractal_memory.niche — NicheConstructor (Phase 3, B-6)."""

from __future__ import annotations

import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.niche import (
    DomainProposal,
    NicheConstructor,
    NicheHealth,
    _is_valid_uuid,
)


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(
        niche_attract_rate=0.1,
        niche_repel_rate=0.05,
        niche_modularity_threshold=0.05,
        niche_min_cluster_size=3,
    )


def _make_niche(cfg: FractalConfig, associations: AsyncMock | None = None) -> NicheConstructor:
    storage = AsyncMock()
    storage.get_memories_by_domain.return_value = []
    storage.get_memory.return_value = None
    storage.update_memory = AsyncMock()

    assoc = associations if associations is not None else AsyncMock()
    if associations is None:
        assoc.adjust_edge_weight = AsyncMock()
    assoc.get_all_edges.return_value = []

    domains = AsyncMock()
    return NicheConstructor(
        storage=storage,
        associations=assoc,
        domains=domains,
        config=cfg,
    )


def _make_memory_stub(domain: str = "test") -> MagicMock:
    mem = MagicMock()
    mem.id = uuid.uuid4()
    mem.domain = domain
    return mem


# ---------------------------------------------------------------------------
# _is_valid_uuid helper
# ---------------------------------------------------------------------------


def test_is_valid_uuid_true_for_uuid() -> None:
    assert _is_valid_uuid(str(uuid.uuid4())) is True


def test_is_valid_uuid_false_for_garbage() -> None:
    assert _is_valid_uuid("not-a-uuid") is False


def test_is_valid_uuid_false_for_empty() -> None:
    assert _is_valid_uuid("") is False


def test_is_valid_uuid_false_for_integer_string() -> None:
    assert _is_valid_uuid("12345") is False


# ---------------------------------------------------------------------------
# on_co_retrieval_outcome — positive (attract)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_positive_outcome_calls_adjust_edge_weight(cfg: FractalConfig) -> None:
    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    niche = _make_niche(cfg, associations=assoc)

    ids = [uuid.uuid4(), uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="positive", domain="test")

    # 3 memories → 3 pairs (0-1, 0-2, 1-2)
    assert assoc.adjust_edge_weight.call_count == 3


@pytest.mark.asyncio
async def test_positive_outcome_increases_weight(cfg: FractalConfig) -> None:
    """Positive outcome: delta_fn should increase weight toward 1.0."""
    assoc = AsyncMock()
    captured_fns = []
    async def capture_adjust(id_a, id_b, delta_fn):
        captured_fns.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture_adjust

    niche = _make_niche(cfg, associations=assoc)
    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="positive", domain="test")

    assert len(captured_fns) == 1
    current_weight = 0.5
    new_weight = captured_fns[0](current_weight)
    # Should increase: w + attract_rate * (1 - w) > w
    assert new_weight > current_weight


@pytest.mark.asyncio
async def test_positive_outcome_weight_asymptotes_toward_1(cfg: FractalConfig) -> None:
    """Repeated positive outcomes push weight toward 1 but never exceed it."""
    assoc = AsyncMock()
    captured_fns = []
    async def capture_adjust(id_a, id_b, delta_fn):
        captured_fns.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture_adjust

    niche = _make_niche(cfg, associations=assoc)
    ids = [uuid.uuid4(), uuid.uuid4()]

    # Simulate 20 positive outcomes
    for _ in range(20):
        await niche.on_co_retrieval_outcome(ids, outcome="positive", domain="test")

    w = 0.0
    for fn in captured_fns:
        w = fn(w)
    assert w > 0.5, "Weight should grow substantially with repeated positive outcomes"
    assert w <= 1.0, "Weight must not exceed 1.0"


# ---------------------------------------------------------------------------
# on_co_retrieval_outcome — negative (repel)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_negative_outcome_calls_adjust_edge_weight(cfg: FractalConfig) -> None:
    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    niche = _make_niche(cfg, associations=assoc)

    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="negative", domain="test")

    assert assoc.adjust_edge_weight.call_count == 1


@pytest.mark.asyncio
async def test_negative_outcome_decreases_weight(cfg: FractalConfig) -> None:
    """Negative outcome: delta_fn should decrease weight toward 0."""
    assoc = AsyncMock()
    captured_fns = []
    async def capture_adjust(id_a, id_b, delta_fn):
        captured_fns.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture_adjust

    niche = _make_niche(cfg, associations=assoc)
    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="negative", domain="test")

    assert len(captured_fns) == 1
    current_weight = 0.5
    new_weight = captured_fns[0](current_weight)
    assert new_weight < current_weight


@pytest.mark.asyncio
async def test_negative_outcome_never_below_zero(cfg: FractalConfig) -> None:
    """Negative outcome: weight decays toward 0 but the formula stays non-negative for non-negative inputs."""
    assoc = AsyncMock()
    captured_fns = []
    async def capture_adjust(id_a, id_b, delta_fn):
        captured_fns.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture_adjust

    niche = _make_niche(cfg, associations=assoc)
    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="negative", domain="test")

    fn = captured_fns[0]
    # w - repel_rate * w = w * (1 - repel_rate); non-negative for non-negative w
    result = fn(0.5)
    assert result >= 0.0


# ---------------------------------------------------------------------------
# on_co_retrieval_outcome — edge cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_calls_for_single_memory(cfg: FractalConfig) -> None:
    """Single memory has no pairs — no edge adjustment calls."""
    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    niche = _make_niche(cfg, associations=assoc)

    await niche.on_co_retrieval_outcome([uuid.uuid4()], outcome="positive", domain="test")
    assoc.adjust_edge_weight.assert_not_called()


@pytest.mark.asyncio
async def test_no_calls_for_empty_memory_list(cfg: FractalConfig) -> None:
    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    niche = _make_niche(cfg, associations=assoc)

    await niche.on_co_retrieval_outcome([], outcome="positive", domain="test")
    assoc.adjust_edge_weight.assert_not_called()


@pytest.mark.asyncio
async def test_unknown_outcome_makes_no_calls(cfg: FractalConfig) -> None:
    """Unknown outcome string should not call adjust_edge_weight."""
    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    niche = _make_niche(cfg, associations=assoc)

    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="neutral", domain="test")
    assoc.adjust_edge_weight.assert_not_called()


@pytest.mark.asyncio
async def test_uses_config_attract_rate(cfg: FractalConfig) -> None:
    """attract_rate from config must be used, not a hardcoded constant."""
    cfg2 = FractalConfig(niche_attract_rate=0.5)
    assoc = AsyncMock()
    captured = []
    async def capture(a, b, delta_fn):
        captured.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture

    niche = _make_niche(cfg2, associations=assoc)
    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, outcome="positive", domain="test")

    fn = captured[0]
    w = 0.5
    result = fn(w)
    # w + 0.5 * (1 - 0.5) = 0.75
    assert abs(result - 0.75) < 1e-6


# ---------------------------------------------------------------------------
# detect_domain_clusters
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_detect_returns_empty_when_no_edges(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    niche._associations.get_all_edges.return_value = []
    proposals = await niche.detect_domain_clusters()
    assert proposals == []


@pytest.mark.asyncio
async def test_detect_returns_empty_when_networkx_missing(cfg: FractalConfig, monkeypatch) -> None:
    """If networkx is not installed, detect_domain_clusters returns [] gracefully."""
    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "networkx":
            raise ImportError("networkx not available")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)
    niche = _make_niche(cfg)
    proposals = await niche.detect_domain_clusters()
    assert proposals == []


@pytest.mark.asyncio
async def test_detect_returns_proposals_list(cfg: FractalConfig) -> None:
    """detect_domain_clusters returns a list (even if empty)."""
    niche = _make_niche(cfg)
    result = await niche.detect_domain_clusters()
    assert isinstance(result, list)


# ---------------------------------------------------------------------------
# apply_domain_proposals
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_empty_proposals_returns_zero(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    count = await niche.apply_domain_proposals([])
    assert count == 0


@pytest.mark.asyncio
async def test_apply_reassigns_memories(cfg: FractalConfig) -> None:
    mem_id = uuid.uuid4()
    mem = _make_memory_stub(domain="old-domain")
    mem.id = mem_id

    storage = AsyncMock()
    storage.get_memory.return_value = mem
    storage.update_memory = AsyncMock()

    assoc = AsyncMock()
    assoc.adjust_edge_weight = AsyncMock()
    assoc.get_all_edges.return_value = []

    niche = NicheConstructor(storage=storage, associations=assoc, domains=AsyncMock(), config=cfg)

    proposal = DomainProposal(
        memory_ids=[mem_id],
        proposed_domain="new-domain",
        current_domains=["old-domain"],
        modularity_delta=0.1,
        confidence=0.7,
    )
    count = await niche.apply_domain_proposals([proposal])

    assert count == 1
    assert mem.domain == "new-domain"
    storage.update_memory.assert_called_once_with(mem)


@pytest.mark.asyncio
async def test_apply_skips_already_correct_domain(cfg: FractalConfig) -> None:
    """If memory is already in the proposed domain, no update is called."""
    mem_id = uuid.uuid4()
    mem = _make_memory_stub(domain="target-domain")
    mem.id = mem_id

    storage = AsyncMock()
    storage.get_memory.return_value = mem
    storage.update_memory = AsyncMock()

    assoc = AsyncMock()
    assoc.get_all_edges.return_value = []

    niche = NicheConstructor(storage=storage, associations=assoc, domains=AsyncMock(), config=cfg)

    proposal = DomainProposal(
        memory_ids=[mem_id],
        proposed_domain="target-domain",  # same as current
        current_domains=["target-domain"],
        modularity_delta=0.1,
        confidence=0.7,
    )
    count = await niche.apply_domain_proposals([proposal])

    assert count == 0
    storage.update_memory.assert_not_called()


@pytest.mark.asyncio
async def test_apply_updates_stability_tracker(cfg: FractalConfig) -> None:
    """After applying a proposal, the domain's stability session counter is set."""
    mem_id = uuid.uuid4()
    mem = _make_memory_stub(domain="old")
    mem.id = mem_id

    storage = AsyncMock()
    storage.get_memory.return_value = mem
    storage.update_memory = AsyncMock()
    assoc = AsyncMock()
    assoc.get_all_edges.return_value = []

    niche = NicheConstructor(storage=storage, associations=assoc, domains=AsyncMock(), config=cfg)
    niche._session_count = 5

    proposal = DomainProposal(
        memory_ids=[mem_id],
        proposed_domain="new-domain",
        current_domains=["old"],
        modularity_delta=0.1,
        confidence=0.8,
    )
    await niche.apply_domain_proposals([proposal])

    assert "new-domain" in niche._stability
    assert niche._stability["new-domain"] == 5


# ---------------------------------------------------------------------------
# get_niche_health
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_niche_health_returns_correct_type(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    health = await niche.get_niche_health("test")
    assert isinstance(health, NicheHealth)


@pytest.mark.asyncio
async def test_niche_health_domain_field(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    health = await niche.get_niche_health("my-domain")
    assert health.domain == "my-domain"


@pytest.mark.asyncio
async def test_niche_health_memory_count(cfg: FractalConfig) -> None:
    mem1 = _make_memory_stub("test")
    mem2 = _make_memory_stub("test")
    niche = _make_niche(cfg)
    niche._storage.get_memories_by_domain.return_value = [mem1, mem2]
    health = await niche.get_niche_health("test")
    assert health.memory_count == 2


@pytest.mark.asyncio
async def test_niche_health_zero_memories(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    niche._storage.get_memories_by_domain.return_value = []
    health = await niche.get_niche_health("empty-domain")
    assert health.memory_count == 0
    assert health.internal_cohesion == 0.0


@pytest.mark.asyncio
async def test_niche_health_cohesion_from_internal_edges(cfg: FractalConfig) -> None:
    """Internal cohesion is the mean edge weight between domain members."""
    mem1 = _make_memory_stub("test")
    mem2 = _make_memory_stub("test")

    assoc = AsyncMock()
    assoc.get_all_edges.return_value = [
        {"source": str(mem1.id), "target": str(mem2.id), "weight": 0.8}
    ]

    storage = AsyncMock()
    storage.get_memories_by_domain.return_value = [mem1, mem2]
    storage.get_memory.return_value = None
    storage.update_memory = AsyncMock()

    niche = NicheConstructor(storage=storage, associations=assoc, domains=AsyncMock(), config=cfg)
    health = await niche.get_niche_health("test")

    assert abs(health.internal_cohesion - 0.8) < 1e-5


@pytest.mark.asyncio
async def test_niche_health_external_separation_from_cross_edges(cfg: FractalConfig) -> None:
    """External separation is 1 minus mean cross-domain edge weight."""
    mem_in = _make_memory_stub("test")
    mem_out = _make_memory_stub("other")

    assoc = AsyncMock()
    assoc.get_all_edges.return_value = [
        {"source": str(mem_in.id), "target": str(mem_out.id), "weight": 0.2}
    ]

    storage = AsyncMock()
    storage.get_memories_by_domain.return_value = [mem_in]
    storage.get_memory.return_value = None
    storage.update_memory = AsyncMock()

    niche = NicheConstructor(storage=storage, associations=assoc, domains=AsyncMock(), config=cfg)
    health = await niche.get_niche_health("test")

    assert abs(health.external_separation - 0.8) < 1e-5


@pytest.mark.asyncio
async def test_niche_health_stability_is_session_based(cfg: FractalConfig) -> None:
    """stability_sessions is (current_session - last_reassignment_session)."""
    niche = _make_niche(cfg)
    niche._session_count = 10
    niche._stability["test-domain"] = 7  # last reassigned at session 7
    health = await niche.get_niche_health("test-domain")
    assert health.stability_sessions == 3  # 10 - 7


@pytest.mark.asyncio
async def test_niche_health_stability_for_never_reassigned(cfg: FractalConfig) -> None:
    """Domain never reassigned → stability = full session_count."""
    niche = _make_niche(cfg)
    niche._session_count = 8
    health = await niche.get_niche_health("pristine-domain")
    assert health.stability_sessions == 8


# ---------------------------------------------------------------------------
# increment_session
# ---------------------------------------------------------------------------


def test_increment_session_increases_counter(cfg: FractalConfig) -> None:
    niche = _make_niche(cfg)
    assert niche._session_count == 0
    niche.increment_session()
    assert niche._session_count == 1
    niche.increment_session()
    assert niche._session_count == 2


# ---------------------------------------------------------------------------
# DomainProposal dataclass
# ---------------------------------------------------------------------------


def test_domain_proposal_fields() -> None:
    ids = [uuid.uuid4(), uuid.uuid4()]
    proposal = DomainProposal(
        memory_ids=ids,
        proposed_domain="cluster-A",
        current_domains=["dom1", "dom2"],
        modularity_delta=0.12,
        confidence=0.75,
    )
    assert proposal.memory_ids == ids
    assert proposal.proposed_domain == "cluster-A"
    assert proposal.modularity_delta == pytest.approx(0.12)
    assert 0.0 <= proposal.confidence <= 1.0


# ---------------------------------------------------------------------------
# NicheHealth dataclass
# ---------------------------------------------------------------------------


def test_niche_health_cohesion_bounds() -> None:
    health = NicheHealth(
        domain="x",
        internal_cohesion=0.7,
        external_separation=0.6,
        stability_sessions=5,
        memory_count=10,
    )
    assert 0.0 <= health.internal_cohesion <= 1.0
    assert 0.0 <= health.external_separation <= 1.0
    assert health.stability_sessions >= 0
    assert health.memory_count >= 0


# ---------------------------------------------------------------------------
# Louvain determinism — same graph produces same communities
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_louvain_deterministic_seed(cfg: FractalConfig) -> None:
    """Same graph edges should produce the same communities across repeated calls."""
    # Create a graph with clear community structure
    ids = [uuid.uuid4() for _ in range(6)]
    edges = []
    # Cluster 1: ids[0:3] strongly connected
    for i in range(3):
        for j in range(i + 1, 3):
            edges.append({"source": str(ids[i]), "target": str(ids[j]), "weight": 0.9})
    # Cluster 2: ids[3:6] strongly connected
    for i in range(3, 6):
        for j in range(i + 1, 6):
            edges.append({"source": str(ids[i]), "target": str(ids[j]), "weight": 0.9})
    # Weak cross-cluster link
    edges.append({"source": str(ids[0]), "target": str(ids[3]), "weight": 0.05})

    assoc = AsyncMock()
    assoc.get_all_edges = AsyncMock(return_value=edges)
    niche = NicheConstructor(
        storage=AsyncMock(), associations=assoc, domains=AsyncMock(), config=cfg,
    )

    results_1 = await niche.detect_domain_clusters()
    results_2 = await niche.detect_domain_clusters()

    # Same number of proposals with same memory IDs
    assert len(results_1) == len(results_2)
    ids_1 = [sorted(str(m) for m in r.memory_ids) for r in results_1]
    ids_2 = [sorted(str(m) for m in r.memory_ids) for r in results_2]
    assert sorted(ids_1) == sorted(ids_2)


# ---------------------------------------------------------------------------
# Minimum cluster size
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_minimum_cluster_size_filter(cfg: FractalConfig) -> None:
    """Clusters smaller than niche_min_cluster_size should not produce proposals."""
    cfg2 = FractalConfig(niche_min_cluster_size=10)

    # Create a tiny graph (< 10 nodes)
    ids = [uuid.uuid4() for _ in range(4)]
    edges = [
        {"source": str(ids[0]), "target": str(ids[1]), "weight": 0.9},
        {"source": str(ids[2]), "target": str(ids[3]), "weight": 0.9},
    ]

    assoc = AsyncMock()
    assoc.get_all_edges = AsyncMock(return_value=edges)
    niche = NicheConstructor(
        storage=AsyncMock(), associations=assoc, domains=AsyncMock(), config=cfg2,
    )

    proposals = await niche.detect_domain_clusters()
    assert proposals == []


# ---------------------------------------------------------------------------
# Weight bounds clamping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_weight_bounds_clamped_on_positive_outcome(cfg: FractalConfig) -> None:
    """Positive outcome should not push weight above 0.99."""
    assoc = AsyncMock()
    captured_fns = []
    async def capture(a, b, delta_fn):
        captured_fns.append(delta_fn)
    assoc.adjust_edge_weight.side_effect = capture

    niche = NicheConstructor(
        storage=AsyncMock(), associations=assoc, domains=AsyncMock(), config=cfg,
    )

    ids = [uuid.uuid4(), uuid.uuid4()]
    await niche.on_co_retrieval_outcome(ids, "positive", "test")

    fn = captured_fns[0]
    # Even with weight near 1.0, result should be <= 0.99
    result = fn(0.999)
    assert result <= 0.99
