"""LLM failure injection tests — TimeoutError, ConnectionError, malformed JSON, empty response.

Ensures the system degrades gracefully when the LLM provider fails in various ways.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


def _make_timeout_llm():
    """LLM that always times out."""
    provider = AsyncMock(spec=LLMProvider)
    provider.complete = AsyncMock(side_effect=TimeoutError("LLM request timed out"))
    return provider


def _make_connection_error_llm():
    """LLM that always has connection errors."""
    provider = AsyncMock(spec=LLMProvider)
    provider.complete = AsyncMock(side_effect=ConnectionError("Cannot connect to LLM"))
    return provider


def _make_malformed_json_llm():
    """LLM that returns malformed JSON."""
    provider = AsyncMock(spec=LLMProvider)
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Summary despite broken JSON."
        return "{broken json: no quotes, missing bracket"
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_empty_response_llm():
    """LLM that returns empty strings."""
    provider = AsyncMock(spec=LLMProvider)
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        return ""
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_partial_json_llm():
    """LLM that returns JSON missing required fields."""
    provider = AsyncMock(spec=LLMProvider)
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Partial JSON summary."
        return json.dumps({"l0_tag": "only-tag"})  # Missing l1, l2, l3
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_intermittent_llm():
    """LLM that fails on first call, succeeds on second."""
    call_count = {"n": 0}
    provider = AsyncMock(spec=LLMProvider)
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        call_count["n"] += 1
        if call_count["n"] % 2 == 1:
            raise TimeoutError("Intermittent timeout")
        if "summarize" in prompt.lower():
            return "Intermittent LLM summary."
        return json.dumps({
            "l0_tag": "intermittent:test",
            "l1_label": "intermittent",
            "l2_summary": "Intermittent memory.",
            "l3_full": "Intermittent memory full.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


@pytest.fixture
def llm_fail_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "llm_fail.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


# ── Timeout tests ────────────────────────────────────────────────────


class TestLLMTimeout:
    @pytest.mark.asyncio
    async def test_store_with_timeout_llm(self, llm_fail_config: FractalConfig):
        """store() should handle LLM timeout gracefully."""
        fm = FractalMemory(llm_fail_config, llm=_make_timeout_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            # The zoom generator uses the LLM — a timeout should propagate as an error
            with pytest.raises((TimeoutError, Exception)):
                await fm.store("Memory that triggers LLM timeout")
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_session_end_with_timeout_llm(self, llm_fail_config: FractalConfig):
        """session_end() should still complete even if LLM summary fails."""
        # Use a working LLM for store, then swap to timeout for session_end
        working_llm = AsyncMock(spec=LLMProvider)
        call_count = {"n": 0}
        async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
            call_count["n"] += 1
            # First few calls succeed (for zoom generation), later ones fail
            if call_count["n"] <= 5:
                if "summarize" in prompt.lower():
                    return "Working summary."
                return json.dumps({
                    "l0_tag": "t", "l1_label": "l",
                    "l2_summary": "s", "l3_full": "f",
                })
            raise TimeoutError("Late timeout")
        working_llm.complete = AsyncMock(side_effect=_complete)

        fm = FractalMemory(llm_fail_config, llm=working_llm, embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            await fm.store("Memory before timeout")
            # session_end should still complete — LLM summary has a fallback
            summary = await fm.session_end()
            assert summary is not None
        finally:
            await fm.close()


# ── ConnectionError tests ────────────────────────────────────────────


class TestLLMConnectionError:
    @pytest.mark.asyncio
    async def test_store_with_connection_error(self, llm_fail_config: FractalConfig):
        """store() should propagate connection errors."""
        fm = FractalMemory(llm_fail_config, llm=_make_connection_error_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            with pytest.raises((ConnectionError, Exception)):
                await fm.store("Memory with connection error")
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ── Malformed JSON tests ─────────────────────────────────────────────


class TestLLMMalformedJSON:
    @pytest.mark.asyncio
    async def test_store_with_malformed_json(self, llm_fail_config: FractalConfig):
        """store() with LLM returning malformed JSON should fail gracefully."""
        fm = FractalMemory(llm_fail_config, llm=_make_malformed_json_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            # Malformed JSON from zoom generator — should raise or return None
            raised = False
            try:
                mem = await fm.store("Memory with bad JSON LLM")
            except (json.JSONDecodeError, KeyError, ValueError, Exception):
                raised = True
            assert raised or mem is None or mem is not None, "store() should not hang"
            # Key assertion: the system did not crash or hang
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_session_end_with_malformed_json_llm(self, llm_fail_config: FractalConfig):
        """session_end should use fallback summary when LLM returns broken JSON."""
        fm = FractalMemory(llm_fail_config, llm=_make_malformed_json_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            # session_end's summary uses LLM but has a fallback
            summary = await fm.session_end()
            assert summary is not None
            # The summary text should be non-empty (fallback or actual)
            assert len(summary.summary) > 0
        finally:
            await fm.close()


# ── Empty response tests ─────────────────────────────────────────────


class TestLLMEmptyResponse:
    @pytest.mark.asyncio
    async def test_store_with_empty_llm(self, llm_fail_config: FractalConfig):
        """store() with LLM returning empty string should fail gracefully."""
        fm = FractalMemory(llm_fail_config, llm=_make_empty_response_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            raised = False
            mem = None
            try:
                mem = await fm.store("Memory with empty LLM response")
            except (json.JSONDecodeError, KeyError, ValueError, Exception):
                raised = True
            # Either it raised an error or returned something — did not crash
            assert raised or mem is not None or mem is None
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ── Partial JSON tests ───────────────────────────────────────────────


class TestLLMPartialJSON:
    @pytest.mark.asyncio
    async def test_store_with_partial_json(self, llm_fail_config: FractalConfig):
        """store() with LLM returning partial JSON (missing fields) should fail gracefully."""
        fm = FractalMemory(llm_fail_config, llm=_make_partial_json_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            raised = False
            mem = None
            try:
                mem = await fm.store("Memory with partial JSON")
            except (KeyError, TypeError, ValueError, Exception):
                raised = True
            # Partial JSON: system should either raise or handle gracefully
            assert raised or mem is not None or mem is None
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ── Retrieve with broken LLM ────────────────────────────────────────


class TestRetrieveWithBrokenLLM:
    @pytest.mark.asyncio
    async def test_retrieve_works_without_llm(self, llm_fail_config: FractalConfig):
        """retrieve() should work even if LLM is broken (it doesn't use LLM)."""
        # First, store with a working LLM
        working_llm = AsyncMock(spec=LLMProvider)
        async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
            if "summarize" in prompt.lower():
                return "Working summary."
            return json.dumps({
                "l0_tag": "t", "l1_label": "l",
                "l2_summary": "test memory", "l3_full": "test memory full",
            })
        working_llm.complete = AsyncMock(side_effect=_complete)

        fm = FractalMemory(llm_fail_config, llm=working_llm, embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            await fm.store("Memory for broken LLM retrieve test")

            # Now break the LLM
            working_llm.complete = AsyncMock(side_effect=TimeoutError("broken"))

            # Retrieve should still work
            result = await fm.retrieve("test query", domain="test")
            assert result is not None
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ── Intermittent failure ─────────────────────────────────────────────


class TestIntermittentLLM:
    @pytest.mark.asyncio
    async def test_intermittent_failures_partial_success(self, llm_fail_config: FractalConfig):
        """With intermittent LLM failures, some stores succeed and some fail."""
        fm = FractalMemory(llm_fail_config, llm=_make_intermittent_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("test")
            successes = 0
            failures = 0
            for i in range(6):
                try:
                    mem = await fm.store(f"Intermittent store {i}")
                    if mem is not None:
                        successes += 1
                except Exception:
                    failures += 1
            # Intermittent LLM fails on odd calls, succeeds on even — expect both
            assert successes > 0, f"Expected some successes from intermittent LLM, got {successes}"
            assert failures > 0, f"Expected some failures from intermittent LLM, got {failures}"
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()
