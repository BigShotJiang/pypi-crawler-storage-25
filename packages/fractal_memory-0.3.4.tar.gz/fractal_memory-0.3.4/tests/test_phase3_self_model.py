"""Tests for fractal_memory.self_model — SelfModel (Phase 3)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.self_model import ExplanationReport, HealthReport, SelfModel
from fractal_memory.states import SystemState, SystemStateManager


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig()


def _make_domain_stub(name: str = "test", memory_count: int = 50) -> MagicMock:
    d = MagicMock()
    d.name = name
    d.memory_count = memory_count
    return d


@pytest.fixture
def self_model(cfg: FractalConfig) -> SelfModel:
    storage = AsyncMock()
    storage.get_session_stats.return_value = {"retrieval_hits": 8, "retrieval_total": 10}
    storage.count_active_scars.return_value = 3
    storage.get_chronic_memories.return_value = [MagicMock()]

    associations = AsyncMock()
    associations.get_stats.return_value = {"nodes_with_edges": 20, "edge_count": 40, "avg_weight": 0.5, "max_weight": 0.9}

    morphogens = MagicMock()
    morphogens.has_converged.return_value = False
    morphogens.last_morphogens = None
    morphogens.curves = []
    morphogens.get_parameter.return_value = None

    domains = AsyncMock()
    domain_stub = _make_domain_stub("general", 50)
    domains.list_domains_with_stats.return_value = [domain_stub]
    domains.domain_stats.return_value = domain_stub

    states = SystemStateManager(cfg)
    from fractal_memory.bandits import ContextualBandit
    bandits = ContextualBandit(cfg)

    return SelfModel(
        storage=storage,
        associations=associations,
        morphogens=morphogens,
        domains=domains,
        config=cfg,
        states=states,
        bandits=bandits,
    )


# ---------------------------------------------------------------------------
# health()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_health_returns_health_report(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert isinstance(report, HealthReport)


@pytest.mark.asyncio
async def test_health_retrieval_hit_rate(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert abs(report.retrieval_hit_rate - 0.8) < 1e-5


@pytest.mark.asyncio
async def test_health_scar_count(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert report.scar_count == 3


@pytest.mark.asyncio
async def test_health_chronic_count(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert report.chronic_memories_count == 1


@pytest.mark.asyncio
async def test_health_association_density(self_model: SelfModel) -> None:
    report = await self_model.health()
    # 40 edges / 20 nodes = 2.0
    assert abs(report.association_density - 2.0) < 1e-5


@pytest.mark.asyncio
async def test_health_system_state_is_string(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert isinstance(report.system_state, str)
    assert report.system_state in ("flow", "stress", "curiosity")


@pytest.mark.asyncio
async def test_health_morphogen_convergence_has_keys(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert "converged" in report.morphogen_convergence
    assert isinstance(report.morphogen_convergence["converged"], bool)


@pytest.mark.asyncio
async def test_health_total_memories_has_domain(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert "general" in report.total_memories
    assert report.total_memories["general"] == 50


@pytest.mark.asyncio
async def test_health_bandit_distribution_is_dict(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert isinstance(report.bandit_arm_distribution, dict)


@pytest.mark.asyncio
async def test_health_flagged_parameters_is_list(self_model: SelfModel) -> None:
    report = await self_model.health()
    assert isinstance(report.flagged_parameters, list)


@pytest.mark.asyncio
async def test_health_cascade_warnings_list(self_model: SelfModel) -> None:
    self_model.record_cascade_warnings(["w1", "w2"])
    report = await self_model.health()
    assert report.cascade_warnings == ["w1", "w2"]


@pytest.mark.asyncio
async def test_health_tolerates_storage_exceptions(cfg: FractalConfig) -> None:
    storage = AsyncMock()
    storage.get_session_stats.side_effect = Exception("DB error")
    storage.count_active_scars.side_effect = Exception("DB error")
    storage.get_chronic_memories.side_effect = Exception("DB error")
    associations = AsyncMock()
    associations.get_stats.side_effect = Exception("No graph")
    morphogens = MagicMock()
    morphogens.has_converged.return_value = False
    morphogens.last_morphogens = None
    morphogens.curves = []
    morphogens.get_parameter.return_value = None
    domains = AsyncMock()
    domains.list_domains_with_stats.side_effect = Exception("No domains")
    sm = SelfModel(storage=storage, associations=associations, morphogens=morphogens, domains=domains, config=cfg)
    # Should not raise
    report = await sm.health()
    assert report.retrieval_hit_rate == 0.0
    assert report.scar_count == 0


# ---------------------------------------------------------------------------
# explain_last()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_explain_last_returns_report(self_model: SelfModel) -> None:
    report = await self_model.explain_last()
    assert isinstance(report, ExplanationReport)


@pytest.mark.asyncio
async def test_explain_last_reflects_record_retrieval(self_model: SelfModel) -> None:
    self_model.record_retrieval(
        query="What is X?",
        retrieved=[{"id": "abc", "score": 0.9}],
        suppressed=[{"id": "def", "reason": "scar"}],
    )
    report = await self_model.explain_last()
    assert report.query == "What is X?"
    assert len(report.retrieved_memories) == 1
    assert len(report.suppressed_memories) == 1


@pytest.mark.asyncio
async def test_explain_last_morphogens_empty_without_last(self_model: SelfModel) -> None:
    self_model._morphogens.last_morphogens = None
    report = await self_model.explain_last()
    assert report.morphogens == {}


@pytest.mark.asyncio
async def test_explain_last_morphogens_present(self_model: SelfModel) -> None:
    from fractal_memory.morphogens import MorphogenState
    self_model._morphogens.last_morphogens = MorphogenState(
        information_richness=0.6, retrieval_pressure=0.4, domain_density=0.8
    )
    report = await self_model.explain_last()
    assert "information_richness" in report.morphogens
    assert abs(report.morphogens["information_richness"] - 0.6) < 1e-5


@pytest.mark.asyncio
async def test_explain_last_bandit_arm(self_model: SelfModel) -> None:
    from fractal_memory.morphogens import MorphogenState
    morphs = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
    self_model._bandits.select_arm(morphs)
    report = await self_model.explain_last()
    assert report.bandit_arm_selected in ("conservative", "aggressive", "precision", "exploratory", "balanced")


# ---------------------------------------------------------------------------
# domain_maturity()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_domain_maturity_pioneer_low_counts(self_model: SelfModel) -> None:
    self_model._domains.domain_stats.return_value = MagicMock(memory_count=5, session_count=2)
    result = await self_model.domain_maturity("test")
    assert result == "pioneer"


@pytest.mark.asyncio
async def test_domain_maturity_shrub(self_model: SelfModel) -> None:
    self_model._domains.domain_stats.return_value = MagicMock(memory_count=50, session_count=10)
    self_model._morphogens.has_converged.return_value = False
    result = await self_model.domain_maturity("test")
    assert result == "shrub"


@pytest.mark.asyncio
async def test_domain_maturity_forest(self_model: SelfModel) -> None:
    self_model._domains.domain_stats.return_value = MagicMock(memory_count=150, session_count=20)
    self_model._morphogens.has_converged.return_value = False
    result = await self_model.domain_maturity("test")
    assert result == "forest"


@pytest.mark.asyncio
async def test_domain_maturity_mature(self_model: SelfModel) -> None:
    self_model._domains.domain_stats.return_value = MagicMock(memory_count=500, session_count=30)
    self_model._morphogens.has_converged.return_value = True
    result = await self_model.domain_maturity("test")
    assert result == "mature"


@pytest.mark.asyncio
async def test_domain_maturity_pioneer_on_exception(self_model: SelfModel) -> None:
    self_model._domains.domain_stats.side_effect = Exception("no domain")
    result = await self_model.domain_maturity("missing")
    assert result == "pioneer"


# ---------------------------------------------------------------------------
# record_retrieval / record_cascade_warnings
# ---------------------------------------------------------------------------


def test_record_retrieval_updates_fields(self_model: SelfModel) -> None:
    self_model.record_retrieval(
        query="test query",
        retrieved=[{"id": "1"}],
        suppressed=[],
    )
    assert self_model._last_query == "test query"


def test_record_cascade_warnings_stores_list(self_model: SelfModel) -> None:
    warnings = [{"severity": 0.5}, {"severity": 0.8}]
    self_model.record_cascade_warnings(warnings)
    assert self_model._cascade_warnings == warnings


def test_record_cascade_warnings_stores_copy(self_model: SelfModel) -> None:
    warnings = [{"severity": 0.5}]
    self_model.record_cascade_warnings(warnings)
    warnings.clear()
    assert len(self_model._cascade_warnings) == 1


# ---------------------------------------------------------------------------
# flag_parameter_drift
# ---------------------------------------------------------------------------


def test_flag_parameter_drift_empty_without_params(self_model: SelfModel) -> None:
    self_model._morphogens.curves = []
    result = self_model.flag_parameter_drift()
    assert result == []


def test_flag_parameter_drift_no_flag_at_base_value(self_model: SelfModel) -> None:
    from fractal_memory.morphogens import ResponseCurve
    curve = ResponseCurve(
        name="gate_strictness",
        morphogen_weights={"domain_density": 1.0},
        base_value=0.5,
        midpoint=0.5,
        steepness=5.0,
        min_value=0.1,
        max_value=0.9,
    )
    self_model._morphogens.curves = [curve]
    self_model._morphogens.get_parameter.return_value = 0.5  # at base value
    result = self_model.flag_parameter_drift()
    assert "gate_strictness" not in result


def test_flag_parameter_drift_flags_2x_base_value(self_model: SelfModel) -> None:
    from fractal_memory.morphogens import ResponseCurve
    curve = ResponseCurve(
        name="gate_strictness",
        morphogen_weights={"domain_density": 1.0},
        base_value=0.5,
        midpoint=0.5,
        steepness=5.0,
        min_value=0.1,
        max_value=0.9,
    )
    self_model._morphogens.curves = [curve]
    self_model._morphogens.get_parameter.return_value = 1.5  # > 2 × 0.5
    result = self_model.flag_parameter_drift()
    assert "gate_strictness" in result


# ---------------------------------------------------------------------------
# Issue #11 — health() uses list_domains_with_stats (correct method)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_health_report_total_memories_per_domain(cfg: FractalConfig) -> None:
    """health() populates total_memories from list_domains_with_stats()."""
    storage = AsyncMock()
    storage.get_session_stats.return_value = {"retrieval_hits": 0, "retrieval_total": 1}
    storage.count_active_scars.return_value = 0
    storage.get_chronic_memories.return_value = []

    associations = AsyncMock()
    associations.get_stats.return_value = {"nodes_with_edges": 1, "edge_count": 0, "avg_weight": 0, "max_weight": 0}

    morphogens = MagicMock()
    morphogens.has_converged.return_value = False
    morphogens.last_morphogens = None
    morphogens.curves = []
    morphogens.get_parameter.return_value = None

    domains = AsyncMock()
    work_stub = _make_domain_stub("work", 3)
    personal_stub = _make_domain_stub("personal", 2)
    domains.list_domains_with_stats.return_value = [work_stub, personal_stub]
    domains.domain_stats.return_value = work_stub

    sm = SelfModel(
        storage=storage, associations=associations,
        morphogens=morphogens, domains=domains, config=cfg,
    )
    report = await sm.health()
    assert report.total_memories == {"work": 3, "personal": 2}


# ---------------------------------------------------------------------------
# Issue #12 — health() reads correct keys from get_stats()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_health_report_association_density_computed_correctly(cfg: FractalConfig) -> None:
    """association_density = edge_count / nodes_with_edges, not 0.0."""
    storage = AsyncMock()
    storage.get_session_stats.return_value = {"retrieval_hits": 0, "retrieval_total": 1}
    storage.count_active_scars.return_value = 0
    storage.get_chronic_memories.return_value = []

    associations = AsyncMock()
    associations.get_stats.return_value = {
        "nodes_with_edges": 3,
        "edge_count": 2,
        "avg_weight": 0.5,
        "max_weight": 0.9,
    }

    morphogens = MagicMock()
    morphogens.has_converged.return_value = False
    morphogens.last_morphogens = None
    morphogens.curves = []
    morphogens.get_parameter.return_value = None

    domains = AsyncMock()
    domains.list_domains_with_stats.return_value = []

    sm = SelfModel(
        storage=storage, associations=associations,
        morphogens=morphogens, domains=domains, config=cfg,
    )
    report = await sm.health()
    assert abs(report.association_density - (2 / 3)) < 1e-5
