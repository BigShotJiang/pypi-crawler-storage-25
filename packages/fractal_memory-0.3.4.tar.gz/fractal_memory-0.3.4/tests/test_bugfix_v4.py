"""Tests for bug fixes from issues4.md (v0.3.2 stress test report).

Each test verifies the specific fix for one validated bug, following
TEST_REQUIREMENTS.md: exact assertions, boundary conditions, observable
behavior, deterministic fixtures.
"""

from __future__ import annotations

import dataclasses
from collections import deque
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from fractal_memory import FractalMemory, WaitingRoomEntry
from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.feedback import BatchedLLMJudge
from fractal_memory.folding import DimensionalFolder
from fractal_memory.gate import Signal
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# BUG 1: _propagate_config() must update all subsystems
# ---------------------------------------------------------------------------


class TestPropagateConfigAllSubsystems:
    """BUG 1: Verify _propagate_config updates all 23 subsystems."""

    @pytest.mark.asyncio
    async def test_all_subsystems_receive_new_config(
        self, tmp_config: FractalConfig, mock_llm, mock_embeddings
    ):
        """Every subsystem must hold a reference to the new config after propagation."""
        fm = FractalMemory(tmp_config, llm=mock_llm, embeddings=mock_embeddings)
        await fm.initialize()
        try:
            new_config = dataclasses.replace(tmp_config, gate_signal_count=3)
            fm._propagate_config(new_config)

            # All 23 subsystems that were missing or present
            subsystems = [
                ("_storage", fm._storage),
                ("_retrieval", fm._retrieval),
                ("_gate", fm._gate),
                ("_lifecycle", fm._lifecycle),
                ("_session", fm._session),
                ("_consolidation", fm._consolidation),
                ("_associations", fm._associations),
                ("_morphogens", fm._morphogens),
                ("_self_model", fm._self_model),
                ("_domain_manager", fm._domain_manager),
                ("_bandits", fm._bandits),
                ("_dreaming", fm._dreaming),
                ("_maintenance", fm._maintenance),
                ("_apoptosis", fm._apoptosis),
                ("_scars", fm._scars),
                # Previously missing 8 subsystems (BUG 1):
                ("_niche", fm._niche),
                ("_buffer", fm._buffer),
                ("_folding", fm._folding),
                ("_cascade", fm._cascade),
                ("_danger_theory", fm._danger_theory),
                ("_store_signal_detector", fm._store_signal_detector),
                ("_judge", fm._judge),
                ("_states", fm._states),
            ]

            for name, subsystem in subsystems:
                assert subsystem._config is new_config, (
                    f"Subsystem {name} still has old config after _propagate_config()"
                )

            assert fm._config is new_config
            assert fm._config.gate_signal_count == 3
        finally:
            await fm.close()


# ---------------------------------------------------------------------------
# BUG 2: store() intensity parameter must be respected
# ---------------------------------------------------------------------------


class TestStoreIntensityRespected:
    """BUG 2: User-provided intensity must act as a floor for final intensity."""

    @pytest.mark.asyncio
    async def test_high_user_intensity_preserved(self, fractal_memory: FractalMemory):
        """User intensity=0.9 should be preserved when gate computes lower."""
        await fractal_memory.session_start("intensity-test")
        mem = await fractal_memory.store(
            "Important user memory", domain="intensity-test", intensity=0.9
        )
        assert mem is not None
        # User provided 0.9; gate computes ~0.65 from EXPLICIT_STORE signal.
        # max(0.9, ~0.65) = 0.9
        assert mem.intensity >= 0.9

    @pytest.mark.asyncio
    async def test_low_user_intensity_allows_gate_boost(self, fractal_memory: FractalMemory):
        """User intensity=0.1 should still allow gate to boost higher."""
        await fractal_memory.session_start("intensity-test")
        mem = await fractal_memory.store(
            "Low priority memory", domain="intensity-test", intensity=0.1
        )
        assert mem is not None
        # max(0.1, gate_computed) — gate always computes > 0.1 with EXPLICIT_STORE
        assert mem.intensity >= 0.1

    @pytest.mark.asyncio
    async def test_different_intensities_produce_different_results(
        self, fractal_memory: FractalMemory
    ):
        """Two stores with different user intensities should differ when user > gate."""
        await fractal_memory.session_start("intensity-test")
        mem_low = await fractal_memory.store(
            "Low memory A", domain="intensity-test", intensity=0.0
        )
        mem_high = await fractal_memory.store(
            "High memory B", domain="intensity-test", intensity=1.0
        )
        assert mem_low is not None
        assert mem_high is not None
        assert mem_high.intensity >= mem_low.intensity
        assert mem_high.intensity == 1.0


# ---------------------------------------------------------------------------
# BUG 3: confirm() must promote PROBATION → CONFIRMED
# ---------------------------------------------------------------------------


class TestConfirmPromotesLifecycle:
    """BUG 3: A single confirm() must promote PROBATION → CONFIRMED."""

    @pytest.mark.asyncio
    async def test_confirm_promotes_to_confirmed(self, fractal_memory: FractalMemory):
        """After confirm(), a memory in PROBATION must be CONFIRMED."""
        await fractal_memory.session_start("confirm-test")
        mem = await fractal_memory.store("Confirm this memory", domain="confirm-test")
        assert mem is not None
        assert mem.lifecycle == LifecycleStatus.PROBATION

        await fractal_memory.confirm(mem.id)
        updated = await fractal_memory.get(mem.id)
        assert updated is not None
        assert updated.lifecycle == LifecycleStatus.CONFIRMED

    @pytest.mark.asyncio
    async def test_confirm_idempotent_on_confirmed(self, fractal_memory: FractalMemory):
        """Confirming an already CONFIRMED memory should not demote it."""
        await fractal_memory.session_start("confirm-test")
        mem = await fractal_memory.store("Idempotent confirm", domain="confirm-test")
        assert mem is not None

        await fractal_memory.confirm(mem.id)
        await fractal_memory.confirm(mem.id)
        updated = await fractal_memory.get(mem.id)
        assert updated is not None
        assert updated.lifecycle == LifecycleStatus.CONFIRMED

    @pytest.mark.asyncio
    async def test_confirm_does_not_affect_permanent(self, fractal_memory: FractalMemory):
        """Confirming a PERMANENT memory should leave lifecycle unchanged."""
        await fractal_memory.session_start("confirm-test")
        mem = await fractal_memory.store("Permanent memory", domain="confirm-test")
        assert mem is not None

        await fractal_memory.pin(mem.id)
        pinned = await fractal_memory.get(mem.id)
        assert pinned is not None
        assert pinned.lifecycle == LifecycleStatus.PERMANENT

        await fractal_memory.confirm(mem.id)
        after_confirm = await fractal_memory.get(mem.id)
        assert after_confirm is not None
        assert after_confirm.lifecycle == LifecycleStatus.PERMANENT

    @pytest.mark.asyncio
    async def test_confirm_increments_retrieval_count(self, fractal_memory: FractalMemory):
        """confirm() must also increment retrieval_count as a side effect."""
        await fractal_memory.session_start("confirm-test")
        mem = await fractal_memory.store("Count check", domain="confirm-test")
        assert mem is not None
        initial_count = mem.retrieval_count

        await fractal_memory.confirm(mem.id)
        updated = await fractal_memory.get(mem.id)
        assert updated is not None
        assert updated.retrieval_count > initial_count


# ---------------------------------------------------------------------------
# BUG 4: BatchedLLMJudge must handle non-string model_name
# ---------------------------------------------------------------------------


class TestJudgeModelNameTypeGuard:
    """BUG 4: evaluate() must not crash on non-string model_name."""

    @pytest.mark.asyncio
    async def test_non_string_model_name_does_not_crash(self, tmp_config: FractalConfig):
        """When model_name is a non-string truthy value, evaluate() must not raise."""
        llm = AsyncMock()
        # Simulate dynamic proxy returning a coroutine object for model_name
        llm.model_name = AsyncMock()  # truthy non-string
        llm.complete = AsyncMock(return_value="1")
        judge = BatchedLLMJudge(llm, tmp_config)

        # Record a triple so evaluate has work to do
        judge.record_triple(
            memory_id=uuid4(),
            memory_l2="test summary",
            query="test query",
            response_summary=None,
            has_clear_signal=False,
        )

        # Must not raise TypeError
        ratings = await judge.evaluate()
        assert isinstance(ratings, list)

    @pytest.mark.asyncio
    async def test_string_model_name_works_normally(self, tmp_config: FractalConfig):
        """Normal string model_name should still work."""
        llm = AsyncMock()
        llm.model_name = "claude-sonnet"
        llm.complete = AsyncMock(return_value="1")
        judge = BatchedLLMJudge(llm, tmp_config)

        judge.record_triple(
            memory_id=uuid4(),
            memory_l2="test",
            query="test",
            response_summary=None,
            has_clear_signal=False,
        )

        ratings = await judge.evaluate()
        assert isinstance(ratings, list)


# ---------------------------------------------------------------------------
# BUG 5: signals=[] must be treated same as signals=None
# ---------------------------------------------------------------------------


class TestEmptySignalsList:
    """BUG 5: store(signals=[]) must use default [EXPLICIT_STORE], not reject."""

    @pytest.mark.asyncio
    async def test_empty_signals_list_stores_memory(self, fractal_memory: FractalMemory):
        """signals=[] must be treated as default, storing the memory."""
        await fractal_memory.session_start("signals-test")
        mem = await fractal_memory.store(
            "Empty signals memory", domain="signals-test", signals=[]
        )
        assert mem is not None, "store(signals=[]) should not return None"
        assert mem.l4_raw == "Empty signals memory"

    @pytest.mark.asyncio
    async def test_empty_signals_matches_none_behavior(self, fractal_memory: FractalMemory):
        """signals=[] and signals=None should produce equivalent results."""
        await fractal_memory.session_start("signals-test")
        mem_none = await fractal_memory.store(
            "Signals None", domain="signals-test", signals=None
        )
        mem_empty = await fractal_memory.store(
            "Signals Empty", domain="signals-test", signals=[]
        )
        assert mem_none is not None
        assert mem_empty is not None


# ---------------------------------------------------------------------------
# BUG 6: delete() must clean up chain references
# ---------------------------------------------------------------------------


class TestDeleteCleansChainRefs:
    """BUG 6: Deleting a memory must NULL chain_next/chain_prev on linked memories."""

    @pytest.mark.asyncio
    async def test_delete_clears_chain_next_on_predecessor(
        self, fractal_memory: FractalMemory
    ):
        """After deleting B in chain A→B, A.chain_next must be None."""
        await fractal_memory.session_start("chain-test")
        mem_a = await fractal_memory.store("Original fact", domain="chain-test")
        assert mem_a is not None

        # Create correction chain: A → B
        mem_b = await fractal_memory.correct(mem_a.id, "Completely different fact")
        assert mem_b is not None

        # Verify chain is established
        a_before = await fractal_memory.get(mem_a.id)
        assert a_before is not None
        assert a_before.chain_next == mem_b.id

        # Delete B
        deleted = await fractal_memory.delete(mem_b.id)
        assert deleted is True

        # A.chain_next must be cleared
        a_after = await fractal_memory.get(mem_a.id)
        assert a_after is not None
        assert a_after.chain_next is None, (
            "chain_next on predecessor must be NULL after deleting successor"
        )

    @pytest.mark.asyncio
    async def test_delete_clears_chain_prev_on_successor(
        self, fractal_memory: FractalMemory
    ):
        """After deleting A in chain A→B, B.chain_prev must be None."""
        await fractal_memory.session_start("chain-test")
        mem_a = await fractal_memory.store("Original fact 2", domain="chain-test")
        assert mem_a is not None

        mem_b = await fractal_memory.correct(mem_a.id, "Completely different fact 2")
        assert mem_b is not None
        assert mem_b.chain_prev == mem_a.id

        # Delete A (the original)
        deleted = await fractal_memory.delete(mem_a.id)
        assert deleted is True

        # B.chain_prev must be cleared
        b_after = await fractal_memory.get(mem_b.id)
        assert b_after is not None
        assert b_after.chain_prev is None, (
            "chain_prev on successor must be NULL after deleting predecessor"
        )


# ---------------------------------------------------------------------------
# BUG 7: update_association_weight must be bidirectional
# ---------------------------------------------------------------------------


class TestAssociationWeightBidirectional:
    """BUG 7: update_association_weight must update both A→B and B→A."""

    @pytest.mark.asyncio
    async def test_weight_update_applies_both_directions(
        self, storage: Storage
    ):
        """Updating weight for (A,B) must also update (B,A) if it exists."""
        a_id = uuid4()
        b_id = uuid4()

        # Create edges in both directions
        await storage.store_association(source_id=a_id, target_id=b_id, weight=0.5)
        await storage.store_association(source_id=b_id, target_id=a_id, weight=0.5)

        # Update weight via A→B — should update both directions
        await storage.update_association_weight(a_id, b_id, 0.9)

        # get_all_associations returns (source_id, target_id, weight) tuples
        all_edges = await storage.get_all_associations()
        edge_map = {(src, tgt): w for src, tgt, w in all_edges}

        assert edge_map[(a_id, b_id)] == pytest.approx(0.9), "A→B weight not updated"
        assert edge_map[(b_id, a_id)] == pytest.approx(0.9), (
            "B→A weight not updated — update_association_weight must be bidirectional"
        )


# ---------------------------------------------------------------------------
# BUG 9: DimensionalFolder must track unknown subsystem stats
# ---------------------------------------------------------------------------


class TestFoldingUnknownSubsystems:
    """BUG 9: update_folded_stats must create anomaly history for unknown subsystems."""

    def test_unknown_subsystem_added_to_anomaly_history(self):
        """Custom subsystem names must be added to _anomaly_history."""
        config = FractalConfig()
        folder = DimensionalFolder(config)

        folder.update_folded_stats({"custom_plugin": 0.8})

        assert "custom_plugin" in folder._anomaly_history
        assert len(folder._anomaly_history["custom_plugin"]) == 1
        assert folder._anomaly_history["custom_plugin"][0] == 0.8

    def test_unknown_subsystem_builds_history_over_time(self):
        """After 3+ updates, forced unfold check should be able to detect anomalies."""
        config = FractalConfig()
        folder = DimensionalFolder(config)

        # Build up a normal baseline
        for _ in range(5):
            folder.update_folded_stats({"custom_plugin": 0.5})

        assert len(folder._anomaly_history["custom_plugin"]) == 5

        # Verify forced unfold can now operate on this subsystem
        # (extreme value should trigger z-score > 2σ)
        result = folder.check_forced_unfold("custom_plugin", 10.0)
        # Result depends on regime, but the key point is no KeyError is raised
        # and the method can process the custom subsystem
        assert isinstance(result, bool)

    def test_known_subsystem_still_works(self):
        """Known subsystems must continue to work correctly."""
        config = FractalConfig()
        folder = DimensionalFolder(config)

        folder.update_folded_stats({"morphogens": 0.7})

        assert "morphogens" in folder._anomaly_history
        assert folder._anomaly_history["morphogens"][-1] == 0.7


# ---------------------------------------------------------------------------
# BUG 10: Empty string domain must raise ValueError
# ---------------------------------------------------------------------------


class TestEmptyDomainRejected:
    """BUG 10: domain='' must raise ValueError, not silently become 'default'."""

    @pytest.mark.asyncio
    async def test_store_empty_domain_raises(self, fractal_memory: FractalMemory):
        """store(domain='') must raise ValueError."""
        await fractal_memory.session_start("domain-test")
        with pytest.raises(ValueError, match="empty string"):
            await fractal_memory.store("test", domain="")

    @pytest.mark.asyncio
    async def test_retrieve_empty_domain_raises(self, fractal_memory: FractalMemory):
        """retrieve(domain='') must raise ValueError."""
        await fractal_memory.session_start("domain-test")
        with pytest.raises(ValueError, match="empty string"):
            await fractal_memory.retrieve("test query", domain="")

    @pytest.mark.asyncio
    async def test_none_domain_still_defaults(self, fractal_memory: FractalMemory):
        """domain=None must still default to config.default_domain (not break)."""
        default_domain = fractal_memory._config.default_domain
        await fractal_memory.session_start(default_domain)
        mem = await fractal_memory.store("test", domain=None)
        assert mem is not None
        assert mem.domain == default_domain


# ---------------------------------------------------------------------------
# BUG 11: WaitingRoomEntry must be importable from package
# ---------------------------------------------------------------------------


class TestWaitingRoomEntryExported:
    """BUG 11: WaitingRoomEntry must be importable from fractal_memory."""

    def test_import_from_package(self):
        """from fractal_memory import WaitingRoomEntry must work."""
        from fractal_memory import WaitingRoomEntry as WRE
        assert WRE is not None

    def test_in_all(self):
        """WaitingRoomEntry must be listed in __all__."""
        import fractal_memory
        assert "WaitingRoomEntry" in fractal_memory.__all__

    def test_can_construct(self):
        """WaitingRoomEntry must be constructable with expected fields."""
        entry = WaitingRoomEntry(
            id=uuid4(),
            content="test",
            first_signal={},
            domain="test",
            created_at=utcnow(),
        )
        assert entry.content == "test"
        assert entry.sessions_elapsed == 0
