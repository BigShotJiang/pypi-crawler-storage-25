"""Tests for embedding provider abstraction."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from fractal_memory.embeddings import EmbeddingProvider, LocalEmbeddingProvider


async def test_embedding_provider_protocol(mock_embeddings):
    """Mock embeddings satisfy the EmbeddingProvider protocol."""
    assert isinstance(mock_embeddings, EmbeddingProvider)


async def test_mock_embed_returns_correct_dimension(mock_embeddings):
    """Embedding vector has the expected dimensionality."""
    vec = await mock_embeddings.embed("hello world")
    assert len(vec) == 384
    assert all(isinstance(v, float) for v in vec)


async def test_mock_embed_deterministic(mock_embeddings):
    """Same input produces the same embedding."""
    vec1 = await mock_embeddings.embed("test text")
    vec2 = await mock_embeddings.embed("test text")
    assert vec1 == vec2


async def test_mock_embed_different_for_different_inputs(mock_embeddings):
    """Different inputs produce different embeddings."""
    vec1 = await mock_embeddings.embed("hello")
    vec2 = await mock_embeddings.embed("goodbye")
    assert vec1 != vec2


async def test_mock_embed_batch(mock_embeddings):
    """Batch embedding produces correct number of vectors."""
    texts = ["alpha", "beta", "gamma"]
    vecs = await mock_embeddings.embed_batch(texts)
    assert len(vecs) == 3
    for v in vecs:
        assert len(v) == 384


async def test_mock_embed_batch_matches_single(mock_embeddings):
    """Batch embedding matches individual embed calls."""
    texts = ["hello", "world"]
    batch = await mock_embeddings.embed_batch(texts)
    single_0 = await mock_embeddings.embed(texts[0])
    single_1 = await mock_embeddings.embed(texts[1])
    assert batch[0] == single_0
    assert batch[1] == single_1


async def test_embedding_provider_has_model_name(mock_embeddings):
    """Provider exposes model name."""
    assert mock_embeddings.model_name == "mock-model"


async def test_embedding_provider_has_dimension(mock_embeddings):
    """Provider exposes embedding dimension."""
    assert mock_embeddings.dimension == 384


async def test_embedding_vector_is_normalized(mock_embeddings):
    """Embedding vectors should be approximately unit-normalized."""
    import numpy as np

    vec = await mock_embeddings.embed("test normalization")
    norm = np.linalg.norm(vec)
    assert abs(norm - 1.0) < 0.01


async def test_local_embedding_provider_instantiation():
    """LocalEmbeddingProvider can be instantiated without loading model."""
    provider = LocalEmbeddingProvider("all-MiniLM-L6-v2")
    assert provider.model_name == "all-MiniLM-L6-v2"
    # Model should NOT be loaded yet (lazy loading)
    assert provider._model is None


# ---------------------------------------------------------------------------
# Issue #32: Embedding dimension API fallback
# ---------------------------------------------------------------------------


def test_embedding_dimension_uses_new_api():
    """Issue #32: Uses get_embedding_dimension() when available."""
    from unittest.mock import MagicMock

    provider = LocalEmbeddingProvider("test-model")
    mock_model = MagicMock()
    mock_model.get_embedding_dimension = MagicMock(return_value=384)
    # Inject mock model directly and call _load_model logic
    provider._model = mock_model
    provider._dimension = getattr(
        mock_model, "get_embedding_dimension", mock_model.get_sentence_embedding_dimension
    )()
    assert provider._dimension == 384
    mock_model.get_embedding_dimension.assert_called_once()
    mock_model.get_sentence_embedding_dimension.assert_not_called()


def test_embedding_dimension_falls_back_to_old_api():
    """Issue #32: Falls back to get_sentence_embedding_dimension() when new API missing."""
    from unittest.mock import MagicMock

    provider = LocalEmbeddingProvider("test-model")
    mock_model = MagicMock()
    # Remove new API so getattr falls back
    del mock_model.get_embedding_dimension
    mock_model.get_sentence_embedding_dimension = MagicMock(return_value=384)
    provider._model = mock_model
    provider._dimension = getattr(
        mock_model, "get_embedding_dimension", mock_model.get_sentence_embedding_dimension
    )()
    assert provider._dimension == 384
    mock_model.get_sentence_embedding_dimension.assert_called_once()
