"""Session state machine tests — wrong-order calls, double-start, store without session.

Validates that the session lifecycle handles degenerate call sequences gracefully:
end before start, double-start, store/retrieve without an active session, etc.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.session import SessionManager
from fractal_memory.storage import Storage


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Session state machine test summary."
        return json.dumps({
            "l0_tag": "session:test",
            "l1_label": "session-test",
            "l2_summary": "Session test memory.",
            "l3_full": "Session test memory full context.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def ssm_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "ssm_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def ssm_fm(ssm_config: FractalConfig):
    fm = FractalMemory(ssm_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ── Wrong-order calls ────────────────────────────────────────────────


class TestWrongOrderCalls:
    @pytest.mark.asyncio
    async def test_end_before_start(self, ssm_fm: FractalMemory):
        """session_end without session_start should raise RuntimeError."""
        with pytest.raises(RuntimeError, match="No active session"):
            await ssm_fm.session_end()

    @pytest.mark.asyncio
    async def test_double_end(self, ssm_fm: FractalMemory):
        """Two session_end calls should raise on the second."""
        await ssm_fm.session_start("test")
        await ssm_fm.session_end()
        with pytest.raises(RuntimeError, match="No active session"):
            await ssm_fm.session_end()

    @pytest.mark.asyncio
    async def test_double_start_overwrites(self, ssm_fm: FractalMemory):
        """A second session_start should overwrite the previous session cleanly."""
        ctx1 = await ssm_fm.session_start("domain-a")
        session1_id = ctx1.session.id
        ctx2 = await ssm_fm.session_start("domain-b")
        session2_id = ctx2.session.id
        assert session1_id != session2_id
        # The current session should be domain-b
        assert ssm_fm._session.current_session is not None
        assert ssm_fm._session.current_session.domain == "domain-b"

    @pytest.mark.asyncio
    async def test_store_without_session_raises(self, ssm_fm: FractalMemory):
        """store() without session_start should raise RuntimeError (Issue #2)."""
        with pytest.raises(RuntimeError, match="No active session"):
            await ssm_fm.store("Memory without active session")

    @pytest.mark.asyncio
    async def test_retrieve_without_session_raises(self, ssm_fm: FractalMemory):
        """retrieve() without session_start should raise RuntimeError (Issue #2)."""
        # Store a memory first
        await ssm_fm.session_start("test")
        await ssm_fm.store("Background memory for retrieve test")
        await ssm_fm.session_end()

        # Retrieve without a session should raise
        with pytest.raises(RuntimeError, match="No active session"):
            await ssm_fm.retrieve("retrieve test", domain="test")


# ── Session boundary interactions ────────────────────────────────────


class TestSessionBoundaries:
    @pytest.mark.asyncio
    async def test_store_after_end_raises(self, ssm_fm: FractalMemory):
        """store() after session_end should raise RuntimeError (Issue #2)."""
        await ssm_fm.session_start("test")
        await ssm_fm.session_end()
        with pytest.raises(RuntimeError, match="No active session"):
            await ssm_fm.store("Post-session memory")

    @pytest.mark.asyncio
    async def test_rapid_start_end_cycles(self, ssm_fm: FractalMemory):
        """5 rapid start→end cycles should not leak state."""
        for i in range(5):
            await ssm_fm.session_start("rapid")
            await ssm_fm.store(f"Rapid cycle {i} memory")
            summary = await ssm_fm.session_end()
            assert summary is not None
            assert summary.memories_stored >= 1

    @pytest.mark.asyncio
    async def test_start_store_start_end(self, ssm_fm: FractalMemory):
        """start → store → start (overwrite) → end should not lose the store."""
        await ssm_fm.session_start("first")
        await ssm_fm.store("Memory from first session")
        # Overwrite session
        await ssm_fm.session_start("second")
        summary = await ssm_fm.session_end()
        # The second session should have 0 stores (the store was in the first session)
        assert summary.memories_stored == 0

    @pytest.mark.asyncio
    async def test_session_summary_content(self, ssm_fm: FractalMemory):
        """Session summary should reflect actual stores and retrievals."""
        await ssm_fm.session_start("summary-test")
        await ssm_fm.store("Memory one for summary test")
        await ssm_fm.store("Memory two for summary test")
        await ssm_fm.retrieve("query about summary", domain="summary-test")
        summary = await ssm_fm.session_end()
        assert summary.memories_stored == 2
        assert summary.memories_retrieved == 1


# ── Edge case domains ────────────────────────────────────────────────


class TestEdgeCaseDomains:
    @pytest.mark.asyncio
    async def test_none_domain_defaults(self, ssm_fm: FractalMemory):
        """session_start(None) should use the default domain."""
        ctx = await ssm_fm.session_start(None)
        assert ctx.session.domain in ("default", "general")

    @pytest.mark.asyncio
    async def test_invalid_domain_rejected(self, ssm_fm: FractalMemory):
        """session_start with invalid domain chars should raise ValueError."""
        with pytest.raises(ValueError, match="Invalid domain"):
            await ssm_fm.session_start("has spaces and!special")

    @pytest.mark.asyncio
    async def test_very_long_domain_rejected(self, ssm_fm: FractalMemory):
        """A domain name exceeding max_domain_length should be rejected."""
        long_domain = "a" * 200
        with pytest.raises(ValueError, match="exceeds max length"):
            await ssm_fm.session_start(long_domain)

    @pytest.mark.asyncio
    async def test_empty_text_store_rejected(self, ssm_fm: FractalMemory):
        """Storing empty text should be rejected."""
        await ssm_fm.session_start("test")
        with pytest.raises(ValueError, match="must not be empty"):
            await ssm_fm.store("")

    @pytest.mark.asyncio
    async def test_whitespace_only_store_rejected(self, ssm_fm: FractalMemory):
        """Storing whitespace-only text should be rejected."""
        await ssm_fm.session_start("test")
        with pytest.raises(ValueError, match="must not be empty"):
            await ssm_fm.store("   \n\t  ")
