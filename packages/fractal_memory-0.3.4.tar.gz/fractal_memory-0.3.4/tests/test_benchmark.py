"""Kill gate benchmark: multi-resolution vs top-5 cosine baseline."""

from datetime import datetime
from uuid import UUID, uuid4

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.models import Memory
from fractal_memory.retrieval import RetrievalEngine
from fractal_memory.storage import Storage


def _generate_memories(
    count: int,
    domain: str,
    seed: int = 42,
) -> list[Memory]:
    """Generate synthetic memories with varied embeddings."""
    rng = np.random.RandomState(seed)
    memories = []
    for i in range(count):
        vec = rng.randn(384).astype(np.float32)
        vec = vec / np.linalg.norm(vec)
        intensity = float(rng.uniform(0.2, 0.9))
        memories.append(Memory(
            id=uuid4(),
            domain=domain,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            context={},
            l0_tag=f"syn:m{i}",
            l1_label=f"synthetic-memory-{i}",
            l2_summary=f"Synthetic memory number {i} in {domain} about topic {i % 10}.",
            l3_full=f"Detailed synthetic memory number {i} in domain {domain}. Topic: {i % 10}. "
                     f"This memory contains information about test subject {i}.",
            l4_raw=f"Raw text for memory {i}",
            embedding=vec.tolist(),
            embedding_model="synthetic",
            intensity=intensity,
        ))
    return memories


def _generate_query(
    memories: list[Memory],
    relevant_indices: list[int],
    noise_scale: float = 0.3,
    seed: int = 0,
) -> list[float]:
    """Generate a query embedding near the centroid of relevant memories."""
    rng = np.random.RandomState(seed)
    relevant_vecs = np.array([memories[i].embedding for i in relevant_indices], dtype=np.float32)
    centroid = relevant_vecs.mean(axis=0)
    noise = rng.randn(384).astype(np.float32) * noise_scale
    query = centroid + noise
    query = query / np.linalg.norm(query)
    return query.tolist()


async def test_multiresolution_beats_top5(tmp_path):
    """Kill gate: multi-resolution retrieval must match or beat top-5 cosine baseline."""

    config = FractalConfig(
        db_path=tmp_path / "bench.db",
        gate_signal_count=1,
        top_l1=200,
        top_l2=50,
        top_l3=10,
    )
    storage = Storage(config)
    await storage.initialize()

    try:
        # Generate 200 memories across 3 domains
        domains = ["coding", "deployment", "design"]
        all_memories: list[Memory] = []
        for di, domain in enumerate(domains):
            mems = _generate_memories(67 if di < 2 else 66, domain, seed=42 + di * 100)
            for m in mems:
                await storage.store_memory(m)
            all_memories.extend(mems)

        # For benchmark, we only test within "coding" domain
        coding_memories = [m for m in all_memories if m.domain == "coding"]

        # Create mock embeddings that return pre-computed vectors
        from unittest.mock import AsyncMock
        from fractal_memory.embeddings import EmbeddingProvider

        mock_emb = AsyncMock(spec=EmbeddingProvider)
        mock_emb.model_name = "synthetic"
        mock_emb.dimension = 384

        # Generate 100 test queries with known relevant memories
        rng = np.random.RandomState(999)
        n_queries = 100
        multiresolution_hits = 0
        top5_hits = 0

        for qi in range(n_queries):
            # Pick 3-5 relevant memories
            n_relevant = rng.randint(3, 6)
            relevant_indices = rng.choice(len(coding_memories), size=n_relevant, replace=False).tolist()
            relevant_ids = {coding_memories[i].id for i in relevant_indices}

            query_vec = _generate_query(coding_memories, relevant_indices, noise_scale=0.3, seed=qi)

            # Configure mock to return this query vector
            mock_emb.embed = AsyncMock(return_value=query_vec)

            engine = RetrievalEngine(storage, mock_emb, config)

            # Multi-resolution retrieval
            result = await engine.retrieve("test query", "coding")
            mr_retrieved_ids = {m.id for m in result.l2_memories}  # L2 includes L3
            if mr_retrieved_ids & relevant_ids:
                multiresolution_hits += 1

            # Top-5 baseline: pure cosine, no intensity weighting
            all_embs = await storage.get_all_embeddings("coding")
            q = np.array(query_vec, dtype=np.float32)
            q = q / np.linalg.norm(q)
            sims = []
            for uid, vec in all_embs:
                v = np.array(vec, dtype=np.float32)
                v_norm = np.linalg.norm(v)
                if v_norm > 0:
                    v = v / v_norm
                sim = float(np.dot(q, v))
                sims.append((uid, sim))
            sims.sort(key=lambda x: x[1], reverse=True)
            top5_ids = {uid for uid, _ in sims[:5]}
            if top5_ids & relevant_ids:
                top5_hits += 1

        multiresolution_hit_rate = multiresolution_hits / n_queries
        top5_hit_rate = top5_hits / n_queries

        print(f"\nMulti-resolution hit rate: {multiresolution_hit_rate:.1%}")
        print(f"Top-5 baseline hit rate: {top5_hit_rate:.1%}")

        assert multiresolution_hit_rate >= top5_hit_rate, (
            f"Multi-resolution ({multiresolution_hit_rate:.1%}) must outperform "
            f"top-5 baseline ({top5_hit_rate:.1%})"
        )

    finally:
        await storage.close()
