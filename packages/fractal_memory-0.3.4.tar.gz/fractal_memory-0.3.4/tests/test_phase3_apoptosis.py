"""Tests for fractal_memory.apoptosis — ApoptosisManager (Phase 3)."""

from __future__ import annotations

import uuid
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

import numpy as np
import pytest

from fractal_memory.apoptosis import ApoptosisDecision, ApoptosisManager, ApoptosisReport
from fractal_memory.config import FractalConfig
from fractal_memory.models import ContextTags, LifecycleStatus, Memory


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(
        apoptosis_context_drift_threshold=0.2,
        apoptosis_contradiction_limit=3,
        apoptosis_min_vitality=0.05,
        apoptosis_scar_duration=10,
        apoptosis_fragment_strength=0.3,
    )


def _make_memory(
    retrieval_count: int = 5,
    miss_count: int = 0,
    reconsolidation_count: int = 0,
    embedding: list[float] | None = None,
    last_accessed: datetime | None = None,
) -> Memory:
    emb = embedding if embedding is not None else np.random.default_rng(42).standard_normal(16).tolist()
    return Memory(
        id=uuid.uuid4(),
        domain="test",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context=ContextTags(),
        l0_tag="test",
        l1_label="test label",
        l2_summary="test summary",
        l3_full="test full content",
        l4_raw="test raw content",
        embedding=emb,
        embedding_model="test-model",
        intensity=0.5,
        lifecycle=LifecycleStatus.CONFIRMED,
        retrieval_count=retrieval_count,
        miss_count=miss_count,
        reconsolidation_count=reconsolidation_count,
        last_accessed=last_accessed,
    )


@pytest.fixture
def manager(cfg: FractalConfig) -> ApoptosisManager:
    storage = AsyncMock()
    associations = AsyncMock()
    scars = AsyncMock()
    embeddings = AsyncMock()
    llm = AsyncMock()
    llm.complete.return_value = "NONE"
    return ApoptosisManager(
        storage=storage,
        associations=associations,
        scars=scars,
        embeddings=embeddings,
        llm=llm,
        config=cfg,
    )


def _ctx_emb(seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    v = rng.standard_normal(16).astype(np.float32)
    return v / np.linalg.norm(v)


# ---------------------------------------------------------------------------
# compute_vitality
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_vitality_high_for_frequently_retrieved(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=10, miss_count=0)
    v = manager.compute_vitality(mem)
    assert v > 0.8


@pytest.mark.asyncio
async def test_vitality_low_for_many_misses(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=1, miss_count=9)
    v = manager.compute_vitality(mem)
    assert v < 0.5


@pytest.mark.asyncio
async def test_vitality_clamped_to_01(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=100, miss_count=0)
    v = manager.compute_vitality(mem)
    assert 0.0 <= v <= 1.0


@pytest.mark.asyncio
async def test_vitality_zero_retrieval_is_low(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=0, miss_count=5)
    v = manager.compute_vitality(mem)
    assert v == 0.0


# ---------------------------------------------------------------------------
# check_apoptosis — context drift trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_context_drift_trigger(manager: ApoptosisManager, cfg: FractalConfig) -> None:
    rng = np.random.default_rng(0)
    mem_emb = rng.standard_normal(16).astype(np.float32)
    mem_emb /= np.linalg.norm(mem_emb)

    # Context pointing in opposite direction → low cosine similarity
    ctx_emb = -mem_emb
    mem = _make_memory(embedding=mem_emb.tolist(), retrieval_count=0, miss_count=5)
    decision = await manager.check_apoptosis(mem, ctx_emb)
    assert decision.should_apoptose
    assert decision.reason == "context_drift"


@pytest.mark.asyncio
async def test_no_drift_when_recently_retrieved(manager: ApoptosisManager) -> None:
    rng = np.random.default_rng(0)
    mem_emb = rng.standard_normal(16).astype(np.float32)
    mem_emb /= np.linalg.norm(mem_emb)
    ctx_emb = -mem_emb  # far from memory

    # Recently accessed — should NOT trigger context drift
    mem = _make_memory(
        embedding=mem_emb.tolist(),
        retrieval_count=5,
        miss_count=0,
        last_accessed=datetime.utcnow(),
    )
    decision = await manager.check_apoptosis(mem, ctx_emb)
    # May trigger vitality floor or no trigger, but NOT context_drift
    assert decision.reason != "context_drift"


# ---------------------------------------------------------------------------
# check_apoptosis — contradiction ceiling trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_contradiction_trigger(manager: ApoptosisManager, cfg: FractalConfig) -> None:
    mem = _make_memory(reconsolidation_count=cfg.apoptosis_contradiction_limit)
    ctx = _ctx_emb()
    # Make embedding match context so drift doesn't trigger
    mem.embedding = ctx.tolist()
    decision = await manager.check_apoptosis(mem, ctx)
    assert decision.should_apoptose
    assert decision.reason == "contradicted"


@pytest.mark.asyncio
async def test_no_contradiction_below_limit(manager: ApoptosisManager, cfg: FractalConfig) -> None:
    mem = _make_memory(
        reconsolidation_count=cfg.apoptosis_contradiction_limit - 1,
        retrieval_count=10,
        miss_count=0,
    )
    ctx = _ctx_emb()
    mem.embedding = ctx.tolist()
    decision = await manager.check_apoptosis(mem, ctx)
    assert decision.reason != "contradicted"


# ---------------------------------------------------------------------------
# check_apoptosis — vitality floor trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_vitality_floor_trigger(manager: ApoptosisManager, cfg: FractalConfig) -> None:
    # Zero retrieval, many misses → vitality = 0 < floor
    mem = _make_memory(retrieval_count=0, miss_count=10)
    ctx = _ctx_emb()
    # Give it a matching embedding to avoid drift trigger
    mem.embedding = ctx.tolist()
    decision = await manager.check_apoptosis(mem, ctx)
    assert decision.should_apoptose
    assert decision.reason == "obsolescence"


@pytest.mark.asyncio
async def test_no_apoptosis_for_healthy_memory(manager: ApoptosisManager) -> None:
    ctx = _ctx_emb()
    # High retrieval, no misses, no contradictions, matching embedding
    mem = _make_memory(
        retrieval_count=10,
        miss_count=0,
        reconsolidation_count=0,
        embedding=ctx.tolist(),
        last_accessed=datetime.utcnow(),
    )
    decision = await manager.check_apoptosis(mem, ctx)
    assert not decision.should_apoptose
    assert decision.reason == ""


# ---------------------------------------------------------------------------
# check_apoptosis — decision fields
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_decision_has_memory_id(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=10, miss_count=0)
    ctx = _ctx_emb()
    mem.embedding = ctx.tolist()
    decision = await manager.check_apoptosis(mem, ctx)
    assert decision.memory_id == mem.id


@pytest.mark.asyncio
async def test_decision_vitality_in_range(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=5, miss_count=5)
    ctx = _ctx_emb()
    mem.embedding = ctx.tolist()
    decision = await manager.check_apoptosis(mem, ctx)
    assert 0.0 <= decision.vitality <= 1.0


# ---------------------------------------------------------------------------
# execute_apoptosis
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execute_returns_report(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=0, miss_count=5)
    report = await manager.execute_apoptosis(mem, reason="context_drift")
    assert isinstance(report, ApoptosisReport)
    assert report.memory_id == mem.id
    assert report.reason == "context_drift"


@pytest.mark.asyncio
async def test_execute_calls_delete(manager: ApoptosisManager) -> None:
    mem = _make_memory(retrieval_count=0, miss_count=5)
    manager._storage.delete_memory = AsyncMock()
    await manager.execute_apoptosis(mem, reason="obsolescence")
    manager._storage.delete_memory.assert_called_once_with(mem.id)


@pytest.mark.asyncio
async def test_execute_creates_fragments_from_llm(manager: ApoptosisManager) -> None:
    # Fragments must be > 10 chars to be stored
    manager._llm.complete.return_value = "This is fact number one\nThis is fact number two\nThis is fact three"
    manager._embeddings.embed = AsyncMock(return_value=[1.0] * 16)
    manager._storage.store_memory = AsyncMock()
    mem = _make_memory(retrieval_count=5, miss_count=0)
    report = await manager.execute_apoptosis(mem, reason="obsolescence")
    assert report.fragments_created == 3


@pytest.mark.asyncio
async def test_execute_handles_llm_failure_gracefully(manager: ApoptosisManager) -> None:
    manager._llm.complete.side_effect = Exception("LLM unavailable")
    manager._storage.delete_memory = AsyncMock()
    mem = _make_memory(retrieval_count=0, miss_count=5)
    # Should not raise
    report = await manager.execute_apoptosis(mem, reason="context_drift")
    assert report.fragments_created == 0
    assert report.memory_id == mem.id


# ---------------------------------------------------------------------------
# execute_apoptosis — scar creation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execute_creates_scar(manager: ApoptosisManager) -> None:
    """Apoptosis should create a scar from the deleted memory's embedding."""
    manager._storage.delete_memory = AsyncMock()
    manager._storage.store_memory = AsyncMock()
    manager._scars.create_scar = AsyncMock()
    mem = _make_memory(retrieval_count=2, miss_count=5)
    report = await manager.execute_apoptosis(mem, reason="context_drift")
    assert report.memory_id == mem.id
    # Scar should have been created (if embedding exists)
    if mem.embedding:
        manager._scars.create_scar.assert_called_once()


# ---------------------------------------------------------------------------
# Issue #4 — 4 apoptosis fixes (complete/generate, tolist, edge weaken, scar)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apoptosis_calls_llm_complete_not_generate(manager: ApoptosisManager) -> None:
    """execute_apoptosis must call LLM complete() with <memory> delimiters, not generate()."""
    manager._llm.complete = AsyncMock(return_value="Fact one\nFact two")
    manager._embeddings.embed = AsyncMock(return_value=[0.1, 0.2, 0.3])
    manager._storage.store_memory = AsyncMock()
    manager._storage.delete_memory = AsyncMock()
    manager._scars.create_scar = AsyncMock()
    mem = _make_memory(retrieval_count=5, miss_count=0)

    await manager.execute_apoptosis(mem, reason="obsolescence")

    manager._llm.complete.assert_called_once()
    call_kwargs = manager._llm.complete.call_args
    prompt = call_kwargs.kwargs.get("prompt") or call_kwargs.args[0]
    assert "<memory>" in prompt
    assert "</memory>" in prompt
    assert "max_tokens" in str(call_kwargs)
    # generate should NOT have been called
    assert not hasattr(manager._llm, "generate") or not manager._llm.generate.called


@pytest.mark.asyncio
async def test_apoptosis_stores_fragments_without_tolist(manager: ApoptosisManager) -> None:
    """embed() returns list[float] — fragment embedding must be stored as list, not ndarray."""
    emb_list = [0.1, 0.2, 0.3]
    manager._llm.complete = AsyncMock(return_value="Fragment fact one\nFragment fact two")
    manager._embeddings.embed = AsyncMock(return_value=emb_list)
    manager._storage.store_memory = AsyncMock()
    manager._storage.delete_memory = AsyncMock()
    manager._scars.create_scar = AsyncMock()
    mem = _make_memory(retrieval_count=5, miss_count=0)

    await manager.execute_apoptosis(mem, reason="obsolescence")

    assert manager._storage.store_memory.call_count == 2
    for call in manager._storage.store_memory.call_args_list:
        stored_mem = call.args[0]
        assert isinstance(stored_mem.embedding, list)
        assert stored_mem.embedding == emb_list


@pytest.mark.asyncio
async def test_apoptosis_weakens_edges_via_adjust(manager: ApoptosisManager) -> None:
    """Apoptosis must weaken neighbor edges via adjust_edge_weight, not weaken_edge."""
    nid1, nid2 = uuid.uuid4(), uuid.uuid4()
    manager._associations.get_neighbors = AsyncMock(return_value=[nid1, nid2])
    manager._associations.adjust_edge_weight = AsyncMock()
    manager._storage.delete_memory = AsyncMock()
    manager._scars.create_scar = AsyncMock()
    mem = _make_memory(retrieval_count=2, miss_count=5)

    await manager.execute_apoptosis(mem, reason="context_drift")

    assert manager._associations.adjust_edge_weight.call_count == 2
    for call in manager._associations.adjust_edge_weight.call_args_list:
        source, target, delta_fn = call.args
        assert source == mem.id
        assert target in (nid1, nid2)
        # Verify the delta_fn reduces weight
        assert delta_fn(1.0) < 1.0


@pytest.mark.asyncio
async def test_apoptosis_creates_scar_with_correct_signature(manager: ApoptosisManager) -> None:
    """create_scar must use reason/subtype/query_embedding/memory_ids, not old API."""
    manager._storage.delete_memory = AsyncMock()
    manager._storage.store_memory = AsyncMock()
    manager._scars.create_scar = AsyncMock()
    emb = [0.5, 0.6]
    mem = _make_memory(retrieval_count=2, miss_count=5, embedding=emb)

    await manager.execute_apoptosis(mem, reason="context_drift")

    manager._scars.create_scar.assert_called_once()
    call_kwargs = manager._scars.create_scar.call_args.kwargs
    assert call_kwargs["reason"].startswith("apoptosis:")
    assert call_kwargs["subtype"] == "apoptosis"
    assert call_kwargs["query_embedding"] == emb
    assert call_kwargs["memory_ids"] == [mem.id]
    # ttl_sessions must NOT be passed
    assert "ttl_sessions" not in call_kwargs
