"""Tests for Phase 2 — DangerTheoryDetector and BatchedLLMJudge (B-2, B-5)."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.feedback import (
    BatchedLLMJudge,
    DangerTheoryDetector,
    FeedbackSignalType,
    FeedbackSubtype,
)
from fractal_memory.llm import LLMProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _unit_vec(seed: int = 0, dim: int = 384) -> list[float]:
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return (v / np.linalg.norm(v)).tolist()


@pytest.fixture
def config(tmp_config: FractalConfig):
    return tmp_config


@pytest.fixture
def detector(config: FractalConfig):
    return DangerTheoryDetector(config)


# ---------------------------------------------------------------------------
# DangerTheoryDetector — correction signals
# ---------------------------------------------------------------------------


def test_detects_correction_no():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals("No, that's wrong", _unit_vec(), [uuid4()])
    types = [(s.type, s.subtype) for s in signals]
    assert (FeedbackSignalType.DANGER, FeedbackSubtype.CORRECTION) in types


def test_detects_correction_that_is_not_right():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals("That's not right!", _unit_vec(), [uuid4()])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.CORRECTION in subtypes


def test_detects_rejection():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals(
        "That's irrelevant, disregard it please", _unit_vec(), [uuid4()]
    )
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.REJECTION in subtypes


def test_rejection_not_fired_when_correction_present():
    """If both correction and rejection match, only correction should fire."""
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals(
        "No, that's wrong — ignore it", _unit_vec(), []
    )
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.CORRECTION in subtypes
    # Rejection should NOT fire because the message also matches correction
    assert FeedbackSubtype.REJECTION not in subtypes


# ---------------------------------------------------------------------------
# DangerTheoryDetector — safety signals
# ---------------------------------------------------------------------------


def test_detects_confirmation_yes():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals("Yes, exactly!", _unit_vec(), [uuid4()])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.CONFIRMATION in subtypes


def test_detects_confirmation_correct():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals("That's correct, proceed.", _unit_vec(), [])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.CONFIRMATION in subtypes


# ---------------------------------------------------------------------------
# DangerTheoryDetector — re-ask detection
# ---------------------------------------------------------------------------


def test_detects_re_ask_with_same_embedding():
    detector = DangerTheoryDetector(FractalConfig())
    q_emb = _unit_vec(seed=42)
    mem_ids = [uuid4()]
    # First message sets history
    detector.detect_signals("What is the deployment process?", q_emb, mem_ids)
    # Second very similar message
    signals = detector.detect_signals("What is the deployment process?", q_emb, mem_ids)
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.RE_ASK in subtypes


def test_no_re_ask_on_different_embedding():
    detector = DangerTheoryDetector(FractalConfig())
    q1 = _unit_vec(seed=1)
    q2 = _unit_vec(seed=99)  # very different direction
    mem_ids = [uuid4()]
    detector.detect_signals("First question", q1, mem_ids)
    signals = detector.detect_signals("Completely different topic", q2, mem_ids)
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.RE_ASK not in subtypes


# ---------------------------------------------------------------------------
# DangerTheoryDetector — neutral message produces no signals
# ---------------------------------------------------------------------------


def test_neutral_message_no_signals():
    detector = DangerTheoryDetector(FractalConfig())
    signals = detector.detect_signals(
        "Please explain how the cache works.", _unit_vec(), []
    )
    assert signals == []


# ---------------------------------------------------------------------------
# DangerTheoryDetector — session state
# ---------------------------------------------------------------------------


def test_get_session_signals_accumulates():
    detector = DangerTheoryDetector(FractalConfig())
    q = _unit_vec()
    detector.detect_signals("No, that's wrong", q, [])
    detector.detect_signals("Yes, exactly", q, [])
    all_signals = detector.get_session_signals()
    assert len(all_signals) >= 2


def test_reset_session_clears_state():
    detector = DangerTheoryDetector(FractalConfig())
    q = _unit_vec()
    detector.detect_signals("No, wrong", q, [])
    assert len(detector.get_session_signals()) > 0
    detector.reset_session()
    assert detector.get_session_signals() == []
    assert detector._message_count == 0


# ---------------------------------------------------------------------------
# BatchedLLMJudge — basic evaluation
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_judge_llm():
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value="[2, 0, 1]")
    return llm


async def test_judge_evaluates_triples(mock_judge_llm, tmp_config: FractalConfig):
    judge = BatchedLLMJudge(mock_judge_llm, tmp_config)
    ids = [uuid4(), uuid4(), uuid4()]
    for i, mid in enumerate(ids):
        judge.record_triple(
            memory_id=mid,
            memory_l2=f"Memory {i}",
            query="some query",
            response_summary="some response",
            has_clear_signal=False,
        )
    ratings = await judge.evaluate()
    assert len(ratings) == 3
    rating_values = {r.memory_id: r.rating for r in ratings}
    assert rating_values[ids[0]] == 2
    assert rating_values[ids[1]] == 0
    assert rating_values[ids[2]] == 1


async def test_judge_skips_clear_signal_triples(mock_judge_llm, tmp_config: FractalConfig):
    judge = BatchedLLMJudge(mock_judge_llm, tmp_config)
    mid = uuid4()
    judge.record_triple(mid, "Memory", "query", None, has_clear_signal=True)
    ratings = await judge.evaluate()
    assert ratings == []
    mock_judge_llm.complete.assert_not_called()


async def test_judge_fallback_on_bad_response(tmp_config: FractalConfig):
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value="not valid json at all !!!")
    judge = BatchedLLMJudge(llm, tmp_config)
    mid = uuid4()
    judge.record_triple(mid, "Memory", "query", None, has_clear_signal=False)
    ratings = await judge.evaluate()
    # Should fall back gracefully — either parses something or pads with 1
    assert len(ratings) == 1
    assert ratings[0].rating in (0, 1, 2)


async def test_judge_handles_markdown_fenced_json(tmp_config: FractalConfig):
    llm = AsyncMock(spec=LLMProvider)
    llm.complete = AsyncMock(return_value="```json\n[2]\n```")
    judge = BatchedLLMJudge(llm, tmp_config)
    mid = uuid4()
    judge.record_triple(mid, "Memory", "query", None, has_clear_signal=False)
    ratings = await judge.evaluate()
    assert len(ratings) == 1
    assert ratings[0].rating == 2


async def test_judge_reset_session(mock_judge_llm, tmp_config: FractalConfig):
    judge = BatchedLLMJudge(mock_judge_llm, tmp_config)
    mid = uuid4()
    judge.record_triple(mid, "M", "q", None, has_clear_signal=False)
    judge.reset_session()
    ratings = await judge.evaluate()
    assert ratings == []


# ---------------------------------------------------------------------------
# DangerTheoryDetector — engagement signal
# ---------------------------------------------------------------------------


def test_detects_engagement_signal_when_message_long_and_on_topic():
    """Long message on the same topic as previous query triggers engagement signal."""
    config = FractalConfig()
    detector = DangerTheoryDetector(config)
    q_emb = _unit_vec(seed=10)

    # Establish baseline average message length with a short message
    detector.detect_signals("short", q_emb, [])

    # Send a long message that is 2x the average length and on the same topic
    # engagement_length_ratio = 1.5 by default; prev avg = len("short") = 5
    # long_msg needs len >= 5 * 1.5 = 7.5, so >= 8 chars
    long_message = "A long and detailed follow-up message about the same topic."
    signals = detector.detect_signals(long_message, q_emb, [uuid4()])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.ENGAGEMENT in subtypes, (
        "Long on-topic message should trigger engagement signal"
    )


def test_no_engagement_signal_when_message_short():
    """Short message below length ratio threshold does not trigger engagement."""
    config = FractalConfig()
    detector = DangerTheoryDetector(config)
    q_emb = _unit_vec(seed=10)

    # Establish a longer baseline average
    detector.detect_signals("A fairly long baseline message for length tracking.", q_emb, [])
    # Second message is much shorter than 1.5x the average
    signals = detector.detect_signals("Short.", q_emb, [])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.ENGAGEMENT not in subtypes


def test_no_engagement_signal_when_topic_differs():
    """Long message on a different topic does not trigger engagement."""
    config = FractalConfig()
    detector = DangerTheoryDetector(config)
    q_emb_1 = _unit_vec(seed=10)   # topic A
    q_emb_2 = _unit_vec(seed=999)  # topic B — very different direction

    detector.detect_signals("short", q_emb_1, [])
    long_message = "A very long message but about a completely different topic entirely."
    signals = detector.detect_signals(long_message, q_emb_2, [])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.ENGAGEMENT not in subtypes


def test_engagement_boundary_exactly_at_ratio():
    """Message exactly at the length ratio boundary triggers engagement."""
    config = FractalConfig(engagement_length_ratio=2.0)
    detector = DangerTheoryDetector(config)
    q_emb = _unit_vec(seed=20)

    baseline = "abcde"  # 5 chars
    detector.detect_signals(baseline, q_emb, [])
    # Exactly 2x: 10 chars, same topic embedding
    # avg after first call = 5, need >= 5 * 2.0 = 10
    exactly_at_boundary = "abcdefghij"  # 10 chars
    signals = detector.detect_signals(exactly_at_boundary, q_emb, [uuid4()])
    subtypes = [s.subtype for s in signals]
    assert FeedbackSubtype.ENGAGEMENT in subtypes, (
        "Message at exact boundary should trigger engagement"
    )


# ---------------------------------------------------------------------------
# BatchedLLMJudge — cost estimate and LLM mock call assertion
# ---------------------------------------------------------------------------


def test_judge_cost_estimate_returns_float(tmp_config: FractalConfig, mock_judge_llm):
    judge = BatchedLLMJudge(mock_judge_llm, tmp_config)
    for i in range(5):
        judge.record_triple(uuid4(), f"M{i}", "q", None, has_clear_signal=False)
    cost = judge.get_cost_estimate()
    assert isinstance(cost, float)
    assert cost > 0.0


async def test_judge_calls_llm_once_per_batch(tmp_config: FractalConfig, mock_judge_llm):
    """For N <= JUDGE_BATCH_SIZE triples, LLM should be called exactly once."""
    judge = BatchedLLMJudge(mock_judge_llm, tmp_config)
    for i in range(3):
        judge.record_triple(uuid4(), f"M{i}", "q", None, has_clear_signal=False)
    mock_judge_llm.complete.reset_mock()
    await judge.evaluate()
    mock_judge_llm.complete.assert_called_once()
