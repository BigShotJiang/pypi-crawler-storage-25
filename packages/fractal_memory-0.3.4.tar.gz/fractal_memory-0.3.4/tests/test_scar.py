"""Tests for Phase 2 — ScarTissueManager."""

from __future__ import annotations

from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.scar import ScarTissueManager
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _unit_vec(seed: int = 0, dim: int = 384) -> list[float]:
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return (v / np.linalg.norm(v)).tolist()


def _make_memory(
    lifecycle: LifecycleStatus = LifecycleStatus.CONFIRMED,
) -> Memory:
    from datetime import datetime
    return Memory(
        id=uuid4(),
        domain="default",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="label",
        l2_summary="summary",
        l3_full="detail",
        l4_raw="raw",
        embedding=_unit_vec(),
        embedding_model="test",
        lifecycle=lifecycle,
        intensity=0.5,
    )


@pytest.fixture
def scar_mgr(storage: Storage, mock_embeddings, tmp_config: FractalConfig):
    return ScarTissueManager(storage, mock_embeddings, tmp_config)


# ---------------------------------------------------------------------------
# Scar creation
# ---------------------------------------------------------------------------


async def test_create_scar_stores_record(scar_mgr: ScarTissueManager, storage: Storage):
    q_emb = _unit_vec(seed=1)
    scar = await scar_mgr.create_scar(
        reason="test correction",
        subtype="correction",
        query_embedding=q_emb,
        memory_ids=[uuid4()],
    )
    assert scar.id is not None
    active = await storage.get_active_scars()
    assert any(s[0] == scar.id for s in active)


async def test_create_scar_ttl_correction(scar_mgr: ScarTissueManager, tmp_config: FractalConfig):
    q_emb = _unit_vec(seed=2)
    scar = await scar_mgr.create_scar("reason", "correction", q_emb, [])
    assert scar.ttl_sessions == tmp_config.scar_ttl_sessions


async def test_create_scar_ttl_re_ask(scar_mgr: ScarTissueManager, tmp_config: FractalConfig):
    q_emb = _unit_vec(seed=3)
    scar = await scar_mgr.create_scar("reason", "re_ask", q_emb, [])
    assert scar.ttl_sessions == tmp_config.scar_ttl_sessions // 2


async def test_create_scar_no_memory_ids(scar_mgr: ScarTissueManager):
    q_emb = _unit_vec(seed=4)
    scar = await scar_mgr.create_scar("reason", "rejection", q_emb, [])
    assert scar.memory_id is None


async def test_create_scar_reinforces_similar_existing(
    scar_mgr: ScarTissueManager, storage: Storage
):
    q_emb = _unit_vec(seed=5)
    scar1 = await scar_mgr.create_scar("first", "correction", q_emb, [])
    # Slightly perturbed but same direction (cosine > 0.85)
    scar2 = await scar_mgr.create_scar("second", "correction", q_emb, [])
    # Should reinforce the same scar, not create a new one
    active = await storage.get_active_scars()
    scar_ids = {s[0] for s in active}
    assert scar1.id in scar_ids
    # Count should not grow unbounded for same pattern
    assert len(scar_ids) == 1


# ---------------------------------------------------------------------------
# Penalty application
# ---------------------------------------------------------------------------


async def test_apply_scar_penalty_reduces_score(
    scar_mgr: ScarTissueManager, storage: Storage
):
    q_emb = _unit_vec(seed=10)
    mem = _make_memory()
    scar = await scar_mgr.create_scar("bad", "correction", q_emb, [mem.id])

    scored = [(mem, 1.0)]
    result = await scar_mgr.apply_scar_penalty(q_emb, scored)
    assert len(result) == 1
    _mem, new_score = result[0]
    assert new_score < 1.0


async def test_apply_scar_penalty_exempts_safety_critical(
    scar_mgr: ScarTissueManager, storage: Storage
):
    q_emb = _unit_vec(seed=11)
    mem = _make_memory(lifecycle=LifecycleStatus.SAFETY_CRITICAL)
    await scar_mgr.create_scar("bad", "correction", q_emb, [mem.id])

    scored = [(mem, 1.0)]
    result = await scar_mgr.apply_scar_penalty(q_emb, scored)
    _mem, score = result[0]
    assert score == 1.0  # exempt


async def test_apply_scar_penalty_no_scars(scar_mgr: ScarTissueManager):
    q_emb = _unit_vec()
    mem = _make_memory()
    scored = [(mem, 0.8)]
    result = await scar_mgr.apply_scar_penalty(q_emb, scored)
    assert result[0][1] == 0.8


async def test_apply_scar_penalty_unrelated_query_no_effect(
    scar_mgr: ScarTissueManager, storage: Storage
):
    """A scar created for a very different query should not penalise other queries."""
    scar_emb = _unit_vec(seed=100)
    unrelated_emb = _unit_vec(seed=101)
    mem = _make_memory()
    await scar_mgr.create_scar("bad", "correction", scar_emb, [mem.id])

    scored = [(mem, 0.9)]
    result = await scar_mgr.apply_scar_penalty(unrelated_emb, scored)
    # Penalty should not apply if cosine similarity < threshold (0.7)
    # Seeds 100 and 101 produce nearly orthogonal vectors (random 384-d)
    _mem, score = result[0]
    assert score >= 0.9 - 1e-6


async def test_apply_scar_indirect_penalty(
    scar_mgr: ScarTissueManager, storage: Storage
):
    """Memories associated with a scarred memory receive the 0.8x indirect penalty."""
    q_emb = _unit_vec(seed=12)
    scarred_mem = _make_memory()
    neighbor_mem = _make_memory()
    await storage.store_memory(scarred_mem)
    await storage.store_memory(neighbor_mem)
    # Create association between the two memories
    await storage.store_association(neighbor_mem.id, scarred_mem.id, weight=0.4)
    # Create scar attributed to scarred_mem
    await scar_mgr.create_scar("bad", "correction", q_emb, [scarred_mem.id])

    # Score only the neighbor — it's not directly scarred but is associated
    scored = [(neighbor_mem, 1.0)]
    result = await scar_mgr.apply_scar_penalty(q_emb, scored)
    _mem, new_score = result[0]
    assert new_score < 1.0  # indirect penalty applied
    assert abs(new_score - 0.8) < 1e-6  # exactly 0.8x


# ---------------------------------------------------------------------------
# Expiry
# ---------------------------------------------------------------------------


async def test_expire_scars_deletes_expired(
    scar_mgr: ScarTissueManager, storage: Storage, tmp_path
):
    config = FractalConfig(db_path=tmp_path / "scar_expire.db", scar_ttl_sessions=1)
    s = Storage(config)
    await s.initialize()
    mgr = ScarTissueManager(s, None, config)  # type: ignore[arg-type]

    q_emb = _unit_vec(seed=20)
    await mgr.create_scar("short-lived", "correction", q_emb, [])

    # Expire once — should delete (ttl=1, after 1 increment sessions_elapsed >= ttl)
    expired = await mgr.expire_scars()
    assert expired >= 1
    active = await s.get_active_scars()
    assert len(active) == 0
    await s.close()


async def test_get_active_scars_returns_scar_objects(
    scar_mgr: ScarTissueManager, storage: Storage
):
    q_emb = _unit_vec(seed=30)
    await scar_mgr.create_scar("test", "correction", q_emb, [uuid4()])
    scars = await scar_mgr.get_active_scars()
    assert len(scars) == 1
    assert scars[0].reason == "test"


# ---------------------------------------------------------------------------
# Issue #6 — count_active_scars excludes expired
# ---------------------------------------------------------------------------


async def test_count_active_scars_excludes_expired(storage: Storage):
    """count_active_scars must not count expired scars (sessions_elapsed >= ttl_sessions)."""
    conn = storage._ensure_conn()
    from uuid import uuid4 as _u4
    from datetime import datetime
    from fractal_memory.storage import _pack_embedding
    now = datetime.utcnow().isoformat()
    dummy_emb = _pack_embedding([0.0] * 384)
    # Expired scar: sessions_elapsed=10, ttl_sessions=5
    await conn.execute(
        "INSERT INTO scars (id, reason, pattern_embedding, created_at, sessions_elapsed, ttl_sessions) VALUES (?, ?, ?, ?, ?, ?)",
        (str(_u4()), "expired", dummy_emb, now, 10, 5),
    )
    # Active scar: sessions_elapsed=2, ttl_sessions=10
    await conn.execute(
        "INSERT INTO scars (id, reason, pattern_embedding, created_at, sessions_elapsed, ttl_sessions) VALUES (?, ?, ?, ?, ?, ?)",
        (str(_u4()), "active", dummy_emb, now, 2, 10),
    )
    await conn.commit()
    count = await storage.count_active_scars()
    assert count == 1


async def test_count_active_scars_boundary_exact_expiry(storage: Storage):
    """Scar with sessions_elapsed == ttl_sessions is expired (not active)."""
    conn = storage._ensure_conn()
    from uuid import uuid4 as _u4
    from datetime import datetime
    from fractal_memory.storage import _pack_embedding
    now = datetime.utcnow().isoformat()
    dummy_emb = _pack_embedding([0.0] * 384)
    await conn.execute(
        "INSERT INTO scars (id, reason, pattern_embedding, created_at, sessions_elapsed, ttl_sessions) VALUES (?, ?, ?, ?, ?, ?)",
        (str(_u4()), "boundary", dummy_emb, now, 5, 5),
    )
    await conn.commit()
    count = await storage.count_active_scars()
    assert count == 0


async def test_count_active_scars_boundary_one_before_expiry(storage: Storage):
    """Scar with sessions_elapsed == ttl_sessions - 1 is still active."""
    conn = storage._ensure_conn()
    from uuid import uuid4 as _u4
    from datetime import datetime
    from fractal_memory.storage import _pack_embedding
    now = datetime.utcnow().isoformat()
    dummy_emb = _pack_embedding([0.0] * 384)
    await conn.execute(
        "INSERT INTO scars (id, reason, pattern_embedding, created_at, sessions_elapsed, ttl_sessions) VALUES (?, ?, ?, ?, ?, ?)",
        (str(_u4()), "almost", dummy_emb, now, 4, 5),
    )
    await conn.commit()
    count = await storage.count_active_scars()
    assert count == 1
