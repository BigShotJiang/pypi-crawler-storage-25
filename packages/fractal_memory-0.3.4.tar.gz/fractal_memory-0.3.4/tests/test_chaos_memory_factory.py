"""Adversarial data tests — NaN embeddings, Unicode, empty strings, zero vectors, extreme intensity.

Probes storage and FractalMemory with pathological inputs to discover
edge-case failures in embedding packing, retrieval, and memory creation.
"""

from __future__ import annotations

import asyncio
import json
import math
import struct
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Chaos test session summary."
        return json.dumps({
            "l0_tag": "chaos:test",
            "l1_label": "chaos-memory",
            "l2_summary": "Chaos test memory summary.",
            "l3_full": "Chaos test memory with full context.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


@pytest.fixture
def chaos_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "chaos_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def chaos_storage(chaos_config: FractalConfig):
    s = Storage(chaos_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
async def chaos_fm(chaos_config: FractalConfig):
    fm = FractalMemory(chaos_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ── Embedding packing/unpacking ──────────────────────────────────────


class TestEmbeddingPacking:
    def test_nan_embedding_rejected(self):
        """_pack_embedding must reject NaN values."""
        vec = [0.0] * 383 + [float("nan")]
        with pytest.raises(ValueError, match="NaN"):
            _pack_embedding(vec)

    def test_inf_embedding_rejected(self):
        """_pack_embedding must reject Inf values."""
        vec = [0.0] * 383 + [float("inf")]
        with pytest.raises(ValueError, match="Inf"):
            _pack_embedding(vec)

    def test_neg_inf_embedding_rejected(self):
        """_pack_embedding must reject -Inf values."""
        vec = [0.0] * 383 + [float("-inf")]
        with pytest.raises(ValueError, match="Inf"):
            _pack_embedding(vec)

    def test_zero_vector_packs(self):
        """An all-zero embedding should pack and unpack correctly."""
        vec = [0.0] * 384
        blob = _pack_embedding(vec)
        restored = _unpack_embedding(blob)
        assert restored == vec

    def test_round_trip_fidelity(self):
        """Pack → unpack should be lossless for float32 values."""
        vec = _deterministic_embed("round-trip-test")
        blob = _pack_embedding(vec)
        restored = _unpack_embedding(blob)
        np.testing.assert_allclose(restored, vec, rtol=1e-6)

    def test_empty_embedding_packs(self):
        """Empty embedding should pack to empty bytes."""
        vec: list[float] = []
        blob = _pack_embedding(vec)
        assert blob == b""
        restored = _unpack_embedding(blob)
        assert restored == []


# ── Unicode and special strings ──────────────────────────────────────


class TestUnicodeStrings:
    @pytest.mark.asyncio
    async def test_store_emoji_text(self, chaos_fm: FractalMemory):
        """Storing emoji-heavy text should not crash."""
        await chaos_fm.session_start("chaos")
        mem = await chaos_fm.store("🧠💡🔥 Memory with emojis and special chars: é à ü ñ 中文 日本語")
        assert mem is not None
        assert "🧠" in mem.l4_raw

    @pytest.mark.asyncio
    async def test_store_null_bytes(self, chaos_fm: FractalMemory):
        """Text with embedded null bytes should be stored safely or rejected gracefully."""
        await chaos_fm.session_start("chaos")
        text = "Memory with\x00null\x00bytes inside"
        # Should either succeed with round-trip fidelity or raise — not crash
        raised = False
        try:
            mem = await chaos_fm.store(text)
            if mem is not None:
                fetched = await chaos_fm.get(mem.id)
                assert fetched is not None, "Stored memory with null bytes but couldn't fetch it"
        except (ValueError, Exception):
            raised = True
        # Verify: either stored successfully or raised a clear exception
        assert raised or mem is not None, "Null-byte text should either store or raise"

    @pytest.mark.asyncio
    async def test_store_very_long_unicode(self, chaos_fm: FractalMemory):
        """Store a 50KB Unicode string at the config max."""
        await chaos_fm.session_start("chaos")
        text = "こんにちは世界 " * 5000  # ~50K chars
        mem = await chaos_fm.store(text[:50000])
        assert mem is not None

    @pytest.mark.asyncio
    async def test_retrieve_with_unicode_query(self, chaos_fm: FractalMemory):
        """Retrieving with Unicode query should work."""
        await chaos_fm.session_start("chaos")
        await chaos_fm.store("Japanese programming: Python is パイソン")
        result = await chaos_fm.retrieve("パイソン言語", domain="chaos")
        # Should not raise — results may or may not match
        assert result is not None


# ── Extreme intensity values ─────────────────────────────────────────


class TestExtremeIntensity:
    @pytest.mark.asyncio
    async def test_store_zero_intensity(self, chaos_fm: FractalMemory):
        """Storing with intensity=0.0 should work."""
        await chaos_fm.session_start("chaos")
        mem = await chaos_fm.store("Zero intensity memory", intensity=0.0)
        assert mem is not None
        assert mem.intensity >= 0.0

    @pytest.mark.asyncio
    async def test_store_max_intensity(self, chaos_fm: FractalMemory):
        """Storing with intensity=1.0 should work."""
        await chaos_fm.session_start("chaos")
        mem = await chaos_fm.store("Max intensity memory", intensity=1.0)
        assert mem is not None
        assert mem.intensity <= 1.0

    @pytest.mark.asyncio
    async def test_store_negative_intensity(self, chaos_fm: FractalMemory):
        """Negative intensity should be clamped to 0.0."""
        await chaos_fm.session_start("chaos")
        mem = await chaos_fm.store("Negative intensity", intensity=-0.5)
        assert mem is not None
        assert mem.intensity >= 0.0, "Negative intensity stored unclamped"

    @pytest.mark.asyncio
    async def test_store_beyond_one_intensity(self, chaos_fm: FractalMemory):
        """Intensity > 1.0 should be clamped to 1.0."""
        await chaos_fm.session_start("chaos")
        mem = await chaos_fm.store("Over-one intensity", intensity=5.0)
        assert mem is not None
        assert mem.intensity <= 1.0, "Intensity > 1.0 stored unclamped"


# ── Direct storage with bad embeddings ───────────────────────────────


class TestStorageBadEmbeddings:
    @pytest.mark.asyncio
    async def test_store_memory_with_zero_vector(self, chaos_storage: Storage):
        """A memory with an all-zero embedding should store and retrieve."""
        mem = Memory(
            id=uuid4(), domain="chaos", created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(), context={},
            l0_tag="zero", l1_label="zero-vec", l2_summary="Zero vector test",
            l3_full="Full text for zero vector", l4_raw="raw zero vector",
            embedding=[0.0] * 384, embedding_model="mock",
        )
        await chaos_storage.store_memory(mem)
        fetched = await chaos_storage.get_memory(mem.id)
        assert fetched is not None
        assert all(v == 0.0 for v in fetched.embedding)

    @pytest.mark.asyncio
    async def test_store_memory_dim1(self, tmp_path: Path):
        """Storing a 1-dimensional embedding should work."""
        cfg = FractalConfig(
            db_path=tmp_path / "dim1.db", gate_signal_count=1, embedding_dim=1
        )
        s = Storage(cfg)
        await s.initialize()
        try:
            mem = Memory(
                id=uuid4(), domain="chaos", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag="d1", l1_label="dim1", l2_summary="1D test",
                l3_full="Full 1D", l4_raw="raw 1D",
                embedding=[0.42], embedding_model="mock",
            )
            await s.store_memory(mem)
            fetched = await s.get_memory(mem.id)
            assert fetched is not None
            assert len(fetched.embedding) == 1
        finally:
            await s.close()
