"""Tests for SQLite storage layer."""

import json
from datetime import datetime
from uuid import uuid4

import pytest

from fractal_memory.models import (
    LifecycleStatus,
    Memory,
    Session,
    Task,
    TaskStatus,
    WaitingRoomEntry,
)
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


# -------------------------------------------------------------------
# Embedding serialization
# -------------------------------------------------------------------

def test_embedding_roundtrip():
    original = [0.1, -0.2, 0.3, 0.0, 1.0, -1.0]
    packed = _pack_embedding(original)
    unpacked = _unpack_embedding(packed)
    assert len(unpacked) == len(original)
    for a, b in zip(original, unpacked):
        assert abs(a - b) < 1e-6


def test_embedding_384d_roundtrip():
    import numpy as np
    rng = np.random.RandomState(42)
    original = rng.randn(384).astype(np.float32).tolist()
    packed = _pack_embedding(original)
    unpacked = _unpack_embedding(packed)
    for a, b in zip(original, unpacked):
        assert abs(a - b) < 1e-6


# -------------------------------------------------------------------
# Schema creation
# -------------------------------------------------------------------

async def test_schema_created(storage: Storage):
    conn = storage._ensure_conn()
    async with conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ) as cur:
        tables = {row[0] async for row in cur}
    assert "memories" in tables
    assert "tasks" in tables
    assert "waiting_room" in tables
    assert "sessions" in tables
    assert "schema_version" in tables
    assert "associations" in tables
    assert "scars" in tables


async def test_schema_version(storage: Storage):
    conn = storage._ensure_conn()
    async with conn.execute("SELECT version FROM schema_version") as cur:
        row = await cur.fetchone()
        assert row[0] == 1


# -------------------------------------------------------------------
# Memory CRUD
# -------------------------------------------------------------------

def _make_memory(**kwargs) -> Memory:
    defaults = dict(
        id=uuid4(),
        domain="test",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={"project": "test"},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="test summary",
        l3_full="test full context",
        l4_raw="raw text",
        embedding=[0.1] * 384,
        embedding_model="test-model",
    )
    defaults.update(kwargs)
    return Memory(**defaults)


async def test_store_and_get_memory(storage: Storage):
    mem = _make_memory()
    await storage.store_memory(mem)
    fetched = await storage.get_memory(mem.id)
    assert fetched is not None
    assert fetched.id == mem.id
    assert fetched.domain == mem.domain
    assert fetched.l0_tag == mem.l0_tag
    assert fetched.lifecycle == LifecycleStatus.PROBATION
    assert len(fetched.embedding) == 384
    # Check embedding precision
    for a, b in zip(mem.embedding, fetched.embedding):
        assert abs(a - b) < 1e-6


async def test_get_nonexistent_memory(storage: Storage):
    result = await storage.get_memory(uuid4())
    assert result is None


async def test_delete_memory(storage: Storage):
    mem = _make_memory()
    await storage.store_memory(mem)
    deleted = await storage.delete_memory(mem.id)
    assert deleted is True
    assert await storage.get_memory(mem.id) is None


async def test_delete_nonexistent(storage: Storage):
    deleted = await storage.delete_memory(uuid4())
    assert deleted is False


async def test_update_memory(storage: Storage):
    mem = _make_memory()
    await storage.store_memory(mem)
    mem.retrieval_count = 5
    mem.lifecycle = LifecycleStatus.CONFIRMED
    mem.updated_at = datetime.utcnow()
    await storage.update_memory(mem)
    fetched = await storage.get_memory(mem.id)
    assert fetched.retrieval_count == 5
    assert fetched.lifecycle == LifecycleStatus.CONFIRMED


async def test_get_all_embeddings(storage: Storage):
    m1 = _make_memory(domain="d1", embedding=[0.5] * 384)
    m2 = _make_memory(domain="d1", embedding=[0.3] * 384)
    m3 = _make_memory(domain="d2", embedding=[0.7] * 384)
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    await storage.store_memory(m3)
    result = await storage.get_all_embeddings("d1")
    assert len(result) == 2
    ids = {uid for uid, _ in result}
    assert m1.id in ids
    assert m2.id in ids


async def test_get_memories_by_ids(storage: Storage):
    m1 = _make_memory()
    m2 = _make_memory()
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    result = await storage.get_memories_by_ids([m2.id, m1.id])
    assert len(result) == 2
    assert result[0].id == m2.id
    assert result[1].id == m1.id


async def test_get_memories_by_domain(storage: Storage):
    m1 = _make_memory(domain="alpha")
    m2 = _make_memory(domain="beta")
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    result = await storage.get_memories_by_domain("alpha")
    assert len(result) == 1
    assert result[0].domain == "alpha"


async def test_get_memories_by_lifecycle(storage: Storage):
    m1 = _make_memory(lifecycle=LifecycleStatus.SAFETY_CRITICAL)
    m2 = _make_memory(lifecycle=LifecycleStatus.PROBATION)
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    result = await storage.get_memories_by_lifecycle(LifecycleStatus.SAFETY_CRITICAL)
    assert len(result) == 1
    assert result[0].id == m1.id


async def test_count_memories(storage: Storage):
    m1 = _make_memory(domain="a")
    m2 = _make_memory(domain="a")
    m3 = _make_memory(domain="b")
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    await storage.store_memory(m3)
    assert await storage.count_memories() == 3
    assert await storage.count_memories("a") == 2
    assert await storage.count_memories("b") == 1


# -------------------------------------------------------------------
# Waiting room CRUD
# -------------------------------------------------------------------

def _make_waiting(**kwargs) -> WaitingRoomEntry:
    defaults = dict(
        id=uuid4(),
        content="test content",
        first_signal={"type": "explicit_store"},
        domain="test",
        created_at=datetime.utcnow(),
        sessions_elapsed=0,
        embedding=[0.1] * 384,
    )
    defaults.update(kwargs)
    return WaitingRoomEntry(**defaults)


async def test_waiting_room_store_and_get(storage: Storage):
    entry = _make_waiting()
    await storage.store_waiting_room_entry(entry)
    fetched = await storage.get_waiting_room_entry(entry.id)
    assert fetched is not None
    assert fetched.id == entry.id
    assert fetched.content == entry.content


async def test_waiting_room_delete(storage: Storage):
    entry = _make_waiting()
    await storage.store_waiting_room_entry(entry)
    await storage.delete_waiting_room_entry(entry.id)
    assert await storage.get_waiting_room_entry(entry.id) is None


async def test_waiting_room_expire(storage: Storage):
    e1 = _make_waiting(sessions_elapsed=5)
    e2 = _make_waiting(sessions_elapsed=1)
    await storage.store_waiting_room_entry(e1)
    await storage.store_waiting_room_entry(e2)
    expired = await storage.get_expired_waiting_room_entries(3)
    assert len(expired) == 1
    assert expired[0].id == e1.id


async def test_waiting_room_increment(storage: Storage):
    e = _make_waiting(sessions_elapsed=0)
    await storage.store_waiting_room_entry(e)
    await storage.increment_waiting_room_sessions()
    fetched = await storage.get_waiting_room_entry(e.id)
    assert fetched.sessions_elapsed == 1


async def test_waiting_room_evict(storage: Storage):
    for i in range(5):
        await storage.store_waiting_room_entry(_make_waiting())
    evicted = await storage.evict_oldest_waiting_room(3)
    assert evicted == 2


# -------------------------------------------------------------------
# Task CRUD
# -------------------------------------------------------------------

async def test_task_store_and_get(storage: Storage):
    task = Task(
        id=uuid4(),
        description="Do something",
        created_at=datetime.utcnow(),
    )
    await storage.store_task(task)
    fetched = await storage.get_task(task.id)
    assert fetched is not None
    assert fetched.description == "Do something"
    assert fetched.status == TaskStatus.ACTIVE


async def test_task_update(storage: Storage):
    task = Task(
        id=uuid4(),
        description="Do something",
        created_at=datetime.utcnow(),
    )
    await storage.store_task(task)
    task.status = TaskStatus.COMPLETED
    await storage.update_task(task)
    fetched = await storage.get_task(task.id)
    assert fetched.status == TaskStatus.COMPLETED


async def test_task_list(storage: Storage):
    t1 = Task(id=uuid4(), description="a", created_at=datetime.utcnow())
    t2 = Task(id=uuid4(), description="b", created_at=datetime.utcnow(), status=TaskStatus.COMPLETED)
    await storage.store_task(t1)
    await storage.store_task(t2)
    all_tasks = await storage.list_tasks()
    assert len(all_tasks) == 2
    active = await storage.list_tasks(TaskStatus.ACTIVE)
    assert len(active) == 1
    assert active[0].id == t1.id


# -------------------------------------------------------------------
# Session CRUD
# -------------------------------------------------------------------

async def test_session_store_and_update(storage: Storage):
    s = Session(id=uuid4(), domain="test", started_at=datetime.utcnow())
    await storage.store_session(s)
    s.ended_at = datetime.utcnow()
    s.summary = "session summary"
    await storage.update_session(s)
    last = await storage.get_last_session("test")
    assert last is not None
    assert last.summary == "session summary"


async def test_get_last_session_none(storage: Storage):
    result = await storage.get_last_session("nonexistent")
    assert result is None


async def test_session_count(storage: Storage):
    s1 = Session(id=uuid4(), domain="d1", started_at=datetime.utcnow(), ended_at=datetime.utcnow())
    s2 = Session(id=uuid4(), domain="d1", started_at=datetime.utcnow(), ended_at=datetime.utcnow())
    s3 = Session(id=uuid4(), domain="d2", started_at=datetime.utcnow(), ended_at=datetime.utcnow())
    await storage.store_session(s1)
    await storage.store_session(s2)
    await storage.store_session(s3)
    assert await storage.get_session_count() == 3
    assert await storage.get_session_count("d1") == 2


# -------------------------------------------------------------------
# Domain aggregation
# -------------------------------------------------------------------

async def test_list_domains(storage: Storage):
    m1 = _make_memory(domain="alpha")
    m2 = _make_memory(domain="alpha")
    m3 = _make_memory(domain="beta")
    await storage.store_memory(m1)
    await storage.store_memory(m2)
    await storage.store_memory(m3)
    domains = await storage.list_domains()
    assert len(domains) == 2
    domain_dict = {d[0]: d[1] for d in domains}
    assert domain_dict["alpha"] == 2
    assert domain_dict["beta"] == 1


# -------------------------------------------------------------------
# Concurrent reads (WAL mode)
# -------------------------------------------------------------------

async def test_concurrent_reads_wal(storage: Storage):
    """WAL mode allows concurrent reads without blocking."""
    import asyncio

    for i in range(10):
        await storage.store_memory(_make_memory(domain="wal"))

    async def read_count():
        return await storage.count_memories("wal")

    async def read_all():
        return await storage.get_memories_by_domain("wal")

    # Run concurrent reads
    results = await asyncio.gather(
        read_count(), read_all(), read_count(), read_all()
    )
    assert results[0] == 10
    assert len(results[1]) == 10
    assert results[2] == 10
    assert len(results[3]) == 10


# -------------------------------------------------------------------
# Issue #2 — get_summary_stats() key names
# -------------------------------------------------------------------

async def test_summary_stats_keys_used_by_folding_regime(storage: Storage):
    """get_summary_stats() returns total_memories and total_sessions keys."""
    for i in range(5):
        await storage.store_memory(_make_memory(domain="stats_test"))
    stats = await storage.get_summary_stats()
    assert stats["total_memories"] >= 5
    assert "total_sessions" in stats
    # Verify the wrong keys are NOT present
    assert "memories" not in stats
    assert "sessions" not in stats


# -------------------------------------------------------------------
# Issue #3 — _row_to_memory module-level function used correctly
# -------------------------------------------------------------------

async def test_get_top_memories_for_rem_returns_memories(storage: Storage):
    """get_top_memories_for_rem returns Memory objects ordered by retrieval count."""
    mem_a = _make_memory(l4_raw="low retrieval")
    mem_b = _make_memory(l4_raw="mid retrieval")
    mem_c = _make_memory(l4_raw="high retrieval")
    await storage.store_memory(mem_a)
    await storage.store_memory(mem_b)
    await storage.store_memory(mem_c)
    # Bump retrieval counts directly
    conn = storage._ensure_conn()
    await conn.execute("UPDATE memories SET retrieval_count = 1 WHERE id = ?", (str(mem_a.id),))
    await conn.execute("UPDATE memories SET retrieval_count = 5 WHERE id = ?", (str(mem_b.id),))
    await conn.execute("UPDATE memories SET retrieval_count = 10 WHERE id = ?", (str(mem_c.id),))
    await conn.commit()

    result = await storage.get_top_memories_for_rem(limit=2)
    assert len(result) == 2
    assert isinstance(result[0], Memory)
    assert result[0].l4_raw == "high retrieval"
    assert result[1].l4_raw == "mid retrieval"


async def test_list_memories_returns_all(storage: Storage):
    """list_memories returns all stored Memory objects."""
    ids = set()
    for _ in range(3):
        m = _make_memory(domain="list_test")
        ids.add(m.id)
        await storage.store_memory(m)
    result = await storage.list_memories(domain="list_test", limit=10)
    assert len(result) == 3
    assert isinstance(result[0], Memory)
    returned_ids = {m.id for m in result}
    assert returned_ids == ids


# -------------------------------------------------------------------
# Issue #5 — morphogen_history table
# -------------------------------------------------------------------

async def test_morphogen_history_roundtrip(storage: Storage):
    """save_morphogen_state + get_morphogen_history returns exact data."""
    from uuid import uuid4 as _u4
    sid = _u4()
    data = {"curve_a": 0.8, "curve_b": 0.3}
    await storage.save_morphogen_state(sid, data)
    history = await storage.get_morphogen_history()
    assert len(history) == 1
    assert history[0]["curve_a"] == 0.8
    assert history[0]["curve_b"] == 0.3


async def test_morphogen_history_empty(storage: Storage):
    """get_morphogen_history on fresh DB returns empty list."""
    history = await storage.get_morphogen_history()
    assert history == []


async def test_morphogen_history_malformed_json(storage: Storage):
    """Malformed JSON in morphogen_history is skipped, not crash."""
    conn = storage._ensure_conn()
    from uuid import uuid4 as _u4
    await conn.execute(
        "INSERT INTO morphogen_history (id, session_id, morphogens, created_at) VALUES (?, ?, ?, ?)",
        (str(_u4()), str(_u4()), "NOT VALID JSON{{{", datetime.utcnow().isoformat()),
    )
    await conn.commit()
    history = await storage.get_morphogen_history()
    assert history == []


async def test_morphogen_migration_idempotent(storage: Storage):
    """Running _migrate_phase3_schema twice does not error."""
    await storage._migrate_phase3_schema()
    await storage._migrate_phase3_schema()
    # Verify table exists
    conn = storage._ensure_conn()
    async with conn.execute("PRAGMA table_info(morphogen_history)") as cur:
        columns = [row[1] async for row in cur]
    assert "id" in columns
    assert "session_id" in columns
    assert "morphogens" in columns


# ---------------------------------------------------------------------------
# Issue #24: NaN / Inf embedding validation
# ---------------------------------------------------------------------------


async def test_store_rejects_nan_embedding(storage: Storage):
    """Issue #24: NaN in embedding raises ValueError."""
    from fractal_memory.storage import _pack_embedding

    with pytest.raises(ValueError, match="NaN"):
        _pack_embedding([0.1, float("nan"), 0.3])


async def test_store_rejects_inf_embedding(storage: Storage):
    """Issue #24: Inf in embedding raises ValueError."""
    from fractal_memory.storage import _pack_embedding

    with pytest.raises(ValueError, match="Inf"):
        _pack_embedding([0.1, float("inf"), 0.3])


async def test_store_accepts_valid_embedding(storage: Storage):
    """Issue #24: Valid embedding is accepted."""
    from fractal_memory.storage import _pack_embedding, _unpack_embedding

    packed = _pack_embedding([0.1, 0.2, 0.3])
    unpacked = _unpack_embedding(packed, 3)
    assert abs(unpacked[0] - 0.1) < 1e-6
    assert abs(unpacked[1] - 0.2) < 1e-6
    assert abs(unpacked[2] - 0.3) < 1e-6


# ---------------------------------------------------------------------------
# Issue #16: utcnow() returns naive datetime
# ---------------------------------------------------------------------------


def test_utcnow_returns_naive_datetime():
    """Issue #16: utcnow() returns a naive datetime (tzinfo is None)."""
    from fractal_memory._compat import utcnow

    result = utcnow()
    assert result.tzinfo is None
    # Should be within 1 second of now
    from datetime import UTC, datetime

    now = datetime.now(UTC).replace(tzinfo=None)
    diff = abs((now - result).total_seconds())
    assert diff < 1.0


# ---------------------------------------------------------------------------
# Issue #33: __version__ attribute
# ---------------------------------------------------------------------------


def test_version_matches_semver():
    """Issue #33: fractal_memory.__version__ matches semver pattern."""
    import re

    import fractal_memory

    assert hasattr(fractal_memory, "__version__")
    assert re.match(r"^\d+\.\d+\.\d+", fractal_memory.__version__)


# ---------------------------------------------------------------------------
# Issue #29: Activity flush triggers at interval, not before
# ---------------------------------------------------------------------------


async def test_activity_flush_at_interval_not_before(fractal_memory):
    """Issue #29: Flush only at activity_flush_interval, not before."""
    fm = fractal_memory
    await fm.session_start("test")

    # Patch upsert_session_activity to track calls
    from unittest.mock import AsyncMock

    original = fm._storage.upsert_session_activity
    call_count = 0

    async def tracking_upsert(**kwargs):
        nonlocal call_count
        call_count += 1
        return await original(**kwargs)

    fm._storage.upsert_session_activity = tracking_upsert

    interval = fm._config.activity_flush_interval
    # Store (interval - 1) memories — should NOT trigger flush
    for i in range(interval - 1):
        await fm.store(f"memory content {i}", domain="test")

    before_count = call_count
    # Store one more to hit the interval
    await fm.store(f"memory content {interval}", domain="test")
    # Should have flushed exactly once more
    assert call_count == before_count + 1


# ---------------------------------------------------------------------------
# Issue #16: test_stored_timestamp_format_unchanged
# ---------------------------------------------------------------------------


async def test_stored_timestamp_format_unchanged(storage: Storage):
    """Issue #16: Stored timestamps do NOT contain +00:00 (naive UTC preserved)."""
    from fractal_memory._compat import utcnow
    from fractal_memory.models import Memory

    mem = Memory(
        id=uuid4(),
        domain="test",
        created_at=utcnow(),
        updated_at=utcnow(),
        context={},
        l0_tag="t",
        l1_label="label",
        l2_summary="summary",
        l3_full="full",
        l4_raw="raw",
        embedding=[0.1] * 384,
        embedding_model="mock",
        intensity=0.5,
    )
    await storage.store_memory(mem)

    conn = storage._ensure_conn()
    async with conn.execute(
        "SELECT created_at FROM memories WHERE id = ?", (str(mem.id),)
    ) as cur:
        row = await cur.fetchone()
    assert row is not None
    created_at_str = row[0]
    assert "+00:00" not in created_at_str


# ---------------------------------------------------------------------------
# Issue #14: test_acreate_memory_can_store_and_retrieve
# ---------------------------------------------------------------------------


async def test_acreate_memory_can_store_and_retrieve(tmp_path):
    """Issue #14: acreate_memory() produces a working FractalMemory instance."""
    from unittest.mock import AsyncMock

    from fractal_memory import FractalMemory, acreate_memory
    from fractal_memory.config import FractalConfig

    config = FractalConfig(db_path=tmp_path / "test_acreate.db")
    fm = await acreate_memory(config)
    assert isinstance(fm, FractalMemory)
    assert fm._initialized is True
    await fm.close()


# ---------------------------------------------------------------------------
# Issue #25: test_warmup_completes_successfully
# ---------------------------------------------------------------------------


async def test_warmup_completes_successfully(fractal_memory):
    """Issue #25: Warmup task completes without error and is stored."""
    fm = fractal_memory
    assert hasattr(fm, "_warmup_task")
    # Await should not raise
    await fm._warmup_task
    assert fm._embeddings.dimension > 0
