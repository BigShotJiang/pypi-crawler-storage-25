"""Concurrent torture tests — 50+ concurrent stores/retrieves, double-delete, close-during-init.

Goes beyond test_stress_concurrency.py with adversarial concurrent patterns:
simultaneous session operations, double-deletes, closing storage mid-operation.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import Memory
from fractal_memory.storage import Storage


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Torture test summary."
        return json.dumps({
            "l0_tag": "torture:test",
            "l1_label": "torture-test",
            "l2_summary": "Torture test memory.",
            "l3_full": "Torture test memory full.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def torture_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "torture_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=50000,
    )


@pytest.fixture
async def torture_fm(torture_config: FractalConfig):
    fm = FractalMemory(torture_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def torture_storage(torture_config: FractalConfig):
    s = Storage(torture_config)
    await s.initialize()
    yield s
    await s.close()


# ── Concurrent store + retrieve ──────────────────────────────────────


class TestConcurrentTorture:
    @pytest.mark.asyncio
    async def test_75_concurrent_stores(self, torture_fm: FractalMemory):
        """75 concurrent stores should all succeed."""
        await torture_fm.session_start("torture")
        tasks = [torture_fm.store(f"Concurrent torture store {i} with unique data") for i in range(75)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Got {len(errors)} errors: {errors[:3]}"

    @pytest.mark.asyncio
    async def test_concurrent_store_retrieve_interleaved(self, torture_fm: FractalMemory):
        """Interleaved stores and retrieves should not deadlock."""
        await torture_fm.session_start("torture")
        for i in range(10):
            await torture_fm.store(f"Seed memory {i}")

        async def _store(i: int):
            return await torture_fm.store(f"Interleaved store {i}")

        async def _retrieve(i: int):
            return await torture_fm.retrieve(f"interleaved query {i}", domain="torture")

        tasks = []
        for i in range(25):
            tasks.append(_store(i))
            tasks.append(_retrieve(i))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Interleaved errors: {errors[:3]}"


# ── Double-delete ────────────────────────────────────────────────────


class TestDoubleDelete:
    @pytest.mark.asyncio
    async def test_delete_nonexistent_memory(self, torture_fm: FractalMemory):
        """Deleting a non-existent memory should return False, not crash."""
        result = await torture_fm.delete(uuid4())
        assert result is False

    @pytest.mark.asyncio
    async def test_double_delete_same_memory(self, torture_fm: FractalMemory):
        """Deleting the same memory twice should not crash."""
        await torture_fm.session_start("torture")
        mem = await torture_fm.store("Memory to double-delete")
        assert mem is not None
        first = await torture_fm.delete(mem.id)
        assert first is True
        second = await torture_fm.delete(mem.id)
        assert second is False

    @pytest.mark.asyncio
    async def test_concurrent_deletes(self, torture_fm: FractalMemory):
        """Concurrent deletes of the same memory should not crash."""
        await torture_fm.session_start("torture")
        mem = await torture_fm.store("Memory for concurrent delete")
        assert mem is not None
        results = await asyncio.gather(
            torture_fm.delete(mem.id),
            torture_fm.delete(mem.id),
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0
        # Exactly one should return True, the other False
        bools = [r for r in results if isinstance(r, bool)]
        assert True in bools


# ── Storage close during operations ──────────────────────────────────


class TestCloseDuringOps:
    @pytest.mark.asyncio
    async def test_close_then_store_raises(self, tmp_path: Path):
        """Store after close should raise RuntimeError."""
        cfg = FractalConfig(db_path=tmp_path / "close_test.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        await s.close()
        with pytest.raises(RuntimeError, match="not initialized"):
            mem = Memory(
                id=uuid4(), domain="test", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag="t", l1_label="l", l2_summary="s",
                l3_full="f", l4_raw="r",
                embedding=_deterministic_embed("test"),
                embedding_model="mock",
            )
            await s.store_memory(mem)

    @pytest.mark.asyncio
    async def test_double_close(self, tmp_path: Path):
        """Closing storage twice should not crash."""
        cfg = FractalConfig(db_path=tmp_path / "double_close.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        await s.close()
        await s.close()  # Should not raise

    @pytest.mark.asyncio
    async def test_close_then_count(self, tmp_path: Path):
        """count_memories after close should raise RuntimeError."""
        cfg = FractalConfig(db_path=tmp_path / "close_count.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        await s.close()
        with pytest.raises(RuntimeError, match="not initialized"):
            await s.count_memories()


# ── Concurrent session operations ────────────────────────────────────


class TestConcurrentSessions:
    @pytest.mark.asyncio
    async def test_concurrent_session_start_end(self, torture_config: FractalConfig):
        """Rapid sequential start→end should not corrupt state."""
        fm = FractalMemory(torture_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            for i in range(20):
                await fm.session_start("torture")
                await fm.store(f"Rapid session {i}")
                await fm.session_end()
            # After all cycles, no session should be active
            assert fm._session.current_session is None
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_fm_double_initialize(self, torture_config: FractalConfig):
        """Double initialize should not corrupt state."""
        fm = FractalMemory(torture_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        await fm.initialize()  # Should be safe
        try:
            await fm.session_start("double-init")
            mem = await fm.store("After double init")
            assert mem is not None
        finally:
            if fm._session.current_session:
                await fm.session_end()
            await fm.close()
