"""Tests for Phase 2 — ConsolidationEngine (B-13 partial)."""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.associations import AssociationNetwork
from fractal_memory.config import FractalConfig
from fractal_memory.consolidation import ConsolidationEngine
from fractal_memory.domains import DomainManager
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.scar import ScarTissueManager
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _unit_vec(seed: int = 0, dim: int = 384) -> list[float]:
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return (v / np.linalg.norm(v)).tolist()


def _similar_vec(reference: list[float], noise: float = 0.01) -> list[float]:
    """Return a vector very similar to reference (cosine > 0.99)."""
    rng = np.random.RandomState(42)
    v = np.array(reference, dtype=np.float32)
    v += rng.randn(len(v)).astype(np.float32) * noise
    v /= np.linalg.norm(v)
    return v.tolist()


def _make_memory(domain: str = "default", seed: int = 0) -> Memory:
    from datetime import datetime
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="label",
        l2_summary="A test memory summary.",
        l3_full="Detailed content for testing purposes.",
        l4_raw="raw content",
        embedding=_unit_vec(seed),
        embedding_model="test",
        lifecycle=LifecycleStatus.CONFIRMED,
        intensity=0.5,
    )


@pytest.fixture
async def engine(storage: Storage, mock_embeddings, mock_llm, tmp_config: FractalConfig):
    associations = AssociationNetwork(storage, mock_embeddings, tmp_config)
    scars = ScarTissueManager(storage, mock_embeddings, tmp_config)
    lifecycle = LifecycleManager(storage, tmp_config)
    domain_manager = DomainManager(storage, tmp_config)

    # Mock LLM returns a valid merge JSON
    async def _merge_response(prompt, system=None, max_tokens=500):
        if "Merge" in prompt:
            return json.dumps({
                "l0_tag": "test:merged",
                "l1_label": "merged-label",
                "l2_summary": "Merged memory summary.",
                "l3_full": "Full detail of merged memories.",
                "contrast": None,
            })
        return json.dumps({
            "l0_tag": "test:tag",
            "l1_label": "test-label",
            "l2_summary": "summary",
            "l3_full": "detail",
        })

    mock_llm.complete = AsyncMock(side_effect=_merge_response)

    eng = ConsolidationEngine(
        storage=storage,
        embeddings=mock_embeddings,
        llm=mock_llm,
        associations=associations,
        scars=scars,
        lifecycle=lifecycle,
        domains=domain_manager,
        config=tmp_config,
    )
    return eng


# ---------------------------------------------------------------------------
# Basic run — no-op on empty storage
# ---------------------------------------------------------------------------


async def test_consolidation_empty_db(engine: ConsolidationEngine):
    engine.set_session_data([], [], [])
    report = await engine.run()
    assert report.edges_strengthened == 0
    assert report.merges == []


# ---------------------------------------------------------------------------
# Slow-wave downscale
# ---------------------------------------------------------------------------


async def test_slow_wave_downscale_runs(
    engine: ConsolidationEngine, storage: Storage
):
    a, b = uuid4(), uuid4()
    await storage.store_association(a, b, weight=0.5)
    engine.set_session_data([], [], [])
    report = await engine.run()
    # After decay (factor 0.85): 0.5 * 0.85 = 0.425 — still above 0.01, not pruned
    assert report.edges_decayed == 0  # 0.425 is above min_viable_edge_weight
    edges = await storage.get_all_associations()
    # Edge must exist with a reduced weight
    assert len(edges) == 1
    _, _, decayed_weight = edges[0]
    assert decayed_weight < 0.5, f"Weight should have decayed below 0.5, got {decayed_weight}"
    assert decayed_weight > 0.01, "Weight should remain above min_viable threshold"


async def test_slow_wave_downscale_prunes_weak_edges(
    engine: ConsolidationEngine, storage: Storage
):
    """Edges that decay below min_viable_edge_weight are deleted."""
    a, b = uuid4(), uuid4()
    # 0.011 * 0.85 = 0.00935 < 0.01 (min_viable_edge_weight) — should be pruned
    await storage.store_association(a, b, weight=0.011)
    engine.set_session_data([], [], [])
    report = await engine.run()
    assert report.edges_decayed == 1
    edges = await storage.get_all_associations()
    assert len(edges) == 0, "Weak edge should have been pruned"


# ---------------------------------------------------------------------------
# Scar expiry during consolidation
# ---------------------------------------------------------------------------


async def test_scars_expired_during_consolidation(
    engine: ConsolidationEngine, storage: Storage, mock_embeddings, tmp_path
):
    config = FractalConfig(db_path=tmp_path / "ce_scar.db", scar_ttl_sessions=1)
    s = Storage(config)
    await s.initialize()
    from fractal_memory.associations import AssociationNetwork as AN
    from fractal_memory.lifecycle import LifecycleManager as LM
    from fractal_memory.domains import DomainManager as DM
    from fractal_memory.scar import ScarTissueManager as SM

    scars2 = SM(s, mock_embeddings, config)
    q_emb = _unit_vec(seed=50)
    await scars2.create_scar("test", "correction", q_emb, [])

    from fractal_memory.consolidation import ConsolidationEngine as CE
    eng2 = CE(
        storage=s,
        embeddings=mock_embeddings,
        llm=AsyncMock(spec=LLMProvider),
        associations=AN(s, mock_embeddings, config),
        scars=scars2,
        lifecycle=LM(s, config),
        domains=DM(s, config),
        config=config,
    )
    eng2.set_session_data([], [], [])
    report = await eng2.run()
    assert report.scars_expired >= 1
    await s.close()


# ---------------------------------------------------------------------------
# ConsolidationReport dataclass
# ---------------------------------------------------------------------------


def test_consolidation_report_defaults():
    from fractal_memory.consolidation import ConsolidationReport
    r = ConsolidationReport()
    assert r.edges_strengthened == 0
    assert r.merges == []
    assert r.scars_expired == 0
    assert r.freeloaders_found == 0


# ---------------------------------------------------------------------------
# set_session_data contract
# ---------------------------------------------------------------------------


async def test_set_session_data_used_in_run(engine: ConsolidationEngine, storage: Storage):
    mem = _make_memory()
    await storage.store_memory(mem)
    engine.set_session_data(
        session_memories=[mem.id],
        session_retrievals=[],
        judge_ratings=[],
    )
    report = await engine.run()
    # With no co-retrievals, no edges should be strengthened
    assert report.edges_strengthened == 0


async def test_strengthen_associations_on_co_retrieval(
    engine: ConsolidationEngine, storage: Storage
):
    """Co-retrieved memories at L3 zoom should result in edge strengthening."""
    mem_a = _make_memory(seed=1)
    mem_b = _make_memory(seed=2)
    await storage.store_memory(mem_a)
    await storage.store_memory(mem_b)

    retrieval = {
        "l2_ids": [mem_a.id, mem_b.id],
        "l3_ids": [mem_a.id, mem_b.id],
    }
    engine.set_session_data(
        session_memories=[mem_a.id, mem_b.id],
        session_retrievals=[retrieval],
        judge_ratings=[],
    )
    report = await engine.run()
    # Both L2 and L3 co-retrievals should strengthen the edge
    assert report.edges_strengthened > 0
    edges = await storage.get_all_associations()
    assert len(edges) >= 1, "Co-retrieval should have created an association edge"
    _, _, weight = edges[0]
    assert weight > 0, "Association edge weight must be positive"


async def test_llm_called_for_merge(storage: Storage, mock_embeddings, tmp_config: FractalConfig):
    """LLM must be called when two similar memories are found for merging."""
    from fractal_memory.lifecycle import LifecycleManager
    from fractal_memory.domains import DomainManager
    from fractal_memory.scar import ScarTissueManager

    # Use a mock LLM that returns l3_full longer than source memories
    llm = AsyncMock(spec=LLMProvider)
    async def _long_merge(prompt, system=None, max_tokens=500):
        return json.dumps({
            "l0_tag": "test:merged",
            "l1_label": "merged-label",
            "l2_summary": "Merged memory summary with more content.",
            "l3_full": "Full unified detail of all merged memories with comprehensive context spanning multiple topics.",
            "contrast": None,
        })
    llm.complete = AsyncMock(side_effect=_long_merge)

    eng = ConsolidationEngine(
        storage=storage,
        embeddings=mock_embeddings,
        llm=llm,
        associations=AssociationNetwork(storage, mock_embeddings, tmp_config),
        scars=ScarTissueManager(storage, mock_embeddings, tmp_config),
        lifecycle=LifecycleManager(storage, tmp_config),
        domains=DomainManager(storage, tmp_config),
        config=tmp_config,
    )

    vec = _unit_vec(seed=0)
    similar = _similar_vec(vec, noise=0.001)
    mem_a = _make_memory(seed=0)
    mem_b = _make_memory(seed=0)
    # Rebuild mem_b with a similar embedding and different id
    from dataclasses import replace
    mem_b = Memory(
        **{**mem_b.__dict__, "embedding": similar, "id": uuid4()}
    )
    await storage.store_memory(mem_a)
    await storage.store_memory(mem_b)

    eng.set_session_data([], [], [])
    llm.complete.reset_mock()
    report = await eng.run()

    # LLM should have been called at least once for the merge
    assert llm.complete.call_count >= 1, (
        "LLM merge should have been called for similar memories"
    )
    assert len(report.merges) == 1, "One merge group should have been processed"
    assert report.merges[0].domain == "default"


# ---------------------------------------------------------------------------
# Issue #1 — prune_expired / merge_duplicates delegates
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prune_expired_returns_pruned_count(tmp_config: FractalConfig) -> None:
    """prune_expired() delegates to _prune_freeloaders and returns its count."""
    storage = AsyncMock(spec=Storage)
    llm = AsyncMock(spec=LLMProvider)
    embeddings = AsyncMock(spec=EmbeddingProvider)
    associations = AsyncMock(spec=AssociationNetwork)
    scars = AsyncMock(spec=ScarTissueManager)
    lifecycle = AsyncMock(spec=LifecycleManager)
    domains = AsyncMock(spec=DomainManager)

    eng = ConsolidationEngine(
        storage=storage,
        embeddings=embeddings,
        llm=llm,
        associations=associations,
        scars=scars,
        lifecycle=lifecycle,
        domains=domains,
        config=tmp_config,
    )
    # Inject judge ratings with zero-rated memories
    from fractal_memory.feedback import JudgeRating
    mids = [uuid4() for _ in range(3)]
    ratings = [JudgeRating(memory_id=mid, rating=0, confidence=1.0) for mid in mids]
    eng.set_session_data([], [], ratings)
    # Mock get_memory to return a Memory
    storage.get_memory = AsyncMock(return_value=Memory(
        id=mids[0], domain="d", created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(), context={}, l0_tag="t", l1_label="l",
        l2_summary="s", l3_full="f", l4_raw="r", embedding=[0.1] * 384,
        embedding_model="m",
    ))
    result = await eng.prune_expired()
    assert result == 3
    assert lifecycle.on_memory_missed.call_count == 3


@pytest.mark.asyncio
async def test_merge_duplicates_passes_threshold(tmp_config: FractalConfig) -> None:
    """merge_duplicates() overrides similarity threshold and returns merge count."""
    storage = AsyncMock(spec=Storage)
    llm = AsyncMock(spec=LLMProvider)
    embeddings = AsyncMock(spec=EmbeddingProvider)
    associations = AsyncMock(spec=AssociationNetwork)
    scars = AsyncMock(spec=ScarTissueManager)
    lifecycle = AsyncMock(spec=LifecycleManager)
    domains = AsyncMock(spec=DomainManager)

    eng = ConsolidationEngine(
        storage=storage,
        embeddings=embeddings,
        llm=llm,
        associations=associations,
        scars=scars,
        lifecycle=lifecycle,
        domains=domains,
        config=tmp_config,
    )
    # No domains → no merges
    storage.list_domains.return_value = []
    result = await eng.merge_duplicates(similarity_threshold=0.85)
    assert result == 0
    # Verify threshold was restored
    assert eng._config.merge_similarity_threshold == tmp_config.merge_similarity_threshold


# ---------------------------------------------------------------------------
# Issue #13 — _current_session_id not initialized
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_consolidation_run_before_set_session_data_does_not_crash(
    tmp_config: FractalConfig,
) -> None:
    """run() before set_session_data() must not crash with AttributeError."""
    storage = AsyncMock(spec=Storage)
    llm = AsyncMock(spec=LLMProvider)
    embeddings = AsyncMock(spec=EmbeddingProvider)
    associations = AsyncMock(spec=AssociationNetwork)
    scars = AsyncMock(spec=ScarTissueManager)
    lifecycle = AsyncMock(spec=LifecycleManager)
    domains = AsyncMock(spec=DomainManager)

    eng = ConsolidationEngine(
        storage=storage,
        embeddings=embeddings,
        llm=llm,
        associations=associations,
        scars=scars,
        lifecycle=lifecycle,
        domains=domains,
        config=tmp_config,
    )
    # Do NOT call set_session_data — run() should handle _current_session_id = None
    storage.list_domains.return_value = []
    scars.expire_scars = AsyncMock(return_value=0)
    report = await eng.run()
    assert report.edges_strengthened == 0
    assert len(report.merges) == 0
