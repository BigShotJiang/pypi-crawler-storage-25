"""Tests for fractal_memory.folding — DimensionalFolder (Phase 3)."""

from __future__ import annotations

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.folding import (
    DimensionalFolder,
    _REGIME_ACTIVE,
    _ALL_SUBSYSTEMS,
)


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig()


@pytest.fixture
def folder(cfg: FractalConfig) -> DimensionalFolder:
    return DimensionalFolder(cfg)


# ---------------------------------------------------------------------------
# determine_regime — transitions
# ---------------------------------------------------------------------------


def test_initial_regime_is_bootstrap(folder: DimensionalFolder) -> None:
    assert folder.current_regime == "BOOTSTRAP"


def test_bootstrap_when_low_session_count(folder: DimensionalFolder) -> None:
    regime = folder.determine_regime(session_count=3, memory_count=200, morphogens_converged=True)
    assert regime == "BOOTSTRAP"


def test_bootstrap_when_low_memory_count(folder: DimensionalFolder) -> None:
    regime = folder.determine_regime(session_count=10, memory_count=10, morphogens_converged=True)
    assert regime == "BOOTSTRAP"


def test_learning_when_not_converged(folder: DimensionalFolder) -> None:
    regime = folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    assert regime == "LEARNING"


def test_mature_when_converged_and_enough_data(folder: DimensionalFolder) -> None:
    # Must be converged for 10+ consecutive sessions before MATURE
    for _ in range(10):
        folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=True)
    regime = folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=True)
    assert regime == "MATURE"


def test_regime_boundary_exactly_5_sessions_is_bootstrap(folder: DimensionalFolder) -> None:
    regime = folder.determine_regime(session_count=5, memory_count=100, morphogens_converged=True)
    assert regime == "BOOTSTRAP"


def test_regime_boundary_6_sessions_with_memory(folder: DimensionalFolder) -> None:
    regime = folder.determine_regime(session_count=6, memory_count=50, morphogens_converged=False)
    assert regime == "LEARNING"


def test_regime_transition_updates_active_subsystems(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    assert folder.active_subsystems == _REGIME_ACTIVE["LEARNING"]


def test_regime_change_replaces_active_set(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    assert "bandits" in folder.active_subsystems
    # Transition to MATURE — requires 10+ consecutive converged sessions
    for _ in range(11):
        folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=True)
    assert folder.current_regime == "MATURE"
    assert folder.active_subsystems == _REGIME_ACTIVE["MATURE"]


# ---------------------------------------------------------------------------
# is_active / get_folded_stat
# ---------------------------------------------------------------------------


def test_is_active_for_regime_subsystem(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    # In LEARNING, "bandits" should be active
    assert folder.is_active("bandits")


def test_is_not_active_for_foreign_subsystem(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    # "niche" is MATURE-only
    assert not folder.is_active("niche")


def test_get_folded_stat_returns_none_for_active(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    folder.update_folded_stats({"bandits": 0.7})
    # bandits is active → get_folded_stat returns None
    assert folder.get_folded_stat("bandits") is None


def test_get_folded_stat_returns_value_for_inactive(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    folder.update_folded_stats({"niche": 0.3})  # niche is inactive in LEARNING
    assert folder.get_folded_stat("niche") == pytest.approx(0.3)


def test_get_folded_stat_returns_none_when_no_data(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    assert folder.get_folded_stat("niche") is None


# ---------------------------------------------------------------------------
# update_folded_stats
# ---------------------------------------------------------------------------


def test_update_folded_stats_stores_values(folder: DimensionalFolder) -> None:
    folder.update_folded_stats({"niche": 0.5, "kalman": 0.8})
    assert folder._folded_stats["niche"] == pytest.approx(0.5)
    assert folder._folded_stats["kalman"] == pytest.approx(0.8)


def test_update_folded_stats_overwrites_previous(folder: DimensionalFolder) -> None:
    folder.update_folded_stats({"niche": 0.5})
    folder.update_folded_stats({"niche": 0.9})
    assert folder._folded_stats["niche"] == pytest.approx(0.9)


def test_update_adds_to_anomaly_history(folder: DimensionalFolder) -> None:
    folder.update_folded_stats({"niche": 0.5})
    assert len(folder._anomaly_history["niche"]) == 1


# ---------------------------------------------------------------------------
# check_forced_unfold
# ---------------------------------------------------------------------------


def test_forced_unfold_not_triggered_with_insufficient_history(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    # Only 2 historical values — not enough
    folder.update_folded_stats({"niche": 0.5})
    folder.update_folded_stats({"niche": 0.5})
    assert not folder.check_forced_unfold("niche", current_metric=5.0)


def test_forced_unfold_not_triggered_for_active_subsystem(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    assert not folder.check_forced_unfold("bandits", current_metric=100.0)


def test_forced_unfold_triggers_on_high_zscore(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    # Build up history of 0.5 ± small variance
    for _ in range(8):
        folder.update_folded_stats({"niche": 0.5})
    # Inject anomalous variance in history
    for _ in range(2):
        folder.update_folded_stats({"niche": 0.51})
    # Current metric far from mean (anomaly)
    triggered = folder.check_forced_unfold("niche", current_metric=10.0)
    assert triggered
    assert folder.is_active("niche")


def test_forced_unfold_adds_to_active(folder: DimensionalFolder) -> None:
    folder.determine_regime(session_count=10, memory_count=50, morphogens_converged=False)
    for _ in range(8):
        folder.update_folded_stats({"niche": 0.5})
    for _ in range(2):
        folder.update_folded_stats({"niche": 0.51})
    folder.check_forced_unfold("niche", current_metric=10.0)
    assert "niche" in folder._active_subsystems


# ---------------------------------------------------------------------------
# active_subsystems property
# ---------------------------------------------------------------------------


def test_active_subsystems_is_copy(folder: DimensionalFolder) -> None:
    active = folder.active_subsystems
    active.add("fake_system")
    assert "fake_system" not in folder._active_subsystems


def test_bootstrap_active_subsystems_correct() -> None:
    cfg = FractalConfig()
    folder = DimensionalFolder(cfg)
    assert folder.active_subsystems == _REGIME_ACTIVE["BOOTSTRAP"]
