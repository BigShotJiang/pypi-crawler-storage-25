"""Real embedding model tests — NO mocks.

Tests the actual all-MiniLM-L6-v2 sentence-transformer model to verify:
- Model loading and lazy initialization
- Correct dimensionality (384)
- Vector normalization (L2 norm ≈ 1.0)
- Semantic similarity (similar texts → high cosine, dissimilar → low)
- Batch vs single embedding consistency
- Empty/edge-case inputs
- Performance under load
"""

from __future__ import annotations

import asyncio
import time

import numpy as np
import pytest

from fractal_memory.embeddings import LocalEmbeddingProvider


@pytest.fixture(scope="module")
def provider() -> LocalEmbeddingProvider:
    """Single provider instance shared across the module (model loads once)."""
    return LocalEmbeddingProvider("all-MiniLM-L6-v2")


def _cosine(a: list[float], b: list[float]) -> float:
    va, vb = np.array(a), np.array(b)
    return float(np.dot(va, vb) / (np.linalg.norm(va) * np.linalg.norm(vb)))


# ── Model loading ──────────────────────────────────────────────────────

class TestModelLoading:
    @pytest.mark.asyncio
    async def test_model_loads_on_first_embed(self, provider: LocalEmbeddingProvider):
        assert provider._model is None  # lazy
        vec = await provider.embed("test")
        assert provider._model is not None
        assert len(vec) == 384

    def test_model_name_property(self, provider: LocalEmbeddingProvider):
        assert provider.model_name == "all-MiniLM-L6-v2"

    def test_dimension_property(self, provider: LocalEmbeddingProvider):
        assert provider.dimension == 384


# ── Normalization ──────────────────────────────────────────────────────

class TestNormalization:
    @pytest.mark.asyncio
    async def test_single_embed_is_unit_vector(self, provider: LocalEmbeddingProvider):
        vec = await provider.embed("The quick brown fox jumps over the lazy dog")
        norm = float(np.linalg.norm(vec))
        assert abs(norm - 1.0) < 1e-4

    @pytest.mark.asyncio
    async def test_batch_embed_all_unit_vectors(self, provider: LocalEmbeddingProvider):
        texts = [
            "Python is a programming language",
            "JavaScript runs in the browser",
            "Rust is memory safe",
            "Go has goroutines for concurrency",
            "TypeScript adds types to JavaScript",
        ]
        vecs = await provider.embed_batch(texts)
        assert len(vecs) == 5
        for vec in vecs:
            norm = float(np.linalg.norm(vec))
            assert abs(norm - 1.0) < 1e-4


# ── Determinism ────────────────────────────────────────────────────────

class TestDeterminism:
    @pytest.mark.asyncio
    async def test_same_text_same_embedding(self, provider: LocalEmbeddingProvider):
        text = "User prefers dark mode for all IDEs"
        v1 = await provider.embed(text)
        v2 = await provider.embed(text)
        assert _cosine(v1, v2) > 0.9999

    @pytest.mark.asyncio
    async def test_batch_matches_single(self, provider: LocalEmbeddingProvider):
        texts = ["hello world", "fractal memory system", "neural network"]
        batch_vecs = await provider.embed_batch(texts)
        for i, text in enumerate(texts):
            single_vec = await provider.embed(text)
            sim = _cosine(batch_vecs[i], single_vec)
            assert sim > 0.9999, f"Batch[{i}] vs single mismatch: {sim}"


# ── Semantic similarity ───────────────────────────────────────────────

class TestSemanticSimilarity:
    @pytest.mark.asyncio
    async def test_similar_texts_high_cosine(self, provider: LocalEmbeddingProvider):
        v1 = await provider.embed("Python is great for data science")
        v2 = await provider.embed("Python excels in data analysis and machine learning")
        sim = _cosine(v1, v2)
        assert sim > 0.5, f"Similar texts should have cosine > 0.5, got {sim}"

    @pytest.mark.asyncio
    async def test_dissimilar_texts_low_cosine(self, provider: LocalEmbeddingProvider):
        v1 = await provider.embed("I love eating spaghetti with tomato sauce")
        v2 = await provider.embed("Quantum computing uses qubits for parallel computation")
        sim = _cosine(v1, v2)
        assert sim < 0.4, f"Dissimilar texts should have cosine < 0.4, got {sim}"

    @pytest.mark.asyncio
    async def test_semantic_ranking_preserves_order(self, provider: LocalEmbeddingProvider):
        """Query should be closest to the most semantically relevant text."""
        query = await provider.embed("How do I deploy a web application?")
        texts = [
            "Deploying web apps to cloud servers with Docker",  # most relevant
            "Frontend JavaScript frameworks comparison",        # somewhat relevant
            "History of ancient Roman architecture",            # irrelevant
        ]
        vecs = await provider.embed_batch(texts)
        sims = [_cosine(query, v) for v in vecs]
        assert sims[0] > sims[1] > sims[2], f"Ranking broken: {sims}"

    @pytest.mark.asyncio
    async def test_correction_similarity(self, provider: LocalEmbeddingProvider):
        """A correction of a fact should have moderate similarity to the original."""
        original = await provider.embed("The project uses PostgreSQL for the database")
        correction = await provider.embed("The project uses SQLite, not PostgreSQL")
        sim = _cosine(original, correction)
        # Should be related but not identical
        assert 0.4 < sim < 0.95, f"Correction similarity should be moderate, got {sim}"


# ── Edge cases ─────────────────────────────────────────────────────────

class TestEdgeCases:
    @pytest.mark.asyncio
    async def test_very_short_text(self, provider: LocalEmbeddingProvider):
        vec = await provider.embed("a")
        assert len(vec) == 384
        norm = float(np.linalg.norm(vec))
        assert abs(norm - 1.0) < 1e-4

    @pytest.mark.asyncio
    async def test_very_long_text(self, provider: LocalEmbeddingProvider):
        text = "word " * 2000  # ~10K chars
        vec = await provider.embed(text)
        assert len(vec) == 384
        norm = float(np.linalg.norm(vec))
        assert abs(norm - 1.0) < 1e-4

    @pytest.mark.asyncio
    async def test_unicode_text(self, provider: LocalEmbeddingProvider):
        vec = await provider.embed("日本語のテスト文章です。Unicode処理を確認します。")
        assert len(vec) == 384

    @pytest.mark.asyncio
    async def test_empty_string_does_not_crash(self, provider: LocalEmbeddingProvider):
        vec = await provider.embed("")
        assert len(vec) == 384

    @pytest.mark.asyncio
    async def test_special_characters(self, provider: LocalEmbeddingProvider):
        vec = await provider.embed("!@#$%^&*()_+-=[]{}|;':\",./<>?`~")
        assert len(vec) == 384

    @pytest.mark.asyncio
    async def test_batch_single_item(self, provider: LocalEmbeddingProvider):
        vecs = await provider.embed_batch(["hello"])
        assert len(vecs) == 1
        assert len(vecs[0]) == 384

    @pytest.mark.asyncio
    async def test_batch_empty_list(self, provider: LocalEmbeddingProvider):
        vecs = await provider.embed_batch([])
        assert len(vecs) == 0


# ── Performance ────────────────────────────────────────────────────────

class TestEmbeddingPerformance:
    @pytest.mark.asyncio
    async def test_single_embed_latency(self, provider: LocalEmbeddingProvider):
        """Single embedding should complete in under 500ms (warm model)."""
        # Warm up
        await provider.embed("warmup text")

        start = time.perf_counter()
        await provider.embed("Measure the latency of a single embedding call")
        elapsed = time.perf_counter() - start
        assert elapsed < 0.5, f"Single embed took {elapsed:.3f}s (should be < 0.5s)"

    @pytest.mark.asyncio
    async def test_batch_100_embeddings(self, provider: LocalEmbeddingProvider):
        """100 embeddings in batch should complete in under 10s."""
        texts = [f"Test sentence number {i} about topic {i % 10}" for i in range(100)]
        start = time.perf_counter()
        vecs = await provider.embed_batch(texts)
        elapsed = time.perf_counter() - start
        assert len(vecs) == 100
        assert elapsed < 10.0, f"Batch 100 took {elapsed:.3f}s (should be < 10s)"

    @pytest.mark.asyncio
    async def test_concurrent_embeds(self, provider: LocalEmbeddingProvider):
        """10 concurrent embed calls should all succeed."""
        texts = [f"Concurrent embed test {i}" for i in range(10)]
        tasks = [provider.embed(t) for t in texts]
        results = await asyncio.gather(*tasks)
        assert len(results) == 10
        for vec in results:
            assert len(vec) == 384
