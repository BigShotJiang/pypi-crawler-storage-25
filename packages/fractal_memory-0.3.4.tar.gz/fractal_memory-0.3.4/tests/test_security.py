"""Security tests for input validation, file permissions, and degraded mode."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig


async def test_store_rejects_empty_text(fractal_memory: FractalMemory):
    """store() rejects empty or whitespace-only text."""
    with pytest.raises(ValueError, match="must not be empty"):
        await fractal_memory.store("", domain="test")

    with pytest.raises(ValueError, match="must not be empty"):
        await fractal_memory.store("   ", domain="test")


async def test_store_rejects_oversized_text(fractal_memory: FractalMemory):
    """store() rejects text exceeding max_text_length."""
    huge = "x" * 60_000  # default max is 50_000
    with pytest.raises(ValueError, match="exceeds max length"):
        await fractal_memory.store(huge, domain="test")


async def test_retrieve_rejects_empty_query(fractal_memory: FractalMemory):
    """retrieve() rejects empty query."""
    with pytest.raises(ValueError, match="must not be empty"):
        await fractal_memory.retrieve("", domain="test")


async def test_retrieve_rejects_oversized_query(fractal_memory: FractalMemory):
    """retrieve() rejects query exceeding max_query_length."""
    huge = "q" * 15_000  # default max is 10_000
    with pytest.raises(ValueError, match="exceeds max length"):
        await fractal_memory.retrieve(huge, domain="test")


async def test_store_rejects_invalid_domain_chars(fractal_memory: FractalMemory):
    """store() rejects domain names with invalid characters."""
    with pytest.raises(ValueError, match="Invalid domain name"):
        await fractal_memory.store("hello", domain="my domain")  # space

    with pytest.raises(ValueError, match="Invalid domain name"):
        await fractal_memory.store("hello", domain="bad/domain")  # slash

    with pytest.raises(ValueError, match="Invalid domain name"):
        await fractal_memory.store("hello", domain="bad;domain")  # semicolon


async def test_store_rejects_oversized_domain(fractal_memory: FractalMemory):
    """store() rejects domain names exceeding max length."""
    long_domain = "a" * 150  # default max is 100
    with pytest.raises(ValueError, match="exceeds max length"):
        await fractal_memory.store("hello", domain=long_domain)


async def test_store_accepts_valid_domains(fractal_memory: FractalMemory):
    """store() accepts well-formed domain names."""
    await fractal_memory.session_start("my-project")
    # These should all work without raising
    for domain in ["test", "my-project", "v2.0", "foo_bar", "ABC123"]:
        result = await fractal_memory.store("hello", domain=domain)
        # result may be None (gated) or a Memory, but no exception
    await fractal_memory.session_end()


async def test_session_start_validates_domain(fractal_memory: FractalMemory):
    """session_start() validates domain name."""
    with pytest.raises(ValueError, match="Invalid domain name"):
        await fractal_memory.session_start("bad domain!")


async def test_sqlite_file_permissions(tmp_path):
    """Database file is created with user-only (0600) permissions."""
    db_path = tmp_path / "perm_test.db"
    config = FractalConfig(db_path=db_path, gate_signal_count=1)
    from fractal_memory.storage import Storage

    storage = Storage(config)
    await storage.initialize()
    try:
        assert db_path.exists()
        mode = stat.S_IMODE(os.stat(db_path).st_mode)
        assert mode == 0o600, f"Expected 0600, got {oct(mode)}"
    finally:
        await storage.close()


async def test_store_special_characters_safe(fractal_memory: FractalMemory):
    """store() handles special characters without SQL injection."""
    await fractal_memory.session_start("test")
    malicious = "Robert'); DROP TABLE memories; --"
    mem = await fractal_memory.store(malicious, domain="test")
    # In pioneer mode (gate_signal_count=1), EXPLICIT_STORE passes the gate
    assert mem is not None, "Memory should be stored in pioneer mode"
    assert mem.l4_raw == malicious, "Raw text must be preserved verbatim"
    # Verify the memories table still exists and is intact
    fetched = await fractal_memory.get(mem.id)
    assert fetched is not None, "Memory must be retrievable after SQL injection attempt"
    assert fetched.l4_raw == malicious
    await fractal_memory.session_end()


async def test_retrieve_special_characters_safe(fractal_memory: FractalMemory):
    """retrieve() handles special characters without SQL injection."""
    await fractal_memory.session_start("test")
    await fractal_memory.store("hello world", domain="test")
    # SQL injection attempt via query
    result = await fractal_memory.retrieve(
        "Robert'); DROP TABLE memories; --",
        domain="test",
    )
    # Should return results normally, no crash
    assert result is not None
    await fractal_memory.session_end()
