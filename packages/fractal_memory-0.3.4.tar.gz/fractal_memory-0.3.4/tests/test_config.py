"""Tests for configuration system."""

import os
from pathlib import Path

import pytest

from fractal_memory.config import FractalConfig, load_config


def test_default_config():
    cfg = FractalConfig()
    assert cfg.db_path == Path("~/.fractal_memory/memory.db")
    assert cfg.embedding_model == "all-MiniLM-L6-v2"
    assert cfg.embedding_dim == 384
    assert cfg.llm_provider == "bridge"
    assert cfg.gate_signal_count == 1  # default: works out of the box with single signal
    assert cfg.top_l1 == 200
    assert cfg.top_l2 == 50
    assert cfg.top_l3 == 10


def test_memory_token_budget():
    cfg = FractalConfig()
    expected = int(200_000 * 0.15)
    assert cfg.memory_token_budget == expected


def test_memory_token_budget_custom():
    cfg = FractalConfig(context_window_tokens=100_000, memory_token_budget_pct=0.20)
    assert cfg.memory_token_budget == 20_000


def test_load_config_pioneer_default(tmp_path: Path):
    cfg = load_config(path=tmp_path / "nonexistent.toml", pioneer=True)
    assert cfg.gate_signal_count == 1


def test_load_config_no_pioneer(tmp_path: Path):
    cfg = load_config(path=tmp_path / "nonexistent.toml", pioneer=False)
    assert cfg.gate_signal_count == 1  # default is now 1; pioneer=False just skips override


def test_load_config_from_toml(tmp_path: Path):
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('embedding_model = "custom-model"\ntop_l3 = 5\n')
    cfg = load_config(path=toml_file)
    assert cfg.embedding_model == "custom-model"
    assert cfg.top_l3 == 5


def test_load_config_env_overrides(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("FRACTAL_LLM_PROVIDER", "ollama")
    monkeypatch.setenv("FRACTAL_LLM_MODEL", "llama3")
    cfg = load_config(path=tmp_path / "nonexistent.toml")
    assert cfg.llm_provider == "ollama"
    assert cfg.llm_model == "llama3"


def test_load_config_env_db_path(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("FRACTAL_DB_PATH", str(tmp_path / "custom.db"))
    cfg = load_config(path=tmp_path / "nonexistent.toml")
    assert cfg.db_path == tmp_path / "custom.db"


def test_frozen_config():
    cfg = FractalConfig()
    try:
        cfg.embedding_model = "other"  # type: ignore
        assert False, "Should have raised"
    except AttributeError:
        pass


# ---------------------------------------------------------------------------
# Issue #21 / #22 / #23: Config validation
# ---------------------------------------------------------------------------


def test_config_default_passes_validation():
    """Issue #21: Default FractalConfig passes all validation."""
    cfg = FractalConfig()
    assert cfg.gate_signal_count == 1


def test_config_rejects_gate_signal_count_below_min():
    """Issue #21: gate_signal_count=0 is rejected."""
    with pytest.raises(ValueError, match="gate_signal_count"):
        FractalConfig(gate_signal_count=0)


def test_config_rejects_gate_signal_count_above_max():
    """Issue #21: gate_signal_count=6 is rejected."""
    with pytest.raises(ValueError, match="gate_signal_count"):
        FractalConfig(gate_signal_count=6)


def test_config_rejects_zero_flush_interval():
    """Issue #23: activity_flush_interval=0 causes ZeroDivisionError, so rejected."""
    with pytest.raises(ValueError):
        FractalConfig(activity_flush_interval=0)


def test_config_rejects_negative_top_l1():
    """Issue #21: top_l1=-1 is rejected."""
    with pytest.raises(ValueError):
        FractalConfig(top_l1=-1)


def test_config_accepts_boundary_values():
    """Issue #21: Boundary values are accepted."""
    cfg1 = FractalConfig(gate_signal_count=1)
    assert cfg1.gate_signal_count == 1
    cfg5 = FractalConfig(gate_signal_count=5)
    assert cfg5.gate_signal_count == 5


def test_config_rejects_weights_summing_to_0_6():
    """Issue #22: Weights summing to 0.6 are rejected."""
    with pytest.raises(ValueError, match="sum to 1.0"):
        FractalConfig(scoring_cosine_weight=0.5, scoring_intensity_weight=0.1)


def test_config_accepts_weights_summing_to_1_0():
    """Issue #22: Weights summing to 1.0 are accepted."""
    cfg = FractalConfig(scoring_cosine_weight=0.7, scoring_intensity_weight=0.3)
    assert abs(cfg.scoring_cosine_weight + cfg.scoring_intensity_weight - 1.0) < 0.01


def test_config_rejects_cosine_weight_below_range():
    """Issue #22: scoring_cosine_weight below 0.5 is rejected."""
    with pytest.raises(ValueError, match="scoring_cosine_weight"):
        FractalConfig(scoring_cosine_weight=0.4, scoring_intensity_weight=0.6)


def test_config_accepts_weights_at_tolerance_boundary():
    """Issue #22: Boundary check for weight sum tolerance."""
    cfg = FractalConfig(scoring_cosine_weight=0.505, scoring_intensity_weight=0.495)
    assert cfg is not None  # sum = 1.0 exactly, passes
