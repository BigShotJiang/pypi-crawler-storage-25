"""Tests for the diagnostic dashboard — routes, API shape, and template rendering.

Each test verifies observable behavior (HTTP status, response structure, HTML markers)
per TEST_REQUIREMENTS.md: type-specific assertions, no "no exception" checks, deterministic.
"""

from __future__ import annotations

import uuid
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from fractal_memory.dashboard.app import DashboardApp, create_dashboard


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_memory(
    memory_id: uuid.UUID | None = None,
    domain: str = "default",
    lifecycle: str = "confirmed",
    l1_label: str = "Test label",
    l2_summary: str = "Test summary",
    l3_full: str = "Test full detail",
    intensity: float = 0.8,
    retrieval_count: int = 3,
) -> MagicMock:
    """Build a MagicMock that looks like a Memory dataclass."""
    m = MagicMock()
    m.id = memory_id or uuid.uuid4()
    m.domain = domain
    m.l0_tag = "test:tag"
    m.l1_label = l1_label
    m.l2_summary = l2_summary
    m.l3_full = l3_full
    m.lifecycle = lifecycle
    m.intensity = intensity
    m.retrieval_count = retrieval_count
    m.chronic_score = 0.5
    m.created_at = MagicMock()
    m.created_at.isoformat.return_value = "2024-01-01T00:00:00"
    m.created_at.strftime.return_value = "2024-01-01 00:00"
    m.updated_at = MagicMock()
    m.updated_at.isoformat.return_value = "2024-01-02T00:00:00"
    return m


def _make_domain_stats(
    name: str = "default",
    memory_count: int = 5,
    session_count: int = 2,
    avg_internal_edge_weight: float = 0.4,
    edge_count: int = 3,
) -> MagicMock:
    ds = MagicMock()
    ds.name = name
    ds.memory_count = memory_count
    ds.session_count = session_count
    ds.avg_internal_edge_weight = avg_internal_edge_weight
    ds.edge_count = edge_count
    return ds


def _build_fractal_memory_mock(
    memories: list[Any] | None = None,
    domain_stats: list[Any] | None = None,
    associations: list[tuple] | None = None,
    lifecycle_counts: dict[str, int] | None = None,
    stats: dict | None = None,
) -> MagicMock:
    """Build a MagicMock mimicking the FractalMemory public API."""
    fm = MagicMock()

    _memories = memories or []
    _domain_stats = domain_stats or []
    _associations = associations or []
    _lifecycle_counts = lifecycle_counts or {"probation": 2, "confirmed": 5, "permanent": 1, "safety_critical": 0}
    _stats = stats or {
        "overall": {"total_memories": 8, "total_sessions": 3},
        "associations": {"edge_count": 4, "avg_weight": 0.35},
        "lifecycle": {"confirmed": 5, "probation": 2, "permanent": 1, "safety_critical": 0},
        "current_session": {"stores": 2, "retrievals": 3},
        "scars": {"active_count": 1},
        "domains": [{"name": "default"}],
    }

    # Config
    fm._config = MagicMock()
    fm._config.memory_token_budget = 100
    fm._config.gate_signal_count = 2
    fm._config.top_l1 = 200
    fm._config.top_l2 = 50
    fm._config.top_l3 = 10

    # Storage
    fm._storage = MagicMock()
    fm._storage.get_memories_by_domain = AsyncMock(return_value=_memories)
    fm._storage.get_all_associations = AsyncMock(return_value=_associations)
    fm._storage.get_lifecycle_counts = AsyncMock(return_value=_lifecycle_counts)
    fm._storage._conn = None  # disable waiting_room SQL fallback
    fm._storage.get_all_active_session_activity = AsyncMock(return_value=[
        {"domain": "default", "stores": 2, "retrievals": 3},
    ])
    fm._storage.get_session_summaries = AsyncMock(return_value=[])

    # Associations
    fm._associations = MagicMock()
    fm._associations.get_edges = AsyncMock(return_value=[])

    # Domain manager
    fm._domain_manager = MagicMock()
    fm._domain_manager.list_domains_with_stats = AsyncMock(return_value=_domain_stats)

    # Public API
    fm.get = AsyncMock(return_value=None)
    fm.get_stats = AsyncMock(return_value=_stats)

    return fm


@pytest.fixture
def client() -> TestClient:
    """TestClient backed by a DashboardApp with a fully mocked FractalMemory."""
    fm = _build_fractal_memory_mock(
        domain_stats=[_make_domain_stats("default"), _make_domain_stats("work", memory_count=3)],
    )
    app = DashboardApp(fm).create_app()
    return TestClient(app)


@pytest.fixture
def client_with_memories() -> tuple[TestClient, uuid.UUID]:
    """TestClient with one real-looking memory available."""
    mem_id = uuid.uuid4()
    memory = _make_mock_memory(memory_id=mem_id, domain="default")
    fm = _build_fractal_memory_mock(
        memories=[memory],
        domain_stats=[_make_domain_stats("default", memory_count=1)],
        associations=[(mem_id, uuid.uuid4(), 0.7)],
    )
    fm.get = AsyncMock(return_value=memory)
    fm._associations.get_edges = AsyncMock(return_value=[(uuid.uuid4(), 0.55)])
    app = DashboardApp(fm).create_app()
    return TestClient(app), mem_id


# ---------------------------------------------------------------------------
# HTML page routes
# ---------------------------------------------------------------------------

class TestPageRoutes:
    """Verify all HTML page routes return 200 with expected HTML markers."""

    def test_home_returns_200_with_html(self, client: TestClient) -> None:
        """GET / returns 200 HTML containing Domain Organs heading."""
        response = client.get("/")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Domain Organs" in response.text

    def test_home_contains_vitals_panel(self, client: TestClient) -> None:
        """GET / renders vitals-panel and organ-grid elements."""
        response = client.get("/")
        assert "vitals-panel" in response.text
        assert "organ-grid" in response.text

    def test_brain_returns_200_with_html(self, client: TestClient) -> None:
        """GET /brain returns 200 HTML containing Neural Network heading."""
        response = client.get("/brain")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Neural Network" in response.text

    def test_brain_contains_svg_and_d3_init(self, client: TestClient) -> None:
        """GET /brain renders brain-svg element and D3.js initialization."""
        response = client.get("/brain")
        assert "brain-svg" in response.text
        # D3.js force simulation init is in the script block
        assert "forceSimulation" in response.text or "d3.select" in response.text

    def test_lifecycle_returns_200_with_html(self, client: TestClient) -> None:
        """GET /lifecycle returns 200 HTML containing Lifecycle Chrysalis heading."""
        response = client.get("/lifecycle")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Lifecycle Chrysalis" in response.text

    def test_lifecycle_contains_chart_canvas(self, client: TestClient) -> None:
        """GET /lifecycle renders the lifecycle-chart canvas for Chart.js."""
        response = client.get("/lifecycle")
        assert "lifecycle-chart" in response.text

    def test_pipeline_returns_200_with_html(self, client: TestClient) -> None:
        """GET /pipeline returns 200 HTML containing Digestive Tract heading."""
        response = client.get("/pipeline")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Processing Pipeline" in response.text

    def test_pipeline_contains_stage_elements(self, client: TestClient) -> None:
        """GET /pipeline renders pipeline stage elements."""
        response = client.get("/pipeline")
        assert "Coincidence Gate" in response.text
        assert "Waiting Room" in response.text
        assert "Storage" in response.text

    def test_domain_detail_returns_200_with_memories(
        self, client_with_memories: tuple[TestClient, uuid.UUID]
    ) -> None:
        """GET /domain/default renders domain detail with memory table."""
        client, _ = client_with_memories
        response = client.get("/domain/default")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "default" in response.text

    def test_domain_detail_invalid_name_returns_400(self, client: TestClient) -> None:
        """GET /domain/<invalid> returns 400 for unsafe domain names."""
        response = client.get("/domain/" + "a" * 200)
        assert response.status_code == 400

    def test_memory_detail_returns_200_with_zoom_levels(
        self, client_with_memories: tuple[TestClient, uuid.UUID]
    ) -> None:
        """GET /memory/{id} renders memory detail with zoom level cards."""
        client, mem_id = client_with_memories
        response = client.get(f"/memory/{mem_id}")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "L1" in response.text
        assert "L2" in response.text

    def test_memory_detail_not_found_returns_404(self, client: TestClient) -> None:
        """GET /memory/{unknown_id} returns 404 when memory does not exist."""
        missing_id = uuid.uuid4()
        response = client.get(f"/memory/{missing_id}")
        assert response.status_code == 404

    def test_memory_detail_invalid_uuid_returns_400(self, client: TestClient) -> None:
        """GET /memory/not-a-uuid returns 400."""
        response = client.get("/memory/not-a-uuid")
        assert response.status_code == 400

    def test_nav_links_present_on_all_pages(self, client: TestClient) -> None:
        """Every HTML page contains the top navigation links."""
        for path in ("/", "/brain", "/lifecycle", "/pipeline"):
            response = client.get(path)
            assert "Neural Network" in response.text, f"Missing nav on {path}"
            assert "Lifecycle" in response.text, f"Missing nav on {path}"
            assert "Pipeline" in response.text, f"Missing nav on {path}"


# ---------------------------------------------------------------------------
# JSON API — /api/vitals
# ---------------------------------------------------------------------------

class TestApiVitals:
    """Verify /api/vitals returns correct shape and values."""

    def test_vitals_returns_200_json(self, client: TestClient) -> None:
        """GET /api/vitals returns 200 with application/json content-type."""
        response = client.get("/api/vitals")
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]

    def test_vitals_contains_required_keys(self, client: TestClient) -> None:
        """GET /api/vitals returns heart_rate, pressure, temperature, total_memories."""
        data = client.get("/api/vitals").json()
        for key in ("heart_rate", "pressure", "temperature", "total_memories", "total_sessions"):
            assert key in data, f"Missing key: {key}"

    def test_vitals_heart_rate_is_sum_of_session_ops(self, client: TestClient) -> None:
        """heart_rate equals stores + retrievals from current session stats."""
        # mock returns stores=2, retrievals=3
        data = client.get("/api/vitals").json()
        assert data["heart_rate"] == 5

    def test_vitals_pressure_is_percentage(self, client: TestClient) -> None:
        """pressure is a float between 0 and 100 representing memory budget usage."""
        data = client.get("/api/vitals").json()
        assert isinstance(data["pressure"], (int, float))
        assert 0 <= data["pressure"] <= 100

    def test_vitals_domains_is_list_of_strings(self, client: TestClient) -> None:
        """domains field is a list of domain name strings."""
        data = client.get("/api/vitals").json()
        assert isinstance(data["domains"], list)
        assert all(isinstance(d, str) for d in data["domains"])

    def test_vitals_total_memories_matches_stats(self, client: TestClient) -> None:
        """total_memories in vitals matches overall.total_memories from get_stats()."""
        data = client.get("/api/vitals").json()
        assert data["total_memories"] == 8  # matches mock stats


# ---------------------------------------------------------------------------
# JSON API — /api/associations/{domain}
# ---------------------------------------------------------------------------

class TestApiAssociations:
    """Verify /api/associations/{domain} returns nodes + edges structure for D3.js."""

    def test_associations_returns_200_json(self, client: TestClient) -> None:
        """GET /api/associations/default returns 200 JSON."""
        response = client.get("/api/associations/default")
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]

    def test_associations_has_nodes_and_edges_keys(self, client: TestClient) -> None:
        """Response contains both 'nodes' and 'edges' top-level keys."""
        data = client.get("/api/associations/default").json()
        assert "nodes" in data
        assert "edges" in data

    def test_associations_nodes_shape(
        self, client_with_memories: tuple[TestClient, uuid.UUID]
    ) -> None:
        """Each node has id, label, lifecycle, intensity, retrieval_count, x, y."""
        client, _ = client_with_memories
        data = client.get("/api/associations/default").json()
        assert len(data["nodes"]) == 1
        node = data["nodes"][0]
        for field in ("id", "label", "lifecycle", "intensity", "retrieval_count", "x", "y"):
            assert field in node, f"Missing node field: {field}"

    def test_associations_edges_shape(
        self, client_with_memories: tuple[TestClient, uuid.UUID]
    ) -> None:
        """Each edge has source, target, weight."""
        # Build a client where two memories share an edge
        mem_a = _make_mock_memory(domain="default", l1_label="A")
        mem_b = _make_mock_memory(domain="default", l1_label="B")
        assoc = [(mem_a.id, mem_b.id, 0.65)]
        fm = _build_fractal_memory_mock(
            memories=[mem_a, mem_b],
            associations=assoc,
        )
        app = DashboardApp(fm).create_app()
        c = TestClient(app)
        data = c.get("/api/associations/default").json()
        assert len(data["edges"]) == 1
        edge = data["edges"][0]
        assert "source" in edge
        assert "target" in edge
        assert "weight" in edge
        assert 0.0 <= edge["weight"] <= 1.0

    def test_associations_empty_domain_returns_empty_graph(self, client: TestClient) -> None:
        """Domain with no memories returns nodes=[] and edges=[]."""
        data = client.get("/api/associations/default").json()
        # Default client has no memories
        assert data["nodes"] == []
        assert data["edges"] == []

    def test_associations_invalid_domain_returns_400(self, client: TestClient) -> None:
        """Invalid domain name returns 400."""
        response = client.get("/api/associations/" + "x" * 200)
        assert response.status_code == 400

    def test_associations_edges_only_within_domain(
        self, client_with_memories: tuple[TestClient, uuid.UUID]
    ) -> None:
        """Edges between memories from different domains are excluded from graph."""
        mem_in = _make_mock_memory(domain="default")
        mem_out = _make_mock_memory(domain="work")
        # Edge crosses domains — should be excluded
        cross_edge = [(mem_in.id, mem_out.id, 0.9)]
        fm = _build_fractal_memory_mock(
            memories=[mem_in],  # only mem_in is in "default"
            associations=cross_edge,
        )
        app = DashboardApp(fm).create_app()
        c = TestClient(app)
        data = c.get("/api/associations/default").json()
        assert data["edges"] == []


# ---------------------------------------------------------------------------
# JSON API — /api/lifecycle-distribution
# ---------------------------------------------------------------------------

class TestApiLifecycleDistribution:
    """Verify /api/lifecycle-distribution returns correct counts and rates."""

    def test_lifecycle_returns_200_json(self, client: TestClient) -> None:
        """GET /api/lifecycle-distribution returns 200 JSON."""
        response = client.get("/api/lifecycle-distribution")
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]

    def test_lifecycle_contains_all_status_keys(self, client: TestClient) -> None:
        """Response has probation, confirmed, permanent, safety_critical, total."""
        data = client.get("/api/lifecycle-distribution").json()
        for key in ("probation", "confirmed", "permanent", "safety_critical", "total", "promotion_rate", "pruning_rate"):
            assert key in data, f"Missing key: {key}"

    def test_lifecycle_counts_match_storage_values(self, client: TestClient) -> None:
        """Counts match what get_lifecycle_counts() returns."""
        # Mock returns: probation=2, confirmed=5, permanent=1, safety_critical=0
        data = client.get("/api/lifecycle-distribution").json()
        assert data["probation"] == 2
        assert data["confirmed"] == 5
        assert data["permanent"] == 1
        assert data["safety_critical"] == 0

    def test_lifecycle_total_is_sum_of_counts(self, client: TestClient) -> None:
        """total equals sum of all lifecycle counts."""
        data = client.get("/api/lifecycle-distribution").json()
        expected_total = data["probation"] + data["confirmed"] + data["permanent"] + data["safety_critical"]
        assert data["total"] == expected_total

    def test_lifecycle_promotion_rate_is_percentage(self, client: TestClient) -> None:
        """promotion_rate is a float 0-100."""
        data = client.get("/api/lifecycle-distribution").json()
        assert isinstance(data["promotion_rate"], float)
        assert 0.0 <= data["promotion_rate"] <= 100.0

    def test_lifecycle_promotion_rate_calculation(self, client: TestClient) -> None:
        """promotion_rate = (confirmed + permanent) / total * 100."""
        # 5 confirmed + 1 permanent = 6 out of 8 total = 75.0%
        data = client.get("/api/lifecycle-distribution").json()
        assert data["promotion_rate"] == 75.0


# ---------------------------------------------------------------------------
# JSON API — /api/pipeline-stats
# ---------------------------------------------------------------------------

class TestApiPipelineStats:
    """Verify /api/pipeline-stats returns gate configuration and waiting room size."""

    def test_pipeline_returns_200_json(self, client: TestClient) -> None:
        """GET /api/pipeline-stats returns 200 JSON."""
        response = client.get("/api/pipeline-stats")
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]

    def test_pipeline_contains_required_keys(self, client: TestClient) -> None:
        """Response contains waiting_room_size, gate_signal_count, top_l1/l2/l3."""
        data = client.get("/api/pipeline-stats").json()
        for key in ("waiting_room_size", "gate_signal_count", "top_l1", "top_l2", "top_l3"):
            assert key in data, f"Missing key: {key}"

    def test_pipeline_gate_signal_count_matches_config(self, client: TestClient) -> None:
        """gate_signal_count reflects the config value."""
        data = client.get("/api/pipeline-stats").json()
        assert data["gate_signal_count"] == 2  # matches mock config

    def test_pipeline_injection_levels_correct(self, client: TestClient) -> None:
        """top_l1=200, top_l2=50, top_l3=10 matches mock config."""
        data = client.get("/api/pipeline-stats").json()
        assert data["top_l1"] == 200
        assert data["top_l2"] == 50
        assert data["top_l3"] == 10

    def test_pipeline_waiting_room_defaults_to_zero_without_db(self, client: TestClient) -> None:
        """waiting_room_size is 0 when storage connection is unavailable."""
        data = client.get("/api/pipeline-stats").json()
        assert data["waiting_room_size"] == 0


# ---------------------------------------------------------------------------
# JSON API — /api/domain-health
# ---------------------------------------------------------------------------

class TestApiDomainHealth:
    """Verify /api/domain-health returns per-domain health metrics."""

    def test_domain_health_returns_200_json(self, client: TestClient) -> None:
        """GET /api/domain-health returns 200 JSON."""
        response = client.get("/api/domain-health")
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]

    def test_domain_health_has_domains_list(self, client: TestClient) -> None:
        """Response contains top-level 'domains' list."""
        data = client.get("/api/domain-health").json()
        assert "domains" in data
        assert isinstance(data["domains"], list)

    def test_domain_health_each_domain_has_required_fields(self, client: TestClient) -> None:
        """Each domain entry has name, memory_count, session_count, edge_count, avg_internal_edge_weight."""
        data = client.get("/api/domain-health").json()
        assert len(data["domains"]) == 2  # default + work from fixture
        for domain in data["domains"]:
            for field in ("name", "memory_count", "session_count", "edge_count", "avg_internal_edge_weight"):
                assert field in domain, f"Missing field {field!r} in domain {domain.get('name')}"

    def test_domain_health_memory_count_is_int(self, client: TestClient) -> None:
        """memory_count is an integer for all domains."""
        data = client.get("/api/domain-health").json()
        for domain in data["domains"]:
            assert isinstance(domain["memory_count"], int)

    def test_domain_health_avg_edge_weight_is_float(self, client: TestClient) -> None:
        """avg_internal_edge_weight is a float between 0 and 1."""
        data = client.get("/api/domain-health").json()
        for domain in data["domains"]:
            w = domain["avg_internal_edge_weight"]
            assert isinstance(w, float)
            assert 0.0 <= w <= 1.0


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------

class TestCreateDashboard:
    """Verify create_dashboard factory returns a configured FastAPI app."""

    def test_create_dashboard_returns_fastapi_app(self) -> None:
        """create_dashboard() returns a FastAPI instance."""
        from fastapi import FastAPI

        fm = _build_fractal_memory_mock()
        app = create_dashboard(fm)
        assert isinstance(app, FastAPI)

    def test_create_dashboard_app_has_home_route(self) -> None:
        """The app created by the factory responds to GET /."""
        fm = _build_fractal_memory_mock()
        app = create_dashboard(fm)
        c = TestClient(app)
        response = c.get("/")
        assert response.status_code == 200
