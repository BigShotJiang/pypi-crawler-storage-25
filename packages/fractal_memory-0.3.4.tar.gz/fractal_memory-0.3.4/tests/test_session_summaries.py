"""Tests for Option 12 — session_summaries table + session_end hook.

Verifies:
- session_summaries table is created by storage.initialize() (idempotent).
- session_summaries table is created by _migrate_phase2_schema() for Phase 1 DBs.
- record_session_summary writes exact values and is idempotent (INSERT OR REPLACE).
- get_session_summaries returns rows newest-first, respects limit parameter.
- session_end() writes a summary row with correct store/retrieve counts and timestamps.
- Empty database returns empty list from get_session_summaries.
- Failure in record_session_summary is non-fatal (session_end still returns summary).
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ---------------------------------------------------------------------------
# Storage: table creation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_summaries_table_created_on_initialize(tmp_path: Path):
    """session_summaries table exists after Storage.initialize()."""
    config = FractalConfig(db_path=tmp_path / "m.db", gate_signal_count=1)
    storage = Storage(config)
    await storage.initialize()

    import aiosqlite
    async with aiosqlite.connect(str(config.db_path)) as conn:
        async with conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='session_summaries'"
        ) as cur:
            row = await cur.fetchone()
    await storage.close()

    assert row is not None, "session_summaries table must be created by initialize()"


@pytest.mark.asyncio
async def test_session_summaries_index_created(tmp_path: Path):
    """idx_session_summaries_ended_at index exists for query performance."""
    config = FractalConfig(db_path=tmp_path / "m.db", gate_signal_count=1)
    storage = Storage(config)
    await storage.initialize()

    import aiosqlite
    async with aiosqlite.connect(str(config.db_path)) as conn:
        async with conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' "
            "AND name='idx_session_summaries_ended_at'"
        ) as cur:
            row = await cur.fetchone()
    await storage.close()

    assert row is not None, "ended_at index must be created (required for timeline queries)"


@pytest.mark.asyncio
async def test_initialize_idempotent_does_not_fail_on_existing_table(tmp_path: Path):
    """Calling initialize() twice does not raise (CREATE TABLE IF NOT EXISTS)."""
    config = FractalConfig(db_path=tmp_path / "m.db", gate_signal_count=1)
    storage = Storage(config)
    await storage.initialize()
    await storage.close()

    # Second open/init must not fail
    storage2 = Storage(config)
    await storage2.initialize()
    await storage2.close()


# ---------------------------------------------------------------------------
# Storage: record_session_summary
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_record_session_summary_writes_exact_values(storage: Storage):
    """record_session_summary persists all fields with exact values."""
    sid = uuid4()
    started = datetime(2024, 1, 15, 10, 0, 0)
    ended = datetime(2024, 1, 15, 11, 30, 0)

    await storage.record_session_summary(
        session_id=sid,
        started_at=started,
        ended_at=ended,
        store_count=7,
        retrieve_count=12,
        scar_count=2,
        merge_count=1,
        edge_count=45,
    )

    rows = await storage.get_session_summaries(limit=10)
    assert len(rows) == 1
    row = rows[0]
    assert row["session_id"] == str(sid)
    assert row["store_count"] == 7
    assert row["retrieve_count"] == 12
    assert row["scar_count"] == 2
    assert row["merge_count"] == 1
    assert row["edge_count"] == 45


@pytest.mark.asyncio
async def test_record_session_summary_defaults_phase2_fields_to_zero(storage: Storage):
    """scar_count, merge_count, edge_count default to 0 (Phase 1 sessions have no Phase 2 data)."""
    sid = uuid4()
    started = datetime(2024, 2, 1, 9, 0, 0)
    ended = datetime(2024, 2, 1, 9, 30, 0)

    await storage.record_session_summary(
        session_id=sid,
        started_at=started,
        ended_at=ended,
        store_count=3,
        retrieve_count=5,
        # scar_count, merge_count, edge_count omitted → should default to 0
    )

    rows = await storage.get_session_summaries()
    assert len(rows) == 1
    assert rows[0]["scar_count"] == 0
    assert rows[0]["merge_count"] == 0
    assert rows[0]["edge_count"] == 0


@pytest.mark.asyncio
async def test_record_session_summary_is_idempotent(storage: Storage):
    """Calling record_session_summary twice for the same session_id replaces the row."""
    sid = uuid4()
    started = datetime(2024, 3, 1, 8, 0, 0)
    ended = datetime(2024, 3, 1, 8, 45, 0)

    await storage.record_session_summary(
        session_id=sid, started_at=started, ended_at=ended,
        store_count=1, retrieve_count=2,
    )
    # Second call with different counts — should replace, not duplicate
    await storage.record_session_summary(
        session_id=sid, started_at=started, ended_at=ended,
        store_count=5, retrieve_count=10,
    )

    rows = await storage.get_session_summaries()
    assert len(rows) == 1, "Duplicate rows must not be inserted — INSERT OR REPLACE"
    assert rows[0]["store_count"] == 5
    assert rows[0]["retrieve_count"] == 10


# ---------------------------------------------------------------------------
# Storage: get_session_summaries
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_session_summaries_empty_returns_empty_list(storage: Storage):
    """get_session_summaries returns [] when no sessions have ended."""
    rows = await storage.get_session_summaries()
    assert rows == []


@pytest.mark.asyncio
async def test_get_session_summaries_returns_newest_first(storage: Storage):
    """get_session_summaries orders rows by ended_at DESC (newest first)."""
    ids = [uuid4(), uuid4(), uuid4()]
    for i, sid in enumerate(ids):
        await storage.record_session_summary(
            session_id=sid,
            started_at=datetime(2024, 1, i + 1, 10, 0, 0),
            ended_at=datetime(2024, 1, i + 1, 11, 0, 0),
            store_count=i,
            retrieve_count=i * 2,
        )

    rows = await storage.get_session_summaries()
    assert len(rows) == 3
    # Newest (Jan 3) must come first
    assert rows[0]["session_id"] == str(ids[2])
    assert rows[1]["session_id"] == str(ids[1])
    assert rows[2]["session_id"] == str(ids[0])


@pytest.mark.asyncio
async def test_get_session_summaries_respects_limit(storage: Storage):
    """get_session_summaries returns at most `limit` rows."""
    for i in range(5):
        await storage.record_session_summary(
            session_id=uuid4(),
            started_at=datetime(2024, 1, i + 1, 10, 0, 0),
            ended_at=datetime(2024, 1, i + 1, 11, 0, 0),
            store_count=i,
            retrieve_count=i,
        )

    rows = await storage.get_session_summaries(limit=3)
    assert len(rows) == 3


@pytest.mark.asyncio
async def test_get_session_summaries_default_limit_is_90(storage: Storage):
    """Default limit of 90 covers ~90 days of daily sessions for Phase 4 timeline."""
    # Insert 100 sessions
    for i in range(100):
        await storage.record_session_summary(
            session_id=uuid4(),
            started_at=datetime(2024, 1, 1, i % 24, 0, 0),
            ended_at=datetime(2024, 1, 1, (i % 24) + 1 if i % 24 < 23 else 23, 0, 0),
            store_count=1,
            retrieve_count=1,
        )

    rows = await storage.get_session_summaries()  # default limit=90
    assert len(rows) == 90


# ---------------------------------------------------------------------------
# Session end hook: session_summaries written after session_end()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_end_writes_session_summary(fractal_memory, tmp_config):
    """session_end() writes a row to session_summaries with correct store/retrieve counts."""
    fm = fractal_memory
    storage = fm._storage

    await fm.session_start("test-domain")

    # Perform 2 stores and 1 retrieve
    await fm.store("memory one", domain="test-domain")
    await fm.store("memory two", domain="test-domain")
    await fm.retrieve("what do I know", domain="test-domain")

    await fm.session_end()

    rows = await storage.get_session_summaries()
    assert len(rows) == 1, "Exactly one summary row must be written per session_end()"
    row = rows[0]
    assert row["store_count"] == 2
    assert row["retrieve_count"] == 1


@pytest.mark.asyncio
async def test_session_end_writes_summary_for_empty_session(fractal_memory):
    """session_end() writes a row even when the session had zero stores and retrieves."""
    fm = fractal_memory
    storage = fm._storage

    await fm.session_start("empty-domain")
    await fm.session_end()

    rows = await storage.get_session_summaries()
    assert len(rows) == 1
    assert rows[0]["store_count"] == 0
    assert rows[0]["retrieve_count"] == 0


@pytest.mark.asyncio
async def test_multiple_session_ends_produce_multiple_summary_rows(fractal_memory):
    """Each session_end() produces a distinct row in session_summaries."""
    fm = fractal_memory
    storage = fm._storage

    # Session 1
    await fm.session_start("domain-a")
    await fm.store("first memory", domain="domain-a")
    await fm.session_end()

    # Session 2
    await fm.session_start("domain-b")
    await fm.store("second memory", domain="domain-b")
    await fm.store("third memory", domain="domain-b")
    await fm.session_end()

    rows = await storage.get_session_summaries()
    assert len(rows) == 2
    # Newest first — session 2 has 2 stores
    assert rows[0]["store_count"] == 2
    assert rows[1]["store_count"] == 1


@pytest.mark.asyncio
async def test_session_end_summary_session_id_matches_session(fractal_memory):
    """The session_id in session_summaries matches the actual session ID."""
    fm = fractal_memory
    storage = fm._storage

    ctx = await fm.session_start("check-domain")
    session_id = ctx.session.id
    await fm.session_end()

    rows = await storage.get_session_summaries()
    assert len(rows) == 1
    assert rows[0]["session_id"] == str(session_id)


@pytest.mark.asyncio
async def test_session_end_writes_correct_timestamps(fractal_memory):
    """session_end() writes started_at and ended_at that are internally consistent.

    ended_at must be after started_at — the Phase 4 timeline ribbon relies on
    these timestamps for accurate session duration and ordering.
    """
    fm = fractal_memory
    storage = fm._storage

    ctx = await fm.session_start("timestamp-domain")
    session_started = ctx.session.started_at

    await fm.session_end()

    rows = await storage.get_session_summaries()
    assert len(rows) == 1

    recorded_started = datetime.fromisoformat(rows[0]["started_at"])
    recorded_ended = datetime.fromisoformat(rows[0]["ended_at"])

    assert recorded_started == session_started, (
        "started_at must match the session's started_at field"
    )
    assert recorded_ended >= recorded_started, (
        "ended_at must be equal to or after started_at"
    )


@pytest.mark.asyncio
async def test_session_summaries_created_by_phase2_migration(tmp_path: Path):
    """_migrate_phase2_schema() creates session_summaries for Phase 1 → Phase 2 upgrades.

    A Phase 1 database (schema_version=1) does not have session_summaries.
    After running initialize() which calls _migrate_phase2_schema(), the table
    must exist so that record_session_summary() does not fail for existing users.
    """
    import aiosqlite

    db_path = tmp_path / "phase1.db"

    # Bootstrap a Phase 1 schema (no session_summaries table)
    async with aiosqlite.connect(str(db_path)) as conn:
        await conn.execute(
            "CREATE TABLE schema_version (version INTEGER PRIMARY KEY)"
        )
        await conn.execute("INSERT INTO schema_version VALUES (1)")
        await conn.execute(
            "CREATE TABLE associations "
            "(source_id TEXT, target_id TEXT, weight REAL, created_at TEXT, "
            "PRIMARY KEY(source_id, target_id))"
        )
        await conn.execute(
            "CREATE TABLE scars "
            "(id TEXT PRIMARY KEY, pattern_embedding BLOB, memory_id TEXT, "
            "reason TEXT, created_at TEXT)"
        )
        await conn.commit()

    # Now open through Storage (which runs the migration)
    from fractal_memory.storage import Storage

    config = FractalConfig(db_path=db_path, gate_signal_count=1)
    storage = Storage(config)
    await storage.initialize()

    # session_summaries must now exist
    async with aiosqlite.connect(str(db_path)) as conn:
        async with conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name='session_summaries'"
        ) as cur:
            row = await cur.fetchone()

    await storage.close()
    assert row is not None, (
        "session_summaries must be created by _migrate_phase2_schema() "
        "for Phase 1 → Phase 2 upgrades"
    )


@pytest.mark.asyncio
async def test_session_end_non_fatal_when_record_summary_fails(
    fractal_memory, monkeypatch
):
    """session_end() returns a valid SessionSummary even if record_session_summary fails.

    The session_summaries write is explicitly documented as non-fatal.
    A storage I/O error must not prevent session_end from completing.
    """
    fm = fractal_memory

    await fm.session_start("nonfatal-domain")
    await fm.store("test memory", domain="nonfatal-domain")

    # Make record_session_summary raise to simulate an I/O failure
    async def _broken(*args, **kwargs):
        raise OSError("Simulated disk full")

    monkeypatch.setattr(fm._storage, "record_session_summary", _broken)

    summary = await fm.session_end()

    # session_end must still return a valid summary
    assert summary is not None
    assert summary.memories_stored == 1
    assert summary.duration_seconds >= 0
