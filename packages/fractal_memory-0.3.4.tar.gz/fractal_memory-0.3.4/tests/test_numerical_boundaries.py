"""Numerical boundary tests — 0/NaN/Inf in embeddings, morphogens, response curves, vitality, cosine sim.

Probes every numerical computation in the system with boundary and pathological values.
"""

from __future__ import annotations

import math
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.models import Memory
from fractal_memory.morphogens import AllostericUpdater, MorphogenState, MorphogeneticField, ResponseCurve
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── ResponseCurve boundary tests ─────────────────────────────────────


class TestResponseCurveBoundaries:
    def _make_curve(self, **overrides) -> ResponseCurve:
        defaults = dict(
            name="test_param",
            morphogen_weights={"information_richness": 1.0},
            base_value=0.5,
            midpoint=0.5,
            steepness=10.0,
            min_value=0.0,
            max_value=1.0,
        )
        defaults.update(overrides)
        return ResponseCurve(**defaults)

    def test_zero_morphogens(self):
        """Curve with all-zero morphogens should produce a valid value."""
        curve = self._make_curve()
        ms = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.0)
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0
        assert not math.isnan(val)

    def test_max_morphogens(self):
        """Curve with all-1.0 morphogens should produce a valid value."""
        curve = self._make_curve()
        ms = MorphogenState(information_richness=1.0, retrieval_pressure=1.0, domain_density=1.0)
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0

    def test_extreme_steepness(self):
        """Very high steepness should not produce NaN or Inf."""
        curve = self._make_curve(steepness=1000.0)
        ms = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0
        assert not math.isnan(val)

    def test_negative_steepness(self):
        """Negative steepness should produce a valid (inverted) value."""
        curve = self._make_curve(steepness=-10.0)
        ms = MorphogenState(information_richness=1.0, retrieval_pressure=0.0, domain_density=0.0)
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0

    def test_zero_steepness(self):
        """Zero steepness should yield sigmoid(0) = 0.5 contribution."""
        curve = self._make_curve(steepness=0.0)
        ms = MorphogenState(information_richness=1.0, retrieval_pressure=0.0, domain_density=0.0)
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0

    def test_base_equals_min_equals_max(self):
        """When base=min=max, output should always be that value."""
        curve = self._make_curve(base_value=0.5, min_value=0.5, max_value=0.5)
        ms = MorphogenState(information_richness=0.7, retrieval_pressure=0.3, domain_density=0.5)
        val = curve.compute(ms)
        assert val == pytest.approx(0.5, abs=0.01)


# ── MorphogenState boundary tests ────────────────────────────────────


class TestMorphogenStateBoundaries:
    def test_morphogen_state_with_zeros(self):
        """MorphogenState should accept all-zero values."""
        ms = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.0)
        assert ms.information_richness == 0.0
        assert ms.retrieval_pressure == 0.0

    def test_morphogen_state_with_ones(self):
        """MorphogenState should accept all-one values."""
        ms = MorphogenState(information_richness=1.0, retrieval_pressure=1.0, domain_density=1.0)
        assert ms.domain_density == 1.0

    def test_morphogen_state_negative_values(self):
        """MorphogenState with negative values should not crash curves."""
        ms = MorphogenState(information_richness=-1.0, retrieval_pressure=-0.5, domain_density=-0.1)
        curve = ResponseCurve(
            name="test", morphogen_weights={"information_richness": 1.0},
            base_value=0.5, midpoint=0.5, steepness=10.0,
            min_value=0.0, max_value=1.0,
        )
        val = curve.compute(ms)
        assert 0.0 <= val <= 1.0
        assert not math.isnan(val)


# ── AllostericUpdater boundary tests ─────────────────────────────────


class TestAllostericUpdaterBoundaries:
    def test_update_with_perfect_score(self):
        """Judge score = 1.0 should not crash."""
        updater = AllostericUpdater(alpha=0.05, ema_window=10)
        curve = ResponseCurve(
            name="test", morphogen_weights={"information_richness": 1.0},
            base_value=0.5, midpoint=0.5, steepness=10.0,
            min_value=0.0, max_value=1.0,
        )
        ms = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
        updater.update(curve, 1.0, ms)
        # Should not raise

    def test_update_with_zero_score(self):
        """Judge score = 0.0 should not crash."""
        updater = AllostericUpdater(alpha=0.05, ema_window=10)
        curve = ResponseCurve(
            name="test", morphogen_weights={"information_richness": 1.0},
            base_value=0.5, midpoint=0.5, steepness=10.0,
            min_value=0.0, max_value=1.0,
        )
        ms = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
        updater.update(curve, 0.0, ms)

    def test_many_updates_stability(self):
        """100 sequential updates should not diverge."""
        updater = AllostericUpdater(alpha=0.1, ema_window=5)
        curve = ResponseCurve(
            name="test", morphogen_weights={"information_richness": 1.0},
            base_value=0.5, midpoint=0.5, steepness=10.0,
            min_value=0.0, max_value=1.0,
        )
        ms = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
        for i in range(100):
            score = 0.8 if i % 2 == 0 else 0.2
            updater.update(curve, score, ms)
        # midpoint and steepness should still be finite
        assert not math.isnan(curve.midpoint)
        assert not math.isinf(curve.midpoint)
        assert not math.isnan(curve.steepness)
        assert not math.isinf(curve.steepness)


# ── Cosine similarity edge cases ─────────────────────────────────────


class TestCosineSimilarityEdges:
    def _cosine(self, a: list[float], b: list[float]) -> float:
        va = np.array(a, dtype=np.float32)
        vb = np.array(b, dtype=np.float32)
        na = np.linalg.norm(va)
        nb = np.linalg.norm(vb)
        if na == 0 or nb == 0:
            return 0.0
        return float(np.dot(va, vb) / (na * nb))

    def test_identical_vectors(self):
        """Cosine similarity of identical vectors should be ~1.0."""
        vec = _deterministic_embed("identical")
        assert self._cosine(vec, vec) == pytest.approx(1.0, abs=1e-5)

    def test_orthogonal_vectors(self):
        """Cosine similarity of orthogonal vectors should be ~0.0."""
        v1 = [1.0, 0.0, 0.0]
        v2 = [0.0, 1.0, 0.0]
        assert self._cosine(v1, v2) == pytest.approx(0.0, abs=1e-7)

    def test_zero_vs_nonzero(self):
        """Cosine with a zero vector should return 0.0, not NaN."""
        v1 = [0.0] * 384
        v2 = _deterministic_embed("nonzero")
        sim = self._cosine(v1, v2)
        assert sim == 0.0
        assert not math.isnan(sim)

    def test_both_zero_vectors(self):
        """Cosine of two zero vectors should return 0.0, not NaN."""
        v1 = [0.0] * 384
        v2 = [0.0] * 384
        sim = self._cosine(v1, v2)
        assert sim == 0.0
        assert not math.isnan(sim)


# ── Vitality computation boundaries ──────────────────────────────────


class TestVitalityBoundaries:
    @pytest.mark.asyncio
    async def test_vitality_zero_counts(self, tmp_path: Path):
        """Memory with 0 retrieval and 0 miss should have computable vitality."""
        cfg = FractalConfig(db_path=tmp_path / "vit.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            mem = Memory(
                id=uuid4(), domain="test", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag="v", l1_label="vitality", l2_summary="Zero count test",
                l3_full="Full", l4_raw="raw",
                embedding=_deterministic_embed("vitality-test"),
                embedding_model="mock",
                retrieval_count=0, miss_count=0,
            )
            await s.store_memory(mem)
            updated = await s.update_vitality_batch([mem.id])
            assert updated == 1
            fetched = await s.get_memory(mem.id)
            assert fetched is not None
            assert not math.isnan(fetched.vitality)
            assert 0.0 <= fetched.vitality <= 1.0
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_vitality_high_miss_rate(self, tmp_path: Path):
        """Memory with high miss count should have low vitality."""
        cfg = FractalConfig(db_path=tmp_path / "vit2.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            mem_id = uuid4()
            mem = Memory(
                id=mem_id, domain="test", created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(), context={},
                l0_tag="v", l1_label="miss", l2_summary="High miss",
                l3_full="Full", l4_raw="raw",
                embedding=_deterministic_embed("miss-test"),
                embedding_model="mock",
                retrieval_count=1, miss_count=100,
            )
            await s.store_memory(mem)
            await s.update_vitality_batch([mem_id])
            fetched = await s.get_memory(mem_id)
            assert fetched is not None
            assert fetched.vitality < 0.5
        finally:
            await s.close()
