"""Tests for fractal_memory.cli — Click CLI interface (Phase 3)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from click.testing import CliRunner

from fractal_memory.cli import cli


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class _FakeMemory:
    id: uuid.UUID
    domain: str = "test"
    l0_tag: str = "test"
    l1_label: str = "test label"
    l2_summary: str = "test summary"
    l3_full: str = "test full content"
    lifecycle: str = "confirmed"
    intensity: float = 0.5
    vitality: float = 0.8
    chronic_score: float = 0.3
    retrieval_count: int = 5
    miss_count: int = 1


@dataclass
class _FakeRetrievalResult:
    l3_memories: list[Any]
    l2_memories: list[Any]
    token_budget_used: int = 500
    token_budget_total: int = 1000


@dataclass
class _FakeSessionContext:
    session: Any
    bootstrap_memories: list[Any]


@dataclass
class _FakeSession:
    id: uuid.UUID


@dataclass
class _FakeSessionSummary:
    session_id: uuid.UUID
    memories_stored: int = 3
    memories_retrieved: int = 7
    duration_seconds: float = 42.5


@dataclass
class _FakeDomain:
    name: str
    memory_count: int
    last_active: datetime


@dataclass
class _FakeHealthReport:
    system_state: str = "flow"
    retrieval_hit_rate: float = 0.85
    association_density: float = 2.3
    scar_count: int = 2
    morphogen_convergence: dict = None  # type: ignore[assignment]
    total_memories: dict = None  # type: ignore[assignment]
    cascade_warnings: list = None  # type: ignore[assignment]
    flagged_parameters: list = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.morphogen_convergence is None:
            self.morphogen_convergence = {"converged": True}
        if self.total_memories is None:
            self.total_memories = {"test": 50}
        if self.cascade_warnings is None:
            self.cascade_warnings = []
        if self.flagged_parameters is None:
            self.flagged_parameters = []


@dataclass
class _FakeExplanation:
    query: str = "test query"
    system_state: str = "flow"
    bandit_arm_selected: str = "balanced"
    retrieved_memories: list = None  # type: ignore[assignment]
    suppressed_memories: list = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.retrieved_memories is None:
            self.retrieved_memories = [{"id": "abc", "score": 0.9}]
        if self.suppressed_memories is None:
            self.suppressed_memories = []


@dataclass
class _FakeMaintenanceReport:
    tier: str
    actions_taken: dict
    duration_seconds: float = 1.5
    health_snapshot: Any = None


def _mock_fm() -> AsyncMock:
    """Create a mock FractalMemory instance with all needed methods."""
    fm = AsyncMock()
    fm.initialize = AsyncMock()
    fm.close = AsyncMock()

    # store
    mem = _FakeMemory(id=uuid.uuid4())
    fm.store = AsyncMock(return_value=mem)

    # retrieve
    fm.retrieve = AsyncMock(return_value=_FakeRetrievalResult(
        l3_memories=[mem],
        l2_memories=[mem],
    ))

    # session
    sid = uuid.uuid4()
    fm.session_start = AsyncMock(return_value=_FakeSessionContext(
        session=_FakeSession(id=sid),
        bootstrap_memories=[],
    ))
    fm.session_end = AsyncMock(return_value=_FakeSessionSummary(session_id=sid))

    # health / explain
    fm.health = AsyncMock(return_value=_FakeHealthReport())
    fm.explain_last = AsyncMock(return_value=_FakeExplanation())

    # domains
    fm.list_domains = AsyncMock(return_value=[
        _FakeDomain(name="test", memory_count=50, last_active=datetime.now(UTC)),
    ])

    # pin / unpin
    fm.pin = AsyncMock()
    fm.unpin = AsyncMock()

    # storage internals used by some commands
    fm._storage = AsyncMock()
    fm._storage.list_memories = AsyncMock(return_value=[mem])
    fm._storage.get_memory = AsyncMock(return_value=mem)
    fm._storage.delete_memory = AsyncMock()
    fm._storage.get_summary_stats = AsyncMock(return_value={
        "memories": 100,
        "domains": 3,
        "edges": 500,
        "scars": 5,
        "seams": 2,
        "sessions": 20,
    })

    # morphogens
    fm._morphogens = None
    fm._bandits = None
    fm._maintenance = None

    return fm


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def _patch_make_fm(mock_fm: AsyncMock):
    """Patch _make_fm to return our mock."""
    async def fake_make_fm(db: Any, domain: Any) -> tuple[Any, str]:
        return mock_fm, domain or "test"
    return patch("fractal_memory.cli._make_fm", side_effect=fake_make_fm)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


def test_cli_help(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Fractal Memory" in result.output


# ---------------------------------------------------------------------------
# store command
# ---------------------------------------------------------------------------


def test_store_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["store", "test memory text"])
    assert result.exit_code == 0
    assert "Stored:" in result.output


def test_store_with_domain(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["store", "text", "--domain", "mydom"])
    assert result.exit_code == 0
    assert "Stored:" in result.output


def test_store_with_intensity(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["store", "text", "--intensity", "0.9"])
    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# retrieve command
# ---------------------------------------------------------------------------


def test_retrieve_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["retrieve", "test query"])
    assert result.exit_code == 0
    assert "L3" in result.output
    assert "Tokens used:" in result.output


def test_retrieve_with_budget(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["retrieve", "query", "--budget", "500"])
    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# session commands
# ---------------------------------------------------------------------------


def test_session_start_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["session", "start"])
    assert result.exit_code == 0
    assert "Session started" in result.output


def test_session_start_with_domain(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["session", "start", "--domain", "mydom"])
    assert result.exit_code == 0


def test_session_end_command(runner: CliRunner) -> None:
    """Issue #17: CLI session end prints 'not supported' and exits with code 1."""
    result = runner.invoke(cli, ["session", "end"])
    assert result.exit_code == 1
    assert "not supported" in result.output


def test_cli_store_creates_micro_session(runner: CliRunner) -> None:
    """Issue #18: CLI store wraps in a micro-session (session_start + session_end)."""
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["store", "hello", "--domain", "test"])
    assert result.exit_code == 0
    assert "Stored:" in result.output
    fm.session_start.assert_called_once_with("test")
    fm.session_end.assert_called_once()


# ---------------------------------------------------------------------------
# health command
# ---------------------------------------------------------------------------


def test_health_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["health"])
    assert result.exit_code == 0
    assert "System state:" in result.output
    assert "hit rate:" in result.output


def test_health_with_cascade_warnings(runner: CliRunner) -> None:
    fm = _mock_fm()

    @dataclass
    class _FakeWarning:
        affected_system: str = "gate"
        recommended_action: str = "loosen_gate"

    report = _FakeHealthReport()
    report.cascade_warnings = [_FakeWarning()]
    fm.health = AsyncMock(return_value=report)

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["health"])
    assert result.exit_code == 0
    assert "CASCADE WARNINGS:" in result.output


def test_health_with_flagged_params(runner: CliRunner) -> None:
    fm = _mock_fm()
    report = _FakeHealthReport()
    report.flagged_parameters = ["gate_strictness"]
    fm.health = AsyncMock(return_value=report)

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["health"])
    assert result.exit_code == 0
    assert "Flagged parameters:" in result.output


# ---------------------------------------------------------------------------
# explain command
# ---------------------------------------------------------------------------


def test_explain_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["explain"])
    assert result.exit_code == 0
    assert "Query:" in result.output
    assert "State:" in result.output


# ---------------------------------------------------------------------------
# domains command
# ---------------------------------------------------------------------------


def test_domains_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["domains"])
    assert result.exit_code == 0
    assert "Domain" in result.output
    assert "test" in result.output


# ---------------------------------------------------------------------------
# memories command
# ---------------------------------------------------------------------------


def test_memories_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["memories"])
    assert result.exit_code == 0
    assert "L1 Label" in result.output


def test_memories_with_filters(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["memories", "--lifecycle", "confirmed", "--limit", "5"])
    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# inspect command
# ---------------------------------------------------------------------------


def test_inspect_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    mid = str(uuid.uuid4())
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["inspect", mid])
    assert result.exit_code == 0
    assert "Domain:" in result.output
    assert "Lifecycle:" in result.output


def test_inspect_not_found(runner: CliRunner) -> None:
    fm = _mock_fm()
    fm._storage.get_memory = AsyncMock(return_value=None)
    mid = str(uuid.uuid4())
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["inspect", mid])
    assert result.exit_code == 0
    assert "not found" in result.output


# ---------------------------------------------------------------------------
# delete command
# ---------------------------------------------------------------------------


def test_delete_command_with_confirmation(runner: CliRunner) -> None:
    fm = _mock_fm()
    mid = str(uuid.uuid4())
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["delete", mid, "--yes"])
    assert result.exit_code == 0
    assert "Deleted:" in result.output


# ---------------------------------------------------------------------------
# pin / unpin commands
# ---------------------------------------------------------------------------


def test_pin_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    mid = str(uuid.uuid4())
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["pin", mid])
    assert result.exit_code == 0
    assert "Pinned:" in result.output


def test_unpin_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    mid = str(uuid.uuid4())
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["unpin", mid])
    assert result.exit_code == 0
    assert "Unpinned:" in result.output


# ---------------------------------------------------------------------------
# morphogens command
# ---------------------------------------------------------------------------


def test_morphogens_not_active(runner: CliRunner) -> None:
    fm = _mock_fm()
    fm._morphogens = None
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["morphogens"])
    assert result.exit_code == 0
    assert "not active" in result.output


def test_morphogens_active(runner: CliRunner) -> None:
    fm = _mock_fm()

    @dataclass
    class _FakeMorphogenState:
        information_richness: float = 0.5
        retrieval_pressure: float = 0.4
        domain_density: float = 0.6

    @dataclass
    class _FakeCurve:
        name: str = "gate_strictness"
        midpoint: float = 0.5
        steepness: float = 5.0

        def compute(self, ms: Any) -> float:
            return 0.65

    morph = MagicMock()
    morph.last_morphogens = _FakeMorphogenState()
    morph.has_converged.return_value = False
    morph.curves = [_FakeCurve()]
    fm._morphogens = morph

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["morphogens"])
    assert result.exit_code == 0
    assert "information_richness:" in result.output
    assert "Converged:" in result.output
    assert "gate_strictness" in result.output


# ---------------------------------------------------------------------------
# bandits command
# ---------------------------------------------------------------------------


def test_bandits_not_active(runner: CliRunner) -> None:
    fm = _mock_fm()
    fm._bandits = None
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["bandits"])
    assert result.exit_code == 0
    assert "not active" in result.output


def test_bandits_active(runner: CliRunner) -> None:
    fm = _mock_fm()
    b = MagicMock()
    b.get_arm_stats.return_value = {
        "balanced": {"alpha": 5.0, "beta": 3.0, "mean_success": 0.625, "pulls": 8},
        "conservative": {"alpha": 2.0, "beta": 4.0, "mean_success": 0.333, "pulls": 6},
    }
    b.current_arm = "balanced"
    fm._bandits = b

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["bandits"])
    assert result.exit_code == 0
    assert "balanced" in result.output
    assert "conservative" in result.output
    assert "Current arm:" in result.output


# ---------------------------------------------------------------------------
# maintenance command
# ---------------------------------------------------------------------------


def test_maintenance_daily(runner: CliRunner) -> None:
    fm = _mock_fm()
    sched = AsyncMock()
    sched.daily_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
        tier="daily",
        actions_taken={"pruned_expired": 3, "edges_weakened": 10},
    ))
    fm._maintenance = sched

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
    assert result.exit_code == 0
    assert "daily" in result.output


def test_maintenance_weekly(runner: CliRunner) -> None:
    fm = _mock_fm()
    sched = AsyncMock()
    sched.weekly_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
        tier="weekly",
        actions_taken={"clusters_detected": 2},
    ))
    fm._maintenance = sched

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["maintenance", "--tier", "weekly"])
    assert result.exit_code == 0
    assert "weekly" in result.output


def test_maintenance_monthly(runner: CliRunner) -> None:
    fm = _mock_fm()
    sched = AsyncMock()
    sched.monthly_maintenance = AsyncMock(return_value=_FakeMaintenanceReport(
        tier="monthly",
        actions_taken={"apoptosis_checked": 50},
    ))
    fm._maintenance = sched

    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["maintenance", "--tier", "monthly"])
    assert result.exit_code == 0
    assert "monthly" in result.output


def test_maintenance_not_active(runner: CliRunner) -> None:
    fm = _mock_fm()
    fm._maintenance = None
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["maintenance", "--tier", "daily"])
    assert result.exit_code == 0
    assert "not active" in result.output


# ---------------------------------------------------------------------------
# stats command
# ---------------------------------------------------------------------------


def test_stats_command(runner: CliRunner) -> None:
    fm = _mock_fm()
    with _patch_make_fm(fm):
        result = runner.invoke(cli, ["stats"])
    assert result.exit_code == 0
    assert "Fractal Memory Stats" in result.output
    assert "memories:" in result.output
