"""Tests for lifecycle management."""

from datetime import datetime, timedelta
from uuid import uuid4

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.models import LifecycleStatus, Memory, Session
from fractal_memory.storage import Storage


def _make_memory(**kwargs) -> Memory:
    defaults = dict(
        id=uuid4(),
        domain="test",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="test summary",
        l3_full="test full",
        l4_raw="raw text",
        embedding=[0.1] * 384,
        embedding_model="test-model",
    )
    defaults.update(kwargs)
    return Memory(**defaults)


async def test_memory_starts_probation(storage):
    mem = _make_memory()
    await storage.store_memory(mem)
    fetched = await storage.get_memory(mem.id)
    assert fetched.lifecycle == LifecycleStatus.PROBATION


async def test_promotion_to_confirmed(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(retrieval_count=1)
    await storage.store_memory(mem)
    # One more retrieval should reach threshold (2)
    updated = await lm.on_memory_retrieved(mem)
    assert updated.lifecycle == LifecycleStatus.CONFIRMED
    assert updated.retrieval_count == 2


async def test_no_premature_confirmation(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(retrieval_count=0)
    await storage.store_memory(mem)
    updated = await lm.on_memory_retrieved(mem)
    assert updated.lifecycle == LifecycleStatus.PROBATION
    assert updated.retrieval_count == 1


async def test_promotion_to_permanent(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(
        retrieval_count=9,
        lifecycle=LifecycleStatus.CONFIRMED,
        created_at=datetime.utcnow() - timedelta(days=30),
    )
    await storage.store_memory(mem)

    # Create 3 completed sessions since memory creation
    for i in range(3):
        s = Session(
            id=uuid4(),
            domain="test",
            started_at=mem.created_at + timedelta(days=i + 1),
            ended_at=mem.created_at + timedelta(days=i + 1, hours=1),
            summary=f"session {i}",
        )
        await storage.store_session(s)

    updated = await lm.on_memory_retrieved(mem)
    assert updated.lifecycle == LifecycleStatus.PERMANENT
    assert updated.retrieval_count == 10


async def test_safety_critical_never_pruned(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(lifecycle=LifecycleStatus.SAFETY_CRITICAL)
    await storage.store_memory(mem)
    pruned = await lm.prune_expired()
    assert mem.id not in pruned


async def test_permanent_never_pruned(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(lifecycle=LifecycleStatus.PERMANENT)
    await storage.store_memory(mem)
    pruned = await lm.prune_expired()
    assert mem.id not in pruned


async def test_pin_promotes_to_permanent(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(lifecycle=LifecycleStatus.CONFIRMED)
    await storage.store_memory(mem)
    await lm.pin(mem.id)
    fetched = await storage.get_memory(mem.id)
    assert fetched.lifecycle == LifecycleStatus.PERMANENT


async def test_unpin_reverts_to_confirmed(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(lifecycle=LifecycleStatus.PERMANENT)
    await storage.store_memory(mem)
    await lm.unpin(mem.id)
    fetched = await storage.get_memory(mem.id)
    assert fetched.lifecycle == LifecycleStatus.CONFIRMED


async def test_unpin_no_effect_on_safety_critical(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(lifecycle=LifecycleStatus.SAFETY_CRITICAL)
    await storage.store_memory(mem)
    await lm.unpin(mem.id)
    fetched = await storage.get_memory(mem.id)
    assert fetched.lifecycle == LifecycleStatus.SAFETY_CRITICAL


async def test_mark_safety_critical(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory()
    await storage.store_memory(mem)
    await lm.mark_safety_critical(mem.id)
    fetched = await storage.get_memory(mem.id)
    assert fetched.lifecycle == LifecycleStatus.SAFETY_CRITICAL


async def test_on_memory_missed(storage, tmp_config):
    lm = LifecycleManager(storage, tmp_config)
    mem = _make_memory(miss_count=0)
    await storage.store_memory(mem)
    updated = await lm.on_memory_missed(mem)
    assert updated.miss_count == 1


async def test_probation_pruned_after_ttl(storage):
    """Probation memories older than TTL sessions get pruned."""
    config = FractalConfig(
        db_path=storage._db_path,
        gate_signal_count=1,
        pruning_ttl_sessions=3,
    )
    lm = LifecycleManager(storage, config)

    # Create a probation memory in the past
    old_time = datetime.utcnow() - timedelta(days=30)
    mem = _make_memory(created_at=old_time, updated_at=old_time)
    await storage.store_memory(mem)

    # Create enough completed sessions to exceed TTL
    for i in range(5):
        s = Session(
            id=uuid4(),
            domain="test",
            started_at=old_time + timedelta(days=i + 1),
            ended_at=old_time + timedelta(days=i + 1, hours=1),
            summary=f"session {i}",
        )
        await storage.store_session(s)

    pruned = await lm.prune_expired()
    assert mem.id in pruned
    assert await storage.get_memory(mem.id) is None
