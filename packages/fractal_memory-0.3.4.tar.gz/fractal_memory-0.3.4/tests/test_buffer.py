"""Tests for working memory buffer."""

from uuid import uuid4

from fractal_memory.buffer import WorkingMemoryBuffer
from fractal_memory.config import FractalConfig


def _config(soft_cap: int = 20) -> FractalConfig:
    return FractalConfig(buffer_soft_cap=soft_cap, gate_signal_count=1)


def test_add_recent_and_get():
    buf = WorkingMemoryBuffer(_config())
    ids = [uuid4() for _ in range(3)]
    for uid in ids:
        buf.add_recent(uid)
    result = buf.get_buffer_ids()
    assert len(result) == 3
    # Most recent first (after pinned/promoted/just_written)
    assert result[0] == ids[2]


def test_soft_cap_eviction():
    buf = WorkingMemoryBuffer(_config(soft_cap=5))
    ids = [uuid4() for _ in range(7)]
    for uid in ids:
        buf.add_recent(uid)
    result = buf.get_buffer_ids()
    assert len(result) == 5
    # Oldest should be evicted
    assert ids[0] not in result
    assert ids[1] not in result


def test_pinned_immune_from_eviction():
    buf = WorkingMemoryBuffer(_config(soft_cap=3))
    pinned_id = uuid4()
    buf.add_recent(pinned_id)
    buf.pin(pinned_id)
    # Add more than soft_cap
    for _ in range(5):
        buf.add_recent(uuid4())
    result = buf.get_buffer_ids()
    assert pinned_id in result


def test_auto_promotion_after_3_accesses():
    buf = WorkingMemoryBuffer(_config())
    uid = uuid4()
    buf.add_recent(uid)
    buf.on_access(uid)
    buf.on_access(uid)
    # Not yet promoted
    result = buf.get_buffer_ids()
    assert uid in result

    buf.on_access(uid)  # 3rd access → promoted
    result = buf.get_buffer_ids()
    assert uid in result
    # Should be in auto_promoted position (after pinned)


def test_just_written_holds_last_3():
    buf = WorkingMemoryBuffer(_config())
    ids = [uuid4() for _ in range(5)]
    for uid in ids:
        buf.add_just_written(uid)
    result = buf.get_buffer_ids()
    # Last 3 just_written should be present
    assert ids[4] in result
    assert ids[3] in result
    assert ids[2] in result
    # Older ones overflow to recent
    assert ids[1] in result  # overflowed to recent
    assert ids[0] in result  # overflowed to recent


def test_get_buffer_ids_ordering():
    buf = WorkingMemoryBuffer(_config())
    pinned = uuid4()
    promoted = uuid4()
    just_written = uuid4()
    recent = uuid4()

    buf.add_recent(recent)
    buf.add_just_written(just_written)
    buf.add_recent(promoted)
    for _ in range(3):
        buf.on_access(promoted)
    buf.add_recent(pinned)
    buf.pin(pinned)

    result = buf.get_buffer_ids()
    # pinned first, then auto-promoted, then just_written, then recent
    pinned_idx = result.index(pinned)
    promoted_idx = result.index(promoted)
    jw_idx = result.index(just_written)
    recent_idx = result.index(recent)
    assert pinned_idx < promoted_idx
    assert promoted_idx < jw_idx
    assert jw_idx < recent_idx


def test_clear():
    buf = WorkingMemoryBuffer(_config())
    uid = uuid4()
    buf.add_recent(uid)
    buf.pin(uid)
    buf.add_just_written(uuid4())
    buf.clear()
    assert buf.get_buffer_ids() == []


def test_unpin():
    buf = WorkingMemoryBuffer(_config())
    uid = uuid4()
    buf.pin(uid)
    assert uid in buf.get_buffer_ids()
    buf.unpin(uid)
    # uid is no longer pinned, may not show if not in recent
    # It shouldn't be in pinned set anymore
    assert uid not in buf._pinned
