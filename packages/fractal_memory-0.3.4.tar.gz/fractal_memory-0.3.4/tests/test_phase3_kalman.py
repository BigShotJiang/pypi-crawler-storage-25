"""Tests for fractal_memory.kalman — CircuitBreaker (Phase 3)."""

from __future__ import annotations

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.kalman import (
    CascadeWarning,
    CircuitBreaker,
)


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig()


@pytest.fixture
def cb(cfg: FractalConfig) -> CircuitBreaker:
    return CircuitBreaker(cfg)


# ---------------------------------------------------------------------------
# CircuitBreaker
# ---------------------------------------------------------------------------


def test_cb_no_warning_for_healthy(cb: CircuitBreaker) -> None:
    result = cb.observe({"hit_rate": 0.8, "correction_rate": 0.05, "memory_growth_rate": 5})
    assert result is None


def test_cb_triggers_on_low_hit_rate(cb: CircuitBreaker) -> None:
    bad_metrics = {"hit_rate": 0.1, "correction_rate": 0.0, "memory_growth_rate": 0}
    result = None
    for _ in range(3):
        result = cb.observe(bad_metrics)
    assert result is not None
    assert result.affected_system == "retrieval"
    assert result.recommended_action == "widen_activation"


def test_cb_resets_low_hit_counter_on_recovery(cb: CircuitBreaker) -> None:
    bad = {"hit_rate": 0.1}
    good = {"hit_rate": 0.9}
    cb.observe(bad)
    cb.observe(bad)
    cb.observe(good)  # reset counter
    # Should NOT trigger (counter < 3)
    result = cb.observe(bad)
    result2 = cb.observe(bad)
    # After reset, only 2 consecutive bad — not triggered
    assert result is None or result2 is None


def test_cb_triggers_on_high_correction_rate(cb: CircuitBreaker) -> None:
    high_corr = {"hit_rate": 0.8, "correction_rate": 0.5, "memory_growth_rate": 0}
    result = None
    for _ in range(2):
        result = cb.observe(high_corr)
    assert result is not None
    assert result.affected_system == "gate"
    assert result.recommended_action == "loosen_gate"


def test_cb_triggers_on_memory_growth(cb: CircuitBreaker) -> None:
    metrics = {"hit_rate": 0.8, "correction_rate": 0.0, "memory_growth_rate": 60}
    result = cb.observe(metrics)
    assert result is not None
    assert result.recommended_action == "tighten_gate"


def test_cb_returns_none_after_correction_recovery(cb: CircuitBreaker) -> None:
    high_corr = {"hit_rate": 0.8, "correction_rate": 0.5, "memory_growth_rate": 0}
    good = {"hit_rate": 0.8, "correction_rate": 0.05, "memory_growth_rate": 0}
    cb.observe(high_corr)
    cb.observe(good)  # reset
    result = cb.observe(high_corr)
    assert result is None  # counter reset — only 1 consecutive high, not 2


def test_cb_warning_severity_is_valid(cb: CircuitBreaker) -> None:
    bad = {"hit_rate": 0.1, "correction_rate": 0.0, "memory_growth_rate": 0}
    result = None
    for _ in range(3):
        result = cb.observe(bad)
    assert result is not None
    assert 0.0 <= result.severity <= 1.0
