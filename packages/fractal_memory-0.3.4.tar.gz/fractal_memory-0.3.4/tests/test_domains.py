"""Tests for Phase 2 — DomainManager."""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.domains import DomainManager
from fractal_memory.models import ContextTags, LifecycleStatus, Memory
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_memory(domain: str, mid=None) -> Memory:
    import numpy as np
    from datetime import datetime
    rng = np.random.RandomState(0)
    emb = rng.randn(384).tolist()
    return Memory(
        id=mid or uuid4(),
        domain=domain,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="label",
        l2_summary="summary",
        l3_full="detail",
        l4_raw="raw",
        embedding=emb,
        embedding_model="test",
        lifecycle=LifecycleStatus.CONFIRMED,
        intensity=0.5,
    )


@pytest.fixture
def dm(storage: Storage, tmp_config: FractalConfig):
    return DomainManager(storage, tmp_config)


# ---------------------------------------------------------------------------
# Domain detection
# ---------------------------------------------------------------------------


async def test_detect_domain_explicit(dm: DomainManager):
    ctx: ContextTags = {"domain": "my-project"}  # type: ignore[assignment]
    domain = await dm.detect_domain(ctx, "some text")
    assert domain == "my-project"


async def test_detect_domain_from_project(dm: DomainManager):
    ctx: ContextTags = {"project": "alpha"}  # type: ignore[assignment]
    domain = await dm.detect_domain(ctx, "some text")
    assert domain == "project-alpha"


async def test_detect_domain_fallback(dm: DomainManager):
    ctx: ContextTags = {}  # type: ignore[assignment]
    domain = await dm.detect_domain(ctx, "some text")
    assert domain == "general"


async def test_detect_domain_explicit_overrides_project(dm: DomainManager):
    ctx: ContextTags = {"domain": "explicit", "project": "ignored"}  # type: ignore[assignment]
    domain = await dm.detect_domain(ctx, "")
    assert domain == "explicit"


# ---------------------------------------------------------------------------
# Domain drift suggestion
# ---------------------------------------------------------------------------


async def test_suggest_domain_no_drift_when_same_domain(dm: DomainManager):
    a, b = uuid4(), uuid4()
    edges = [(a, 0.5), (b, 0.5)]
    lookup = {a: "alpha", b: "alpha"}
    result = await dm.suggest_domain_from_associations(
        uuid4(), edges, current_domain="alpha", domain_lookup=lookup
    )
    assert result is None


async def test_suggest_domain_drift_detected(dm: DomainManager):
    neighbors = [uuid4() for _ in range(4)]
    # 3 out of 4 neighbors are in "beta" → drift should be suggested
    edges = [(n, 1.0) for n in neighbors]
    lookup = {
        neighbors[0]: "beta",
        neighbors[1]: "beta",
        neighbors[2]: "beta",
        neighbors[3]: "alpha",  # minority
    }
    result = await dm.suggest_domain_from_associations(
        uuid4(), edges, current_domain="alpha", domain_lookup=lookup
    )
    assert result == "beta"


async def test_suggest_domain_no_foreign_neighbors(dm: DomainManager):
    neighbor = uuid4()
    edges = [(neighbor, 1.0)]
    lookup = {neighbor: "alpha"}  # same domain
    result = await dm.suggest_domain_from_associations(
        uuid4(), edges, "alpha", lookup
    )
    assert result is None


async def test_suggest_domain_empty_edges(dm: DomainManager):
    result = await dm.suggest_domain_from_associations(
        uuid4(), [], "alpha", {}
    )
    assert result is None


# ---------------------------------------------------------------------------
# Domain stats
# ---------------------------------------------------------------------------


async def test_domain_stats_empty(dm: DomainManager, storage: Storage):
    stats = await dm.domain_stats("nonexistent-domain")
    assert stats.memory_count == 0
    assert stats.edge_count == 0
    assert stats.avg_internal_edge_weight == 0.0


async def test_domain_stats_with_memories(dm: DomainManager, storage: Storage):
    mem1 = _make_memory("test-dom")
    mem2 = _make_memory("test-dom")
    await storage.store_memory(mem1)
    await storage.store_memory(mem2)

    stats = await dm.domain_stats("test-dom")
    assert stats.name == "test-dom"
    assert stats.memory_count == 2


async def test_domain_stats_internal_edge_weight(dm: DomainManager, storage: Storage):
    mem1 = _make_memory("dom-x")
    mem2 = _make_memory("dom-x")
    await storage.store_memory(mem1)
    await storage.store_memory(mem2)
    await storage.store_association(mem1.id, mem2.id, weight=0.6)

    stats = await dm.domain_stats("dom-x")
    assert stats.edge_count == 1
    assert abs(stats.avg_internal_edge_weight - 0.6) < 1e-5


# ---------------------------------------------------------------------------
# list_domains_with_stats
# ---------------------------------------------------------------------------


async def test_list_domains_with_stats(dm: DomainManager, storage: Storage):
    for i in range(3):
        m = _make_memory(f"domain-{i}")
        await storage.store_memory(m)

    results = await dm.list_domains_with_stats()
    domain_names = {r.name for r in results}
    for i in range(3):
        assert f"domain-{i}" in domain_names
