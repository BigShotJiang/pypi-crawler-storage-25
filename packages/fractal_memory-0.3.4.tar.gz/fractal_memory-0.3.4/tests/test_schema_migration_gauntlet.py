"""Schema migration gauntlet — create v1-v5 databases with data, migrate to v6, verify integrity.

Tests the schema migration path by creating databases at various historical
schema versions and verifying that migration to the current version preserves data.
"""

from __future__ import annotations

import json
import struct
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import aiosqlite
import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Helpers ──────────────────────────────────────────────────────────

async def _create_v1_database(db_path: Path) -> None:
    """Create a minimal v1 schema database with test data."""
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.executescript("""
        CREATE TABLE schema_version (version INTEGER PRIMARY KEY);
        INSERT INTO schema_version (version) VALUES (1);

        CREATE TABLE memories (
            id TEXT PRIMARY KEY, domain TEXT NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, context TEXT,
            l0_tag TEXT NOT NULL, l1_label TEXT NOT NULL,
            l2_summary TEXT NOT NULL, l3_full TEXT NOT NULL, l4_raw TEXT NOT NULL,
            embedding BLOB NOT NULL, embedding_model TEXT NOT NULL,
            intensity REAL NOT NULL DEFAULT 0.5,
            retrieval_count INTEGER NOT NULL DEFAULT 0,
            miss_count INTEGER NOT NULL DEFAULT 0,
            last_accessed TEXT,
            lifecycle TEXT NOT NULL DEFAULT 'probation',
            chronic_score REAL NOT NULL DEFAULT 0.0,
            contrast TEXT, chain_next TEXT, chain_prev TEXT,
            vitality REAL NOT NULL DEFAULT 1.0,
            reconsolidation_count INTEGER NOT NULL DEFAULT 0,
            origin TEXT NOT NULL DEFAULT 'organic',
            trust_score REAL NOT NULL DEFAULT 1.0
        );

        CREATE TABLE tasks (
            id TEXT PRIMARY KEY, description TEXT NOT NULL,
            created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
            related_memory_ids TEXT, priority INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE waiting_room (
            id TEXT PRIMARY KEY, content TEXT NOT NULL,
            first_signal TEXT, domain TEXT,
            created_at TEXT NOT NULL,
            sessions_elapsed INTEGER NOT NULL DEFAULT 0,
            embedding BLOB
        );

        CREATE TABLE sessions (
            id TEXT PRIMARY KEY, domain TEXT NOT NULL,
            started_at TEXT NOT NULL, ended_at TEXT, summary TEXT
        );

        CREATE TABLE associations (
            source_id TEXT NOT NULL, target_id TEXT NOT NULL,
            weight REAL NOT NULL DEFAULT 0.1,
            created_at TEXT NOT NULL,
            PRIMARY KEY (source_id, target_id)
        );

        CREATE TABLE scars (
            id TEXT PRIMARY KEY,
            pattern TEXT NOT NULL,
            memory_id TEXT,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
    """)

    # Insert test data
    mem_id = str(uuid4())
    embedding = _pack_embedding(_deterministic_embed("v1 test memory"))
    now = datetime.utcnow().isoformat()
    await conn.execute(
        """INSERT INTO memories (id, domain, created_at, updated_at, context,
           l0_tag, l1_label, l2_summary, l3_full, l4_raw,
           embedding, embedding_model, intensity)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (mem_id, "v1-domain", now, now, "{}",
         "v1:tag", "v1-label", "V1 memory summary", "V1 full", "V1 raw",
         embedding, "mock", 0.5),
    )

    session_id = str(uuid4())
    await conn.execute(
        "INSERT INTO sessions (id, domain, started_at) VALUES (?,?,?)",
        (session_id, "v1-domain", now),
    )

    await conn.commit()
    await conn.close()


async def _create_v3_database(db_path: Path) -> None:
    """Create a v3 schema database (has session_activity but not maintenance_log)."""
    await _create_v1_database(db_path)
    conn = await aiosqlite.connect(str(db_path))

    # Simulate v2 migration
    await conn.execute(
        "ALTER TABLE associations ADD COLUMN trail_weight REAL NOT NULL DEFAULT 0.0"
    )
    await conn.execute(
        "ALTER TABLE associations ADD COLUMN trail_context_centroid BLOB"
    )
    await conn.execute("DROP TABLE scars")
    await conn.execute("""CREATE TABLE scars (
        id TEXT PRIMARY KEY, pattern_embedding BLOB NOT NULL,
        memory_id TEXT, reason TEXT NOT NULL,
        created_at TEXT NOT NULL,
        ttl_sessions INTEGER NOT NULL DEFAULT 20,
        sessions_elapsed INTEGER NOT NULL DEFAULT 0
    )""")
    await conn.execute("""CREATE TABLE IF NOT EXISTS session_summaries (
        session_id TEXT PRIMARY KEY, started_at TEXT NOT NULL, ended_at TEXT NOT NULL,
        store_count INTEGER NOT NULL DEFAULT 0, retrieve_count INTEGER NOT NULL DEFAULT 0,
        scar_count INTEGER NOT NULL DEFAULT 0, merge_count INTEGER NOT NULL DEFAULT 0,
        edge_count INTEGER NOT NULL DEFAULT 0
    )""")
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (2)")

    # Simulate v3 migration
    await conn.execute("""CREATE TABLE IF NOT EXISTS session_activity (
        session_id TEXT PRIMARY KEY, domain TEXT NOT NULL,
        started_at TEXT NOT NULL,
        stores INTEGER NOT NULL DEFAULT 0, retrievals INTEGER NOT NULL DEFAULT 0,
        last_updated TEXT NOT NULL
    )""")
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (3)")

    await conn.commit()
    await conn.close()


# ── Migration tests ──────────────────────────────────────────────────


class TestMigrationFromV1:
    @pytest.mark.asyncio
    async def test_v1_to_current_preserves_memories(self, tmp_path: Path):
        """Migrating from v1 should preserve existing memories."""
        db_path = tmp_path / "v1_migrate.db"
        await _create_v1_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            count = await s.count_memories()
            assert count == 1, f"Expected 1 memory after migration, got {count}"

            # Verify the memory is readable
            memories = await s.get_recent_memories(limit=1)
            assert len(memories) == 1
            assert memories[0].domain == "v1-domain"
            assert memories[0].l0_tag == "v1:tag"
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_v1_to_current_schema_version(self, tmp_path: Path):
        """After migration from v1, schema_version should be current (6)."""
        db_path = tmp_path / "v1_version.db"
        await _create_v1_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            async with conn.execute("SELECT MAX(version) FROM schema_version") as cur:
                row = await cur.fetchone()
                assert row[0] >= 6
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_v1_migration_creates_missing_tables(self, tmp_path: Path):
        """v1→current should create session_summaries, session_activity, etc."""
        db_path = tmp_path / "v1_tables.db"
        await _create_v1_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            # Check session_activity table exists
            async with conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='session_activity'"
            ) as cur:
                row = await cur.fetchone()
                assert row is not None, "session_activity table not created"

            # Check maintenance_log table exists
            async with conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='maintenance_log'"
            ) as cur:
                row = await cur.fetchone()
                assert row is not None, "maintenance_log table not created"

            # Check morphogen_history table exists
            async with conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='morphogen_history'"
            ) as cur:
                row = await cur.fetchone()
                assert row is not None, "morphogen_history table not created"
        finally:
            await s.close()


class TestMigrationFromV3:
    @pytest.mark.asyncio
    async def test_v3_to_current_preserves_data(self, tmp_path: Path):
        """Migrating from v3 should preserve memories and sessions."""
        db_path = tmp_path / "v3_migrate.db"
        await _create_v3_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            count = await s.count_memories()
            assert count == 1
            sessions = await s.get_session_count()
            assert sessions >= 0  # Session may not be ended
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_v3_adds_retrieval_hits_column(self, tmp_path: Path):
        """v3→v6 should add retrieval_hits column to session_summaries."""
        db_path = tmp_path / "v3_hits.db"
        await _create_v3_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            async with conn.execute("PRAGMA table_info(session_summaries)") as cur:
                cols = {r["name"] async for r in cur}
            assert "retrieval_hits" in cols
        finally:
            await s.close()


class TestFreshDatabase:
    @pytest.mark.asyncio
    async def test_fresh_db_has_current_schema(self, tmp_path: Path):
        """A freshly created database should be at schema version 6."""
        cfg = FractalConfig(db_path=tmp_path / "fresh.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            async with conn.execute("SELECT MAX(version) FROM schema_version") as cur:
                row = await cur.fetchone()
                assert row[0] >= 6
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_fresh_db_all_tables_exist(self, tmp_path: Path):
        """A fresh database should have all expected tables."""
        cfg = FractalConfig(db_path=tmp_path / "fresh_tables.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            expected_tables = [
                "memories", "tasks", "waiting_room", "sessions",
                "associations", "scars", "session_summaries",
                "session_activity", "maintenance_log", "correction_events",
                "morphogen_history", "schema_version",
            ]
            for table in expected_tables:
                async with conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                    (table,),
                ) as cur:
                    row = await cur.fetchone()
                    assert row is not None, f"Table '{table}' not found in fresh database"
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_double_initialize_idempotent(self, tmp_path: Path):
        """Initializing storage twice should not duplicate schema or data."""
        cfg = FractalConfig(db_path=tmp_path / "double_init.db", gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        await s.close()
        # Re-initialize on same DB
        s2 = Storage(cfg)
        await s2.initialize()
        try:
            conn = s2._ensure_conn()
            async with conn.execute("SELECT COUNT(*) FROM schema_version") as cur:
                row = await cur.fetchone()
                # Should not have duplicate version rows
                assert row[0] >= 1
        finally:
            await s2.close()
