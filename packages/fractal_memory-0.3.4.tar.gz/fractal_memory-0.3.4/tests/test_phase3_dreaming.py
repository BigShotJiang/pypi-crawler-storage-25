"""Tests for fractal_memory.dreaming — DreamingEngine (Phase 3)."""

from __future__ import annotations

import uuid
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.dreaming import (
    DreamingEngine,
    DreamReport,
    REMReport,
    SlowWaveReport,
    _cosine_sim,
)
from fractal_memory.models import ContextTags, LifecycleStatus, Memory


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(
        slow_wave_decay_factor=0.85,
        rem_resonance_min=0.3,
        rem_resonance_max=0.7,
        rem_emergence_threshold=0.6,
        rem_max_pairs=20,
        rem_top_memories=20,
        bandit_downscale_factor=0.85,
        apoptosis_fragment_strength=0.3,
        rem_enabled=True,
        dawn_rezoom_enabled=True,
    )


def _make_memory(
    seed: int = 0,
    retrieval_count: int = 10,
    intensity: float = 0.8,
    domain: str = "test",
) -> Memory:
    rng = np.random.default_rng(seed)
    emb = rng.standard_normal(16).astype(np.float32)
    emb = (emb / np.linalg.norm(emb)).tolist()
    return Memory(
        id=uuid.uuid4(),
        domain=domain,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context=ContextTags(),
        l0_tag="test",
        l1_label="test label",
        l2_summary="test summary",
        l3_full="test full content for synthesis",
        l4_raw="test raw content",
        embedding=emb,
        embedding_model="test-model",
        intensity=intensity,
        lifecycle=LifecycleStatus.CONFIRMED,
        retrieval_count=retrieval_count,
    )


@pytest.fixture
def storage() -> AsyncMock:
    s = AsyncMock()
    s.store_memory = AsyncMock()
    s.get_top_memories_for_rem = AsyncMock(return_value=[])
    return s


@pytest.fixture
def associations() -> AsyncMock:
    a = AsyncMock()
    a.decay_all_weights = AsyncMock(
        return_value={"edges_before": 100, "edges_pruned": 5, "edges_after": 95}
    )
    a.prune_below = AsyncMock(return_value=0)
    return a


@pytest.fixture
def embeddings() -> AsyncMock:
    e = AsyncMock()
    e.embed = AsyncMock(return_value=np.ones(16, dtype=np.float32) / 4)
    return e


@pytest.fixture
def llm() -> AsyncMock:
    m = AsyncMock()
    m.complete = AsyncMock(return_value="Both patterns share a common design principle of early validation.")
    return m


@pytest.fixture
def bandits() -> MagicMock:
    b = MagicMock()
    b.downscale_posteriors = MagicMock()
    return b


@pytest.fixture
def engine(
    storage: AsyncMock,
    associations: AsyncMock,
    embeddings: AsyncMock,
    llm: AsyncMock,
    bandits: MagicMock,
    cfg: FractalConfig,
) -> DreamingEngine:
    return DreamingEngine(
        storage=storage,
        associations=associations,
        embeddings=embeddings,
        llm=llm,
        bandits=bandits,
        config=cfg,
    )


# ---------------------------------------------------------------------------
# dream_cycle — orchestration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dream_cycle_returns_report(engine: DreamingEngine) -> None:
    report = await engine.dream_cycle(session_memories=[])
    assert isinstance(report, DreamReport)
    assert isinstance(report.slow_wave, SlowWaveReport)
    assert isinstance(report.rem, REMReport)
    assert report.duration_seconds >= 0


@pytest.mark.asyncio
async def test_dream_cycle_runs_all_phases(
    engine: DreamingEngine,
    associations: AsyncMock,
    bandits: MagicMock,
) -> None:
    await engine.dream_cycle(session_memories=[])
    associations.decay_all_weights.assert_called_once()
    bandits.downscale_posteriors.assert_called_once()


# ---------------------------------------------------------------------------
# slow_wave
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_slow_wave_decay_factor(
    engine: DreamingEngine,
    associations: AsyncMock,
    cfg: FractalConfig,
) -> None:
    report = await engine._slow_wave()
    associations.decay_all_weights.assert_called_once_with(factor=cfg.slow_wave_decay_factor)


@pytest.mark.asyncio
async def test_slow_wave_report_fields(engine: DreamingEngine) -> None:
    report = await engine._slow_wave()
    assert isinstance(report, SlowWaveReport)
    assert report.edges_pruned == 5
    assert report.edges_remaining == 95
    assert report.bandits_downscaled is True


@pytest.mark.asyncio
async def test_slow_wave_handles_decay_returning_int(
    engine: DreamingEngine,
    associations: AsyncMock,
) -> None:
    associations.decay_all_weights = AsyncMock(return_value=3)
    report = await engine._slow_wave()
    assert report.edges_pruned == 3


@pytest.mark.asyncio
async def test_slow_wave_handles_decay_failure(
    engine: DreamingEngine,
    associations: AsyncMock,
) -> None:
    associations.decay_all_weights = AsyncMock(side_effect=Exception("DB error"))
    report = await engine._slow_wave()
    assert report.edges_pruned == 0
    assert report.edges_decayed == 0


@pytest.mark.asyncio
async def test_slow_wave_bandit_downscale_factor(
    engine: DreamingEngine,
    bandits: MagicMock,
    cfg: FractalConfig,
) -> None:
    await engine._slow_wave()
    bandits.downscale_posteriors.assert_called_once_with(cfg.bandit_downscale_factor)


@pytest.mark.asyncio
async def test_slow_wave_bandit_failure_sets_false(
    engine: DreamingEngine,
    bandits: MagicMock,
) -> None:
    bandits.downscale_posteriors.side_effect = Exception("Bandit error")
    report = await engine._slow_wave()
    assert report.bandits_downscaled is False


# ---------------------------------------------------------------------------
# REM recombination
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_rem_no_memories_returns_zeros(engine: DreamingEngine) -> None:
    report = await engine._rem_recombination(session_memories=[])
    assert report.pairs_evaluated == 0
    assert report.syntheses_attempted == 0
    assert report.syntheses_stored == 0
    assert report.syntheses_discarded == 0


@pytest.mark.asyncio
async def test_rem_one_memory_returns_zeros(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    storage.get_top_memories_for_rem = AsyncMock(return_value=[_make_memory(seed=0)])
    report = await engine._rem_recombination(session_memories=[])
    assert report.pairs_evaluated == 0


@pytest.mark.asyncio
async def test_rem_evaluates_pairs(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    """Two memories should produce one pair to evaluate."""
    mems = [_make_memory(seed=i) for i in range(3)]
    storage.get_top_memories_for_rem = AsyncMock(return_value=mems)
    report = await engine._rem_recombination(session_memories=[])
    # With 3 memories, up to 3 pairs exist (C(3,2)=3)
    assert report.pairs_evaluated >= 0


@pytest.mark.asyncio
async def test_rem_resonance_filter(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    """Identical embeddings (sim=1.0) should be filtered out by resonance window."""
    emb = np.ones(16, dtype=np.float32)
    emb = emb / np.linalg.norm(emb)
    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = emb.tolist()
    m2.embedding = emb.tolist()  # identical → sim=1.0 > rem_resonance_max
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])
    report = await engine._rem_recombination(session_memories=[])
    assert report.pairs_evaluated >= 1
    assert report.syntheses_attempted == 0  # filtered out by resonance


@pytest.mark.asyncio
async def test_rem_orthogonal_embeddings_filtered(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    """Orthogonal embeddings (sim≈0) should be filtered out by resonance window."""
    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    emb1 = np.zeros(16, dtype=np.float32)
    emb1[0] = 1.0
    emb2 = np.zeros(16, dtype=np.float32)
    emb2[1] = 1.0
    m1.embedding = emb1.tolist()
    m2.embedding = emb2.tolist()  # orthogonal → sim=0 < rem_resonance_min
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])
    report = await engine._rem_recombination(session_memories=[])
    assert report.pairs_evaluated >= 1
    assert report.syntheses_attempted == 0


@pytest.mark.asyncio
async def test_rem_stores_coherent_synthesis(
    engine: DreamingEngine,
    storage: AsyncMock,
    llm: AsyncMock,
    embeddings: AsyncMock,
) -> None:
    """When resonance is in window and coherence is high, a synthesis should be stored."""
    rng = np.random.default_rng(42)
    base = rng.standard_normal(16).astype(np.float32)
    base = base / np.linalg.norm(base)

    # Create two memories with moderate similarity (in the 0.3–0.7 window)
    noise = rng.standard_normal(16).astype(np.float32) * 0.6
    m1_emb = base
    m2_emb = base + noise
    m2_emb = m2_emb / np.linalg.norm(m2_emb)

    sim = float(np.dot(m1_emb, m2_emb) / (np.linalg.norm(m1_emb) * np.linalg.norm(m2_emb)))

    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = m1_emb.tolist()
    m2.embedding = m2_emb.tolist()

    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])

    # Make synthesis embedding close to both parents → high coherence
    synth_emb = (m1_emb + m2_emb) / 2
    synth_emb = synth_emb / np.linalg.norm(synth_emb)
    embeddings.embed = AsyncMock(return_value=synth_emb)

    report = await engine._rem_recombination(session_memories=[])

    if 0.3 < sim < 0.7:
        assert report.syntheses_attempted >= 1
        assert report.syntheses_stored >= 1
        storage.store_memory.assert_called()
    # If sim is outside window, that's fine — no synthesis attempted


@pytest.mark.asyncio
async def test_rem_discards_low_coherence(
    engine: DreamingEngine,
    storage: AsyncMock,
    llm: AsyncMock,
    embeddings: AsyncMock,
) -> None:
    """When coherence is below threshold, synthesis should be discarded."""
    rng = np.random.default_rng(42)
    base = rng.standard_normal(16).astype(np.float32)
    base = base / np.linalg.norm(base)

    noise = rng.standard_normal(16).astype(np.float32) * 0.6
    m1_emb = base
    m2_emb = base + noise
    m2_emb = m2_emb / np.linalg.norm(m2_emb)

    sim = float(np.dot(m1_emb, m2_emb) / (np.linalg.norm(m1_emb) * np.linalg.norm(m2_emb)))

    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = m1_emb.tolist()
    m2.embedding = m2_emb.tolist()

    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])

    # Return an embedding far from both parents → low coherence
    random_emb = rng.standard_normal(16).astype(np.float32)
    random_emb = -base  # opposite direction → very low coherence
    random_emb = random_emb / np.linalg.norm(random_emb)
    embeddings.embed = AsyncMock(return_value=random_emb)

    report = await engine._rem_recombination(session_memories=[])

    if 0.3 < sim < 0.7:
        assert report.syntheses_attempted >= 1
        assert report.syntheses_stored == 0
        assert report.syntheses_discarded >= 1


@pytest.mark.asyncio
async def test_rem_handles_llm_failure(
    engine: DreamingEngine,
    storage: AsyncMock,
    llm: AsyncMock,
) -> None:
    """LLM failure during synthesis should not crash the engine."""
    rng = np.random.default_rng(42)
    base = rng.standard_normal(16).astype(np.float32)
    base = base / np.linalg.norm(base)
    noise = rng.standard_normal(16).astype(np.float32) * 0.6
    m1_emb = base
    m2_emb = (base + noise)
    m2_emb = m2_emb / np.linalg.norm(m2_emb)

    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = m1_emb.tolist()
    m2.embedding = m2_emb.tolist()
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])
    llm.complete = AsyncMock(side_effect=Exception("LLM unavailable"))

    report = await engine._rem_recombination(session_memories=[])
    # Should not crash; failures are handled
    assert isinstance(report, REMReport)


@pytest.mark.asyncio
async def test_rem_empty_synthesis_discarded(
    engine: DreamingEngine,
    storage: AsyncMock,
    llm: AsyncMock,
) -> None:
    """Empty synthesis text should be discarded."""
    rng = np.random.default_rng(42)
    base = rng.standard_normal(16).astype(np.float32)
    base = base / np.linalg.norm(base)
    noise = rng.standard_normal(16).astype(np.float32) * 0.6
    m1_emb = base
    m2_emb = (base + noise)
    m2_emb = m2_emb / np.linalg.norm(m2_emb)

    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = m1_emb.tolist()
    m2.embedding = m2_emb.tolist()
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])
    llm.complete = AsyncMock(return_value="   ")  # whitespace only

    report = await engine._rem_recombination(session_memories=[])
    assert report.syntheses_stored == 0


@pytest.mark.asyncio
async def test_rem_synthesis_stored_as_probation(
    engine: DreamingEngine,
    storage: AsyncMock,
    llm: AsyncMock,
    embeddings: AsyncMock,
) -> None:
    """Stored syntheses should have PROBATION lifecycle."""
    rng = np.random.default_rng(42)
    base = rng.standard_normal(16).astype(np.float32)
    base = base / np.linalg.norm(base)
    noise = rng.standard_normal(16).astype(np.float32) * 0.6
    m1_emb = base
    m2_emb = (base + noise)
    m2_emb = m2_emb / np.linalg.norm(m2_emb)
    sim = float(np.dot(m1_emb, m2_emb) / (np.linalg.norm(m1_emb) * np.linalg.norm(m2_emb)))

    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = m1_emb.tolist()
    m2.embedding = m2_emb.tolist()
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])

    # High coherence embedding
    synth_emb = (m1_emb + m2_emb) / 2
    synth_emb = synth_emb / np.linalg.norm(synth_emb)
    embeddings.embed = AsyncMock(return_value=synth_emb)

    await engine._rem_recombination(session_memories=[])

    if 0.3 < sim < 0.7 and storage.store_memory.called:
        stored_mem = storage.store_memory.call_args[0][0]
        assert stored_mem.lifecycle == LifecycleStatus.PROBATION
        assert stored_mem.origin == "rem_synthesis"


@pytest.mark.asyncio
async def test_rem_skips_memories_without_embedding(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    """Memories with no embedding should be skipped."""
    m1 = _make_memory(seed=0)
    m2 = _make_memory(seed=1)
    m1.embedding = None  # type: ignore[assignment]
    storage.get_top_memories_for_rem = AsyncMock(return_value=[m1, m2])
    report = await engine._rem_recombination(session_memories=[])
    assert report.syntheses_attempted == 0


@pytest.mark.asyncio
async def test_rem_get_top_memories_failure(
    engine: DreamingEngine,
    storage: AsyncMock,
) -> None:
    """Failure in get_top_memories_for_rem should not crash."""
    storage.get_top_memories_for_rem = AsyncMock(side_effect=Exception("DB error"))
    report = await engine._rem_recombination(session_memories=[])
    assert isinstance(report, REMReport)
    assert report.pairs_evaluated == 0


# ---------------------------------------------------------------------------
# dawn_reset
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dawn_reset_does_not_crash(engine: DreamingEngine) -> None:
    await engine._dawn_reset()


# ---------------------------------------------------------------------------
# _cosine_sim helper
# ---------------------------------------------------------------------------


def test_cosine_sim_identical_vectors() -> None:
    v = np.array([1.0, 2.0, 3.0])
    assert abs(_cosine_sim(v, v) - 1.0) < 1e-6


def test_cosine_sim_orthogonal_vectors() -> None:
    a = np.array([1.0, 0.0])
    b = np.array([0.0, 1.0])
    assert abs(_cosine_sim(a, b)) < 1e-6


def test_cosine_sim_opposite_vectors() -> None:
    a = np.array([1.0, 0.0])
    b = np.array([-1.0, 0.0])
    assert abs(_cosine_sim(a, b) - (-1.0)) < 1e-6


def test_cosine_sim_zero_vector() -> None:
    a = np.array([0.0, 0.0])
    b = np.array([1.0, 2.0])
    assert _cosine_sim(a, b) == 0.0


# ---------------------------------------------------------------------------
# Data class structure
# ---------------------------------------------------------------------------


def test_slow_wave_report_fields() -> None:
    r = SlowWaveReport(edges_decayed=10, edges_pruned=2, edges_remaining=8, bandits_downscaled=True)
    assert r.edges_decayed == 10
    assert r.edges_pruned == 2
    assert r.edges_remaining == 8
    assert r.bandits_downscaled is True


def test_rem_report_fields() -> None:
    r = REMReport(pairs_evaluated=5, syntheses_attempted=3, syntheses_stored=2, syntheses_discarded=1)
    assert r.pairs_evaluated == 5
    assert r.syntheses_attempted == 3
    assert r.syntheses_stored == 2
    assert r.syntheses_discarded == 1


def test_dream_report_fields() -> None:
    sw = SlowWaveReport(edges_decayed=0, edges_pruned=0, edges_remaining=0, bandits_downscaled=False)
    rem = REMReport(pairs_evaluated=0, syntheses_attempted=0, syntheses_stored=0, syntheses_discarded=0)
    r = DreamReport(slow_wave=sw, rem=rem, duration_seconds=1.5)
    assert r.duration_seconds == 1.5
    assert isinstance(r.slow_wave, SlowWaveReport)
    assert isinstance(r.rem, REMReport)


# ---------------------------------------------------------------------------
# Issue #9 — REM calls complete() not generate(); no .tolist() on list
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_rem_synthesis_calls_complete_with_delimiters(
    cfg: FractalConfig,
    storage: AsyncMock,
    associations: AsyncMock,
    bandits: MagicMock,
) -> None:
    """REM must call complete() with <memory_a>/<memory_b> XML delimiters."""
    llm = AsyncMock()
    llm.complete = AsyncMock(return_value="Combined insight about X and Y")
    embeddings = AsyncMock()
    # Create memories with cosine sim ~0.5 (within resonance range 0.3-0.7 exclusive)
    # cos(60°) = 0.5 — use orthogonal-ish vectors
    emb_a = np.zeros(16, dtype=np.float32)
    emb_a[0] = 1.0
    emb_b = np.zeros(16, dtype=np.float32)
    emb_b[0] = 0.5
    emb_b[1] = np.sqrt(0.75)  # cos(θ) = 0.5
    emb_a = (emb_a / np.linalg.norm(emb_a)).tolist()
    emb_b = (emb_b / np.linalg.norm(emb_b)).tolist()
    mem_a = _make_memory(seed=0)
    mem_b = _make_memory(seed=1)
    mem_a = Memory(**{**mem_a.__dict__, "embedding": emb_a})
    mem_b = Memory(**{**mem_b.__dict__, "embedding": emb_b})
    storage.get_top_memories_for_rem = AsyncMock(return_value=[mem_a, mem_b])
    synth_emb = emb_a  # high coherence
    embeddings.embed = AsyncMock(return_value=synth_emb)
    engine = DreamingEngine(
        storage=storage, associations=associations, embeddings=embeddings,
        llm=llm, config=cfg, bandits=bandits,
    )
    await engine._rem_recombination([mem_a.id, mem_b.id])
    llm.complete.assert_called()
    call_kwargs = llm.complete.call_args
    prompt = call_kwargs.kwargs.get("prompt") or call_kwargs.args[0]
    assert "<memory_a>" in prompt
    assert "<memory_b>" in prompt
    assert "max_tokens" in str(call_kwargs)


@pytest.mark.asyncio
async def test_rem_synthesis_stores_embedding_as_list(
    cfg: FractalConfig,
    storage: AsyncMock,
    associations: AsyncMock,
    bandits: MagicMock,
) -> None:
    """Stored synthesis embedding must be a list, not ndarray."""
    llm = AsyncMock()
    llm.complete = AsyncMock(return_value="Combined insight about X and Y")
    embeddings = AsyncMock()
    # Create memories with cosine sim ~0.5 (within resonance range 0.3-0.7 exclusive)
    emb_a = np.zeros(16, dtype=np.float32)
    emb_a[0] = 1.0
    emb_b = np.zeros(16, dtype=np.float32)
    emb_b[0] = 0.5
    emb_b[1] = np.sqrt(0.75)
    emb_a_list = (emb_a / np.linalg.norm(emb_a)).tolist()
    emb_b_list = (emb_b / np.linalg.norm(emb_b)).tolist()
    mem_a = _make_memory(seed=0)
    mem_b = _make_memory(seed=1)
    mem_a = Memory(**{**mem_a.__dict__, "embedding": emb_a_list})
    mem_b = Memory(**{**mem_b.__dict__, "embedding": emb_b_list})
    synth_emb = emb_a_list  # high coherence
    embeddings.embed = AsyncMock(return_value=synth_emb)
    storage.get_top_memories_for_rem = AsyncMock(return_value=[mem_a, mem_b])
    engine = DreamingEngine(
        storage=storage, associations=associations, embeddings=embeddings,
        llm=llm, config=cfg, bandits=bandits,
    )
    await engine._rem_recombination([mem_a.id, mem_b.id])
    if storage.store_memory.called:
        stored_mem = storage.store_memory.call_args.args[0]
        assert isinstance(stored_mem.embedding, list)


# ---------------------------------------------------------------------------
# Issue #31 — DreamReport.dawn type
# ---------------------------------------------------------------------------


def test_dream_report_dawn_defaults_to_none() -> None:
    from fractal_memory.dreaming import DawnReport
    sw = SlowWaveReport(edges_decayed=0, edges_pruned=0, edges_remaining=0, bandits_downscaled=False)
    rem = REMReport(pairs_evaluated=0, syntheses_attempted=0, syntheses_stored=0, syntheses_discarded=0)
    report = DreamReport(slow_wave=sw, rem=rem)
    assert report.dawn is None
    dawn_instance = DawnReport(memories_rezoomed=5)
    report2 = DreamReport(slow_wave=sw, rem=rem, dawn=dawn_instance)
    assert isinstance(report2.dawn, DawnReport)
    assert report2.dawn.memories_rezoomed == 5
