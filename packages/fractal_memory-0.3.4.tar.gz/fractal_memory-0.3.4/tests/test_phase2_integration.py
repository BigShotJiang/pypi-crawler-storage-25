"""Phase 2 integration tests — full store/retrieve/session cycles with Phase 2 modules."""

from __future__ import annotations

from unittest.mock import AsyncMock
from uuid import UUID

import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig


# ---------------------------------------------------------------------------
# store + retrieve round trip
# ---------------------------------------------------------------------------


async def test_store_and_retrieve_returns_result(fractal_memory: FractalMemory):
    await fractal_memory.session_start("integration")
    mem = await fractal_memory.store("The sky is blue.", domain="integration", intensity=0.7)
    assert mem is not None, "Memory should pass the gate with EXPLICIT_STORE signal"
    result = await fractal_memory.retrieve("sky color", domain="integration")
    assert result is not None
    # At least L1 should contain the stored memory
    all_mems = result.l1_memories + result.l2_memories + result.l3_memories
    assert len(all_mems) >= 1, "At least the stored memory should appear in results"
    all_ids = {m.id for m in all_mems}
    assert mem.id in all_ids, "The stored memory should be retrievable"


async def test_store_multiple_then_retrieve(fractal_memory: FractalMemory):
    await fractal_memory.session_start("multi")
    for i in range(5):
        await fractal_memory.store(f"Memory number {i}", domain="multi")
    result = await fractal_memory.retrieve("number", domain="multi")
    assert result is not None


# ---------------------------------------------------------------------------
# correct() + confirm()
# ---------------------------------------------------------------------------


async def test_correct_memory_creates_scar(fractal_memory: FractalMemory):
    await fractal_memory.session_start("feedback")
    mem = await fractal_memory.store("Old information about config.", domain="feedback")
    if mem is None:
        pytest.skip("Memory gated out")

    corrected = await fractal_memory.correct(mem.id, "Updated config information.")
    assert corrected is not None

    # Verify a scar was created for the correction pattern
    active_scars = await fractal_memory._scars.get_active_scars()
    assert len(active_scars) >= 1, "Correction should have created a scar"
    scar_reasons = [s.reason for s in active_scars]
    assert any("Correction" in r for r in scar_reasons), (
        "Scar reason should reference the correction"
    )


async def test_confirm_memory_increments_retrieval_count(fractal_memory: FractalMemory):
    await fractal_memory.session_start("confirm-domain")
    mem = await fractal_memory.store("User prefers dark mode.", domain="confirm-domain")
    if mem is None:
        pytest.skip("Memory gated out")

    count_before = mem.retrieval_count
    await fractal_memory.confirm(mem.id)
    updated = await fractal_memory.get(mem.id)
    assert updated is not None
    assert updated.retrieval_count >= count_before


# ---------------------------------------------------------------------------
# session_start and session_end
# ---------------------------------------------------------------------------


async def test_session_start_returns_context(fractal_memory: FractalMemory):
    ctx = await fractal_memory.session_start("session-test")
    assert ctx.session is not None
    assert ctx.session.domain == "session-test"


async def test_session_end_returns_summary(fractal_memory: FractalMemory):
    await fractal_memory.session_start("end-test")
    await fractal_memory.store("Some content.", domain="end-test")
    summary = await fractal_memory.session_end()
    assert summary is not None
    assert summary.session_id is not None
    assert summary.duration_seconds >= 0


async def test_multiple_session_cycles(fractal_memory: FractalMemory):
    for i in range(3):
        await fractal_memory.session_start("cycle")
        await fractal_memory.store(f"Cycle {i} content", domain="cycle")
        summary = await fractal_memory.session_end()
        assert summary is not None


# ---------------------------------------------------------------------------
# Feedback signals through retrieve with user_message
# ---------------------------------------------------------------------------


async def test_retrieve_with_correction_user_message(fractal_memory: FractalMemory):
    await fractal_memory.session_start("danger-test")
    mem = await fractal_memory.store("Wrong information.", domain="danger-test")
    if mem is None:
        pytest.skip("Memory gated out")

    # This user_message should trigger a danger signal
    result = await fractal_memory.retrieve(
        "wrong info",
        domain="danger-test",
        user_message="No, that's wrong.",
    )
    assert result is not None  # should not crash


async def test_retrieve_with_confirmation_user_message(fractal_memory: FractalMemory):
    await fractal_memory.session_start("safety-test")
    await fractal_memory.store("Correct fact.", domain="safety-test")
    result = await fractal_memory.retrieve(
        "correct fact",
        domain="safety-test",
        user_message="Yes, exactly right!",
    )
    assert result is not None


# ---------------------------------------------------------------------------
# pin / unpin
# ---------------------------------------------------------------------------


async def test_pin_promotes_to_permanent(fractal_memory: FractalMemory):
    await fractal_memory.session_start("pin-test")
    mem = await fractal_memory.store("Important fact.", domain="pin-test")
    if mem is None:
        pytest.skip("Memory gated out")

    await fractal_memory.pin(mem.id)
    updated = await fractal_memory.get(mem.id)
    assert updated is not None
    from fractal_memory.models import LifecycleStatus
    assert updated.lifecycle == LifecycleStatus.PERMANENT


async def test_unpin_reverts_to_confirmed(fractal_memory: FractalMemory):
    await fractal_memory.session_start("unpin-test")
    mem = await fractal_memory.store("Pinned fact.", domain="unpin-test")
    if mem is None:
        pytest.skip("Memory gated out")

    await fractal_memory.pin(mem.id)
    await fractal_memory.unpin(mem.id)
    updated = await fractal_memory.get(mem.id)
    assert updated is not None
    from fractal_memory.models import LifecycleStatus
    assert updated.lifecycle == LifecycleStatus.CONFIRMED


# ---------------------------------------------------------------------------
# get_stats includes Phase 2 fields
# ---------------------------------------------------------------------------


async def test_get_stats_includes_associations(fractal_memory: FractalMemory):
    await fractal_memory.session_start("stats-test")
    stats = await fractal_memory.get_stats()
    assert "associations" in stats
    assert "edge_count" in stats["associations"]


async def test_get_stats_includes_scars(fractal_memory: FractalMemory):
    stats = await fractal_memory.get_stats()
    assert "scars" in stats


# ---------------------------------------------------------------------------
# list_domains
# ---------------------------------------------------------------------------


async def test_list_domains_after_storing(fractal_memory: FractalMemory):
    await fractal_memory.session_start("dom-list")
    await fractal_memory.store("Content in dom-list.", domain="dom-list")
    domains = await fractal_memory.list_domains()
    domain_names = {d.name for d in domains}
    assert "dom-list" in domain_names


# ---------------------------------------------------------------------------
# delete memory
# ---------------------------------------------------------------------------


async def test_delete_memory(fractal_memory: FractalMemory):
    await fractal_memory.session_start("delete-test")
    mem = await fractal_memory.store("Temporary memory.", domain="delete-test")
    if mem is None:
        pytest.skip("Memory gated out")

    deleted = await fractal_memory.delete(mem.id)
    assert deleted is True
    fetched = await fractal_memory.get(mem.id)
    assert fetched is None


async def test_delete_memory_cleans_association_edges(fractal_memory: FractalMemory):
    """Deleting a memory must remove its association edges to prevent orphan references."""
    await fractal_memory.session_start("edge-cleanup")
    mem_a = await fractal_memory.store("Memory A about Python.", domain="edge-cleanup")
    mem_b = await fractal_memory.store("Memory B about Python.", domain="edge-cleanup")
    if mem_a is None or mem_b is None:
        pytest.skip("Memories gated out")

    # Manually create an association edge
    await fractal_memory._associations.on_co_retrieval([mem_a.id, mem_b.id], zoom_level=3)
    edges_before = await fractal_memory._storage.get_associations(mem_a.id)
    assert len(edges_before) >= 1, "Edge should exist before deletion"

    # Delete mem_a — all its edges should be cleaned up
    await fractal_memory.delete(mem_a.id)

    edges_after = await fractal_memory._storage.get_associations(mem_a.id)
    assert len(edges_after) == 0, "Edges referencing deleted memory must be removed"

    # Verify mem_b still exists and has no edges pointing to mem_a
    edges_b = await fractal_memory._storage.get_associations(mem_b.id)
    referencing_deleted = [e for e in edges_b if e[0] == mem_a.id]
    assert len(referencing_deleted) == 0, "No edges should reference the deleted memory"


async def test_delete_memory_clears_association_edges_both_directions(fractal_memory: FractalMemory):
    """Edges are stored with source→target; deleting either endpoint should remove the edge."""
    await fractal_memory.session_start("edge-bidir")
    mem_a = await fractal_memory.store("Fact about deployment.", domain="edge-bidir")
    mem_b = await fractal_memory.store("Fact about CI/CD.", domain="edge-bidir")
    if mem_a is None or mem_b is None:
        pytest.skip("Memories gated out")

    await fractal_memory._associations.on_co_retrieval([mem_a.id, mem_b.id], zoom_level=2)

    # Delete the target memory (mem_b)
    await fractal_memory.delete(mem_b.id)

    # No edges from mem_a should reference the deleted mem_b
    edges_a = await fractal_memory._storage.get_associations(mem_a.id)
    assert all(e[0] != mem_b.id for e in edges_a), (
        "Edges from A pointing to deleted B must be removed"
    )
