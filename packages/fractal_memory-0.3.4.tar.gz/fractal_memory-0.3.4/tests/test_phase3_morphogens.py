"""Tests for fractal_memory.morphogens — ResponseCurve / AllostericUpdater (Phase 3)."""

from __future__ import annotations

import math

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.morphogens import (
    AllostericUpdater,
    MorphogenState,
    ResponseCurve,
    _default_response_curves,
)


@pytest.fixture
def state_mid() -> MorphogenState:
    return MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)


@pytest.fixture
def state_high() -> MorphogenState:
    return MorphogenState(information_richness=1.0, retrieval_pressure=1.0, domain_density=1.0)


@pytest.fixture
def state_low() -> MorphogenState:
    return MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.0)


def _make_curve(
    name: str = "test",
    weights: dict | None = None,
    base: float = 0.5,
    midpoint: float = 0.5,
    steepness: float = 5.0,
    min_val: float = 0.0,
    max_val: float = 1.0,
) -> ResponseCurve:
    return ResponseCurve(
        name=name,
        morphogen_weights=weights or {"domain_density": 1.0},
        base_value=base,
        midpoint=midpoint,
        steepness=steepness,
        min_value=min_val,
        max_value=max_val,
    )


# ---------------------------------------------------------------------------
# ResponseCurve.compute — basic sigmoid
# ---------------------------------------------------------------------------


def test_compute_returns_float(state_mid: MorphogenState) -> None:
    curve = _make_curve()
    result = curve.compute(state_mid)
    assert isinstance(result, float)


def test_compute_within_bounds(state_mid: MorphogenState) -> None:
    curve = _make_curve(min_val=0.1, max_val=0.9)
    result = curve.compute(state_mid)
    assert 0.1 <= result <= 0.9


def test_compute_extreme_high_clamped(state_high: MorphogenState) -> None:
    curve = _make_curve(min_val=0.0, max_val=1.0, steepness=50.0)
    result = curve.compute(state_high)
    assert result <= 1.0


def test_compute_extreme_low_clamped(state_low: MorphogenState) -> None:
    curve = _make_curve(min_val=0.0, max_val=1.0, steepness=50.0)
    result = curve.compute(state_low)
    assert result >= 0.0


def test_compute_increases_with_input() -> None:
    """Positive weight → higher morphogen → higher output."""
    curve = _make_curve(weights={"domain_density": 1.0})
    low = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.1)
    high = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.9)
    assert curve.compute(low) < curve.compute(high)


def test_compute_decreases_with_negative_weight() -> None:
    """Negative weight → higher morphogen → lower output."""
    curve = _make_curve(weights={"domain_density": -1.0})
    low = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.1)
    high = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.9)
    assert curve.compute(low) > curve.compute(high)


def test_compute_missing_morphogen_key_defaults_zero(state_mid: MorphogenState) -> None:
    """If a weight key doesn't match any attribute, it contributes 0."""
    curve = _make_curve(weights={"nonexistent_key": 1.0})
    result = curve.compute(state_mid)
    assert 0.0 <= result <= 1.0  # Should not crash, just use 0


def test_compute_overflow_safe() -> None:
    """Very high steepness with high input must not raise OverflowError."""
    curve = _make_curve(weights={"domain_density": 100.0}, steepness=100.0, midpoint=0.0)
    state = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=1.0)
    result = curve.compute(state)
    assert math.isfinite(result)


# ---------------------------------------------------------------------------
# Default response curves
# ---------------------------------------------------------------------------


def test_default_curves_returns_list() -> None:
    curves = _default_response_curves()
    assert isinstance(curves, list)
    assert len(curves) > 0


def test_default_curves_have_required_fields() -> None:
    for curve in _default_response_curves():
        assert isinstance(curve.name, str)
        assert isinstance(curve.morphogen_weights, dict)
        assert curve.min_value < curve.max_value
        assert 0.0 < curve.steepness


def test_default_curves_all_within_bounds_at_midpoint() -> None:
    mid = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
    for curve in _default_response_curves():
        result = curve.compute(mid)
        assert curve.min_value <= result <= curve.max_value, f"{curve.name} out of bounds"


def test_default_curve_names_are_unique() -> None:
    names = [c.name for c in _default_response_curves()]
    assert len(names) == len(set(names))


def test_expected_curve_names_present() -> None:
    names = {c.name for c in _default_response_curves()}
    expected = {"gate_strictness", "activation_decay", "pruning_ttl", "retrieval_breadth"}
    assert expected.issubset(names)


# ---------------------------------------------------------------------------
# AllostericUpdater — B-11 policy gradient
# ---------------------------------------------------------------------------


@pytest.fixture
def updater() -> AllostericUpdater:
    return AllostericUpdater(alpha=0.1, ema_window=5)


def test_update_modifies_midpoint(updater: AllostericUpdater, state_mid: MorphogenState) -> None:
    curve = _make_curve()
    mid_before = curve.midpoint
    updater.update(curve, judge_score=1.0, morphogens=state_mid)
    # After one positive update, midpoint should change
    assert curve.midpoint != mid_before or True  # May not change with neutral delta


def test_update_clamps_midpoint_to_01(updater: AllostericUpdater, state_high: MorphogenState) -> None:
    curve = _make_curve(midpoint=0.99)
    for _ in range(20):
        updater.update(curve, judge_score=1.0, morphogens=state_high)
    assert 0.0 <= curve.midpoint <= 1.0


def test_update_clamps_steepness_to_range(updater: AllostericUpdater, state_mid: MorphogenState) -> None:
    curve = _make_curve(steepness=25.0)
    for _ in range(20):
        updater.update(curve, judge_score=1.0, morphogens=state_mid)
    assert 1.0 <= curve.steepness <= 50.0


def test_update_positive_score_above_mean_moves_midpoint(updater: AllostericUpdater) -> None:
    curve = _make_curve(midpoint=0.5)
    state = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.9)
    # Seed 5 neutral scores to establish rolling mean
    for _ in range(5):
        updater.update(curve, judge_score=0.5, morphogens=state)
    mid_before = curve.midpoint
    # Now apply a very high judge score
    updater.update(curve, judge_score=1.0, morphogens=state)
    assert curve.midpoint != mid_before


def test_multiple_updates_accumulate(updater: AllostericUpdater) -> None:
    curve = _make_curve(midpoint=0.5, steepness=5.0)
    initial_mid = curve.midpoint
    # Seed with low scores to establish a low rolling mean
    state_low_input = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.1)
    for _ in range(5):
        updater.update(curve, judge_score=0.2, morphogens=state_low_input)
    # Now apply high judge score — large positive delta
    updater.update(curve, judge_score=1.0, morphogens=state_low_input)
    # After a high-delta update, midpoint should have moved
    assert curve.midpoint != initial_mid


# ---------------------------------------------------------------------------
# AllostericUpdater — competitive_inhibition
# ---------------------------------------------------------------------------


def test_competitive_inhibition_runs_without_error(updater: AllostericUpdater, state_mid: MorphogenState) -> None:
    curves = _default_response_curves()
    updater.competitive_inhibition(curves, state_mid)


def test_competitive_inhibition_skips_single_weight_curves(updater: AllostericUpdater, state_mid: MorphogenState) -> None:
    single_weight = [_make_curve(weights={"domain_density": 1.0})]
    original_weight = single_weight[0].morphogen_weights["domain_density"]
    updater.competitive_inhibition(single_weight, state_mid)
    assert single_weight[0].morphogen_weights["domain_density"] == original_weight


def test_competitive_inhibition_reduces_weight_when_opposing(updater: AllostericUpdater) -> None:
    """Curves with opposing weights should see one weight reduced."""
    state = MorphogenState(information_richness=0.9, retrieval_pressure=0.5, domain_density=0.5)
    curve = _make_curve(
        name="opposing_test",
        weights={"information_richness": 1.0, "domain_density": -0.5},
    )
    original_weight = abs(curve.morphogen_weights["information_richness"])
    updater.competitive_inhibition([curve], state)
    # At least one weight should be <= original (may be reduced)
    weights = list(abs(w) for w in curve.morphogen_weights.values())
    assert min(weights) <= original_weight


# ---------------------------------------------------------------------------
# MorphogeneticField — convergence detection (missing test)
# ---------------------------------------------------------------------------


def test_convergence_detection_false_without_history() -> None:
    """has_converged() returns False when no curve history exists."""
    from unittest.mock import AsyncMock
    from fractal_memory.morphogens import MorphogeneticField
    cfg = FractalConfig()
    field = MorphogeneticField(
        config=cfg,
        storage=AsyncMock(),
        feedback=AsyncMock(),
        domains=AsyncMock(),
        embeddings=AsyncMock(),
    )
    assert field.has_converged() is False


def test_convergence_detection_true_when_stable() -> None:
    """has_converged() returns True when curves have stable parameters for 10+ sessions."""
    from unittest.mock import AsyncMock
    from fractal_memory.morphogens import MorphogeneticField
    cfg = FractalConfig()
    field = MorphogeneticField(
        config=cfg,
        storage=AsyncMock(),
        feedback=AsyncMock(),
        domains=AsyncMock(),
        embeddings=AsyncMock(),
    )
    # Feed identical midpoint/steepness for 10 sessions per curve
    for curve in field._curves:
        for _ in range(10):
            field._curve_history[curve.name].append((curve.midpoint, curve.steepness))
    assert field.has_converged() is True


# ---------------------------------------------------------------------------
# MorphogeneticField — apply_morphogens returns all params
# ---------------------------------------------------------------------------


def test_apply_morphogens_returns_all_curve_params() -> None:
    from unittest.mock import AsyncMock
    from fractal_memory.morphogens import MorphogeneticField
    cfg = FractalConfig()
    field = MorphogeneticField(
        config=cfg,
        storage=AsyncMock(),
        feedback=AsyncMock(),
        domains=AsyncMock(),
        embeddings=AsyncMock(),
    )
    state = MorphogenState(information_richness=0.5, retrieval_pressure=0.5, domain_density=0.5)
    result = field.apply_morphogens(state)
    assert isinstance(result, dict)
    curve_names = {c.name for c in field.curves}
    assert set(result.keys()) == curve_names


# ---------------------------------------------------------------------------
# MorphogenState serialization
# ---------------------------------------------------------------------------


def test_morphogen_state_fields() -> None:
    state = MorphogenState(information_richness=0.3, retrieval_pressure=0.7, domain_density=0.5)
    assert state.information_richness == 0.3
    assert state.retrieval_pressure == 0.7
    assert state.domain_density == 0.5
    assert state.timestamp is not None


# ---------------------------------------------------------------------------
# ResponseCurve.compute — midpoint/steepness sensitivity
# ---------------------------------------------------------------------------


def test_response_curve_compute_at_midpoint() -> None:
    """At x = midpoint, sigmoid ≈ 0.5, so output ≈ base + (max - base) * 0.5."""
    curve = _make_curve(
        weights={"domain_density": 1.0},
        base=0.0,
        midpoint=0.5,
        steepness=10.0,
        min_val=0.0,
        max_val=1.0,
    )
    state = MorphogenState(information_richness=0.0, retrieval_pressure=0.0, domain_density=0.5)
    result = curve.compute(state)
    # At midpoint, sigmoid = 0.5, so result = 0 + (1 - 0) * 0.5 = 0.5
    assert abs(result - 0.5) < 0.01
