"""Health report truth tests — every HealthReport field matches ground truth from storage.

Verifies that the SelfModel health report accurately reflects the actual state
of the storage layer, associations, scars, and other subsystems.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.self_model import HealthReport


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Fixtures ───────────────────────────────────────────────────────────

def _make_mock_llm():
    provider = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Health truth test summary."
        return json.dumps({
            "l0_tag": "health:truth",
            "l1_label": "health-test",
            "l2_summary": "Health truth test memory.",
            "l3_full": "Health truth test memory full context.",
        })
    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()
    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)
    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]
    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def health_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "health_truth.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,
    )


@pytest.fixture
async def health_fm(health_config: FractalConfig):
    fm = FractalMemory(health_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ── Empty system health ──────────────────────────────────────────────


class TestEmptySystemHealth:
    @pytest.mark.asyncio
    async def test_empty_system_retrieval_hit_rate_zero(self, health_fm: FractalMemory):
        """Empty system should have retrieval_hit_rate = 0."""
        report = await health_fm.health()
        assert report.retrieval_hit_rate == 0.0

    @pytest.mark.asyncio
    async def test_empty_system_scar_count_zero(self, health_fm: FractalMemory):
        """Empty system should have scar_count = 0."""
        report = await health_fm.health()
        assert report.scar_count == 0

    @pytest.mark.asyncio
    async def test_empty_system_chronic_count_zero(self, health_fm: FractalMemory):
        """Empty system should have chronic_memories_count = 0."""
        report = await health_fm.health()
        assert report.chronic_memories_count == 0

    @pytest.mark.asyncio
    async def test_empty_system_association_density_zero(self, health_fm: FractalMemory):
        """Empty system should have association_density = 0."""
        report = await health_fm.health()
        assert report.association_density == 0.0


# ── Health after stores ──────────────────────────────────────────────


class TestHealthAfterStores:
    @pytest.mark.asyncio
    async def test_total_memories_matches_storage(self, health_fm: FractalMemory):
        """HealthReport.total_memories should match actual storage count."""
        await health_fm.session_start("truth")
        for i in range(5):
            await health_fm.store(f"Health truth memory {i}")
        await health_fm.session_end()

        report = await health_fm.health()
        actual_count = await health_fm._storage.count_memories()

        # total_memories is per-domain dict — sum should match storage
        report_total = sum(report.total_memories.values())
        assert report_total == actual_count, (
            f"HealthReport total_memories ({report_total}) doesn't match "
            f"storage count ({actual_count})"
        )

    @pytest.mark.asyncio
    async def test_system_state_valid(self, health_fm: FractalMemory):
        """system_state should be one of the known states."""
        report = await health_fm.health()
        assert report.system_state in ("flow", "stress", "curiosity")


# ── Health report field types ────────────────────────────────────────


class TestHealthFieldTypes:
    @pytest.mark.asyncio
    async def test_retrieval_hit_rate_bounded(self, health_fm: FractalMemory):
        """retrieval_hit_rate should be in [0, 1]."""
        report = await health_fm.health()
        assert 0.0 <= report.retrieval_hit_rate <= 1.0

    @pytest.mark.asyncio
    async def test_freshness_bounded(self, health_fm: FractalMemory):
        """freshness should be in [0, 1]."""
        report = await health_fm.health()
        assert 0.0 <= report.freshness <= 1.0

    @pytest.mark.asyncio
    async def test_cascade_warnings_is_list(self, health_fm: FractalMemory):
        """cascade_warnings should be a list."""
        report = await health_fm.health()
        assert isinstance(report.cascade_warnings, list)

    @pytest.mark.asyncio
    async def test_flagged_parameters_is_list(self, health_fm: FractalMemory):
        """flagged_parameters should be a list of strings."""
        report = await health_fm.health()
        assert isinstance(report.flagged_parameters, list)
        for p in report.flagged_parameters:
            assert isinstance(p, str)

    @pytest.mark.asyncio
    async def test_morphogen_convergence_keys(self, health_fm: FractalMemory):
        """morphogen_convergence should have 'converged' and 'variance' keys."""
        report = await health_fm.health()
        assert "converged" in report.morphogen_convergence
        assert "variance" in report.morphogen_convergence
        assert isinstance(report.morphogen_convergence["converged"], bool)
