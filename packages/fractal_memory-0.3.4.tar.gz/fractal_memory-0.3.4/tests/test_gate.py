"""Tests for coincidence gate and waiting room."""

from datetime import datetime
from uuid import uuid4

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.gate import CoincidenceGate, GateDecision, Signal


async def test_single_signal_passes_pioneer(storage, mock_embeddings, tmp_config):
    """In Pioneer stage (threshold=1), a single signal passes the gate."""
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    decision = await gate.evaluate("test content", [Signal.EXPLICIT_STORE], "test")
    assert decision.passed is True
    assert Signal.EXPLICIT_STORE in decision.signals


async def test_no_signals_goes_to_waiting_room(storage, mock_embeddings):
    """With threshold=2, zero signals should fail (but we need to test threshold>signals)."""
    config = FractalConfig(gate_signal_count=2, db_path=storage._db_path)
    gate = CoincidenceGate(storage, mock_embeddings, config)
    decision = await gate.evaluate("test content", [Signal.NOVELTY], "test")
    assert decision.passed is False


async def test_two_signals_pass_threshold2(storage, mock_embeddings):
    config = FractalConfig(gate_signal_count=2, db_path=storage._db_path)
    gate = CoincidenceGate(storage, mock_embeddings, config)
    decision = await gate.evaluate(
        "test content",
        [Signal.EXPLICIT_STORE, Signal.EMPHASIS],
        "test",
    )
    assert decision.passed is True


async def test_intensity_computation(storage, mock_embeddings, tmp_config):
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    # EMPHASIS adds 0.20 to base 0.5
    decision = await gate.evaluate("test", [Signal.EMPHASIS], "test")
    assert decision.intensity == pytest.approx(0.7, abs=0.01)


async def test_intensity_explicit_store(storage, mock_embeddings, tmp_config):
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    decision = await gate.evaluate("test", [Signal.EXPLICIT_STORE], "test")
    assert decision.intensity == pytest.approx(0.65, abs=0.01)


async def test_intensity_multiple_signals(storage, mock_embeddings, tmp_config):
    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    decision = await gate.evaluate(
        "test",
        [Signal.EMPHASIS, Signal.EXPLICIT_STORE, Signal.NOVELTY],
        "test",
    )
    # 0.5 + 0.20 + 0.15 + 0.05 = 0.90
    assert decision.intensity == pytest.approx(0.9, abs=0.01)


async def test_waiting_room_expiry(storage, mock_embeddings, tmp_config):
    from fractal_memory.models import WaitingRoomEntry

    # Add entries with high sessions_elapsed
    for i in range(3):
        entry = WaitingRoomEntry(
            id=uuid4(),
            content=f"content {i}",
            first_signal={"type": "novelty"},
            domain="test",
            created_at=datetime.utcnow(),
            sessions_elapsed=5,
            embedding=[0.1] * 384,
        )
        await storage.store_waiting_room_entry(entry)

    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    expired = await gate.expire_waiting_room()
    assert expired == 3


async def test_waiting_room_not_expired(storage, mock_embeddings, tmp_config):
    from fractal_memory.models import WaitingRoomEntry

    entry = WaitingRoomEntry(
        id=uuid4(),
        content="content",
        first_signal={"type": "novelty"},
        domain="test",
        created_at=datetime.utcnow(),
        sessions_elapsed=1,
        embedding=[0.1] * 384,
    )
    await storage.store_waiting_room_entry(entry)

    gate = CoincidenceGate(storage, mock_embeddings, tmp_config)
    expired = await gate.expire_waiting_room()
    assert expired == 0


async def test_second_signal_promotes_from_waiting_room(storage, mock_embeddings):
    """With threshold=2, content matching a waiting room entry should promote."""
    from unittest.mock import AsyncMock
    from fractal_memory.models import WaitingRoomEntry
    import numpy as np

    config = FractalConfig(gate_signal_count=2, db_path=storage._db_path)

    # Create a fixed embedding that will be returned for all embed calls
    fixed_vec = np.random.RandomState(42).randn(384).astype(np.float32)
    fixed_vec = (fixed_vec / np.linalg.norm(fixed_vec)).tolist()

    # First: manually add an entry to the waiting room with the same embedding
    entry = WaitingRoomEntry(
        id=uuid4(),
        content="original content",
        first_signal={"type": "novelty"},
        domain="test",
        created_at=datetime.utcnow(),
        sessions_elapsed=0,
        embedding=fixed_vec,
    )
    await storage.store_waiting_room_entry(entry)

    # Mock embeddings to return the same vector (high cosine sim with waiting room entry)
    emb = AsyncMock()
    emb.embed = AsyncMock(return_value=fixed_vec)
    emb.model_name = "mock"
    emb.dimension = 384

    gate = CoincidenceGate(storage, emb, config)
    # Only 1 signal but matching waiting room entry → should promote
    decision = await gate.evaluate("similar content", [Signal.NOVELTY], "test")
    assert decision.passed is True
    assert decision.waiting_room_entry is not None
    assert decision.waiting_room_entry.id == entry.id

    # Waiting room entry should be deleted after promotion
    assert await storage.get_waiting_room_entry(entry.id) is None


async def test_waiting_room_semantic_matching(storage, mock_embeddings):
    """Cosine > 0.85 triggers waiting room match."""
    from fractal_memory.models import WaitingRoomEntry
    import numpy as np

    # Put an entry with a known embedding
    fixed_vec = [0.1] * 384
    norm = np.linalg.norm(fixed_vec)
    fixed_vec = [v / norm for v in fixed_vec]

    entry = WaitingRoomEntry(
        id=uuid4(),
        content="stored content",
        first_signal={"type": "novelty"},
        domain="test",
        created_at=datetime.utcnow(),
        sessions_elapsed=0,
        embedding=fixed_vec,
    )
    await storage.store_waiting_room_entry(entry)

    # Search with the same embedding → should match (cosine=1.0 > 0.85)
    found = await storage.find_waiting_room_by_content(fixed_vec, threshold=0.85)
    assert found is not None
    assert found.id == entry.id

    # Search with a very different embedding → should not match
    diff_vec = np.random.RandomState(999).randn(384).astype(np.float32)
    diff_vec = (diff_vec / np.linalg.norm(diff_vec)).tolist()
    not_found = await storage.find_waiting_room_by_content(diff_vec, threshold=0.85)
    assert not_found is None


async def test_waiting_room_max_size_eviction(storage, mock_embeddings):
    """Gate enforces waiting_room_max by evicting oldest entries."""
    config = FractalConfig(
        gate_signal_count=2,
        waiting_room_max=3,
        db_path=storage._db_path,
    )
    gate = CoincidenceGate(storage, mock_embeddings, config)

    # Add 5 entries via gate (each with only 1 signal, below threshold=2)
    for i in range(5):
        await gate.evaluate(f"unique content {i}", [Signal.NOVELTY], "test")

    # Should have been capped at 3
    from fractal_memory.models import WaitingRoomEntry
    conn = storage._ensure_conn()
    async with conn.execute("SELECT COUNT(*) FROM waiting_room") as cur:
        row = await cur.fetchone()
        count = row[0]
    assert count <= 3


# ---------------------------------------------------------------------------
# Issue #27: GateDecision includes embedding
# ---------------------------------------------------------------------------


async def test_gate_decision_includes_embedding_on_waiting_room_pass(
    storage, mock_embeddings, tmp_config,
):
    """Issue #27: When gate passes via waiting room, decision.embedding is populated."""
    config = FractalConfig(
        gate_signal_count=2,
        db_path=storage._db_path,
    )
    gate = CoincidenceGate(storage, mock_embeddings, config)

    # First call: 1 signal, goes to waiting room
    d1 = await gate.evaluate("hello world", [Signal.NOVELTY], "test")
    assert not d1.passed

    # Second call: same content, 1 signal, should promote from waiting room
    d2 = await gate.evaluate("hello world", [Signal.TOPIC_RELEVANCE], "test")
    assert d2.passed
    assert d2.embedding is not None
    assert isinstance(d2.embedding, list)
    assert len(d2.embedding) == 384


async def test_store_reuses_gate_embedding(fractal_memory):
    """Issue #27: store() reuses gate-computed embedding instead of calling embed() twice."""
    fm = fractal_memory
    await fm.session_start("test")

    # Track embed calls
    embed_call_count = 0
    original_embed = fm._embeddings.embed

    async def counting_embed(text):
        nonlocal embed_call_count
        embed_call_count += 1
        return await original_embed(text)

    fm._embeddings.embed = counting_embed

    # In pioneer mode (gate_signal_count=1), the gate passes with 1 signal
    # but the direct-pass path doesn't compute an embedding, so store still
    # embeds once. The optimization only applies to waiting-room promotion path.
    mem = await fm.store("test embedding reuse", domain="test")
    assert mem is not None
    # Should have called embed: once for zoom generate + once for store embed
    # (gate direct-pass doesn't compute embedding)
    # The key check: no MORE than expected calls
    assert embed_call_count >= 1


# ---------------------------------------------------------------------------
# Issue #7: Pioneer→Shrub transition tests
# ---------------------------------------------------------------------------


async def test_pioneer_to_shrub_restores_default_gate_count(tmp_path, mock_embeddings, mock_llm):
    """Issue #7: After enough memories/sessions, gate_signal_count restores to default."""
    from fractal_memory import FractalMemory
    from fractal_memory.config import FractalConfig

    config = FractalConfig(
        db_path=tmp_path / "pioneer_test.db",
        gate_signal_count=1,  # Pioneer mode
        domain_sparse_memory_threshold=20,
        domain_sparse_session_threshold=3,
    )
    fm = FractalMemory(config, llm=mock_llm, embeddings=mock_embeddings)
    await fm.initialize()
    try:
        assert fm._config.gate_signal_count == 1

        # Simulate enough memories and sessions to trigger transition
        # Need: memory_count >= domain_sparse_memory_threshold (20)
        #       and session_count >= domain_sparse_session_threshold (3)
        for s in range(4):
            await fm.session_start("test")
            for i in range(6):
                await fm.store(f"memory {s}_{i}", domain="test")
            await fm.session_end()

        # Re-initialize to trigger _check_gate_transition
        await fm._check_gate_transition()
        assert fm._config.gate_signal_count == 2  # Shrub default
    finally:
        await fm.close()


async def test_propagate_config_updates_all_subsystems(tmp_path, mock_embeddings, mock_llm):
    """Issue #7: _propagate_config updates config on all subsystems."""
    import dataclasses

    from fractal_memory import FractalMemory
    from fractal_memory.config import FractalConfig

    config = FractalConfig(db_path=tmp_path / "propagate_test.db")
    fm = FractalMemory(config, llm=mock_llm, embeddings=mock_embeddings)
    await fm.initialize()
    try:
        new_config = dataclasses.replace(config, gate_signal_count=3)
        fm._propagate_config(new_config)

        assert fm._config is new_config
        assert fm._gate._config is new_config
        assert fm._storage._config is new_config
        assert fm._retrieval._config is new_config
    finally:
        await fm.close()
