"""Tests for fractal_memory.bandits — ContextualBandit / Thompson Sampling (Phase 3)."""

from __future__ import annotations

import pytest

from fractal_memory.bandits import (
    ARMS_CONFIG,
    ContextualBandit,
    RetrievalArm,
    _bin_morphogen,
    _context_key,
)
from fractal_memory.config import FractalConfig
from fractal_memory.morphogens import MorphogenState


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(bandit_downscale_factor=0.5)


@pytest.fixture
def bandit(cfg: FractalConfig) -> ContextualBandit:
    return ContextualBandit(config=cfg)


def _morph(ir: float = 0.5, rp: float = 0.5, dd: float = 0.5) -> MorphogenState:
    return MorphogenState(
        information_richness=ir,
        retrieval_pressure=rp,
        domain_density=dd,
    )


# ---------------------------------------------------------------------------
# Context binning
# ---------------------------------------------------------------------------


def test_bin_morphogen_low() -> None:
    assert _bin_morphogen(0.0) == 0
    assert _bin_morphogen(0.32) == 0


def test_bin_morphogen_medium() -> None:
    assert _bin_morphogen(0.33) == 1
    assert _bin_morphogen(0.66) == 1


def test_bin_morphogen_high() -> None:
    assert _bin_morphogen(0.67) == 2
    assert _bin_morphogen(1.0) == 2


def test_context_key_format() -> None:
    key = _context_key(_morph(0.1, 0.5, 0.9))
    parts = key.split("_")
    assert len(parts) == 3
    assert all(p in ("0", "1", "2") for p in parts)


def test_context_key_distinct_bins() -> None:
    k1 = _context_key(_morph(0.1, 0.1, 0.1))
    k2 = _context_key(_morph(0.9, 0.9, 0.9))
    assert k1 != k2


def test_context_key_all_medium() -> None:
    assert _context_key(_morph(0.5, 0.5, 0.5)) == "1_1_1"


# ---------------------------------------------------------------------------
# select_arm
# ---------------------------------------------------------------------------


def test_select_arm_returns_retrieval_arm(bandit: ContextualBandit) -> None:
    arm = bandit.select_arm(_morph())
    assert isinstance(arm, RetrievalArm)


def test_select_arm_name_is_known(bandit: ContextualBandit) -> None:
    arm = bandit.select_arm(_morph())
    assert arm.name in ARMS_CONFIG


def test_select_arm_sets_current_arm(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph())
    assert bandit.current_arm is not None
    assert bandit.current_arm in ARMS_CONFIG


def test_select_arm_initialises_context(bandit: ContextualBandit) -> None:
    m = _morph(0.1, 0.1, 0.1)
    bandit.select_arm(m)
    ctx_key = _context_key(m)
    assert ctx_key in bandit._arms
    assert len(bandit._arms[ctx_key]) == len(ARMS_CONFIG)


# ---------------------------------------------------------------------------
# record_outcome — Beta posterior updates
# ---------------------------------------------------------------------------


def test_record_outcome_success_increases_alpha(bandit: ContextualBandit) -> None:
    m = _morph()
    bandit.select_arm(m)
    arm_name = bandit.current_arm
    ctx = bandit._current_context_key
    alpha_before = bandit._arms[ctx][arm_name].alpha
    bandit.record_outcome(success=True)
    assert bandit._arms[ctx][arm_name].alpha == alpha_before + 1.0


def test_record_outcome_failure_increases_beta(bandit: ContextualBandit) -> None:
    m = _morph()
    bandit.select_arm(m)
    arm_name = bandit.current_arm
    ctx = bandit._current_context_key
    beta_before = bandit._arms[ctx][arm_name].beta_param
    bandit.record_outcome(success=False)
    assert bandit._arms[ctx][arm_name].beta_param == beta_before + 1.0


def test_record_outcome_no_op_without_select(bandit: ContextualBandit) -> None:
    # No select_arm called — should not raise
    bandit.record_outcome(success=True)


# ---------------------------------------------------------------------------
# get_arm_stats
# ---------------------------------------------------------------------------


def test_get_arm_stats_has_all_arms(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph())
    stats = bandit.get_arm_stats()
    assert set(stats.keys()) == set(ARMS_CONFIG.keys())


def test_get_arm_stats_has_expected_keys(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph())
    stats = bandit.get_arm_stats()
    for arm_stats in stats.values():
        assert "alpha" in arm_stats
        assert "beta" in arm_stats
        assert "mean_success" in arm_stats
        assert "pulls" in arm_stats


def test_get_arm_stats_mean_success_range(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph())
    bandit.record_outcome(success=True)
    stats = bandit.get_arm_stats()
    for arm_stats in stats.values():
        assert 0.0 <= arm_stats["mean_success"] <= 1.0


def test_get_arm_stats_pulls_increase_after_outcome(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph())
    before = bandit.get_arm_stats()[bandit.current_arm]["pulls"]
    bandit.record_outcome(success=True)
    after = bandit.get_arm_stats()[bandit.current_arm]["pulls"]
    assert after > before


# ---------------------------------------------------------------------------
# downscale_posteriors
# ---------------------------------------------------------------------------


def test_downscale_reduces_alpha(bandit: ContextualBandit) -> None:
    m = _morph()
    bandit.select_arm(m)
    bandit.record_outcome(success=True)
    bandit.record_outcome(success=True)
    ctx = bandit._current_context_key
    arm_name = bandit.current_arm
    alpha_before = bandit._arms[ctx][arm_name].alpha
    bandit.downscale_posteriors(factor=0.5)
    assert bandit._arms[ctx][arm_name].alpha < alpha_before


def test_downscale_floors_at_one(bandit: ContextualBandit) -> None:
    m = _morph()
    bandit.select_arm(m)
    bandit.downscale_posteriors(factor=0.0001)
    ctx = bandit._current_context_key
    for arm in bandit._arms[ctx].values():
        assert arm.alpha >= 1.0
        assert arm.beta_param >= 1.0


def test_downscale_uses_config_factor(bandit: ContextualBandit) -> None:
    m = _morph()
    bandit.select_arm(m)
    bandit.record_outcome(success=True)
    ctx = bandit._current_context_key
    arm_name = bandit.current_arm
    alpha_before = bandit._arms[ctx][arm_name].alpha
    bandit.downscale_posteriors()  # uses cfg.bandit_downscale_factor = 0.5
    expected = max(1.0, alpha_before * 0.5)
    assert abs(bandit._arms[ctx][arm_name].alpha - expected) < 1e-6


# ---------------------------------------------------------------------------
# Serialization roundtrip
# ---------------------------------------------------------------------------


def test_serialize_deserialize_roundtrip(cfg: FractalConfig) -> None:
    bandit = ContextualBandit(cfg)
    m = _morph()
    bandit.select_arm(m)
    bandit.record_outcome(success=True)
    data = bandit.serialize()
    bandit2 = ContextualBandit.deserialize(data, cfg)
    assert bandit2.current_arm == bandit.current_arm
    ctx = bandit._current_context_key
    assert ctx is not None
    assert ctx in bandit2._arms


def test_deserialize_preserves_posteriors(cfg: FractalConfig) -> None:
    bandit = ContextualBandit(cfg)
    m = _morph(0.1, 0.9, 0.5)
    bandit.select_arm(m)
    bandit.record_outcome(success=True)
    bandit.record_outcome(success=True)
    data = bandit.serialize()
    bandit2 = ContextualBandit.deserialize(data, cfg)
    ctx = bandit._current_context_key
    arm_name = bandit.current_arm
    assert bandit2._arms[ctx][arm_name].alpha == bandit._arms[ctx][arm_name].alpha


def test_serialize_empty_bandit(cfg: FractalConfig) -> None:
    bandit = ContextualBandit(cfg)
    data = bandit.serialize()
    assert data["arms"] == {}
    bandit2 = ContextualBandit.deserialize(data, cfg)
    assert bandit2.current_arm is None


# ---------------------------------------------------------------------------
# Multiple context bins
# ---------------------------------------------------------------------------


def test_different_morphogens_create_separate_bins(bandit: ContextualBandit) -> None:
    bandit.select_arm(_morph(0.1, 0.1, 0.1))  # bin 0_0_0
    bandit.select_arm(_morph(0.9, 0.9, 0.9))  # bin 2_2_2
    assert len(bandit._arms) == 2


def test_same_bin_shares_posteriors(bandit: ContextualBandit) -> None:
    m1 = _morph(0.5, 0.5, 0.5)
    m2 = _morph(0.4, 0.45, 0.55)  # same bin 1_1_1
    bandit.select_arm(m1)
    arm_name = bandit.current_arm
    bandit.record_outcome(success=True)
    alpha_after_first = bandit._arms["1_1_1"][arm_name].alpha

    bandit.select_arm(m2)
    # Alpha should be same because same bin
    assert bandit._arms["1_1_1"][arm_name].alpha == alpha_after_first


# ---------------------------------------------------------------------------
# Context binning — 27 bins (3^3)
# ---------------------------------------------------------------------------


def test_context_binning_27_bins() -> None:
    """All 27 context bins are reachable (3 levels per 3 morphogens)."""
    bins_seen = set()
    for ir_level in [0.1, 0.5, 0.9]:
        for rp_level in [0.1, 0.5, 0.9]:
            for dd_level in [0.1, 0.5, 0.9]:
                key = _context_key(_morph(ir_level, rp_level, dd_level))
                bins_seen.add(key)
    assert len(bins_seen) == 27


# ---------------------------------------------------------------------------
# Thompson sampling — exploration / exploitation
# ---------------------------------------------------------------------------


def test_thompson_sampling_exploration(cfg: FractalConfig) -> None:
    """With uniform priors, all 5 arms should be selected at least once over many trials."""
    bandit = ContextualBandit(cfg)
    m = _morph()
    arms_seen = set()
    for _ in range(200):
        arm = bandit.select_arm(m)
        arms_seen.add(arm.name)
    assert len(arms_seen) == len(ARMS_CONFIG), f"Only saw arms {arms_seen}"


def test_thompson_sampling_exploitation(cfg: FractalConfig) -> None:
    """After heavy positive feedback on one arm, that arm should be selected most often."""
    bandit = ContextualBandit(cfg)
    m = _morph()
    # Force "balanced" arm to have strong posterior
    bandit.select_arm(m)
    target_arm = bandit.current_arm
    for _ in range(50):
        bandit.select_arm(m)
        # Force selection to be target arm for feedback
        bandit._current_arm = target_arm
        bandit.record_outcome(success=True)

    # Now select many times and check that target arm dominates
    count = 0
    trials = 100
    for _ in range(trials):
        arm = bandit.select_arm(m)
        if arm.name == target_arm:
            count += 1
    assert count > trials * 0.5, f"{target_arm} selected only {count}/{trials}"
