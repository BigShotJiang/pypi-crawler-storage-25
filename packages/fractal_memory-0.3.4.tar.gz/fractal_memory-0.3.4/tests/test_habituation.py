"""Tests for Phase 2 — Buffer habituation extension."""

from __future__ import annotations

from uuid import uuid4

import pytest

from fractal_memory.buffer import WorkingMemoryBuffer as WorkingBuffer
from fractal_memory.config import FractalConfig


@pytest.fixture
def buf(tmp_config: FractalConfig):
    return WorkingBuffer(tmp_config)


# ---------------------------------------------------------------------------
# update_habituation
# ---------------------------------------------------------------------------


def test_update_habituation_returns_no_habituated_on_first(buf: WorkingBuffer):
    ids = [uuid4() for _ in range(3)]
    habituated = buf.update_habituation(ids)
    # First injection — none habituated yet
    assert habituated == []


def test_update_habituation_marks_after_threshold(buf: WorkingBuffer):
    mid = uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([mid])
    # After window turns, next injection should flag as habituated
    habituated = buf.update_habituation([mid])
    assert mid in habituated


def test_is_habituated_false_before_threshold(buf: WorkingBuffer):
    mid = uuid4()
    window = buf._config.habituation_window
    for _ in range(window - 1):
        buf.update_habituation([mid])
    assert not buf.is_habituated(mid)


def test_is_habituated_true_at_threshold(buf: WorkingBuffer):
    mid = uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([mid])
    assert buf.is_habituated(mid)


def test_reset_habituation_clears_counter(buf: WorkingBuffer):
    mid = uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([mid])
    assert buf.is_habituated(mid)
    buf.reset_habituation(mid)
    assert not buf.is_habituated(mid)


def test_update_habituation_unaffected_memories(buf: WorkingBuffer):
    a, b = uuid4(), uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([a])
    # b has not been injected — should not be habituated
    assert not buf.is_habituated(b)


def test_clear_resets_habituation(buf: WorkingBuffer):
    mid = uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([mid])
    buf.clear()
    assert not buf.is_habituated(mid)


def test_multiple_memories_independent_counters(buf: WorkingBuffer):
    a, b = uuid4(), uuid4()
    window = buf._config.habituation_window
    for _ in range(window):
        buf.update_habituation([a])
    # a is habituated (reached window), b is not
    assert buf.is_habituated(a)
    assert not buf.is_habituated(b)
