# Contributing to Fractal Memory

## Development Setup

```bash
# Clone
git clone https://github.com/entropyvector/fractal-memory.git
cd fractal-memory

# Create virtual environment
python3.11 -m venv .venv
source .venv/bin/activate

# Install with all extras
pip install -e ".[dev,dashboard]"
```

## Running Tests

```bash
pytest
```

Tests use `pytest-asyncio` with `asyncio_mode = "auto"` — async test functions are detected automatically.

## Code Style

- **Async-first** — all I/O must be async. No sync database drivers in async contexts.
- **Type annotations** on all public functions.
- **No hardcoding** — all configurable parameters go in `FractalConfig` (`src/fractal_memory/config.py`).
- **Extend, don't rewrite** — no phase may rewrite prior phase code. Use hooks, callbacks, or new modules.
- **Single source of truth** — `FractalConfig` is the only config object. No shadow configs.

See `internal/requirements/CODE_REQUIREMENTS.md` for the full specification.

## Project Structure

```
src/fractal_memory/
├── __init__.py          # FractalMemory main class
├── config.py            # FractalConfig — all parameters
├── storage.py           # SQLite persistence (async via aiosqlite)
├── models.py            # Data models (Memory, Session, etc.)
├── cli.py               # Click CLI (fractal command)
├── mcp/
│   └── server.py        # MCP server (fractal-memory-mcp)
└── dashboard/           # FastAPI dashboard
    ├── app.py
    ├── templates/
    └── static/
```

## Architecture

The codebase is organized by evolutionary phases. Each phase builds on the previous:

- **Phase 1 (Pioneer):** Core store/retrieve, 5 zoom levels, lifecycle, gate
- **Phase 2 (Shrub):** Association network, danger theory, scar tissue, consolidation
- **Phase 3 (Forest):** Morphogenetic fields, niche construction, dreaming, maintenance
- **Phase 4 (Old Growth):** Aliveness diagnostic, memory packs, cross-domain (planned)

See `internal/plans/` for detailed phase plans.

## Pull Request Process

1. Fork the repository
2. Create a feature branch from `main`
3. Make your changes (follow the code style above)
4. Add tests for new functionality
5. Run `pytest` and ensure all tests pass
6. Submit a PR against `main`

## Reporting Issues

Open an issue at https://github.com/entropyvector/fractal-memory/issues with:
- What you expected to happen
- What actually happened
- Steps to reproduce
- Your Python version and OS
