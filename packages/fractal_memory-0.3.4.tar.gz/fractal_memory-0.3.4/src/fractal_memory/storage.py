"""SQLite persistence layer for fractal-memory (async via aiosqlite)."""

from __future__ import annotations

import json
import logging
import os
import struct
from datetime import datetime
from pathlib import Path
from uuid import UUID, uuid4

import aiosqlite

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig

logger = logging.getLogger(__name__)
from fractal_memory.models import (
    LifecycleStatus,
    Memory,
    Session,
    Task,
    TaskStatus,
    WaitingRoomEntry,
)

# ---------------------------------------------------------------------------
# Embedding serialization helpers
# ---------------------------------------------------------------------------


def _pack_embedding(embedding: list[float]) -> bytes:
    import math
    if any(math.isnan(v) or math.isinf(v) for v in embedding):
        raise ValueError("Embedding contains NaN or Inf values")
    return struct.pack(f"<{len(embedding)}f", *embedding)


def _unpack_embedding(blob: bytes, dim: int | None = None) -> list[float]:
    if dim is None:
        dim = len(blob) // 4
    return list(struct.unpack(f"<{dim}f", blob))


# ---------------------------------------------------------------------------
# Row → model helpers
# ---------------------------------------------------------------------------


def _row_to_memory(row: aiosqlite.Row) -> Memory:
    return Memory(
        id=UUID(row["id"]),
        domain=row["domain"],
        created_at=datetime.fromisoformat(row["created_at"]),
        updated_at=datetime.fromisoformat(row["updated_at"]),
        context=json.loads(row["context"]) if row["context"] else {},
        l0_tag=row["l0_tag"],
        l1_label=row["l1_label"],
        l2_summary=row["l2_summary"],
        l3_full=row["l3_full"],
        l4_raw=row["l4_raw"],
        embedding=_unpack_embedding(row["embedding"]),
        embedding_model=row["embedding_model"],
        intensity=row["intensity"],
        retrieval_count=row["retrieval_count"],
        miss_count=row["miss_count"],
        last_accessed=(
            datetime.fromisoformat(row["last_accessed"])
            if row["last_accessed"]
            else None
        ),
        lifecycle=LifecycleStatus(row["lifecycle"]),
        chronic_score=row["chronic_score"],
        contrast=row["contrast"],
        chain_next=UUID(row["chain_next"]) if row["chain_next"] else None,
        chain_prev=UUID(row["chain_prev"]) if row["chain_prev"] else None,
        vitality=row["vitality"],
        reconsolidation_count=row["reconsolidation_count"],
        origin=row["origin"],
        trust_score=row["trust_score"],
        pinned=bool(row["pinned"]) if "pinned" in row.keys() else False,
    )


def _row_to_task(row: aiosqlite.Row) -> Task:
    return Task(
        id=UUID(row["id"]),
        description=row["description"],
        created_at=datetime.fromisoformat(row["created_at"]),
        status=TaskStatus(row["status"]),
        related_memory_ids=(
            [UUID(x) for x in json.loads(row["related_memory_ids"])]
            if row["related_memory_ids"]
            else []
        ),
        priority=row["priority"],
    )


def _row_to_waiting(row: aiosqlite.Row) -> WaitingRoomEntry:
    return WaitingRoomEntry(
        id=UUID(row["id"]),
        content=row["content"],
        first_signal=json.loads(row["first_signal"]) if row["first_signal"] else {},
        domain=row["domain"],
        created_at=datetime.fromisoformat(row["created_at"]),
        sessions_elapsed=row["sessions_elapsed"],
        embedding=_unpack_embedding(row["embedding"]) if row["embedding"] else [],
    )


def _row_to_session(row: aiosqlite.Row) -> Session:
    return Session(
        id=UUID(row["id"]),
        domain=row["domain"],
        started_at=datetime.fromisoformat(row["started_at"]),
        ended_at=(
            datetime.fromisoformat(row["ended_at"]) if row["ended_at"] else None
        ),
        summary=row["summary"],
    )


# ---------------------------------------------------------------------------
# Schema SQL
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS memories (
    id              TEXT PRIMARY KEY,
    domain          TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,
    context         TEXT,
    l0_tag          TEXT NOT NULL,
    l1_label        TEXT NOT NULL,
    l2_summary      TEXT NOT NULL,
    l3_full         TEXT NOT NULL,
    l4_raw          TEXT NOT NULL,
    embedding       BLOB NOT NULL,
    embedding_model TEXT NOT NULL,
    intensity       REAL NOT NULL DEFAULT 0.5,
    retrieval_count INTEGER NOT NULL DEFAULT 0,
    miss_count      INTEGER NOT NULL DEFAULT 0,
    last_accessed   TEXT,
    lifecycle       TEXT NOT NULL DEFAULT 'probation',
    chronic_score   REAL NOT NULL DEFAULT 0.0,
    contrast        TEXT,
    chain_next      TEXT,
    chain_prev      TEXT,
    vitality        REAL NOT NULL DEFAULT 1.0,
    reconsolidation_count INTEGER NOT NULL DEFAULT 0,
    origin          TEXT NOT NULL DEFAULT 'organic',
    trust_score     REAL NOT NULL DEFAULT 1.0,
    pinned          INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_memories_domain ON memories(domain);
CREATE INDEX IF NOT EXISTS idx_memories_lifecycle ON memories(lifecycle);
CREATE INDEX IF NOT EXISTS idx_memories_chain_next ON memories(chain_next);
CREATE INDEX IF NOT EXISTS idx_memories_last_accessed ON memories(last_accessed);

CREATE TABLE IF NOT EXISTS tasks (
    id                  TEXT PRIMARY KEY,
    description         TEXT NOT NULL,
    created_at          TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'active',
    related_memory_ids  TEXT,
    priority            INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS waiting_room (
    id               TEXT PRIMARY KEY,
    content          TEXT NOT NULL,
    first_signal     TEXT,
    domain           TEXT,
    created_at       TEXT NOT NULL,
    sessions_elapsed INTEGER NOT NULL DEFAULT 0,
    embedding        BLOB
);

CREATE TABLE IF NOT EXISTS sessions (
    id         TEXT PRIMARY KEY,
    domain     TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at   TEXT,
    summary    TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_domain ON sessions(domain);

-- Phase 2+ tables (created empty at init)
-- Note: associations uses application-level cascade (delete_memory() removes edges)
-- rather than FK constraints because SQLite FK ON DELETE CASCADE requires table recreation
-- for existing databases. Data integrity is enforced by delete_memory().
CREATE TABLE IF NOT EXISTS associations (
    source_id              TEXT NOT NULL,
    target_id              TEXT NOT NULL,
    weight                 REAL NOT NULL DEFAULT 0.1,
    trail_weight           REAL NOT NULL DEFAULT 0.0,
    trail_context_centroid BLOB,
    created_at             TEXT NOT NULL,
    PRIMARY KEY (source_id, target_id)
);

CREATE INDEX IF NOT EXISTS idx_associations_source ON associations(source_id);
CREATE INDEX IF NOT EXISTS idx_associations_target ON associations(target_id);

CREATE TABLE IF NOT EXISTS scars (
    id               TEXT PRIMARY KEY,
    pattern_embedding BLOB NOT NULL,
    memory_id        TEXT,
    reason           TEXT NOT NULL,
    created_at       TEXT NOT NULL,
    ttl_sessions     INTEGER NOT NULL DEFAULT 20,
    sessions_elapsed INTEGER NOT NULL DEFAULT 0
);

-- Phase 2+ table: one row per ended session — Phase 4 Aliveness timeline foundation
CREATE TABLE IF NOT EXISTS session_summaries (
    session_id     TEXT PRIMARY KEY,
    started_at     TEXT NOT NULL,
    ended_at       TEXT NOT NULL,
    store_count    INTEGER NOT NULL DEFAULT 0,
    retrieve_count INTEGER NOT NULL DEFAULT 0,
    scar_count     INTEGER NOT NULL DEFAULT 0,
    merge_count    INTEGER NOT NULL DEFAULT 0,
    edge_count     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_session_summaries_ended_at ON session_summaries(ended_at);

-- Phase 3+ tables
CREATE TABLE IF NOT EXISTS maintenance_log (
    tier     TEXT PRIMARY KEY,
    last_run TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS correction_events (
    id               TEXT PRIMARY KEY,
    occurred_at      TEXT NOT NULL,
    memory_id        TEXT,
    original_pattern TEXT,
    correction_text  TEXT,
    scar_id          TEXT,
    session_id       TEXT
);
CREATE INDEX IF NOT EXISTS idx_correction_events_occurred_at ON correction_events(occurred_at);

-- Phase 3+ table: live session activity — one row per active session, flushed every N ops.
-- Enables dashboard heartbeat across process boundaries via SQLite polling.
CREATE TABLE IF NOT EXISTS session_activity (
    session_id   TEXT PRIMARY KEY,
    domain       TEXT NOT NULL,
    started_at   TEXT NOT NULL,
    stores       INTEGER NOT NULL DEFAULT 0,
    retrievals   INTEGER NOT NULL DEFAULT 0,
    last_updated TEXT NOT NULL
);
"""


# ---------------------------------------------------------------------------
# Storage class
# ---------------------------------------------------------------------------


class Storage:
    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        self._db_path = Path(config.db_path) if not isinstance(config.db_path, Path) else config.db_path
        self._conn: aiosqlite.Connection | None = None

    async def initialize(self) -> None:
        db_path = self._db_path.expanduser()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        is_new = not db_path.exists()
        self._conn = await aiosqlite.connect(str(db_path))
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA foreign_keys=ON")
        await self._conn.executescript(_SCHEMA_SQL)
        # Insert initial schema version if not present
        async with self._conn.execute(
            "SELECT COUNT(*) FROM schema_version"
        ) as cur:
            row = await cur.fetchone()
            if row[0] == 0:
                await self._conn.execute(
                    "INSERT INTO schema_version (version) VALUES (?)", (1,)
                )
        await self._conn.commit()
        # Run Phase 2 schema migration (idempotent)
        await self._migrate_phase2_schema()
        # Run Phase 3 schema migration (idempotent)
        await self._migrate_phase3_schema()
        # Set user-only permissions on new database files
        if is_new and db_path.exists():
            os.chmod(db_path, 0o600)

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    # -- helpers --

    def _ensure_conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Storage not initialized — call initialize() first")
        return self._conn

    # -----------------------------------------------------------------------
    # Memory CRUD
    # -----------------------------------------------------------------------

    async def store_memory(self, memory: Memory) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO memories (
                id, domain, created_at, updated_at, context,
                l0_tag, l1_label, l2_summary, l3_full, l4_raw,
                embedding, embedding_model, intensity,
                retrieval_count, miss_count, last_accessed,
                lifecycle, chronic_score, contrast,
                chain_next, chain_prev,
                vitality, reconsolidation_count, origin, trust_score, pinned
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                str(memory.id),
                memory.domain,
                memory.created_at.isoformat(),
                memory.updated_at.isoformat(),
                json.dumps(memory.context) if memory.context else None,
                memory.l0_tag,
                memory.l1_label,
                memory.l2_summary,
                memory.l3_full,
                memory.l4_raw,
                _pack_embedding(memory.embedding),
                memory.embedding_model,
                memory.intensity,
                memory.retrieval_count,
                memory.miss_count,
                memory.last_accessed.isoformat() if memory.last_accessed else None,
                memory.lifecycle.value,
                memory.chronic_score,
                memory.contrast,
                str(memory.chain_next) if memory.chain_next else None,
                str(memory.chain_prev) if memory.chain_prev else None,
                memory.vitality,
                memory.reconsolidation_count,
                memory.origin,
                memory.trust_score,
                int(memory.pinned),
            ),
        )
        await conn.commit()

    async def get_memory(self, memory_id: UUID) -> Memory | None:
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM memories WHERE id = ?", (str(memory_id),)
        ) as cur:
            row = await cur.fetchone()
            return _row_to_memory(row) if row else None

    async def delete_memory(self, memory_id: UUID) -> bool:
        conn = self._ensure_conn()
        mid = str(memory_id)
        # Clear dangling chain references on linked memories
        await conn.execute(
            "UPDATE memories SET chain_next = NULL WHERE chain_next = ?", (mid,)
        )
        await conn.execute(
            "UPDATE memories SET chain_prev = NULL WHERE chain_prev = ?", (mid,)
        )
        async with conn.execute(
            "DELETE FROM memories WHERE id = ?", (mid,)
        ) as cur:
            deleted = cur.rowcount > 0
        # Clean up all references including association edges
        await conn.execute(
            "DELETE FROM waiting_room WHERE id = ?", (mid,)
        )
        await conn.execute(
            "DELETE FROM associations WHERE source_id = ? OR target_id = ?", (mid, mid)
        )
        await conn.commit()
        return deleted

    async def rollback_merge(self, memory_id: UUID) -> None:
        """Remove a merged memory and its edges — used for merge rollback (Issue #45)."""
        conn = self._ensure_conn()
        mid = str(memory_id)
        await conn.execute("DELETE FROM memories WHERE id = ?", (mid,))
        await conn.execute(
            "DELETE FROM associations WHERE source_id = ? OR target_id = ?",
            (mid, mid),
        )
        await conn.commit()

    async def get_all_memory_domains(self) -> list[tuple[str, str]]:
        """Return (memory_id, domain) for all memories — single query (Issue #47)."""
        conn = self._ensure_conn()
        results: list[tuple[str, str]] = []
        async with conn.execute("SELECT id, domain FROM memories") as cur:
            async for row in cur:
                results.append((row["id"], row["domain"]))
        return results

    async def update_memory(self, memory: Memory) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """UPDATE memories SET
                domain=?, updated_at=?, context=?,
                l0_tag=?, l1_label=?, l2_summary=?, l3_full=?, l4_raw=?,
                embedding=?, embedding_model=?, intensity=?,
                retrieval_count=?, miss_count=?, last_accessed=?,
                lifecycle=?, chronic_score=?, contrast=?,
                chain_next=?, chain_prev=?,
                vitality=?, reconsolidation_count=?, origin=?, trust_score=?,
                pinned=?
            WHERE id=?""",
            (
                memory.domain,
                memory.updated_at.isoformat(),
                json.dumps(memory.context) if memory.context else None,
                memory.l0_tag,
                memory.l1_label,
                memory.l2_summary,
                memory.l3_full,
                memory.l4_raw,
                _pack_embedding(memory.embedding),
                memory.embedding_model,
                memory.intensity,
                memory.retrieval_count,
                memory.miss_count,
                memory.last_accessed.isoformat() if memory.last_accessed else None,
                memory.lifecycle.value,
                memory.chronic_score,
                memory.contrast,
                str(memory.chain_next) if memory.chain_next else None,
                str(memory.chain_prev) if memory.chain_prev else None,
                memory.vitality,
                memory.reconsolidation_count,
                memory.origin,
                memory.trust_score,
                int(memory.pinned),
                str(memory.id),
            ),
        )
        await conn.commit()

    async def get_all_embeddings(
        self, domain: str,
    ) -> list[tuple[UUID, list[float]]]:
        conn = self._ensure_conn()
        results: list[tuple[UUID, list[float]]] = []
        async with conn.execute(
            "SELECT id, embedding FROM memories WHERE domain = ?", (domain,)
        ) as cur:
            async for row in cur:
                results.append((UUID(row["id"]), _unpack_embedding(row["embedding"])))
        return results

    async def get_memories_by_ids(self, ids: list[UUID]) -> list[Memory]:
        if not ids:
            return []
        conn = self._ensure_conn()
        placeholders = ",".join("?" for _ in ids)
        id_strs = [str(i) for i in ids]
        rows: list[Memory] = []
        async with conn.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders})", id_strs
        ) as cur:
            async for row in cur:
                rows.append(_row_to_memory(row))
        # Preserve input order
        id_map = {m.id: m for m in rows}
        return [id_map[i] for i in ids if i in id_map]

    async def get_memories_by_domain(self, domain: str) -> list[Memory]:
        conn = self._ensure_conn()
        results: list[Memory] = []
        async with conn.execute(
            "SELECT * FROM memories WHERE domain = ?", (domain,)
        ) as cur:
            async for row in cur:
                results.append(_row_to_memory(row))
        return results

    async def get_memories_by_lifecycle(
        self, lifecycle: LifecycleStatus,
    ) -> list[Memory]:
        conn = self._ensure_conn()
        results: list[Memory] = []
        async with conn.execute(
            "SELECT * FROM memories WHERE lifecycle = ?", (lifecycle.value,)
        ) as cur:
            async for row in cur:
                results.append(_row_to_memory(row))
        return results

    async def count_memories(self, domain: str | None = None) -> int:
        conn = self._ensure_conn()
        if domain:
            async with conn.execute(
                "SELECT COUNT(*) FROM memories WHERE domain = ?", (domain,)
            ) as cur:
                row = await cur.fetchone()
        else:
            async with conn.execute("SELECT COUNT(*) FROM memories") as cur:
                row = await cur.fetchone()
        return row[0] if row else 0

    # -----------------------------------------------------------------------
    # Waiting room CRUD
    # -----------------------------------------------------------------------

    async def store_waiting_room_entry(self, entry: WaitingRoomEntry) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO waiting_room
               (id, content, first_signal, domain, created_at, sessions_elapsed, embedding)
               VALUES (?,?,?,?,?,?,?)""",
            (
                str(entry.id),
                entry.content,
                json.dumps(entry.first_signal),
                entry.domain,
                entry.created_at.isoformat(),
                entry.sessions_elapsed,
                _pack_embedding(entry.embedding) if entry.embedding else None,
            ),
        )
        await conn.commit()

    async def get_waiting_room_entry(
        self, entry_id: UUID,
    ) -> WaitingRoomEntry | None:
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM waiting_room WHERE id = ?", (str(entry_id),)
        ) as cur:
            row = await cur.fetchone()
            return _row_to_waiting(row) if row else None

    async def find_waiting_room_by_content(
        self, embedding: list[float], threshold: float = 0.85,
    ) -> WaitingRoomEntry | None:
        """Find a waiting room entry semantically similar to the given embedding."""
        conn = self._ensure_conn()
        import numpy as np

        query_vec = np.array(embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)
        if query_norm == 0:
            return None

        best_entry: WaitingRoomEntry | None = None
        best_sim = -1.0

        async with conn.execute(
            "SELECT * FROM waiting_room WHERE embedding IS NOT NULL"
        ) as cur:
            async for row in cur:
                entry_emb = _unpack_embedding(row["embedding"])
                entry_vec = np.array(entry_emb, dtype=np.float32)
                entry_norm = np.linalg.norm(entry_vec)
                if entry_norm == 0:
                    continue
                sim = float(np.dot(query_vec, entry_vec) / (query_norm * entry_norm))
                if sim >= threshold and sim > best_sim:
                    best_sim = sim
                    best_entry = _row_to_waiting(row)

        return best_entry

    async def delete_waiting_room_entry(self, entry_id: UUID) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            "DELETE FROM waiting_room WHERE id = ?", (str(entry_id),)
        )
        await conn.commit()

    async def get_expired_waiting_room_entries(
        self, max_sessions: int,
    ) -> list[WaitingRoomEntry]:
        conn = self._ensure_conn()
        results: list[WaitingRoomEntry] = []
        async with conn.execute(
            "SELECT * FROM waiting_room WHERE sessions_elapsed >= ?",
            (max_sessions,),
        ) as cur:
            async for row in cur:
                results.append(_row_to_waiting(row))
        return results

    async def increment_waiting_room_sessions(self) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            "UPDATE waiting_room SET sessions_elapsed = sessions_elapsed + 1"
        )
        await conn.commit()

    async def evict_oldest_waiting_room(self, max_size: int) -> int:
        conn = self._ensure_conn()
        async with conn.execute("SELECT COUNT(*) FROM waiting_room") as cur:
            row = await cur.fetchone()
            count = row[0] if row else 0

        if count <= max_size:
            return 0

        to_evict = count - max_size
        await conn.execute(
            """DELETE FROM waiting_room WHERE id IN (
                SELECT id FROM waiting_room ORDER BY created_at ASC LIMIT ?
            )""",
            (to_evict,),
        )
        await conn.commit()
        return to_evict

    # -----------------------------------------------------------------------
    # Task CRUD
    # -----------------------------------------------------------------------

    async def store_task(self, task: Task) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO tasks (id, description, created_at, status, related_memory_ids, priority)
               VALUES (?,?,?,?,?,?)""",
            (
                str(task.id),
                task.description,
                task.created_at.isoformat(),
                task.status.value,
                json.dumps([str(x) for x in task.related_memory_ids]),
                task.priority,
            ),
        )
        await conn.commit()

    async def get_task(self, task_id: UUID) -> Task | None:
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM tasks WHERE id = ?", (str(task_id),)
        ) as cur:
            row = await cur.fetchone()
            return _row_to_task(row) if row else None

    async def update_task(self, task: Task) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """UPDATE tasks SET description=?, status=?, related_memory_ids=?, priority=?
               WHERE id=?""",
            (
                task.description,
                task.status.value,
                json.dumps([str(x) for x in task.related_memory_ids]),
                task.priority,
                str(task.id),
            ),
        )
        await conn.commit()

    async def list_tasks(self, status: TaskStatus | None = None) -> list[Task]:
        conn = self._ensure_conn()
        results: list[Task] = []
        if status:
            query = "SELECT * FROM tasks WHERE status = ?"
            params: tuple = (status.value,)
        else:
            query = "SELECT * FROM tasks"
            params = ()
        async with conn.execute(query, params) as cur:
            async for row in cur:
                results.append(_row_to_task(row))
        return results

    # -----------------------------------------------------------------------
    # Session CRUD
    # -----------------------------------------------------------------------

    async def store_session(self, session: Session) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO sessions (id, domain, started_at, ended_at, summary)
               VALUES (?,?,?,?,?)""",
            (
                str(session.id),
                session.domain,
                session.started_at.isoformat(),
                session.ended_at.isoformat() if session.ended_at else None,
                session.summary,
            ),
        )
        await conn.commit()

    async def update_session(self, session: Session) -> None:
        conn = self._ensure_conn()
        await conn.execute(
            "UPDATE sessions SET ended_at=?, summary=? WHERE id=?",
            (
                session.ended_at.isoformat() if session.ended_at else None,
                session.summary,
                str(session.id),
            ),
        )
        await conn.commit()

    async def get_last_session(self, domain: str) -> Session | None:
        conn = self._ensure_conn()
        async with conn.execute(
            """SELECT * FROM sessions
               WHERE domain = ? AND ended_at IS NOT NULL
               ORDER BY ended_at DESC LIMIT 1""",
            (domain,),
        ) as cur:
            row = await cur.fetchone()
            return _row_to_session(row) if row else None

    async def get_sessions_since(self, since: datetime) -> list[Session]:
        conn = self._ensure_conn()
        results: list[Session] = []
        async with conn.execute(
            "SELECT * FROM sessions WHERE started_at >= ?",
            (since.isoformat(),),
        ) as cur:
            async for row in cur:
                results.append(_row_to_session(row))
        return results

    async def get_session_count(self, domain: str | None = None) -> int:
        conn = self._ensure_conn()
        if domain:
            async with conn.execute(
                "SELECT COUNT(*) FROM sessions WHERE domain = ? AND ended_at IS NOT NULL",
                (domain,),
            ) as cur:
                row = await cur.fetchone()
        else:
            async with conn.execute(
                "SELECT COUNT(*) FROM sessions WHERE ended_at IS NOT NULL"
            ) as cur:
                row = await cur.fetchone()
        return row[0] if row else 0

    async def get_probation_memories(self, ttl_sessions: int) -> list[Memory]:
        """Get probation memories older than ttl_sessions completed sessions."""
        conn = self._ensure_conn()
        # Count completed sessions
        async with conn.execute(
            "SELECT COUNT(*) FROM sessions WHERE ended_at IS NOT NULL"
        ) as cur:
            row = await cur.fetchone()
            total_sessions = row[0] if row else 0

        if total_sessions < ttl_sessions:
            return []

        # Get probation memories created before (total_sessions - ttl_sessions) sessions ago
        # Approximate by finding the session started_at for the cutoff
        async with conn.execute(
            """SELECT started_at FROM sessions WHERE ended_at IS NOT NULL
               ORDER BY started_at ASC LIMIT 1 OFFSET ?""",
            (total_sessions - ttl_sessions,),
        ) as cur:
            row = await cur.fetchone()
            if not row:
                return []
            cutoff = row[0]  # ISO string

        results: list[Memory] = []
        async with conn.execute(
            """SELECT * FROM memories
               WHERE lifecycle = 'probation' AND created_at <= ?""",
            (cutoff,),
        ) as cur:
            async for row in cur:
                results.append(_row_to_memory(row))
        return results

    # -----------------------------------------------------------------------
    # Session summaries (Phase 2 — Option 12)
    # -----------------------------------------------------------------------

    async def record_session_summary(
        self,
        session_id: UUID,
        started_at: datetime,
        ended_at: datetime,
        store_count: int,
        retrieve_count: int,
        scar_count: int = 0,
        merge_count: int = 0,
        edge_count: int = 0,
        retrieval_hits: int = 0,
    ) -> None:
        """Write one row to session_summaries at session_end.

        One write per session, zero per-op overhead. Provides the per-session
        history that Phase 4's Aliveness Diagnostic timeline ribbon requires.
        Idempotent: uses INSERT OR REPLACE so re-running session_end is safe.

        Args:
            session_id: ID of the ended session.
            started_at: When the session started.
            ended_at: When the session ended.
            store_count: Number of memory_store calls this session.
            retrieve_count: Number of memory_retrieve calls this session.
            scar_count: Number of scars created this session (Phase 2+).
            merge_count: Number of merges performed this session (Phase 2+).
            edge_count: Total association edges at session end (Phase 2+).
        """
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT OR REPLACE INTO session_summaries
               (session_id, started_at, ended_at,
                store_count, retrieve_count, scar_count, merge_count, edge_count,
                retrieval_hits)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                str(session_id),
                started_at.isoformat(),
                ended_at.isoformat(),
                store_count,
                retrieve_count,
                scar_count,
                merge_count,
                edge_count,
                retrieval_hits,
            ),
        )
        await conn.commit()

    async def get_session_summaries(self, limit: int = 90) -> list[dict]:
        """Return the most recent session summaries, newest first.

        Args:
            limit: Maximum number of rows to return. Default 90 (≈ 90 days
                   of daily sessions) — covers Phase 4 timeline ribbon window.

        Returns:
            List of dicts with keys: session_id, started_at, ended_at,
            store_count, retrieve_count, scar_count, merge_count, edge_count.
        """
        conn = self._ensure_conn()
        results: list[dict] = []
        async with conn.execute(
            """SELECT session_id, started_at, ended_at,
                      store_count, retrieve_count,
                      scar_count, merge_count, edge_count
               FROM session_summaries
               ORDER BY ended_at DESC LIMIT ?""",
            (limit,),
        ) as cur:
            async for row in cur:
                results.append(dict(row))
        return results

    # -----------------------------------------------------------------------
    # Domain aggregation
    # -----------------------------------------------------------------------

    async def list_domains(self) -> list[tuple[str, int, str]]:
        """Returns (domain, count, last_updated_at) tuples."""
        conn = self._ensure_conn()
        results: list[tuple[str, int, str]] = []
        async with conn.execute(
            """SELECT domain, COUNT(*) as cnt, MAX(updated_at) as last_updated
               FROM memories GROUP BY domain"""
        ) as cur:
            async for row in cur:
                results.append((row["domain"], row["cnt"], row["last_updated"]))
        return results

    # -----------------------------------------------------------------------
    # Stats queries
    # -----------------------------------------------------------------------

    async def get_lifecycle_counts(self) -> dict[str, int]:
        """Return memory counts grouped by lifecycle status."""
        conn = self._ensure_conn()
        result: dict[str, int] = {}
        async with conn.execute(
            "SELECT lifecycle, COUNT(*) as cnt FROM memories GROUP BY lifecycle"
        ) as cur:
            async for row in cur:
                result[row["lifecycle"]] = row["cnt"]
        return result

    async def get_recent_memories(self, limit: int = 10) -> list[Memory]:
        """Return the most recently created memories."""
        conn = self._ensure_conn()
        results: list[Memory] = []
        async with conn.execute(
            "SELECT * FROM memories ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ) as cur:
            async for row in cur:
                results.append(_row_to_memory(row))
        return results

    async def get_domain_lifecycle_breakdown(
        self,
    ) -> list[tuple[str, str, int]]:
        """Return (domain, lifecycle, count) tuples."""
        conn = self._ensure_conn()
        results: list[tuple[str, str, int]] = []
        async with conn.execute(
            "SELECT domain, lifecycle, COUNT(*) as cnt "
            "FROM memories GROUP BY domain, lifecycle"
        ) as cur:
            async for row in cur:
                results.append((row["domain"], row["lifecycle"], row["cnt"]))
        return results

    # -----------------------------------------------------------------------
    # Schema migration helpers (Phase 2 upgrade)
    # -----------------------------------------------------------------------

    async def _migrate_phase2_schema(self) -> None:
        """Migrate legacy Phase 1 associations/scars tables to Phase 2 schema.

        Idempotent — safe to run on already-migrated databases.
        """
        conn = self._ensure_conn()

        # Check current schema version
        async with conn.execute("SELECT MAX(version) FROM schema_version") as cur:
            row = await cur.fetchone()
            current_version = row[0] if row and row[0] else 1

        if current_version >= 2:
            return  # Already migrated

        # Migrate associations table: add missing columns if absent
        async with conn.execute("PRAGMA table_info(associations)") as cur:
            existing_cols = {r["name"] async for r in cur}

        if "trail_weight" not in existing_cols:
            await conn.execute(
                "ALTER TABLE associations ADD COLUMN trail_weight REAL NOT NULL DEFAULT 0.0"
            )
        if "trail_context_centroid" not in existing_cols:
            await conn.execute(
                "ALTER TABLE associations ADD COLUMN trail_context_centroid BLOB"
            )

        # Migrate scars table: Phase 1 had different schema — drop and recreate
        # (Phase 1 scars table was empty so no data loss)
        await conn.execute("DROP TABLE IF EXISTS scars")
        await conn.execute(
            """CREATE TABLE scars (
                id                TEXT PRIMARY KEY,
                pattern_embedding BLOB NOT NULL,
                memory_id         TEXT,
                reason            TEXT NOT NULL,
                created_at        TEXT NOT NULL,
                ttl_sessions      INTEGER NOT NULL DEFAULT 20,
                sessions_elapsed  INTEGER NOT NULL DEFAULT 0
            )"""
        )

        # Ensure indexes exist
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_associations_source ON associations(source_id)"
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_associations_target ON associations(target_id)"
        )

        # Ensure session_summaries table exists — new in Phase 2.
        # Databases created before Phase 2 won't have it in _SCHEMA_SQL history.
        await conn.execute(
            """CREATE TABLE IF NOT EXISTS session_summaries (
                session_id     TEXT PRIMARY KEY,
                started_at     TEXT NOT NULL,
                ended_at       TEXT NOT NULL,
                store_count    INTEGER NOT NULL DEFAULT 0,
                retrieve_count INTEGER NOT NULL DEFAULT 0,
                scar_count     INTEGER NOT NULL DEFAULT 0,
                merge_count    INTEGER NOT NULL DEFAULT 0,
                edge_count     INTEGER NOT NULL DEFAULT 0
            )"""
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_session_summaries_ended_at "
            "ON session_summaries(ended_at)"
        )

        await conn.execute(
            "INSERT OR REPLACE INTO schema_version (version) VALUES (2)"
        )
        await conn.commit()

    # -----------------------------------------------------------------------
    # Association CRUD (Phase 2)
    # -----------------------------------------------------------------------

    async def store_association(
        self,
        source_id: UUID,
        target_id: UUID,
        weight: float,
        trail_weight: float = 0.0,
        trail_context_centroid: list[float] | None = None,
    ) -> None:
        """Insert or update an association edge."""
        if source_id == target_id:
            return  # Prevent self-loops
        conn = self._ensure_conn()
        centroid_blob = (
            _pack_embedding(trail_context_centroid)
            if trail_context_centroid is not None
            else None
        )
        await conn.execute(
            """INSERT INTO associations
               (source_id, target_id, weight, trail_weight, trail_context_centroid, created_at)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(source_id, target_id) DO UPDATE SET
                 weight=excluded.weight,
                 trail_weight=excluded.trail_weight,
                 trail_context_centroid=excluded.trail_context_centroid""",
            (
                str(source_id),
                str(target_id),
                weight,
                trail_weight,
                centroid_blob,
                utcnow().isoformat(),
            ),
        )
        await conn.commit()

    async def get_associations(
        self, memory_id: UUID
    ) -> list[tuple[UUID, float, float, list[float] | None]]:
        """Return all edges for a memory (bidirectional).

        Returns list of (target_id, weight, trail_weight, trail_context_centroid).
        """
        conn = self._ensure_conn()
        mid = str(memory_id)
        results: list[tuple[UUID, float, float, list[float] | None]] = []

        async with conn.execute(
            """SELECT target_id, weight, trail_weight, trail_context_centroid
               FROM associations WHERE source_id = ?""",
            (mid,),
        ) as cur:
            async for row in cur:
                centroid = (
                    _unpack_embedding(row["trail_context_centroid"])
                    if row["trail_context_centroid"]
                    else None
                )
                results.append((
                    UUID(row["target_id"]),
                    row["weight"],
                    row["trail_weight"],
                    centroid,
                ))

        async with conn.execute(
            """SELECT source_id, weight, trail_weight, trail_context_centroid
               FROM associations WHERE target_id = ?""",
            (mid,),
        ) as cur:
            async for row in cur:
                centroid = (
                    _unpack_embedding(row["trail_context_centroid"])
                    if row["trail_context_centroid"]
                    else None
                )
                results.append((
                    UUID(row["source_id"]),
                    row["weight"],
                    row["trail_weight"],
                    centroid,
                ))

        return results

    async def get_all_associations(self) -> list[tuple[UUID, UUID, float]]:
        """Return all edges as (source_id, target_id, weight)."""
        conn = self._ensure_conn()
        results: list[tuple[UUID, UUID, float]] = []
        async with conn.execute(
            "SELECT source_id, target_id, weight FROM associations"
        ) as cur:
            async for row in cur:
                results.append((
                    UUID(row["source_id"]), UUID(row["target_id"]), row["weight"]
                ))
        return results

    async def update_association_weight(
        self, source_id: UUID, target_id: UUID, weight: float
    ) -> None:
        """Update edge weight bidirectionally."""
        conn = self._ensure_conn()
        await conn.execute(
            """UPDATE associations SET weight=?
               WHERE (source_id=? AND target_id=?) OR (source_id=? AND target_id=?)""",
            (weight, str(source_id), str(target_id), str(target_id), str(source_id)),
        )
        await conn.commit()

    async def batch_decay_and_prune(self, factor: float, min_weight: float) -> int:
        """Decay all edge weights by factor and delete sub-threshold edges (Issue #38).

        Uses two bulk SQL statements instead of per-edge updates.

        Args:
            factor: Multiplicative decay factor (0 < factor < 1).
            min_weight: Minimum viable edge weight; edges below are deleted.

        Returns:
            Count of edges pruned.
        """
        conn = self._ensure_conn()
        # Batch update: multiply all weights
        await conn.execute("UPDATE associations SET weight = weight * ?", (factor,))
        # Batch delete: remove edges below threshold
        async with conn.execute(
            "SELECT COUNT(*) FROM associations WHERE weight < ?", (min_weight,)
        ) as cur:
            row = await cur.fetchone()
            pruned = row[0] if row else 0
        await conn.execute("DELETE FROM associations WHERE weight < ?", (min_weight,))
        await conn.commit()
        return pruned

    async def update_association_trail(
        self,
        source_id: UUID,
        target_id: UUID,
        trail_weight: float,
        trail_context_centroid: list[float] | None,
    ) -> None:
        """Update trail weight and centroid for an edge."""
        conn = self._ensure_conn()
        centroid_blob = (
            _pack_embedding(trail_context_centroid)
            if trail_context_centroid is not None
            else None
        )
        await conn.execute(
            """UPDATE associations SET trail_weight=?, trail_context_centroid=?
               WHERE (source_id=? AND target_id=?) OR (source_id=? AND target_id=?)""",
            (
                trail_weight,
                centroid_blob,
                str(source_id),
                str(target_id),
                str(target_id),
                str(source_id),
            ),
        )
        await conn.commit()

    async def delete_association(self, source_id: UUID, target_id: UUID) -> None:
        """Remove an edge."""
        conn = self._ensure_conn()
        await conn.execute(
            """DELETE FROM associations
               WHERE (source_id=? AND target_id=?) OR (source_id=? AND target_id=?)""",
            (str(source_id), str(target_id), str(target_id), str(source_id)),
        )
        await conn.commit()

    async def delete_weak_associations(self, min_weight: float) -> int:
        """Delete all edges with weight below min_weight. Returns count deleted."""
        conn = self._ensure_conn()
        async with conn.execute(
            "DELETE FROM associations WHERE weight < ?", (min_weight,)
        ) as cur:
            count = cur.rowcount
        await conn.commit()
        return count

    async def count_associations(self, memory_id: UUID) -> int:
        """Return the number of edges for a given memory (both directions)."""
        conn = self._ensure_conn()
        mid = str(memory_id)
        async with conn.execute(
            "SELECT COUNT(*) FROM associations WHERE source_id=? OR target_id=?",
            (mid, mid),
        ) as cur:
            row = await cur.fetchone()
        return row[0] if row else 0

    async def get_weakest_association(
        self, memory_id: UUID
    ) -> tuple[UUID, UUID, float] | None:
        """Return (source_id, target_id, weight) for the weakest edge of a memory."""
        conn = self._ensure_conn()
        mid = str(memory_id)
        async with conn.execute(
            """SELECT source_id, target_id, weight FROM associations
               WHERE source_id=? OR target_id=?
               ORDER BY weight ASC LIMIT 1""",
            (mid, mid),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        return (UUID(row["source_id"]), UUID(row["target_id"]), row["weight"])

    async def get_total_association_count(self) -> int:
        """Return total number of association edges."""
        conn = self._ensure_conn()
        async with conn.execute("SELECT COUNT(*) FROM associations") as cur:
            row = await cur.fetchone()
        return row[0] if row else 0

    # -----------------------------------------------------------------------
    # Scar CRUD (Phase 2)
    # -----------------------------------------------------------------------

    async def store_scar(
        self,
        scar_id: UUID,
        pattern_embedding: list[float],
        memory_id: UUID | None,
        reason: str,
        ttl_sessions: int,
        sessions_elapsed: int = 0,
    ) -> None:
        """Insert a scar record."""
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO scars
               (id, pattern_embedding, memory_id, reason, created_at, ttl_sessions, sessions_elapsed)
               VALUES (?,?,?,?,?,?,?)""",
            (
                str(scar_id),
                _pack_embedding(pattern_embedding),
                str(memory_id) if memory_id else None,
                reason,
                utcnow().isoformat(),
                ttl_sessions,
                sessions_elapsed,
            ),
        )
        await conn.commit()

    async def get_active_scars(
        self,
    ) -> list[tuple[UUID, list[float], UUID | None, str, int, int]]:
        """Return all active scars as (id, pattern_embedding, memory_id, reason, ttl, elapsed)."""
        conn = self._ensure_conn()
        results = []
        async with conn.execute(
            "SELECT * FROM scars WHERE sessions_elapsed < ttl_sessions"
        ) as cur:
            async for row in cur:
                results.append((
                    UUID(row["id"]),
                    _unpack_embedding(row["pattern_embedding"]),
                    UUID(row["memory_id"]) if row["memory_id"] else None,
                    row["reason"],
                    row["ttl_sessions"],
                    row["sessions_elapsed"],
                ))
        return results

    async def increment_scar_sessions(self) -> None:
        """Increment sessions_elapsed for all scars."""
        conn = self._ensure_conn()
        await conn.execute(
            "UPDATE scars SET sessions_elapsed = sessions_elapsed + 1"
        )
        await conn.commit()

    async def delete_expired_scars(self) -> int:
        """Delete scars where sessions_elapsed >= ttl_sessions. Returns count."""
        conn = self._ensure_conn()
        async with conn.execute(
            "DELETE FROM scars WHERE sessions_elapsed >= ttl_sessions"
        ) as cur:
            count = cur.rowcount
        await conn.commit()
        return count

    async def find_scar_by_pattern(
        self, embedding: list[float], threshold: float = 0.85
    ) -> tuple[UUID, int] | None:
        """Find a scar with pattern_embedding similar to the given embedding.

        Returns (scar_id, sessions_elapsed) for the best match above threshold, or None.
        """
        import numpy as np

        conn = self._ensure_conn()
        query_vec = np.array(embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)
        if query_norm == 0:
            return None

        best_id: UUID | None = None
        best_elapsed = 0
        best_sim = -1.0

        async with conn.execute(
            "SELECT id, pattern_embedding, sessions_elapsed FROM scars "
            "WHERE sessions_elapsed < ttl_sessions"
        ) as cur:
            async for row in cur:
                emb = _unpack_embedding(row["pattern_embedding"])
                vec = np.array(emb, dtype=np.float32)
                vnorm = np.linalg.norm(vec)
                if vnorm == 0:
                    continue
                sim = float(np.dot(query_vec, vec) / (query_norm * vnorm))
                if sim >= threshold and sim > best_sim:
                    best_sim = sim
                    best_id = UUID(row["id"])
                    best_elapsed = row["sessions_elapsed"]

        return (best_id, best_elapsed) if best_id else None

    async def reset_scar_sessions_elapsed(self, scar_id: UUID) -> None:
        """Reset a scar's sessions_elapsed to 0 (TTL reset on reinforcement)."""
        conn = self._ensure_conn()
        await conn.execute(
            "UPDATE scars SET sessions_elapsed=0 WHERE id=?", (str(scar_id),)
        )
        await conn.commit()

    # -----------------------------------------------------------------------
    # Schema migration (Phase 3 — session_activity table)
    # -----------------------------------------------------------------------

    async def _migrate_phase3_schema(self) -> None:
        """Migrate schema to Phase 3: session_activity, maintenance_log,
        and correction_events tables.

        Idempotent — safe to run on already-migrated databases.
        Version 3 = session_activity only (legacy).
        Version 4 = full Phase 3 schema (maintenance_log, correction_events).
        """
        conn = self._ensure_conn()

        async with conn.execute("SELECT MAX(version) FROM schema_version") as cur:
            row = await cur.fetchone()
            current_version = row[0] if row and row[0] else 1

        # ------------------------------------------------------------------
        # Version 3: session_activity (original Phase 3 migration)
        # ------------------------------------------------------------------
        if current_version < 3:
            await conn.execute(
                """CREATE TABLE IF NOT EXISTS session_activity (
                    session_id   TEXT PRIMARY KEY,
                    domain       TEXT NOT NULL,
                    started_at   TEXT NOT NULL,
                    stores       INTEGER NOT NULL DEFAULT 0,
                    retrievals   INTEGER NOT NULL DEFAULT 0,
                    last_updated TEXT NOT NULL
                )"""
            )
            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (3)"
            )
            await conn.commit()

        # ------------------------------------------------------------------
        # Version 4: full Phase 3 schema
        # ------------------------------------------------------------------
        if current_version < 4:
            await conn.execute(
                """CREATE TABLE IF NOT EXISTS maintenance_log (
                    tier     TEXT PRIMARY KEY,
                    last_run TEXT NOT NULL
                )"""
            )

            await conn.execute(
                """CREATE TABLE IF NOT EXISTS correction_events (
                    id               TEXT PRIMARY KEY,
                    occurred_at      TEXT NOT NULL,
                    memory_id        TEXT,
                    original_pattern TEXT,
                    correction_text  TEXT,
                    scar_id          TEXT,
                    session_id       TEXT
                )"""
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_correction_events_occurred_at "
                "ON correction_events(occurred_at)"
            )

            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (4)"
            )
            await conn.commit()

        # ------------------------------------------------------------------
        # Version 5: morphogen_history table (Phase 3 — cross-session warmup)
        # ------------------------------------------------------------------
        if current_version < 5:
            await conn.execute(
                """CREATE TABLE IF NOT EXISTS morphogen_history (
                    id          TEXT PRIMARY KEY,
                    session_id  TEXT NOT NULL,
                    morphogens  TEXT NOT NULL,
                    created_at  TEXT NOT NULL
                )"""
            )
            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (5)"
            )
            await conn.commit()

        # ------------------------------------------------------------------
        # Version 6: retrieval_hits column on session_summaries
        # ------------------------------------------------------------------
        if current_version < 6:
            # Add retrieval_hits column if missing
            async with conn.execute("PRAGMA table_info(session_summaries)") as cur:
                existing_cols = {r["name"] async for r in cur}
            if "retrieval_hits" not in existing_cols:
                await conn.execute(
                    "ALTER TABLE session_summaries ADD COLUMN retrieval_hits INTEGER NOT NULL DEFAULT 0"
                )
            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (6)"
            )
            await conn.commit()

        # ------------------------------------------------------------------
        # Version 7: bandit_state table (Phase 3 — bandit persistence, Issue #30)
        # ------------------------------------------------------------------
        if current_version < 7:
            await conn.execute(
                """CREATE TABLE IF NOT EXISTS bandit_state (
                    id          TEXT PRIMARY KEY,
                    state_json  TEXT NOT NULL,
                    created_at  TEXT NOT NULL
                )"""
            )
            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (7)"
            )
            await conn.commit()

        # ------------------------------------------------------------------
        # Version 8: pinned column on memories (persistent pin flag)
        # ------------------------------------------------------------------
        if current_version < 8:
            try:
                await conn.execute(
                    "ALTER TABLE memories ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0"
                )
            except Exception:
                pass  # Column may already exist
            await conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (8)"
            )
            await conn.commit()

    # -----------------------------------------------------------------------
    # Session activity CRUD (Phase 3 — dashboard heartbeat)
    # -----------------------------------------------------------------------

    async def upsert_session_activity(
        self,
        session_id: UUID,
        domain: str,
        started_at: datetime,
        stores: int,
        retrievals: int,
    ) -> None:
        """Write or update the live activity row for the current session.

        Called every N store/retrieve ops by FractalMemory to give the dashboard
        a near-real-time heartbeat without per-op write overhead.
        """
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO session_activity
               (session_id, domain, started_at, stores, retrievals, last_updated)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(session_id) DO UPDATE SET
                 stores=excluded.stores,
                 retrievals=excluded.retrievals,
                 last_updated=excluded.last_updated""",
            (
                str(session_id),
                domain,
                started_at.isoformat(),
                stores,
                retrievals,
                utcnow().isoformat(),
            ),
        )
        await conn.commit()

    async def get_session_activity(self, session_id: UUID) -> dict | None:
        """Return the activity row for a specific session, or None."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM session_activity WHERE session_id = ?",
            (str(session_id),),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        return dict(row)

    async def get_latest_session_activity(self) -> dict | None:
        """Return the most recently updated session_activity row, or None."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM session_activity ORDER BY last_updated DESC LIMIT 1"
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        return dict(row)

    async def get_all_active_session_activity(
        self, stale_seconds: float = 600,
    ) -> list[dict]:
        """Return all session_activity rows updated within *stale_seconds*."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT * FROM session_activity ORDER BY last_updated DESC"
        ) as cur:
            rows = await cur.fetchall()
        if not rows:
            return []
        result = []
        now = utcnow()
        for row in rows:
            d = dict(row)
            try:
                last = datetime.fromisoformat(d.get("last_updated", ""))
                if last.tzinfo is not None:
                    last = last.replace(tzinfo=None)
                if (now - last).total_seconds() <= stale_seconds:
                    result.append(d)
            except (ValueError, TypeError):
                logger.debug("Skipping session_activity row with malformed timestamp", exc_info=True)
                continue
        return result

    async def delete_session_activity(self, session_id: UUID) -> None:
        """Remove the activity row for a completed session."""
        conn = self._ensure_conn()
        await conn.execute(
            "DELETE FROM session_activity WHERE session_id = ?",
            (str(session_id),),
        )
        await conn.commit()

    # -----------------------------------------------------------------------
    # Maintenance log (Phase 3+)
    # -----------------------------------------------------------------------

    async def get_maintenance_log(self, tier: str) -> "datetime | None":
        """Return last run timestamp for a maintenance tier, or None if never run."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT last_run FROM maintenance_log WHERE tier=?", (tier,)
        ) as cur:
            row = await cur.fetchone()
            if row is None:
                return None
            return datetime.fromisoformat(row["last_run"])

    async def set_maintenance_log(self, tier: str, timestamp: "datetime") -> None:
        """Upsert the last run timestamp for a maintenance tier."""
        conn = self._ensure_conn()
        await conn.execute(
            "INSERT INTO maintenance_log (tier, last_run) VALUES (?,?) ON CONFLICT(tier) DO UPDATE SET last_run=excluded.last_run",
            (tier, timestamp.isoformat()),
        )
        await conn.commit()

    # -----------------------------------------------------------------------
    # Apoptosis queries (Phase 3+)
    # -----------------------------------------------------------------------

    async def get_memories_by_vitality(
        self, max_vitality: float, domain: str | None = None
    ) -> list[Memory]:
        """Return memories with vitality below max_vitality, optionally filtered by domain."""
        conn = self._ensure_conn()
        results: list[Memory] = []
        if domain:
            async with conn.execute(
                "SELECT * FROM memories WHERE vitality < ? AND domain = ?",
                (max_vitality, domain),
            ) as cur:
                async for row in cur:
                    results.append(_row_to_memory(row))
        else:
            async with conn.execute(
                "SELECT * FROM memories WHERE vitality < ?", (max_vitality,)
            ) as cur:
                async for row in cur:
                    results.append(_row_to_memory(row))
        return results

    async def get_chronic_memories(
        self, threshold: float, min_sessions: int = 5
    ) -> list[Memory]:
        """Return memories with chronic_score above threshold and accessed in >= min_sessions.

        Uses retrieval_count as a proxy for distinct session access count.
        """
        conn = self._ensure_conn()
        results: list[Memory] = []
        async with conn.execute(
            "SELECT * FROM memories WHERE chronic_score >= ? AND retrieval_count >= ? "
            "ORDER BY chronic_score DESC",
            (threshold, min_sessions),
        ) as cur:
            async for row in cur:
                results.append(_row_to_memory(row))
        return results

    # -----------------------------------------------------------------------
    # Correction events (Phase 3+)
    # -----------------------------------------------------------------------

    async def store_correction_event(
        self,
        event_id: "UUID",
        occurred_at: "datetime",
        memory_id: "UUID | None",
        original_pattern: str | None,
        correction_text: str,
        scar_id: "UUID | None",
        session_id: "UUID | None",
    ) -> None:
        """Append an immutable correction event to the correction_events log."""
        conn = self._ensure_conn()
        await conn.execute(
            """INSERT INTO correction_events
               (id, occurred_at, memory_id, original_pattern, correction_text, scar_id, session_id)
               VALUES (?,?,?,?,?,?,?)""",
            (
                str(event_id),
                occurred_at.isoformat(),
                str(memory_id) if memory_id else None,
                original_pattern,
                correction_text,
                str(scar_id) if scar_id else None,
                str(session_id) if session_id else None,
            ),
        )
        await conn.commit()

    async def save_morphogen_state(self, session_id: UUID, morphogens: dict[str, float]) -> None:
        """Persist morphogen state for cross-session warm-up.

        Args:
            session_id: The session that produced this morphogen state.
            morphogens: Mapping of morphogen names to their current values.

        Added in Phase 3 for cross-session morphogen warm-up.
        See also: ``get_morphogen_history``.
        """
        conn = self._ensure_conn()
        row_id = str(uuid4())
        now = utcnow().isoformat()
        await conn.execute(
            "INSERT INTO morphogen_history (id, session_id, morphogens, created_at) VALUES (?, ?, ?, ?)",
            (row_id, str(session_id), json.dumps(morphogens), now),
        )
        await conn.commit()

    async def get_morphogen_history(self, limit: int = 20) -> list[dict]:
        """Return morphogen state history from previous sessions.

        Reads from the ``morphogen_history`` table (schema version 5).
        Returns empty list if no prior sessions have morphogen data.
        """
        conn = self._ensure_conn()
        results: list[dict] = []
        try:
            async with conn.execute(
                "SELECT morphogens FROM morphogen_history ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ) as cur:
                async for row in cur:
                    try:
                        data = json.loads(row["morphogens"])
                        if isinstance(data, dict):
                            results.append(data)
                    except (json.JSONDecodeError, TypeError):
                        logger.warning("Malformed JSON in morphogen_history row, skipping")
        except Exception:
            logger.debug("get_morphogen_history failed", exc_info=True)
        return results

    async def save_bandit_state(self, state: dict) -> None:
        """Persist bandit posteriors for cross-session learning (Issue #30).

        Stores a single JSON blob keyed by a fixed ID so each save overwrites
        the previous state (only the latest snapshot matters).
        """
        conn = self._ensure_conn()
        now = utcnow().isoformat()
        try:
            await conn.execute(
                """INSERT INTO bandit_state (id, state_json, created_at)
                   VALUES ('latest', ?, ?)
                   ON CONFLICT(id) DO UPDATE SET state_json=excluded.state_json, created_at=excluded.created_at""",
                (json.dumps(state), now),
            )
            await conn.commit()
        except Exception:
            logger.debug("save_bandit_state failed", exc_info=True)

    async def load_bandit_state(self) -> dict | None:
        """Load the most recent bandit state snapshot.

        Returns:
            The deserialised state dict, or None if no saved state exists.
        """
        conn = self._ensure_conn()
        try:
            async with conn.execute(
                "SELECT state_json FROM bandit_state WHERE id = 'latest'"
            ) as cur:
                row = await cur.fetchone()
                if row:
                    return json.loads(row["state_json"])
        except Exception:
            logger.debug("load_bandit_state failed", exc_info=True)
        return None

    async def get_correction_events(self, limit: int = 50) -> list[dict]:
        """Return recent correction events ordered by occurred_at desc."""
        conn = self._ensure_conn()
        results = []
        async with conn.execute(
            "SELECT * FROM correction_events ORDER BY occurred_at DESC LIMIT ?", (limit,)
        ) as cur:
            async for row in cur:
                results.append({
                    "id": row["id"],
                    "occurred_at": row["occurred_at"],
                    "memory_id": row["memory_id"],
                    "original_pattern": row["original_pattern"],
                    "correction_text": row["correction_text"],
                    "scar_id": row["scar_id"],
                    "session_id": row["session_id"],
                })
        return results

    # ------------------------------------------------------------------
    # Phase 3: Additional methods used by new modules
    # ------------------------------------------------------------------

    async def get_top_memories_for_rem(self, limit: int = 20) -> list:
        """Return top memories by retrieval_count * intensity for REM recombination."""
        from fractal_memory.models import Memory as MemModel
        conn = self._ensure_conn()
        rows = []
        async with conn.execute(
            """SELECT * FROM memories
               ORDER BY (retrieval_count * intensity) DESC
               LIMIT ?""",
            (limit,),
        ) as cur:
            async for row in cur:
                rows.append(_row_to_memory(row))
        return rows

    async def update_vitality_batch(self, memory_ids: list) -> int:
        """Recompute and persist vitality for a list of memory IDs. Returns count updated."""
        if not memory_ids:
            return 0
        conn = self._ensure_conn()
        count = 0
        for mid in memory_ids:
            mid_str = str(mid)
            async with conn.execute(
                "SELECT retrieval_count, miss_count FROM memories WHERE id = ?", (mid_str,)
            ) as cur:
                row = await cur.fetchone()
            if row is None:
                continue
            rc = row["retrieval_count"] or 0
            mc = row["miss_count"] or 0
            total = rc + mc
            # Linear vitality: hit_rate, not hit_rate² (fixes quadratic penalty bug)
            vitality = max(0.0, min(1.0, rc / max(1, total)))
            await conn.execute(
                "UPDATE memories SET vitality = ? WHERE id = ?", (vitality, mid_str)
            )
            count += 1
        await conn.commit()
        return count

    async def update_chronic_batch(self, memory_ids: list) -> int:
        """Update chronic scores for accessed memories. Returns count updated."""
        if not memory_ids:
            return 0
        conn = self._ensure_conn()
        decay = self._config.chronic_decay_factor
        weight = self._config.chronic_retrieval_weight
        count = 0
        for mid in memory_ids:
            mid_str = str(mid)
            async with conn.execute(
                "SELECT chronic_score FROM memories WHERE id = ?", (mid_str,)
            ) as cur:
                row = await cur.fetchone()
            if row is None:
                continue
            new_score = min(1.0, row["chronic_score"] * decay + weight)
            await conn.execute(
                "UPDATE memories SET chronic_score = ? WHERE id = ?", (new_score, mid_str)
            )
            count += 1
        await conn.commit()
        return count

    async def get_edge_stats(self) -> dict:
        """Return association edge statistics."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT COUNT(*) as cnt, AVG(weight) as avg_w, MAX(weight) as max_w FROM associations"
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return {"count": 0, "mean_weight": 0.0, "max_weight": 0.0}
        return {
            "count": row["cnt"] or 0,
            "mean_weight": float(row["avg_w"] or 0.0),
            "max_weight": float(row["max_w"] or 0.0),
        }

    async def get_reinforced_scars(self) -> list[dict]:
        """Return scars that have been reinforced (sessions_elapsed reset multiple times)."""
        conn = self._ensure_conn()
        results = []
        async with conn.execute(
            "SELECT * FROM scars WHERE sessions_elapsed = 0 ORDER BY created_at DESC LIMIT 20"
        ) as cur:
            async for row in cur:
                results.append(dict(row))
        return results

    async def weaken_unused_edges(self, decay: float | None = None) -> int:
        """Decay edge weights for edges not recently accessed. Returns count updated."""
        effective_decay = decay if decay is not None else self._config.slow_wave_decay_factor
        min_weight = self._config.min_viable_edge_weight
        conn = self._ensure_conn()
        async with conn.execute(
            "UPDATE associations SET weight = MAX(?, weight * ?) WHERE weight > ?",
            (min_weight, effective_decay, min_weight),
        ) as cur:
            count = cur.rowcount
        await conn.commit()
        return count

    async def update_vitality_all(self) -> int:
        """Recompute vitality for all memories. Returns count updated."""
        conn = self._ensure_conn()
        async with conn.execute("SELECT id FROM memories") as cur:
            ids = [row["id"] for row in await cur.fetchall()]
        return await self.update_vitality_batch(ids)

    async def list_domains_with_counts(self) -> list[dict]:
        """Return list of dicts with domain and memory count."""
        conn = self._ensure_conn()
        results = []
        async with conn.execute(
            "SELECT domain, COUNT(*) as cnt FROM memories GROUP BY domain ORDER BY cnt DESC"
        ) as cur:
            async for row in cur:
                results.append({"domain": row["domain"], "count": row["cnt"]})
        return results

    async def get_session_stats(self) -> dict:
        """Return session-level retrieval statistics from session_summaries.

        Queries the last 90 days of session summaries (bounded query per
        PERFORMANCE_REQUIREMENTS). retrieval_hits tracks retrievals that
        returned at least one L3 result (recorded by SessionManager).
        """
        conn = self._ensure_conn()
        try:
            async with conn.execute(
                """SELECT COALESCE(SUM(retrieve_count), 0) as retrieval_total,
                          COALESCE(SUM(store_count), 0) as store_total,
                          COUNT(*) as session_count
                   FROM session_summaries
                   WHERE ended_at > datetime('now', '-90 days')"""
            ) as cur:
                row = await cur.fetchone()
            # retrieval_hits column added in schema v6; handle older schemas
            try:
                async with conn.execute(
                    """SELECT COALESCE(SUM(retrieval_hits), 0) as total_hits
                       FROM session_summaries
                       WHERE ended_at > datetime('now', '-90 days')"""
                ) as hits_cur:
                    hits_row = await hits_cur.fetchone()
                total_hits = hits_row["total_hits"] if hits_row else 0
            except Exception:
                total_hits = 0
            return {
                "retrieval_hits": total_hits,
                "retrieval_total": row["retrieval_total"] if row else 0,
                "store_total": row["store_total"] if row else 0,
                "session_count": row["session_count"] if row else 0,
            }
        except Exception:
            logger.debug("get_session_stats failed", exc_info=True)
            return {
                "retrieval_hits": 0,
                "retrieval_total": 0,
                "store_total": 0,
                "session_count": 0,
            }

    async def count_active_scars(self) -> int:
        """Return count of non-expired scars."""
        conn = self._ensure_conn()
        async with conn.execute(
            "SELECT COUNT(*) as cnt FROM scars WHERE sessions_elapsed < ttl_sessions"
        ) as cur:
            row = await cur.fetchone()
        return row["cnt"] if row else 0

    async def get_summary_stats(self) -> dict:
        """Quick summary statistics."""
        conn = self._ensure_conn()
        total_mems = await self.count_memories()
        total_sessions = await self.get_session_count()
        async with conn.execute("SELECT COUNT(*) as cnt FROM associations") as cur:
            row = await cur.fetchone()
        edges = row["cnt"] if row else 0
        async with conn.execute("SELECT COUNT(*) as cnt FROM scars") as cur:
            row = await cur.fetchone()
        scars = row["cnt"] if row else 0
        return {
            "total_memories": total_mems,
            "total_sessions": total_sessions,
            "total_edges": edges,
            "active_scars": scars,
        }

    async def list_memories(
        self,
        domain: str | None = None,
        lifecycle: str | None = None,
        limit: int = 20,
    ) -> list:
        """Return memories with optional domain/lifecycle filters."""
        conn = self._ensure_conn()
        conditions: list[str] = []
        params: list = []
        if domain:
            conditions.append("domain = ?")
            params.append(domain)
        if lifecycle:
            conditions.append("lifecycle = ?")
            params.append(lifecycle)
        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        rows = []
        async with conn.execute(
            f"SELECT * FROM memories {where} ORDER BY updated_at DESC LIMIT ?",
            [*params, limit],
        ) as cur:
            async for row in cur:
                rows.append(_row_to_memory(row))
        return rows
