"""Cascade detection — CircuitBreaker fallback (B-7, Phase 3)."""

from __future__ import annotations

from dataclasses import dataclass

from fractal_memory.config import FractalConfig


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------


@dataclass
class CascadeWarning:
    """Warning issued when a cascade failure is predicted or detected."""

    affected_system: str          # "gate"|"retrieval"|"storage"|"associations"|"domains"
    severity: float               # 0–1
    recommended_action: str       # "loosen_gate"|"widen_activation"|"pause_consolidation"|…
    predicted_sessions_to_impact: int


# ---------------------------------------------------------------------------
# CircuitBreaker (simple fallback)
# ---------------------------------------------------------------------------


class CircuitBreaker:
    """Threshold-based circuit breaker — fallback when B-7 is not validated."""

    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        self._low_hit_sessions: int = 0
        self._high_correction_sessions: int = 0

    def observe(self, session_metrics: dict[str, float]) -> CascadeWarning | None:
        """Simple threshold-based cascade detection.

        Triggers:
        - hit_rate < 0.2 for 3 consecutive sessions → stress state
        - correction_rate > 0.3 for 2 consecutive sessions → loosen gate
        - memory_growth_rate > 50 → tighten gate
        """
        hit_rate = float(session_metrics.get("hit_rate", 1.0))
        correction_rate = float(session_metrics.get("correction_rate", 0.0))
        memory_growth = float(session_metrics.get("memory_growth_rate", 0.0))

        if hit_rate < 0.2:
            self._low_hit_sessions += 1
        else:
            self._low_hit_sessions = 0

        if correction_rate > 0.3:
            self._high_correction_sessions += 1
        else:
            self._high_correction_sessions = 0

        if self._low_hit_sessions >= 3:
            return CascadeWarning(
                affected_system="retrieval",
                severity=0.7,
                recommended_action="widen_activation",
                predicted_sessions_to_impact=1,
            )
        if self._high_correction_sessions >= 2:
            return CascadeWarning(
                affected_system="gate",
                severity=0.5,
                recommended_action="loosen_gate",
                predicted_sessions_to_impact=1,
            )
        if memory_growth > 50:
            return CascadeWarning(
                affected_system="storage",
                severity=0.4,
                recommended_action="tighten_gate",
                predicted_sessions_to_impact=2,
            )
        return None
